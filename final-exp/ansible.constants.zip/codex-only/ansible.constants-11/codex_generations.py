

# Generated at 2022-06-22 19:30:38.266756
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('foo', 'bar', export=test_dict)
    assert 'foo' in test_dict
    assert test_dict['foo'] == 'bar'

# Generate deprecated constants from config

DEPRECATED_CONSTANTS = {}

_CONSTANTS_DEPRECATED_IN_2_9 = (
    # these are the constants deprecated in Ansible 2.9
    ('DEFAULT_MODULE_NAME', 'module_name'),
    ('DEFAULT_MODULE_PATH', 'module_path'),
    ('DEFAULT_MODULE_UTILS_PATH', 'module_utils_path'),
    ('DEFAULT_PLUGIN_PATH', 'plugin_paths'),
)


# Generated at 2022-06-22 19:30:40.153103
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant([0, 1, 2], 'msg', 'version')[1]


# Generated at 2022-06-22 19:30:50.191528
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    class Constants:
        def __init__(self, name, value, msg, version):
            self.name = name
            self.value = _DeprecatedSequenceConstant(value, msg, version)

    constants = Constants('ACTION_ALL_INCLUDE_IMPORT_TASKS', ACTION_ALL_INCLUDE_IMPORT_TASKS,
                          'The ansible.cli.CONSTANTS.ACTION_ALL_INCLUDE_IMPORT_TASKS constant is deprecated since version 2.8. '
                          'Use ansible.plugins.loader.COMPATIBLE_TASK_INCLUDE_IMPORT_KEYS instead.', '2.10')
    assert isinstance(constants.value, _DeprecatedSequenceConstant)

# Generated at 2022-06-22 19:30:52.801074
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert(len(_DeprecatedSequenceConstant((1, 2, 3), "test", "1.0")) == 3)


# Generated at 2022-06-22 19:30:59.568993
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dc1 = _DeprecatedSequenceConstant((1, 2, 3), 'testing', '2.9')
    assert len(dc1) == 3
    assert dc1[1] == 2
    assert dc1[2] == 3
    dc1[1] = 3
    assert dc1[1] == 3
    dc1.append(4)
    assert dc1[3] == 4
    assert dc1[0] == 1
    dc2 = _DeprecatedSequenceConstant([1, 2, 3], 'testing', '2.9')
    assert len(dc2) == 3
    assert dc2[1] == 2
    assert dc2[2] == 3
    dc2[1] = 3
    assert dc2[1] == 3
    dc2.append(4)
    assert dc2[3] == 4

# Generated at 2022-06-22 19:31:10.768803
# Unit test for function set_constant

# Generated at 2022-06-22 19:31:15.535103
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = u'Deprecated message'
    version = u'Version'
    value = [1, 2]
    c = _DeprecatedSequenceConstant(value, msg, version)
    assert len(c) == len(value)
    assert c[0] == value[0]
    assert c[1] == value[1]

# Generated at 2022-06-22 19:31:19.455469
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _msg = "msg"
    _version = "version"
    _value = "value"
    _d = _DeprecatedSequenceConstant(_value,_msg,_version)
    assert _d[0] == "v"


# Generated at 2022-06-22 19:31:31.133896
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_CONFIG_SETTING_FOO', True)
    assert 'ANSIBLE_CONFIG_SETTING_FOO' in vars()


# The following are deprecated CONSTANTS and/or converted to variables.
# FIXME: remove these

# FIXME: convert to variables
# color deprecation
DEPRECATED_COLOR = '''[deprecation warning]: The 'ANSIBLE_NOCOLOR' environment variable,
and corresponding config [defaults] 'nocolor' option, are deprecated and will be
removed in a future version. See
https://docs.ansible.com/ansible/devel/reference_appendices/config.html#conf-nocolor
for details. (exceptions.AnsibleDeprecationWarning)'''

ANSIBLE_LIBRARY = config.get_config

# Generated at 2022-06-22 19:31:35.632405
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_sequence = _DeprecatedSequenceConstant([1, 2], 'msg', 'version')
    assert test_sequence[0] == 1
    assert test_sequence[1] == 2


# Generated at 2022-06-22 19:31:41.046401
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')[2] == 3


# Generated at 2022-06-22 19:31:43.885526
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'foo')
    assert TEST_CONSTANT == 'foo'

# Generated at 2022-06-22 19:31:45.540267
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils import basic
    assert basic.AnsibleModule.fail_json.__name__ == 'fail_json'

# Generated at 2022-06-22 19:31:57.561981
# Unit test for function set_constant
def test_set_constant():
    ''' test setting a constant in a dict and at global scope '''
    dc = {}
    set_constant('FOO', 'BAR', export=dc)
    assert dc['FOO'] == 'BAR'
    set_constant('FOO', 'BAZ')
    assert FOO == 'BAR'


# TODO: these need to become config settings

TIMEOUT = 30  # the timeout for executing modules in seconds
TREE_DIR = None
DEFAULT_KEEP_REMOTE_FILES = True
ANSIBLE_FORCE_COLOR = False
DEFAULT_MODULE_LANG = 'C'
DEFAULT_MODULE_NAME = 'command'
DEFAULT_MODULE_PATH = None
DEFAULT_REMOTE_TMP = None
DEFAULT_SUDO = False

# Generated at 2022-06-22 19:31:58.991696
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant([1, 2, 3], msg='msg', version='v')
    assert len(a) == 3

# Generated at 2022-06-22 19:32:03.363851
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # init
    foo = _DeprecatedSequenceConstant([1, 2, 3], 'msg_foo', '2.0')
    # test
    assert len(foo) == 3
    try:
        len(foo)
    except _Deprecated:
        assert 0

# Generated at 2022-06-22 19:32:07.176719
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), "msg", "1.3")) == 3
    assert len(_DeprecatedSequenceConstant((1, 2, 3), "msg", "1.3")) == 3
    assert len(_DeprecatedSequenceConstant((1, 2, 3), "msg", "1.3")) == 3


# Generated at 2022-06-22 19:32:12.007005
# Unit test for function set_constant
def test_set_constant():
    result_dict = {}
    set_constant('foo', 'bar', export=result_dict)
    assert result_dict['foo'] == 'bar'



# Generated at 2022-06-22 19:32:20.790704
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant([1, 2, "a"], "msg", "version")
    assert len(c) == 3
    assert c[0] == 1
    assert c[2] == "a"
    # test the Deprecated behaviour
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-22 19:32:25.706697
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant(value=("1","2","3"), msg="This is a test", version="2.9")
    assert len(c) == 3
    assert c[0] == "1"
    assert c[2] == "3"

# Generated at 2022-06-22 19:32:32.417705
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence_constant = _DeprecatedSequenceConstant( [1, 2, 3, 4], 'msg', 'version')
    assert len(deprecated_sequence_constant) == 4
    assert deprecated_sequence_constant[0] == 1
    assert deprecated_sequence_constant[1] == 2
    assert deprecated_sequence_constant[2] == 3
    assert deprecated_sequence_constant[3] == 4

# Generated at 2022-06-22 19:32:36.347042
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class MyClass:
        @property
        def y(self):
            return 1
    my = MyClass()
    # TODO: need a better test for the __getitem__ method
    assert _DeprecatedSequenceConstant([1, 2, 3], 'unittest', '1.0')[my.y] == 2

# Generated at 2022-06-22 19:32:44.406934
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    import unittest
    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def test_non_negative_integer(self):
            count = 5
            expected_len = 5
            value = list(range(count))
            msg = 'msg'
            version = 'version'

            actual = _DeprecatedSequenceConstant(value, msg, version)
            self.assertEqual(len(actual), expected_len)

    suite = unittest.TestLoader().loadTestsFromTestCase(Test__DeprecatedSequenceConstant)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-22 19:32:52.005138
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    def test_getitem(seq, index, expected_output):
        seq_obj = _DeprecatedSequenceConstant(seq, 'Test msg', '2.10')
        assert seq_obj[index] == expected_output
    test_getitem(('foo', 'bar'), 1, 'bar')
    test_getitem(('foo', 'bar'), -1, 'bar')
    test_getitem((1, 2), 0, 1)
    test_getitem((1, 2), -1, 2)


# Generated at 2022-06-22 19:32:54.577505
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], 'testing', '1.0')
    assert hasattr(c, '__len__')
    assert c.__len__() == 3

# Generated at 2022-06-22 19:32:56.684603
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_sequence = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert len(test_sequence) == 3
    assert test_sequence[1] == 2

# Generated at 2022-06-22 19:33:04.482691
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    __test_list = ["item 0", "item 1", "item 2", "item 3", "item 4", "item 5"]
    __test_inst = _DeprecatedSequenceConstant(__test_list,
                                              msg="Unit test for method __len__ of class _DeprecatedSequenceConstant",
                                              version="2.10")
    assert len(__test_inst) == len(__test_list)



# Generated at 2022-06-22 19:33:10.255325
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Type check
    msg = 'This is message.'
    version = '2.10'
    value = ['foo', 'bar']

    obj = _DeprecatedSequenceConstant(value, msg, version)
    actual = len(obj)

    assert obj._msg == msg
    assert obj._version == version
    assert obj._value == value
    assert actual == 2

# Generated at 2022-06-22 19:33:14.569672
# Unit test for function set_constant
def test_set_constant():
    '''test set_constant function'''
    opt = {}
    set_constant('test', 'value', opt)
    assert opt == {'test': 'value'}, "Value %s doesn't match expected 'value'" % opt['test']



# Generated at 2022-06-22 19:33:21.519143
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = [ "a", "b", "c" ]
    msg = "Test _DeprecatedSequenceConstant construction"
    version = "2.9"
    test_obj = _DeprecatedSequenceConstant(seq, msg, version)

    if not isinstance(test_obj, _DeprecatedSequenceConstant):
        raise AssertionError("constructor of class _DeprecatedSequenceConstant failed to generate object")


# Generated at 2022-06-22 19:33:24.985167
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_object = _DeprecatedSequenceConstant([], 'test_msg', '2.9')
    assert isinstance(deprecated_object, _DeprecatedSequenceConstant)
    assert isinstance(deprecated_object, Sequence)

# Generated at 2022-06-22 19:33:27.820874
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert len(constant) == 0



# Generated at 2022-06-22 19:33:32.859499
# Unit test for function set_constant
def test_set_constant():
    test_module = {}
    set_constant('name', 'value', export=test_module)
    assert 'name' in test_module
    assert test_module['name'] == 'value'

# vim: set filetype=python expandtab tabstop=4 shiftwidth=4 softtabstop=4 :

# Generated at 2022-06-22 19:33:36.064225
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'

# Generated at 2022-06-22 19:33:39.191756
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3, 4]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(value) == len(dsc)


# Generated at 2022-06-22 19:33:48.171748
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """Test the method __getitem__ of the class _DeprecatedSequenceConstant."""
    import sys
    import io
    sys.stderr = io.StringIO()

    original_value = [1, 2, 3]
    msg = 'test_message'
    version = '2.8'
    x = _DeprecatedSequenceConstant(original_value, msg, version)
    assert sys.stderr.getvalue() == ''

    y = x[1]
    assert y == 2
    assert sys.stderr.getvalue() == " [DEPRECATED] test_message, to be removed in 2.8\n", \
        'method __getitem__ of class _DeprecatedSequenceConstant does not work properly'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-22 19:33:54.234440
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = u'Deprecated String'
    version = u'2.9'
    value = [u'one', u'two', u'three']
    sequence = _DeprecatedSequenceConstant(value, msg, version)
    assert(len(sequence) == len(value))

# Generated at 2022-06-22 19:33:55.433757
# Unit test for function set_constant
def test_set_constant():
    assert(TREE_DIR == "/tmp")

# Generated at 2022-06-22 19:34:01.573865
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_object = _DeprecatedSequenceConstant([1,2,3], 'this_var is deprecated', '2.12')
    try:
        len(test_object)
    except Exception as e:
        assert False, 'len() method not working properly'

    try:
        test_object[0]
    except Exception as e:
        assert False, '__getitem__() method not working properly'

# Generated at 2022-06-22 19:34:09.633076
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    mock_value = [1, 2, 3]
    mock_msg = 'This is a deprecated message.'
    mock_version = '2.9'
    # Check if _DeprecatedSequenceConstant is initialized successfully.
    assert _DeprecatedSequenceConstant(mock_value, mock_msg, mock_version)
    # Check if len(mock_value) is returned.
    assert len(_DeprecatedSequenceConstant(mock_value, mock_msg, mock_version)) == len(mock_value)
    # Check if mock_value[0] is returned.
    assert _DeprecatedSequenceConstant(mock_value, mock_msg, mock_version)[0] == mock_value[0]
    # Check if the deprecated message is returned.

# Generated at 2022-06-22 19:34:21.949523
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common._collections import _DeprecatedSequenceConstant
    value = u'value'
    msg = 'test'
    version = '1.0'
    x = _DeprecatedSequenceConstant(value, msg, version)
    assert 1 == x[0]
    assert int in x[0].__class__.__bases__


# import the collections namespace, which adds some additional common
# data types to the ones provided by python
from ansible.module_utils.common.collections import MutableMapping, MutableSequence
from ansible.module_utils.parsing.convert_bool import boolean, BOOLEANS_FALSE
from ansible.module_utils.six import PY3, string_types, text_type, binary_type

# Generated at 2022-06-22 19:34:29.347884
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible import constants

    constants.DOCUMENTABLE_PLUGINS = ['a', 'b', 'c']

    msg = "foo"
    version = "bar"
    dsc = _DeprecatedSequenceConstant(constants.DOCUMENTABLE_PLUGINS, msg, version)

    assert len(dsc) == 3

    msg = "baz"
    version = "quz"
    dsc2 = _DeprecatedSequenceConstant(constants.DOCUMENTABLE_PLUGINS, msg, version)

    assert len(dsc2) == 3

# Generated at 2022-06-22 19:34:36.051915
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Arrange
    list = ['a', 'b', 'c']
    msg = "test__DeprecatedSequenceConstant"
    version = "2.1.0"

    # Act
    test = _DeprecatedSequenceConstant(list, msg, version)

    # Assert
    assert test[1] == 'b'
    assert test.__len__() == 3

# Generated at 2022-06-22 19:34:37.299875
# Unit test for function set_constant
def test_set_constant():
    global answer
    set_constant('answer', 42)
    assert answer == 42

# Generated at 2022-06-22 19:34:41.114163
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'This is a warning!'
    version = '2.8'
    seq = [1, 2, 3]
    constant_seq = _DeprecatedSequenceConstant(value=seq, msg=msg, version=version)
    assert constant_seq[0] == seq[0]
    assert constant_seq[1] == seq[1]
    assert constant_seq[2] == seq[2]

# Generated at 2022-06-22 19:34:45.567512
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert [_DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')[i] for i in range(3)] == [1, 2, 3]



# Generated at 2022-06-22 19:34:49.036138
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')

    assert 'FOO' in globals()
    assert globals()['FOO'] == 'BAR'



# Generated at 2022-06-22 19:34:52.234392
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    c = _DeprecatedSequenceConstant("abc", "msg", "version")
    assert isinstance(c, Sequence)
    assert c[0] == "a"

# Generated at 2022-06-22 19:34:57.951376
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = '2.9'
    lst = ['val1', 'val2']
    dsc = _DeprecatedSequenceConstant(lst, msg, version)
    assert dsc[0] == lst[0]
    assert dsc[1] == lst[1]

# Generated at 2022-06-22 19:34:59.702854
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2], "msg", "version")) == 2
    assert _DeprecatedSequenceConstant([1, 2], "msg", "version")[0] == 1



# Generated at 2022-06-22 19:35:03.653483
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "this is deprecated"
    version = "2.9.0"
    value = ["test_sequence"]
    result = _DeprecatedSequenceConstant(value, msg, version)
    assert len(result) == len(value)
    assert result[0] == value[0]


# Generated at 2022-06-22 19:35:07.673813
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant('foo', 'bar', '1.0')
    assert len(a) == len('foo')
    assert a[0] == 'foo'[0]

# Generated at 2022-06-22 19:35:18.051851
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dict1 = _DeprecatedSequenceConstant((1,2,3,4,5), u'Test Message', u'2.0')
    assert len(dict1) == 5, 'Unexpected dict1 length'
    assert dict1[0] == 1, 'Unexpected dict1[0] value'
    assert dict1[1] == 2, 'Unexpected dict1[1] value'
    assert dict1[2] == 3, 'Unexpected dict1[2] value'
    assert dict1[3] == 4, 'Unexpected dict1[3] value'
    assert dict1[4] == 5, 'Unexpected dict1[4] value'


# Generated at 2022-06-22 19:35:21.049523
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    c = _DeprecatedSequenceConstant([1, 2, 3], '', '1.0')
    assert len(c) == 3


# Generated at 2022-06-22 19:35:24.478690
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'the msg'
    version = 'the version'
    val = 'the value'
    d = _DeprecatedSequenceConstant(val, msg, version)
    assert d[0] == val


# Generated at 2022-06-22 19:35:30.116445
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list1 = [1, 2, 3, 4, 5]
    deprecated_list_constant = _DeprecatedSequenceConstant(list1, '', '1.1.1')
    assert len(deprecated_list_constant) == 5


# Generated at 2022-06-22 19:35:34.045351
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    l = ['test']
    c = _DeprecatedSequenceConstant(l, 'msg', 'version')
    assert l[0] == c[0]  # pylint: disable=comparison-with-callable

# Generated at 2022-06-22 19:35:35.878322
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant(value=[], msg="msg", version="version")
    assert len(x) == 0

# Generated at 2022-06-22 19:35:39.438935
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence_constant = _DeprecatedSequenceConstant((1, ), 'message', 'version')
    assert len(deprecated_sequence_constant) == 2
    assert deprecated_sequence_constant[1] == 1

# Generated at 2022-06-22 19:35:42.365201
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")

    assert seq[1] == 2


# Generated at 2022-06-22 19:35:47.002088
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant(('value1', 'value2'), 'msg', 'version')
    assert len(a) == 2
    assert a[0] == 'value1'
    assert a[1] == 'value2'

# Generated at 2022-06-22 19:35:49.280278
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('foo', 'bar', export)
    assert 'foo' in export
    assert export['foo'] == 'bar'

# Generated at 2022-06-22 19:35:52.329685
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    expected = 5
    actual = _DeprecatedSequenceConstant(range(5), 'A dummy message', 'A dummy version')
    assert len(actual) == expected


# Generated at 2022-06-22 19:35:54.346879
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST', 42)
    assert TEST == 42

# Generated at 2022-06-22 19:36:01.423941
# Unit test for function set_constant
def test_set_constant():
    set_constant('A', True)
    set_constant('B', 'test')
    set_constant('C', [1, 2, 3])
    set_constant('D', dict(a=1, b=2, c=3))
    set_constant('E', dict(a=1, b=2, c=3), export=dict())
    assert A is True
    assert B == 'test'
    assert C == [1, 2, 3]
    assert D == dict(a=1, b=2, c=3)
    assert E is None

# Generated at 2022-06-22 19:36:05.633492
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence_constant = _DeprecatedSequenceConstant(['1', '2'], 'test', '2.9')
    assert len(sequence_constant) == 2
    assert sequence_constant[0] == '1'
    assert sequence_constant[1] == '2'


# Generated at 2022-06-22 19:36:11.337478
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant((1, 2), 'first msg', 'v2.4')
    assert len(a) == 2
    assert a[1] == 2
    b = _DeprecatedSequenceConstant([1, 2], 'second msg', 'v2.5')
    assert len(b) == 2
    assert b[1] == 2

# Generated at 2022-06-22 19:36:23.864892
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO_BAR', 'Baz')
    assert 'FOO_BAR' in globals()
    assert globals()['FOO_BAR'] == 'Baz'

# FIXME: remove once play_context mangling is removed
if ANSIBLE_CONFIG:
    MAGIC_VARIABLE_MAPPING['private_key_file'] += (ANSIBLE_PRIVATE_KEY_FILE,)
if ANSIBLE_SCP_IF_SSH:
    MAGIC_VARIABLE_MAPPING['ssh_transfer_method'] += ('ansible_scp_if_ssh',)

# Generated at 2022-06-22 19:36:32.798999
# Unit test for function set_constant
def test_set_constant():
    changes = False
    constants = {}
    # Test if set_constant updates the dict passed in export
    changes = set_constant('TEST_CONSTANT', 'Test Constant', constants)
    assert constants.get('TEST_CONSTANT') == 'Test Constant'
    assert changes == True
    # Test if set_constant does not override the dict passed in export
    # if the value does not change
    changes = set_constant('TEST_CONSTANT', 'Test Constant', constants)
    assert constants.get('TEST_CONSTANT') == 'Test Constant'
    assert changes == False
    # Test if set_constant does override the dict passed in export
    # if the value changes
    changes = set_constant('TEST_CONSTANT', 'New Constant Value', constants)

# Generated at 2022-06-22 19:36:44.723497
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    result_expected = {
        'result': 'success',
        'msg': 'This is the expected result'
    }
    result_actual = _DeprecatedSequenceConstant(value=result_expected, msg='Deprecation message', version='2.8')
    if len(result_expected) != len(result_actual):
        raise AssertionError(
            'There is an unexpected length of the actual result in _DeprecatedSequenceConstant class. Actual: [%s] , expected: [%s]' %
            (len(result_actual), len(result_expected))
        )

# Generated at 2022-06-22 19:36:46.279409
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([0], 'message', 'version')) == 1

# Generated at 2022-06-22 19:36:53.547791
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_data = (
        ("abc", "xyz", "0.0"),
        (1, 2, "0.0"),
        ([1, 2, 3], [1, 2], "0.0"),
    )

    for input_value, expected_value, expected_version in test_data:
        result = _DeprecatedSequenceConstant(input_value, "msg", "version")
        assert result._value == expected_value
        assert result._msg == "msg"
        assert result._version == "version"



# Generated at 2022-06-22 19:36:59.771171
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test if _DeprecatedSequenceConstant.__getitem__, param y: slice, will be deprecated
    from collections import abc
    test_slice = slice(0, 4)
    msg = 'Test warning message'
    version = '2.14'
    test_val = _DeprecatedSequenceConstant(range(5), msg, version)
    a_seq_slice = test_val[test_slice]
    assert(isinstance(a_seq_slice, abc.Sequence))
    assert(a_seq_slice == range(0, 4))

    # Test if _DeprecatedSequenceConstant.__getitem__, param y: int, will be deprecated
    test_int = 2
    a_seq_int = test_val[test_int]
    assert(isinstance(a_seq_int, int))

# Generated at 2022-06-22 19:37:09.241440
# Unit test for function set_constant
def test_set_constant():
    global COLOR_CODES

    from ansible.config.manager import get_config_value
    from ansible.release import __version__ as ansible_release

    cm = ConfigManager()

    # Generate constants from config
    for setting in cm.data.get_settings():
        assert vars()[setting.name] == get_config_value(setting, vars())

    # test something else
    COLOR_CODES = ('red', 'black')
    cm = ConfigManager()
    for setting in cm.data.get_settings():
        assert vars()[setting.name] == get_config_value(setting, vars())

    # test something else
    COLOR_CODES = {}
    cm = ConfigManager()

# Generated at 2022-06-22 19:37:20.380076
# Unit test for function set_constant
def test_set_constant():
    import sys
    import ast

    # these tests only work if the object is a copy from memory and
    # is not the same object, so amend the set_constant function to
    # create a new object and copy over the values from vars()
    def set_constant_test(name, value, export=None, module=sys.modules[__name__], safe=True):
        module = sys.modules[__name__]
        if safe:
            if name in ('__file__', '__doc__', '__name__', '__package__'):
                return
            elif name.isupper():
                return
            elif not re.match(r'^[A-Z0-9_]+$', name):
                return

# Generated at 2022-06-22 19:37:24.157910
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    len_ = len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', '2.9'))
    assert len_ == 3
    assert len_ == len([1, 2, 3])


# Generated at 2022-06-22 19:37:32.878161
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    class Test:
        def __init__(self, value):
            self._value = value

        def __len__(self):
            return len(self._value)

    class Test_DeprecatedSequenceConstant(Test, _DeprecatedSequenceConstant):
        pass

    test_obj = Test_DeprecatedSequenceConstant(value=['a', 'b'], msg='msg', version='version')
    assert len(test_obj) == 2

# Generated at 2022-06-22 19:37:38.539755
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_one', 'foo')
    assert test_one == 'foo'
    set_constant('test_two', {'hello': 'world'})
    assert test_two == {'hello': 'world'}
    set_constant('test_three', [1, 2, 3])
    assert test_three == [1, 2, 3]
    set_constant('test_four', 5)
    assert test_four == 5

# Generated at 2022-06-22 19:37:41.408336
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'ver')
    assert len(constant) == len([1, 2, 3])


# Generated at 2022-06-22 19:37:48.486715
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = (1, 2, 3)
    msg = 'my error msg'
    version = '2.0'
    result = _DeprecatedSequenceConstant(value, msg, version)
    assert len(result) == len(value)
    assert result[0] == value[0]
    assert result[1] == value[1]
    assert result[2] == value[2]


# Generated at 2022-06-22 19:37:50.473817
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], '', 'version')) == 0


# Generated at 2022-06-22 19:37:59.602042
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.utils.unsafe_proxy import wrap_var
    import sys
    import io

    class RedirectStdStreams(object):
        def __init__(self, stdout=None, stderr=None):
            self._stdout = stdout or sys.stdout
            self._stderr = stderr or sys.stderr

        def __enter__(self):
            self.old_stdout, self.old_stderr = sys.stdout, sys.stderr

            self.old_stdout.flush(); self.old_stderr.flush()
            sys.stdout, sys.stderr = self._stdout, self._stderr

        def __exit__(self, exc_type, exc_value, traceback):
            self._stdout.flush(); self._stder

# Generated at 2022-06-22 19:38:05.809774
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert set(_DeprecatedSequenceConstant(
        ['foo', 'bar', 'baz'], 'msg', 'version')._value) == set(['foo', 'bar', 'baz'])
    assert _DeprecatedSequenceConstant(
        ['foo', 'bar', 'baz'], 'msg', 'version')._msg == 'msg'
    assert _DeprecatedSequenceConstant(
        ['foo', 'bar', 'baz'], 'msg', 'version')._version == 'version'



# Generated at 2022-06-22 19:38:08.923882
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant(
        value = [1, 2],
        msg = "Testing",
        version = "2.2"
    )

    assert len(x) == 2


# Generated at 2022-06-22 19:38:12.466230
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sourceValue = ['localhost', '127.0.0.1']

    obj = _DeprecatedSequenceConstant(sourceValue, "Testing deprecation mechanism", "v999.0")

    assert len(obj) == len(sourceValue)
    assert obj[0] == sourceValue[0]

# Generated at 2022-06-22 19:38:18.282745
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'
    set_constant('BAR', ['BAZ'])
    assert BAR == ['BAZ']
    set_constant('BAZ', 1)
    assert BAZ == 1
    set_constant('TEST', {'test': ['test']})
    assert TEST == {'test': ['test']}



# Generated at 2022-06-22 19:38:20.706099
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(DEFAULT_HOST_LIST) == len(['127.0.0.1', 'localhost', '::1'])


# Generated at 2022-06-22 19:38:27.595938
# Unit test for function set_constant
def test_set_constant():
    f = {}
    set_constant('f', 'f', export=f)
    assert f['f'] == 'f'
    f['f'] = 'override'
    set_constant('f', 'f', override=False, export=f)
    assert f['f'] == 'override'
    f['f'] = 'override'
    set_constant('f', 'f', override=True, export=f)
    assert f['f'] == 'f'

# Generated at 2022-06-22 19:38:29.233345
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq = _DeprecatedSequenceConstant([1, 2, 3, 4], "msg", "version")
    assert len(seq) == 4

# Generated at 2022-06-22 19:38:31.609760
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = _DeprecatedSequenceConstant([], '', '')
    assert len(test_value) == 0


# Generated at 2022-06-22 19:38:37.694564
# Unit test for function set_constant
def test_set_constant():
    assert len(vars()) > 0
    assert 'ANSIBLE_HOST_KEY_CHECKING' in vars()
    assert vars()['ANSIBLE_HOST_KEY_CHECKING'] is True
    assert vars()['ANSIBLE_SYSTEM_WARNINGS'] is False
    assert vars()['ANSIBLE_INTERNAL_TASKS'] == []
    assert vars()['ANSIBLE_INTERNAL_ROLES'] == []

# Generated at 2022-06-22 19:38:47.323882
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'works', vars())
    assert vars()['test'] == 'works'


# DEPRECATED CONSTANTS ###
DEFAULT_KEEP_REMOTE_FILES = _DeprecatedSequenceConstant(DEFAULT_KEEP_REMOTE_FILES, 'DEPRECATION: DEFAULT_KEEP_REMOTE_FILES '
                                                         'has been replaced by DEFAULT_KEEP_REMOTE_FILES; the new setting '
                                                         'will not be used if the old setting is defined', '2.9')

# Generated at 2022-06-22 19:38:50.613560
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1,2,3], 'hello', '1.0')
    z = dsc[0]
    assert z == 1
    assert len(dsc) == 3

# Generated at 2022-06-22 19:38:55.420391
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # setup
    msg = 'test deprecated'
    version = '2.0'
    # execution
    lst = _DeprecatedSequenceConstant([], msg, version)
    length = len(lst)  # will print the deprecated message


# Generated at 2022-06-22 19:39:05.290912
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # _DeprecatedSequenceConstant() takes 3 parameters,
    # value, msg and version, and only accepts tuple as value.
    test_tuple = ('test_tuple', )
    test_str = 'test_str'
    test_list = ['test_list']
    test_dict = {'test_dict': 'do not support'}
    test_msg = 'msg'
    version = '1.1'

    # Test invalid value, should raise TypeError
    try:
        d = _DeprecatedSequenceConstant(test_str, test_msg, version)
    except TypeError:
        assert True
    else:
        assert False
    try:
        d = _DeprecatedSequenceConstant(test_list, test_msg, version)
    except TypeError:
        assert True

# Generated at 2022-06-22 19:39:08.417461
# Unit test for function set_constant
def test_set_constant():
    # Test that a global variable is set by the call to set_constant
    global test_constant
    set_constant('test_constant', 'value')
    assert(test_constant == 'value')

# Generated at 2022-06-22 19:39:15.636774
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 19:39:20.371545
# Unit test for function set_constant
def test_set_constant():
    """Test function set_constant."""
    global TEST_CONST
    set_constant('TEST_CONST', 'test')
    assert TEST_CONST == 'test'

    set_constant('TEST_CONST', 'test', export=None)
    assert TEST_CONST == 'test'



# Generated at 2022-06-22 19:39:32.058782
# Unit test for function set_constant
def test_set_constant():
    import sys
    import os

    global TREE_DIR

    export = dict()
    set_constant('TREE_DIR', '/tmp', export)
    assert export.get('TREE_DIR') == '/tmp'

    # ensure that the global is set too
    assert TREE_DIR == '/tmp'
    TREE_DIR = None  # reset for the next test

    export.clear()
    set_constant('LIBRARY_PATHS', ['/tmp/library'], export)
    assert export.get('LIBRARY_PATHS') == ['/tmp/library']

    export.clear()
    set_constant('DEFAULT_SUDO_USER', 'mdehaan', export)
    assert export.get('DEFAULT_SUDO_USER') == 'mdehaan'

    export.clear

# Generated at 2022-06-22 19:39:44.683874
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Create a _DeprecatedSequenceConstant object with an empty list
    test_object = _DeprecatedSequenceConstant([], "This is a test!", "2.5")
    assert isinstance(test_object, _DeprecatedSequenceConstant)
    assert (len(test_object) == 0)

    # Create a _DeprecatedSequenceConstant object with a populated list
    test_object = _DeprecatedSequenceConstant([0, 1, 2], "This is a test!", "2.5")
    assert isinstance(test_object, _DeprecatedSequenceConstant)
    assert (len(test_object) == 3)
    assert (test_object[0] == 0)
    assert (test_object[1] == 1)
    assert (test_object[2] == 2)

# ensure the tree dir is

# Generated at 2022-06-22 19:39:47.577069
# Unit test for function set_constant
def test_set_constant():
    test_constants = {}
    set_constant('test_constant', 'constant_value', export=test_constants)
    assert test_constants['test_constant'] == 'constant_value'

# Generated at 2022-06-22 19:39:52.116345
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    class FakeDisplay:
        def __init__(self):
            self.called = []

        def deprecated(self, msg, version=None):
            self.called.append(msg)

    obj = _DeprecatedSequenceConstant(['potato', 'tomato'], 'msg', '42')
    obj.display = FakeDisplay()

    assert obj[0] == 'potato'
    assert obj[1] == 'tomato'
    assert len(obj) == 2
    assert obj.display.called == ['msg']

# Generated at 2022-06-22 19:40:00.026030
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Create a _DeprecatedSequenceConstant object for the test
    C = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test_msg', version='test_version')
    # Test the case which y is in the range of the len(value)
    assert C[2] == C._value[2]
    # Test the case which y is out of the range of the len(value)
    try:
        C[3]
    except IndexError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 19:40:03.560961
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('my_name', 'my_value', export)
    assert 'my_name' in export
    assert export['my_name'] == 'my_value'

# Generated at 2022-06-22 19:40:07.565627
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3, 4]
    test_msg = "Test Message"
    test_version = "1.0"

    seq = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_value) == len(seq)


# Generated at 2022-06-22 19:40:10.669628
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "msg", "version")) == 3


# Generated at 2022-06-22 19:40:22.345544
# Unit test for function set_constant
def test_set_constant():
    export = dict()
    set_constant('ANSIBLE_TEST_CONSTANT_ONE', 'one', export=export)
    set_constant('ANSIBLE_TEST_CONSTANT_TWO', 'two', export=export)
    assert(export['ANSIBLE_TEST_CONSTANT_ONE'] == 'one')
    assert(export['ANSIBLE_TEST_CONSTANT_TWO'] == 'two')
    set_constant('ANSIBLE_TEST_CONSTANT_TWO', 'two_modified_inplace', export=export)
    assert(export['ANSIBLE_TEST_CONSTANT_TWO'] == 'two_modified_inplace')

# We must fail fast if we're running Ansible so old it does not match our deprecation and versioning policy
# NOTE: this is explicitly done *

# Generated at 2022-06-22 19:40:31.212264
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj1= _DeprecatedSequenceConstant((1, 2, 3), 'test msg', 'version 2.8')
    obj2= _DeprecatedSequenceConstant(['abc', 'def', 1], 'test msg', 'version 2.8')
    obj3= _DeprecatedSequenceConstant('string', 'test msg', 'version 2.8')
    assert len(obj1)==3
    assert len(obj2)==3
    assert len(obj3)==6
    assert obj1[0]==1
    assert obj2[2]==1
    assert obj3[3]=='i'
