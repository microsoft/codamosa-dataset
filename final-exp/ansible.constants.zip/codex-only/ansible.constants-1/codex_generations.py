

# Generated at 2022-06-22 19:30:30.834136
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([], '', '')) == 0
    assert len(_DeprecatedSequenceConstant(['a'], '', '')) == 1
    assert _DeprecatedSequenceConstant(['a'], '', '')[0] == 'a'


# Generated at 2022-06-22 19:30:36.333937
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # Testing _DeprecatedSequenceConstant constructor
    foo = _DeprecatedSequenceConstant(1, "Testing _DeprecatedSequenceConstant constructor", '2.7.0')
    assert foo._value == 1
    assert foo._msg == "Testing _DeprecatedSequenceConstant constructor"
    assert foo._version == '2.7.0'

# Generated at 2022-06-22 19:30:39.594307
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant(value=(1, 2, 3), msg='msg', version='version')
    assert x[0] == 1
    assert x[2] == 3

# Generated at 2022-06-22 19:30:43.996167
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = _DeprecatedSequenceConstant(value=[1, 2, 3, 4], msg='My message', version='2.10')
    assert len(a) == 4
    assert a[3] == 4


# Generated at 2022-06-22 19:30:46.425057
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], "THIS IS A TEST", "VERSION")
    assert dsc[1] == 2


# Generated at 2022-06-22 19:30:54.332258
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    r = _DeprecatedSequenceConstant([1,2,3], '', '')
    assert type(r) == _DeprecatedSequenceConstant
    assert len(r) == 3
    assert r[1] == 2

# NOTE: This is a temporary work around to fix the issue with
#   the 'gathering' option being deprecated in the config.
#   Once 'gathering' is removed from config, this should be
#   removed as well
gathering = getattr(config, 'gathering')
gather_subset = getattr(config, 'gather_subset')


# FIXME: remove once source_tree mangling is removed
tree_dir = getattr(config, 'tree_dir')

# Generated at 2022-06-22 19:31:07.517506
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a deprecated message'
    version = '1.0'
    values = ['a', 'b', 'c']
    test_object = _DeprecatedSequenceConstant(values, msg, version)
    assert test_object is not None
    assert len(test_object) == 3
    for i in range(0, 3):
        assert test_object[i] == values[i]
    return test_object

# Generate constants for deprecated config options
for (old, new) in CORRECT_VARS.items():
    set_constant(old, _DeprecatedSequenceConstant((new, ), "ansible.cfg setting '%s' has been replaced by '%s' since Ansible 2.7" % (old, new), "2.8"))

# Generate deprecated constants for plugins

# Generated at 2022-06-22 19:31:14.206941
# Unit test for function set_constant

# Generated at 2022-06-22 19:31:25.363471
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('DEBUG', "test value", export=test_dict)
    assert test_dict['DEBUG'] == "test value"


TREE_DIR = config.get_config_value('DEFAULT', 'local_tmp', default='$HOME/.ansible/tmp')

# FIXME: all_ipv4_addresses is specifically not set here, as it's easy to fake.
# FIXME: allow hex IPs
LOCALHOST_VARS = config.get_config_value(
    'DEFAULT', 'localhost_variables',
    default='ansible_all_ipv4_addresses inventory_hostname'
)

# Generated at 2022-06-22 19:31:29.187741
# Unit test for function set_constant
def test_set_constant():
    export = {}
    name = 'test_set_constant'
    value = 'test_set_constant_value'
    set_constant(name, value, export)
    assert value == export[name]



# Generated at 2022-06-22 19:31:32.570305
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """
    >>> c = _DeprecatedSequenceConstant(['a','b','c'],'msg','version')
    >>> c[0]
    'a'
    >>> c[1]
    'b'
    >>> c[2]
    'c'
    """


# Generated at 2022-06-22 19:31:35.273606
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant(value=[1, 2, 3], msg='Test', version='Foo')[1]


# Generated at 2022-06-22 19:31:37.968096
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('TEST_CONSTANT', 'test_value', export)
    assert export['TEST_CONSTANT'] == 'test_value'

# Generated at 2022-06-22 19:31:48.271378
# Unit test for function set_constant
def test_set_constant():
    from tempfile import mkdtemp
    from shutil import rmtree
    from os.path import exists

    test_dir = mkdtemp()

# Generated at 2022-06-22 19:31:53.835747
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    data = [1,2,3,4,5]
    msg = "This is the message"
    version = "2.7"
    dsc = _DeprecatedSequenceConstant(data, msg, version)
    for i, v in enumerate(data):
        assert v == dsc[i]


# Generated at 2022-06-22 19:32:04.638488
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test default return values
    test_const = _DeprecatedSequenceConstant('Value', 'Warning message', '2.5')
    assert len(test_const) == 1
    assert test_const[0] == 'Value'
    assert isinstance(test_const, Sequence)
    assert isinstance(test_const._value, string_types)
    assert isinstance(test_const._msg, string_types)
    assert isinstance(test_const._version, string_types)
    assert test_const._value == 'Value'
    assert test_const._msg == 'Warning message'
    assert test_const._version == '2.5'
    # Test with a list
    test_const = _DeprecatedSequenceConstant(['Value1', 'Value2'], 'Warning message', '2.5')

# Generated at 2022-06-22 19:32:06.702485
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    constant = _DeprecatedSequenceConstant(['a', 'b'], 'Test message', 'version')
    assert constant[1] == 'b'

# Generated at 2022-06-22 19:32:09.820543
# Unit test for function set_constant
def test_set_constant():
    # test for setting constant
    set_constant('test', 'test')
    assert 'test' in globals()
    # test to see that constants are not overridden
    set_constant('test', 'test2')
    assert globals()['test'] == 'test'

# Generated at 2022-06-22 19:32:16.155716
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    l1 = [1, 2, 3, 4]
    msg = "msg"
    version = "version"
    l2 = _DeprecatedSequenceConstant(l1, msg, version)
    assert len(l1) == len(l2)
    for i in range(len(l1)):
        assert l1[i] == l2[i]
    assert l2._msg == msg
    assert l2._version == version

# Generated at 2022-06-22 19:32:27.803243
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', '123')
    assert test_constant == '123'
    set_constant('test_constant', '321')
    assert test_constant == '321'

# FIXME: remove once play_context mangling is removed
# update the MAGIC_VARIABLE_MAPPING by adding a 'ansible_' prefix to each
# of the keys and the elements in each tuple value
VARS_TRANSLATION = dict()
for key, values in MAGIC_VARIABLE_MAPPING.items():
    for value in values:
        VARS_TRANSLATION[value] = key

# Generated at 2022-06-22 19:32:31.512658
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2], "test message", "version")) == 2
    assert _DeprecatedSequenceConstant([1, 2], "test message", "version")[1] == 2

# Generated at 2022-06-22 19:32:38.969921
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    constant_obj = _DeprecatedSequenceConstant(
        value=('a', 'b'),
        msg='foo',
        version='2.5.0')
    assert isinstance(constant_obj, Sequence)
    assert constant_obj[0] == 'a'


# Backwards compatibility support

# Generated at 2022-06-22 19:32:41.123072
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'v')
    assert len(obj) == 3


# Generated at 2022-06-22 19:32:44.370706
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ('foo', 'bar')
    msg = 'msg'
    version = 'version'
    test = _DeprecatedSequenceConstant(value, msg, version)
    assert test[0] == value[0]
    assert test[1] == value[1]


# Generated at 2022-06-22 19:32:49.256717
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "test msg"
    version = "test version"
    sequence_constant = _DeprecatedSequenceConstant((1, 2, 3), msg, version)
    assert isinstance(sequence_constant, Sequence)
    assert sequence_constant[1] == 2

# Generated at 2022-06-22 19:32:50.620510
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_value = [1,2,3,4]
    _DeprecatedSequenceConstant(list_value, "Some warning message for the test.", "100.0.0").__len__()

# Generated at 2022-06-22 19:32:53.193615
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = _DeprecatedSequenceConstant([1, 2], "a message", "2.0")
    assert test_value._value == [1, 2]
    assert test_value._msg == "a message"
    assert test_value._version == "2.0"
    assert len(test_value) == 2
    assert test_value[0] == 1


# Generated at 2022-06-22 19:33:03.988987
# Unit test for function set_constant
def test_set_constant():
    set_constant('PYTHON_VERSION_INFO', (2, 6, 1))
    assert PYTHON_VERSION_INFO == (2, 6, 1)


# TODO:  deprecate these in 2.5
# deprecated, used in config logic
HOST_VARS_DIR = 'host_vars'
GROUP_VARS_DIR = 'group_vars'
INVENTORY_DIRS = [HOST_VARS_DIR, GROUP_VARS_DIR]
# deprecated, used in config logic
DEFAULT_ROLES_PATH = '/etc/ansible/roles:/usr/share/ansible/roles:/usr/local/share/ansible/roles'

# Generated at 2022-06-22 19:33:07.120222
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert isinstance(ANSIBLE_MODULE_UTILS, _DeprecatedSequenceConstant)
    assert len(ANSIBLE_MODULE_UTILS) == 3


# Generated at 2022-06-22 19:33:11.903002
# Unit test for function set_constant
def test_set_constant():
    # init
    export = {}
    # test
    set_constant('set_constant_test', 'test', export)
    # assert
    assert export['set_constant_test'] == 'test'

# test for constant
import mock
from ansible.utils import context_objects as co


# Generated at 2022-06-22 19:33:17.221872
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated = _DeprecatedSequenceConstant(value=('foo', 'bar'), msg='YO', version='1.0')
    assert isinstance(deprecated, _DeprecatedSequenceConstant)
    assert len(deprecated) == 2
    assert deprecated[0] == 'foo'
    assert deprecated[1] == 'bar'


# Generated at 2022-06-22 19:33:27.434182
# Unit test for function set_constant
def test_set_constant():
    _set_constant_dict = {}
    set_constant('aaa', 'bbb', _set_constant_dict)
    set_constant('ccc', 'ddd', _set_constant_dict)
    assert _set_constant_dict == {'aaa': 'bbb', 'ccc': 'ddd'}


# update aliases
MAGIC_VARIABLE_MAPPING.update(((t, k) for k, v in MAGIC_VARIABLE_MAPPING.items() for t in v))

# Datacenter naming

# Generated at 2022-06-22 19:33:32.541736
# Unit test for function set_constant
def test_set_constant():
    set_constant("MAX_FAIL_PERCENTAGE", "20")
    set_constant("REMOTE_FILES", '/tmp/', export=locals())
    assert(MAX_FAIL_PERCENTAGE == 20)
    assert(REMOTE_FILES == '/tmp/')



# Generated at 2022-06-22 19:33:44.682327
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    old_stderr = None
    args = [
        ('a_string', 'a_message', '2.0.0'),
        ('a_dict', 'a_message', '2.0.0'),
        ('a_list', 'a_message', '2.0.0'),
    ]

    for arg in args:
        old_stderr = sys.stderr
        sys.stderr = mystderr = StringIO()
        _DeprecatedSequenceConstant(arg[0], arg[1], arg[2])
        sys.stderr = old_stderr
        out = mystderr.getvalue()

# Generated at 2022-06-22 19:33:46.756824
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant(['hello', 'world'], 'msg', 'version')
    assert a[0] == 'hello'
    assert a[1] == 'world'

# Generated at 2022-06-22 19:33:53.172329
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest
    import os
    from ansible.config.manager import ConfigManager
    from ansible.config.manager import ensure_type
    from ansible.config.manager import ConfigManager

    config = ConfigManager()

    for setting in config.data.get_settings():
        set_constant(setting.name, setting.value)

    test_msgs = ['test this']
    test_versions = ['1.0-test']

    class TestDeprecated(_DeprecatedSequenceConstant):

        def __init__(self, test_msgs, test_versions):
            self.test_msgs = test_msgs
            self.test_versions = test_versions

            self._value = ['1', '2', '3']
            self._msg = test_msgs[0]

# Generated at 2022-06-22 19:34:04.279110
# Unit test for function set_constant
def test_set_constant():
    import sys
    import random
    import math
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import range

    ran = random.randint(-1000, 1000)
    set_constant('RANDOM_INT', ran)
    assert ran == RANDOM_INT

    ran = random.choice(['a', 'b', 'c'])
    set_constant('RANDOM_STR', ran)
    assert ran == RANDOM_STR

    ran = random.choice([True, False])
    set_constant('RANDOM_BOOL', ran)
    assert ran == RANDOM_BOOL

    ran = [random.choice(string.ascii_letters) for x in range(0, random.randint(0, 200))]

# Generated at 2022-06-22 19:34:17.244559
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR == False
    assert ANSIBLE_NOCOLOR == False
    assert ANSIBLE_DEBUG == False
    assert private_key_file == None
    assert ansible_managed == u'Ansible managed'
    assert ansible_version == __version__
    assert password == None

# Generate constants for deprecated variables
MAGIC_VARIABLE_MAPPING_V2 = MAGIC_VARIABLE_MAPPING.copy()
MAGIC_VARIABLE_MAPPING_V2['remote_addr'] += ('ansible_ssh_host', )
MAGIC_VARIABLE_MAPPING_V2['remote_user'] += ('ansible_ssh_user', )

# Generated at 2022-06-22 19:34:23.259466
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    name = 'test'
    version = '2.9'
    msg = 'test is deprecated, to be removed in version 2.9'
    value = ['test']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 1
    assert dsc[0] == 'test'

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 19:34:29.186535
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Init object _DeprecatedSequenceConstant
    obj = _DeprecatedSequenceConstant(
        value=['/path/to/file', '/path/to/other/file']
        , msg='This is a deprecated message'
        , version='2.9'
    )

    # Test method
    value = obj[0]
    assert value == '/path/to/file'

    # Test method
    value = obj[1]
    assert value == '/path/to/other/file'

# Generated at 2022-06-22 19:34:40.560262
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self, value, msg, version):
            self.value = value
            self.msg = msg
            self.version = version

        def __len__(self):
            _deprecated(self.msg, self.version)
            return len(self.value)

        def __getitem__(self, y):
            return 'mock.__getitem__'

    c = _DeprecatedSequenceConstant(Test('a', 'msg', 'version'))
    assert c[0] == 'mock.__getitem__'


__all__ = [_ for _ in dir() if not _.startswith('_')]

# Generated at 2022-06-22 19:34:42.919141
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1,2,3), 'msg', 'version')) == 3


# Generated at 2022-06-22 19:34:46.554227
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = [1, 2, 3]
    msg = 'This is a test'
    version = '2.9'
    deprecated_value = _DeprecatedSequenceConstant(value, msg, version)
    assert(len(deprecated_value) == len(value))
    assert(deprecated_value[1] == value[1])
    return True


# Generated at 2022-06-22 19:34:51.506381
# Unit test for function set_constant
def test_set_constant():
    t = {'a': 0}
    set_constant('a', 2, t)
    assert t['a'] == 2

# Back-compat
for setting in ('ANSIBLE_INVENTORY_IGNORE', 'ANSIBLE_INVENTORY_IGNORE_EXTRANEOUS'):
    set_constant(setting.lower(), to_text(config.get_config_value(setting, variables=vars())))

# Generated at 2022-06-22 19:34:54.404416
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3, 4], "msg", "version")[3] == 4



# Generated at 2022-06-22 19:34:59.457528
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_constant_value = ["foo", "bar"]
    test_constant = _DeprecatedSequenceConstant(value=test_constant_value, msg="test_msg", version="test_version")
    assert test_constant[0] == "foo"

# Generated at 2022-06-22 19:35:03.747929
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'Test Message'
    version = 'Test Version'
    value = [1, 2, 3]

    dsc = _DeprecatedSequenceConstant(value, msg, version)

    assert (dsc._value == value)
    assert (dsc._msg == msg)
    assert (dsc._version == version)
    assert (len(dsc) == 3)
    assert (dsc[0] == 1)
    assert (dsc[1] == 2)
    assert (dsc[2] == 3)

# Generated at 2022-06-22 19:35:07.362993
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    my_const = _DeprecatedSequenceConstant([1, 2, 3], msg='msg', version='1.3')
    assert len(my_const) == 3
    assert my_const[1] == 2

# Generated at 2022-06-22 19:35:09.926896
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant((1, 2), '', '')
    assert len(constant) == 2


# Generated at 2022-06-22 19:35:15.189094
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = (1, 'foo', {'bar': 'baz'}, [1, 2, 3])
    msg = 'This is a test warning message'
    version = '4.4'
    dsc = _DeprecatedSequenceConstant(value=value, msg=msg, version=version)
    assert len(dsc) == len(value)


# Generated at 2022-06-22 19:35:17.596380
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 1, locals())
    assert a == 1, 'set_constant failed to set a value in locals'

# Generated at 2022-06-22 19:35:20.578803
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(None, 'Deprecated', '3.0')
    assert c[None] is None


# Generated at 2022-06-22 19:35:29.860194
# Unit test for function set_constant
def test_set_constant():
    import tempfile
    fd, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write('''
[defaults]
constant_one = value
constant_two = one
constant_three = 1
        ''')
    set_constant('test_config_file', path)
    config.set_config_defaults()
    assert 'constant_one' in globals()
    assert 'constant_two' in globals()
    assert 'constant_three' in globals()
    assert constant_one == 'value'
    assert constant_two == 'one'
    assert constant_three == 1

# Populate deprecated constant

# Generated at 2022-06-22 19:35:35.655776
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'Test Message', '2.1')
    assert obj[0] == 1, 'Expected value to be 1'
    assert obj[1] == 2, 'Expected value to be 2'
    assert obj[2] == 3, 'Expected value to be 3'



# Generated at 2022-06-22 19:35:38.563558
# Unit test for function set_constant
def test_set_constant():
    test_dict = {}
    set_constant('test_const', 'test 1234', export=test_dict)
    assert test_dict['test_const'] == 'test 1234'

# Generated at 2022-06-22 19:35:51.294987
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_var', 'foo', export={})
    assert(test_var == 'foo')

# Legacy constants replaced by config entries

VAULT_VERSION = DEFAULT_VAULT_VERSION_2

# FIXME: remove, move to config
DEFAULT_VAULT_ID_MATCH = u'^[a-zA-Z0-9_\\-]+$'
DEFAULT_VAULT_ID_MATCH_SLIPPERY = u'^[a-zA-Z0-9_-+/=]+$'
DEFAULT_VAULT_ID_MATCH_TRANSITIONAL = u'^[a-zA-Z0-9_\\-\\.:,]+$'
VAULT_ID_MATCH_DEFAULT = DEFAULT_VAULT_ID_MATCH

# FIXME: remove

# Generated at 2022-06-22 19:35:54.346978
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    s = _DeprecatedSequenceConstant([1,2,3], 'msg', 'version')
    assert len(s) == 3

# Generated at 2022-06-22 19:36:05.030649
# Unit test for function set_constant
def test_set_constant():
    assert BECOME_TIMEOUT == 300
    assert MODULE_REQUIRE_ARGS == ('command', 'win_command', 'ansible.windows.win_command', 'shell', 'win_shell',
                                   'ansible.windows.win_shell', 'raw', 'script')
    assert MODULE_NO_JSON == ('command', 'win_command', 'ansible.windows.win_command', 'shell', 'win_shell',
                              'ansible.windows.win_shell', 'raw')
    assert COLLECTION_PTYPE_COMPAT == {'module': 'modules'}
    assert RESTRICTED_RESULT_KEYS == ('ansible_rsync_path', 'ansible_playbook_python', 'ansible_facts')
    assert ANSIBLE_CONFIG == 'ansible.cfg'
    assert __version__

# Generated at 2022-06-22 19:36:08.254902
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    x = _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")
    assert x[0] == 1
    assert x[1] == 2
    assert x[2] == 3
    assert len(x) == 3

# Generated at 2022-06-22 19:36:10.597634
# Unit test for function set_constant
def test_set_constant():
    set_constant('MY_CONSTANT', '1')
    if MY_CONSTANT != '1':
        raise Exception('Failed to set constant')

# Generated at 2022-06-22 19:36:13.440604
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = [1, 2, 3]
    b = _DeprecatedSequenceConstant(a, 'msg', 'version')
    assert len(b) == len(a)

# Generated at 2022-06-22 19:36:19.624401
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['test'], 'test', 'test')
    assert dsc[0] == 'test'
    assert dsc[-1] == 'test'
    assert dsc[:1] == ['test']
    assert dsc[-1:] == ['test']


# Generated at 2022-06-22 19:36:22.644180
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence = _DeprecatedSequenceConstant((0, 1), 'This is a test warning.', '2.10')
    assert sequence[0] == 0
    assert sequence[1] == 1

# Generated at 2022-06-22 19:36:29.037863
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_HOST_LIST == '/etc/ansible/hosts'
    assert DEFAULT_MODULE_NAME == 'command'
    assert DEFAULT_MODULE_PATH == '/usr/share/ansible/'
    assert DEFAULT_MODULE_LANG == 'C'
    assert DEFAULT_FORKS == 5
    assert DEFAULT_MODULE_ARGS == ''
    assert DEFAULT_PATTERN == '*'
    assert DEFAULT_REMOTE_PORT == 22
    assert DEFAULT_TIMEOUT == 10
    assert DEFAULT_POLL_INTERVAL == 15
    assert DEFAULT_REMOTE_USER == 'root'
    assert DEFAULT_ASK_PASS == False
    assert DEFAULT_PRIVATE_KEY_FILE == '~/.ssh/id_rsa'
    assert DEFAULT_SUDO_

# Generated at 2022-06-22 19:36:41.145432
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from types import GeneratorType
    from types import MethodType
    from types import FunctionType
    from types import BuiltinMethodType

    a = _DeprecatedSequenceConstant([1,2,3], '', '')
    # Test case 1: If a is an instance of _DeprecatedSequenceConstant
    if isinstance(a, _DeprecatedSequenceConstant):
        assert isinstance(a.__len__(), int)
        assert isinstance(len(a), int)
    # Test case 2: If a is not an instance of _DeprecatedSequenceConstant
    else:
        with pytest.raises(AttributeError):
            a.__len__()
        with pytest.raises(AttributeError):
            len(a)


# Generated at 2022-06-22 19:36:49.554952
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_data = [
        (['abc'], 'abc', '1.0'),
        (['abc', 'def'], 'abc', '2.0'),
        (['abc', 'def', 'ghi'], 'abc', '3.0'),
    ]
    for seq, msg, version in test_data:
        obj = _DeprecatedSequenceConstant(seq, msg, version)
        len_val = len(obj)
        assert len_val == len(seq)
        for idx, val in enumerate(seq):
            assert val == obj[idx]

# Generated at 2022-06-22 19:36:54.415816
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'uh oh, message'
    version = '2.9'
    some_value = (1, 2, 3)
    d = _DeprecatedSequenceConstant(some_value, msg, version)
    assert len(d) == len(some_value)

# Generated at 2022-06-22 19:37:05.026111
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant(value=[1, 2, 3], msg='This is a sample message', version='2.9').__len__()
    _DeprecatedSequenceConstant(value=(1, 2, 3), msg='This is a sample message', version='2.9').__len__()
    _DeprecatedSequenceConstant(value=set([1, 2, 3]), msg='This is a sample message', version='2.9').__len__()
    _DeprecatedSequenceConstant(value='1,2,3', msg='This is a sample message', version='2.9').__len__()

# Generated at 2022-06-22 19:37:10.139813
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_msg = "Got something somewhere"
    test_version = "2.8"
    test_value = ['value1', 'value2']
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    test_index = 1
    assert test_obj[test_index] == test_value[test_index]

# Generated at 2022-06-22 19:37:18.067616
# Unit test for function set_constant
def test_set_constant():
    new_test_global_var = set_constant('new_test_global_var', 'test_set_constant')
    new_test_global_dict = set_constant('new_test_global_dict', {'test_set_constant': 'test_dict'})
    assert new_test_global_var['new_test_global_var'] == 'test_set_constant'
    assert new_test_global_dict['new_test_global_dict'] == {'test_set_constant': 'test_dict'}

# Generated at 2022-06-22 19:37:20.305711
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'message', 'version')
    assert obj.__len__() == 3


# Generated at 2022-06-22 19:37:33.928572
# Unit test for function set_constant

# Generated at 2022-06-22 19:37:42.753156
# Unit test for function set_constant
def test_set_constant():
    # simple test of set_constant
    d = {}
    set_constant('foo', 'bar', export=d)
    assert d['foo'] == 'bar'

    # ensure set_constant replaces previous value
    d['foo'] = 'baz'
    assert d['foo'] == 'baz'

    # ensure set_constant updates value of an imported object
    d['foo'] = 'foo'
    set_constant('foo', 'bar', export=d)
    assert d['foo'] == 'bar'

    # ensure set_constant is able to use imported __builtins__
    d = {}
    set_constant('False', False, export=d)
    assert d['False'] is False

    # ensure set_constant is able to update a value in __builtins__
    assert False is False
   

# Generated at 2022-06-22 19:37:47.552684
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Ensure constructor works with the following parameters
    assert _DeprecatedSequenceConstant([], '', '')
    assert _DeprecatedSequenceConstant('', '', '')
    assert _DeprecatedSequenceConstant('', '', 0)


# Generated at 2022-06-22 19:37:58.529027
# Unit test for function set_constant
def test_set_constant():
    export = {}
    set_constant('a', 1, export)
    assert 1 == export['a']

    export = {}
    set_constant('a', 'b', export)
    assert 'b' == export['a']

# NOTE: this is deliberately done this way so that the code for the constants above doesn't need the config_manager import
constants = dict((k, v) for k, v in globals().copy().items() if k.isupper())

# FIXME: move the below to their own files
#        this file is getting too bloated

# ANSIBLE_CONFIG, ANSIBLE_INVENTORY and ANSIBLE_LIBRARY are outside of this dict
# so we can avoid importing config_manager until after these are set

# Generated at 2022-06-22 19:38:06.122841
# Unit test for function set_constant
def test_set_constant():
    # TODO: fix this test with explicit dicts
    variables = {}
    set_constant('FOO', 'bar', variables)
    assert FOO == 'bar'
    assert 'FOO' in locals()
    assert 'bar' in locals().values()
    assert variables['FOO'] == 'bar'
    set_constant('BAR', 'foo', variables)
    assert 'BAR' in locals()
    assert 'foo' in locals().values()
    assert variables['BAR'] == 'foo'
    set_constant('FOO', 'baz', variables)
    assert 'baz' in locals().values()
    assert variables['FOO'] == 'baz'


# FIXME: hard-coded vars above, but read-only in constants.py!

# FIXME: These are hard-coded into the modules

# Generated at 2022-06-22 19:38:10.809408
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """_DeprecatedSequenceConstant - Test method __len__"""
    # Test method __len__ of class _DeprecatedSequenceConstant

    # Setup test data
    sequence = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'Test message', '2.0')

    # Test __len__
    assert len(sequence) == 3

# Generated at 2022-06-22 19:38:13.967685
# Unit test for function set_constant
def test_set_constant():
    locals_copy = locals().copy()
    for k, v in config.data.get_settings():
        assert locals()[k] == v, '%s is %s and not %s' % (k, locals()[k], v)
    locals().update(locals_copy)

# Generated at 2022-06-22 19:38:17.200563
# Unit test for function set_constant
def test_set_constant():
    set_constant('BLAH', 'foo')
    assert BLAH == 'foo'

    set_constant('BLAH', 'bar', export=dict(BLAH=None))
    assert BLAH == 'bar'

# Generated at 2022-06-22 19:38:19.582218
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    sequence = _DeprecatedSequenceConstant([1, 2, 3, 4], 'msg', '1.0')

    # When
    position_0 = sequence[0]
    position_1 = sequence[1]

    # Then
    assert position_0 == 1
    assert position_1 == 2


# Generated at 2022-06-22 19:38:29.457429
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.errors import AnsibleDeprecationWarning
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import reload_module
    import ansible.constants
    import sys
    s = "this is a test"
    obj = _DeprecatedSequenceConstant(s, 'test', '2.0')
    # capture sys.stderr
    stderr = sys.stderr
    reload_module(ansible.constants)
    try:
        sys.stderr = StringIO()
        v = obj[0]
        assert v == s[0]
        assert "DEPRECATED" in sys.stderr.getvalue()
    finally:
        sys.stderr = stderr

# Generated at 2022-06-22 19:38:33.043730
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ('foo', 'bar')
    msg = 'Foo bar'
    version = '0.1'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[1] == 'bar'


# Generated at 2022-06-22 19:38:35.473558
# Unit test for function set_constant
def test_set_constant():
    assert 'foo' not in vars()
    set_constant('foo', 'bar')
    assert 'foo' in vars()
    assert vars()['foo'] == 'bar'

# Generated at 2022-06-22 19:38:41.824819
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # test normal case
    constant = _DeprecatedSequenceConstant(value=[1, 2], msg='test_msg', version='1.0')
    assert len(constant) == 2
    # test the case that value is not a list
    constant = _DeprecatedSequenceConstant(value='1, 2', msg='test_msg', version='1.0')
    assert len(constant) == 3


# Generated at 2022-06-22 19:38:46.603153
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with _DeprecatedSequenceConstant(list, str, str)
    # as input parameter.
    o = _DeprecatedSequenceConstant([1, 2, 3], 'ABC', '1.2.3')
    # Test case 1, __getitem__(self, y)
    assert o[0] == 1
    assert o[1] == 2
    assert o[2] == 3



# Generated at 2022-06-22 19:38:50.359091
# Unit test for function set_constant
def test_set_constant():
    testmod = {}
    set_constant('ANSIBLE_TESTING', True, export=testmod)
    assert testmod['ANSIBLE_TESTING']
    testmod = {}
    set_constant('ANSIBLE_TESTING', None, export=testmod)
    assert not testmod.get('ANSIBLE_TESTING')


# This is a dictionary to allow downstreams to munge it as needed
ALLOWED_INTERNAL_ADDRESSES = dict()

# Generated at 2022-06-22 19:38:54.502681
# Unit test for function set_constant
def test_set_constant():
    __import__('ansible.release')
    __import__('ansible.config.defaults')
    __import__('ansible.utils.display')

    set_constant('TEST_SET_CONSTANT', 'testing')
    assert TEST_SET_CONSTANT == 'testing'

# Generated at 2022-06-22 19:39:05.048131
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class DummyDisplay(object):
        def __init__(self):
            self._deprecated_calls = []

        def deprecated(self, msg, version):
            self._deprecated_calls.append((msg, version))

    tst_seq = _DeprecatedSequenceConstant(value=['tst_val'], msg='tst_msg', version='tst_version')
    d_obj = DummyDisplay()
    d_obj.deprecated = d_obj.__deprecated
    tst_seq._display = d_obj

    seq_val = tst_seq[0]
    assert seq_val == 'tst_val'
    assert len(d_obj._deprecated_calls) == 1

# Generated at 2022-06-22 19:39:13.326360
# Unit test for function set_constant
def test_set_constant():
    ''' Returns changed constants '''
    import ansible.constants as C
    changed = []
    for name in dir(C):
        if not name.startswith('_') and not isinstance(getattr(C, name), property):
            # these change all the time, and don't need to be checked
            if name == 'DEFAULT_MODULE_LANG':
                continue
            else:
                value = getattr(C, name)

            set_constant(name, value, export={})
            try:
                if value != globals()[name]:
                    changed.append(name)
            except KeyError:
                # new global was introduced, which is fine
                continue

    if not changed:
        return True

    return changed

# Generated at 2022-06-22 19:39:17.511064
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'Test msg'
    version = '0.0.1'
    seq = _DeprecatedSequenceConstant(['item1', 'item2', 'item3'], msg, version)

    seq[0]  # should not fail



# Generated at 2022-06-22 19:39:25.719540
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = add_internal_fqcns(('test', 'playbook_executor'))
    assert a == ['test', 'ansible.executor.playbook_executor']

    a = _DeprecatedSequenceConstant(value=('test', 'playbook_executor'), msg='this is a test', version='2.6')
    assert a._value == ['test', 'ansible.executor.playbook_executor']
    assert a._msg == 'this is a test'
    assert a._version == '2.6'

# Generated at 2022-06-22 19:39:35.110157
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST', 'TEST')
    assert TEST == 'TEST'
    set_constant('TEST_TEMPLATE', '{{TEST}}{{TEST}}')
    assert TEST_TEMPLATE == 'TESTTEST'
    set_constant('TEST_TEMPLATE_FAIL', '{{TEST_NO_SUCH_TEMPLATE}}')
    assert TEST_TEMPLATE_FAIL == '{{TEST_NO_SUCH_TEMPLATE}}'
    set_constant('TEST_LIST', '["a","b"]')
    assert TEST_LIST == ["a", "b"]

# Generate deprecated constants from config
for setting in config.data.get_settings():
    if not setting.deprecated_name:
        continue

    set_constant

# Generated at 2022-06-22 19:39:37.560993
# Unit test for function set_constant
def test_set_constant():
    config = {}
    set_constant('foo', 'bar', config)
    assert config['foo'] == 'bar'


# Generated at 2022-06-22 19:39:48.512539
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    d = _DeprecatedSequenceConstant([1, 2, 3], msg='foo', version='2.9')
    assert d.__getitem__(0) == 1
    assert d.__getitem__(1) == 2
    assert d.__getitem__(2) == 3
    assert d[0] == 1, 'Attribute access is the same as __getitem__'
    try:
        d.__getitem__(3)
        assert False, 'should have thrown'
    except IndexError:
        assert True
    try:
        d[3]
        assert False, 'should have thrown'
    except IndexError:
        assert True

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-22 19:39:50.957202
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 1)
    assert 'a' in vars()

# Generated at 2022-06-22 19:40:02.451567
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    '''
    Unit test for method __getitem__ of class _DeprecatedSequenceConstant
    '''
    def mock_warning(msg, version):
        global var_msg, var_version
        var_msg, var_version = msg, version

    global _deprecated
    old_deprecated = _deprecated
    _deprecated = mock_warning

    test_object = _DeprecatedSequenceConstant(value=[1, 2, 3],
                                              msg='foo',
                                              version='2.9')

    test_object[1]
    assert var_msg == 'foo'
    assert var_version == '2.9'

    test_object[-1]
    assert var_msg == 'foo'
    assert var_version == '2.9'

    test_object[2:3]

# Generated at 2022-06-22 19:40:05.121638
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dsc = _DeprecatedSequenceConstant((1, 2, 3), 'msg', '2.9')
    assert len(dsc) == 3


# Generated at 2022-06-22 19:40:07.317067
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dv = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', '1.2.3')
    assert len(dv) == 3
    assert dv[1] == 'b'

# Generated at 2022-06-22 19:40:13.399458
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # _DeprecatedSequenceConstant([ele_1, ele_2, ele_3],'message to be displayed', 'version')
    # _deprecated(msg, version)
    dep_seq_const = _DeprecatedSequenceConstant([1, '2', 3],'message to be displayed', 'version')
    assert len(dep_seq_const) == 3


# Generated at 2022-06-22 19:40:25.823810
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test case for when DeprecatedSequenceConstant object is created with list as the value
    test_list = list('abc')
    test_value = _DeprecatedSequenceConstant(test_list, 'test warning', '2.2')
    assert len(test_value) == 3
    # Test case for when DeprecatedSequenceConstant object is created with tuple as the value
    test_tuple = tuple('abc')
    test_value = _DeprecatedSequenceConstant(test_tuple, 'test warning', '2.2')
    assert len(test_value) == 3
    # Test case for when DeprecatedSequenceConstant object is created with integer value
    test_value = _DeprecatedSequenceConstant(10, 'test warning', '2.2')
    assert len(test_value) == 10
    # Test case

# Generated at 2022-06-22 19:40:27.430577
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant([], '', '2.9')
    assert len(x) == 0



# Generated at 2022-06-22 19:40:35.251112
# Unit test for function set_constant
def test_set_constant():
    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_native
    set_constant(setting.name, value)
    config = ConfigManager()
    for setting in config.data.get_settings():
        assert setting.name == setting.name
        assert setting.value == setting.value
    for warn in config.WARNINGS:
        Display().warning(to_native(warn))