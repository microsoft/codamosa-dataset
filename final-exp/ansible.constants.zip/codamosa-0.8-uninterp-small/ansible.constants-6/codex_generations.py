

# Generated at 2022-06-24 18:25:24.682911
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

if __name__ == "__main__":
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-24 18:25:29.093034
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    pass



# Generated at 2022-06-24 18:25:37.037419
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Setup test data
    self_0 = _DeprecatedSequenceConstant((1, ('2', 3)), 'test__DeprecatedSequenceConstant___init___0', 'test__DeprecatedSequenceConstant___init___1')
    self_1 = _DeprecatedSequenceConstant((1, ('2', 3)), 'test__DeprecatedSequenceConstant___init___0', 'test__DeprecatedSequenceConstant___init___1')
    self_2 = _DeprecatedSequenceConstant((1, ('2', 3)), 'test__DeprecatedSequenceConstant___init___0', 'test__DeprecatedSequenceConstant___init___1')

# Generated at 2022-06-24 18:25:38.522692
# Unit test for function set_constant
def test_set_constant():
    assert var_0 == tuple_0

# set_constant() function tests ends here.


# Generated at 2022-06-24 18:25:44.546387
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'ph'
    list_0 = [3]
    var_0 = set_constant(str_0, list_0)
    assert var_0 == vars()
    tuple_0 = ()
    str_1 = 'Ps'
    var_1 = set_constant(str_1, tuple_0)
    assert var_1 == vars()
    list_1 = [6]
    str_2 = 'xd'
    var_2 = set_constant(str_2, list_1)
    assert var_2 == vars()
    str_3 = 'Xl'
    tuple_1 = ()
    var_3 = set_constant(str_3, tuple_1)
    assert var_3 == vars()
    list_2 = [6]

# Generated at 2022-06-24 18:25:46.508077
# Unit test for function set_constant
def test_set_constant():
    assert globals()['JC'] == ()


# Generated at 2022-06-24 18:25:52.461043
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except NameError as e:
        if 'global name' in e.message and 'is not defined' in e.message:
            new_globals = {}
            exec ('globals().update(vars())', globals(), new_globals)
            new_globals['vars'] = new_globals
            exec ('test_case_0()', new_globals)
        else:
            raise e

# Generated at 2022-06-24 18:25:57.459567
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'JC'
    tuple_0 = ()
    var_0 = set_constant(str_0, tuple_0)
    print(var_0)
        

if __name__ == '__main__':
	test_set_constant()

# Generated at 2022-06-24 18:26:03.239889
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'JC'
    tuple_0 = ()
    var_0 = set_constant(str_0, tuple_0)
    var_1 = _DeprecatedSequenceConstant(var_0, str_0, tuple_0)
    var_2 = var_1.__len__()
    print(var_2)


# Generated at 2022-06-24 18:26:06.138119
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'JC'
    tuple_0 = ()
    var_0 = _DeprecatedSequenceConstant(tuple_0, str_0, str_0)
    var_1 = var_0.__len__()
    print(var_1)

# Generated at 2022-06-24 18:26:13.690564
# Unit test for function set_constant
def test_set_constant():
    try:
        # set_constant() in function scope
        var_0 = set_constant("name_0", "value_0", "export_0")
    except Exception:
        raise ValueError("test_case_0 failed")


# Generated at 2022-06-24 18:26:15.409265
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test cases
    test_case_0()



# Generated at 2022-06-24 18:26:17.804857
# Unit test for function set_constant
def test_set_constant():
    var_0 = True
    var_1 = {}
    set_constant(var_0, var_0, var_1)

# Generated at 2022-06-24 18:26:22.509171
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    list_0 = [bool_0]
    tuple_0 = (bool_0, list_0)
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(tuple_0, dict_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(1)
    var_1 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:26:25.962209
# Unit test for function set_constant
def test_set_constant():
    import sys
    # We need to check that our constant is present in the module's namespace
    assert 'test_const' in sys.modules['ansible.constants']
    try:
        test_const = None
        set_constant('test_const', True)
    except NameError:
        assert False

    # We also need to get rid of it after the test
    try:
        del sys.modules['ansible.constants'].test_const
    except AttributeError:
        assert False



# Generated at 2022-06-24 18:26:28.881328
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()



# Generated at 2022-06-24 18:26:32.492378
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    dict_0 = {True: True, False: False}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, dict_0, False)
    assert deprecated_sequence_constant_0 is not None


# Generated at 2022-06-24 18:26:38.739420
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dict_0 = dict()
    int_0 = 0
    list_0 = [int_0, int_0, int_0]
    tuple_0 = (int_0, list_0, dict_0)
    _DeprecatedSequenceConstant.__init__(tuple_0, dict_0, list_0)
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(list_0, tuple_0, dict_0)
    assert deprecated_sequence_constant_0.__getitem__(0) == 0

# Generated at 2022-06-24 18:26:43.320117
# Unit test for function set_constant
def test_set_constant():
    # Simple test
    name = 'hello'
    value = 'world'
    export = None
    set_constant(name, value, export)
    assert value == export[name]

# Generated at 2022-06-24 18:26:46.242924
# Unit test for function set_constant
def test_set_constant():
    name_0 = None
    value_0 = None
    export_0 = None
    function_return_value_0 = set_constant(name_0, value_0, export_0)
    assert function_return_value_0 is None




# Generated at 2022-06-24 18:26:55.328919
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert True


# Generated at 2022-06-24 18:26:56.515567
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:26:58.542317
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except:
        raise AssertionError('Test failed')



# Generated at 2022-06-24 18:27:03.767716
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, dict_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(0)

# Generated at 2022-06-24 18:27:11.181716
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Run against a test case
    test_case_0()

MANAGED_HOST_VARS = frozenset(('ansible_user', 'ansible_password', 'ansible_port', 'ansible_host', 'ansible_ssh_pass',
                               'ansible_become_pass', 'ansible_connection'))


# Generated at 2022-06-24 18:27:12.443805
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:27:20.820595
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, dict_0, bool_0)
    deprecated_sequence_constant_1 = None
    # verify that the class of the object is _DeprecatedSequenceConstant
    assert isinstance(deprecated_sequence_constant_1, _DeprecatedSequenceConstant)
    assert isinstance(deprecated_sequence_constant_0, _DeprecatedSequenceConstant)
    # verify the method call
    assert deprecated_sequence_constant_0.__len__() == 0


# Generated at 2022-06-24 18:27:25.613976
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        pass
    except Exception as e:
        print('Caught exception: ' + str(e))
        raise
    else:
        pass
    finally:
        pass


# Generated at 2022-06-24 18:27:32.176814
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except:
        print("Exception caught, details:")
        import sys
        print(sys.exc_info())



# Generated at 2022-06-24 18:27:38.007313
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, dict_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(True)


# Generated at 2022-06-24 18:27:47.373705
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Empty test
    pass

# Generated at 2022-06-24 18:27:50.957906
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(deprecated_sequence_constant_0)

# Generated at 2022-06-24 18:27:51.819351
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:28:02.114016
# Unit test for function set_constant
def test_set_constant():

    assert(isinstance(TEST_BECOME_ALLOW_SAME_USER, bool))
    assert(TEST_BECOME_ALLOW_SAME_USER is True)

    assert(isinstance(TEST_CACHEABLE_TASKS, list))
    assert(TEST_CACHEABLE_TASKS == [])

    assert(isinstance(TEST_CACHE_PLUGIN_NAMES, list))
    assert(TEST_CACHE_PLUGIN_NAMES == [])

    assert(isinstance(TEST_CACHE_PLUGIN_CONNECTION, str))
    assert(TEST_CACHE_PLUGIN_CONNECTION == 'network_cli')

    assert(isinstance(TEST_CACHE_PLUGIN_TERMINAL, list))


# Generated at 2022-06-24 18:28:03.436353
# Unit test for function set_constant
def test_set_constant():
    test_case_0()

# Generated at 2022-06-24 18:28:10.299593
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:28:15.713662
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__(dreprecated_sequence_constant_0)


# Generated at 2022-06-24 18:28:16.385398
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:28:21.768161
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert deprecated_sequence_constant_0._msg is bool_0
    assert deprecated_sequence_constant_0._value is bool_0
    assert deprecated_sequence_constant_0._version is bool_0
    # check function _DeprecatedSequenceConstant.__init__
    assert isinstance(deprecated_sequence_constant_0, _DeprecatedSequenceConstant)


# Generated at 2022-06-24 18:28:24.960631
# Unit test for function set_constant
def test_set_constant():
    # This should return None
    assert set_constant(bool(), bool(), bool()) is None



# Generated at 2022-06-24 18:28:38.093545
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()

# Generated at 2022-06-24 18:28:44.194770
# Unit test for function set_constant
def test_set_constant():
    name_0 = 'name'
    value_0 = 'value'
    export_0 = {}
    var_0 = set_constant(name_0, value_0, export_0)
    assert var_0 == {}

    # set_constant(name_0, value_0, export_0)



# Generated at 2022-06-24 18:28:48.534972
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    arg_0 = {}
    arg_1 = {}
    arg_2 = {}
    obj = _DeprecatedSequenceConstant(arg_0, arg_1, arg_2)
    assert isinstance(obj, _DeprecatedSequenceConstant)
    assert obj._value is arg_0
    assert obj._msg is arg_1
    assert obj._version is arg_2


# Generated at 2022-06-24 18:28:51.762480
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    testcase_0 = _DeprecatedSequenceConstant({}, "", "")
    assert type(testcase_0) is _DeprecatedSequenceConstant
    test_case_0()


# Generated at 2022-06-24 18:28:55.250000
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('test_string_0', 'test_value_2', globals()) == {'test_string_0': 'test_value_2'}


# Generated at 2022-06-24 18:28:59.688435
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:29:01.231084
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert var_0 == bool_0


# Generated at 2022-06-24 18:29:06.952400
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        assert callable(_DeprecatedSequenceConstant.__getitem__)
    except AssertionError as e:
        raise AssertionError(str(e) + '\n\nCallable expected for attribute __getitem__ of class _DeprecatedSequenceConstant, but non-callable found.')


# Generated at 2022-06-24 18:29:10.549537
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(deprecated_sequence_constant_0)


# Generated at 2022-06-24 18:29:16.148046
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    str_0 = 'CaxHp=_d4#)b6N^UYc8M@'
    var_0 = _DeprecatedSequenceConstant(int_0, str_0, str_0)
    var_1 = var_0.__getitem__(int_0)


# Generated at 2022-06-24 18:29:30.215552
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(deprecated_sequence_constant_0)
    assert var_0 == True


# Generated at 2022-06-24 18:29:32.996594
# Unit test for function set_constant
def test_set_constant():
    set_constant(0, 0, 0)

# Function to test for function set_constant

# Generated at 2022-06-24 18:29:37.464255
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:29:40.510865
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert deprecated_sequence_constant_0.__getitem__(deprecated_sequence_constant_0) == bool_0


# Generated at 2022-06-24 18:29:44.079231
# Unit test for function set_constant
def test_set_constant():
    
    name = 'name'
    value = 'value'
    export = 'export'
    set_constant(name, value, export)


# Generated at 2022-06-24 18:29:55.261008
# Unit test for function set_constant
def test_set_constant():
    constant_name = 'test_ansible'
    name = constant_name
    value = 'test_value'
    export = {}
    set_constant(name, value, export)
    assert export.get(constant_name) == value

ansible_module_payload_dict = {
    'include': _ACTION_ALL_INCLUDES,
    'include_role': _ACTION_INCLUDE_ROLE,
    'include_tasks': _ACTION_INCLUDE_TASKS,
    'include_vars': _ACTION_INCLUDE_VARS,
    'meta': _ACTION_META,
    'setup': _ACTION_SETUP,
}

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:30:06.979151
# Unit test for function set_constant

# Generated at 2022-06-24 18:30:13.546904
# Unit test for function set_constant
def test_set_constant():
    assert _ACTION_IMPORT_PLAYBOOK == ('import_playbook', 'ansible.builtin.import_playbook')
    assert _ACTION_IMPORT_ROLE == ('import_role', 'ansible.builtin.import_role')
    assert _ACTION_IMPORT_TASKS == ('import_tasks', 'ansible.builtin.import_tasks')


# Generated at 2022-06-24 18:30:18.897348
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = _DeprecatedSequenceConstant(0, 0, 0).__getitem__(0)


# Generated at 2022-06-24 18:30:22.413148
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_1 = {}
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(bool_1, bool_1, bool_1)
    var_1 = deprecated_sequence_constant_1.__getitem__(deprecated_sequence_constant_1)

# Generated at 2022-06-24 18:30:41.972767
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert type(deprecated_sequence_constant_0.__len__()) is int


# Generated at 2022-06-24 18:30:43.007504
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:30:44.152157
# Unit test for function set_constant
def test_set_constant():
    set_constant('bool_1', True)
    assert bool_1 == True


# Generated at 2022-06-24 18:30:50.082036
# Unit test for function set_constant
def test_set_constant():
    set_constant("test_string", "string")
    assert("string" == test_string)
    test_string = "change"
    assert("change" == test_string)

if __name__ == '__main__':
    print("Start tests")
    test_set_constant()
    print("End tests")

# Generated at 2022-06-24 18:30:53.048738
# Unit test for function set_constant
def test_set_constant():
    # Test with a valid name and value
    set_constant('valid_name', 123)

    # Test with an invalid name
    try:
        set_constant('invalid name', 123)
    except SyntaxError:
        pass

# Generated at 2022-06-24 18:30:57.294785
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = _DeprecatedSequenceConstant(list(), "Test msg", "2.5")
    var_1 = var_0.__getitem__(list())
    assert type(var_1) == list



# Generated at 2022-06-24 18:31:01.933317
# Unit test for function set_constant
def test_set_constant():
    try:
        assert 'value'
        test_case_0()
    except Exception:
        print('Test  Failed')
        return 0
    print('Test  Passed')
    return 1


if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-24 18:31:03.915543
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:31:06.664595
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:31:09.573536
# Unit test for function set_constant
def test_set_constant():
    name = 'name'
    value = 'value'
    export = 'export'
    set_constant(name, value, export)


# Generated at 2022-06-24 18:31:45.919884
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_1 = {}
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(bool_1, bool_1, bool_1)
    var_1 = deprecated_sequence_constant_1.__len__()

test_case_0()
test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-24 18:31:47.456030
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    var_0 = _DeprecatedSequenceConstant([], [], [])
    assert var_0 is not None

# Generated at 2022-06-24 18:31:49.407440
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """Test method __len__ of class _DeprecatedSequenceConstant"""

    assert isinstance(var_0, int)

# Generated at 2022-06-24 18:31:52.142028
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_0 = []
    int_0 = len(list_0)
    print(int_0)


# Generated at 2022-06-24 18:31:56.898404
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert deprecated_sequence_constant_0 is not None

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:32:03.063560
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Variable bool_0 is of type bool
    var_0 = True
    
    # Variable deprecated_sequence_constant_0 is of type string
    var_1 = "1"

    # Variable deprecated_sequence_constant_0 is of type string
    var_2 = "2"
    
    # Variable deprecated_sequence_constant_0 is of type string
    var_3 = "3"
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_1, var_2, var_3)
    var_0 = deprecated_sequence_constant_0.__getitem__(deprecated_sequence_constant_0)


# Generated at 2022-06-24 18:32:04.093921
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # FIXME: build tests
    pass



# Generated at 2022-06-24 18:32:06.053342
# Unit test for function set_constant
def test_set_constant():
    # FIXME: maybe just fake the globals dict?
    set_constant('test_var', 'this is a test', globals())
    assert globals().get('test_var') == 'this is a test'

# Generated at 2022-06-24 18:32:07.044690
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Tests a valid call to the constructor
    test_case_0()



# Generated at 2022-06-24 18:32:10.876738
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # self, value, msg, version
    _DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant(dict(), dict(), dict())
    # obj, y
    _DeprecatedSequenceConstant_0.__getitem__(_DeprecatedSequenceConstant_0)

    # Unit test for method __len__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:33:30.361443
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert not hasattr(deprecated_sequence_constant_0, '__len__')


# Generated at 2022-06-24 18:33:32.156625
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()



# Generated at 2022-06-24 18:33:32.946082
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:33:34.186687
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Zero arguments
    test_case_0()


# Generated at 2022-06-24 18:33:38.417200
# Unit test for function set_constant
def test_set_constant():
    name = "name"
    value = "value"
    export = vars()
    # pass in module scope instead of having it globals()
    set_constant(name, value, export)
    ans = export[name]
    assert ans == value, "'%s' does not equal '%s'" % (ans, value)
    assert name in export, "'%s' not found in local variables" % name

# Generated at 2022-06-24 18:33:41.314167
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:33:43.386197
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Initialize test suite
    test = TestSuite()
    test.add_test('test_case_0', test_case_0)
    test.run_test()

# Generated at 2022-06-24 18:33:46.872387
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    get_text_0 = bool_0[0]
    var_0 = deprecated_sequence_constant_0.__getitem__(get_text_0)


# Generated at 2022-06-24 18:33:49.423348
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_1 = {}
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(bool_1, bool_1, bool_1)
    assert int(deprecated_sequence_constant_1.__len__()) == 0


# Generated at 2022-06-24 18:33:53.405366
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = {}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert isinstance(deprecated_sequence_constant_0, _DeprecatedSequenceConstant)
