

# Generated at 2022-06-24 18:25:32.072583
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # instantiate from class
    assert isinstance(_DeprecatedSequenceConstant, object)
    # check results of len(), __getitem__()
    assert len(_DeprecatedSequenceConstant) == 9
    assert __getitem__(_DeprecatedSequenceConstant, 0) == deprecate

# Generated at 2022-06-24 18:25:36.026188
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg_0 = "The config {} uses a sequence value with a deprecated and replaced value of: {}. Replace with: {}."
    version_0 = '3.3'
    constant_0 = _DeprecatedSequenceConstant(msg_0, version_0, msg_0)
    constant_0.getmessage()
    constant_0.getversion()
    constant_0.getskipped_rule()


# Generated at 2022-06-24 18:25:41.184876
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    float_0 = 0.0001
    bytes_0 = b'\x904\x06\x05\t\xa1I\xdb\xd1'
    int_0 = 4
    _DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant(float_0, bytes_0, int_0)
    _DeprecatedSequenceConstant__len___0 = _DeprecatedSequenceConstant_0.__len__()


# Generated at 2022-06-24 18:25:46.276374
# Unit test for function set_constant
def test_set_constant():
    float_0 = 0.0001
    bytes_0 = b'\x904\x06\x05\t\xa1I\xdb\xd1'
    int_0 = 4
    var_0 = set_constant(float_0, bytes_0, int_0)



# Generated at 2022-06-24 18:25:54.479253
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = u'd\xf7\x9d\xb8\xce\xb6B\xe6\xbc\xfdo\x1b\xda\xa3l\xfe'
    var_1 = 6
    var_2 = u'8\x19\xa6\x88\x82\r\x8d\x80\x1e\x14\xb1\xce#\xce\xb5\x1f\x10\x85\x9b'
    var_3 = u'\xbb\x03\x1ft\xe3\x1e\x9e\x8d\xee\xa0\xbf\xb1\x07\xdf\xf0\xae\x9b\x0e\x0c\xb3Y'
    var_4

# Generated at 2022-06-24 18:26:00.758543
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_1 = 0.0002
    bytes_1 = b'\x904\x06\x05\t\xa1I\xdb\xd1'
    int_1 = 4

    d = _DeprecatedSequenceConstant(float_1, bytes_1, int_1)

    assert d[0] == tuple(float_1)



# Generated at 2022-06-24 18:26:03.390219
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    x = _DeprecatedSequenceConstant(value=float(0.0001), msg=None, version=None)
    assert x[var_0] == bytes_0


# Generated at 2022-06-24 18:26:04.319701
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    pass


# Generated at 2022-06-24 18:26:08.179524
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    float_0 = 0.0001
    bytes_0 = b'\x904\x06\x05\t\xa1I\xdb\xd1'
    int_0 = 4
    sequence_constant_0 = _DeprecatedSequenceConstant(float_0, bytes_0, int_0)
    sequence_constant_0.__len__()


# Generated at 2022-06-24 18:26:13.691209
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    print('Constructor')
    float_0 = 0.0001
    bytes_0 = b'\x904\x06\x05\t\xa1I\xdb\xd1'
    int_0 = 4
    var_0 = _DeprecatedSequenceConstant(float_0, bytes_0, int_0)
    return var_0

# Generated at 2022-06-24 18:26:22.895789
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 619
    set_0 = {int_0}
    tuple_0 = ()
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, set_0, tuple_0)
    int_1 = 35
    int_2 = 62
    int_3 = 2
    try:
        deprecated_sequence_constant_0.__getitem__(int_1, int_2, int_3)
    except TypeError as e:
        assert "__getitem__() takes 2 positional arguments but 4 were given" in str(e)


# Generated at 2022-06-24 18:26:28.925347
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 619
    set_0 = {int_0}
    tuple_0 = ()
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, set_0, tuple_0)
    getitem_0 = deprecated_sequence_constant_0[int_0]
    if getitem_0 == int_0:
        pass
    else:
        assert False


# Generated at 2022-06-24 18:26:33.412576
# Unit test for function set_constant
def test_set_constant():
    int_0 = 619
    set_0 = {int_0}
    tuple_0 = ()
    set_constant(set_0, tuple_0, int_0)
    set_constant(int_0, set_0, tuple_0)
    set_constant(set_0, int_0, tuple_0)
    set_constant(tuple_0, int_0, set_0)

# Generated at 2022-06-24 18:26:35.506137
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_set_constant', 'test_0')
    assert test_set_constant == 'test_0'


# Generated at 2022-06-24 18:26:43.383898
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1
    set_0 = {int_0}
    tuple_0 = ()
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, set_0, tuple_0)
    res = deprecated_sequence_constant_0.__len__()
    assert res == 1


# Generated at 2022-06-24 18:26:48.328545
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 619
    set_0 = {int_0}
    tuple_0 = ()
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, set_0, tuple_0)
    assert tuple_0 == deprecated_sequence_constant_0._version
    assert set_0 == deprecated_sequence_constant_0._msg
    assert int_0 == deprecated_sequence_constant_0._value


# Generated at 2022-06-24 18:26:55.604974
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import unittest
    from ansible.module_utils.__main__ import StdoutProxy
    self_0 = test_case_0()
    output_capturer = StdoutProxy()
    output_capturer.start()
    int_0 = self_0['deprecated_sequence_constant_0']
    output = output_capturer.stop()
    assert not len(output)

# Generated at 2022-06-24 18:26:56.737429
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:26:57.876044
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:27:06.360986
# Unit test for function set_constant
def test_set_constant():
    import sys
    import os
    import subprocess
    set_constant('', '', export=sys.modules[__name__].__dict__)
    set_constant('', '', export=sys.modules[__name__].__dict__)
    set_constant('', '', export=sys.modules[__name__].__dict__)
    set_constant('', '', export=sys.modules[__name__].__dict__)
    set_constant('', '', export=sys.modules[__name__].__dict__)
    set_constant('', '', export=sys.modules[__name__].__dict__)
    set_constant('', '', export=sys.modules[__name__].__dict__)

# Generated at 2022-06-24 18:27:16.565890
# Unit test for function set_constant
def test_set_constant():
    set_constant('int_0', 1)
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(1, 1, 1)
    var_0 = deprecated_sequence_constant_0.__len__()
    var_1 = globals().get('int_0')
    assert var_0 == var_1


# Generated at 2022-06-24 18:27:19.279637
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__len__()



# Generated at 2022-06-24 18:27:21.449290
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 1
    int_1 = 2
    int_2 = 3
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_1, int_2)


# Generated at 2022-06-24 18:27:30.515770
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert __version__.__class__ is str
    assert _ACTION_DEBUG.__class__ is tuple
    assert _ACTION_IMPORT_PLAYBOOK.__class__ is tuple
    assert _ACTION_IMPORT_ROLE.__class__ is tuple
    assert _ACTION_IMPORT_TASKS.__class__ is tuple
    assert _ACTION_INCLUDE.__class__ is tuple
    assert _ACTION_INCLUDE_ROLE.__class__ is tuple
    assert _ACTION_INCLUDE_TASKS.__class__ is tuple
    assert _ACTION_INCLUDE_VARS.__class__ is tuple
    assert _ACTION_META.__class__ is tuple
    assert _ACTION_SET_FACT.__class__ is tuple
    assert _ACTION_SETUP.__class__ is tuple
    assert _ACTION

# Generated at 2022-06-24 18:27:34.325123
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    try:
        var_0 = deprecated_sequence_constant_0.__len__()
        assert True
    except Exception:
        assert False



# Generated at 2022-06-24 18:27:39.246049
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_1 = 1
    str_0 = "test"

    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(int_1, str_0, int_1)

    assert(deprecated_sequence_constant_1._version == int_1)



# Generated at 2022-06-24 18:27:48.342649
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    string_0 = "c8m#,,=Bn^mK\"HXfm#M%`Q{'$E;.D:jG^";
    var_0 = deprecated_sequence_constant_0.__getitem__(string_0)


# Generated at 2022-06-24 18:27:52.782188
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)


if __name__ == "__main__":
    test_case_0()
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-24 18:27:54.636368
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:27:58.054814
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(0)

# Generated at 2022-06-24 18:28:06.530322
# Unit test for function set_constant
def test_set_constant():
    set_constant(var_0, var_0)

# Generated at 2022-06-24 18:28:08.003870
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:28:10.647223
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except:
        print("Exception in test case 0")

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:28:13.518245
# Unit test for function set_constant
def test_set_constant():
    set_constant('AA', 'aa', export=vars())
    assert vars()['AA'] == 'aa'


# Generated at 2022-06-24 18:28:16.841142
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except TypeError as error:
        print("Caught TypeError:", error)
        return False
    else:
        return True


# Generated at 2022-06-24 18:28:18.954036
# Unit test for function set_constant
def test_set_constant():
    value = 12
    name = 'some_name'

    set_constant(name, value)

    assert value == locals()[name]

# Generated at 2022-06-24 18:28:24.247376
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)

# Generated at 2022-06-24 18:28:27.074067
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    a = _DeprecatedSequenceConstant(0,0,0)
    b = a._DeprecatedSequenceConstant__len__()
    if True:
        assert True
    return


# Generated at 2022-06-24 18:28:31.258686
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
  try:
    test_case_0()
  except Exception as e:
    print("Exception in test case: ", e)

if __name__ == '__main__':
  test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-24 18:28:32.068564
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:28:50.177451
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 1
    str_0 = "test_case_0"
    int_1 = 0
    expected_result = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, str_0, int_1)
    actual_result_1 = deprecated_sequence_constant_0.__len__()
    assert expected_result == actual_result_1, "expected number of attributes didn't match"
    assert isinstance(deprecated_sequence_constant_0, Sequence)
    actual_result_2 = _DeprecatedSequenceConstant.__name__
    assert actual_result_2 != str_0, "expected number of attributes didn't match"

# Test case for set_constant

# Generated at 2022-06-24 18:28:58.123856
# Unit test for function set_constant
def test_set_constant():
    # Module globals
    globals_before = globals().keys()
    # Constant has not yet been set
    assert not('name_0' in globals_before)
    # Set the constant
    set_constant('name_0', 0)
    globals_after = globals().keys()
    # Assert the constant has been set
    assert 'name_0' in globals_after
    # Clean up the globals dict
    globals().pop('name_0')
    globals_end = globals().keys()
    # Assert the constant has been removed
    assert not('name_0' in globals_end)

# Generated at 2022-06-24 18:28:59.884745
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-24 18:29:05.569977
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
  # Test for __init__
  num_0 = 1
  str_0 = 'abc'
  num_1 = 1
  deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(num_0, str_0, num_1)


# Generated at 2022-06-24 18:29:08.860496
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    deprecated_sequence_constant_0.__len__()



# Generated at 2022-06-24 18:29:12.060390
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:29:13.429435
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()



# Generated at 2022-06-24 18:29:19.221200
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    int_1 = 1
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(int_1, int_1, int_1)
    var_1 = deprecated_sequence_constant_1.__getitem__(int_1)


# Generated at 2022-06-24 18:29:24.519778
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:29:32.924602
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    try:
        var_0 = deprecated_sequence_constant_0.__len__()
    except Exception as err:
        var_1 = err.__cause__
    else:
        var_2 = var_0
    if (var_2 is not None):
        with raises(NameError):
            int_0.msg
    else:
        var_3 = var_1
    if (var_3 is not None):
        with raises(NameError):
            int_0.version


# Generated at 2022-06-24 18:29:57.699552
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:30:00.274745
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest
    unittest.main()

test_case_0()

# Generated at 2022-06-24 18:30:05.675346
# Unit test for function set_constant
def test_set_constant():
    # Test case where setting is valid
    try:
        set_constant('var_1', 1)
        var_1 = 1
    except:
        assert False

    # Test case where setting invalid
    try:
        set_constant('var_2', 2)
        var_2 = 2
    except:
        assert False



# Generated at 2022-06-24 18:30:07.515880
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert False


# Generated at 2022-06-24 18:30:09.403126
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0() # Testing: def __len__(self):



# Generated at 2022-06-24 18:30:14.564411
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__()


# Generated at 2022-06-24 18:30:22.604022
# Unit test for function set_constant
def test_set_constant():
    # Create a new config manager
    tempConfig = ConfigManager({"TestConfig": "This is a test"})
    # Create a temporary dictionary
    tempDict = {}
    # Make sure that the tempDict has no elements
    if not len(tempDict) == 0:
        print('Dictionary is not empty!')
        exit(1)
    # Set the constant for key 'TestConfig' to the value in the tempConfig
    set_constant('TestConfig', tempConfig.data.get_setting('TestConfig').value, tempDict)
    # Ensure that the value is what we expect it to be
    if not tempDict['TestConfig'] == tempConfig.data.get_setting('TestConfig').value:
        print('The constant was not set correctly!')
        exit(1)



# Generated at 2022-06-24 18:30:24.405265
# Unit test for function set_constant
def test_set_constant():
    str_0 = "j"
    set_constant(str_0, str_0)



# Generated at 2022-06-24 18:30:25.378772
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:30:28.182164
# Unit test for function set_constant
def test_set_constant():
    name = 'name'
    value = 42
    export = {'name': 'value'}
    set_constant(name, value, export)
    assert value == export['name']




test_set_constant()

# Generated at 2022-06-24 18:32:54.619250
# Unit test for function set_constant
def test_set_constant():
    global TREE_DIR
    global INTERNAL_RESULT_KEYS
    TREE_DIR = 1
    INTERNAL_RESULT_KEYS = 1
    try:
        assert set_constant('TREE_DIR', 1)
        assert set_constant('INTERNAL_RESULT_KEYS', 1)
    finally:
        TREE_DIR = None
        INTERNAL_RESULT_KEYS = ('add_host', 'add_group')

if __name__ == '__main__':
    print('Running unit tests')
    import pytest
    pytest.main()

# Generated at 2022-06-24 18:32:55.345806
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:32:56.040730
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:33:04.650000
# Unit test for function set_constant
def test_set_constant():
    set_constant('int', 1)
    assert 'int' in globals()
    assert globals()['int'] == 1

    set_constant('dict', {'key': 'value'})
    assert 'dict' in globals()
    assert globals()['dict'] == {'key': 'value'}

    set_constant('str', 'value')
    assert 'str' in globals()
    assert globals()['str'] == 'value'

if __name__ == "__main__":
    test_set_constant()
    test_case_0()

# Generated at 2022-06-24 18:33:06.240903
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(config.WARNINGS) == 0
    test_case_0()

# Generated at 2022-06-24 18:33:09.940410
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    int_1 = 1
    var_0 = deprecated_sequence_constant_0.__getitem__(int_1)


# Generated at 2022-06-24 18:33:13.101066
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)

# Generated at 2022-06-24 18:33:15.832824
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:33:16.957366
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:33:20.037537
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as err:
        print("Caught exception: " + str(err))

test__DeprecatedSequenceConstant()