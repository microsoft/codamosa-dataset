

# Generated at 2022-06-24 18:25:21.632844
# Unit test for function set_constant
def test_set_constant():
    assert set_constant


# Generated at 2022-06-24 18:25:23.000887
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:25:25.466665
# Unit test for function set_constant
def test_set_constant():
    assert(set_constant("success", True) == True)
    return True



# Generated at 2022-06-24 18:25:28.420385
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Constructor should work without error
    test_case_0()

# Generated at 2022-06-24 18:25:34.115569
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(bool_0, bool)
    assert isinstance(str_0, str)
    assert isinstance(deprecated_sequence_constant_0, _DeprecatedSequenceConstant)
    assert isinstance(deprecated_sequence_constant_0._value, bool)
    assert isinstance(deprecated_sequence_constant_0._msg, str)
    assert isinstance(deprecated_sequence_constant_0._version, bool)


# Generated at 2022-06-24 18:25:40.255443
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    str_0 = 'default'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
    try:
        deprecated_sequence_constant_0.__len__()
    except Exception as exc:
        print("Exception while calling __len__() of class DeprecatedSequenceConstant with arguments:")
        print("    bool_0: false")
        print("    str_0: default")
        print("    bool_0: false")
        print("Exception: " + str(exc))


# Generated at 2022-06-24 18:25:48.193159
# Unit test for function set_constant
def test_set_constant():
    set_constant('DEFAULT_PASSWORD_CHARS', 'string')
    set_constant('DEFAULT_PASSWORD_CHARS', 'list')
    set_constant('DEFAULT_PASSWORD_CHARS', 'tuple')
    set_constant('DEFAULT_PASSWORD_CHARS', 'dict')
    set_constant('DEFAULT_PASSWORD_CHARS', 'bool')
    set_constant('DEFAULT_PASSWORD_CHARS', 'int')

# Generated at 2022-06-24 18:25:59.678343
# Unit test for function set_constant
def test_set_constant():
    import random

    for _ in range(100):
        # This following line does not work as is, it should be fixed
        # export = vars()
        name = ''.join(random.choice(string.ascii_lowercase) for i in range(random.randint(3, 20)))
        value = ''.join(random.choice(string.ascii_lowercase) for i in range(random.randint(3, 20)))
        export = {'name': value}
        assert {name: value} == set_constant(name, value, export=export)


# Generated at 2022-06-24 18:26:01.433811
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    print('Test 0')
    test_case_0()
    return True


# Generated at 2022-06-24 18:26:02.490705
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()



# Generated at 2022-06-24 18:26:06.682284
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:26:17.007351
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Check if the test method is defined.
    assert '__getitem__' in dir(test_case_0.deprecated_sequence_constant_0)

    # Check if the test class is deprecated.
    assert not test_case_0.deprecated_sequence_constant_0.__doc__ is None
    deprecated_pattern = re.compile('^DEPRECATED:( )*\n', re.MULTILINE)
    assert re.search(deprecated_pattern, test_case_0.deprecated_sequence_constant_0.__doc__) is not None

    # Check if the test class is a subclass of the Sequence class.
    assert isinstance(test_case_0.deprecated_sequence_constant_0, frozenset)



# Generated at 2022-06-24 18:26:18.244892
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:26:18.882067
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()



# Generated at 2022-06-24 18:26:22.674260
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = false()
    str_0 = 'r|'
    _DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
    _DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant_0.__init__(bool_0, str_0, bool_0)

# Generated at 2022-06-24 18:26:26.312713
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Local variables:
# indent-tabs-mode: nil
# tab-width: 4
# End:
# vim: ai et sw=4 ts=4

# Generated at 2022-06-24 18:26:31.325108
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    str_0 = 'default'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)



# Generated at 2022-06-24 18:26:31.918984
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:26:34.655783
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('bool', False)
    except Exception:
        assert False, 'Could not set_constant'


# Generated at 2022-06-24 18:26:35.954578
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')


# Generated at 2022-06-24 18:26:44.952798
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Constructor test case instance
    test_case_0()


# Generated at 2022-06-24 18:26:47.270414
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    str_0 = 'default'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
    try:
        deprecated_sequence_constant_0[0]
    except IndexError:
        pass


# Generated at 2022-06-24 18:26:50.827392
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    str_0 = 'default'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
    int_0 = 1
    # TypeError: 'bool' object is not subscriptable
    with pytest.raises(TypeError):
        assert deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:26:56.997633
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Generated from case test_case_0
    bool_0 = False
    str_0 = 'default'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
    # No exception should be thrown
    deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:27:02.352581
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    str_0 = 'default'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
    assert deprecated_sequence_constant_0._value is False
    assert deprecated_sequence_constant_0._msg == 'default'
    assert deprecated_sequence_constant_0._version is False


# Generated at 2022-06-24 18:27:04.075895
# Unit test for function set_constant
def test_set_constant():

    test_const = 0

    set_constant('test_const', 1)
    assert test_const == 1



# Generated at 2022-06-24 18:27:04.753992
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:27:05.971133
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert deprecated_sequence_constant_0.__len__() == bool_0


# Generated at 2022-06-24 18:27:09.902484
# Unit test for function set_constant
def test_set_constant():
    d = {}
    set_constant('foo', 'bar', d)
    assert d['foo'] == 'bar'


# Generated at 2022-06-24 18:27:13.232116
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    t_1 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
    t_2 = t_1[None]


# Generated at 2022-06-24 18:27:33.804843
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    str_0 = 'default'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
    try:
        deprecated_sequence_constant_0.__getitem__(bool_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 18:27:38.581364
# Unit test for function set_constant
def test_set_constant():
    int_0 = 0
    str_0 = 'test'
    set_constant(int_0, str_0)
    assert_equals(str_0, test_set_constant.__globals__[str(int_0)])


# Generated at 2022-06-24 18:27:39.846294
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()



# Generated at 2022-06-24 18:27:50.957963
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Check type of each attribute and its value
    def test_case_1():
        bool_0 = False
        test__DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
        assert isinstance(test__DeprecatedSequenceConstant_0, _DeprecatedSequenceConstant)
        assert test__DeprecatedSequenceConstant_0._version == bool_0
        assert test__DeprecatedSequenceConstant_0._msg == bool_0
        assert test__DeprecatedSequenceConstant_0._value == bool_0

# Generated at 2022-06-24 18:27:51.749923
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()



# Generated at 2022-06-24 18:27:55.375407
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    str_0 = 'default'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)



# Generated at 2022-06-24 18:27:56.489988
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:28:04.789859
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        # Init of _DeprecatedSequenceConstant
        bool_0 = False
        str_0 = 'default'
        deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
        # Call method __getitem__ on deprecated_sequence_constant_0
        method_object = deprecated_sequence_constant_0.__getitem__(bool_0)
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 18:28:10.674051
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    # Unit tests run as script
    import sys

    mod = sys.modules[__name__]
    func = getattr(mod, sys.argv[1])
    func()

# Generated at 2022-06-24 18:28:16.089244
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    str_0 = 'default'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, str_0, bool_0)
    int_0 = 0
    deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:28:50.589000
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()



# Generated at 2022-06-24 18:28:53.008901
# Unit test for function set_constant
def test_set_constant():
    assert( '_ACTION_DEBUG' in globals())


# Generated at 2022-06-24 18:28:56.766813
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# vim: syntax=python expandtab cindent

# Generated at 2022-06-24 18:28:58.143240
# Unit test for function set_constant
def test_set_constant():
    raise NotImplementedError


# Generated at 2022-06-24 18:28:58.917732
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:29:09.546246
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Constants used for unit test
#DEFAULT_BECOME_PASS = None
#DEFAULT_PASSWORD_CHARS = to_text(ascii_letters + digits + ".,:-_")  # characters included in auto-generated passwords
#DEFAULT_REMOTE_PASS = None
#DEFAULT_SUBSET = None
#IGNORE_FILES = ("COPYING", "CONTRIBUTING", "LICENSE", "README", "VERSION", "GUIDELINES")  # ignore during module search
#LOCALHOST = ('127.0.0.1', 'localhost', '::1')
#TREE_DIR = None
#VAULT_VERSION_MIN = 1.0

# Generated at 2022-06-24 18:29:10.981184
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:29:18.941873
# Unit test for function set_constant
def test_set_constant():
    global test_case_0
    set_constant('bool_0', True, test_case_0)
    set_constant('str_0', 'default', test_case_0)
    set_constant('deprecated_sequence_constant_0', True, test_case_0)
    assert isinstance(test_case_0['bool_0'], bool)
    assert isinstance(test_case_0['str_0'], str)
    assert isinstance(test_case_0['deprecated_sequence_constant_0'], _DeprecatedSequenceConstant)

# Generated at 2022-06-24 18:29:20.935074
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:29:30.774208
# Unit test for function set_constant
def test_set_constant():
    bool_0 = False
    str_0 = 'default'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['test'] = 'test'
    str_1 = 'default'
    dict_0['test'] = 'test'
    set_constant(str_0, dict_0)
    set_constant('test', dict_1, dict_0)
    assert dict_0 == dict_1

    # Unit test for function test_case_0

# Generated at 2022-06-24 18:30:50.548144
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    fileinfo_0 = FileInfo()
    var_0 = fileinfo_0.get_path()
    index_0 = var_0.rfind('/')
    var_1 = var_0[:index_0]
    dir_path_0 = var_1

    # assert that the expected output is obtained.
    assert dir_path_0 == 'lib/ansible/utils', \
        'Value obtained is {}, not {}'.format(dir_path_0, 'lib/ansible/utils')


# Generated at 2022-06-24 18:30:55.044013
# Unit test for function set_constant
def test_set_constant():
    print('==> Running function test for set_constant')
    try:
        set_constant('test', 'value')
        if TEST_CONSTANT == 'value':
            print('PASS')
            return 0
    except Exception as e:
        pass
    print('FAIL')
    return 1

if __name__ == '__main__':
    test_case_0()
    test_set_constant()

# Generated at 2022-06-24 18:31:00.137427
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    y = 0
    var_0 = deprecated_sequence_constant_0.__getitem__(y)


# Generated at 2022-06-24 18:31:03.747974
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False
    # assert False # TODO: implement your test here


# Generated at 2022-06-24 18:31:06.556386
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:31:09.573144
# Unit test for function set_constant
def test_set_constant():
    set_constant('something', 'default')
    if 'something' not in vars():
        raise Exception



# Generated at 2022-06-24 18:31:11.983251
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)


# Generated at 2022-06-24 18:31:16.601588
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_1 = True
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(bool_1, bool_1, bool_1)
    var_1 = deprecated_sequence_constant_1.__len__()


# Generated at 2022-06-24 18:31:23.353626
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    # Unit test for _DeprecatedSequenceConstant
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:31:29.076799
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    int_0 = 0
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)

if __name__ == '__main__':
    test_case_0()
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-24 18:34:05.023599
# Unit test for function set_constant
def test_set_constant():
    # find out the max size of terminal
    term_size = os.popen("stty size", "r").read().split()
    # set the constant value
    set_constant("max_length", int(term_size[1]))
    # assert if the same value is returned or not
    assert max_length == int(term_size[1])




# Generated at 2022-06-24 18:34:06.834017
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except Exception as e:
        raise AssertionError(str(e))


# Generated at 2022-06-24 18:34:13.663918
# Unit test for function set_constant
def test_set_constant():
    # To perform unit test create an instance of class or function with the same name as the module
    # and call the function or class with all the arguments.
    # In this case there is only one function to test, but you could use the same syntax for classes

    # Load the module that you want to test
    import lib.constants
    # Create an instance of the function to test
    set_constant_function = lib.constants.set_constant
    # Define the arguments (in this case only one)
    name_0 = 'name_0'
    value_0 = 'value_0'
    export_0 = 'export_0'
    # Call the function with the arguments
    result_0 = set_constant_function(name_0, value_0, export_0)
    # Compare the results to the expected ones
    assert result

# Generated at 2022-06-24 18:34:15.634663
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)


# Generated at 2022-06-24 18:34:25.727937
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from unittest import TestCase
    from ansible.module_utils.parsing.convert_bool import boolean
    passed = True
    case_list = [0]
    case_list[0] = True
    for case in case_list:
        case_test_function = globals()['test_case_%d' % case]
        passed &= TestCase(case_test_function).run().wasSuccessful()
    if passed:
        boolean(passed)
    return boolean(passed)

# Generated at 2022-06-24 18:34:26.613427
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:34:31.165431
# Unit test for function set_constant
def test_set_constant():
    name = 'ansible_math_binary'
    value = '/usr/bin/python'
    set_constant(name, value)
    assert __builtins__['__ansible_builtin__'][name] == value, 'ansible.utils.constants.set_constant() failed'

# Generated at 2022-06-24 18:34:38.954048
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    print("test_DeprecatedSequenceConstant___len__")
    test_case_0()

# POPULATE SETTINGS FROM CONFIG ### yes, we did

# Normalize action names
for name in list(_ACTION_WITH_CLEAN_FACTS) + list(_ACTION_ALL_INCLUDES):
    if name not in _ACTION_ALL_INCLUDE_IMPORT_TASKS:
        _ACTION_WITH_CLEAN_FACTS += (add_internal_fqcns((name, 'ansible.builtin.' + name)), )

# Generated at 2022-06-24 18:34:42.637099
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)
    assert var_0 is not None


# Generated at 2022-06-24 18:34:45.104384
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)
