

# Generated at 2022-06-24 18:25:24.843828
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([1, 2, 3], 'message', '2.0')

# Generated at 2022-06-24 18:25:29.683792
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    t = _DeprecatedSequenceConstant(['a','b', 'c'], 'msg', 'version')
    assert t[0] == 'a'
    assert t[1] == 'b'
    assert t[2] == 'c'


# Generated at 2022-06-24 18:25:37.307308
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    text_0 = _DeprecatedSequenceConstant(var_0, 'Do not use this', '1.0')
    text_1 = str(text_0)
    text_2 = _DeprecatedSequenceConstant(var_0, 'Do not use this', '1.0')
    text_3 = text_0 == text_2
    text_4 = text_0 in text_2
    text_5 = _DeprecatedSequenceConstant(var_0, 'Do not use this', '1.0')
    text_6 = text_4 == text_5
    text_7 = text_0 == text_6
    text_8 = text_6 in text_2
    text_9 = text_7 != text_8

# Generated at 2022-06-24 18:25:40.557283
# Unit test for function set_constant
def test_set_constant():
    int_0 = 1689
    bytes_0 = b'L\x99x\xc1V\xf1\xd8\xfa\t\xbb[\xf2q'
    class_1 = set_constant(int_0, bytes_0)
    assert class_1 is None


# Generated at 2022-06-24 18:25:50.822017
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1689
    bytes_0 = b'L\x99x\xc1V\xf1\xd8\xfa\t\xbb[\xf2q'
    var_0 = set_constant(int_0, bytes_0)

    int_0 = 1689
    bytes_0 = b'L\x99x\xc1V\xf1\xd8\xfa\t\xbb[\xf2q'
    var_1 = set_constant(int_0, bytes_0)
    # len(_DeprecatedSequenceConstant)
    string_0 = _deprecated(var_0, var_1)



# Generated at 2022-06-24 18:25:52.689311
# Unit test for function set_constant
def test_set_constant():
    assert type(set_constant(int_0, bytes_0)) == bytes


# Generated at 2022-06-24 18:26:01.243558
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1747
    bytes_0 = b'\xfb\xab\x9a\xc9\xa8\xe8\xb8\x82\xd3\xdc\x85\x08\x9b\x9e\xcf\xd8'
    var_0 = _DeprecatedSequenceConstant(int_0, bytes_0, bytes_0)
    var_0_len = var_0.__len__()
    if (var_0_len):
        raise Exception("");

# Generated at 2022-06-24 18:26:05.804695
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    list_0 = ['Test case 0', 'Test case 1']
    sequence_constant_0 = _DeprecatedSequenceConstant(list_0, 'p0', 'p1')
    assert 'test_case_0' in globals()
    dict_0 = dict(list_0=list_0)
    var_0 = set_constant('dict_0', dict_0)


# Generated at 2022-06-24 18:26:07.713521
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant(["test"], "this is a test", "2.5.12").__len__()

# Generated at 2022-06-24 18:26:09.034744
# Unit test for function set_constant
def test_set_constant():
    assert var_0 == bytes_0

# Generated at 2022-06-24 18:26:16.009331
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = 'Y`7'
    bool_0 = False
    float_0 = 3140.42
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    str_1 = 'W!@-!Y'
    bool_1 = False
    float_1 = -6.18
    #Index of String
    assert deprecated_sequence_constant_0[0] == str_1[0]
    

# Generated at 2022-06-24 18:26:22.160292
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '~w*T5_UxiR%`'
    bool_0 = False
    float_0 = -1552.3784
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    int_0 = 12
    str_1 = deprecated_sequence_constant_0[int_0]


# Generated at 2022-06-24 18:26:27.644413
# Unit test for function set_constant
def test_set_constant():
    name_0 = 'K^.9H-xRQhW6M!=6q3'
    value_0 = 'K^.9H-xRQhW6M!=6q3'
    export_0 = vars()
    set_constant(name_0, value_0, export_0)


# Generated at 2022-06-24 18:26:34.596075
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '~w*T5_UxiR%`'
    bool_0 = False
    float_0 = -1552.3784
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    int_0 = 16
    assert deprecated_sequence_constant_0[int_0] == '5'
    assert deprecated_sequence_constant_0[int_0] == '5'
    assert deprecated_sequence_constant_0[int_0] == '5'
    assert deprecated_sequence_constant_0[int_0] == '5'


# Generated at 2022-06-24 18:26:37.431428
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = '~w*T5_UxiR%`'
    bool_0 = False
    float_0 = -1552.3784
    _DeprecatedSequenceConstant(str_0, bool_0, float_0)

# Generated at 2022-06-24 18:26:49.170421
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Generate a random string (str_0)
    str_0 = ''
    for index in range(0, 6):
        str_0 += chr(randrange(97, 122))

    # Generate random boolean value (bool_0)
    bool_0 = randint(0, 1)
    if bool_0:
        bool_0 = True
    else:
        bool_0 = False

    # Generate random float number (float_0)
    float_0 = random()

    # Generate a new DeprecatedSequenceConstant object (deprecated_sequence_constant_0)
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)

    # Use _DeprecatedSequenceConstant.__getitem__ to access deprecated_sequence_constant_

# Generated at 2022-06-24 18:26:56.125594
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = '~w*T5_UxiR%`'
    bool_0 = False
    float_0 = -1552.3784
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    int_0 = deprecated_sequence_constant_0.__len__()
    assert (int_0 == 1)


# Generated at 2022-06-24 18:26:57.258520
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Generated at 2022-06-24 18:27:03.422661
# Unit test for function set_constant
def test_set_constant():
    str_0 = '~w*T5_UxiR%`'
    bool_0 = False
    float_0 = -1552.3784
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    assert len(deprecated_sequence_constant_0) == len(str_0)


# Generated at 2022-06-24 18:27:07.050590
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
        assert('~w*T5_UxiR%`' == test_case_0().deprecated_sequence_constant_0._value)
        assert(False == test_case_0().deprecated_sequence_constant_0._msg)
        assert(-1552.3784 == test_case_0().deprecated_sequence_constant_0._version)

# Generated at 2022-06-24 18:27:22.511234
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'N>D2!=MF'
    str_1 = '%5RvG/QW'
    dict_0 = {
    'int': '|',
    'float': '#',
    'list': 'C',
    'str': '&',
    'dict': ')',
    }
    float_0 = -1552.3784
    dict_1 = dict_0
    int_0 = -35

# Generated at 2022-06-24 18:27:23.730354
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:27:25.941536
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()



# Generated at 2022-06-24 18:27:27.009162
# Unit test for function set_constant
def test_set_constant():
    test_case_0()



# Generated at 2022-06-24 18:27:30.042152
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    pass


# Generated at 2022-06-24 18:27:31.527724
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:34.377422
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as err:
        assert False, str(err)

if __name__ == '__main__':
    # Unit test for constant ANSIBLE_VERSION
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:36.030720
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    test_case_0()


# Generated at 2022-06-24 18:27:37.485768
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:27:39.016929
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:27:49.653631
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:50.367774
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:27:56.851950
# Unit test for function set_constant
def test_set_constant():
    assert not vars().get('_does_not_exist_')
    set_constant('_does_not_exist_', 'foobar')
    assert vars()['_does_not_exist_'] == 'foobar'
    set_constant('_does_not_exist_', 'baz')
    assert vars()['_does_not_exist_'] == 'baz'


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 18:27:58.148833
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:28:00.666216
# Unit test for function set_constant
def test_set_constant():
    result = set_constant('name_0', 'value_1')

    assert result is None
    # assert result == ???

# Generated at 2022-06-24 18:28:07.540726
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = "]\x0cQmf(uAFo4%'`gB*)V"
    float_0 = 2064.3652
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(0)


if __name__ == '__main__':
    test_case_0()
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-24 18:28:14.150797
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = "]\x0cQmf(uAFo4%'`gB*)V"
    float_0 = 2064.3652
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:28:15.900833
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:28:19.031805
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str(), str(), str())
    assert isinstance(deprecated_sequence_constant_0, Sequence) is True


# Generated at 2022-06-24 18:28:20.311998
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()



# Generated at 2022-06-24 18:28:49.815950
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_1 = "]\x0cQmf(uAFo4%'`gB*)V"
    float_1 = 2064.3652
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(str_1, float_1, float_1)
    var_1 = deprecated_sequence_constant_1.__getitem__(0)
    try:
        assert var_1 == "]"
    except AssertionError as e:
        print(e, file=sys.stderr)


# Generated at 2022-06-24 18:28:51.092953
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except:
        print('Exception')

# Generated at 2022-06-24 18:28:52.786367
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    print("test_DeprecatedSequenceConstant")

    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:29:01.635506
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = "=mg`-['`\x0c\x0e *_x{w"
    float_0 = 45.61747879055934
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(5)


if __name__ == '__main__':
    test_case_0()
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-24 18:29:09.141847
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    global str_0, float_0, deprecated_sequence_constant_0, var_0

    str_0 = "]\x0cQmf(uAFo4%'`gB*)V"
    float_0 = 2064.3652
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    print(var_0)


# Generated at 2022-06-24 18:29:12.128635
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert test_case_0() == 8


# Generated at 2022-06-24 18:29:17.090764
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = 'z'
    int_0 = 36
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, int_0, int_0)
    deprecated_sequence_constant_1 = deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:29:26.787711
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = "{b|Z\x7fFb\x06\\'\x0b\\\x7f\x06\x07.\x1d"
    float_0 = 3832.3432
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__("p\x02\x7f\x1a\x0b'\x13\x14\x15\x16")


# Generated at 2022-06-24 18:29:37.573119
# Unit test for function set_constant
def test_set_constant():
    var_0 = BOOLEANS_TRUE.__iter__()
    var_0.__next__()
    var_1 = BOOLEANS_TRUE.__iter__()
    var_1.__next__()
    # RE: [u'y', u'Y', u'1', u'yes', u'Yes', u'YES', u'true', u'true', u'True', u'TRUE']
    set_constant('test_key', 'test_value')
    if 'test_key' in vars():
        return True
    return False


# Generated at 2022-06-24 18:29:38.401188
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:30:04.628948
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:30:05.901435
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:30:09.020925
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__=='__main__':
    test__DeprecatedSequenceConstant()
    print('\n')

# Generated at 2022-06-24 18:30:10.468269
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert  test_case_0() == None

# Generated at 2022-06-24 18:30:11.779475
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:30:12.999815
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()



# Generated at 2022-06-24 18:30:15.969626
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except NameError:
        # Expect an exception here
        pass

# Generated at 2022-06-24 18:30:20.761528
# Unit test for function set_constant
def test_set_constant():
    str_0 = "]\x0cQmf(uAFo4%'`gB*)V"
    float_0 = 2064.3652
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    return var_0


# Generated at 2022-06-24 18:30:27.117625
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = "]\x0cQmf(uAFo4%'`gB*)V"
    float_0 = 2064.3652
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, float_0)
    assert (len(deprecated_sequence_constant_0) == len(str_0))
    assert deprecated_sequence_constant_0[0] == str_0[0]


# Generated at 2022-06-24 18:30:29.574216
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except AssertionError:
        print("AssertionError raised in test_case_0 of test__DeprecatedSequenceConstant")

# Generated at 2022-06-24 18:31:25.111372
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 36
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    assert_equal(deprecated_sequence_constant_0._value, int_0)
    assert_equal(deprecated_sequence_constant_0._msg, int_0)
    assert_equal(deprecated_sequence_constant_0._version, int_0)

# Generated at 2022-06-24 18:31:34.945850
# Unit test for function set_constant

# Generated at 2022-06-24 18:31:36.411105
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-24 18:31:37.350961
# Unit test for function set_constant

# Generated at 2022-06-24 18:31:40.078460
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 36
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:31:45.648120
# Unit test for function set_constant
def test_set_constant():
    set_constant(str, int, export=dict)
    expired_int_constant_0 = int

# This is used for the --diff argument, to allow the end of the diff string to be modified
# for easier reading in some cases.
_DIFF_INSTR_REPLACE_RE = re.compile(r'^(\s*)[^\n]+', re.M)

# NOTE: this is not a proper to/from conversion, it's a lossy conversion that turns an arbitrary
# dict/complex object into a dict that can be used with the json module.
#
# in particular, it recursively walks lists and sets, checking the contents of all the items and
# trying to turn things inside into simple types.
#
# Recursion should eventually terminate because items that aren't one of the datatypes above are checked
# to see if

# Generated at 2022-06-24 18:31:56.457991
# Unit test for function set_constant
def test_set_constant():
    test_var_1 = "val_1"
    test_var_2 = "val_2"
    tmp_dict = {}
    test_case_0()
    assert(tmp_dict == {})
    set_constant(test_var_1, test_var_2, tmp_dict)
    assert(tmp_dict["test_var_1"] == test_var_2)
    test_var_3 = "val_3"
    test_var_4 = "val_4"
    tmp_dict = {}
    set_constant(test_var_3, test_var_4)
    assert(globals()["test_var_3"] == test_var_4)

if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-24 18:31:57.550615
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('name', 'value') == None


# Generated at 2022-06-24 18:31:58.262308
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert test_case_0()


# Generated at 2022-06-24 18:31:59.530461
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert test_case_0() == 36

test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:32:56.436473
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        int_0 = 13
        deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
        deprecated_sequence_constant_0.__getitem__(int_0)

        assert False
    except Exception as e:
        print("exception: ", e)
        assert True


# Generated at 2022-06-24 18:32:56.869171
# Unit test for function set_constant
def test_set_constant():
    pass

# Generated at 2022-06-24 18:33:00.328384
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    print(test_case_0())


# Generated at 2022-06-24 18:33:01.628548
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:33:04.387213
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 72
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)

# Generated at 2022-06-24 18:33:05.055421
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert test_case_0() == 36

# Generated at 2022-06-24 18:33:08.746971
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    int_0 = 36
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)

# Generated at 2022-06-24 18:33:09.633852
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:33:11.088018
# Unit test for function set_constant
def test_set_constant():
    print("test_set_constant")
    # FIXME: create test

# Generated at 2022-06-24 18:33:15.703197
# Unit test for function set_constant
def test_set_constant():
    class TestClass(object):
        def __init__(self,):
            self.test_value = 'passed'
    test_obj = TestClass()
    set_constant('test_obj', test_obj)
    assert test_obj == getattr(set_constant, 'test_obj')
    assert test_obj.test_value == getattr(test_obj, 'test_value')



# Generated at 2022-06-24 18:34:12.166800
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 36
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:34:14.381936
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 36

    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)
    print(var_0)


# Generated at 2022-06-24 18:34:16.291170
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 36
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:34:19.933789
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    test_case_0()

# Generated at 2022-06-24 18:34:20.970996
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:34:26.144469
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

    import sys
    from ansible.module_utils._text import to_bytes

    if sys.version_info[0] >= 3:
        assert type(var_0) == int
    else:
        assert type(var_0) == long



# Generated at 2022-06-24 18:34:27.544354
# Unit test for function set_constant
def test_set_constant():
    # Test for case 0
    test_case_0()

# Generated at 2022-06-24 18:34:30.835726
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 36
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:34:32.873381
# Unit test for function set_constant
def test_set_constant():
    assert set_constant(__version__, __version__, None) is None

if __name__ == "__main__":
    import sys
    sys.exit(0)

# Generated at 2022-06-24 18:34:36.795867
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_1 = 36
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(int_1, int_1, int_1)
    assert(deprecated_sequence_constant_1.__len__() == int_1)

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()