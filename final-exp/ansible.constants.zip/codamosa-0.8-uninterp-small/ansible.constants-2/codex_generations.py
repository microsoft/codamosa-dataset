

# Generated at 2022-06-24 18:25:26.148923
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = 'Expected: not empty Actual: <class \'int\'>: 0'
    int_0 = 0
    var_0 = _DeprecatedSequenceConstant(int_0, msg, '3.3.3')
    var_1 = var_0.__len__()
    assert var_1 == 0


# Generated at 2022-06-24 18:25:30.837383
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    variable_0 = _DeprecatedSequenceConstant([], {}, 0.0)
    int_0 = variable_0.__len__()


# Generated at 2022-06-24 18:25:34.315435
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    item_0 = _DeprecatedSequenceConstant(value=[], msg='', version='')
    try:
        item_0.__getitem__(1)
    except IndexError as e:
        assert 'index out of range' == e.args[0]


# Generated at 2022-06-24 18:25:36.239124
# Unit test for function set_constant
def test_set_constant():
    # Test if the value has been exported.
    assert 'var_0' in vars()
    # Test if it's value has been exported.
    assert int_0 == vars()['var_0']


# Generated at 2022-06-24 18:25:39.717284
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    _DeprecatedSequenceConstant___getitem__object = _DeprecatedSequenceConstant(int, int, int)
    # Assign values to the parameters.
    int_0 = -1731
    _DeprecatedSequenceConstant___getitem__object[int_0]



# Generated at 2022-06-24 18:25:45.091132
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = tuple()
    msg = 'some string'
    version = 'some string'
    inst = _DeprecatedSequenceConstant(value, msg, version)
    assert inst._value == value
    assert inst._msg == msg
    assert inst._version == version
    assert inst.__len__() == len(value)
    assert inst.__getitem__(0) == value[0]
    inst = _DeprecatedSequenceConstant('some string', 'some string', 'some string')
    assert inst._value == 'some string'
    assert inst._msg == 'some string'
    assert inst._version == 'some string'
    assert inst.__len__() == len('some string')
    assert inst.__getitem__(0) == 'some string'[0]


# Generated at 2022-06-24 18:25:49.395276
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_0 = _DeprecatedSequenceConstant([-100, -100.0, -100.1, -100], 'message', 'version')
    assert len(var_0) == 4


# Generated at 2022-06-24 18:26:02.581850
# Unit test for function set_constant
def test_set_constant():
    """
    Function set_constant(name, value, export)

    Set a constant and return the resolved options dict.
    """

    import inspect

    constants = {
        'CONSTANT_A': 4,
        'CONSTANT_B': 5.5,
        'CONSTANT_C': 'constant_c',
        'CONSTANT_D': 'constant_d',
        'CONSTANT_E': {
            'constant_e_a': 'constant_e_a',
            'constant_e_b': 'constant_e_b',
            'constant_e_c': 'constant_e_c',
            'constant_e_d': 'constant_e_d',
        }
    }

    def verify_constants():
        failure = False

# Generated at 2022-06-24 18:26:04.525760
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    obj = _DeprecatedSequenceConstant(None, None, None)
    assert isinstance(obj, _DeprecatedSequenceConstant)


# Generated at 2022-06-24 18:26:11.037664
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()
    test_case_0()
    test_case_0()
    int_0 = -1731
    float_0 = -928.16
    var_0 = set_constant(int_0, float_0)
    test_case_0()
    test_case_0()
    test_case_0()



# Generated at 2022-06-24 18:26:22.324403
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg_0 = "random string"
    version_0 = "6.0.0"
    # assert (test_case_0() == True)
    _DeprecatedSequenceConstant_instance_0 = _DeprecatedSequenceConstant(msg_0, version_0, msg_0)
    _DeprecatedSequenceConstant_instance_0.__len__()
    _DeprecatedSequenceConstant_instance_0.__getitem__(version_0)

test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:26:22.822778
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert 1


# Generated at 2022-06-24 18:26:26.428745
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant('value', 'msg', 'version')

if __name__ == '__main__':
    test_case_0()
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:26:28.493388
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    seq_0 = _DeprecatedSequenceConstant([], '', '')
    int_0 = seq_0.__len__()

# Generated at 2022-06-24 18:26:32.283535
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = _DeprecatedSequenceConstant(value=(1, 2, 3), msg='msg', version='version')
    if obj.__len__() == 3:
        obj.__len__()
    else:
        raise Exception('Exception was expected but not raised')


# Generated at 2022-06-24 18:26:36.929863
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    set_constant('value', [1, 2, 3])
    set_constant('msg', 'msg')
    set_constant('version', 'version')
    constant_1 = _DeprecatedSequenceConstant(value, msg, version)
    assert (constant_1.__len__() is None)


# Generated at 2022-06-24 18:26:40.964544
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()
    seq_0 = _DeprecatedSequenceConstant(object(), object(), object())
    length_0 = len(seq_0)

# Generated at 2022-06-24 18:26:44.828271
# Unit test for function set_constant
def test_set_constant():
    set_constant("int_0", int_0, export=vars())
    return

if __name__ == "__main__":
    test_set_constant()

# Generated at 2022-06-24 18:26:45.906104
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(value = (), msg = "test msg", version = "test version")


# Generated at 2022-06-24 18:26:48.017633
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()
    assert len(_DeprecatedSequenceConstant([], 'msg', 'version')) == 0


# Generated at 2022-06-24 18:26:56.616502
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('lol', 'lol')
    except NameError:
        print("FAIL: NameError")
    else:
        print("PASS")

if __name__ == '__main__':
    test_case_0()
    test_set_constant()

# Generated at 2022-06-24 18:26:59.969668
# Unit test for function set_constant
def test_set_constant():
    try:
        test_case_0()
    except:
        print("Exception in set_constant")
        assert True == False

# Unit test execution
test_set_constant()

# Generated at 2022-06-24 18:27:04.809883
# Unit test for function set_constant
def test_set_constant():
    # try to slip malicious code in
    name = "__import__('subprocess').call(['/bin/sh','-c','echo OWNED > /tmp/owned'])"
    value = "subprocess.call(['/bin/sh','-c','echo OWNED > /tmp/owned'])"
    set_constant(name, value)


# Generated at 2022-06-24 18:27:05.577643
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = test_case_0()


# Generated at 2022-06-24 18:27:09.335071
# Unit test for function set_constant
def test_set_constant():
    print(test_case_0())

# Check if set_constant function returns a non-empty string

# Generated at 2022-06-24 18:27:14.308807
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    float_0 = -7.750283782402131
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    assert deprecated_sequence_constant_0.__len__() == 1



# Generated at 2022-06-24 18:27:22.467803
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant(1, 1)
    except TypeError as err:
        assert str(err) == "Module name must be a string"
    else:
        raise Exception("No exception was raised for non-string module_name")

    try:
        set_constant("python", 1)
    except TypeError as err:
        assert str(err) == "Module value must be a string"
    else:
        raise Exception("No exception was raised for non-string module_name")

    try:
        set_constant("python", "2.7", ["list"])
    except TypeError as err:
        assert str(err) == "Export dict must be a dict"
    else:
        raise Exception("No exception was raised for non-dict export_dict")


# Generated at 2022-06-24 18:27:27.698189
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    float_0 = -7.750283782402131
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:27:38.966022
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as exc:
        assert False, exc

for deprecated in config.DEPRECATED:
    _deprecated(deprecated.msg, deprecated.version)

# FIXME: pull this into config
VERSION = __version__


# Generated at 2022-06-24 18:27:44.401287
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -7.750283782402131
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(float_0)


# Generated at 2022-06-24 18:27:57.250538
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -1.2518154451149803
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(float_0)


# Generated at 2022-06-24 18:27:59.640997
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:28:02.139026
# Unit test for method __len__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:28:10.061238
# Unit test for function set_constant

# Generated at 2022-06-24 18:28:11.336667
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert test_case_0()



# Generated at 2022-06-24 18:28:15.713282
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except Exception as err:
        print('Caught exception: ' + repr(err))


if __name__ == '__main__':
    test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-24 18:28:17.029222
# Unit test for function set_constant
def test_set_constant():
    test_case_0()


# Generated at 2022-06-24 18:28:18.107462
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:28:22.380127
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(1.0, 1.0, 1.0)
    var_0 = deprecated_sequence_constant_0._value
    var_1 = deprecated_sequence_constant_0._msg
    var_2 = deprecated_sequence_constant_0._version
    var_3 = deprecated_sequence_constant_0.__len__()
    var_4 = deprecated_sequence_constant_0.__getitem__(2)
    

# Generated at 2022-06-24 18:28:24.825182
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:28:38.613231
# Unit test for function set_constant
def test_set_constant():
    name = 'foo'
    value = 'bar'
    export = {}
    set_constant(name, value, export)
    assert 'foo' in export
    assert export[name] == 'bar'

# Generated at 2022-06-24 18:28:43.706209
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    float_0 = -7.750283782402131
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__len__()

# Generated at 2022-06-24 18:28:47.834321
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -7.750283782402131
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(float_0)
    assert var_0 == 0.8123850163391576


# Generated at 2022-06-24 18:28:51.912826
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    float_0 = -7.750283782402131
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:28:55.722152
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except Exception as e:
        print('Exception caught: ', e)

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-24 18:29:00.508481
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    index = 0
    float_0 = -8.331415974680284
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, index, index)
    assert isinstance(deprecated_sequence_constant_0.__getitem__(index), float)


# Generated at 2022-06-24 18:29:02.644676
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Unit test entry point

# Generated at 2022-06-24 18:29:07.123864
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -7.750283782402131
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(float_0)

# Generated at 2022-06-24 18:29:08.456663
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert test_case_0() == 0


# Generated at 2022-06-24 18:29:09.477089
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:29:33.665396
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except Exception:
        print('Exception: __DeprecatedSequenceConstant___len__')

# Generated at 2022-06-24 18:29:35.934773
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-24 18:29:38.857842
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -7.0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(float_0)


# Generated at 2022-06-24 18:29:41.612607
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -7.750283782402131
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(0)


# Generated at 2022-06-24 18:29:44.317370
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:29:50.507184
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    float_0 = -7.750283782402131
    deprecated_sequence_constant_3 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_3.__getitem__(float_0)


# Generated at 2022-06-24 18:29:55.688698
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except Exception as err:
        print('Caught exception: {}'.format(err))
        raise Exception('Received exception')
    else:
        print('No exception caught')

test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-24 18:29:57.371372
# Unit test for function set_constant
def test_set_constant():
    set_constant('name', 'value')  # No exception raised


# Generated at 2022-06-24 18:30:04.378155
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    print('Test constructors')
    float_0 = -2.574162506705262
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)

    var_0 = deprecated_sequence_constant_0.__len__()




# Generated at 2022-06-24 18:30:10.872666
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    def test_method_0():

        float_0 = -7.750283782402131
        deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
        var_0 = deprecated_sequence_constant_0.__getitem__(float_0)


# Generated at 2022-06-24 18:31:04.683134
# Unit test for function set_constant
def test_set_constant():
    # Yes, this is horrible, but it only gets evaluated if the unit test is called
    # i.e. it's not called during normal use of this module
    # FIXME: make this better.
    set_constant('INT_1', 1)
    test_case_0()

# Generated at 2022-06-24 18:31:08.652621
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = 0.0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    float_1 = float_0

    try:
        deprecated_sequence_constant_0.__getitem__(float_1)
        assert True
    except Exception:
        assert False, "Unreachable"



# Generated at 2022-06-24 18:31:16.321127
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -3.0897134213243074
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(float_0)
    assert type(var_0) == float, "var_0 should be a float"



# Generated at 2022-06-24 18:31:17.412702
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()



# Generated at 2022-06-24 18:31:20.245888
# Unit test for function set_constant
def test_set_constant():
    name = 'test_set_constant'
    value = '_set_constant'
    set_constant(name, value)
    if name != value:
        print('Error: name and value do not match')
        print('Expected value: ', name)
        print('Actual value: ', value)
        return
    print('Correct value')

# Generated at 2022-06-24 18:31:23.517121
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(58, 58, 58)
    var_0 = deprecated_sequence_constant_0.__getitem__(58)


# Generated at 2022-06-24 18:31:27.684351
# Unit test for function set_constant
def test_set_constant():
    # Setup fixture
    name = "test"
    value = "value"
    export = {}

    try:
        set_constant(name, value, export)
        assert export[name] == value
    except Exception:
        assert False, "Failed to call function set_constant"


# Generated at 2022-06-24 18:31:28.685070
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert test_case_0() == 0



# Generated at 2022-06-24 18:31:31.025697
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    long_0 = -942474104848209645
    var_0 = _DeprecatedSequenceConstant.__getitem__(long_0, long_0)


# Generated at 2022-06-24 18:31:35.039768
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -7.750283782402131
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_0, float_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(float_0)



# Generated at 2022-06-24 18:32:29.722520
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:32:37.619980
# Unit test for function set_constant
def test_set_constant():
    var_1 = set_constant('asdf', 'asdf', export=[])
    var_2 = set_constant('asdf', 'asdf', export={})

if __name__ == "__main__":
    # Unit test for function _warning
    test_case_0()
    # Unit test for function set_constant
    test_set_constant()

# Generated at 2022-06-24 18:32:39.027526
# Unit test for function set_constant
def test_set_constant():
    assert callable(set_constant)

if __name__ == "__main__":
    test_case_0()
    test_set_constant()

# Generated at 2022-06-24 18:32:46.533077
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    boolean_0 = true
    boolean_1 = false
    string_0 = 'hlpzV7MBu'
    string_1 = 'r6U'
    string_2 = 'pX8I'
    string_3 = 'DZ2'
    int_0 = 5
    int_1 = -2
    float_0 = 1.3
    float_1 = -4.507056854299547
    float_2 = -5.920544189044231
    float_3 = 5.0583423586612635
    float_4 = -9.653482794368893
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, string_0, float_0)
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:32:54.965544
# Unit test for function set_constant
def test_set_constant():
    string_0 = 'GHTAz$'
    string_1 = '0'
    value_0 = '1'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()

    # Call function set_constant
    set_constant(string_0, string_1, dict_0)

    # Call function set_constant
    set_constant(string_0, dict_1, dict_2)

    # Assertions
    assert dict_0.get(string_0) == string_1
    assert dict_2.get(string_0) == dict_1


# Generated at 2022-06-24 18:32:56.833640
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_0 = _DeprecatedSequenceConstant(1, 1, 1)
    var_1 = var_0.__len__()
    print("var_1 value : " + str(var_1))


# Generated at 2022-06-24 18:33:04.753643
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    float_1 = 8.880112447101222
    str_0 = '1e9a9a8f-c4f4-4a4a-a2e2-cec62e071426'
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(float_1, str_0, float_1)

    var_0 = deprecated_sequence_constant_1.__len__()

    assert var_0 == float_1


# Generated at 2022-06-24 18:33:09.274052
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = 8.961524296618266
    float_1 = -2.218735758940717
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, float_1, float_0)
    deprecated_sequence_constant_0.__getitem__(float_1)


# Generated at 2022-06-24 18:33:11.376065
# Unit test for function set_constant
def test_set_constant():
    pass


if __name__ == '__main__':

    # Unit test for function set_constant
    test_case_0()

# Generated at 2022-06-24 18:33:21.923341
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # test case source: https://bugs.python.org/issue33923
    float_1 = -39.879456
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant('a', 'a', float_1)
    assert ( isinstance(deprecated_sequence_constant_1.__getitem__('a'), str) )

# Generated at 2022-06-24 18:35:18.604162
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_4 = -4.38179506039
    deprecated_sequence_constant_4 = _DeprecatedSequenceConstant(float_4, float_4, float_4)
    var_4 = deprecated_sequence_constant_4.__getitem__(float_4)
