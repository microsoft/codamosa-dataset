

# Generated at 2022-06-24 18:25:26.956736
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant.__getitem__(test_case_0.deprecated_sequence_constant_0, (test_case_0.deprecated_sequence_constant_0)) is test_case_0.str_0


# Generated at 2022-06-24 18:25:28.199039
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Generated at 2022-06-24 18:25:32.429467
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = "KQPN72Ii+'\x0c\x0c4P"
    list_0 = [str_0]
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, list_0, str_0)

# Generated at 2022-06-24 18:25:38.484401
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = 'UVSz@x6^\x0e'
    list_0 = [str_0]
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, list_0, str_0)

    # Verify that the method __getitem__ of class _DeprecatedSequenceConstant is wrapped
    try:
        deprecated_sequence_constant_0.__getitem__(str_0)
    except Exception as exception_0:
        if 'Wrap' in str(exception_0):
            assert True
        else:
            assert False

    # Verify that the method __getitem__ of class _DeprecatedSequenceConstant is wrapped

# Generated at 2022-06-24 18:25:39.214177
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:25:40.098612
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:25:41.342194
# Unit test for function set_constant
def test_set_constant():
    set_constant(str_0, str_0)


# Generated at 2022-06-24 18:25:47.491625
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = "KQPN72Ii+'\x0c\x0c4P"
    list_0 = [str_0]
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, list_0, str_0)
    len_0 = len(deprecated_sequence_constant_0)


# Generated at 2022-06-24 18:25:50.125763
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except TypeError as error:
        print(error)


# Generated at 2022-06-24 18:25:52.983325
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    __tracebackhide__ = True
    # Testing for __getitem__ of class _DeprecatedSequenceConstant

    test_case_0()


# Generated at 2022-06-24 18:26:00.819755
# Unit test for function set_constant
def test_set_constant():
    set_constant('SET_CONSTANT_TEST', 'test', vars())
    assert vars()['SET_CONSTANT_TEST'] == 'test'
    del vars()['SET_CONSTANT_TEST']

# Generated at 2022-06-24 18:26:05.600150
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg_0 = "this is msg"
    version_0 = "this is version"
    # test constant
    value_0 = _ACTION_ALL_INCLUDES
    # test param msg
    _DeprecatedSequenceConstant(value_0, msg_0, version_0)
    # test param version
    _DeprecatedSequenceConstant(value_0, msg_0, version_0)



# Generated at 2022-06-24 18:26:13.414425
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Create an instance of class _DeprecatedSequenceConstant
    obj_0 = _DeprecatedSequenceConstant(value=None, msg=None, version=None)
    # Test the len() function
    int_0 = len(obj_0)
    # Test the __getitem__() function
    _DeprecatedSequenceConstant_0 = obj_0[0]
    # AssertionError: False is not true
    assert (False)


# Generated at 2022-06-24 18:26:18.185902
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(value=add_internal_fqcns(('debug', )), msg='msg', version='version')
    assert _DeprecatedSequenceConstant(value=add_internal_fqcns(('raw', )), msg='msg', version='version')


# Generated at 2022-06-24 18:26:20.928367
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    assert issubclass(_DeprecatedSequenceConstant, Sequence)


# Generated at 2022-06-24 18:26:28.835527
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    bool_1 = True
    value = (1, None, "")
    msg = "Just For Test"
    version = "0.1.0"
    obj_0 = _DeprecatedSequenceConstant(value, msg, version)
    len_1 = len(obj_0)
    bool_2 = len_1 == 3
    if bool_2:
        bool_1 = False
    bool_0 = bool_1
    assert bool_0 == bool_1

test__DeprecatedSequenceConstant___len__()



# Generated at 2022-06-24 18:26:31.997214
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['a', 'b', 'c']
    msg = 'this is a test message'
    version = 'some version'
    _DeprecatedSequenceConstant(value, msg, version)

# Generated at 2022-06-24 18:26:35.464642
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    temp_instance = _DeprecatedSequenceConstant(bool_0, 'msg', 'version')
    temp_instance.__len__()
    temp_instance.__getitem__(0)


# Generated at 2022-06-24 18:26:44.327631
# Unit test for function set_constant
def test_set_constant():
    bool_0 = False
    export = None
    value = ''
    name = 'test_constant'
    set_constant(name, value)
    if name in globals():
        bool_0 = True
    set_constant(name, value, export)
    if name in export:
        bool_0 = True
    test_case_0()
    assert bool_0


# Generated at 2022-06-24 18:26:46.016837
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    object_0 = _DeprecatedSequenceConstant(None, None, None)
    object_0._value = ['get', 'utr']
    assert object_0[1] == 'utr'

# Generated at 2022-06-24 18:26:56.297892
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    coll = _DeprecatedSequenceConstant(value=[], msg='', version='')
    # No exception should be raised
    coll.__getitem__(0)


# Generated at 2022-06-24 18:27:00.622083
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = []
    msg = "msg"
    version = "version"
    obj = _DeprecatedSequenceConstant(value, msg, version)
    y = 0
    obj.__getitem__(y)
    assert True


# Generated at 2022-06-24 18:27:05.911710
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Set up mock objects
    value = test_case_0()
    msg = test_case_0()
    version = test_case_0()
    # Invoke the constructor
    # Verify that the expected exception was thrown
    try:
        _DeprecatedSequenceConstant(value, msg, version)
    except Exception as e:
        assert(isinstance(e, SyntaxError))

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:11.819749
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        constant = _DeprecatedSequenceConstant(42, "This is a warning", "2.0")
        constant[0]
    except Exception:
        assert False, "The method raised an Exception"
    else:
        assert True


# Generated at 2022-06-24 18:27:21.716967
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils.common._collections_compat import Mapping
    # Test for non constant string
    try:
        set_constant("AN_STRING", "Hello")
    except AttributeError:
        pass
    else:
        raise Exception("Failed to raise AttributeError for setting a non-constant value")
    # Test for valid constant string
    set_constant("AN_STRING", u"Hello", export=globals())
    assert AN_STRING == "Hello"
    # Test for valid constant unicode
    set_constant("AN_UNICODE", u"Hello", export=globals())
    assert AN_UNICODE == u"Hello"
    # Test for valid constant bool
    set_constant("AN_BOOL", True, export=globals())
    assert AN

# Generated at 2022-06-24 18:27:29.180735
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    global _warning_called
    _warning_called = False
    def _warning_patched(msg):
        global _warning_called
        _warning_called = True

    _DeprecatedSequenceConstant("value", "msg", "version")

    _warning_called = False
    old_warning = AnsibleOptions._warning
    AnsibleOptions._warning = _warning_patched
    _DeprecatedSequenceConstant("value", "msg", "version")
    assert _warning_called
    AnsibleOptions._warning = old_warning


# Generated at 2022-06-24 18:27:33.017700
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # note: the test case only pass when test_case_0 had been executed in the same session
    if len(_DeprecatedSequenceConstant([1,2,3], 'msg', 'version')) != 3:
        # Should actually raise an exception here but for now just print
        print("test case failed")



# Generated at 2022-06-24 18:27:36.863437
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()
    test_0 = _DeprecatedSequenceConstant(value=None, msg='', version='')
    pass

# vim: filetype=python

# Generated at 2022-06-24 18:27:39.107781
# Unit test for function set_constant
def test_set_constant():
    result = set_constant('bool_0', True, test_case_0.__dict__)
    assert result == {'bool_0': True}


# Generated at 2022-06-24 18:27:47.725360
# Unit test for function set_constant
def test_set_constant():
    """
    Test setting a constant and check to see if the value has been set correctly
    """

    test_constant_0 = 'test_constant_0'
    test_constant_value = 'test'

    set_constant(test_constant_0, test_constant_value)

    assert test_constant_value == globals()[test_constant_0]



# Generated at 2022-06-24 18:28:04.514689
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except:
        print("Test case 0 failed!")

test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:28:11.534107
# Unit test for function set_constant
def test_set_constant():
    value = set_constant('bool_0', True)  # value = True
    assert value is True, f'expected {True}, got {value}'
    value = set_constant('none_0', None)
    assert value is None, f'expected {None}, got {value}'
    value = set_constant('none_1', False)
    assert value is False, f'expected {False}, got {value}'



# Generated at 2022-06-24 18:28:14.454247
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant(0, "", "")
    deprecated_sequence_constant[0]



# Generated at 2022-06-24 18:28:16.778043
# Unit test for function set_constant
def test_set_constant():
    # Assert value of constant TEST_CASE_0
    assert(test_case_0 == True)


# Generated at 2022-06-24 18:28:25.606537
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from types import GeneratorType
    from collections.abc import Sized
    from collections import Sequence
    from ansible.config.constants import _DeprecatedSequenceConstant

    # From the Python 3 documentation: "If a class defines only one of __len__() or __bool__(),
    # the interpreter will call __bool__() if the class instance is used as a condition in the
    # context of a boolean expression"
    # "Not implementing __bool__() and __len__() is almost always an error."

    assert issubclass(_DeprecatedSequenceConstant, Sized)
    assert issubclass(_DeprecatedSequenceConstant, Sequence)

    # Create class instance
    value = []
    msg = "test_msg"
    version = "test_version"

    x = _DeprecatedSequenceConstant(value, msg, version)

   

# Generated at 2022-06-24 18:28:31.468814
# Unit test for function set_constant
def test_set_constant():
    local_vars = locals()

    set_constant('TEST_CONSTANT', 'hello')
    assert local_vars['TEST_CONSTANT'] == 'hello'

    set_constant('TEST_CONSTANT', 'hello', local_vars)
    assert local_vars['TEST_CONSTANT'] == 'hello'

    set_constant('TEST_CONSTANT', 'hello', export=globals())
    assert globals()['TEST_CONSTANT'] == 'hello'



# Generated at 2022-06-24 18:28:33.204495
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(
        [1, 2, 3],
        "msg",
        "version")
    print(len(constant))


# Generated at 2022-06-24 18:28:47.029857
# Unit test for function set_constant
def test_set_constant():
    # Make sure we're able to fail with a non-defined variable
    try:
        set_constant('test_case_1', bool_1)
    except NameError:
        pass
    # Make sure we don't have the variable defined beforehand
    try:
        set_constant('test_case_1', bool_0)
    except NameError:
        raise
    # Make sure that the variable is set to True
    if not test_case_1:
        raise
    # Make sure we can override an existing variable to False
    set_constant('test_case_1', False)
    if test_case_1:
        raise
    # Remove the variable so we don't pollute the global namespace
    del test_case_1

test_set_constant()

# Generated at 2022-06-24 18:28:53.912761
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    __msg = 'test'
    __version = 'test'
    __obj = _DeprecatedSequenceConstant([], __msg, __version)
    _deprecated(__msg, __version)

    # __obj = _DeprecatedSequenceConstant([], __msg, __version)
    # __obj = _DeprecatedSequenceConstant([], __msg, __version)
    # __obj = _DeprecatedSequenceConstant([], __msg, __version)
    # __obj = _DeprecatedSequenceConstant([], __msg, __version)
    # __obj = _DeprecatedSequenceConstant([], __msg, __version)
    # __obj = _DeprecatedSequenceConstant([], __msg, __version)
    # __obj = _DeprecatedSequenceConstant([], __msg, __version)
    # __obj

# Generated at 2022-06-24 18:28:57.320976
# Unit test for function set_constant
def test_set_constant():
    assert True
    return
    assert test_case_0() == True

test_set_constant()

# Generated at 2022-06-24 18:29:15.765164
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()

# Generated at 2022-06-24 18:29:18.742594
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__([])

# Generated at 2022-06-24 18:29:23.135084
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:29:28.413079
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    # var_0 is not used
    deprecated_sequence_constant_0.__len__()
    # var_0 is not used
    deprecated_sequence_constant_0.__len__()
    # var_0 is not used
    deprecated_sequence_constant_0.__len__()

# Generated at 2022-06-24 18:29:32.512741
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except:
        print('Testing failed: test__DeprecatedSequenceConstant___len__')


# Generated at 2022-06-24 18:29:33.983243
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:29:39.381921
# Unit test for function set_constant
def test_set_constant():
    name = 'MOCK_NAME'
    value = 'MOCK_VALUE'
    export = { }

    set_constant(name, value, export)
    assert export[name] == value, 'set_constant fails'

if __name__ == '__main__':
    if test_case_0() == False:
        print('fail')
    else:
        print('success')
    test_set_constant()

# Generated at 2022-06-24 18:29:41.806176
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    pass


if __name__ == "__main__":
    test_case_0()
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:29:47.721008
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = []
    int_0 = 0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)

# Generated at 2022-06-24 18:29:53.920399
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    #assert test_case_0() == None
    str_0 = 'test_case_0'
    str_1 = [1, 2, 3]
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_1, str_0)
    var_2 = deprecated_sequence_constant_0.__getitem__(0)

# Generated at 2022-06-24 18:30:16.096219
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Run unit tests
if __name__ == '__main__':
    test_case_0()
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:30:19.073692
# Unit test for function set_constant
def test_set_constant():
    var_1 = (test_case_0())
    try:
        assert (var_1 > 0)
    except AssertionError:
        raise AssertionError("function set_constant() failed")

test_set_constant()

# Generated at 2022-06-24 18:30:24.117803
# Unit test for function set_constant
def test_set_constant():
    # set_constant('test', 'Rolando123')
    # print(globals())
    # should print value if exists
    # print(test)
    # set_constant('test', 'Rolando123', locals())
    # print(locals())
    # print(test)
    # should print value if exists
    # print(test)
    return locals()


# test_set_constant()

# Generated at 2022-06-24 18:30:27.765772
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a basic object with a single str item
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(0)

# Generated at 2022-06-24 18:30:29.314887
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('name', 'value') is None


# Generated at 2022-06-24 18:30:35.853190
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    # Unit:
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)



# Generated at 2022-06-24 18:30:38.372669
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    assert var_0 == 0


# Generated at 2022-06-24 18:30:42.307573
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as err:
        print("AssertionError raised, Exception test_case_0()")

# Generated at 2022-06-24 18:30:42.983032
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    test_case_0()

# Generated at 2022-06-24 18:30:43.865500
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert test_case_0() == 0

# Generated at 2022-06-24 18:31:04.109225
# Unit test for function set_constant
def test_set_constant():
    ### START OF YOUR TEST CODE ###
    var_0 = set_constant(str_0, str_1, str_2)
    ### END OF YOUR TEST CODE ###
    return var_0



# Generated at 2022-06-24 18:31:05.067060
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    pass


# Generated at 2022-06-24 18:31:08.038626
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    assert isinstance(deprecated_sequence_constant_0, _DeprecatedSequenceConstant)


# Generated at 2022-06-24 18:31:09.521622
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:31:12.218195
# Unit test for function set_constant
def test_set_constant():
    str_0 = []
    set_constant(str_0, str_0)


# Generated at 2022-06-24 18:31:15.906480
# Unit test for function set_constant
def test_set_constant():
    var_1 = set_constant(__version__, __version__)
    assert var_1 is None

test_set_constant()
test_case_0()

# Generated at 2022-06-24 18:31:19.910321
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = []
    str_1 = []
    str_2 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_1, str_2)
    assert deprecated_sequence_constant_0._value is str_0
    assert deprecated_sequence_constant_0._msg is str_1
    assert deprecated_sequence_constant_0._version is str_2

# Generated at 2022-06-24 18:31:23.791187
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)

# Generated at 2022-06-24 18:31:27.322078
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    assert deprecated_sequence_constant_0.__len__() == 0


# Generated at 2022-06-24 18:31:28.640672
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    string_0 = "str"
    test_case_0()


# Generated at 2022-06-24 18:32:03.868429
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__([])


# Generated at 2022-06-24 18:32:06.185586
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    var_1 = len(str_0)
    assert var_0 == var_1


# Generated at 2022-06-24 18:32:07.468076
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:32:08.424400
# Unit test for function set_constant
def test_set_constant():
    assert len(set_constant._ansible_constants) >= 2

# Generated at 2022-06-24 18:32:12.299969
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    result_0 = deprecated_sequence_constant_0.__getitem__(str_0)
    return result_0


# Generated at 2022-06-24 18:32:16.374333
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    str_1 = []
    deprecated_sequence_constant_1 = deprecated_sequence_constant_0.__getitem__(str_1)


# Generated at 2022-06-24 18:32:20.346395
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = []
    str_1 = []
    str_2 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_1, str_2)
    var_0 = len(deprecated_sequence_constant_0)
    return var_0


# Generated at 2022-06-24 18:32:21.854649
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:32:27.908069
# Unit test for function set_constant
def test_set_constant():
    set_constant('var_0', str_0)
    assert var_0 == str_0
    set_constant('var_1', str_1)
    assert var_1 == str_1
    set_constant('var_2', str_0)
    assert var_2 == str_0
    set_constant('var_3', str_1)
    assert var_3 == str_1
    set_constant('var_4', str_0)
    assert var_4 == str_0
    set_constant('var_5', str_1)
    assert var_5 == str_1
    set_constant('var_6', str_0)
    assert var_6 == str_0
    set_constant('var_7', str_1)
    assert var_7 == str_1

# Generated at 2022-06-24 18:32:30.260231
# Unit test for function set_constant
def test_set_constant():
    print('Testing function set_constant')
    print('Case 0')
    test_case_0()

# Function to test constant COLOR_CODES

# Generated at 2022-06-24 18:33:40.824390
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__('y')

# Generated at 2022-06-24 18:33:44.179908
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    assert var_0 == len(str_0)



# Generated at 2022-06-24 18:33:51.097329
# Unit test for function set_constant
def test_set_constant():
    for setting in config.data.get_settings():
        name = setting.name
        value = setting.value
        if setting.origin == 'default' and \
           isinstance(setting.value, string_types) and \
           (setting.value.startswith('{{') and setting.value.endswith('}}')):
            try:
                t = Template(setting.value)
                value = t.render(vars())
                try:
                    value = literal_eval(value)
                except ValueError:
                    pass  # not a python data structure
            except Exception:
                pass  # not templatable

            value = ensure_type(value, setting.type)

        var_0 = set_constant(name, value)
        var_0 = set_constant(name, value)
        var_0 = set_

# Generated at 2022-06-24 18:33:56.850774
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    dict_0 = dict()
    dict_0['A'] = 'L'
    dict_0['B'] = '3'
    dict_0['C'] = 'P'
    dict_0['D'] = '1'
    dict_0['E'] = 'Z'
    dict_0['F'] = 'U'
    dict_0['G'] = 'I'
    dict_0['H'] = 'W'
    dict_0['I'] = 'X'
    dict_0['J'] = 'Y'
    dict_0['K'] = 'M'
    dict_0['L'] = 'F'
    dict_0['M'] = 'N'
    dict_0['N'] = 'C'
    dict_0['O'] = 'D'
    dict_0

# Generated at 2022-06-24 18:34:06.601308
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    str_1 = []
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(str_1, str_1, str_1)
    var_1 = deprecated_sequence_constant_1.__len__()
    str_2 = []
    deprecated_sequence_constant_2 = _DeprecatedSequenceConstant(str_2, str_2, str_2)
    var_2 = deprecated_sequence_constant_2.__len__()
    str_3 = []

# Generated at 2022-06-24 18:34:09.364446
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()



# Generated at 2022-06-24 18:34:10.092324
# Unit test for function set_constant
def test_set_constant():
    pass



# Generated at 2022-06-24 18:34:12.044396
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    assert deprecated_sequence_constant_0 is not None


# Generated at 2022-06-24 18:34:14.294380
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = []
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(0)
    return var_0


# Generated at 2022-06-24 18:34:16.662556
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = []
    int_0 = 0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, str_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    assert int_0 == var_0