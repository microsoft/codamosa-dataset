

# Generated at 2022-06-24 18:25:25.580228
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    x = _DeprecatedSequenceConstant([ 'apple', 'google', 'amazon', 'oracle' ], 'not a list', '1.0')
    y = x.__len__()
    assert y == 4, "Expected (4), Got ({})".format(y)



# Generated at 2022-06-24 18:25:34.216503
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    param_0 = frozenset({'EASY_INSTALL_PTH'})
    param_1 = 'The environment variable "EASY_INSTALL_PTH" is no longer supported'
    param_2 = '{{ ansible_version }}'
    instance_0 = _DeprecatedSequenceConstant(param_0, param_1, param_2)
    assert len(instance_0) == 1
    assert instance_0[0] == 'EASY_INSTALL_PTH'

# Generated at 2022-06-24 18:25:36.356331
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'check mode not (yet) supported for this module'
    bool_0 = False
    var_0 = set_constant(str_0, bool_0)


# Generated at 2022-06-24 18:25:40.784579
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'check mode not (yet) supported for this module'
    bool_0 = False
    vars_0 = {'check_mode_not_(yet)_supported_for_this_module': False}
    vars_1 = {'check_mode_not_(yet)_supported_for_this_module': bool_0}
    assert vars_0 == vars_1


# Generated at 2022-06-24 18:25:42.056893
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # FIXME: implement test
    return True


# Generated at 2022-06-24 18:25:46.012728
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'check mode not (yet) supported for this module'
    bool_0 = True
    var_0 = set_constant(str_0, bool_0)


# Generated at 2022-06-24 18:25:52.040239
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_1 = 'check_mode'
    str_2 = 'Please use \'any_errors_fatal: true\' instead. This option will be removed in version 2.11.1.'
    str_3 = '2.11.1'
    obj_0 = _DeprecatedSequenceConstant([str_1, str_2, str_3], str_1, str_2)
    assert len(obj_0) == 3


# Generated at 2022-06-24 18:26:04.319566
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    with test_case_0:
        str_0 = 'check mode not (yet) supported for this module'
        bool_0 = False
        var_0 = set_constant(str_0, bool_0)
    with test_case_0:
        str_1 = 'check mode not (yet) supported for this module'
        bool_0 = False
        var_0 = set_constant(str_1, bool_0)
    with test_case_0:
        str_2 = 'check mode not (yet) supported for this module'
        bool_0 = False
        var_0 = set_constant(str_2, bool_0)
    with test_case_0:
        str_3 = 'check mode not (yet) supported for this module'
        bool_0 = False
        var_0 = set

# Generated at 2022-06-24 18:26:14.505188
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'check mode not (yet) supported for this module'
    bool_0 = False
    var_0 = set_constant(str_0, bool_0)
    str_1 = 'check mode not (yet) supported for this module'
    bool_1 = False
    var_1 = set_constant(str_1, bool_1)
    # Testing if the 1st element of var_0 equals bool_0
    assert var_0[0] == bool_0
    # Testing if the 2nd element of var_1 equals bool_1
    assert var_1[1] == bool_1


# Generated at 2022-06-24 18:26:20.043010
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'string'
    version = '1.2'
    value = [1,2,3]
    _DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant(value, msg, version)
    int_0 = 1
    var_1 = _DeprecatedSequenceConstant_0[int_0]


# Generated at 2022-06-24 18:26:25.674132
# Unit test for function set_constant
def test_set_constant():
    assert set_constant("FOO", "BAR") == {'FOO': 'BAR'}


# Generated at 2022-06-24 18:26:29.095222
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    sequence_constant_0 = _DeprecatedSequenceConstant(None, None, None)


# Generated at 2022-06-24 18:26:31.614714
# Unit test for function set_constant
def test_set_constant():

    a = 1
    set_constants('a', 2, export=locals())
    result = a
    assert result == 2


# Generated at 2022-06-24 18:26:33.238552
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = _DeprecatedSequenceConstant(value=['test'], msg='test', version='1.0')
    assert len(value) == 1
    assert value[0] == 'test'


# Generated at 2022-06-24 18:26:34.281324
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert bool(test_case_0())
    return True

# Generated at 2022-06-24 18:26:41.235172
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # xxxxxxxxxx Test openstack network xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    t.cmp('[__len__]', _DeprecatedSequenceConstant(value, msg, version).__len__,
    )

    method_names = []
    warnings = []
    for method in dir(t):
        if not re.search('^test_', method):
            continue
        method_names.append(method)

    for method in method_names:
        getattr(t, method)()


if __name__ == "__main__":
    import sys
    import logging
    import __builtin__

    # Initialize logging, otherwise you'll not see any output.
    logging.basicConfig(level=logging.DEBUG)

    # This is needed to load the environment variables.
    def fn(*args, **kw):
        pass

    __built

# Generated at 2022-06-24 18:26:48.145724
# Unit test for function set_constant
def test_set_constant():
    set_constant("DEBUG", 1)
    assert DEBUG == 1
    set_constant("SHELL_PLUGINS", ["shell_plugin_0", "shell_plugin_1"])
    assert SHELL_PLUGINS == ["shell_plugin_0", "shell_plugin_1"]
    set_constant("HOST_KEY_CHECKING", True)
    assert isinstance(HOST_KEY_CHECKING, bool)
    assert HOST_KEY_CHECKING is True
    set_constant("DEFAULT_RESTART_COMMAND", 'restart')
    assert DEFAULT_RESTART_COMMAND == 'restart'
    set_constant("DEFAULT_USERSHELL", '/bin/sh')
    assert DEFAULT_USERSHELL == '/bin/sh'

# Generated at 2022-06-24 18:26:52.299019
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Create test object
    test = _DeprecatedSequenceConstant([], "message", "1.0")

    # Run method
    # TODO: should we assert something?
    test.__getitem__(0)

# Generated at 2022-06-24 18:27:04.248845
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        if not hasattr(test_case_0, '_test__DeprecatedSequenceConstant'):
            raise AttributeError
        test_case_0._test__DeprecatedSequenceConstant()
    except AssertionError:
        pass
    except AttributeError as e:
        class_name = "_DeprecatedSequenceConstant"
        # this method (test) is called by some other test.
        # raise an exception if the class we're testing is missing
        raise AttributeError(
            "{} not found. Class {} is missing.".format(class_name, e))


# the following constants are not populated by the config file
set_constant('ACTIVE_HOST_LIST', config.get_active_host_list())

# Generated at 2022-06-24 18:27:10.255012
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    test_case_0(test__DeprecatedSequenceConstant___getitem__)
    expected = "[WARNING] Ansible is running in a world writable directory (/Users/myname/Documents/personal/ansible/demo), ignoring it as an ansible.cfg source. For more information see https://docs.ansible.com/ansible/devel/reference_appendices/config.html#cfg-in-world-writable-dir. [WARNING] Unable to parse /Users/myname/Documents/personal/ansible/demo/ansible.cfg as an ini file"
    assert __warning('test__DeprecatedSequenceConstant___getitem__') == expected



# Generated at 2022-06-24 18:27:17.128464
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = len(_DeprecatedSequenceConstant(value, msg, version))
    assert int_0 == 1  # filled-in value


# Generated at 2022-06-24 18:27:18.739008
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    TYPE = 'str'
    assert(type(_DeprecatedSequenceConstant([], 'msg', 'version')[0]) == TYPE )


# Generated at 2022-06-24 18:27:21.232552
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Create an instance of the _DeprecatedSequenceConstant class to test
    deprecated_0 = _DeprecatedSequenceConstant(value=[], msg="", version="")

    ret = deprecated_0.__getitem__(0)


# Generated at 2022-06-24 18:27:28.299025
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_0 = ['a', 'b']
    # setup test
    constant_a = _DeprecatedSequenceConstant(list_0, 'test', '1.0')
    # execute method
    result = constant_a.__len__()
    assert result == 2

if __name__ == "__main__":

    test_case_0()
    test__DeprecatedSequenceConstant___len__()

    print('done')

# Generated at 2022-06-24 18:27:39.313866
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    na = None
    test = _DeprecatedSequenceConstant((), "123", "123")
    # Parameter 1: Value: None
    assert test.__getitem__(None) == None
    # Parameter 1: Value: 0
    assert test.__getitem__(0) == None
    # Parameter 1: Value: 1
    assert test.__getitem__(1) == None
    # Parameter 1: Value: 1
    assert test.__getitem__(1) == None
    # Parameter 1: Value: 1
    assert test.__getitem__(1) == None
    # Parameter 1: Value: False
    assert test.__getitem__(False) == None
    # Parameter 1: Value: True
    assert test.__getitem__(True) == None
    # Parameter 1: Value

# Generated at 2022-06-24 18:27:42.141315
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(test_case_0(), bool)


if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:55.049301
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = "value_0"
    msg = "msg_0"
    version = "version_0"
    obj = _DeprecatedSequenceConstant(value, msg, version)
    assert __len__(obj) == 0

#  value = "value_1"
#  msg = "msg_1"
#  version = "version_1"
#  obj = _DeprecatedSequenceConstant(value, msg, version)
#  assert __len__(obj) == 1

#  value = "value_2"
#  msg = "msg_2"
#  version = "version_2"
#  obj = _DeprecatedSequenceConstant(value, msg, version)
#  assert __len__(obj) == 2

#  value = "value_3"
#  msg = "msg_3

# Generated at 2022-06-24 18:27:58.337184
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dc = _DeprecatedSequenceConstant([], "hello", "v2")
    if dc[0] != None:
        print("Failed to test function __getitem__")
        return 1
    return 0


# Generated at 2022-06-24 18:28:03.977617
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = [1,2,3]
    msg = 'This is deprecated'
    version = '1.0'
    test_case_0.bool_0 = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_case_0.bool_0) == 3

# Generated at 2022-06-24 18:28:06.391827
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant([1, 2, 3], "test_case_0", "0.0.1")


# Generated at 2022-06-24 18:28:14.872238
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    pass


# Generated at 2022-06-24 18:28:17.726693
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Getting a specific member from the class _DeprecatedSequenceConstant
    specific_member = _DeprecatedSequenceConstant.__init__

# Generated at 2022-06-24 18:28:20.303437
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        msg = ''
        version = ''
        value = ''
        _DeprecatedSequenceConstant(value, msg, version)
    except Exception as e:
        print(str(e))
        assert False


# Generated at 2022-06-24 18:28:26.108352
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dep_seq_const_0 = _DeprecatedSequenceConstant([], 'msg', '0.0.0')
    try:
        _DeprecatedSequenceConstant.__getitem__(dep_seq_const_0, 'msg')

    except AttributeError:
        print('AttributeError raised')


# Generated at 2022-06-24 18:28:31.590280
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Exception raised in case of error
    exception_raised = 0
    try:
        # Case test
        # Case test
        test_case_0()
    except Exception:
        exception_raised = 1

    assert not exception_raised, "Exception raised during unit test"



if __name__ == "__main__":
    import os
    import pytest
    pytest.main([os.path.join(os.path.dirname(__file__), "..", "..", "tests")])

# Generated at 2022-06-24 18:28:41.243351
# Unit test for function set_constant
def test_set_constant():
    from ansible.module_utils.common.collections import ImmutableDict
    set_constant('_test_constant_0', 'foo')
    set_constant('_test_constant_1', 'bar')
    set_constant('_test_constant_2', 'hello', export=ImmutableDict())
    assert export['_test_constant_0'] == 'foo'
    assert export['_test_constant_1'] == 'bar'
    assert export['_test_constant_2'] != 'hello'



# Generated at 2022-06-24 18:28:48.239970
# Unit test for function set_constant
def test_set_constant():
    test_constant_0 = 'foo'
    test_constant_1 = 1
    test_constant_2 = False
    # Test with a short list of constants
    set_constant('test_constant_0', test_case_0)
    set_constant('test_constant_1', test_case_1)
    set_constant('test_constant_2', test_case_2)


# Generated at 2022-06-24 18:28:50.462725
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = test_case_0()
    assert a 


# Generated at 2022-06-24 18:28:55.616332
# Unit test for function set_constant
def test_set_constant():
    test_cases = []
    test_case_0()
    set_constant('bool_0', False)
    if bool_0:
        test_cases.append('FAIL')
    else:
        test_cases.append('PASS')

    return test_cases


# Generated at 2022-06-24 18:28:59.921571
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_ = _DeprecatedSequenceConstant('value', 'message', 'version')
    str_0 = str(class_)
    str_1 = str(class_)
    assert class_._msg == 'message'



# Generated at 2022-06-24 18:29:13.868470
# Unit test for function set_constant
def test_set_constant():
    try:
        from unittest import TestCase
    except ImportError:
        TestCase = object

    class Testset_constant(TestCase):
        def test_set_constant_0(self):
            self.assertEqual(set_constant('name', 'value'), {'name': 'value'})

        def test_set_constant_1(self):
            self.assertEqual(set_constant('var_0', 'name'), {'var_0': 'name'})

    unittest.main()


# Generated at 2022-06-24 18:29:16.530708
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    #
    # Constants
    #

    #
    # Variables
    #

    #
    # Setup
    #

    #
    # Exercise
    #

    #
    # Verify
    #

    #
    # Cleanup
    #

    pass



# Generated at 2022-06-24 18:29:19.440790
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    return var_0


# Generated at 2022-06-24 18:29:21.786178
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('test_set_constant', __name__)
    except:
        pass

# Generated at 2022-06-24 18:29:28.287334
# Unit test for function set_constant
def test_set_constant():
    name = "Ansible_version"
    value = __version__
    export = vars()
    result = set_constant(name, value, export)
    assert(export["Ansible_version"] == __version__)


if __name__ == '__main__':
    try:
        import ansible
    except ImportError:
        raise SystemExit('Could not import ansible, please make sure it is installed.')
    for test in (test_case_0, test_set_constant, ):
        test()

# Generated at 2022-06-24 18:29:34.103614
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_1 = False
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(bool_1, bool_1, bool_1)
    assert isinstance(deprecated_sequence_constant_1, _DeprecatedSequenceConstant)


# Generated at 2022-06-24 18:29:38.062676
# Unit test for function set_constant
def test_set_constant():
    name = 'some_name'
    value = 'some_value'
    set_constant(name, value)
    if name not in globals():
        raise RuntimeError('set_constant() didn\'t set constant.')


# Generated at 2022-06-24 18:29:40.217280
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except:
        print(bool_0)
        print(deprecated_sequence_constant_0)
        print(var_0)
        raise


# Generated at 2022-06-24 18:29:46.364266
# Unit test for function set_constant
def test_set_constant():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    set_constant(bool_0, var_0)


# Generated at 2022-06-24 18:29:49.086646
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    test_case_0()

if __name__ == "__main__":
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    unittest.main()

# Generated at 2022-06-24 18:30:15.059576
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    deprecated_sequence_constant_0.__getitem__(bool_0)


# Generated at 2022-06-24 18:30:18.084887
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:30:21.293714
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)


# Generated at 2022-06-24 18:30:24.008401
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except Exception as e:
        print("Test Case is failed: {0}".format(e))
        assert False



# Generated at 2022-06-24 18:30:26.777265
# Unit test for function set_constant
def test_set_constant():
    new_constant = 'new_constant'
    value = 0
    export = {}
    set_constant(new_constant, value, export)
    assert export[new_constant] == value


# Generated at 2022-06-24 18:30:30.089512
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)


# Generated at 2022-06-24 18:30:33.383426
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()



# Generated at 2022-06-24 18:30:37.472241
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Setting up test values
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)

    # Invoking method
    var_0 = deprecated_sequence_constant_0.__len__()

    # Assert
    try:
        assert var_0 == 0
    except:
        raise AssertionError("Expected: <0>, Actual: <%s>" % var_0)



# Generated at 2022-06-24 18:30:39.603431
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    int_0 = drand48()
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)

# Generated at 2022-06-24 18:30:44.450216
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Run var0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    test_case_0()


# Export all Names
__all__ = [name for name in locals().keys() if name[:1] != '_']

# Generated at 2022-06-24 18:31:06.977629
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:31:08.133874
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:31:09.572077
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant


# Generated at 2022-06-24 18:31:12.217199
# Unit test for function set_constant
def test_set_constant():
    set_constant(False, False)
    if False:
        raise Exception('AssertionError')


# Generated at 2022-06-24 18:31:14.354640
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert callable(_DeprecatedSequenceConstant.__len__)


# Generated at 2022-06-24 18:31:18.028841
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_1 = True
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(bool_1, bool_1, bool_1)
    var_1 = deprecated_sequence_constant_1.__len__()


# Generated at 2022-06-24 18:31:24.805338
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(0)
    int_0 = 0
    deprecated_sequence_constant_0.__getitem__(int_0)



# Generated at 2022-06-24 18:31:34.816141
# Unit test for function set_constant

# Generated at 2022-06-24 18:31:39.486980
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    result = _DeprecatedSequenceConstant(VALUE_0, STRING_0, VERSION_0)
    assert result is not None


# Generated at 2022-06-24 18:31:42.586172
# Unit test for function set_constant
def test_set_constant():
    cmd_1 = "FactCacheDir = '/var/fact-cache'\n"
    ret = set_constant('value', cmd_1)
    assert ret == {}


# Generated at 2022-06-24 18:32:36.257111
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()

    assert var_0 is not None


# Generated at 2022-06-24 18:32:39.864133
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__("")


# Generated at 2022-06-24 18:32:43.481874
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # _DeprecatedSequenceConstant()
    #print("_DeprecatedSequenceConstant")
    var_1 = True
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(var_1, var_1, var_1)
    var_2 = deprecated_sequence_constant_1.__getitem__(var_1)


# Generated at 2022-06-24 18:32:44.404879
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert(len(_DeprecatedSequenceConstant(False, False, False)) == 0)

# Generated at 2022-06-24 18:32:46.610697
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)


# Generated at 2022-06-24 18:32:47.253220
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:32:51.461828
# Unit test for function set_constant
def test_set_constant():
    name_0 = 'var_0'
    var_0 = True
    var_1 = set_constant(name_0, var_0)
    assert var_1 == 'var_0'


# Generated at 2022-06-24 18:32:54.340781
# Unit test for function set_constant
def test_set_constant():
    var_0 = "PATH"
    var_1 = "/usr/bin:/usr/sbin:/bin:/sbin"
    var_2 = None
    var_3 = set_constant(var_0, var_1, var_2)
    assert var_3 == None


# Generated at 2022-06-24 18:32:55.816648
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except:
        pass
    else:
        raise Exception("FAIL: cannot construct an instance of _DeprecatedSequenceConstant")



# Generated at 2022-06-24 18:33:00.046197
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    for bool_0 in bool:
        for deprecated_sequence_constant_0 in _DeprecatedSequenceConstant:
            for var_0 in var:
                test_case_0()

# Generated at 2022-06-24 18:34:40.829518
# Unit test for function set_constant

# Generated at 2022-06-24 18:34:42.862337
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)

# Generated at 2022-06-24 18:34:49.349963
# Unit test for function set_constant
def test_set_constant():
    var_0 = None
    value_0 = None
    export_0 = None
    var_1 = None
    var_2 = None
    name_0 = None
    var_3 = None
    value_1 = None
    export_1 = None
    var_4 = None
    value_2 = None
    export_2 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    value_3 = None
    export_3 = None
    var_9 = None
    value_4 = None
    export_4 = None
    name_1 = None
    value_5 = None
    export_5 = None
    name_2 = None
    var_10 = None
    value_6 = None
    export_6 = None
    var_

# Generated at 2022-06-24 18:34:52.058575
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Not implemented yet
    pass


# Generated at 2022-06-24 18:34:54.550454
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert len(deprecated_sequence_constant_0) == 0


# Generated at 2022-06-24 18:35:01.839510
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        return False
    else:
        return True


# MAIN #
if __name__ == '__main__':

    print('\n=== Testing for method __len__ of class _DeprecatedSequenceConstant ===\n')
    print(' Number of test case = 1\n')
    print('=== Run test case 0 ===\n')

    if test__DeprecatedSequenceConstant___len__():
        print('\nSUCCESS: All test cases passed !!!')
    else:
        print('\nFAILURE: At least 1 test case failed !!!')

# Generated at 2022-06-24 18:35:05.110389
# Unit test for function set_constant
def test_set_constant():
    # Ensure that this returns a dictionary
    assert_true(isinstance(set_constant(bool, bool), dict))
    # Ensure that this does not raises any exception
    set_constant(bool, bool, bool)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    #unittest.main()
    test_case_0()

# Generated at 2022-06-24 18:35:07.768347
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert test_case_0() is None

# Generated at 2022-06-24 18:35:12.297525
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)



# Generated at 2022-06-24 18:35:16.991478
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)
    print(var_0)