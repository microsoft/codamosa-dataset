

# Generated at 2022-06-24 18:25:24.843773
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant('value','msg','version')


# Generated at 2022-06-24 18:25:27.545534
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    user_input_0 = []
    user_input_1 = 'msg'
    user_input_2 = '1.2'
    str_0 = _DeprecatedSequenceConstant(user_input_0, user_input_1, user_input_2)


# Generated at 2022-06-24 18:25:29.769344
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    getitem_0 = _DeprecatedSequenceConstant(var_0, str_0, str_0)
    getitem_1 = getitem_0[str_0]
    print(getitem_1)


# Generated at 2022-06-24 18:25:34.459716
# Unit test for function set_constant
def test_set_constant():
    import copy
    import inspect
    import sys

    # run the test
    test_case_0()

    # check that var_0 is defined
    var_0 = getattr(sys.modules[__name__], 'var_0', None)

    assert var_0 is not None
    assert var_0 == 3510



# Generated at 2022-06-24 18:25:35.987672
# Unit test for function set_constant
def test_set_constant():
    '''
    Test for constant setter.
    '''
    test_case_0()

# Generated at 2022-06-24 18:25:45.681076
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = '''This is a test.
    This is the second line of the test'''
    msg = '''This is a test.
    This is the second line of the test'''
    version = '''This is a test.
    This is the second line of the test'''
    obj = _DeprecatedSequenceConstant(value, msg, version)
    assert repr(obj) == "<ansible.constants._DeprecatedSequenceConstant(value='This is a test.\\n    This is the second line of the test', msg='This is a test.\\n    This is the second line of the test', version='This is a test.\\n    This is the second line of the test')>"
    # check instance attributes
    assert obj._value == '''This is a test.
    This is the second line of the test'''


# Generated at 2022-06-24 18:25:48.651472
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_1 = _DeprecatedSequenceConstant()
    var_2 = var_1[0]


# Generated at 2022-06-24 18:25:52.061300
# Unit test for function set_constant
def test_set_constant():
    assert '9' in dir()
    assert 3510 == globals()['9']


# Generated at 2022-06-24 18:25:54.687570
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq_0 = _DeprecatedSequenceConstant(1, '2', '3')


# Generated at 2022-06-24 18:25:57.892292
# Unit test for function set_constant
def test_set_constant():
    # Get the value of var_0 after the call to set_constant
    var_0 = test_case_0()
    assert var_0 == 3510



# Generated at 2022-06-24 18:26:03.389537
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:26:06.162229
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(_ACTION_ALL_PROPER_INCLUDE_IMPORT_TASKS, str_0, str_0)) != min(
        _ACTION_DEBUG, _ACTION_INCLUDE_VARS, _ACTION_IMPORT_PLAYBOOK, _ACTION_SETUP, _ACTION_IMPORT_ROLE, _ACTION_INCLUDE_ROLE)


# Generated at 2022-06-24 18:26:10.738130
# Unit test for function set_constant
def test_set_constant():
    assert to_text(set_constant('TEST_CONSTANT', 'Foo')) == to_text(str_0)

if __name__ == '__main__':
    import sys
    sys.exit(test_case_0())

# Generated at 2022-06-24 18:26:12.524645
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant_sequence = _DeprecatedSequenceConstant(value = [], msg = 'This is a message', version = 'v1.9.0')
    assert len(constant_sequence)


# Generated at 2022-06-24 18:26:14.064440
# Unit test for function set_constant
def test_set_constant():
    str_0 = '\n    Test for constant setter.\n    '
    set_constant('Test message', str_0)
    assert(Test_message == str_0)

# Generated at 2022-06-24 18:26:20.280512
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = '\n    Test for constant setter.\n    '
    str_1 = '\n    Test for constant setter.\n    '
    str_2 = '\n    Test for constant setter.\n    '
    param_0 = _DeprecatedSequenceConstant(str_0, str_1, str_2)


# Generated at 2022-06-24 18:26:24.748931
# Unit test for function set_constant
def test_set_constant():
    str_0 = ''
    try:
        str_0 = 'test_test'
        test_case_0()
    except:
        raise Exception("Unable to set the constant.")
    finally:
        if str_0:
            del str_0


# Generated at 2022-06-24 18:26:25.967142
# Unit test for function set_constant
def test_set_constant():
    output = 'Test for constant setter.'

# Generated at 2022-06-24 18:26:29.416367
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = 'paths'
    msg = 'Using the `paths` option without `file` is deprecated and will be removed in version 2.10.  Specify `file` instead.'
    version = '2.10'
    _DeprecatedSequenceConstant(value, msg, version)



# Generated at 2022-06-24 18:26:35.216737
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    version_expected = 'some version'
    value_expected = 'some value'
    msg_expected = 'some message'
    o = _DeprecatedSequenceConstant(value_expected, msg_expected, version_expected)
    assert o[0] == value_expected



# Generated at 2022-06-24 18:26:40.836884
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert len.__doc__ == None


# Generated at 2022-06-24 18:26:43.679260
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '\n    Test for constant setter.\n    '


# Generated at 2022-06-24 18:26:47.076295
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()
    assert isinstance(len(_DeprecatedSequenceConstant(('\n            Test for constant setter.\n            ', ), '\n            Test for constant setter.\n            ', '\n            Test for constant setter.\n            ')), int)


# Generated at 2022-06-24 18:26:49.371494
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case = _DeprecatedSequenceConstant(list(), str_0, str_0)
    test_case[0] == []


# Generated at 2022-06-24 18:26:55.668355
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant(
        'value', 'msg', 'version'), _DeprecatedSequenceConstant)
    assert _DeprecatedSequenceConstant(
        'value', 'msg', 'version')._value == 'value'
    assert _DeprecatedSequenceConstant(
        'value', 'msg', 'version')._msg == 'msg'


# Generated at 2022-06-24 18:26:56.791764
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    pass


# Generated at 2022-06-24 18:26:59.394998
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """
    Test for constant setter.
    """
    assert_equal(None, None)


# Generated at 2022-06-24 18:27:01.090053
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '\n    Test for constant setter.\n    '


# Generated at 2022-06-24 18:27:02.261726
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:27:04.552622
# Unit test for function set_constant
def test_set_constant():
    global str_0
    str_0 = 'TEST'
    assert str_0 == 'TEST'

test_case_0()
test_set_constant()

# Generated at 2022-06-24 18:27:16.788147
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_1 = b'\xe7\xa4\xe6eB?\r%N'
    set_1 = {bytes_1, bytes_1, bytes_1, bytes_1}
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(set_1, set_1, bytes_1)
    assert not hasattr(deprecated_sequence_constant_1, '__len__'), "Failed to remove __len__ from instance."


# Generated at 2022-06-24 18:27:20.629559
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    deprecation_message = "This feature is being deprecated, please use another one"
    deprecated_version = __version__
    deprecated_sequence_constant = _DeprecatedSequenceConstant(None, deprecation_message, deprecated_version)
    assert deprecated_sequence_constant.__len__() == 0
    assert type(deprecated_sequence_constant) is _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:27:30.304056
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    exception_0 = Exception()
    exception_0.__traceback__ = None
    exception_1 = Exception()
    exception_1.__traceback__ = None
    exception_2 = Exception()
    exception_2.__traceback__ = None
    exception_3 = Exception()
    exception_3.__traceback__ = None
    exception_4 = Exception()
    exception_4.__traceback__ = None
    exception_5 = Exception()
    exception_5.__traceback__ = None
    exception_6 = Exception()
    exception_6.__traceback__ = None
    exception_7 = Exception()
    exception_7.__traceback__ = None
    exception_8 = Exception()
    exception_8.__traceback__ = None
    exception_9 = Exception()
    exception_9.__traceback__ = None

# Generated at 2022-06-24 18:27:35.859719
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xe7\xa4\xe6eB?\r%N'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(set_0, set_0, bytes_0)

    assert hasattr(deprecated_sequence_constant_0, '_value')
    assert hasattr(deprecated_sequence_constant_0, '_msg')
    assert hasattr(deprecated_sequence_constant_0, '_version')



# Generated at 2022-06-24 18:27:40.132696
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xff'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(set_0, set_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(1)


# Generated at 2022-06-24 18:27:43.744023
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_1 = test_case_0()
    assert var_1 is None
    var_2 = test_case_1()
    assert var_2 is None


# Generated at 2022-06-24 18:27:46.531281
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert test_case_0() == 4

# Generated at 2022-06-24 18:27:53.555373
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xe7\xa4\xe6eB?\r%N'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(set_0, set_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    assert var_0 == 4


# Generated at 2022-06-24 18:28:01.665667
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # unit test for DeprecatedSequenceConstant
    set_0 = {'\xe7\xa4\xe6eB?\r%N', '\xe7\xa4\xe6eB?\r%N', '\xe7\xa4\xe6eB?\r%N', '\xe7\xa4\xe6eB?\r%N'}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(set_0, '\xe7\xa4\xe6eB?\r%N', '\xe7\xa4\xe6eB?\r%N')



# Generated at 2022-06-24 18:28:05.891889
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xf3*q\x8a\x93\xa5\x1b'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(set_0, set_0, bytes_0)



# Generated at 2022-06-24 18:28:20.493963
# Unit test for function set_constant
def test_set_constant():

    # Test the case when value is a string.
    set_constant('foo', 'bar')
    if 'foo' in globals() and globals()['foo'] == 'bar':
        print(True)
    else:
        print(False)

    # Test the case when value is a string and export is a dictionary.
    export = globals()
    set_constant('foo', 'bar', export)
    if 'foo' in globals() and globals()['foo'] == 'bar':
        print(True)
    else:
        print(False)

    # Test the case when value is a string and export is a dictionary.
    export = {}
    set_constant('foo', 'bar', export)
    if 'foo' in export and export['foo'] == 'bar':
        print(True)

# Generated at 2022-06-24 18:28:27.094670
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        bytes_0 = b'\xe7\xa4\xe6eB?\r%N'
        set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
        deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(set_0, set_0, bytes_0)
    except Exception as exception_0:
        print(exception_0)

# Generated at 2022-06-24 18:28:28.697718
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test cases
    test_case_0()
    pass



# Generated at 2022-06-24 18:28:30.783199
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # test case for {}
    test_case_0()


# Generated at 2022-06-24 18:28:32.928382
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('test_value', test_set)
        assert 'test_value' in globals()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-24 18:28:47.191853
# Unit test for function set_constant
def test_set_constant():
    bytes_0 = b'\xe7\xa4\xe6eB?\r%N'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(set_0, set_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    var_1 = deprecated_sequence_constant_0.__getitem__(1)
    set_1 = {set_0, var_1, set_0, var_0}
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(set_1, set_0, bytes_0)
    var_2 = deprecated_sequence_constant_1.__len__()

# Generated at 2022-06-24 18:28:49.599762
# Unit test for function set_constant
def test_set_constant():
    ansible_user = 'Michael'

    set_constant(ansible_user, 'Dummy')
    assert vars()[ansible_user] == 'Dummy'


# Generated at 2022-06-24 18:28:56.991105
# Unit test for function set_constant
def test_set_constant():
    bytes_0 = b'\xe7\xa4\xe6eB?\r%N'

# Generated at 2022-06-24 18:29:03.542890
# Unit test for function set_constant

# Generated at 2022-06-24 18:29:06.820696
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    set_0 = {u''}
    try:
        _DeprecatedSequenceConstant(set_0, set_0, None)
    except:
        return False
    return True



# Generated at 2022-06-24 18:29:15.617742
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:29:19.570375
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xe7\xe6B?\r%N'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = to_text(deprecated_sequence_constant_0.__getitem__())
    assert var_0 == bytes_0

# Generated at 2022-06-24 18:29:22.895918
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except NameError:
        print("No test cases defined for _DeprecatedSequenceConstant.__len__")


# Generated at 2022-06-24 18:29:24.586843
# Unit test for function set_constant
def test_set_constant():
    assert set_constant is not None



# Generated at 2022-06-24 18:29:31.871218
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    var_0 = _DeprecatedSequenceConstant(None, None, None)
    assert None == var_0, 'var_0: %s' % var_0
    assert None == var_0.__len__(), 'var_0.__len__(): %s' % var_0.__len__()
    assert None == var_0.__getitem__(None), 'var_0.__getitem__(None): %s' % var_0.__getitem__(None)



# Generated at 2022-06-24 18:29:33.915991
# Unit test for function set_constant
def test_set_constant():
    assert set_constant(0, 0) == vars()



# Generated at 2022-06-24 18:29:38.448736
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xe7\xe6B?\r%N'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(1)


# Generated at 2022-06-24 18:29:40.317166
# Unit test for function set_constant
def test_set_constant():
    name='foo'
    value='bar'
    set_constant(name,value)


if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-24 18:29:48.109044
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\x9d\xdf\x01\x10\x89\xed?\x8d\x9a\x0f\xb9'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bytes_0)

# Generated at 2022-06-24 18:29:52.046002
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    temp_0 = _DeprecatedSequenceConstant(None, None, None)
    try:
        assert len(temp_0) == len(temp_0)
    except Exception:
        print('Test Failed')

# Generated at 2022-06-24 18:30:05.069804
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0) == _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-24 18:30:19.286474
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xc6\xe7\xd3\x05\x9a\xa3p\x1b\x81\xcd\xa4\x01'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    assert str(deprecated_sequence_constant_0) == "['\\xc6\\xe7\\xd3\\x05\\x9a\\xa3p\\x1b\\x81\\xcd\\xa4\\x01']", "{0} != {1}".format(str(deprecated_sequence_constant_0), "['\\xc6\\xe7\\xd3\\x05\\x9a\\xa3p\\x1b\\x81\\xcd\\xa4\\x01']")


# Generated at 2022-06-24 18:30:24.786150
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    Bool_0 = BOOLEANS_TRUE
    bytes_0 = b'\xe7\xe6B?\r%N'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    _deprecated(bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:30:25.777681
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'test')

# Generated at 2022-06-24 18:30:29.855968
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    warning_0 = ' [WARNING] something'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(b'\xe7\xe6B?\r%N', warning_0, '3.3.0')
    assert(deprecated_sequence_constant_0._msg == warning_0)


# Generated at 2022-06-24 18:30:32.210394
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except:
        print('TestCase 0 FAILED')
    print('TestCase 0 Finished')

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:30:33.724349
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert callable(_DeprecatedSequenceConstant.__len__)
    test_case_0()


# Generated at 2022-06-24 18:30:36.504488
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xe7\xe6B?\r%N'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    deprecated_sequence_constant_0.__getitem__(1)


# Generated at 2022-06-24 18:30:37.427176
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test case 0
    test_case_0()



# Generated at 2022-06-24 18:30:38.052274
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    assert test_case_0() == 5

# Generated at 2022-06-24 18:31:01.368414
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('name', 'value') == vars()


# Generated at 2022-06-24 18:31:03.479917
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('name', 'value', export=vars()) == None

# Generated at 2022-06-24 18:31:06.983621
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xe7\xe6B?\r%N'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    assert deprecated_sequence_constant_0.__len__() == 6


# Generated at 2022-06-24 18:31:10.300854
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except Exception as err:
        print('Test automatically generated from method _DeprecatedSequenceConstant.__len__')
        raise err


# Generated at 2022-06-24 18:31:20.395578
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xf6\x0f"\x01\x14\xc0'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(3)
    assert var_0 == bytes_0[3]


# Generated at 2022-06-24 18:31:22.373008
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Update variable values
    test_case_0()

    # Assertions
    assert var_0 == 0


# Generated at 2022-06-24 18:31:25.162896
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xe7\xe6B?\r%N'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__len__()



# Generated at 2022-06-24 18:31:26.495515
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:31:27.446789
# Unit test for function set_constant
def test_set_constant():
    assert False


# Generated at 2022-06-24 18:31:29.161517
# Unit test for function set_constant
def test_set_constant():
    set_constant('debug', False)
    assert isinstance(debug, bool) == True


# Generated at 2022-06-24 18:32:22.376033
# Unit test for function set_constant
def test_set_constant():
    # Set constant
    set_constant('test_constant', 1)

# Generated at 2022-06-24 18:32:25.896415
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xe7\xe6B?\r%N'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    # Test 'y' parameter is of type str
    str_0 = str()
    assert isinstance(deprecated_sequence_constant_0.__getitem__(str_0), str)


# Generated at 2022-06-24 18:32:29.646219
# Unit test for function set_constant
def test_set_constant():
    x = dict()
    set_constant('a', 1, export=x)
    assert 'a' in x
    assert x['a'] == 1
    set_constant('b', 2, export=x)
    assert 'b' in x
    assert x['b'] == 2


# Generated at 2022-06-24 18:32:33.841680
# Unit test for function set_constant
def test_set_constant():
    set_constant(name='var_1', value=var_0)
    assert var_1 is var_0



# Generated at 2022-06-24 18:32:37.619767
# Unit test for function set_constant
def test_set_constant():
    # Verify that the function operates correctly on valid input
    assert set_constant(None, None, None) == {'color': False, 'cows': False}


# Generated at 2022-06-24 18:32:45.761336
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == "__main__":
    import sys
    import __main__
    if hasattr(__main__, '__file__') and __file__.endswith('.py'):
        print('[{0}] Executing unit tests...'.format(os.path.basename(__file__)))
        test__DeprecatedSequenceConstant()
        print('[{0}] Unit test executed successfully.'.format(os.path.basename(__file__)))
        sys.exit(0)
    else:
        print('[{0}] Unit tests can only executed from a .py file.'.format(os.path.basename(__file__)))

# Generated at 2022-06-24 18:32:48.144349
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    a = b'\xe7\xe6B?\r%N'
    b = b'\xe7\xe6B?\r%N'
    c = b'\xe7\xe6B?\r%N'
    d = _DeprecatedSequenceConstant(a, b, c)

# Generated at 2022-06-24 18:32:51.305927
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('test_0', 'test_1')
    except:
        print('fail')
    else:
        print('success')


# Generated at 2022-06-24 18:32:51.908518
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test Case 0
    test_case_0()

# Generated at 2022-06-24 18:32:53.416782
# Unit test for function set_constant
def test_set_constant():
    set_constant('var_1', 'str_1', 'dict_1')
    #assert var_1 == 'test str_1'


# Generated at 2022-06-24 18:34:42.213197
# Unit test for function set_constant
def test_set_constant():
    assert set_constant(2, 3, 1) == 1


# Generated at 2022-06-24 18:34:48.706614
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:34:53.911805
# Unit test for function set_constant
def test_set_constant():
    name = 'var_0'
    export = {}
    value = 'value_0'
    ret_val =set_constant(name, value, export)
    assert ret_val == {}
    assert export[name] == value


# Generated at 2022-06-24 18:34:55.270865
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert True

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:34:59.132803
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xe7\xe6B?\r%N'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    dict_0 = dict(deprecated_sequence_constant_0)


# Generated at 2022-06-24 18:35:00.087076
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:35:01.411219
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:35:02.265903
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:35:03.756967
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    while True:
        try:
            test_case_0()
        except Exception as exc:
            print(exc)
            break



# Generated at 2022-06-24 18:35:06.205439
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xcc\x0c,\x8e\xbf\x9f'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    byte_0 = deprecated_sequence_constant_0.__getitem__(0)


# unit tests for constants