

# Generated at 2022-06-24 18:25:25.755213
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    global var_0
    var_0 = _DeprecatedSequenceConstant((1, 2, 3))
    len_0 = var_0.__len__()
    assert len_0 == 3



# Generated at 2022-06-24 18:25:32.164017
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    version_0 = '3.0'
    msg_0 = 'Testing __getitem__'
    value_0 = _DeprecatedSequenceConstant(value_0, msg_0, version_0)
    var_0 = value_0[0]


# Generated at 2022-06-24 18:25:38.446120
# Unit test for function set_constant
def test_set_constant():
    test_case_0()
# initialize with some defaults, so that we can test
# the configuration code below
TREE_DIR = "~/.ansible/test"

# FIXME: remove once play_context mangling is removed
# Mangle the data from config to make it fit the PlayContext
# object, which is the format expected by users.
for varname, alternatives in MAGIC_VARIABLE_MAPPING.items():

    for alt_varname in alternatives:

        value = getattr(config, varname)
        if value is not None and value != '':
            setattr(config, varname, value)
            set_constant(varname, value)

# Generated at 2022-06-24 18:25:42.592683
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Generate error, since version is not specified in the constructor
    _deprecatedSequenceConstant_0 = _DeprecatedSequenceConstant([u'ansible.windows.win_command', u'ansible.windows.win_shell'], 'ansible_connection: str is deprecated, please use ansible_connection: connection', u'2.12')
    # Call method __getitem__ of class _DeprecatedSequenceConstant
    assert _deprecatedSequenceConstant_0[0] == u'ansible.windows.win_command'

# Generated at 2022-06-24 18:25:46.778111
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    CONSTANT_0 = _DeprecatedSequenceConstant(value, "DEPRECATED MESSAGE", "2.10")
    test = CONSTANT_0[10]


# Generated at 2022-06-24 18:25:50.829232
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        # Run
        test_case_0()
    except Exception as exception:
        print('An exception of type {0} occurred'.format(exception))
    else:
        pass
    finally:
        pass

# END TEST CASES

# Generated at 2022-06-24 18:25:53.999236
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    float_0 = 1000.0
    var_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)


# Generated at 2022-06-24 18:25:57.704051
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """Unit test for method __len__ of class _DeprecatedSequenceConstant"""
    var_0 = _DeprecatedSequenceConstant(())
    assert var_0.__len__() == 0


# Generated at 2022-06-24 18:25:59.054363
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(1000.0, float)

# Generated at 2022-06-24 18:26:08.483701
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    float_1 = 1000.1
    var_1 = _DeprecatedSequenceConstant(float_1, 'msg', 'version')
    # call __len__ method of class _DeprecatedSequenceConstant
    __len__result_1 = var_1.__len__()
    var_2 = len(float_1)
    len_result_1 = var_2
    assert __len__result_1 == len_result_1

# local globals

# Generated at 2022-06-24 18:26:20.815983
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = MASTER_SORT_MODULES
    msg = 'ansible.config.constants.MASTER_SORT_MODULES is deprecated, use MODULE_CACHE instead'
    version = '2.13'
    test_obj = _DeprecatedSequenceConstant(value, msg, version)

    try:
        __result = len(test_obj)
    except:
        raise AssertionError("Result of len() call is unexpected")
    assert __result == 1


# Generated at 2022-06-24 18:26:25.309009
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    '''test method __len__'''
    test_case = _DeprecatedSequenceConstant(range(10), 'test', '1.0')
    result = test_case.__len__()

# Generated at 2022-06-24 18:26:29.549211
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    case_0__DeprecatedSequenceConstant = _DeprecatedSequenceConstant([], '', '')
    assert case_0__DeprecatedSequenceConstant[0] == [], 'case_0: test_case_0 failed'

if __name__ == '__main__':
    test_case_0()
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-24 18:26:34.876081
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant(['ansible', 'ansible-plugin'], 'the message', 'the version')
    # second arg is either a string or tuple of strings
    assert obj[0] == 'ansible'
    assert obj[1] == 'ansible-plugin'
    assert obj[-1] == 'ansible-plugin'
    assert obj[-2] == 'ansible'
    assert obj[0:2] == ['ansible', 'ansible-plugin']
    assert obj[:] == ['ansible', 'ansible-plugin']
    assert obj[0:0] == []


# Generated at 2022-06-24 18:26:39.105790
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value_0 = 1
    msg_0 = 'msg_0'
    version_0 = 'version_0'
    _DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant(value_0, msg_0, version_0)
    _DeprecatedSequenceConstant_0.__getitem__()
    _DeprecatedSequenceConstant_0.__len__()


# Generated at 2022-06-24 18:26:42.321933
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    c = _DeprecatedSequenceConstant(value, msg, version)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:26:42.979789
# Unit test for function set_constant
def test_set_constant():
    assert float_0 == 1000.0

# Generated at 2022-06-24 18:26:47.004910
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test msg'
    version = 'test version'

    test_case_0()
    test_obj = _DeprecatedSequenceConstant((1, 2), msg, version)
    assert test_obj._msg == 'test msg'
    assert test_obj._version == 'test version'
    assert test_obj._value == (1, 2)

# Generated at 2022-06-24 18:26:51.208012
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_1 = 1000.0
    string_0 = 'hi'
    constant_0 = _DeprecatedSequenceConstant([float_1], string_0, float_0)
    int_1 = 1
    test_case_0()
    assert float_1 == constant_0[int_1]


# Generated at 2022-06-24 18:26:55.585422
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test = _DeprecatedSequenceConstant('string', 'string', 'string')
    assert test.__getitem__('string') == 'string'


# Generated at 2022-06-24 18:27:04.075265
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'w{/FbyD;'
    float_0 = 658.90895
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    assert deprecated_sequence_constant_0.__len__() == float_0


# Generated at 2022-06-24 18:27:07.014828
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    test_case_0()

# Generated at 2022-06-24 18:27:13.061567
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:27:16.598423
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = '[dR6/vU2&kk@^I'
    float_0 = -220.016
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__
    assert var_0 == str_0


# Generated at 2022-06-24 18:27:17.600397
# Unit test for function set_constant
def test_set_constant():
    test_case_0()

# Generated at 2022-06-24 18:27:24.193716
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = 'g~>C<`7J'
    float_0 = -14.006988
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)
    str_1 = '''SnlD}'6a8Y6'|%'e/2<^'@(5[v\*aN:`p'~M`6W8O6*_U<l~O6)L-0_8pR'=H(|'>?zf>Z'W3'''
    float_1 = -1.406988

# Generated at 2022-06-24 18:27:29.154587
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except TypeError:
        # FIXME: assertRaises replacement
        pass


if __name__ == "__main__":

    # Unit tests
    print('## Running the unit tests of ansible/constants')
    print('## Test for _DeprecatedSequenceConstant')
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:30.427398
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # FIXME
    pass


# Generated at 2022-06-24 18:27:35.406603
# Unit test for function set_constant
def test_set_constant():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)
    float_1 = float_0
    int_0 = int(float_1)
    assert_equal(var_0, int_0)


# Generated at 2022-06-24 18:27:37.469980
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:27:44.933873
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    pass


# Generated at 2022-06-24 18:27:48.359936
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:49.216286
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:27:54.403778
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)


if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:58.494017
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)
    assert(var_0 == float_0)



# Generated at 2022-06-24 18:28:00.007803
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:28:05.348030
# Unit test for function set_constant
def test_set_constant():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    set_constant(str_0, deprecated_sequence_constant_0)


# Generated at 2022-06-24 18:28:10.871798
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        _DeprecatedSequenceConstant().__len__()
        raise Exception('Failed to raise type error')
    except TypeError:
        pass

if __name__ == '__main__':
    test_case_0()
    test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-24 18:28:16.841065
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)

# Generated at 2022-06-24 18:28:19.472703
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)
    assert type(var_0) == str


# Generated at 2022-06-24 18:28:32.174056
# Unit test for function set_constant
def test_set_constant():
    dict_0 = {}
    set_constant('test', 'set_constant', dict_0)
    assert dict_0['test'] == 'set_constant'


# Generated at 2022-06-24 18:28:39.054123
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'In_[hN.~'
    float_0 = 928.3965
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:28:48.506676
# Unit test for function set_constant
def test_set_constant():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)

    set_constant(str_0, deprecated_sequence_constant_0)

    var_1 = deprecated_sequence_constant_0.__getitem__(str_0)

    # Test that sequence is same after set_constant
    assert var_0 == var_1

# Generated at 2022-06-24 18:28:50.325296
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:28:53.197541
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    set_constant(test_case_0)

test_case = [test_case_0]


# Generated at 2022-06-24 18:28:57.918927
# Unit test for function set_constant
def test_set_constant():
    import unittest
    str_0 = '^!V-q+r:WQ|8U'
    float_0 = -72.187

# Generated at 2022-06-24 18:29:01.744625
# Unit test for function set_constant
def test_set_constant():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    set_constant(float_0, deprecated_sequence_constant_0)


# Generated at 2022-06-24 18:29:05.907276
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = '[1'
    float_0 = -1360.4901246
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)

# Generated at 2022-06-24 18:29:08.220702
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        test_case_0()
    except Exception as e:
        assert False, "Uncaught exception: " + repr(e)


# Generated at 2022-06-24 18:29:11.988426
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:29:25.973199
# Unit test for function set_constant
def test_set_constant():
    assert set_constant(str_0, str_0, dict_0) == dict_0

# Generated at 2022-06-24 18:29:37.303384
# Unit test for function set_constant
def test_set_constant():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)
    int_0 = -50
    set_constant(str_0, int_0)
    var_1 = globals()['(W&jI+t}q$]#qT']
    assert var_1 == -50


# Generated at 2022-06-24 18:29:38.169123
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:29:40.542988
# Unit test for function set_constant
def test_set_constant():
    try:
        result = set_constant('string_0', 'yTulT{o-PX/sPZ')
    except Exception as error:
        print(error)
        result = False

    assert result



# Generated at 2022-06-24 18:29:41.693594
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:29:54.436024
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)

if __name__ == "__main__":
    import __main__
    import sys
    import trace
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(__main__.__file__)))
    __main__.__dict__.clear()
    __main__.__dict__.update(globals())
    tracer = trace.Trace(count=False, trace=True)
    tracer.run("test_case_0()")

# Generated at 2022-06-24 18:30:00.573597
# Unit test for function set_constant
def test_set_constant():
    set_constant('str_0', 'bsW$z{(^7Q}%')
    set_constant('float_0', -251.288366)
    set_constant('deprecated_sequence_constant_0', _DeprecatedSequenceConstant('bsW$z{(^7Q}%', -251.288366, 'bsW$z{(^7Q}%'), export=None)
    set_constant('var_0', deprecated_sequence_constant_0.__getitem__('bsW$z{(^7Q}%'), export=None)
    assert str_0 == '(W&jI+t}q$]#qT'
    assert float_0 == -282.75343

# Generated at 2022-06-24 18:30:03.562877
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    test_case_0()

# Test class: TestDeprecatedSequenceConstant

# Generated at 2022-06-24 18:30:06.277914
# Unit test for function set_constant
def test_set_constant():
    constant_name = _ACTION_DEBUG
    constant_value = _ACTION_SETUP
    constant_export = vars()
    set_constant(constant_name, constant_value, constant_export)
    assert (magic_variable_mapping == constant_export)


# Generated at 2022-06-24 18:30:07.750687
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:30:38.213364
# Unit test for function set_constant
def test_set_constant():

    set_constant('var_0', str_0, export=globals())
    assert var_0 == str_0

    set_constant('var_1', float_0, export=globals())
    assert var_1 == float_0

    set_constant('var_2', str_0, export=globals())
    assert var_2 == str_0

    set_constant('var_3', str_0, export=globals())
    assert var_3 == str_0

# Generated at 2022-06-24 18:30:43.667070
# Unit test for function set_constant
def test_set_constant():

    assert(set_constant('str_1', 1))
    assert(set_constant('str_2', 1))
    assert(set_constant('str_3', 1))
    assert(set_constant('str_4', 1))


# Generated at 2022-06-24 18:30:52.983292
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = ' 0&n'
    dict_0 = dict()
    dict_0['str_0'] = str_0

    for elem in dict_0:
        str_1 = elem
        bool_0 = str_1 == str_0

    float_0 = 0.3674
    float_1 = 0.1498
    dict_0['float_0'] = float_0
    dict_0['float_1'] = float_1

    for elem in dict_0:
        str_2 = elem
        bool_1 = str_2 == str_0
        bool_2 = str_2 != '!_!#'
        bool_3 = str_2 != 'QY'
        bool_4 = str_2 != '$'

    deprecated_sequence_constant_0 = _Deprecated

# Generated at 2022-06-24 18:31:02.011419
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '(W&jI+t}q$]#qT'
    str_1 = '=d@<t[>Xt&O`&'
    int_0 = -30
    str_2 = '#l%}J!^hvJeXg='
    long_0 = -7354559753750398032
    str_3 = 'E`.T!_aU6!p$P"'
    dict_0 = {'int_0': int_0, 'str_1': str_1, 'long_0': long_0, 'float_0': float_0, 'str_0': str_0}
    str_4 = '<c%x0Bq=/pK#'
    str_5 = '9"&vRKW:}d_!f'


# Generated at 2022-06-24 18:31:07.375815
# Unit test for function set_constant
def test_set_constant():
    str_0 = '3q4hD#j;'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)
    export_0 = None
    function_return_value_0 = set_constant(str_0, float_0, export_0)
    assert function_return_value_0 is None


# Generated at 2022-06-24 18:31:17.412406
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Calls the __init__ method of the class _DeprecatedSequenceConstant
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    assert deprecated_sequence_constant_0._msg == str_0
    assert not(deprecated_sequence_constant_0._value == str_0)
    assert deprecated_sequence_constant_0._version == float_0

# Generated at 2022-06-24 18:31:18.727821
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        test_case_0()
    except Exception as err:
        print(err)
    else:
        print('no exception')

# Generated at 2022-06-24 18:31:24.776043
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'nQ~'
    float_0 = -44.342528
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    # Method-0 is __init__
    # Method-1 is __len__
    var_0 = deprecated_sequence_constant_0.__len__()

# Generated at 2022-06-24 18:31:30.067245
# Unit test for function set_constant
def test_set_constant():
    str_0 = '?gVLfX<FxcK>'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['name'] = str_0
    dict_0['value'] = (dict_1)
    dict_0['export'] = dict_1
    return_value = set_constant(**dict_0)
    print(return_value)


# Generated at 2022-06-24 18:31:31.176928
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:31:59.784638
# Unit test for function set_constant
def test_set_constant():
    str_0 = '-QJ]}0(U*M`)a<'
    set_constant(str_0, str_0)


assert config.BECOME_PASS == DEFAULT_BECOME_PASS
assert config.REMOTE_PASS == DEFAULT_REMOTE_PASS

# Generated at 2022-06-24 18:32:00.732243
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:32:03.608105
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'ansible'
    str_1 = 'ansible'
    dict_0 = {}
    float_0 = -143.35108
    set_constant(str_0, float_0, dict_0)
    assert dict_0[str_1] == float_0

# Generated at 2022-06-24 18:32:09.522358
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    str_1 = '{c`XM'
    float_1 = -10.16
    var_0 = deprecated_sequence_constant_0.__getitem__(str_1)
    assert_equals(var_0, None)
    var_1 = deprecated_sequence_constant_0.__getitem__(float_1)
    assert_equals(var_1, None)
    var_2 = deprecated_sequence_constant_0.__getitem__(str_0)
    assert_equals(var_2, None)

# Unit

# Generated at 2022-06-24 18:32:10.787940
# Unit test for function set_constant
def test_set_constant():
    assert callable(set_constant)


# Generated at 2022-06-24 18:32:15.571288
# Unit test for function set_constant
def test_set_constant():
    local_var = None
    try:
        set_constant('local_var', 'test_str', locals())
    except TypeError:
        assert False, 'set_constant raised TypeError'
        return

    assert locals().get('local_var') == 'test_str'

if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-24 18:32:17.348623
# Unit test for function set_constant
def test_set_constant():
    with pytest.raises(TypeError):
        assert set_constant()


# Testcase 1

# Generated at 2022-06-24 18:32:24.564822
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Set up test values
    input_0 = ''
    expected_value = ''
    # Perform the test
    test_value = _DeprecatedSequenceConstant(input_0, input_0, input_0).__getitem__(input_0)
    # Verify the results
    assert(test_value == expected_value)


# Generated at 2022-06-24 18:32:27.280671
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    ansible_deprecated_sequence_constant_0 = _DeprecatedSequenceConstant('(W&jI+t}q$]#qT', float(-282.75343), '')


# Generated at 2022-06-24 18:32:30.365911
# Unit test for function set_constant
def test_set_constant():
    dict_0 = dict()
    str_0 = 'v'
    str_1 = 'P>('
    set_constant(str_0, str_1, dict_0)
    assert dict_0[str_0] == str_1

# Generated at 2022-06-24 18:33:25.008679
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_0 = getattr(__DeprecatedSequenceConstant,__len__)
    try:
        var_0.__assert_fail__()
    except AssertionError:
        var_0.__assert_fail__()


# Generated at 2022-06-24 18:33:26.395037
# Unit test for function set_constant
def test_set_constant():
    set_constant('hello', 'world')
    assert hello == 'world'


# Generated at 2022-06-24 18:33:31.061920
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(str_0)


# Generated at 2022-06-24 18:33:34.398383
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as e:
        print("[FAIL] Exception caught: ", str(e))
        raise


if __name__ == "__main__":
    test__DeprecatedSequenceConstant()
    print("All test cases completed")

# Generated at 2022-06-24 18:33:38.007390
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    int_0 = deprecated_sequence_constant_0.__len__()



# Generated at 2022-06-24 18:33:42.344541
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = '(W&jI+t}q$]#qT'
    float_0 = -282.75343
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, float_0, str_0)
    deprecated_sequence_constant_0.__len__()
    deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:33:43.964349
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # FIXME: add unit tests to test method __len__ of class _DeprecatedSequenceConstant
    pass

# Generated at 2022-06-24 18:33:44.764232
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
  assert test_case_0() == None

# Generated at 2022-06-24 18:33:47.047632
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    print('Testing _DeprecatedSequenceConstant')
    test_case_0()
    print('Test passed')

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:33:52.646065
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        _DeprecatedSequenceConstant(str_0, float_0, str_0)
        assert True
    except AssertionError:
        assert False