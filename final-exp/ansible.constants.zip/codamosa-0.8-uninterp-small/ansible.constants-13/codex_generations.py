

# Generated at 2022-06-24 18:25:29.517269
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant_0 = object()
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(deprecated_sequence_constant_0, "0", "2.4")
    deprecated_sequence_constant_1 = object()
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(deprecated_sequence_constant_1, "1", "2.4")
    deprecated_sequence_constant_2 = object()
    deprecated_sequence_constant_2 = _DeprecatedSequenceConstant(deprecated_sequence_constant_2, "2", "2.4")
    var_0 = set_constant("deprecated_sequence_constant_0", deprecated_sequence_constant_0)

# Generated at 2022-06-24 18:25:32.246372
# Unit test for function set_constant
def test_set_constant():
    int_0 = 3581
    bool_0 = True
    set_constant(int_0, bool_0)

    assert bool_0 == var_0


# Generated at 2022-06-24 18:25:33.723519
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 3581
    var_0 = _DeprecatedSequenceConstant((), int_0, int_0)
    result = var_0.__len__()


# Generated at 2022-06-24 18:25:38.228520
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 3581
    bool_0 = True
    str_0 = "I can't believe it's not butter."
    list_0 = [int_0, bool_0, str_0]
    var_1 = _DeprecatedSequenceConstant(list_0, str_0, int_0)
    var_0 = var_1[int_0]
    print(var_0)


# Generated at 2022-06-24 18:25:40.994652
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 4757
    bool_0 = True
    var_0 = _DeprecatedSequenceConstant(int_0, bool_0)
    int_1 = 8373
    var_0 = var_0[int_1]


# Generated at 2022-06-24 18:25:42.267086
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(int_0, bool_0, var_0)[int_0] == bool_0



# Generated at 2022-06-24 18:25:46.879493
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 3581
    bool_0 = True
    var_0 = _DeprecatedSequenceConstant(int_0, bool_0, bool_0)
    var_0.__len__()


# Generated at 2022-06-24 18:25:48.761404
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:25:51.592442
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant, object)


# Generated at 2022-06-24 18:25:55.438811
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    par_1 = None
    var_0 = _DeprecatedSequenceConstant(par_1, False, False)
    par_1 = None
    var_0.__getitem__(par_1)

# Generated at 2022-06-24 18:26:00.116359
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:26:05.979751
# Unit test for function set_constant
def test_set_constant():

    # Create a temporary shell namespace
    import os
    import copy
    import sys
    temp_shell_namespace = copy.copy(vars(os))

    # Call function set_constant
    set_constant(sys.version_info.major, sys.version_info.minor)

    # Check if the function set the variables into the shell namespace
    assert(sys.version_info.major in temp_shell_namespace and
           sys.version_info.minor in temp_shell_namespace)



# Generated at 2022-06-24 18:26:06.698153
# Unit test for function set_constant
def test_set_constant():
    pass # Nothing to test

# Generated at 2022-06-24 18:26:08.233438
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Generated at 2022-06-24 18:26:09.798266
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        test_case_0()
    except Exception as e:
        print('Caught exception: ' + e.__str__())
        assert(False)


# Generated at 2022-06-24 18:26:11.036436
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Generated at 2022-06-24 18:26:13.744493
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    #
    # This test doesn't necessarily check the functionality in _DeprecatedSequenceConstant, although it will catch
    # problems with correctness.
    # This test only checks the parameter correctness in the constructor of _DeprecatedSequenceConstant.
    #
    tester_0 = _DeprecatedSequenceConstant(0,0,0)


# Generated at 2022-06-24 18:26:17.241540
# Unit test for function set_constant
def test_set_constant():
    global CONNECTION_PLUGINS
    set_constant('CONNECTION_PLUGINS', deprecated_sequence_constant_0)
    assert CONNECTION_PLUGINS is deprecated_sequence_constant_0

# Generated at 2022-06-24 18:26:28.756612
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # test with class attributes
    print('Testing constructor of class _DeprecatedSequenceConstant')
    print('')

    # test with class variables
    print('Testing constructor of class _DeprecatedSequenceConstant')
    print('')
    print('For class variable: int_0')
    print('Expected value: 3581')
    print('Actual value: ', int_0)
    print('For class variable: None')
    print('Expected value: None')
    print('Actual value: ', None)
    # test constructor of class _DeprecatedSequenceConstant
    print('Testing constructor with arguments int_0, None, None')
    print('')
    print('test_case_0()')
    test_case_0()
    # test constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:26:31.341874
# Unit test for function set_constant
def test_set_constant():
    set_constant(int_0, deprecated_sequence_constant_0, dict())


test_case_0()
test_set_constant()

# Generated at 2022-06-24 18:26:36.585875
# Unit test for function set_constant
def test_set_constant():
    assert set_constant("test_constant_0", test_case_0)

# Generated at 2022-06-24 18:26:38.954587
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    # Test with deprecation warning
    test_case_0()


# Generated at 2022-06-24 18:26:44.068867
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    assert True # done testing of constructor for class _DeprecatedSequenceConstant


# Generated at 2022-06-24 18:26:46.820716
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT_0', 'TEST_CONSTANT_0')
    if 'TEST_CONSTANT_0' in vars():
        del vars()['TEST_CONSTANT_0']

# Generated at 2022-06-24 18:26:51.883635
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as e:
        print('---->Failed to call test_case_0()')
        print(e)
        return False
    return True


if __name__ == '__main__':
    if test__DeprecatedSequenceConstant():
        print('-----Passed all test cases-----')
    else:
        print('-----Failed at least one test case-----')

# Generated at 2022-06-24 18:26:53.345180
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:26:58.272194
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    int_1 = deprecated_sequence_constant_0.__len__()
    assert int_1 == int_0



# Generated at 2022-06-24 18:27:04.612094
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    assert (deprecated_sequence_constant_0._value == int_0)
    assert(deprecated_sequence_constant_0._msg == int_0)
    assert(deprecated_sequence_constant_0._version == int_0)


# Generated at 2022-06-24 18:27:06.280155
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(35865, 35865, 35865)
    _deprecated_sequence_constant_0.__len__()

# Generated at 2022-06-24 18:27:14.677294
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    assert deprecated_sequence_constant_0[_DeprecatedSequenceConstant(int_0, int_0, int_0)] == deprecated_sequence_constant_0[_DeprecatedSequenceConstant(int_0, int_0, int_0)]


# Generated at 2022-06-24 18:27:20.725846
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # parameters with default value
    try:
        test_case_0()
    except Exception:
        print("Failed")

# Generated at 2022-06-24 18:27:22.560764
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    __msg__.good("TestCase stepped through")


# Generated at 2022-06-24 18:27:27.464716
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


if __name__ == '__main__':
    import os
    import sys
    import pytest

    sys.exit(pytest.main(args=[os.path.abspath(__file__)]))

# Generated at 2022-06-24 18:27:34.216632
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    str_0 = "P"
    int_1 = 1
    deprecated_sequence_constant_0.__getitem__(int_1, str_0)
    print(repr(deprecated_sequence_constant_0))

# Generated at 2022-06-24 18:27:40.258755
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    deprecated_sequence_constant_0._deprecated_sequence_constant_deprecated(deprecated_sequence_constant_1, deprecated_sequence_constant_0)



# Generated at 2022-06-24 18:27:46.397416
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    print("")
    print("Test for _DeprecatedSequenceConstant can not be run as a script.")
    print("Please run ansible-test units --python 3.5 to run the unit test for this class.")
    print("")


# Generated at 2022-06-24 18:27:56.954333
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 3581

    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    if test__DeprecatedSequenceConstant___len__.counter == 0:
        test__DeprecatedSequenceConstant___len__.counter += 1
        assert deprecated_sequence_constant_0.__len__() == 3
    elif test__DeprecatedSequenceConstant___len__.counter == 1:
        test__DeprecatedSequenceConstant___len__.counter += 1
        assert deprecated_sequence_constant_0.__len__() == 2
    elif test__DeprecatedSequenceConstant___len__.counter == 2:
        test__DeprecatedSequenceConstant___len__.counter += 1
        assert deprecated_sequence_constant_0.__len__

# Generated at 2022-06-24 18:28:08.076087
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'c%A'
    str_1 = 'G[67'
    str_2 = '^#l.'
    str_3 = '5yum'
    str_4 = '&F6M'
    int_0 = 3048041402
    int_1 = 20749
    int_2 = -889592927
    int_3 = -981475280

    # Call function set_constant with correct arguments
    set_constant(str_0, int_0)
    set_constant(str_0, int_1, vars())
    set_constant(str_1, int_2, vars())
    set_constant(str_2, int_3, vars())
    set_constant(str_3, int_0, vars())
    set_const

# Generated at 2022-06-24 18:28:09.249052
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:28:11.006920
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    t = _DeprecatedSequenceConstant(358, 8, 8)



# Generated at 2022-06-24 18:28:27.843766
# Unit test for function set_constant
def test_set_constant():
    set_constant('a', 'b', export=vars())
    assert 'a' in vars()
    assert vars()['a'] == 'b'

if __name__ == "__main__":
    # Test the constants
    for testcase in dir():
        if testcase.startswith('test_'):
            print('Running Test Case: ' + testcase)
            locals()[testcase]()

    print('Passed Test Cases: ' + str(len([x for x in dir() if x.startswith('test_')])))

# Generated at 2022-06-24 18:28:29.235041
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:28:30.658886
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:28:33.702539
# Unit test for function set_constant

# Generated at 2022-06-24 18:28:37.960183
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    expr = _DeprecatedSequenceConstant(358, 358, 358)
    res = expr.__getitem__()
    expr.__getitem__(res)


# Generated at 2022-06-24 18:28:39.238301
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()



# Generated at 2022-06-24 18:28:41.684028
# Unit test for function set_constant
def test_set_constant():
    test_case_0()

if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])
    test_set_constant()

# Generated at 2022-06-24 18:28:50.445809
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1
    str_0 = '{'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    str_1 = '1'
    str_2 = '1'
    str_3 = '{'
    str_4 = '{{'
    str_5 = str_1
    str_6 = str_1
    str_7 = str_1
    bool_0 = bool(str_7)
    bool_1 = bool(bool_0)
    bool_2 = bool(bool_0)
    bool_3 = bool(bool_0)
    bool_4 = bool(bool_0)
    bool_5 = bool(bool_0)
    bool_6 = bool(bool_0)

# Generated at 2022-06-24 18:28:56.016580
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)

    try:
        deprecated_sequence_constant_0.__getitem__({})
        assert False
    except Exception:
        pass


# Generated at 2022-06-24 18:28:58.949901
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:29:20.035198
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generate constants from config
for setting in config.data.get_settings():

    value = setting.value
    if setting.origin == 'default' and \
       isinstance(setting.value, string_types) and \
       (setting.value.startswith('{{') and setting.value.endswith('}}')):
        try:
            t = Template(setting.value)
            value = t.render(vars())
            try:
                value = literal_eval(value)
            except ValueError:
                pass  # not a python data structure
        except Exception:
            pass  # not templatable

        value = ensure_type(value, setting.type)

    set_constant(setting.name, value)

# allow us to load stuff from plugins/__init__.py


# Generated at 2022-06-24 18:29:23.606011
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:29:28.509285
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Check that __getitem__ eventually calls _DeprecatedSequenceConstant.__getitem__
    class TestMock(object):
        def __getitem__(self, x):
            if x == ():
                return True
            return False
    test_mock = TestMock()
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(test_mock)
    assert(deprecated_sequence_constant_0[()])


# Generated at 2022-06-24 18:29:35.803062
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert hasattr(test_case_0.__closure__[1].cell_contents, '_value') == True
    assert hasattr(test_case_0.__closure__[1].cell_contents, '_msg') == True
    assert hasattr(test_case_0.__closure__[1].cell_contents, '_version') == True


# Generated at 2022-06-24 18:29:38.468982
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('test_var', 'test_value')
        if test_var != 'test_value':
            raise Exception()
    except Exception:
        raise AssertionError("set_constant not working correctly")



# Generated at 2022-06-24 18:29:39.126138
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    pass


# Generated at 2022-06-24 18:29:41.811102
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    try:
        deprecated_sequence_constant_0.__len__()
    except NameError:
        pass


# Generated at 2022-06-24 18:29:44.497860
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:29:46.364848
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:29:56.092203
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 3581
    msg_0 = int_0
    version_0 = int_0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    deprecated_sequence_constant_2 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    assert deprecated_sequence_constant_0.__init__(int_0, int_0, int_0)
    assert deprecated_sequence_constant_1.__init__(int_0, int_0, int_0)

# Generated at 2022-06-24 18:30:22.856380
# Unit test for function set_constant
def test_set_constant():
    arg_test = 'test'
    int_test = 3581
    result = set_constant(arg_test, int_test)
    assert result == {'test': 3581}

# Generated at 2022-06-24 18:30:29.573710
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    try:
        assert deprecated_sequence_constant_0.__len__() == int_0
    except AssertionError as e:
        print("Assertion failed at test__DeprecatedSequenceConstant___len__")
        print("{0} != {1}".format(deprecated_sequence_constant_0.__len__(), int_0))
        print(e)


# Generated at 2022-06-24 18:30:35.578403
# Unit test for function set_constant
def test_set_constant():
    ansible_version = (__version__)
    debug = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(ansible_version, ansible_version, ansible_version)
    set_constant('ansible_version', ansible_version, export=vars())
    assert type(ansible_version) == type(deprecated_sequence_constant_0)
    set_constant('debug', debug, export=vars())
    assert type(debug) == type(deprecated_sequence_constant_0)

if __name__ == '__main__':
    test_case_0()
    test_set_constant()

# Generated at 2022-06-24 18:30:38.875672
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        int_0 = 3581
        deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
        deprecated_sequence_constant_0.__len__()
    except Exception as e:
        print(e)
    else:
        raise RuntimeError("Expected Exception")



# Generated at 2022-06-24 18:30:41.213322
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    deprecated_sequence_constant_0 = deprecated_sequence_constant_0.__len__()



# Generated at 2022-06-24 18:30:44.699438
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:30:45.359311
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:30:48.495386
# Unit test for function set_constant
def test_set_constant():
    # False assertion
    assert not set_constant("A", "B") == ["A", "B"]
    # False assertion
    assert not set_constant("A", "B") == ["B", "A"]
    # False assertion
    assert not set_constant("A", "B") == "A"
    # False assertion
    assert not set_constant("A", "B") == "AB"

# Generated at 2022-06-24 18:30:52.313811
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.utils.constants import _DeprecatedSequenceConstant
    v = _DeprecatedSequenceConstant(358, 358, 358)
    if v[0]:
        raise Exception("Test case v[0] failed.")


# Generated at 2022-06-24 18:30:56.811720
# Unit test for function set_constant
def test_set_constant():
    int_0 = 3581
    set_constant(int_0, int_0)
    set_constant(int_0, int_0, int_0)
    assert True  # BOOM!


# Generated at 2022-06-24 18:31:45.278547
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:31:49.203350
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Setup
    test_case_0()
    # Perform action
    deprecated_sequence_constant_0.__getitem__("")

# Generated at 2022-06-24 18:31:52.947859
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
        print("Successful test of constructor for _DeprecatedSequenceConstant")
    except AssertionError:
        print("Failed test of constructor for _DeprecatedSequenceConstant")

# Generated at 2022-06-24 18:31:55.886663
# Unit test for function set_constant
def test_set_constant():
    test_set_constant_0 = (_DeprecatedSequenceConstant(0, 0, 0))



# Generated at 2022-06-24 18:31:56.932853
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    print(test_case_0())

test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:31:58.461882
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except TypeError:
        print("TEST CASE 0 FAILED.")



# Generated at 2022-06-24 18:32:00.890015
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 8677
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)


# Generated at 2022-06-24 18:32:01.632603
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:32:02.569891
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 3581
    test_case_0()



# Generated at 2022-06-24 18:32:08.824860
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test inputs
    # test case 0
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)

    # Output
    assert deprecated_sequence_constant_0._value == int_0 and \
           deprecated_sequence_constant_0._msg == int_0 and \
           deprecated_sequence_constant_0._version == int_0



# class TestDeprecatedSequenceConstant(unittest.TestCase):
#     def test__init__(self):
#         # Input parameters
#         int_0 = 3581
#         # Output
#         deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
#         # Visual output
#         self

# Generated at 2022-06-24 18:33:57.795010
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()



# Generated at 2022-06-24 18:34:02.102284
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as e:
        print(str(e))
# List of all default constants
DEFAULTS = [x for x in list(globals().keys()) if not x.startswith('_') and x.isupper()]

# Remove deprecated constants from the list so they don't get used
for def_const in DEFAULTS:
    if config.data[def_const].deprecated:
        DEFAULTS.remove(def_const)

# Generated at 2022-06-24 18:34:05.686448
# Unit test for function set_constant
def test_set_constant():
    try:
        assert constant_0 == 123
        # Ensure the assert fails when the value is different.
        assert constant_0 == 12
    # Catch the exception in case the assert fails.
    except AssertionError:
        pass
    else:
        # In case the exception is not raised this method is called.
        raise Exception('AssertionError not raised')

# Generated at 2022-06-24 18:34:10.386199
# Unit test for function set_constant
def test_set_constant():
    set_constant(__file__, __version__)
    assert __file__ != PC_DEFAULT_PLAINTEXT_VAULT_ID_MATCH
    set_constant(__file__, PC_DEFAULT_PLAINTEXT_VAULT_ID_MATCH)
    assert __file__ == PC_DEFAULT_PLAINTEXT_VAULT_ID_MATCH

if __name__ == '__main__':
    test_case_0()
    test_set_constant()

# Generated at 2022-06-24 18:34:12.778204
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    dep_seq_const_0 = _DeprecatedSequenceConstant(35812, "35812", "35812")
    try:
        dep_seq_const_0.__len__()
        assert "AssertionError" not in locals()
    except AssertionError:
        pass

# Generated at 2022-06-24 18:34:14.548134
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except TypeError as err:
        assert 'object of type' in str(err)
    else:
        raise AssertionError("Expected TypeError")

# Generated at 2022-06-24 18:34:17.099137
# Unit test for function set_constant
def test_set_constant():
    set_constant('name', 'value', export=vars())


# Generated at 2022-06-24 18:34:24.415273
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 3581
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    try:
        deprecated_sequence_constant_0.__len__()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 18:34:30.544105
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test method __len__ of class _DeprecatedSequenceConstant
    # Create test data
    int_0 = 3581
    int_1 = 1723
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    # Test operation
    result = deprecated_sequence_constant_0.__len__()
    # Verify
    assert result == int_1


# Generated at 2022-06-24 18:34:34.071331
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    for _ in range(10):
        int_0 = 3581
        deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
        int_1 = test_case_0()
        assert int_1 is not None
    return
