

# Generated at 2022-06-24 18:25:27.884474
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Generated at 2022-06-24 18:25:29.140874
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    print('In test__DeprecatedSequenceConstant___getitem__')
    test_case_0()

# Generated at 2022-06-24 18:25:33.770717
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -4451.8032
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, bool_0, float_0)
    float_1 = -4451.8032
    deprecated_sequence_constant_0.__getitem__(float_1)



# Generated at 2022-06-24 18:25:38.030088
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -4451.8032
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, bool_0, float_0)
    int_0 = 0
    output_0 = deprecated_sequence_constant_0[int_0]
    assert output_0 == -4451.8032

# Generated at 2022-06-24 18:25:41.484739
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Input parameters
    float_0 = 3099.75
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, bool_0, float_0)

    # Exercise
    len_0 = deprecated_sequence_constant_0.__len__()

    # Verify
    assert len_0 == float_0


# Generated at 2022-06-24 18:25:46.777730
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    float_0 = -2640.73034
    bool_1 = True
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(float_0, bool_1, float_0)
    int_0 = deprecated_sequence_constant_1[0]


# Generated at 2022-06-24 18:25:49.442374
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Test if value of [variable] is equal to the expected value

# Generated at 2022-06-24 18:25:52.919473
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    # test__DeprecatedSequenceConstant()    
    print(test__DeprecatedSequenceConstant())

# Generated at 2022-06-24 18:25:59.054584
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    float_0 = -4451.8032
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(float_0, bool_0, float_0)
    len_0 = deprecated_sequence_constant_0.__len__()
    assert len_0 == len(float_0)


# Generated at 2022-06-24 18:26:01.813558
# Unit test for function set_constant
def test_set_constant():
    set_constant("bool_1", True, globals())


test_case_0()
test_set_constant()

# Generated at 2022-06-24 18:26:15.364269
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    list_0 = []
    str_0 = 'In test__DeprecatedSequenceConstant'
    var_1 = _DeprecatedSequenceConstant(list_0, str_0, '2.11')
    var_2 = var_1[0]
    var_3 = print(var_2)
    list_1 = []
    str_1 = 'In test__DeprecatedSequenceConstant'
    var_4 = _DeprecatedSequenceConstant(list_1, str_1, '2.11')
    var_5 = len(var_4)
    var_6 = print(var_5)

# Generated at 2022-06-24 18:26:16.546862
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:26:21.153426
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    try:
        var_1 = test_case_0()
    except Exception as exception:
        print(exception)
    else:
        print('Testcase passed')
    finally:
        if var_1 is not None:
            var_1.close()

# Generated at 2022-06-24 18:26:22.211452
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test_case_0
    test_case_0()


# Generated at 2022-06-24 18:26:24.944432
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'TestModule')
    if test == 'TestModule':
        print('TestName')

# Generated at 2022-06-24 18:26:25.599459
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Generated at 2022-06-24 18:26:34.921644
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq_0 = ('attr_name', 'key', 'value')
    var_0 = _DeprecatedSequenceConstant(seq_0, 'In test_case_0', 'in 2.12')
    var_1 = test_case_0()

if __name__ == '__main__':
    import sys
    import traceback

    # Unit test for _warning
    def test__warning():
        var_0 = _warning('In test_case_0')
    test__warning()

    # Unit test for _deprecated
    def test__deprecated():
        var_0 = _deprecated('In test_case_0', 1.0)
    test__deprecated()

    # Unit test for set_constant

# Generated at 2022-06-24 18:26:40.286720
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg_0 = 'I think you should be a little more careful with the automated system.'
    version_0 = ''
    var_1 = _DeprecatedSequenceConstant(var_0, msg_0, version_0)
    msg_1 = 'I think you should be a little more careful with the automated system.'
    version_1 = ''
    var_2 = _DeprecatedSequenceConstant(var_0, msg_1, version_1)
    result = var_1 + var_2
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:26:46.033365
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    SEQUENCE = range(100)
    MSG = 'In test__DeprecatedSequenceConstant___len__'
    VERSION = '1.0.0'
    var_0 = _DeprecatedSequenceConstant(SEQUENCE, MSG, VERSION)
    var_1 = print(var_0.__len__())


# Generated at 2022-06-24 18:26:48.113293
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:26:57.570470
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        test_case_0()
    except Exception:
        str_0 = 'Failed to run test__DeprecatedSequenceConstant___getitem__'
        var_0 = print(str_0)
    else:
        pass
    finally:
        str_0 = 'Completed test__DeprecatedSequenceConstant___getitem__'
        var_0 = print(str_0)


# Generated at 2022-06-24 18:27:02.386692
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        var_1 = list()
        var_0 = _DeprecatedSequenceConstant(var_1, '', '')
        var_0.__len__()
    except AssertionError:
        var_2 = test_case_0()
    else:
        var_3 = print('test__DeprecatedSequenceConstant___len__ executed without any exception')


# Generated at 2022-06-24 18:27:07.169101
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = 'In test__DeprecatedSequenceConstant'
    var_0 = print(str_0)
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = _DeprecatedSequenceConstant(var_1, var_2, var_3)
    var_8 = test_case_0(var_7, var_4, var_5, var_6)


# Generated at 2022-06-24 18:27:13.051176
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = 'In test__DeprecatedSequenceConstant'
    var_0 = print(str_0)

    # Test case 0
    test_case_0()

if __name__ == '__main__':
    print('Running DeprecatedSequenceConstant.py')
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:21.092622
# Unit test for function set_constant
def test_set_constant():
    """
    Unit test for function set_constant
    """
    print('Test set_constant(name, value, export=vars())')

    def __set_constant(name, value, export=vars()):
        export[name] = value
        return export

    import sys
    var_0 = __set_constant('sys', sys)
    var_1 = __set_constant('print', print)
    var_2 = __set_constant('test__DeprecatedSequenceConstant___getitem__', test_case_0)

    var_1(var_0, var_1, var_2)

# Generated at 2022-06-24 18:27:26.613943
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = _DeprecatedSequenceConstant(1, 1, 1)
    var_0.__getitem__
    str_0 = 'In test__DeprecatedSequenceConstant___getitem__'
    var_1 = print(str_0)


# Generated at 2022-06-24 18:27:29.300952
# Unit test for function set_constant
def test_set_constant():
    str_1 = 'In test_set_constant'
    var_0 = print(str_1)


# Generated at 2022-06-24 18:27:32.699991
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    var_0 = _DeprecatedSequenceConstant(['test_case_0'], 'In test_case_0', '1.1')
    var_0.test_case_0()

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:39.545622
# Unit test for function set_constant
def test_set_constant():
    var_0 = 'ansible_ssh_common_args'
    var_1 = '-o ProxyCommand="ssh -W %h:%p -q {{ ansible_ssh_user }}@{{ ansible_ssh_host }}"'
    var_2 = vars()

    print(set_constant(var_0, var_1, var_2))

if __name__ == '__main__':
    test_case_0()
    test_set_constant()

# Generated at 2022-06-24 18:27:43.485040
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    var_5 = _DeprecatedSequenceConstant('value', 'msg', 'version')
    var_6 = isinstance(var_5, Sequence)
    assert var_6 == True
    

# Generated at 2022-06-24 18:27:52.232416
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_0 = _DeprecatedSequenceConstant([1,2,3,4], 'test', '2.1')
    var_1 = len(var_0)
    return var_1


# Generated at 2022-06-24 18:27:54.745615
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise

# Generated at 2022-06-24 18:27:56.393313
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Testing when var_0 is integer
    test_case_0()


# Generated at 2022-06-24 18:28:01.144431
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    var_0 = _DeprecatedSequenceConstant(10, 'foo', 'bar')
    str_0 = 'In test__DeprecatedSequenceConstant'
    var_1 = print(str_0)


# Generated at 2022-06-24 18:28:04.888145
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'In test_set_constant'
    var_0 = print(str_0)

if __name__ == '__main__':
    test_case_0()
    test_set_constant()

# Generated at 2022-06-24 18:28:07.951551
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    _DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant(
                                    )
    _DeprecatedSequenceConstant___len___1 = _DeprecatedSequenceConstant_0.__len__()
    assert _DeprecatedSequenceConstant___len___1 == 0


# Generated at 2022-06-24 18:28:11.337481
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_1 = print('In test__DeprecatedSequenceConstant___getitem__')
    var_2 = [2, 3, 4]
    var_3 = _DeprecatedSequenceConstant(var_2, 'msg', 'version')
    var_4 = var_3.__getitem__(0)
    assert var_4 == 2


# Generated at 2022-06-24 18:28:12.024156
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Generated at 2022-06-24 18:28:18.547892
# Unit test for function set_constant
def test_set_constant():
    warn_0 = 'test_case_0'
    var_1 = set_constant('local', warn_0)
    assert var_1 is None

if __name__ == '__main__':
    set_constant('local', 'this is a test')
    test_set_constant()
    set_constant('local', 'this is a test')
    test_case_0()

# Generated at 2022-06-24 18:28:19.398147
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:28:25.951552
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('__name__', '__value__') is None


# Generated at 2022-06-24 18:28:32.069456
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_0 = ['d', 'e', 'p', 'r', 'e', 'c', 'a', 't', 'e', 'd']
    var_1 = 'DeprecatedSequenceConstant'
    var_2 = '1.1'
    var_3 = _DeprecatedSequenceConstant(var_0, var_1, var_2)
    var_4 = var_3.__len__()
    var_5 = 'In test__DeprecatedSequenceConstant___len__'
    var_6 = print(var_5)


# Generated at 2022-06-24 18:28:35.802874
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'In test_set_constant'
    var_0 = print(str_0)


# Generated at 2022-06-24 18:28:44.912031
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():

    # Test Input #0
    str_0 = 'In test__DeprecatedSequenceConstant___len__'
    var_0 = print(str_0)
    
    var_1 = _DeprecatedSequenceConstant(None,'test_case_0','In test__DeprecatedSequenceConstant___len__')
    var_2 = print('var_1: ', var_1)
    var_2 = var_1.__len__()
    var_3 = print('var_2: ', var_2)
    

# Generated at 2022-06-24 18:28:47.983525
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_0 = _DeprecatedSequenceConstant('test_value_0', 'test_value_1', 'test_value_2')
    var_1 = len(var_0)
    print('len: %s' % var_1)


# Generated at 2022-06-24 18:28:51.459559
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj_0 = _DeprecatedSequenceConstant('value', 'msg', 'version')
    var_0 = len(obj_0)
    var_0 = print(var_0)

# Generated at 2022-06-24 18:28:54.830636
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_1 = 'In test__DeprecatedSequenceConstant___len__'
    var_2 = print(var_1)


# Generated at 2022-06-24 18:28:57.046134
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Test cases for method test_case_1

# Generated at 2022-06-24 18:28:58.983563
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = _DeprecatedSequenceConstant(value, msg, version)
    var_1 = test_case_0()
    assert var_1 == None


# Generated at 2022-06-24 18:29:04.910058
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    """ Test of constructor _DeprecatedSequenceConstant """
    try:
        var_1 = _DeprecatedSequenceConstant()
    except TypeError as e:
        print(e)
    try:
        test_case_0()
    except TypeError as e:
        print(e)

# Generated at 2022-06-24 18:29:12.401621
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:29:16.040166
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    var_0 = None
    my_object_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    test_case_0()

test__DeprecatedSequenceConstant()
# EOF

# Generated at 2022-06-24 18:29:18.769711
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    """test for method __getitem__ of class _DeprecatedSequenceConstant"""
    arg = 3
    obj = _DeprecatedSequenceConstant('test', 'some_message_some_message', 'some_version_some_version')
    # Operation/Call
    var_return = obj.__getitem__(arg)
    # Test after
    test_case_0()


# Generated at 2022-06-24 18:29:20.799172
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = (1, 'string', 2)
    msg = 'hi'
    version = '1.0'
    obj = _DeprecatedSequenceConstant(value, msg, version)
    test_case_0()
    

test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:29:26.874193
# Unit test for function set_constant
def test_set_constant():
    var_0 = set_constant({}, [])
    # assert
    test_case_0()
    test__DeprecatedSequenceConstant___getitem__()


# Generated at 2022-06-24 18:29:28.179142
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:29:32.752641
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    print("== Start test__DeprecatedSequenceConstant___len__ ==")
    test_case_0()
    print("== End test__DeprecatedSequenceConstant___len__ ==")


# Generated at 2022-06-24 18:29:39.575783
# Unit test for function set_constant
def test_set_constant():
    print("In test_set_constant")
    str_0 = 'In test_set_constant'
    var_0 = int_0 = 1
    str_1 = 'test_set_constant'
    str_2 = 'test_set_constant'
    var_1 = set_constant(str_1, int_0, export=vars())
    print(var_1)
    str_3 = 'In test_set_constant'
    var_2 = print(str_3)


# Generated at 2022-06-24 18:29:41.125400
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'In test__DeprecatedSequenceConstant___len__'
    var_0 = print(str_0)


# Generated at 2022-06-24 18:29:44.793047
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = _DeprecatedSequenceConstant(None, None, None).__len__()
    var_0 = print(int_0)


# Generated at 2022-06-24 18:29:52.040082
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Define a set of constant values
    var_0 = _DeprecatedSequenceConstant()
    test_case_0()


# Generated at 2022-06-24 18:29:55.927000
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'In test__DeprecatedSequenceConstant___len__'
    var_0 = print(str_0)

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___len__()
    test_case_0()

# Generated at 2022-06-24 18:29:57.757679
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:29:59.853297
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:30:03.706889
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'In test_set_constant'
    var_0 = print(str_0)


# Generated at 2022-06-24 18:30:04.870696
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test__DeprecatedSequenceConstant_0()


# Generated at 2022-06-24 18:30:07.397198
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 18:30:11.521336
# Unit test for function set_constant
def test_set_constant():
    str_0 = 'In test_set_constant'
    var_0 = set_constant('test_constant', 'test_value')
    var_1 = print(str_0, var_0)


# Generated at 2022-06-24 18:30:19.162020
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        for x in range(10):
            test_case_0()
        else:
            print("For loop is over")
    except Exception as e:
        print("Exception occured during method call: ", e, type(e))
    else:
        print("No exception occured during method call")
    finally:
        print("Finally block")

test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-24 18:30:28.296711
# Unit test for function set_constant
def test_set_constant():
    try:
        from test_cases.test__fqcn import test__fqcn_1
        test__fqcn_1()
    except ImportError:
        pass
    try:
        from test_cases.test__jinja2 import test__jinja2_1
        test__jinja2_1()
    except ImportError:
        pass

if __name__ == '__main__':
    try:
        from test_cases.test__DeprecatedSequenceConstant import test__DeprecatedSequenceConstant_1
        test__DeprecatedSequenceConstant_1()
    except ImportError:
        pass
    try:
        from test_cases.test__display import test__display_1
        test__display_1()
    except ImportError:
        pass

# Generated at 2022-06-24 18:30:37.890561
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_val', globals())
    if TEST_CONSTANT != 'test_val':
        raise AssertionError('Unit test for function set_constant failed')



# Generated at 2022-06-24 18:30:50.807917
# Unit test for function set_constant
def test_set_constant():
    # Test for raise exception if argument name is not string
    try:
        set_constant([], 'value', export=vars())
    except TypeError:
        pass
    else:
        assert False, 'Expected Exception not thrown'

    # Test for raise exception if argument value is not string
    try:
        set_constant('name', [], export=vars())
    except TypeError:
        pass
    else:
        assert False, 'Expected Exception not thrown'

    # Test for raise exception if argument export is not dictionary
    try:
        set_constant('name', 'value', export='')
    except TypeError:
        pass
    else:
        assert False, 'Expected Exception not thrown'

    # Test if constant is successfully set
    set_constant('name', 'value', export=vars())

# Generated at 2022-06-24 18:30:52.904941
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Calls __len__
    T = _DeprecatedSequenceConstant(value=None, msg=None, version=None)
    y = len(T)


# Generated at 2022-06-24 18:30:55.956929
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant()


# Generated at 2022-06-24 18:31:07.130887
# Unit test for function set_constant
def test_set_constant():
    global EXAMPLE_VAR_0, EXAMPLE_VAR_1, EXAMPLE_VAR_2, EXAMPLE_VAR_3
    EXAMPLE_VAR_0 = 'TEST_RESULT'
    EXAMPLE_VAR_1 = 1
    EXAMPLE_VAR_2 = []
    EXAMPLE_VAR_3 = {}
    set_constant('EXAMPLE_VAR_0', 'test')
    set_constant('EXAMPLE_VAR_1', 1)
    set_constant('EXAMPLE_VAR_2', [])
    set_constant('EXAMPLE_VAR_3', {})
    assert(EXAMPLE_VAR_0 == 'test')
    assert(EXAMPLE_VAR_1 == 1)

# Generated at 2022-06-24 18:31:09.998401
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR', export=globals())
    assert FOO == 'BAR'



# Generated at 2022-06-24 18:31:11.490995
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:31:17.864380
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant([0, 1, 2, 3],
                                                                 msg="The 'key' option has been deprecated and will be removed in version 2.10. Use 'name' instead.",
                                                                 version=2)
    assert len(deprecated_sequence_constant_0) == 4


# Generated at 2022-06-24 18:31:23.354297
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant()
    assert deprecated_sequence_constant_0.__getitem__(0) == None


# Generated at 2022-06-24 18:31:25.489464
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest

    class Test_DeprecatedSequenceConstant(unittest.TestCase):

        def test_deprecated_sequence_constant(self):
            test_case_0()

    unittest.TestLoader.sortTestMethodsUsing = None
    unittest.main()

# Generated at 2022-06-24 18:31:36.596689
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    my_value = 'my_value'
    my_msg = 'my_msg'
    my_version = 'my_version'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(my_value, my_msg, my_version)
    assert deprecated_sequence_constant_0._value == my_value
    assert deprecated_sequence_constant_0._msg == my_msg
    assert deprecated_sequence_constant_0._version == my_version

# Generated at 2022-06-24 18:31:38.120453
# Unit test for function set_constant
def test_set_constant():
    globals()['a'] = 0
    set_constant('a', 1)
    assert globals()['a'] == 1

# Generated at 2022-06-24 18:31:40.478413
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # DeprecatedSequenceConstant = _DeprecatedSequenceConstant()
    return


# Generated at 2022-06-24 18:31:42.238167
# Unit test for function set_constant
def test_set_constant():
    set_constant("test_set_constant", "test_set_constant_value")
    assert globals()["test_set_constant"] == "test_set_constant_value"



# Generated at 2022-06-24 18:31:46.318601
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert (len(deprecated_sequence_constant_0) == len(deprecated_sequence_constant_0._value))
    assert (deprecated_sequence_constant_0[0] == deprecated_sequence_constant_0._value[0])

# Generated at 2022-06-24 18:31:49.506231
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant()
    __len___ret_val_0 = test_case_0()
    assert __len___ret_val_0 == 0


# Generated at 2022-06-24 18:31:51.892711
# Unit test for function set_constant
def test_set_constant():
    x = 'a'
    set_constant('x', 'b')
    assert x == 'b'



# Generated at 2022-06-24 18:31:56.998031
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(
        sequence, msg, version)
    try:
        deprecated_sequence_constant_0.__len__()
    except Exception as err:
        print(
            "Exception raised when calling deprecated_sequence_constant_0.__len__()")


# Generated at 2022-06-24 18:32:03.736250
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(['self._value', 'self._msg', 'self._version'], 'self._msg', 'self._version')
    assert deprecated_sequence_constant_0._value == ['self._value', 'self._msg', 'self._version']
    assert deprecated_sequence_constant_0._msg == 'self._msg'
    assert deprecated_sequence_constant_0._version == 'self._version'
    assert deprecated_sequence_constant_0[0] == 'self._value'
    assert deprecated_sequence_constant_0[1] == 'self._msg'
    assert deprecated_sequence_constant_0[2] == 'self._version'



# Generated at 2022-06-24 18:32:04.440795
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant is not None

# Generated at 2022-06-24 18:32:12.626187
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception:
        assert False

# Generated at 2022-06-24 18:32:13.381785
# Unit test for function set_constant
def test_set_constant():
    set_constant(var_0, None)

# Generated at 2022-06-24 18:32:17.537804
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = None
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    return_value = deprecated_sequence_constant_0.__getitem__(var_0)
    return return_value


# Generated at 2022-06-24 18:32:24.797875
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    var_0 = None
    var_1 = None
    # test for class _DeprecatedSequenceConstant
    assert issubclass(_DeprecatedSequenceConstant, Sequence)
    # test for constructor of class _DeprecatedSequenceConstant
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)


# Generated at 2022-06-24 18:32:27.994032
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = None
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    with pytest.raises(Exception):
        deprecated_sequence_constant_0.__getitem__()


# Generated at 2022-06-24 18:32:33.528449
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = None
    var_1 = None
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    deprecated_sequence_constant_0[var_1]


# Generated at 2022-06-24 18:32:34.545292
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:32:38.750832
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var_0 = None
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    assert deprecated_sequence_constant_0.__len__() == len(var_0)

# Generated at 2022-06-24 18:32:39.806656
# Unit test for function set_constant
def test_set_constant():
    assert callable(set_constant)
    assert set_constant == set_constant


# Generated at 2022-06-24 18:32:42.648119
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = None
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    var_1 = None
    var_1 = deprecated_sequence_constant_0[var_1]


# Generated at 2022-06-24 18:32:51.429677
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj = test_case_0()
    obj.deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:32:56.787163
# Unit test for function set_constant
def test_set_constant():
    var_0 = None
    var_1 = None
    set_constant(var_0, var_1)

# with the above defined, it's easy to know the possible values for constants

# Generated at 2022-06-24 18:33:03.620112
# Unit test for function set_constant
def test_set_constant():
    global something
    assert not hasattr(__builtins__, 'something')
    set_constant('something', 'value')
    assert hasattr(__builtins__, 'something')
    assert something == 'value'


if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-24 18:33:10.506230
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = 'ansible.release.__version__'
    var_1 = 'ansible.release.__version__'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    var_2 = deprecated_sequence_constant_0._value
    var_3 = deprecated_sequence_constant_0._value
    assert var_2 == var_3
    var_4 = deprecated_sequence_constant_0._value
    var_5 = var_4[var_1]
    assert var_5 == __version__


# Generated at 2022-06-24 18:33:15.115962
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        val_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
        val_0[var_0]
        assert True
    except AssertionError:
        raise AssertionError('Caught AssertionError')
    except Exception:
        raise AssertionError('Caught Exception')


# Generated at 2022-06-24 18:33:24.068229
# Unit test for function set_constant
def test_set_constant():
    for test_input, expected in [
        [('var_0', 'val_0'), {'var_0': 'val_0'}],
        [('var_1', 'val_1'), {'var_1': 'val_1', 'var_0': 'val_0'}],
    ]:
        set_constant(*test_input)
        assert vars() == expected


# invoke test code with 'python -m ansible.constants'
if __name__ == '__main__':
    import sys
    import doctest
    failed, _ = doctest.testmod()
    sys.exit(failed)

# Generated at 2022-06-24 18:33:26.982159
# Unit test for function set_constant
def test_set_constant():
    # All inputs
    var_name = 'ansible_host'
    var_value = '10.10.10.1'
    var_export = vars()
    assert var_name in var_export
    assert var_value == var_export[var_name]

# Generated at 2022-06-24 18:33:30.475003
# Unit test for function set_constant
def test_set_constant():
    arg_0 = 'x'
    arg_1 = 1
    arg_2 = globals()
    set_constant(arg_0, arg_1, export=arg_2)
    assert x == 1
    assert globals()['x'] == 1

# Generated at 2022-06-24 18:33:32.912676
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:33:34.827581
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('constant_0', 'ansible')['constant_0'] == 'ansible'


# Generated at 2022-06-24 18:33:51.965505
# Unit test for function set_constant
def test_set_constant():
    set_constant('CONSTANT_0', 'value_0', {})



# Generated at 2022-06-24 18:33:53.894360
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Calling injecting keyword parameters in constructor of class _DeprecatedSequenceConstant
    test_case_0()

# Unit tests for constants

# Generated at 2022-06-24 18:33:56.899289
# Unit test for function set_constant
def test_set_constant():
    test_case_0()

if __name__ == '__main__':
    test_set_constant()

# Generated at 2022-06-24 18:33:57.758945
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:34:03.075586
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = None
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    deprecated_sequence_constant_0.__getitem__(var_0)

# Generated at 2022-06-24 18:34:04.100218
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('name', 'value', {}) == {}



# Generated at 2022-06-24 18:34:07.447433
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = 'test__DeprecatedSequenceConstant___getitem__'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    len(deprecated_sequence_constant_0)
    deprecated_sequence_constant_0[0]



# Generated at 2022-06-24 18:34:09.365330
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    self = test_case_0()
    arg = None
    # Call method
    result = self.__getitem__(arg)


# Generated at 2022-06-24 18:34:13.720059
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    var_0 = None
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    if not (isinstance(deprecated_sequence_constant_0, _DeprecatedSequenceConstant)): raise AssertionError()
    if not (deprecated_sequence_constant_0._value == var_0): raise AssertionError()
    if not (deprecated_sequence_constant_0._msg == var_0): raise AssertionError()
    if not (deprecated_sequence_constant_0._version == var_0): raise AssertionError()

# Generated at 2022-06-24 18:34:14.308881
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:34:46.548059
# Unit test for function set_constant
def test_set_constant():
    tmpdir = tempfile.mkdtemp(dir=os.getcwd())
    fname = os.path.join(tmpdir, "test_set_constant.py")

    # Write out the data file that defines the expected default values
    with open(fname, "w") as ofile:
        ofile.write("MIN_MAP_COUNT = 1\n")
        ofile.write("MAGIC_VARIABLE_MAPPING = {\n")
        ofile.write("    'foo': 'bar',\n")
        ofile.write("}\n")
        ofile.write("config = ConfigManager()\n")
        ofile.write("for setting in config.data.get_settings():\n")
        ofile.write("    set_constant(setting.name, setting.value)\n")



# Generated at 2022-06-24 18:34:51.074154
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    var_0 = None
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(var_0, var_0, var_0)
    var_1 = None
    var_2 = None
    var_3 = None
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(var_1, var_2, var_3)
    var_4 = None
    deprecated_sequence_constant_0.__getitem__(var_4)
    deprecated_sequence_constant_1.__getitem__(var_4)
    test_case_0()



# Generated at 2022-06-24 18:34:52.059415
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        assert(False)
    except Exception as e:
        assert(True)


# Generated at 2022-06-24 18:35:00.407499
# Unit test for function set_constant
def test_set_constant():
    # basic test
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence
    value1 = 42
    value2 = 'forty-two'
    value3 = ['forty', 'two']
    value4 = True
    value5 = None
    value6 = object()

    set_constant('test_case_1', value1)
    set_constant('test_case_2', value2)
    set_constant('test_case_3', value3)
    set_constant('test_case_4', value4)
    set_constant('test_case_5', value5)
    set_constant('test_case_6', value6)

    assert test_case_1 == value1
    assert test_case_

# Generated at 2022-06-24 18:35:06.983337
# Unit test for function set_constant
def test_set_constant():
    import tempfile
    tmpdir_0 = tempfile.mkdtemp()
    tmpdir_0_0 = tempfile.mkdtemp()
    set_constant('tmpdir_1', tmpdir_0_0, export=vars())
    set_constant('tmpdir_0', tmpdir_0)
    set_constant('tmpdir_0', tmpdir_0, export=vars())
    str_0 = str()
    set_constant('str_0', str_0, export=vars())
    set_constant('str_0', str_0)
    dict_0 = dict()
    set_constant('dict_0', dict_0, export=vars())
    set_constant('dict_0', dict_0)
    set_constant('dict_0', dict())
    bool

# Generated at 2022-06-24 18:35:08.941742
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert test_case_0.__len__() is None


# Generated at 2022-06-24 18:35:15.863413
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:35:20.312836
# Unit test for function set_constant
def test_set_constant():
    var_0 = None
    try:
        set_constant(var_0, var_0)
    except Exception:
        raise AssertionError('Ansiballz module set_constant function failed')
