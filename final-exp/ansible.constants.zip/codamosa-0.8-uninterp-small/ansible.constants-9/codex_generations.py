

# Generated at 2022-06-24 18:25:26.083752
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = 'ze-z1'
    str_1 = 'ze-z2'
    var_0 = _DeprecatedSequenceConstant(['euuewj'], str_0, str_1)
    

# Generated at 2022-06-24 18:25:32.205024
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg_0 = 'default'
    version_0 = 3.1415
    list_0 = ['default', 'default']
    var_0 = _DeprecatedSequenceConstant(value=list_0, msg=msg_0, version=version_0)


# Generated at 2022-06-24 18:25:34.860630
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    seq = _DeprecatedSequenceConstant((1, 2, 3), 'test', '2.0')
    assert isinstance(seq, Sequence)
    assert len(seq) == 3
    assert seq[0] == 1
    assert seq[1] == 2
    assert seq[2] == 3

# Generated at 2022-06-24 18:25:41.944700
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    set_constant('display', 'default')
    set_constant('version', '2.13')
    int_0 = _DeprecatedSequenceConstant(set_constant('value', 15), 'msg', 'version')
    int_0[int_0[set_constant('i', 0)]]
    del int_0[test_case_0()['i']]
    len(test_case_0()['value'])
    from ansible.release import __version__
    if __version__ < '2.13':
        str_0 = '2.13'
        str_1 = 'msg'
        _warning(str_1)
        _warning(str_1)
        _warning(str_1)
        str_2 = '2.13'
        _warning(str_2)
        _warning

# Generated at 2022-06-24 18:25:46.508221
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Unit test for method __getitem__ of class _DeprecatedSequenceConstant
    # get the value at position 1
    value = test_case_0()[1]
    # check the value is correct
    assert value == -1509


# Generated at 2022-06-24 18:25:53.961349
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = 'default'
    int_0 = -1509
    var_1 = set_constant(str_0, int_0)
    str_1 = 'default'
    int_1 = -1509
    var_2 = set_constant(str_1, int_1)
    str_2 = 'default'
    int_2 = -1509
    var_3 = set_constant(str_2, int_2)
    int_3 = -1509
    str_3 = 'default'
    var_4 = set_constant(str_3, int_3)
    var_5 = _DeprecatedSequenceConstant(var_4, var_2, var_0)

# Generated at 2022-06-24 18:25:55.192831
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    pass


# Generated at 2022-06-24 18:25:58.995007
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Creating a object of the class _DeprecatedSequenceConstant and calling the constructor
    # NOTE: Not sure how to unit test this yet
    _DeprecatedSequenceConstant( );


# Generated at 2022-06-24 18:26:00.225957
# Unit test for function set_constant
def test_set_constant():
    assert test_case_0() is None

# Generated at 2022-06-24 18:26:03.048514
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'default'
    int_0 = -1509
    var_0 = set_constant(str_0, int_0)


# Generated at 2022-06-24 18:26:15.205178
# Unit test for function set_constant
def test_set_constant():
    warning_0 = 'has the wrong value'
    str_0 = '_TEST_VAR'
    dict_0 = dict()
    set_constant(str_0, warning_0, dict_0)
    iterable_0 = dict_0.items()
    for list_0, str_1 in iterable_0:
        assert list_0 == str_0, 'set_constant returned an unexpected value'
        assert str_1 == warning_0, 'set_constant returned an unexpected value'


# Generated at 2022-06-24 18:26:22.437029
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xb6\xaa'
    str_0 = '85-\x0c\'\'$u>O>P"\x0b'
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, str_0, bool_0)
    str_1 = "3"
    int_0 = deprecated_sequence_constant_0[str_1]


# Generated at 2022-06-24 18:26:25.131212
# Unit test for function set_constant
def test_set_constant():
    pass

if __name__ == '__main__':
    test_set_constant()
    test_case_0()

# Generated at 2022-06-24 18:26:30.075171
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bytes_0 = b'\xb6\xaa'
    str_0 = '85-\x0c\'\'$u>O>P"\x0b'
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, str_0, bool_0)
    int_0 = deprecated_sequence_constant_0.__len__()
    assert int_0 == 2


# Generated at 2022-06-24 18:26:34.224804
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = True
    str_0 = '85-\x0c\'\'$u>O>P"\x0b'
    bytes_0 = b'\xb6\xaa'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, str_0, bool_0)
    result_0 = deprecated_sequence_constant_0.__len__()
    assert result_0 == 2



# Generated at 2022-06-24 18:26:40.109855
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xb6\xaa'
    str_0 = '85-\x0c\'\'$u>O>P"\x0b'
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, str_0, bool_0)
    str_1 = '|\x1b'
    int_0 = 1
    try:
        str_2 = deprecated_sequence_constant_0[int_0]
    except IndexError:
        str_2 = str_1
    return str_2


# Generated at 2022-06-24 18:26:41.762041
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:26:44.883699
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xb6\xaa'
    str_0 = '85-\x0c\'\'$u>O>P"\x0b'
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, str_0, bool_0)

    assert deprecated_sequence_constant_0[0] == 187

# Generated at 2022-06-24 18:26:50.201591
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = 'n'
    str_1 = '`'
    str_2 = ','
    str_3 = '4'
    list_0 = [str_0, str_1, str_2, str_3]
    dict_0 = {str_0: str_1, str_2: str_3}
    bytes_0 = b'\xb6\xaa'
    str_4 = '85-\x0c\'\'$u>O>P"\x0b'
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, str_4, bool_0)
    # Store original function references
    original__warn = _warning
    # Replace function references with mocked functions
    _warning = mock__warn
    # Execute test


# Generated at 2022-06-24 18:26:57.940686
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xb6\xaa'
    str_0 = '85-\x0c\'\'$u>O>P"\x0b'
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, str_0, bool_0)
    int_0 = 0
    assert deprecated_sequence_constant_0.__getitem__(int_0) == b'\xb6'


# Generated at 2022-06-24 18:27:05.186091
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)


# Generated at 2022-06-24 18:27:10.455057
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Try invoking the constructor with different args
    # Args:
    # Parameter 1: bool or string
    # Parameter 2: bool or string
    # Return type: None
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert len(deprecated_sequence_constant_0) == 0  # len() -> int
    # Return type: float
    float_0 = deprecated_sequence_constant_0.__len__()
    assert float_0 == 0.0  # float() -> float
    # Return type: int
    int_0 = deprecated_sequence_constant_0.__len__()
    assert int_0 == 0  # int() -> int
    str_0 = 'sWm'
    tuple

# Generated at 2022-06-24 18:27:12.299869
# Unit test for function set_constant
def test_set_constant():
    # the function was tested in the main function
    pass


# Generated at 2022-06-24 18:27:14.820906
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)


# Generated at 2022-06-24 18:27:18.802711
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
   bool_0 = False
   deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
   assert deprecated_sequence_constant_0.__len__() == 0


# Generated at 2022-06-24 18:27:19.929426
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(True, True, True)



# Generated at 2022-06-24 18:27:20.726367
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:27:22.148002
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:27:27.112567
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:27:33.072536
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    passed = 0
    failed = 0
    for test in range(0, 1):
        try:
            test_case_0()
            passed += 1
        except:
            failed += 1
            pass
    print('')
    print('Passed: %s' % passed)
    print('Failed: %s' % failed)


if __name__ == '__main__':
    test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-24 18:27:42.687900
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:27:55.234341
# Unit test for function set_constant
def test_set_constant():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    dict_0 = dict()
    dict_1 = dict_0
    dict_0['name'] = dict_1
    dict_0['value'] = dict_1
    dict_0['export'] = dict_1
    set_constant(dict_0['name'], dict_0['value'], dict_0['export'])
    dict_0['export'] = dict_1
    dict_0['export'] = dict_1
    dict_0['export'] = dict_0['export']
    dict_0['export'] = dict_0['export']
    dict_0['export'] = dict_0['export']
    dict_0['export'] = dict_0

# Generated at 2022-06-24 18:28:05.161910
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_0 = _DeprecatedSequenceConstant(False, False, False)
        assert(test_0 != False)
        test_1 = _DeprecatedSequenceConstant(0, 0, 0)
        assert(test_1 != 0)
    except AssertionError as e:
        print("Test Failed: " + str(e))
        print("Expected False or 0, got " + str(test_0) + " and " + str(test_1))
    except Exception as err:
        print("Test Failed: " + str(err))
    else:
        print("Passed test_DeprecatedSequenceConstant")

if __name__ == "__main__":
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:28:07.206342
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:28:12.717435
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()
    assert isinstance(var_0, int)



# Generated at 2022-06-24 18:28:15.077197
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert callable(_DeprecatedSequenceConstant.__len__)
    test_case_0()

# Generated at 2022-06-24 18:28:20.237137
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    bool_1 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_1, bool_1, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(int(0))


if __name__ == '__main__':
    import sys
    sys.exit(int(not test_case_0()))

# Generated at 2022-06-24 18:28:24.850484
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('name', 'value')
    except Exception as e:
        print(e)
        ans = False
    else:
        ans = True
    assert ans


# Generated at 2022-06-24 18:28:31.071529
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('test_string', 'aba', {'test_string': 'test_string'}) == 'aba'
    assert set_constant('test_string', 'bab', {'test_string': 'test_string'}) == 'bab'
    assert set_constant('test_dict', 'aba', {'test_dict': 'test'}) == 'aba'


# Generated at 2022-06-24 18:28:32.668137
# Unit test for function set_constant
def test_set_constant():
    assert set_constant(bool, bool, export=vars()) == set_constant(bool, bool, export=vars())


# Generated at 2022-06-24 18:28:50.671261
# Unit test for function set_constant
def test_set_constant():

    assert True is True


# Generated at 2022-06-24 18:28:57.819588
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    for _ in range(100):
        _DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
        _DeprecatedSequenceConstant_0.__getitem__(bool_0)
        assert(_DeprecatedSequenceConstant_0.__len__() == bool_0)


if __name__ == '__main__':
    for _ in range(100):
        test_case_0()
        test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-24 18:29:00.508880
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except NameError:
        assert 0, 'Method __len__ of class _DeprecatedSequenceConstant raised NameError exception - from Dummy Module'


# Generated at 2022-06-24 18:29:02.644023
# Unit test for function set_constant
def test_set_constant():
    assert isinstance(set_constant(), dict)


# Generated at 2022-06-24 18:29:07.125452
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)


# Generated at 2022-06-24 18:29:13.233367
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert deprecated_sequence_constant_0._msg == False
    assert deprecated_sequence_constant_0._version == False
    assert deprecated_sequence_constant_0._value == False

    bool_1 = False
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(bool_1, bool_1, bool_1)
    assert deprecated_sequence_constant_1._msg == False
    assert deprecated_sequence_constant_1._version == False
    assert deprecated_sequence_constant_1._value == False

    bool_2 = False

# Generated at 2022-06-24 18:29:15.552584
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    var = _DeprecatedSequenceConstant(None, None, None)
    assert var._deprecated_sequence_constant___len__() == None

# Generated at 2022-06-24 18:29:18.584923
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0[bool_0]


# Generated at 2022-06-24 18:29:26.873888
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    str_1 = 'q3d=%c0'
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(str_1, str_1, str_1)
    int_0 = deprecated_sequence_constant_1.__len__()
    deprecated_sequence_constant_0.__getitem__(int_0)

# Generated at 2022-06-24 18:29:30.930732
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('test_set_constant', 'test_set_constant')
    except Exception as e:
        print(str(e))


# Test it all

# Generated at 2022-06-24 18:29:50.217024
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)

# unit test for method _DeprecatedSequenceConstant.__len__

# Generated at 2022-06-24 18:29:54.079867
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:29:56.297734
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(0)

# Generated at 2022-06-24 18:30:02.749474
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert deprecated_sequence_constant_0 is not None


# Generated at 2022-06-24 18:30:04.734542
# Unit test for function set_constant
def test_set_constant():
    # the function returns a dict with one key and value
    assert set_constant('name', 'value') == {'name': 'value'}

# Generated at 2022-06-24 18:30:08.156247
# Unit test for function set_constant
def test_set_constant():
    dict_1 = dict()
    assert set_constant('name', 'value', dict_1) == dict_1

    assert dict_1 == 'value'


test_case_0()

# Generated at 2022-06-24 18:30:12.885091
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:30:17.418809
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:30:26.012345
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    # length > 0 and index in range
    assert deprecated_sequence_constant_0.__getitem__(0) is False
    # length > 0 and index range error
    try:
        deprecated_sequence_constant_0.__getitem__(1)
    except IndexError as e:
        assert type(e) == IndexError

# Generated at 2022-06-24 18:30:28.479205
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
        assert True
    except Exception:
        assert False

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:30:59.713056
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    try:
        deprecated_sequence_constant_0.__len__()
    except Exception as e:
        print(e)



# Generated at 2022-06-24 18:31:05.905167
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    if not isinstance(deprecated_sequence_constant_0, _DeprecatedSequenceConstant):
        deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    try:
        assert callable(deprecated_sequence_constant_0.__len__)
    except AssertionError as e:
        print(e)
        raise e


# Generated at 2022-06-24 18:31:07.224996
# Unit test for function set_constant
def test_set_constant():
    assert callable(set_constant)


# Generated at 2022-06-24 18:31:17.298541
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except NameError as err:
        assert False, "NameError: %s" % err
    except AttributeError as err:
        assert False, "AttributeError: %s" % err
    except SyntaxError as err:
        assert False, "SyntaxError: %s" % err
    except TypeError as err:
        assert False, "TypeError: %s" % err
    except ValueError as err:
        assert False, "ValueError: %s" % err
    else:
        assert True



# Generated at 2022-06-24 18:31:24.923674
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant(MAGIC_VARIABLE_MAPPING.__contains__(bool(), bool()), MAGIC_VARIABLE_MAPPING.__contains__(bool(), bool()), MAGIC_VARIABLE_MAPPING.__contains__(bool(), bool()))
    except Exception:
        print('[-] Test failed')


# Generated at 2022-06-24 18:31:28.949261
# Unit test for function set_constant
def test_set_constant():
    for _ in range(4):
        _set_constant('ansible:test:test_set_constant')

# Generated at 2022-06-24 18:31:31.342317
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except Exception:
        print("Error while executing test_case_0")

test__DeprecatedSequenceConstant___len__()

# Generated at 2022-06-24 18:31:37.289512
# Unit test for function set_constant
def test_set_constant():
    set_constant('%d', var_0, export=vars())

if __name__ == '__main__':
    import sys
    import traceback
    try:
        test_case_0()
    except Exception:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        for line in lines:
            sys.stderr.write(line)
        sys.exit(1)
    else:
        sys.exit(0)

# Generated at 2022-06-24 18:31:41.303250
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)


# Generated at 2022-06-24 18:31:46.441884
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    int_0 = 0
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:32:23.875015
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # assert raised with expected values
    with pytest.raises(Exception) as _excinfo0:
        test_case_0()
    with pytest.raises(Exception) as _excinfo1:
        test_case_1()

# Generated at 2022-06-24 18:32:25.366124
# Unit test for function set_constant
def test_set_constant():
    set_constant('var_1', True)
    assert var_1 is True


# Generated at 2022-06-24 18:32:28.217062
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()



# Generated at 2022-06-24 18:32:29.182325
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:32:41.084309
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except NameError:
        print("NameError")

test__DeprecatedSequenceConstant()


# What follows are a set of constants only used internally; they are not
# exposed to the rest of the code but are kept in this same file for
# convenience.


# Generated at 2022-06-24 18:32:42.370783
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('var_1', 'value_1') is None


# Generated at 2022-06-24 18:32:43.635241
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-24 18:32:45.661045
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:32:49.990219
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # 1
    bool_0 = True
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)
    # 2
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bool_0)

if __name__ == "__main__":
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-24 18:32:52.699812
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    var_1 = deprecated_sequence_constant_0.__getitem__()

# Generated at 2022-06-24 18:34:03.872867
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)
    assert 0 == deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:34:11.229525
# Unit test for function set_constant
def test_set_constant():
    var_1 = 'ansible_become_password'
    var_2 = 'DEFAULT_BECOME_PASS'
    var_3 = 'ansible_shell_executable'
    var_4 = 'DEFAULT_REMOTE_PASS'
    var_5 = 'ansible_become_method'
    var_6 = 'DEFAULT_SUBSET'
    var_7 = 'ansible_become_user'
    var_8 = 'TREE_DIR'
    var_9 = 'ansible_connection'
    var_10 = 'COLOR_CODES'
    var_11 = 'ansible_user'
    var_12 = 'DOCUMENTABLE_PLUGINS'
    var_13 = 'ansible_password'
    var_14 = 'REJECT_EXTS'
    var_15

# Generated at 2022-06-24 18:34:12.322127
# Unit test for function set_constant
def test_set_constant():
    var_1 = False
    var_2 = var_1
    return var_1, var_2


# Generated at 2022-06-24 18:34:12.981715
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:34:15.207274
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Create the object for class _DeprecatedSequenceConstant
    test_case_0()

# Call the methods for class _DeprecatedSequenceConstant

test__DeprecatedSequenceConstant___len__()

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 18:34:19.878140
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:34:20.923625
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:34:23.858362
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        test_case_0()
    except:
        assert False



# Generated at 2022-06-24 18:34:33.642623
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


if __name__ == '__main__':
    import sys
    import subprocess
    import os
    import tempfile

    def write_file(path, data):
        fh = open(path, 'w')
        fh.write(data)
        fh.close()

    def run_command(cmd):
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        out, err = p.communicate()
        return out, err

    def generate_tests():
        res = ''


# Generated at 2022-06-24 18:34:36.473008
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test using constructor of class _DeprecatedSequenceConstant
    bool_0 = False
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, bool_0, bool_0)

