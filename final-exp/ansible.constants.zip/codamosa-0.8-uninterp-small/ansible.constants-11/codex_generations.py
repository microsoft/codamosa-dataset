

# Generated at 2022-06-24 18:25:22.296006
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:25:23.488421
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:25:27.547411
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    float_0 = 291.1
    int_0 = 257
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, float_0, int_0)
    test__DeprecatedSequenceConstant___len___0(deprecated_sequence_constant_0)


# Generated at 2022-06-24 18:25:29.413460
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class _DeprecatedSequenceConstant
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:25:32.735583
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bool_0 = False
    float_0 = 291.1
    int_0 = 257
    _DeprecatedSequenceConstant(bool_0, float_0, int_0)


# Generated at 2022-06-24 18:25:34.916856
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        test_case_0()
    except Exception as e:
        print('Test case 0 failed: ', e)


# Generated at 2022-06-24 18:25:36.244916
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Unit tests for class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:25:39.739660
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    float_0 = 291.1
    int_0 = 257
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, float_0, int_0)
    assert deprecated_sequence_constant_0.__len__() == len(bool_0)


# Generated at 2022-06-24 18:25:42.355677
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    float_0 = 291.1
    int_0 = 257
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, float_0, int_0)
    deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:25:49.394550
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bool_0 = False
    float_0 = 291.1
    int_0 = 257
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bool_0, float_0, int_0)
    with pytest.raises(Exception) as e_1:
        deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:25:54.625434
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:25:56.344278
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert deprecated_sequence_constant_0.__len__() == 451


# Generated at 2022-06-24 18:26:06.674732
# Unit test for method __len__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:26:12.912557
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:26:13.964674
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:26:15.410355
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:26:17.304023
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test case with no parameters
    # Deprecated sequence constant test case 0
    test_case_0()


# Generated at 2022-06-24 18:26:21.097115
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant_0 = 'ansible_connection_user'
    value_0 = deprecated_sequence_constant_0.__len__()
    assert value_0 == 23


# Generated at 2022-06-24 18:26:22.271553
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:26:23.545459
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # FIXME: Test
    pass


# Generated at 2022-06-24 18:26:28.985974
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()



# Generated at 2022-06-24 18:26:32.095481
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    (deprecated_sequence_constant_0, str_0, bytes_0) = test_case_0()
    deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:26:33.723848
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:26:34.737088
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:26:37.252313
# Unit test for function set_constant
def test_set_constant():
    # FIXME: fix the test.
    assert 1
    # assert set_constant('DIRECTORY_MODE', 0o775) == {'DIRECTORY_MODE': 0o775}

# Generated at 2022-06-24 18:26:42.791016
# Unit test for function set_constant
def test_set_constant():
    assert _ACTION_ALLOWED_INCLUDE_MODULES == _ACTION_ALLOWED_INCLUDE_MODULES
    assert _ACTION_ALLOWED_INCLUDE_MODULES == add_internal_fqcns(('include_role', 'import_playbook', 'include_tasks'))
    assert ACTION_COMMON_ARGUMENT_SPEC == ACCUMULATE_OPTIONS == {'param1': {'accumulate': 'first', 'choices': ['a', 'b', 'c']}, 'param2': {'accumulate': 'last'}}

# Generated at 2022-06-24 18:26:43.878446
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Create an instance of _DeprecatedSequenceConstant
    test_case_0()


# Generated at 2022-06-24 18:26:45.526513
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
# @todo This test does not return an error if len is called in method.
    len(deprecated_sequence_constant_0)


# Generated at 2022-06-24 18:26:46.568066
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Generated at 2022-06-24 18:26:53.757131
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:27:02.703737
# Unit test for function set_constant
def test_set_constant():
    test_case_0()



# Generated at 2022-06-24 18:27:03.776245
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:27:07.051049
# Unit test for function set_constant
def test_set_constant():
    name = 'string_0'
    value = 'string_1'
    export = {'dictionary_0': {}}

    # Call set_constant
    set_constant(name, value, export)

    assert name in export
    assert export['dictionary_0'][name] == value



# Generated at 2022-06-24 18:27:08.438612
# Unit test for function set_constant
def test_set_constant():
    assert set_constant == 0
    assert set_constant == 0
    assert set_constant == 0


# Generated at 2022-06-24 18:27:09.245675
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:27:10.049263
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()



# Generated at 2022-06-24 18:27:11.088073
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    len(deprecated_sequence_constant_0)


# Generated at 2022-06-24 18:27:18.333263
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:27:19.133602
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:27:20.603633
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:27:37.387965
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:27:39.520483
# Unit test for function set_constant
def test_set_constant():
    assert callable(set_constant)


# Generated at 2022-06-24 18:27:40.804124
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:27:43.286949
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()
    # cons_str, cons_str_1, cons_str_2


# Generated at 2022-06-24 18:27:45.048206
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()



# Generated at 2022-06-24 18:27:49.319317
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(deprecated_sequence_constant_0) > 0
    assert isinstance(deprecated_sequence_constant_0, _DeprecatedSequenceConstant)

# Generated at 2022-06-24 18:27:53.336353
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bytes_0, str_0)
    int_0 = deprecated_sequence_constant_0.__len__()
    assert int_0 == 16


# Generated at 2022-06-24 18:28:03.539502
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-24 18:28:08.281271
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
  test_case_0()

# Generated at 2022-06-24 18:28:09.384806
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

