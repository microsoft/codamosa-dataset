

# Generated at 2022-06-24 18:25:22.234472
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:25:27.044347
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = ''
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, dict_0, dict_0)


# Generated at 2022-06-24 18:25:29.769918
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        _DeprecatedSequenceConstant(str, str, str)
    # AssertionError was raised as a result of deprecated sequence constant
    except AssertionError:
        return 1
    except Exception:
        return 0
    else:
        return 1


# Generated at 2022-06-24 18:25:35.207054
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = 'oHkM@\x05y:dg'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(str_0, dict_0, dict_0)
    assert deprecated_sequence_constant_1.__len__() is None


# Generated at 2022-06-24 18:25:42.327777
# Unit test for function set_constant
def test_set_constant():
    str_0 = ''
    str_1 = ''
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    set_constant(str_0, str_1, dict_0)
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, dict_0, dict_0)
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, dict_0, dict_0)
    return deprecated_sequence_constant_0



# Generated at 2022-06-24 18:25:44.758235
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:25:51.168367
# Unit test for function set_constant
def test_set_constant():
    try:
        if not(__name__ == '__main__'):
            return
        set_constant(str_0, str_0)
        if isinstance(str_0, tuple):
            raise TypeError
    except TypeError:
        raise Exception("%s expected %s to raise TypeError, not %s" % ('test_set_constant', 'set_constant', TypeError))

# Generated at 2022-06-24 18:26:03.353236
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = ''
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, dict_0, dict_0)
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    dict_2 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}

# Generated at 2022-06-24 18:26:07.604670
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = ''
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, dict_0, str_0)
    assert deprecated_sequence_constant_0[str_0] == str_0


# Generated at 2022-06-24 18:26:17.517037
# Unit test for function set_constant
def test_set_constant():

    str_0 = ''
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, dict_0, dict_0)
    # Call function set_constant and side_effect var_0
    var_0 = {}
    
    try:
        set_constant(str_0, dict_0, var_0)
    except Exception:
        var_0 = None
    assert var_0 == None

    # Call function set_constant and side_effect var_1
    var_1 = {}
    try:
        set_constant(str_0, dict_0, var_1)
    except Exception:
        var_

# Generated at 2022-06-24 18:26:22.451153
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([0, 1], 'Example warning message', '2.0')


# Generated at 2022-06-24 18:26:24.689668
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    result = _DeprecatedSequenceConstant.__len__(test_case_0())
    assert result is 1


# Generated at 2022-06-24 18:26:26.841523
# Unit test for function set_constant
def test_set_constant():
    test_case_0()
    assert(vars()['int_0']==1)


# Generated at 2022-06-24 18:26:30.576997
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():

    # AssertionError: AssertionError: ValueError not raised
    # test_case_0()

    test_case_1()


# Generated at 2022-06-24 18:26:32.314453
# Unit test for function set_constant
def test_set_constant():
    dict_0 = {}
    set_constant('int_0', 2, dict_0)
    assert dict_0['int_0'] == 2

# Generated at 2022-06-24 18:26:36.624179
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    obj_0 = _DeprecatedSequenceConstant(1, 1, 1)
    assert len(obj_0) == 0
    assert len(obj_0) == 0
    assert obj_0._value == 1
    assert obj_0._msg == 1
    assert obj_0._version == 1


# Generated at 2022-06-24 18:26:38.587428
# Unit test for function set_constant
def test_set_constant():
    try:
        set_constant('test_case_0', test_case_0)
    except:
        assert False, 'An exception should not be thrown.'


# Generated at 2022-06-24 18:26:40.619322
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 18:26:42.139536
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:26:44.661312
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 1
    str_0 = 'test'
    dict_0 = {
        'test' : int_0
    }
    list_0 = [
        int_0,
        str_0,
        dict_0
    ]
    _DeprecatedSequenceConstant(list_0, str_0, int_0)


# Generated at 2022-06-24 18:26:51.413562
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant([None], 'test', '0.0.0').__len__() == 1


# Generated at 2022-06-24 18:26:57.428662
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = test_case_0 ()
    assert int_0 == 1
    obj_0 = _DeprecatedSequenceConstant(int_0, int_0, int_0)
    assert isinstance(obj_0, _DeprecatedSequenceConstant)
    assert obj_0._version == 1
    assert obj_0._msg == 1
    assert obj_0._value == 1


# Generated at 2022-06-24 18:27:02.070171
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()
    a = [1, 2]
    b = "./ansible/constants.py"
    c = "2.2"
    deprecated_sequence = _DeprecatedSequenceConstant(a, b, c)
    print("_DeprecatedSequenceConstant: {0}".format(deprecated_sequence))


# Generated at 2022-06-24 18:27:06.209328
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = len(_DeprecatedSequenceConstant(['a','b','c'], 'test_message', 'version'))
    assert int_0 == 3
    list_0 = [x for x in _DeprecatedSequenceConstant(['a','b','c'], 'test_message', 'version')]
    assert list_0 == ['a','b','c']


# Generated at 2022-06-24 18:27:11.509244
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()
    test_value_0 = _DeprecatedSequenceConstant((), '', '')
    assert len(test_value_0) == 0, 'unit test failed for case 0'


# Generated at 2022-06-24 18:27:16.508711
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq_const_0 = _DeprecatedSequenceConstant(None, None, None)
    item_0 = 0
    rst_0 = seq_const_0[item_0]
    assert isinstance(rst_0, Exception)


# Generated at 2022-06-24 18:27:20.321177
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('int_0', 1) == 1
    assert set_constant('str_0', 'str') == 'str'
    assert set_constant('bool_0', True) == True
    assert set_constant('float_0', 0.1) == 0.1


# Generated at 2022-06-24 18:27:23.275478
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value_0 = "test_value_0"
    test_msg_0 = "test_msg_0"
    test_version_0 = "test_version_0"
    test_name_0 = _DeprecatedSequenceConstant(test_value_0, test_msg_0, test_version_0)


# Generated at 2022-06-24 18:27:26.448254
# Unit test for function set_constant
def test_set_constant():
    set_constant('int_0', 2)

    assert int_0 == 2


# Generated at 2022-06-24 18:27:29.118764
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dep_seq = _DeprecatedSequenceConstant([], '', '')
    assert dep_seq[0] == []


# Generated at 2022-06-24 18:27:39.374798
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant([1,2,3],'test_msg','test_version')
    result_0 = constant.__len__()
    assert result_0 == 3, "Expected result[0] = 3"


# Generated at 2022-06-24 18:27:44.284534
# Unit test for function set_constant
def test_set_constant():
    test_case_0()
    result_0 = 'ansible_python_version' in vars()
    assert result_0 == True
    result_1 = ANSIBLE_PYTHON_VERSION == '3.6'
    assert result_1 == True


# Generated at 2022-06-24 18:27:52.120973
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # create an instance of _DeprecatedSequenceConstant
    test_sequence = _DeprecatedSequenceConstant(0,0,0)
    # create an instance of object
    test_obj = object
    # test the method of __init__()
    assert isinstance(test_sequence, Sequence) == True
    assert isinstance(test_sequence, test_obj) == True


# Generated at 2022-06-24 18:27:54.603765
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq_0 = _DeprecatedSequenceConstant('9', '6', '11')
    assert seq_0[1] == '6'


# Generated at 2022-06-24 18:27:59.251807
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = [1, 2, 3]
    msg = "this is a test"
    version = "2.0"
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    # Call __len__()
    dsc.__len__()
    # Call __getitem__()
    dsc.__getitem__(0)


# Generated at 2022-06-24 18:28:05.527435
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test_msg'
    version = 'test_version'
    value = [1,2,3]
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant_0) == 3 and deprecated_sequence_constant_0[0] == 1 and deprecated_sequence_constant_0[1] == 2


# Generated at 2022-06-24 18:28:09.041888
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_0 = ['1']
    deprecated_constant_0 = _DeprecatedSequenceConstant(list_0,'0','0')
    try:
        assert len(deprecated_constant_0) == 1
    except:
        __logger.exception('AssertionError')
        raise


# Generated at 2022-06-24 18:28:15.964580
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Instantiation of class _DeprecatedSequenceConstant
    msg = 'msg'
    version = 'version'
    value = 'value'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)

    # Testing method __len__
    len(deprecated_sequence_constant)

    # Tested method returns the length of the object.
    # Test passes.



# Generated at 2022-06-24 18:28:18.744325
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = 1
    msg = 'msg'
    version = 'version'
    print(_DeprecatedSequenceConstant(value, msg, version).__len__())


# Generated at 2022-06-24 18:28:20.199850
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1




# Generated at 2022-06-24 18:28:33.497471
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert_param = None
    assert_param = _DeprecatedSequenceConstant('value', 'msg', '1.0')
    assert_param = _DeprecatedSequenceConstant([], 'msg', '1.0')
    assert_param = _DeprecatedSequenceConstant(None, 'msg', '1.0')
    assert_param = _DeprecatedSequenceConstant(set(), 'msg', '1.0')
    assert_param = _DeprecatedSequenceConstant({}, 'msg', '1.0')


# Generated at 2022-06-24 18:28:37.229208
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_name = 'test__DeprecatedSequenceConstant___getitem__'
    test_case_0()


# Generated at 2022-06-24 18:28:42.851786
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test Case 0
    global COLOR_CODES
    global _DeprecatedSequenceConstant
    test_case_0()
    dsc = _DeprecatedSequenceConstant(COLOR_CODES, "COLOR_CODES is deprecated", "2.10")
    assert len(dsc) == 25

# Generated at 2022-06-24 18:28:46.860056
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # 创建类的实例
    obj = _DeprecatedSequenceConstant(0, 0, 0)
    # 调用无参数的方法
    int_0 = obj.__getitem__()
    # 回归断言
    assert(int_0 == 0)


# Generated at 2022-06-24 18:28:52.082307
# Unit test for function set_constant
def test_set_constant():
    # Test passing an invalid name returns nothing
    assert set_constant("test", "value", export=dict()) == None

    # Test passing a valid name returns a value
    t = dict()
    set_constant("test", "value", export=t)
    assert t.get("test") == "value"

# Generated at 2022-06-24 18:28:56.562158
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()
    test__DeprecatedSequenceConstant.actual_result = 'pass'

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()
    print(test__DeprecatedSequenceConstant.actual_result)

# Generated at 2022-06-24 18:29:01.664096
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    class_1 = _DeprecatedSequenceConstant(['action_plugins', 'cache', 'callback_plugins'], 'This will be removed in version 2.9.', '2.9')
    class_1._msg
    class_1._version
    class_1._value
    class_1.__getitem__(0)
    class_1.__len__()

test_case_0()
test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:29:06.556937
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    k = _DeprecatedSequenceConstant([1, 2], "int_0 != int_1", "v2.7.0")
    assert(len(k) == 2)
    assert(k[0] == 1)
    assert(k[1] == 2)


# Generated at 2022-06-24 18:29:10.503691
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    sequence_0 = _DeprecatedSequenceConstant((),"msg_0","version_0")
    try:
        sequence_0[0]
    except IndexError:
        pass


# Generated at 2022-06-24 18:29:19.545832
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import nose
    import random
    import textwrap
    import unittest

    from test.test_support import run_unittest
    import ansible.config.constants

    # Set up parameters
    int_0 = random.randint(1, 50)
    int_1 = random.randint(1, 50)

    # Perform the test
    placeholder_0 = ansible.config.constants._DeprecatedSequenceConstant([int_0, int_1], 'msg', 'version')
    int_2 = placeholder_0[random.randint(0, 1)]

    # Verify the results
    nose.tools.assert_in(int_2, (int_0, int_1))



# Generated at 2022-06-24 18:29:28.112062
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(CONFIGURABLE_PLUGINS) == 13


# Generated at 2022-06-24 18:29:31.671185
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-24 18:29:36.150723
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    value = 1
    msg = 'Testing __len__ method'
    version = 'ansible-2.7'
    inst = _DeprecatedSequenceConstant(value, msg, version)
    assert len(inst) == len(value)


# Generated at 2022-06-24 18:29:38.002742
# Unit test for function set_constant
def test_set_constant():
    set_constant('int_0', 2)
    assert int_0 == 2

test_case_0()
test_set_constant()

# Generated at 2022-06-24 18:29:40.141981
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'deprecated', '2.0')
    assert dsc[1] == 'b'


# Generated at 2022-06-24 18:29:44.256851
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant_0 = _DeprecatedSequenceConstant((1), (''), (''))
    int_0 = constant_0.__len__()
    assert int_0 is None


# Generated at 2022-06-24 18:29:47.175789
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:29:55.629500
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = u"test_case_0"
    msg = msg.encode('ascii')
    msg1 = u"test_case_1"
    msg1 = msg1.encode('ascii')
    version1 = u"test_case_2"
    version1 = version1.encode('ascii')
    value1 = test_case_0
    assert isinstance(_DeprecatedSequenceConstant((value1,), msg1, version1), _DeprecatedSequenceConstant)
    print('Unit test of class _DeprecatedSequenceConstant is OK')

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:30:07.113312
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    int_0 = 1
    int_1 = 1
    str_0 = "1"
    str_1 = "2"
    str_2 = "3"
    dict_0 = {}
    dict_1 = {"1": "2"}
    dict_2 = {"1": "2", "3": "4"}
    list_0 = []
    list_1 = ["1"]
    list_2 = ["1", "2"]
    list_3 = ["1", "2", "3"]
    list_4 = ["1", "2", list_0]
    list_5 = [int_0, int_1]
    list_6 = [str_0, str_1]
    list_7 = [dict_0, dict_1, dict_2]

# Generated at 2022-06-24 18:30:15.113291
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

    test_obj_0 = _DeprecatedSequenceConstant( [ '', '', '', '', '', '', '' ], 'msg', 'version')

    try:
        test_obj_0.__getitem__(0)
    except NameError:
        print('Exception')


if __name__ == "__main__":
    test__DeprecatedSequenceConstant___getitem__()

# Generated at 2022-06-24 18:30:29.465598
# Unit test for function set_constant
def test_set_constant():
    int_0 = 0
    set_constant('int_0', 1)
    assert int_0 == 1


# Generated at 2022-06-24 18:30:34.376793
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], "", "")) == 0


# Generated at 2022-06-24 18:30:36.245508
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = _DeprecatedSequenceConstant(value = [], msg = "", version = "")
    assert len(int_0) == 0


# Generated at 2022-06-24 18:30:39.292252
# Unit test for function set_constant
def test_set_constant():
    import inspect
    test_case_0()
    current_env = inspect.currentframe().f_back.f_globals
    assert current_env['int_0'] == 1
    set_constant('int_1', 2)
    assert current_env['int_1'] == 2
    del int_0
    del int_1

# Generated at 2022-06-24 18:30:44.984800
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Here's our payoff idiom!
if __name__ == '__main__':
    import sys
    import doctest

    # Set up the environment
    sys.path.insert(0, '.')

    # Run the tests
    doctest.testmod(sys.modules.get(__name__))

# Generated at 2022-06-24 18:30:46.403095
# Unit test for function set_constant
def test_set_constant():
    assert set_constant("test_name", "test_value", {}) == {}
    return True


# Generated at 2022-06-24 18:30:51.283950
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    print('Testing _DeprecatedSequenceConstant constructor')
    value = ['test', 'test1']
    msg = 'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST'
    version = '2.3.4'
  
    _DeprecatedSequenceConstant(value, msg, version)


# Generated at 2022-06-24 18:30:53.157512
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = ''
    version = ''
    sequence_object = _DeprecatedSequenceConstant(1, msg, version)
    assert sequence_object


# Generated at 2022-06-24 18:30:56.038792
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1,2], "msg", "1.0")

# Generated at 2022-06-24 18:30:57.316814
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    int_0 = 1


# Generated at 2022-06-24 18:31:19.171204
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()
    int_0 = 1
    int_1 = 1
    int_2 = 1
    int_3 = 1

    str_0 = 'test'
    str_1 = 'test'
    str_2 = 'test'
    str_3 = 'test'

    # This is a test of your code
    _DeprecatedSequenceConstant(str_0, str_1, str_2)
    _DeprecatedSequenceConstant(str_0, str_1, str_2)[int_0]

    _DeprecatedSequenceConstant(str_0, str_1, str_2)[int_0:int_1:int_2]
    print('Test 0 Pass')


# Generated at 2022-06-24 18:31:20.800613
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:31:22.367756
# Unit test for function set_constant
def test_set_constant():
    assert set_constant("test_var", "test_value")

# Generated at 2022-06-24 18:31:24.591638
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    t = _DeprecatedSequenceConstant(value = 1, msg = "test_msg", version = "2.0")
    t.__len__()


# Generated at 2022-06-24 18:31:26.423341
# Unit test for function set_constant
def test_set_constant():
    assert vars()['int_0'] == 1


# Generated at 2022-06-24 18:31:28.469937
# Unit test for function set_constant
def test_set_constant():
    int_1 = 1
    set_constant('int_1', int_1)
    assert int_1 == int_1



# Generated at 2022-06-24 18:31:32.246655
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    msg = "hello"
    version = "1.0"
    value = [1, 2, 3]
    obj = _DeprecatedSequenceConstant(value=value, msg=msg, version=version)
    res = obj.__len__()


# Generated at 2022-06-24 18:31:35.657025
# Unit test for function set_constant
def test_set_constant():
    """
    Test case for function DefaultData
    """
    assert set_constant('int_0', 123) == None
    assert set_constant('a', 1234) == None
    assert set_constant('b', 12345) == None
    assert set_constant('c', 123456) == None

# Generated at 2022-06-24 18:31:39.656877
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    from ansible.module_utils.common.collections import Sequence
    an_obj = _DeprecatedSequenceConstant(['a'], 'msg', 'version')
    assert an_obj is not None
    assert isinstance(an_obj, _DeprecatedSequenceConstant)
    assert isinstance(an_obj, Sequence)
    assert an_obj.__len__() == 1
    assert an_obj.__getitem__(0) == 'a'

# Generated at 2022-06-24 18:31:43.939722
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = []
    msg = "Deprecated"
    version = "1.1"
    test_case_0.dsc = _DeprecatedSequenceConstant(value, msg, version)

test_case_0()


# Generated at 2022-06-24 18:31:58.645135
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    param0 = _DeprecatedSequenceConstant(None, 'test', '1.2.3')
    param1 = 0
    result = param0.__getitem__(param1)
    assert isinstance(result, object) == True


# Generated at 2022-06-24 18:32:01.953924
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = []
    msg = "test is a test"
    version = "1.0"
    dep_con = _DeprecatedSequenceConstant(value, msg, version)
    assert dep_con._value == value
    assert dep_con._msg == msg
    assert dep_con._version == version

# Generated at 2022-06-24 18:32:03.800013
# Unit test for function set_constant
def test_set_constant():
    value = 1
    export = {}
    name = 'int_0'
    set_constant(name, value, export)
    assert export[name] == 1


# Generated at 2022-06-24 18:32:07.617607
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Init object
    i = 0
    test__DeprecatedSequenceConstant_0 = _DeprecatedSequenceConstant(
        i,
        'test__DeprecatedSequenceConstant_0',
        'test_case_0()'
    )
    assert(test__DeprecatedSequenceConstant_0[0] == i)
    assert(test__DeprecatedSequenceConstant_0.__getitem__(0) == i)


# Generated at 2022-06-24 18:32:10.597632
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    const_0 = _DeprecatedSequenceConstant([1,2,3], 'Test message', '2.0')
    int_0 = len(const_0)
    assert (int_0 == 3), 'Failedvalue: %s' % int_0


# Generated at 2022-06-24 18:32:14.466053
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()
    msg = "test_msg"
    version = "test_version"
    value = []
    dep_sequence_constant = _DeprecatedSequenceConstant(value=value, msg=msg, version=version)
    return dep_sequence_constant[0] == value[0]


# Generated at 2022-06-24 18:32:19.862450
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    print("test__DeprecatedSequenceConstant")
    test_case_0()

    res = _DeprecatedSequenceConstant(value, msg, version)

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-24 18:32:25.931614
# Unit test for function set_constant
def test_set_constant():
    from tempfile import mkdtemp
    from os import environ
    from os.path import join
    from shutil import rmtree

    test_folder = mkdtemp()

    # This is where ansible.cfg will live
    environ['ANSIBLE_CONFIG'] = join(test_folder, 'ansible.cfg')

    config.DEFAULTS['TEST_CONSTANT'] = dict(
        default='hello world',
    )

    # Set config
    config.parse()

    # Setting constant in global namespace
    set_constant('TEST_CONSTANT', 'I am a constant')

    # Make sure constant was set properly
    assert TEST_CONSTANT == 'I am a constant'

    # Cleanup
    rmtree(test_folder)
    del environ['ANSIBLE_CONFIG']

# Generated at 2022-06-24 18:32:32.757835
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_a = 1
    int_b = 2
    int_c = 3
    list_0 = [int_a,int_b,int_c]
    _DeprecatedSequenceConstant(list_0, "get_bin_path() is deprecated. Switch to ansible.module_utils.basic.AnsibleModule().get_bin_path() instead.", '2.10')


# Generated at 2022-06-24 18:32:42.345871
# Unit test for function set_constant
def test_set_constant():
    set_constant('name', 'value')


### Backwards compat for plugins, remove in 2.8 ###

# a dictionary of plugin names (the key) and a tuple describing that plugin and how it should be loaded
#
# the tuple is of the form ( <path to the plugin>, <plugin type>, <plugin subdir>, <plugin name> )
# - the plugin name is used to import the module and is also used to name the attribute added to the ActionBase
#   subclass
# - the path to the plugin is used to import the plugin file itself
# - the plugin type is used to select which ActionBase subclass to add the plugin to
# - the plugin subdir is used to identify which subdir in the plugin path to prepend to the plugin name
#
###############
# examples:
#   "FooModule":          ( 'lib/ansible/modules/core

# Generated at 2022-06-24 18:33:11.375830
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    int_0 = 1
    int_1 = 2
    str_0 = "Test string."
    _DeprecatedSequenceConstant([int_0, int_1], str_0, str_0)


# Generated at 2022-06-24 18:33:22.824713
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_int', 1024)
    set_constant('test_str', 'test string')
    set_constant('test_list', ['a', 1, 'b'])
    assert test_int == 1024
    assert test_str == 'test string'
    assert test_list == ['a', 1, 'b']

if __name__ == "__main__":
    test_set_constant()
    print('All tests successful')

# Generated at 2022-06-24 18:33:25.350350
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    sequence = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    if len(sequence) == 3:
        pass #This was expected
    else:
        raise AssertionError



# Generated at 2022-06-24 18:33:27.746259
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    case0 = _DeprecatedSequenceConstant(1,2,3)
    assert isinstance(case0,_DeprecatedSequenceConstant)


# Generated at 2022-06-24 18:33:29.186849
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant(1, 2, 3)



# Generated at 2022-06-24 18:33:31.026088
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([], "", "")
    assert dsc[0] == None


# Generated at 2022-06-24 18:33:35.556753
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    """
    Test method __len__ of class _DeprecatedSequenceConstant
    """
    from ansible.parsing.convert_bool import _DeprecatedSequenceConstant
    value = ('test-value',)
    msg = 'test-message'
    version = 'test-version'
    expected = len(value)
    result = _DeprecatedSequenceConstant(value, msg, version)
    assert (len(result) == expected)


# Generated at 2022-06-24 18:33:43.514477
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    warnings = []
    def generate_message(msg, version):
        warnings.append(' [DEPRECATED] %s, to be removed in %s\n' % (msg, version))

    import sys
    setattr(sys.modules[__name__], 'test_case_0', test_case_0)
    setattr(sys.modules[__name__], '_deprecated', generate_message)
    # Construction of object
    # test_0 = _DeprecatedSequenceConstant((0, 1), 'test_msg', '1.0')
    # test_0.__getitem__(0)
    # test_0.__getitem__(1)
    # test_0.__getitem__(2)


# Generated at 2022-06-24 18:33:44.657318
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()
    assert 1 == 1


# Generated at 2022-06-24 18:33:47.796746
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_s = _DeprecatedSequenceConstant(value=[0], msg='test_msg', version='test_version')
    assert(test_s._value == [0])
    assert(test_s._msg == 'test_msg')
    assert(test_s._version == 'test_version')


# Generated at 2022-06-24 18:35:18.728133
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    mock = [1, 2, 3]
    arg = _DeprecatedSequenceConstant(mock, 'foo', 'bar')
    assert len(arg) == len(mock)
    assert arg[0] == mock[0]
    assert arg[0] == mock[0]
    assert arg[0] == mock[0]
