

# Generated at 2022-06-24 18:25:29.623154
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    str_0 = '"/o@^d?3YD.=%@c.'
    bool_0 = True
    float_0 = 344.0
    # Negative test case 3
    # Exception raised?
    # assertRaises(TypeError, _DeprecatedSequenceConstant, "string", True, 344.0)
    if isinstance(str_0, string_types) and isinstance(344.0, (int, float, complex)) and isinstance(344.0, (int, float, complex)):
        # Exception raised?
        # assertRaises(TypeError, _DeprecatedSequenceConstant, "string", True, 344.0)
        # _DeprecatedSequenceConstant(str_0, bool_0, float_0)
        pass


# Generated at 2022-06-24 18:25:34.314133
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = '"/o@^d?3YD.=%@c.'
    bool_0 = True
    float_0 = 344.0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    assert deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:25:38.522566
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '"/o@^d?3YD.=%@c.'
    bool_0 = True
    float_0 = 344.0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    int_0 = -1
    deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:25:39.304968
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert True # implemented as needed



# Generated at 2022-06-24 18:25:45.026591
# Unit test for function set_constant
def test_set_constant():

    # Test case 0
    value = '"/o@^d?3YD.=%@c.'
    name = 'bool_0'
    bool_0 = True
    export = vars()
    set_constant(name, value, export)
    assert bool_0 is True
    name = 'float_0'
    float_0 = 344.0
    export = vars()
    set_constant(name, value, export)
    assert float_0 == 344.0
    name = 'deprecated_sequence_constant_0'
    msg = True
    version = 344.0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(value, msg, version)
    export = vars()
    set_constant(name, value, export)
    assert deprecated_sequence_constant_

# Generated at 2022-06-24 18:25:51.058694
# Unit test for function set_constant
def test_set_constant():
    str_0 = '"/o@^d?3YD.=%@c.'
    bool_0 = True
    float_0 = 344.0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    set_constant(str_0, bool_0, deprecated_sequence_constant_0)

# Generated at 2022-06-24 18:25:58.382280
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    str_0 = '"/o@^d?3YD.=%@c.'
    bool_0 = True
    float_0 = 344.0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    assert deprecated_sequence_constant_0.__len__() == len(str_0), 'Expected and actual values do not match'


# Generated at 2022-06-24 18:26:07.820608
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    str_0 = '"/o@^d?3YD.=%@c.'
    bool_0 = True
    float_0 = 344.0
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(str_0, bool_0, float_0)
    str_1 = '}d41#+Nt-$:<g]*!'
    int_0 = 0
    char_0 = deprecated_sequence_constant_0[int_0]
    assert char_0 == '"', 'Assertion Failed'
    int_1 = 30
    char_1 = deprecated_sequence_constant_0[int_1]
    assert char_1 == '.', 'Assertion Failed'
    int_2 = 15
    char_2 = deprecated_sequence_constant_0[int_2]

# Generated at 2022-06-24 18:26:13.413961
# Unit test for function set_constant
def test_set_constant():
    set_constant()
    str_1 = '"/o@^d?3YD.=%@c.'
    bool_1 = True
    float_1 = 344.0
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(str_1, bool_1, float_1)



# Generated at 2022-06-24 18:26:15.116284
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Driver program to test above functions

# Generated at 2022-06-24 18:26:22.363082
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    list_1 = []
    bytes_1 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(list_1, bytes_1, list_1)


# Generated at 2022-06-24 18:26:28.766792
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list_0 = []
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(list_0, bytes_0, list_0)
    int_0 = 1
    var_0 = deprecated_sequence_constant_0.__getitem__(int_0)


# Generated at 2022-06-24 18:26:32.665654
# Unit test for function set_constant
def test_set_constant():
    name = 'test'
    value = 'a test'
    export = {}
    set_constant(name, value, export)
    assert export['test'] == 'a test'
    set_constant(name, value)
    assert globals()['test'] == 'a test'
    globals().pop('test')

# Generated at 2022-06-24 18:26:33.960948
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert test_case_0() == 0


# Generated at 2022-06-24 18:26:38.412361
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list_0 = []
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(list_0, bytes_0, list_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(list_0)


# Generated at 2022-06-24 18:26:45.977393
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list_0 = []
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(list_0, bytes_0, list_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(list_0)
    print(var_0)


# Generated at 2022-06-24 18:26:49.923436
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    list_0 = []
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    assert_equal(_DeprecatedSequenceConstant(list_0, bytes_0, list_0).__dict__, _DeprecatedSequenceConstant(list_0, bytes_0, list_0).__dict__)


# Generated at 2022-06-24 18:26:59.331330
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    print('Testing method _DeprecatedSequenceConstant.__getitem__')
    list_0 = []

# Generated at 2022-06-24 18:27:04.753010
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    list_0 = []
    list_1 = []
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(list_0, bytes_0, list_1)
    var_0 = deprecated_sequence_constant_0.__len__()



# Generated at 2022-06-24 18:27:07.925420
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    list_0 = []
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(list_0, bytes_0, list_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(0)


# Generated at 2022-06-24 18:27:15.628266
# Unit test for function set_constant
def test_set_constant():
    func_var_0 = set_constant('var_0', 'var_0', 'vars()')
    assert func_var_0 == 'var_0'


# Generated at 2022-06-24 18:27:19.668647
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_1 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_1.__len__()
    assert var_0 == 0


# Generated at 2022-06-24 18:27:22.963911
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bytes_0)


# Generated at 2022-06-24 18:27:28.472912
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Basic test of instantiation of class
    _DeprecatedSequenceConstant(object(), object(), object())
    # Instantiation should trigger deprecation warning
    from ansible.module_utils.common.warnings import DeprecationWarning
    with pytest.warns(DeprecationWarning):
        test_case_0()


# Generated at 2022-06-24 18:27:29.077749
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:27:31.661298
# Unit test for function set_constant
def test_set_constant():
    var_0 = bytes_0
    name_0 = bytes_0
    export_0 = locals()
    set_constant(name_0, var_0, export_0)


# Generated at 2022-06-24 18:27:32.803147
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()


# Generated at 2022-06-24 18:27:36.427781
# Unit test for function set_constant
def test_set_constant():
    try:
        assert callable(set_constant)
    except AssertionError as e:
        raise(AssertionError(e.args))



# Generated at 2022-06-24 18:27:40.282348
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bytes_0)



# Generated at 2022-06-24 18:27:49.049967
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    def test_case_0():
        bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
        deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
        var_0 = deprecated_sequence_constant_0.__getitem__(bytes_0)



# Generated at 2022-06-24 18:28:08.535700
# Unit test for function set_constant
def test_set_constant():
    import tempfile
    import shutil
    import os
    import sys

    try:
        os.mkdir('test_set_constant')
        fd, path = tempfile.mkstemp(dir='test_set_constant')
        temp_file = open(path, 'w')
        old_stdout, sys.stdout = sys.stdout, temp_file
        try:
            set_constant('abc', 'abc')
        finally:
            sys.stdout = old_stdout
        temp_file.close()
        with open(path) as f:
            first_line = f.readline()
            assert 'abc = \'abc\'' in first_line, first_line
    finally:
        shutil.rmtree('test_set_constant')

# Generated at 2022-06-24 18:28:12.412019
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('test_var', bytes_0) is None
    try:
        assert set_constant('test_var', bytes_0)
    except NameError:
        assert True


# Generated at 2022-06-24 18:28:13.765215
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant()



# Generated at 2022-06-24 18:28:22.380397
# Unit test for function set_constant
def test_set_constant():
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    bytes_1 = b"T\xc3\x19\xf1\xa8<\x15\xe2\xab\xd0\xefs\x83\xb2\xc7\xae\x1d\xa1\xea"

    assert literal_eval(set_constant(bytes_0, bytes_1)) == 67149002538944001959911362698933574849982278810252077
    assert literal_eval(set_constant(bytes_0, bytes_0, globals())) == -13641467536331028263900778930467997173794908699814449

# Generated at 2022-06-24 18:28:26.799689
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    try:
        test_case_0()
    except NameError as error:
        print(error)
        raise Exception("Test Case No: 0 Failed")
    print("Test Case No: 0 Passed")



# Generated at 2022-06-24 18:28:27.866984
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:28:32.320098
# Unit test for function set_constant
def test_set_constant():
    value_0 = 'Ansible'
    name_0 = 'ANSIBLE_VERSION'
    export_0 = {}
    set_constant(name_0, value_0, export_0)


if __name__ == '__main__':
    test_case_0()
    test_set_constant()

# Generated at 2022-06-24 18:28:41.689166
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)


if __name__ == "__main__":
    import sys
    print(sys.version)
    print(sys.version_info)
    for i, j in globals().items():
        print('{} --> {}'.format(i, j))

# Generated at 2022-06-24 18:28:45.040741
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # _DeprecatedSequenceConstant_0 is an instance of
    # _DeprecatedSequenceConstant; _DeprecatedSequenceConstant_0.__getitem__ is
    # the method __getitem__ of class _DeprecatedSequenceConstant
    assert isinstance(test_case_0(), int)

# Generated at 2022-06-24 18:28:46.219565
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert test_case_0() is None


# Generated at 2022-06-24 18:29:12.534311
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()
    print('Tests Complete')



# Generated at 2022-06-24 18:29:15.446478
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Verify the object has the class _DeprecatedSequenceConstant
    assert_class(test_case_0(), _DeprecatedSequenceConstant)


# Generated at 2022-06-24 18:29:16.061947
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()

# Generated at 2022-06-24 18:29:17.189784
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    pass


# Generated at 2022-06-24 18:29:19.497664
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 18:29:24.256847
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    with pytest.raises(Exception) as excinfo:
        test_case_0()
    assert excinfo.value.args[0] == ' [DEPRECATED] %s, to be removed in %s\n'


# Generated at 2022-06-24 18:29:28.661963
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    bytearray_0 = bytearray(bytes_0)
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytearray_0, bytearray_0, bytearray_0)
    int_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:29:35.921793
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bytes_0 = b's\x19\x1e\x0c'
    msg_0 = str(bytes_0, encoding='utf-8')
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, msg_0, bytes_0)

    len_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:29:39.378239
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__len__()

# Generated at 2022-06-24 18:29:42.000149
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xc0\xbe\xb0\x10\x90\xbe\x1e\x81\x02\x0f'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)


# Generated at 2022-06-24 18:30:32.143927
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()

# Generated at 2022-06-24 18:30:35.132489
# Unit test for function set_constant
def test_set_constant():
    name_0 = 0
    value_0 = 0
    export_0 = {}
    set_constant(name_0, value_0, export_0)

# Generated at 2022-06-24 18:30:35.857784
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_case_0()



# Generated at 2022-06-24 18:30:37.316314
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert _DeprecatedSequenceConstant.__len__(test_case_0())


# Generated at 2022-06-24 18:30:38.158007
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('/', '', {}) == {}


# Generated at 2022-06-24 18:30:49.236389
# Unit test for function set_constant
def test_set_constant():
    bytes_1 = b'abcdefg'
    int_2 = 6
    list_2 = ['oi', 'ui', 'qw', 'df']
    str_4 = '12345'
    bytes_3 = b'12345'
    int_3 = -3
    list_3 = [True, 'qw', 8, bytes_1, b'\x88', 'oi', '12345', b'12345']
    assert set_constant(bytes_1, int_2, export=vars()) in list_2
    assert set_constant(str_4, bytes_3, export=vars()) in list_3

# Generated at 2022-06-24 18:30:50.535340
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert test_case_0()


# Generated at 2022-06-24 18:30:52.312743
# Unit test for function set_constant
def test_set_constant():
    assert type(set_constant(config, config, export=vars())) is dict


# Generated at 2022-06-24 18:30:55.803432
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test Scenario : Call the method with a valid value and return the computed value.
    # Expected Result: None
    assert test_case_0() is None

# Generated at 2022-06-24 18:30:57.564863
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():

    test_case_0()
# end of class _DeprecatedSequenceConstant


# Generated at 2022-06-24 18:32:38.953380
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:32:40.326560
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    try:
        _DeprecatedSequenceConstant()
    except Exception:
        return
    else:
        raise AssertionError('AssertionError raised')


# Generated at 2022-06-24 18:32:41.049312
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()

# Generated at 2022-06-24 18:32:46.123385
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    try:
        bytes_0 = b'[w\xa4\xa4\xb4\x9e\x15\x8c\xbc\x1b\xe0\xec\xfa\xb7\xc0\x9c\x14\x87#-\xa1'
        var_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
        var_0.__len__()
    except Exception:
        print("There was an error in method __len__ of class _DeprecatedSequenceConstant")
        raise


# Generated at 2022-06-24 18:32:52.630189
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    bytes_0 = b'\xf0\x1aQ\xad\x9c\x87\xca\xa5\x7f'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__len__()


# Generated at 2022-06-24 18:33:01.289726
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # assert _DeprecatedSequenceConstant('\xbcH\x96\xb2xW\xbf\x8cG\x12', '\xbcH\x96\xb2xW\xbf\x8cG\x12', '\xbcH\x96\xb2xW\xbf\x8cG\x12').__getitem__('\xbcH\x96\xb2xW\xbf\x8cG\x12') == '\xbcH\x96\xb2xW\xbf\x8cG\x12'
    test_case_0()

# Generated at 2022-06-24 18:33:02.623868
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_case_0()


# Generated at 2022-06-24 18:33:03.411609
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    pass


# Generated at 2022-06-24 18:33:12.380994
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    bytes_0 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    bytes_1 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    bytes_2 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    bytes_3 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    bytes_4 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'
    bytes_5 = b'\xbcH\x96\xb2xW\xbf\x8cG\x12'

# Generated at 2022-06-24 18:33:15.765769
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_case_0()


# Generated at 2022-06-24 18:35:11.892460
# Unit test for function set_constant
def test_set_constant():
    assert _ACTION_HAS_CMD == add_internal_fqcns(('command', 'shell', 'script'))
    assert _ACTION_ALLOWS_RAW_ARGS == _ACTION_HAS_CMD + add_internal_fqcns(('raw', ))


# Generated at 2022-06-24 18:35:18.808699
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    bytes_0 = b'\x86\x92\x93\xbbuO\xa7\xcb\xb0\xb9'
    deprecated_sequence_constant_0 = _DeprecatedSequenceConstant(bytes_0, bytes_0, bytes_0)
    var_0 = deprecated_sequence_constant_0.__getitem__(bytes_0)

if __name__ == '__main__':
    test__DeprecatedSequenceConstant___getitem__()