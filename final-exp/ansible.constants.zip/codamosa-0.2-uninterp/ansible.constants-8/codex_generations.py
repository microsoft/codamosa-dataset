

# Generated at 2022-06-22 16:06:31.508217
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'
    set_constant('FOO', 'BAZ', export=globals())
    assert FOO == 'BAZ'
    set_constant('FOO', 'BAZ', export=locals())
    assert FOO == 'BAR'

# Generated at 2022-06-22 16:06:33.972996
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:06:41.070072
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:06:43.701114
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # Arrange
    value = ['a', 'b', 'c']
    msg = 'msg'
    version = 'version'

    # Act
    dsc = _DeprecatedSequenceConstant(value, msg, version)

    # Assert
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version


# Generated at 2022-06-22 16:06:46.057606
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:06:51.884629
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:06:57.054359
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    value = [1, 2, 3]
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert dsc[-1] == 3
    assert dsc[-2] == 2
    assert dsc[-3] == 1
    assert dsc[1:2] == [2]
    assert dsc[1:] == [2, 3]
    assert dsc[:2] == [1, 2]
    assert dsc[:] == [1, 2, 3]
    assert dsc[::2] == [1, 3]

# Generated at 2022-06-22 16:07:02.797148
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:13.682278
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    from ansible.module_utils.common.collections import Sequence

    class _DeprecatedSequenceConstant(Sequence):
        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

        def __len__(self):
            _deprecated(self._msg, self._version)
            return len(self._value)

        def __getitem__(self, y):
            _deprecated(self._msg, self._version)
            return self._value[y]

    # Capture stderr
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()

    # Test

# Generated at 2022-06-22 16:07:15.599095
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'


# Generated at 2022-06-22 16:07:21.226226
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'



# Generated at 2022-06-22 16:07:27.864507
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = 'test version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:07:29.932693
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:39.398651
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:41.645277
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:07:44.094888
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:48.282076
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant[1] == 2


# Generated at 2022-06-22 16:07:50.616439
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:52.715573
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:56.909986
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a test message"
    version = "2.9"
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:08:01.890731
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:08:05.468279
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:16.725166
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR is False
    assert ANSIBLE_HOST_KEY_CHECKING is True
    assert ANSIBLE_NOCOWS is False
    assert ANSIBLE_NOCOLOR is False
    assert ANSIBLE_SSH_PIPELINING is False
    assert ANSIBLE_STDOUT_CALLBACK is 'default'
    assert ANSIBLE_RETRY_FILES_ENABLED is True
    assert ANSIBLE_ROLES_PATH == [u'/etc/ansible/roles']
    assert ANSIBLE_SSH_RETRIES == 3
    assert ANSIBLE_TIMEOUT == 10
    assert ANSIBLE_TREE_DIR is None
    assert ANSIBLE_VAULT_PASSWORD_FILE == u'~/.vault_pass.txt'
    assert ANS

# Generated at 2022-06-22 16:08:28.353857
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list

# Generated at 2022-06-22 16:08:31.233702
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('TEST_CONSTANT', 'test_value') == {'TEST_CONSTANT': 'test_value'}


# Generated at 2022-06-22 16:08:33.669298
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:08:39.538072
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.0'
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_object[0] == 'a'
    assert test_object[1] == 'b'
    assert test_object[2] == 'c'


# Generated at 2022-06-22 16:08:42.133206
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['a', 'b'], 'test', '2.0')
    assert len(dsc) == 2
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'

# Generated at 2022-06-22 16:08:47.343877
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.9'
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]
    assert test_obj[2] == value[2]

# Generated at 2022-06-22 16:08:54.519397
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version') == ['a', 'b']
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[1] == 'b'


# Generated at 2022-06-22 16:09:08.320611
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:09:12.375878
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'version')
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:09:20.081658
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # with a list
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc._value == [1, 2, 3]
    assert dsc._msg == 'msg'
    assert dsc._version == 'version'
    # with a tuple
    dsc = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert dsc._value == (1, 2, 3)
    assert dsc._msg == 'msg'
    assert dsc._version == 'version'
    # with a string
    dsc = _DeprecatedSequenceConstant('123', 'msg', 'version')
    assert dsc._value == '123'
    assert dsc._msg == 'msg'

# Generated at 2022-06-22 16:09:27.022044
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['a', 'b', 'c']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version
    assert len(test_obj) == 3
    assert test_obj[1] == 'b'

# Generated at 2022-06-22 16:09:28.988770
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:09:39.373812
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz', export=locals())
    assert FOO == 'baz'
    assert locals()['FOO'] == 'baz'
    set_constant('FOO', 'qux', export=globals())
    assert FOO == 'qux'
    assert globals()['FOO'] == 'qux'


# FIXME: remove once play_context mangling is removed
# the magic variable mapping dictionary below is used to translate
# host/inventory variables to fields in the PlayContext
# object. The dictionary values are tuples, to account for aliases
# in variable names.


# Generated at 2022-06-22 16:09:44.706626
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test'
    version = '1.0'
    value = ['test']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 1
    assert dsc[0] == 'test'


# Generated at 2022-06-22 16:09:46.841048
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'



# Generated at 2022-06-22 16:09:55.212362
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import unittest

    class Test__DeprecatedSequenceConstant___getitem__(unittest.TestCase):
        def setUp(self):
            self.held, sys.stderr = sys.stderr, io.StringIO()

        def tearDown(self):
            sys.stderr = self.held

        def test__DeprecatedSequenceConstant___getitem__(self):
            _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1]
            self.assertEqual(sys.stderr.getvalue(), ' [DEPRECATED] msg, to be removed in version\n')

    unittest.main()

# Generated at 2022-06-22 16:09:59.447926
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self):
            self.value = [1, 2, 3]
            self.msg = 'test'
            self.version = '1.0'
            self.obj = _DeprecatedSequenceConstant(self.value, self.msg, self.version)

        def test(self):
            assert self.obj[0] == self.value[0]
            assert self.obj[1] == self.value[1]
            assert self.obj[2] == self.value[2]

    test = Test()
    test.test()

# Generated at 2022-06-22 16:10:07.569745
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:10:10.197346
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:10:18.212775
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version') == ['a', 'b']
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[1] == 'b'


# Generated at 2022-06-22 16:10:20.440921
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 'foo')
    assert ANSIBLE_TEST_CONSTANT == 'foo'

# Generated at 2022-06-22 16:10:27.053206
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    value = [1, 2, 3]
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

    # Test with a tuple
    value = (1, 2, 3)
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

    # Test with a string
    value = '123'
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequence

# Generated at 2022-06-22 16:10:35.023104
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test case 1:
    #   Test if the constructor of class _DeprecatedSequenceConstant
    #   can be called with a list as the first parameter.
    #   The second parameter is a string, and the third parameter is a string.
    #   The expected result is that the constructor can be called.
    #   No exception is raised.
    #   The length of the list is returned.
    #   The string is printed to stderr.
    #   The string is printed to stderr.
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')) == 3

    # Test case 2:
    #   Test if the constructor of class _DeprecatedSequenceConstant
    #   can be called with a list as the first parameter.
    #   The second parameter is a string, and

# Generated at 2022-06-22 16:10:36.135749
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'

# Generated at 2022-06-22 16:10:37.588794
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:10:39.898114
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'



# Generated at 2022-06-22 16:10:46.563678
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = 'test version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 16:11:02.548391
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    msg = 'This is a test message'
    version = '2.0'
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version


# Generated at 2022-06-22 16:11:04.014037
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:09.962253
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == 3
    assert deprecated_sequence_constant[0] == 1
    assert deprecated_sequence_constant[1] == 2
    assert deprecated_sequence_constant[2] == 3

# Generated at 2022-06-22 16:11:18.149221
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for _DeprecatedSequenceConstant.__len__()
    # Test for _DeprecatedSequenceConstant.__len__() with empty sequence
    assert _DeprecatedSequenceConstant([], 'test', '2.0').__len__() == 0
    # Test for _DeprecatedSequenceConstant.__len__() with non-empty sequence
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0').__len__() == 3


# Generated at 2022-06-22 16:11:20.208297
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[1] == 'b'


# Generated at 2022-06-22 16:11:22.723788
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['test_value']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 1
    assert test_obj[0] == 'test_value'

# Generated at 2022-06-22 16:11:29.291994
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.9'
    test_sequence = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_sequence) == 3
    assert test_sequence[0] == 'a'
    assert test_sequence[1] == 'b'
    assert test_sequence[2] == 'c'

# Generated at 2022-06-22 16:11:41.318575
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_bool
    from ansible.module_utils.common.text.converters import to_int
    from ansible.module_utils.common.text.converters import to_float
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-22 16:11:46.087603
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['value']
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == 1
    assert deprecated_sequence_constant[0] == 'value'

# Generated at 2022-06-22 16:11:52.001716
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]


# Generated at 2022-06-22 16:12:15.972661
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:12:20.090723
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:12:24.470679
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:12:29.351930
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self, value):
            self.value = value

        def __getitem__(self, y):
            return self.value[y]

    test = Test([1, 2, 3])
    dsc = _DeprecatedSequenceConstant(test, 'msg', 'version')
    assert dsc[1] == 2

# Generated at 2022-06-22 16:12:31.903779
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:12:36.938268
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    obj = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert obj[0] == 1
    assert obj[1] == 2
    assert obj[2] == 3


# Generated at 2022-06-22 16:12:42.403261
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[2] == 3


# Generated at 2022-06-22 16:12:44.802253
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:50.554682
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:12:58.940502
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:14:04.500197
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:14:06.721271
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:12.426794
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3


# Generated at 2022-06-22 16:14:21.581651
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import unittest

    class Test__DeprecatedSequenceConstant___getitem__(unittest.TestCase):

        def setUp(self):
            self.held, sys.stderr = sys.stderr, io.StringIO()

        def tearDown(self):
            sys.stderr = self.held

        def test_DeprecatedSequenceConstant___getitem__(self):
            _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[0]
            self.assertEqual(sys.stderr.getvalue(), ' [DEPRECATED] msg, to be removed in version\n')

    unittest.main()

# Generated at 2022-06-22 16:14:26.041961
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('FOO', 'bar') == {'FOO': 'bar'}
    assert set_constant('FOO', 'bar', export={'FOO': 'baz'}) == {'FOO': 'baz'}

# Generated at 2022-06-22 16:14:28.293962
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:30.671564
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:14:37.624075
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'
    set_constant('TEST_CONSTANT', 'test2', export=globals())
    assert TEST_CONSTANT == 'test2'
    set_constant('TEST_CONSTANT', 'test3', export=locals())
    assert TEST_CONSTANT == 'test2'
    assert 'TEST_CONSTANT' not in locals()


# Generated at 2022-06-22 16:14:38.452830
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:14:47.197398
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    # Test with a tuple
    dsc = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
