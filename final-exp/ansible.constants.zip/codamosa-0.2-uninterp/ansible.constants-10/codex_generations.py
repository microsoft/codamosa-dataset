

# Generated at 2022-06-22 16:06:42.095001
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    from ansible.module_utils.common.collections import Sequence

    class _TestDeprecatedSequenceConstant(Sequence):
        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

        def __len__(self):
            return len(self._value)

        def __getitem__(self, y):
            return self._value[y]

    class _TestDisplay(object):
        def __init__(self):
            self.warning_msg = None
            self.deprecated_msg = None
            self.deprecated_version = None

        def warning(self, msg):
            self.warning_msg = msg

        def deprecated(self, msg, version):
            self.deprecated_msg = msg

# Generated at 2022-06-22 16:06:50.417253
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['test_value']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == 1
    assert test_obj[0] == 'test_value'

# Generated at 2022-06-22 16:07:02.519900
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:13.301122
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:24.021923
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:25.982148
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:07:31.818759
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:07:35.381797
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:07:37.545172
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:48.282570
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_CONFIG == '/etc/ansible/ansible.cfg'
    assert ANSIBLE_CONFIG_FILE == '/etc/ansible/ansible.cfg'
    assert ANSIBLE_DEBUG == False
    assert ANSIBLE_FORCE_COLOR == False
    assert ANSIBLE_HOST_KEY_CHECKING == True
    assert ANSIBLE_INVENTORY == '/etc/ansible/hosts'
    assert ANSIBLE_LIBRARY == '/usr/share/ansible'
    assert ANSIBLE_NOCOWS == 1
    assert ANSIBLE_NOCOLOR == False
    assert ANSIBLE_PIPELINING == False
    assert ANSIBLE_PRIVATE_KEY_FILE == '/etc/ansible/sshkey'

# Generated at 2022-06-22 16:07:53.265479
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:08:04.948259
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:08:15.828836
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('foo', 'bar') == {'foo': 'bar'}
    assert set_constant('foo', 'bar', {'foo': 'baz'}) == {'foo': 'baz'}
    assert set_constant('foo', 'bar', {'foo': 'baz'}) == {'foo': 'baz'}
    assert set_constant('foo', 'bar', {'foo': 'baz'}) == {'foo': 'baz'}
    assert set_constant('foo', 'bar', {'foo': 'baz'}) == {'foo': 'baz'}
    assert set_constant('foo', 'bar', {'foo': 'baz'}) == {'foo': 'baz'}

# Generated at 2022-06-22 16:08:21.723137
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:08:24.396882
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:08:30.921697
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

# Generated at 2022-06-22 16:08:38.992951
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ('test_value_1', 'test_value_2')
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_deprecated_sequence_constant = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_deprecated_sequence_constant) == len(test_value)
    assert test_deprecated_sequence_constant[0] == test_value[0]
    assert test_deprecated_sequence_constant[1] == test_value[1]


# Generated at 2022-06-22 16:08:43.261809
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:08:46.042976
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:53.057512
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    assert _DeprecatedSequenceConstant(value, msg, version)._value == value
    assert _DeprecatedSequenceConstant(value, msg, version)._msg == msg
    assert _DeprecatedSequenceConstant(value, msg, version)._version == version
    assert len(_DeprecatedSequenceConstant(value, msg, version)) == len(value)
    assert _DeprecatedSequenceConstant(value, msg, version)[0] == value[0]

# Generated at 2022-06-22 16:09:01.823503
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:09:04.399127
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:09:11.143243
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:09:13.224184
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:15.502882
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 'foo')
    assert ANSIBLE_TEST_CONSTANT == 'foo'


# Generated at 2022-06-22 16:09:16.703578
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:09:29.115375
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert COLOR_CODES['black'] == u'0;30'
    assert COLOR_CODES['bright gray'] == u'0;37'
    assert COLOR_CODES['blue'] == u'0;34'
    assert COLOR_CODES['white'] == u'1;37'
    assert COLOR_CODES['green'] == u'0;32'
    assert COLOR_CODES['bright blue'] == u'1;34'
    assert COLOR_CODES['cyan'] == u'0;36'
    assert COLOR_CODES['bright green'] == u'1;32'
    assert COLOR_COD

# Generated at 2022-06-22 16:09:34.540261
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self):
            self.msg = 'msg'
            self.version = 'version'

        def __getitem__(self, y):
            return y

    test = Test()
    assert _DeprecatedSequenceConstant(test, test.msg, test.version)[0] == 0

# Generated at 2022-06-22 16:09:36.282311
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'


# Generated at 2022-06-22 16:09:40.372978
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'
    set_constant('TEST_CONSTANT', 'test_value2', export=globals())
    assert TEST_CONSTANT == 'test_value2'

# Generated at 2022-06-22 16:10:06.296311
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert COLLECTION_PTYPE_COMPAT == {'module': 'modules'}
    assert CONFIGURABLE_PLUGINS == ('become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars')

# Generated at 2022-06-22 16:10:14.329113
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.collections import _DeprecatedSequenceConstant
    from ansible.module_utils.common.collections import _deprecated
    from ansible.module_utils.common.collections import _warning
    import sys
    import mock

    # Test case 1:
    # Test if the method __getitem__ of class _DeprecatedSequenceConstant
    # raises a DeprecationWarning when called
    with mock.patch.object(sys, 'stderr') as mock_stderr:
        _DeprecatedSequenceConstant([], 'msg', 'version').__getitem__(0)
        mock_stderr.write.assert_called_with(' [DEPRECATED] msg, to be removed in version\n')

    #

# Generated at 2022-06-22 16:10:18.809167
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:10:20.987952
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:28.762128
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a test message"
    version = "2.0"
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]
    assert test_obj[2] == value[2]

# Generated at 2022-06-22 16:10:41.199156
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'
    set_constant('TEST_CONSTANT', 'test2', export=locals())
    assert TEST_CONSTANT == 'test2'
    set_constant('TEST_CONSTANT', 'test3', export=globals())
    assert TEST_CONSTANT == 'test3'
    set_constant('TEST_CONSTANT', 'test4', export=globals())
    assert TEST_CONSTANT == 'test4'
    set_constant('TEST_CONSTANT', 'test5', export=locals())
    assert TEST_CONSTANT == 'test5'
    set_constant('TEST_CONSTANT', 'test6')
    assert TEST_CONST

# Generated at 2022-06-22 16:10:43.354920
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:45.778874
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:47.879368
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:10:50.336980
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:11:28.265974
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert len(dsc) == 3

# Generated at 2022-06-22 16:11:32.992684
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test', '2.0')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:11:44.734232
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:11:53.196641
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'
    set_constant('foo', 'baz', export=locals())
    assert foo == 'baz'
    assert locals()['foo'] == 'baz'
    set_constant('foo', 'qux', export=globals())
    assert foo == 'qux'
    assert globals()['foo'] == 'qux'
    set_constant('foo', 'quux', export=vars())
    assert foo == 'quux'
    assert vars()['foo'] == 'quux'

# Generated at 2022-06-22 16:12:04.850325
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:12:11.359629
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:12:23.024559
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:12:29.207523
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    l = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(l, 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

    # Test with a tuple
    t = (1, 2, 3)
    dsc = _DeprecatedSequenceConstant(t, 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

    # Test with a string
    s = '123'
    dsc = _DeprecatedSequenceConstant(s, 'msg', 'version')
    assert dsc[0] == '1'
    assert dsc[1] == '2'

# Generated at 2022-06-22 16:12:31.753615
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:12:44.113513
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('foo', 'bar') == {'foo': 'bar'}
    assert set_constant('foo', 'bar', {'foo': 'baz'}) == {'foo': 'baz'}
    assert set_constant('foo', 'bar', {'foo': 'baz'}) == {'foo': 'baz'}
    assert set_constant('foo', 'bar', {'foo': 'baz'}, export={'foo': 'baz'}) == {'foo': 'baz'}
    assert set_constant('foo', 'bar', export={'foo': 'baz'}) == {'foo': 'baz'}
    assert set_constant('foo', 'bar', export={'foo': 'baz'}) == {'foo': 'baz'}
    assert set_const

# Generated at 2022-06-22 16:14:19.876808
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:14:26.261047
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'
    set_constant('foo', 'bar', export=globals())
    assert foo == 'bar'
    set_constant('foo', 'bar', export=locals())
    assert foo == 'bar'
    set_constant('foo', 'bar', export=vars())
    assert foo == 'bar'

# Generated at 2022-06-22 16:14:28.818265
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:37.624820
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['test_value1', 'test_value2']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == 2
    assert test_obj[0] == 'test_value1'
    assert test_obj[1] == 'test_value2'

# Generated at 2022-06-22 16:14:49.914830
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text

    class _DeprecatedSequenceConstant(Sequence):
        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

        def __len__(self):
            _deprecated(self._msg, self._version)
            return len(self._value)

        def __getitem__(self, y):
            _deprecated(self._msg, self._version)
            return self._value[y]

    # Capture stderr
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()

    # Test


# Generated at 2022-06-22 16:14:52.679803
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:14:54.718504
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:14:58.646297
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'test')
    assert vars()['test'] == 'test'
    set_constant('test', 'test2', {'test': 'test'})
    assert vars()['test'] == 'test'
    assert {'test': 'test'}['test'] == 'test2'

# Generated at 2022-06-22 16:15:10.895510
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR is False
    assert ANSIBLE_HOST_KEY_CHECKING is True
    assert ANSIBLE_NOCOWS is False
    assert ANSIBLE_NOCOLOR is False
    assert ANSIBLE_SSH_PIPELINING is False
    assert ANSIBLE_STDOUT_CALLBACK is 'default'
    assert ANSIBLE_TRANSFORM_INVALID_GROUP_CHARS is True
    assert ANSIBLE_TRANSFORM_INVALID_GROUP_CHARS_STRIP is True
    assert ANSIBLE_TRANSFORM_INVALID_GROUP_CHARS_REPLACE is '_'
    assert ANSIBLE_UNSAFE_WRITE_TMP is False
    assert ANSIBLE_VERBOSITY is 0
    assert ANSIBLE_VERSION is __

# Generated at 2022-06-22 16:15:21.527866
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant