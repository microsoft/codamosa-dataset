

# Generated at 2022-06-22 16:06:36.242211
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list

# Generated at 2022-06-22 16:06:39.057376
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:06:43.685630
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[1] == 2

# Generated at 2022-06-22 16:06:50.636544
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3


# Generated at 2022-06-22 16:07:02.704280
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:13.521915
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    assert test_obj[-1] == 'c'
    assert test_obj[-2] == 'b'
    assert test_obj[-3] == 'a'
    assert test_obj[1:3] == ['b', 'c']
    assert test_obj[1:-1] == ['b']

# Generated at 2022-06-22 16:07:15.207153
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:07:17.690732
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert len(dsc) == 0
    assert dsc[0] == []


# Generated at 2022-06-22 16:07:23.735379
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'
    set_constant('test_constant', 'test_value2', export=locals())
    assert test_constant == 'test_value2'
    assert locals()['test_constant'] == 'test_value2'

# Generated at 2022-06-22 16:07:25.717777
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'


# Generated at 2022-06-22 16:07:32.809534
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['a', 'b', 'c']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:07:38.379812
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2

# Generated at 2022-06-22 16:07:49.145216
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:57.613110
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:59.605266
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:05.835033
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:08:10.956155
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Arrange
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    # Act
    result = dsc[1]
    # Assert
    assert result == 'b'


# Generated at 2022-06-22 16:08:13.365685
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:08:15.126576
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:08:17.270172
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:08:30.306912
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = '1.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 16:08:37.999789
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:08:48.800266
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_CONFIG == 'ansible.cfg'
    assert ANSIBLE_CONFIG_FILE == 'ansible.cfg'
    assert ANSIBLE_DEBUG == False
    assert ANSIBLE_FORCE_COLOR == False
    assert ANSIBLE_HOST_KEY_CHECKING == True
    assert ANSIBLE_HOST_KEY_CHECKING_STRICT == False
    assert ANSIBLE_INVENTORY == '/etc/ansible/hosts'
    assert ANSIBLE_INVENTORY_ENABLED == ['host_list', 'script', 'auto']
    assert ANSIBLE_LIBRARY == '/usr/share/ansible'
    assert ANSIBLE_MODULE_UTILS == '/usr/share/ansible/module_utils'
    assert ANSIBLE_NOCOWS == False
    assert AN

# Generated at 2022-06-22 16:08:53.044812
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:08:58.158443
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for a valid index
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[1] == 2
    # Test for an invalid index
    try:
        dsc[4]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'

# Generated at 2022-06-22 16:09:00.675413
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:09:03.045368
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:09:05.513211
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'


# Generated at 2022-06-22 16:09:14.967280
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import unittest

    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def setUp(self):
            self.held, sys.stderr = sys.stderr, io.StringIO()

        def tearDown(self):
            sys.stderr = self.held

        def test_getitem(self):
            dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')
            self.assertEqual(dsc[0], 1)
            self.assertEqual(dsc[1], 2)
            self.assertEqual(dsc[2], 3)


# Generated at 2022-06-22 16:09:16.454407
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=['a', 'b'], msg='msg', version='version')) == 2


# Generated at 2022-06-22 16:09:27.837712
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')) == 3


# Generated at 2022-06-22 16:09:30.855243
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[1] == 'b'

# Generated at 2022-06-22 16:09:34.564651
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]


# Generated at 2022-06-22 16:09:39.174339
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version

# Generated at 2022-06-22 16:09:41.206686
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'

# Generated at 2022-06-22 16:09:50.745894
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid value
    test_value = ['a', 'b', 'c']
    test_msg = 'Test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    # Test for invalid value
    try:
        test_obj[3]
    except IndexError:
        pass
    else:
        raise AssertionError('IndexError not raised')


# Generated at 2022-06-22 16:09:52.039917
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')

# Generated at 2022-06-22 16:09:57.586562
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[2] == 3


# Generated at 2022-06-22 16:10:00.829630
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:10:02.443359
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:10:34.600635
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:10:36.643615
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:46.878520
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:10:58.929328
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'This is a test'
    test_version = '2.9'
    test_object = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_object[0] == 'a'
    assert test_object[1] == 'b'
    assert test_object[2] == 'c'
    assert test_object[-1] == 'c'
    assert test_object[-2] == 'b'
    assert test

# Generated at 2022-06-22 16:11:05.581692
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:11:07.940651
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:16.404902
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = "This is a test message"
    test_version = "2.9"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 16:11:18.835090
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:20.098959
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:27.141287
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:12:33.880947
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), "msg", "version")) == 3


# Generated at 2022-06-22 16:12:41.636990
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:12:44.070219
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:51.671269
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test case 1: value is a list, msg is a string, version is a string
    value = ['a', 'b', 'c']
    msg = 'msg'
    version = 'version'
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version

    # Test case 2: value is a tuple, msg is a string, version is a string
    value = ('a', 'b', 'c')
    msg = 'msg'
    version = 'version'
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version

    # Test

# Generated at 2022-06-22 16:12:54.563890
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:12:58.992991
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:13:04.303071
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:13:13.626577
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for empty sequence
    assert len(_DeprecatedSequenceConstant([], 'msg', 'version')) == 0
    # Test for non-empty sequence
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:13:18.882014
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:25.035980
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class _TestDeprecatedSequenceConstant(_DeprecatedSequenceConstant):
        def __init__(self):
            super(_TestDeprecatedSequenceConstant, self).__init__(value=['a', 'b', 'c'], msg='test', version='2.9')

    test_obj = _TestDeprecatedSequenceConstant()
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:16:08.710685
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert 'test_constant' in globals()
    assert globals()['test_constant'] == 'test_value'

# Generated at 2022-06-22 16:16:15.277780
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:16:16.977919
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:16:18.797350
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')) == 3

# Generated at 2022-06-22 16:16:28.909791
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0') == [1, 2, 3]
    assert _DeprecatedSequenceConstant((1, 2, 3), 'test', '2.0') == (1, 2, 3)
    assert _DeprecatedSequenceConstant({1, 2, 3}, 'test', '2.0') == {1, 2, 3}
    assert _DeprecatedSequenceConstant({1: 'a', 2: 'b', 3: 'c'}, 'test', '2.0') == {1: 'a', 2: 'b', 3: 'c'}
    assert _DeprecatedSequenceConstant(set([1, 2, 3]), 'test', '2.0') == set([1, 2, 3])