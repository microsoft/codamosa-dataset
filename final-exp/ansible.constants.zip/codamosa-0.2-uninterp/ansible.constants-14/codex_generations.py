

# Generated at 2022-06-22 16:06:26.341618
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:31.910082
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a valid index
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.9')
    assert dsc[1] == 2

    # Test with an invalid index
    try:
        dsc[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'

# Generated at 2022-06-22 16:06:43.306968
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_listlike
    from ansible.module_utils.common.collections import is_setlike
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_sequence_of
    from ansible.module_utils.common.collections import is_iterable_of
    from ansible.module_utils.common.collections import is_listlike_of
    from ansible.module_utils.common.collections import is_setlike_of

# Generated at 2022-06-22 16:06:45.322345
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:06:58.168698
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:03.300858
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:07:04.912845
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:07:08.846131
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test constructor of class _DeprecatedSequenceConstant
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(dsc) == 3
    assert dsc[1] == 2


# Generated at 2022-06-22 16:07:15.834147
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:07:17.865948
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:31.305295
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for _DeprecatedSequenceConstant with a list
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'
    assert dsc[-1] == 'c'
    assert dsc[-2] == 'b'
    assert dsc[-3] == 'a'
    assert dsc[0:1] == ['a']
    assert dsc[0:2] == ['a', 'b']
    assert dsc[0:3] == ['a', 'b', 'c']

# Generated at 2022-06-22 16:07:34.236745
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:39.229867
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = [1, 2, 3]
    msg = 'test'
    version = '2.0'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:07:47.623349
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:07:54.704805
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:08:03.185259
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.9'
    value = ['a', 'b', 'c']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]
    assert test_obj[2] == value[2]

# Generated at 2022-06-22 16:08:05.514525
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:08:16.770126
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # This is a private class, so we need to use the name of the class
    # with a leading underscore
    #
    # Create an instance of the class
    dsc = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    #
    # Test the __len__ method
    assert len(dsc) == 2
    #
    # Test the __getitem__ method
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    #
    # Test the __getitem__ method with an invalid index
    try:
        dsc[2]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'


# Generated at 2022-06-22 16:08:24.339970
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test constructor
    dsc = _DeprecatedSequenceConstant(value=['a', 'b'], msg='msg', version='version')
    assert dsc._value == ['a', 'b']
    assert dsc._msg == 'msg'
    assert dsc._version == 'version'

    # test __len__
    assert len(dsc) == 2

    # test __getitem__
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'

# Generated at 2022-06-22 16:08:26.861990
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(list(range(10)), 'msg', 'version')) == 10


# Generated at 2022-06-22 16:08:37.874101
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '1.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:08:45.504665
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:08:53.841496
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'
    set_constant('TEST_CONSTANT', 'test2')
    assert TEST_CONSTANT == 'test2'
    set_constant('TEST_CONSTANT', 'test3', export=globals())
    assert TEST_CONSTANT == 'test3'
    set_constant('TEST_CONSTANT', 'test4', export=locals())
    assert TEST_CONSTANT == 'test3'
    assert locals()['TEST_CONSTANT'] == 'test4'
    del TEST_CONSTANT
    del locals()['TEST_CONSTANT']

# FIXME: remove once play_context mangling is removed
# the magic variable mapping dictionary below is used to translate


# Generated at 2022-06-22 16:09:00.085398
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:09:02.188630
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:09:07.168919
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test message', '2.0')
    assert len(test_value) == 3
    assert test_value[0] == 'a'
    assert test_value[1] == 'b'
    assert test_value[2] == 'c'

# Generated at 2022-06-22 16:09:09.131526
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[0] == 'a'


# Generated at 2022-06-22 16:09:10.977894
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:09:15.502650
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[1] == 2

# Generated at 2022-06-22 16:09:17.310187
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:09:32.401476
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 16:09:36.243583
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:09:47.970958
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR is False
    assert ANSIBLE_HOST_KEY_CHECKING is True
    assert ANSIBLE_NOCOWS is False
    assert ANSIBLE_NOCOLOR is False
    assert ANSIBLE_SSH_ARGS == ''
    assert ANSIBLE_STDOUT_CALLBACK == 'default'
    assert ANSIBLE_RETRY_FILES_ENABLED is True
    assert ANSIBLE_ROLES_PATH == [u'/etc/ansible/roles']
    assert ANSIBLE_SSH_CONTROL_PATH == u'%(directory)s/ansible-ssh-%%h-%%p-%%r'
    assert ANSIBLE_KEEP_REMOTE_FILES is False

# Generated at 2022-06-22 16:09:50.328756
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:09:52.416261
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')) == 3

# Generated at 2022-06-22 16:09:56.685176
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[1] == 'b'


# Generated at 2022-06-22 16:09:57.994141
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:10:00.161777
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:02.108653
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:05.761475
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:10:47.907285
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:10:51.892362
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert 'TEST_CONSTANT' in globals()
    assert globals()['TEST_CONSTANT'] == 'test'


# Generated at 2022-06-22 16:10:59.225768
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version') == ['a', 'b']
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[1] == 'b'

# Generated at 2022-06-22 16:11:00.401996
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:11.561596
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    value = ['a', 'b', 'c']
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'
    assert dsc[-1] == 'c'
    assert dsc[-2] == 'b'
    assert dsc[-3] == 'a'
    assert dsc[0:2] == ['a', 'b']
    assert dsc[1:3] == ['b', 'c']
    assert dsc[-3:-1] == ['a', 'b']
    assert dsc[-2:] == ['b', 'c']
    assert d

# Generated at 2022-06-22 16:11:13.234799
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 16:11:20.207794
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid input
    test_obj = _DeprecatedSequenceConstant(value=['a', 'b'], msg='test', version='2.0')
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    # Test for invalid input
    try:
        test_obj[2]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'


# Generated at 2022-06-22 16:11:23.423364
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test msg'
    test_version = 'test version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:11:27.185691
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for class _DeprecatedSequenceConstant
    test_object = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(test_object) == 3


# Generated at 2022-06-22 16:11:38.730163
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:12:57.922740
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_CONFIG == './ansible.cfg'
    assert ANSIBLE_LIBRARY == '~/.ansible/plugins/modules:/usr/share/ansible/plugins/modules'
    assert ANSIBLE_ROLES_PATH == '/etc/ansible/roles:/usr/share/ansible/roles'
    assert ANSIBLE_SSH_RETRIES == 3
    assert ANSIBLE_STDOUT_CALLBACK == 'default'
    assert ANSIBLE_VERSION == __version__
    assert ANSIBLE_CACHE_PLUGIN == 'memory'
    assert ANSIBLE_CACHE_PLUGIN_CONNECTION == ''
    assert ANSIBLE_CACHE_PLUGIN_PREFIX == 'ansible_facts'
    assert ANSIBLE_CACHE_PLUG

# Generated at 2022-06-22 16:13:01.912683
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:13:04.702879
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:13:07.879089
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'test', '2.0')) == 3

# Generated at 2022-06-22 16:13:18.466531
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz')
    assert FOO == 'baz'
    set_constant('FOO', 'bar', export=globals())
    assert FOO == 'bar'
    set_constant('FOO', 'baz', export=globals())
    assert FOO == 'baz'
    set_constant('FOO', 'bar', export=locals())
    assert FOO == 'bar'
    set_constant('FOO', 'baz', export=locals())
    assert FOO == 'baz'

# FIXME: remove once play_context mangling is removed
# the magic variable mapping dictionary below is used to translate
# host/inventory variables to fields in the PlayContext


# Generated at 2022-06-22 16:13:20.410794
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:26.014756
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a test message"
    version = "2.9"
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]
    assert test_obj[2] == value[2]

# Generated at 2022-06-22 16:13:31.201529
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:13:33.450018
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:13:34.644116
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')
