

# Generated at 2022-06-22 16:06:33.656136
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1,2,3), 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:37.025091
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:06:37.958859
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:44.406734
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:06:47.574756
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'



# Generated at 2022-06-22 16:06:50.254313
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:06:52.724238
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:06:55.341835
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:07:03.525197
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:07:10.022144
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert TREE_DIR is None
    assert VAULT_VERSION_MIN == 1.0
    assert VAULT_VERSION_MAX == 1.0
    assert REJECT_EXTS == ('.pyc', '.pyo', '.swp', '.bak', '~', '.rpm', '.md', '.txt', '.rst')
    assert BOOL_TRUE == BOOLEANS_TRUE
    assert COLLECTION_PTYPE_COMPAT == {'module': 'modules'}
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')

# Generated at 2022-06-22 16:07:17.243959
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)


# Generated at 2022-06-22 16:07:19.762861
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:07:21.760350
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 16:07:23.848646
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:07:24.638473
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 16:07:26.521645
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:07:28.824932
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:07:37.838002
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3, 4]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]


# Generated at 2022-06-22 16:07:42.548469
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3]
    test_msg = "test_msg"
    test_version = "test_version"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)


# Generated at 2022-06-22 16:07:50.897354
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:08:00.184930
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['a', 'b', 'c']
    msg = 'This is a test'
    version = '2.8'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:08:07.002590
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'
    set_constant('test_constant', 'test_value2', export=globals())
    assert test_constant == 'test_value2'
    set_constant('test_constant', 'test_value3', export=locals())
    assert test_constant == 'test_value3'
    set_constant('test_constant', 'test_value4', export=locals())
    assert test_constant == 'test_value4'

# Generated at 2022-06-22 16:08:12.293156
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:08:14.599989
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='1.0')) == 3


# Generated at 2022-06-22 16:08:26.347193
# Unit test for function set_constant
def test_set_constant():
    # Test for setting a constant
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

    # Test for setting a constant with a value that is a string that looks like a template
    set_constant('TEST_CONSTANT_TEMPLATE', '{{TEST_CONSTANT}}')
    assert TEST_CONSTANT_TEMPLATE == 'test'

    # Test for setting a constant with a value that is a string that looks like a template
    # but is not a template
    set_constant('TEST_CONSTANT_TEMPLATE_INVALID', '{{TEST_CONSTANT_INVALID}}')
    assert TEST_CONSTANT_TEMPLATE_INVALID == '{{TEST_CONSTANT_INVALID}}'

# Generated at 2022-06-22 16:08:29.776867
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2

# Generated at 2022-06-22 16:08:36.017719
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.0'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]


# Generated at 2022-06-22 16:08:40.762010
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'
    set_constant('test_constant', 'test_value2', export=locals())
    assert test_constant == 'test_value2'

# Generated at 2022-06-22 16:08:42.833987
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:08:51.710979
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    from io import StringIO
    from ansible.module_utils.common.collections import Sequence

    class _DeprecatedSequenceConstant(Sequence):
        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

        def __len__(self):
            _deprecated(self._msg, self._version)
            return len(self._value)

        def __getitem__(self, y):
            _deprecated(self._msg, self._version)
            return self._value[y]

    # Capture stderr.
    captured_stderr = StringIO()
    sys.stderr = captured_stderr

    # Test __getitem__ method of _DeprecatedSequenceConstant class.
    test_value

# Generated at 2022-06-22 16:09:02.985234
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # Create a _DeprecatedSequenceConstant object
    dsc = _DeprecatedSequenceConstant(['a', 'b'], 'test', '2.9')
    # Check if the object is created correctly
    assert len(dsc) == 2
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'

# Generated at 2022-06-22 16:09:05.467807
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:09:14.441623
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert COLLECTION_PTYPE_COMPAT == {'module': 'modules'}
    assert CONFIGURABLE_PLUGINS == ('become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars')

# Generated at 2022-06-22 16:09:16.640912
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert seq[0] == 1
    assert seq[1] == 2
    assert seq[2] == 3


# Generated at 2022-06-22 16:09:29.032635
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:09:32.569411
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:09:34.626172
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:36.397454
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:38.162555
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:09:44.863111
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:57.604327
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[-1] == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[-2] == 2

# Generated at 2022-06-22 16:09:58.959728
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 16:10:06.673097
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[2] == 3


# Generated at 2022-06-22 16:10:14.541660
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a string
    dsc = _DeprecatedSequenceConstant('test', 'msg', 'version')
    assert dsc[0] == 't'
    assert dsc[1] == 'e'
    assert dsc[2] == 's'
    assert dsc[3] == 't'

    # Test with a list
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

    # Test with a tuple
    dsc = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc

# Generated at 2022-06-22 16:10:17.448884
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:10:19.688248
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:23.148648
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:10:31.957935
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:10:38.469084
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == len(value)
    assert deprecated_sequence_constant[0] == value[0]
    assert deprecated_sequence_constant[1] == value[1]
    assert deprecated_sequence_constant[2] == value[2]

# Generated at 2022-06-22 16:10:46.458702
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:11:04.146409
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for a valid index
    test_obj = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

    # Test for an invalid index
    try:
        test_obj[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'



# Generated at 2022-06-22 16:11:06.516255
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:11:18.148433
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'Test message'
    test_version = '1.0'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

    # Test with a tuple
    test_tuple = ('a', 'b', 'c')
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

    #

# Generated at 2022-06-22 16:11:20.201473
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[], msg='msg', version='version')) == 0


# Generated at 2022-06-22 16:11:25.233679
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_NOCOWS == False
    assert ANSIBLE_NOCOLOR == False
    assert ANSIBLE_FORCE_COLOR == False
    assert ANSIBLE_CALLBACK_WHITELIST == ['default']
    assert ANSIBLE_STDOUT_CALLBACK == 'default'
    assert ANSIBLE_CALLBACK_PLUGINS == 'plugins/callbacks'
    assert ANSIBLE_CALLBACK_PLUGINS_DATADIR == '$ANSIBLE_CALLBACK_PLUGINS/../callback_data'
    assert ANSIBLE_CALLBACK_PLUGINS_DATADIR == 'plugins/callbacks/../callback_data'
    assert ANSIBLE_CALLBACK_PLUGINS_DATADIR == 'plugins/callback_data'
    assert ANSIBLE_CALLBACK

# Generated at 2022-06-22 16:11:29.519732
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['test_value']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'test_value'


# Generated at 2022-06-22 16:11:37.439182
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['test_value']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == 1
    assert test_obj[0] == 'test_value'

# Generated at 2022-06-22 16:11:38.846827
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:11:45.361460
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'This is a test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

# Generated at 2022-06-22 16:11:48.176302
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:12:11.176046
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import unittest

    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def setUp(self):
            self.held, sys.stderr = sys.stderr, io.StringIO()

        def tearDown(self):
            sys.stderr = self.held

        def test_getitem(self):
            dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
            self.assertEqual(dsc[1], 'b')
            self.assertEqual(sys.stderr.getvalue(), ' [DEPRECATED] msg, to be removed in version\n')

    unittest.main()

# Generated at 2022-06-22 16:12:20.181578
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid input
    test_value = [1, 2, 3]
    test_msg = "Test message"
    test_version = "2.0"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

    # Test for invalid input
    try:
        test_obj[3]
    except IndexError:
        pass
    else:
        assert False, "IndexError not raised"



# Generated at 2022-06-22 16:12:21.937849
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[], msg='msg', version='version')) == 0


# Generated at 2022-06-22 16:12:25.540536
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:12:31.903816
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:12:40.769580
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid sequence
    sequence = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert sequence[0] == 'a'
    assert sequence[1] == 'b'
    assert sequence[2] == 'c'

    # Test for invalid sequence
    sequence = _DeprecatedSequenceConstant([], 'msg', 'version')
    try:
        sequence[0]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'



# Generated at 2022-06-22 16:12:44.755161
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:12:49.541705
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = "test_msg"
    test_version = "test_version"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:12:56.524753
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:13:03.616085
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:13:47.398711
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:13:48.548328
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 16:13:49.530905
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2

# Generated at 2022-06-22 16:13:51.203112
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:56.756625
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:14:01.456369
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1


# Generated at 2022-06-22 16:14:07.301692
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.0'
    value = ['a', 'b', 'c']
    test = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test) == len(value)
    assert test[0] == value[0]
    assert test[1] == value[1]
    assert test[2] == value[2]

# Generated at 2022-06-22 16:14:12.606917
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:14:23.248636
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:14:30.964882
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:15:48.873014
# Unit test for function set_constant
def test_set_constant():
    assert 'ANSIBLE_CONFIG' in globals()
    assert 'ANSIBLE_CONFIG' in locals()
    assert 'ANSIBLE_CONFIG' in vars()
    assert ANSIBLE_CONFIG == config.get_config_value('ANSIBLE_CONFIG')
    assert 'ANSIBLE_LOG_PATH' in globals()
    assert 'ANSIBLE_LOG_PATH' in locals()
    assert 'ANSIBLE_LOG_PATH' in vars()
    assert ANSIBLE_LOG_PATH == config.get_config_value('ANSIBLE_LOG_PATH')
    assert 'ANSIBLE_LIBRARY' in globals()
    assert 'ANSIBLE_LIBRARY' in locals()
    assert 'ANSIBLE_LIBRARY' in vars()

# Generated at 2022-06-22 16:15:53.680920
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['test1', 'test2']
    test = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test) == len(value)
    assert test[0] == value[0]
    assert test[1] == value[1]


# Generated at 2022-06-22 16:15:56.524333
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:15:58.893441
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:16:00.607624
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:16:05.085022
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]


# Generated at 2022-06-22 16:16:06.366178
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], '', '')) == 3


# Generated at 2022-06-22 16:16:15.064868
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'
    # Test with a tuple
    dsc = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'
    # Test with a string
    dsc = _DeprecatedSequenceConstant('abc', 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc

# Generated at 2022-06-22 16:16:24.274592
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('test_constant', 'test_value') == {'test_constant': 'test_value'}
    assert set_constant('test_constant', 'test_value', export={'test_constant': 'test_value'}) == {'test_constant': 'test_value'}
    assert set_constant('test_constant', 'test_value', export={'test_constant': 'test_value'}) == {'test_constant': 'test_value'}
    assert set_constant('test_constant', 'test_value', export={'test_constant': 'test_value'}) == {'test_constant': 'test_value'}

# Generated at 2022-06-22 16:16:25.858470
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')