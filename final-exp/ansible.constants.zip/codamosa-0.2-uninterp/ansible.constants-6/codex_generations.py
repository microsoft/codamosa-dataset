

# Generated at 2022-06-22 16:06:33.884191
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:06:35.880458
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:06:38.302114
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:06:39.254721
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:40.049211
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:06:41.089499
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:42.209082
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:49.916200
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = "test_msg"
    test_version = "test_version"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:06:52.580236
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:07:00.725369
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version') == ['a', 'b']
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[1] == 'b'

# Generated at 2022-06-22 16:07:05.218233
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:07:06.906780
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:07:11.060935
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:07:16.045420
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_obj = _DeprecatedSequenceConstant([1, 2, 3], 'test_msg', 'test_version')
    assert len(test_obj) == 3
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

# Generated at 2022-06-22 16:07:19.074392
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:07:26.965721
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:07:29.149595
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_SET_CONSTANT', 'test')
    assert TEST_SET_CONSTANT == 'test'

# Generated at 2022-06-22 16:07:31.506930
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:07:34.684425
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:40.017246
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.0'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:07:46.957185
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:07:51.193122
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = 'test_value'
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]


# Generated at 2022-06-22 16:07:57.132139
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # Create an instance of class _DeprecatedSequenceConstant
    test_instance = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='This is a test', version='2.0')
    # Check the length of the instance
    assert len(test_instance) == 3
    # Check the value of the instance
    assert test_instance[0] == 'a'
    assert test_instance[1] == 'b'
    assert test_instance[2] == 'c'


# Generated at 2022-06-22 16:08:00.405106
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = [1, 2, 3]
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1


# Generated at 2022-06-22 16:08:02.955089
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:08:05.650632
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:07.888175
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'



# Generated at 2022-06-22 16:08:11.436307
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([], '', '')) == 0
    assert len(_DeprecatedSequenceConstant([1, 2, 3], '', '')) == 3


# Generated at 2022-06-22 16:08:13.419569
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:08:19.443449
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['a', 'b', 'c']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]
    assert test_obj[2] == value[2]

# Generated at 2022-06-22 16:08:34.074492
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[-1] == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[-2] == 2

# Generated at 2022-06-22 16:08:42.919673
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:08:51.787742
# Unit test for function set_constant
def test_set_constant():
    assert 'DEFAULT_BECOME_PASS' in globals()
    assert 'DEFAULT_PASSWORD_CHARS' in globals()
    assert 'DEFAULT_REMOTE_PASS' in globals()
    assert 'DEFAULT_SUBSET' in globals()
    assert 'CONFIGURABLE_PLUGINS' in globals()
    assert 'DOCUMENTABLE_PLUGINS' in globals()
    assert 'IGNORE_FILES' in globals()
    assert 'INTERNAL_RESULT_KEYS' in globals()
    assert 'LOCALHOST' in globals()
    assert 'MODULE_REQUIRE_ARGS' in globals()
    assert 'MODULE_NO_JSON' in globals()
    assert 'RESTRICTED_RESULT_KEYS' in globals()

# Generated at 2022-06-22 16:08:55.411344
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(test_obj) == 3


# Generated at 2022-06-22 16:08:57.107572
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:09:08.211155
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:09:14.750779
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class TestClass(object):
        def __init__(self):
            self.value = [1, 2, 3]
            self.msg = 'test message'
            self.version = '2.9'
            self.test = _DeprecatedSequenceConstant(self.value, self.msg, self.version)

        def test(self):
            assert self.test[0] == 1
            assert self.test[1] == 2
            assert self.test[2] == 3

    test = TestClass()
    test.test()

# Generated at 2022-06-22 16:09:15.951522
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 16:09:19.248140
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:09:22.057952
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:09:35.486434
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:09:39.560234
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')) == 3

# Generated at 2022-06-22 16:09:45.783931
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')) == 2
    assert _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')[1] == 'b'

# Generated at 2022-06-22 16:09:46.804339
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:48.745313
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]

# Generated at 2022-06-22 16:09:54.420702
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:10:03.957883
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:10:12.981855
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for __getitem__() when the value is a list
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = 'test version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    # Test for __getitem__() when the value is a tuple
    test_value = ('a', 'b', 'c')
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'


# Generated at 2022-06-22 16:10:23.517725
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

    # Test with a tuple
    dsc = _DeprecatedSequenceConstant(('a', 'b', 'c'), 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

    # Test with a string
    dsc = _DeprecatedSequenceConstant('abc', 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc

# Generated at 2022-06-22 16:10:31.379311
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self, value):
            self.value = value

        def __getitem__(self, y):
            return self.value[y]

    test_obj = Test([1, 2, 3])
    deprecated_obj = _DeprecatedSequenceConstant(test_obj, 'test', '2.0')
    assert deprecated_obj[0] == 1
    assert deprecated_obj[1] == 2
    assert deprecated_obj[2] == 3

# Generated at 2022-06-22 16:10:47.137494
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    value = ['a', 'b', 'c']
    msg = 'msg'
    version = 'version'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant[0] == 'a'
    assert deprecated_sequence_constant[1] == 'b'
    assert deprecated_sequence_constant[2] == 'c'


# Generated at 2022-06-22 16:10:50.092472
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:10:52.861762
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.9')) == 3


# Generated at 2022-06-22 16:10:55.024827
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:11:01.175757
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test that _DeprecatedSequenceConstant.__getitem__() returns the correct value.
    # Arrange
    value = [1, 2, 3]
    msg = 'This is a test message'
    version = '2.0'
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    # Act
    result = test_obj[1]
    # Assert
    assert result == 2


# Generated at 2022-06-22 16:11:06.474431
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant[0] == 1
    assert deprecated_sequence_constant[1] == 2
    assert deprecated_sequence_constant[2] == 3


# Generated at 2022-06-22 16:11:08.694444
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:11:11.474963
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:11:22.862063
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# FIXME: remove once play_context mangling is removed
# the following are used to translate host/inventory variables
# to fields in the PlayContext object.

COMMON_BOOL_VARS = frozenset(('ansible_check_mode', 'ansible_diff'))
COMMON_INT_VARS = frozenset(('ansible_forks', 'ansible_ssh_port', 'ansible_timeout'))

# Generated at 2022-06-22 16:11:24.977051
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2

# Generated at 2022-06-22 16:11:44.100303
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = "test message"
    test_version = "test version"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]


# Generated at 2022-06-22 16:11:51.496477
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for _DeprecatedSequenceConstant.__getitem__()
    # Test with a string
    test_string = 'test_string'
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_sequence = _DeprecatedSequenceConstant(test_string, test_msg, test_version)
    assert test_sequence[0] == 't'
    assert test_sequence[-1] == 'g'
    assert test_sequence[1:3] == 'es'
    assert test_sequence[1:] == 'est_string'
    assert test_sequence[:3] == 'tes'
    assert test_sequence[:] == 'test_string'
    # Test with a list
    test_list = ['test_list_1', 'test_list_2']
    test_

# Generated at 2022-06-22 16:11:54.170221
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    from ansible.module_utils.common.collections import Sequence
    assert len(_DeprecatedSequenceConstant(Sequence(), '', '')) == 0


# Generated at 2022-06-22 16:12:05.718869
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:12:11.403537
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # It should not raise any exception
    try:
        _DeprecatedSequenceConstant(value=None, msg=None, version=None)
    except Exception as e:
        raise AssertionError("Failed to instantiate class _DeprecatedSequenceConstant: %s" % to_text(e))


# Generated at 2022-06-22 16:12:16.949723
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:12:18.851562
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:12:25.003935
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]

# Generated at 2022-06-22 16:12:37.279917
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    value = ['a', 'b', 'c']
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

    # Test with a tuple
    value = ('a', 'b', 'c')
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

    # Test with a string
    value = 'abc'
    msg = 'msg'


# Generated at 2022-06-22 16:12:39.275860
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:12:57.022406
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['value']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert dsc[0] == value[0]
    assert len(dsc) == len(value)

# Generated at 2022-06-22 16:13:02.410452
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 16:13:11.692620
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:13:13.753387
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'



# Generated at 2022-06-22 16:13:20.046376
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:13:24.070284
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:13:26.497979
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'


# Generated at 2022-06-22 16:13:32.887309
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3


# Generated at 2022-06-22 16:13:34.720272
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:36.509890
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:13:56.645423
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:13:58.734124
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:14:04.720000
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.0'
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]
    assert test_obj[2] == value[2]

# Generated at 2022-06-22 16:14:13.763490
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz')
    assert FOO == 'baz'
    set_constant('FOO', 'baz', export=locals())
    assert FOO == 'baz'
    set_constant('FOO', 'baz', export=globals())
    assert FOO == 'baz'
    set_constant('FOO', 'baz', export=locals())
    assert FOO == 'baz'
    set_constant('FOO', 'baz', export=globals())
    assert FOO == 'baz'

# Generated at 2022-06-22 16:14:25.278690
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import xrange
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import url_argument_spec
    from ansible.module_utils.urls import url_filename
    from ansible.module_utils.urls import url_get
    from ansible.module_utils.urls import url_get_

# Generated at 2022-06-22 16:14:30.161380
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)


# Generated at 2022-06-22 16:14:39.814705
# Unit test for function set_constant
def test_set_constant():
    # Test that set_constant works as expected
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

    # Test that set_constant works as expected with a dict
    set_constant('test_constant_2', 'test_value_2', export={'test_constant_2': 'test_value_2'})
    assert test_constant_2 == 'test_value_2'

    # Test that set_constant works as expected with a dict
    set_constant('test_constant_3', 'test_value_3', export=globals())
    assert test_constant_3 == 'test_value_3'

# Generated at 2022-06-22 16:14:42.351350
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:14:44.686354
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:51.050795
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[0] == 1
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:15:06.958222
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a test message"
    version = "2.9"
    test_obj = _DeprecatedSequenceConstant([1, 2, 3], msg, version)
    assert len(test_obj) == 3
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

# Generated at 2022-06-22 16:15:12.331198
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:15:13.878629
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:15:18.519069
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'
    set_constant('test_constant', 'test_value2', export=globals())
    assert test_constant == 'test_value2'

# Generated at 2022-06-22 16:15:29.002031
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.9'
    test_object = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_object[0] == 'a'
    assert test_object[-1] == 'c'
    assert test_object[1:3] == ['b', 'c']
    assert test_object[::-1] == ['c', 'b', 'a']
    # Test with a tuple
    test_tuple = ('a', 'b', 'c')
    test_object = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert test_object[0] == 'a'
   

# Generated at 2022-06-22 16:15:31.485327
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'


# Generated at 2022-06-22 16:15:33.679115
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'



# Generated at 2022-06-22 16:15:35.741243
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:15:37.685962
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:15:39.798847
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:16:20.567102
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:16:26.774784
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]
