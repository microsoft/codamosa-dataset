

# Generated at 2022-06-22 16:06:36.929893
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_PASSWORD_CHARS == u'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:-_'
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert DOCUMENTABLE_PLUGINS == ('become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars', 'module', 'strategy')
    assert IGNORE_FILES == ('COPYING', 'CONTRIBUTING', 'LICENSE', 'README', 'VERSION', 'GUIDELINES')
    assert INTERNAL_RESULT_KEYS

# Generated at 2022-06-22 16:06:42.701678
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz')
    assert FOO == 'baz'
    set_constant('FOO', 'baz', export=dict())
    assert FOO == 'baz'
    assert 'FOO' not in globals()
    assert 'FOO' not in locals()

# Generated at 2022-06-22 16:06:45.326370
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1


# Generated at 2022-06-22 16:06:46.289165
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:51.882338
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3, 4]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_object) == len(test_value)


# Generated at 2022-06-22 16:06:54.752583
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:55.818612
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.9')) == 3


# Generated at 2022-06-22 16:06:57.386971
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'

# Generated at 2022-06-22 16:07:03.029829
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Create a _DeprecatedSequenceConstant object
    seq = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')
    # Test __getitem__
    assert seq[0] == 1
    assert seq[1] == 2
    assert seq[2] == 3
    # Test __len__
    assert len(seq) == 3


# Generated at 2022-06-22 16:07:14.051036
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version') == ['a', 'b', 'c']
    assert len(_DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')) == 3
    assert _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')[0] == 'a'
    assert _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')[1] == 'b'
    assert _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')[2] == 'c'


# Generated at 2022-06-22 16:07:23.848704
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for a valid index
    test_obj = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert test_obj[0] == 1

    # Test for an invalid index
    try:
        test_obj[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'



# Generated at 2022-06-22 16:07:33.257018
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert COLLECTION_PTYPE_COMPAT == {'module': 'modules'}
    assert CONFIGURABLE_PLUGINS == ('become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars')

# Generated at 2022-06-22 16:07:39.477769
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for _DeprecatedSequenceConstant.__getitem__
    # Arrange
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)

    # Act
    result = dsc[1]

    # Assert
    assert result == value[1]


# Generated at 2022-06-22 16:07:41.733070
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:43.712403
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:07:46.102449
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'


# Generated at 2022-06-22 16:07:55.754444
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = 'test version'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    assert test_obj[-1] == 'c'
    assert test_obj[-2] == 'b'
    assert test_obj[-3] == 'a'
    assert test_obj[0:2] == ['a', 'b']
    assert test_obj[1:3] == ['b', 'c']

# Generated at 2022-06-22 16:08:02.770297
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:08:10.835280
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 16:08:13.259216
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:26.666333
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'
    set_constant('test_constant', 'test_value2', export=globals())
    assert test_constant == 'test_value2'
    set_constant('test_constant', 'test_value3', export=locals())
    assert test_constant == 'test_value3'

# Generated at 2022-06-22 16:08:29.191670
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:35.925055
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid sequence
    test_sequence = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert test_sequence[0] == 'a'
    assert test_sequence[1] == 'b'
    assert test_sequence[2] == 'c'

    # Test for invalid sequence
    try:
        test_sequence[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'

# Generated at 2022-06-22 16:08:39.731423
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test', '2.0')
    assert seq[0] == 'a'
    assert seq[1] == 'b'
    assert seq[2] == 'c'


# Generated at 2022-06-22 16:08:44.854794
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import unittest

    class Test__DeprecatedSequenceConstant___getitem__(unittest.TestCase):
        def test_with_valid_input(self):
            value = ['a', 'b', 'c']
            msg = 'msg'
            version = 'version'
            dsc = _DeprecatedSequenceConstant(value, msg, version)
            self.assertEqual(dsc[0], 'a')
            self.assertEqual(dsc[1], 'b')
            self.assertEqual(dsc[2], 'c')

    unittest.main()

# Generated at 2022-06-22 16:08:46.828343
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:52.943160
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid value
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

    # Test for invalid value
    try:
        dsc[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'


# Generated at 2022-06-22 16:08:59.202004
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz', export=globals())
    assert FOO == 'baz'
    set_constant('FOO', 'bam', export=locals())
    assert FOO == 'baz'
    assert locals()['FOO'] == 'bam'
    assert globals()['FOO'] == 'baz'

# Generated at 2022-06-22 16:09:01.873062
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:05.368855
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test'
    version = '2.0'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:09:24.487376
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:09:27.678399
# Unit test for function set_constant
def test_set_constant():
    '''
    Test set_constant function
    '''
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'



# Generated at 2022-06-22 16:09:33.208331
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class _TestDeprecatedSequenceConstant(_DeprecatedSequenceConstant):
        def __init__(self, value, msg, version):
            super(_TestDeprecatedSequenceConstant, self).__init__(value, msg, version)

    test_value = ['test_value']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_deprecated_sequence_constant = _TestDeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_deprecated_sequence_constant[0] == test_value[0]


# Generated at 2022-06-22 16:09:39.757280
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a valid index
    test_obj = _DeprecatedSequenceConstant(value=('a', 'b', 'c'), msg='msg', version='version')
    assert test_obj[1] == 'b'

    # Test with an invalid index
    test_obj = _DeprecatedSequenceConstant(value=('a', 'b', 'c'), msg='msg', version='version')
    try:
        test_obj[3]
    except IndexError:
        assert True
    else:
        assert False, 'IndexError not raised'


# Generated at 2022-06-22 16:09:42.980106
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:47.663800
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3

# Generated at 2022-06-22 16:09:50.083966
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:59.540215
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    value = ['a', 'b', 'c']
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'
    # Test with a tuple
    value = ('a', 'b', 'c')
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:10:05.974365
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:10:11.311607
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:10:53.501600
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:10:56.444495
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')) == 3


# Generated at 2022-06-22 16:10:58.556184
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:07.722094
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:11:19.598711
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'This is a test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    # Test with a tuple
    test_tuple = ('a', 'b', 'c')
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test

# Generated at 2022-06-22 16:11:24.469629
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[1] == test_value[1]


# Generated at 2022-06-22 16:11:31.866541
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]


# Generated at 2022-06-22 16:11:34.506567
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:11:36.803785
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:11:40.640662
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:12:55.912074
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'this is a test'
    version = '2.0'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:12:57.953722
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:05.771095
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:13:12.207328
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = 'value'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]


# Generated at 2022-06-22 16:13:17.468969
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3
    assert len(test_obj) == 3

# Generated at 2022-06-22 16:13:27.101720
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # with empty string
    try:
        _DeprecatedSequenceConstant('', '', '')
    except Exception:
        pass
    else:
        raise AssertionError("Expected an exception")

    # Test for constructor of class _DeprecatedSequenceConstant
    # with empty string
    try:
        _DeprecatedSequenceConstant([], '', '')
    except Exception:
        pass
    else:
        raise AssertionError("Expected an exception")

    # Test for constructor of class _DeprecatedSequenceConstant
    # with empty string
    try:
        _DeprecatedSequenceConstant([], '', '')
    except Exception:
        pass
    else:
        raise AssertionError("Expected an exception")

    # Test for

# Generated at 2022-06-22 16:13:34.828031
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a test message"
    version = "2.9"
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version
    assert len(test_obj) == 3
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3


# Generated at 2022-06-22 16:13:36.855777
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('test_set_constant', 'test_set_constant') == {'test_set_constant': 'test_set_constant'}


# Generated at 2022-06-22 16:13:47.780095
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR is False
    assert ANSIBLE_HOST_KEY_CHECKING is True
    assert ANSIBLE_NOCOLOR is False
    assert ANSIBLE_NOCOWS is False
    assert ANSIBLE_SSH_ARGS == ''
    assert ANSIBLE_SSH_CONTROL_PATH == '%(directory)s/ansible-ssh-%%h-%%p-%%r'
    assert ANSIBLE_SSH_PIPELINING is True
    assert ANSIBLE_STDOUT_CALLBACK == 'default'
    assert ANSIBLE_TRANSFER_METHOD == 'smart'
    assert ANSIBLE_VAULT_PASSWORD_FILE == ''
    assert ANSIBLE_VERSION == __version__
    assert ANSIBLE_WARNINGS_FILTER == []

# Generated at 2022-06-22 16:13:49.388963
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
