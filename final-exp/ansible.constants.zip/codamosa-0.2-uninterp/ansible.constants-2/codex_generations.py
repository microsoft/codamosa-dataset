

# Generated at 2022-06-22 16:06:32.566172
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == len(value)
    assert deprecated_sequence_constant[0] == value[0]

# Generated at 2022-06-22 16:06:34.606902
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2), 'msg', 'version')) == 2

# Generated at 2022-06-22 16:06:45.649034
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:06:52.956912
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant[0] == value[0]
    assert deprecated_sequence_constant[1] == value[1]
    assert deprecated_sequence_constant[2] == value[2]


# Generated at 2022-06-22 16:07:02.025513
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:07:06.870882
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[1] == 'b'

# Generated at 2022-06-22 16:07:18.330227
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:30.158241
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:32.907438
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:07:39.187099
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:07:47.875012
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'
    assert len(dsc) == 3


# Generated at 2022-06-22 16:07:53.047188
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['test1', 'test2']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 2
    assert dsc[0] == 'test1'
    assert dsc[1] == 'test2'


# Generated at 2022-06-22 16:07:57.812890
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:08:06.939077
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import unittest

    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def setUp(self):
            self.held, sys.stderr = sys.stderr, io.StringIO()

        def tearDown(self):
            sys.stderr = self.held

        def test_getitem(self):
            dsc = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
            self.assertEqual(dsc[0], 'a')
            self.assertEqual(dsc[1], 'b')
            self.assertEqual(sys.stderr.getvalue(), '[DEPRECATED] msg, to be removed in version\n')

    unittest.main()

# Generated at 2022-06-22 16:08:14.718022
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = "test message"
    test_version = "test version"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]


# Generated at 2022-06-22 16:08:24.234572
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:08:28.949971
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'
    set_constant('TEST_CONSTANT', 'test_value2', export=globals())
    assert TEST_CONSTANT == 'test_value2'

# Generated at 2022-06-22 16:08:36.041617
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:08:38.023365
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:08:46.394280
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:08:54.672235
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:09:00.679853
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3


# Generated at 2022-06-22 16:09:02.659694
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:09:09.042046
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'Test', '1.0') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'Test', '1.0')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'Test', '1.0')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'Test', '1.0')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'Test', '1.0')[2] == 3


# Generated at 2022-06-22 16:09:11.249617
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:09:12.955190
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:09:15.295547
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    constant = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test', '2.0')
    assert len(constant) == 3


# Generated at 2022-06-22 16:09:17.134350
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:09:20.282674
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_object) == len(test_value)
    assert test_object[1] == test_value[1]

# Generated at 2022-06-22 16:09:22.934840
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'


# Generated at 2022-06-22 16:09:32.425506
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 'foo')
    assert ANSIBLE_TEST_CONSTANT == 'foo'


# Generated at 2022-06-22 16:09:38.200682
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid input
    test_obj = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='test', version='2.0')
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

    # Test for invalid input
    try:
        test_obj[3]
    except IndexError:
        pass
    else:
        raise AssertionError('IndexError not raised')


# Generated at 2022-06-22 16:09:45.784221
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = 'test version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:09:54.045572
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:09:59.239268
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.10') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.10')[0] == 1
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.10')) == 3

# Generated at 2022-06-22 16:10:01.207394
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:03.092696
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:10:13.308863
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

    # Test with a tuple
    test_tuple = (1, 2, 3)
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2

# Generated at 2022-06-22 16:10:15.598456
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:10:19.224533
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_sequence = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test_msg', 'test_version')
    assert len(test_sequence) == 3


# Generated at 2022-06-22 16:10:28.495684
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('FOO', 'bar') == {'FOO': 'bar'}


# Generated at 2022-06-22 16:10:32.745189
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:34.270394
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:40.144559
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

        def __len__(self):
            _deprecated(self._msg, self._version)
            return len(self._value)

        def __getitem__(self, y):
            _deprecated(self._msg, self._version)
            return self._value[y]

    test = Test([1, 2, 3], 'msg', 'version')
    assert test[0] == 1
    assert test[1] == 2
    assert test[2] == 3

# Generated at 2022-06-22 16:10:47.504118
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:10:57.617771
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    l = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(l, 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'
    # Test with a tuple
    t = ('a', 'b', 'c')
    dsc = _DeprecatedSequenceConstant(t, 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:11:03.299846
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:11:05.702160
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'



# Generated at 2022-06-22 16:11:08.023402
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:11:10.095026
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:25.234309
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'
    set_constant('TEST_CONSTANT', 'test2')
    assert TEST_CONSTANT == 'test2'
    set_constant('TEST_CONSTANT', 'test3', export=globals())
    assert TEST_CONSTANT == 'test3'
    set_constant('TEST_CONSTANT', 'test4', export=locals())
    assert TEST_CONSTANT == 'test3'
    set_constant('TEST_CONSTANT', 'test5', export=globals())
    assert TEST_CONSTANT == 'test5'
    set_constant('TEST_CONSTANT', 'test6', export=locals())
    assert TEST_CONST

# Generated at 2022-06-22 16:11:27.674571
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

# Generated at 2022-06-22 16:11:31.026692
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1


# Generated at 2022-06-22 16:11:37.229352
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:11:42.569041
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == len(value)
    assert deprecated_sequence_constant[0] == value[0]

# Generated at 2022-06-22 16:11:53.943037
# Unit test for function set_constant
def test_set_constant():
    assert 'ANSIBLE_CONFIG' in globals()
    assert 'ANSIBLE_HOST_KEY_CHECKING' in globals()
    assert 'ANSIBLE_INVENTORY' in globals()
    assert 'ANSIBLE_LIBRARY' in globals()
    assert 'ANSIBLE_MODULE_UTILS' in globals()
    assert 'ANSIBLE_ROLES_PATH' in globals()
    assert 'ANSIBLE_SSH_ARGS' in globals()
    assert 'ANSIBLE_STDOUT_CALLBACK' in globals()
    assert 'ANSIBLE_TRANSPORT' in globals()
    assert 'ANSIBLE_VAULT_PASSWORD_FILE' in globals()
    assert 'ANSIBLE_VERBOSITY' in globals()
    assert 'ANSIBLE_VERSION' in globals()

# Generated at 2022-06-22 16:11:55.582403
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:11:57.738252
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:12:03.773203
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[2] == 3


# Generated at 2022-06-22 16:12:06.204020
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')) == 3


# Generated at 2022-06-22 16:12:18.280077
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[1] == 'b'


# Generated at 2022-06-22 16:12:22.335639
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:12:25.450646
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1

# Generated at 2022-06-22 16:12:32.472862
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test constructor
    dsc = _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')
    assert dsc._value == ['a', 'b']
    assert dsc._msg == 'msg'
    assert dsc._version == 'version'

    # Test __len__
    assert len(dsc) == 2

    # Test __getitem__
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'

# Generated at 2022-06-22 16:12:44.546579
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_obj = _DeprecatedSequenceConstant(test_list, 'msg', 'version')
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    assert test_obj[-1] == 'c'
    assert test_obj[-2] == 'b'
    assert test_obj[-3] == 'a'
    # Test with a tuple
    test_tuple = ('a', 'b', 'c')
    test_obj = _DeprecatedSequenceConstant(test_tuple, 'msg', 'version')
    assert test_obj[0] == 'a'

# Generated at 2022-06-22 16:12:51.934548
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'
    set_constant('foo', 'baz')
    assert foo == 'baz'
    set_constant('foo', 'baz', export=globals())
    assert foo == 'baz'
    set_constant('foo', 'baz', export=locals())
    assert foo == 'baz'
    set_constant('foo', 'baz', export=locals())
    assert foo == 'baz'
    set_constant('foo', 'baz', export=locals())
    assert foo == 'baz'
    set_constant('foo', 'baz', export=locals())
    assert foo == 'baz'
    set_constant('foo', 'baz', export=locals())
    assert foo

# Generated at 2022-06-22 16:12:56.614609
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:12:57.911110
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([], '', ''), Sequence)

# Generated at 2022-06-22 16:13:02.249414
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:13:05.073447
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:13:38.412142
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:13:40.767610
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:13:43.050189
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:46.906679
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:13:50.951195
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.0'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:14:00.581525
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:14:06.608995
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:14:09.720948
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz', export=globals())
    assert FOO == 'baz'

# Generated at 2022-06-22 16:14:15.027130
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for a valid index
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')
    assert dsc[1] == 2
    # Test for an invalid index
    try:
        dsc[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'


# Generated at 2022-06-22 16:14:17.641959
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:15:16.096244
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = 'test_value'
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 16:15:20.924778
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    c = _DeprecatedSequenceConstant(value=('a', 'b', 'c'), msg='test', version='2.0')
    assert c[0] == 'a'
    assert c[1] == 'b'
    assert c[2] == 'c'


# Generated at 2022-06-22 16:15:29.354659
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'This is a test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:15:34.594609
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.9'
    value = ['a', 'b', 'c']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:15:36.241425
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'

# Generated at 2022-06-22 16:15:38.550196
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:15:40.662719
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:15:48.936804
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:15:56.658930
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:15:58.575538
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], '', '')) == 3
