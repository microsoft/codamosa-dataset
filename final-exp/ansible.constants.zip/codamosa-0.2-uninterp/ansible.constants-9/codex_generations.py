

# Generated at 2022-06-22 16:06:29.915726
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:06:35.431860
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:06:38.302077
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(('a', 'b'), 'msg', 'version')) == 2


# Generated at 2022-06-22 16:06:40.566774
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:45.487500
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == len(value)
    assert deprecated_sequence_constant[0] == value[0]

# Generated at 2022-06-22 16:06:48.292249
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:06:50.474606
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:07:02.568169
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == test_list[0]
    assert test_obj[1] == test_list[1]
    assert test_obj[2] == test_list[2]
    # Test with a tuple
    test_tuple = (1, 2, 3)
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert test_obj[0] == test_tuple[0]
    assert test_obj[1] == test_tuple[1]
   

# Generated at 2022-06-22 16:07:06.767158
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:07:08.901128
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:07:16.406938
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:18.371021
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:27.917304
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:07:34.242665
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:07:36.920489
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'


# Generated at 2022-06-22 16:07:40.122976
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:07:41.644818
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'

# Generated at 2022-06-22 16:07:43.632560
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:07:47.875222
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

# Generated at 2022-06-22 16:07:50.238830
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:08:05.841265
# Unit test for function set_constant
def test_set_constant():
    assert ANSIBLE_FORCE_COLOR is True
    assert ANSIBLE_HOST_KEY_CHECKING is True
    assert ANSIBLE_NOCOLOR is False
    assert ANSIBLE_SSH_PIPELINING is True
    assert ANSIBLE_STDOUT_CALLBACK is 'default'
    assert ANSIBLE_TRANSPORT is 'smart'
    assert ANSIBLE_VERBOSITY is 0
    assert ANSIBLE_VERSION is __version__
    assert ANSIBLE_INTERNAL_TEMPLATE_ENGINE is False
    assert ANSIBLE_INTERNAL_TASK_SERIALIZATION is False
    assert ANSIBLE_INTERNAL_TASK_RESULT_CACHE is False
    assert ANSIBLE_INTERNAL_TASK_CACHE is False


# Generated at 2022-06-22 16:08:07.631010
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:08:10.241756
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:21.585442
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:08:23.991126
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:30.302746
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert seq[0] == 'a'
    assert seq[1] == 'b'
    assert seq[2] == 'c'
    assert seq[-1] == 'c'
    assert seq[-2] == 'b'
    assert seq[-3] == 'a'


# Generated at 2022-06-22 16:08:37.845365
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_SUBSET == 'all'
    assert DEFAULT_BECOME_PASS == None
    assert DEFAULT_REMOTE_PASS == None
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')

# Generated at 2022-06-22 16:08:41.331966
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:08:48.453677
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid index
    constant = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')
    assert constant[0] == 'a'
    assert constant[1] == 'b'
    assert constant[2] == 'c'

    # Test for invalid index
    constant = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')
    try:
        constant[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'



# Generated at 2022-06-22 16:08:50.430147
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'



# Generated at 2022-06-22 16:09:06.279135
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test constructor
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version

    # Test __len__
    assert len(test_obj) == len(test_value)

    # Test __getitem__
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 16:09:11.436323
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[1] == 'b'
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[2] == 'c'


# Generated at 2022-06-22 16:09:18.488642
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = [1, 2, 3]
    test_msg = "test message"
    test_version = "test version"
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

    # Test with a tuple
    test_tuple = (1, 2, 3)
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

    # Test with a string
    test_string = "123"
    test_

# Generated at 2022-06-22 16:09:25.134132
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:09:26.100474
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:09:28.292186
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')) == 3


# Generated at 2022-06-22 16:09:31.992183
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:34.791144
# Unit test for function set_constant
def test_set_constant():
    assert 'ANSIBLE_CONFIG' in vars()
    assert 'ANSIBLE_CONFIG' in globals()
    assert 'ANSIBLE_CONFIG' in locals()
    assert 'ANSIBLE_CONFIG' in dir()

# Generated at 2022-06-22 16:09:39.847794
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = 'test version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:09:46.699097
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version') == ['a', 'b']
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[1] == 'b'

# Generated at 2022-06-22 16:10:12.983697
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    assert test_obj[-1] == 'c'
    assert test_obj[-2] == 'b'
    assert test_obj[-3] == 'a'
    assert test_obj[0:1] == ['a']
    assert test_obj[0:2] == ['a', 'b']

# Generated at 2022-06-22 16:10:18.899726
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz', export=globals())
    assert FOO == 'baz'
    set_constant('FOO', 'bam', export=locals())
    assert FOO == 'baz'
    assert locals()['FOO'] == 'bam'
    set_constant('FOO', 'baz', export=globals())
    assert FOO == 'baz'
    assert locals()['FOO'] == 'bam'
    set_constant('FOO', 'bam', export=locals())
    assert FOO == 'baz'
    assert locals()['FOO'] == 'bam'

# Generated at 2022-06-22 16:10:21.078160
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:10:32.730696
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'
    set_constant('TEST_CONSTANT', 'new_value')
    assert TEST_CONSTANT == 'new_value'
    set_constant('TEST_CONSTANT', 'new_value', export=globals())
    assert TEST_CONSTANT == 'new_value'
    set_constant('TEST_CONSTANT', 'new_value', export=locals())
    assert TEST_CONSTANT == 'new_value'
    set_constant('TEST_CONSTANT', 'new_value', export=locals())
    assert TEST_CONSTANT == 'new_value'

# Generated at 2022-06-22 16:10:35.003981
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:42.431798
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:10:44.576316
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:46.248107
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:10:48.778810
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'test', '1.0')) == 3


# Generated at 2022-06-22 16:10:53.978085
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]

# Generated at 2022-06-22 16:11:36.330681
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.10') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.10')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.10')) == 3

# Generated at 2022-06-22 16:11:38.537012
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:11:44.820644
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'test', '2.0')) == 2
    assert _DeprecatedSequenceConstant(['a', 'b'], 'test', '2.0')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'test', '2.0')[1] == 'b'


# Generated at 2022-06-22 16:11:52.898000
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = 'test version'
    test_constant = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_constant) == len(test_value)
    assert test_constant[0] == test_value[0]
    assert test_constant[1] == test_value[1]
    assert test_constant[2] == test_value[2]

# Generated at 2022-06-22 16:11:55.097252
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:12:07.385815
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'This is a test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    # Test with a tuple
    test_tuple = ('a', 'b', 'c')
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test

# Generated at 2022-06-22 16:12:14.456434
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = '2.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]


# Generated at 2022-06-22 16:12:17.518164
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:12:20.092103
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:12:24.462349
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.0'
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]

# Generated at 2022-06-22 16:13:46.946029
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:13:48.121147
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar')
    assert foo == 'bar'

# Generated at 2022-06-22 16:13:53.068843
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # Arrange
    value = [1, 2, 3]
    msg = 'test message'
    version = '2.0'
    # Act
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    # Assert
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version


# Generated at 2022-06-22 16:14:03.159578
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:14:05.185410
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:07.558944
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 'foo')
    assert ANSIBLE_TEST_CONSTANT == 'foo'

# Generated at 2022-06-22 16:14:09.846367
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '1.0')) == 3


# Generated at 2022-06-22 16:14:17.282804
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['test_value']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == 1
    assert test_obj[0] == 'test_value'

# Generated at 2022-06-22 16:14:28.336036
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:14:30.671434
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
