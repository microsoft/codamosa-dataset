

# Generated at 2022-06-22 16:06:37.025521
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['test_value']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_object = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_object[0] == 'test_value'


# Generated at 2022-06-22 16:06:39.357606
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:06:47.340211
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == 2
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'

# Generated at 2022-06-22 16:06:49.644020
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "This is a test message"
    version = "2.0"
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

# Generated at 2022-06-22 16:06:52.265906
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:03.971844
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for a list
    test_list = ['a', 'b', 'c']
    test_msg = 'Test message'
    test_version = '2.9'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    assert test_obj[-1] == 'c'
    assert test_obj[-2] == 'b'
    assert test_obj[-3] == 'a'

    # Test for a tuple
    test_tuple = ('a', 'b', 'c')
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)

# Generated at 2022-06-22 16:07:15.352406
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_obj = _DeprecatedSequenceConstant(test_list, 'test_msg', '2.9')
    assert len(test_obj) == len(test_list)

    # Test with a tuple
    test_tuple = ('a', 'b', 'c')
    test_obj = _DeprecatedSequenceConstant(test_tuple, 'test_msg', '2.9')
    assert len(test_obj) == len(test_tuple)

    # Test with a string
    test_string = 'abc'
    test_obj = _DeprecatedSequenceConstant(test_string, 'test_msg', '2.9')
    assert len(test_obj) == len(test_string)

    # Test with

# Generated at 2022-06-22 16:07:22.658306
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = [1, 2, 3]
    test_msg = "This is a test message"
    test_version = "2.0"
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == test_list[0]
    assert test_obj[1] == test_list[1]
    assert test_obj[2] == test_list[2]

    # Test with a tuple
    test_tuple = (1, 2, 3)
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert test_obj[0] == test_tuple[0]
    assert test_obj[1] == test_tuple[1]

# Generated at 2022-06-22 16:07:32.560326
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'
    set_constant('FOO', 'BAR2')
    assert FOO == 'BAR2'
    set_constant('FOO', 'BAR3', export=locals())
    assert FOO == 'BAR3'
    assert locals()['FOO'] == 'BAR3'
    set_constant('FOO', 'BAR4', export=globals())
    assert FOO == 'BAR4'
    assert globals()['FOO'] == 'BAR4'
    set_constant('FOO', 'BAR5', export=locals())
    assert FOO == 'BAR5'
    assert locals()['FOO'] == 'BAR5'

# Generated at 2022-06-22 16:07:36.087895
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:52.154807
# Unit test for function set_constant
def test_set_constant():
    set_constant('ANSIBLE_TEST_CONSTANT', 'foo')
    assert ANSIBLE_TEST_CONSTANT == 'foo'
    set_constant('ANSIBLE_TEST_CONSTANT', 'bar')
    assert ANSIBLE_TEST_CONSTANT == 'bar'
    set_constant('ANSIBLE_TEST_CONSTANT', 'baz', export=globals())
    assert ANSIBLE_TEST_CONSTANT == 'baz'
    set_constant('ANSIBLE_TEST_CONSTANT', 'qux', export=locals())
    assert ANSIBLE_TEST_CONSTANT == 'qux'
    set_constant('ANSIBLE_TEST_CONSTANT', 'quux', export=vars())
    assert ANSIBLE_TEST_CON

# Generated at 2022-06-22 16:07:54.203626
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:57.596712
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:08:03.275216
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for _DeprecatedSequenceConstant
    msg = 'This is a test message'
    version = '2.0'
    test_value = ['test1', 'test2']
    test_obj = _DeprecatedSequenceConstant(test_value, msg, version)
    assert test_obj[0] == 'test1'
    assert test_obj[1] == 'test2'


# Generated at 2022-06-22 16:08:07.545672
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:08:12.001706
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:08:14.316845
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1


# Generated at 2022-06-22 16:08:16.294352
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:19.266057
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test_msg', version='test_version')
    assert len(test_obj) == 3


# Generated at 2022-06-22 16:08:21.722078
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:08:34.731511
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:39.344561
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:08:43.648644
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid index
    test_value = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert test_value[0] == 1
    assert test_value[1] == 2
    assert test_value[2] == 3

    # Test for invalid index
    try:
        test_value[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'



# Generated at 2022-06-22 16:08:45.774000
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:08:47.610400
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'


# Generated at 2022-06-22 16:08:51.416612
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:08:52.520182
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([], '', ''), Sequence)

# Generated at 2022-06-22 16:08:56.735910
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_sequence = _DeprecatedSequenceConstant([1, 2, 3], 'test_msg', 'test_version')
    assert test_sequence[0] == 1
    assert test_sequence[1] == 2
    assert test_sequence[2] == 3


# Generated at 2022-06-22 16:09:07.865504
# Unit test for function set_constant
def test_set_constant():
    assert 'DEFAULT_BECOME_PASS' in vars()
    assert 'DEFAULT_PASSWORD_CHARS' in vars()
    assert 'DEFAULT_REMOTE_PASS' in vars()
    assert 'DEFAULT_SUBSET' in vars()
    assert 'CONFIGURABLE_PLUGINS' in vars()
    assert 'DOCUMENTABLE_PLUGINS' in vars()
    assert 'IGNORE_FILES' in vars()
    assert 'INTERNAL_RESULT_KEYS' in vars()
    assert 'LOCALHOST' in vars()
    assert 'MODULE_REQUIRE_ARGS' in vars()
    assert 'MODULE_NO_JSON' in vars()
    assert 'RESTRICTED_RESULT_KEYS' in vars()

# Generated at 2022-06-22 16:09:09.845857
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:31.415454
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:09:35.440971
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_obj = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test_msg', '2.0')
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:09:46.887367
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    import unittest

    class Test__DeprecatedSequenceConstant___getitem__(unittest.TestCase):
        def setUp(self):
            self.held, sys.stderr = sys.stderr, io.StringIO()
            self.dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')

        def tearDown(self):
            sys.stderr = self.held

        def test_getitem(self):
            self.assertEqual(self.dsc[0], 'a')
            self.assertEqual(self.dsc[1], 'b')
            self.assertEqual(self.dsc[2], 'c')


# Generated at 2022-06-22 16:09:49.381224
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:09:51.516856
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:09:53.871049
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:09:55.212456
# Unit test for function set_constant
def test_set_constant():
    set_constant('test', 'test')
    assert test == 'test'

# Generated at 2022-06-22 16:09:57.392533
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2

# Generated at 2022-06-22 16:10:00.627091
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(value=('a', 'b', 'c'), msg='msg', version='version')
    assert seq[0] == 'a'
    assert seq[1] == 'b'
    assert seq[2] == 'c'


# Generated at 2022-06-22 16:10:10.056802
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text

    # Test for valid input
    test_obj = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

    # Test for invalid input
    try:
        test_obj[3]
    except IndexError:
        pass
    else:
        raise AssertionError("IndexError not raised")

    # Test for invalid input
    try:
        test_obj[-1]
    except IndexError:
        pass

# Generated at 2022-06-22 16:10:33.384383
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'
    set_constant('test_constant', 'test_value2', export=globals())
    assert test_constant == 'test_value2'
    set_constant('test_constant', 'test_value3', export=locals())
    assert test_constant == 'test_value3'
    set_constant('test_constant', 'test_value4', export=globals())
    assert test_constant == 'test_value4'
    set_constant('test_constant', 'test_value5', export=locals())
    assert test_constant == 'test_value5'

# Generated at 2022-06-22 16:10:42.456507
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for _DeprecatedSequenceConstant.__getitem__(y)
    # Test for _DeprecatedSequenceConstant.__getitem__(y) when y is a valid index
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[1] == 2
    # Test for _DeprecatedSequenceConstant.__getitem__(y) when y is a invalid index
    try:
        _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[3]
    except IndexError:
        pass
    else:
        raise AssertionError('IndexError not raised')


# Generated at 2022-06-22 16:10:46.405449
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['value']
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == 1
    assert deprecated_sequence_constant[0] == 'value'

# Generated at 2022-06-22 16:10:48.932841
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:51.938701
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:57.297796
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = 'value'
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant._value == value
    assert deprecated_sequence_constant._msg == msg
    assert deprecated_sequence_constant._version == version

# Generated at 2022-06-22 16:11:01.543848
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]

# Generated at 2022-06-22 16:11:12.841671
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test case 1:
    #   _DeprecatedSequenceConstant(value, msg, version)
    #   value: a list
    #   msg: a string
    #   version: a string
    #   Expected result:
    #       The length of the list is returned
    #       The msg is printed
    #       The version is printed
    #       The list is returned
    test_list = ['a', 'b', 'c']
    test_msg = 'This is a test message'
    test_version = '2.9'
    test_case = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert len(test_case) == 3
    assert test_case[0] == 'a'
    assert test_case[1] == 'b'
    assert test_case

# Generated at 2022-06-22 16:11:24.220987
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[-1] == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[-2] == 2

# Generated at 2022-06-22 16:11:33.715265
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid input
    test_value = ['a', 'b', 'c']
    test_msg = 'test message'
    test_version = 'test version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]
    # Test for invalid input
    try:
        test_obj[3]
    except IndexError:
        pass
    else:
        raise AssertionError('IndexError not raised')


# Generated at 2022-06-22 16:11:54.482984
# Unit test for function set_constant
def test_set_constant():
    assert set_constant('FOO', 'bar') == {'FOO': 'bar'}
    assert set_constant('FOO', 'bar', export={'FOO': 'baz'}) == {'FOO': 'baz'}
    assert set_constant('FOO', 'bar', export={}) == {'FOO': 'bar'}


# Generated at 2022-06-22 16:11:56.571728
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:12:02.818882
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:05.393177
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:12.159359
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:12:14.361563
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert 'TEST_CONSTANT' in globals()
    assert globals()['TEST_CONSTANT'] == 'test'
    del globals()['TEST_CONSTANT']


# Generated at 2022-06-22 16:12:25.844632
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:12:30.352125
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test', '2.0')
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:12:33.042914
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:12:36.400957
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:03.409365
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz', export=locals())
    assert FOO == 'baz'
    set_constant('FOO', 'qux', export=globals())
    assert FOO == 'qux'
    set_constant('FOO', 'quux', export=locals())
    assert FOO == 'quux'
    set_constant('FOO', 'corge', export=globals())
    assert FOO == 'corge'
    set_constant('FOO', 'grault', export=locals())
    assert FOO == 'grault'
    set_constant('FOO', 'garply', export=globals())
    assert FOO == 'garply'


# Generated at 2022-06-22 16:13:08.852534
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)

# Generated at 2022-06-22 16:13:19.348925
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert dsc[-1] == 3
    assert dsc[-2] == 2
    assert dsc[-3] == 1

    # Test with a tuple
    dsc = _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert dsc[-1] == 3
    assert dsc[-2] == 2
    assert dsc[-3] == 1

    # Test with a string
    d

# Generated at 2022-06-22 16:13:21.611492
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:26.787440
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:13:29.437452
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'


# Generated at 2022-06-22 16:13:33.745900
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for empty list
    assert len(_DeprecatedSequenceConstant([], 'msg', 'version')) == 0
    # Test for non-empty list
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:36.977958
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid index
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[1] == 2
    # Test for invalid index
    try:
        dsc[4]
    except IndexError:
        pass
    else:
        assert False

# Generated at 2022-06-22 16:13:41.755996
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:13:47.975258
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['test_value']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == 1
    assert test_obj[0] == 'test_value'

# Generated at 2022-06-22 16:14:34.177946
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    seq = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert seq[0] == 'a'
    assert seq[1] == 'b'
    assert seq[2] == 'c'
    assert seq[-1] == 'c'
    assert seq[-2] == 'b'
    assert seq[-3] == 'a'


# Generated at 2022-06-22 16:14:36.674708
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:47.253972
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version') == ['a', 'b', 'c']
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[1] == 'b'
    assert _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[2] == 'c'

# Generated at 2022-06-22 16:14:49.823922
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:15:01.293103
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:15:07.819587
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:15:15.774822
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version') == ['a', 'b', 'c']
    assert len(_DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')) == 3
    assert _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')[0] == 'a'
    assert _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')[1] == 'b'
    assert _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')[2] == 'c'


# Generated at 2022-06-22 16:15:27.581077
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:15:29.320440
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:15:31.320557
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'
    assert test_constant == 'test_value'


# Generated at 2022-06-22 16:16:21.810811
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:16:24.136530
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'


# Generated at 2022-06-22 16:16:34.544858
# Unit test for constructor of class _DeprecatedSequenceConstant