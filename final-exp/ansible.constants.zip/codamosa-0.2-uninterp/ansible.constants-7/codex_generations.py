

# Generated at 2022-06-22 16:06:28.803560
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:34.063879
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['test1', 'test2']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version

# Generated at 2022-06-22 16:06:44.945206
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:06:48.177854
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:50.795371
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:59.398632
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'
    set_constant('TEST_CONSTANT', 'test2')
    assert TEST_CONSTANT == 'test2'
    set_constant('TEST_CONSTANT', 'test3', export=locals())
    assert TEST_CONSTANT == 'test3'
    set_constant('TEST_CONSTANT', 'test4', export=globals())
    assert TEST_CONSTANT == 'test4'

# Generated at 2022-06-22 16:07:01.387367
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')) == 3

# Generated at 2022-06-22 16:07:06.544376
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:07:17.333889
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for a valid sequence
    test_sequence = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='msg', version='version')
    assert test_sequence[0] == 'a'
    assert test_sequence[1] == 'b'
    assert test_sequence[2] == 'c'

    # Test for a sequence with an invalid index
    try:
        test_sequence[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'

    # Test for a sequence with a negative index
    try:
        test_sequence[-1]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'



# Generated at 2022-06-22 16:07:29.353481
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:40.976157
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:07:51.974719
# Unit test for function set_constant
def test_set_constant():
    # Test for constants that are set
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert MODULE_REQUIRE_ARGS == ('command', 'win_command', 'ansible.windows.win_command', 'shell', 'win_shell',
                                   'ansible.windows.win_shell', 'raw', 'script')
    assert MODULE_NO_JSON == ('command', 'win_command', 'ansible.windows.win_command', 'shell', 'win_shell',
                              'ansible.windows.win_shell', 'raw')
    assert RESTRICTED_RESULT_KEYS

# Generated at 2022-06-22 16:07:54.039327
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'test', '2.9')) == 3


# Generated at 2022-06-22 16:08:01.468305
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:08:09.011681
# Unit test for function set_constant
def test_set_constant():
    # Test for setting a constant
    set_constant('ANSIBLE_TEST_CONSTANT', 'test_value')
    assert ANSIBLE_TEST_CONSTANT == 'test_value'

    # Test for setting a constant to a value that already exists
    set_constant('ANSIBLE_TEST_CONSTANT', 'test_value2')
    assert ANSIBLE_TEST_CONSTANT == 'test_value2'

    # Test for setting a constant to a value that already exists in a different namespace
    set_constant('ANSIBLE_TEST_CONSTANT', 'test_value3', export=dict(ANSIBLE_TEST_CONSTANT='test_value'))
    assert ANSIBLE_TEST_CONSTANT == 'test_value3'

    # Test for setting a constant to a value that already exists

# Generated at 2022-06-22 16:08:14.600283
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:08:23.290524
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:08:25.772618
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:08:36.811163
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a string
    test_string = 'test_string'
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_object = _DeprecatedSequenceConstant(test_string, test_msg, test_version)
    assert test_object[0] == 't'
    assert test_object[-1] == 'g'
    assert test_object[0:3] == 'tes'
    assert test_object[-3:] == 'ing'
    assert test_object[::-1] == 'gnirts_tset'

    # Test with a list
    test_list = ['test_list_1', 'test_list_2']
    test_object = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_object

# Generated at 2022-06-22 16:08:45.987784
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[2] == 3


# Generated at 2022-06-22 16:09:03.835423
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    from ansible.module_utils.common.collections import Sequence

    class _DeprecatedSequenceConstant(Sequence):
        def __init__(self, value, msg, version):
            self._value = value
            self._msg = msg
            self._version = version

        def __len__(self):
            _deprecated(self._msg, self._version)
            return len(self._value)

        def __getitem__(self, y):
            _deprecated(self._msg, self._version)
            return self._value[y]

    # Capture stderr
    old_stderr = sys.stderr
    sys.stderr = io.StringIO()

    # Test
    test_value = [1, 2, 3]

# Generated at 2022-06-22 16:09:05.380270
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:09:11.158466
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid input
    value = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert value[0] == 'a'
    assert value[1] == 'b'
    assert value[2] == 'c'
    # Test for invalid input
    try:
        value[3]
    except IndexError:
        pass
    else:
        assert False, 'IndexError not raised'


# Generated at 2022-06-22 16:09:15.992352
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for empty list
    empty_list = _DeprecatedSequenceConstant([], 'msg', 'version')
    assert len(empty_list) == 0

    # Test for non-empty list
    non_empty_list = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert len(non_empty_list) == 3


# Generated at 2022-06-22 16:09:20.418287
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    import unittest
    class Test__DeprecatedSequenceConstant(unittest.TestCase):
        def test_len(self):
            self.assertEqual(len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')), 3)
        def test_getitem(self):
            self.assertEqual(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')[1], 'b')
    unittest.main()

if __name__ == '__main__':
    test__DeprecatedSequenceConstant()

# Generated at 2022-06-22 16:09:30.822213
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:09:37.565076
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test message'
    version = '2.9'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == len(value)
    assert deprecated_sequence_constant[0] == value[0]
    assert deprecated_sequence_constant[1] == value[1]
    assert deprecated_sequence_constant[2] == value[2]


# Generated at 2022-06-22 16:09:39.668464
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:42.235354
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:09:47.966752
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2

# Generated at 2022-06-22 16:09:57.298514
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test'
    version = '2.0'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[1] == 2


# Generated at 2022-06-22 16:10:00.000321
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for _DeprecatedSequenceConstant
    msg = 'msg'
    version = 'version'
    value = 'value'
    _DeprecatedSequenceConstant(value, msg, version)


# Generated at 2022-06-22 16:10:04.231432
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:10:07.569449
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:11.427599
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2

# Generated at 2022-06-22 16:10:14.447609
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:20.157591
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b']
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant._value == value
    assert deprecated_sequence_constant._msg == msg
    assert deprecated_sequence_constant._version == version


# Generated at 2022-06-22 16:10:21.468941
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:10:29.890164
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = 'test version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:10:32.806500
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:10:45.700298
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.9')) == 3


# Generated at 2022-06-22 16:10:52.541479
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3

# Generated at 2022-06-22 16:10:55.113471
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:57.252505
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:10:58.677151
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2

# Generated at 2022-06-22 16:11:05.702478
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:11:09.513416
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:11:17.689012
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['test1', 'test2']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version
    assert len(test_obj) == 2
    assert test_obj[0] == 'test1'
    assert test_obj[1] == 'test2'

# Generated at 2022-06-22 16:11:19.771803
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:11:21.764967
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:35.306775
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'foo')
    assert TEST_CONSTANT == 'foo'

# Generated at 2022-06-22 16:11:37.843500
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:11:40.489613
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:51.760540
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    value = ['a', 'b', 'c']
    msg = 'test message'
    version = '2.9'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'
    # Test with a tuple
    value = ('a', 'b', 'c')
    msg = 'test message'
    version = '2.9'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:12:03.040272
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:12:05.926122
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    deprecated_sequence_constant = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(deprecated_sequence_constant) == 3

# Generated at 2022-06-22 16:12:12.947335
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:12:16.271847
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:12:18.561177
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:26.292213
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], "msg", "version") == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], "msg", "version")) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], "msg", "version")[2] == 3

# Generated at 2022-06-22 16:12:43.981863
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1

# Generated at 2022-06-22 16:12:47.763766
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:12:50.031740
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:52.361621
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:03.284924
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:13:15.023259
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:13:19.987147
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:13:30.577140
# Unit test for function set_constant
def test_set_constant():
    # Test for string
    set_constant('test_string', 'test_value')
    assert test_string == 'test_value'

    # Test for int
    set_constant('test_int', 1)
    assert test_int == 1

    # Test for float
    set_constant('test_float', 1.0)
    assert test_float == 1.0

    # Test for boolean
    set_constant('test_bool', True)
    assert test_bool is True

    # Test for list
    set_constant('test_list', ['a', 'b', 'c'])
    assert test_list == ['a', 'b', 'c']

    # Test for dict
    set_constant('test_dict', {'a': 'b', 'c': 'd'})

# Generated at 2022-06-22 16:13:34.152783
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_sequence = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test message', '2.9')
    assert len(test_sequence) == 3
    assert test_sequence[1] == 'b'

# Generated at 2022-06-22 16:13:35.957002
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:25.231580
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['test1', 'test2']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 2
    assert dsc[0] == 'test1'
    assert dsc[1] == 'test2'


# Generated at 2022-06-22 16:14:27.186381
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:14:33.378580
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'msg'
    version = 'version'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant[0] == value[0]
    assert deprecated_sequence_constant[1] == value[1]
    assert deprecated_sequence_constant[2] == value[2]


# Generated at 2022-06-22 16:14:39.975299
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:14:47.113002
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test message'
    version = '2.9'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]


# Generated at 2022-06-22 16:14:57.657316
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

    # Test with a tuple
    test_tuple = (1, 2, 3)
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2

# Generated at 2022-06-22 16:15:01.231931
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:15:03.870454
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test value')
    assert TEST_CONSTANT == 'test value'


# Generated at 2022-06-22 16:15:13.724651
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # Test for constructor of class _DeprecatedSequenceConstant with empty value
    try:
        _DeprecatedSequenceConstant([], 'msg', 'version')
    except Exception:
        assert False, "Failed to create object of class _DeprecatedSequenceConstant"

    # Test for constructor of class _DeprecatedSequenceConstant with empty msg
    try:
        _DeprecatedSequenceConstant(['value'], '', 'version')
    except Exception:
        assert False, "Failed to create object of class _DeprecatedSequenceConstant"

    # Test for constructor of class _DeprecatedSequenceConstant with empty version

# Generated at 2022-06-22 16:15:25.668625
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'Test message'
    test_version = '1.0'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

    # Test with a tuple
    test_tuple = ('a', 'b', 'c')
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

    #