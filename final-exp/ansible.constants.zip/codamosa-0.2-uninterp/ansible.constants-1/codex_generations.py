

# Generated at 2022-06-22 16:06:27.343994
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:06:33.883586
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:06:42.507280
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[2] == 3


# Generated at 2022-06-22 16:06:50.904938
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid input
    test_obj = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

    # Test for invalid input
    try:
        test_obj[3]
    except IndexError:
        pass
    else:
        raise AssertionError('IndexError not raised')


# Generated at 2022-06-22 16:06:53.313388
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:06:56.415274
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:06.611728
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:13.413448
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    value = ['a', 'b', 'c']
    msg = 'This is a test'
    version = '2.9'
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == 3
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

# Generated at 2022-06-22 16:07:17.999562
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a test message"
    version = "2.0"
    value = [1, 2, 3]
    deprecated_sequence = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence) == 3
    assert deprecated_sequence[0] == 1
    assert deprecated_sequence[1] == 2
    assert deprecated_sequence[2] == 3


# Generated at 2022-06-22 16:07:20.443293
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:07:25.932512
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:28.254975
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:07:37.697764
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:07:39.809897
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:07:49.053818
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid sequence
    test_sequence = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test_message', '2.0')
    assert test_sequence[0] == 'a'
    assert test_sequence[1] == 'b'
    assert test_sequence[2] == 'c'
    # Test for invalid sequence
    test_sequence = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'test_message', '2.0')
    try:
        test_sequence[3]
    except IndexError:
        pass
    else:
        raise AssertionError("IndexError not raised for invalid sequence")

# Generated at 2022-06-22 16:07:55.466808
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = "test_msg"
    test_version = "test_version"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 16:07:59.912791
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.0'
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]

# Generated at 2022-06-22 16:08:02.581819
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.8')) == 3

# Generated at 2022-06-22 16:08:07.044137
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[0] == 'a'
    assert _DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')[1] == 'b'


# Generated at 2022-06-22 16:08:09.022400
# Unit test for function set_constant
def test_set_constant():
    set_constant('foo', 'bar', export=globals())
    assert globals()['foo'] == 'bar'

# Generated at 2022-06-22 16:08:14.116748
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:08:18.192889
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(dsc) == 3
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

# Generated at 2022-06-22 16:08:20.608475
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:08:28.782568
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for valid input
    test_obj = _DeprecatedSequenceConstant(value=['a', 'b', 'c'], msg='test', version='2.9')
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'

    # Test for invalid input
    try:
        test_obj[3]
    except IndexError:
        pass
    else:
        raise AssertionError('IndexError not raised')



# Generated at 2022-06-22 16:08:31.233651
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:08:33.286201
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:08:35.685273
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:08:37.787272
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:08:48.581147
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # with valid values
    _DeprecatedSequenceConstant(value=['a', 'b'], msg='test', version='2.0')
    # Test for constructor of class _DeprecatedSequenceConstant
    # with invalid values
    try:
        _DeprecatedSequenceConstant(value=['a', 'b'], msg=None, version='2.0')
    except Exception as e:
        assert isinstance(e, TypeError)
    try:
        _DeprecatedSequenceConstant(value=['a', 'b'], msg='test', version=None)
    except Exception as e:
        assert isinstance(e, TypeError)

# Generated at 2022-06-22 16:08:50.562613
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:08:56.243666
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:09:07.392199
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test case 1:
    # Test with a list
    # Expected result:
    # The list is returned
    test_list = [1, 2, 3]
    test_msg = "This is a test message"
    test_version = "2.9"
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3

    # Test case 2:
    # Test with a tuple
    # Expected result:
    # The tuple is returned
    test_tuple = (1, 2, 3)
    test_obj = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)

# Generated at 2022-06-22 16:09:09.261151
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:09:11.113084
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'

# Generated at 2022-06-22 16:09:14.859905
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)


# Generated at 2022-06-22 16:09:20.712950
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:09:22.965399
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:09:29.075203
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'


# Generated at 2022-06-22 16:09:32.280762
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:09:34.317943
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1,2,3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:43.349239
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:09:46.171554
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'


# Generated at 2022-06-22 16:09:53.274379
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self):
            self.value = [1, 2, 3]
            self.msg = 'test'
            self.version = '1.0'
            self.obj = _DeprecatedSequenceConstant(self.value, self.msg, self.version)

        def test(self):
            assert self.obj[0] == self.value[0]
            assert self.obj[1] == self.value[1]
            assert self.obj[2] == self.value[2]

    t = Test()
    t.test()

# Generated at 2022-06-22 16:09:56.407441
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2

# Generated at 2022-06-22 16:09:59.895816
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_sequence = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')
    assert test_sequence[0] == 1
    assert test_sequence[1] == 2
    assert test_sequence[2] == 3


# Generated at 2022-06-22 16:10:09.370010
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'
    set_constant('FOO', 'baz', export=locals())
    assert FOO == 'baz'
    set_constant('FOO', 'qux', export=globals())
    assert FOO == 'qux'
    set_constant('FOO', 'quux', export=locals())
    assert FOO == 'quux'
    set_constant('FOO', 'corge', export=globals())
    assert FOO == 'corge'
    set_constant('FOO', 'grault', export=locals())
    assert FOO == 'grault'
    set_constant('FOO', 'garply', export=globals())
    assert FOO == 'garply'


# Generated at 2022-06-22 16:10:11.130045
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'

# Generated at 2022-06-22 16:10:14.124771
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')) == 3


# Generated at 2022-06-22 16:10:16.787259
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.9')) == 3


# Generated at 2022-06-22 16:10:23.336005
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:10:32.845971
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:10:43.407026
# Unit test for function set_constant
def test_set_constant():
    # Test for setting constants
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'
    # Test for setting constants with export
    set_constant('TEST_CONSTANT_EXPORT', 'test', export=locals())
    assert TEST_CONSTANT_EXPORT == 'test'
    # Test for setting constants with export
    set_constant('TEST_CONSTANT_EXPORT_2', 'test', export=globals())
    assert TEST_CONSTANT_EXPORT_2 == 'test'
    # Test for setting constants with export
    set_constant('TEST_CONSTANT_EXPORT_3', 'test', export=vars())
    assert TEST_CONSTANT_EXPORT_3 == 'test'
    # Test for setting constants with

# Generated at 2022-06-22 16:10:51.423237
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]


# Generated at 2022-06-22 16:10:53.820568
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'



# Generated at 2022-06-22 16:11:04.820674
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_HOST_LIST == '/etc/ansible/hosts'
    assert DEFAULT_MODULE_NAME == 'command'
    assert DEFAULT_MODULE_PATH == ['/usr/share/ansible']
    assert DEFAULT_PATTERN == '*'
    assert DEFAULT_REMOTE_TMP == '$HOME/.ansible/tmp'
    assert DEFAULT_SUDO_EXE == '/usr/bin/sudo'
    assert DEFAULT_SUDO_FLAGS == '-H'
    assert DEFAULT_SUDO_USER == 'root'
    assert DEFAULT_SYSLOG_FACILITY == 'LOG_USER'
    assert DEFAULT_UNDEFINED_VAR_BEHAVIOR == 'warn'
    assert DEFAULT_VERBOSITY == 0
    assert DEFAULT_

# Generated at 2022-06-22 16:11:12.617962
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for a valid index
    test_obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')
    assert test_obj[0] == 1
    # Test for an invalid index
    test_obj = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')
    try:
        test_obj[4]
    except IndexError:
        pass
    else:
        assert False, "An IndexError should have been raised"


# Generated at 2022-06-22 16:11:15.601199
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:11:26.469090
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:11:28.700923
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')) == 3


# Generated at 2022-06-22 16:11:35.936055
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for _DeprecatedSequenceConstant.__len__()
    # Test for _DeprecatedSequenceConstant.__len__() with empty sequence
    assert _DeprecatedSequenceConstant([], '', '').__len__() == 0
    # Test for _DeprecatedSequenceConstant.__len__() with non-empty sequence
    assert _DeprecatedSequenceConstant([1, 2, 3], '', '').__len__() == 3


# Generated at 2022-06-22 16:11:45.128160
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=('a', 'b', 'c'), msg='msg', version='version')
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'


# Generated at 2022-06-22 16:11:50.387456
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.0'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]

# Generated at 2022-06-22 16:11:52.716980
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:12:02.414305
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    value = [1, 2, 3]
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    # Test with a tuple
    value = (1, 2, 3)
    msg = 'msg'
    version = 'version'
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:12:04.525463
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'

# Generated at 2022-06-22 16:12:07.016045
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:12:09.357295
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:11.129290
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:12:16.662618
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test message'
    version = '2.0'
    value = ['a', 'b', 'c']
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == 3
    assert deprecated_sequence_constant[1] == 'b'

# Generated at 2022-06-22 16:12:27.413783
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert COLLECTION_PTYPE_COMPAT == {'module': 'modules'}
    assert CONFIGURABLE_PLUGINS == ('become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars')

# Generated at 2022-06-22 16:12:45.051055
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0') == [1, 2, 3]
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')[1] == 2
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:12:47.102391
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:48.554198
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:13:00.004756
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'
    set_constant('TEST_CONSTANT', 'test2')
    assert TEST_CONSTANT == 'test2'
    set_constant('TEST_CONSTANT', 'test3', export=globals())
    assert TEST_CONSTANT == 'test3'
    set_constant('TEST_CONSTANT', 'test4', export=locals())
    assert TEST_CONSTANT == 'test3'
    assert 'TEST_CONSTANT' not in locals()

# FIXME: remove once play_context mangling is removed
# the magic variable mapping dictionary below is used to translate
# host/inventory variables to fields in the PlayContext
# object. The dictionary values are tuples, to account

# Generated at 2022-06-22 16:13:02.082809
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:13:04.691462
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'BAR')
    assert FOO == 'BAR'


# Generated at 2022-06-22 16:13:07.531527
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert isinstance(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version'), Sequence)

# Generated at 2022-06-22 16:13:18.255539
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for constructor of class _DeprecatedSequenceConstant
    # with a tuple
    test_tuple = ('test', 'test2')
    test_msg = 'test message'
    test_version = 'test version'
    test_constant = _DeprecatedSequenceConstant(test_tuple, test_msg, test_version)
    assert len(test_constant) == len(test_tuple)
    assert test_constant[0] == test_tuple[0]
    assert test_constant[1] == test_tuple[1]

    # Test for constructor of class _DeprecatedSequenceConstant
    # with a list
    test_list = ['test', 'test2']
    test_msg = 'test message'
    test_version = 'test version'
    test_constant = _Dep

# Generated at 2022-06-22 16:13:19.801101
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:13:22.006557
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:14:11.917284
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:14:14.100637
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:16.710980
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:18.710957
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:14:29.913008
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[-1] == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[-2] == 2

# Generated at 2022-06-22 16:14:34.721187
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = 'value'
    d = _DeprecatedSequenceConstant(value, msg, version)
    assert d._value == value
    assert d._msg == msg
    assert d._version == version
    assert len(d) == len(value)
    assert d[0] == value[0]

# Generated at 2022-06-22 16:14:37.624021
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:14:40.177297
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    # Test for _DeprecatedSequenceConstant
    # Test for method __len__
    # Test for empty list
    assert _DeprecatedSequenceConstant([], 'msg', 'version').__len__() == 0
    # Test for non-empty list
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version').__len__() == 3


# Generated at 2022-06-22 16:14:49.733089
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:14:52.131084
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'