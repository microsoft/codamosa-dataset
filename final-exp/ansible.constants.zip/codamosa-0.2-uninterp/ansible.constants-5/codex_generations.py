

# Generated at 2022-06-22 16:06:40.704318
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.9'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 'a'
    assert dsc[1] == 'b'
    assert dsc[2] == 'c'

# Generated at 2022-06-22 16:06:43.068216
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['test1', 'test2']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]

# Generated at 2022-06-22 16:06:55.944583
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for _DeprecatedSequenceConstant.__getitem__()
    # Test for _DeprecatedSequenceConstant.__getitem__() with index
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    # Test for _DeprecatedSequenceConstant.__getitem__() with slice
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1:3] == [2, 3]
    # Test for _DeprecatedSequenceConstant.__getitem__() with negative index
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[-1] == 3
    # Test for _DeprecatedSequenceConstant.__getitem__() with negative slice
    assert _DeprecatedSequenceCon

# Generated at 2022-06-22 16:07:06.311252
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert test_obj[0] == 'a'
    assert test_obj[1] == 'b'
    assert test_obj[2] == 'c'
    assert test_obj[-1] == 'c'
    assert test_obj[-2] == 'b'
    assert test_obj[-3] == 'a'
    assert test_obj[0:2] == ['a', 'b']
    assert test_obj[1:3] == ['b', 'c']

# Generated at 2022-06-22 16:07:08.377763
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2

# Generated at 2022-06-22 16:07:11.061792
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:16.421504
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)


# Generated at 2022-06-22 16:07:18.657261
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'



# Generated at 2022-06-22 16:07:23.462281
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3



# Generated at 2022-06-22 16:07:29.491505
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.0'
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == 3
    assert deprecated_sequence_constant[0] == 1
    assert deprecated_sequence_constant[1] == 2
    assert deprecated_sequence_constant[2] == 3

# Generated at 2022-06-22 16:07:34.183905
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([], '', '')

# Generated at 2022-06-22 16:07:37.160359
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:07:43.443535
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    # Test for a valid key
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')
    assert dsc[0] == 1
    # Test for an invalid key
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')
    try:
        dsc[4]
        assert False
    except IndexError:
        assert True


# Generated at 2022-06-22 16:07:47.730757
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.9')
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3


# Generated at 2022-06-22 16:07:52.181771
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test message'
    version = 'test version'
    value = ['test', 'value']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version
    assert len(test_obj) == len(value)
    assert test_obj[0] == value[0]


# Generated at 2022-06-22 16:07:59.121490
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['a', 'b', 'c']
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == 3
    assert deprecated_sequence_constant[0] == 'a'
    assert deprecated_sequence_constant[1] == 'b'
    assert deprecated_sequence_constant[2] == 'c'

# Generated at 2022-06-22 16:08:01.837844
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1,2,3], msg='test', version='1.0')) == 3


# Generated at 2022-06-22 16:08:05.852755
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')
    assert dsc[1] == 2


# Generated at 2022-06-22 16:08:07.477659
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:08:13.620837
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 1
    assert test_obj[1] == 2
    assert test_obj[2] == 3


# Generated at 2022-06-22 16:08:26.808965
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = [1, 2, 3]
    test_msg = "This is a test message"
    test_version = "2.10"
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:08:29.382324
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:08:34.882210
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'test message'
    version = '2.0'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert len(dsc) == 3


# Generated at 2022-06-22 16:08:42.925763
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj._value == test_value
    assert test_obj._msg == test_msg
    assert test_obj._version == test_version
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]

# Generated at 2022-06-22 16:08:46.700310
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'
    set_constant('test_constant', 'test_value2', export=globals())
    assert test_constant == 'test_value2'

# Generated at 2022-06-22 16:08:57.742136
# Unit test for function set_constant
def test_set_constant():
    assert DEFAULT_BECOME_PASS is None
    assert DEFAULT_PASSWORD_CHARS == to_text(ascii_letters + digits + ".,:-_", errors='strict')
    assert DEFAULT_REMOTE_PASS is None
    assert DEFAULT_SUBSET is None
    assert COLLECTION_PTYPE_COMPAT == {'module': 'modules'}
    assert CONFIGURABLE_PLUGINS == ('become', 'cache', 'callback', 'cliconf', 'connection', 'httpapi', 'inventory', 'lookup', 'netconf', 'shell', 'vars')

# Generated at 2022-06-22 16:09:00.085291
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')) == 3


# Generated at 2022-06-22 16:09:10.804519
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    class Test:
        def __init__(self, value, msg, version):
            self.value = value
            self.msg = msg
            self.version = version

        def __len__(self):
            return len(self.value)

        def __getitem__(self, y):
            return self.value[y]

    test = Test(value=[1, 2, 3], msg='msg', version='version')
    assert len(test) == 3
    assert test[0] == 1
    assert test[1] == 2
    assert test[2] == 3

    test = Test(value=('a', 'b', 'c'), msg='msg', version='version')
    assert len(test) == 3
    assert test[0] == 'a'
    assert test[1] == 'b'

# Generated at 2022-06-22 16:09:14.317465
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert len(dsc) == 3
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

# Generated at 2022-06-22 16:09:15.732278
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:31.141139
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:09:36.056994
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2

# Generated at 2022-06-22 16:09:39.368375
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.9'
    value = ['a', 'b', 'c']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version

# Generated at 2022-06-22 16:09:42.342247
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:47.663724
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = "This is a test message"
    version = "2.9"
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 1


# Generated at 2022-06-22 16:09:50.085265
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant((1, 2, 3), 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:54.655106
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    test_list = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_list, test_msg, test_version)
    assert len(test_list) == len(test_obj)


# Generated at 2022-06-22 16:09:57.299078
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:09:58.972782
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:10:00.794119
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:10:14.094869
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:10:20.894913
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:10:23.852895
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    a = _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')
    assert a[0] == 1
    assert a[1] == 2
    assert a[2] == 3


# Generated at 2022-06-22 16:10:34.441683
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:10:36.107700
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3

# Generated at 2022-06-22 16:10:42.402424
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # test for __init__
    msg = 'test msg'
    version = '2.9'
    value = ['a', 'b', 'c']
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version

    # test for __len__
    assert len(test_obj) == len(value)

    # test for __getitem__
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]
    assert test_obj[2] == value[2]


# Generated at 2022-06-22 16:10:46.321850
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test'
    version = '2.9'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert len(dsc) == 3
    assert dsc[0] == 1


# Generated at 2022-06-22 16:10:57.209125
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    # Test for __init__()
    msg = "This is a test"
    version = "2.0"
    value = [1, 2, 3]
    test_obj = _DeprecatedSequenceConstant(value, msg, version)
    assert test_obj._value == value
    assert test_obj._msg == msg
    assert test_obj._version == version

    # Test for __len__()
    assert len(test_obj) == len(value)

    # Test for __getitem__()
    assert test_obj[0] == value[0]
    assert test_obj[1] == value[1]
    assert test_obj[2] == value[2]


# Generated at 2022-06-22 16:10:59.357031
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:11:09.915572
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:11:25.769312
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    dsc = _DeprecatedSequenceConstant(value=[1, 2, 3], msg='test', version='2.0')
    assert len(dsc) == 3
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3

# Generated at 2022-06-22 16:11:37.229954
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:11:40.856268
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]


# Generated at 2022-06-22 16:11:43.574885
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:11:45.727049
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test_value')
    assert TEST_CONSTANT == 'test_value'

# Generated at 2022-06-22 16:11:47.461243
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'


# Generated at 2022-06-22 16:11:50.154584
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:01.536110
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = 'This is a test'
    version = '2.9'
    value = [1, 2, 3]
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc[0] == 1
    assert dsc[1] == 2
    assert dsc[2] == 3
    assert dsc[-1] == 3
    assert dsc[-2] == 2
    assert dsc[-3] == 1
    assert dsc[0:2] == [1, 2]
    assert dsc[1:3] == [2, 3]
    assert dsc[0:3] == [1, 2, 3]
    assert dsc[0:-1] == [1, 2]
    assert dsc[-2:-1] == [2]

# Generated at 2022-06-22 16:12:12.555479
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    import sys
    import io
    from ansible.module_utils.common.collections import Sequence
    from ansible.module_utils.common.text.converters import to_text

    # Capture the output of sys.stderr
    stderr = sys.stderr
    sys.stderr = io.StringIO()

    # Create a _DeprecatedSequenceConstant object
    dsc = _DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')

    # Get the first element of the object
    assert dsc[0] == 'a'

    # Get the second element of the object
    assert dsc[1] == 'b'

    # Get the last element of the object
    assert dsc[-1] == 'c'

    # Get the second last element of the

# Generated at 2022-06-22 16:12:15.861411
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'msg'
    version = 'version'
    value = ['a', 'b', 'c']
    dsc = _DeprecatedSequenceConstant(value, msg, version)
    assert dsc._value == value
    assert dsc._msg == msg
    assert dsc._version == version
    assert len(dsc) == len(value)
    assert dsc[0] == value[0]
    assert dsc[1] == value[1]
    assert dsc[2] == value[2]

# Generated at 2022-06-22 16:12:43.116865
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b', 'c'], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:12:47.916658
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:12:49.802236
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:12:57.777090
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    msg = 'This is a test message'
    version = '2.10'
    value = ['a', 'b', 'c']
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert len(deprecated_sequence_constant) == len(value)
    assert deprecated_sequence_constant[0] == value[0]
    assert deprecated_sequence_constant[1] == value[1]
    assert deprecated_sequence_constant[2] == value[2]


# Generated at 2022-06-22 16:13:05.685463
# Unit test for constructor of class _DeprecatedSequenceConstant

# Generated at 2022-06-22 16:13:10.225562
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    test_value = [1, 2, 3]
    test_msg = 'test message'
    test_version = '1.0'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert test_obj[0] == 1

# Generated at 2022-06-22 16:13:15.446792
# Unit test for method __getitem__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___getitem__():
    msg = "msg"
    version = "version"
    value = [1, 2, 3]
    deprecated_sequence_constant = _DeprecatedSequenceConstant(value, msg, version)
    assert deprecated_sequence_constant[0] == 1
    assert deprecated_sequence_constant[1] == 2
    assert deprecated_sequence_constant[2] == 3


# Generated at 2022-06-22 16:13:23.475832
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.9')[2] == 3


# Generated at 2022-06-22 16:13:25.484800
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(value=[1, 2, 3], msg='msg', version='version')) == 3


# Generated at 2022-06-22 16:13:30.218579
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'
    set_constant('TEST_CONSTANT', 'test2', export=globals())
    assert TEST_CONSTANT == 'test2'


# Generated at 2022-06-22 16:14:35.616557
# Unit test for function set_constant
def test_set_constant():
    set_constant('FOO', 'bar')
    assert FOO == 'bar'

# Generated at 2022-06-22 16:14:37.686922
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'

# Generated at 2022-06-22 16:14:38.993265
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant(['a', 'b'], 'msg', 'version')) == 2


# Generated at 2022-06-22 16:14:42.143877
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:14:49.868467
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = ['a', 'b', 'c']
    test_msg = 'test_msg'
    test_version = 'test_version'
    test_obj = _DeprecatedSequenceConstant(test_value, test_msg, test_version)
    assert len(test_obj) == len(test_value)
    assert test_obj[0] == test_value[0]
    assert test_obj[1] == test_value[1]
    assert test_obj[2] == test_value[2]

# Generated at 2022-06-22 16:14:54.464654
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    test_value = _DeprecatedSequenceConstant([1, 2, 3], 'test', '2.0')
    assert len(test_value) == 3
    assert test_value[0] == 1
    assert test_value[1] == 2
    assert test_value[2] == 3

# Generated at 2022-06-22 16:15:03.505187
# Unit test for constructor of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant():
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version') == [1, 2, 3]
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[0] == 1
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[1] == 2
    assert _DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')[2] == 3


# Generated at 2022-06-22 16:15:05.995149
# Unit test for method __len__ of class _DeprecatedSequenceConstant
def test__DeprecatedSequenceConstant___len__():
    assert len(_DeprecatedSequenceConstant([1, 2, 3], 'msg', 'version')) == 3


# Generated at 2022-06-22 16:15:10.135684
# Unit test for function set_constant
def test_set_constant():
    set_constant('TEST_CONSTANT', 'test')
    assert TEST_CONSTANT == 'test'
    set_constant('TEST_CONSTANT', 'test2', export=globals())
    assert TEST_CONSTANT == 'test2'


# Generated at 2022-06-22 16:15:11.883823
# Unit test for function set_constant
def test_set_constant():
    set_constant('test_constant', 'test_value')
    assert test_constant == 'test_value'