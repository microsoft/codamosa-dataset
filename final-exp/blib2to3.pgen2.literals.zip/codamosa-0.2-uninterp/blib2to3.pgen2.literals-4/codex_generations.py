

# Generated at 2022-06-17 16:38:13.170944
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:38:23.426426
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
   

# Generated at 2022-06-17 16:38:35.410165
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"abc\\n"') == "abc\n"
    assert evalString("'abc\\n'") == "abc\n"
    assert evalString('"abc\\"def"') == 'abc"def'
    assert evalString("'abc\\'def'") == "abc'def"
    assert evalString('"abc\\x00def"') == "abc\x00def"
    assert evalString('"abc\\077def"') == "abc?def"
    assert evalString('"abc\\177def"') == "abc\x7fdef"
    assert evalString('"abc\\377def"') == "abc\xffdef"

# Generated at 2022-06-17 16:38:39.516919
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"

# Generated at 2022-06-17 16:38:47.588539
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == '\x00'
    assert evalString('"\\xFF"') == '\xFF'
    assert evalString('"\\x00\\xFF"') == '\x00\xFF'
    assert evalString('"\\x00\\xFF\\x00"') == '\x00\xFF\x00'
    assert evalString('"\\x00\\xFF\\x00\\xFF"') == '\x00\xFF\x00\xFF'
    assert evalString('"\\x00\\xFF\\x00\\xFF\\x00"') == '\x00\xFF\x00\xFF\x00'

# Generated at 2022-06-17 16:38:59.520509
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc\\n"') == 'abc\n'
    assert evalString("'abc\\n'") == 'abc\n'
    assert evalString('"abc\\r\\n"') == 'abc\r\n'
    assert evalString("'abc\\r\\n'") == 'abc\r\n'
    assert evalString('"abc\\r\\n\\t"') == 'abc\r\n\t'
    assert evalString("'abc\\r\\n\\t'") == 'abc\r\n\t'
    assert evalString('"abc\\r\\n\\t\\0"') == 'abc\r\n\t\x00'

# Generated at 2022-06-17 16:39:09.170574
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:39:20.874872
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"a\\"b\\"c"') == 'a"b"c'
    assert evalString("'a\\'b\\'c'") == "a'b'c"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\"') == "\a\b\f\n\r\t\v\'\"\\"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\'") == "\a\b\f\n\r\t\v\'\"\\"
    assert evalString('"\\x61\\x62\\x63"') == "abc"

# Generated at 2022-06-17 16:39:21.679672
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:39:28.483932
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:40:20.559578
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"abc\\n"') == "abc\n"
    assert evalString("'abc\\n'") == "abc\n"
    assert evalString('"abc\\r\\n"') == "abc\r\n"
    assert evalString("'abc\\r\\n'") == "abc\r\n"
    assert evalString('"abc\\r\\n\\t"') == "abc\r\n\t"
    assert evalString("'abc\\r\\n\\t'") == "abc\r\n\t"
    assert evalString('"abc\\r\\n\\t\\x20"') == "abc\r\n\t "

# Generated at 2022-06-17 16:40:29.272161
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:40:41.167102
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:40:41.695758
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:40:42.465711
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:40:51.098166
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == "\x00"
    assert evalString('"\\x7f"') == "\x7f"
    assert evalString('"\\x80"') == "\x80"
    assert evalString('"\\xff"') == "\xff"
    assert evalString('"\\0"') == "\x00"
    assert evalString('"\\07"') == "\x07"
    assert evalString('"\\0177"') == "\x7f"
    assert evalString('"\\200"') == "\x80"
    assert evalString('"\\377"') == "\xff"
    assert evalString('"\\x"') == "x"
    assert evalString('"\\x0"') == "x0"
    assert evalString('"\\x00x"') == "\x00x"

# Generated at 2022-06-17 16:41:02.617863
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == "\x00"
    assert evalString('"\\x7f"') == "\x7f"
    assert evalString('"\\x80"') == "\x80"
    assert evalString('"\\xff"') == "\xff"
    assert evalString('"\\x00"') == "\x00"
    assert evalString('"\\077"') == "?"
    assert evalString('"\\100"') == "\x40"
    assert evalString('"\\377"') == "\xff"
    assert evalString('"\\0"') == "\x00"
    assert evalString('"\\7"') == "\x07"
    assert evalString('"\\10"') == "\x08"
    assert evalString('"\\17"') == "\x0f"
    assert eval

# Generated at 2022-06-17 16:41:11.422903
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:41:21.833236
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:41:29.596529
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
   

# Generated at 2022-06-17 16:42:23.479591
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:42:32.005694
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:42:42.477588
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:42:42.973216
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:42:43.554406
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:42:52.283464
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:43:03.336490
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:43:13.618789
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:43:14.097461
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:43:26.055815
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:44:30.230205
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:44:37.159455
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:44:38.232159
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:44:50.879345
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:44:58.002808
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:44:58.653345
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:45:07.231993
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:45:17.291807
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:45:17.926536
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:45:19.947592
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:47:37.732882
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"

# Generated at 2022-06-17 16:47:50.431983
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x0")) == "\x00"
    assert escape(re.match(r"\\x", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x", "\\x000")) == "\x00"
    assert escape(re.match(r"\\x", "\\x0000")) == "\x00"
    assert escape(re.match(r"\\x", "\\x00000")) == "\x00"
    assert escape(re.match(r"\\x", "\\x000000")) == "\x00"
    assert escape(re.match(r"\\x", "\\x0000000")) == "\x00"

# Generated at 2022-06-17 16:47:56.412491
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x1")) == "\\x1"
    assert escape(re.match(r"\\x", "\\x12")) == "\\x12"
    assert escape(re.match(r"\\x", "\\x123")) == "\\x123"
    assert escape(re.match(r"\\x", "\\x1234")) == "\\x1234"
    assert escape(re.match(r"\\x", "\\x12345")) == "\\x12345"
    assert escape(re.match(r"\\x", "\\x123456")) == "\\x123456"
    assert escape(re.match(r"\\x", "\\x1234567"))

# Generated at 2022-06-17 16:48:02.954561
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"