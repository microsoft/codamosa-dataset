

# Generated at 2022-06-17 16:38:10.166596
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\n\\n'") == "\n\n"
    assert evalString("'\\n\\n\\n'") == "\n\n\n"
    assert evalString("'\\n\\n\\n\\n'") == "\n\n\n\n"
    assert evalString("'\\n\\n\\n\\n\\n'") == "\n\n\n\n\n"
    assert evalString("'\\n\\n\\n\\n\\n\\n'") == "\n\n\n\n\n\n"

# Generated at 2022-06-17 16:38:21.606434
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) != "x"
    assert escape(re.match(r"\\x", "\\x")) != "\\"
    assert escape(re.match(r"\\x", "\\x")) != "\\x"
    assert escape(re.match(r"\\x", "\\x")) != "\\x"
    assert escape(re.match(r"\\x", "\\x")) != "\\x"
    assert escape(re.match(r"\\x", "\\x")) != "\\x"
    assert escape(re.match(r"\\x", "\\x")) != "\\x"
    assert escape(re.match(r"\\x", "\\x"))

# Generated at 2022-06-17 16:38:31.741211
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:38:42.354067
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'

# Generated at 2022-06-17 16:38:51.697243
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:39:03.821129
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
   

# Generated at 2022-06-17 16:39:11.720187
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:39:21.969569
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"

# Generated at 2022-06-17 16:39:32.187469
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:39:42.138257
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:40:07.655740
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:40:08.360263
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:40:20.844080
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc\\n"') == 'abc\n'
    assert evalString("'abc\\n'") == 'abc\n'
    assert evalString('"abc\\n\\n"') == 'abc\n\n'
    assert evalString("'abc\\n\\n'") == 'abc\n\n'
    assert evalString('"abc\\n\\n\\n"') == 'abc\n\n\n'
    assert evalString("'abc\\n\\n\\n'") == 'abc\n\n\n'
    assert evalString('"abc\\n\\n\\n\\n"') == 'abc\n\n\n\n'

# Generated at 2022-06-17 16:40:25.730337
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:40:29.093987
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:40:41.021623
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\x61'") == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString('"\\x61\\x62\\x63"') == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString('"\\x61\\x62\\x63"') == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"

# Generated at 2022-06-17 16:40:50.594772
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:41:02.339629
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"

# Generated at 2022-06-17 16:41:11.309617
# Unit test for function escape
def test_escape():
    # Test simple escapes
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\'", r"\'")) == "'"

# Generated at 2022-06-17 16:41:18.612356
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:42:33.778157
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:42:34.397298
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:42:44.109209
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:42:52.109069
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:42:52.873989
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:43:03.808179
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:43:13.974889
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'

# Generated at 2022-06-17 16:43:25.948580
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"

# Generated at 2022-06-17 16:43:26.430460
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:43:37.507924
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:44:57.419182
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:45:06.631693
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"

# Generated at 2022-06-17 16:45:16.860267
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:45:24.601623
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61\\x62"') == "ab"
    assert evalString('"\\x61\\x62\\x63"') == "abc"
    assert evalString('"\\x61\\x62\\x63\\x64"') == "abcd"
    assert evalString('"\\x61\\x62\\x63\\x64\\x65"') == "abcde"
    assert evalString('"\\x61\\x62\\x63\\x64\\x65\\x66"') == "abcdef"
    assert evalString('"\\x61\\x62\\x63\\x64\\x65\\x66\\x67"') == "abcdefg"

# Generated at 2022-06-17 16:45:33.865889
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:45:47.222662
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"

# Generated at 2022-06-17 16:45:57.420668
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\a")) == "\a"
    assert escape(re.match(r"\\(.)", "\\b")) == "\b"
    assert escape(re.match(r"\\(.)", "\\f")) == "\f"
    assert escape(re.match(r"\\(.)", "\\n")) == "\n"
    assert escape(re.match(r"\\(.)", "\\r")) == "\r"
    assert escape(re.match(r"\\(.)", "\\t")) == "\t"
    assert escape(re.match(r"\\(.)", "\\v")) == "\v"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"

# Generated at 2022-06-17 16:46:08.896399
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:46:20.510020
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\a")) == "\a"
    assert escape(re.match(r"\\(.)", "\\b")) == "\b"
    assert escape(re.match(r"\\(.)", "\\f")) == "\f"
    assert escape(re.match(r"\\(.)", "\\n")) == "\n"
    assert escape(re.match(r"\\(.)", "\\r")) == "\r"
    assert escape(re.match(r"\\(.)", "\\t")) == "\t"
    assert escape(re.match(r"\\(.)", "\\v")) == "\v"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"

# Generated at 2022-06-17 16:46:27.856563
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"