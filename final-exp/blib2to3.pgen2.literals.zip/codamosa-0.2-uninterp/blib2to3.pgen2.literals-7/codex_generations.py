

# Generated at 2022-06-17 16:38:24.434919
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:38:24.951905
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:38:36.912531
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\a")) == "\a"
    assert escape(re.match(r"\\(.)", "\\b")) == "\b"
    assert escape(re.match(r"\\(.)", "\\f")) == "\f"
    assert escape(re.match(r"\\(.)", "\\n")) == "\n"
    assert escape(re.match(r"\\(.)", "\\r")) == "\r"
    assert escape(re.match(r"\\(.)", "\\t")) == "\t"
    assert escape(re.match(r"\\(.)", "\\v")) == "\v"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"

# Generated at 2022-06-17 16:38:49.923538
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:39:02.094922
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:39:10.636270
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:39:21.717517
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61"') == 'a'

# Generated at 2022-06-17 16:39:31.925966
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:39:32.493445
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:39:42.319470
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\a")) == "\a"
    assert escape(re.match(r"\\(.)", "\\b")) == "\b"
    assert escape(re.match(r"\\(.)", "\\f")) == "\f"
    assert escape(re.match(r"\\(.)", "\\n")) == "\n"
    assert escape(re.match(r"\\(.)", "\\r")) == "\r"
    assert escape(re.match(r"\\(.)", "\\t")) == "\t"
    assert escape(re.match(r"\\(.)", "\\v")) == "\v"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"

# Generated at 2022-06-17 16:40:22.968436
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"

# Generated at 2022-06-17 16:40:30.788923
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:40:43.064713
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\"")) == "\""
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"

# Generated at 2022-06-17 16:40:51.246408
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"

# Generated at 2022-06-17 16:41:02.619019
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:41:03.415564
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:41:11.756932
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x1")) == "\\x1"
    assert escape(re.match(r"\\x", "\\x12")) == "\\x12"
    assert escape(re.match(r"\\x", "\\x123")) == "\\x123"
    assert escape(re.match(r"\\x", "\\x1234")) == "\\x1234"
    assert escape(re.match(r"\\x", "\\x12345")) == "\\x12345"
    assert escape(re.match(r"\\x", "\\x123456")) == "\\x123456"
    assert escape(re.match(r"\\x", "\\x1234567"))

# Generated at 2022-06-17 16:41:16.484336
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:41:27.264514
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:41:35.126147
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x1f", "\\x1f")) == "\x1f"
    assert escape(re.match(r"\\x1f", "\\x1f")) == "\x1f"
    assert escape(re.match(r"\\x1f", "\\x1f")) == "\x1f"
    assert escape(re.match(r"\\x1f", "\\x1f")) == "\x1f"
    assert escape(re.match(r"\\x1f", "\\x1f")) == "\x1f"
    assert escape(re.match(r"\\x1f", "\\x1f")) == "\x1f"
    assert escape(re.match(r"\\x1f", "\\x1f")) == "\x1f"
    assert escape

# Generated at 2022-06-17 16:42:23.571023
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:42:32.125292
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:42:32.939306
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:42:33.403637
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:42:43.531397
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'a\\nb'") == "a\nb"
    assert evalString('"a\\nb"') == "a\nb"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v"') == "\a\b\f\n\r\t\v"
    assert eval

# Generated at 2022-06-17 16:42:52.255923
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x0a", "\\x0a")) == "\n"
    assert escape(re.match(r"\\x0A", "\\x0A")) == "\n"
    assert escape(re.match(r"\\x0B", "\\x0B")) == "\x0b"
    assert escape(re.match(r"\\x0C", "\\x0C")) == "\x0c"
    assert escape(re.match(r"\\x0D", "\\x0D")) == "\r"
    assert escape(re.match(r"\\x0E", "\\x0E")) == "\x0e"

# Generated at 2022-06-17 16:43:03.303105
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61'") == "a"

# Generated at 2022-06-17 16:43:03.857676
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:43:14.005251
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:43:25.984689
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:44:40.755192
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:44:41.606212
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:44:42.355455
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:44:52.025359
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"

# Generated at 2022-06-17 16:44:58.450706
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:45:07.137917
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:45:17.208178
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"

# Generated at 2022-06-17 16:45:24.805971
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:45:34.119832
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:45:41.188417
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\"")) == '"'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"

# Generated at 2022-06-17 16:46:36.460580
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:46:37.491300
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:46:38.305539
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:46:39.127792
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:46:39.946760
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:46:51.513568
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x01", "\\x01")) == "\x01"
    assert escape(re.match(r"\\x02", "\\x02")) == "\x02"
    assert escape(re.match(r"\\x03", "\\x03")) == "\x03"
    assert escape(re.match(r"\\x04", "\\x04")) == "\x04"
    assert escape(re.match(r"\\x05", "\\x05")) == "\x05"
    assert escape(re.match(r"\\x06", "\\x06")) == "\x06"
    assert escape(re.match(r"\\x07", "\\x07")) == "\x07"

# Generated at 2022-06-17 16:47:01.705618
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:47:08.011043
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"

# Generated at 2022-06-17 16:47:08.545230
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:47:21.132911
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"