

# Generated at 2022-06-17 16:38:15.469181
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:38:25.046010
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\x01'") == "\x01"
    assert evalString("'\\x02'") == "\x02"
    assert evalString("'\\x03'") == "\x03"
    assert evalString("'\\x04'") == "\x04"
    assert evalString("'\\x05'") == "\x05"
    assert evalString("'\\x06'") == "\x06"
    assert evalString("'\\x07'") == "\x07"
    assert evalString("'\\x08'") == "\x08"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\n'") == "\n"

# Generated at 2022-06-17 16:38:37.031825
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\a")) == "\a"
    assert escape(re.match(r"\\(.)", "\\b")) == "\b"
    assert escape(re.match(r"\\(.)", "\\f")) == "\f"
    assert escape(re.match(r"\\(.)", "\\n")) == "\n"
    assert escape(re.match(r"\\(.)", "\\r")) == "\r"
    assert escape(re.match(r"\\(.)", "\\t")) == "\t"
    assert escape(re.match(r"\\(.)", "\\v")) == "\v"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"

# Generated at 2022-06-17 16:38:49.980619
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\a")) == "\a"
    assert escape(re.match(r"\\(.)", "\\b")) == "\b"
    assert escape(re.match(r"\\(.)", "\\f")) == "\f"
    assert escape(re.match(r"\\(.)", "\\n")) == "\n"
    assert escape(re.match(r"\\(.)", "\\r")) == "\r"
    assert escape(re.match(r"\\(.)", "\\t")) == "\t"
    assert escape(re.match(r"\\(.)", "\\v")) == "\v"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"

# Generated at 2022-06-17 16:39:02.144313
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == "\x00"
    assert evalString('"\\x01"') == "\x01"
    assert evalString('"\\x02"') == "\x02"
    assert evalString('"\\x03"') == "\x03"
    assert evalString('"\\x04"') == "\x04"
    assert evalString('"\\x05"') == "\x05"
    assert evalString('"\\x06"') == "\x06"
    assert evalString('"\\x07"') == "\x07"
    assert evalString('"\\x08"') == "\x08"
    assert evalString('"\\x09"') == "\x09"
    assert evalString('"\\x0a"') == "\n"
    assert evalString('"\\x0b"')

# Generated at 2022-06-17 16:39:10.669865
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"

# Generated at 2022-06-17 16:39:15.465733
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:39:26.398502
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:39:32.011165
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:39:41.957034
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:40:07.032587
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:40:19.610180
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(.)', r'\a')) == '\a'
    assert escape(re.match(r'\\(.)', r'\b')) == '\b'
    assert escape(re.match(r'\\(.)', r'\f')) == '\f'
    assert escape(re.match(r'\\(.)', r'\n')) == '\n'
    assert escape(re.match(r'\\(.)', r'\r')) == '\r'
    assert escape(re.match(r'\\(.)', r'\t')) == '\t'
    assert escape(re.match(r'\\(.)', r'\v')) == '\v'

# Generated at 2022-06-17 16:40:28.660449
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:40:37.915292
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:40:48.369188
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString("'\\r'") == "\r"
    assert evalString('"\\t"') == "\t"
    assert evalString("'\\t'") == "\t"
    assert evalString('"\\b"') == "\b"
    assert evalString("'\\b'") == "\b"
    assert evalString('"\\f"') == "\f"

# Generated at 2022-06-17 16:41:00.036639
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:41:09.589845
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:41:20.386475
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61"') == "a"

# Generated at 2022-06-17 16:41:21.681243
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:41:29.484156
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"a\\"b\\"c"') == 'a"b"c'
    assert evalString("'a\\'b\\'c'") == "a'b'c"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v"') == "\a\b\f\n\r\t\v"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString('"\\x61\\x62\\x63"') == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
   

# Generated at 2022-06-17 16:42:26.500515
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:42:37.290257
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61\\x62"') == "ab"
    assert evalString('"\\x61\\x62\\x63"') == "abc"
    assert evalString('"\\x61\\x62\\x63\\x64"') == "abcd"
    assert evalString('"\\x61\\x62\\x63\\x64\\x65"') == "abcde"
    assert evalString('"\\x61\\x62\\x63\\x64\\x65\\x66"') == "abcdef"
    assert evalString('"\\x61\\x62\\x63\\x64\\x65\\x66\\x67"') == "abcdefg"

# Generated at 2022-06-17 16:42:39.006863
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:42:50.605750
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:43:02.998858
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61\\x62'") == "ab"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63\\x64'") == "abcd"
    assert evalString("'\\x61\\x62\\x63\\x64\\x65'") == "abcde"
    assert evalString("'\\x61\\x62\\x63\\x64\\x65\\x66'") == "abcdef"

# Generated at 2022-06-17 16:43:03.309364
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:43:13.586201
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:43:25.531556
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:43:36.727399
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"

# Generated at 2022-06-17 16:43:50.068117
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"

# Generated at 2022-06-17 16:46:39.585861
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:46:51.410033
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:47:01.685752
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:47:07.982426
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:47:14.624145
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:47:16.130480
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:47:25.687051
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:47:34.452788
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:47:42.795362
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:47:52.142733
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"