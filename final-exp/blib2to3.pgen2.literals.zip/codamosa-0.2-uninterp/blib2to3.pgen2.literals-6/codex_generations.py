

# Generated at 2022-06-17 16:38:18.249493
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:38:25.283573
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61\\x62"') == 'ab'
    assert evalString('"\\x61\\x62\\x63"') == 'abc'
    assert evalString('"\\x61\\x62\\x63\\x64"') == 'abcd'
    assert evalString('"\\x61\\x62\\x63\\x64\\x65"') == 'abcde'
    assert evalString('"\\x61\\x62\\x63\\x64\\x65\\x66"') == 'abcdef'
    assert evalString('"\\x61\\x62\\x63\\x64\\x65\\x66\\x67"') == 'abcdefg'

# Generated at 2022-06-17 16:38:37.233572
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', '\\a')) == '\a'
    assert escape(re.match('\\b', '\\b')) == '\b'
    assert escape(re.match('\\f', '\\f')) == '\f'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'
    assert escape(re.match('\\v', '\\v')) == '\v'
    assert escape(re.match('\\\'', '\\\'')) == '\''
    assert escape(re.match('\\"', '\\"')) == '"'

# Generated at 2022-06-17 16:38:50.061946
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\x7f'") == "\x7f"
    assert evalString("'\\x80'") == "\x80"
    assert evalString("'\\xff'") == "\xff"

# Generated at 2022-06-17 16:39:02.194731
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"

# Generated at 2022-06-17 16:39:10.700128
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:39:15.480712
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63'")

# Generated at 2022-06-17 16:39:26.398454
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:39:34.240391
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == "\x00"
    assert evalString('"\\x01"') == "\x01"
    assert evalString('"\\x02"') == "\x02"
    assert evalString('"\\x03"') == "\x03"
    assert evalString('"\\x04"') == "\x04"
    assert evalString('"\\x05"') == "\x05"
    assert evalString('"\\x06"') == "\x06"
    assert evalString('"\\x07"') == "\x07"
    assert evalString('"\\x08"') == "\x08"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\n"') == "\n"

# Generated at 2022-06-17 16:39:43.376972
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:40:11.192828
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == '\x00'
    assert evalString('"\\x01"') == '\x01'
    assert evalString('"\\x02"') == '\x02'
    assert evalString('"\\x03"') == '\x03'
    assert evalString('"\\x04"') == '\x04'
    assert evalString('"\\x05"') == '\x05'
    assert evalString('"\\x06"') == '\x06'
    assert evalString('"\\x07"') == '\x07'
    assert evalString('"\\x08"') == '\x08'
    assert evalString('"\\x09"') == '\t'
    assert evalString('"\\x0a"') == '\n'

# Generated at 2022-06-17 16:40:23.176687
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x0")) == "\\x0"
    assert escape(re.match(r"\\x", "\\x00")) == "\\x00"
    assert escape(re.match(r"\\x", "\\x000")) == "\\x000"
    assert escape(re.match(r"\\x", "\\x0000")) == "\\x0000"
    assert escape(re.match(r"\\x", "\\x00000")) == "\\x00000"
    assert escape(re.match(r"\\x", "\\x000000")) == "\\x000000"
    assert escape(re.match(r"\\x", "\\x0000000")) == "\\x0000000"
   

# Generated at 2022-06-17 16:40:23.764651
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:40:31.309479
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:40:43.108826
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:40:51.522601
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:41:02.707001
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"
    assert escape(re.match(r"\\x41", r"\x41")) == "A"

# Generated at 2022-06-17 16:41:11.448149
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == "\x00"
    assert evalString('"\\xFF"') == "\xFF"
    assert evalString('"\\x00\\xFF"') == "\x00\xFF"
    assert evalString('"\\x00\\xFF\\x00"') == "\x00\xFF\x00"
    assert evalString('"\\x00\\xFF\\x00\\xFF"') == "\x00\xFF\x00\xFF"
    assert evalString('"\\x00\\xFF\\x00\\xFF\\x00"') == "\x00\xFF\x00\xFF\x00"

# Generated at 2022-06-17 16:41:21.834675
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:41:29.595509
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:42:21.303132
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:42:30.489413
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-17 16:42:38.328805
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:42:50.441256
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape

# Generated at 2022-06-17 16:42:51.637356
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:43:03.201451
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\a")) == "\a"
    assert escape(re.match(r"\\(.)", "\\b")) == "\b"
    assert escape(re.match(r"\\(.)", "\\f")) == "\f"
    assert escape(re.match(r"\\(.)", "\\n")) == "\n"
    assert escape(re.match(r"\\(.)", "\\r")) == "\r"
    assert escape(re.match(r"\\(.)", "\\t")) == "\t"
    assert escape(re.match(r"\\(.)", "\\v")) == "\v"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"

# Generated at 2022-06-17 16:43:03.759950
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-17 16:43:13.944631
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape

# Generated at 2022-06-17 16:43:25.911187
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-17 16:43:36.894256
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x0")) == "\\x0"
    assert escape(re.match(r"\\x", "\\x00")) == "\\x00"
    assert escape(re.match(r"\\x", "\\x000")) == "\\x000"
    assert escape(re.match(r"\\x", "\\x0000")) == "\\x0000"
    assert escape(re.match(r"\\x", "\\x00000")) == "\\x00000"
    assert escape(re.match(r"\\x", "\\x000000")) == "\\x000000"
    assert escape(re.match(r"\\x", "\\x0000000")) == "\\x0000000"
   

# Generated at 2022-06-17 16:45:05.234533
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:45:16.188324
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"

# Generated at 2022-06-17 16:45:24.174063
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\a")) == "\a"
    assert escape(re.match(r"\\(.)", "\\b")) == "\b"
    assert escape(re.match(r"\\(.)", "\\f")) == "\f"
    assert escape(re.match(r"\\(.)", "\\n")) == "\n"
    assert escape(re.match(r"\\(.)", "\\r")) == "\r"
    assert escape(re.match(r"\\(.)", "\\t")) == "\t"
    assert escape(re.match(r"\\(.)", "\\v")) == "\v"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"

# Generated at 2022-06-17 16:45:32.567998
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x1")) == "\\x1"
    assert escape(re.match(r"\\x", "\\x12")) == "\\x12"
    assert escape(re.match(r"\\x", "\\x123")) == "\\x123"
    assert escape(re.match(r"\\x", "\\x1234")) == "\\x1234"
    assert escape(re.match(r"\\x", "\\x12345")) == "\\x12345"
    assert escape(re.match(r"\\x", "\\x123456")) == "\\x123456"
    assert escape(re.match(r"\\x", "\\x1234567"))

# Generated at 2022-06-17 16:45:40.606355
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"

# Generated at 2022-06-17 16:45:49.650814
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"

# Generated at 2022-06-17 16:45:58.844386
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"
    assert escape(re.match(r"\\x", "\\x")) == "\\x"

# Generated at 2022-06-17 16:46:09.502396
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\x61", r"\x61")) == "a"
    assert escape(re.match(r"\\x61", r"\x61")) == "a"
    assert escape(re.match(r"\\x61", r"\x61")) == "a"
    assert escape(re.match(r"\\x61", r"\x61")) == "a"
    assert escape(re.match(r"\\x61", r"\x61")) == "a"
    assert escape(re.match(r"\\x61", r"\x61")) == "a"

# Generated at 2022-06-17 16:46:21.333216
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-17 16:46:28.243738
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
    assert escape(re.match(r"\\x", "\\x")) == "x"
   