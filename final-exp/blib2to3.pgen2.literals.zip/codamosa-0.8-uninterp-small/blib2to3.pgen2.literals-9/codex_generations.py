

# Generated at 2022-06-25 14:48:13.857491
# Unit test for function escape
def test_escape():
    for key, value in simple_escapes.items():
        m = re.search(r"\\" + key, s)
        assert m == escape(m)



# Generated at 2022-06-25 14:48:16.076472
# Unit test for function escape
def test_escape():
    assert escape('a') == 'a'


# Generated at 2022-06-25 14:48:18.453137
# Unit test for function escape
def test_escape():
    # Zero-length string
    assert escape(re.match(r"\\x", "\\x")) is None


# Generated at 2022-06-25 14:48:20.315815
# Unit test for function test
def test_test():
    test_case_0()
    # Replace with test code


if __name__ == '__main__':
    test_test()

# Generated at 2022-06-25 14:48:22.363047
# Unit test for function escape
def test_escape():
    assert escape('\\x04') == '\x04'


# Generated at 2022-06-25 14:48:23.607372
# Unit test for function escape
def test_escape():
    assert escape("\\x1f") == chr(31)


# Generated at 2022-06-25 14:48:25.753388
# Unit test for function evalString
def test_evalString():
    r = evalString('"this is a test string"')
    assert r == "this is a test string"

# Generated at 2022-06-25 14:48:36.655907
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\'", "'")) == "'"
    assert escape(re.match("\\\"", '"')) == '"'
    assert escape(re.match("\\\\", "\\")) == "\\"
    assert escape(re.match("\\a", "a")) == "\a"
    assert escape(re.match("\\b", "b")) == "\b"
    assert escape(re.match("\\f", "f")) == "\f"
    assert escape(re.match("\\n", "n")) == "\n"
    assert escape(re.match("\\r", "r")) == "\r"
    assert escape(re.match("\\t", "t")) == "\t"
    assert escape(re.match("\\v", "v")) == "\v"

# Generated at 2022-06-25 14:48:43.716355
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"

# Generated at 2022-06-25 14:48:44.763191
# Unit test for function test
def test_test():
    assert callable(test)

# Generated at 2022-06-25 14:49:02.987191
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\A\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\a')) == '\a'
    assert escape(re.search(r"\A\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\b')) == '\b'
    assert escape(re.search(r"\A\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\f')) == '\x0c'

# Generated at 2022-06-25 14:49:07.009704
# Unit test for function escape
def test_escape():
    m = re.match(r'\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})','\\x')
    assert m is not None # Passes
    

# Generated at 2022-06-25 14:49:17.691022
# Unit test for function escape
def test_escape():
    m = match = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\n')
    assert m.group(0) == '\\n'
    assert m.group(1) == 'n'
    assert evalString('"\\n"') == '\n'
    m = match = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\xF6')
    assert m.group(0) == '\\xF6'
    assert m.group(1) == 'xF6'
    assert evalString('"\\xF6"') == 'ö'
    m = match = re

# Generated at 2022-06-25 14:49:19.630796
# Unit test for function test
def test_test():
    try:
        assert test() 
    except AssertionError:
        raise AssertionError("something wrong with test")


# Generated at 2022-06-25 14:49:20.590056
# Unit test for function test
def test_test():
    assert test() is None



# Generated at 2022-06-25 14:49:27.663797
# Unit test for function escape
def test_escape():
    assert escape("\\x01") == "\x01"
    assert escape("\\x12") == "\x12"
    assert escape("\\x34") == "\x34"
    assert escape("\\x56") == "\x56"
    assert escape("\\x78") == "\x78"
    assert escape("\\x01") == "\x01"
    assert escape("\\x12") == "\x12"
    assert escape("\\x34") == "\x34"
    assert escape("\\x56") == "\x56"
    assert escape("\\x78") == "\x78"



# Generated at 2022-06-25 14:49:37.342599
# Unit test for function escape
def test_escape():
    # Simple strings
    for x in ["a", "b", "f", "n", "r", "t", "v", "'", '"', "\\"]:
        assert escape(re.match(r'\\' + x, '\\' + x)) == x

    # Hex strings
    for x in ["x41", "x4a", "x50"]:
        assert escape(re.match(r'\\' + x, '\\' + x)) == chr(int(x[1:], 16))

    # Octal strings
    for x in ["101", "122", "150"]:
        assert escape(re.match(r'\\' + x, '\\' + x)) == chr(int(x, 8))

    # Invalid strings

# Generated at 2022-06-25 14:49:38.727259
# Unit test for function escape
def test_escape():
    assert escape(r"\x00") == "\\x00"


# Generated at 2022-06-25 14:49:42.716104
# Unit test for function test
def test_test():
    def test_lambda(i, c, s, e):
        assert i is not None
        assert c is not None
        assert s is not None
        assert e is not None

    test.__dict__['test_lambda'] = test_lambda
    test()



# Generated at 2022-06-25 14:49:43.680830
# Unit test for function escape
def test_escape():
    pass


# Generated at 2022-06-25 14:49:59.235390
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\x00', '\\x00')) == '\x00'
    assert escape(re.match('\\a', '\\a')) == '\x07'
    assert escape(re.match('\\b', '\\b')) == '\x08'
    assert escape(re.match('\\f', '\\f')) == '\x0c'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'
    assert escape(re.match('\\v', '\\v')) == '\x0b'

# Generated at 2022-06-25 14:50:05.832045
# Unit test for function escape
def test_escape():
    assert escape('\\t') == "\t"
    assert escape('\\t') == "\t"
    assert escape('\\x1A') == "\x1a"
    assert escape('\\x1F') == "\x1f"
    assert escape('\\x1g') == "\\x1g"
    assert escape('\\x1') == "\\x1"
    assert escape('\\x') == "\\x"


# Generated at 2022-06-25 14:50:07.111753
# Unit test for function escape
def test_escape():
    assert len(escape('text')) == len('text')


# Generated at 2022-06-25 14:50:10.371864
# Unit test for function evalString
def test_evalString():
    assert evalString('"testing \\"testing\\""') == 'testing "testing"'
    assert evalString('"\\u00e9"') == '\xe9'

# vim:ts=4:sw=4:et

# Generated at 2022-06-25 14:50:11.674221
# Unit test for function escape
def test_escape():
    assert escape('\\n') == '\n'
    assert escape('\\x01') == '\x01'

# Generated at 2022-06-25 14:50:12.167320
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-25 14:50:18.458343
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\x2a", "*")) == "*"
    assert escape(re.search(r"\\x2", "x2")) == "x2"
    assert escape(re.search(r"\\x", "xx")) == "xx"
    assert escape(re.search(r"\\x", "\\x")) == "\\x"


# Generated at 2022-06-25 14:50:21.785099
# Unit test for function escape
def test_escape():
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\x27') == "'"
    assert escape('\\b') == '\b'


# Generated at 2022-06-25 14:50:23.532450
# Unit test for function escape
def test_escape():
    # Default parameters
    # Positional arguments
    # Keyword arguments
    test()


# Generated at 2022-06-25 14:50:25.052410
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\", "\\x1F")) == '\x1f'


# Generated at 2022-06-25 14:50:50.550909
# Unit test for function evalString
def test_evalString():
    x = evalString(r"'\0\0'")
    assert x == "\0\0"
    y = evalString(r"r'\0\0'")
    assert y == r"\0\0"


# Generated at 2022-06-25 14:51:01.844928
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\\x07", "escape('\\a') == '\\x07'"
    assert escape("\\b") == "\\x08", "escape('\\b') == '\\x08'"
    assert escape("\\f") == "\\x0c", "escape('\\f') == '\\x0c'"
    assert escape("\\n") == "\\n", "escape('\\n') == '\\n'"
    assert escape("\\r") == "\\r", "escape('\\r') == '\\r'"
    assert escape("\\t") == "\\t", "escape('\\t') == '\\t'"
    assert escape("\\v") == "\\x0b", "escape('\\v') == '\\x0b'"

# Generated at 2022-06-25 14:51:06.750292
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\5", "\\5")) == '5'
    assert escape(re.match(r"\\a", "\\a")) == '\x07'
    assert escape(re.match(r"\\b", "\\b")) == '\x08'
    assert escape(re.match(r"\\f", "\\f")) == '\x0c'
    assert escape(re.match(r"\\n", "\\n")) == '\n'
    assert escape(re.match(r"\\r", "\\r")) == '\r'
    assert escape(re.match(r"\\t", "\\t")) == '\t'
    assert escape(re.match(r"\\v", "\\v")) == '\x0b'

# Generated at 2022-06-25 14:51:16.618334
# Unit test for function evalString
def test_evalString():
    # These tests are based on test_docstring_repr() in Python's own
    # test_string.py, except for the last one.
    s = evalString('''""''')
    assert s == ''
    # Too many quotes
    try:
        evalString("'''''")
    except ValueError:
        pass
    else:
        raise AssertionError
    s = evalString("'\n'")
    assert s == '\n'
    s = evalString("'\\\n'")
    assert s == ''
    s = evalString("'\\\n  '")
    assert s == '  '
    s = evalString("'\\\n  \\\n  '")
    assert s == '    '
    s = evalString("'\\\n\\\n\\\n  '")


# Generated at 2022-06-25 14:51:22.995592
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a",r"\a")) == "\a"
    assert escape(re.match(r"\\b",r"\b")) == "\b"
    assert escape(re.match(r"\\f",r"\f")) == "\f"
    assert escape(re.match(r"\\n",r"\n")) == "\n"
    assert escape(re.match(r"\\r",r"\r")) == "\r"
    assert escape(re.match(r"\\t",r"\t")) == "\t"
    assert escape(re.match(r"\\v",r"\v")) == "\v"
    assert escape(re.match(r"\\\'",r"\'")) == "'"

# Generated at 2022-06-25 14:51:25.216331
# Unit test for function escape
def test_escape():
    assert escape(Match(r"\\x10", "\\x10", 1, 1)) == "\x10"


# Generated at 2022-06-25 14:51:29.952010
# Unit test for function escape
def test_escape():
    #Pre-condition
    test_escape_string = "\\\""
    test_escape_match = re.match(r"\\(.*)", test_escape_string)
    result = escape(test_escape_match)
    assert result == "\""



# Generated at 2022-06-25 14:51:39.186557
# Unit test for function evalString
def test_evalString():
    assert 1, evalString('"abc"')
    assert 2, evalString('"abc\\x1"')
    assert 3, evalString('"abc\\x1\\x2"')
    assert 4, evalString('"abc\\x1\\x2\\x3"')
    assert 5, evalString('"abc\\x1\\x2\\x3\\x4"')
    assert 6, evalString('"abc\\x1\\x2\\x3\\x4\\x5"')
    assert 7, evalString('"abc\\x1\\x2\\x3\\x4\\x5\\x6"')
    assert 7, evalString('"abc\\x1\\x2\\x3\\x4\\x5\\x6"')

# Generated at 2022-06-25 14:51:47.671113
# Unit test for function escape
def test_escape():
    print("Test 1")
    assert escape(re.match(r'\\\"', '\\\"', re.M | re.I)) == '\"'
    print("Test 2")
    assert escape(re.match(r'\\n', '\\n', re.M | re.I)) == '\n'
    print("Test 3")
    assert escape(re.match(r'\\\\', '\\\\', re.M | re.I)) == '\\'
    print("Test 4")
    assert escape(re.match(r'\\x11', '\\x11', re.M | re.I)) == '\x11'
    print("Test 5")
    assert escape(re.match(r'\\\'', '\\\'', re.M | re.I)) == '\''
    print("Test 6")

# Generated at 2022-06-25 14:51:57.947115
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")
    assert m.group(0) == "\\a"
    assert escape(m) == '\x07'
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")
    assert m.group(0) == "\\'"
    assert escape(m) == "'"
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x")
    assert m.group

# Generated at 2022-06-25 14:52:20.329498
# Unit test for function escape
def test_escape():
    # assert escape(r"\x20") == " "
    assert escape(r'\"') == "\""

    # assert escape(r"\x7E") == "~"


# Generated at 2022-06-25 14:52:20.799037
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-25 14:52:22.536736
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\\\x([a-fA-F0-9]{1,2})", "\\x61")) == 'a'


# Generated at 2022-06-25 14:52:27.527315
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == '\\'
    assert escape("\\x41") == 'A'
    assert escape("\\x4") == '\\x4'
    assert escape("\\x4a") == 'J'
    assert escape("\\x4g") == '\\x4g'
    assert escape("\\0477") == chr(377)
   

# Generated at 2022-06-25 14:52:28.331706
# Unit test for function escape
def test_escape():
    r'\x32'


# Generated at 2022-06-25 14:52:31.451393
# Unit test for function escape
def test_escape():

    a = escape(0)
    assert a == 0

    b = escape(1)
    assert b == 1

    c = escape(0)
    assert c == 0

    d = escape(0)
    assert d == 0


# Generated at 2022-06-25 14:52:34.553932
# Unit test for function escape
def test_escape():
    assert evalString("'AAA'") == "AAA"
    assert evalString("'AAA\\n\\t'") == "AAA\n\t"
    assert evalString("'AAA\\x41'") == "AAA"
    assert evalString("'AAA\\0101'") == "AAA"

# Generated at 2022-06-25 14:52:41.479530
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'

    assert escape('\\\\') == '\\'
    assert escape('\\\'') == '\''
    assert escape('\\\"') == '\"'

    assert escape('\\1') == '1'
    assert escape('\\xab') == '\xab'
    assert escape('\\xabcd') == '\xab'
    assert escape('\\xabd') == '\xab'



# Generated at 2022-06-25 14:52:43.326010
# Unit test for function escape
def test_escape():
    assert escape(re.match(b"\\x12", b"\\x12")) == b'\x12'

# Generated at 2022-06-25 14:52:44.362740
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-25 14:53:30.254221
# Unit test for function test
def test_test():
    assert test() is None



# Generated at 2022-06-25 14:53:33.646118
# Unit test for function escape

# Generated at 2022-06-25 14:53:42.527428
# Unit test for function escape
def test_escape():
    assert escape('\\x12') == '\x12'
    assert escape('\\x12') == '\x12'
    assert escape('\\x12') == '\x12'
    assert escape('\\x12') == '\x12'
    assert escape('\\x12') == '\x12'
    assert escape('\\x12') == '\x12'
    assert escape('\\x12') == '\x12'
    assert escape('\\x12') == '\x12'
    assert escape('\\x12') == '\x12'
    assert escape('\\x1') == '\x01'
    assert escape('\\x12') == '\x12'
    assert escape('\\x12') == '\x12'
    assert escape('\\x2') == '\x02'

# Generated at 2022-06-25 14:53:43.673845
# Unit test for function escape
def test_escape():
    assert escape("\x00") == "\\x00"


# Generated at 2022-06-25 14:53:45.861568
# Unit test for function test
def test_test():
    assert test()==None

__all__ = ["evalString", "test", "test_case_0", "test_test"]

# Generated at 2022-06-25 14:53:47.207017
# Unit test for function escape
def test_escape():
    assert escape("\\\\a") == '\a'


# Generated at 2022-06-25 14:53:48.613327
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\b", r"\b")) == '\b'


# Generated at 2022-06-25 14:53:49.774686
# Unit test for function escape
def test_escape():
    assert escape("\\\\xabcd") == "‭"

# Generated at 2022-06-25 14:53:50.818856
# Unit test for function escape
def test_escape():
    assert escape("\\xab") == "ab"


# Generated at 2022-06-25 14:53:52.147740
# Unit test for function escape
def test_escape():
    # Test cases for function escape
    # FIXME: No test cases for function escape
    pass



# Generated at 2022-06-25 14:55:45.422885
# Unit test for function escape

# Generated at 2022-06-25 14:55:52.625594
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\*', '\\a')) == '\x07'
    assert escape(re.match('\\*', '\\b')) == '\x08'
    assert escape(re.match('\\*', '\\f')) == '\x0c'
    assert escape(re.match('\\*', '\\n')) == '\n'
    assert escape(re.match('\\*', '\\r')) == '\r'
    assert escape(re.match('\\*', '\\t')) == '\t'
    assert escape(re.match('\\*', '\\v')) == '\x0b'
    assert escape(re.match('\\*', '\\\'')) == '\''
    assert escape(re.match('\\*', '\\"')) == '"'

# Generated at 2022-06-25 14:55:53.456176
# Unit test for function test
def test_test():
    assert callable(test)


# Generated at 2022-06-25 14:56:02.288761
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r"\\"'"'"'", "\\'")) == "'"
    assert escape(re.match(r"\\"'"'"'", "\\''")) == "'"
    assert escape(re.match(r"\\"'"'"'", "\\'''")) == "'"
    assert escape(re.match(r"\\"'"'"'", "\\''''")) == "'"
    assert escape(re.match(r"\\"'"'"'", "\\'''''")) == "'"
    assert escape(re.match(r"\\"'"'"'", "\\''''''")) == "'"
    assert escape(re.match(r"\\"'"'"'", "\\'''''''")) == "'"

# Generated at 2022-06-25 14:56:09.916825
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})$", "\\x")) == "x"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})$", "\\x1")) == "\x01"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})$", "\\x79")) == "\x79"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})$", "\\0")) == "\x00"

# Generated at 2022-06-25 14:56:11.205446
# Unit test for function test
def test_test():
    assert test() is None

if __name__ == "__main__":
    import sys
    sys.exit(test())

# Generated at 2022-06-25 14:56:11.681489
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-25 14:56:12.253556
# Unit test for function test
def test_test():
  assert test() is None, "test() should return None"

# Generated at 2022-06-25 14:56:16.964146
# Unit test for function escape
def test_escape():
    m = re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")
    #assert m.group() == r"\f"
    #assert m.group(1) == "f"
    assert escape(m) == "\x0c"



# Generated at 2022-06-25 14:56:22.530430
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\"') == '"'
    assert escape('\\\\') == '\\'

