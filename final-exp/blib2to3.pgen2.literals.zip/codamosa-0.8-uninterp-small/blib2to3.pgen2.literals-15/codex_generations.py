

# Generated at 2022-06-25 14:48:30.555536
# Unit test for function evalString
def test_evalString():
    print('Testing function evalString')

# Generated at 2022-06-25 14:48:34.679477
# Unit test for function escape
def test_escape():
    expected = '\\'
    actual = escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\?'))
    assert expected == actual


# Generated at 2022-06-25 14:48:38.266347
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})",r"\x41")) == "A"


# Generated at 2022-06-25 14:48:48.489887
# Unit test for function escape

# Generated at 2022-06-25 14:48:55.799792
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\"')) == '"'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\\")) == "\\"

# Generated at 2022-06-25 14:48:56.271122
# Unit test for function test
def test_test():
    assert test()

# Generated at 2022-06-25 14:49:04.798215
# Unit test for function escape
def test_escape():
    assert escape(["\\a", "a"]) == "\a"
    assert escape(["\\b", "b"]) == "\b"
    assert escape(["\\f", "f"]) == "\f"
    assert escape(["\\n", "n"]) == "\n"
    assert escape(["\\r", "r"]) == "\r"
    assert escape(["\\t", "t"]) == "\t"
    assert escape(["\\v", "v"]) == "\v"

# Generated at 2022-06-25 14:49:05.702589
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"



# Generated at 2022-06-25 14:49:15.959310
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(x.{0,2})", "\\x09")) == "\t"
    assert escape(re.match(r"\\(x.{0,2})", "\\x0A")) == "\n"
    assert escape(re.match(r"\\(x.{0,2})", "\\x0B")) == "\v"
    assert escape(re.match(r"\\(x.{0,2})", "\\x0D")) == "\r"
    assert escape(re.match(r"\\(x.{0,2})", "\\x20")) == " "
    assert escape(re.match(r"\\(x.{0,2})", "\\x7F")) == "\x7f"

# Generated at 2022-06-25 14:49:24.959419
# Unit test for function escape
def test_escape():
    import re

    assert escape("\a") == "\\a"
    assert escape("\b") == "\\b"
    assert escape("\f") == "\\f"
    assert escape("\n") == "\\n"
    assert escape("\r") == "\\r"
    assert escape("\t") == "\\t"
    assert escape("\v") == "\\v"
    assert escape("\'") == "\\\'"
    assert escape("\"") == '\\"'
    assert escape("\\") == "\\\\"

# Generated at 2022-06-25 14:49:42.715203
# Unit test for function test
def test_test():
    from nose.tools import assert_equals, assert_raises
    assert_equals(test(), None)


# Generated at 2022-06-25 14:49:43.683795
# Unit test for function escape
def test_escape():
    assert escape() == '\\'


# Generated at 2022-06-25 14:49:53.073788
# Unit test for function escape
def test_escape():
    assert escape.__annotations__ == {'m': Match[Text], 'return': Text}
    assert escape(re.match('a', 'a')) == 'a'
    # ex1
    assert escape(re.match('a', 'a')) == 'a'
    # ex2
    assert escape(re.match('a', 'a')) == 'a'
    # ex3
    assert escape(re.match('a', 'a')) == 'a'
    # ex4
    assert escape(re.match('a', 'a')) == 'a'
    # ex5
    assert escape(re.match('a', 'a')) == 'a'
    # ex6
    assert escape(re.match('a', 'a')) == 'a'
    # ex7

# Generated at 2022-06-25 14:49:56.675973
# Unit test for function escape
def test_escape():
    # test_escape_0() -> None
    r"""
    Eval sample string

    """
    # '\'+chr(i)
    for i in range(256):
        s = "'" + chr(i) + "'"
        # eval(simple_escapes.get(tail))
        c = evalString(s)
    return



# Generated at 2022-06-25 14:50:07.822272
# Unit test for function escape
def test_escape():
    assert escape("\\") == "\\"
    assert escape("\\'") == "'"
    assert escape("\\\"") == "\""
    assert escape("\\'\\'") == "\\'"
    assert escape("\\\"\\\"") == "\\\""
    assert escape("\\\"") == "\""
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\x0e") == chr(14)
    assert escape("\\x0f") == chr(15)
    assert escape("\\x11")

# Generated at 2022-06-25 14:50:10.125624
# Unit test for function escape
def test_escape():
    assert escape('\\x01') == '\x01'
    assert escape('\\x1') == '\x01'


# Generated at 2022-06-25 14:50:20.285607
# Unit test for function escape
def test_escape():
    assert escape('\\x07') == '\a'
    assert escape('\\x07') != '\\a'
    assert escape('\\x07') != '\x07'
    assert escape('\\07') == '\a'
    assert escape('\\07') != '\\a'
    assert escape('\\07') != '\a'
    assert escape('\\07') != '\x07'
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\x08'
    assert escape('\\n') == '\x0a'
    assert escape('\\r') == '\x0d'
    assert escape('\\t') == '\x09'
    assert escape('\\t') != 't'
    assert escape('\\t') != '\t'

# Generated at 2022-06-25 14:50:29.067380
# Unit test for function escape
def test_escape():

    # Test case from example
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\200")) == "\xcc"

    # Extra test cases
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\x")) == 'x'
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\0")) == "\x00"

# Generated at 2022-06-25 14:50:30.982572
# Unit test for function test
def test_test():
    assert test() == None, 'Expected None, got: ' + str(test())


# Generated at 2022-06-25 14:50:32.175471
# Unit test for function escape
def test_escape():
    m = "\\x12"
    result = escape(m)
    assert result == "\x12"


# Generated at 2022-06-25 14:50:40.394548
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:50:40.968599
# Unit test for function test
def test_test():
    assert test()

# Generated at 2022-06-25 14:50:42.196404
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'


# Generated at 2022-06-25 14:50:42.706853
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-25 14:50:51.889131
# Unit test for function escape
def test_escape():
    import sys
    import libfuturize.fixes.fix_stringeval

    if sys.version_info[0] >= 3:
        raise unittest.SkipTest('no way this works on py3')

    m = libfuturize.fixes.fix_stringeval.escape

    # simplest case:
    if m('\\a') != '\a':
        print(m('\\a'))

    # case \b
    if m('\\b') != '\b':
        print(m('\\b'))

    # case \f
    if m('\\f') != '\f':
        print(m('\\f'))

    # case \n
    if m('\\n') != '\n':
        print(m('\\n'))

    # case \r

# Generated at 2022-06-25 14:50:54.679093
# Unit test for function escape
def test_escape():
    txt = "\\x00"
    assert escape(txt) == "\\x00"

# Generated at 2022-06-25 14:50:55.990229
# Unit test for function escape
def test_escape():
    pass


# Generated at 2022-06-25 14:50:58.093282
# Unit test for function escape
def test_escape():
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\\'\\"\\\\"') == "\a\b\f\n\r\t\v\'\"\\"

# Generated at 2022-06-25 14:51:01.044228
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})","\\x19")) is not None


# Generated at 2022-06-25 14:51:11.119964
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(a)", "\\a")) == "\a"
    assert escape(re.match(r"\\(b)", "\\b")) == "\b"
    assert escape(re.match(r"\\(f)", "\\f")) == "\f"
    assert escape(re.match(r"\\(n)", "\\n")) == "\n"
    assert escape(re.match(r"\\(r)", "\\r")) == "\r"
    assert escape(re.match(r"\\(t)", "\\t")) == "\t"
    assert escape(re.match(r"\\(v)", "\\v")) == "\v"
    assert escape(re.match(r"\\(')", "\\'")) == "'"

# Generated at 2022-06-25 14:51:17.609855
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:51:18.470878
# Unit test for function test
def test_test():
    print(test())
    assert test() == None



# Generated at 2022-06-25 14:51:18.930481
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-25 14:51:20.643437
# Unit test for function escape
def test_escape():
    assert escape(re.search("\\'", "\\'")) == "'"
    assert escape(re.search("\\\"", "\\\"")) == "\""


# Generated at 2022-06-25 14:51:32.311992
# Unit test for function escape
def test_escape():

    # Test case 1:
    m = re.match(r'\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\"')
    assert escape(m) == '"'
    # Test case 2:
    m = re.match(r'\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', "\\'")
    assert escape(m) == "'"
    # Test case 3:
    m = re.match(r'\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\a')
    assert escape(m) == '\x07'
   

# Generated at 2022-06-25 14:51:33.140752
# Unit test for function escape
def test_escape():
    assert escape('\a') == '\x07'

# Generated at 2022-06-25 14:51:34.569153
# Unit test for function escape
def test_escape():
    m = re.search("\\", "\\'")
    assert escape(m) == "'"


# Generated at 2022-06-25 14:51:41.620271
# Unit test for function escape
def test_escape():
    assert escape("\\'" ) == "'"
    assert escape("\\\"" ) == '"'
    assert escape("\\\"\\" ) == '\"\\'
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\xae") == "®"
    assert escape("\\x2d") == "-"
    assert escape("\\x2") == escape("\\x0") == escape("\\0") == '\x00'


# Generated at 2022-06-25 14:51:42.600566
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-25 14:51:50.116079
# Unit test for function escape
def test_escape():
    assert escape("\a") == "\a"
    assert escape("\b") == "\b"
    assert escape("\f") == "\f"
    assert escape("\n") == "\n"
    assert escape("\r") == "\r"
    assert escape("\t") == "\t"
    assert escape("\v") == "\v"
    assert escape("\'") == "\'"
    assert escape("\"") == "\""
    assert escape("\\") == "\\"
    assert escape("\xFF") == chr(255)
    assert escape("\777") == chr(511)
    assert escape("\888") == chr(888)
    assert escape("\88") == chr(72)
    assert escape("\08") == chr(8)

# Generated at 2022-06-25 14:52:09.109403
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\\'", r"\'")) == "\'"

# Generated at 2022-06-25 14:52:15.981179
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\"') == '\"'
    assert escape('\\\\') == '\\'



# Generated at 2022-06-25 14:52:16.782384
# Unit test for function test
def test_test():
    test()
    assert True



# Generated at 2022-06-25 14:52:17.560565
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:52:25.660976
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"

    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\''") == "\\'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"

    assert escape("\\x00") == "\x00"
    assert escape("\\x41") == "\x41"
    assert escape("\\x7f") == "\x7f"



# Generated at 2022-06-25 14:52:31.416119
# Unit test for function escape
def test_escape():
    # Test 1
    m = re.search('(\\\\)(\'|\"|\\\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', "\\'")
    assert escape(m) == "'", "Test 1"
    # Test 2
    m = re.search('(\\\\)(\'|\"|\\\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', "\\n")
    assert escape(m) == "\n", "Test 2"
    # Test 3
    m = re.search('(\\\\)(\'|\"|\\\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', "\\x03")

# Generated at 2022-06-25 14:52:35.831442
# Unit test for function escape
def test_escape():
    assert escape("\x40") == "@"
    assert escape("\x41") == "A"
    assert escape("\x42") == "B"
    assert escape("\x43") == "C"
    assert escape("\x44") == "D"
    assert escape("\x45") == "E"
    assert escape("\x46") == "F"
    assert escape("\x47") == "G"
    assert escape("\x48") == "H"
    assert escape("\x49") == "I"
    assert escape("\x4A") == "J"
    assert escape("\x4B") == "K"
    assert escape("\x4C") == "L"
    assert escape("\x4D") == "M"
    assert escape("\x4E") == "N"


# Generated at 2022-06-25 14:52:38.460422
# Unit test for function escape
def test_escape():
    m = re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\0")
    assert escape(m) == "\x00"


# Generated at 2022-06-25 14:52:39.419267
# Unit test for function test
def test_test():

    test()
    # No output
    assert True


# Generated at 2022-06-25 14:52:41.777349
# Unit test for function escape
def test_escape():
    a = {0:2}
    b = (1,2)
    c = "a"
    e = escape(a,b,c)
    if e == True:
        pass
    else:
        flag = False
    assert flag

# Generated at 2022-06-25 14:53:22.159463
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:53:28.464240
# Unit test for function test
def test_test():
    expected = """
0
1
2
3
4
5
6
7
8
9
\t
\n
\r
\x0c
\x0b
\x1c
\x1d
\x1e
\x1f
'
"
\\
0
1
2
3
4
5
6
7
8
9
\t
\n
\r
\x0c
\x0b
\x1c
\x1d
\x1e
\x1f
'
"
\\
"""
    test() # run it

    # Get the output from that test run
    import sys
    test_out = sys.stdout.getvalue()
    sys.stdout = sys.__stdout__ # restore stdout

    assert test_out == expected

# Generated at 2022-06-25 14:53:33.120839
# Unit test for function escape
def test_escape():
    result = evalString('"\\u2222"')
    assert result == '\u2222'
    result = evalString('"\\u2222"')
    assert result == '\u2222'
    result = evalString('"\\u2222"')
    assert result == '\u2222'



# Generated at 2022-06-25 14:53:33.647798
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-25 14:53:35.432789
# Unit test for function escape
def test_escape():
    result = escape("\x61")
    expected = "a"
    assert result == expected



# Generated at 2022-06-25 14:53:43.903162
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\x08'
    assert escape('\\f') == '\x0c'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\x0b'
    assert escape('\\x61') == 'a'
    assert escape('\\x39') == '9'
    assert escape('\\x0a') == '\n'
    assert escape('\\077') == '?'
    assert escape('\\41') == 'A'
    assert escape('\\41') == 'A'

# Generated at 2022-06-25 14:53:44.343763
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-25 14:53:52.709446
# Unit test for function escape
def test_escape():
    tail = "x23"
    expected = chr(0x23)
    actual = escape(re.search(r"\\(x.{0,2})", tail))
    assert actual == expected

    tail = "\""
    expected = '"'
    actual = escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", tail))
    assert actual == expected

    tail = "n"
    expected = "\n"
    actual = escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", tail))
    assert actual == expected

    tail = "\\"
    expected = "\\"
   

# Generated at 2022-06-25 14:53:53.692026
# Unit test for function test
def test_test():
    assert test() is None, "Return value of evalString is incorrect."


# Generated at 2022-06-25 14:53:54.395853
# Unit test for function test
def test_test():
    assert test() is None


# Generated at 2022-06-25 14:55:17.635495
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-25 14:55:18.966970
# Unit test for function test
def test_test():
    # Test that the return value is stable
    assert callable(test)

# Generated at 2022-06-25 14:55:19.772860
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:55:21.533443
# Unit test for function test
def test_test():
    assert evalString("'test'") == "test"


# Generated at 2022-06-25 14:55:28.725695
# Unit test for function escape

# Generated at 2022-06-25 14:55:31.226798
# Unit test for function test
def test_test():
    """Test function"""

    # Input parameters
    # No input parameters

    # Perform test
    test()

# Generated at 2022-06-25 14:55:35.107480
# Unit test for function escape
def test_escape():
    # Perform some tests.
    assert escape("\\a") == "a"
    assert escape("\\b") == "b"
    assert escape("\\n") == "n"
    assert escape("\\r") == "r"
    assert escape("\\t") == "t"
    assert escape("\\\\") == "\\"


# Generated at 2022-06-25 14:55:40.291316
# Unit test for function escape
def test_escape():
    # Test cases
    assert escape('\\x41') == 'A'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\\'\'') == '\''
    assert escape('\\"') == '"'
    assert escape('\\\\') == '\\'



# Generated at 2022-06-25 14:55:49.210237
# Unit test for function escape
def test_escape():
    # Python 3
    assert escape("\x00\x01") == "\\x00\\x01"
    assert escape("\x00") == "\\x00"
    assert escape("\\x00") == "\\\\x00"
    assert escape("\x01") == "\\x01"
    assert escape("\\x01") == "\\\\x01"
    assert escape("\x02") == "\\x02"
    assert escape("\\x02") == "\\\\x02"
    assert escape("\x03") == "\\x03"
    assert escape("\\x03") == "\\\\x03"
    assert escape("\x04") == "\\x04"
    assert escape("\\x04") == "\\\\x04"
    assert escape("\x05") == "\\x05"
    assert escape("\\x05")

# Generated at 2022-06-25 14:55:50.005388
# Unit test for function test
def test_test():
    assert test() == None

