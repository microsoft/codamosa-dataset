

# Generated at 2022-06-25 14:48:21.646833
# Unit test for function evalString
def test_evalString():
    # Test for evalString()
    assert evalString('"\\x1B[0m"') == '\x1B[0m'
    assert evalString('"\\x1B[1m"') == '\x1B[1m'
    assert evalString('"\\x1B[4m"') == '\x1B[4m'
    assert evalString('"\\x1B[5m"') == '\x1B[5m'
    assert evalString('"\\x1B[7m"') == '\x1B[7m'
    assert evalString('"\\x1B[30m"') == '\x1B[30m'
    assert evalString('"\\x1B[31m"') == '\x1B[31m'

# Generated at 2022-06-25 14:48:22.920735
# Unit test for function escape
def test_escape():
    assert 'e' == escape('a')


# Generated at 2022-06-25 14:48:32.031057
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\x41") == "A"
    assert escape("\\x7f") == chr(127)
    assert escape("\\x7ff") == chr(127) + "f"



# Generated at 2022-06-25 14:48:36.745402
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)


if __name__ == "__main__":
    test_evalString()

# Generated at 2022-06-25 14:48:47.190135
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\xab", '\\xab')) == '\xab'
    assert escape(re.match(r"\\xab", '\\xab')) == '\xab'
    assert escape(re.match(r"\\xab", '\\xab')) == '\xab'
    assert escape(re.match(r"\\xab", '\\xab')) == '\xab'
    assert escape(re.match(r"\\xab", '\\xab')) == '\xab'
    try:
        evalString('"\\x"')
        assert 0, "should have raised"
    except ValueError:
        pass


# Generated at 2022-06-25 14:48:54.898009
# Unit test for function evalString
def test_evalString():
    print("Testing evalString")

    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\\''") == "'"
    assert evalString("'\\\"'") == '"'
    assert evalString("'\\\\'") == "\\"

    assert evalString("'\\1'") == "\x01"
    assert evalString("'\\1'") == "\x01"

# Generated at 2022-06-25 14:48:58.052503
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|[0-7]{1,3}|x[0-9a-fA-F]{2})", "\\a")) == '\a'


# Generated at 2022-06-25 14:49:06.245887
# Unit test for function escape
def test_escape():
    tail = "\\xAA"
    m = re.search(r"\\(.{0,2})", tail)
    assert m.groups()[0] == "\\xAA"
    assert escape(m) == chr(170)

    tail = "\\x0"
    m = re.search(r"\\(.{0,2})", tail)
    assert m.groups()[0] == "\\x0"
    assert escape(m) == chr(0)

    tail = "\\x00"
    m = re.search(r"\\(.{0,2})", tail)
    assert m.groups()[0] == "\\x00"
    assert escape(m) == chr(0)

    tail = "\\x000"

# Generated at 2022-06-25 14:49:07.830270
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\x00", "\\x00")) == '\x00'


# Generated at 2022-06-25 14:49:18.607753
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\\\x10'") == '\x10'
    assert evalString("'\\a'") == '\a'
    assert evalString("'\\b'") == '\b'
    assert evalString("'\\f'") == '\f'
    assert evalString("'\\n'") == '\n'
    assert evalString("'\\r'") == '\r'
    assert evalString("'\\t'") == '\t'
    assert evalString("'\\v'") == '\v'
    assert evalString("'\\x10'") == '\x10'
    assert evalString("'\\100'") == '@'
    assert evalString("'\\777'") == '\u01ff'
    assert evalString("'\\''") == "'"

# Generated at 2022-06-25 14:49:42.166786
# Unit test for function escape
def test_escape():
    assert escape("\\a")== "\a"
    assert escape("\\ff") == "\x0ff"
    assert escape("\\n") == "\n"
    assert escape("\\") == "\\"

# Generated at 2022-06-25 14:49:44.082681
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert False, '`test` raised exception'


# Generated at 2022-06-25 14:49:46.119492
# Unit test for function escape
def test_escape():
    regex = re.compile(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})")

    # Valid escape
    match = re.search(regex, "\\x5a")
    if match != None:
        escape(match)


# Generated at 2022-06-25 14:49:46.992386
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"

# Generated at 2022-06-25 14:49:47.982649
# Unit test for function escape
def test_escape():
    assert escape("a") == "\a"

# Generated at 2022-06-25 14:49:56.227751
# Unit test for function escape
def test_escape():
    def _mock_match(match_string):
        class Match:
            def group(num):
                return (match_string,)[num]
        return Match()

    # Case 1
    match_string = "\\a"
    m = _mock_match(match_string)
    result = escape(m)
    assert(result == "\a")

     # Case 2
    match_string = "\\b"
    m = _mock_match(match_string)
    result = escape(m)
    assert(result == "\b")

     # Case 3
    match_string = "\\f"
    m = _mock_match(match_string)
    result = escape(m)
    assert(result == "\f")

     # Case 4
    match_string = "\\n"
    m = _m

# Generated at 2022-06-25 14:50:01.268940
# Unit test for function escape
def test_escape():
    # Set up test inputs
    in0 = "\\'";
    in1 = "\\'";

    # Call the function (using the globals to pass in the variables)
    # Function call
    out0 = escape(re.match("\\'", in0))

    # Compare the actual output to the expected output
    assert out0 == in1



# Generated at 2022-06-25 14:50:11.467113
# Unit test for function evalString

# Generated at 2022-06-25 14:50:15.096523
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, "Result does not match expected"


# Generated at 2022-06-25 14:50:18.930728
# Unit test for function test
def test_test():
    import StringIO
    import sys
    old_stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    test()
    assert sys.stdout.getvalue()
    sys.stdout = old_stdout


# Unit tests for function evalString

# Generated at 2022-06-25 14:50:40.437763
# Unit test for function escape
def test_escape():
    assert escape('\a') == "a"
    assert escape('\b') == "b"
    assert escape('\f') == "f"
    assert escape('\n') == "n"
    assert escape('\r') == "r"
    assert escape('\t') == "t"
    assert escape('\v') == "v"
    assert escape("'") == "'"
    assert escape('"') == '"'
    assert escape("\\") == "\\"

# Generated at 2022-06-25 14:50:49.940630
# Unit test for function escape
def test_escape():
    assert escape(chr(1)) == 'a'
    assert escape(chr(2)) == 'b'
    assert escape(chr(3)) == 'f'
    assert escape(chr(4)) == 'n'
    assert escape(chr(5)) == 'r'
    assert escape(chr(6)) == 't'
    assert escape(chr(7)) == 'v'
    assert escape(chr(8)) == '\\'
    assert escape(chr(9)) == '\\x00'
    assert escape(chr(10)) == '\\x00'
    assert escape(chr(11)) == '\\x00'
    assert escape(chr(12)) == '\\x00'
    assert escape(chr(13)) == '\\x00'

# Generated at 2022-06-25 14:50:50.609988
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-25 14:51:01.883393
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == '', "expected ''"
    assert evalString('""""') == '', "expected ''"
    assert evalString('"0a\n"') == '0a\n', "expected '0a\n'"
    assert evalString('"0a\n"') == '0a\n', "expected '0a\n'"
    assert evalString('"""0a\n"""') == '0a\n', "expected '0a\n'"
    assert evalString('"\\t\\n"') == '\t\n', "expected '\t\n'"
    assert evalString("'\\t\\n'") == '\t\n', "expected '\t\n'"
    assert evalString(r"'\r\n'") == '\r\n', 'expected \r\n'


# Generated at 2022-06-25 14:51:02.407278
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-25 14:51:03.210402
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:51:03.690702
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-25 14:51:14.150496
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == "foo"
    assert evalString('"foo"') == "foo"
    assert evalString("'''foo'''") == "foo"
    assert evalString('""foo""') == "foo"
    assert evalString('"""foo"""') == "foo"
    assert evalString("'''foo") == "foo"
    assert evalString("\"\"\"foo") == "foo"
    assert evalString("'foo\"\"\"") == "foo\"\"\""
    assert evalString("\"foo\'\'\'") == "foo\'\'\'"
    assert evalString("'\"foo\"'") == "\"foo\""
    assert evalString("\"\'foo\'\"") == "\'foo\'"
    assert evalString("\"\"\"\"\"\"") == ""
    assert evalString("'''''''")

# Generated at 2022-06-25 14:51:15.007356
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"

# Generated at 2022-06-25 14:51:17.763748
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = escape(s)
        if e != c:
            print(i, c, s, e)


# Generated at 2022-06-25 14:51:33.836560
# Unit test for function escape
def test_escape():
    assert evalString('"bla"') == 'bla'
    assert evalString('"bla bla"') == 'bla bla'
    assert evalString("'bla bla'") == 'bla bla'


# Generated at 2022-06-25 14:51:36.489542
# Unit test for function escape
def test_escape():
    m = re.search('\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\n')
    assert escape(m) == '\n'


# Generated at 2022-06-25 14:51:46.012696
# Unit test for function escape
def test_escape():

    # Case 0
    # Note: this case was originally disabled in the original test suite.
    # m = match object
    m = (r'', 'a')
    if escape(m) == "\a":
        pass

    # Case 1
    m = (r'', 'b')
    if escape(m) == "\b":
        pass

    # Case 2
    # Note: this case was originally disabled in the original test suite.
    m = (r'', 'f')
    if escape(m) == "\f":
        pass

    # Case 3
    m = (r'', 'n')
    if escape(m) == "\n":
        pass

    # Case 4
    # Note: this case was originally disabled in the original test suite.
    m = (r'', 'r')

# Generated at 2022-06-25 14:51:56.687118
# Unit test for function escape
def test_escape():
    #assert escape(('\\','a')) == '\a'
    #assert escape(('\\','b')) == '\b'
    #assert escape(('\\','f')) == '\f'
    #assert escape(('\\','n')) == '\n'
    #assert escape(('\\','r')) == '\r'
    #assert escape(('\\','t')) == '\t'
    #assert escape(('\\','v')) == '\v'
    #assert escape(('\\','\'')) == '\''
    #assert escape(('\\','"')) == '"'
    #assert escape(('\\','\\')) == '\\'
    assert escape(('\\','1')) == '\x01'


# Generated at 2022-06-25 14:51:59.718469
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\('\\'\)", "('\\')")) == "'"
    assert escape(re.match(r"\('\\\\'\)", "('\\\\')")) == "\\"


# Generated at 2022-06-25 14:52:00.728854
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-25 14:52:01.653535
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:52:10.257603
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\x0c'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\x0b'
    assert escape('\\xF0\\x9d\\x96\\x93') == '𝖓'
    assert escape('\\xF0\\x9d\\x96\\x93') == '𝖓'
    assert escape('\\xF0\\x9d') == '\xf0\x9d'
    assert escape('\\x') == 'x'
    assert escape('\\x1') == '\x01'
   

# Generated at 2022-06-25 14:52:13.162233
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"(\\'ab)","\\'ab")) == "'ab"
    assert escape(re.match(r"(\\'ab)","\\'ab")) != "ab"


# Generated at 2022-06-25 14:52:18.011585
# Unit test for function escape
def test_escape():
    esc = r"\\"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", esc)) == "\\"

    esc = r"\n"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", esc)) == "\n"

    esc = r"\x41"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", esc)) == "A"

    esc = r"\x1"

# Generated at 2022-06-25 14:52:30.213643
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-25 14:52:31.115761
# Unit test for function test
def test_test():
    assert 1

# Generated at 2022-06-25 14:52:31.945646
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:52:32.821380
# Unit test for function test
def test_test():
    pass


# Generated at 2022-06-25 14:52:34.288147
# Unit test for function test
def test_test():
    global i, assert_equals
    test()
    assert_equals(i, 255)

# Generated at 2022-06-25 14:52:37.269154
# Unit test for function test
def test_test():
    # Get current function name for use in unit test error messages
    func = get_current_function_name()
    # Set up constants to be used in unit tests
    expected = ''
    # Perform unit test
    test()
    # Verify expected results
    assert (expected == get_system_output())

# Generated at 2022-06-25 14:52:38.044100
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:52:40.440032
# Unit test for function test
def test_test():
    str1 = "tst"
    str2 = "test"
    assert test() == None, 'incorrect'
    test()


# Generated at 2022-06-25 14:52:43.365465
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\'', '\\')) == "\'"

    assert escape(re.match('\\\\', '\\')) == "\\"

    assert escape(re.match('\\\"', '\\')) == "\""


# Generated at 2022-06-25 14:52:50.472007
# Unit test for function escape
def test_escape():
    print(escape(re.match(r"[0-7]+", "0777")))
    print(escape(re.match(r"[0-7]+", "0")))
    print(escape(re.match(r"[0-7]+", "07")))
    print(escape(re.match(r"[0-7]+", "077")))
    print(escape(re.match(r"[0-7]+", "0777")))
    print(escape(re.match(r"[0-7]+", "0777")))
    
    

# Generated at 2022-06-25 14:53:21.804559
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\x10')) == '\x10'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\x101')) == '\x101'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\0052')) == 'R'

# Generated at 2022-06-25 14:53:22.585653
# Unit test for function test
def test_test():
    assert 1 == 1 , 'no test done'

# Generated at 2022-06-25 14:53:23.645010
# Unit test for function escape
def test_escape():
    assert escape('\\n') == '\n'


# Generated at 2022-06-25 14:53:24.855095
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:53:27.780006
# Unit test for function escape
def test_escape():
    match = mock.create_autospec(re.Match, instance=True)
    match.group.return_value = "\\x00"
    assert escape(match) == "\x00"
    match.group.assert_called_with(0, 1)



# Generated at 2022-06-25 14:53:28.670777
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:53:34.556274
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\a')
    print('test_escape:')
    #print(escape(m))
    if escape(m) == '\x07':
        print('Test case passed.')
    else:
        print('Test case failed.')


# Generated at 2022-06-25 14:53:39.709224
# Unit test for function escape
def test_escape():
    # We need the "re" module to be imported to run this
    global re
    # test the function with the following values
    values = [
        {
            "input": re,
            "output": None
        },
    ]
    for v in values:
        param = v.get("input")
        expected = v.get("output")

        # Calculate function output
        actual = escape(param)

        # compare with expected
        assert actual == expected



# Generated at 2022-06-25 14:53:40.891352
# Unit test for function test
def test_test():
    # Test the function
    test()
    assert True


# Generated at 2022-06-25 14:53:48.572849
# Unit test for function escape
def test_escape():
    assert (escape(Match(string=None, pos=0, endpos=0, lastgroup=None, lastindex=None, re=None, regs=None)) == '\\')
    assert (escape(Match(string=None, pos=1, endpos=1, lastgroup=None, lastindex=None, re=None, regs=None)) == '[')
    assert (escape(Match(string=None, pos=2, endpos=2, lastgroup=None, lastindex=None, re=None, regs=None)) == ']')
    assert (escape(Match(string=None, pos=3, endpos=3, lastgroup=None, lastindex=None, re=None, regs=None)) == 'a')

# Generated at 2022-06-25 14:54:58.257600
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:55:00.120435
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 14:55:00.954090
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:55:05.639763
# Unit test for function escape
def test_escape():
    test_escape.counter += 1
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")
    assert m.group(0) == "\\n"
    assert m.group(1) == "n"
    s = evalString(r'"\x41\n\t\\\x83"')
    assert s == "\x41\n\t\\\x83"

test_escape.counter = 0

# Generated at 2022-06-25 14:55:07.445562
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:55:08.980896
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x1A", "\\x1A")) == "\x1A"


# Generated at 2022-06-25 14:55:09.361822
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:55:09.720235
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-25 14:55:15.168207
# Unit test for function escape
def test_escape():
    assert escape('\\x0a') == '\n'
    assert escape('\\x0A') == '\n'
    with pytest.raises(ValueError) as exc_info:
        escape('\\x0')
    assert str(exc_info.value) == "invalid hex string escape ('\\x0')"


# Generated at 2022-06-25 14:55:24.525316
# Unit test for function escape
def test_escape():
    try:
        escape(re.match(r"\\.", "\\x"))
    except ValueError:
        pass
    else:
        raise AssertionError

    try:
        escape(re.match(r"\\.", "\\xz"))
    except ValueError:
        pass
    else:
        raise AssertionError

    try:
        escape(re.match(r"\\.", "\\0"))
    except ValueError:
        pass
    else:
        raise AssertionError

    try:
        escape(re.match(r"\\.", "\\8"))
    except ValueError:
        pass
    else:
        raise AssertionError

    try:
        escape(re.match(r"\\(.|$)", "\\j"))
    except ValueError:
        pass