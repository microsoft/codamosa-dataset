

# Generated at 2022-06-25 14:48:24.694084
# Unit test for function test
def test_test():
    # check with valid input
    test()


# Generated at 2022-06-25 14:48:30.332520
# Unit test for function escape
def test_escape():
    sample = "\\x22"
    input = re.sub(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", escape, sample)
    solution = '"'
    print ("\nInput\t",sample)
    print ("Output\t",input)
    print ("Expected\t",solution)
    assert input == solution


# Generated at 2022-06-25 14:48:40.328584
# Unit test for function escape
def test_escape():
    m = re.match(r"\\([n\\\'\"]|[0-7]{1,3}|x.{0,2}|[abfnrtv])", '\\n')
    assert m
    assert escape(m) == "\n"
    m = re.match(r"\\([n\\\'\"]|[0-7]{1,3}|x.{0,2}|[abfnrtv])", '\\0')
    assert m
    assert escape(m) == "\x00"
    m = re.match(r"\\([n\\\'\"]|[0-7]{1,3}|x.{0,2}|[abfnrtv])", '\\xFF')
    assert m
    assert escape(m) == "ÿ"


# Generated at 2022-06-25 14:48:43.962359
# Unit test for function escape
def test_escape():

    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")
    assert escape(m) == "'"


# Generated at 2022-06-25 14:48:52.859405
# Unit test for function escape
def test_escape():
    # \005 is invalid, so escape should raise a ValueError
    assert escape(re.match(r"\\005", r"\\005")) is ValueError
    assert escape(re.match(r"\\005", r"\\005")) is None
    # \5 is valid, so escape should not raise a ValueError
    assert escape(re.match(r"\\5", r"\\5")) is not ValueError
    assert escape(re.match(r"\\5", r"\\5")) is not None
    # \5 should translate to control-E
    assert escape(re.match(r"\\5", r"\\5")) == "\x05"
    assert escape(re.match(r'\\"', r'\\"')) == "\""
    assert escape(re.match(r"\\'", r"\\'")) == "'"


# Generated at 2022-06-25 14:48:54.233188
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\n', '\n')) == '\n'


# Generated at 2022-06-25 14:48:56.232919
# Unit test for function escape
def test_escape():
    evalString('"\\x53\\x4c\\x49\\x43\\x45\\x53"')



# Generated at 2022-06-25 14:49:01.455695
# Unit test for function escape
def test_escape():
    pattern = re.compile(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})")
    assert pattern.match('\\n').group(1) == 'n'
    assert pattern.match('\\x6c').group(1) == 'x6c'
    assert pattern.match('\\072').group(1) == '72'


# Generated at 2022-06-25 14:49:11.905354
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        if c == '"':
            assert escape('\\"' + c) == '"', 'Failed string \\' + c + '"'
        elif c == "'":
            assert escape("\\'" + c) == "'", 'Failed string \\' + c + "'"
        elif c == "\\":
            assert escape("\\\\" + c) == "\\", 'Failed string \\\\' + c
        elif c == "\a":
            assert escape("\\a" + c) == "\a", 'Failed string \\a' + c
        elif c == "\b":
            assert escape("\\b" + c) == "\b", 'Failed string \\b' + c

# Generated at 2022-06-25 14:49:14.131372
# Unit test for function test
def test_test():

    # Arrange


    # Act
    test()

    # Assert
    # ...

# Generated at 2022-06-25 14:49:25.768208
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'


# Generated at 2022-06-25 14:49:36.092545
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", "\\'")) == "'"

# Generated at 2022-06-25 14:49:40.838900
# Unit test for function escape
def test_escape():
    assert escape(re.match(escape, r'\t')) == '\t'
    assert escape(re.match(escape, r'\xab')) == '\xab'
    assert escape(re.match(escape, r'\177')) == '\177'
    assert escape(re.match(escape, r'\377')) == '\xff'


# Generated at 2022-06-25 14:49:42.166964
# Unit test for function escape
def test_escape():
	assert escape("1") == 1


# Generated at 2022-06-25 14:49:43.174440
# Unit test for function escape
def test_escape():
    test_case_0()

test_escape()

# Generated at 2022-06-25 14:49:52.640349
# Unit test for function escape
def test_escape():
    m = re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\a')
    assert m.group(1) == 'a'
    assert m.group(0) == '\\a'
    assert escape(m) == "\a"

    m = re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\b')
    assert m.group(1) == 'b'
    assert m.group(0) == '\\b'
    assert escape(m) == "\b"


# Generated at 2022-06-25 14:49:58.910823
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(.)", "\\a")
    if m:
        assert simple_escapes[m.group(1)] == '\a'
    m = re.match(r"\\(.)", "\\b")
    if m:
        assert simple_escapes[m.group(1)] == '\b'
    m = re.match(r"\\(.)", "\\f")
    if m:
        assert simple_escapes[m.group(1)] == '\f'
    m = re.match(r"\\(.)", "\\n")
    if m:
        assert simple_escapes[m.group(1)] == '\n'
    m = re.match(r"\\(.)", "\\r")

# Generated at 2022-06-25 14:50:10.090014
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", r"\x12")) == "\\x12"
    assert escape(re.match(r"\\a", r"\a")) == "\\x07"
    assert escape(re.match(r"\\b", r"\b")) == "\\x08"
    assert escape(re.match(r"\\f", r"\f")) == "\\x0c"
    assert escape(re.match(r"\\n", r"\n")) == "\\x0a"
    assert escape(re.match(r"\\r", r"\r")) == "\\x0d"
    assert escape(re.match(r"\\t", r"\t")) == "\\x09"

# Generated at 2022-06-25 14:50:10.834003
# Unit test for function escape
def test_escape():
    test_escape_0()


# Generated at 2022-06-25 14:50:11.945961
# Unit test for function escape
def test_escape():
    assert escape("a") == "a"


# Generated at 2022-06-25 14:50:49.855235
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\'\\") == "'\\"
    assert escape("\\'\\") == "'\\"
    assert escape("\\x123") == "\u0123"
    assert escape("\\x123") == "\u0123"
    assert escape("\\x12") == "\u0012"
    assert escape("\\x12") == "\u0012"

# Generated at 2022-06-25 14:50:51.465146
# Unit test for function escape
def test_escape():
    t = r"\1"
    result = escape(t)
    assert result == "\\1"


# Generated at 2022-06-25 14:50:52.457363
# Unit test for function escape

# Generated at 2022-06-25 14:51:03.137405
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(a)", "\\a")).__eq__("\a"), "unexpected result"
    assert escape(re.search(r"\\(b)", "\\b")).__eq__("\b"), "unexpected result"
    assert escape(re.search(r"\\(f)", "\\f")).__eq__("\f"), "unexpected result"
    assert escape(re.search(r"\\(n)", "\\n")).__eq__("\n"), "unexpected result"
    assert escape(re.search(r"\\(r)", "\\r")).__eq__("\r"), "unexpected result"
    assert escape(re.search(r"\\(t)", "\\t")).__eq__("\t"), "unexpected result"

# Generated at 2022-06-25 14:51:04.212326
# Unit test for function escape
def test_escape():
    m = "\\x0A"
    assert escape(m) == "\n"

# Generated at 2022-06-25 14:51:05.301194
# Unit test for function escape
def test_escape():
    assert escape("'") == "'"


# Generated at 2022-06-25 14:51:15.326484
# Unit test for function escape
def test_escape():
    a = escape('\\a')
    assert a == '\a'

    a = escape('\\b')
    assert a == '\x08'

    a = escape('\\f')
    assert a == '\x0c'

    a = escape('\\n')
    assert a == '\n'

    a = escape('\\r')
    assert a == '\r'

    a = escape('\\t')
    assert a == '\t'

    a = escape('\\v')
    assert a == '\x0b'

    a = escape('\\\'')
    assert a == '\''

    a = escape('\\"')
    assert a == '\"'

    a = escape('\\\\')
    assert a == '\\'


# Generated at 2022-06-25 14:51:22.416495
# Unit test for function escape
def test_escape():
    r = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3}", r"\\x1")
    assert escape(r) == '\x01'
    r = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3}", r"\\x1f")
    assert escape(r) == '\x1f'
    r = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3}", r"\\x1F")
    assert escape(r) == '\x1F'
    r = re.match

# Generated at 2022-06-25 14:51:33.641146
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\x7e")) == "~"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\177")) == "\177"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\777")) == "\udc07"

# Generated at 2022-06-25 14:51:38.807908
# Unit test for function escape
def test_escape():
    assert evalString('"foo"') == "foo"
    assert evalString('"foo\nbar"') == "foo\nbar"
    assert evalString('"foo\x01bar"') == "foo\x01bar"
    assert evalString('"\\x01"') == "\x01"
    assert evalString('"\\x41"') == "A"
    assert evalString('"\\0"') == "\0"



# Generated at 2022-06-25 14:51:53.326186
# Unit test for function test
def test_test():
    assert not False



# Generated at 2022-06-25 14:51:57.612541
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")
    assert m.group(0) == "\\n"
    assert m.group(1) == "n"
    assert escape(m) == "\n"



# Generated at 2022-06-25 14:52:07.662818
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\a')) == '\a'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\b')) == '\b'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\f')) == '\x0c'

# Generated at 2022-06-25 14:52:17.232180
# Unit test for function escape
def test_escape():
    s = '\\\a'
    assert escape(s) == '\a'
    s = '\\\b'
    assert escape(s) == '\b'
    s = '\\\f'
    assert escape(s) == '\f'
    s = '\\\n'
    assert escape(s) == '\n'
    s = '\\\r'
    assert escape(s) == '\r'
    s = '\\\t'
    assert escape(s) == '\t'
    s = '\\\v'
    assert escape(s) == '\v'
    s = "\\'"
    assert escape(s) == "'"
    s = '\\"'
    assert escape(s) == '"'
    s = '\\\\'
    assert escape(s) == '\\'



# Generated at 2022-06-25 14:52:18.913345
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert False


# Generated at 2022-06-25 14:52:21.584092
# Unit test for function escape
def test_escape():
    c = escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\\x0F'))
    assert c == '\x0f'


# Generated at 2022-06-25 14:52:29.985720
# Unit test for function escape
def test_escape():
    test_escape_case_0()
    test_escape_case_1()
    test_escape_case_2()
    test_escape_case_3()
    test_escape_case_4()
    test_escape_case_5()
    test_escape_case_6()
    test_escape_case_7()
    test_escape_case_8()
    test_escape_case_9()
    test_escape_case_10()
    test_escape_case_11()
    test_escape_case_12()
    test_escape_case_13()
    test_escape_case_14()
    test_escape_case_15()
    test_escape_case_16()
    test_escape_case_17()
    test_escape_case_18()
    test_escape_case_19()

# Generated at 2022-06-25 14:52:31.260352
# Unit test for function test
def test_test():
    assert test() is None


# Generated at 2022-06-25 14:52:33.730379
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-25 14:52:34.249160
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-25 14:52:53.126672
# Unit test for function escape

# Generated at 2022-06-25 14:53:03.106978
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\xabcd")) == "\xab"
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\xabcd")) == "\xab"
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\xabcd")) == "\xab"

# Generated at 2022-06-25 14:53:03.928504
# Unit test for function test
def test_test():
    assert None == test()
    return

# Generated at 2022-06-25 14:53:09.757100
# Unit test for function escape
def test_escape():
    from io import StringIO
    from unittest import mock
    import ast
    import sys

    def runtest(testcase, m):
        if len(testcase["pass"]) > 0:
            sys.stdout = StringIO()
            try:
                testcase["func"]()
            except:
                print("FAIL: %s" % testcase["func"].__name__)
                print("REASON: %s" % sys.exc_info()[0])
            sys.stdout = StringIO()
        else:
            testcase["func"]()

    testcases = {
        "test_case_0": {
            "func": test_case_0,
            "pass": [
                "output.txt",
                "input.txt",
            ],
        },
    }

    # test setup
   

# Generated at 2022-06-25 14:53:16.371066
# Unit test for function escape
def test_escape():
    x = re.compile('(\\\\)([abfnrtv]|x.{0,2}|[0-7]{1,3})')

    # UNARY_CONVERSION
    x = re.compile('(\\\\)([abfnrtv]|x.{0,2}|[0-7]{1,3})')

    # BINARY_CONVERSION
    x = re.compile('(\\\\)([abfnrtv]|x.{0,2}|[0-7]{1,3})')


# Generated at 2022-06-25 14:53:19.655286
# Unit test for function escape
def test_escape():
    assert escape('\\"') == '"'
    assert escape('\\n') == "\n"
    assert escape('\\x1') == "\x01"
    assert escape('\\x01') == "\x01"
    assert escape('\\0') == "\x00"
    assert escape('\\08') == "\x08"


# Generated at 2022-06-25 14:53:26.121481
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape("\\\"") == '"'
    assert escape("\\\\") == "\\"

    assert escape("\\x1F") == "\x1F"
    assert escape("\\100") == chr(100)
    assert escape("\\10") == chr(10)
    assert escape("\\01") == chr(1)



# Generated at 2022-06-25 14:53:26.673987
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-25 14:53:27.744789
# Unit test for function escape
def test_escape():
    assert escape(None) == "\x00"


# Generated at 2022-06-25 14:53:28.935885
# Unit test for function escape
def test_escape():
    assert escape("\x03") == ''


# Generated at 2022-06-25 14:54:58.219454
# Unit test for function escape
def test_escape():
    m1 = re.match(r"\\(b)", '\\b')
    assert escape(m1) == '\b'

    m2 = re.match(r"\\(x)", '\\x')
    try:
        escape(m2)
        assert False
    except:
        assert True

    m3 = re.match(r"\\(x\w{0,2})", '\\x')
    try:
        escape(m3)
        assert False
    except:
        assert True

    m4 = re.match(r"\\(x\w{0,2})", '\\xw')
    try:
        escape(m4)
        assert False
    except:
        assert True


# Generated at 2022-06-25 14:55:05.777934
# Unit test for function escape
def test_escape():
    assert escape(re.search('\\[abfnrtv]', 'ab')) == "\a"
    assert escape(re.search('\\[abfnrtv]', 'ba')) == "\b"
    assert escape(re.search('\\[abfnrtv]', 'fa')) == "\f"
    assert escape(re.search('\\[abfnrtv]', 'na')) == "\n"
    assert escape(re.search('\\[abfnrtv]', 'ra')) == "\r"
    assert escape(re.search('\\[abfnrtv]', 'ta')) == "\t"
    assert escape(re.search('\\[abfnrtv]', 'va')) == "\v"
    assert escape(re.search('\\[abfnrtv]', '\'')) == "\'"


# Generated at 2022-06-25 14:55:12.373554
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\xa")
    assert m.group(0) == '\\xa'
    assert m.group(1) == 'xa'
    assert escape(m) == '\n'


# Generated at 2022-06-25 14:55:18.892094
# Unit test for function escape
def test_escape():
    assert escape(re.search("\\a", "\a")) == "\a"
    assert escape(re.search("\\b", "\b")) == "\b"
    assert escape(re.search("\\f", "\f")) == "\f"
    assert escape(re.search("\\n", "\n")) == "\n"
    assert escape(re.search("\\r", "\r")) == "\r"
    assert escape(re.search("\\t", "\t")) == "\t"
    assert escape(re.search("\\v", "\v")) == "\v"



# Generated at 2022-06-25 14:55:19.422971
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:55:20.772925
# Unit test for function test
def test_test():
    test()
    return

# Test cases for function evalString

# Generated at 2022-06-25 14:55:22.058231
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:55:22.906177
# Unit test for function test
def test_test():
    assert test() == None



# Generated at 2022-06-25 14:55:25.481948
# Unit test for function escape
def test_escape():
    m=re.match(r"\\([abfnrtv\\\'\"]|x.{0,2}|[0-7]{1,3})","\\n")
    print(escape(m))


# Generated at 2022-06-25 14:55:31.655390
# Unit test for function escape
def test_escape():
    m = re.compile(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})").match
    assert escape(m("\\a")) == "\a"
    assert escape(m('\\"')) == '"'
    assert escape(m('\\x41')) == 'A'
    assert escape(m('\\x414243')) == 'ABC'
    assert escape(m('\\077')) == '?'
    assert escape(m('\\177')) == '\x7f'
    assert escape(m('\\377')) == '\xff'
    try:
        escape(m('\\x'))
    except ValueError:
        pass
    else:
        assert 0, "expected ValueError"

# Generated at 2022-06-25 14:56:50.666826
# Unit test for function test
def test_test():
    # Standard print for debugging
    print("test_test():\n")

    test()
    
    

# Generated at 2022-06-25 14:56:51.274668
# Unit test for function escape
def test_escape():
    print("FUck me")


# Generated at 2022-06-25 14:56:57.579078
# Unit test for function escape
def test_escape():
    # function should throw error if there is a tail without a \
    try:
        escape(re.search(r"^(\\{1})([a-zA-Z0-9][a-zA-Z0-9])$", "\\2"))
    except ValueError:
        assert True
    else:
        assert False

    # function should throw error if there is a tail that does not
    # a hex string escape
    try:
        escape(re.search(r"^(\\{1})(x[a-zA-Z0-9][a-zA-Z0-9])$", "\\x2"))
    except ValueError:
        assert (True)
    else:
        assert (False)

    # function should throw error if there is a tail that contains an
    # invalid hex string escape

# Generated at 2022-06-25 14:57:00.297611
# Unit test for function escape
def test_escape():
    m: Match[Text]
    assert escape(m) == "\\", repr(m.group(0, 1))



# Generated at 2022-06-25 14:57:08.259980
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"(\\.')", "\\x12")) == "\x12"
    assert escape(re.match(r"(\\.')", "\\xAB")) == "\xab"
    assert escape(re.match(r"(\\.')", "\\xAB")) == "\xab"
    assert escape(re.match(r"(\\.')", "\\x51")) == "Q"
    assert escape(re.match(r"(\\.')", "\\x12AB")) == "\x12AB"
    assert escape(re.match(r"(\\.')", "\\xABAB")) == "\xabab"
    assert escape(re.match(r"(\\.')", "\\xAB51")) == "\xabQ"
    assert escape(re.match(r"(\\.')", "\\x125195")) == "\x125195"


# Generated at 2022-06-25 14:57:12.833083
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\ab")
    assert escape(m) == "\a"
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\xbx")
    assert escape(m) == "bx"
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x2C")
    assert escape(m) == ","

# Generated at 2022-06-25 14:57:14.655795
# Unit test for function test
def test_test():
    assert callable(test), "test is not a function"


test_test()

test_case = {
    "test": test,
    "evalString": evalString,
}

# Generated at 2022-06-25 14:57:24.290019
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([abfnrtv])', '\\' + '\a')) == '\a'
    assert escape(re.match(r'\\([abfnrtv])', '\\' + '\b')) == '\b'
    assert escape(re.match(r'\\([abfnrtv])', '\\' + '\f')) == '\f'
    assert escape(re.match(r'\\([abfnrtv])', '\\' + '\n')) == '\n'
    assert escape(re.match(r'\\([abfnrtv])', '\\' + '\r')) == '\r'
    assert escape(re.match(r'\\([abfnrtv])', '\\' + '\t')) == '\t'
   

# Generated at 2022-06-25 14:57:26.320327
# Unit test for function test
def test_test():
    print("Test test")
    # Test test



# Generated at 2022-06-25 14:57:34.966383
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x0a")) == "\n"
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x0A")) == "\n"