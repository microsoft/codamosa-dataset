

# Generated at 2022-06-25 14:48:28.929515
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x2[12]", "\\x2d")) == "-"
    assert escape(re.match(r"\\x2[12]", "\\x2D")) == "-"
    assert escape(re.match(r"\\x0.", "\\x06")) == chr(6)
    assert escape(re.match(r"\\x0.", "\\x06")) == chr(6)
    assert escape(re.match(r"\\x.", "\\x6")) == chr(6)
    assert escape(re.match(r"\\x.", "\\x6")) == chr(6)
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"

# Generated at 2022-06-25 14:48:33.669070
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x72")
    assert m.groups() == ('x72',)
    assert escape(m) == 'r'

    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")
    assert m.groups() == ('n',)
    assert escape(m) == '\n'

    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\72")
    assert m.groups()

# Generated at 2022-06-25 14:48:34.855378
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:48:43.059249
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x1", "\\x1")) == "\x01"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x123", "\\x123")) == "\x123"
    assert escape(re.match(r"\\x1234", "\\x1234")) == "\x1234"
    #
    assert escape(re.match(r"\\000", "\\000")) == "\x00"
    assert escape(re.match(r"\\001", "\\001")) == "\x01"
    assert escape(re.match(r"\\022", "\\022")) == "\x12"

# Generated at 2022-06-25 14:48:46.766750
# Unit test for function escape
def test_escape():

    # Setup
    m = {}
    m["tail"] = "\\"
    m["group"] = ["\\", "\\"]

    # Exercise
    result = escape(m)

    # Verify
    assert result == "\\"


# Generated at 2022-06-25 14:48:48.726325
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)
    return

# Generated at 2022-06-25 14:48:56.162627
# Unit test for function escape

# Generated at 2022-06-25 14:49:04.661002
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\b", str)) == "\b", "'\\b'"
    assert escape(re.match(r"\f", str)) == "\f", "'\\f'"
    assert escape(re.match(r"\n", str)) == "\n", "'\\n'"
    assert escape(re.match(r"\r", str)) == "\r", "'\\r'"
    assert escape(re.match(r"\t", str)) == "\t", "'\\t'"
    assert escape(re.match(r"\v", str)) == "\v", "'\\v'"
    assert escape(re.match(r"\'", str)) == "\'", "'\\''"
    assert escape(re.match(r"\"", str)) == "\"", "'\"'"

# Generated at 2022-06-25 14:49:10.087403
# Unit test for function escape
def test_escape():
    assert escape(r'\n') == '\n'
    assert escape(r'\x15') == '\x15'
    assert escape(r'\115') == 'M'
    assert escape(r'\x1') == '\x01'

# Generated at 2022-06-25 14:49:12.162066
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv])", r"\b")) == "\b"



# Generated at 2022-06-25 14:49:39.888212
# Unit test for function escape
def test_escape():
    m = re.match('(\\a)', '\a')
    assert escape(m) == '\a'

    m = re.match('(\\\b)', '\b')
    assert escape(m) == '\b'

    m = re.match('(\\\f)', '\f')
    assert escape(m) == '\f'

    m = re.match('(\\\n)', '\n')
    assert escape(m) == '\n'

    m = re.match('(\\\r)', '\r')
    assert escape(m) == '\r'

    m = re.match('(\\\t)', '\t')
    assert escape(m) == '\t'

    m = re.match('(\\\v)', '\v')

# Generated at 2022-06-25 14:49:50.165884
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\\"', '\\\"')) == '"'
    assert escape(re.match(r'\\\\', '\\\\')) == '\\'
    assert escape(re.match(r'\\a', '\\a')) == '\a'
    assert escape(re.match(r'\\b', '\\b')) == '\b'
    assert escape(re.match(r'\\f', '\\f')) == '\f'
    assert escape(re.match(r'\\n', '\\n')) == '\n'
    assert escape(re.match(r'\\r', '\\r')) == '\r'
    assert escape(re.match(r'\\t', '\\t')) == '\t'

# Generated at 2022-06-25 14:49:57.651006
# Unit test for function escape
def test_escape():
    # Test 0
    try:
        __expected = "\N{LINE FEED}"
    except KeyError:
        __expected = '\\n'
    __result = evalString(r'"\n"')
    assert __result == __expected

    # Test 1

# Generated at 2022-06-25 14:50:00.094897
# Unit test for function escape
def test_escape():
    str = "\\xFF"
    result = escape(str)
    assert result == "\xFF"


# Generated at 2022-06-25 14:50:02.119309
# Unit test for function test
def test_test():
    # Assign parameter
    # Execute function
    test()
    # Compare result
    # Cleanup
    pass



# Generated at 2022-06-25 14:50:03.323493
# Unit test for function test
def test_test():
    test_case_0()

# Generated at 2022-06-25 14:50:04.899693
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:50:05.788554
# Unit test for function evalString
def test_evalString():
    test()

# Test for function evalString

# Generated at 2022-06-25 14:50:06.731232
# Unit test for function test
def test_test():
    assert test() == None



# Generated at 2022-06-25 14:50:07.944128
# Unit test for function test
def test_test():
    test_case_0()
    pass

# Generated at 2022-06-25 14:50:41.010676
# Unit test for function escape
def test_escape():
    assert escape('\\a') == "\a"
    assert escape('\\b') == "\b"
    assert escape('\\f') == "\f"
    assert escape('\\n') == "\n"
    assert escape('\\r') == "\r"
    assert escape('\\t') == "\t"
    assert escape('\\v') == "\v"
    assert escape('\\\'') == "\'"
    assert escape('\\\"') == '"'
    assert escape('\\\\') == "\\"
    assert escape('\\x5c') == "\\"
    assert escape('\\x5C') == "\\"
    assert escape('\\11') == "\t"
    assert escape('\\111') == "I"
    assert escape('\\1111') == "I1"
    assert escape('\\x1234') == "S4"
   

# Generated at 2022-06-25 14:50:42.225087
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'


# Generated at 2022-06-25 14:50:51.475885
# Unit test for function escape
def test_escape():
    #assert False # No test available
    assert len(escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})",'\\n')))==1
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})",'\\n'))=='\n'
    assert evalString('"\n"')=='\n'
    assert evalString('"\xFF"')=='ÿ'
    assert evalString('\'\xFF\'')=='ÿ'


# Generated at 2022-06-25 14:50:56.634704
# Unit test for function escape
def test_escape():
    """Test function escape."""
    assert escape(re.match(r'\\([abfnrtv\'"]|\\)', r'\a')) == '\x07'
    assert escape(re.match(r'\\([abfnrtv\'"]|\\)', r'\x61')) == 'a'
    assert escape(re.match(r'\\([abfnrtv\'"]|\\)', r"\'")) == "'"
    assert escape(re.match(r'\\([abfnrtv\'"]|\\)', r"\"")) == '"'
    
# Testing the concrete argument types raises a type error

# Generated at 2022-06-25 14:50:59.487210
# Unit test for function escape
def test_escape():
    # Handle errors correctly.
    escape_test_exceptions()
    escape_test_invalid_octal()
    escape_test_invalid_hex()


# Generated at 2022-06-25 14:51:00.388581
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:51:05.247175
# Unit test for function test
def test_test():
    tests = [
        # each element of test is a 3-element tuple
        # (expected, test_expression, note)
        # expected: bool
        # test_expression: bool
        # note: str
        (True, True, "#1"),
        (False, False, "#2"),
    ]
    for expected, test_expr, note in tests:
        _test_0(expected, test_expr, note)


# Generated at 2022-06-25 14:51:15.690331
# Unit test for function escape
def test_escape():
    # Test case 2
    re.group = MockGroup2()
    try:
        if escape('\\a') != '\x07':
            raise AssertionError
    except ValueError:
        pass
    # Test case 3
    re.group = MockGroup3()
    try:
        if escape('\\a') != '\x07':
            raise AssertionError
    except ValueError:
        pass
    # Test case 4
    re.group = MockGroup4()
    if escape('\\a') != 'a':
        raise AssertionError
    # Test case 5
    re.group = MockGroup5()
    try:
        if escape('\\xabc') != '\xab':
            raise AssertionError
    except ValueError:
        pass
    # Test case 6
    re.group = MockGroup

# Generated at 2022-06-25 14:51:22.405435
# Unit test for function escape
def test_escape():
    import re
    escape_regex = re.compile(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})")
    assert escape(escape_regex.match(r"\x00")) == "\x00"
    assert escape(escape_regex.match(r"\\x00")) == "\\x00"
    assert escape(escape_regex.match(r"\x7f")) == "\x7f"
    assert escape(escape_regex.match(r"\\x7f")) == "\\x7f"
    assert escape(escape_regex.match(r"\x80")) == "\x80"
    assert escape(escape_regex.match(r"\\x80")) == "\\x80"

# Generated at 2022-06-25 14:51:22.987864
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-25 14:52:07.551193
# Unit test for function test
def test_test():
    try:
        test()

    except:
        pass



# Generated at 2022-06-25 14:52:08.590202
# Unit test for function escape
def test_escape():
    assert escape('\\') == '\\'
    

# Generated at 2022-06-25 14:52:14.743701
# Unit test for function escape
def test_escape():
    ch = '\\'
    tail = 'x'
    res = escape(ch + tail)
    assert (res == 'x')
    tail = 'x1234'
    res = escape(ch + tail)
    assert (res == 'x')
    tail = 'x123'
    res = escape(ch + tail)
    assert (res == 'x')
    tail = 'x12'
    res = escape(ch + tail)
    assert (res == 'x')
    tail = 'x1'
    res = escape(ch + tail)
    assert (res == 'x')
    tail = 'x'
    res = escape(ch + tail)
    assert (res == 'x')
    tail = 'x1x'
    assert (escape(ch + tail) == 'x')
    tail = '1'
   

# Generated at 2022-06-25 14:52:22.651869
# Unit test for function escape
def test_escape():
    assert escape("\\x") == "\\x"
    assert escape("\\0") == '\x00'
    assert escape("\\0") == '\x00'
    assert escape("\\1") == '\x01'
    assert escape("\\2") == '\x02'
    assert escape("\\3") == '\x03'
    assert escape("\\4") == '\x04'
    assert escape("\\5") == '\x05'
    assert escape("\\6") == '\x06'
    assert escape("\\7") == '\x07'
    assert escape("\\'") == "'"
    assert escape("\\0") == '\x00'
    assert escape("\\0") == '\x00'
    assert escape("\\0") == '\x00'
    assert escape("\\0")

# Generated at 2022-06-25 14:52:30.022795
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\xdf", "\\xdf")) == "\xdf"
    assert escape(re.match(r"\\xdf", "\\xdf")) == "\xdf"
    assert escape(re.match(r"\\xdf", "\\xdf")) == "\xdf"
    assert escape(re.match(r"\\xdf", "\\xdf")) == "\xdf"
    assert escape(re.match(r"\\xdf", "\\xdf")) == "\xdf"
    assert escape(re.match(r"\\xdf", "\\xdf")) == "\xdf"
    assert escape(re.match(r"\\xdf", "\\xdf")) == "\xdf"


# Generated at 2022-06-25 14:52:32.232986
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(.{2})', '\\x2A')) == '*'


# Generated at 2022-06-25 14:52:33.414052
# Unit test for function escape
def test_escape():
	assert escape('\\000').startswith('\x00')

# Generated at 2022-06-25 14:52:34.246481
# Unit test for function test
def test_test():
    assert test() is None


# Generated at 2022-06-25 14:52:41.512954
# Unit test for function escape
def test_escape():
    # String does not match
    m = re.match('abcde', 'abcdefgh')
    assert escape(m) == 'g'

    # Nothing is nothing
    m = re.match('', '')
    assert escape(m) == ''

    # '\x00' is not a hexadecimal number
    m = re.match('\\x00', '\\x00123')
    assert escape(m) == '3'

    # '\x' is not a hexadecimal number
    m = re.match('\\x', '\\x123')
    assert escape(m) == '3'

    # '\1' is a octal number
    m = re.match('\\1', '\\1221')
    assert escape(m) == '1'

    # '\1' is not a octal number


# Generated at 2022-06-25 14:52:42.496333
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-25 14:53:52.160399
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\a", "\\a")) == "\a"
    assert escape(re.match("\\b", "\\b")) == "\b"
    assert escape(re.match("\\f", "\\f")) == "\f"
    assert escape(re.match("\\n", "\\n")) == "\n"
    assert escape(re.match("\\r", "\\r")) == "\r"
    assert escape(re.match("\\t", "\\t")) == "\t"
    assert escape(re.match("\\v", "\\v")) == "\v"
    assert escape(re.match("\\'", "\\'")) == "\'"
    assert escape(re.match("\\\"", "\\\"")) == "\""
    assert escape(re.match("\\\\", "\\\\")) == "\\"

# Generated at 2022-06-25 14:53:52.895900
# Unit test for function test
def test_test():
    assert callable(test)

# Generated at 2022-06-25 14:54:02.046810
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\xA1")) == "\u00a1"
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\xA")) == r"\xA"

# Generated at 2022-06-25 14:54:11.958809
# Unit test for function escape
def test_escape():
    _match = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\a')
    assert _match.group(0) == '\\a'
    assert _match.group(1) == 'a'
    assert escape(_match) == '\a'

    _match = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\b')
    assert _match.group(0) == '\\b'
    assert _match.group(1) == 'b'
    assert escape(_match) == '\b'


# Generated at 2022-06-25 14:54:17.796349
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x\d\d", '\\x09')) == "\t"
    assert escape(re.match(r"\\\d\d\d", '\\009')) == "\t"
    assert escape(re.match(r"\\\d\d", '\\09')) == "\t"
    assert escape(re.match(r"\\\d", '\\9')) == "9"
    assert escape(re.match(r"\\b", '\\b')) == "\b"
    assert escape(re.match(r"\\f", '\\f')) == "\f"
    assert escape(re.match(r"\\n", '\\n')) == "\n"
    assert escape(re.match(r"\\r", '\\r')) == "\r"
   

# Generated at 2022-06-25 14:54:23.902467
# Unit test for function escape
def test_escape():
    cases = (
        (r"\a", "\a"),
        (r"\b", "\b"),
        (r"\f", "\f"),
        (r"\n", "\n"),
        (r"\r", "\r"),
        (r"\t", "\t"),
        (r'\v', "\v"),
        (r"\'", "'"),
        (r'\"', '"'),
        (r"\\", "\\"),
        (r"\x00", "\x00"),
        (r"\x07", "\x07"),
        (r"\x7F", "\x7F"),
        (r"\0177", "\0177"),
        (r"\xFF", "\xFF"),
        (r"\177", "\177"),
    )

# Generated at 2022-06-25 14:54:24.300995
# Unit test for function test
def test_test():
    assert test()

# Generated at 2022-06-25 14:54:25.399342
# Unit test for function escape
def test_escape():
    # Using 'a' as a case
    assert escape(re.match('a', '\\a')) == '\a'


# Generated at 2022-06-25 14:54:31.590734
# Unit test for function escape
def test_escape():
    # Test simple escapes
    for c, escape in simple_escapes.items():
        m = re.match(r"(\\" + c + ")", escape)
        if escape == m.group(1):
            pass
        else:
            raise RuntimeError("Unable to interpret simple escape")

    # Test octal escapes
    for i in range(8):
        m = re.match(r"\\" + oct(i)[2:], chr(i))
        if chr(i) == m.group(0):
            pass
        else:
            raise RuntimeError("Unable to interpret octal escape")

    # Test hex escapes
    for i in range(16):
        m = re.match(r"\\x" + hex(i)[2:], chr(i))

# Generated at 2022-06-25 14:54:34.576066
# Unit test for function escape
def test_escape():
    assert escape('\\n') == '\n'
    assert escape('\\x0a') == '\n'


# Generated at 2022-06-25 14:57:03.666716
# Unit test for function test
def test_test():
    test_case_0()

##
# Runtime Test Cases
##

##
# Unit Test Case Descriptions
##

# Generated at 2022-06-25 14:57:10.104978
# Unit test for function escape
def test_escape():
    assert escape("\\x12") == "\x12"
    assert escape("\\04") == "\004"

# Generated at 2022-06-25 14:57:13.045351
# Unit test for function escape
def test_escape():
    """This is a test for escape"""
    # Test case 1
    assert escape('\\') == "\\"

    # Test case 2
    assert escape('\\x9') == "\t"

    # Test case 3
    assert escape('\\65') == "A"


# Generated at 2022-06-25 14:57:15.651243
# Unit test for function escape
def test_escape():
    """Test case for function escape"""
    result = evalString('"""\n\t\\\t\\n\t"""')
    assert result == '\n\t\\\t\\n\t'
    result = evalString("""'\\''""")
    assert result == """\'"'"""

# Generated at 2022-06-25 14:57:16.569371
# Unit test for function escape
def test_escape():
    assert escape("\\u") == "\\u"


# Generated at 2022-06-25 14:57:18.851488
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:57:20.049722
# Unit test for function test
def test_test():
    x = True
    assert x, f"Error: test failed"

# Generated at 2022-06-25 14:57:21.180642
# Unit test for function test
def test_test():
    # Runs test and returns number of failures
    test()


# Generated at 2022-06-25 14:57:27.763604
# Unit test for function escape
def test_escape():
    try:
        assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x00")) == "\x00"
    except:
        assert False, "Could not escape \\x00"

# Generated at 2022-06-25 14:57:36.369724
# Unit test for function escape
def test_escape():
    assert escape(r"\a") == "\a"
    assert escape(r"\b") == "\b"
    assert escape(r"\f") == "\f"
    assert escape(r"\n") == "\n"
    assert escape(r"\r") == "\r"
    assert escape(r"\t") == "\t"
    assert escape(r"\v") == "\v"
    assert escape(r"\'") == "\'"
    assert escape(r'\"') == '"'
    assert escape(r"\\") == "\\"

    assert escape(r"\x41") == "A"
    assert escape(r"\x00") == "\x00"

    assert escape(r"\100") == "d"
    assert escape(r"\77") == "?"
