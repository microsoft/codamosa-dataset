

# Generated at 2022-06-25 14:48:15.027604
# Unit test for function escape
def test_escape():
    assert "'\\n'", evalString(r'"\n"')
    assert "\\a", evalString(r"'\a'")


# Generated at 2022-06-25 14:48:19.064017
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\n", r"\n")) == "\n"

# Generated at 2022-06-25 14:48:23.990654
# Unit test for function escape
def test_escape():
    from pytsa.safe_eval import escape

    assert escape("\n") == "\n"
    assert escape("\'") == "\'"
    assert escape("\x11") == "\x11"
    assert escape('"') == '"'
    assert escape("\o134") == "\o134"
    assert escape("\a") == "\a"
    assert escape("\v") == "\v"
    assert escape("\f") == "\f"
    assert escape("\r") == "\r"
    assert escape("\b") == "\b"
    assert escape("\t") == "\t"



# Generated at 2022-06-25 14:48:27.908570
# Unit test for function escape
def test_escape():
    m = re.sub(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", escape, r"\\\t")
    assert m == '\t'


# Generated at 2022-06-25 14:48:30.470911
# Unit test for function escape
def test_escape():
    opt = simple_escapes.get('a')
    rlt = escape(re.match(r'\\a','\\a'))
    assert rlt == opt


# Generated at 2022-06-25 14:48:40.469779
# Unit test for function escape
def test_escape():
    """
    The input of escape is a string.
    The output of escape is a string.
    Escape parses a string containing an escape sequence.
    The string is valid if the escape sequence is in the simple_escapes.
    The string is valid if the escape sequence is octal.
    The string is valid if the escape sequence is hexadecimal.
    returns an error if the escape sequence is invalid.
    """
    assert escape(re.match(r'\\x', '')) != None
    assert escape(re.match(r'\\a', '')) != None
    assert escape(re.match(r'\\b', '')) != None
    assert escape(re.match(r'\\f', '')) != None
    assert escape(re.match(r'\\n', '')) != None

# Generated at 2022-06-25 14:48:42.297738
# Unit test for function escape
def test_escape():
    """Test case for function escape"""
    assert False, "No test result"



# Generated at 2022-06-25 14:48:43.209059
# Unit test for function escape
def test_escape():
    assert escape('') == ''


# Generated at 2022-06-25 14:48:44.466673
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-25 14:48:53.168146
# Unit test for function escape
def test_escape():
    esc_tab = {"\n": "\\n", "\t": "\\t", "\r": "\\r", '"': '\\"', "\\": "\\\\"}
    t = esc_tab
    if esc_tab["\n"] != '\n':
        raise TestFailure("wrong result for newline")
    if esc_tab["\t"] != '\t':
        raise TestFailure("wrong result for tab")
    if esc_tab["\r"] != '\r':
        raise TestFailure("wrong result for carriage return")
    if esc_tab['"'] != '"':
        raise TestFailure("wrong result for double quote")
    if esc_tab["\\"] != "\\":
        raise TestFailure("wrong result for backslash")
    # test round trip

# Generated at 2022-06-25 14:49:11.144449
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == '\a'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == '\b'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")) == '\f'

# Generated at 2022-06-25 14:49:21.493334
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")
    assert escape(m) == u"\u0007"

    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")
    assert escape(m) == u"\u0008"

    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")
    assert escape(m) == u"\u000C"


# Generated at 2022-06-25 14:49:22.374804
# Unit test for function escape
def test_escape():
    test_escape_0()


# Generated at 2022-06-25 14:49:31.585067
# Unit test for function escape
def test_escape():
    assert evalString("""''' '''""") == "' '"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\x61\\141\\o141\\0141'") == "aaAA"
    assert evalString("'\\x\\x\\x'") == "xxx"
    assert evalString("'\\x\\x\\xA'") == "xxx"
    assert evalString("'\\x\\x\\xAA'") == "xxx"
    try:
        evalString("'\\x\\x\\xAAA'")
        assert False, "Failed to raise a ValueError"
    except ValueError:
        pass

# Generated at 2022-06-25 14:49:32.959234
# Unit test for function test
def test_test():
    result = test()

    expected = None
    assert result == expected

    return

# Generated at 2022-06-25 14:49:34.894129
# Unit test for function escape
def test_escape():
    assert escape(Match[Text]('\\n', 'n')) == '\n'



# Generated at 2022-06-25 14:49:39.031685
# Unit test for function escape
def test_escape():
    # test_escape_0
    escaped = escape(re.match(r"\\x[0-9a-fA-F]+", "\\xDEADBEEF"))
    expected = "\xDE\xAD\xBE\xEF"
    assert escaped == expected, (escaped, expected)


# Generated at 2022-06-25 14:49:39.959122
# Unit test for function escape
def test_escape():
    test()


# Generated at 2022-06-25 14:49:46.992499
# Unit test for function escape
def test_escape():
    input_values = [
        "\\x01\\x02"
    ]

    expected_output = [
        "\x01\x02"
    ]

    for i in range(len(input_values)):
        if escape(input_values[i]) != expected_output[i]:
            raise RuntimeError("test failed")

# test_case_1.txt contains the output of `repr(evalString("a{0}".format(x)))` for x in range(256)

# Generated at 2022-06-25 14:49:48.323351
# Unit test for function escape
def test_escape():
    evaluate_each_line(escape, test_escape_src)


# Generated at 2022-06-25 14:50:05.160177
# Unit test for function test
def test_test():
    assert callable(test)
    test()


# Generated at 2022-06-25 14:50:13.217529
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\f')) == r'\f'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\a')) == r'\a'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\n')) == r'\n'

# Generated at 2022-06-25 14:50:15.727240
# Unit test for function escape
def test_escape():
    m = re.match(r'\\(.+)', '\\x')
    assert escape(m) == ''


# Generated at 2022-06-25 14:50:19.362823
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\ab")
    assert escape(m) == "\a\b"



# Generated at 2022-06-25 14:50:21.259140
# Unit test for function test
def test_test():
    try:
        test()
    except SystemExit as exception:
        assert exception.code == 0



# Generated at 2022-06-25 14:50:22.345551
# Unit test for function test
def test_test():
  assert test() == None


# Generated at 2022-06-25 14:50:30.208915
# Unit test for function escape
def test_escape():

    func = escape
    one_char_string_escapes = (
        ("\a", r"\a"),
        ("\b", r"\b"),
        ("\f", r"\f"),
        ("\n", r"\n"),
        ("\r", r"\r"),
        ("\t", r"\t"),
        ("\v", r"\v"),
        ("\'", r"\'"),
        ('\"', r'\"'),
        ("\\", r'\\'),
    )
    for test_string, expected_result in one_char_string_escapes:
        print(func.__name__ + test_string)
        result = func(test_string)
        print(func.__name__ + result)
        assert result == expected_result

# Generated at 2022-06-25 14:50:40.399374
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(a)", "\\a")) == "\a"
    assert escape(re.match(r"\\(b)", "\\b")) == "\b"
    assert escape(re.match(r"\\(f)", "\\f")) == "\f"
    assert escape(re.match(r"\\(n)", "\\n")) == "\n"
    assert escape(re.match(r"\\(r)", "\\r")) == "\r"
    assert escape(re.match(r"\\(t)", "\\t")) == "\t"
    assert escape(re.match(r"\\(v)", "\\v")) == "\v"
    assert escape(re.match(r"\\(')", "\\'")) == "'"

# Generated at 2022-06-25 14:50:49.901066
# Unit test for function escape

# Generated at 2022-06-25 14:50:57.018394
# Unit test for function escape
def test_escape():
    assert "A" == escape(r'\x41')
    assert "" == escape(r'\200')
    assert "1" == escape(r'\o41')
    assert "A" == escape(r'\x41')
    assert "1" == escape(r'\x0o41')
    assert "A" == escape(r'\x0A')
    assert "A" == escape(r'\x0A')



# Generated at 2022-06-25 14:51:31.646008
# Unit test for function escape
def test_escape():
    # Tests for exact text matches
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\x00") == "\x00"
    assert escape("\\x10") == "\x10"
    assert escape("\\x20") == "\x20"
    assert escape("\\x30") == "\x30"
    assert escape("\\x40") == "\x40"
    assert escape("\\x50") == "\x50"
   

# Generated at 2022-06-25 14:51:40.664380
# Unit test for function escape
def test_escape():
    assert escape(re.search('\\\\r', '\\r')) == '\r'
    assert escape(re.search('\\\\n', '\\n')) == '\n'
    assert escape(re.search('\\\\v', '\\v')) == '\v'
    assert escape(re.search('\\"', '"')) == '"'
    assert escape(re.search('\\\\"', '\\"')) == '"'
    assert escape(re.search('\\\\a', '\\a')) == '\a'
    assert escape(re.search('\\\\f', '\\f')) == '\f'
    assert escape(re.search('\\\\xab', '\\xab')) == '\xab'
    assert escape(re.search('\\\\t', '\\t')) == '\t'

# Generated at 2022-06-25 14:51:42.913008
# Unit test for function escape
def test_escape():
    assert escape('\n') == '\n'
    assert escape('\0') == '\x00'


# Generated at 2022-06-25 14:51:47.053440
# Unit test for function escape
def test_escape():

    # Python string escaped
    escaped_python_string = r'\\\a\b\f\r\t\v\'\"'
    # C# string escaped
    escaped_csharp_string = r'"\\\a\b\f\r\t\v\'""'

    # 100% match
    assert evalString(escaped_python_string) == evalString(escaped_csharp_string)


# Generated at 2022-06-25 14:51:57.390754
# Unit test for function escape
def test_escape():
    match = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\0")
    assert escape(match) == "\0"

    match = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\e")
    assert escape(match) == "\x1b"

    match = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\x1b")
    assert escape(match) == "\x1b"


# Generated at 2022-06-25 14:51:58.254434
# Unit test for function test
def test_test():
    assert True

test_test()

# Generated at 2022-06-25 14:52:02.029003
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\v")
    assert escape(m) == "\v"

# Generated at 2022-06-25 14:52:03.417905
# Unit test for function escape
def test_escape():
    assert escape('\n') == '\n'


# Generated at 2022-06-25 14:52:06.408351
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\"', '"')) == ""'""""', 'escape("\"")'
    assert escape(re.match('', '"')) == '', 'escape("")'



# Generated at 2022-06-25 14:52:07.988586
# Unit test for function test
def test_test():
    checker = Checker()

    checker.check_equal(test(), None)


# Generated at 2022-06-25 14:52:54.119763
# Unit test for function test
def test_test():
    # No output
    test()


# Generated at 2022-06-25 14:52:57.118875
# Unit test for function escape
def test_escape():

    # Trivial case
    input = "\\x55"
    expected_result = 'U'
    result = escape(input)

    assert expected_result == result, "Error while testing escape function"


# Generated at 2022-06-25 14:53:05.915202
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'''\\''', '\\')) == '\\'
    assert escape(re.match(r'''\\''', '\\\'')) == '\\\''
    assert escape(re.match(r'''\\''', '\\\\')) == '\\\\'
    assert escape(re.match(r'''\\''', '\\a')) == '\\a'
    assert escape(re.match(r'''\\''', '\\x00')) == '\x00'
    assert escape(re.match(r'''\\''', '\\xff')) == '\xff'
    assert escape(re.match(r'''\\''', '\\xffa')) == '\xff'
    assert escape(re.match(r'''\\''', '\\0')) == '\x00'

# Generated at 2022-06-25 14:53:06.470365
# Unit test for function test
def test_test():
    assert True


# Generated at 2022-06-25 14:53:07.784991
# Unit test for function escape
def test_escape():
    import re
    assert escape(re.match(r"\\([\\'\"])", "\\'")) == "'"


# Generated at 2022-06-25 14:53:09.005308
# Unit test for function test
def test_test():
    assert test() is None

# Unit tests for function evalString

# Generated at 2022-06-25 14:53:11.943165
# Unit test for function test
def test_test():
    import io
    out = io.StringIO()
    test()
    out = out.getvalue()
    assert out == ''


# Generated at 2022-06-25 14:53:19.382935
# Unit test for function escape
def test_escape():
    assert escape('\\"') == '"'
    assert escape('\\b') == '\x08'
    assert escape('\\n') == '\n'
    assert escape('\\v') == '\x0b'
    assert escape('\\x1b') == '\x1b'
    assert escape('\\x7f') == '\x7f'
    assert escape('\\x80') == '\x80'
    assert escape('\\xFF') == '\xff'
    assert escape('\\"x') == '"x'
    assert escape('\\xHG') == 'xHG'
    assert escape('\\x1HG') == 'x1HG'
    assert escape('\\1') == '\x01'
    assert escape('\\12') == '\n'

# Generated at 2022-06-25 14:53:20.378922
# Unit test for function test
def test_test():
    # Asserts
    assert 0 == 0


# Generated at 2022-06-25 14:53:27.178914
# Unit test for function escape
def test_escape():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()
    test_case_25()

# Generated at 2022-06-25 14:55:27.425951
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\x07'
    assert escape('\\b') == '\x08'
    assert escape('\\f') == '\x0c'
    assert escape('\\n') == '\n'
    assert escape('\\v') == '\x0b'
    assert escape('\\t') == '\t'
    assert escape('\\x1f') == '\x1f'
    assert escape('\\00') == '\x00'
    assert escape('\\07') == '\x07'
    assert escape('\\123') == '{'
    assert escape('\\1') == '\x01'


# Generated at 2022-06-25 14:55:28.692596
# Unit test for function escape
def test_escape():
    #assert escape(___) == ___
    raise NotImplementedError



# Generated at 2022-06-25 14:55:38.693640
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r"\\x20", "\\x20")) == " "
    assert escape(re.match(r"\\x20", "\\x20")) == " "
    assert escape(re.match(r"\\323", "\\323")) == chr(0o323)
    assert escape(re.match(r"\\32", "\\32")) == chr(0o32)
    assert escape(re.match(r"\\2", "\\2")) == chr(0o2)

# Generated at 2022-06-25 14:55:40.360740
# Unit test for function escape
def test_escape():
# Test for function file_escape
    assert escape(re.match("a", "a")) == "a"



# Generated at 2022-06-25 14:55:49.247337
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\[']", "\\'")) == "'"
    assert escape(re.match(r"\\[\"]", '\\"')) == '"'
    assert escape(re.match(r"\\[a]", "\\a")) == "\a"
    assert escape(re.match(r"\\[b]", "\\b")) == "\b"
    assert escape(re.match(r"\\[f]", "\\f")) == "\f"
    assert escape(re.match(r"\\[n]", "\\n")) == "\n"
    assert escape(re.match(r"\\[r]", "\\r")) == "\r"
    assert escape(re.match(r"\\[t]", "\\t")) == "\t"

# Generated at 2022-06-25 14:55:56.744839
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\27")) == "\x1b"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x1b")) == "\x1b"

# Generated at 2022-06-25 14:56:05.572456
# Unit test for function escape
def test_escape():
    # Test 1: Non-control characters
    assert escape(re.search(r"\\[']", "'")) == "'"
    assert escape(re.search(r"\\[\"]", '"')) == '"'
    assert escape(re.search(r"\\a", "\a")) == "\a"
    assert escape(re.search(r"\\b", "\b")) == "\b"
    assert escape(re.search(r"\\f", "\f")) == "\f"
    assert escape(re.search(r"\\n", "\n")) == "\n"
    assert escape(re.search(r"\\r", "\r")) == "\r"
    assert escape(re.search(r"\\t", "\t")) == "\t"
    assert escape(re.search(r"\\v", "\v")) == "\v"


# Generated at 2022-06-25 14:56:06.720714
# Unit test for function test
def test_test():
    assert test() == None
test_test()


# Generated at 2022-06-25 14:56:07.218504
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-25 14:56:07.757401
# Unit test for function test
def test_test():
    assert 1 == 1