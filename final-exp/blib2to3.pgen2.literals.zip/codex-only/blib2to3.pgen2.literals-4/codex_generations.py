

# Generated at 2022-06-23 15:40:40.009707
# Unit test for function escape
def test_escape():
    tests = [
        # invalid
        ("\\x", SyntaxError),
        ("\\x1", SyntaxError),
        ("\\x1x", SyntaxError),
        ("\\582", SyntaxError),
        ("\\658", SyntaxError),
        ("\\348", SyntaxError),
        # valid
        ("\\x00", "\x00"),
        ("\\x0a", "\n"),
        ("\\xFF", "\xFF"),
        ("\\377", "\xFF"),
        ("\\378", "\xFF"),
        ("\\0", "\x00"),
        ("\\1", "\x01"),
        ("\\11", "\t"),
        ("\\111", "I"),
    ]


# Generated at 2022-06-23 15:40:41.747602
# Unit test for function evalString
def test_evalString():
    assert evalString("'\n'") == "\n"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x0a'") == "\n"

# Generated at 2022-06-23 15:40:47.291297
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\\\", r"\\")) == "\\"
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"

# Generated at 2022-06-23 15:40:50.129618
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError:
        print("Unit test for function test failed")
    else:
        print("Unit test for function test passed")

# Generated at 2022-06-23 15:41:01.387814
# Unit test for function escape
def test_escape():
    # Test function escape

    # Three common cases
    assert escape(re.match(r"\\([abfnrtv\'\"\\ ])", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv\'\"\\ ])", "\\'")) == "'"
    assert escape(re.match(r"\\([abfnrtv\'\"\\ ])", '\\"')) == '"'

    # But these are not allowed
    try:
        escape(re.match(r"\\([abfnrtv\'\"\\ ])", "\\ "))
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    try:
        escape(re.match(r"\\([abfnrtv\'\"\\ ])", "\\dx"))
    except ValueError:
        pass


# Generated at 2022-06-23 15:41:11.730388
# Unit test for function escape
def test_escape():
    # Test simple escapes
    assert escape(re.match(r"\\", "\\")) == "\\"
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"

# Generated at 2022-06-23 15:41:24.780714
# Unit test for function evalString

# Generated at 2022-06-23 15:41:29.038819
# Unit test for function evalString
def test_evalString():
    # test that evalString gives the same result as eval on a variety of strings
    examples = ["'abc'", '"abcdef"', '"\x61\x62\x63\x64\x65\x66"']
    for s in examples:
        e = evalString(s)
        assert e == eval(s)

# Generated at 2022-06-23 15:41:33.099176
# Unit test for function test
def test_test():
    with pytest.raises(AssertionError):
        evalString('\\x')
    with pytest.raises(AssertionError):
        evalString('\\x9')
    with pytest.raises(AssertionError):
        evalString('\\09')

# Generated at 2022-06-23 15:41:38.670817
# Unit test for function escape
def test_escape():
    assert escape("\x00") == "\\x00"
    assert escape("\x01") == "\\x01"
    assert escape("\x02") == "\\x02"
    assert escape("\x03") == "\\x03"
    assert escape("\x04") == "\\x04"
    assert escape("\x05") == "\\x05"
    assert escape("\x06") == "\\x06"
    assert escape("\x07") == "\\a"
    assert escape("\x08") == "\\b"
    assert escape("\x09") == "\\t"
    assert escape("\x0a") == "\\n"
    assert escape("\x0b") == "\\v"
    assert escape("\x0c") == "\\f"

# Generated at 2022-06-23 15:41:50.256236
# Unit test for function escape
def test_escape():
    m = re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")
    s = escape(m)
    assert s == "'"

    m = re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\"')
    s = escape(m)
    assert s == '"'

    m = re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")
    s = escape(m)
    assert s == "\a"


# Generated at 2022-06-23 15:41:59.128118
# Unit test for function evalString
def test_evalString():
    # Testing string literals
    assert evalString('"a"') == 'a'
    assert evalString("'a'") == 'a'
    assert evalString('"\'"') == "'"
    assert evalString("'\"'") == '"'
    # Testing invalid string literals
    try:
        evalString("'a")
    except ValueError:
        pass
    else:
        raise AssertionError("evalString did not catch an Invalid Literal")
    try:
        evalString("'a'\n")
    except ValueError:
        pass
    else:
        raise AssertionError("evalString did not catch an Invalid Literal")
    # Testing escape sequences
    assert evalString("'\\''") == "'"
    assert evalString("'\\\"'") == '"'

# Generated at 2022-06-23 15:42:05.091542
# Unit test for function evalString
def test_evalString():

    # Test single quotes
    assert evalString("''") == ""
    assert evalString("'a'") == "a"
    assert evalString("'\\''") == "'"
    assert evalString("'\\x23'") == "#"

    # Test double quotes
    assert evalString('""') == ""
    assert evalString('"a"') == "a"
    assert evalString('"\\""') == '"'
    assert evalString('"\\x23"') == "#"

    # Test triple quotes
    assert evalString("'''a'") == "a'"
    assert evalString("a'''") == "a'"
    assert evalString("'''a") == "'a"
    assert evalString("a'''") == "a'"
    assert evalString("a'''b") == "a'b"
    assert eval

# Generated at 2022-06-23 15:42:09.604383
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-23 15:42:10.311042
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:18.422213
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\1")) == "\1"

# Generated at 2022-06-23 15:42:18.911106
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:30.143904
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv\\\'\"])", "\\'")).encode('utf-8') == b"'"
    assert escape(re.match(r"\\([abfnrtv\\\'\"])", r'\\')).encode('utf-8') == b'\\'
    assert escape(re.match(r"\\([abfnrtv\\\'\"])", '\\a')).encode('utf-8') == b'\x07'
    assert escape(re.match(r"\\([abfnrtv\\\'\"])", '\\b')).encode('utf-8') == b'\x08'

# Generated at 2022-06-23 15:42:34.681050
# Unit test for function escape
def test_escape():
    assert escape(Match(r'\x3j', '3j')) == '3'
    assert escape(Match(r'\xEj', 'Ej')) == 'E'
    assert escape(Match(r'\xEj', 'Ej')) == 'E'
    assert escape(Match(r'\oe', 'oe')) == 'ö'


# Generated at 2022-06-23 15:42:35.710036
# Unit test for function test
def test_test():
    """Unit test for function test"""
    test()

# Generated at 2022-06-23 15:42:48.047763
# Unit test for function escape
def test_escape():
    # Test that escape replaces simple escapes correctly
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "\\'"

# Generated at 2022-06-23 15:42:56.794245
# Unit test for function escape
def test_escape():
    # Use mocked values
    simple_escapes_values = {'a': 'b', 'c': 'd'}
    def mock_escape(m: Match[Text]) -> Text:
        return simple_escapes_values.get(m.group(), 'e')
    # Set mocked values
    globals()['escape'] = mock_escape
    globals()['simple_escapes'] = simple_escapes_values
    # Test
    assert evalString(r'"\a"') == 'b'
    assert evalString(r'"\c"') == 'd'
    assert evalString(r'"\z"') == 'e'
    # Restore original values
    globals()['escape'] = escape
    globals()['simple_escapes'] = simple_escapes

# Generated at 2022-06-23 15:42:58.173827
# Unit test for function test
def test_test():
    import pytest
    with pytest.raises(Exception):
        test()

# Generated at 2022-06-23 15:43:00.755426
# Unit test for function evalString
def test_evalString():
    assert evalString('\t') == '\t'
    assert evalString('\n') == '\n'
    assert evalString('\'"') == '\'"'

# Generated at 2022-06-23 15:43:10.774040
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r'\a')) == '\a'
    assert escape(re.match(r"\\b", r'\b')) == '\x08'
    assert escape(re.match(r"\\f", r'\f')) == '\x0c'
    assert escape(re.match(r"\\n", r'\n')) == '\n'
    assert escape(re.match(r"\\r", r'\r')) == '\r'
    assert escape(re.match(r"\\t", r'\t')) == '\t'
    assert escape(re.match(r"\\v", r'\v')) == '\x0b'

# Generated at 2022-06-23 15:43:12.308815
# Unit test for function test
def test_test():
    test()
    return True

# Generated at 2022-06-23 15:43:22.766973
# Unit test for function escape

# Generated at 2022-06-23 15:43:33.118414
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == '\x00'
    assert evalString('"\\x7f"') == '\x7f'
    assert evalString('"\\x80"') == '\x80'
    assert evalString('"\\xff"') == '\xff'
    assert evalString("'\\x00'") == '\x00'
    assert evalString("'\\x7f'") == '\x7f'
    assert evalString("'\\x80'") == '\x80'
    assert evalString("'\\xff'") == '\xff'
    assert evalString('"\\x00"') == '\x00'
    assert evalString('"\\x7f"') == '\x7f'
    assert evalString('"\\x80"') == '\x80'

# Generated at 2022-06-23 15:43:45.526903
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\''") == "'"
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\255'") == "\xFF"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\xFF'") == "\xFF"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\377'") == "\xFF"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\00'") == "\0"
    assert evalString("'\\''") == "'"

# Generated at 2022-06-23 15:43:54.916898
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x61'") == "a"
    assert evalString("'a'") == "a"
    assert evalString("'\\''") == "'"
    assert evalString("'\\x7f'") == "\u007f"
    assert evalString("'\\x1b'") == "\x1b"
    assert evalString("'\\''") == "'"
    assert evalString("'\"'") == '"'
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x61\\x62'") == "ab"
    assert evalString("'\\n\\n'") == "\n\n"

# Generated at 2022-06-23 15:43:55.871872
# Unit test for function test
def test_test():
    res = test()
    assert res is None


# Generated at 2022-06-23 15:44:03.518202
# Unit test for function evalString
def test_evalString():
    assert evalString('"Hello, World"') == 'Hello, World'
    assert evalString("'Hello, World'") == 'Hello, World'
    assert evalString(r'"Hello, World\n"') == 'Hello, World\n'
    assert evalString(r"'Hello, World\n'") == 'Hello, World\n'
    assert evalString(r'"Hello, World\""') == 'Hello, World"'
    assert evalString(r"'Hello, World\''") == 'Hello, World\''

# Generated at 2022-06-23 15:44:09.991912
# Unit test for function evalString
def test_evalString():
    cases = [
        ('"\\n"', '\n'),
        ('"\\001"', '\x01'),
        ('"a \\n b"', 'a \n b'),
        ('"\\\'hello\\\'"', "'hello'"),
        ("'''hello'''", 'hello'),
        ("''''''", "''"),
        ('"""hello"""', 'hello'),
        ('"""""', '""'),
        ('""', ''),
        ("'hello'", 'hello'),
        ("''", ''),
    ]
    for string, expected in cases:
        assert evalString(string) == expected

# Generated at 2022-06-23 15:44:21.049955
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("'a'") == "a"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\x00'") == "\0"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\x00'") == "\0"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\01'") == "\x01"
    assert evalString("'\\077'") == "\x1f"
    assert evalString("'\\141'") == "a"
    assert evalString("'\\101'") == "A"
    assert evalString("'\\x7f'") == "\x7f"
    assert evalString("'\\377'") == "\xff"


# Generated at 2022-06-23 15:44:25.395853
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-23 15:44:26.006947
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:27.794114
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\'", r"\'")) == r"'"



# Generated at 2022-06-23 15:44:33.498374
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\r\\n'") == "\r\n"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\''") == "'"
    assert evalString('"""hello"""') == "hello"
    assert evalString(repr("hello world")) == "hello world"

# Generated at 2022-06-23 15:44:39.021608
# Unit test for function evalString
def test_evalString():
    s = '"abc" + "def"'
    assert evalString(s) == "abcdef"
    s = "'abc' + 'def'"
    assert evalString(s) == "abcdef"
    s = "'abc' + \"def\""
    assert evalString(s) == "abcdef"
    s = '"abc" + \'def\''
    assert evalString(s) == "abcdef"



# Generated at 2022-06-23 15:44:47.418634
# Unit test for function evalString
def test_evalString():
    from pprint import pprint, pformat
    from docutils.utils.roman import roman_numerals

# Generated at 2022-06-23 15:44:57.805268
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-3][0-7]{0,2})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-3][0-7]{0,2})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-3][0-7]{0,2})", r"\f")) == "\f"

# Generated at 2022-06-23 15:45:00.357242
# Unit test for function test
def test_test():
    try:
        test()
    except ValueError as err:
        print("test failed:", err)

# Generated at 2022-06-23 15:45:05.530753
# Unit test for function test
def test_test():
    """
    Test the test function.
    """
    with pytest.raises(AssertionError):
        test(False)
    with pytest.raises(NotImplementedError):
        test(None)
    with pytest.raises(NotImplementedError):
        test(1)
    with pytest.raises(NotImplementedError):
        test("1")



# Generated at 2022-06-23 15:45:06.447608
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:10.425044
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == "hello"
    assert evalString('"\\x63"') == "c"
    assert evalString("r'\\n'") == "\\n"

# Generated at 2022-06-23 15:45:14.901868
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\xaa", "\\xaa")) == '\xaa'
    assert escape(re.match(r"\\255", "\\255")) == '\x9b'



# Generated at 2022-06-23 15:45:27.421375
# Unit test for function evalString

# Generated at 2022-06-23 15:45:32.074800
# Unit test for function escape
def test_escape():
    m = re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\x0")
    assert escape(m) == "\x00"

# Generated at 2022-06-23 15:45:33.846963
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-23 15:45:40.401921
# Unit test for function escape
def test_escape():
    assert escape(None) is None
    assert escape(type(1)) == 1
    assert escape('a') == 'a'
    assert escape('"'+'a') != 'a'
    # assert escape('\\a') == 'a'
    # assert escape('\\b') == 'b'
    # assert escape('\\f') == 'f'
    # assert escape('\\n') == 'n'
    # assert escape('\\r') == 'r'
    # assert escape('\\t') == 't'
    # assert escape('\\v') == 'v'
    # assert escape('\\') == '\\'
    # assert escape('x1F') == 'a'

# Generated at 2022-06-23 15:45:40.977296
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:45.884782
# Unit test for function escape
def test_escape():
    # Test cases: (string, expected result)
    tests = [("\\\\\\x41", "\\A"), ("\\\\\\077", "\\?"), ("\a\\a", "\a\\a")]
    for test in tests:
        assert evalString(test[0]) == test[1]

# Generated at 2022-06-23 15:45:57.517856
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(.)', r'\a')) == '\a'
    assert escape(re.match(r'\\(.)', r'\b')) == '\x08'
    assert escape(re.match(r'\\(.)', r'\f')) == '\x0c'
    assert escape(re.match(r'\\(.)', r'\n')) == '\n'
    assert escape(re.match(r'\\(.)', r'\r')) == '\r'
    assert escape(re.match(r'\\(.)', r'\t')) == '\t'
    assert escape(re.match(r'\\(.)', r'\v')) == '\x0b'

# Generated at 2022-06-23 15:46:06.561894
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\xFF"') == "\xFF"
    assert evalString('"\\377"') == "\xFF"
    assert evalString('"\\37"') == "7"
    assert evalString('"\\3"') == "\x03"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\0"') == "\x00"
    assert evalString('"\\1"') == "\x01"
    assert evalString('"\\12"') == "\x0A"
    assert evalString('"\\123"') == "\x5B"
    assert evalString('"\\0"') == "\x00"
    assert evalString('"\\015"') == "\x0D"

# Generated at 2022-06-23 15:46:09.629713
# Unit test for function evalString
def test_evalString():
    test_string = '"this is a test string"'
    result = evalString(test_string)
    assert result == 'this is a test string'

# Generated at 2022-06-23 15:46:19.667825
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'\\n'") == "\n"
    assert evalString("'foo\\tbar'") == "foo\tbar"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\0x61'") == "a"
    assert evalString("'\\\\'") == "\\"
    assert evalString('"a"') == "a"
    assert evalString('"\\n"') == "\n"
    assert evalString('"foo\\tbar"') == "foo\tbar"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\0x61"') == "a"
    assert evalString('"\\\\"') == "\\"



# Generated at 2022-06-23 15:46:21.010387
# Unit test for function escape
def test_escape():
    assert escape("\\x12") == "\\x12"
    assert escape("\\x1") == "\\x1"

# Generated at 2022-06-23 15:46:31.055471
# Unit test for function evalString
def test_evalString():

    # Test case of evalString
    # This is An example of "assert"
    assert evalString("'\\'") == "'"
    assert evalString("'\\'\\'") == "''"
    assert evalString('"\\""') == '"'
    assert evalString('"\\"\\""') == '""'
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61lert(1)'") == "alert(1)"
    assert evalString("'\\n\\r\\b\\t\\v\\f'") == "\n\r\b\t\v\f"
    assert evalString("'\\007\\x07'") == "\x07\x07"
   

# Generated at 2022-06-23 15:46:40.985829
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x.{0,2}", "\\x41")) == '@'
    assert escape(re.match(r"\\x.{0,2}", "\\x4a")) == 'J'
    assert escape(re.match(r"\\x.{0,2}", "\\x00")) == '0'
    assert escape(re.match(r"\\x.{0,2}", "\\x01")) == '1'
    assert escape(re.match(r"\\x.{0,2}", "\\x10")) == '0'
    assert escape(re.match(r"\\x.{0,2}", "\\x11")) == '1'
    assert escape(re.match(r"\\x.{0,2}", "\\x11"))

# Generated at 2022-06-23 15:46:42.846816
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:50.443774
# Unit test for function evalString
def test_evalString():
    test_assert_eq(evalString("'foo'"), "foo")
    test_assert_eq(evalString('"foo"'), "foo")
    test_assert_eq(evalString("'''foo'"), "'foo")
    test_assert_eq(evalString('"""foo"'), '"foo')

    test_assert_eq(evalString('"foo'), '"foo')
    test_assert_eq(evalString("'foo"), "'foo")
    test_assert_eq(evalString("'\\''"), "'")
    test_assert_eq(evalString('"\\""'), '"')

    for i in range(256):
        test_assert_eq(
            evalString('"' + chr(i) + '"'), chr(i), "chr({}) unexpectedly failed".format(i)
        )
        test

# Generated at 2022-06-23 15:46:53.044951
# Unit test for function test
def test_test():
    import pytest

    with pytest.raises(SystemExit):
        test()

# Unit tests for functions

# Generated at 2022-06-23 15:46:56.915884
# Unit test for function test
def test_test():
    orig_stdout = sys.stdout
    try:
        sys.stdout = StringIO()
        test()
        assert sys.stdout.getvalue() == ''
    finally:
        sys.stdout = orig_stdout


# Generated at 2022-06-23 15:47:01.112934
# Unit test for function escape
def test_escape():
    assert escape('\\x00') == '\x00'
    assert escape('\\01') == '\x01'
    assert escape('\\b') == '\x08'
    assert escape('\\x0a') == '\n'
    assert escape('\\12') == '\n'
    assert escape('\\1234') == '\x1a4'

# Generated at 2022-06-23 15:47:12.412327
# Unit test for function evalString
def test_evalString():
    assert evalString("abcd") == "abcd"
    assert evalString("''") == ""
    assert evalString("'a\\nb'") == "a\nb"
    assert evalString('"a\\nb"') == "a\nb"
    assert evalString("r'a\\nb'") == "a\\nb"
    assert evalString("'a\\\nb'") == "ab"
    assert evalString("'a\\\nb'") == "ab"
    assert evalString("'a\\\rb'") == "arb"
    assert evalString("'a\\\xab'") == "a\xab"
    assert evalString("'a\\\u1234'") == "a\u1234"
    assert evalString("'a\\\U00010111'") == "a\U00010111"

# Generated at 2022-06-23 15:47:24.304693
# Unit test for function evalString
def test_evalString():
    import sys
    import operator
    import tempfile
    from test.support import captured_stdout, captured_stderr, run_unittest

    # Build test suite
    suite = unittest.TestSuite()

# Generated at 2022-06-23 15:47:25.546929
# Unit test for function test
def test_test():
    assert test() is None, 'Function test must be None.'

# Generated at 2022-06-23 15:47:26.507546
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:47:27.086919
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:27.968346
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:31.037447
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        print(e)
        assert 0

# Generated at 2022-06-23 15:47:35.835569
# Unit test for function evalString
def test_evalString():
    from hypothesis import given
    from hypothesis.strategies import text, binary

    @given(text())
    def test(s):
        s = repr(s)
        assert eval(s) == evalString(s)

    @given(binary())
    def test_bytes(s):
        s = repr(s)
        assert eval(s) == evalString(s)

# Generated at 2022-06-23 15:47:38.163963
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError as ae:
        print(ae)

# Generated at 2022-06-23 15:47:38.857777
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:49.648412
# Unit test for function escape
def test_escape():
    import io
    from unittest import TestCase

    class EscapeTest(TestCase):
        def test_simple_escapes(self):
            for char, text in simple_escapes.items():
                with self.subTest(char=char, text=text):
                    self.assertEqual(escape(re.match(r"\\%s" % re.escape(char), "\\%s" % char)), text)

        def test_x_escapes(self):
            test_cases = (
                ("\\x00", "\x00"),
                ("\\xAB", "\xAB"),
                ("\\xFF", "\xFF"),
            )

# Generated at 2022-06-23 15:47:55.622358
# Unit test for function test
def test_test():
    import io
    import sys

    savestdout = sys.stdout
    try:
        s = io.StringIO()
        sys.stdout = s
        test()
        s.seek(0)
        output = s.read()
    finally:
        sys.stdout = savestdout
    assert output == "", repr(output)



# Generated at 2022-06-23 15:47:56.206623
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:08.090331
# Unit test for function escape
def test_escape():
    u = "\uFFFF"
    assert escape(re.match(r"\\uFFFF", "\\uFFFF")) == u
    assert escape(re.match(r"\\xFF", "\\xFF")) == chr(0xFF)
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"

# Generated at 2022-06-23 15:48:17.097412
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"a\\"bc"') == 'a"bc'
    assert evalString("'a\\'bc'") == "a'bc"
    assert evalString('r"a\\"bc"') == 'a\\"bc'
    assert evalString('r"a\\"bc"') == 'a\\"bc'
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\'\\"\\\\"') == "\a\b\f\n\r\t\v'\"\\"
    assert evalString('"""abc"""') == "abc"
    assert evalString(r"""'''a\"bc'''""") == 'a"bc'

# Generated at 2022-06-23 15:48:27.491204
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r"\\\"", r'\"')) == '"'
    assert escape(re.match(r"\\", r"\\")) == "\\"
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"

# Generated at 2022-06-23 15:48:34.906567
# Unit test for function escape
def test_escape():
    import unittest
    import test.support

    class EscapeTest(unittest.TestCase):
        # Format:
        # (input, output)
        simple_test_cases = (
            ("a", "\\x07"),
            ("b", "\\x08"),
            ("f", "\\x0c"),
            ("n", "\\x0a"),
            ("r", "\\x0d"),
            ("t", "\\x09"),
            ("v", "\\x0b"),
            ('"', '"'),
            ("'", "'"),
            ("\\", "\\"),
        )


# Generated at 2022-06-23 15:48:35.830783
# Unit test for function test
def test_test():
    try:
        test()
    except:
        pass

# Generated at 2022-06-23 15:48:43.412776
# Unit test for function evalString
def test_evalString():

    # simple string literals
    assert evalString('"Hello World!"') == "Hello World!"
    assert evalString("'Hello World!'") == "Hello World!"

    # escaped
    assert evalString('"Hello \\"World\\""') == 'Hello "World"'
    assert evalString("'Hello \\'World\\''") == "Hello 'World'"

    # raw string literals
    assert evalString(r'"Hello World!"') == "Hello World!"
    assert evalString(r"'Hello World!'") == "Hello World!"

    # raw escaped
    assert evalString(r'"Hello \\"World\\""') == 'Hello \\"World\\"'
    assert evalString(r"'Hello \\'World\\''") == "Hello \\'World\\'"

    # triple-quoted string literals
    # the following is from the python docs
    # (the

# Generated at 2022-06-23 15:48:53.614116
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"

# Generated at 2022-06-23 15:49:03.788980
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'\t\''") == r"\t'"
    assert evalString(r'"\t"') == r"\t"
    assert evalString(r"r'\t'") == r"\t"
    assert evalString(r"r'\''") == r"\'"
    assert evalString(r'r"\""') == r"\""
    assert evalString(r"r'\\'") == r"\\"
    assert evalString(r"r'\"'") == r"\""
    assert evalString(r"r'\x7f'") == r"\x7f"
    assert evalString(r"r'\177'") == chr(127)
    assert evalString(r'r"\\"') == r"\\"

# Generated at 2022-06-23 15:49:04.455030
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:06.673429
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as exc:
        assert False, f"Exception : {exc}"

# Generated at 2022-06-23 15:49:07.538602
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:18.352507
# Unit test for function escape
def test_escape():
    import pytest
    from typing import Dict
    from types import TracebackType as tbty

    err_tests: Dict[Text, Exception] = {
        # \x escapes
        "\\x1": ValueError("invalid hex string escape ('\\x1')"),
        "\\x12": ValueError("invalid hex string escape ('\\x12')"),
        # \0 escapes
        "\\55": ValueError("invalid octal string escape ('\\55')"),
        "\\555": ValueError("invalid octal string escape ('\\555')"),
        # Other escapes
        "\\q": ValueError("invalid string escape ('\\q')"),
        "\\": ValueError("invalid string escape ('\\')"),
    }


# Generated at 2022-06-23 15:49:25.431121
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == "\0"
    assert evalString("'a'") == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString("'\\x61'") == "a"
    assert evalString("'''\\x61'''") == "a"
    assert evalString('"""\\x61"""') == "a"
    assert evalString("'\\141'") == "a"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\\t'") == "\t"
    assert evalString('"""\\\t"""') == "\t"
    assert evalString("'''\\\t'''") == "\t"

# Generated at 2022-06-23 15:49:36.903491
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{1,2}|[0-7]{1,3})', r'\a')) == '\a'
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{1,2}|[0-7]{1,3})', r'\x41')) == 'A'

# Generated at 2022-06-23 15:49:37.402568
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:45.763967
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"""\f""")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"""\\""")) == "\\"



# Generated at 2022-06-23 15:49:55.994738
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\'", r"\'")) == "'"

# Generated at 2022-06-23 15:50:02.577385
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'ab\\'\\\\c'") == "ab'\\c"
    assert evalString("'ab\\'\\\\c'") != "ab'\\c"
    assert evalString("'\\'") == "'"
    assert evalString('"\\"') == '"'
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x1f'") == "\x1f"

# Generated at 2022-06-23 15:50:15.380064
# Unit test for function test
def test_test():
    """Test that a few specific ones work"""
    assert evalString(r"'\t'") == "\t"
    assert evalString(r"'\x09'") == "\x09"
    assert evalString(r"'\r'") == "\r"
    assert evalString(r"'\n'") == "\n"
    assert evalString(r"'\xf'") == "\x0f"
    assert evalString(r"'\x10'") == "\x10"
    assert evalString(r"'\x56'") == "\x56"
    assert evalString(r"'\xff'") == "\xff"
    assert evalString(r"'\x00'") == "\x00"
    assert evalString(r"'\x0'") == "\x00"
    assert evalString(r"'\0'") == "\x00"

# Generated at 2022-06-23 15:50:25.053810
# Unit test for function escape
def test_escape():

    # Handle backslashes
    assert (escape(re.match(r"\\", '\\')).encode() == b'\\')
    assert (escape(re.match(r"\\", '\\\\')).encode() == b'\\')
    assert (escape(re.match(r"\\\\", '\\\\')).encode() == b'\\')
    assert (escape(re.match(r"\\\\", '\\\\\\\\')).encode() == b'\\')

    # Handle double quotes
    assert (escape(re.match(r'\\"', '\\"')).encode() == b'"')
    assert (escape(re.match(r'\\"', '\\\\"')).encode() == b'"')
    assert (escape(re.match(r'\\\\"', '\\\\"')).encode() == b'"')
   

# Generated at 2022-06-23 15:50:27.442621
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        assert False, "test_test failed"



# Generated at 2022-06-23 15:50:38.374211
# Unit test for function escape
def test_escape():
    """
    Test that escape correctly converts escape sequences.
    """

    import unittest

    class TestEscape(unittest.TestCase):
        def test_simple(self):
            m = re.match(r"\\(['\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")
            s = escape(m)
            self.assertEqual(s, "\a")

        def test_hex(self):
            m = re.match(r"\\(['\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x0A")
            s = escape(m)
            self.assertEqual(s, "\n")
