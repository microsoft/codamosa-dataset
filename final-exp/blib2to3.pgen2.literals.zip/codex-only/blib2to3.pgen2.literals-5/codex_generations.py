

# Generated at 2022-06-23 15:40:39.414372
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\\'', '\\\'')) == "'"
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape(re.match(r'\\a', '\\a')) == '\x07'
    assert escape(re.match(r'\\\\', '\\\\')) == '\\'
    assert escape(re.match(r'\\x20', '\\x20')) == ' '
    assert escape(re.match(r'\\x7f', '\\x7f')) == '\x7f'
    assert escape(re.match(r'\\x80', '\\x80')) == '\x80'
    assert escape(re.match(r'\\xFF', '\\xFF')) == '\xff'
    assert escape

# Generated at 2022-06-23 15:40:41.514430
# Unit test for function test
def test_test():
    assert evalString(r'"\x01"') == "\\x01"


# Generated at 2022-06-23 15:40:43.084354
# Unit test for function test
def test_test():
    with pytest.raises(Exception) as exception:
        test()



# Generated at 2022-06-23 15:40:43.652320
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:45.577833
# Unit test for function test
def test_test():
    test()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-23 15:40:48.725585
# Unit test for function test
def test_test():
    import io
    from contextlib import redirect_stdout
    # Check that calling the test function generates data on stdout
    f = io.StringIO()
    with redirect_stdout(f):
        test()
    assert f.getvalue()

# Generated at 2022-06-23 15:40:54.907875
# Unit test for function escape

# Generated at 2022-06-23 15:40:55.887130
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:02.364172
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "\'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r'\\"', r'\\')) == '\\'

    assert escape(re.match(r"\\x12", r"\x12")) == "\x12"

    assert escape(re.match(r"\\012", r"\012")) == "\x0a"
    assert escape(re.match(r"\\090", r"\090")) == "\x28"

# Generated at 2022-06-23 15:41:12.349368
# Unit test for function escape

# Generated at 2022-06-23 15:41:25.282507
# Unit test for function evalString
def test_evalString():
    import string

    # Test the cases where evalString() cannot parse the given
    # string properly.
    for s in ('"""abc"""', "'''abc'''", '"ab\"c"', "'ab\\'c'"):
        try:
            evalString(s)
        except ValueError:
            pass
        else:
            raise AssertionError("evalString() failed to raise exception for the string: %s" % s)

    # Test that the result of evalString() is the same as the
    # result of string.strip(r'...').
    for s in string.printable:
        assert evalString(s) == string.strip(r"'" + s + "'", "'")

    assert evalString(r"'\"'") == '"'
    assert evalString(r"'\'a'") == "'a"
    assert eval

# Generated at 2022-06-23 15:41:27.243956
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        raise AssertionError("test failed", e)

# Generated at 2022-06-23 15:41:28.250690
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:30.209710
# Unit test for function test
def test_test():
    test()
    try:
        evalString("\\0")
    except ValueError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-23 15:41:34.537005
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r"\\'", r"\\x23")) == "#"
    assert escape(re.match(r"\\'", r"\\10")) == chr(8)


# Generated at 2022-06-23 15:41:42.349731
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"
    assert escape("\\x12") == "\x12"
    assert escape("\\17") == "\x11"
    assert escape("\\12") == "\x0a"
    assert escape("\\012") == "\x0a"
    assert escape("\\405") == "\x15"
    assert escape("\\177") == "\x7f"

# Generated at 2022-06-23 15:41:52.957081
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\''") == "'"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x69'") == "i"
    assert evalString("'\\x20'") == " "
    assert evalString("'\\xC8'") == "È"
    assert evalString("'\\x1b'") == "\x1b"
    assert evalString("'\\033'") == "\033"
    assert evalString("'\\0'") == "\0"

    with pytest.raises(ValueError):
        assert evalString("'\\x'")
    with pytest.raises(ValueError):
        assert evalString("'\\x1'")
    with pytest.raises(ValueError):
        assert evalString("'\\x1G'")

# Generated at 2022-06-23 15:41:59.010836
# Unit test for function escape
def test_escape():
    from StringIO import StringIO
    import tokenize
    from io import BytesIO
    r = StringIO(u"\\x0a'H\\xe9llo, world!'".encode('raw-unicode-escape'))
    t = tokenize.generate_tokens(BytesIO(r.read()).readline)
    try:
        while True:
            token = t.next()
            if token[0] == tokenize.STRING:
                evalString(token[1])
    except StopIteration:
        pass
    except ValueError:
        assert False

# Generated at 2022-06-23 15:42:04.531412
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"

    assert evalString(r"'\x7f'") == chr(127)
    assert evalString(r'"\x7f"') == chr(127)

    assert evalString(r"'\127'") == chr(127)
    assert evalString(r'"\127"') == chr(127)

    assert evalString(r"'\xff'") == chr(255)
    assert evalString(r'"\xff"') == chr(255)

    assert evalString(r"'\377'") == chr(255)
    assert evalString(r'"\377"') == chr(255)



# Generated at 2022-06-23 15:42:07.200788
# Unit test for function test
def test_test():
    # Check that the test actually finishes without failing
    test()
    # Check that the test actually ran
    assert(evalString('"\\x69"') == 'i')

# Generated at 2022-06-23 15:42:08.475685
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:42:17.674138
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\\"'") == "\""
    assert evalString("'\\''") == "'"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\000'") == "\0"
    assert evalString("'\\016'") == "\016"

# Generated at 2022-06-23 15:42:28.320014
# Unit test for function escape

# Generated at 2022-06-23 15:42:32.235203
# Unit test for function escape

# Generated at 2022-06-23 15:42:32.760607
# Unit test for function test
def test_test():
    _ = test()

# Generated at 2022-06-23 15:42:33.995510
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        print(e)

# Generated at 2022-06-23 15:42:36.614828
# Unit test for function test
def test_test():
    # If the test function has no output and no exceptions, we
    # assume that it passed
    test()

# Generated at 2022-06-23 15:42:39.346321
# Unit test for function test
def test_test():
    import unittest

    class Test_test(unittest.TestCase):
        def test(self):
            test()

    unittest.main()

# Generated at 2022-06-23 15:42:39.994185
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:51.097794
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\x1", "\\x1")) == "\x01"

# Generated at 2022-06-23 15:42:51.746518
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:03.364378
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"(\\)(a)", '\\a')) == '\a'
    assert escape(re.match(r"(\\)(b)", '\\b')) == '\b'
    assert escape(re.match(r"(\\)(f)", '\\f')) == '\f'
    assert escape(re.match(r"(\\)(n)", '\\n')) == '\n'
    assert escape(re.match(r"(\\)(r)", '\\r')) == '\r'
    assert escape(re.match(r"(\\)(t)", '\\t')) == '\t'
    assert escape(re.match(r"(\\)(v)", '\\v')) == '\v'
    assert escape(re.match(r"(\\)(\')", "\\'")) == "'"
   

# Generated at 2022-06-23 15:43:06.794898
# Unit test for function evalString
def test_evalString():
    s = evalString("'%s'" % chr(255))
    assert ord(s) == 255

    # Verify that a string with a trailing space is not evaluated
    evalString("'foo' ")

# Generated at 2022-06-23 15:43:07.389598
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:19.406175
# Unit test for function evalString
def test_evalString():
    # Test incorrect type
    s = 1
    try:
        evalString(s)
    except TypeError:
        pass
    else:
        raise Exception("evalString on incorrect type should raise TypeError")

    # Test empty string
    s = ""
    e = evalString(s)
    assert e == ""

    # Test empty string with quotes
    s = '""'
    e = evalString(s)
    assert e == ""

    # Test empty string using three quotes
    s = '"""'
    e = evalString(s)
    assert e == ""

    # Test non-empty string without quotes
    s = "Hello World"
    try:
        evalString(s)
    except ValueError:
        pass
    else:
        raise Exception("evalString on string without quotes should raise ValueError")

    # Test non

# Generated at 2022-06-23 15:43:31.205065
# Unit test for function escape
def test_escape():
    # Positive tests
    assert escape(re.search(r'\\a', '\\a')) == '\a'
    assert escape(re.search(r'\\b', '\\b')) == '\b'
    assert escape(re.search(r'\\f', '\\f')) == '\f'
    assert escape(re.search(r'\\n', '\\n')) == '\n'
    assert escape(re.search(r'\\r', '\\r')) == '\r'
    assert escape(re.search(r'\\t', '\\t')) == '\t'
    assert escape(re.search(r'\\v', '\\v')) == '\v'
    assert escape(re.search(r'\\\'', "\\'")) == "'"

# Generated at 2022-06-23 15:43:31.560868
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:43.414955
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-23 15:43:54.326307
# Unit test for function evalString
def test_evalString():
    test_data = [
            ('hello', 'hello'),
            ('\n', '\n'),
            ('\a', '\a'),
            ('\b', '\b'),
            ('\f', '\f'),
            ('\r', '\r'),
            ('\t', '\t'),
            ('\v', '\v'),
            ('\\', '\\'),
        ]

    for s, val in test_data:
        assert evalString("'{0}'".format(s)) == val

    for s, val in test_data:
        assert evalString('"{0}"'.format(s)) == val

    for s, val in test_data:
        assert evalString("'''{0}'''".format(s)) == val

    for s, val in test_data:
        assert evalString

# Generated at 2022-06-23 15:44:00.141114
# Unit test for function evalString
def test_evalString():
    # Test a few common cases
    assert evalString("'hello'") == "hello"
    assert evalString('"hello"') == "hello"
    assert evalString("'x\\ny'") == "x\ny"
    assert evalString("'''x\\ny'''") == "x\\ny"
    assert evalString("'\\u20ac'") == "\u20ac"
    assert evalString("'\\U0001f4a9'") == "\U0001f4a9"

    # Test various escape sequences
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"

# Generated at 2022-06-23 15:44:04.452204
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", r"\x12")) == "x1"
    assert escape(re.match(r"\\x12", r"\x12")) != "x2"

# Generated at 2022-06-23 15:44:05.041719
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:44:12.967257
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'\n'") == "\n"
    assert evalString(r"'\001'") == "\x01"
    assert evalString(r"'\xff'") == "\xff"
    assert evalString(r"'\0xff'") == "ff"
    assert evalString('"\n"') == "\n"
    assert evalString('"\001"') == "\x01"
    assert evalString('"\xff"') == "\xff"
    assert evalString('"\0xff"') == "ff"
    assert evalString('"foo"') == "foo"
    assert evalString('"foo\\\nbar"') == "foo"
    assert evalString("'foo' + 'bar'") == "foobar"
    assert evalString("'foo'   'bar'") == "foobar"
   

# Generated at 2022-06-23 15:44:21.815521
# Unit test for function evalString
def test_evalString():
    assert evalString("'\n'") == "\n"
    assert evalString("'a\x03bb'") == "a\x03bb"
    assert evalString("'\\x03bb\\''") == "\x03bb'"
    assert evalString("'\\''") == "'"
    assert evalString('"\\r\\n\\t\\v\\b\\a\\\\\\"\\\\"') == "\r\n\t\v\b\a\\\"\\"

    try:
        evalString("'''")
    except ValueError:
        pass
    else:
        assert False, "expected a ValueError"

    try:
        evalString("'foo\\zbar'")
    except ValueError:
        pass
    else:
        assert False, "expected a ValueError"

# Generated at 2022-06-23 15:44:32.487488
# Unit test for function evalString
def test_evalString():
    assert evalString("'ab'") == 'ab'
    assert evalString("'\\'ab'") == '\'ab'
    assert evalString("'ab\\''") == 'ab\''
    assert evalString("'\\'") == "'"
    assert evalString("'\\\\'") == '\\'
    assert evalString("'\\a'") == '\a'
    assert evalString("'\\b'") == '\b'
    assert evalString("'\\f'") == '\f'
    assert evalString("'\\n'") == '\n'
    assert evalString("'\\r'") == '\r'
    assert evalString("'\\t'") == '\t'
    assert evalString("'\\v'") == '\v'

# Generated at 2022-06-23 15:44:42.120216
# Unit test for function evalString

# Generated at 2022-06-23 15:44:42.622157
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:45.338512
# Unit test for function test
def test_test():
    with pytest.raises(AssertionError):
        test()

# Generated at 2022-06-23 15:44:56.951465
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x32"') == '2'
    assert evalString("'\\x32'") == '2'
    assert evalString("'\"'") == '"'
    assert evalString('\'"\'') == '"'
    assert evalString("'\\''") == "'"
    assert evalString('\'"\'') == '"'
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\''") == "'"
    assert evalString('"\\\'\"\\\'\\\'"') == "'\"\\'\\'"
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"

# Generated at 2022-06-23 15:45:07.364908
# Unit test for function evalString
def test_evalString():
    """Test evalString function"""
    assert evalString("'\\''") == "'"
    assert evalString("'\\'") == "\\"
    assert evalString("'\\" "t'") == "\t"
    assert evalString("'\\" "n'") == "\n"
    assert evalString("'\\" "'") == "\\"
    assert evalString("'\\" "00'") == "\0"
    assert evalString("'\\" "07'") == "\a"
    assert evalString("'\\" "0177'") == "\x7f"
    assert evalString("'\\" "0177 '") == "\x7f "
    assert evalString("'\\" "x7f'") == "\x7f"
    assert evalString("'\\" "x7f '") == "\x7f "

# Generated at 2022-06-23 15:45:11.299411
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError as e:
        print("Caught AssertionError:", e)
    except:
        print("Caught error")
    else:
        print("No error")

# Generated at 2022-06-23 15:45:18.660276
# Unit test for function escape
def test_escape():
    escape_test_cases = [
        '\\"',
        '\\a',
        '\\b',
        '\\f',
        '\\n',
        '\\r',
        '\\t',
        '\\v',
        '\\\'',
        '\\x41',
        '\\xFF',
        '\\x001',
        '\\123',
        '\\\\'
    ]
    for test_case in escape_test_cases:
        assert evalString(test_case) == re.sub(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", escape, test_case)

# Generated at 2022-06-23 15:45:19.567484
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:30.551500
# Unit test for function escape
def test_escape():
    assert escape(re_match("\\'", r"\'", flags=0)) == "'"
    assert escape(re_match("\\\"", r'\"', flags=0)) == '"'
    assert escape(re_match("\\x89", r"\x89", flags=0)) == chr(0x89)
    assert escape(re_match("\\0", r"\0", flags=0)) == "\0"
    assert escape(re_match("\\1", r"\1", flags=0)) == "\1"
    assert escape(re_match("\\2", r"\2", flags=0)) == "\2"
    assert escape(re_match("\\3", r"\3", flags=0)) == "\3"

# Generated at 2022-06-23 15:45:39.323896
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == 'a'
    assert evalString("'\\''") == "'"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\x61'") == 'a'
    assert evalString("'\\x6Afoo'") == '\x6a'
    assert evalString("'\\x6a'") == '\x6a'
    assert evalString("'\\x'") == 'x'
    assert evalString("'\\x1'") == '\x01'
    assert evalString("'\\x12'") == '\x12'
    assert evalString("'\\x123'") == '\x0123'
    assert evalString("'\\0'") == '\0'
    assert evalString("'\\07'") == '\07'

# Generated at 2022-06-23 15:45:40.163530
# Unit test for function test
def test_test():
    assert callable(test)

# Generated at 2022-06-23 15:45:50.303782
# Unit test for function test
def test_test():
    from io import StringIO
    from unittest import TestCase

    class StreamTester(TestCase):
        def check_output(self, exp):
            self.assertEqual(self.saved_stdout.getvalue(), exp)

        def setUp(self):
            self.saved_stdout = StringIO()
            self.old_stdout = sys.stdout
            sys.stdout = self.saved_stdout

        def tearDown(self):
            sys.stdout = self.old_stdout

    class Test_test(StreamTester):
        def test(self):
            test()
            self.check_output("")

    run_unittest(Test_test)

# Generated at 2022-06-23 15:46:02.426058
# Unit test for function test
def test_test():
    import io
    import sys
    import unittest

    from nuitka import (
        Options,
        Tracing,
        Utils,
    )

    # Create temporary Python module and execute it.
    test_filename = Utils.getTempFilename(".py")
    try:
        with io.open(test_filename, mode="w", encoding="utf-8") as output:
            output.write("test()\n")

        Options.getPythonPaths(False, False)
        Tracing.checkTrace(False)

        test_result = Utils.executePythonCommand(test_filename, True)
        assert test_result.signal_number == 0, test_result
        assert test_result.exit_code == 0, test_result
    finally:
        Utils.removeFile(test_filename)

# Generated at 2022-06-23 15:46:11.488785
# Unit test for function escape
def test_escape():
    import pytest
    assert escape(re.search(r"\\x1A", "\\x1A")) == "\x1a"
    assert escape(re.search(r"\\x1A", "\\x1Aabc")) == "\x1a"
    assert escape(re.search(r"\\x1A", "\\x1A1234")) == "\x1a"
    assert escape(re.search(r"\\x1A", "\\x1A1234\\x1A")) == "\x1a"

    with pytest.raises(ValueError):
        evalString("\\x")



# Generated at 2022-06-23 15:46:20.953705
# Unit test for function evalString

# Generated at 2022-06-23 15:46:26.397402
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\\a', r'\a')).encode() == b'\x07'
    assert escape(re.match(r'\\\b', r'\b')).encode() == b'\x08'
    assert escape(re.match(r'\\\f', r'\f')).encode() == b'\x0c'
    assert escape(re.match(r'\\\n', r'\n')).encode() == b'\n'
    assert escape(re.match(r'\\\r', r'\r')).encode() == b'\r'
    assert escape(re.match(r'\\\t', r'\t')).encode() == b'\t'

# Generated at 2022-06-23 15:46:33.575405
# Unit test for function escape
def test_escape():
  def test(esc, expected_result):
    result = escape(re.match(r"\\" + esc, "\\" + esc))
    assert result == expected_result, (esc, result, expected_result)

  test("a", "\x07")
  test("b", "\x08")
  test("f", "\x0c")
  test("n", "\n")
  test("r", "\r")
  test("t", "\t")
  test("v", "\x0b")
  test("'", "'")
  test('"', '"')
  test("\\", "\\")
  test("x03", "\x03")
  test("0", "\0")
  test("007", "\x07")


# Generated at 2022-06-23 15:46:42.386632
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\\[\\\'"]', "\\'")).__eq__("'")
    assert escape(re.match('\\\\x...', "\\xff")).__eq__("ÿ")
    assert escape(re.match('\\\\x', "\\x")).__eq__("x")
    assert escape(re.match('\\\\x0', "\\xfg")).__eq__("fg")
    assert escape(re.match('\\\\', "\\a")).__eq__("")
    assert escape(re.match('\\\\0...', "\\000")).__eq__("\x00")
    assert escape(re.match('\\\\0', "\\0")).__eq__("\x00")
    assert escape(re.match('\\\\0', "\\00")).__eq__("\x00")

# Generated at 2022-06-23 15:46:43.233008
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:53.847169
# Unit test for function evalString
def test_evalString():
    assert evalString("'''abc'''") == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString("'a\\\nb'") == 'ab'
    assert evalString("'a\\\rb'") == 'ab'
    assert evalString("'a\\\tb'") == 'ab'
    assert evalString("'a\\\fb'") == 'ab'
    assert evalString("'\\\nabc'") == 'abc'
    assert evalString("'\\\rabc'") == 'abc'
    assert evalString("'\\\tabc'") == 'abc'
    assert evalString("'\\\fabc'") == 'abc'
    assert evalString("'\\\'\\\"\\\\'") == "'\"\\"

# Generated at 2022-06-23 15:46:58.504360
# Unit test for function evalString
def test_evalString():
    r = repr('\t')
    assert evalString(r) == '\t'

    r = repr('')
    assert evalString(r) == ''

    r = repr('\'')
    assert evalString(r) == '\''

    r = repr('\n')
    assert evalString(r) == '\n'

# Generated at 2022-06-23 15:47:03.652854
# Unit test for function escape

# Generated at 2022-06-23 15:47:12.895927
# Unit test for function evalString
def test_evalString():
    """Assert that evalString("'one'") works and so does evalString('"one"')"""
    assert evalString("'one'") == "one"
    assert evalString('"one"') == "one"
    assert evalString("'two'") == "two"
    assert evalString('"two"') == "two"
    assert evalString("'three'") == "three"
    assert evalString('"three"') == "three"
    assert evalString("'four'") == "four"
    assert evalString('"four"') == "four"
    assert evalString("'five'") == "five"
    assert evalString('"five"') == "five"



# Generated at 2022-06-23 15:47:13.958142
# Unit test for function test
def test_test():
    test()


# Unit tests for function evalString

# Generated at 2022-06-23 15:47:25.647261
# Unit test for function escape
def test_escape():
    # Test for octal escapes
    assert escape(re.match(r"\\[0-7]{1,3}", r"\00")) == "\x00"
    assert escape(re.match(r"\\[0-7]{1,3}", r"\7")) == "\x07"
    assert escape(re.match(r"\\[0-7]{1,3}", r"\37")) == "\x1f"
    assert escape(re.match(r"\\[0-7]{1,3}", r"\377")) == "\xff"
    assert escape(re.match(r"\\[0-7]{1,3}", r"\400")) == "\x80"

# Generated at 2022-06-23 15:47:30.999887
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == "foo"
    assert evalString("'foo'") == "foo"
    assert evalString('"""foo"""') == "foo"
    assert evalString("'''foo'''") == "foo"
    assert evalString('"foo\\nbar"') == "foo\nbar"
    assert evalString("'foo\\nbar'") == "foo\nbar"
    assert evalString('"foo\\073"') == "foo;3"
    assert evalString("'foo\\073'") == "foo;3"
    assert evalString('"foo\\nbar"') == "foo\nbar"
    assert evalString("'foo\\nbar'") == "foo\nbar"
    assert evalString('"foo\\x21"') == "foo!"

# Generated at 2022-06-23 15:47:34.725044
# Unit test for function escape
def test_escape():

    import unittest

    class TestEscape(unittest.TestCase):

        def test_escape_throws_with_invalid_hex_string_escape(self):
            with self.assertRaises(ValueError):
                escape(None)

    unittest.main()

# Generated at 2022-06-23 15:47:36.240787
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:36.889314
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:48.160464
# Unit test for function evalString
def test_evalString():
    import unittest

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            pass

        def test_empty_input(self):
            # evalString should return an empty string with empty inputs
            self.assertEqual(evalString("''"), "")
            self.assertEqual(evalString('""'), "")

        def test_simple_inputs(self):
            # evalString should return the input without quotes
            self.assertEqual(evalString("'hello'"), "hello")
            self.assertEqual(evalString('"hello"'), "hello")

        def test_inputs_with_quotes(self):
            # evalString should return the input with escaped quotes
            self.assertEqual(evalString("'hello \"world\"'"), 'hello "world"')

# Generated at 2022-06-23 15:47:55.861946
# Unit test for function escape
def test_escape():
   m = Match(1, '\\', '\\', [], None, None)
   assert escape(m) == '\\', "escape('\\')"

   m = Match(1, '\\', 'a', [], None, None)
   assert escape(m) == '\a', "escape('a')"

   m = Match(1, '\\', 'b', [], None, None)
   assert escape(m) == '\b', "escape('b')"

   m = Match(1, '\\', 'f', [], None, None)
   assert escape(m) == '\f', "escape('f')"

   m = Match(1, '\\', 'n', [], None, None)
   assert escape(m) == '\n', "escape('n')"


# Generated at 2022-06-23 15:48:07.692848
# Unit test for function evalString
def test_evalString():
   assert evalString('"abcd"') == 'abcd'
   assert evalString("'dcba'") == 'dcba'
   assert evalString('"a\\x00b"') == 'a\x00b'
   assert evalString('"a\\\\b"') == 'a\\b'
   assert evalString('"a\\"b"') == 'a"b'
   assert evalString("'a\\'b'") == "a'b"
   assert evalString('"a\\\'b"') == "a'b"
   assert evalString("'a\\\"b'") == 'a"b'
   assert evalString('"abc\\ndef"') == 'abc\ndef'
   assert evalString("'abc\\ndef'") == 'abc\ndef'

# Generated at 2022-06-23 15:48:09.381543
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\\w', r'\a')) == '\a'


# Generated at 2022-06-23 15:48:18.055250
# Unit test for function evalString
def test_evalString():

    # Test empty strings.
    assert evalString("''") == ""
    assert evalString('""') == ""

    # Simple strings.
    assert evalString("'this is a test'") == "this is a test"
    assert evalString('"this is a test"') == "this is a test"

    # Backslash escapes.
    # These are all equivalent.
    assert evalString("'\\'") == "'"
    assert evalString("'\\x27'") == "'"
    assert evalString("'\\047'") == "'"

    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\x5c'") == "\\"
    assert evalString("'\\134'") == "\\"

    assert evalString("'\\a'") == "\a"

# Generated at 2022-06-23 15:48:27.967462
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"a\tb\nc"') == "a\tb\nc"
    assert evalString('"a\\tb\\nc"') == "a\\tb\\nc"
    assert evalString('"a\\tb\\r\\nc"') == "a\\tb\\r\\nc"
    assert evalString('"a\\tb\\r\\nc"') == "a\\tb\\r\\nc"
    assert evalString('"\\"abc\\""') == '"abc"'
    assert evalString('"\\"abc\\""') == '"abc"'
    assert evalString('"\\"a\\"b\\"c\\""') == '"a"b"c"'
    assert eval

# Generated at 2022-06-23 15:48:28.874006
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:48:39.314094
# Unit test for function escape
def test_escape():
    tests = {
        "\\'": "'",
        '\\"': '"',
        "\\a": "\a",
        "\\b": "\b",
        "\\f": "\f",
        "\\n": "\n",
        "\\r": "\r",
        "\\t": "\t",
        "\\v": "\v",
        "\\\a": "\\\a",
        "\\\\": "\\\\",
        "\\'": "'",
        "\\x61": "a",
        "\\x61\\x62\\x63": "abc",
        "\\x0": "\0",
    }
    for escape_string, expected_result in tests.items():
        assert escape(re.match(r"\\(.*)", escape_string)) == expected_result

# Generated at 2022-06-23 15:48:44.207626
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\0'")

# Generated at 2022-06-23 15:48:45.008855
# Unit test for function test
def test_test():
  test()

# Generated at 2022-06-23 15:48:51.500614
# Unit test for function escape
def test_escape():
    # test a few simple cases
    assert escape(re.match('\\x61', 'a')) == '\a'
    assert escape(re.match('\\x62', 'b')) == '\b'
    assert escape(re.match('\\x63', 'c')) == '\x63'
    assert escape(re.match('\\x64', 'd')) == '\x64'
    assert escape(re.match('\\x65', 'e')) == '\x65'

# Generated at 2022-06-23 15:48:53.824848
# Unit test for function evalString
def test_evalString():
    s = '"\\x47"'
    res = evalString(s)
    assert res == 'G', res  # handles hex escapes

# Generated at 2022-06-23 15:49:03.935854
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\0', '\\0')) == '\x00'
    assert escape(re.match('\\001', '\\001')) == '\x01'
    assert escape(re.match('\\x00', '\\x00')) == '\x00'
    assert escape(re.match('\\x001', '\\x001')) == '\x01'
    assert escape(re.match('\\x0', '\\x0')) == '\x00'
    assert escape(re.match('\\x', '\\x')) == '\x00'

    assert escape(re.match('\\x1', '\\x1')) == '\x01'
    assert escape(re.match('\\x01', '\\x01')) == '\x01'

# Generated at 2022-06-23 15:49:04.563276
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:49:05.104258
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:12.635451
# Unit test for function escape
def test_escape():
    test_cases = {
        "\\a": "\a",
        "\\b": "\b",
        "\\f": "\f",
        "\\n": "\n",
        "\\r": "\r",
        "\\t": "\t",
        "\\v": "\v",
        "\\'": "'",
        '\\"': '"',
        "\\\\": "\\",
        "\\x41": "A",
        "\\064": "@",
        "\\x064": "@",
        "\\055": "-",
        "\\078": "x",
    }


# Generated at 2022-06-23 15:49:21.203822
# Unit test for function evalString
def test_evalString():
    test_vectors = {
        b'"hello world"': "hello world",
        b'"hello \x00 world"': "hello \x00 world",
        b'"hello\tworld"': "hello\tworld",
        b'"hello\bworld"': "hello\bworld",
        b'"hello\nworld"': "hello\nworld",
        b'"hello\rworld"': "hello\rworld",
        b'"hello\\\\world"': "hello\\\\world",
        b'"hello\\tworld"': "hello\\tworld",
    }

    for py_str, c_str in test_vectors.items():
        assert evalString(py_str) == c_str

# Generated at 2022-06-23 15:49:22.024767
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:22.705097
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:32.179770
# Unit test for function evalString
def test_evalString():
    s = 'Hello, World!'
    assert evalString(repr(s)) == s
    assert evalString('"Hello, World!"') == s
    assert evalString("'Hello, World!'") == s
    
    s = 'Hello, "World!"'
    assert evalString(repr(s)) == s
    assert evalString('"Hello, \"World!\""') == s
    assert evalString("'Hello, \"World!\"'") == s

    assert evalString('''"Hello, 'World!'"''') == "Hello, 'World!'"
    assert evalString("'''Hello, 'World!'''") == "Hello, 'World!'"

# Generated at 2022-06-23 15:49:41.209965
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello world"') == 'hello world'
    assert evalString("'hello world'") == 'hello world'
    assert evalString('"hello \\\\\\\\ world"') == r'hello \ world'
    assert evalString('"hello \\\' world"') == "hello ' world"
    assert evalString('"hello \\\" world"') == 'hello " world'
    assert evalString('"hello \a world"') == 'hello \x07 world'
    assert evalString(r'"hello \b world"') == 'hello \x08 world'
    assert evalString(r'"hello \f world"') == 'hello \x0c world'
    assert evalString(r'"hello \n world"') == 'hello \n world'

# Generated at 2022-06-23 15:49:52.285947
# Unit test for function evalString
def test_evalString():
    '''Verifies function can eval valid Python string literals'''
    assert evalString("''") == ''
    assert evalString('""') == ''
    assert evalString("'a'") == 'a'
    assert evalString('"a"') == 'a'
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString("'\\a'") == '\a'
    assert evalString("'\\b'") == '\b'
    assert evalString("'\\f'") == '\f'
    assert evalString("'\\n'") == '\n'
    assert evalString("'\\r'") == '\r'
    assert evalString("'\\t'") == '\t'

# Generated at 2022-06-23 15:49:52.863486
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:54.457150
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:50:04.408162
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\x63"') == 'c'
    assert evalString(r"'\x63'") == 'c'
    assert evalString(r'"\x00"') == '\x00'
    assert evalString(r"'\x00'") == '\x00'
    assert evalString(r'"\x63"') == 'c'
    assert evalString(r'"\x63"') == 'c'
    assert evalString(r'"\x63"') == 'c'
    assert evalString(r"r'''C:\x63'''") == r"""r'''C:\x63'''"""
    assert evalString(r"b'''C:\x62'''") == r"""b'''C:\x62'''"""

# Generated at 2022-06-23 15:50:12.010633
# Unit test for function escape
def test_escape():
    s = r"\u\v\U\V\u1\U1"
    s_single_quote = r"'\u\v\U\V\u1\U1'"
    s_double_quote = r'"\u\v\U\V\u1\U1"'

# Generated at 2022-06-23 15:50:23.063118
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"

# Generated at 2022-06-23 15:50:23.677758
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:50:35.960759
# Unit test for function escape
def test_escape():
    import pytest
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\'")) == "'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\"")) == '"'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\\")) == "\\"