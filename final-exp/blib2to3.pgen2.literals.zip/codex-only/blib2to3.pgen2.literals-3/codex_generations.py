

# Generated at 2022-06-23 15:40:41.564256
# Unit test for function evalString
def test_evalString():
    # Test that evalString does what we want.
    assert evalString('"\'"') == "'"
    assert evalString('"abc"') == "abc"

    # Test that evalString raises an exception for invalid escapes.

# Generated at 2022-06-23 15:40:51.349136
# Unit test for function escape
def test_escape():
  # Test simple escapes
  input_strings = {
      r'\n': '\n',
      r'\r': '\r',
      r'\t': '\t',
      r'\v': '\v',
      r'\a': '\a',
      r'\b': '\b',
      r'\f': '\f',
      r'\\': '\\',
  }
  for k, v in input_strings.items():
    assert(escape(re.search(r'\\.', k)) == v)

  # Test 3-digit octal escapes

# Generated at 2022-06-23 15:40:51.906313
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:02.738581
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\'\\\"\\\\\\x3f\\041\\101'") == "\a\b\f\n\r\t\v\'\"\\?\x1bA"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\\\x3f\\041\\101"') == "\a\b\f\n\r\t\v\'\"\\?\x1bA"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\'\\\"\\\\\\x3f\\041\\101'") == "\a\b\f\n\r\t\v\'\"\\?\x1bA"

# Generated at 2022-06-23 15:41:05.952386
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"

# Generated at 2022-06-23 15:41:08.287435
# Unit test for function evalString
def test_evalString():
    source = "'\\x5c'"
    assert evalString(source) == "'\\'"
    source = "\\x5c"
    assert evalString(source) == "\\x5c"

# Generated at 2022-06-23 15:41:09.457707
# Unit test for function test
def test_test():
  assert test() == None

# Generated at 2022-06-23 15:41:15.066170
# Unit test for function escape
def test_escape():
    # Test for escape function, for the following:
    # test escape function against all valid and invalid
    # escape sequences.
    import string

    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r'\\\n', r'\\\n')) == '\n'
    assert escape(re.match(r'\\xab', r'\\xab')) == '\xab'
    assert escape(re.match(r'\\077', r'\\077')) == chr(0o77)
    assert escape(re.match(r'\\xab', r'\\xab')) == '\xab'

# Generated at 2022-06-23 15:41:16.157710
# Unit test for function test
def test_test():
    test()
    assert True

# Generated at 2022-06-23 15:41:19.999628
# Unit test for function test
def test_test():
    try:
        test()
    except:
        # This function should produce no output
        print("Oops")
    else:
        print("Ok")
#


# Unit tests for function evalString

# Generated at 2022-06-23 15:41:26.435713
# Unit test for function test
def test_test():
    """Test the test() function."""
    import sys
    from io import StringIO

    # Run the test() function with output being captured
    # in a StringIO object.
    result = StringIO()
    sys.stdout = result
    test()
    sys.stdout = sys.__stdout__

    # Make sure no output was printed
    output = result.getvalue()
    assert output == ""

# Generated at 2022-06-23 15:41:27.243386
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-23 15:41:28.212833
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:36.049901
# Unit test for function evalString

# Generated at 2022-06-23 15:41:48.727589
# Unit test for function escape
def test_escape():
    # "valid" strings
    assert escape(re.match("\\'", "'")) == "'"
    assert escape(re.match("\\\"", "\"")) == "\""
    assert escape(re.match("\\\\", "\\")) == "\\"
    assert escape(re.match("\\a", "a")) == "\a"
    assert escape(re.match("\\b", "b")) == "\b"
    assert escape(re.match("\\f", "f")) == "\f"
    assert escape(re.match("\\n", "n")) == "\n"
    assert escape(re.match("\\r", "r")) == "\r"
    assert escape(re.match("\\t", "t")) == "\t"
    assert escape(re.match("\\v", "v")) == "\v"

# Generated at 2022-06-23 15:41:58.855767
# Unit test for function escape
def test_escape():
    def check(result, pattern):
        m = re.match(pattern, result)
        assert m, result
        assert m.end() == len(result), result

    check(escape(re.match(r"\\a", "")), r"\a")
    check(escape(re.match(r"\\b", "")), r"\b")
    check(escape(re.match(r"\\f", "")), r"\f")
    check(escape(re.match(r"\\n", "")), r"\n")
    check(escape(re.match(r"\\r", "")), r"\r")
    check(escape(re.match(r"\\t", "")), r"\t")

# Generated at 2022-06-23 15:42:11.166397
# Unit test for function escape
def test_escape():
    assert escape(re.match('.*', r"\'")) is "'"
    assert escape(re.match('.*', r'\"')) is '"'
    assert escape(re.match('.*', r'\\')) is '\\'
    assert escape(re.match('.*', r'\b')) is '\b'
    assert escape(re.match('.*', r"\n")) is "\n"
    assert escape(re.match('.*', r"\r")) is "\r"
    assert escape(re.match('.*', r"\f")) is "\f"
    assert escape(re.match('.*', r"\x5B")) is "["
    assert escape(re.match('.*', r"\x5b")) is "["

# Generated at 2022-06-23 15:42:19.976132
# Unit test for function escape
def test_escape():
    s = r"\x20"
    e = re.sub(r"\\(x.{0,2})", escape, s)
    assert e == " "
    assert repr(e) == repr(" ")
    assert repr(s) == repr("\\x20")
    assert e != s
    assert e == eval("\"" + s + "\"")

    s = r"\40"
    e = re.sub(r"\\(x.{0,2})", escape, s)
    assert e == " "
    assert repr(e) == repr(" ")
    assert repr(s) == repr("\\40")
    assert e != s
    assert e == eval("\"" + s + "\"")

    s = r"\040"

# Generated at 2022-06-23 15:42:23.659249
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ''
    assert evalString('"\'zxcv"') == "'zxcv"
    assert evalString('"\\b\\t\\r\\n\\f\\v\\a\\?"') == "\b\t\r\n\f\v\a\?"
    assert evalString("'\\'") == "'"
    assert evalString("'\\x22'") == '"'
    assert evalString("'\\77'") == '?'
    assert evalString("'\\u1234'") == '\u1234'

# Generated at 2022-06-23 15:42:24.253388
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:34.715964
# Unit test for function evalString
def test_evalString():
    cases = [
        (r'"\t"', "\t"),
        (r'"\n"', "\n"),
        (r'"\r"', "\r"),
        (r'""', ""),
        (r'""""', '""'),
        (r'"\\"', "\\"),
        (r'"\""', '"'),
        (r'"abc"', "abc"),
        (r'"abcdef"', "abcdef"),
        (r'"abc\ndef"', "abc\ndef"),
        (r'"\x61"', "a"),
        (r'"\x61\x62"', "ab"),
        (r'"\x61\x62\x63"', "abc"),
    ]
    for case in cases:
        input, expected = case[0], case[1]
        assert eval

# Generated at 2022-06-23 15:42:40.003203
# Unit test for function escape
def test_escape():
    from hypothesis import given
    from hypothesis.strategies import characters, text
    from string import hexdigits


# Generated at 2022-06-23 15:42:44.909283
# Unit test for function evalString
def test_evalString():
    k = evalString("'a\\r\\n'")
    expected = "a\\r\\n"
    assert k == expected
    print(f"Test Passed!")

if __name__ == "__main__":
    test_evalString()

# Generated at 2022-06-23 15:42:53.094252
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\'"') == "'"
    assert evalString(r'"\'"') == "'"
    assert evalString(r'"\r\n\t\021"') == "\r\n\t\021"
    assert evalString(r"'\r\n\t\021'") == "\r\n\t\021"
    assert evalString(r"'\\\r\n\t\021'") == "\\\r\n\t\021"
    assert evalString(r"'\t\t'") == "\t\t"
    assert evalString(r'"\t\t"') == "\t\t"
    assert evalString(r"'\t'") == "\t"
    assert evalString(r'"\t"') == "\t"

# Generated at 2022-06-23 15:43:03.838820
# Unit test for function escape
def test_escape():
    # test1: simple_escapes
    assert escape(re.match("\\a", "\\a")) == "\a"
    assert escape(re.match("\\b", "\\b")) == "\b"
    assert escape(re.match("\\f", "\\f")) == "\f"
    assert escape(re.match("\\n", "\\n")) == "\n"
    assert escape(re.match("\\r", "\\r")) == "\r"
    assert escape(re.match("\\t", "\\t")) == "\t"
    assert escape(re.match("\\v", "\\v")) == "\v"
    assert escape(re.match("\\'", "\\'")) == "'"
    assert escape(re.match('\\"', '\\"')) == '"'

# Generated at 2022-06-23 15:43:11.055376
# Unit test for function evalString
def test_evalString():
    assert evalString('"string"') == "string"
    assert evalString("'string'") == "string"
    assert evalString("'str\\'ing'") == "str'ing"
    assert evalString('"str\\"ing"') == 'str"ing'
    assert evalString('"str\\x20ing"') == "str ing"
    assert evalString('"str\\07ing"') == "str\x07ing"
    assert evalString('"str\\100ing"') == "str\x40ing"
    assert evalString('"str\\001ing"') == "str\x01ing"

# Generated at 2022-06-23 15:43:22.082873
# Unit test for function escape
def test_escape():
    assert escape(re.search('a','a')) == 'a'
    assert escape(re.search('\\\\','\\')) == '\\'
    assert escape(re.search('\\\'','\'')) == '\''
    assert escape(re.search('\\\"','"')) == '"'
    assert escape(re.search('\\r','r')) == '\r'
    assert escape(re.search('\\n','n')) == '\n'
    assert escape(re.search('\\t','t')) == '\t'
    assert escape(re.search('\\b','b')) == '\b'
    assert escape(re.search('\\f','f')) == '\x0c'
    assert escape(re.search('\\v','v')) == '\x0b'

# Generated at 2022-06-23 15:43:31.886317
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"
    assert escape("\\x5B") == "["
    assert escape("\\x5D") == "]"
    assert escape("\\064") == "@"
    assert escape("\\100") == "@"
    assert escape("\\u007b") == "{"
    assert escape("\\u007B") == "{"
    assert escape("\\u007d") == "}"
    assert escape("\\u007D") == "}"
    assert escape("\\U0001F44D") == "\U0001F44D"
    assert escape("\\U0001F44D") == "\U0001F44D"
    assert escape("\\U00110000") is None
    assert escape("\\U00110000") is None

# Generated at 2022-06-23 15:43:43.897340
# Unit test for function evalString
def test_evalString():
    # Simple tests
    assert evalString("'a'") == "a"
    assert evalString('"b"') == "b"

    # Test backslashes
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\"') == '"'
    assert evalString("'\\''") == "'"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\012'") == "\n"

    # Test that evalString doesn't blow up on invalid escapes


# Generated at 2022-06-23 15:43:50.011515
# Unit test for function escape
def test_escape():
    import sys
    if sys.version_info[0] >= 3:
        simple_escapes["U"] = False
    else:
        simple_escapes["u"] = False
    assert escape("\\x0a") == "\n"
    assert escape("\\x0A") == "\n"
    assert escape("\\u000a") == "\\u000a"
    assert escape("\\U0000000a") == "\\U0000000a"

# Generated at 2022-06-23 15:43:51.026724
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:51.476824
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:44:01.107143
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\t' ' ' '\\n'") == "\t \n"
    assert evalString("'abc'") == "abc"
    assert evalString("'abc' 'def'") == "abcdef"
    assert evalString("'\\x22'") == '"'
    assert evalString("'\\x22' '\\x22'") == '""'
    assert evalString("'\\x22' '\\x22' '\\x22'") == '"""'

    assert evalString('"\\t"') == "\t"
    assert evalString('"\\t" " " "\\n"') == "\t \n"
    assert evalString('"abc"') == "abc"

# Generated at 2022-06-23 15:44:03.683241
# Unit test for function evalString
def test_evalString():
    test_string = "\"Hello World!\""
    assert evalString(test_string) == "Hello World!"



# Generated at 2022-06-23 15:44:07.314233
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        # evalString returns a string whose contents are the single
        # byte represented by the value i.  That byte is chr(i).
        # So evalString should return chr(i).
        assert evalString(repr(chr(i))) == chr(i)

# Generated at 2022-06-23 15:44:15.840602
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"x"') == "x"
    assert evalString('"\\t"') == "\t"
    assert evalString("'a\\x41'") == "aA"
    assert evalString('"\\277"') == "\x9f"
    assert evalString('"\\07"') == "\x07"
    assert evalString('"\\0001"') == "\x01"
    assert evalString('"\\01"') == "\x01"
    assert evalString('"\\1"') == "\x01"
    assert evalString('"\\_"') == "\\_"

    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-23 15:44:17.167056
# Unit test for function evalString
def test_evalString():
    import test_support
    test_support.run_unittest(SafeEvalTestCase)



# Generated at 2022-06-23 15:44:17.577641
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:17.983557
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:18.906672
# Unit test for function test
def test_test():
    # function test is not doctested
    pass

# Generated at 2022-06-23 15:44:23.541406
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"(\\x.)", r"\xaa")) == chr(0xaa)
    assert escape(re.match(r"(\\x.)", r"\xa")) == chr(0xa)

    # This is a bug, but it's hard to fix without breaking existing code.
    # See <http://bugs.python.org/issue16033>.
    assert escape(re.match(r"(\\x.)", r"\xag")) == "g"

# Generated at 2022-06-23 15:44:26.659098
# Unit test for function escape
def test_escape():
    assert escape("\\0") == "\0"
    assert escape("\\111") == "I"
    assert escape("\\x49") == "I"
    assert escape("\\x4g") == "x4g"

# Generated at 2022-06-23 15:44:29.205308
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-23 15:44:39.268099
# Unit test for function escape
def test_escape():
    import pytest

    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"

    # the following don't work on Windows
    assert escape("\\x20") == " "
    assert escape("\\037") == "?"

    with pytest.raises(ValueError):
        escape("\\x")
    with pytest.raises(ValueError):
        escape("\\0")

# Generated at 2022-06-23 15:44:41.193614
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "\\x41")) == "A"



# Generated at 2022-06-23 15:44:41.774604
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:44:54.091030
# Unit test for function evalString

# Generated at 2022-06-23 15:44:58.611818
# Unit test for function escape
def test_escape():
    testList = [(r"\n", "\n"), (r"\x00", "\x00"), (r"\071", "1"), (r"\042", '"')]

    for test in testList:
        assert escape(re.match(r"\\(.)", test[0])) == test[1]



# Generated at 2022-06-23 15:44:59.065659
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:03.288085
# Unit test for function evalString
def test_evalString():
    assert evalString('"""abc"""') == 'abc'
    assert evalString('"""\\\\x00"""') == '\\x00'
    assert evalString('"""\\b"""') == '\b'
    assert evalString('"""\\b"""') == '\b'
    assert evalString('"""\\"""') == '\\'

# Generated at 2022-06-23 15:45:12.709236
# Unit test for function evalString
def test_evalString():
    import sys
    import math
    import random
    import unittest
    from test import test_support

    for base in 2, 8, 10, 16:
        for n in range(200):
            v = n % base
            if base == 16:
                v += random.randrange(sys.maxunicode - v)
                if random.random() < 0.2:
                    v += random.randrange(sys.maxunicode - v)
            elif base == 8:
                v += random.randrange(399) * 256
                if random.random() < 0.2:
                    v += random.randrange(399) * 256
            s = repr(v)
            e = evalString(s)
            assert e == v
            assert type(e) is int

    for code in range(256):
        s = repr

# Generated at 2022-06-23 15:45:18.488860
# Unit test for function escape
def test_escape():
    import unittest
    class TestEscape(unittest.TestCase):
        def test_simple_escapes(self):
            for esc, c in simple_escapes.items():
                self.assertEqual(escape(re.match(r'\\%s' % esc, c)), c)

        def test_hex_escapes(self):
            # Test with two hex digits
            for i in range(16):
                for j in range(16):
                    hexes = '%x%x' % (i, j)
                    match = re.match(r'\\x' + hexes, '\\x' + hexes)
                    self.assertEqual(escape(match), chr(int(hexes, 16)))

            # Test with one hex digit

# Generated at 2022-06-23 15:45:29.887623
# Unit test for function evalString
def test_evalString():
    assert evalString("'Hello world'") == "Hello world"
    assert evalString("'Hello\\nworld'") == "Hello\nworld"
    assert evalString("'Hello\\rworld'") == "Hello\rworld"
    assert evalString("'Hello\\vworld'") == "Hello\vworld"
    assert evalString("'Hello\\bworld'") == "Hello\bworld"
    assert evalString("'\\x01world'") == "\x01world"
    assert evalString("'\\x1aworld'") == "\x1aworld"
    assert evalString("'\\01world'") == "\x01world"
    assert evalString("'\\1aworld'") == "\x1aworld"
    assert evalString("'Hello\\\\world'") == "Hello\\world"

# Generated at 2022-06-23 15:45:34.060710
# Unit test for function test
def test_test():
    try:
        test()
    except NameError:
        print("NameError")
    except TypeError:
        print("TypeError")
    except ValueError:
        print("ValueError")
    except:
        print("Exception")
    else:
        print("No exception")

# Generated at 2022-06-23 15:45:37.564839
# Unit test for function evalString
def test_evalString():
    assert evalString("'\x00'") == "\x00", evalString("'\x00'")
    assert evalString("'\r'") == "\r", evalString("'\r'")
    assert evalString("'\\r'") == "\r", evalString("'\\r'")

# Generated at 2022-06-23 15:45:46.401209
# Unit test for function escape
def test_escape():
    # Successful tests
    escape(re.match(r'\\a', r'\a'))
    escape(re.match(r'\\b', r'\b'))
    escape(re.match(r'\\f', r'\f'))
    escape(re.match(r'\\n', r'\n'))
    escape(re.match(r'\\r', r'\r'))
    escape(re.match(r'\\t', r'\t'))
    escape(re.match(r'\\v', r'\v'))
    escape(re.match(r'\\\'', r"\'"))
    escape(re.match(r'\\\"', r'\"'))
    escape(re.match(r'\\\\', r'\\'))

# Generated at 2022-06-23 15:45:49.502770
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\\\'"') == "\\'"
    assert evalString(r'"\\\'"') == "\\'"
    assert evalString(r'"\\\'"') == r'"\\\'"'

# Generated at 2022-06-23 15:45:50.100336
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:52.777639
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\"hello\\""') == '"hello"'
    assert evalString("'\\'hello\\''") == "'hello'"



# Generated at 2022-06-23 15:45:54.102886
# Unit test for function test
def test_test():
    assert True

# Generated at 2022-06-23 15:46:04.158998
# Unit test for function test
def test_test():
    import io
    import sys
    import unittest
    from unittest import mock

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    class TestStringEval(unittest.TestCase):
        def setUp(self) -> None:
            self.old_stdout = sys.stdout
            sys.stdout = self.stdout = io.StringIO()

        def tearDown(self) -> None:
            sys.stdout = self.old_stdout

        def test_test(self) -> None:
            test()
            self.assertEqual(self.stdout.getvalue(), "")

    unittest.main(verbosity=2)

# Generated at 2022-06-23 15:46:05.558186
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\x07", "\\x07")) == "\a"

# Generated at 2022-06-23 15:46:17.016905
# Unit test for function evalString

# Generated at 2022-06-23 15:46:17.617273
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:28.456019
# Unit test for function escape
def test_escape():
    assert escape(re.search(r'\\x21', '\\x21')) == '!', 'escape() should return "!" given "\\x21"'
    # The following line is controversial.
    # I believe it should raise ValueError, but I'm going not to break compatibility with 2.6 here.
    # I eneded up not using this function after all.
    assert escape(re.search(r'\\x1', '\\x1')) == '\\x1', 'escape() should return "\\x1" given "\\x1"'

    assert escape(re.search(r'\\21', '\\21')) == '!', 'escape() should return "!" given "\\21"'

# Generated at 2022-06-23 15:46:39.503865
# Unit test for function test
def test_test():
    # no_type_check: test_test is a unittest itself
    import unittest as test

    class Test(test.TestCase):
        def check(self, s: str, e: str) -> None:
            r = evalString(s)
            self.assertEqual(r, e)

        def test_string_literals(self) -> None:
            self.check('"\\\'\\\"\\\\"', '\'\\\'"\\\\')
            self.check("'\\\'\\\"\\\\'", '\'\\\'"\\\\')
            self.check(r'"\""', '"\\"')

# Generated at 2022-06-23 15:46:48.020918
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == '\x08'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\n")) == '\n'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\x0a")) == '\n'

# Generated at 2022-06-23 15:46:53.514298
# Unit test for function evalString
def test_evalString():
    quoted_string = "evalString('\n')"
    # evalString() takes a string and returns a string
    assert evalString(quoted_string) == "\n"

    quoted_string = "evalString(\"\\\"\"+'\\n'+\"\\\"\")"
    # evalString() safely evaluates strings even with escapeing
    assert evalString(quoted_string) == "\"\n\""

# Generated at 2022-06-23 15:47:02.847512
# Unit test for function escape

# Generated at 2022-06-23 15:47:13.600903
# Unit test for function evalString

# Generated at 2022-06-23 15:47:14.747295
# Unit test for function evalString
def test_evalString():
    assert evalString('"asdf"') == 'asdf'

# Generated at 2022-06-23 15:47:26.553068
# Unit test for function escape
def test_escape():
    # Test for escape sequences
    assert escape(re.match(r"\\(a)", "\\a")) == "\a"
    assert escape(re.match(r"\\(b)", "\\b")) == "\b"
    assert escape(re.match(r"\\(f)", "\\f")) == "\f"
    assert escape(re.match(r"\\(n)", "\\n")) == "\n"
    assert escape(re.match(r"\\(r)", "\\r")) == "\r"
    assert escape(re.match(r"\\(t)", "\\t")) == "\t"
    assert escape(re.match(r"\\(v)", "\\v")) == "\v"
    assert escape(re.match(r"\\(\'|\")", "\\'")) == "\'"

# Generated at 2022-06-23 15:47:37.674660
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\[abfnrtv]', r'\z')) == 'z'
    assert escape(re.match(r'\\[abfnrtv]', r'\z')) != r'\z'
    assert escape(re.match(r'\\[abfnrtv]', r'\a')) == '\a'
    assert escape(re.match(r'\\[abfnrtv]', r'\b')) == '\b'
    assert escape(re.match(r'\\[abfnrtv]', r'\f')) == '\f'
    assert escape(re.match(r'\\[abfnrtv]', r'\n')) == '\n'

# Generated at 2022-06-23 15:47:44.003810
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString('"a\\"bc"') == 'a"bc'
    assert evalString("'a\\'bc'") == "a'bc"
    assert evalString("'''a\\'bc'") == "a'bc"
    assert evalString('"""a\\"bc"') == 'a"bc'

# Generated at 2022-06-23 15:47:53.258434
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", '\\a')) == "\a"
    assert escape(re.match(r"\\b", '\\b')) == "\b"
    assert escape(re.match(r"\\f", '\\f')) == "\f"
    assert escape(re.match(r"\\n", '\\n')) == "\n"
    assert escape(re.match(r"\\r", '\\r')) == "\r"
    assert escape(re.match(r"\\t", '\\t')) == "\t"
    assert escape(re.match(r"\\v", '\\v')) == "\v"
    assert escape(re.match(r"\\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', '\\"'))

# Generated at 2022-06-23 15:48:05.240735
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\\"') == '\"'
    assert escape('\\\\') == '\\'

    assert escape('\\x41') == 'A'
    assert escape('\\x5A') == 'Z'
    assert escape('\\x61') == 'a'
    assert escape('\\x7A') == 'z'
    assert escape('\\x20') == ' '

# Generated at 2022-06-23 15:48:11.277098
# Unit test for function evalString

# Generated at 2022-06-23 15:48:19.316960
# Unit test for function evalString
def test_evalString():
    from . import tokenizer
    from .pytoken import tok_name
    import io


# Generated at 2022-06-23 15:48:28.770918
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'single'") == "single"
    assert evalString('"double"') == "double"
    assert evalString("'sss\\'sss'") == "sss'sss"
    assert evalString('"ddd\\"ddd"') == 'ddd"ddd'
    assert evalString("'s\\xd7ss'") == "s\xd7ss"
    assert evalString('"d\\u1234dd"') == "d\u1234dd"
    assert evalString("'s\\0ss'") == "s\0ss"

# Generated at 2022-06-23 15:48:39.613336
# Unit test for function escape
def test_escape():
    import pytest

    for given, expected in simple_escapes.items():
        assert escape(re.match(r"\\"+given, "\\"+given)) == expected

    for digit in range(1, 8):
        assert escape(re.match(r"\\x0{:d}".format(digit), r"\x0{:d}".format(digit))) == chr(int(digit*"0", 8))
        assert escape(re.match(r"\\0{:d}".format(digit), r"\0{:d}".format(digit))) == chr(int(digit*"0", 8))

    with pytest.raises(ValueError) as exc:
        escape(re.match(r"\\x", r"\x"))

# Generated at 2022-06-23 15:48:51.223857
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x02"') == "\x02"
    assert evalString('"\\x2"') == "\\x2"
    assert evalString('"foo\\x02"') == "foo\x02"
    assert evalString('"\\x"') == "\\x"
    assert evalString("'\\x2'") == "\\x2"
    assert evalString("'\\x'") == "\\x"
    assert evalString("'\\x02'") == "\x02"
    assert evalString("'foo\\x02'") == "foo\x02"
    assert evalString("'\\x2'") == "\\x2"
    assert evalString("'\\x'") == "\\x"
    assert evalString("'\\x02'") == "\x02"

# Generated at 2022-06-23 15:48:51.973626
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:02.454568
# Unit test for function evalString
def test_evalString():
    assert evalString('''"foo"''') == "foo"
    assert evalString('''"foo\"bar"''') == "foo\"bar"
    assert evalString('''"foo\\\"bar"''') == "foo\\\"bar"
    assert evalString('''"f\\\\o\"bar"''') == "f\\\\o\"bar"
    assert evalString('''"foo\\\
    bar"''') == "foobar"
    assert evalString('''"foo\\\
bar"''') == "foo\\\x0abar"
    assert evalString('''"foo"''') == "foo"
    assert evalString('''"a n\\est\\'ed \\string"''') == "a n\\est'd \\string"

# Generated at 2022-06-23 15:49:09.370522
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'a\nb'") == "a\nb"
    assert evalString('"a\nb"') == "a\nb"
    assert evalString("'a\'b'") == "a'b"
    assert evalString('"a\"b"') == 'a"b'
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\a'") == "\x07"
    assert evalString("'\\b'") == "\x08"
    assert evalString("'\\f'") == "\x0c"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"

# Generated at 2022-06-23 15:49:20.659392
# Unit test for function evalString
def test_evalString():
    # NOTE: If new tests are added here, they should also be added to
    # test_ast.py:test_literal_eval.
    def f(s, v):
        assert evalString(s) == v, repr((s, evalString(s), v))

    # Strings
    f("''", "")
    f("'a'", "a")
    f("'abc'", "abc")
    f("'\\x'", "\\x")
    f("'\\x0'", "\\x0")
    f("'\\x00'", "\x00")
    f("'\\xff'", "\xff")
    f("'\\n'", "\n")
    f("'\\r'", "\r")
    f("'\\t'", "\t")

# Generated at 2022-06-23 15:49:21.449397
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:33.137506
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x63"') == 'c'
    assert evalString('"a\\x6cpha"') == 'alpha'
    assert evalString('"\\x63\\x00om\\x00pu\\x00te\\x00r\\x00"') == 'computer'
    assert evalString('"a\\\\b\\"\\\'c"') == 'a\\b"\'c'
    assert evalString('"a\\\\b\\"\\\'c"') != r'a\b"\'c'
    assert evalString(r'"a\\b\"\'c"') == 'a\\b"\'c'
    assert evalString(r'"a\\b\"\'c"') != r'a\b"\'c'
    assert evalString('"\\x75\\x63"') == 'uc'

# Generated at 2022-06-23 15:49:41.280567
# Unit test for function evalString

# Generated at 2022-06-23 15:49:47.427574
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'abc\\n'") == "abc\n"
    assert evalString('"abc"') == "abc"
    assert evalString('"abc\\n"') == "abc\n"
    assert evalString('"\\x61"') == "a"

# Generated at 2022-06-23 15:49:59.359864
# Unit test for function escape
def test_escape():
    import pytest
    from sys import version_info

    # Test escape function
    def test_escape_1():
        assert escape(re.match("\\1", "\\1")) == "\\1"
    def test_escape_2():
        assert escape(re.match("\\b", "\\b")) == "\b"
    def test_escape_3():
        assert escape(re.match("\\x43", "\\x43")) == "C"
    def test_escape_4():
        assert escape(re.match("\\x43", "\\x43")) == "C"
    def test_escape_5():
        assert escape(re.match("\\777", "\\777")) == "\x1f"

    # Test function escape with bad characters

# Generated at 2022-06-23 15:50:07.288997
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\''") == "'"
    assert evalString("'\\x20'") == " "
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\11'") == "\t"
    assert evalString("'\\13'") == "\r"
    assert evalString("'\\141'") == "a"
    assert evalString("'\\101'") == "A"
    assert evalString("'\\141\\142'") == "ab"
    assert evalString("'\\101\\102'") == "AB"
    assert evalString

# Generated at 2022-06-23 15:50:19.437111
# Unit test for function escape
def test_escape():
    # case 'a'
    assert escape(re.match('\\a', '\\a')) == '\a'

    # case 'b'
    assert escape(re.match('\\b', '\\b')) == '\b'

    # case 'f'
    assert escape(re.match('\\f', '\\f')) == '\f'

    # case 'n'
    assert escape(re.match('\\n', '\\n')) == '\n'

    # case 'r'
    assert escape(re.match('\\r', '\\r')) == '\r'

    # case 't'
    assert escape(re.match('\\t', '\\t')) == '\t'

    # case 'v'

# Generated at 2022-06-23 15:50:27.822281
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\a", "\\a")) == "\a"
    assert escape(re.match("\\b", "\\b")) == "\b"
    assert escape(re.match("\\f", "\\f")) == "\f"
    assert escape(re.match("\\n", "\\n")) == "\n"
    assert escape(re.match("\\r", "\\r")) == "\r"
    assert escape(re.match("\\t", "\\t")) == "\t"
    assert escape(re.match("\\v", "\\v")) == "\v"
    assert escape(re.match("\\'", "\\'")) == "'"
    assert escape(re.match('\\"', '\\"')) == '"'
    assert escape(re.match("\\\\", "\\\\")) == "\\"
    assert escape

# Generated at 2022-06-23 15:50:38.433806
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"spam"') == "spam"
    assert evalString("'eggs'") == "eggs"
    assert evalString('"s\\"p\\\'a\\\\m"') == 's"p\'a\\m'
    assert evalString('"\\001\\002\\x03"') == "\001\002\x03"
    assert evalString('""') == ""