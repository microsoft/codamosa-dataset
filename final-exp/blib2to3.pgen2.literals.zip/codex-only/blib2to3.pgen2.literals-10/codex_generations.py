

# Generated at 2022-06-23 15:40:35.955001
# Unit test for function escape
def test_escape():
    assert escape('\\x0a') == escape('\n')
    assert escape('\\07') == escape('\a')
    assert escape('\\\\') == escape('\\')
    try:
        escape('\\xyz')
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError"
    try:
        escape('\\')
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError"
    try:
        escape('\\a')
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError"

# Generated at 2022-06-23 15:40:46.983070
# Unit test for function evalString
def test_evalString():
    assert evalString('"xy"') == 'xy'
    assert evalString('"\\n"') == '\n'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\111"') == 'I'
    assert evalString('"\\x4e"') == 'N'
    assert evalString('"\\x4E"') == 'N'
    assert evalString('"\\x4e"') == 'N'
    assert evalString('"\\x4e\\n"') == 'N\n'
    assert evalString('"\\111\\012"') == 'I\n'
    assert evalString('"\\0"') == '\0'
    assert evalString('"\\7"') == '\7'

# Generated at 2022-06-23 15:40:54.402613
# Unit test for function escape
def test_escape():
    import pytest
    with pytest.raises(ValueError):
        assert escape(r"\x")
    with pytest.raises(ValueError):
        assert escape(r"\x0")
    with pytest.raises(ValueError):
        assert escape(r"\x0a")
    with pytest.raises(ValueError):
        assert escape(r"\x1")
    with pytest.raises(ValueError):
        assert escape(r"\x1a")
    with pytest.raises(ValueError):
        assert escape(r"\x00")
    with pytest.raises(ValueError):
        assert escape(r"\xff")
    assert escape(r"\x0a") == "\n"
    assert escape(r"\x00") == "\x00"
   

# Generated at 2022-06-23 15:40:55.725143
# Unit test for function test
def test_test():
    # Tests the module
    assert test() == None

# Generated at 2022-06-23 15:41:04.167292
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-23 15:41:12.696039
# Unit test for function escape
def test_escape():
    # Simple escapes
    assert escape(re.match(r"\\([abfnrtv\\\'\"]|\\)", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv\\\'\"]|\\)", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv\\\'\"]|\\)", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv\\\'\"]|\\)", r"\n")) == "\n"
    assert escape(re.match(r"\\([abfnrtv\\\'\"]|\\)", r"\r")) == "\r"

# Generated at 2022-06-23 15:41:17.714580
# Unit test for function escape
def test_escape():
    for x in range(256):
        if chr(x) == '"':
            continue
        assert escape(re.search(fr'\\{x:02x}', "")).encode('latin-1') == bytes([x])


# Generated at 2022-06-23 15:41:29.083520
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\""') == "\""
    assert evalString(r'"\\"') == "\\"
    assert evalString(r'"\a"') == "\a"
    assert evalString(r'"\b"') == "\b"
    assert evalString(r'"\f"') == "\f"
    assert evalString(r'"\n"') == "\n"
    assert evalString(r'"\r"') == "\r"
    assert evalString(r'"\t"') == "\t"
    assert evalString(r'"\v"') == "\v"
    assert evalString(r'"\x00"') == "\x00"
    assert evalString(r'"\x7f"') == "\x7f"
    assert evalString(r'"\x80"') == "\x80"
   

# Generated at 2022-06-23 15:41:29.538818
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:30.021328
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:31.908095
# Unit test for function test
def test_test():
    """This is the docstring of test_test"""
    test()

# Generated at 2022-06-23 15:41:32.626037
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:44.637419
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\xaf")) == "\xaf"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\x1f")) == "\x1f"

# Generated at 2022-06-23 15:41:51.066862
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        if s.startswith("\\"):
            m = re.match(r"\\(['\"\\abfnrtv]|x(?:[0-9a-f]{1,2})|[0-7]{1,3})", s)
            assert m, s
            e = escape(m)
            assert e == c, (s, e)

# Generated at 2022-06-23 15:41:55.026468
# Unit test for function escape
def test_escape():
    from py.test import raises
    from typing import Tuple

    def t(expected: Text, input: Text) -> None:
        assert escape(re.search("(.*)", input)) == expected

    def xt(expected: Text, input: Text) -> None:
        try:
            escape(re.search("(.*)", input))
        except ValueError as e:
            assert str(e) == expected

    t("\a", r"\a")
    t("\b", r"\b")
    t("\f", r"\f")
    t("\n", r"\n")
    t("\r", r"\r")
    t("\t", r"\t")
    t("\v", r"\v")
    t("'", r"\'")

# Generated at 2022-06-23 15:42:01.129893
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\xaa") == "ª"
    assert escape("\\xFF") == "ÿ"
    assert escape("\\777") == "?"



# Generated at 2022-06-23 15:42:10.398298
# Unit test for function escape
def test_escape():
    import ast
    def _test(test_string, result):
        assert ast.literal_eval(test_string) == result
    _test(r"'\n'", "\n")
    _test(r'"\n"', "\n")
    _test(r"'\\n'", "\\n")
    _test(r'"\\n"', "\\n")
    _test(r"'\\\n'", "\\\n")
    _test(r'"\\\n"', "\\\n")
    _test(r"'\\\\n'", "\\\\n")
    _test(r'"\\\\n"', "\\\\n")


# Generated at 2022-06-23 15:42:11.481564
# Unit test for function test
def test_test():
    test()


del test

# Generated at 2022-06-23 15:42:20.242191
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\%s' % 'a', '\\a')) == '\a'
    assert escape(re.match(r'\\%s' % 'b', '\\b')) == '\b'
    assert escape(re.match(r'\\%s' % 'f', '\\f')) == '\f'
    assert escape(re.match(r'\\%s' % 'n', '\\n')) == '\n'
    assert escape(re.match(r'\\%s' % 'r', '\\r')) == '\r'
    assert escape(re.match(r'\\%s' % 't', '\\t')) == '\t'

# Generated at 2022-06-23 15:42:20.927223
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:32.806358
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == 'a'
    assert evalString("'\\x61'") == 'a'
    assert evalString('"\\t"') == '\t'
    assert evalString("'\\t'") == '\t'
    assert evalString('"\\r"') == '\r'
    assert evalString("'\\r'") == '\r'
    assert evalString('"\\n"') == '\n'
    assert evalString("'\\n'") == '\n'
    assert evalString('"\\f"') == '\f'
    assert evalString("'\\f'") == '\f'
    assert evalString('"\\b"') == '\b'
    assert evalString("'\\b'") == '\b'

# Generated at 2022-06-23 15:42:41.700638
# Unit test for function evalString
def test_evalString():
    s = evalString('"""string"""')
    assert s == 'string'
    s = evalString('"""string with "quotes"""')
    assert s == 'string with "quotes"'
    s = evalString('"string\nwith\nnewlines"')
    assert s == "string\nwith\nnewlines"
    s = evalString('"string\\nwith\\nnewlines"')
    assert s == "string\\nwith\\nnewlines"
    s = evalString('"string\\\\nwith\\\\nnewlines"')
    assert s == "string\\\\nwith\\\\nnewlines"
    s = evalString('"string\\000with\\000nulls"')
    assert s == "string\000with\000nulls"
    s = evalString("'string\000with\000nulls'")
    assert s

# Generated at 2022-06-23 15:42:48.409133
# Unit test for function test
def test_test():
    real_set = set()
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            real_set.add(c)
    for i in range(256):
        c = chr(i)
        if c in real_set:
            continue
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-23 15:42:49.473625
# Unit test for function test
def test_test():
    test()
    # Test passes if function doesn't crash

# Generated at 2022-06-23 15:42:58.676548
# Unit test for function escape
def test_escape():
    import pytest
    m = re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", '\\a')
    assert escape(m) == "\a"
    m = re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", '\\b')
    assert escape(m) == "\b"
    m = re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", '\\f')
    assert escape(m) == "\f"

# Generated at 2022-06-23 15:43:00.995713
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        import traceback

        traceback.print_exc()
        raise e

# Generated at 2022-06-23 15:43:01.563552
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:43:11.401103
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"

    assert escape("\\x61") == "a"
    assert escape("\\x0a") == "\n"

    assert escape("\\01") == "\x01"
    assert escape("\\012") == "\x0a"
    assert escape("\\123") == "\x5b"

    # Invalid escape sequences

# Generated at 2022-06-23 15:43:22.259592
# Unit test for function escape
def test_escape():
    test_case = [
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\x61", "a"),
        ("\\x0a", "\n"),
        ("\\x5C", "\\"),
        ("\\012", "\n"),
        ("\\140", "@"),
    ]
    for test in test_case:
        assert escape(test[0]) == test[1]
    with pytest.raises(ValueError) as excinfo:
        escape("\\01")

# Generated at 2022-06-23 15:43:23.292265
# Unit test for function test
def test_test():
    assert test() is None



# Generated at 2022-06-23 15:43:27.980861
# Unit test for function escape
def test_escape():
    # Test \\x7F and \\177
    assert escape(re.match(r"\\x7F", "\\x7F")) == "\x7f"
    assert escape(re.match(r"\\17", "\\177")) == "\x7f"

    # Test \\a, \\b, \\f, \\n, \\r, \\t, \\v
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"

# Generated at 2022-06-23 15:43:29.550109
# Unit test for function evalString
def test_evalString():
    assert evalString("'Please stop hacking me'") == "Please stop hacking me"

# Generated at 2022-06-23 15:43:36.872339
# Unit test for function evalString
def test_evalString():
    assert evalString("'''abc'''") == "abc"
    assert evalString("'abc'") == "abc"
    # XXX evalString("''") == "";  # FIXME: Why is empty string raised
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\''") == "'"
    assert evalString('\'\\"\'') == '"'
    assert evalString("'\\\\'") == "\\"


# Generated at 2022-06-23 15:43:47.725254
# Unit test for function evalString
def test_evalString():
    evalString(r'\x00')
    evalString(r'\077')
    evalString(r'\400')
    evalString(r"\u0005")
    evalString(r"\U00000000")
    evalString(r'\U00100000')
    evalString(r"'\x00'")
    evalString(r"'\077'")
    evalString(r"'\400'")
    evalString(r"'\u0005'")
    evalString(r"'\U00000000'")
    evalString(r"'\U00100000'")
    evalString(r'"\x00"')
    evalString(r'"\077"')
    evalString(r'"\400"')
    evalString(r'"\u0005"')

# Generated at 2022-06-23 15:43:48.700487
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:58.941549
# Unit test for function evalString

# Generated at 2022-06-23 15:44:06.953004
# Unit test for function evalString
def test_evalString():
    # Simple test cases
    assert evalString(r'""') == ""
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\'") == "'"
    assert evalString(r"''''") == "''"
    assert evalString(r'"\"\"\""') == '"""', repr(evalString(r'"\"\"\""'))
    assert evalString(r"'\'\'\'\'") == "'''", repr(evalString(r"'\'\'\'\'"))
    assert evalString(r"'\a\b\f\n\r\t\v\'\"\\'") == "\a\b\f\n\r\t\v'\"\\"

# Generated at 2022-06-23 15:44:08.173596
# Unit test for function test
def test_test():
    try:
        test()
    except:
        print('Error in evalString')

# Generated at 2022-06-23 15:44:14.498009
# Unit test for function escape
def test_escape():
    m = re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x32")
    assert m.group(1) == "x32"
    assert escape(m) == "2"

    m = re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")
    assert m.group(1) == "b"
    assert escape(m) == "\b"


# Generated at 2022-06-23 15:44:17.102435
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-23 15:44:18.049859
# Unit test for function escape
def test_escape():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:44:23.853003
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', '\\a')) == '\a'
    assert escape(re.match('\\b', '\\b')) == '\b'
    assert escape(re.match('\\f', '\\f')) == '\f'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'
    assert escape(re.match('\\v', '\\v')) == '\v'
    assert escape(re.match('\\\'', '\\\'')) == '\''
    assert escape(re.match('\\\"', '\\\"')) == '"'

# Generated at 2022-06-23 15:44:29.258047
# Unit test for function escape
def test_escape():
    import pytest
    s = "'\\x5c'"
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", s[2:-1])
    assert m, "re.match error"
    esc = escape(m)
    assert esc == '\\'


# Generated at 2022-06-23 15:44:39.299416
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == 'a'
    assert evalString("'\\n'") == '\n'
    assert evalString("'\\\\'") == '\\'
    assert evalString("'\\\\n'") == '\\n'
    assert evalString("'\\n\\\\'") == '\\n\\'
    assert evalString("'\\\\n\\n'") == '\\n\\n'
    assert evalString('"a"') == 'a'
    assert evalString('"\\n"') == '\n'
    assert evalString('"\\\\"') == '\\'
    assert evalString('"\\\\n"') == '\\n'
    assert evalString('"\\n\\\\"') == '\\n\\'
    assert evalString('"\\\\n\\n"') == '\\n\\n'
    assert eval

# Generated at 2022-06-23 15:44:47.593777
# Unit test for function escape
def test_escape():
    assert escape(('\\xF0', 'xF0')) == 'ð'
    assert escape(('\\xF0', 'F0')) == 'ð'
    assert escape(('\\x0F', 'x0F')) == '\x0f'
    assert escape(('\\x00', 'x00')) == '\x00'
    assert escape(('\\x20', 'x20')) == ' '
    assert escape(('\\x7F', 'x7F')) == '\x7f'
    assert escape(('\\xFF', 'xFF')) == 'ÿ'

    assert escape(('\\0', '0')) == '\x00'
    assert escape(('\\1', '1')) == '\x01'

# Generated at 2022-06-23 15:44:55.685095
# Unit test for function escape
def test_escape():
    assert escape(Match(object(), r'\b')) == '\b'
    assert escape(Match(object(), r'\n')) == '\n'
    assert escape(Match(object(), r'\\')) == '\\'
    assert escape(Match(object(), r'\x0B')) == '\u000b'
    assert escape(Match(object(), r'\u1234')) == '\u1234'
    assert escape(Match(object(), r'\uFFFF')) == '\uffff'


# Generated at 2022-06-23 15:44:57.635870
# Unit test for function test
def test_test():
    import io
    import sys
    from contextlib import redirect_stdout

    f = io.StringIO()
    with redirect_stdout(f):
        test()
    assert f.getvalue() == ""

# Generated at 2022-06-23 15:45:00.219831
# Unit test for function test
def test_test():
    test()
    print("Unit test of function test :\n")
    print("-> Done\n")

# Generated at 2022-06-23 15:45:09.001625
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(a)", r"\a")) == "\a"
    assert escape(re.match(r"\\(b)", r"\b")) == "\b"
    assert escape(re.match(r"\\(f)", r"\f")) == "\f"
    assert escape(re.match(r"\\(n)", r"\n")) == "\n"
    assert escape(re.match(r"\\(r)", r"\r")) == "\r"
    assert escape(re.match(r"\\(t)", r"\t")) == "\t"
    assert escape(re.match(r"\\(v)", r"\v")) == "\v"
    assert escape(re.match(r"\\(')", r"\'")) == "'"

# Generated at 2022-06-23 15:45:18.509409
# Unit test for function escape
def test_escape():
    def test(s, expected):
        m = re.match(r"\\(.+)", s)
        assert m
        result = escape(m)
        assert result == expected

    test(r"\a", "\a")
    test(r"\b", "\b")
    test(r"\f", "\f")
    test(r"\n", "\n")
    test(r"\r", "\r")
    test(r"\t", "\t")
    test(r"\v", "\v")
    test(r"\'", "\'")
    test(r'\"', '\"')
    test(r"\\", "\\")
    test(r"\x01", "\x01")
    test(r"\x12", "\x12")

# Generated at 2022-06-23 15:45:22.727829
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == 'a'
    assert evalString("'\\n'") == '\n'
    assert evalString("'\\x61'") == 'a'
    assert evalString("'\\071'") == 'A'

# Generated at 2022-06-23 15:45:32.860709
# Unit test for function escape
def test_escape():
    assert escape(r"\a") == "\a"
    assert escape(r"\b") == "\b"
    assert escape(r"\f") == "\f"
    assert escape(r"\n") == "\n"
    assert escape(r"\r") == "\r"
    assert escape(r"\t") == "\t"
    assert escape(r"\v") == "\v"
    assert escape(r"\'") == "'"
    assert escape(r'\"') == '"'
    assert escape(r"\\") == "\\"

    assert escape(r"\x7f") == chr(127)
    assert escape(r"\x80") == chr(128)

    assert escape(r"\777") == chr(511)

# Generated at 2022-06-23 15:45:42.772615
# Unit test for function escape

# Generated at 2022-06-23 15:45:54.726401
# Unit test for function escape
def test_escape():
    import pytest
    from .test_lib import capture_stdout

    err = None
    try:
        escape(re.match('a', 'a'))
    except ValueError as ex:
        err = ex
    assert err is None

    with capture_stdout() as out:
        try:
            escape(re.match('a', 'b'))
        except ValueError as ex:
            err = ex
        assert err is not None
        print(err)

    assert escape(re.match('a', '\\a')) == "\a"
    assert escape(re.match('a', '\\b')) == "\b"
    assert escape(re.match('a', '\\f')) == "\f"
    assert escape(re.match('a', '\\n')) == "\n"

# Generated at 2022-06-23 15:45:59.736165
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\001\\002\\x03'") == "\x01\x02\x03"
    assert evalString('"\\001\\002\\x03"') == "\x01\x02\x03"


"""
Decode bytes objects in Python 2 and 3
"""

import sys



# Generated at 2022-06-23 15:46:08.353869
# Unit test for function evalString
def test_evalString():
    # Simple string
    assert evalString('"hello"') == 'hello'
    assert evalString("'hello'") == 'hello'

    # Single quotes with double quotes in string
    assert evalString('"hel\\"lo"') == 'hel"lo'

    # Double quotes with single quotes in string
    assert evalString("'hel\\'lo'") == "hel'lo"

    # Multiline string
    assert evalString('"""hello\nworld"""') == "hello\nworld"

    # Multiline string with whitespace on both ends of first and last line
    assert evalString('"""hello\nworld"""') == "hello\nworld"

    # Multiline string with empty lines on both ends

# Generated at 2022-06-23 15:46:08.998607
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:19.222593
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString('"a\"bc\""') == "a\"bc\""
    assert evalString("'abc'") == "abc"
    assert evalString("'a\\'bc'") == "a'bc"
    assert evalString("'a\\\"bc'") == 'a"bc'
    assert evalString("'a\\\\bc'") == "a\\bc"
    assert evalString("'\\ab\\n\\r\\t\\b\\f\\v\\\\'") == "\ab\n\r\t\b\f\v\\"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
   

# Generated at 2022-06-23 15:46:23.383779
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\"', '\\"')) == '"'
    assert escape(re.match("\\'", "\\'")) == "'"
    assert escape(re.match("\\x41", "\\x41")) == "A"

# Generated at 2022-06-23 15:46:32.367060
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(x.{0,2})", r"\x0a")) == "\n"
    assert escape(re.match(r"\\(x.{0,2})", r"\x20")) == " "
    assert escape(re.match(r"\\(x.{0,2})", r"\xFF")) == "ÿ"
    assert escape(re.match(r"\\x(.{0,2})", r"\x20")) == " "
    assert escape(re.match(r"\\(x.{0,2})", r"\x0g")) == ""
    assert escape(re.match(r"\\(x.{0,2})", r"\xgg")) == ""


# Generated at 2022-06-23 15:46:41.755137
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString("'''abc'''") == "abc"
    assert evalString("\"\"\"abc\"\"\"") == "abc"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\x21'") == "!"
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\x0f'") == "\x0f"
    assert evalString("'\\x7f'") == "\x7f"
    assert evalString("'\\xae'") == "\xae"
    assert evalString("'\\xFF'") == "\xFF"
    assert evalString("'\\u0021'") == "!"
    assert eval

# Generated at 2022-06-23 15:46:43.140426
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:44.964658
# Unit test for function test
def test_test():
    try:
        test()
    except ValueError as e:
        print(e.args)

# Generated at 2022-06-23 15:46:50.221095
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"b"') == "b"
    assert evalString('"a\\nb\\rc"') == "a\nb\rc"
    assert evalString("'a\\nb\\rc'") == "a\nb\rc"
    assert evalString('"a\\"b"') == 'a"b'
    assert evalString('"a\'b"') == "a'b"
    assert evalString(r'"a\"b"') == r'a\"b'
    assert evalString(r'"a\'b"') == r"a\'b"
    assert evalString(r'"a\"b"') == r'a\"b'
    assert evalString(r'"a\'b"') == r"a\'b"

# Generated at 2022-06-23 15:47:00.454302
# Unit test for function escape

# Generated at 2022-06-23 15:47:11.641793
# Unit test for function escape
def test_escape():
    assert evalString("'abc'") == 'abc'
    assert evalString("'abc\\ndef'") == 'abc\ndef'
    assert evalString("'\\n'") == '\n'
    assert evalString('"\\n"') == '\n'
    assert evalString('"\\\'\\"\\\\"') == "'\"\\"
    assert evalString("r'\\n'") == "\\n"
    assert evalString("'\\''") == "'"
    assert evalString("'\"'") == '"'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"

# Generated at 2022-06-23 15:47:14.232376
# Unit test for function test
def test_test():
    try:
        test()
    except:
        print("*** test requires stringold module ***")
    else:
        print("    test passed")

# Generated at 2022-06-23 15:47:25.974728
# Unit test for function escape
def test_escape():
    # Acceptance tests from the original evalstring.py
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\'")).encode('utf-8') == b"'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\\")).encode('utf-8') == b"\\"

# Generated at 2022-06-23 15:47:37.205549
# Unit test for function evalString
def test_evalString():
    # Test simple literals
    assert evalString('""') == ""
    assert evalString('"test"') == "test"
    assert evalString('"test\\ntest"') == "test\ntest"
    assert evalString('"test\\xff"') == "test\xff"
    assert evalString("'test'") == "test"
    assert evalString("'''test'''") == "test"

    # Test escapes
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\"') == "\a\b\f\n\r\t\v\'\"\\"
    assert evalString('"\\x00\\xff"') == "\x00\xff"
    assert evalString('"\\000\\377"') == "\000\377"

# Generated at 2022-06-23 15:47:46.381624
# Unit test for function escape
def test_escape():
    # Use eval to check that escape really is the inverse of eval.

    for c in "abfnrtv":
        assert escape(re.search(r"\\" + c, "")) == eval("\\" + c)

    assert escape(re.search("\\'", "")) == "'"
    assert escape(re.search("\\\"", "")) == '"'
    assert escape(re.search("\\\\", "")) == "\\"

    for i in range(8):
        for j in range(8):
            for k in range(8):
                s = "\\%o%o%o" % (i, j, k)
                assert escape(re.search(s, "")) == s

    assert escape(re.search("\\123", "")) == "\\123"
    assert escape(re.search("\\12", ""))

# Generated at 2022-06-23 15:47:54.754296
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString("''") == ""
    assert evalString('"0"') == "0"
    assert evalString("'0'") == "0"
    assert evalString('"0"') == "0"
    assert evalString("'0'") == "0"
    assert evalString('"abcd"') == "abcd"
    assert evalString("'abcd'") == "abcd"
    assert evalString('"\\\'\'"') == "'"
    assert evalString('"\\"\\"\\""') == '"""'
    assert evalString("'\\'\\'\\''") == "'''"
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\a"') == "\a"

# Generated at 2022-06-23 15:47:55.492643
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:01.515827
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x1a"') == '\x1a'
    assert evalString('"\\n"') == '\n'
    assert evalString('"\\\\"') == '\\'
    assert evalString('"\\\'"') == '\''
    assert evalString('"\\\f"') == '\f'
    assert evalString('"\\\r"') == '\r'

# Generated at 2022-06-23 15:48:12.451107
# Unit test for function escape
def test_escape():
    def assertEval(string, result, msg=None):
        assert evalString(string) == result

    # Verify that escape() inserts a Unicode character rather than
    # a byte, so that the resulting string is Unicode all the way
    string = '\\N{LATIN SMALL LETTER A WITH GRAVE}'
    assertEval(string, '\u00e0')
    string = '"' + string + '"'
    assertEval(string, '\u00e0')

    # 2-3 octal digits only
    assertEval(r"'\0'", '\0')
    assertEval(r"'\00'", '\0')
    assertEval(r"'\000'", '\0')
    assertEval(r"'\077'", '?')

# Generated at 2022-06-23 15:48:16.486792
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\n"') == "\n"
    a = "hello"
    assert evalString(repr(a)) == a

# Generated at 2022-06-23 15:48:25.220655
# Unit test for function escape
def test_escape():
    # Simple escapes
    for e in simple_escapes:
        assert escape(re.match(r"\\" + e, '\\' + e)) == simple_escapes[e]
    # Unicode escapes
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"
    assert escape(re.match(r"\\x1a", r"\x1a")) == "\x1a"
    # Verify that ValueError is raised for a bad escape
    with pytest.raises(ValueError):
        escape(re.match(r"\\z", r"\z"))

# Generated at 2022-06-23 15:48:33.684381
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == "foo", "Simple string"
    assert evalString("'foo'") == "foo", "Simple string"
    assert evalString('"\x00\x00\x00"') == "\x00\x00\x00", "Null string"
    assert evalString('"\xfe\xff"') == "\xfe\xff", "fffe"
    assert evalString('"\377\376\375"') == "\377\376\375", "High byte"
    assert evalString('"\001\002\003"') == "\001\002\003", "Other high bytes"
    assert evalString('"\\b\\a\\t\\v\\f\\r\\n\\\"\\\'\\\\"') == "\b\a\t\v\f\r\n\"\'\\", "Escapes"

# Generated at 2022-06-23 15:48:42.113354
# Unit test for function evalString

# Generated at 2022-06-23 15:48:52.676859
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'

# Generated at 2022-06-23 15:49:03.148515
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'")=='abc'
    assert evalString('"abc"')=='abc'
    assert evalString("'abc\\n'")=='abc\n'
    assert evalString("'abc\\x61\\x62\\x63'")=='abcabc'
    assert evalString("'abc\\r'")=='abc\r'
    assert evalString("'\\b\\f\\n\\r\\t'")=='\b\f\n\r\t'
    assert evalString("'\\x2e'")=='.'
    assert evalString("'\\x2E'")=='.'
    assert evalString("'\\n\\r\\t\\\\'")=='\n\r\t\\'

# Generated at 2022-06-23 15:49:04.411893
# Unit test for function evalString
def test_evalString():
    e = evalString('"foo"')
    assert e == "foo"

# Generated at 2022-06-23 15:49:06.674390
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x12", "\\x1")) == "x1"

# Generated at 2022-06-23 15:49:13.241329
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == 'abc'
    assert evalString("'abc\\ndef'") == 'abc\ndef'
    assert evalString("'abc\\n\\\\def'") == 'abc\n\\def'
    assert evalString("'abc\\ndef\\tghi'") == 'abc\ndef\tghi'
    assert evalString("'abc\\x20def'") == 'abc def'
    assert evalString("'abc\\0def'") == 'abc\x00def'
    assert evalString("'abc\\077def'") == 'abc?def'
    assert evalString("'abc\\117def'") == 'abcUdef'
    assert evalString("'abc\\u00e7def'") == 'abcçdef'

# Generated at 2022-06-23 15:49:16.566089
# Unit test for function test
def test_test():
    try:
        test()
        assert False, "Expected exception"
    # pylint: disable=broad-except
    except ValueError as e:
        print(e)
        assert "invalid" in e.args[0]

# Generated at 2022-06-23 15:49:17.537317
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-23 15:49:29.190720
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString("'\\\\n'") == '\\n'
    assert evalString('"\\n"') == '\n'
    assert evalString("'\\\\x41'") == '\x41'
    assert evalString('"\\x41"') == '\x41'
    assert evalString("'\\\\x41abc'") == '\x41abc'
    assert evalString('"\\x41abc"') == '\x41abc'
    assert evalString("'\\\\x41ABC'") == '\x41ABC'
    assert evalString('"\\x41ABC"') == '\x41ABC'
    assert evalString("'\\\\x4110'") == '\x4110'
    assert eval

# Generated at 2022-06-23 15:49:30.231538
# Unit test for function evalString
def test_evalString():
    assert evalString('\r') == '\r'

# Generated at 2022-06-23 15:49:40.125425
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == "hello"
    assert evalString("'hello'") == "hello"
    assert evalString('"a"') == "a"
    assert evalString("'a'") == "a"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\t\\n\\r"') == "\t\n\r"
    assert evalString('"\\u1234"') == "\u1234"
    assert evalString('"\\U00001234"') == "\U00001234"
    assert evalString('"\\N{GREEK SMALL LETTER ALPHA}a"') == "αa"
    assert evalString('"\\"\\\\\\""') == '"\\"'
    assert evalString('"\\\\a"') == "\\a"
    assert eval

# Generated at 2022-06-23 15:49:41.007839
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:52.099303
# Unit test for function escape
def test_escape():
    rx = re.compile(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})")
    assert rx.sub(escape, r"""\'\"\\\a\b\f\n\r\t\v\073\x53""") == "'\"\\\a\b\f\n\r\t\v;S"

# Generated at 2022-06-23 15:49:52.687715
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:50:03.224353
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\x80") == "€"
    assert escape("\u2019") == "’"
    assert escape("\\u2019") == "’"

    # Use a raw string literal to test escape sequences.
    assert r"\U00010000" == "\U00010000"



# Generated at 2022-06-23 15:50:08.315386
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        if c in "abfnrtvx": continue  # No test (not escaped char)
        s = repr(c)
        e = escape(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-23 15:50:10.915312
# Unit test for function test
def test_test():
    """
    Here we test the function test in the file literaleval.py
    """
    assert test() is None

# Generated at 2022-06-23 15:50:12.237894
# Unit test for function test
def test_test():
    assert 1 == 1
    test()

# Generated at 2022-06-23 15:50:13.300810
# Unit test for function test
def test_test():
    assert test() is None


# Generated at 2022-06-23 15:50:23.850865
# Unit test for function evalString

# Generated at 2022-06-23 15:50:32.476784
# Unit test for function escape
def test_escape():
    # All simple escapes should match
    for k in simple_escapes:
        m = re.match(r'\\' + k, '\\' + k)
        assert (m is not None), 'test for \\' + k + ' failed'

        assert (m.group(0) == '\\' + k), 'test for \\' + k + ' failed'

        assert (m.group(1) == k), 'test for \\' + k + ' failed'

