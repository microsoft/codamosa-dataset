

# Generated at 2022-06-23 15:40:38.204088
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\""') == '"'
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\"') == "\a\b\f\n\r\t\v\'\"\\"

# Generated at 2022-06-23 15:40:48.687070
# Unit test for function evalString
def test_evalString():
    assert evalString("'bob'") == "bob"
    assert evalString('"bob"') == "bob"
    assert evalString("'bob'") == "bob"
    assert evalString("'\\''") == "'"
    assert evalString("'\\\"'") == '"'
    assert evalString('"\\\'"') == "'"
    assert evalString('"\\\""') == '"'
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61\\x62'") == "ab"
    assert evalString("'a\\x61'") == "aa"
    assert evalString("'a\\\\x61'") == "a\\x61"

# Generated at 2022-06-23 15:40:49.199386
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:40:52.477479
# Unit test for function test
def test_test():
    import sys
    from io import StringIO
    from contextlib import redirect_stdout
    import re

    capturedOutput = StringIO()
    sys.stdout = capturedOutput
    test()
    sys.stdout = sys.__stdout__
    outputStr = capturedOutput.getvalue()
    assert re.match(r'^$', outputStr) is not None


# Generated at 2022-06-23 15:41:01.585253
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\xA2", "\\xA2")) == "\xa2"
    assert escape(re.match(r"\\xA2", "\\xA2" * 2)) == "\xa2" * 2
    assert escape(re.match(r"\\xA2", "\\" + "x" * 15)) == "\\" + "x" * 14
    with pytest.raises(ValueError) as e:
        assert escape(re.match(r"\\xA2", "\\" + "x" * 2))
    assert e.match('invalid hex string escape')



# Generated at 2022-06-23 15:41:02.266106
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:02.920711
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:11.696724
# Unit test for function evalString
def test_evalString():
    input = ["'abc'", '"abc"', "'\\n'", '"\\n"', "'\\xff'", '"\\xff"']
    output = ["abc", "abc", "\n", "\n", "\xff", "\xff"]
    for i, o in zip(input, output):
        assert evalString(i) == o

    input = ["'abc'", '"abc"', "'\\n'", '"\\n"', "'\\xff'", '"\\xff"']
    # output = ["abc", "abc", "\n", "\n", "\xff", "\xff"]
    for i, o in zip(input, output):
        assert evalString(i) == o

# Generated at 2022-06-23 15:41:15.195675
# Unit test for function escape
def test_escape():
    testinput = "\\x"
    out = escape(re.match(r"\\x", testinput))

    assert out == "\\x"



# Generated at 2022-06-23 15:41:19.476008
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        s = repr(c)[1:-1]
        assert escape(re.match(r'\\[abfnrtv\\x0-7]', s)) == c

# Generated at 2022-06-23 15:41:23.803147
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'\n'") == "\n"
    assert evalString(r"'\x61'") == "a"
    assert evalString(r"'\u1234'") == "\u1234"


# unit test for function escape

# Generated at 2022-06-23 15:41:32.681318
# Unit test for function evalString
def test_evalString():
    assert evalString('"spam"') == "spam"
    assert evalString("'spam'") == "spam"
    assert evalString("'a\\t\\n\\r\\'\"\\\\b'") == "a\t\n\r\'\"\\b"
    assert evalString("'a\\x62'") == "ab"
    assert evalString("'\\61\\62'") == "ab"
    assert evalString("'\\x61\\x62'") == "ab"
    assert evalString("'\\061\\062'") == "ab"
    assert evalString("'''abc'''") == "abc"
    assert evalString('"""abc"""') == "abc"
    assert evalString("'abc' + 'def'") == "abcdef"

# Generated at 2022-06-23 15:41:33.416407
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:34.154857
# Unit test for function escape
def test_escape():
    escape('\\')


# Generated at 2022-06-23 15:41:34.876282
# Unit test for function test
def test_test():
    assert True



# Generated at 2022-06-23 15:41:39.829008
# Unit test for function evalString
def test_evalString():
    assert evalString('"hel\'lo"') == "hel'lo"
    assert evalString("'''hel\"lo'") == "hel\"lo"
    assert evalString("'hel\"lo'") == "hel\"lo"
    assert evalString("\"hel\"\"lo\"") == "hel\"lo"
    assert evalString("'hel\\'lo'") == "hel'lo"
    assert evalString("\"hel\\\"lo\"") == "hel\"lo"
    assert evalString("'hel\\x20lo'") == "hel lo"
    assert evalString("\"hel\\021lo\"") == "hel\tlo"
    assert evalString("\"hel\\0lo\"") == "hel\x00lo"
    assert evalString("'hel\\llo'") == "hello"

# Generated at 2022-06-23 15:41:41.028535
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:51.731061
# Unit test for function escape
def test_escape():
    # Taken from the Python 3.2.2 std lib.
    assert escape(re.match(r'\\([abfnrtv\'"]|\d+|x.|N{.*?}|u[a-fA-F\d]{4}|U[a-fA-F\d]{8})', '\\b')) == '\b'
    assert escape(re.match(r'\\([abfnrtv\'"]|\d+|x.|N{.*?}|u[a-fA-F\d]{4}|U[a-fA-F\d]{8})', '\\n')) == '\n'

# Generated at 2022-06-23 15:41:59.925973
# Unit test for function evalString
def test_evalString():
    test_string = '"Neurons are the basic structural and functional elements of the nervous system, the organ of the mind that allows us to perceive and react to the outside world. Neurons are organized into pathways and networks that process information and generate behavior. Over the course of evolution, these pathways and networks have become increasingly sophisticated, resulting in the emergence of increasingly complex animal species. In this section, we will reveal how neurons are organized within the nervous system to achieve such complexity."'

# Generated at 2022-06-23 15:42:02.744940
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        pytest.fail("test raises Exception")

# Generated at 2022-06-23 15:42:03.370608
# Unit test for function test
def test_test():

    assert test() == None

# Generated at 2022-06-23 15:42:13.975873
# Unit test for function evalString
def test_evalString():

    # Positive test cases
    assert evalString("'a'") == 'a'
    assert evalString("'ab'") == 'ab'
    assert evalString('"a"') == 'a'
    assert evalString('"ab"') == 'ab'
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\\''") == "'"
    assert evalString

# Generated at 2022-06-23 15:42:16.699065
# Unit test for function test
def test_test():
    _saved_globals = globals().copy()
    try:
        test()
    finally:
        globals().clear()
        globals().update(_saved_globals)

# Generated at 2022-06-23 15:42:24.217218
# Unit test for function evalString
def test_evalString():
    import test.support
    

# Generated at 2022-06-23 15:42:33.197948
# Unit test for function evalString
def test_evalString():
    assert evalString('''"\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\"''') == "\a\b\f\n\r\t\v\'\"\\"
    assert evalString('''"'\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\'"''') == \
            "'\a\b\f\n\r\t\v\\'\"\\'"
    for i in range(256):
        c = chr(i)
        s = repr(c)
        try:
            e = evalString(s)
        except ValueError:
            pass
        else:
            assert e == c

# Generated at 2022-06-23 15:42:39.687295
# Unit test for function evalString
def test_evalString():
    print(evalString('"\'"'))
    print(evalString("'\\''"))
    print(evalString('"\\"\'"'))
    print(evalString('"\\x41"'))
    print(evalString("'\\x41'"))
    print(evalString('"\\x41\\x42"'))
    print(evalString("'\\x41\\x42'"))
    print(evalString('"\\x0f"'))
    print(evalString("'\\x0f'"))

# Generated at 2022-06-23 15:42:50.854016
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv]|0.{0,2}|[0-7]{1,3})", "abcd")) == "a" # noqa E501
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv]|0.{0,2}|[0-7]{1,3})", "\\r")) == "\r" # noqa E501
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv]|0.{0,2}|[0-7]{1,3})", "\\'\'")) == "'" # noqa E501

# Generated at 2022-06-23 15:43:03.196834
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x(.{2,2})", r"\xFF")) == chr(0xFF)
    assert escape(re.match(r"\\x(.{2,2})", r"\x00")) == chr(0x00)

    assert escape(re.match(r"\\x(.{2,2})", r"\xff")) == chr(0xFF)
    assert escape(re.match(r"\\x(.{2,2})", r"\x00")) == chr(0x00)

    assert escape(re.match(r"\\x(.{2,2})", r"\x10")) == chr(0x10)

# Generated at 2022-06-23 15:43:12.212099
# Unit test for function escape
def test_escape():
    assert escape('\\"') == '"'
    assert escape('\\\'') == '\''
    assert escape('\\\\') == '\\'
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\x61') == 'a'
    assert escape('\\377') == '\xff'
    assert escape('\\0') == '\x00'
    assert escape('\\01') == '\x01'
    assert escape('\\012') == '\n'

# Generated at 2022-06-23 15:43:22.700351
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc\\x2d"') == "abc-", "evalString: escape characters"
    assert evalString('"abc\\x2a"') == 'abc*', "evalString: escape characters"
    assert evalString('"abc\\xb0"') == "abc°", "evalString: escape characters"
    assert evalString('"abc\\t"') == "abc\t", "evalString: escape characters"
    assert evalString('"abc"'), "evalString: simple string"
    assert evalString('"a\\b"') == "a\b", "evalString: escape characters"
    assert evalString('"a\\f"') == "a\f", "evalString: escape characters"
    assert evalString('"a\\n"') == "a\n", "evalString: escape characters"

# Generated at 2022-06-23 15:43:23.294321
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:33.485867
# Unit test for function escape
def test_escape():
    test_inputs = (
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\\\", "\\"),
        ("\\x01", "\x01"),
        ("\\x0A", "\n"),
        ("\\x1A", "\x1A"),
        ("\\x9F", "\x9F"),
        ("\\xFF", "\xFF"),
        ("\\001", "\x01"),
        ("\\010", "\x08"),
        ("\\100", "\x40"),
        ("\\177", "\x7F"),
    )



# Generated at 2022-06-23 15:43:45.566648
# Unit test for function escape
def test_escape():
    escp = "\a\b\f\n\r\t\v'\"\\"
    esc = ''.join([f"\\{c:s}" for c in escp])

    for i in range(256):
        assert escape(re.match(r"\\("+chr(i)+")", esc)) == chr(i)

    assert escape(re.match(r"\\("+esc+")", esc)) == escp

    assert escape(re.match(r"\\x0a", esc)) == "\n"
    assert escape(re.match(r"\\x0A", esc)) == "\n"
    assert escape(re.match(r"\\xaf", esc)) == "\xaf"
    assert escape(re.match(r"\\xAF", esc)) == "\xaf"


# Generated at 2022-06-23 15:43:48.993696
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-23 15:43:49.665012
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:51.428655
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\n"') == "\n"

# Generated at 2022-06-23 15:44:00.232242
# Unit test for function escape
def test_escape():
    match = re.match(r"\\(x.{0,2}|[0-7]{1,3})", r"\x41")
    assert match is not None
    assert escape(match) == "A"

    match = re.match(r"\\(x.{0,2}|[0-7]{1,3})", r"\041")
    assert match is not None
    assert escape(match) == "!"

    match = re.match(r"\\(x.{0,2}|[0-7]{1,3})", r"\061")
    assert match is not None
    assert escape(match) == "1"



# Generated at 2022-06-23 15:44:03.780073
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError as e:
        raise AssertionError(str(e)) from e

# Generated at 2022-06-23 15:44:04.253546
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:13.161114
# Unit test for function escape
def test_escape():
    tst = [
        ('\\a', '\a'), ('\\b', '\b'), ('\\f', '\f'), ('\\n', '\n'), ('\\r', '\r'),
        ('\\t', '\t'), ('\\v', '\v'), ('\\\'', '\''), ('\\"', '"'),
        ('\\\\', '\\'), ('\\x41', 'A'), ('\\x4A', 'J'), ('\\x4z', '\\x4z'),
        ('\\x4', '\\x4'), ('\\1', '\1')
    ]

    for i, j in tst:
        result = escape(re.match(r'\\.|$', i))
        assert result == j



# Generated at 2022-06-23 15:44:22.228433
# Unit test for function escape
def test_escape():
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\xFF") == chr(255)
    assert escape("\\377") == chr(255)
    assert escape("\\77") == chr(63)
    assert escape("\\7") == chr(7)
    assert escape("\\x7") == chr(7)


# Generated at 2022-06-23 15:44:27.794588
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\n"') == '\n'
    assert evalString('"\\x65"') == 'e'

# Generated at 2022-06-23 15:44:38.182807
# Unit test for function escape
def test_escape():
    from unittest import TestCase, main

    class EscapeTest(TestCase):
        def test_simple(self):
            simple_escapes = {'a': '\a', 'b': '\b', 'f': '\f', 'n': '\n', 'r': '\r',
                              't': '\t', 'v': '\v', '"': '"', "'": "'", "\\": "\\"}
            for esc, val in simple_escapes.items():
                m = re.search(r'\\%s' % esc, "\\%s" % esc)
                self.assertEqual(escape(m), val)
                m = re.search(r'\\%s' % esc, "\\%sA" % esc)
                self.assertEqual(escape(m), val)
               

# Generated at 2022-06-23 15:44:41.936410
# Unit test for function escape
def test_escape():
    assert escape(re.Match[Text, Text](
                  "\\x32",
                  "x32")
                  ) == "\x32"
    assert escape(re.Match[Text, Text](
                  "\\073",
                  "073")
                  ) == ";"

# Generated at 2022-06-23 15:44:42.731183
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:44:55.210682
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", "'\\'")) == "'"
    assert escape(re.match(r'\\"', '"\\"')) == '"'
    assert escape(re.match(r"\\\\", '"\\\\"')) == "\\"
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"

# Generated at 2022-06-23 15:45:05.701458
# Unit test for function escape

# Generated at 2022-06-23 15:45:12.281991
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ''
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\xfe"') == "\xfe"
    assert evalString('"\\377"') == "\xff"
    assert evalString('"\\"x"') == '"x'
    assert evalString("'\\'x'") == "'x"
    assert evalString('"x\\x"') == "x\\x"
    assert evalString('"\\x"') == "\\x"
    assert evalString('"\\"' + '"') == '"'
    assert evalString('"""') == ""
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\xfe"') == "\xfe"
    assert evalString('"\\377"') == "\xff"

# Generated at 2022-06-23 15:45:12.723851
# Unit test for function test
def test_test():
    _ = test()

# Generated at 2022-06-23 15:45:13.154005
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:26.191894
# Unit test for function escape
def test_escape():
    # invalid escapes
    try:
        escape(re.match(r"\\[abfnrtv]", r"\#"))
    except ValueError:
        pass
    else:
        raise AssertionError
    try:
        escape(re.match(r"\\[abfnrtv]", r"\\"))
    except ValueError:
        pass
    else:
        raise AssertionError
    try:
        escape(re.match(r"\\[abfnrtv]", r"\x"))
    except ValueError:
        pass
    else:
        raise AssertionError
    try:
        escape(re.match(r"\\[abfnrtv]", r"\x1"))
    except ValueError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-23 15:45:35.042058
# Unit test for function evalString
def test_evalString():
    print("Testing evalString()...", end=" ")

    def t(s, v):
        try:
            assert evalString(s) == v
        except:
            print("\nFailed evalString(%s), should be %s" % (repr(s), repr(v)))
            raise

    t("'abc'", "abc")
    t("'\\\\'", "\\")
    t("'\\'", "'")
    t("'\\\"'", '"')
    t("'a'", "a")
    t("'\\a'", "\a")
    t("'\\n'", "\n")
    t('"abc"', "abc")
    t('"\\\\"', "\\")
    t('"\\"', '"')
    t('"\\\'"', "'")
    t

# Generated at 2022-06-23 15:45:44.816256
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\n"') == '\n', evalString('"\\n"')
    assert evalString('"\\xFF"') == '\xff', evalString('"\\xFF"')
    assert evalString('"\\77"') == '?', evalString('"\\77"')
    assert evalString('"\\077"') == '?', evalString('"\\077"')
    assert evalString('"\\007"') == '\x07', evalString('"\\007"')
    assert evalString('"\\0"') == '\x00', evalString('"\\0"')
    assert evalString('"\\1"') == '\x01', evalString('"\\1"')
    assert evalString('"\\11"') == '\t', evalString('"\\11"')

# Generated at 2022-06-23 15:45:45.684297
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:48.298383
# Unit test for function escape
def test_escape():
    assert escape('"\\"') == '"', 'test_escape #1 failed'
    assert escape("'\\''") == "'", 'test_escape #2 failed'

# Generated at 2022-06-23 15:45:51.253888
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-23 15:45:51.870567
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:52.484576
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:04.233639
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'abc\\ndef'") == "abc\ndef"
    assert evalString("'\\t\\u1234\\U00012345\\xab'") == "\t\u1234\U00012345\xab"
    assert evalString("'\\''") == "'"
    assert evalString("'\"'") == '"'
    assert evalString("'\\\\'") == "\\"
    assert evalString("'abc'") == "abc"
    assert evalString("'abc\\ndef'") == "abc\ndef"
    assert evalString("'\\t\\u1234\\U00012345\\xab'") == "\t\u1234\U00012345\xab"
    assert evalString("'\\''") == "'"


# Generated at 2022-06-23 15:46:15.607082
# Unit test for function escape
def test_escape():
    import unittest

    from black_mamba.ast_tools.ast_string_eval import escape

    def escape_black_box(m: Match[Text]) -> Text:
        all, tail = m.group(0, 1)
        assert all.startswith("\\")
        return escape(m)

    class TestEscape(unittest.TestCase):
        def test_escape(self):
            self.assertEqual("\a", escape_black_box("\a"))
            self.assertEqual("\b", escape_black_box("\b"))
            self.assertEqual("\f", escape_black_box("\f"))
            self.assertEqual("\n", escape_black_box("\n"))
            self.assertEqual("\r", escape_black_box("\r"))
           

# Generated at 2022-06-23 15:46:26.895955
# Unit test for function escape
def test_escape():

    # Test cases based on valid Python escape sequences
    _test_escape("", "\\")
    _test_escape("a", "\\a")
    _test_escape("b", "\\b")
    _test_escape("f", "\\f")
    _test_escape("n", "\\n")
    _test_escape("r", "\\r")
    _test_escape("t", "\\t")
    _test_escape("v", "\\v")

    # Single-character escape sequences
    _test_escape("'", "\\'")
    _test_escape('"', '\\"')
    _test_escape("\\", "\\\\")

    # Hexadecimal escape sequences
    _test_escape("0", "\\x00")
    _test_escape("1", "\\x01")
    _test

# Generated at 2022-06-23 15:46:37.715032
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape('\\\\') == '\\'
    assert escape('\\x61') == 'a'
    assert escape('\\x41') == 'A'
    assert escape('\\107') == 'g'
    assert escape('\\x7f') == '\x7f'
    assert escape('\\177') == '\x7f'


# Generated at 2022-06-23 15:46:45.968199
# Unit test for function evalString
def test_evalString():
    assert evalString(r'\'') == r"'"
    assert evalString(r'"') == r'"'
    assert evalString(r"'abc'") == r"abc"
    assert evalString(r'"abc"') == r"abc"
    assert evalString(r"'\''") == r"'"
    assert evalString(r'"\""') == r'"'

# Generated at 2022-06-23 15:46:48.868283
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-23 15:46:51.924700
# Unit test for function escape
def test_escape():
    assert escape('\\n') == "\n"
    assert escape('\\x80') == '\x80'
    assert escape('\\142') == 'B'
    assert escape('\\142\\x80') == 'B\x80'

# Generated at 2022-06-23 15:47:01.862062
# Unit test for function evalString
def test_evalString():
    def check(s1: str) -> int:
        s2 = evalString(s1)
        if isinstance(s1, str):
            assert isinstance(s2, str)
        else:
            assert isinstance(s2, bytes)
        assert s2 == eval(s1)
        return 0

    check("b'abc'")
    check("'abc'")
    check("b'abc\\x61'")
    check("'abc\\x61'")
    check("b'abc\\x61\\n'")
    check("'abc\\x61\\n'")
    check("b'abc\\x61\\n\\n'")
    check("'abc\\x61\\n\\n'")
    check("b'abc\\x61\\n\\n\\n'")

# Generated at 2022-06-23 15:47:13.345873
# Unit test for function test
def test_test():
    with mock.patch("builtins.print") as mock_print:
        test()

# Generated at 2022-06-23 15:47:14.189463
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:47:25.925398
# Unit test for function evalString
def test_evalString():
    assert evalString('"\x00"') == "\x00"
    assert evalString("'\\007'") == "\x07"
    assert evalString("'\\0'") == "\x00"
    assert evalString("'\\07'") == "\x07"
    assert evalString("'\\077'") == "?"
    assert evalString("'\\777'") == "?"
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\xFF'") == "\xFF"
    assert evalString("'\\xffff'") == "\xFF\xFF"
    assert evalString("'\\u1234'") == "\u1234"
    assert evalString("'\\U00010111'") == "\U00010111"
    assert evalString("'\\uFFFF'")

# Generated at 2022-06-23 15:47:28.095415
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\'\n'") == "'\n"
    assert evalString("'\\'\n\\'\n'") == "'\n'\n"
    assert evalString("'''\n'\n'''") == "'\n"

# Generated at 2022-06-23 15:47:29.805212
# Unit test for function evalString

# Generated at 2022-06-23 15:47:39.206096
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61\\x62"') == 'ab'
    assert evalString('"\\x62\\x61"') == 'ba'
    assert evalString('"\\x63\\x64"') == 'cd'
    assert evalString('"\\x64\\x63"') == 'dc'
    assert evalString('"\\x65\\x66"') == 'ef'
    assert evalString('"\\x66\\x65"') == 'fe'
    assert evalString('"\\x67\\x68"') == 'gh'
    assert evalString('"\\x68\\x67"') == 'hg'
    assert evalString('"\\x69\\x6a"') == 'ij'
    assert evalString('"\\x6a\\x69"') == 'ji'

# Generated at 2022-06-23 15:47:39.901127
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:40.542766
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:51.014887
# Unit test for function evalString
def test_evalString():

    s = evalString("'Hello'")
    assert(s == "Hello")

    s = evalString('"Hello"')
    assert(s == "Hello")

    s = evalString("'Hello\\nWorld'")
    assert(s == "Hello\nWorld")

    s = evalString("'Hello\\\'World'")
    assert(s == "Hello\'World")

    s = evalString("'Hello\\\"World'")
    assert(s == "Hello\"World")

    s = evalString("r'Hello\\nWorld'")
    assert(s == "Hello\\nWorld")

    s = evalString("r'Hello\\rWorld'")
    assert(s == "Hello\\rWorld")

    s = evalString("r'Hello\\\'World'")
    assert(s == "Hello\\\'World")

    s

# Generated at 2022-06-23 15:47:52.698680
# Unit test for function test
def test_test():
    """Unit test function for the test function"""
    test()


# Generated at 2022-06-23 15:48:04.825599
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\x77"') == "w"
    assert evalString('"\\111"') == "I"
    assert evalString('"\\0"') == "\0"
    assert evalString('"\\x0A"') == "\n"
    assert evalString('"w\\x77 w\\x77"') == "wwww"
    assert evalString('"\\x77" + "w"') == "www"
    assert evalString('u"foo"') == "foo"
    assert evalString('u"\\ufeff"') == "\ufeff"
    assert evalString('r"foo"') == "foo"
    assert eval

# Generated at 2022-06-23 15:48:05.424498
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:06.012067
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:06.589244
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:48:14.237559
# Unit test for function escape
def test_escape():
    # This test case was created because the unescape function would
    # return an incomplete string with the following input.
    # The fix was to change the regular expression in the escape function
    # to [0-7]{1,3} rather than [0-7]{1,2}
    assert escape(re.match(r"\[0-7]{1,2}", b'\\777')) == chr(777)

# Local Variables:
# tab-width:4
# indent-tabs-mode:nil
# End:
# vim: set expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-23 15:48:14.771359
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:48:15.680472
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"

# Generated at 2022-06-23 15:48:25.086658
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x(..)", "\\xab")) == "\\xab"
    assert escape(re.match(r"\\(.)", "\\a")) == "\\a"
    assert escape(re.match(r"\\(.)", "\\n")) == "\\n"
    assert escape(re.match(r"\\(.)", "\\xA")) == "\\xA"
    assert escape(re.match(r"\\(.)", "\\xF")) == "\\xF"
    assert escape(re.match(r"\\(.)", "\\xG")) == "\\xG"

# Generated at 2022-06-23 15:48:28.979059
# Unit test for function escape
def test_escape():
    esc = re.sub(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", escape, "test")
    assert esc == "test"

# Generated at 2022-06-23 15:48:30.798768
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        assert False, "Got exception {}".format(e)

# Generated at 2022-06-23 15:48:39.678741
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a"))
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b"))
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f"))
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n"))
    assert escape

# Generated at 2022-06-23 15:48:46.480031
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\.", "\\n")) == "\n"
    assert escape(re.match(r"\\.", "\\xFF")) == "\u00FF"
    assert escape(re.match(r"\\.", "\\377")) == "\u00FF"
    assert escape(re.match(r"\\.", "\\0")) == "\0"

# Generated at 2022-06-23 15:48:58.480205
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString("'abc\\ndef\\r\\nghi'") == "abc\ndef\r\nghi"
    assert evalString("'\\u1234'") == "\u1234"
    assert evalString("'\\U00012345'") == "\U00012345"
    assert evalString("'Mëssîµ'") == "Mëssîµ"
    assert evalString("'aaaaaaaaaaaaa\\'bbbbbbbbbbbbbb'") == "aaaaaaaaaaaaa'bbbbbbbbbbbbbb"
    assert evalString("'abc\\n\\ndef'") == "abc\n\ndef"
    assert evalString("'a\\\\tb\\nc'")

# Generated at 2022-06-23 15:49:08.213051
# Unit test for function evalString

# Generated at 2022-06-23 15:49:19.232058
# Unit test for function evalString
def test_evalString():

    from pgen2 import tokenize

    # Generate test cases by running a tokenizer on each of the test files.
    try:
        from test.test_tokenize import tokenize_cases
    except ImportError:
        # Python 3.3+
        from test.tokenize_tests import tokenize_cases

    cases = []
    for file in tokenize_cases:
        stream = tokenize.tokenize(open(file, "rb").readline)
        try:
            while True:
                token_type, token, _, _, _ = next(stream)
                if token_type == tokenize.STRING:
                    cases.append(token)
        except tokenize.TokenError:
            continue
        except StopIteration:
            pass

    for case in cases:
        assert evalString(case) == eval(case)

# Generated at 2022-06-23 15:49:19.913297
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:49:31.547457
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString('"\\r\\n"') == "\r\n"
    assert evalString('"\\r\\n"') == "\r\n"
    assert evalString('"\\r\\n"') == "\r\n"
    assert evalString('"\\r\\n"') == "\r\n"
    assert evalString('"\\x61\\b"') == "a\b"
    assert evalString('"\\055\\061\\062\\063"') == "-+123"
    assert evalString('"\\r\\n"') == "\r\n"
    assert evalString('"\\r\\n"') == "\r\n"

# Generated at 2022-06-23 15:49:40.929476
# Unit test for function escape
def test_escape():
    # Test cases
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"

# Generated at 2022-06-23 15:49:52.060532
# Unit test for function escape
def test_escape():
    # pylint: disable=undefined-variable
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r"\\", r"\\")) == "\\"
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\012", r"\012")) == "\n"
    assert escape(re.match(r"\\x12", r"\x12")) == "\x12"
    assert escape(re.match(r"\\xff", r"\xff")) == "\xff"
    assert escape(re.match(r"\\u12ab", r"\u12ab")) == "\u12ab"

# Generated at 2022-06-23 15:50:02.714136
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("Chapman") == "Chapman"
    assert evalString("\\x00") == "\0"
    assert evalString("\\x01") == "\x01"
    assert evalString("\\x09") == "\t"
    assert evalString("\\x0a") == "\n"
    assert evalString("\\xFF") == "\u00FF"
    assert evalString("\\U00000001") == "\u0001"

# Generated at 2022-06-23 15:50:05.031123
# Unit test for function test
def test_test():
    print('test_test')
    test()
    print('pass')

# Generated at 2022-06-23 15:50:06.981592
# Unit test for function test
def test_test():
    try:
        test()
    except ValueError:
        raise ValueError("test failed") from None

# Generated at 2022-06-23 15:50:07.677309
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:50:09.315721
# Unit test for function test
def test_test():
    import unittest
    unittest.main()

# Generated at 2022-06-23 15:50:21.950443
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"a", "a")) == "a"
    assert escape(re.match(r"\0", "\\0")) == "\0"
    assert escape(re.match(r"\12", "\\12")) == "\n"
    assert escape(re.match(r"\1", "\\1")) == "\x01"
    assert escape(re.match(r"\x1", "\\x1")) == "\x01"
    assert escape(re.match(r"\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\x123", "\\x123")) == "\x12"
    assert escape(re.match(r"\x0g", "\\x0g")) == "x0g"

# Generated at 2022-06-23 15:50:23.634335
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-23 15:50:34.920027
# Unit test for function evalString
def test_evalString():
    s = "abcd"
    assert evalString(s) == "abcd"

    s = ''''\\\\'\\"\\"a'\\"\\'a'\"'''
    assert evalString(s) == '\\"a"\'a"'

    s = '''r"\\\\"\\'\\'a\\'\\"a'\"''''"\\a\\b\\c"'''
    assert evalString(s) == '\\"a\'a"\\a\\b\\c'

    s = '''"\\x00\\00\\000\\0000\\00000"'''
    assert evalString(s) == "\x00\x00\x00\x00\x00\x00\x00"