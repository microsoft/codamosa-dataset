

# Generated at 2022-06-23 15:40:36.246964
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == chr(0)
    assert escape(re.match(r"\\xFF", "\\xFF")) == chr(0xFF)
    assert escape(re.match(r"\\000", "\\000")) == chr(0)
    assert escape(re.match(r"\\377", "\\377")) == chr(0xFF)

# Generated at 2022-06-23 15:40:37.405110
# Unit test for function test
def test_test():
    test()
    assert 1

# Generated at 2022-06-23 15:40:38.202836
# Unit test for function test
def test_test():
    try:
        test()
    except:
        pass

# Generated at 2022-06-23 15:40:38.905900
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:39.405524
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:44.125789
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello'") == "hello"
    assert evalString('"hello"') == "hello"
    assert evalString("'he\\x00llo'") == "he\x00llo"
    assert evalString('"he\\x00llo"') == "he\x00llo"
    assert evalString("'he\\101llo'") == "hello"
    assert evalString('"he\\101llo"') == "hello"
    assert evalString("'he\\0101llo'") == "hello"
    assert evalString('"he\\0101llo"') == "hello"

# Generated at 2022-06-23 15:40:45.203143
# Unit test for function test
def test_test():
    test()
    assert 0

# Generated at 2022-06-23 15:40:46.666984
# Unit test for function escape
def test_escape():
    assert "a" == escape(re.match('\\a', '\\a'))

# Generated at 2022-06-23 15:40:47.253055
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:47.802253
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:48.986128
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:50.133291
# Unit test for function escape
def test_escape():
    print(escape(re.match(r"\\(.)", "\\")))

# Generated at 2022-06-23 15:40:50.922223
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:51.743887
# Unit test for function test
def test_test():
    # should print nothing
    test()

# Generated at 2022-06-23 15:40:54.177995
# Unit test for function test
def test_test():
    assert test() == None



# Generated at 2022-06-23 15:41:03.369992
# Unit test for function evalString
def test_evalString():
    from StringIO import StringIO
    from pgen2 import parser
    from pgen2.token import Token
    from pgen2.pgen import PgenParser
    from pprint import pprint
    import pprint
    import sys
    import unittest

    class TestEvalString(unittest.TestCase):
        def setUp(self):
            pgen = PgenParser()
            pgen.create_grammar()
            self.parser = parser.Parser(pgen.grammar, "expr_stmt")
            self.maxDiff = None

        def parse(self, text):
            return self.parser.parse(
                StringIO(text), "<test>", debug=getattr(sys, "tracebacklimit", 0)
            )


# Generated at 2022-06-23 15:41:12.645205
# Unit test for function evalString
def test_evalString():
    assert evalString(r'""') == ''
    assert evalString(r'"foo"') == 'foo'
    assert evalString(r'"foo\rabar\n"') == 'foo\rabar\n'
    assert evalString(r'"foo\r\nbar\n"') == 'foo\r\nbar\n'
    assert evalString(r'"\\"') == '\\'
    assert evalString(r'"\'"') == "'"
    assert evalString(r'"\a\b\f\n\r\t\v"') == "\a\b\f\n\r\t\v"
    assert evalString(r'"\001\010\014\n\r\t\v"') == "\x01\x08\x0c\n\r\t\x0b"
    assert eval

# Generated at 2022-06-23 15:41:25.607930
# Unit test for function evalString

# Generated at 2022-06-23 15:41:34.272028
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\x07"
    assert escape("\\b") == "\x08"
    assert escape("\\f") == "\x0c"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\x0b"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\x07") == "\x07"
    assert escape("\\x7f") == "\x7f"
    assert escape("\\377") == "\xff"
    assert escape("\\x") == "\\x"


# Generated at 2022-06-23 15:41:34.748361
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:39.844650
# Unit test for function escape
def test_escape():
    import io

    try:
        escape(io.StringIO("\\xRR"))
    except ValueError:
        return

    raise AssertionError("unexpectedly escaped invalid hex escape")

# Generated at 2022-06-23 15:41:44.113305
# Unit test for function test
def test_test():
    import contextlib
    import io
    import sys

    with contextlib.redirect_stdout(io.StringIO()) as output:
        test()
    output = output.getvalue()
    assert output == ""


# Generated at 2022-06-23 15:41:54.631062
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\[']", "\\'")) == "'"
    assert escape(re.match(r"\\[\"]", '\\"')) == '"'
    assert escape(re.match(r"\\[\\]", "\\\\")) == "\\"
    assert escape(re.match(r"\\[\\]", "\\\\")) == "\\"
    assert escape(re.match(r"\\[a]", "\\a")) == "\a"
    assert escape(re.match(r"\\[b]", "\\b")) == "\b"
    assert escape(re.match(r"\\[f]", "\\f")) == "\f"
    assert escape(re.match(r"\\[n]", "\\n")) == "\n"

# Generated at 2022-06-23 15:41:57.961288
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("' '") == " "
    assert evalString("'x y'") == "x y"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\''") == "'"
    assert evalString("'\\x7f'") == chr(127)

# Generated at 2022-06-23 15:42:10.353844
# Unit test for function evalString
def test_evalString():
    print(evalString("''"))
    print(evalString("'\\''"))
    print(evalString("'a space'"))
    print(evalString("'\\nTab\\t'"))
    print(evalString("'\\nTab\\t\\n'"))
    print(evalString("'\\b\\t\\n'"))
    print(evalString("'\\x20'"))
    print(evalString("'\\n'"))
    print(evalString("'\\n\\n'"))
    print(evalString("'\\n\\n\\t\\t\\t\\n\\n\\n\\t\\t\\t'"))
    print(evalString("'\\t\\t\\t\\n\\n\\n\\t\\t\\t\\n'"))

# Generated at 2022-06-23 15:42:12.926225
# Unit test for function escape
def test_escape():
    test_string = r'\n\t\r'
    result = escape(r'\n')
    assert result == '\n'

# Generated at 2022-06-23 15:42:20.984277
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r'"\a"') == "\a"
    assert evalString(r'"\b"') == "\b"
    assert evalString(r'"\f"') == "\f"
    assert evalString(r'"\n"') == "\n"
    assert evalString(r'"\r"') == "\r"
    assert evalString(r'"\t"') == "\t"
    assert evalString(r'"\v"') == "\v"
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r'"\\"') == "\\"
    assert evalString(r'"\041"') == "!"
   

# Generated at 2022-06-23 15:42:23.247914
# Unit test for function test
def test_test():
    test()
    return 0


# Generated at 2022-06-23 15:42:23.947826
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:34.234088
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == "foo"
    assert evalString('"foo"') == "foo"
    assert evalString('"foo" ') == "foo"
    assert evalString('"foo"\n ') == "foo"
    assert evalString("r'foo'") == "foo"
    assert evalString('r"foo"') == "foo"
    assert evalString("'\\'foo\\''") == "'foo'"
    assert evalString('"\\"foo\\""') == '"foo"'
    assert evalString("'\\'foo\' , bar'") == "'foo' , bar"
    assert evalString('"\\"foo\\" , bar"') == '"foo" , bar'
    assert evalString("r'''\\'foo\' , bar'''") == "\\'foo\' , bar"
   

# Generated at 2022-06-23 15:42:42.622685
# Unit test for function evalString

# Generated at 2022-06-23 15:42:43.532309
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:52.380614
# Unit test for function evalString
def test_evalString():
    s = evalString("'abc'")
    assert s == "abc"
    s = evalString('"abc"')
    assert s == "abc"
    s = evalString('"a\\\nb\\\nc"')
    assert s == "a\\\nb\\\nc"
    s = evalString('"a\\\nb\\\nc"')
    assert s == "a\\\nb\\\nc"
    s = evalString("'\\x61\\x62\\x63'")
    assert s == "abc"
    s = evalString("'\\061\\062\\063'")
    assert s == "abc"
    s = evalString("'\\061\\062\\063'")
    assert s == "abc"
    s = evalString("'\\61\\62\\63'")

# Generated at 2022-06-23 15:43:03.552897
# Unit test for function evalString
def test_evalString():
    s = evalString("'asd'")
    assert s == "asd"
    s = evalString("'\\n'")
    assert s == "\n"
    s = evalString("'\\123'")
    assert s == "\x7b"
    s = evalString("'\\x7a'")
    assert s == "z"
    s = evalString("'\\x7a'")
    assert s == "z"
    s = evalString("'\u1234'")
    assert s == "\ue234"
    s = evalString("'\U00012345'")
    assert s == "\U00012345"

    try:
        evalString("'''error")
    except ValueError:
        pass

# Generated at 2022-06-23 15:43:12.444673
# Unit test for function evalString
def test_evalString():
    assert evalString('"Hello World!"') == "Hello World!"

# Generated at 2022-06-23 15:43:22.797955
# Unit test for function evalString
def test_evalString():
    # Test basic cases
    assert evalString('""') == ""
    assert evalString('"foo"') == "foo"
    assert evalString("'foo'") == "foo"
    assert evalString('"\\a\\b\\n\\r\\t\\v\\f\\0\\1\\18\\\\"') == "\a\b\n\r\t\v\f\0\1\x08\\"
    assert evalString("'\\a\\b\\n\\r\\t\\v\\f\\\\'") == "\a\b\n\r\t\v\f\\"
    assert evalString('"\\"\\""') == '""'
    assert evalString("'\\'\\''") == "''"
    assert evalString('"\\"\\\'\\""') == '"\'"'

# Generated at 2022-06-23 15:43:33.118330
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("'foo'") == "foo"
    assert evalString("'foo\\nbar'") == "foo\nbar"
    assert evalString("'foo\\xFFbar'") == "foo\xFFbar"
    assert evalString("'foo\\177bar'") == "foo\177bar"
    assert evalString("'foo\\77bar'") == "foo?bar"

# Generated at 2022-06-23 15:43:38.246305
# Unit test for function escape
def test_escape():
    result = re.sub(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", escape, "\\x55")
    assert result == "U"

# Generated at 2022-06-23 15:43:48.340583
# Unit test for function escape
def test_escape():
    tester = {
        "\\'": "'",
        "\\x55": "U",
        "\\000": "\x00",
        "\\007": "\x07",
        "\\079": "9",
        "\\0c": "\f",
        "\\12": "\x12",
        "\\x1f": "\\x1f",
        "\\x1": "\x01",
        "\\n": "\n",
        "\\r": "\r",
        "\\t": "\t",
        "\\\n": "\\\n",
        "\\''": "'",
        "\\\"": '"',
        "\\\\": "\\",
    }

# Generated at 2022-06-23 15:43:49.140711
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:56.916971
# Unit test for function evalString
def test_evalString():

    test_cases = [
        ("'abc'", 'abc'),
        ('"abc"', 'abc'),
        ('"a\\\\c"', 'a\\c'),
        ('"a\\"c"', 'a"c'),
        ('"a\\\'c"', "a'c"),
        ('"a\\x61c"', 'aac'),
        ('"a\\141c"', 'aac'),
        ('"a\\051c"', 'a!c'),
        ('"a\\n\\x61c"', 'a\naac'),
        ('"a\\x61\\n\\x61c"', 'aa\naac'),
    ]

    for test_case in test_cases:
        assert evalString(test_case[0]) == test_case[1]

# Generated at 2022-06-23 15:43:57.249314
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:44:04.180285
# Unit test for function escape
def test_escape():
    cases = [
        (r"\a", "\a"),
        (r"\b", "\b"),
        (r"\f", "\f"),
        (r"\n", "\n"),
        (r"\r", "\r"),
        (r"\t", "\t"),
        (r"\v", "\v"),
        (r"\'", "'"),
        (r'\"', '"'),
        (r"\\", "\\"),
        (r"\x00", "\x00"),
        (r"\xff", "\xff"),
    ]
    for case in cases:
        assert escape(re.match(r"\\", case[0])) == case[1]

# Generated at 2022-06-23 15:44:04.763701
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:12.816685
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\a')) == "\a"
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\b')) == "\b"
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\f')) == "\f"
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\n')) == "\n"

# Generated at 2022-06-23 15:44:16.552139
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x(?![0-9a-fA-F]{0,2})", "\\x")) == "x"
    assert escape(re.match(r"\\[0-8]{4}", "\\0")) == "\x00"

# Generated at 2022-06-23 15:44:18.496628
# Unit test for function test
def test_test():
    import io
    import contextlib
    f = io.StringIO()
    with contextlib.redirect_stdout(f):
        test()
    s = f.getvalue()
    assert not s


# Generated at 2022-06-23 15:44:23.579606
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")).encode() == b"'"
    assert escape(re.match(r'\\"', r'\"')).encode() == b'"'
    assert escape(re.match(r"\\a", r"\a")).encode() == b"\x07"
    assert escape(re.match(r"\\b", r"\b")).encode() == b"\x08"
    assert escape(re.match(r"\\f", r"\f")).encode() == b"\x0c"
    assert escape(re.match(r"\\n", r"\n")).encode() == b"\n"

# Generated at 2022-06-23 15:44:33.709177
# Unit test for function evalString
def test_evalString():
    assert evalString("""'foo\nbar'""") == """foo\nbar"""
    assert evalString("""'a\\t\\\\b'""") == """a\t\\b"""
    assert evalString("""'\\x61\\045'""") == """a%"""
    assert evalString("""'\\41\\x62'""") == """Ab"""
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\07'") == "\0"
    assert evalString("'\\077'") == "?"
    assert evalString("'\\077\\101'") == "?A"
    assert evalString("'\\077\\101\\077'") == "?A?"
    assert evalString("'\\077\\101\\077\\101'") == "?A?A"


# Generated at 2022-06-23 15:44:34.534605
# Unit test for function test
def test_test():
    test()
    print("Test of test function successful")

# Generated at 2022-06-23 15:44:37.359437
# Unit test for function escape
def test_escape():
    str = "\\x61\\x62\\x63\\x64"
    m = re.match("(\\x61\\x62\\x63\\x64)", str)
    assert escape(m) == "abcd"

# Generated at 2022-06-23 15:44:39.414984
# Unit test for function escape
def test_escape():
    assert escape("\\n") == "\n"
    assert escape("\\\"") == "\""
    assert escape("\\\'") == "\'"

# Generated at 2022-06-23 15:44:47.650071
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'ab\"c'") == "ab\"c"
    assert evalString("'ab\\'c'") == "ab'c"
    assert evalString("'\\\\\\''") == "\\'"
    assert evalString("'\\\n'") == ""
    assert evalString("'''a'bc'''") == "a'bc"
    assert evalString("'''ab\\'c'''") == "ab'c"
    assert evalString("r'a\tb'") == "a\\tb"
    assert evalString("r'a\\tb'") == "a\\tb"
    assert evalString("r'a\\\nb'") == "a\\\nb"
    assert evalString("'\\001'") == "\1"


# Generated at 2022-06-23 15:44:58.140550
# Unit test for function evalString
def test_evalString():
    # Test simple repr values
    assert evalString("'a'") == "a"
    assert evalString("'\\''") == "'"

    # Test values that have to be double quoted
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\v"') == "\v"

    # Test triple quoted values
    assert evalString("'''\'''") == "'"
    assert evalString('"""\\a"""') == "\a"
    assert evalString('"""\\b"""') == "\b"
    assert evalString('"""\\t"""') == "\t"
    assert evalString('"""\\v"""') == "\v"

    # Test hex and octal escapes
    assert eval

# Generated at 2022-06-23 15:45:08.147853
# Unit test for function escape
def test_escape():
    from friendly_traceback import traceback

    # Should return the same
    for i in range(32):
        c = chr(i)
        s = chr(i)
        assert escape(re.match(r"\\%s" % s, "\\%s" % s)) == c
    for c in "abfnrtv":
        s = c
        assert escape(re.match(r"\\%s" % s, "\\%s" % s)) == c

    # ERROR: Should fail!
    try:
        escape(re.match(r"\\x", "\\x"))
    except ValueError:  # pragma: debug
        traceback()
        pass
    else:  # pragma: debug
        assert False

    # ERROR: Should fail!

# Generated at 2022-06-23 15:45:09.743375
# Unit test for function test
def test_test():
    # This will raise an AssertionError exception if there is an error in
    # the test() function
    test()

# Generated at 2022-06-23 15:45:14.311800
# Unit test for function test
def test_test():
    import io
    import sys

    tempOut = io.StringIO()
    sys.stdout = tempOut

    test()
    sys.stdout = sys.__stdout__
    assert tempOut.getvalue() == ""

# Generated at 2022-06-23 15:45:14.961833
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:27.473377
# Unit test for function escape
def test_escape():
    import nose
    from unittest import mock

    m = mock.MagicMock(group=lambda i: '\\a')
    s = escape(m)
    assert s == '\a'
    m = mock.MagicMock(group=lambda i: '\\x09')
    s = escape(m)
    assert s == '\t'
    nose.tools.raises(ValueError, escape, mock.MagicMock(group=lambda i: '\\c'))
    nose.tools.raises(ValueError, escape, mock.MagicMock(group=lambda i: '\\xC'))
    nose.tools.raises(ValueError, escape, mock.MagicMock(group=lambda i: '\\xC0'))

# Generated at 2022-06-23 15:45:29.814497
# Unit test for function escape
def test_escape():
    result = evalString("\"\\n\"")
    assert result == "\n"


# Generated at 2022-06-23 15:45:30.879702
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:39.524347
# Unit test for function evalString

# Generated at 2022-06-23 15:45:46.624701
# Unit test for function escape
def test_escape():
    def test(s):
        assert escape(re.match(r'\\(.*)', s)) == s[1:]
    test("\\a")
    test("\\b")
    test("\\f")
    test("\\n")
    test("\\r")
    test("\\t")
    test("\\v")
    test("\\'")
    test('\\"')
    test("\\\\")
    test("\\x01")
    test("\\x02")
    test("\\x12")
    test("\\xFF")
    test("\\xab")
    test("\\xFF")
    test("\\xff")
    test("\\377")
    test("\\000")


# Generated at 2022-06-23 15:45:47.556701
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:45:48.201256
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:00.117024
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\a')) == '\a'
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\b')) == '\b'
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\f')) == '\f'

# Generated at 2022-06-23 15:46:00.733000
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:03.394789
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-23 15:46:14.732513
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"\\t"') == "\t"
    assert evalString("'\\t'") == "\t"
    assert evalString('"\\x0d"') == "\r"
    assert evalString("'\\x0d'") == "\r"
    assert evalString('"\\"') == "\""
    assert evalString("'\\'") == "'"
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\\'"') == "'"
    assert evalString("'\\\"'") == '"'
    assert evalString('"\\\n\\\t"') == "\n\t"
    assert eval

# Generated at 2022-06-23 15:46:20.487843
# Unit test for function evalString
def test_evalString():
    s = evalString("'bob \\' cat'")
    assert s == "bob ' cat"
    s = evalString("'bob \\' cat'")
    assert s == "bob ' cat"
    s = evalString("'bob \\' cat'")
    assert s == "bob ' cat"
    s = evalString("'bob \\' cat'")
    assert s == "bob ' cat"

# Generated at 2022-06-23 15:46:27.436063
# Unit test for function test
def test_test():
    # Since the module is imported in the same namespace,
    # all function and variable names from evalString would be
    # available here
    assert evalString(r'"\001\002\x03"') == "\x01\x02\x03"
    assert evalString(r'"\001\002\x03"') != "\"\001\002\x03\""
    assert evalString(r'"\001\002\x03"') != "\\001\\002\\x03"

# Generated at 2022-06-23 15:46:38.261396
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\"')) == '"'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"

# Generated at 2022-06-23 15:46:41.562852
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x01", "")) == "\x01"
    assert escape(re.match(r"\\x10", "")) == "\x10"
    assert escape(re.match(r"\\x100", "")) == "\x100"

# Generated at 2022-06-23 15:46:52.605881
# Unit test for function escape
def test_escape():

    from typing import Dict, Match, Text

    simple_escapes: Dict[Text, Text] = {
        "a": "\a",
        "b": "\b",
        "f": "\f",
        "n": "\n",
        "r": "\r",
        "t": "\t",
        "v": "\v",
        "'": "'",
        '"': '"',
        "\\": "\\",
    }


    def escape(m: Match[Text]) -> Text:
        all, tail = m.group(0, 1)
        assert all.startswith("\\")
        esc = simple_escapes.get(tail)
        if esc is not None:
            return esc
        if tail.startswith("x"):
            hexes = tail[1:]

# Generated at 2022-06-23 15:47:02.300842
# Unit test for function escape
def test_escape():
    # Test numbers
    assert escape(re.search(r"[0-7]{1,3}", "096")) is not None
    assert escape(re.search(r"[0-7]{1,3}", "127")) is not None
    assert escape(re.search(r"[0-7]{1,3}", "128")) is None

    # Tests for special chars
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv])", r"\a")) == "\a"
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv])", r"\b")) == "\b"
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv])", r"\f")) == "\f"

# Generated at 2022-06-23 15:47:13.516652
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-23 15:47:20.895183
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\n"') == "\n"



# Generated at 2022-06-23 15:47:30.194337
# Unit test for function evalString
def test_evalString():
    # Simple tests are done in test() above
    assert evalString('"\xc0"') == '\xc0'
    assert evalString('"\\u03a0"') == '\u03a0'
    assert evalString("'\\U00001234'") == '\U00001234'
    # As the following code has a different meaning in 2.4 and 2.5,
    # and 2.6 we have to test it in three different ways to cover it properly.

# Generated at 2022-06-23 15:47:39.232940
# Unit test for function evalString
def test_evalString():
    assert evalString("b'abc'") == b"abc"
    assert evalString("b'def'") == b"def"
    assert evalString("b'ghi\n'") == b"ghi\n"
    assert evalString("b'jkl'") == b"jkl"
    assert evalString("b'mno'") == b"mno"
    assert evalString("b'pqr'") == b"pqr"
    assert evalString('b"abc"') == b"abc"
    assert evalString('b"def"') == b"def"
    assert evalString('b"ghi\n"') == b"ghi\n"
    assert evalString('b"jkl"') == b"jkl"
    assert evalString('b"mno"') == b"mno"


# Generated at 2022-06-23 15:47:43.101676
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x90'") == "\x90"
    assert evalString("'\\uABCD'") == "\uABCD"
    assert evalString("'\\U00010203'") == "\U00010203"

# Generated at 2022-06-23 15:47:43.799259
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:49.603429
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\U00012345"') == "\\U00012345"
    assert evalString('"\\u1234"') == "\\u1234"
    assert evalString('"\\xFF"') == "\\xFF"
    assert evalString('"\\117"') == "O"
    assert evalString('"\\"') == '"'
    assert evalString('"abc"') == "abc"
    assert evalString('"\\117\\xFF"') == "O\\xFF"
    assert evalString('"\\117\\0"') == "O\x00"
    assert evalString('"\\117\\42"') == "O*"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v"') == "\a\b\f\n\r\t\v"

# Generated at 2022-06-23 15:47:52.696903
# Unit test for function evalString
def test_evalString():
    from pathlib import Path
    from .test_flakes import get_errors

    for path in Path(".").glob("test_*.py"):
        errors = get_errors(path)
        assert not errors, f"{path}: Unexpected errors: {errors}"

# Generated at 2022-06-23 15:48:04.831414
# Unit test for function escape
def test_escape():
    def eq(x, y=None, z=None):
        assert x == y, z or (x, y)

    eq(escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")), "\a")
    eq(escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")), "\b")
    eq(escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")), "\f")

# Generated at 2022-06-23 15:48:11.017217
# Unit test for function evalString

# Generated at 2022-06-23 15:48:18.929898
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61\\x62"') == 'ab'
    assert evalString('"\\x61\\n"') == 'a\n'
    assert evalString('"\\x61\\t\\x62"') == 'a\tb'
    assert evalString('"\\x7f"') == unichr(127)
    assert evalString('"\\x80"') == unichr(128)
    assert evalString('"\\u1234"') == unichr(0x1234)
    assert evalString('"\\U00010111"') == unichr(0x10111)
    assert evalString('"\\U0001011111"') == unichr(0x1011111)

# Generated at 2022-06-23 15:48:23.680568
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\t")) == "\t"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\xff")) == "\xff"

# Generated at 2022-06-23 15:48:28.433583
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\'", r"\'")) == "'"

# Generated at 2022-06-23 15:48:39.578473
# Unit test for function evalString
def test_evalString():
    assert evalString("'single quotes'") == "single quotes"
    assert evalString("'escape \\'\\''") == "escape ''"
    assert evalString("'escape \\'\\'\\''") == "escape ''"
    assert evalString('"double quotes"') == "double quotes"
    assert evalString('"escape \\"\\""') == 'escape "'
    assert evalString('"escape \\"\\"\\""') == 'escape ""'
    assert evalString("'''triple single quotes'''") == "triple single quotes"
    assert evalString('"""triple double quotes"""') == 'triple double quotes'
    assert evalString("'single quotes \\'\\''") == "single quotes ''"
    assert evalString('"double quotes \\"\\""') == 'double quotes ""'

# Generated at 2022-06-23 15:48:40.225021
# Unit test for function escape

# Generated at 2022-06-23 15:48:40.789355
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:48:52.410533
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(')", r"\\'")) == "'", "Single quote"
    assert escape(re.search(r'\\(")', r'\\"')) == '"', "Double quote"
    assert escape(re.search(r"\\(\\)", r"\\\\")) == "\\", "Backslash"
    assert escape(re.search(r"\\a", r"\\a")) == "\a", "Bell"
    assert escape(re.search(r"\\b", r"\\b")) == "\b", "Backspace"
    assert escape(re.search(r"\\f", r"\\f")) == "\f", "Formfeed"
    assert escape(re.search(r"\\n", r"\\n")) == "\n", "Newline"

# Generated at 2022-06-23 15:48:56.101122
# Unit test for function test
def test_test():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        test()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-23 15:48:58.980992
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == 'a'
    assert evalString("'a'") == 'a'
    assert evalString('"\\x41"') == 'A'


# Generated at 2022-06-23 15:49:00.631740
# Unit test for function test
def test_test():
    assert test() is None

# Unit tests for function evalString

# Generated at 2022-06-23 15:49:09.628340
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == "foo"
    assert evalString('"foo"') == "foo"
    assert evalString("'\'foo\''") == "'foo'"
    assert evalString('"\\"foo\\""') == '"foo"'
    assert evalString("'''foo'bar'baz'''") == "'foobarbaz"
    assert evalString('"""foo"bar"baz"""') == '"foobarbaz'
    assert evalString("r'foo'") == "foo"
    assert evalString("r'foo\'") == "foo%"
    assert evalString("r'foo\\'") == "foo\\"
    assert evalString("'foo\\tbar'") == "foo\tbar"
    assert evalString("'\n'") == "\n"

# Generated at 2022-06-23 15:49:13.614710
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-23 15:49:21.448103
# Unit test for function escape
def test_escape():
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\'") == "'"
    assert escape("\\\"") == "\""
    assert escape("\\\\") == "\\"
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\v") == "\v"
    assert escape("\\x12") == "\x12"
    assert escape("\\123") == "\x5b"

# Generated at 2022-06-23 15:49:33.137828
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"

    # octals
    assert escape(re.match(r"\\0", r"\0")) == "\x00"
    assert escape(re.match(r"\\1", r"\1")) == "\x01"

# Generated at 2022-06-23 15:49:34.276920
# Unit test for function evalString
def test_evalString():
    print("Testing evalString")
    assert evalString('"a"') == "a"

# Generated at 2022-06-23 15:49:37.894191
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\x45')) == 'E'

# Generated at 2022-06-23 15:49:39.202428
# Unit test for function test
def test_test():
    test()
    assert 1==1

# Generated at 2022-06-23 15:49:45.517710
# Unit test for function evalString
def test_evalString():

    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"

# Generated at 2022-06-23 15:49:46.989274
# Unit test for function test
def test_test():
    # The tests are in test.py in the same directory
    pass

# Generated at 2022-06-23 15:49:55.451382
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == "\x00"
    assert evalString('"\\xff"') == "\xff"
    assert evalString('"\\xff\\x00"') == "\xff\x00"
    assert evalString('"\\xfe"') == "\xfe"
    assert evalString('"\\xfe\\x00"') == "\xfe\x00"
    assert evalString('"\\xfe\\xff"') == "\xfe\xff"

# Generated at 2022-06-23 15:50:05.340875
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString("'a'") == "a"
    assert evalString(r'"\'"') == "'"
    assert evalString(r"'\"'") == '"'
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\1'") == "\x01"

# Generated at 2022-06-23 15:50:05.988072
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:50:10.133776
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'\\b'") == "\b"
    assert evalString('"a"') == "a"
    assert evalString('"\\b"') == "\b"

# Generated at 2022-06-23 15:50:11.517131
# Unit test for function test
def test_test():
    """silly"""
    assert test() is None

# Generated at 2022-06-23 15:50:22.964839
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == "foo"
    assert evalString('"foo"') == "foo"
    assert evalString("'\\a'") == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString('"\\v"') == "\v"
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\\'"') == "\'"
    assert evalString("'\\\"'") == '"'

# Generated at 2022-06-23 15:50:30.011584
# Unit test for function evalString
def test_evalString():
    assert evalString('"abcd"') == "abcd"
    assert evalString('"a\\0c"') == "a\0c"
    assert evalString('"a\\x00c"') == "a\0c"
    assert evalString('"a\\073c"') == "a;c"
    assert evalString('"a\\\\c"') == "a\\c"
    assert evalString("'abcd'") == "abcd"
    assert evalString("'a\\0c'") == "a\0c"
    assert evalString("'a\\x00c'") == "a\0c"
    assert evalString("'a\\073c'") == "a;c"
    assert evalString("'a\\\\c'") == "a\\c"

# Generated at 2022-06-23 15:50:38.896285
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == '\a'
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\'')) == "'"
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\"')) == '"'