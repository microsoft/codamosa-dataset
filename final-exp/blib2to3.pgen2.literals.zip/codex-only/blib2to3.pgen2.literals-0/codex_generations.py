

# Generated at 2022-06-23 15:40:34.016055
# Unit test for function evalString
def test_evalString():
    # Test the eval escapement for strings
    assert evalString('"Foo \\x01"') == 'Foo \x01'
    assert evalString("'Foo \\x01'") == "Foo \x01"

# Generated at 2022-06-23 15:40:35.441866
# Unit test for function test
def test_test():
    try:
        test()
    except ValueError as e:
        print(e)

# Generated at 2022-06-23 15:40:46.881522
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\a", "\a")) == "\a"
    assert escape(re.match("\\b", "\b")) == "\b"
    assert escape(re.match("\\f", "\f")) == "\f"
    assert escape(re.match("\\n", "\n")) == "\n"
    assert escape(re.match("\\r", "\r")) == "\r"
    assert escape(re.match("\\t", "\t")) == "\t"
    assert escape(re.match("\\v", "\v")) == "\v"
    assert escape(re.match("\\'", "'")) == "'"
    assert escape(re.match('\\"', '"')) == '"'
    assert escape(re.match("\\\\", "\\")) == "\\"

# Generated at 2022-06-23 15:40:51.501847
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"

# Generated at 2022-06-23 15:41:02.442730
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\\\", r"\\")) == "\\"
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"

# Generated at 2022-06-23 15:41:06.841559
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-23 15:41:07.426234
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:11.719102
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", r"\x12")) == evalString(r"'\x12'")
    assert escape(re.match(r"\\a", r"\a")) == evalString(r"'\a'")
    assert escape(re.match(r"\\b", r"\b")) == evalString(r"'\b'")

# Generated at 2022-06-23 15:41:24.782020
# Unit test for function evalString
def test_evalString():
    import pytest
    s = "'abc'"
    b = evalString(s)
    assert (b == "abc")
    s = '"abc"'
    b = evalString(s)
    assert (b == "abc")
    s = "'ab' 'c'"
    b = evalString(s)
    assert (b == "ab c")
    s = "'ab'  'c'"
    b = evalString(s)
    assert (b == "abc")
    s = "'abc\ndef'"
    b = evalString(s)
    assert (b == "abc\ndef")
    s = "'abc\def'"
    b = evalString(s)
    assert (b == "abc\def")
    s = "'abc\vdef'"
    b = evalString(s)

# Generated at 2022-06-23 15:41:33.693744
# Unit test for function escape
def test_escape():
    import pytest

    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\\'", "\\'")) == "'"

# Generated at 2022-06-23 15:41:39.044866
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\t\\r'") == "\t\r"
    assert evalString("'\\x99\\x00'") == "\x99\x00"
    assert evalString("'\\063\\07'") == "??"
    assert evalString("'\\063')") == "3)"
    assert evalString("'\\063\\x09'") == "3\t"
    assert evalString("'\\063\\057')") == "3/"
    assert evalString("'\\063\\x09')") == "3\t"
    assert evalString("'\\063\\x09x')") == "3\tx"
    assert evalString("'\\063\\x09xy')") == "3\txy"

# Generated at 2022-06-23 15:41:41.583024
# Unit test for function escape
def test_escape():
    assert escape(['\xabc', 'xabc']) == 'ABC'

# Generated at 2022-06-23 15:41:52.174407
# Unit test for function evalString
def test_evalString():
    # Test for literal strings
    assert evalString('"a literal string with no special characters"') == "a literal string with no special characters"
    assert evalString("'another literal string with no special characters'") == "another literal string with no special characters"
    assert evalString("'a literal string with a single quote: \\''") == "a literal string with a single quote: '"
    assert evalString('"a literal string with a double quote: \\""') == 'a literal string with a double quote: "'
    assert evalString("'a literal string with a backslash: \\\\'") == "a literal string with a backslash: \\"
    assert evalString("'a literal string with a slash: /'") == "a literal string with a slash: /"

# Generated at 2022-06-23 15:42:00.255176
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\x0A", "\\x0A")) == "\n"

# Generated at 2022-06-23 15:42:01.283673
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:02.396698
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:12.967878
# Unit test for function escape
def test_escape():

    tests = (
        ('\\a', '\\a', '\a'),
        ('\\b', '\\b', '\b'),
        ('\\f', '\\f', '\f'),
        ('\\n', '\\n', '\n'),
        ('\\r', '\\r', '\r'),
        ('\\t', '\\t', '\t'),
        ('\\v', '\\v', '\v'),
        ('\\x1A', '\\x1A', '\x1A'),
        ('\\01', '\\01', '\01'),
        ('\\012', '\\012', '\012'),
    )

    for test in tests:
        assert escape(re.match(r'\\(.*)', test[0])) == test[2]

# Generated at 2022-06-23 15:42:20.969471
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x45", "\\x45")) == "\x45"
    assert escape(re.match(r"\\xzl", "\\xzl")) == '\\xzl'
    assert escape(re.match(r"\\045", "\\045")) == "\x2d"
    assert escape(re.match(r"\\fo", "\\fo")) == "\\fo"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape(re.match(r"\\\\", "\\\\")) == "\\"
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b"))

# Generated at 2022-06-23 15:42:25.545276
# Unit test for function escape
def test_escape():
    assert escape("\\b") == "\b"
    assert escape("\\x42") == "B"
    assert escape("\\42") == "*"
    assert escape("\\7") == "\x07"
    assert escape("\\6") == "6"

# Generated at 2022-06-23 15:42:37.051397
# Unit test for function escape
def test_escape():
    assert escape('\a') == '\\a', 'escape of \\a'
    assert escape('\b') == '\\b', 'escape of \\b'
    assert escape('\f') == '\\f', 'escape of \\f'
    assert escape('\n') == '\\n', 'escape of \\n'
    assert escape('\r') == '\\r', 'escape of \\r'
    assert escape('\t') == '\\t', 'escape of \\t'
    assert escape('\v') == '\\v', 'escape of \\v'
    assert escape('\'a') == '\\\'', 'escape of \\\''
    assert escape('\"a') == '\\\"', 'escape of \\\"'
    assert escape('\\a') == '\\\\', 'escape of \\\\a'
    assert escape('\x00')

# Generated at 2022-06-23 15:42:49.221189
# Unit test for function escape
def test_escape():
    assert(escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'")
    assert(escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\"")) == "\"")
    assert(escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a")

# Generated at 2022-06-23 15:42:55.419541
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == "hello"
    assert evalString('"hello world"') == "hello world"

    # create a new string that isn't in the source code
    #    q = "\xab"
    #    s = repr(q)
    #    e = evalString(s)
    #    assert e == q, "evalString(%r) returned %r, expected %r" % (s, e, q)

    #    assert evalString('"ab\xcd\xef"') == 'ab\xcd\xef'
    #    assert evalString('r"ab\xcd\xef"') == 'ab\\xcd\\xef'

    # test raw strings
    assert evalString('r"a\"b"') == 'a\\"b'

# Generated at 2022-06-23 15:42:56.000899
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:06.842613
# Unit test for function evalString
def test_evalString():

    assert evalString("'abc'") == "abc"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'foo\\x20bar'") == "foo bar"
    assert evalString("'foo\\xA9bar'") == "foo\xa9bar"
    assert evalString("'foo\\xA9bar'", "strict") == "foo\xa9bar"
    assert evalString("'foo\\xA9bar'", "backslashreplace") == "foo\\xA9bar"


# Generated at 2022-06-23 15:43:07.363013
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:14.416478
# Unit test for function evalString
def test_evalString():
    assert evalString('"7"') == '7'
    assert evalString("'\\x7'") == '\x07'
    assert evalString("b'7'") == '7'
    assert evalString("b'\\x7'") == '\x07'
    assert evalString("b'\\x7'") == b'\x07'
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\''") == "'"
    assert evalString("'\"'") == '"'
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"

# Generated at 2022-06-23 15:43:15.783454
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:43:24.170487
# Unit test for function evalString
def test_evalString():

    # Test regexp for simple escape sequences
    assert evalString(r'"\a\b\f\n\r\t\v\'"') == "\a\b\f\n\r\t\v'"

    # Test hexadecimal and octal escape sequences
    assert evalString(r'"\x20\x80\400\0"') == "\x20\x80\x80\x00"
    assert evalString(r'"\100\200\300\0"') == "\x40\xc8\x83\x00"
    assert evalString(r'"\100\200\300\0"') == "\x40\xc8\x83\x00"

    # Test unquoted newline
    assert evalString(r'"\
    ab"') == "\nab"

    # Test trailing backslash
   

# Generated at 2022-06-23 15:43:34.036147
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("' '") == " "
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\n\\n'") == "\n\n"
    assert evalString("'\\n\\n\\n'") == "\n\n\n"
    assert evalString('" "') == " "
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\n\\n"') == "\n\n"
    assert evalString('"""\\n"""') == """\n"""
    assert evalString("'\\0'") == "\x00"
    assert evalString("'\\47'") == "'"
    assert evalString("'\\047'") == "\\47"

# Generated at 2022-06-23 15:43:46.459631
# Unit test for function evalString
def test_evalString():
    print("Testing evalString()...")

# Generated at 2022-06-23 15:43:57.243872
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString("''") == ""
    assert evalString('"a"') == "a"
    assert evalString("'a'") == "a"
    assert evalString('"\\""') == '"'
    assert evalString("'\\''") == "'"
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\a"') == "\a"
    assert evalString("'\\a'") == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString("'\\b'") == "\b"
    assert evalString('"\\f"') == "\f"
    assert evalString("'\\f'") == "\f"

# Generated at 2022-06-23 15:44:00.836264
# Unit test for function test
def test_test():
    def test_eval(s: Text) -> Text:
        return eval(r'u"' + s + '"')

    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

    assert evalString(r"'\x1\n'") == "\x01\n"
    assert evalString(r'"\x1\n"') == "\x01\n"
    assert evalString(r"'\0\n'") == "\0\n"
    assert evalString(r'"\0\n"') == "\0\n"
    assert evalString(r"'\\'") == "\\"
    assert evalString(r'"\\"') == "\\"

# Generated at 2022-06-23 15:44:02.911802
# Unit test for function test
def test_test():
    try:
        test()
    except ImportError:
        pass

# Generated at 2022-06-23 15:44:11.518777
# Unit test for function test
def test_test():
    import io
    import sys

    if sys.version_info[:2] >= (2, 7):
        # Python 2.7 and above give the output in a different order than
        # earlier versions.
        expected = (
            "39 '\\x27' '\\x27' '''\n"
            "34 '\\x22' '\\x22' '\"'\n"
            "92 '\\\\' '\\\\' '\\\\'\n"
        )
    else:
        expected = "39 '\\x27' '\\x27' '''\n34 '\\x22' '\\x22' '\"'\n92 '\\\\' '\\\\' '\\\\'\n"
    with io.StringIO() as f:
        with open(None, "w", 1) as old_stdout:
            sys.stdout

# Generated at 2022-06-23 15:44:14.140884
# Unit test for function test
def test_test():
    """
    verifies that the test function behaves as expected
    """
    # Run the test function if it is defined
    try:
        test()
    except NameError:
        pass

# Generated at 2022-06-23 15:44:20.697327
# Unit test for function test
def test_test():
    import tempfile

    temp_file_name = tempfile.gettempdir() + "/test.txt"
    # Need to have the following escape sequence
    # '\x1b[92m'
    with open(temp_file_name, "w") as temp_file:
        temp_file.write('\\x1b[92m')
    with open(temp_file_name, "r") as temp_file:
        content = temp_file.read()
    assert evalString(content) == "\x1b[92m"

# Generated at 2022-06-23 15:44:22.639738
# Unit test for function test
def test_test():
    test()
    print("Test completed")

# Generated at 2022-06-23 15:44:32.919912
# Unit test for function evalString
def test_evalString():
    assert evalString("'Hello, world!'") == "Hello, world!"
    assert evalString('"Hello, world!"') == "Hello, world!"
    assert evalString("'\\x41\\x42\\x43'") == "ABC"
    assert evalString("'\\u1234\\U00012345'") == "\u1234\U00012345"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v"') == "\a\b\f\n\r\t\v"
    assert evalString('"\\\'\\"\\\\"') == "\"'"
    assert evalString("'\\xE0\\xE1\\xE2\\xE3\\xE4\\xE5\\xE6\\xE7'") == "àáâãäåæç"
    assert eval

# Generated at 2022-06-23 15:44:35.540534
# Unit test for function test
def test_test():
    import io
    from unittest import mock

    with mock.patch.object(io, "print") as mock_print:
        test()

    assert mock_print.call_count == 0

# Generated at 2022-06-23 15:44:44.767901
# Unit test for function escape
def test_escape():
    assert (escape(re.search(r"\\a", "\\a")) == "\a")
    assert (escape(re.search(r"\\b", "\\b")) == "\b")
    assert (escape(re.search(r"\\f", "\\f")) == "\f")
    assert (escape(re.search(r"\\n", "\\n")) == "\n")
    assert (escape(re.search(r"\\r", "\\r")) == "\r")
    assert (escape(re.search(r"\\t", "\\t")) == "\t")
    assert (escape(re.search(r"\\v", "\\v")) == "\v")
    assert (escape(re.search(r"\\'", "\\'")) == "'")

# Generated at 2022-06-23 15:44:45.386844
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:56.988809
# Unit test for function escape
def test_escape():
    import pytest

    escape_tests = [
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\\\", "\\"),
        ("\\012", "\n"),
        ("\\x1a", "\x1a"),
        ("\\n", "\n"),
        ("\\N{GREEK SMALL LETTER ALPHA}", "α"),
        ("\\u0100", "\u0100"),
        ("\\U00010000", "\U00010000"),
        ("", ""),
    ]


# Generated at 2022-06-23 15:44:57.599353
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:07.791701
# Unit test for function escape
def test_escape():
    import pytest
    assert escape(re.match(r'\\(.)', '\\a')) == '\a'
    assert escape(re.match(r'\\(.)', '\\b')) == '\b'
    assert escape(re.match(r'\\(.)', '\\f')) == '\f'
    assert escape(re.match(r'\\(.)', '\\n')) == '\n'
    assert escape(re.match(r'\\(.)', '\\r')) == '\r'
    assert escape(re.match(r'\\(.)', '\\t')) == '\t'
    assert escape(re.match(r'\\(.)', '\\v')) == '\v'

# Generated at 2022-06-23 15:45:13.518759
# Unit test for function escape
def test_escape():
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\xab') == '\xab'
    assert escape('\\xz') == '\\xz'

# Generated at 2022-06-23 15:45:20.007755
# Unit test for function escape
def test_escape():
    assert escape('\\') == '\\'
    assert escape('\\x') == 'x'
    assert escape('\\xab') == '\xab'

# Generated at 2022-06-23 15:45:30.850114
# Unit test for function escape
def test_escape():
    m = re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x61")
    assert m
    assert escape(m) == "a"
    m = re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x61")
    assert m
    assert escape(m) == "a"
    m = re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")
    assert m
    assert escape(m) == "\n"

# Generated at 2022-06-23 15:45:31.440438
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:39.927785
# Unit test for function evalString
def test_evalString():

    assert evalString('"\\x05"') == "\x05"
    assert evalString('"\\x0A"') == "\n"
    assert evalString('"\\x0A\\x0"') == "\n\x00"
    assert evalString('"\\x0A\\x0\\x01\\x02"') == "\n\x00\x01\x02"
    assert evalString('"\\xa"') == "\n"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\f"') == "\f"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString('"\\t"') == "\t"

# Generated at 2022-06-23 15:45:45.885384
# Unit test for function test
def test_test():
    import io
    import sys

    captured_output = io.StringIO()
    sys.stdout = captured_output
    test()
    sys.stdout = sys.__stdout__

    # The test suite passes in Python 3.7 and 3.8 if no output is produced.
    assert "42 *" not in captured_output.getvalue()

# Generated at 2022-06-23 15:45:46.340961
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:58.157912
# Unit test for function escape
def test_escape():
    assert escape("\\t") == "\t"
    assert escape("\\n") == "\n"
    assert escape("\\x0A") == "\n"
    assert escape("\\x7F") == "\x7f"
    assert escape("\\x7f") == "\x7f"
    assert escape("\\77") == "?"
    assert escape("\\174") == "|"
    assert escape("\\377") == "\xff"
    assert escape("\\378") == "\x38\x37\x38"
    assert escape("\\400") == "\0"
    assert escape("\\400") == "\0"
    assert escape("\\077") == "?"
    assert escape("\\101") == "A"
    assert escape("\\101") == "A"
    assert escape("\\101") == "A"
    assert escape

# Generated at 2022-06-23 15:46:06.791740
# Unit test for function evalString

# Generated at 2022-06-23 15:46:07.127730
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:08.456782
# Unit test for function test
def test_test():
    assert False, "unimplemented"

# Generated at 2022-06-23 15:46:09.098116
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:10.605198
# Unit test for function test
def test_test():
    """
    Can test the test function
    """
    test()

# Generated at 2022-06-23 15:46:11.234332
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:46:11.854771
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-23 15:46:21.181516
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape

# Generated at 2022-06-23 15:46:21.956877
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:22.596197
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:46:24.265670
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        msg = "test() not passed!"
        print(e)
        print(msg)
        assert False, msg

# Generated at 2022-06-23 15:46:24.874694
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:33.258427
# Unit test for function evalString
def test_evalString():
    assert evalString('"""foo"""') == '"""foo"""'
    assert evalString('"foo"') == 'foo'
    assert evalString("'''foo'''") == "'''foo'''"
    assert evalString("'foo'") == 'foo'
    assert evalString(r'"foo\"bar"') == 'foo"bar'
    assert evalString(r"'foo\'bar'") == "foo'bar"
    assert evalString(r'"foo\\bar"') == r"foo\bar"
    assert evalString(r"'foo\\bar'") == r"foo\bar"
    assert evalString(r'"foo\tbar"') == 'foo\tbar'
    assert evalString(r"'foo\tbar'") == 'foo\tbar'

# Generated at 2022-06-23 15:46:34.496662
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:38.424347
# Unit test for function escape
def test_escape():
    from .util import dump_module_list
    from .. import util
    dump_module_list()
    s = evalString("'abcd\\'efgh\\tijkl\\x01'")
    assert s == "abcd'efgh\tijkl\x01"


# Generated at 2022-06-23 15:46:39.197809
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-23 15:46:47.687899
# Unit test for function evalString
def test_evalString():
    assert evalString('"abcd"') == "abcd"
    assert evalString("'abcd'") == "abcd"
    assert evalString("'\\xFF'") == "\xFF"
    assert evalString("'\\377'") == "\377"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\'"') == "\a\b\f\n\r\t\v'"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\''") == "\a\b\f\n\r\t\v'"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\''") == "\a\b\f\n\r\t\v'"

# Generated at 2022-06-23 15:46:57.948942
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61\\xb0"') == 'a°'
    assert evalString('"\\61\\xb0"') == 'a°'
    assert evalString('"\\081\\xb0"') == 'a°'
    assert evalString('"\\u0061"') == 'a'
    assert evalString('"\\U00000061"') == 'a'
    assert evalString('"\\U00000061"') == 'a'
    assert evalString('"\\N{GREEK SMALL LETTER ALPHA}"') == 'α'
    assert evalString('"\\N{GREEK SMALL LETTER ALPHA}\\u0061"') == 'αa'
    assert evalString('"\\N{greek small letter alpha}"') == 'α'

# Generated at 2022-06-23 15:47:05.723618
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(['\"\\])", "\\x")) == "x"

# Generated at 2022-06-23 15:47:15.237233
# Unit test for function escape
def test_escape():
    '''
    doc string
    '''
    assert escape(re.match(r'\\a', '\\a')) == '\a', "Escape of '\\a' should be a bell character"
    assert escape(re.match(r'\\b', '\\b')) == '\b', "Escape of '\\b' should be a backspace character"
    assert escape(re.match(r'\\f', '\\f')) == '\f', "Escape of '\\f' should be a form feed character"
    assert escape(re.match(r'\\n', '\\n')) == '\n', "Escape of '\\n' should be a newline character"

# Generated at 2022-06-23 15:47:26.999160
# Unit test for function evalString

# Generated at 2022-06-23 15:47:27.971140
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:28.826689
# Unit test for function test
def test_test():
	assert test() == None

# Generated at 2022-06-23 15:47:38.841636
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == "hello", evalString('"hello"')
    assert evalString("'hello'") == "hello", evalString("'hello'")
    assert evalString("'a\\\'b'") == "a'b", evalString("'a\\\'b'")
    assert evalString('"a\\\"b"') == 'a"b', evalString('"a\\\"b"')
    assert evalString("'a\\tb\\nc\\rd'") == "a\tb\nc\rd", evalString("'a\\tb\\nc\\rd'")

# Generated at 2022-06-23 15:47:39.472753
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-23 15:47:40.180752
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:41.421389
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:47:43.430031
# Unit test for function test
def test_test():
    e = evalString("'a'*1000")
    expected = "a" * 1000
    assert e == expected

# Generated at 2022-06-23 15:47:52.901529
# Unit test for function evalString
def test_evalString():
    assert evalString("'qwerty'") == "qwerty"
    assert evalString('"qwerty"') == "qwerty"

    assert evalString(r""" '\x01' """) == "\x01"
    assert evalString(r""" '\1' """) == "\x01"
    assert evalString(r""" '\001' """) == "\x01"

    assert evalString(r""" '\x64' """) == "d"
    assert evalString(r""" '\x064' """) == "d"
    assert evalString(r""" '\0064' """) == "d"

    assert evalString(r""" '\x20ac' """) == "\u20ac"
    assert evalString(r""" '\u20ac' """) == "\u20ac"
    assert eval

# Generated at 2022-06-23 15:48:01.262561
# Unit test for function escape
def test_escape():
    # Test for function escape
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\"') == '"'
    assert escape('\\\\') == '\\'



# Generated at 2022-06-23 15:48:10.229537
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\'"') == "\a\b\f\n\r\t\v'"
    assert evalString("'\\x61\\x62\\x66\\x6e\\x72\\x74\\x76\\x27'") == "abfnrtv'"
    assert evalString("'\\x61\\x62\\x66\\x6e\\x72\\x74\\x76\\x27'") == "abfnrtv'"
    assert evalString("'\\161\\162\\166\\156\\162\\164\\176\\127'") == "abfnrtv'"

# Generated at 2022-06-23 15:48:13.491176
# Unit test for function escape
def test_escape():
    assert escape('\\x') == 'x'
    assert escape('\\07') == '\x07'
    assert escape('\\077') == '\x3f'
    assert escape('\\123') == 'S'
    return

# Generated at 2022-06-23 15:48:14.406364
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:48:26.593805
# Unit test for function escape
def test_escape():
    # N.B. This isn't a unit test for evalString
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\''")) == "\\'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x27")) == "'"

# Generated at 2022-06-23 15:48:27.253924
# Unit test for function test
def test_test():
    assert True

# Generated at 2022-06-23 15:48:34.778725
# Unit test for function evalString
def test_evalString():

    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r'""') == ""
    assert evalString(r"''") == ""
    assert evalString(r'"a\nb"') == "a\nb"
    assert evalString(r"'a\nb'") == "a\nb"

    assert evalString(br'"\x63"') == "c"
    assert evalString(br'"\x63"') == "c"

    # evalString() doesn't support unicode strings.
    raises(ValueError, evalString, br'"\u1234"')
    raises(ValueError, evalString, br'"\U00012345"')
    raises(ValueError, evalString, br'"\U00110000"')

# Generated at 2022-06-23 15:48:35.407020
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:43.333232
# Unit test for function escape

# Generated at 2022-06-23 15:48:44.957133
# Unit test for function test
def test_test():
    assert test() is None # TypeError: 'NoneType' object is not callable

# Generated at 2022-06-23 15:48:54.465064
# Unit test for function evalString

# Generated at 2022-06-23 15:48:55.752379
# Unit test for function test
def test_test():
    # Basic test
    test()


# Generated at 2022-06-23 15:49:05.961861
# Unit test for function escape
def test_escape():
    # Tests for correct escaping of valid input
    assert escape(re.match(r'\\x([a-f]|[A-F]|[0-9]){2}', '\\x41')) == 'A'
    assert escape(re.match(r'\\[a-f]|[A-F]|[0-9]{1,3}', '\\41')) == 'A'
    assert escape(re.match(r'\\[\'\"\\abfnrtv]', '\\a')) == '\a'
    # Tests for correct escaping of invalid input
    assert escape(re.match(r'\\x([a-f]|[A-F]|[0-9]){2}', '\\x414')) == '\\x414'

# Generated at 2022-06-23 15:49:07.502074
# Unit test for function test
def test_test():
    """function test"""
    test()

# Generated at 2022-06-23 15:49:14.527189
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x[0-9a-fA-F]{2}", "\\x20")) == " "
    assert escape(re.match(r"\\x[0-9a-fA-F]{2}", "\\x7f")) == "\x7f"
    assert escape(re.match(r"\\x[0-9a-fA-F]{2}", "\\xFF")) == "\xFF"


# Generated at 2022-06-23 15:49:21.712421
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == "foo"
    assert evalString('"foo"') == "foo"
    assert evalString("'foo\\nbar'") == "foo\nbar"
    assert evalString("'foo\\tbar\\n'") == "foo\tbar\n"
    assert evalString("'\\r\\n\\r\\n\\r'") == "\r\n\r\n\r"
    assert evalString("'\\x01\\x02\\x03\\x04'") == "\u0001\u0002\u0003\u0004"

# Generated at 2022-06-23 15:49:31.497451
# Unit test for function test
def test_test():
    # Bugfix for issue #13106. The test did not verify that all escape
    # combinations were evaluated correctly.
    import sys

    errors = []
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            errors.append((i, c, s, e))

    if errors:
        print("The following escape strings did not evaluate correctly:")
        for i, c, s, e in errors:
            print(i, c, s, e, file=sys.stderr)
        raise AssertionError("Some escape strings did not evaluate correctly.")

# Generated at 2022-06-23 15:49:33.085296
# Unit test for function test
def test_test():
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 15:49:37.252607
# Unit test for function escape
def test_escape():
    with pytest.raises(ValueError, match="invalid hex string escape"):
        escape(re.match(r"\\x", ""))
    assert escape(re.match(r"\\xF", "")) == "\x0F"
    assert escape(re.match(r"\\xFF", "")) == "\xFF"


# Generated at 2022-06-23 15:49:41.143178
# Unit test for function evalString
def test_evalString():
    assert evalString('"1"') == "1"
    assert evalString('"\\\a1234567\\\b\\\f\\\n\\\r\\\t\\\v"') == "\a1234567\b\f\n\r\t\v"
    assert evalString("'\\\x01234567\\\x89'") == "\x01234567\x89"

# Generated at 2022-06-23 15:49:49.743804
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString('"\\a\\b\\c"') == "\a\b\c"
    assert evalString("'''abc'''") == "abc"
    assert evalString('"""abc"""') == "abc"
    # Test non-ascii characters in Python 3
    if bytes is not str:
        assert evalString("'\xe9'") == "\xe9"
        assert evalString("'\u03b1'") == "\u03b1"

# Generated at 2022-06-23 15:50:01.053336
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x31\\n'") == "1\n"
    assert evalString("''") == ""
    assert evalString("' '") == " "
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\b'") == '\b'
    assert evalString("'\\n'") == '\n'
    assert evalString("'\\f'") == '\f'
    assert evalString("'\\v'") == '\v'
    assert evalString("'\\a'") == '\a'
    assert evalString("'\\''") == "'"
    assert evalString("'\"'") == '"'

# Generated at 2022-06-23 15:50:08.251412
# Unit test for function evalString
def test_evalString():
    """Unit test for function evalString"""
    # Simple strings
    assert evalString("'hello'") == "hello"
    assert evalString('"hello"') == "hello"
    assert evalString("'hello'") != evalString('"hello"')

    # Quotes inside
    assert evalString("'hello'") != evalString("'hel\"lo'")
    assert evalString("'hello'") != evalString("'hel\'lo'")
    assert evalString("'he\"llo'") == evalString("'hel\\\"lo'")
    assert evalString("'he\'llo'") == evalString("'hel\\\'lo'")

    # Escapes
    assert evalString("'hello\\n'") != 'hello'
    assert evalString("'hello\\n'") == 'hello\n'

# Generated at 2022-06-23 15:50:20.526625
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString('"abc"') == evalString("'abc'")
    assert evalString('"\'\\\n\r\t\v\b\f"') == "'\\\n\r\t\v\b\f"
    assert evalString("'\\x61bc'") == "abc"
    assert evalString("'\\x61\\n\\x62\\x63\\n'") == "a\nb\nc\n"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\061\\062\\063'") == "abc"
    assert evalString("'\\61\\62\\63'") == "abc"


# Generated at 2022-06-23 15:50:21.176457
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:50:29.014751
# Unit test for function escape
def test_escape():
    # test simple escapes
    assert escape(re.search(r"\\'", r"'")) == "'"
    assert escape(re.search(r"\\\"", r'"')) == '"'
    assert escape(re.search(r"\\\\", r"\\")) == "\\"
    assert escape(re.search(r"\\x", r"\x")) == "x"
    assert escape(re.search(r"\\a", r"\a")) == "a"
    assert escape(re.search(r"\\b", r"\b")) == "b"
    assert escape(re.search(r"\\f", r"\f")) == "f"
    assert escape(re.search(r"\\n", r"\n")) == "n"

# Generated at 2022-06-23 15:50:38.546052
# Unit test for function evalString
def test_evalString():
    # Test evalString with all printable ASCII characters
    # Each string must be correctly eval()ed, but the result must not be a single quote or backslash
    import string
    assert [evalString(c) for c in string.printable] == list(string.printable)
    assert [evalString(c) for c in string.printable[:-2]] != list(string.printable[:-2])
    # Test evalString with a few different escape sequences
    assert evalString(r"'\n'") == "\n"
    assert evalString(r"'\r'") == "\r"
    assert evalString(r"'\t'") == "\t"
    assert evalString(r"'\\'") == "\\"
    assert evalString(r"'\"'") == '"'
    assert evalString(r"'\''") == "'"