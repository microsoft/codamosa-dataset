

# Generated at 2022-06-23 15:40:38.322584
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\177'") == "\177"
    assert evalString("'\\x7f'") == "\177"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\037'") == "\037"
    assert evalString("'\\377'") == "\377"
    assert evalString("'\\xFF'") == "\377"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\012'") == "\n"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\102'") == "B"
    assert evalString("'\\x42'") == "B"

# Generated at 2022-06-23 15:40:40.633648
# Unit test for function test
def test_test():
    import pytest
    from test.test_support import captured_stdout

    with captured_stdout() as out:
        test()
    if out.getvalue():
        raise pytest.fail("test() prints something")

# Generated at 2022-06-23 15:40:42.096869
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"a b"') == "a b"
    assert evalString(r'"a \"b\""') == r'a "\b"'

# Generated at 2022-06-23 15:40:47.968835
# Unit test for function escape
def test_escape():
    assert escape(re.match(re.compile(r"\\([abfnrtv']|x.{0,2}|[0-7]{1,3})"), r"\x20")) == "\x20"
    assert escape(re.match(re.compile(r"\\([abfnrtv']|x.{0,2}|[0-7]{1,3})"), r"\x20")) != "20"

# Generated at 2022-06-23 15:40:54.827897
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\xFF") == "ÿ"
    assert escape("\\377") == "\xff"
    assert escape("\\377\\377") == "\xff\xff"
    assert escape("\\377\\377\\377") == "\xff\xff\xff"
    assert escape("\\xFFx") == "ÿx"
    assert escape("\\xFFx\\xFF") == "ÿxÿ"

# Generated at 2022-06-23 15:41:03.803199
# Unit test for function evalString
def test_evalString():
    """Test for basic functionality.
    """
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    # Test ' and " quoting, mixed and triple
    assert evalString('"""abc"""') == "abc"
    assert evalString('"\'abc\'"') == "'abc'"
    assert evalString("'\"abc\"'") == '"abc"'
    assert evalString("'''abc'''") == "abc"
    assert evalString("'''a'bc'''") == "a'bc"
    assert evalString("'''ab'c'''") == "ab'c"
    assert evalString("'''abc'''") == "abc"
    # Test escapes
    assert evalString(r'"\\"') == "\\"

# Generated at 2022-06-23 15:41:11.807599
# Unit test for function evalString
def test_evalString():
    """ Test that evalString works correctly. """
    import unittest
    class TestEvalString(unittest.TestCase):
        """ Test that evalString works correctly. """
        def test_basic(self):
            """ Test basic functionality. """
            self.assertEqual("", evalString("''"))
            self.assertEqual("abc", evalString("'abc'"))
            self.assertEqual("abc", evalString("\"abc\""))
            self.assertEqual("ab'c", evalString("\"ab'c\""))
            self.assertEqual("ab\"c", evalString("'ab\"c'"))
            self.assertEqual("a'\"b", evalString("\"a'\\\"b\""))
            self.assertEqual("a\"'b", evalString("'a\"\\'b'"))
           

# Generated at 2022-06-23 15:41:24.781023
# Unit test for function escape
def test_escape():
    import re
    assert escape(re.match('\\'+'a', '\a')) == '\a'
    assert escape(re.match('\\'+'b', '\b')) == '\b'
    assert escape(re.match('\\'+'f', '\f')) == '\f'
    assert escape(re.match('\\'+'n', '\n')) == '\n'
    assert escape(re.match('\\'+'r', '\r')) == '\r'
    assert escape(re.match('\\'+'t', '\t')) == '\t'
    assert escape(re.match('\\'+'v', '\v')) == '\v'

# Generated at 2022-06-23 15:41:34.536910
# Unit test for function escape
def test_escape():
    # Test bytes
    for i in range(256):
        c = chr(i)
        s = '\\' + c
        e = escape(s)
        assert e == c, s
        s = '\\' + ('%03o' % i)
        e = escape(s)
        assert e == c, s
        s = '\\' + ('%02x' % i)
        e = escape(s)
        assert e == c, s
        s = '\\a'
        e = escape('\\a')
        assert e == '\a', s
        s = '\\b'
        e = escape('\\b')
        assert e == '\b', s
        s = '\\f'
        e = escape('\\f')
        assert e == '\f', s

# Generated at 2022-06-23 15:41:39.580970
# Unit test for function escape
def test_escape():
	# Test all characters
	for i in range(256):
		c = chr(i)
		s = evalString(repr(c))
		assert c == s, "Character {} does not match evalString, is {}".format(c,s)

	assert evalString("'\\n'") == "\n"
	assert evalString("'\\x01'") == "\x01"
	assert evalString("'\\x001'") == "\x01"
	assert evalString("'\\x01A'") == "\x01A"
	assert evalString("'\\x01aa'") == "\x01aa"
	assert evalString("'\\x01aaa'") == "\x01aaa"
	assert evalString("'\\x01aaaa'") == "\x01aaaa"

# Generated at 2022-06-23 15:41:51.067311
# Unit test for function evalString
def test_evalString():
    from . import typings_test_helpers

    def check(s: Text, v: Text) -> None:
        assert evalString(s) == v

    check('"hi"', "hi")
    check("'hi'", "hi")
    check('"\\n"', "\n")
    check("'\\n'", "\n")
    check('"\\x61\\x62"', "ab")
    check("'\\x61\\x62'", "ab")
    check('"""hi"""', "hi")
    check("'''hi'''", "hi")
    check('"""\\n"""', "\n")
    check("'''\\n'''", "\n")
    check('"""\\x61\\x62"""', "ab")
    check("'''\\x61\\x62'''", "ab")

# Generated at 2022-06-23 15:41:53.809326
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\''") == "'"
    assert evalString('"\\\""') == '"'
    assert evalString('"\\x01"') == "\x01"
    assert evalString('"\\x016"') == "\x016"
    assert evalString('"\\000"') == "\000"
    assert evalString('"\\072"') == ":"

# Generated at 2022-06-23 15:41:57.494066
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)
    x = evalString('"John Smith"')
    assert x == 'John Smith'

# Generated at 2022-06-23 15:42:09.683280
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == 'abc'
    assert evalString("'\\x61\\x62\\x63'") == 'abc'
    assert evalString("'\\077'") == '?'
    assert evalString("'\\61'") == 'a'
    assert evalString('"abc"') == 'abc'
    assert evalString('"\\x61\\x62\\x63"') == 'abc'
    assert evalString('"\\077"') == '?'
    assert evalString('"\\61"') == 'a'
    assert evalString('"""abc"""') == 'abc'
    assert evalString('"""\\x61\\x62\\x63"""') == 'abc'
    assert evalString('"""\\077"""') == '?'
    assert evalString('"""\\61"""') == 'a'
   

# Generated at 2022-06-23 15:42:18.846529
# Unit test for function escape
def test_escape():
    # Function escape
    # Input 1: re.match('\\(\\'|"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\')
    # Output 1: '\\'
    assert escape(re.match('\\(\\' '|"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\')) == '\\'

    # Input 2: re.match('\\(\\'|"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\"')
    # Output 2: '"'

# Generated at 2022-06-23 15:42:24.395401
# Unit test for function escape
def test_escape():
    # Test some simple escapes that should be recognized
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"

# Generated at 2022-06-23 15:42:34.858205
# Unit test for function escape
def test_escape():
    assert escape("\\a\\b\\f\\n\\r\\t\\v") == "\a\b\f\n\r\t\v"
    assert escape("\\'\\\"\\\\") == "\"\"\\"
    assert escape("\\xaz\\x80") == "z\x80"
    assert escape("\\xaz\\xb1") == "z\xb1"
    assert escape("\\xaz\\xbf") == "z\xbf"
    assert escape("\\xaz\\xc0") == "z\xc0"
    assert escape("\\xaz\\xff") == "z\xff"
    assert escape("\\0\\111\\177") == "\0I\x7f"
    assert escape("\\xaz\\xbf\\277") == "z\xbf\x7f"

# Generated at 2022-06-23 15:42:40.891489
# Unit test for function escape
def test_escape():
    assert escape(re.search(r'\\x12', '\\x12')) == '\x12'
    assert escape(re.search(r'\\b', '\\b')) == '\x08'
    assert escape(re.search(r'\\n', '\\n')) == '\x0a'
    assert escape(re.search(r'\\\\', '\\\\')) == '\\'
    assert escape(re.search(r'\\x0', '\\x0')) == '\x00'

# Generated at 2022-06-23 15:42:42.417773
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-23 15:42:51.921434
# Unit test for function escape
def test_escape():
    # Test case for invalid escape sequence
    # (string containing only "\")
    with pytest.raises(ValueError) as e:
        escape(re.match("\\", ""))
    assert str(e.value) == "invalid octal string escape ('\\')"

    # Test case for invalid escape sequence
    # (string containing only "\a")
    with pytest.raises(ValueError) as e:
        escape(re.match("\\a", ""))
    assert str(e.value) == "invalid octal string escape ('\\a')"

    # Test case for invalid escape sequence
    # (string containing only "\4")
    with pytest.raises(ValueError) as e:
        escape(re.match("\\4", ""))

# Generated at 2022-06-23 15:43:03.422807
# Unit test for function evalString
def test_evalString():
    # Basic test
    assert evalString('"\\"hello\\"\n"') == '"hello"\n'
    # evalString can also handle single quotes
    assert evalString("'\\'hello\\'\n'") == "'hello'\n"
    # The string must be enclosed in quotes
    try:
        evalString('"\\"hello\\"\n')
    except ValueError:
        pass
    else:
        raise Exception("Should have raised a ValueError")
    # Test octal escapes
    assert evalString('"\\101\\057\\122\\x78"') == "A/Rx"
    # Test hexadecimal escapes with 1 digit
    assert evalString('"\\x71\\x72\\x67"') == "qrg"
    # Test hexadecimal escapes with 2 digits

# Generated at 2022-06-23 15:43:04.025852
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:04.622779
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:13.067402
# Unit test for function escape
def test_escape():
    import pytest
    with pytest.raises(ValueError):
        escape(re.match(r'\\x', ''))

    assert escape(re.match(r"\\x", "\\xff")) == 'ÿ'
    assert escape(re.match(r"\\x", "\\xAA")) == 'ª'
    assert escape(re.match(r"\\x", "\\x1a")) == '\x1a'
    assert escape(re.match(r"\\x", "\\x2")) == '\x02'
    assert escape(re.match(r"\\x", "\\x0")) == '\x00'
    assert escape(re.match(r"\\x", "\\x0b")) == '\x0b'


# Generated at 2022-06-23 15:43:13.808588
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:43:23.430520
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\a", r"\a")) == "\a"
    assert escape(re.match("\\b", r"\b")) == "\b"
    assert escape(re.match("\\f", r"\f")) == "\f"
    assert escape(re.match("\\n", r"\n")) == "\n"
    assert escape(re.match("\\r", r"\r")) == "\r"
    assert escape(re.match("\\t", r"\t")) == "\t"
    assert escape(re.match("\\v", r"\v")) == "\v"
    assert escape(re.match("\\'", r"\'")) == "'"
    assert escape(re.match('\\"', r'\"')) == '"'

# Generated at 2022-06-23 15:43:33.554771
# Unit test for function evalString
def test_evalString():
    assert evalString("'''abc'''") == "abc"
    assert evalString("'''a\\'bc'") == "a'bc"
    assert evalString("'''a\\\'bc'''") == "a\'bc"
    assert evalString("'''a\\\'b\\nc'''") == "a\'b\nc"
    assert evalString("'''\\x61bc'''") == "abc"
    assert evalString("'''abc\\x20def'''") == "abc def"
    assert evalString("'''abc\\x20def\\x20ghi'''") == "abc def ghi"
    assert evalString("'''\\x61bc\\x20def\\x20ghi'''") == "abc def ghi"

# Generated at 2022-06-23 15:43:34.666295
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:43:39.640576
# Unit test for function test
def test_test():
    import StringIO
    import sys
    f = StringIO.StringIO()
    temp = sys.stdout
    sys.stdout = f
    test()
    sys.stdout = temp
    assert f.getvalue() == ""

# Generated at 2022-06-23 15:43:40.710177
# Unit test for function test
def test_test():
    test()
    return True


# Generated at 2022-06-23 15:43:41.451233
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:42.055945
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:50.215326
# Unit test for function escape
def test_escape():
    def assert_e(expected, string):
        assert escape(re.match(r"\\\w", string)) == expected

    assert_e("\a", "\\a")
    assert_e("\b", "\\b")
    assert_e("\f", "\\f")
    assert_e("\n", "\\n")
    assert_e("\r", "\\r")
    assert_e("\t", "\\t")
    assert_e("\v", "\\v")
    assert_e("'", "\\'")
    assert_e('"', '\\"')
    assert_e("\\", "\\\\")

    assert_e("\x07", "\\x07")
    assert_e("\x07", "\\x07")

# Generated at 2022-06-23 15:44:00.194760
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString("'b'") == "b"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\141"') == "a"
    assert evalString('"\\x39"') == "9"
    assert evalString('"\\039"') == "9"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\"') == '"'
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\""') == '"'
    assert evalString('"""\\"""') == '"'
    assert evalString('"\\""""') == '"'
    assert evalString('"\\""""""') == '"'
    assert evalString('"x\\y"')

# Generated at 2022-06-23 15:44:10.297805
# Unit test for function evalString
def test_evalString():
    assert evalString(r'\"') == '"'
    assert evalString(r"\'") == "'"
    assert evalString(r"\x11") == '\x11'
    assert evalString(r"\x00") == '\x00'
    assert evalString(r'\" \n \x11 \x00') == '" \n \x11 \x00'
    assert evalString(r"\' \n \x11 \x00") == "' \n \x11 \x00"
    assert evalString(r'" \\ \r \n \" ') == '\\ \r \n "'
    assert evalString(r"' \\ \r \n \' ") == r'\\ \r \n \' '
    assert evalString(r'" \11 \1111 \11 "') == '\t \t \t '
    assert eval

# Generated at 2022-06-23 15:44:20.092888
# Unit test for function evalString
def test_evalString():
    def test_string(s):
        e = evalString(s)
        assert e == eval(s)
        assert repr(e) == s

    test_string("'abc'")
    test_string('"abc"')
    test_string("'\\''")
    test_string('"\\""')
    test_string('"\\a\\b\\f\\n\\r\\t\\v"')
    test_string('"\\x61\\x62\\x63"')
    test_string('"\\0777"')
    test_string('"""abc\\x77"""')
    test_string("'abc\\x77'")
    test_string('"abc\\x77"')

# Generated at 2022-06-23 15:44:21.336979
# Unit test for function test
def test_test():
    assert True

# Generated at 2022-06-23 15:44:24.809457
# Unit test for function escape
def test_escape():
    assert escape('\\x20') == ' '
    assert escape('\\n') == '\n'
    assert escape('\\x80') == '\x80'


# Generated at 2022-06-23 15:44:27.402042
# Unit test for function escape
def test_escape():
    assert escape('"abc"') == 'abc'
    assert escape('"abc"') != 'Abc'
    assert escape('"abc"') != '123'

# Generated at 2022-06-23 15:44:28.472644
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:38.717811
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41",'\\x41')) == 'A'
    assert escape(re.match(r"\\401",'\\401')) == '\x01'
    assert escape(re.match(r"\\a",'\\a'))=='\x07'
    assert escape(re.match(r"\\n",'\\n'))=='\n'
    assert escape(re.match(r"\\t",'\\t'))=='\t'
    try:
        escape(re.match(r"\\x4",'\\x4'))
        raise AssertionError("Should have raised ValueError")
    except ValueError:
        pass

# Generated at 2022-06-23 15:44:39.362277
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:43.378668
# Unit test for function evalString
def test_evalString():
    # Only the printable ASCII characters
    for c in range(32, 128):
        s = chr(c)
        assert evalString(repr(s)) == s

    # A hard case
    s = evalString(r"'\x5c\x5c'")
    assert s == "\\", repr(s)

# Generated at 2022-06-23 15:44:55.684837
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\", "\\")) == "\\"
    assert escape(re.match(r"\\", "\\a")) == "\a"
    assert escape(re.match(r"\\", "\\b")) == "\b"
    assert escape(re.match(r"\\", "\\f")) == "\f"
    assert escape(re.match(r"\\", "\\n")) == "\n"
    assert escape(re.match(r"\\", "\\r")) == "\r"
    assert escape(re.match(r"\\", "\\t")) == "\t"
    assert escape(re.match(r"\\", "\\v")) == "\v"
    assert escape(re.match(r"\\", "\\'")) == "\'"

# Generated at 2022-06-23 15:44:56.996634
# Unit test for function escape
def test_escape():
    assert escape(r"\$") == r"$"


# Generated at 2022-06-23 15:45:07.399720
# Unit test for function escape
def test_escape():
    assert escape("\a") == "\\x07"
    assert escape("\b") == "\\x08"
    assert escape("\f") == "\\x0c"
    assert escape("\n") == "\\n"
    assert escape("\r") == "\\r"
    assert escape("\t") == "\\t"
    assert escape("\v") == "\\x0b"
    assert escape("'") == "\\'"
    assert escape("\''") == "\\''"
    assert escape("\"") == "\\\""
    assert escape("\"\"") == "\\\"\""
    assert escape("\\") == "\\\\"
    assert escape("\\\\") == "\\\\\\\\"

    assert escape("\x11") == "\\x11"
    assert escape("\x12") == "\\x12"


# Generated at 2022-06-23 15:45:17.744859
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\b"') == "\b"
    assert evalString("'\\b'") == "\b"
    assert evalString('"\\r"') == "\r"
    assert evalString("'\\r'") == "\r"
    assert evalString('"\\t"') == "\t"
    assert evalString("'\\t'") == "\t"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\0"') == "\0"
    assert evalString("'\\0'") == "\0"
    assert evalString('"\\7"') == "\a"

# Generated at 2022-06-23 15:45:18.224248
# Unit test for function test
def test_test():
    test()
    assert True

# Generated at 2022-06-23 15:45:29.664960
# Unit test for function test
def test_test():
    import io
    import sys
    import unittest
    import unittest.mock

    class MockIO:
        def __init__(self, data: Text) -> None:
            self.data = data
            self.pos = 0

        def read(self, size: int) -> Text:
            result = self.data[self.pos : self.pos + size]
            self.pos += size
            return result

    class Test(unittest.TestCase):
        def setUp(self) -> None:
            self.test = test

        def test_test(self) -> None:
            # Test normal conditions
            output = io.StringIO()
            with unittest.mock.patch.object(sys, "stderr", output):
                self.test()

# Generated at 2022-06-23 15:45:31.479515
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == "a"

# Generated at 2022-06-23 15:45:36.408612
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", s))
        if e != c:
            print(i, c, s, e)


# Generated at 2022-06-23 15:45:45.713085
# Unit test for function evalString
def test_evalString():
    assert "foo" == evalString('"foo"')
    assert "foo" == evalString("'foo'")
    assert "fo'o" == evalString('"fo\'o"')
    assert "fo'o" == evalString('\'fo\\\'o\'')
    assert "foo" == evalString("'f\\141o'")
    assert "foo" == evalString("'f\\x66o'")
    assert "foo" == evalString('"f\\o141o"')
    assert "foo" == evalString('"f\\o66o"')
    assert "'" == evalString("'\\''")
    assert '"' == evalString('"\\""')
    assert "foo" == evalString('"""fo\\o"""')


# Generated at 2022-06-23 15:45:51.594676
# Unit test for function escape
def test_escape():
    assert escape("\\a")[0] == '\a'
    assert escape("\\t")[0] == '\t'
    assert escape("\\v")[0] == '\v'
    assert escape("\\u1234")[0] == '\\'
    assert escape("\\u123")[0] == '\\'
    assert escape("\\u")[0] == '\\'
    assert escape("\\u1")[0] == '\\'

# Generated at 2022-06-23 15:46:03.513231
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r"\\\"", "\\\"")) == '"'
    assert escape(re.match(r"\\\\", "\\\\")) == "\\"
    assert escape(re.match(r"\\\n", "\\\n")) == "\n"
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x7f", "\\x7f")) == "\x7f"


# Generated at 2022-06-23 15:46:14.784684
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\x(.*)$", "\\x12")) == "\x12"
    assert escape(re.search(r"\\x(.*)$", "\\xg2")) == "\\xg2"
    assert escape(re.search(r"\\(.*)$", "\\x12")) == "\\x12"
    assert escape(re.search(r"\\(.*)$", "\\g2")) == "\\g2"
    assert escape(re.search(r"\\x(.*)$", "\\x1g2")) == "\\x1g2"
    assert escape(re.search(r"\\x(.*)$", "\\xgg2")) == "\\xgg2"

# Generated at 2022-06-23 15:46:15.270987
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:15.780900
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:23.804191
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'Hello\040World'") == "Hello World"
    assert evalString(r'"Hello\040World"') == "Hello World"
    assert evalString(r"'Hello\\World'") == r"Hello\World"
    assert evalString(r'"Hello\\World"') == r"Hello\World"
    assert evalString(r"'Hello\aWorld'") == "Hello\x07World"
    assert evalString(r'"Hello\aWorld"') == "Hello\x07World"
    assert evalString(r"'Hello\x07World'") == "Hello\x07World"
    assert evalString(r'"Hello\x07World"') == "Hello\x07World"
    assert evalString(r"'Hello\07World'") == "Hello\x07World"

# Generated at 2022-06-23 15:46:32.639592
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == "foo"
    assert evalString('"foo"') == "foo"
    assert evalString("'foo\\nbar\\tbaz'") == "foo\nbar\tbaz"
    assert evalString('"foo\\nbar\\tbaz"') == "foo\nbar\tbaz"
    assert evalString("'fo\\x7ao\\x41bar'") == "foz\x41bar"
    assert evalString("'fo\\x7ao\\x41bar'") == "foz\x41bar"
    assert evalString("'foo\\101bar'") == "fooAbar"
    assert evalString("'foo\\101bar'") == "fooAbar"
    assert evalString("'foo\\xbaz'") == "foo\xbaz"
    assert eval

# Generated at 2022-06-23 15:46:41.922939
# Unit test for function evalString
def test_evalString():
    # Test string with special characters unescaped
    assert evalString('"\x7F\xFF"') == "\x7F\xFF"
    assert evalString("'\x7F\xFF'") == "\x7F\xFF"
    # Test strings with special characters escaped
    assert evalString(r'"\x7F\xFF"') == "\x7F\xFF"
    assert evalString(r"'\x7F\xFF'") == "\x7F\xFF"
    # Test strings with single quotes
    assert evalString("'\''") == "'"
    assert evalString('"\'"') == "'"
    # Test strings with double quotes
    assert evalString('"\'"') == "'"
    assert evalString('"\'"') == "'"

# Generated at 2022-06-23 15:46:43.621214
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\\x7f', '\x7f')) == '\x7f'


# Generated at 2022-06-23 15:46:54.376425
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\x00', '\\x00')) == chr(0)
    assert escape(re.match(r'\\x7f', '\\x7f')) == chr(0x7f)
    assert escape(re.match(r'\\x80', '\\x80')) == chr(0x80)
    assert escape(re.match(r'\\xff', '\\xff')) == chr(0xff)
    assert escape(re.match(r'\\000', '\\000')) == chr(0)
    assert escape(re.match(r'\\127', '\\127')) == chr(0x7f)
    assert escape(re.match(r'\\200', '\\200')) == chr(0x80)

# Generated at 2022-06-23 15:47:03.288871
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"abcd"') == "abcd"
    assert evalString('"\""') == "\""
    assert evalString('"\\"') == "\\"
    assert evalString("'abcd'") == "abcd"
    assert evalString("'\\''") == "'"
    assert evalString("'\"'") == '"'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\011\\012\\013\\014\\015\\016\\017'") == "\t\n\v\f\r\x0e\x0f"
    assert evalString("'\\0'") == "\0"

# Generated at 2022-06-23 15:47:13.685053
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "\'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\x41") == "A"
    assert escape("\\x4A") == "J"
    assert escape("\\x4z") == "z"
    assert escape("\\x4Z") == "Z"
    assert escape("\\xZZ") == "ZZ"
    assert escape("\\x1") == "1"
   

# Generated at 2022-06-23 15:47:21.084023
# Unit test for function evalString
def test_evalString():
    assert evalString('"a\tb"') == 'a\tb'
    assert evalString('"a\tb"') == evalString('"a\\tb"')
    assert evalString('"\\0\\0"') == '\x00\x00'
    assert evalString('"\\0\\0"') == evalString('"\\x00\\x00"')
    assert evalString('"\\0\\0"') == evalString('"\\000\\000"')

# Generated at 2022-06-23 15:47:30.353542
# Unit test for function test
def test_test():
    import sys
    import textwrap
    import io
    from test.support import captured_stdout

    def verify_output(output_bytes: bytes, expected_output: str) -> None:
        output = output_bytes.decode(sys.stdout.encoding)
        assert output == expected_output, (
            "unexpected output:\n"
            "---\n"
            "{}\n"
            "---\n"
            "expected:\n"
            "---\n"
            "{}\n"
            "---"
        ).format(output, expected_output)

    # From the Python 3 documentation

# Generated at 2022-06-23 15:47:32.606189
# Unit test for function test
def test_test():
    test()
    # Check that we covered all the cases.
    assert test.__self__.coverage[0] == 256


# Generated at 2022-06-23 15:47:37.163834
# Unit test for function evalString
def test_evalString():
    string = """
    "a"
    'a'
    ""
    ""
    '''a'''
    """
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString("'''a'''") == "a"
    assert evalString(string[2:]) == "a"

# Generated at 2022-06-23 15:47:38.020969
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:48.902438
# Unit test for function evalString
def test_evalString():

    def check(source, expected_result):
        # This will also get us coverage on the error handlers.
        result = evalString(source)
        assert result == expected_result, (
            "expected %s, got %s" % (repr(expected_result), repr(result))
        )

    check(r"'abc' + 'def'", "abcdef")
    check(r"'abc\"def'", 'abc"def')
    check(r'\'abc\\def\'', r"abc\def")
    check(r"'abc\ndef'", "abc\ndef")
    check(r'"abc\ndef"', "abc\ndef")
    check(r"'abc\x20def'", "abc def")

# Generated at 2022-06-23 15:47:49.881170
# Unit test for function test
def test_test():
    test()
    return None



# Generated at 2022-06-23 15:48:01.566278
# Unit test for function test
def test_test():
    import sys
    import test.test_literal_eval

    # Issue #13771
    # evalString(text) is not necessarily equivalent to eval(text)
    if sys.version_info[:2] == (3, 4):
        expected_error = "unexpected EOF while parsing"
    elif sys.version_info[:2] < (3, 7):
        expected_error = "unexpected EOF while parsing (<string>, line 1)"
    else:
        expected_error = "unexpected EOF while parsing (<string>)"

    def raises_expected_error(s: Text) -> None:
        try:
            test.test_literal_eval.evalString(s)
        except SyntaxError as err:
            assert str(err) == expected_error, repr(str(err))

# Generated at 2022-06-23 15:48:02.854903
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:13.048395
# Unit test for function escape
def test_escape():
    "Test the escape function"

    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\\t", r"\t")) == "\t"
    assert escape

# Generated at 2022-06-23 15:48:25.664449
# Unit test for function escape
def test_escape():
    import ast

    # simple escapes
    assert escape(re.match(r"\\n", "\\n")) == '\n'
    assert escape(re.match(r"\\(.|$)", "\\n")) == '\n'
    assert escape(re.match(r"\\(.|$)", "\\x")) == 'x'
    assert escape(re.match(r"\\(.|$)", "A")) == 'A'

    # octal escapes
    assert escape(re.match(r"\\0", "\\0")) == '\0'
    assert escape(re.match(r"\\0", "\\01")) == '\1'
    assert escape(re.match(r"\\0", "\\011")) == '\t'
    assert escape(re.match(r"\\0", "\\012"))

# Generated at 2022-06-23 15:48:33.599107
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello'") == "hello"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\x61\\x62\\x66\\x6e\\x72\\x74\\x76'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\071\\072\\073\\074\\075\\076\\077'") == "!\"#$%&'"

# Generated at 2022-06-23 15:48:35.767735
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        assert False, "test() failed with exception: {}".format(e)

# Generated at 2022-06-23 15:48:36.305454
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:43.917389
# Unit test for function evalString

# Generated at 2022-06-23 15:48:45.096076
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:49.226791
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x([0-9A-Fa-f]{2})", "\\x41")) == "A"
    assert escape(re.match(r"\\([0-7]{1,3})", "\\41")) == "A"

# Generated at 2022-06-23 15:49:00.037863
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == 'foo'
    assert evalString("'foo\\n'") == 'foo\n'
    assert evalString("'foo\\nbar'") == 'foo\nbar'
    assert evalString("'\\n'") == '\n'
    assert evalString("'\\n123'") == '\n123'
    assert evalString("'\\\\'") == '\\'
    assert evalString("'\\''") == "'"
    assert evalString("'\\x7f'") == chr(0x7f)
    assert evalString("'\\177'") == chr(0o177)
    assert evalString("'\\0177'") == chr(0o177)
    assert evalString("'\\400'") == chr(0o400)

# Generated at 2022-06-23 15:49:01.839988
# Unit test for function test
def test_test():
    result = eval(test.__code__)
    assert result is None

# Generated at 2022-06-23 15:49:06.278205
# Unit test for function escape
def test_escape():
    assert("\r\n" == escape(re.search("\\r\\n", "\\r\\n")))
    assert("\x08" == escape(re.search("\\x08", "\\x08")))
    assert("\x08" == escape(re.search("\\x08", "\x08")))

# Generated at 2022-06-23 15:49:12.941611
# Unit test for function evalString
def test_evalString():
    import unittest

    class TestEvalString(unittest.TestCase):

        def test_bare(self):
            self.assertEqual(evalString(r"'abc'"), "abc")

        def test_escapes(self):
            self.assertEqual(evalString(r"'\b\f\n\r\t\v\''"), "\b\f\n\r\t\v'")

        def test_quotes(self):
            self.assertEqual(evalString(r"'abc' + 'def'"), "abcdef")
            self.assertEqual(evalString(r"'abc" + "'def'"), "abcdef")

        def test_raw(self):
            self.assertEqual(evalString(r"'abc\def'"), "abc\\def")

# Generated at 2022-06-23 15:49:15.245922
# Unit test for function test
def test_test():
    try:
        test()
    except TypeError as e:
        print("test failed with TypeError")
        print(e)
        raise
    except ValueError as e:
        print("test failed with ValueError")
        print(e)
        raise
    except Exception as e:
        print("test failed with exception")
        print(e)
        raise
    print("test passed")

# Generated at 2022-06-23 15:49:24.361858
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(x.{0,2}|[0-7]{1,3})", "\\x012")) == "\x01"
    assert escape(re.match(r"\\(x.{0,2}|[0-7]{1,3})", "\\x12")) == "\x12"
    assert escape(re.match(r"\\(x.{0,2}|[0-7]{1,3})", "\\12")) == "\n"
    assert escape(re.match(r"\\(x.{0,2}|[0-7]{1,3})", "\\78")) == "x"
    assert escape(re.match(r"\\(x.{0,2}|[0-7]{1,3})", "\\21"))

# Generated at 2022-06-23 15:49:35.803466
# Unit test for function evalString
def test_evalString():

    class floatlist(list):
        def append(self, item):
            list.append(self, float(item))

    assert evalString("") == ""
    assert evalString("'hello'") == "hello"
    assert evalString("'hello\\nworld'") == "hello\nworld"
    assert evalString("'hello\\x65llo'") == "helloello"
    assert evalString("'hello\\200ello'") == "hello\200ello"
    assert evalString("'hello\\x65\\x6c\\x6c\\x6f'") == "helloello"
    assert evalString("'hello\\235\\223\\224\\225'") == "hello\235\223\224\225"
    assert evalString("'hello\\x6c\\x6f'") == "hellolo"

# Generated at 2022-06-23 15:49:37.070026
# Unit test for function test
def test_test():
    test()
    assert True

# Generated at 2022-06-23 15:49:43.935824
# Unit test for function evalString
def test_evalString():
    assert evalString("'ab'") == "ab"
    assert evalString("'ab'[:2]") == "ab"
    assert evalString("'ab'[:1]") == "a"
    assert evalString("'ab'[:]") == "ab"
    assert evalString("'ab'[::2]") == "a"
    assert evalString("'ab'[::-2]") == "b"
    assert evalString("'ab'[::-1]") == "ba"
    assert evalString("'ab'[0:100]") == "ab"
    assert evalString("'ab'[-1:]") == "b"
    assert evalString("'ab'[-2:]") == "ab"
    assert evalString("'ab'[-2:1]") == ""
    assert evalString

# Generated at 2022-06-23 15:49:48.467139
# Unit test for function evalString
def test_evalString():
    # From the Python docs:
    assert evalString("'hi'") == "hi"
    assert evalString("'\\x63'") == "c"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\n\\n'") == "\n\n"
    assert evalString("'\\t\\n\\n'") == "\t\n\n"
    assert evalString("'\\n \\n'") == "\n \n"
    assert evalString("'\\'\\''") == "'"
    assert evalString('"\\""') == '"'
    # Some tests
    assert evalString("'\\n\\r'") == "\n\r"
    assert evalString("'\\a\\b'") == "\a\b"

# Generated at 2022-06-23 15:49:59.879459
# Unit test for function test
def test_test():
    import types

    name = "test"
    assert isinstance(name, str), "name must be a string"
    assert type(test) not in (types.FunctionType, types.BuiltinFunctionType), "test must not be a function already"

    test_globals = dict(globals())
    test_globals["name"] = name
    test_globals["test"] = test

    # no need to wrap the call to exec() in a try-except block, since functions
    # already have __name__, __globals__, __doc__ and __module__
    # NOTE: functions are also of type types.CodeType

# Generated at 2022-06-23 15:50:07.154831
# Unit test for function test
def test_test():
    example = (
        "testing evalString\n"
        + "Received: "
        + repr(
            evalString(
                '"\\e\\"\\"\\e\\"\\""\n'
                + '\\e\\"\\"\\e\\"\\""\n'
                + '"\\e\\"\\"\\e\\"\\""\n'
            )
        )
        + "\n"
    )
    success = evalString(
        '"\\e\\"\\"\\e\\"\\""\n'
        + '\\e\\"\\"\\e\\"\\""\n'
        + '"\\e\\"\\"\\e\\"\\""\n'
    )
    assert example == success

# Generated at 2022-06-23 15:50:19.353635
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x(..)", "\\x41\\x42")) == "AB"
    assert escape(re.match(r"\\x(..)", "\\x41\\x42\\x43")) == "AB"
    assert escape(re.match(r"\\x(.)", "\\x41\\x42")) == "A"
    assert escape(re.match(r"\\x(\d)", "\\x41\\x42")) == "A"
    assert escape(re.match(r"\\(\d{1,3})", "\\41\\42")) == "AB"
    assert escape(re.match(r"\\(\d{1,3})", "\\41\\42\\43")) == "AB"

# Generated at 2022-06-23 15:50:19.900883
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:50:28.175312
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"spam"') == "spam"
    assert evalString("'spam'") == "spam"
    assert evalString('"s\\"\\\'pam"') == 's"\'pam'
    assert evalString("'s\\'pam'") == "s'pam"
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r'"\\"') == "\\"
    assert evalString(r"'\\'") == "\\"
    # Note that single quotes must be protected by backslashes in
    # single-quoted string literals, even though the result has no
    # backslashes!