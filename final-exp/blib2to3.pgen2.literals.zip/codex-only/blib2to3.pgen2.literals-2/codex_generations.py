

# Generated at 2022-06-23 15:40:43.257106
# Unit test for function evalString
def test_evalString():
    # cases from docstring
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'a\\nb'") == "a\nb"
    assert evalString('"a\\nb"') == "a\nb"
    assert evalString("r'a\\nb'") == "a\\nb"
    assert evalString('r"a\\nb"') == "a\\nb"
    assert evalString("u'\\u1234'") == "ሴ"
    assert evalString('u"\\u1234"') == "ሴ"
    assert evalString("u'a\\xbcdef'") == "a\xbcdef"
    assert evalString('u"a\\xbcdef"') == "a\xbcdef"
    assert evalString

# Generated at 2022-06-23 15:40:51.659330
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\\"') == '"'
    assert escape('\\\\') == '\\'
    assert escape('\\x10') == '\x10'
    assert escape('\\07') == '\x07'
    assert escape('\\077') == '\x3f'

# Generated at 2022-06-23 15:40:57.945034
# Unit test for function escape
def test_escape():
    assert escape('\\x01') == '\x01'
    assert escape('\\00') == '\0'
    assert escape('\\123') == '{'
    assert escape('\\a') == '\x07'
    assert escape('\\t') == '\t'
    assert escape('\\n') == '\n'

# Generated at 2022-06-23 15:41:09.736074
# Unit test for function escape
def test_escape():
    from hypothesis import given
    from hypothesis.strategies import samplers, text

    c_strategies = text(min_size=1, max_size=1)
    esc_strategies = c_strategies.filter(lambda s: s in simple_escapes)
    hex_strategies = text(min_size=1, alphabet="0123456789abcdefABCDEF")
    oct_strategies = text(min_size=1, alphabet="01234567")

    @given(esc_strategies)
    def test_simple_escapes(s):
        escaped_char = escape(Match(0, 1, (s, s), ((0, 1), (0, 1))))
        assert escaped_char == simple_escapes[s]


# Generated at 2022-06-23 15:41:22.479384
# Unit test for function evalString
def test_evalString():
    s = "''"
    e = evalString(s)
    assert e == "", (s, e)
    s = '""'
    e = evalString(s)
    assert e == "", (s, e)
    s = "'''"
    e = evalString(s)
    assert e == "", (s, e)
    s = '"""'
    e = evalString(s)
    assert e == "", (s, e)
    s = "'''a'''"
    e = evalString(s)
    assert e == "a", (s, e)
    s = '"""a"""'
    e = evalString(s)
    assert e == "a", (s, e)
    s = "''\"''"
    e = evalString(s)

# Generated at 2022-06-23 15:41:32.352903
# Unit test for function escape
def test_escape():
    def _test(value, expected):
        result = escape(re.match("\\" + value, value))
        assert result == expected, "Got %r, expected %r" % (result, expected)

    _test("a", "\a")
    _test("b", "\b")
    _test("f", "\f")
    _test("n", "\n")
    _test("r", "\r")
    _test("t", "\t")
    _test("v", "\v")
    _test("'", "\'")
    _test('"', '"')
    _test("\\", "\\")
    _test("x0D", "\r")  # \r is ASCII 13
    _test("07", "\a")   # \a is ASCII 7


# Generated at 2022-06-23 15:41:36.372512
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\\x07"
    assert escape("\\n") == "\\x0a"
    assert escape("\\v") == "\\x0b"
    assert escape("\\r") == "\\x0d"
    assert escape("\\t") == "\\x09"
    assert escape("\\b") == "\\x08"
    assert escape("\\f") == "\\x0c"



# Generated at 2022-06-23 15:41:37.304324
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:37.898663
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:43.577813
# Unit test for function escape
def test_escape():
    # Raises error on invalid hex
    # Leads to ValueError: invalid escape
    try:
        assert escape(re.search("\\xg", "\\xg"))
    except ValueError as e:
        assert "invalid hex string escape" in str(e)

# Generated at 2022-06-23 15:41:54.112911
# Unit test for function escape
def test_escape():
    s = "\\a"
    assert escape(re.match('\\\\(.)', s)) == '\a'
    s = "\\b"
    assert escape(re.match('\\\\(.)', s)) == '\b'
    s = "\\f"
    assert escape(re.match('\\\\(.)', s)) == '\f'
    s = "\\n"
    assert escape(re.match('\\\\(.)', s)) == '\n'
    s = "\\r"
    assert escape(re.match('\\\\(.)', s)) == '\r'
    s = "\\t"
    assert escape(re.match('\\\\(.)', s)) == '\t'
    s = "\\v"
    assert escape(re.match('\\\\(.)', s)) == '\x0b'
   

# Generated at 2022-06-23 15:41:54.433343
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:01.497779
# Unit test for function evalString
def test_evalString():
    testeql(evalString('''"abc"'''), 'abc')
    testeql(evalString('''"ab'c"'''), "ab'c")
    testeql(evalString('''"ab\\'c"'''), "ab'c")
    testeql(evalString('''"ab\\\\c"'''), 'ab\\c')
    testeql(evalString('''"\\141\\142\\143"'''), 'abc')
    testeql(evalString('''"\\x61\\x62\\x63"'''), 'abc')
    testeql(evalString('''"\\1\\2\\3"'''), "ab'c")
    testeql(evalString(''''''), '')
    testeql(evalString('''''a'''), "a")

# Generated at 2022-06-23 15:42:03.262605
# Unit test for function test
def test_test():
    try:
        test()
        raise Exception
    except UnboundLocalError:
        pass

# Generated at 2022-06-23 15:42:13.900112
# Unit test for function evalString
def test_evalString():
    for s in ["'abc'", '"abc"']:
        assert evalString(s) == "abc"
    for c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-+={[}]:;'<,>.?/":
        assert evalString(repr(c)) == c
    for i in range(256):
        assert evalString(repr(chr(i))) == chr(i)
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r'"\"\'') == '"\''
    assert evalString(r"'\'\"'") == '\'\"'

# Generated at 2022-06-23 15:42:18.393247
# Unit test for function test
def test_test():
    # Since this is a simple test of the evalString function, and since
    # it uses a for loop to do the testing, it is impossible to prove that
    # the function does what it says without duplicating the logic in test()
    # here. This test also asserts that the function does not raise any
    # exceptions, which it should not.
    test()
    # Make sure that our custom test_test() is run
    assert True

# Generated at 2022-06-23 15:42:24.150320
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ''
    assert evalString("'a'") == 'a'
    assert evalString("'\\\\'") == '\\'
    assert evalString("'\\''") == "'"
    assert evalString("'\\n'") == '\n'
    assert evalString("r'\\n'") == r'\n'
    assert evalString("r'\\\n'") == r'\\\n'
    assert evalString("'''a'b'c'''") == "a'b'c"
    assert evalString("'''\\\n'''") == ''
    assert evalString('"""\n"""') == ''
    assert evalString("'\\x41'") == 'A'
    assert evalString("'\\x4a'") == 'J'

# Generated at 2022-06-23 15:42:25.151925
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:42:35.656213
# Unit test for function evalString
def test_evalString():
    assert evalString('"abcd"') == "abcd"
    assert evalString('"a\"b"') == "a\"b"
    assert evalString('"a\\b"') == "a\\b"
    assert evalString('"a\\\\b"') == "a\\b"
    assert evalString("'ab'") == "ab"
    assert evalString("'a\\'b'") == "a'b"
    assert evalString("'a\\\"b'") == "a\"b"
    assert evalString("'a\\\\b'") == "a\\b"
    assert evalString("'''abcd'") == "abcd'"
    assert evalString("'''abc'\\'''") == "abc'"
    assert evalString("'''a\\'bc'\\'''") == "a'bc'"
   

# Generated at 2022-06-23 15:42:41.402176
# Unit test for function escape
def test_escape():
    assert escape('\\a') == "\a"
    assert escape('\\b') == "\b"
    assert escape('\\f') == "\f"
    assert escape('\\n') == "\n"
    assert escape('\\r') == "\r"
    assert escape('\\t') == "\t"
    assert escape('\\v') == "\v"
    assert escape('\\"') == '"'
    assert escape("\\'") == "'"
    assert escape('\\\\') == "\\"


# Generated at 2022-06-23 15:42:51.300798
# Unit test for function evalString
def test_evalString():
    l = [
        ('"string"', "string"),
        ('"string\\n"', "string\n"),
        ('"string\\t"', "string\t"),
        ('"string\\r"', "string\r"),
        ('"string\\xaa"', "string\xaa"),
        ('"string\\077"', "string\x3f"),
        ('"string\\x1"', "string\x01"),
        ('"\\"string\\""', '"string"'),
        ('"\'string\'"', "'string'"),
        ('"string\\\\"', "string\\")
    ]
    for s, r in l:
        assert evalString(s) == r

# This is used in _string.ascii_escape_unicode()

# Generated at 2022-06-23 15:43:03.322710
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a', '\\a'
    assert escape('\\b') == '\b', '\\b'
    assert escape('\\f') == '\f', '\\f'
    assert escape('\\n') == '\n', '\\n'
    assert escape('\\r') == '\r', '\\r'
    assert escape('\\t') == '\t', '\\t'
    assert escape('\\v') == '\v', '\\v'
    assert escape('\\\'') == '\'', '\\\''
    assert escape('\\"') == '"', '\\"'
    assert escape('\\\\') == '\\', '\\\\'
    try:
        escape('\\x')
    except ValueError:
        pass
    else:
        assert False, '\\x'
   

# Generated at 2022-06-23 15:43:12.281072
# Unit test for function escape
def test_escape():

    # Test simple escapes
    assert escape(re.search(r"\\a","You are the anchor to my escape")) == "\a"
    assert escape(re.search(r"\\b","You are the anchor to my escape")) == "\b"
    assert escape(re.search(r"\\f","You are the anchor to my escape")) == "\f"
    assert escape(re.search(r"\\n","You are the anchor to my escape")) == "\n"
    assert escape(re.search(r"\\r","You are the anchor to my escape")) == "\r"
    assert escape(re.search(r"\\t","You are the anchor to my escape")) == "\t"
    assert escape(re.search(r"\\v","You are the anchor to my escape")) == "\v"

# Generated at 2022-06-23 15:43:16.755041
# Unit test for function test
def test_test():
    try:
        test()
    except BaseException:
        # We expect a ValueError on invalid escapes, but those can't
        # be triggered in current Python.
        raise AssertionError("unexpected exception from test()")

# Generated at 2022-06-23 15:43:17.367782
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:19.702069
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError:
        print("test failed")
    else:
        print("test passed")

# Generated at 2022-06-23 15:43:25.944083
# Unit test for function escape
def test_escape():
    assert escape('\'') == "'"
    assert escape('\"') == '"'
    assert escape('\\') == '\\'
    assert escape('\a') == '\a'
    assert escape('\b') == '\b'
    assert escape('\f') == '\f'
    assert escape('\n') == '\n'
    assert escape('\r') == '\r'
    assert escape('\t') == '\t'
    assert escape('\v') == '\v'
    assert escape('\x01') == '\x01'
    assert escape('\x1f') == '\x1f'
    assert escape('\x7f') == '\x7f'
    assert escape('\xFF') == '\xFF'


# Generated at 2022-06-23 15:43:27.338518
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert False, "unexpected exception"

# Generated at 2022-06-23 15:43:35.866658
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello'") == "hello"
    assert evalString('"hello"') == "hello"
    assert evalString("'''hello'''") == "hello"
    assert evalString('"""hello"""') == "hello"
    assert evalString("'*'") == "*"
    assert evalString("'\\xab'") == chr(0xab)
    assert evalString("'\\xFF'") == chr(0xFF)

# Generated at 2022-06-23 15:43:47.308563
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\'\"'") == '\'"'
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\011\\011'") == "\t\t"
    assert evalString("'\\x61\\x62'") == "ab"
    assert evalString("'\\x041\\042'") == "!\""
    assert evalString("'\\x0!\\042'") == "\x00!\""
    assert evalString("'\\x0A\\42'") == "\nB"
    assert evalString("'\\x0A\\x42'") == "\nB"

# Generated at 2022-06-23 15:43:58.044912
# Unit test for function escape
def test_escape():
    '''Test for escape function'''
    assert escape(re.search(r"\\a", "\a")) == "\a"
    assert escape(re.search(r"\\t", "\t")) == "\t"
    assert escape(re.search(r"\\v", "\v")) == "\v"
    assert escape(re.search(r"\\'", "\'")) == "\'"
    assert escape(re.search(r'\\"', '"')) == '"'
    assert escape(re.search(r"\\\\", "\\")) == "\\"
    assert escape(re.search(r"\\x0A", "\n")) == "\n"
    assert escape(re.search(r"\\xaa", chr(170))) == chr(170)

# Generated at 2022-06-23 15:44:01.043261
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        return False
    return True

# Generated at 2022-06-23 15:44:06.128754
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\u0061"') == 'a'
    assert evalString('"\\U00000061"') == 'a'
    assert evalString(r'"\n"') == '\n'
    assert evalString(r'"\011"') == '\t'

# Generated at 2022-06-23 15:44:06.658921
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:08.629863
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00\\n"') == "\x00\n"

# Generated at 2022-06-23 15:44:10.739050
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        print("Failed", e)
    else:
        print("OK")

# Generated at 2022-06-23 15:44:12.673742
# Unit test for function test
def test_test():
    """Tests for test()"""
    test()

# Generated at 2022-06-23 15:44:13.200449
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:14.590678
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert True

# Generated at 2022-06-23 15:44:23.223069
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\'")).encode('utf8') == "&apos;".encode('utf8')
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\x26")).encode('utf8') == "&".encode('utf8')

# Generated at 2022-06-23 15:44:33.495798
# Unit test for function escape
def test_escape():
    # test special cases
    assert escape(match("\\a")) == "\a"
    assert escape(match("\\b")) == "\b"
    assert escape(match("\\f")) == "\f"
    assert escape(match("\\n")) == "\n"
    assert escape(match("\\r")) == "\r"
    assert escape(match("\\t")) == "\t"
    assert escape(match("\\v")) == "\v"
    assert escape(match("\\'")) == "'"
    assert escape(match('\\"')) == '"'
    assert escape(match("\\\\")) == "\\"

    # test hex
    for i in range(256):
        c = chr(i)
        c_hex = c.encode("utf-8").hex()
        assert escape(match("\\x" + c_hex)) == c

# Generated at 2022-06-23 15:44:43.214281
# Unit test for function escape
def test_escape():
    from textwrap import dedent
    from unittest import TestCase

    class TestEscape(TestCase):
        def test_simple_escapes(self):
            for c, v in simple_escapes.items():
                expected = v
                actual = escape(dedent(f"""\
                    \\{c}
                """))
                self.assertEqual(expected, actual)

        def test_hex_escapes(self):
            for c in range(256):
                c = chr(c)
                expected = c
                actual = escape(dedent(f"""\
                    \\x{ord(c):02X}
                """))
                self.assertEqual(expected, actual)

        def test_octal_escapes(self):
            for c in range(256):
                c = chr(c)
               

# Generated at 2022-06-23 15:44:55.612289
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([0-7]{1,3})", "\\0")) == "\x00"
    assert escape(re.match(r"\\([0-7]{1,3})", "\\377")) == "\xff"
    assert escape(re.match(r"\\([0-7]{1,3})", "\\123")) == "\x01\x23"
    assert escape(re.match(r"\\([0-7]{1,3})", "\\40")) == " "
    assert escape(re.match(r"\\([0-7]{1,3})", "\\458")) == '\x15'
    assert escape(re.match(r"\\([0-7]{1,3})", "\\234")) == '\x0c'


# Generated at 2022-06-23 15:44:56.953633
# Unit test for function test
def test_test():
    with pytest.raises(SystemExit):
        test()

# Generated at 2022-06-23 15:45:07.365663
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == "foo"
    assert evalString("'foo'") == "foo"
    assert evalString('"\\x1b"') == "\x1b"
    assert evalString('"\\x1b"') == "\x1b"
    assert evalString('"\\x1b"') == "\x1b"
    assert evalString('"\\x1b"') == "\x1b"
    assert evalString('"\\x1b"') == "\x1b"
    assert evalString('"\\x1b"') == "\x1b"
    assert evalString('"\\x1b"') == "\x1b"
    assert evalString('"\"foo\""') == '"foo"'
    assert evalString('"""foo"""') == 'foo'

# Generated at 2022-06-23 15:45:15.016441
# Unit test for function evalString
def test_evalString():
    s = 'a string'
    assert evalString(s) == s
    s = 'a "string"'
    assert evalString(s) == 'a "string"'
    s = "a 'string'"
    assert evalString(s) == "a 'string'"
    assert evalString('"escape\ntest"') == "escape\ntest"
    assert evalString("'escape\ntest'") == "escape\ntest"
    assert evalString("'\\x61 string'") == 'a string'
    assert evalString("'\\141 string'") == 'a string'
    assert evalString("'\\141string'") == 'astring'
    assert evalString("'\\x61string'") == 'astring'
    assert evalString("'\\0141string'") == '\141string'

# Generated at 2022-06-23 15:45:27.474477
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\x61\\x62\\x63\\x0a'") == "abc\n"
    assert evalString("'\\011\\012\\155'") == "\t\n\r"

# Generated at 2022-06-23 15:45:34.195122
# Unit test for function escape
def test_escape():
    test_cases = [
        ("\\t", "\t"),
        ("\\n", "\n"),
        ("\\x41", "A"),
        ("\\x42", "B"),
        ("\\x43", "C"),
        ("\\x44", "D"),
    ]
    for test_case in test_cases:
        assert escape(test_case[0]) == test_case[1]

# Generated at 2022-06-23 15:45:36.639506
# Unit test for function evalString
def test_evalString():
    a = evalString("'hello'")
    assert a == "hello"
    a = evalString('"hello"')
    assert a == "hello"

# Generated at 2022-06-23 15:45:37.758472
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:45:46.574200
# Unit test for function evalString
def test_evalString():
    assert evalString('"""abc"""') == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString('"\n"') == "\n"
    assert evalString(r'"\0"') == "\0"
    assert evalString(r'"\000"') == "\0"
    assert evalString(r'"\001"') == "\x01"
    assert evalString(r'"\002"') == "\x02"
    assert evalString(r'"\003"') == "\x03"
    assert evalString(r'"\004"') == "\x04"
    assert evalString(r'"\005"') == "\x05"
    assert evalString(r'"\006"') == "\x06"

# Generated at 2022-06-23 15:45:48.853590
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        pytest.fail("Exception raised: {0}".format(e))

# Generated at 2022-06-23 15:45:57.737279
# Unit test for function escape
def test_escape():
    def check(m):
        all, tail = m.group(0, 1)
        assert all.startswith("\\")
        esc = simple_escapes.get(tail)
        if esc is not None:
            return esc
        if tail.startswith("x"):
            hexes = tail[1:]
            if len(hexes) < 2:
                raise ValueError("invalid hex string escape ('\\%s')" % tail)
            try:
                i = int(hexes, 16)
            except ValueError:
                raise ValueError("invalid hex string escape ('\\%s')" % tail) from None
        else:
            try:
                i = int(tail, 8)
            except ValueError:
                raise ValueError("invalid octal string escape ('\\%s')" % tail) from None


# Generated at 2022-06-23 15:45:59.783356
# Unit test for function evalString
def test_evalString():
    result = evalString('"this is a string"')
    assert result == "this is a string"


# Generated at 2022-06-23 15:46:05.609503
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'\\a\\b\\c'") == "\a\b\c"
    assert evalString('"\\a\\b\\c"') == "\a\b\c"
    assert evalString("'\\x7f'") == "\x7f"
    try:
        evalString("'\\x7'")
    except ValueError:
        pass
    else:
        assert 0, "expected ValueError"

# Generated at 2022-06-23 15:46:06.353907
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:17.528668
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "a", "test_escape fails"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "b", "test_escape fails"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "f", "test_escape fails"

# Generated at 2022-06-23 15:46:28.412807
# Unit test for function evalString

# Generated at 2022-06-23 15:46:29.715896
# Unit test for function test
def test_test():
    test_evalString()
    # test()



# Generated at 2022-06-23 15:46:40.600864
# Unit test for function escape
def test_escape():
    print("Testing escape")
    rslt = escape(re.match(r'\\"', r'\"'))
    assert rslt == '"'
    rslt = escape(re.match(r'\\"', r'\\"'))
    assert rslt == '\\"'
    rslt = escape(re.match(r'\\"', r'\\x41'))
    assert rslt == 'A'
    rslt = escape(re.match(r'\\"', r'\\xa'))
    assert rslt == '\n'
    rslt = escape(re.match(r'\\"', r'\\b'))
    assert rslt == '\b'
    rslt = escape(re.match(r'\\"', r'\\v'))
    assert rslt == '\v'
    rslt = escape

# Generated at 2022-06-23 15:46:50.661177
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\x3c', r'\x3c')) == '<'

# Generated at 2022-06-23 15:47:00.484050
# Unit test for function escape
def test_escape():
    test_data = [
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\\\", "\\"),
        ("\\x09", "\t"),
        ("\\xf0", "\xf0"),
        ("\\0", "\0"),
        ("\\01", "\01"),
        ("\\012", "\012"),
        ("\\123", "\123"),
    ]

# Generated at 2022-06-23 15:47:11.688936
# Unit test for function escape
def test_escape():
    # Test simple escapes
    assert escape(r'\a', r'a') == "\a"
    assert escape(r'\b', r'b') == "\b"
    assert escape(r'\f', r'f') == "\f"
    assert escape(r'\n', r'n') == "\n"
    assert escape(r'\r', r'r') == "\r"
    assert escape(r'\t', r't') == "\t"
    assert escape(r'\v', r'v') == "\v"
    assert escape(r'\'', r"'") == "'"
    assert escape(r'\"', r'"') == '"'
    assert escape(r'\\', r'\\') == "\\"
    # Test hex escapes
    assert escape(r'\x61', r'x61')

# Generated at 2022-06-23 15:47:19.701659
# Unit test for function evalString
def test_evalString():
    from pygments.token import Error
    from .config import ConfigError
    from .tokenize import generate_tokens
    from .tokenize import tokenize_loop, TokenInfo
    from .utils import BytesIO
    from typing import List, Tuple

    def test2(f: bytes, r: List[Tuple[int, str, Tuple[int, int], Tuple[int, int], str]]) -> None:
        res = []
        out = BytesIO()
        generate_tokens(f, tokenize_loop(f, out.write, res.append, False), False)
        assert res == r


# Generated at 2022-06-23 15:47:29.514072
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-23 15:47:38.975797
# Unit test for function escape
def test_escape():
    import sys

    # Tests from the Python 2.5 test suite added by Antoine Pitrou
    # Copyright (c) 2001, 2002, 2003, 2004, 2005, 2006 Python Software Foundation;
    # All Rights Reserved
    # Python has no say in support for this part of the library.
    import unittest

    class EscapeTest(unittest.TestCase):
        def test_tail(self):
            import re

            self.assertEqual(re.escape("\\"), "\\\\")

        def test_octal(self):
            import re

            self.assertEqual(re.escape("\07"), "\\07")

        def test_8bit(self):
            import re

            self.assertEqual(re.escape("\177"), "\\177")

        def test_unicode(self):
            import re

            # '\

# Generated at 2022-06-23 15:47:49.786452
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(|)', r'\\')) == "\\"
    assert escape(re.match(r"\\('|)", r"\\'")) == "'"
    assert escape(re.match(r'\\(|")', r'\\"')) == '"'
    assert escape(re.match(r"\\(a|)", r"\\a")) == "\a"
    assert escape(re.match(r"\\(b|)", r"\\b")) == "\b"
    assert escape(re.match(r"\\(f|)", r"\\f")) == "\f"
    assert escape(re.match(r"\\(n|)", r"\\n")) == "\n"
    assert escape(re.match(r"\\(r|)", r"\\r")) == "\r"

# Generated at 2022-06-23 15:47:58.132026
# Unit test for function escape
def test_escape():
    for i in simple_escapes:
        assert escape(re.match(r'\\'+i+'$', '\\'+i)) == simple_escapes[i]
    assert escape(re.match(r'\\x7f$', '\\x7f')) == '\x7f'

# Generated at 2022-06-23 15:47:58.831876
# Unit test for function test
def test_test():
  test()

# Generated at 2022-06-23 15:48:08.090981
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\u4e86'") == "\u4e86"
    assert evalString("'\\U0001d120'") == "\U0001d120"
    assert evalString("'\\u2fe1'") == "\u2fe1"
    assert evalString("'\\U0001d11E'") == "\U0001d11E"


# Generated at 2022-06-23 15:48:17.098121
# Unit test for function evalString
def test_evalString():
    # Test simple and quotes
    result = evalString("''")
    assert result == ""

    result = evalString("'test'")
    assert result == "test"

    result = evalString('"test"')
    assert result == "test"

    result = evalString('"test\'"')
    assert result == "test'"

    result = evalString("'test\"'")
    assert result == 'test"'

    # Test backslash and escape
    result = evalString('"\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\"')
    assert result == "\a\b\f\n\r\t\v\'\"\\"

    # Test octal escapes
    result = evalString('"\\110\\145\\164"')
    assert result == "net"


# Generated at 2022-06-23 15:48:21.060600
# Unit test for function escape
def test_escape():
    assert "test" == escape(re.match(r"\\?(.)", "test"))
    assert evalString('"test"') == "test"
    assert evalString("'test'") == "test"


# Generated at 2022-06-23 15:48:30.222489
# Unit test for function evalString
def test_evalString():
    import string

    quotechars = "'\""
    whitespace = string.whitespace + ','
    letters = string.ascii_letters + '_'
    digits = string.digits
    octdigits = '01234567'
    hexdigits = '0123456789abcdefABCDEF'
    # printable = string.printable
    escapechars = 'abfnrtv?\\' + quotechars + octdigits + 'x' + hexdigits
    assert len(escapechars) == 23
    for c in escapechars:
        assert c in printable


# Generated at 2022-06-23 15:48:39.086262
# Unit test for function evalString
def test_evalString():
    import sys
    if sys.version_info[0] == 2:
        if sys.maxunicode > 65535:
            # If the build supports > 16-bit Unicode characters,
            # then U+10FFFF, the highest assignable Unicode scalar
            # value, is no longer a valid Unicode escape.
            # (See #11761)
            non_bmp_max = 0xD800
        else:
            non_bmp_max = 0xFFFF
        for i in range(non_bmp_max + 1, 0x110000):
            c = chr(i)
            s = repr(c)
            with pytest.raises(ValueError) as excinfo:
                evalString(s)
                assert "invalid escape" in str(excinfo.value)

    # Test evalString() with all printable

# Generated at 2022-06-23 15:48:45.340074
# Unit test for function evalString
def test_evalString():
    # successful tests
    assert evalString('"a"') == "a"
    assert evalString("'a'") == "a"
    assert evalString("\"'\"") == "'"
    assert evalString("'\"'") == '"'
    assert evalString("\"''\"") == "''"
    assert evalString("''\"'") == "''"
    assert evalString("''") == ""
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x41'") == "A"
    assert evalString("'\\x10'") == "\x10"
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\xFF'") == "\xFF"

# Generated at 2022-06-23 15:48:47.132451
# Unit test for function test
def test_test():
    import pytest

    with pytest.raises(SystemExit):
        test()

# Generated at 2022-06-23 15:48:55.680214
# Unit test for function escape
def test_escape():
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x62'") == "b"
    assert evalString("'\\x63'") == "c"
    assert evalString("'\\x64'") == "d"
    assert evalString("'\\x65'") == "e"
    assert evalString("'\\x66'") == "f"
    assert evalString("'\\x67'") == "g"
    assert evalString("'\\x68'") == "h"
    assert evalString("'\\x69'") == "i"
    assert evalString("'\\x6a'") == "j"
    assert evalString("'\\x6b'") == "k"
    assert evalString("'\\x6c'") == "l"
    assert evalString

# Generated at 2022-06-23 15:49:05.304527
# Unit test for function test
def test_test():
    assert evalString("'spam'") == "spam"
    assert evalString('"spam"') == "spam"
    assert evalString("'a\\\'\\\'\\\'\\\'b'") == "a''''b"
    assert evalString('"a\\\"\\\"\\\"\\\"b"') == 'a""""b'
    assert evalString("'a\\\'b'") == "a'b"
    assert evalString('"a\\\"b"') == 'a"b'

# Generated at 2022-06-23 15:49:09.302160
# Unit test for function evalString
def test_evalString():
    s = evalString("'a'")
    assert s == 'a'
    t = evalString("'c:\\\\temp\\\\test.txt'")
    assert t == 'c:\\temp\\test.txt'
    u = evalString('"c:\\temp\\test.txt"')
    assert u == 'c:\\temp\\test.txt'

# Generated at 2022-06-23 15:49:20.451996
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"abc"') == "abc"
    assert evalString(r"\x63\xbc\xa0") == chr(0x63) + chr(0xbc) + chr(0xa0)
    assert evalString(r"\0377") == chr(0xff)
    assert evalString(r"\0377z") == chr(0xff) + "z"
    assert evalString(r"'abc'") == "abc"
    assert evalString(r"\x63\xbc\xa0") == chr(0x63) + chr(0xbc) + chr(0xa0)
    assert evalString(r"\0377") == chr(0xff)
    assert evalString(r"\0377z") == chr(0xff) + "z"

# Generated at 2022-06-23 15:49:21.296933
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:33.034092
# Unit test for function evalString
def test_evalString():
    assert evalString('s\np\x00am') == 'spam'
    assert evalString('\x01\x02\n\r\t\v\b\a\f') == '\x01\x02\n\r\t\v\b\a\f'
    assert evalString('"spam"') == '"spam"'
    assert evalString("'spam'") == "'spam'"
    assert evalString('r"spam"') == 'r"spam"'
    assert evalString("r'spam'") == "r'spam'"
    assert evalString('"""spam"""') == '"""spam"""'
    assert evalString("'''spam'''") == "'''spam'''"
    assert evalString('r"""spam"""') == 'r"""spam"""'


# Generated at 2022-06-23 15:49:35.284480
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"

# Generated at 2022-06-23 15:49:35.898858
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:49:43.359557
# Unit test for function escape
def test_escape():
    assert escape("\x61") == "a"
    assert escape("\x41") == "A"
    assert escape("\x04") == "\x04"
    assert escape("\x10") == "\x10"
    assert escape("\x7f") == "\x7f"
    assert escape("\x80") == "\x80"
    assert escape("\xff") == "\xff"
    # octal
    assert escape("\o00") == "\x00"
    assert escape("\o01") == "\x01"
    assert escape("\o07") == "\x07"
    assert escape("\o10") == "\x08"  # yes, octal 8 is BS
    assert escape("\o77") == "?"
    assert escape("\o100") == "@"

# Generated at 2022-06-23 15:49:48.413915
# Unit test for function escape
def test_escape():
    test_cases = [
        ("foo", "foo"),
        ("\\b", "\b"),
        ("\\x20", "\x20"),
        ("\\77", "\77"),
    ]
    for s, e in test_cases:
        assert escape(re.match(r"\\(.*)", s)) == e



# Generated at 2022-06-23 15:49:59.801955
# Unit test for function escape
def test_escape():
    assert escape("\001") == "\\x01"
    assert escape("\002") == "\\x02"
    assert escape("\003") == "\\x03"
    assert escape("\004") == "\\x04"
    assert escape("\005") == "\\x05"
    assert escape("\006") == "\\x06"
    assert escape("\a") == "\\x07"
    assert escape("\b") == "\\x08"
    assert escape("\t") == "\\t"
    assert escape("\n") == "\\n"
    assert escape("\v") == "\\x0b"
    assert escape("\f") == "\\x0c"
    assert escape("\r") == "\\r"
    assert escape("\016") == "\\x0e"
    assert escape

# Generated at 2022-06-23 15:50:07.551312
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(')", r"\\'")) == "'"
    assert escape(re.match(r'\\(")', r'\\"')) == '"'
    assert escape(re.match(r'\\(\\)', r'\\\\')) == '\\'
    assert escape(re.match(r'\\(a)', r'\\a')) == '\a'
    assert escape(re.match(r'\\(b)', r'\\b')) == '\b'
    assert escape(re.match(r'\\(f)', r'\\f')) == '\f'
    assert escape(re.match(r'\\(n)', r'\\n')) == '\n'
    assert escape(re.match(r'\\(r)', r'\\r'))

# Generated at 2022-06-23 15:50:17.262624
# Unit test for function evalString
def test_evalString():

    # A test
    assert evalString(r"""\x61""" "") == "a"

    # B test
    assert evalString(r""""\\\"
\n\"
""") == "\n"

    # C test
    assert evalString(r"""\n""") == "\n"

    # D test
    assert evalString(r"""\x61""" "") == "a"

    # E test
    assert evalString(r"""\"""") == '"'

    # F test
    try:
        evalString(r"""\y""")
    except ValueError:
        pass
    else:
        raise AssertionError

    # G test
    assert evalString(r"""\'""") == "'"

    # H test

# Generated at 2022-06-23 15:50:17.796955
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:50:26.651519
# Unit test for function escape
def test_escape():
    assert escape('\\"') == '"'
    assert escape('\\\'') == '\''
    assert escape('\\n') == '\n'
    assert escape('\\x20') == ' '
    assert escape('\\x7F') == '\x7F'
    assert escape('\\x7FF') == '\x7F'
    assert escape('\\xFF') == '\xFF'
    assert escape('\\xFFF') == '\xFF'
    assert escape('\\xFFFF') == '\xff'
    assert escape('\\x9ffff') == '\t'
    assert escape('\\t') == '\t'
    try:
        escape('\\t')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-23 15:50:27.289020
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:50:29.193859
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:50:34.795455
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\.", r"\x1F")) == chr(int("1F", 16))
    assert escape(re.search(r"\\.", r"\xF")) == chr(int("F", 16))
    assert escape(re.search(r"\\.", r"\x")) is None
    assert escape(re.search(r"\\.", r"\xFuf")) is None
    assert escape(re.search(r"\\.", r"\F")) is None
    assert escape(re.search(r"\\.", r"\'")) == "'"
    assert escape(re.search(r"\\.", r'\"')) == '"'

