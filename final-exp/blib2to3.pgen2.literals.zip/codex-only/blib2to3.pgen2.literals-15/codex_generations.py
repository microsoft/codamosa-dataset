

# Generated at 2022-06-23 15:40:31.608038
# Unit test for function test
def test_test():
    # Call test() and check if it runs to completion.
    test()

# Generated at 2022-06-23 15:40:32.448466
# Unit test for function test
def test_test():
    # TODO: Write better test
    test()

# Generated at 2022-06-23 15:40:36.961411
# Unit test for function evalString
def test_evalString():
    # This test is inspired by the test() function in the module
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-23 15:40:43.950970
# Unit test for function test
def test_test():
    test()
    assert ''.split() == []
    assert ''.split('a') == ['']
    assert 'a'.split() == ['a']
    assert 'a'.split('a') == ['', '']
    assert 'ab'.split() == ['ab']
    assert 'ab'.split('a') == ['', 'b']
    assert 'ab'.split('b') == ['a', '']
    assert 'a b c d'.split() == ['a', 'b', 'c', 'd']
    assert 'a b c d'.split('a') == ['', ' b c d']
    assert 'a b c d'.split('b') == ['a ', ' c d']
    assert 'a b c d'.split('c') == ['a b ', ' d']

# Generated at 2022-06-23 15:40:45.392918
# Unit test for function test
def test_test():
    test() # It works, but we don't get anything out of it.

# Generated at 2022-06-23 15:40:47.589610
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError:
        assert False, "Should not raise AssertionError"

# Generated at 2022-06-23 15:40:50.096486
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        # Shouldn't raise any exceptions
        assert False, "Should not raise any exceptions"

# Generated at 2022-06-23 15:40:51.229271
# Unit test for function test
def test_test():
    test()
    assert True

# Generated at 2022-06-23 15:40:52.988937
# Unit test for function test
def test_test():
    # testing that test() does not raise any exceptions.
    test()

# Generated at 2022-06-23 15:41:00.649095
# Unit test for function escape
def test_escape():
    assert escape('\\x63') == 'c'
    assert escape('\\077') == '?'
    assert escape('\\x41b') == 'Ab'
    assert escape('\\041') == '!'
    assert escape('\\x5c') == '\\'
    assert escape('\\x5C') == '\\'
    assert escape('\\x5c\\') == '\\'
    assert escape('\\x05c\\') == '\\'

    # Unit test for function evalString
    s = '\\0\\077\\xab\\x5c'

# Generated at 2022-06-23 15:41:05.381934
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\", "\\")) == "\\"
    assert escape(re.match(r"\\.", "\\n")) == "\n"
    assert escape(re.match(r"\\.", "\\x12")) == "\x12"
    assert escape(re.match(r"\\.", "\\7")) == "\x07"
    assert escape(re.match(r"\\.", "\\77")) == "\x3f"
    assert escape(re.match(r"\\.", "\\777")) == "\u03ff"



# Generated at 2022-06-23 15:41:13.323186
# Unit test for function escape
def test_escape():
    test_data = [(r'\\"', '"'),
                 (r"\\'", "'"),
                 (r'\\t', '\t'),
                 (r'\\a', '\a'),
                 (r"\\'", "'"),
                 (r"\\x41", "A"),
                 (r"\\x10", "\x10"),
                 (r"\\377", "\xff"),
                 (r"\\377", "\xff"),
                 (r"\\400", "\\400"),
                 (r"\\1111", "\\1111"),
                 (r"\\abc", "\\abc")]

# Generated at 2022-06-23 15:41:24.928363
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(x[0-9a-fA-F]+|[0-7]*)(.*)", "\\x1b \\g \\33 \\033")
    assert escape(m) == '\x1b'
    m = re.match(r"\\(x[0-9a-fA-F]+|[0-7]*)(.*)", "\\33 \\g \\033")
    assert escape(m) == '\x1b'
    m = re.match(r"\\(x[0-9a-fA-F]+|[0-7]*)(.*)", "\\033")
    assert escape(m) == '\x1b'

# Generated at 2022-06-23 15:41:34.717586
# Unit test for function evalString
def test_evalString():
    # Non-strings don't raise a TypeError exception
    assert evalString(42) is 42
    # Valid strings are correctly parsed
    assert evalString('"ok"') == 'ok'
    assert evalString("'no'") == 'no'
    assert evalString(r"'\x01'") == "\x01"
    assert evalString(r'"\x01"') == "\x01"
    assert evalString(r"'\001'") == "\x01"
    assert evalString(r'"\001"') == "\x01"
    assert evalString(r"'\1'") == "\001"
    assert evalString(r'"\1"') == "\001"
    assert evalString(r"'\a'") == "\a"
    assert evalString(r'"\a"') == "\a"

# Generated at 2022-06-23 15:41:48.080760
# Unit test for function escape
def test_escape():
    escape_test_input = re.match(r"\\(\\|0|a|b|f|n|r|t|v|x[\da-fA-F]{2}|[0-7]{3})", "\\'")
    assert escape(escape_test_input) == "\'"
    escape_test_input = re.match(r"\\(\\|0|a|b|f|n|r|t|v|x[\da-fA-F]{2}|[0-7]{3})", "\\\"")
    assert escape(escape_test_input) == "\""

# Generated at 2022-06-23 15:41:48.575477
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:55.710615
# Unit test for function escape
def test_escape():
    import unittest
    import string

    class TestEscape(unittest.TestCase):

        def test_escape(self):
            string_of_chars = string.printable
            for x in string_of_chars:
                if x == '|' or x == '\\' or x == '+':
                    y = '\\' + x
                else:
                    y = x
                self.assertEqual(escape(x), y)

    unittest.main()

# Generated at 2022-06-23 15:42:02.537650
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")
    assert escape(m) == "'"
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\"')
    assert escape(m) == '"'
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\\")
    assert escape(m) == "\\"

# Generated at 2022-06-23 15:42:07.911383
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == 'a'
    assert evalString('"a"') == 'a'
    assert evalString(r"'\''") == "'"
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\\a\''") == r"\a'"
    assert evalString(r'"\\a\"') == r'\a"'
    assert evalString(r"'\a\b\f\n\r\t\v'") == "\a\b\f\n\r\t\v"
    assert evalString(r'"\a\b\f\n\r\t\v"') == "\a\b\f\n\r\t\v"
    assert evalString(r"'\x61\x62\x63'") == "abc"
    assert eval

# Generated at 2022-06-23 15:42:17.557938
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("\"abc\"") == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString("r'abc'") == "abc"
    assert evalString("'\\'abc\\''") == "'abc'"
    assert evalString("\"\\\"abc\\\"\"") == "\"abc\""
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\b\\f\\n\\r\\t\\v'") == "\b\f\n\r\t\v"
    assert evalString("'\\xFF'") == chr(0xFF)

# Generated at 2022-06-23 15:42:24.868158
# Unit test for function evalString
def test_evalString():
    """Tests evalString()."""
    # Try with a raw string.
    assert evalString('"\\x22"') == '"'
    # Try with a triple-quoted string.
    assert evalString('"""\\x22"""') == '"'
    # Try with a backslash at the end of the string.
    assert evalString('"\\"') == '\\'
    # Try with a backslash in the middle of the string.
    assert evalString('"\foo\\bar"') == '\foo\bar'
    # Try with a backslash at the beginning of the string.
    assert evalString('"\\"') == '\\'
    # Try with a backslash escaped by another backslash in the middle of the
    # string.

# Generated at 2022-06-23 15:42:25.381744
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:34.295459
# Unit test for function evalString
def test_evalString():
    from test import support
    import doctest

    # Let's assume the function works with ASCII strings...
    assert evalString(r'"abc\n\t\"\'') == r"abc\n\t\"'"
    assert evalString(r"'abc\n\t\"\'\x80'") == r"abc\n\t\"'\x80"
    assert evalString(r"""'abc\n\t\"\'\x80'""") == r"abc\n\t\"'\x80"
    assert evalString(r"""'abc\n\t\"\'\x80'""" + r"""'abc\n\t\"\'\x80'""") == r"abc\n\t\"'\x80abc\n\t\"'\x80"

    # Now let's check if the function raises the right exceptions
    support

# Generated at 2022-06-23 15:42:42.646232
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == 'abc'
    assert evalString("'ab\\'c'") == "ab'c"
    assert evalString("'ab\\\'c'") == "ab\'c"
    assert evalString("'a\\'b'") == "a'b"
    assert evalString("'\\\\\\''") == "\\'"
    assert evalString("'\\''") == "'"
    assert evalString('"abc"') == 'abc'
    assert evalString('"ab\\"c"') == 'ab"c'
    assert evalString('"ab\\\"c"') == 'ab"c'
    assert evalString('"a\\"b"') == 'a"b'
    assert evalString('"\\\\\\""') == '\\"'
    assert evalString('"\\""') == '"'
   

# Generated at 2022-06-23 15:42:47.629911
# Unit test for function test
def test_test():
    with open("test_literal_parser.out", "w") as f:
        back = sys.stdout
        sys.stdout = f
        try:
            test()
        finally:
            sys.stdout = back
    with open("test_literal_parser.out") as f:
        assert f.read() == ""

# Generated at 2022-06-23 15:42:56.794212
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello world!'") == 'hello world!'
    assert evalString("'hello \\\\ world'") == 'hello \\ world'
    assert evalString("'hello \\' world'") == "hello ' world"

    assert evalString("'hello \\r\\n world'") == "hello \r\n world"
    assert evalString("'hello \\x7f world'") == "hello \x7F world"
    assert evalString("'hello \\x7f world'") == "hello \x7F world"

    assert evalString("'hello \\177 world'") == "hello \x7F world"

    assert evalString("'hello \\x7f\\x7f world'") == "hello \x7F\x7F world"

# Generated at 2022-06-23 15:43:05.268853
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\n"') == "\n"
    assert evalString('f"\\n"') == "\n"
    assert evalString('"\\n\\n"') == "\n\n"
    assert evalString('"""\\n"""') == "\n"
    assert evalString("'\\n'") == "\n"
    assert evalString("f'\\n'") == "\n"
    assert evalString("'\\n\\n'") == "\n\n"
    assert evalString("'''\\n'''") == "\n"
    assert evalString("'\\t\\\\'") == "\t\\"

# Generated at 2022-06-23 15:43:13.469818
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\a"))         == "\a"
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\b"))         == "\b"
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\f"))         == "\f"
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\n"))         == "\n"
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\r"))         == "\r"

# Generated at 2022-06-23 15:43:15.072218
# Unit test for function test
def test_test():
    """Check that no exceptions are raised."""
    test()

# Generated at 2022-06-23 15:43:15.455968
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:24.012410
# Unit test for function evalString
def test_evalString():
    assert evalString("'123'") == '123'
    assert evalString("'hello world'") == 'hello world'
    assert evalString('"123"') == '123'
    assert evalString('"hello world"') == 'hello world'

    assert evalString("'\\\\'") == '\\'
    assert evalString("'\\''") == "'"
    assert evalString("'\"'") == '"'

    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\011\\011\\011\\011'") == '\t\t\t\t'  # octal

# Generated at 2022-06-23 15:43:25.117108
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"

# Generated at 2022-06-23 15:43:34.590710
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\"")) == '"'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\x07"

# Generated at 2022-06-23 15:43:40.402984
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        # Anyways, this will be called once, so no get_type_for_value.
        assert isinstance(e, str)  # type: ignore
        assert e == c

# Generated at 2022-06-23 15:43:42.446614
# Unit test for function test
def test_test():
    if not hasattr(test, "__wrapped__"):
        test()  # type: ignore[attr-defined]

# Generated at 2022-06-23 15:43:47.726029
# Unit test for function evalString
def test_evalString():
    pythonsrc = '''
        # This is a test script
        s = 'a single \\'quote\\' embedded string'
        d = "a double \\"quote\\" embedded string"
    '''
    assert evalString(pythonsrc) == '# This is a test script\ns = \'a single \\\'quote\\\' embedded string\'\nd = "a double \\"quote\\" embedded string"'

# Generated at 2022-06-23 15:43:51.993038
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x02"') == "\x02"
    assert evalString('"\\35"') == "5"
    assert evalString('"\\x10\\x10"') == "\x10\x10"
    assert evalString('"\\n"') == "\n"

# Generated at 2022-06-23 15:44:01.424796
# Unit test for function test
def test_test():
    import io

    from typing import Iterable

    from lib2to3.pygram import python_symbols as syms
    from lib2to3.pgen2 import token
    from lib2to3.pgen2.parse import ParseError
    from lib2to3.pgen2.tokenize import generate_tokens, untokenize
    from lib2to3.pytree import Leaf, Node

    from mypy_extensions import Arg

    from typing_extensions import Final

    # Taken from pytype's test_eval
    class TokenGenerator(object):
        def __init__(self, tokens: Iterable[token]) -> None:
            self._tokens = list(tokens)

        def next_leaf(self) -> Leaf:
            t = self._tokens[0]

# Generated at 2022-06-23 15:44:02.457314
# Unit test for function test
def test_test():
  test()

# Generated at 2022-06-23 15:44:03.729963
# Unit test for function test
def test_test():
    assert callable(test)

# Generated at 2022-06-23 15:44:11.945503
# Unit test for function evalString
def test_evalString():
    # Tests from the original module docstring
    assert evalString("'hi'") == "hi"
    assert evalString('"hi"') == "hi"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\''") == "'"
    assert evalString('"\'"') == "'"

    # \a, \b, \f, \n, \r, \t, and \v are not escaped in Python strings
    assert evalString('"\a\b\f\n\r\t\v"') == "\a\b\f\n\r\t\v"

    # Test octal and hex escapes
    assert evalString('"\\0"') == "\x00"
    assert evalString('"\\111"') == "I"

# Generated at 2022-06-23 15:44:13.522979
# Unit test for function test
def test_test():
    test()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-23 15:44:14.453145
# Unit test for function evalString
def test_evalString():
    pass
    # not sure how to test it

# Generated at 2022-06-23 15:44:23.085611
# Unit test for function evalString
def test_evalString():
    # Test all standard ASCII chars
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, 'evalString(%r) == %r, expected %r' % (s, e, c)

    # Test a few Unicode chars
    def test(s):
        e = evalString(s)
        assert e == eval(s), 'evalString(%r) == %r, expected %r' % (s, e, eval(s))

    test(r"'\u0020'")
    test(r"'\U00000020'")
    test(r"'\U00010000'")
    test(r"'\U00010001'")
    test(r"'\U00028fff'")

# Generated at 2022-06-23 15:44:33.495459
# Unit test for function escape
def test_escape():
    # Test escape()
    assert escape('\\a') == "\a"
    assert escape('\\b') == "\b"
    assert escape('\\f') == "\f"
    assert escape('\\n') == "\n"
    assert escape('\\r') == "\r"
    assert escape('\\t') == "\t"
    assert escape('\\v') == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape('\\\\') == "\\"
    assert escape("\\x41") == "A"
    assert escape("\\x4") == "x4"
    assert escape("\\0") == "\0"
    assert escape("\\07") == "\x07"
    assert escape("\\13") == "\x0d"

# Generated at 2022-06-23 15:44:34.092366
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:36.303382
# Unit test for function test
def test_test():
    try:
        test()
    except:
        print("testing evalString failed")
        raise

# Generated at 2022-06-23 15:44:37.047034
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:42.797311
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\x40", r"\x40")) == "@"
    assert escape(re.match(r"\\123", r"\123")) == "{"
    assert escape(re.match(r"\\12", r"\12")) == "\n"
    assert escape(re.match(r"\\0", r"\0")) == "\0"

# Generated at 2022-06-23 15:44:55.254991
# Unit test for function escape

# Generated at 2022-06-23 15:45:05.935506
# Unit test for function test
def test_test():
    # These tests verify that the strings that are expected to evaluate to
    # themselves using the evalString function are evaluated correctly.
    assert evalString("' '") == " "
    assert evalString("'a'") == "a"
    assert evalString("'abc'") == "abc"
    assert evalString("'{}'") == "{}"
    assert evalString("'{} {}'") == "{} {}"
    # These tests verify that the strings that are expected to return with an
    # escaped version of their original text, when interpreted with evalString
    # are evaluated correctly.
    assert evalString("'\\n'") == "\n"
    assert evalString("'\n'") == "\n"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\t'") == "\t"

# Generated at 2022-06-23 15:45:06.537948
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:17.451325
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"abc"') == "abc"
    assert evalString(r"'abc'") == "abc"
    assert evalString(r'"\xfe\xff\x00\x01"') == "\xfe\xff\x00\x01"
    assert evalString(r"'\xfe\xff\x00\x01'") == "\xfe\xff\x00\x01"
    assert evalString(r'"\xfe\xff\x00\x01"') == "\xfe\xff\x00\x01"
    assert evalString(r"'\\\xfe\xff\x00\x01'") == "\\\xfe\xff\x00\x01"

# Generated at 2022-06-23 15:45:29.019451
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == 'a'
    assert evalString("'\\\\'") == '\\'
    assert evalString("'\\n'") == '\n'
    assert evalString("'abc'") == 'abc'
    assert evalString('"a"') == 'a'
    assert evalString('"\\\\"') == '\\'
    assert evalString('"\\n"') == '\n'
    assert evalString('"abc"') == 'abc'
    assert evalString("'\\x61'") == 'a'
    assert evalString("'\\x61'") == 'a'
    assert evalString("u'\\x61'") == 'a'
    assert evalString("r'\\x61'") == '\\\\x61'

# Generated at 2022-06-23 15:45:38.618669
# Unit test for function escape

# Generated at 2022-06-23 15:45:42.374281
# Unit test for function test
def test_test():
    """Test that the test() function doesn't print anything"""
    import io
    import sys
    from contextlib import redirect_stdout

    f = io.StringIO()
    with redirect_stdout(f):
        test()
    output = f.getvalue()
    assert output == ""



# Generated at 2022-06-23 15:45:53.597443
# Unit test for function evalString
def test_evalString():
    test_strings = [
        ('"\xff"', "ÿ"),
        ('"\n"', "\n"),
        ('"\r"', "\r"),
        ('"\xaa"', "ª"),
        ('"""\\"\r\n"\\"""', '"\r\n"\\'),
        ('\'\\"\'', '\\"'),
        ('\'"\'', '"'),
        ('\'\\\'\'', "\\"),
        ('\'\'"\'', "\""),
    ]
    for (string, expected) in test_strings:
        result = evalString(string)
        assert (
            result == expected
        ), "Test '%s' gave incorrect result: %s (expecting %s)" % (string, result, expected)


test_evalString()

# Generated at 2022-06-23 15:46:00.961483
# Unit test for function evalString
def test_evalString():
    from . import tokenize
    s = r"'\a\b\f\n\r\t\v\'"
    assert evalString(s) == eval(s)
    s = r"'\\\r\n\x00'"
    assert evalString(s) == eval(s)
    assert evalString(r"'\47'") == eval(r"'\47'")
    assert evalString(r"'''\47'''") == eval(r"'''\47'''")
    assert evalString(r"r'''\47'''") == eval(r"r'''\47'''")
    assert evalString(r"'''\47'''") == eval(r"'''\47'''")

# Generated at 2022-06-23 15:46:13.410046
# Unit test for function test

# Generated at 2022-06-23 15:46:14.316242
# Unit test for function test
def test_test():
    # test() should not raise any exception.
    test()

# Generated at 2022-06-23 15:46:15.977858
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError:
        print("AssertionError")
    except ValueError:
        print("ValueError")

# Generated at 2022-06-23 15:46:18.426209
# Unit test for function test
def test_test():
    try:
        test()
    except (UnboundLocalError, AssertionError):
        assert False
    else:
        assert True

# Generated at 2022-06-23 15:46:19.028175
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-23 15:46:28.324169
# Unit test for function evalString
def test_evalString():
    # Get the module object
    mod = sys.modules[__name__]
    # The function to be tested is in a different module
    # so needs to be passed as an object
    function_object = mod.evalString

    # Trivial test case
    t1 = "Hello, World!"
    assert evalString(t1) == t1

    # A more involved test case
    t2 = "'''Hello, World!'''"
    assert evalString(t2) == "Hello, World!"

    # Another more involved test case
    t3 = "\"\"\"Hello, World!\"\"\""
    assert evalString(t3) == "Hello, World!"

# Generated at 2022-06-23 15:46:28.835195
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:29.320835
# Unit test for function test
def test_test():
    exec("test()")

# Generated at 2022-06-23 15:46:40.227468
# Unit test for function evalString
def test_evalString():
    # <BLANKLINE>
    #     print evalString('""')
    # <BLANKLINE>
    # <BLANKLINE>
    #     print evalString("''")
    # ''
    # <BLANKLINE>
    #     print evalString('"x"')
    # x
    # <BLANKLINE>
    #     print evalString("'x'")
    # x
    # <BLANKLINE>
    #     print evalString('"\'"')
    # '
    # <BLANKLINE>
    #     print evalString("'\"'")
    # "
    # <BLANKLINE>
    assert evalString('""') == ""
    assert evalString("''") == ""
    assert evalString('"x"') == "x"
    assert evalString("'x'") == "x"

# Generated at 2022-06-23 15:46:51.839455
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\.", r'\x7f')) == chr(0x7f)
    assert escape(re.match(r"\\.", r'\127')) == chr(127)
    assert escape(re.match(r"\\.", r'\18')) == chr(14)
    assert escape(re.match(r"\\.", r'\118')) == chr(14)
    assert escape(re.match(r"\\.", r'\11')) == chr(9)
    assert escape(re.match(r"\\.", r'\x1F')) == chr(0x1f)


# Generated at 2022-06-23 15:47:00.562575
# Unit test for function evalString
def test_evalString():
    print(evalString('"a" and "b"'))
    print(evalString('"a" or "b"'))
    print(evalString('"a" if "b" else "c"'))
    print(evalString('"a" + "b"'))
    print(evalString('"x %s %s" % ("a", "b")'))
    print(evalString('"x {a} {b}"'.format(a="a", b="b")))
    print(evalString('f"x {a} {b}"'))
    print(evalString('f"""x {a} {b}"""'))
    print(evalString(r'"\""'))

# Generated at 2022-06-23 15:47:11.733894
# Unit test for function evalString
def test_evalString():
    # Use the same set of assert statements in both test cases
    assert evalString("'abc\\n'") == "abc\\n", (
        f"evalString('abc\\n') did not return 'abc\\\\n'"
    )
    assert evalString("'abc\\n'") == "abc\n", (
        f"evalString('abc\\n') did not return 'abc\\n'"
    )
    assert evalString("'abc\\n'") == "abc\n", (
        f"evalString('abc\\n') did not return 'abc\\n'"
    )
    assert evalString("'abc\\n'") == "abc\n", (
        f"evalString('abc\\n') did not return 'abc\\n'"
    )

# Generated at 2022-06-23 15:47:23.484770
# Unit test for function escape
def test_escape():
    # Using assert
    assert escape(re.match(r"\\a", "\\a")) == "\a" # test "\\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b" # test "\\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f" # test "\\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n" # test "\\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r" # test "\\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t" # test "\\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v" # test "\\v

# Generated at 2022-06-23 15:47:31.983070
# Unit test for function evalString
def test_evalString():
    assert evalString("'''a'''") == "a"
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'''abc\ndef'''") == "abc\ndef"
    assert evalString("'def\\ndef'") == "def\ndef"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\v'") == "\v"

# Generated at 2022-06-23 15:47:35.259680
# Unit test for function test
def test_test():
    backup_test()
    # arrange
    import io
    from contextlib import redirect_stdout
    f = io.StringIO()
    with redirect_stdout(f):
        test()
    assert f.getvalue() == ""

# Generated at 2022-06-23 15:47:47.140961
# Unit test for function evalString
def test_evalString():
    assert evalString('\'\\x1a\'') == '\x1a'
    assert evalString('"\\1a"') == '\x1a'
    assert evalString('"\\51"') == '\x1a'
    assert evalString('"\\151"') == '\x1a'
    assert evalString('"\\x1a"') == '\x1a'
    assert evalString('"\\x1A"') == '\x1a'

# Generated at 2022-06-23 15:47:47.751301
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:52.484486
# Unit test for function escape
def test_escape():
    assert escape(0) == 0
    assert escape('\n') == "\n"
    assert escape('\\n') == 'n'
    assert escape('\\x00') == '\x00'
    assert escape('\\077') == '?'
    assert escape('\\077') == '?'
    assert escape('\\777') == '\xf7'
    assert escape('\\777') == '\xf7'

# Generated at 2022-06-23 15:47:56.605579
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(')", "\\'")) == "'"
    assert escape(re.match(r"\\(x..)", "\\x61")) == "a"
    assert escape(re.match(r"\\(')", "\\'")) == "'"

# Generated at 2022-06-23 15:47:57.207592
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:09.062879
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\t"') == "\t"
    assert evalString('"\t"') == "\t"
    assert evalString('r"\\t"') == "\\t"
    assert evalString('r"\t"') == "\\t"

# Generated at 2022-06-23 15:48:10.357584
# Unit test for function test
def test_test():
    """Verify that test() runs cleanly"""
    test()

# Generated at 2022-06-23 15:48:13.580627
# Unit test for function test
def test_test():
    import io
    import sys

    from contextlib import redirect_stdout

    f = io.StringIO()
    with redirect_stdout(f):
        test()
    output = f.getvalue()
    assert not output, output

# Generated at 2022-06-23 15:48:16.163758
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:48:18.598111
# Unit test for function test
def test_test():
    lines = test.__doc__.splitlines()
    for line in lines:
        print(line)

# Generated at 2022-06-23 15:48:19.290867
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:28.738910
# Unit test for function evalString
def test_evalString():
    # Non-comprehensive tests
    # Empty string
    assert evalString('""') == ''
    assert evalString("''") == ''
    # Backslashes
    assert evalString(r'"\\"') == '\\'
    assert evalString(r"'\\'") == '\\'
    assert evalString(r'"\\\\"') == '\\'
    assert evalString(r"'\\\\'") == '\\'
    # Basic string
    assert evalString(r'"abc"') == 'abc'
    assert evalString(r"'abc'") == 'abc'
    # Newlines
    assert evalString(r'"\n"') == '\n'
    assert evalString(r"'\n'") == '\n'
    # C style string
    assert evalString(r'"ab\
c"') == 'abc'

# Generated at 2022-06-23 15:48:39.613243
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\a")) == "\a"
    assert escape(re.match(r"\\(.)", "\\b")) == "\b"
    assert escape(re.match(r"\\(.)", "\\f")) == "\f"
    assert escape(re.match(r"\\(.)", "\\n")) == "\n"
    assert escape(re.match(r"\\(.)", "\\r")) == "\r"
    assert escape(re.match(r"\\(.)", "\\t")) == "\t"
    assert escape(re.match(r"\\(.)", "\\v")) == "\v"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"

# Generated at 2022-06-23 15:48:51.264391
# Unit test for function evalString
def test_evalString():
    # Note: keep the assert statements and the print statements
    #       because they are used to check the output
    assert evalString("'string'") == 'string'
    assert evalString('"string"') == 'string'
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString("'\\x61\\x62\\x63'") == 'abc'
    assert evalString('"\\x61\\x62\\x63"') == 'abc'
    assert evalString("'\\x61\\x62\\x63'") == 'abc'
    assert evalString('"\\x61\\x62\\x63"') == 'abc'
    assert evalString

# Generated at 2022-06-23 15:49:01.928688
# Unit test for function escape
def test_escape():

    def make_test(m, n, should_raise=False):
        def test():
            if should_raise:
                with pytest.raises(ValueError):
                    escape(m)
            else:
                assert escape(m) == n

        return test

    m_a = re.match('\\a', '')
    m_b = re.match('\\b', '')
    m_f = re.match('\\f', '')
    m_n = re.match('\\n', '')
    m_r = re.match('\\r', '')
    m_t = re.match('\\t', '')
    m_v = re.match('\\v', '')
    m_apos = re.match("\\'", '')
    m_quote = re.match('\\"', '')

# Generated at 2022-06-23 15:49:07.284451
# Unit test for function evalString
def test_evalString():
    import sys
    if sys.version_info[0] < 3:
        hex_string = r'\xFF\xBB'
    else:
        hex_string = r'\xff\xbb'
    assert evalString(r'"\xFF\xBB"') == hex_string
    assert evalString(r"'" + hex_string + r"'") == evalString(r'"' + hex_string + r'"') == hex_string

# Generated at 2022-06-23 15:49:18.032588
# Unit test for function evalString
def test_evalString():
    pass
    # assert evalString('"a"') == 'a'
    # assert evalString(r'"\t"') == '\t'
    # assert evalString(r'"\\"') == '\\'
    # assert evalString(r'"\'abc \t\'"') == '\'abc \t\''
    # assert evalString(r'"\"abc \t\""') == '"abc \t"'
    # assert evalString(r'"\n"') == '\n'
    # assert evalString(r'"\v"') == '\v'
    # assert evalString(r'"\a"') == '\a'
    # assert evalString('"\001"') == '\001'
    # assert evalString('"\002"') == '\002'
    # assert evalString('"\003"') ==

# Generated at 2022-06-23 15:49:29.774962
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("'a'") == "a"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\xff'") == "\255"
    assert evalString("'\\xFF'") == "\255"
    assert evalString("'\\377'") == "\377"
    assert evalString("'\\377\\''") == "\377'"

    # '\0' is not allowed
    try:
        evalString("'\\0'")
        assert False
    except ValueError:
        pass

    # '\0' is not allowed
    try:
        evalString("'\\00'")
        assert False
    except ValueError:
        pass

    # '\0' is not allowed

# Generated at 2022-06-23 15:49:39.852343
# Unit test for function escape
def test_escape():
    m = re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\t')
    assert m.group(1) == 't'
    assert escape(m) == '\t'
    m = re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\n')
    assert m.group(1) == 'n'
    assert escape(m) == '\n'
    m = re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\x7f')
    assert m.group(1) == 'x7f'


# Generated at 2022-06-23 15:49:46.118142
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", r'\x12')) == '\x12'
    assert escape(re.match(r"\\012", r'\012')) == '\n'
    assert escape(re.match(r"\\\'", r"\'")) == "'"

# Generated at 2022-06-23 15:49:56.693792
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\[abfnrtv]', r'\a')) == '\x07'
    assert escape(re.match(r'\\[abfnrtv]', r'\b')) == '\x08'
    assert escape(re.match(r'\\[abfnrtv]', r'\f')) == '\x0c'
    assert escape(re.match(r'\\[abfnrtv]', r'\n')) == '\n'
    assert escape(re.match(r'\\[abfnrtv]', r'\r')) == '\r'
    assert escape(re.match(r'\\[abfnrtv]', r'\t')) == '\t'

# Generated at 2022-06-23 15:50:05.997575
# Unit test for function evalString

# Generated at 2022-06-23 15:50:18.409023
# Unit test for function escape
def test_escape():
    test_escapes = {
        '\\a': "\a",
        '\\b': "\b",
        '\\f': "\f",
        '\\n': "\n",
        '\\r': "\r",
        '\\t': "\t",
        '\\v': "\v",
        '\\\'': "'",
        '\\"': '"',
        '\\\\': "\\",
        '\\x13': '\x13',
        '\\x33': '\x33',
        '\\x4a': '\x4a',
        '\\x4A': '\x4A',
        '\\x00': '\x00',
        '\\xFF': '\xFF',
    }

# Generated at 2022-06-23 15:50:24.586724
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\\([abfnrtv])', '\\a')) == "\a"
    assert escape(re.match('\\\\([abfnrtv])', '\\n')) == "\n"
    assert escape(re.match('\\\\(x....)', '\\xA0')) == " "
    assert escape(re.match('\\\\([0-7]...)', '\\777')) == "?"
    assert escape(re.match('\\\\([0-7]...)', '\\400')) == "@"

# Generated at 2022-06-23 15:50:30.055585
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"

# Generated at 2022-06-23 15:50:32.331635
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError:
        print("Unexpected Assertion raised in test_test")
        #raise