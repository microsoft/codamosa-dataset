

# Generated at 2022-06-23 15:40:38.406029
# Unit test for function escape
def test_escape():
    assert escape("\\x05") == chr(0x05)
    assert escape("\\x5") == chr(0x05)
    assert escape("\\05") == chr(0x03)
    assert escape("\\5") == chr(0x05)
    assert escape("\\a") == "\x07"
    assert escape("\\b") == "\x08"
    assert escape("\\f") == "\x0c"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\x0b"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"

# Generated at 2022-06-23 15:40:45.254674
# Unit test for function evalString
def test_evalString():
    assert evalString("'ar'") == 'ar'
    assert evalString("'\\t '") == '\t '
    assert evalString("'\\t \\' '") == '\t \' '
    assert evalString("'\\t \\\\ '") == '\t \\ '
    assert evalString("'\\x31'") == '\x31'
    assert evalString("'\\x31 \\x20'") == '\x31 \x20'


# Generated at 2022-06-23 15:40:56.508418
# Unit test for function evalString
def test_evalString():
    global simple_escapes

    assert evalString('"\\x01\\x02\\x03"') == "\x01\x02\x03"
    assert evalString('"\\x01"') == "\x01"
    assert evalString('"\\00"') == "\0"
    assert evalString('"\\000"') == "\0"
    assert evalString('"\\001"') == "\1"
    assert evalString('"\\0o1"') == "\1"
    assert evalString('"\\0O1"') == "\1"
    assert evalString('"\\1"') == "\1"
    assert evalString('"\\01"') == "\1"
    assert evalString('"\\11"') == "\t"
    assert evalString('"\\111"') == "I"

# Generated at 2022-06-23 15:40:57.467261
# Unit test for function test
def test_test():
  test()
  assert True

# Generated at 2022-06-23 15:41:09.366927
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("'a'") == "a"
    assert evalString("'\\t\\n\\r'") == "\t\n\r"
    assert evalString("'\\x61\\x62'") == "ab"
    assert evalString("'abc'") == "abc"
    assert evalString('"\\t\\n\\r"') == "\t\n\r"
    assert evalString('"\\x61\\x62"') == "ab"
    assert evalString('"abc"') == "abc"
    assert evalString('"a\\tb\\nc\\rd"') == "a\tb\nc\rd"
    assert evalString("'\"'") == '"'
    assert evalString('"\'"') == "'"
    assert evalString('"\\\\"')

# Generated at 2022-06-23 15:41:13.592323
# Unit test for function evalString
def test_evalString():
  assert evalString('"\\x61"') == 'a'
  assert evalString('"\\x63"') == 'c'
  assert evalString('"\\x2e"') == '.'
  assert evalString('"\\x22"') == '"'
  assert evalString("'\\x61'") == 'a'
  assert evalString("'\\x63'") == 'c'
  assert evalString("'\\x2e'") == '.'
  assert evalString("'\\x22'") == "'"
  #assert evalString('"\\x22"') == '"'

# Generated at 2022-06-23 15:41:26.245603
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello'") == "hello"
    assert evalString("'hello\\n'") == "hello\n"
    assert evalString("'\\x61pple'") == "apple"
    assert evalString("'\\0'") == "\x00"
    assert evalString("u'\\u1234'") == "\u1234"
    s = '\\u0D0A\\U00005041\\uAAA5'
    assert evalString(f"'{s}'") == '\u0d0a\U00005041\uaaa5'
    assert evalString(f"'\\u{i:04x}'") == '\u0100'
    assert evalString(f"'\\u{{{i:x}}}'") == '\u0100'

# Generated at 2022-06-23 15:41:34.672668
# Unit test for function evalString
def test_evalString():
    tests = {
        "''": "",
        '""': "",
        "'''''": "",
        '""""""': "",
        r"'abc'": "abc",
        r'"abc"': "abc",
        r"'a\"bc'": r'a"bc',
        r'"a\'bc"': r"a'bc",
        r"'\x7f'": chr(0x7f),
        r'"\x7f"': chr(0x7f),
        r"'\0'": chr(0),
        r'"\0"': chr(0),
    }

    for s, expected in tests.items():
        result = evalString(s)

# Generated at 2022-06-23 15:41:35.975342
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:41:36.625878
# Unit test for function test
def test_test():
    assert not test()

# Generated at 2022-06-23 15:41:49.180483
# Unit test for function escape
def test_escape():
    assert escape('\\x') == 'x'
    assert escape('\\0') == '\x00'
    assert escape('\\1') == '\x01'
    assert escape('\\7') == '\x07'
    assert escape('\\00') == '\x00'
    assert escape('\\01') == '\x01'
    assert escape('\\10') == '\x08'
    assert escape('\\11') == '\t'
    assert escape('\\17') == '\x0f'
    assert escape('\\27') == '\x1f'
    assert escape('\\117') == 'w'
    assert escape('\\377') == '\xff'
    assert escape('\\377') == '\xff'
    assert escape('\\x77') == 'w'

# Generated at 2022-06-23 15:41:58.950181
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\\'', "\\'")) == "'"
    assert escape(re.match(r'\\\"', '\\"')) == '"'
    assert escape(re.match(r'\\\\', '\\\\')) == "\\"
    assert escape(re.match(r'\\a', '\\a')) == "\a"
    assert escape(re.match(r'\\b', '\\b')) == "\b"
    assert escape(re.match(r'\\f', '\\f')) == "\f"
    assert escape(re.match(r'\\n', '\\n')) == "\n"
    assert escape(re.match(r'\\r', '\\r')) == "\r"

# Generated at 2022-06-23 15:42:04.933981
# Unit test for function test
def test_test():
    # Basic test
    test()

    # test octal escape
    assert evalString("'\\1'") == "\\x01"
    assert evalString("'\\41'") == "\\x11"
    assert evalString("'\\041'") == "!"
    assert evalString("'\\041'") == "!"

    # Check that we raise an error on invalid octal escapes
    try:
        evalString("'\\81'")
    except ValueError:
        pass
    else:
        assert False, "should have raised ValueError"

    # test hex escape
    assert evalString("'\\x01'") == "\\x01"
    assert evalString("'\\x41'") == "A"

    # Check that we raise an error on invalid hex escapes

# Generated at 2022-06-23 15:42:05.342419
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:05.734386
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:15.676049
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"
    assert escape("\\b") == "\b"
    assert escape("\\x41") == "A"
    assert escape("\\055") == "*"
    assert escape("\\37") == "!"
    # Allowed only in bytes literals
    # assert escape("\\0") == "\0"
    # assert escape("\\00") == "\0"
    # assert escape("\\333") == "\u0133"
    # assert escape("\\400") == "\u0200"
    # assert escape("\\900") == "\u0400"
    # assert escape("\\666") == "\uff6"
    # assert escape("\\0042") == "\x00B"
    assert escape("\\x041") == "A"
    assert escape("\\x044") == "D"

# Generated at 2022-06-23 15:42:25.936886
# Unit test for function evalString
def test_evalString():
    # Test boolean literals
    assert evalString('False') == 'False'
    assert evalString('False') == 'False'

    # Test byte literals
    assert evalString("b'a'") == "b'a'"
    assert evalString("b'\\x00'") == "b'\\x00'"
    assert evalString("b'\\x10\\x01\\x02'") == "b'\\x10\\x01\\x02'"

    # Test unicode literals
    assert evalString("u'a'") == "u'a'"
    assert evalString("u'\\x00'") == "u'\\x00'"
    assert evalString("u'\\x10\\x01\\x02'") == "u'\\x10\\x01\\x02'"

    # Test string literals
    assert evalString

# Generated at 2022-06-23 15:42:37.439965
# Unit test for function evalString
def test_evalString():
    assert evalString("'''hola'''") == 'hola'
    assert evalString("'''''hola'''") == "'''hola"
    assert evalString("'hola'") == "hola"
    assert evalString("'ho\\'la'") == "ho'la"
    assert evalString("'hola'") == "hola"
    assert evalString("'hola\\nmundo'") == "hola\nmundo"
    assert evalString("'hola\\nmu\\x6edo'") == "hola\nmundo"
    assert evalString("'\\x68ola\\nmu\\x6edo'") == "hola\nmundo"
    assert evalString("'hola\\nmu\\x6ed\\x6f'") == "hola\nmundo"

# Generated at 2022-06-23 15:42:47.393401
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\x80"') == "\x80", r"incorrect result for r'\"\\x80\"'"
    assert evalString(r'"\100"') == "\100", r"incorrect result for r'\"\\100\"'"

# Generated at 2022-06-23 15:42:50.272929
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-23 15:42:51.796281
# Unit test for function test
def test_test():
    pass



# Generated at 2022-06-23 15:42:57.878587
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\x61", "\\x61")) == "a"
    assert escape(re.match(r"\\071", "\\071")) == "9"
    assert escape(re.match(r"\\'", "\\'")) == "'"

# Generated at 2022-06-23 15:43:08.570456
# Unit test for function evalString
def test_evalString():
    # Test '\n', '\t', 'x'
    assert evalString('"\\n\\t\\x61\\x62"') == '\n\tab'
    
    # Test '\000'
    assert evalString('"\\000"') == '\000'
    
    # Test '\x' exception
    try:
        evalString('"\\x"')
    except ValueError:
        pass
    else:
        raise AssertionError
    
    # Test '\00' exception
    try:
        evalString('"\\00"')
    except ValueError:
        pass
    else:
        raise AssertionError

    # Test '\0'
    assert evalString('"\\0"') == '\0'
    
    # Test '\x0'

# Generated at 2022-06-23 15:43:20.414488
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString('"a\nbc"') == 'a\nbc'
    assert evalString("'a\nbc'") == 'a\nbc'
    assert evalString('"a\rbc"') == "a\rbc"
    assert evalString("'a\rbc'") == "a\rbc"
    assert evalString('"a\0bc"') == "a\0bc"
    assert evalString("'a\0bc'") == "a\0bc"
    assert evalString('"a\x00bc"') == "a\0bc"
    assert evalString("'a\x00bc'") == "a\0bc"

# Generated at 2022-06-23 15:43:31.590341
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'a\\'bc'") == "a'bc"
    assert evalString("'ab\\bc'") == "abbc"
    assert evalString('"abc"') == "abc"
    assert evalString('"a\\"bc"') == 'a"bc'
    assert evalString('"ab\\bc"') == 'abbc'
    assert evalString("'abc\\n'") == "abc\n"
    assert evalString("'abc\\r'") == "abc\r"
    assert evalString("'abc\\t'") == "abc\t"
    assert evalString("'abc\\0'") == "abc\0"
    assert evalString("'abc\\47'") == "abc/"
    assert evalString("'abc\\141'")

# Generated at 2022-06-23 15:43:33.809259
# Unit test for function test
def test_test():
    """
    This test doesn't test anything
    """

    test()


if __name__ == "__main__":
    test()

# Generated at 2022-06-23 15:43:35.729752
# Unit test for function test
def test_test():
    # Check that no exception is raised
    test()



# Generated at 2022-06-23 15:43:44.955030
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'a\nb'") == "a\nb"
    assert evalString('"a\rb"') == "a\rb"
    assert evalString('"a\tb"') == "a\tb"
    assert evalString('"a\nb"') == "a\nb"
    assert evalString("'a\'b'") == "a'b"
    assert evalString('"a\"b"') == 'a"b'
    assert evalString('"a\\b"') == "a\\b"


# Generated at 2022-06-23 15:43:55.847981
# Unit test for function escape
def test_escape():
    """Test escape()."""
    for i in range(256):
        s = "\\x%x" % i
        e = evalString(s)
        assert e == chr(i), "A: %s, %s, %s" % (s, e, chr(i))
        s = "\\%03o" % i
        e = evalString(s)
        assert e == chr(i), "B: %s, %s, %s" % (s, e, chr(i))
    assert evalString("\\a") == "\a"
    assert evalString("\\b") == "\b"
    assert evalString("\\f") == "\f"
    assert evalString("\\n") == "\n"
    assert evalString("\\r") == "\r"

# Generated at 2022-06-23 15:44:02.287358
# Unit test for function evalString
def test_evalString():
    import random

    for quote in ["'", '"']:
        for i in range(256):
            c = chr(i)
            s = repr(c)
            e = evalString(s)
            assert e == c

            s = quote + repr(c) + quote
            e = evalString(s)
            assert e == c

            # put some quotes inside
            t = list(s)
            while t[1] == t[-2]:
                random.shuffle(t)
            s = "".join(t)
            e = evalString(s)
            assert e == c

# Generated at 2022-06-23 15:44:11.686842
# Unit test for function evalString
def test_evalString():
    evalString = strlit.evalString
    assert evalString("''") == ""

# Generated at 2022-06-23 15:44:16.579518
# Unit test for function evalString
def test_evalString():
    assert evalString("'string'") == "string"
    assert evalString("'''string'''") == "string"
    assert evalString("'\\'string\\''") == "'string'"
    assert evalString("'''\\'string\\'''") == "'string'"
    assert evalString("'\\x61'") == "a"
    assert evalString('"\\u0040"') == "@"
    assert evalString("'''\x07'''") == "\x07"
    assert evalString("r'\\n'") == r"\n"
    assert evalString("r'''\\n'''") == r"\n"

# Generated at 2022-06-23 15:44:22.140448
# Unit test for function escape
def test_escape():
    # test simple escapes
    assert escape(re.match(r"\\" + simple_escapes[c], repr(c))) == c
    # test hex escapes
    assert escape(re.match(r"\\x00", "\x00")) == "\x00"
    assert escape(re.match(r"\\xff", "\xff")) == "\xff"
    assert escape(re.match(r"\\x0f", "\x0f")) == "\x0f"
    # test oct escapes
    assert escape(re.match(r"\\000", "\000")) == "\000"
    assert escape(re.match(r"\\377", "\377")) == "\377"
    assert escape(re.match(r"\\077", "\077")) == "\077"

# Generated at 2022-06-23 15:44:32.528918
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString('"\n"') == "\n"
    assert evalString('"\u0394"') == "\u0394"
    assert evalString('"\xdc"') == "\xdc"
    assert evalString("'abc'") == "abc"
    assert evalString("'\n'") == "\n"
    assert evalString("'\u0394'") == "\u0394"
    assert evalString("'\xdc'") == "\xdc"
    assert evalString('"""abc"""') == "abc"
    assert evalString('"""\n"""') == "\n"
    assert evalString('"""\u0394"""') == "\u0394"
    assert evalString('"""\xdc"""') == "\xdc"
    assert evalString

# Generated at 2022-06-23 15:44:42.159227
# Unit test for function evalString

# Generated at 2022-06-23 15:44:42.659415
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:54.810734
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == 'a'
    assert evalString("'\\''") == "'"
    assert evalString("'\\\\'") == '\\'
    assert evalString("'\\x61'") == 'a'
    assert evalString("'\\a'") == '\a'
    assert evalString("'\\n'") == '\n'
    assert evalString("'\\r'") == '\r'
    assert evalString("'\\x20'") == ' '
    assert evalString("'\\u1234'") == '\u1234'
    assert evalString("'\\U00012345'") == '\U00012345'

# Generated at 2022-06-23 15:45:05.362673
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"[\\]x", "\\x")) == ""
    assert escape(re.match(r"[\\]x", "\\xx")) == "x"
    assert escape(re.match(r"[\\]x", "\\xxx")) == "xx"
    assert escape(re.match(r"[\\]x", "\\xxxx")) == "xxx"
    assert escape(re.match(r"[\\][0-7]", "\\0")) == "\x00"
    assert escape(re.match(r"[\\][0-7]", "\\01")) == "\x01"
    assert escape(re.match(r"[\\][0-7]", "\\012")) == "\x01"
    assert escape(re.match(r"[\\][0-7]", "\\0123")) == "\x01"


# Generated at 2022-06-23 15:45:06.406119
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:09.245711
# Unit test for function escape
def test_escape():
    c = escape(re.match(r"\\x1b", "\\x1b"))
    assert c == "\x1b"

# Generated at 2022-06-23 15:45:18.636031
# Unit test for function evalString
def test_evalString():
    assert evalString("'test'") == "test"
    assert evalString('"test"') == "test"
    assert evalString("'test\\ntest'") == "test\ntest"
    assert evalString("'test\\rtest'") == "test\rtest"
    assert evalString("'test\\r\\ntest'") == "test\r\ntest"
    assert evalString("'test\\vtest'") == "test\vtest"
    assert evalString("'test\\x09test'") == "test\ttest"
    assert evalString("'test\\x7ftest'") == "test\x7ftest"
    assert evalString("'test\\x7Ftest'") == "test\x7Ftest"

# Generated at 2022-06-23 15:45:30.021362
# Unit test for function escape
def test_escape():
    from string import ascii_letters, digits

    for c in ascii_letters + digits + '_':
        assert escape(re.match(r'\\' + re.escape(c), '\\' + c)) == c

    assert escape(re.match(r"\\'", "\\'")) == '\''
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape(re.match(r'\\\\', '\\\\')) == '\\'

    # '\a', '\b', '\f', '\n', '\r', '\t', and '\v'
    # '\x' followed by any number of hexadecimal digits
    # '\N{name}' where name is the name of a Unicode character in the Unicode database
    # '\u' followed

# Generated at 2022-06-23 15:45:31.262181
# Unit test for function evalString
def test_evalString():
    raise NotImplementedError()

# Generated at 2022-06-23 15:45:39.833032
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"

    for esc in simple_escapes.keys():
        assert escape("\\" + esc) == simple_escapes[esc]

    assert escape("\\x0A") == "\n"
    assert escape("\\xAA") == chr(0xAA)
    #assert escape("\\xAAB") == chr(0xAAB)
    #assert escape("\\xAABB") == chr(0xAABB)

    assert escape("\\011") == "\t"

# Generated at 2022-06-23 15:45:41.118435
# Unit test for function test
def test_test():
    assert test() is None, "test failed"

# Generated at 2022-06-23 15:45:43.725929
# Unit test for function escape
def test_escape():
    # Check that '\x' is not escaped
    assert escape(r"\x") == '\\x'


# Generated at 2022-06-23 15:45:56.183569
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "'abc'"
    assert evalString('"abc"') == '"abc"'
    assert evalString("'abc'") != '"abc"'
    assert evalString('"abc"') != "'abc'"
    assert evalString("'\\\\'") == "'\\'"
    assert evalString('"\\"') == '"\\"'
    assert evalString('r"\r"') == '"\\r"'
    assert evalString('r"\n"') == '"\\n"'
    assert evalString('r"\r\n"') == '"\\r\\n"'
    assert evalString('r"\\r\\n"') == '"\\\\r\\\\n"'
    assert evalString('r"\'"') == '"\\\'"'

# Generated at 2022-06-23 15:45:56.799382
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:46:06.117764
# Unit test for function evalString
def test_evalString():
    a = evalString(b'"\\0"')
    assert a == b"\x00"
    b = evalString(b'"\\t"')
    assert b == b"\t"
    c = evalString(b'"\\n"')
    assert c == b"\n"
    d = evalString(b'"\\r"')
    assert d == b"\r"
    e = evalString(b'"\\x00"')
    assert e == b"\x00"
    f = evalString(b'"\\x5C"')
    assert f == b"\\"
    g = evalString(b'"\\x5Cabcdef"')
    assert g == b"\\abcdef"
    h = evalString(b'"\\x5C7"')
    assert h == b"\\7"

# Generated at 2022-06-23 15:46:17.374949
# Unit test for function evalString

# Generated at 2022-06-23 15:46:26.022748
# Unit test for function escape
def test_escape():
    cases = [
        ("\\z", "z", "escape of single char"),
        ("\\\\", "\\", "escape of a backslash"),
        ("\\n", "\n", "escape of a newline"),
        ("\\'", "'", "escape of a single quote"),
        ("\\012", "\n", "escape of a octal char"),
        ("\\x0a", "\n", "escape of a hex char"),
    ]
    for s, expected, msg in cases:
        m = re.match(r"\\(.*)", s)
        actual = escape(m)
        assert actual == expected, msg

# Generated at 2022-06-23 15:46:37.158518
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', r'\a')) == '\a'
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', r'\b')) == '\b'
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', r'\f')) == '\f'

# Generated at 2022-06-23 15:46:45.467004
# Unit test for function escape
def test_escape():
    assert escape("\a") == "\\a"  # \a does not exist in escape_dict
    assert escape("\\a") == "\\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\x0040") == "\x0040"
    assert escape("\\x0a") == "\x0a"
    assert escape("\\x44") == "\x44"
    assert escape("\\0123") == "\0123"
    assert escape("\\1234") == "\\1234"  # \123 does not exist in escape_dict

# Generated at 2022-06-23 15:46:56.392263
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\n"') == "\n"
    assert evalString('"a"') == "a"
    assert evalString("'a'") == "a"
    assert evalString("'\\''") == "'"
    assert evalString('"""\n"""') == "\n"
    assert evalString('"\\""') == '"'
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\f"') == "\f"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString('"\\t"') == "\t"

# Generated at 2022-06-23 15:46:57.316583
# Unit test for function evalString
def test_evalString():
    assert evalString('"\'"') == "'"

# Generated at 2022-06-23 15:46:57.806442
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:00.478634
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString("'a'") == "a"
    assert evalString('"\\"a\\""') == '"a"'
    assert evalString("'\\'a\\''") == "'a'"

# Generated at 2022-06-23 15:47:01.256181
# Unit test for function test
def test_test():
    assert test() is None


# Generated at 2022-06-23 15:47:01.730200
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:11.779925
# Unit test for function escape
def test_escape():
    assert escape('\\\'') == '\''
    assert escape('\\"') == '"'
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\x08') == '\x08'
    assert escape('\\xFF') == '\xFF'
    assert escape('\\377') == '\xFF'



# Generated at 2022-06-23 15:47:13.843774
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\'", chr(0))) == chr(0)

# Generated at 2022-06-23 15:47:14.348211
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:14.867366
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:17.169717
# Unit test for function test
def test_test():
    """Function test passed."""
    assert test() == None



# Generated at 2022-06-23 15:47:27.982761
# Unit test for function escape
def test_escape():
    # Test round-trip
    for c in "abfnrtv'\"\\":
        assert evalString(repr(c)) == c

    # Test escape characters
    assert evalString(repr("\a")) == "\a"
    assert evalString(repr("\b")) == "\b"
    assert evalString(repr("\f")) == "\f"
    assert evalString(repr("\n")) == "\n"
    assert evalString(repr("\r")) == "\r"
    assert evalString(repr("\t")) == "\t"
    assert evalString(repr("\v")) == "\v"

    # Test standard hex escape
    assert evalString(repr("\x5A")) == "\x5A"
    assert evalString(repr("\x5a")) == "\x5a"


# Generated at 2022-06-23 15:47:38.493541
# Unit test for function evalString
def test_evalString():
  assert evalString('"abc"') == 'abc'
  assert evalString("'abc'") == 'abc'
  assert evalString('"\\"\\"\\""') == '"""'
  assert evalString("'\\'\\'\\''") == "'''"
  assert evalString('"\\a\\b\\f\\n\\r\\t\\v"') == "\a\b\f\n\r\t\v"
  assert evalString('"\\001\\002\\0003\\0\\04"') == "\x01\x02\x03\x00\x04"
  assert evalString('"\\x01\\x02\\x03\\x04"') == "\x01\x02\x03\x04"

# Generated at 2022-06-23 15:47:39.630764
# Unit test for function test
def test_test():
    assert evalString("'abc'") == "abc"

# Generated at 2022-06-23 15:47:50.312107
# Unit test for function evalString
def test_evalString():
    # Trivial cases
    assert evalString('""') == ''
    assert evalString('"xyzzy"') == 'xyzzy'
    assert evalString('"x" + "y"') == 'xy'
    assert evalString("'" + 'x' + "'") == 'x'

    # Empty string
    assert evalString('""') == ''
    assert evalString('\'\'') == ''
    assert evalString('""""""') == ''
    assert evalString('\'\'\'\'\'') == ''

    # Escape sequences
    assert evalString(r'"\""') == '"'
    assert evalString(r'"\\"') == '\\'
    assert evalString(r'"\'"') == "'"

# Generated at 2022-06-23 15:47:52.146649
# Unit test for function test
def test_test():
    """Verify that all possible input strings are properly handled."""
    test()

# Generated at 2022-06-23 15:47:52.732164
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:48:04.824779
# Unit test for function escape
def test_escape():
    assert escape("\\n") == "\n"
    assert escape("\\0") == "\0"
    assert escape("\\a") == "\a"
    with pytest.raises(ValueError):
        escape("\\")
    with pytest.raises(ValueError):
        escape("\\x")
    with pytest.raises(ValueError):
        escape("\\y")
    with pytest.raises(ValueError):
        escape("\\x1")
    with pytest.raises(ValueError):
        escape("\\x12")
    with pytest.raises(ValueError):
        escape("\\x123")
    with pytest.raises(ValueError):
        escape("\\x123x")
    assert escape("\\0") == "\0"
    assert escape("\\00") == "\0\0"


# Generated at 2022-06-23 15:48:11.016346
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'\x61'") == 'a'
    assert evalString(r"'\0'") == '\0'
    assert evalString(r"'\000'") == '\0'
    assert evalString(r"'\000\000'") == '\0\0'
    assert evalString(r"'\077'") == '?'
    assert evalString(r"'\377'") == chr(255)
    assert evalString(r"'\111\222\333'") == chr(73) + chr(146) + chr(51)
    assert evalString(r"'\1111'") == chr(73) + '1'
    assert evalString(r"'\1111'") == 'I1'

# Generated at 2022-06-23 15:48:19.171063
# Unit test for function escape
def test_escape():
    cases = (
        ("case should be skipped", "\\n", "\\n", "\n"),
        ("case should be skipped", "\\12", "\\12", "\n"),
        ("case should be skipped", "\\x44", "\\x44", "D"),
        ("case should be skipped", "\\0", "\\0", "\x00"),
        ("case should be skipped", "\\x442", "\\x442", "\x442"),
    )
    test_escape.failures = 0

    def check_escape(m, pat, repl, expected):
        try:
            actual = escape(m)
        except ValueError:
            actual = ValueError

# Generated at 2022-06-23 15:48:28.685492
# Unit test for function escape
def test_escape():
    tests = [
        ("\a", "\\a"),
        ("\b", "\\b"),
        ("\f", "\\f"),
        ("\n", "\\n"),
        ("\r", "\\r"),
        ("\t", "\\t"),
        ("\v", "\\v"),
        ("'", r"\'"),
        ('"', r'\"'),
        ("\\", r"\\"),
        ("\000", "\\000"),
        ("\135", "\\135"),
        ("\x7f", "\\x7f"),
        ("\xff", "\\xff"),
        ("\u1234", "\\u1234"),
        ("\U00010111", "\\U00010111"),
    ]

# Generated at 2022-06-23 15:48:39.577660
# Unit test for function escape
def test_escape():
    # test all single character escapes
    for value, result in simple_escapes.items():
        try:
            assert escape(re.search(rf"\\{value}", value)) == result
        except AttributeError:
            # re.search returns None if no match is found
            assert value == result
    # test all multi character escapes
    assert escape(re.search(r"\\x10", "\\x10")) == "\x10"
    assert escape(re.search(r"\\x10", "\\x10")) == "\x10"
    assert escape(re.search(r"\\x10", "\\x10")) == "\x10"
    assert escape(re.search(r"\\x10", "\\x10")) == "\x10"
    assert escape(re.search(r"\\x10", "\\x10"))

# Generated at 2022-06-23 15:48:44.334985
# Unit test for function escape
def test_escape():
    tests = {
        r"\a": "a",
        r"\b": "b",
        r"\f": "f",
        r"\n": "n",
        r"\r": "r",
        r"\t": "t",
        r"\v": "v",
        r"\'": "'",
        r"\"": '"',
        r"\\": "\\",
        r"\x01": ".",
        r"\xFF": ".",
        r"\x00": "\x00",
        r"\x27": "\x27",
    }

# Generated at 2022-06-23 15:48:45.692041
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:54.806240
# Unit test for function escape
def test_escape():
    assert escape(re.search("\\b", "")) == "\b"
    assert escape(re.search("\\t", "")) == "\t"
    assert escape(re.search("\\x00", "")) == "\x00"
    assert escape(re.search("\\x01", "")) == "\x01"
    assert escape(re.search("\\x01", "")) == "\x01"
    assert escape(re.search("\\x01", "")) == "\x01"
    assert escape(re.search("\\x01", "")) == "\x01"
    assert escape(re.search("\\x01", "")) == "\x01"
    assert escape(re.search("\\x01", "")) == "\x01"
    assert escape(re.search("\\x01", "")) == "\x01"
    assert escape

# Generated at 2022-06-23 15:48:55.406538
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:57.379224
# Unit test for function evalString
def test_evalString():
  import string
  for s in string.printable:
    assert s == evalString(repr(s))

# Generated at 2022-06-23 15:48:57.982471
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:02.747453
# Unit test for function evalString
def test_evalString():
    assert evalString("'/usr/bin/perl'") == "/usr/bin/perl"
    assert evalString('"/usr/bin/perl"') == "/usr/bin/perl"
    assert evalString('"a\\tb\nd"') == "a\tb\nd"

# Generated at 2022-06-23 15:49:07.649572
# Unit test for function escape
def test_escape():
    simple_escapes = {
        "a": "\a",
        "b": "\b",
        "f": "\f",
        "n": "\n",
        "r": "\r",
        "t": "\t",
        "v": "\v",
        "'": "'",
        '"': '"',
        "\\": "\\",
    }

    for s in simple_escapes.keys():
        assert escape(s) == simple_escapes[s]



# Generated at 2022-06-23 15:49:18.491406
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\'"') == r"\'"
    assert evalString(r"'\\'") == r"\\"
    assert evalString(r'"\a\b\f\n\r\t\v\"\'\\"') == r"\a\b\f\n\r\t\v\"\'\\"
    assert evalString(r"'\a\b\f\n\r\t\v\"\'\\'") == r"\a\b\f\n\r\t\v\"\'\\"

# Generated at 2022-06-23 15:49:21.807870
# Unit test for function test
def test_test():
  # Test that we get the same result for all 256 bytes
  for i in range(256):
    c = chr(i)
    s = repr(c)
    e = evalString(s)
    assert(e == c)


# TODO: test Unicode escapes
# TODO: test Unicode strings

# Generated at 2022-06-23 15:49:23.858084
# Unit test for function test
def test_test():
    try:
        test()
    except SystemExit:
        pass

# Generated at 2022-06-23 15:49:30.125119
# Unit test for function escape
def test_escape():
    match = re.match(r"\\(x.{0,2}|[0-7]{1,3}|[abfnrtv]|\\|['\"])",
                     '\\xaa')
    result = escape(match)
    assert isinstance(result, str)
    assert result == chr(0xaa)
    # TODO: Test remaining arguments to escape().  All known test cases
    # currently pass.

# Generated at 2022-06-23 15:49:30.743528
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:31.397127
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:33.852437
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-23 15:49:42.190012
# Unit test for function escape
def test_escape():

    value = r'\''
    result_value = escape(value)
    assert result_value == "'"

    value = r'\"'
    result_value = escape(value)
    assert result_value == '"'

    value = r'\\'
    result_value = escape(value)
    assert result_value == '\\'

    value = r'\a'
    result_value = escape(value)
    assert result_value == '\x07'

    value = r'\b'
    result_value = escape(value)
    assert result_value == '\x08'

    value = r'\f'
    result_value = escape(value)
    assert result_value == '\x0c'

    value = r'\n'
    result_value = escape(value)
    assert result_

# Generated at 2022-06-23 15:49:44.307216
# Unit test for function test
def test_test():
    """Verify that test() function runs without exception."""
    test()

# Generated at 2022-06-23 15:49:55.110791
# Unit test for function evalString
def test_evalString():
    assert evalString("'a\\'\\''") == "a'"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61\\x62'") == "ab"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63\\x64'") == "abcd"
    assert evalString("'\\x61\\x62\\x63\\x64\\x65'") == "abcde"
    assert evalString("'\\x61\\x62\\x63\\x64\\x65\\x66'") == "abcdef"
    assert evalString("'\\x61\\x62\\x63\\x64\\x65\\x66\\x67'") == "abcdefg"

# Generated at 2022-06-23 15:50:04.216856
# Unit test for function escape
def test_escape():
    samples = [
        ("\\\a", "\a"),
        ("\\\b", "\b"),
        ("\\\f", "\f"),
        ("\\\n", "\n"),
        ('\\\n', '\n'),
        ("\\\r", "\r"),
        ("\\\t", "\t"),
        ("\\\v", "\v"),
        ('\\\v', '\v'),
        ("\\\'", "'"),
        ('\\\"', '"'),
        ("\\\\", "\\"),
        ("\\\xFF", "\xFF"),
        ("\\\377", "\377"),
    ]

    for sample in samples:
        assert evalString(sample[0]) == sample[1]

# Generated at 2022-06-23 15:50:14.711532
# Unit test for function escape
def test_escape():
    tests = [
        ["a", "'\\a'"],
        ["b", "'\\b'"],
        ["f", "'\\f'"],
        ["n", "'\\n'"],
        ["r", "'\\r'"],
        ["t", "'\\t'"],
        ["v", "'\\v'"],
        ["'", '"\'"'],
        ['"', "'\"'"],
        ["\\", "'\\\\'"],
    ]
    for expected, pattern in tests:
        m = re.match(r"\\(.{1})", pattern)
        if m is None:
            assert False, "could not build match"
        assert escape(m) == expected

# Generated at 2022-06-23 15:50:24.587415
# Unit test for function escape
def test_escape():
    escape_cases = [
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\\\", "\\"),
        ("\\x4f", "O"),
        ("\\040", " "),
        ("\\0", "\0"),
        ("\\5", "\x05"),
        ("\\05", "\x05"),
        ("\\053", "\x053"),
    ]
    for (escape_expr, expected) in escape_cases:
        res = escape(re.match(r"\\\w", escape_expr))
        assert res == expected

# Generated at 2022-06-23 15:50:25.816779
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:50:32.613575
# Unit test for function evalString
def test_evalString():
    test_input = ['\'aabbccdd\'', '\"aabbccdd\"']
    test_output = ['aabbccdd', 'aabbccdd']

    def test_internal():
        for i in range(len(test_input)):
            assert evalString(test_input[i]) == test_output[i]

    return test_internal


test_evalString()