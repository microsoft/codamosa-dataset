

# Generated at 2022-06-23 15:40:32.764493
# Unit test for function test
def test_test():
    """Test evalstring.test()"""
    test()


# Generated at 2022-06-23 15:40:33.587805
# Unit test for function escape
def test_escape():
    pass


# Generated at 2022-06-23 15:40:44.960072
# Unit test for function escape
def test_escape():
    esc = escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\t'))
    assert esc == "\t"
    esc = escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\n'))
    assert esc == "\n"
    esc = escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\"'))
    assert esc == '"'

# Generated at 2022-06-23 15:40:48.844900
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == 'a'
    assert evalString('"b"') == 'b'
    assert evalString("'c'") == 'c'
    assert evalString("'\\xb'") == '\x0b'
    assert evalString(r"'\\n'") == '\\n'

# Generated at 2022-06-23 15:40:56.066837
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\xFF", r"\xFF")) == '\xFF'
    assert escape(re.match(r"\\xF", r"\xF")) == '\x0F'
    assert escape(re.match(r"\\xFF", r"\xFF")) == '\xFF'
    assert escape(re.match(r"\\xFF", r"\xFF")) == '\xFF'

# Generated at 2022-06-23 15:40:56.523347
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:58.593094
# Unit test for function evalString
def test_evalString():
    """Test that evalString returns the same string."""
    assert evalString("'abc'") == "abc", "evalString failed"


# Generated at 2022-06-23 15:41:04.962253
# Unit test for function evalString
def test_evalString():
    test_cases = (
        '""',
        '"hi"',
        '"\\"hi\\""',
        '"\\x12"',
        '"\\177"',
        '"\\377"',
        '"\\498"',
        '"\\1000"',
        "''",
        "'hi'",
        "'\\'hi\\''",
        "'\\x12'",
        "'\\177'",
        "'\\377'",
        "'\\498'",
        "'\\1000'",
        "'\\\''",
        '"\\\""',
        "'\\\\'",
    )
    for case in test_cases:
        evalString(case)

# Generated at 2022-06-23 15:41:11.996790
# Unit test for function evalString
def test_evalString():
    # Test basic strings
    assert evalString("'hello'") == "hello"
    assert evalString("'hello\\nworld'") == "hello\nworld"

    # Test that evalString() works with the "long string"
    # representation allowed by Python (any number of
    # row quotes)
    assert evalString("'''''hello'''''") == "'hello'"
    assert evalString('"""hello"""') == '"hello"'
    assert evalString("""'''hel'lo'''""") == "'hel'lo'"
    assert evalString('""""he"llo"""') == '"he"llo"'

    # Test that evalString() works with the "raw string"
    # representation allowed by Python (which suppresses
    # the special meaning of backslashes)

# Generated at 2022-06-23 15:41:24.976113
# Unit test for function test
def test_test():
    import pytest
    from textwrap import dedent


# Generated at 2022-06-23 15:41:34.717983
# Unit test for function evalString
def test_evalString():
    result = evalString('"\'testing\'"')
    expected = "'testing'"
    assert result == expected
    result = evalString("'\\n'")
    expected = "\n"
    assert result == expected
    result = evalString("'\\r\\n'")
    expected = "\r\n"
    assert result == expected
    result = evalString("'\\r\\n'")
    expected = "\r\n"
    assert result == expected
    result = evalString("'\\''")
    expected = "'"
    assert result == expected
    result = evalString("'\\\\'")
    expected = "\\"
    assert result == expected
    result = evalString("'\\v'")
    expected = "\v"
    assert result == expected
    result = evalString("'\\0'")

# Generated at 2022-06-23 15:41:47.764512
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("'ab'") == "ab"
    assert evalString("r'ab'") == "ab"
    assert evalString("r'''ab'''") == "ab"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\xff'") == "\xff"
    assert evalString("'\\u00ff'") == "\xff"
    assert evalString("'\\xab'") == "\xab"
    assert evalString("'\\0'") == "\0"
    # Issue #87 requires a second "\" to escape in a raw string.
    assert evalString("r'\\0'") == "\\0"
    assert evalString("'\\0'") == "\0"

# Generated at 2022-06-23 15:41:57.962811
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("''") == ""
    assert evalString("'test'") == "test"
    assert evalString("'test2'") == "test2"
    assert evalString("'test3'") == "test3"
    assert evalString("'test4'") == "test4"
    assert evalString("'test5'") == "test5"
    assert evalString("'test6'") == "test6"
    assert evalString("'test7'") == "test7"
    assert evalString("'test8'") == "test8"
    assert evalString("'test9'") == "test9"
    assert evalString("'test10'") == "test10"
    assert evalString("'test11'") == "test11"
   

# Generated at 2022-06-23 15:42:05.219278
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\n"') == '\n'
    assert evalString("'\\n'") == '\n'
    assert evalString("'''\\n'") == '\n'
    assert evalString("'\\''") == "'"
    assert evalString("'\\x61\\x62'") == 'ab'
    assert evalString('"\\x61\\x62"') == 'ab'

# Generated at 2022-06-23 15:42:08.526580
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"

# Generated at 2022-06-23 15:42:17.673610
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-23 15:42:18.171369
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:23.928141
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x56\\043"') == 'V#'
    assert evalString('"\\043"') == "#"
    assert evalString('"\\x56"') == "V"
    assert evalString('"\\56"') == "8"
    assert evalString('"\\x56"') == "V"
    assert evalString('"V"'), "V"
    assert evalString('"\\n"'), "\n"
    assert evalString('"\\n"') == "\n"

# Generated at 2022-06-23 15:42:25.284382
# Unit test for function test
def test_test():
    test() # it's a function - and we are testing it...


# Generated at 2022-06-23 15:42:34.222976
# Unit test for function escape
def test_escape():
    import os

    escaped_string = "\\x00"
    expected = chr(0)
    result = escape(escaped_string)
    assert result == expected
    escaped_string = "\\x10"
    expected = chr(16)
    result = escape(escaped_string)
    assert result == expected
    escaped_string = "\\x2a"
    expected = chr(42)
    result = escape(escaped_string)
    assert result == expected
    escaped_string = "\\x4d"
    expected = chr(77)
    result = escape(escaped_string)
    assert result == expected
    escaped_string = "\\x7f"
    expected = chr(127)
    result = escape(escaped_string)
    assert result == expected

# Generated at 2022-06-23 15:42:37.050313
# Unit test for function test
def test_test():
    try:
        test()
    except SystemExit:
        raise AssertionError("Caught exit() call")

# Generated at 2022-06-23 15:42:49.189386
# Unit test for function evalString
def test_evalString():
    """Test that evalString accepts and correctly interprets valid input
    """
    assert evalString('"\u55aa\u55bb"') == '\u55aa\u55bb'
    assert evalString("'\u55aa\u55bb'") == '\u55aa\u55bb'
    assert evalString("'\u55aa\\\u55bb'") == '\u55aa\\\u55bb'
    assert evalString('"\u55aa\\\u55bb"') == '\u55aa\\\u55bb'

    assert evalString("'\xaa\xbb'") == '\xaa\xbb'
    assert evalString('"\xaa\xbb"') == '\xaa\xbb'

# Generated at 2022-06-23 15:42:55.210537
# Unit test for function escape
def test_escape():
    assert escape('\\\'') == "'"
    assert escape('\\"') == '"'
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\x21') == '!'
    assert escape('\\x4e') == 'N'
    assert escape('\\01') == '\x01'
    assert escape('\\001') == '\x01'
    assert escape('\\111') == 'I'


# Unit tests for function evalString

# Generated at 2022-06-23 15:42:58.530048
# Unit test for function escape
def test_escape():
    assert escape('\u0041') == 'A'
    assert escape('\u0042') == 'B'
    assert escape('\u0043') == 'C'
    assert escape('\u0044') == 'D'

# Generated at 2022-06-23 15:43:07.664977
# Unit test for function evalString
def test_evalString():
    # TODO: As of mypy 0.600, mypy cannot handle the below line.
    # It could also be done with a string with newlines in it.
    # The mypy issue is at https://github.com/python/mypy/issues/5487.
    assert evalString((r"'" * 3) + r"\xabcd" + ("'" * 3)) == "\xabcd"
    assert (
        # TODO: As of mypy 0.600, mypy cannot handle the below line.
        evalString('"\\a\\b\\f\\n\\r\\t\\v\\\\"') == "\a\b\f\n\r\t\v\\"
    )

# Generated at 2022-06-23 15:43:19.880554
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\", r"\a")) == "\a"
    assert escape(re.match(r"\\", r"\b")) == "\b"
    assert escape(re.match(r"\\", r"\f")) == "\f"
    assert escape(re.match(r"\\", r"\n")) == "\n"
    assert escape(re.match(r"\\", r"\r")) == "\r"
    assert escape(re.match(r"\\", r"\t")) == "\t"
    assert escape(re.match(r"\\", r"\v")) == "\v"
    assert escape(re.match(r"\\", r"\'")) == "'"
    assert escape(re.match(r"\\", r'\"')) == '"'
    assert escape

# Generated at 2022-06-23 15:43:28.724398
# Unit test for function escape
def test_escape():
    e = escape(re.match(r"\\x[0-9a-f][0-9a-f]", "\\xab"))
    assert 'ab' in e
    e = escape(re.match(r"\\x.{0,2}", "\\x" * 10))
    assert e == ''
    e = escape(re.match(r"\\[0-7]{1,3}", "\\1234"))
    assert e == ''
    e = escape(re.match(r"\\'", "\\'"))
    assert e == "'"

# Generated at 2022-06-23 15:43:36.455530
# Unit test for function escape
def test_escape():
    # Simple escapes
    assert escape(re.match(r'\\([abfnrtv\'\"\\])', r'\a')) == '\a'
    assert escape(re.match(r'\\([abfnrtv\'\"\\])', r'\b')) == '\b'
    assert escape(re.match(r'\\([abfnrtv\'\"\\])', r'\f')) == '\f'
    assert escape(re.match(r'\\([abfnrtv\'\"\\])', r'\n')) == '\n'
    assert escape(re.match(r'\\([abfnrtv\'\"\\])', r'\r')) == '\r'

# Generated at 2022-06-23 15:43:47.596728
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\x1a', r'\x1a')) == '\x1a'
    assert escape(re.match(r'\\x07', r'\x07')) == '\x07'
    assert escape(re.match(r'\\x15', r'\x15')) == '\x15'
    assert escape(re.match(r'\\xfd', r'\xfd')) == '\xfd'
    assert escape(re.match(r'\\x99', r'\x99')) == '\x99'
    assert escape(re.match(r'\\x76', r'\x76')) == '\x76'
    assert escape(re.match(r'\\xaa', r'\xaa')) == '\xaa'


# Generated at 2022-06-23 15:43:58.301285
# Unit test for function escape
def test_escape():
    assert evalString(r"'\a'") == '\a'
    assert evalString(r"'\b'") == '\b'
    assert evalString(r"'\f'") == '\f'
    assert evalString(r"'\n'") == '\n'
    assert evalString(r"'\r'") == '\r'
    assert evalString(r"'\t'") == '\t'
    assert evalString(r"'\v'") == '\v'
    assert evalString(r"'\'\'") == '\''
    assert evalString(r"'\"\"") == '"'
    assert evalString(r"'\x0a'") == '\n'
    assert evalString(r"'\0a'") == '\n'

# Generated at 2022-06-23 15:43:58.884680
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:06.917545
# Unit test for function escape
def test_escape():
    for s, r in simple_escapes.items():
        assert escape(re.match(r"\\%s" % s, r"\\%s" % s)) == r
    assert escape(re.match(r'\\x41', r'\\x41')) == 'A'
    assert escape(re.match(r'\\x26', r'\\x26')) == '&'
    assert escape(re.match(r'\\x0c', r'\\x0c')) == '\x0c'
    assert escape(re.match(r'\\012', r'\\012')) == '\n'
    assert escape(re.match(r'\\122', r'\\122')) == 'R'
    assert escape(re.match(r'\\222', r'\\222')) == 'R'



# Generated at 2022-06-23 15:44:13.845650
# Unit test for function evalString
def test_evalString():

    assert evalString('"Escape\\n\\r\\\\"') == (
        "Escape\n\r\\"
    ), "evalString(''\"Escape\\n\\r\\\\\"'') should return 'Escape\\n\\r\\\\'"

    assert evalString('"\\x45\\x53\\x43"') == "ESC", "evalString(''\"\\x45\\x53\\x43\"'') should return 'ESC'"

    assert evalString("'abc'") == "abc", "evalString('''abc''') should return 'abc'"

    # Test for the following PR #1355
    # https://github.com/DonJayamanne/pythonVSCode/pull/1355
    assert evalString("'''test'''") == "test"

# Generated at 2022-06-23 15:44:16.143484
# Unit test for function test
def test_test():
    try:
        test()
        assert True
    except AssertionError:
        assert False, "Unit test for function test in module ast_eval failed."

# Generated at 2022-06-23 15:44:21.891436
# Unit test for function escape
def test_escape():
    # Test 1: Basic function
    string = "this is a test"
    m = re.search("is", string)
    assert escape(m) == "\\"
    # Test 2: Helper function
    string = "this is a test"
    m = re.search("is", string)
    assert helper_escape(string, m) == "\\"
    # Test 3: Empty input
    string = "this is a test"
    m = re.search("is", string)
    assert helper_escape("", m) == ""
    # Test 4: Non string input
    string = "this is a test"
    m = re.search("is", string)
    assert helper_escape(5, m) == ""
    # Test 5: None input
    string = "this is a test"

# Generated at 2022-06-23 15:44:22.743382
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:33.074803
# Unit test for function evalString
def test_evalString():
    assert evalString("'''\\n\\r\\t\\f\\v\\b\\a\\\\\\'\\\"'''") == "\n\r\t\f\v\b\a\\\'\""
    assert evalString("'\\x00\\xFF'") == "\0ÿ"
    assert evalString("''") == ""
    assert evalString("'''\\n\\r\\t\\f\\v\\b\\a\\\\\\'\\\"'''") == "\n\r\t\f\v\b\a\\\'\""
    assert evalString("r'''\\n\\r\\t\\f\\v\\b\\a\\\\\\'\\\"'''") == r"\\n\\r\\t\\f\\v\\b\\a\\\\\\'\\\""

# Generated at 2022-06-23 15:44:33.974670
# Unit test for function test
def test_test():
    # check for call
    test()

# Generated at 2022-06-23 15:44:43.223214
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x00'") == chr(0)
    assert evalString('"\\x00"') == chr(0)
    assert evalString("'\\x00'") == evalString("'\\x00'")
    assert evalString("'\\x00'") == evalString("'\\x00'")
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\x00'") == evalString("'\\x00'")
    assert evalString("'\\\n'") == ""
    assert evalString("'\\111'") == "I"
    assert evalString("'\\1111'") == "I"
    assert evalString("'\\11'") == evalString("'\\011'")

# Generated at 2022-06-23 15:44:44.125932
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:44:56.087853
# Unit test for function evalString
def test_evalString():
    assert evalString("'spam'") == "spam"
    assert evalString('"spam"') == "spam"
    assert evalString("'s\\\'pam'") == "s'pam"
    assert evalString('"s\\\"pam"') == 's"pam'
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString(r"'\x61\x62\x63'") == "abc"

# Generated at 2022-06-23 15:45:06.711407
# Unit test for function escape
def test_escape():
    import unittest
    class EscapeTestCase(unittest.TestCase):
        def test_simple_escapes(self):
            for name, value in [
                ("a", "\a"),
                ("b", "\b"),
                ("f", "\f"),
                ("n", "\n"),
                ("r", "\r"),
                ("t", "\t"),
                ("v", "\v"),
                ("'", "'"),
                ('"', '"'),
                ("\\", "\\"),
            ]:
                with self.subTest(name=name, value=value):
                    m = re.match(r"^\A(\\%s)$" % name, value)
                    try:
                        self.assertEqual(escape(m), value)
                    except ValueError as exc:
                        self.fail(exc)

       

# Generated at 2022-06-23 15:45:11.262119
# Unit test for function escape
def test_escape():
    simple_escapes["t"] = "t"
    try:
        escape("\\t")
    except ValueError as e:
        pass
    else:
        raise ValueError("Expected ValueError from invalid escape character")



# Generated at 2022-06-23 15:45:13.406152
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:26.499984
# Unit test for function evalString
def test_evalString():
    # Test various python string escapes
    cases = (
        ('\\a', '\a'),
        ('\\b', '\b'),
        ('\\f', '\f'),
        ('\\n', '\n'),
        ('\\r', '\r'),
        ('\\t', '\t'),
        ('\\v', '\v'),
        ('\\\'', '\''),
        ('\\"', '"'),
        ('\\\\', '\\'),
        ('\\xFF', '\xFF'),
        ('\\377', '\377'),
        ('\\0', '\0'),
    )
    for s, expected in cases:
        assert evalString(s) == expected

    # Test string with control characters

# Generated at 2022-06-23 15:45:35.163956
# Unit test for function evalString
def test_evalString():
    assert evalString('"abcd"') == "abcd"
    assert evalString('"a\\\nbcd"') == "a\\\nbcd"
    assert evalString('"a\\tbcd"') == "a\tbcd"
    assert evalString('"a\\xbcd"') == "a\xbcd"
    assert evalString('"a\\"bcd"') == "a\"bcd"
    assert evalString('"a\\\'bcd"') == "a\'bcd"
    assert evalString('"a\\\x00bcd"') == "a\x00bcd"
    assert evalString('"a\\\x08bcd"') == "a\x08bcd"
    assert evalString('"a\\\x08bcd"') == "a\x08bcd"

# Generated at 2022-06-23 15:45:42.012183
# Unit test for function escape
def test_escape():
    from system.configuration.unit_test import UnitTestConfiguration

    configuration = UnitTestConfiguration()

    assert escape(re.match(r"\\.", r"\0")) == "\0"
    assert escape(re.match(r"\\.", r"\00")) == "\0"
    assert escape(re.match(r"\\.", r"\000")) == "\x00"
    assert escape(re.match(r"\\.", r"\001")) == "\x01"
    assert escape(re.match(r"\\.", r"\377")) == "\xFF"
    assert escape(re.match(r"\\.", r"\x00")) == "\x00"
    assert escape(re.match(r"\\.", r"\x7F")) == "\x7F"

# Generated at 2022-06-23 15:45:50.157061
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == 'foo'
    assert evalString("'foo'") == 'foo'
    assert evalString('"foo\\n"') == 'foo\n'
    assert evalString("'foo\\n'") == 'foo\n'
    assert evalString(r'"foo\\"') == 'foo\\'
    assert evalString(r"'foo\\'") == 'foo\\'

# Generated at 2022-06-23 15:45:51.560456
# Unit test for function test
def test_test():
    from ..testing import run_doctest

    run_doctest(test)

# Generated at 2022-06-23 15:45:52.167159
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:53.596203
# Unit test for function test
def test_test():
    test()
    assert True

# Generated at 2022-06-23 15:45:55.435093
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-23 15:45:56.236442
# Unit test for function escape
def test_escape():
    assert escape(re.match("\", '\""))

# Generated at 2022-06-23 15:46:03.840367
# Unit test for function evalString
def test_evalString():
    s = evalString('"\'\\n\x1a\u1234\U00012345abcdef"')
    assert s == "'\n\x1a\u1234\U00012345abcdef"

    s = evalString('""')
    assert s == ""
    
    s = evalString('"abcdefg"')
    assert s == "abcdefg"

    s = evalString('"\\U00012345"')
    assert s == "\U00012345"

    s = evalString('"\\u1234"')
    assert s == "\u1234"

# Generated at 2022-06-23 15:46:15.208354
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\a\\b\\c"') == "\a\b\c"
    assert evalString("'\\a\\b\\c'") == "\a\b\c"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\x0a'") == "\n"
    assert evalString('"\\x0a"') == "\n"
    assert evalString("'\\u000a'") == "\n"
    assert evalString('"\\u000a"') == "\n"
    assert evalString("'\\\\a\\b\\c'") == "\\a\b\c"
    assert evalString('"\\\\a\\b\\c"') == "\\a\b\c"

# Generated at 2022-06-23 15:46:18.325362
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', "\\x1")) == "\x01"

# Generated at 2022-06-23 15:46:18.922171
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:29.561377
# Unit test for function evalString
def test_evalString():
    assert evalString("'1\n22'") == "1\n22"
    assert evalString("'1\n\\n22'") == "1\n\n22"
    assert evalString('"1\n22"') == "1\n22"
    assert evalString('"1\n\\n22"') == "1\n\n22"
    assert evalString('"1\n\\n\\a\\b22"') == "1\n\n\x07\x0822"
    assert evalString('"1\n\\\\n22"') == "1\n\\n22"
    assert evalString('"1\n\\\\\\\\n22"') == "1\n\\\\n22"
    assert evalString('"1\n\\\\\\\\n22"') != "1\n\\n22"

# Generated at 2022-06-23 15:46:40.493938
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\'", r"\'")) == "'"

# Generated at 2022-06-23 15:46:45.663372
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == "hello"
    assert evalString('u"hello"') == "hello"
    assert evalString('"hel\\nlo"') == "hel\nlo"
    assert evalString(r'"hello\"you"') == 'hello"you'

# Generated at 2022-06-23 15:46:56.585356
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString('"\\""') == '"'
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61\\x62"') == "ab"
    assert evalString('"\\x61\\x62\\x63"') == "abc"
    assert evalString('"\\x61\\x62\\x63\\x64"') == "abcd"
    assert evalString('"\\x61\\x62\\x63\\x64\\x65"') == "abcde"
    assert evalString('"\\x61\\x62\\x63\\x64\\x65\\x66"') == "abcdef"

# Generated at 2022-06-23 15:46:57.802835
# Unit test for function test
def test_test():
    test()
    # This is just a simple test, can't do much.

# Generated at 2022-06-23 15:46:58.290650
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:08.742983
# Unit test for function escape
def test_escape():
  # Invalid octal escapes
  for i in range(7):
    try:
      escape(match("\\" + "0" * i))
    except ValueError:
      pass
    else:
      raise AssertionError("Invalid octal escape '\\" + "0" * i +
                           "' did not raise a ValueError")
  try:
    escape(match("\\00"))
  except ValueError:
    pass
  else:
    raise AssertionError("Invalid octal escape '\\00' did not raise a ValueError")

  # Invalid hex escapes
  for i in range(3):
    try:
      escape(match("\\x" + "0" * i))
    except ValueError:
      pass

# Generated at 2022-06-23 15:47:09.370001
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:18.292455
# Unit test for function evalString
def test_evalString():
    assert evalString('"test"') == "test"
    assert evalString('"te\\"st"') == 'te"st'
    assert evalString('"tes\\\\t"') == "tes\\t"
    assert evalString('"test\\n"') == "test\n"
    assert evalString('"te\\\'st"') == "te'st"
    assert evalString('"te\\177t"') == "te\x7ft"
    assert evalString('"te\x7ft"') == "te\x7ft"
    assert evalString('"test\\067"') == "test\x1b"
    assert evalString('"test\\012"') == "test\n"
    assert evalString('"test\\u1234"') == "test\u1234"

# Generated at 2022-06-23 15:47:28.661519
# Unit test for function evalString

# Generated at 2022-06-23 15:47:38.808431
# Unit test for function evalString
def test_evalString():
    from . import LiteralTestCase
    from .common import py2_only


# Generated at 2022-06-23 15:47:49.647481
# Unit test for function evalString
def test_evalString():
    import sys

    # Both single and double quotes are valid
    assert evalString("'hi'") == 'hi'
    assert evalString('"hi"') == 'hi'

    # Single and double quoted results do not differ
    assert evalString('"hi"') == evalString("'hi'")

    # Empty string
    assert evalString('""') == ""

    # Single character
    assert evalString("'x'") == 'x'

    # Same character with quotes
    assert evalString("'" + '"' + '"') == '"'

    # Unsupported escape sequences
    for s in [r"\a", r"\b", r"\f", r"\v", r"\u1234"]:
        try:
            evalString(s)
        except ValueError:
            pass
        except Exception:
            raise Assert

# Generated at 2022-06-23 15:47:53.987567
# Unit test for function test
def test_test():
    import doctest
    from . import _test_lib as test_lib

    if test_lib.get_verbose():
        verbose = 1
    else:
        verbose = 0

    failures, _ = doctest.testmod(verbose=verbose)
    assert failures == 0

# Generated at 2022-06-23 15:47:54.946698
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:06.457336
# Unit test for function escape
def test_escape():
    print("Testing function escape")
    assert escape(re.match(r"\\.", r"\a")) == "\a"
    assert escape(re.match(r"\\.", r"\b")) == "\b"
    assert escape(re.match(r"\\.", r"\f")) == "\f"
    assert escape(re.match(r"\\.", r"\n")) == "\n"
    assert escape(re.match(r"\\.", r"\r")) == "\r"
    assert escape(re.match(r"\\.", r"\t")) == "\t"
    assert escape(re.match(r"\\.", r"\v")) == "\v"
    assert escape(re.match(r"\\.", r"\'")) == "'"

# Generated at 2022-06-23 15:48:13.405866
# Unit test for function escape
def test_escape():
    pattern = re.compile('\\((\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})')
    test_string = "\\a\\b\\f\\n\\r\\t\\v\\'\\\"\\\\\\x44\\100\\100"
    test_string_result = '\a\b\f\n\r\t\v\'"\\\x44\x44\x64'
    assert test_string_result == re.sub(pattern, escape, test_string)

# Generated at 2022-06-23 15:48:15.676635
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-23 15:48:26.794792
# Unit test for function evalString
def test_evalString():
    # Positive Tests
    assert evalString("'abc'") == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\061\\062\\063'") == "abc"
    assert evalString("'\\x{61}\\x{62}\\x{63}'") == "abc"
    assert evalString("'\\n\\n'") == "\n\n"
    assert evalString("'abc\\nabc'") == "abc\nabc"
    assert evalString("'\\'\\''") == "'"
    assert evalString("'\\\\'") == "\\"
    assert evalString("''") == ""

# Generated at 2022-06-23 15:48:33.818619
# Unit test for function evalString
def test_evalString():
    assert evalString("blah") == "blah"
    assert evalString("'blah'") == "blah"
    assert evalString("'\\nblah'") == "\nblah"
    assert evalString('"\\nblah"') == "\nblah"
    assert evalString("'\\\\nblah'") == "\\nblah"
    assert evalString("'\\'blah'") == "'blah"
    assert evalString("'\\'") == "'"
    assert evalString("'\\077'") == "?"
    assert evalString("'\\x7F'") == "\x7F"
    assert evalString("'\\127'") == "\x7F"

# Generated at 2022-06-23 15:48:40.808285
# Unit test for function escape
def test_escape():
    # Just do a few tests since the function calls
    # other functions which are tested elsewhere.

    # Simple cases
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"

# Generated at 2022-06-23 15:48:52.411701
# Unit test for function evalString
def test_evalString():
    s = evalString("'the string evalString'")
    assert (s == "the string evalString")
    s = evalString("'the string \\n evalString'")
    assert (s == "the string \n evalString")
    s = evalString("'the string \\r\\n evalString'")
    assert (s == "the string \r\n evalString")
    s = evalString("'the string \\r\\n\\t evalString'")
    assert (s == "the string \r\n\t evalString")
    s = evalString("'the string \\t evalString'")
    assert (s == "the string \t evalString")
    s = evalString("'the string evalString \\r\\r\\r \\n'")
    assert (s == "the string evalString \r\r\r \n")

# Generated at 2022-06-23 15:48:53.033450
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:55.955994
# Unit test for function escape
def test_escape():
    assert escape('"\x62"') == 'b'
    assert escape('"\x23"') == '#'

# Unit tests for function evalString

# Generated at 2022-06-23 15:49:06.198862
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'a\x00c'") == "a\0c"

    # tp: 2-char strings are passed to evalString()
    assert evalString("'a\\\c'") == "a\c"

    assert evalString("'a\\\'c'") == "a'c"
    assert evalString("'a\\\"c'") == 'a"c'
    assert evalString("'a\\\\c'") == "a\\c"

    assert evalString("'a\\abc'") == "a\abc"
    assert evalString("'a\\\nbc'") == "abc"

    assert evalString("'a\bbc'") == "abc"
    assert evalString("'a\fbc'") == "abc"
    assert eval

# Generated at 2022-06-23 15:49:12.934293
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == 'hello'
    assert evalString("'\\x20\\x7f'") == "\x20\x7f"
    assert evalString("'hello'") == 'hello'
    assert evalString("'\\x00\\xff'") == "\x00\xff"
    assert evalString("'\\x01\\xfe'") == "\x01\xfe"
    assert evalString("'\\x02\\xfd'") == "\x02\xfd"
    assert evalString("'\\x03\\xfc'") == "\x03\xfc"
    assert evalString("'\\x04\\xfb'") == "\x04\xfb"
    assert evalString("'\\x05\\xfa'") == "\x05\xfa"

# Generated at 2022-06-23 15:49:13.524587
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:14.145167
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:14.765481
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:17.269019
# Unit test for function evalString
def test_evalString():
    testString = '"This is a test"\n'
    assert evalString(testString) == 'This is a test', 'evalString fails to return expected string'

# Generated at 2022-06-23 15:49:18.582753
# Unit test for function test
def test_test():
    try:
        test()
    except SystemExit:
        pass

# Generated at 2022-06-23 15:49:21.029621
# Unit test for function escape
def test_escape():
    assert escape("\\x2") == "\\"
    assert escape("\\x1") == "\\"
    assert escape("\\x0") == "\\"

# Generated at 2022-06-23 15:49:32.827129
# Unit test for function escape
def test_escape():
    valid_escape_sequences = [
        '\\a',
        '\\b',
        '\\f',
        '\\n',
        '\\r',
        '\\t',
        '\\v',
        '\\\'"',
        '\\\"',
        '\\\'"',
        '\\\n',
        '\\x41',
        '\\077',
        ]
    for s in valid_escape_sequences:
        escape(re.search(r'\\(.*)', s))

    invalid_escape_sequences = [
        '\\z',
        '\\\n',
        '\\789',
        '\\x1',
        '\\x1z',
        '\\078',
        ]

# Generated at 2022-06-23 15:49:33.760907
# Unit test for function test
def test_test():
    test()  # pragma: no cover

# Generated at 2022-06-23 15:49:37.472164
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString("'abcdefghijklmnopqrstuvwxyz'") == 'abcdefghijklmnopqrstuvwxyz'
    assert evalString("'\\x61\\x62\\x63'") == 'abc'

# Generated at 2022-06-23 15:49:45.398737
# Unit test for function evalString
def test_evalString():
    e = evalString('"\\x22"')
    assert e == '"', repr(e)
    e = evalString('"\\x20\\x20"')
    assert e == "  ", repr(e)
    e = evalString("'\\001\\002\\003\\004'")
    assert e == "\x01\x02\x03\x04", repr(e)



# Generated at 2022-06-23 15:49:55.696953
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\a", "\\a")) == "\a"
    assert escape(re.match("\\b", "\\b")) == "\b"
    assert escape(re.match("\\f", "\\f")) == "\f"
    assert escape(re.match("\\n", "\\n")) == "\n"
    assert escape(re.match("\\r", "\\r")) == "\r"
    assert escape(re.match("\\t", "\\t")) == "\t"
    assert escape(re.match("\\v", "\\v")) == "\v"
    assert escape(re.match("\\'", "\\'")) == "'"
    assert escape(re.match('\\"', '\\"')) == '"'
    assert escape(re.match("\\\\", "\\\\")) == "\\"
    assert escape

# Generated at 2022-06-23 15:50:04.370631
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\x41", "A")) == "A"
    assert escape(re.search(r"\\x41", r"\x41")) == "A"
    assert escape(re.search(r"\\x41", r"\\x41")) == "A"
    assert escape(re.search(r"\\41", "A")) == "A"
    assert escape(re.search(r"\\41", r"\41")) == "A"
    assert escape(re.search(r"\\41", r"\\41")) == "A"
    assert escape(re.search(r"\\41", r"\\041")) == "A"



# Generated at 2022-06-23 15:50:10.133844
# Unit test for function test
def test_test():
    # There should be no output on stderr.
    import sys
    import io

    saved_stderr = sys.stderr
    try:
        sys.stderr = io.StringIO()
        test()
        assert sys.stderr.getvalue() == ""
    finally:
        sys.stderr = saved_stderr

# Generated at 2022-06-23 15:50:22.232074
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == evalString('"abc"')
    assert evalString('"""abc"""') == "abc"
    assert evalString("'''abc'''") == evalString('"""abc"""')
    assert evalString('"a\\\\"') == "a\\"
    assert evalString("'a\\\\'") == evalString('"a\\\\"')
    assert evalString('"a\\b"') == "a\b"
    assert evalString("'a\\b'") == evalString('"a\\b"')
    assert evalString('"a\\b"') == evalString('"a\\b"')
    assert evalString('"""a\\b"""') == evalString('"a\\b"')

# Generated at 2022-06-23 15:50:35.122661
# Unit test for function escape
def test_escape():
    """Unit test for function escape
    """
    pattern = r"\\(['\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})"
    assert re.match(pattern, r"\'").group(1) == "\'"
    assert re.match(pattern, r"\123").group(1) == "23"
    assert re.match(pattern, r'\"').group(1) == '"'
    assert re.match(pattern, r"\b").group(1) == "b"
    assert re.match(pattern, r"\f").group(1) == "f"
    assert re.match(pattern, r"\n").group(1) == "n"
    assert re.match(pattern, r"\r").group(1) == "r"