

# Generated at 2022-06-23 15:40:41.472827
# Unit test for function evalString
def test_evalString():
    # Test strings from the docstring, and
    # a couple of others
    assert evalString("'hello, world'") == "hello, world"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\nhello, world\\n'") == "\nhello, world\n"
    assert evalString("'\\''") == "'"
    assert evalString("'\"'") == '"'
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\a'") == "\x07"
    # Test invalid string literals
    assert evalString("'\\q'") == "q"
    pytest.raises(ValueError, evalString, "'\\x1'")
    pytest.raises(ValueError, evalString, "'\\x1q'")
    pytest

# Generated at 2022-06-23 15:40:47.058199
# Unit test for function escape
def test_escape():
    # If a digit is used for x it raises an error
    m = re.search('(\\x\d)', '\\x1')
    with pytest.raises(ValueError) as err:
        escape(m)
    assert str(err.value) == "invalid hex string escape ('\\x1')"

    # If a number with more than 2 digits is used for x it raises an error
    m = re.search('(\\x\d\d\d)', '\\x123')
    with pytest.raises(ValueError) as err:
        escape(m)
    assert str(err.value) == "invalid hex string escape ('\\x123')"

    # If a number with more than 3 digits is used for o it raises an error

# Generated at 2022-06-23 15:40:47.762922
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:54.740175
# Unit test for function escape
def test_escape():
    # test escape
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"

# Generated at 2022-06-23 15:41:03.738586
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'\''") == "'"
    assert evalString(r"'''xxxxx'yyy'zzz'aaa'bbb'ccc''''''") == "xxxxx'yyy'zzz'aaa'bbb'ccc'"
    assert evalString(r"'\a'") == "\a"
    assert evalString(r"'\x07'") == "\x07"
    assert evalString(r"'\xFF'") == "\xFF"
    assert evalString(r"'\377'") == "\377"
    assert evalString(r"'\0'") == "\0"
    assert evalString(r"'\008'") == "\0"
    assert evalString(r"'\08'") == "\0"
    assert evalString(r"'\7'") == "\x07"
    assert evalString

# Generated at 2022-06-23 15:41:04.857746
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:41:12.869217
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\"a\\""') == '"a"'
    assert evalString("'a'") == 'a'
    assert evalString("'\\'a\\''") == "'a'"
    assert evalString("'''abc'''") == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString("'ab\\xc3\\xb4c'") == 'abôc'
    assert evalString("'\\x6x'") == "xx"
    assert evalString("'''a\\r\\n\\r\\nb'''") == "a\r\n\r\nb"
    assert evalString("'''a\\r\\nb'''") == "a\r\nb"
    assert evalString("'\\r\\n'") == '\r\n'
    assert evalString

# Generated at 2022-06-23 15:41:25.808688
# Unit test for function escape
def test_escape():
    # Test simple escapes
    for k, v in simple_escapes.items():
        assert escape(re.match(r'\\' + k, r'\\' + k)) == v
    # Test octal escapes
    assert escape(re.match(r'\\377', r'\\377')) == '\xff'
    assert escape(re.match(r'\\377', r'\\377')) == '\xff'
    assert escape(re.match(r'\\0', r'\\0')) == '\x00'
    assert escape(re.match(r'\\00', r'\\00')) == '\x00'
    assert escape(re.match(r'\\000', r'\\000')) == '\x00'
    assert escape(re.match(r'\\001', r'\\001'))

# Generated at 2022-06-23 15:41:34.375177
# Unit test for function evalString
def test_evalString():
    # Test for single and double quotes
    assert evalString("'a'") == "a"
    assert evalString('"b"') == "b"
    # Test for escaped single and double quotes
    assert evalString('"\\"a\\""') == '"a"'
    assert evalString("'\\'b\\''") == "'b'"
    # Test for special characters
    assert evalString("'\n'") == "\n"
    assert evalString("'\t'") == "\t"
    # Test for escape sequences
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\x12"') == "\x12"
    assert evalString('"\\123"') == "\x5b"
    assert evalString('"\\0123"') == "\x5b"
    # Test for invalid escape

# Generated at 2022-06-23 15:41:44.273241
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == "foo"
    assert evalString('"foo"') == "foo"
    assert evalString('"f\\no\\"o"') == "f\\no\\\"o"
    assert evalString(r'"f\no\"o"') == r"f\no\"o"
    assert evalString(r'"f\no\08o"') == r"f\no\08o"
    assert evalString(r'"f\no\x08o"') == r"f\no\x08o"

# Generated at 2022-06-23 15:41:45.876788
# Unit test for function evalString
def test_evalString():
    print(evalString("'abc'"))

# Generated at 2022-06-23 15:41:49.583914
# Unit test for function test
def test_test():
    from typing import TypeVar
    from pytypedecl import no_type_check

    T = TypeVar("T")

    @no_type_check
    def run_test(t: T) -> T:
        test()
        return t


test_test()

# Generated at 2022-06-23 15:41:50.859013
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:56.884830
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\t'") == "\t"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\"'") == '"'
    assert evalString('"\\\'"') == "'"
    assert evalString("'\\x09'") == "\x09"
    assert evalString('"\\x20"') == "\x20"
    assert evalString('"\\101"') == "A"
    assert evalString('"\\x41"') == "A"

# Generated at 2022-06-23 15:41:58.506197
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        print(e)



# Generated at 2022-06-23 15:42:00.018416
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:03.682701
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\.", r"\x01")) == "\x01"
    assert escape(re.match(r"\\.", r"\1")) == "\x01"

# Generated at 2022-06-23 15:42:14.193114
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', r'\a')) == '\a'
    assert escape(re.match(r'\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', r'\b')) == '\b'
    assert escape(re.match(r'\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})', r'\f')) == '\f'

# Generated at 2022-06-23 15:42:14.775179
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:42:22.609753
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.search(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"

# Generated at 2022-06-23 15:42:33.160351
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString('""') == ""
    assert evalString("'hi'") == "hi"
    assert evalString('"hi"') == "hi"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\''") == "'"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\r\\n'") == "\r\n"
    assert evalString("'\\x0'") == "\0"
    assert evalString("'\\x01'") == "\x01"
    assert evalString("'\\x10'") == "\x10"
    assert evalString("'\\xff'") == "\xff"
    assert evalString("'\\0'")

# Generated at 2022-06-23 15:42:41.957298
# Unit test for function evalString
def test_evalString():

    from ..extern.six import StringIO

    import inspect
    import os
    import sys

    def os_is_win32_ver3():
        """Test for Windows 9x versions (95, 98, ME)"""
        try:
            return sys.getwindowsversion().platform == 2
        except AttributeError:
            # Windows versions before XP do not have the platform attribute
            # Assume that they are 9x versions.
            return True

    old_stdout = sys.stdout
    f = sys.stdout = StringIO()
    try:
        test()
    finally:
        sys.stdout = old_stdout
    result = f.getvalue()
    if os_is_win32_ver3():
        # Windows 9x versions do not have the chr(0) character
        expected = ""

# Generated at 2022-06-23 15:42:43.736304
# Unit test for function test
def test_test():
    # Just call the function and make sure that it doesn't error.
    test()

# Generated at 2022-06-23 15:42:45.240861
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"' + r"\"" + r'"') == r'"'

# Generated at 2022-06-23 15:42:48.170302
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        return False
    else:
        return True

# Generated at 2022-06-23 15:42:57.603743
# Unit test for function escape
def test_escape():
    # \a
    new_value = escape(re.match('\\a','\a'))
    assert new_value == '\a'
    # \b
    new_value = escape(re.match('\\b','\b'))
    assert new_value == '\b'
    # \f
    new_value = escape(re.match('\\f','\f'))
    assert new_value == '\f'
    # \n
    new_value = escape(re.match('\\n','\n'))
    assert new_value == '\n'
    # \r
    new_value = escape(re.match('\\r','\r'))
    assert new_value == '\r'
    # \t
    new_value = escape(re.match('\\t','\t'))


# Generated at 2022-06-23 15:43:08.353016
# Unit test for function evalString
def test_evalString():
    assert evalString("'abcd'") == "abcd"
    assert evalString('"abcd"') == "abcd"
    assert evalString("'''abcd'''") == "abcd"
    assert evalString('"""abcd"""') == "abcd"
    assert evalString("'\\x55'") == "\x55"
    assert evalString("'\\055'") == "\055"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\065'") == "\065"
    assert evalString("'\\xe9'") == "\xe9"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\t'") == "\t"

# Generated at 2022-06-23 15:43:20.326307
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x24", r"\x24")) == "$"
    assert escape(re.match(r"\\xA2", r"\xA2")) == "\xa2"
    assert escape(re.match(r"\\372", r"\372")) == "\xb2"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\b", r"\b")) == "\b"

# Generated at 2022-06-23 15:43:31.548803
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString("'\\''") == "'"
    assert evalString("'''\\'\\'''") == "'\\'"
    assert evalString("'abc\"def\"ghi'") == 'abc"def"ghi'
    assert evalString("'abc\\\ndef'") == "abcdef"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\011\\x11\\111'") == "\t\x11I"
    assert evalString("'\\011\\011\\011'") == "\t\t\t"

# Generated at 2022-06-23 15:43:43.415430
# Unit test for function evalString
def test_evalString():
    from lib2to3.pgen2 import tokenize
    from io import BytesIO

    tests = [
        (b'""', b""),
        (b"''", b""),
        (b'"a"', b"a"),
        (b"'a'", b"a"),
        (b'"\\a"', b"\a"),
        (b"'\\a'", b"\a"),
        (b'"\\x61"', b"a"),
        (b"'\\x61'", b"a"),
        (b'"\\61"', b"1"),
        (b"'\\61'", b"1"),
        (b"'\\\n'", b""),
    ]

    for raw, cooked in tests:
        cooked = cooked.decode("latin-1")

# Generated at 2022-06-23 15:43:49.961740
# Unit test for function evalString
def test_evalString():
    assert evalString('"') == ''
    assert evalString('""') == ''
    assert evalString('"abc"') == 'abc'
    assert evalString('"foo\nbar"') == 'foo\nbar'
    assert evalString("'abc'") == 'abc'
    assert evalString('"nested \'single\' quotes"') == "nested 'single' quotes"
    assert evalString("'nested \"double\" quotes'") == 'nested "double" quotes'

# Generated at 2022-06-23 15:44:00.000249
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\'", "\\'")) == "'"
    assert escape(re.search(r"\\\"", "\\\"")) == '"'
    assert escape(re.search(r"\\'", "\\'")) == "'"
    assert escape(re.search(r"\\a", "\\a")) == "\a"
    assert escape(re.search(r"\\b", "\\b")) == "\b"
    assert escape(re.search(r"\\f", "\\f")) == "\f"
    assert escape(re.search(r"\\n", "\\n")) == "\n"
    assert escape(re.search(r"\\r", "\\r")) == "\r"
    assert escape(re.search(r"\\t", "\\t")) == "\t"

# Generated at 2022-06-23 15:44:10.281313
# Unit test for function evalString
def test_evalString():
    assert evalString("""'\x20\x20'""") == "  "
    assert evalString("""'\u201c\u201d\u201c'""") == '"""'

# Generated at 2022-06-23 15:44:21.089266
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("b'abc'") == "abc"
    assert evalString("b\"abc\"") == "abc"
    assert evalString("\"abc\"") == "abc"
    assert evalString("\"\\\\\"") == "\\"
    assert evalString("\'\\r\'") == "\r"
    assert evalString("\'\\n\'") == "\n"
    assert evalString("\'\\b\'") == "\b"
    assert evalString("\"\\v\"") == "\v"
    assert evalString("\"\\t\"") == "\t"
    assert evalString("\'\\f\'") == "\f"
    assert evalString("\"\\a\"") == "\a"
    assert evalString("\"\\\"\"") == "\""

# Generated at 2022-06-23 15:44:32.257027
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv])", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv])", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv])", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv])", r"\n")) == "\n"
    assert escape(re.match(r"\\([abfnrtv])", r"\r")) == "\r"
    assert escape(re.match(r"\\([abfnrtv])", r"\t")) == "\t"
    assert escape(re.match(r"\\([abfnrtv])", r"\v")) == "\v"
    assert escape

# Generated at 2022-06-23 15:44:38.358367
# Unit test for function evalString
def test_evalString():
    # Test against ordinary eval()
    import random
    import string
    for i in range(1000):
        s = """\
%s%s%s
""" % (
            random.choice(string.ascii_letters),
            "".join(
                random.choice(string.ascii_letters + string.digits) for j in range(20)
            ),
            random.choice(string.ascii_letters),
        )
        assert evalString(s) == eval(s)



# Generated at 2022-06-23 15:44:46.473501
# Unit test for function escape
def test_escape():
    test_data = [
        ("\\a", "\\x07"),
        ("\\b", "\\x08"),
        ("\\f", "\\x0c"),
        ("\\n", "\\x0a"),
        ("\\r", "\\x0d"),
        ("\\t", "\\x09"),
        ("\\v", "\\x0b"),
        ('\\\'', '\\\''),
        ('\\"', '\\"'),
        ("\\\\", '\\\\'),
        ("\\x7F", "\\x7f"),
    ]

    for test_value, expected_value in test_data:
        assert expected_value == escape(re.match(r"\\(.+)", test_value))


# Generated at 2022-06-23 15:44:57.125797
# Unit test for function escape
def test_escape():
    test_tuples = [
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\\\", "\\"),
        ("\\x0B", "\x0B"),
        ("\\x00", "\x00"),
    ]
    for test_tuple in test_tuples:
        assert escape(re.match(r"\\([abfnrtv'\"\\]|[x0-9]{1,3})", test_tuple[0])) == test_tuple[1]

# Generated at 2022-06-23 15:45:05.066758
# Unit test for function evalString
def test_evalString():
    # Exercise the evalString function, which is used when string
    # literals are required to be evaluated.  The function is
    # preferred over eval() because it's safer (no side effects)
    # and faster (no parser overhead).  compiler.transformer
    # attempts to use evalString whenever possible.

    # Test all 8-bit characters
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, "%r -> %r: expected %r" % (s, e, c)



# Generated at 2022-06-23 15:45:13.077638
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"And now for something completely different"') == 'And now for something completely different'
    assert evalString(r"'And now for something completely different'") == 'And now for something completely different'
    assert evalString(r'"And now\nfor something completely different"') == 'And now\nfor something completely different'
    assert evalString(r"'And now\rfor something completely different'") == 'And now\rfor something completely different'
    assert evalString(r'"And now\r\nfor something completely different"') == 'And now\r\nfor something completely different'
    assert evalString(r"'And now\r\nfor something completely different'") == 'And now\r\nfor something completely different'

# Generated at 2022-06-23 15:45:17.678023
# Unit test for function test
def test_test():
    # We expect that no output is generated during test().
    # This should be the case even if the 'print' statement
    # in test() is uncommented
    output = str(test())
    assert output == "None"

# Generated at 2022-06-23 15:45:29.297972
# Unit test for function escape
def test_escape():
    doubles = [ 'aa', 'ab', 'ac', 'ad', 'ae', 'af',
                'ba', 'bb', 'bc', 'bd', 'be', 'bf',
                'ca', 'cb', 'cc', 'cd', 'ce', 'cf',
                'da', 'db', 'dc', 'dd', 'de', 'df',
                'ea', 'eb', 'ec', 'ed', 'ee', 'ef',
                'fa', 'fb', 'fc', 'fd', 'fe', 'ff']

# Generated at 2022-06-23 15:45:32.075003
# Unit test for function escape
def test_escape():
    assert(escape(re.match(r"\\x....", r"\x3f")) == chr(0x3f))

# Generated at 2022-06-23 15:45:32.850375
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:33.737631
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-23 15:45:36.929366
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\t\\'\\\\'") == "\t'\\"
    assert evalString('"\\t\\"\\\\"') == '\t"\\'

# Generated at 2022-06-23 15:45:40.256235
# Unit test for function test
def test_test():
    for i in range(256):
        assert evalString('"' + chr(i) + '"') == chr(i)
        assert evalString("'" + chr(i) + "'") == chr(i)
        assert evalString("'" + repr(chr(i)[1:]) + "'") == chr(i)

# Generated at 2022-06-23 15:45:40.882518
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:43.424022
# Unit test for function test
def test_test():
    # This function contains pure Python code.
    # It can be considered a unit for testing.
    #
    # test__test:
    test()

# Generated at 2022-06-23 15:45:55.810309
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape

# Generated at 2022-06-23 15:45:56.441945
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:05.915497
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("'a'") == "a"
    assert evalString("'\\''") == "'"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\x07'") == "\a"
    assert evalString("'\\07'") == "\a"
    assert evalString("'\\7'") == "\a"
    assert evalString("'\n'") == "\n"
    assert evalString('"\\\n"') == "\\\n"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\x5c'") == "\\"
    assert evalString("'\\105'") == "E"
    assert evalString("'\\15'") == "\x0f"

# Generated at 2022-06-23 15:46:08.674442
# Unit test for function test
def test_test():
    import pytest

    with pytest.raises(AssertionError):
        test()


# Generated at 2022-06-23 15:46:18.819812
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x7f", "\\x7f")) == chr(0x7f)
    assert escape(re.match(r"\\x7f", "\\x7f")) != chr(0xff)
    assert escape(re.match(r"\\x7f", "\\x7f")) != chr(0)
    assert escape(re.match(r"\\x7f", "\\x7f")) != chr(0x7)
    assert escape(re.match(r"\\x7f", "\\x7f")) != chr(0x70)
    assert escape(re.match(r"\\x7f", "\\x7f")) != chr(0x1f)

# Generated at 2022-06-23 15:46:19.819321
# Unit test for function test
def test_test():
    assert test() == None


# Generated at 2022-06-23 15:46:23.521688
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\x3a'") == ":"
    assert evalString("'\\163'") == "s"

# Generated at 2022-06-23 15:46:32.455044
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello world'") == "hello world"
    assert evalString('"hello world"') == "hello world"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\n"') == "\n"
    assert evalString("'''\\n'''") == "\n"
    assert evalString('"""\\n"""') == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\a'") == "\a"
    assert evalString('"\\a"') == "\a"


# Generated at 2022-06-23 15:46:41.810601
# Unit test for function evalString
def test_evalString():
    result = evalString('"Hello"')
    assert result == "Hello"
    result = evalString('"Hello\nworld"')
    assert result == "Hello\nworld"
    result = evalString('"Hello\nworld\\"')
    assert result == "Hello\nworld\\"
    result = evalString('"Hello\\u1234world\\"')
    assert result == "Hello\\u1234world\\"
    result = evalString('"Hello\\u1234world"')
    assert result == "Hello\\u1234world"
    result = evalString("'Hello\\nworld'")
    assert result == "Hello\\nworld"
    result = evalString("'Hello\\'world'")
    assert result == "Hello\\'world"
    result = evalString("'Hello\\'world\\''")
    assert result

# Generated at 2022-06-23 15:46:43.141011
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:43.773938
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:46.403383
# Unit test for function evalString
def test_evalString():
    if evalString('"\r"') != '\r':
        raise RuntimeError
    if evalString("'\r'") != '\r':
        raise RuntimeError

# Generated at 2022-06-23 15:46:52.492747
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == 'hello'
    assert evalString('"hello\\nworld"') == 'hello\nworld'
    assert evalString('"hello\\037world"') == 'hello world'
    assert evalString('"hello\\x27world"') == 'hello\'world'
    assert evalString('"hello\\x27world\\x27"') == 'hello\'world\''
    assert evalString('"hello\\001world"') == 'hello\x01world'

# Generated at 2022-06-23 15:47:00.442964
# Unit test for function escape
def test_escape():
    # Test cases
    test_cases = [
        ('\a', 'a'),
        ('\b', 'b'),
        ('\f', 'f'),
        ('\n', 'n'),
        ('\r', 'r'),
        ('\t', 't'),
        ('\v', 'v'),
        ('\\', '\\'),
        ('\x08', 'x08'),
        ('\x7f', 'x7f'),
        ('a', 'a'),
    ]

    for c, e in test_cases:
        assert escape(re.match('\\' + e, c)) == c

# Generated at 2022-06-23 15:47:01.219378
# Unit test for function escape
def test_escape():
    assert escape("\\x50") == "P"

# Generated at 2022-06-23 15:47:12.544710
# Unit test for function escape

# Generated at 2022-06-23 15:47:13.924084
# Unit test for function evalString
def test_evalString():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 15:47:25.647333
# Unit test for function evalString
def test_evalString():
    # Ensure evalString works with all characters
    assert evalString("'\U0010FFFF'") == "\U0010FFFF"
    assert evalString('"\U0010FFFF"') == "\U0010FFFF"
    assert evalString("b'\U0010FFFF'") == "\U0010FFFF"
    assert evalString("b'\U0010FFFF'") == "\U0010FFFF"

    # Ensure evalString works for all edge cases
    for s in ["''", '""', "b''", "b''", "f''", "f''", "r''", "r''"]:
        assert evalString(s) == ""
    for s in ["'a'", "'\\''", "'\\xff'", '"a"', '"\\""', '"\\xff"']:
        assert evalString(s) == eval(s)

# Generated at 2022-06-23 15:47:26.240665
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:31.216151
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"



# Generated at 2022-06-23 15:47:31.845949
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:35.082685
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == r"\a"
    assert escape(re.match(r"\\t", r"\t")) == r"\t"
    assert escape(re.match(r"\\\t", r"\\t")) == r"\\t"
    assert escape(re.match(r"\\x1d", r"\x1d")) == r"\x1d"
    assert escape(re.match(r"\\x", r"\x")) == r"\x"

# Generated at 2022-06-23 15:47:47.090713
# Unit test for function evalString
def test_evalString():
    """test_evalString"""
    assert evalString('"a"') == "a"
    assert evalString('r"a"') == "a"
    assert evalString('r"\n"') == "\n"
    assert evalString('r"\t"') == "\t"
    assert evalString('r"\t"') == "\t"
    assert evalString(r"'\t'") == "\t"
    assert evalString(r"'\t'") == "\t"
    assert evalString(r"'\t'") == "\t"

# Generated at 2022-06-23 15:47:47.747325
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:55.584503
# Unit test for function evalString
def test_evalString():
    # evalString is highly restricted, so this is a test of the test!
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString("'ab\'c'") == "ab'c"
    assert evalString('"ab\\"c"') == 'ab"c'
    assert evalString("'ab\\\\c'") == "ab\\c"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\\''") == '\a\b\f\n\r\t\v\''
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\""') == '\a\b\f\n\r\t\v"'
    assert evalString("'\\''") == "'"
   

# Generated at 2022-06-23 15:48:03.471362
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"



# Generated at 2022-06-23 15:48:13.580844
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\\x07"
    assert escape(re.match(r"\\b", r"\b")) == "\\x08"
    assert escape(re.match(r"\\f", r"\f")) == "\\x0c"
    assert escape(re.match(r"\\n", r"\n")) == "\\x0a"
    assert escape(re.match(r"\\r", r"\r")) == "\\x0d"
    assert escape(re.match(r"\\t", r"\t")) == "\\x09"
    assert escape(re.match(r"\\v", r"\v")) == "\\x0b"

# Generated at 2022-06-23 15:48:23.412379
# Unit test for function escape

# Generated at 2022-06-23 15:48:24.956639
# Unit test for function test
def test_test():
    with pytest.raises(AssertionError):
        test()


# Generated at 2022-06-23 15:48:33.797628
# Unit test for function evalString
def test_evalString():
    '''Test evalString(str) -> str'''
    assert evalString('"abcd"') == "abcd"
    assert evalString("'abcd'") == "abcd"
    assert evalString("'''abcd'''") == "abcd"
    assert evalString('"""abcd"""') == "abcd"
    assert evalString('"ab\tc"') == "ab\tc"
    assert evalString("'ab\tc'") == "ab\tc"
    assert evalString('"ab\tc\tc"') == "ab\tc\tc"
    assert evalString("'ab\tc\tc'") == "ab\tc\tc"
    assert evalString('"ab\n"') == "ab\n"
    assert evalString("'ab\n'") == "ab\n"
    assert eval

# Generated at 2022-06-23 15:48:42.239027
# Unit test for function escape
def test_escape():
    # Known escapes
    assert escape(re.match(r"\\a", "\a")) == "\a"
    assert escape(re.match(r"\\b", "\b")) == "\b"
    assert escape(re.match(r"\\f", "\f")) == "\f"
    assert escape(re.match(r"\\n", "\n")) == "\n"
    assert escape(re.match(r"\\r", "\r")) == "\r"
    assert escape(re.match(r"\\t", "\t")) == "\t"
    assert escape(re.match(r"\\v", "\v")) == "\v"
    assert escape(re.match(r"\\\'", "'")) == "'"
    assert escape(re.match(r'\\"', '"')) == '"'

# Generated at 2022-06-23 15:48:52.661326
# Unit test for function escape
def test_escape():
    assert escape(None) == ""
    assert escape(re.match(r"\\xffff", "\\xffff")) == "\\xff"
    assert escape(re.match(r"\\xaaa", "\\xaaa")) == "\\xaa"
    assert escape(re.match(r"\\xai", "\\xai")) == "\\x0"
    assert escape(re.match(r"\\xaa", "\\xaa")) == "\\xaa"
    assert escape(re.match(r"\\xai", "\\xai")) == "\\x0"
    assert escape(re.match(r"\\", "\\")) == "\\"
    assert escape(re.match(r"\\x", "\\x")) == "\\"


# Generated at 2022-06-23 15:48:54.925827
# Unit test for function test
def test_test():
    try:
        test()
    except TypeError:
        assert False, "test() failed"
    assert True, "test() passed"


# Generated at 2022-06-23 15:49:04.839165
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc\\'def'") == "abc'def"
    assert evalString("'abc\\tdel'") == "abc\tdel"
    assert evalString("'abc\\\\def'") == "abc\\def"
    assert evalString("'abc\\def'") == "abcdef"
    assert evalString("'abc\\\\\\def'") == "abc\\def"
    assert evalString('"abc\\"def"') == 'abc"def'
    assert evalString('"abc\\tdel"') == 'abc\tdel'
    assert evalString('"abc\\\\def"') == 'abc\\def'
    assert evalString('"abc\\def"') == 'abcdef'
    assert evalString('"abc\\\\\\def"') == 'abc\\def'
    assert evalString('"abc\\\\\\\def"')

# Generated at 2022-06-23 15:49:09.126092
# Unit test for function evalString
def test_evalString():
    import sys

    # Check that evalString(repr(c)) == c for all characters c.
    assert sys.version_info >= (3, 6)
    c = eval('\u2587' + '\u2588' + '\u2589')
    r = repr(c)
    e = evalString(r)
    assert c == e

# Generated at 2022-06-23 15:49:17.584255
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([0-7]{1,3})$", '\\001')) == '\x01'
    assert escape(re.match(r"\\([0-7]{1,3})$", '\\123')) == 'S'
    assert escape(re.match(r"\\([0-7]{1,3})$", '\\1234')) == '2S'
    assert escape(re.match(r"\\([0-7]{1,3})$", '\\12345')) == '25'



# Generated at 2022-06-23 15:49:25.002779
# Unit test for function escape
def test_escape():
    assert escape(re.match(r".*x..", '\\xE9')) == 'é'
    assert escape(re.match(r".*x.", '\\xE'))  == 'é'
    assert escape(re.match(r".*x", '\\x')) == 'x'
    assert escape(re.match(r".*.", '\\0')) == '\x00'
    assert escape(re.match(r".*.", '\\9')) == '\x09'
    assert escape(re.match(r".*..", '\\77')) == '?\x07'
    assert escape(re.match(r".*..", '\\77a')) == '?\x07'

# Generated at 2022-06-23 15:49:25.576114
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:37.040645
# Unit test for function escape
def test_escape():
    from unittest.mock import patch
    from pytype.pytd import pytd_utils

    def test_esc(esc, sub):
        m = re.compile(r"\\" + esc).search("\\" + esc)
        assert m.group() == "\\" + esc
        assert m.group(1) == esc
        assert escape(m) == sub

    test_esc("a", "\a")
    test_esc(r"\a", "a")
    test_esc(r"\'", "'")
    test_esc(r'"', '"')
    test_esc("n", "\n")

# Generated at 2022-06-23 15:49:41.481571
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\a", "a")) == "\a"
    assert escape(re.match(r"\x01", "x01")) == "\x01"
    assert escape(re.match(r"\0", "0")) == "\0"
    assert escape(re.match(r"\0", "0")) == "\0"
    assert escape(re.match(r"\0a", "0a")) == "\0"



# Generated at 2022-06-23 15:49:44.161351
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError as e:
        print(e)

# Generated at 2022-06-23 15:49:45.716785
# Unit test for function test
def test_test():
    # Should print nothing
    test()

# Generated at 2022-06-23 15:49:55.955736
# Unit test for function evalString
def test_evalString():
    s = " 'hello' "
    assert evalString(s) == s[2:-2]
    s = ' "hello" '
    assert evalString(s) == s[2:-2]

    s = " '''hello''' "
    assert evalString(s) == s[3:-3]
    s = ' """hello""" '
    assert evalString(s) == s[3:-3]

    # '\033' is an octal representation
    s = " '\033' "
    assert evalString(s) == s[2:-2]

    # '\x1b' is a hex representation
    s = " '\x1b' "
    assert evalString(s) == s[2:-2]

    # '\X1b' is not a hex representation

# Generated at 2022-06-23 15:50:05.751321
# Unit test for function escape
def test_escape():
    import safeeval

    # Test simple escapes
    for (esc, char) in safeeval.simple_escapes.items():
        assert safeeval.escape(re.match(r"\\" + re.escape(esc), "\\" + esc)) == char

    # Test hexadecimal string escape
    assert safeeval.escape(re.match(r"\\x", "\\x")) == "\\x"
    assert safeeval.escape(re.match(r"\\x.", "\\x")) == "\\x"
    assert safeeval.escape(re.match(r"\\x.", "\\x2")) == "\\x2"
    assert safeeval.escape(re.match(r"\\x.", "\\x20")) == " "

    # Test octal string escape

# Generated at 2022-06-23 15:50:07.729548
# Unit test for function test
def test_test():
    with Monkey(locals(), "print", lambda *a, **kw: None):
        test()

# Generated at 2022-06-23 15:50:08.296988
# Unit test for function test
def test_test():
    test()

# End: test-test.py

# Generated at 2022-06-23 15:50:15.676031
# Unit test for function evalString
def test_evalString():
    assert evalString('"\'"') == "'"
    assert evalString('"\x1f"') == chr(31)
    assert evalString('"\x00"') == chr(0)
    assert evalString('"\400"') == chr(0)
    assert evalString('"\x7f"') == chr(127)
    assert evalString('"\x80"') == chr(128)

# Generated at 2022-06-23 15:50:24.624716
# Unit test for function escape
def test_escape():
    """Test for the method escape"""
    escape_data = [
            ("\\x41", 65),
            ("\\a", 7),
            ("\\b", 8),
            ("\\f", 12),
            ("\\n", 10),
            ("\\r", 13),
            ("\\t", 9),
            ("\\v", 11),
            ('\\"', 34),
            ("\\'", 39),
            ("\\\\", 92),
        ]

    for e, r in escape_data:
        rr = escape(re.match(r'\\[abfnrtv"\'\\x.{0,2}|[0-7]{1,3}]', e))
        assert rr == chr(r)


# Generated at 2022-06-23 15:50:33.759276
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\w)", r"\g")) is None
    assert escape(re.match(r"\\(\w)", r"\G")) is None
    assert escape(re.match(r"\\(\w)", r"\1")) == "1"
    assert escape(re.match(r"\\(\w)", r"\x1")) == "x1"
    assert escape(re.match(r"\\(\w)", r"\x1g")) == "x1"