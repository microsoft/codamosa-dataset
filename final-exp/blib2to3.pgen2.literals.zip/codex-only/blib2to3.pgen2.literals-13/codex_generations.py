

# Generated at 2022-06-23 15:40:33.701741
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61\\"') == "a\\"



# Generated at 2022-06-23 15:40:34.273769
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:40:41.970621
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\ab', '\ab')) == '\a'
    assert escape(re.match('\\b', '\b')) == '\x08'
    assert escape(re.match('\\f', '\f')) == '\x0c'
    assert escape(re.match('\\n', '\n')) == '\n'
    assert escape(re.match('\\r', '\r')) == '\r'
    assert escape(re.match('\\t', '\t')) == '\t'
    assert escape(re.match('\\v', '\v')) == '\x0b'
    assert escape(re.match("\\'", '\'')) == '\''
    assert escape(re.match('\\"', '\'')) == '\''


# Generated at 2022-06-23 15:40:47.845081
# Unit test for function escape
def test_escape():
    print(escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\xab")))
    print(escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\001")))

# Generated at 2022-06-23 15:40:49.022095
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:00.265520
# Unit test for function escape
def test_escape():
    esc = escape(re.match(r"\\(.)", r"\a"))
    assert esc == "\x07"
    esc = escape(re.match(r"\\(.)", r"\b"))
    assert esc == "\x08"
    esc = escape(re.match(r"\\(.)", r"\f"))
    assert esc == "\x0c"
    esc = escape(re.match(r"\\(.)", r"\n"))
    assert esc == "\n"
    esc = escape(re.match(r"\\(.)", r"\r"))
    assert esc == "\r"
    esc = escape(re.match(r"\\(.)", r"\t"))
    assert esc == "\t"
    esc = escape(re.match(r"\\(.)", r"\v"))


# Generated at 2022-06-23 15:41:10.794883
# Unit test for function evalString
def test_evalString():
    # Test simple strings.
    assert evalString('""') == ""
    assert evalString("''") == ""
    assert evalString('"a"') == "a"
    assert evalString("'a'") == "a"
    assert evalString('"\\""') == '"'
    assert evalString("'\\''") == "'"

    # Test string escapes.
    assert evalString(r'"\a\b\f\n\r\t\v\\\"\'\0"') == "\x07\x08\x0c\n\r\t\x0b\\\"'\0"

    # Triple quote strings.
    assert evalString(r'"""\"""")') == '"""'
    assert evalString(r"'''\'''") == "'''"

# Generated at 2022-06-23 15:41:20.209167
# Unit test for function evalString
def test_evalString():
    assert evalString('"""\r\n') == '\r\n'
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\r\\n'") == "\r\n"
    assert evalString("'\\r\\u000a'") == "\r\n"
    assert evalString("'\\r\\U0000000a'") == "\r\n"
    assert evalString("'\\u000a'") == "\n"
    assert evalString("'\\U0000000a'") == "\n"

# Generated at 2022-06-23 15:41:27.438698
# Unit test for function test
def test_test():
    import re
    import sys

    if sys.hexversion >= 0x03030000:
        badescape = "chr(0o755)"
    elif sys.hexversion >= 0x03000000:
        badescape = "chr(0755)"
    else:
        badescape = "chr(493)"

    def check(s):
        try:
            got = evalString(s)
        except ValueError as e:
            if str(e) == "invalid octal string escape ('\\7')":
                raise unittest.SkipTest("does not support bad octal escape")
            assert not re.search('chr.*[0-7]{4}', str(e))
        else:
            assert got == eval(s)

    check('"abc"')
    check('"\\n"')

# Generated at 2022-06-23 15:41:36.200144
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x"') == "\\x"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\1111"') == chr(0o1111)
    assert evalString('"\\x1111"') == "\u1111"
    assert evalString('"\\x1"') == "\u0001"
    assert evalString('"\\x11"') == "\u0011"
    assert evalString('"\\x111"') == "\u0111"
    assert evalString('"\\x1111"') == "\u1111"
    assert evalString('"\\x11111"') == "\x11111"
    assert evalString('"\\x111111"') == "\x111111"

# Generated at 2022-06-23 15:41:37.049399
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:37.709413
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:41:49.973736
# Unit test for function escape
def test_escape():
    q = "'"
    s = '"The quick brown fox jumped over the lazy dog."'
    t = q + "The quick brown fox jumped over the lazy dog." + q
    assert evalString(t) == s
    t = q + "The quick brown fox jumped over the lazy \ndog." + q
    assert evalString(t) == s
    t = q + "The quick brown fox jumped over the lazy \tdog." + q
    assert evalString(t) == s
    t = q + "The quick brown fox jumped over the lazy \vdog." + q
    assert evalString(t) == s
    t = q + "The quick brown fox jumped over the lazy \rdog." + q
    assert evalString(t) == s
    t = q + "The quick brown fox jumped over the lazy \fdog." + q

# Generated at 2022-06-23 15:41:58.227608
# Unit test for function escape
def test_escape():
    assert escape("\\n") == "\n"
    assert escape("\\xFF") == "\xff"
    assert escape("\\377") == "\377"
    assert escape("\\777") == "\u0FFF"
    assert escape("\\41") == "A"
    assert escape("\\041") == "!"
    assert escape("\\0041") == "\u0001A"
    assert escape("\\0001") == "\u0001"
    assert escape("\\x1F") == "\x1f"
    assert escape("\\x1f") == "\x1f"
    assert escape("\\u1234") == "\u1234"
    assert escape("\\u001E") == "\x1e"

# Generated at 2022-06-23 15:42:00.062601
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-23 15:42:00.819154
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-23 15:42:12.673828
# Unit test for function evalString
def test_evalString():
   assert evalString('"hello world"') == "hello world"
   assert evalString("'hello world'") == "hello world"
   assert evalString("'\\x41'") == "A"
   assert evalString("'\\x4D'") == "M"
   assert evalString("'\\x6D'") == "m"
   assert evalString("'\\41'") == "A"
   assert evalString("'\\101'") == "A"
   assert evalString("'\\x41\\x42\\x43\\x44'") == "ABCD"
   assert evalString("'\\101\\102\\103\\104'") == "ABCD"
   assert evalString("'\\xAA'") == "ª"
   assert evalString("'\\xC2'") == "Â"

# Generated at 2022-06-23 15:42:13.212333
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:17.245952
# Unit test for function test
def test_test():
    import io
    import sys

    captured_output = io.StringIO()  # Create StringIO object
    sys.stdout = captured_output  # and redirect stdout.
    test()  # Call unexported function.
    sys.stdout = sys.__stdout__  # Reset redirect.
    assert captured_output.getvalue() == ""

# Generated at 2022-06-23 15:42:24.658261
# Unit test for function evalString
def test_evalString():
    e = evalString('"""\n"""')
    assert e == '\n'
    e = evalString('"\\x61"')
    assert e == 'a'
    e = evalString('"\\x61"')
    assert e == 'a'
    e = evalString('"""\n"""')
    assert e == '\n'
    e = evalString("'\\n'")
    assert e == '\n'
    e = evalString("'\\n'")
    assert e == '\n'
    e = evalString("'\\n'")
    assert e == '\n'
    e = evalString("'\\n'")
    assert e == '\n'
    e = evalString("'\\n'")
    assert e == '\n'

# Generated at 2022-06-23 15:42:25.729216
# Unit test for function test
def test_test():
    test()
    # No assert here, because `test` prints to stdout.

# Generated at 2022-06-23 15:42:32.924722
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"


# Generated at 2022-06-23 15:42:33.441547
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:42:37.943942
# Unit test for function test
def test_test():
    import sys

    try:
        original_stdout = sys.stdout

        with open("./test_test.stdout", "w") as f:
            sys.stdout = f
            test()
    finally:
        sys.stdout = original_stdout

# Generated at 2022-06-23 15:42:49.851488
# Unit test for function evalString
def test_evalString():
    assert evalString('"\n"') == "\n"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\f"') == "\f"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\v"') == "\v"
    assert evalString('"\\377"') == "\xff"
    assert evalString('"\\172"') == "\xb2"
    assert evalString('"\\x1f"') == "\x1f"

# Regression test for issue #5735 (pre-existing/dangling backslash causes SyntaxError)
import pickle

# Generated at 2022-06-23 15:42:59.039015
# Unit test for function evalString
def test_evalString():
    assert evalString("'''abc'''") == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString("'\\'\\''") == "'"
    assert evalString("'\\''") == "'"
    assert evalString("'\n'") == "\n"
    assert evalString("'\\n'") == "\\n"
    assert evalString("'\\x61'") == "a"
    assert evalString("'!\\x61!'") == "!a!"
    assert evalString("'\\077'") == chr(63)
    assert evalString("'\\77'") == chr(63)
    assert evalString("'\\7'") == chr(7)
    assert evalString("'\\8'") == "\\8"

# Generated at 2022-06-23 15:42:59.609280
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:06.528844
# Unit test for function escape
def test_escape():
    def check(s, v):
        m = re.match(r"\\(.+)", s)
        if m is None:
            assert v == s[1:]
        else:
            assert v == escape(m)

    check(r'\a', '\a')
    check(r'\b', '\b')
    check(r'\f', '\f')
    check(r'\n', '\n')
    check(r'\r', '\r')
    check(r'\t', '\t')
    check(r'\v', '\v')
    check(r'\'', '\'')
    check(r'"', '"')
    check(r'\\', '\\')
    check(r'\x7f', '\x7f')

# Generated at 2022-06-23 15:43:10.665217
# Unit test for function evalString
def test_evalString():
    print(repr(evalString(r'"\xFF\n\r\t\f"')))
    print(repr(evalString(r"'")) == "'")
    assert evalString(r"'"*3) == "'''"
    print(repr(evalString(r"'"+'\\"\\'+"'")) == "'\\\"\\\\'")

# Generated at 2022-06-23 15:43:12.299619
# Unit test for function test
def test_test():
    return test()


# Generated at 2022-06-23 15:43:13.009359
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:43:23.074344
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', '\\a')) == '\a'
    assert escape(re.match('\\b', '\\b')) == '\b'
    assert escape(re.match('\\f', '\\f')) == '\f'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'
    assert escape(re.match('\\v', '\\v')) == '\v'
    assert escape(re.match('\\\'', '\\\'')) == '\''
    assert escape(re.match('\\"', '\\"')) == '"'

# Generated at 2022-06-23 15:43:24.620379
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        raise AssertionError

# Generated at 2022-06-23 15:43:31.885074
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == 'a'
    assert evalString('"\\""') == '"'
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x0"') == '\x00'
    assert evalString('"\\x00"') == '\x00'
    assert evalString('"\\377"') == "\xff"
    assert evalString('"\\xff"') == "\xff"



# Generated at 2022-06-23 15:43:43.896578
# Unit test for function evalString
def test_evalString():
    if evalString("'x'") != "x":
        raise Exception
    if evalString('"x"') != "x":
        raise Exception
    if evalString("'xxxx'") != "xxxx":
        raise Exception
    if evalString('"xxxx"') != "xxxx":
        raise Exception
    if evalString("'x\\tx'") != "x\tx":
        raise Exception
    if evalString('"x\\tx"') != "x\tx":
        raise Exception
    if evalString("'''x'''") != "x":
        raise Exception
    if evalString('"""x"""') != "x":
        raise Exception
    if evalString("'x' 'y'") != "xy":
        raise Exception
    if evalString('"x" "y"') != "xy":
        raise Exception

# Generated at 2022-06-23 15:43:53.295425
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x55", r"\x55")) == "U"
    assert escape(re.match(r"\\x55", r"\x554")) == "U"
    assert escape(re.match(r"\\x55", r"\x5545")) == "U4"
    assert escape(re.match(r"\\x55", r"\x55455")) == r"U45"
    assert escape(re.match(r"\\2", r"\27")) == "'"
    assert escape(re.match(r"\\2", r"\271")) == "q"
    assert escape(re.match(r"\\2", r"\2712")) == "q2"

# Generated at 2022-06-23 15:43:58.427167
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x61'") == 'a'
    assert evalString("'\\x41'") == 'A'
    assert evalString("'\\x4A'") == 'J'
    assert evalString("'\\x4B'") == 'K'
    assert evalString("'\\x4C'") == 'L'

# Generated at 2022-06-23 15:44:09.572983
# Unit test for function evalString
def test_evalString():
    assert evalString('"""foo"""') == 'foo'
    assert evalString('"foo"') == 'foo'
    assert evalString("'foo'") == 'foo'
    assert evalString('"""f\'\'\'oo"""') == "f'''oo"
    assert evalString('"""f"""') == 'f'
    assert evalString('"""\\\"""') == '\\"'
    assert evalString('"""\\\'""') == "\\'"
    assert evalString(""""\\\\""") == '\\\\'
    assert evalString('"""\\x63"""') == 'c'
    assert evalString('"""\\43"""') == '#'
    assert evalString('"""\\x3f"""') == '?'
    assert evalString('"""\\07"""') == '\\07'
    assert evalString('"""\\007"""') == '?'
   

# Generated at 2022-06-23 15:44:21.011763
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\t"') == "\t"
    assert evalString(r"'\t'") == "\t"
    assert evalString(r'"\07"') == "\07"
    assert evalString(r"'\07'") == "\07"
    assert evalString(r'"\x07"') == "\x07"
    assert evalString(r"'\x07'") == "\x07"
    assert evalString(r'"\xff"') == "\xff"
    assert evalString(r"'\xff'") == "\xff"

    # error upon invalid escape
    try:
        evalString(r"'\z'")
    except ValueError:
        pass
    else:
        raise AssertionError("Failed to raise ValueError")

# Generated at 2022-06-23 15:44:22.387899
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-23 15:44:32.703884
# Unit test for function evalString
def test_evalString():
    assert evalString("'123'") == "123"
    assert evalString("'123'") == "123"
    assert evalString("'123'") == "123"
    assert evalString("'\\t\\n'") == "\t\n"
    assert evalString("'\\t\\n\\a'") == "\t\n\a"
    assert evalString("'\\t\\n\\a\\b'") == "\t\n\a\b"
    assert evalString("'\\t\\n\\a\\b\\r'") == "\t\n\a\b\r"
    assert evalString("'\\t\\n\\a\\b\\r\\f'") == "\t\n\a\b\r\f"
    assert evalString("'\\t\\n\\a\\b\\r\\f\\v'")

# Generated at 2022-06-23 15:44:34.281830
# Unit test for function test
def test_test():
    test()

# vim: tabstop=4 expandtab shiftwidth=4

# Generated at 2022-06-23 15:44:40.411606
# Unit test for function escape
def test_escape():
    """assert that escape works as expected

    It does not test the error cases.
    """
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv])", '\\' + "'")) == "'"
    assert escape(re.match(r"\\x.{0,2}", '\\x0A')) == '\n'
    assert escape(re.match(r"\\[0-7]{1,3}", '\\011')) == '\t'

# Generated at 2022-06-23 15:44:51.908570
# Unit test for function escape
def test_escape():
    assert escape(Match(r"\x20", 20)) == " "
    assert escape(Match(r"\40", 40)) == "("
    assert escape(Match(r"\0", 0)) == "\x00"
    assert escape(Match(r"\a", "a")) == "\a"
    assert escape(Match(r"\b", "b")) == "\b"
    assert escape(Match(r"\f", "f")) == "\f"
    assert escape(Match(r"\n", "n")) == "\n"
    assert escape(Match(r"\r", "r")) == "\r"
    assert escape(Match(r"\t", "t")) == "\t"
    assert escape(Match(r"\v", "v")) == "\v"
    assert escape(Match(r"\'", "'"))

# Generated at 2022-06-23 15:45:03.120532
# Unit test for function evalString

# Generated at 2022-06-23 15:45:12.637916
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc\\n\\r"') == "abc\n\r"
    assert evalString("'abc\\n\\r'") == "abc\n\r"
    assert evalString('"abc\\n\\r"') == '"abc\n\r"'
    assert evalString("'abc\\n\\r'") == "'abc\n\r'"
    assert evalString("''''''") == "''"
    assert evalString("'a''b'") == "a'b"
    assert evalString("'a\\'b'") == "a'b"
    assert evalString("'a\\'b'") == "'a\\'b'"
    assert evalString("'a\\\\'") == "a\\"
    assert evalString("'a\\\\'") == "'a\\\\'"

# Generated at 2022-06-23 15:45:13.790117
# Unit test for function test
def test_test():
    """
    Trivial unit test: no exceptions are raised by test()
    """
    test()

# Generated at 2022-06-23 15:45:26.549574
# Unit test for function evalString
def test_evalString():
    # test simple string
    assert evalString("'simple'") == "simple"
    # test empty string
    assert evalString("''") == ""

    # test  evalString("'\\n\\t'") == "\n\t"
    # test  evalString("'\\x40'") == "@"

    # test invalid octal string 
    try:
        evalString('"\\8"')
    except ValueError as e:
        assert "invalid octal string escape" in str(e)
    else:
        assert False, "Exception not raised"

    # test invalid hex string 
    try:
        evalString('"\\xAG"')
    except ValueError as e:
        assert "invalid hex string escape ('\\xAG')" in str(e)
    else:
        assert False, "Exception not raised"

# Generated at 2022-06-23 15:45:35.927185
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(.)', r'\z')) == 'z'
    assert escape(re.match(r'\\(.)', r'\7')) == '\x07'
    assert escape(re.match(r'\\(.)', r'\x7F')) == '\x7f'
    assert escape(re.match(r'\\(.)', r'\xff')) == '\xff'
    assert escape(re.match(r'\\(.)', r'\b')) == '\x08'
    assert escape(re.match(r'\\(.)', r'\r')) == '\r'


# Generated at 2022-06-23 15:45:45.261212
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\u2603\\U0001f372"') == "☃🍲"
    assert evalString("#\\u2603\\U0001f372\n") == "☃🍲"
    assert evalString("'\\u2603\\U0001f372'") == "☃🍲"
    assert evalString("#\\u2603\\U0001f372\n") == "☃🍲"
    assert evalString("'spam'") == "spam"
    assert evalString("'spam'") == "spam"
    assert evalString("'a\\nb\\tc'") == "a\nb\tc"
    assert evalString("'a\\'b'") == "a'b"
    assert evalString("'\"'") == '"'

# Generated at 2022-06-23 15:45:47.113758
# Unit test for function test
def test_test():
    assert evalString("'\\'") == "'"
    assert evalString("'\\xab'") == chr(0xab)

# Generated at 2022-06-23 15:45:48.552404
# Unit test for function test
def test_test():
    import pytest

    with pytest.raises(AssertionError):
        test()

# Generated at 2022-06-23 15:45:50.741314
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError:
        raise IOError('test failed')

# Generated at 2022-06-23 15:45:51.416511
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:45:55.810173
# Unit test for function test
def test_test():
    import unittest

    class TestStringEval(unittest.TestCase):
        def test_cases(self):
            test()

    unittest.main(module=__name__, verbosity=2)

# Generated at 2022-06-23 15:46:00.586161
# Unit test for function evalString
def test_evalString():
    # Appleseed
    assert evalString('"\\x41\\x70\\x70\\x6c\\x65\\x73\\x65\\x65\\x64"') == "Appleseed"
    # 🍎
    assert evalString('"\\xf0\\x9f\\x8d\\x8e"') == "\U0001f34e"
    # 🍎🍎
    assert evalString('"\\xf0\\x9f\\x8d\\x8e\\xf0\\x9f\\x8d\\x8e"') == "\U0001f34e\U0001f34e"

# Generated at 2022-06-23 15:46:08.769176
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"a"') == "a"
    assert evalString('"\\"') == '"'
    assert evalString('"\\""') == '"'
    assert evalString('"\'"') == "'"
    #
    raises(ValueError, evalString, '"\\"')
    raises(ValueError, evalString, '"\\x1"')
    raises(ValueError, evalString, '"\\177"')
    raises(ValueError, evalString, '"\\800"')
    raises(ValueError, evalString, '"\\0"')
    raises(ValueError, evalString, '"\\8"')
    raises(ValueError, evalString, '"\\9"')

# Generated at 2022-06-23 15:46:09.419813
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:46:19.519383
# Unit test for function escape
def test_escape():
    # Test valid escapes
    simple_escapes_copy = simple_escapes.copy()
    while simple_escapes_copy:
        key, val = simple_escapes_copy.popitem()
        m = re.match(r"\\" + key, r"\\" + key)
        assert escape(m) == val

    # Test hex escapes
    assert escape(re.match(r"\\x11", r"\\x11")) == "\x11"
    assert escape(re.match(r"\\xab", r"\\xab")) == "\xab"
    assert escape(re.match(r"\\xFf", r"\\xFf")) == "\xFf"

    # Test octal escapes
    assert escape(re.match(r"\\377", r"\\377")) == "\377"
    assert escape

# Generated at 2022-06-23 15:46:25.780142
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\\\", r"\\")) == "\\"

    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"

# Generated at 2022-06-23 15:46:37.074622
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\"")) == '"'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"

# Generated at 2022-06-23 15:46:38.421429
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\u2713"') == "\u2713"

# Generated at 2022-06-23 15:46:46.517660
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'(a)', 'a')) == 'a'
    assert escape(re.match(r'(\\a)', '\\a')) == '\a'
    assert escape(re.match(r'(\\b)', '\\b')) == '\b'
    assert escape(re.match(r'(\\f)', '\\f')) == '\f'
    assert escape(re.match(r'(\\n)', '\\n')) == '\n'
    assert escape(re.match(r'(\\r)', '\\r')) == '\r'
    assert escape(re.match(r'(\\t)', '\\t')) == '\t'
    assert escape(re.match(r'(\\v)', '\\v'))

# Generated at 2022-06-23 15:46:47.130762
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-23 15:46:57.872629
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\\'', r'\'')) == "'"
    assert escape(re.match(r'\\\"', r'\"')) == '"'
    assert escape(re.match(r'\\', r'\\')) == '\\'
    assert escape(re.match(r'\\a', r'\a')) == '\a'
    assert escape(re.match(r'\\b', r'\b')) == '\b'
    assert escape(re.match(r'\\f', r'\f')) == '\f'
    assert escape(re.match(r'\\n', r'\n')) == '\n'
    assert escape(re.match(r'\\r', r'\r')) == '\r'

# Generated at 2022-06-23 15:46:59.432782
# Unit test for function test
def test_test():
    """
    Unit test for test.
    """
    # test() is a command-line tool
    pass

# Generated at 2022-06-23 15:47:08.107536
# Unit test for function evalString
def test_evalString():
    assert evalString('r"\\n"') == "\\n"
    assert evalString('r"\\n"') == evalString('r"\\\n"')
    assert evalString('"foo"') == "foo"
    assert evalString('"""foo"""') == '"""foo"""'
    assert evalString('"\\x61"') == "\\x61"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\n"') == evalString('"\\\n"')
    assert evalString('"\\\t"') == "\t"

# Generated at 2022-06-23 15:47:16.949413
# Unit test for function escape
def test_escape():
    # Tests for escape
    assert escape(re.match(r'\\.', '\\a')) == "\a"
    assert escape(re.match(r'\\.', '\\b')) == "\b"
    assert escape(re.match(r'\\.', '\\f')) == "\f"
    assert escape(re.match(r'\\.', '\\n')) == "\n"
    assert escape(re.match(r'\\.', '\\r')) == "\r"
    assert escape(re.match(r'\\.', '\\t')) == "\t"
    assert escape(re.match(r'\\.', '\\v')) == "\v"
    assert escape(re.match(r'\\.', '\\\'')) == "\'"

# Generated at 2022-06-23 15:47:23.284586
# Unit test for function escape
def test_escape():
    # Test a simple escape.
    assert escape(re.match(r'\\a', '\\a')) == '\a'

    # Test a hexadecimal escape.
    assert escape(re.match(r'\\x1b', '\\x1b')) == '\x1b'
    assert escape(re.match(r'\\x0b', '\\x0b')) == '\x0b'

    # Test an octal escape.
    assert escape(re.match(r'\\033', '\\033')) == '\033'

    # Test an invalid escape.
    try:
        escape(re.match(r'\\x1', '\\x1'))
        raise AssertionError("should have raised a ValueError")
    except ValueError:
        pass

    # Test an invalid hexade

# Generated at 2022-06-23 15:47:31.786811
# Unit test for function evalString
def test_evalString():
    assert 'a' == evalString("'a'")
    assert 'lambda ' == evalString("'lambda '")
    assert '\t' == evalString("'\\t'")
    assert '\\\\' == evalString("'\\\\'")
    assert "\n" == evalString("'\\n'")
    assert '\x7f' == evalString("'\\x7f'")
    assert '\x80' == evalString("'\\x80'")
    assert '\xff' == evalString("'\\xff'")
    assert '\n' == evalString("'\\012'")
    assert '\n' == evalString("'\\000012'")
    assert ' ' == evalString("'\\0140'")
    assert ' ' == evalString("'\\00000140'")
    assert 'aaaa' == evalString

# Generated at 2022-06-23 15:47:34.360571
# Unit test for function test
def test_test():
    from . import test
    test()
    try:
        evalString("'\\x0xx'")
        assert 0, "expected exception"
    except ValueError:
        pass

# Generated at 2022-06-23 15:47:37.070089
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        # TODO: actually test something useful
        assert True == False

# Generated at 2022-06-23 15:47:48.260414
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString('"\n"') == "\n"
    assert evalString('"\'"') == "'"
    assert evalString('"abc\ndef\n"') == "abc\ndef\n"
    assert evalString('"\\""') == '"'
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\0\\01\\012\\0123\\x01\\x12\\x1234"') == "\x07\x08\x0c\n\r\t\x0b\x00\x01\x02\x03\x01\x12\x1234"
    assert evalString("'abc'") == "abc"

# Generated at 2022-06-23 15:47:48.862689
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:47:57.024854
# Unit test for function evalString
def test_evalString():
    print(evalString('"\n"'))
    print(evalString("'\n'"))
    print(evalString('"\\n"'))
    print(evalString("'\\n'"))
    print(evalString('"\\x61"'))
    print(evalString("'\\x61'"))
    print(evalString('"\\x0a"'))
    print(evalString("'\\x0a'"))
    print(evalString('"\\n\\x61"'))
    print(evalString("'\\n\\x61'"))

# Generated at 2022-06-23 15:48:08.923721
# Unit test for function escape
def test_escape():
    # simple escapes
    assert escape(re.match(r"\\.", "\\a")) == "\a"
    assert escape(re.match(r"\\.", "\\b")) == "\b"
    assert escape(re.match(r"\\.", "\\f")) == "\f"
    assert escape(re.match(r"\\.", "\\n")) == "\n"
    assert escape(re.match(r"\\.", "\\r")) == "\r"
    assert escape(re.match(r"\\.", "\\t")) == "\t"
    assert escape(re.match(r"\\.", "\\v")) == "\v"
    assert escape(re.match(r"\\.", "\\'")) == "'"
    assert escape(re.match(r"\\.", '\\"')) == '"'

# Generated at 2022-06-23 15:48:09.518445
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:18.159324
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc", evalString('"abc"')
    assert evalString("'abc'") == "abc", evalString("'abc'")
    assert evalString(r'"\n"') == "\n", evalString(r'"\n"')
    assert evalString(r"'\n'") == "\n", evalString(r"'\n'")
    assert evalString(r'"\0"') == "\0", evalString(r'"\0"')
    assert evalString(r"'\0'") == "\0", evalString(r"'\0'")

    # Test for unicode (wide) character string literals
    assert evalString(r'"\u03a3"') == "\u03a3", evalString(r'"\u03a3"')

# Generated at 2022-06-23 15:48:18.859567
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:48:28.471179
# Unit test for function evalString
def test_evalString():
    assert evalString('"\xab"') == '\xab'
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\xab'") == "\xab"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\00'") == "\0"
    assert evalString("'\\00'") == "\0"
    assert evalString("'\\000'") == "\0"
    assert evalString("'\\000'") == "\0"
    assert evalString("'\\123'") == "\x1b"
    assert evalString("'\\123'") == "\x1b"
    assert evalString("'\\0123'") == "\x1b"
    assert evalString("'\\123'") == "\x1b"

# Generated at 2022-06-23 15:48:39.577760
# Unit test for function escape
def test_escape():
    # From code
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"

# Generated at 2022-06-23 15:48:51.185036
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"ab\'c"') == "ab'c"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x2A'") == "*"
    assert evalString("'\\u2345'") == "\u2345"
    assert evalString("'\\U00012345'") == "\U00012345"
    assert evalString("'\\U00012345\\U00012345'") == "\U00012345\u012345"
    assert evalString("'\\U00012345'") == "\U00012345"
    assert evalString('"\\n\\x2a"') == "\n*"
    assert evalString('"\\"abc\\""') == '"abc"'

# Generated at 2022-06-23 15:48:59.074329
# Unit test for function escape
def test_escape():
    # Test octal escape
    assert escape(re.match(r"\\([0-7]+)", r"\123")) == r"{"
    # Test hexadecimal escape
    assert escape(re.match(r"\\x([0-9a-f]+)", r"\x41")) == r"A"
    # Test backspace
    assert escape(re.match(r"\\([0-7]+)", r"\b")) == "\b"
    # Test formfeed
    assert escape(re.match(r"\\([0-7]+)", r"\012")) == "\n"

# Generated at 2022-06-23 15:49:00.037690
# Unit test for function evalString
def test_evalString():
    return
# End of unit test for function evalString

# Generated at 2022-06-23 15:49:09.337304
# Unit test for function evalString
def test_evalString():
    def test(s):
        print("%s -> %s" % (s, evalString(s)))

    test("'abc'")
    test('"abc"')
    test("'abc \\n a'")
    test("'abc \\n \\t a'")
    test("'abc \\077 a'")
    test("'abc \\x7f a'")
    test("'abc \\x77a a'")

    try:
        test("'abc \\x7fa a'")
    except ValueError:
        pass

    try:
        test("'abc \\7fa a'")
    except ValueError:
        pass

    try:
        test("'abc \\xa a'")
    except ValueError:
        pass

    try:
        test("abc")
    except AssertionError:
        pass

# Generated at 2022-06-23 15:49:09.933648
# Unit test for function escape
def test_escape():
    pass

# Generated at 2022-06-23 15:49:17.015372
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString("'a'") == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\000"') == "\000"
    assert evalString('"\\141"') == "a"
    assert evalString('"\\141\\000"') == "a\000"
    assert evalString('"\\000\\141"') == "\000a"

# Generated at 2022-06-23 15:49:17.586529
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-23 15:49:19.607866
# Unit test for function test
def test_test():
    from unittest import TestCase

    class TestTest(TestCase):
        def test_test(self):
            # This test is not dropped
            return test

# Generated at 2022-06-23 15:49:26.219177
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\a", "\a")).encode("utf-8") == b"\a"
    assert escape(re.search(r"\\b", "\b")).encode("utf-8") == b"\b"
    assert escape(re.search(r"\\f", "\f")).encode("utf-8") == b"\f"
    assert escape(re.search(r"\\n", "\n")).encode("utf-8") == b"\n"
    assert escape(re.search(r"\\r", "\r")).encode("utf-8") == b"\r"
    assert escape(re.search(r"\\t", "\t")).encode("utf-8") == b"\t"

# Generated at 2022-06-23 15:49:37.619570
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"

# Generated at 2022-06-23 15:49:49.782107
# Unit test for function evalString
def test_evalString():
    # Test literal with no escape
    assert evalString('"This is a no escape string"') == "This is a no escape string"

    # Test string literal must start and end with the same quote, doesn't matter if it's double or single quote
    assert evalString('"This is a double quoted string"') == "This is a double quoted string"
    assert evalString("'This is a single quoted string'") == "This is a single quoted string"

    # Test escape "\n"
    assert evalString('"A string with \n newline"') == "A string with \n newline"

    # Test escape "\b"
    assert evalString('"A string with \b backspace"') == "A string with \b backspace"

    # Test escape "\t"

# Generated at 2022-06-23 15:49:51.751163
# Unit test for function test
def test_test():
    if __name__ == "__main__":
        test()

# Generated at 2022-06-23 15:50:02.427943
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\])", r"\'")) == "'"
    assert escape(re.match(r"\\([abfnrtv'\"\\])", r'\"')) == '"'
    assert escape(re.match(r"\\([abfnrtv'\"\\])", r"\\")) == "\\"
    assert escape(re.match(r"\\([abfnrtv'\"\\])", r"\a")) == "\x07"
    assert escape(re.match(r"\\([abfnrtv'\"\\])", r"\b")) == "\x08"
    assert escape(re.match(r"\\([abfnrtv'\"\\])", r"\f")) == "\x0c"

# Generated at 2022-06-23 15:50:08.162780
# Unit test for function escape
def test_escape():
    print("Testing escape...")
    print(escape("\\a"))
    print(escape("\\b"))
    print(escape("\\f"))
    print(escape("\\n"))
    print(escape("\\r"))
    print(escape("\\t"))
    print(escape("\\v"))
    print("...done")



# Generated at 2022-06-23 15:50:20.450345
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\([^\\])", "\\a")) == "\a"
    assert escape(re.search(r"\\([^\\])", '\\"')) == '"'
    assert escape(re.search(r"\\([^\\])", "\\'")) == "'"
    assert escape(re.search(r"\\([^\\])", "\\\\")) == "\\"
    assert escape(re.search(r"\\([^\\])", "\\x41")) == "A"
    assert escape(re.search(r"\\([^\\])", "\\x9f")) == "\x9f"
    assert escape(re.search(r"\\([^\\])", "\\0")) == "\x00"

# Generated at 2022-06-23 15:50:22.521307
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as ex:
        print("test failed:", ex)
        assert False
    print("test passed")

# Generated at 2022-06-23 15:50:24.111463
# Unit test for function test
def test_test():
    assert callable(test)
    test()


# Generated at 2022-06-23 15:50:24.674850
# Unit test for function test
def test_test():
  test()

# Generated at 2022-06-23 15:50:37.103506
# Unit test for function escape