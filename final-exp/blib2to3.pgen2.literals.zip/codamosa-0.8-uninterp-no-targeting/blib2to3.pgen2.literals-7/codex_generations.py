

# Generated at 2022-06-21 10:10:26.252271
# Unit test for function escape
def test_escape():
    assert escape(r"\\x00") == "\x00"
    assert escape(r"\\x0f") == "\x0f"
    assert escape(r"\\x10") == "\x10"
    assert escape(r"\\xF0") == "\xF0"

    assert escape(r"\x00") == "x00"
    assert escape(r"\xF0") == "xF0"

    assert escape(r"\\a") == "\a"
    assert escape(r"\\b") == "\b"
    assert escape(r"\\f") == "\f"
    assert escape(r"\\n") == "\n"
    assert escape(r"\\r") == "\r"
    assert escape(r"\\t") == "\t"
    assert escape(r"\\v") == "\v"

# Generated at 2022-06-21 10:10:32.176801
# Unit test for function evalString
def test_evalString():
    s = evalString("'a b\\'c'")
    assert s == "a b'c"
    assert evalString("'\\x61\\x62 c'") == "ab c"
    assert evalString('"a b\\"c"') == 'a b"c'
    assert evalString('"\\x61\\x62 c"') == "ab c"

# Generated at 2022-06-21 10:10:40.160395
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\((\\(x.{0,2}|[0-7]{1,3}))\)", r"(\x2a)")) == "*"
    assert escape(re.match(r"\((\\(x.{0,2}|[0-7]{1,3}))\)", r"(\42)")) == "*"
    assert escape(re.match(r"\((\\(x.{0,2}|[0-7]{1,3}))\)", r"(\042)")) == "*"

# Generated at 2022-06-21 10:10:40.811399
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:10:53.272328
# Unit test for function evalString
def test_evalString():
    def test(s, want):
        got = evalString(s)
        assert got == want, "evalString(%s) == %s, want %s" % (s, got, want)

    test(r"'abc'", "abc")
    test(r'"abc"', "abc")
    test(r"'''abc'''", "abc")
    test(r'"""abc"""', "abc")
    test(r"'\n'", "\n")
    test(r"'\\n'", "\\n")
    test(r"'\''", "'")
    test(r"'\\0'", "\0")
    test(r"'\\01'", "\01")
    test(r"'\\012'", "\012")
    test(r"'\x01'", "\x01")

# Generated at 2022-06-21 10:10:53.977183
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:06.180592
# Unit test for function escape
def test_escape():
    import sys
    if sys.version_info < (3, 0):
        # replace '\x' with '\u'
        assert escape("\\x10") == '\u0010'
        assert escape("\\xFF") == '\u00FF'
        assert escape("\\x0G") == '\\x0G'
    else:
        assert escape("\\x10") == "\x10"
        assert escape("\\xFF") == "\xFF"
        assert escape("\\x0G") == "\\x0G"
    # make sure that escape() comes back a string that can be eval()ed
    # to get the same value as the input string
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = escape(s)

# Generated at 2022-06-21 10:11:17.188515
# Unit test for function escape
def test_escape():
    import unittest

    class TestEscape(unittest.TestCase):
        def test_simple_escapes(self):
            for c in simple_escapes:
                res = simple_escapes[c]
                self.assertEqual(res, escape(re.match(r"\\%s" % c, r"\b")))

        def test_octal_escapes(self):
            self.assertEqual("\x00", escape(re.match(r"\\0", r"\0")))
            self.assertEqual("\t", escape(re.match(r"\\0?11", r"\011")))
            self.assertEqual("\x7F", escape(re.match(r"\\0?177", r"\0177")))


# Generated at 2022-06-21 10:11:18.296689
# Unit test for function evalString
def test_evalString():
    print(evalString('"abc"'))
    print(evalString("'abc'"))

# Generated at 2022-06-21 10:11:30.029856
# Unit test for function evalString
def test_evalString():
    import pytest
    from test.test_support import captured_stdout

    assert evalString('"a"') == "a"
    assert evalString("'a'") == "a"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString('"\\b"') == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString('"\\f"') == "\f"
    assert evalString("'\\n'") == "\n"

# Generated at 2022-06-21 10:11:47.793278
# Unit test for function escape
def test_escape():
    x = escape(re.search(r'\\x', '\\x'))

# Generated at 2022-06-21 10:11:59.657477
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{1,2}|[0-7]{1,3})","\\'")) == "'"
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{1,2}|[0-7]{1,3})","\\\"")) == '"'
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{1,2}|[0-7]{1,3})","\\\\")) == "\\"
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{1,2}|[0-7]{1,3})","\\a")) == "\a"

# Generated at 2022-06-21 10:12:08.278283
# Unit test for function escape
def test_escape():
    tests = [
        (r"\a", "\a"),
        (r"\b", "\b"),
        (r"\f", "\f"),
        (r"\n", "\n"),
        (r"\r", "\r"),
        (r"\t", "\t"),
        (r"\v", "\v"),
        (r"\'", "'"),
        (r'\"', '"'),
        (r"\\", "\\"),
        (r"\x1F", "\x1F"),
        (r"\x1f", "\x1f"),
        (r"\x20", " "),
        (r"\12", "\12"),
    ]
    for (s, val) in tests:
        assert escape(re.match(r"\\.*", s)) == val



# Generated at 2022-06-21 10:12:09.443791
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:10.071990
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:13.929308
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r"'\"'") == '"'
    assert evalString(r'"a"")') == "a"

# Generated at 2022-06-21 10:12:14.694588
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:17.285765
# Unit test for function evalString
def test_evalString():
    evalString('"\\\'\\n\\v\\t\\r\\b\\f\\\\\\x01\\x013\\o755\\0777"')


# Generated at 2022-06-21 10:12:29.977311
# Unit test for function escape
def test_escape():
    # check simple escapes
    for k,v in simple_escapes.items():
        m = re.match(r"\\%s"%k, "\\%s"%v)
        assert escape(m) == v

    # check hex string escapes
    m = re.match(r"\\x..", "\\x00")
    assert escape(m) == "\x00"
    m = re.match(r"\\x..", "\\xab")
    assert escape(m) == "\xab"
    m = re.match(r"\\x..", "\\xFE")
    assert escape(m) == "\xfe"
    m = re.match(r"\\x..", "\\xFF")
    assert escape(m) == "\xff"

    # check octal string escapes

# Generated at 2022-06-21 10:12:31.048752
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:52.301268
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\x7F'") == "\x7F"

    # Round-trip from char to repr to evalString to char
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c



# Generated at 2022-06-21 10:12:52.898399
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:54.670893
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\.", "\\8")) == '\b'

# Generated at 2022-06-21 10:13:06.604249
# Unit test for function escape
def test_escape():
    def check(input, expected_output):
        m = re.match(r"\\(.*)", input)
        assert m
        assert escape(m) == expected_output

    yield check, "\\a", "\a"
    yield check, "\\b", "\b"
    yield check, "\\f", "\f"
    yield check, "\\n", "\n"
    yield check, "\\r", "\r"
    yield check, "\\t", "\t"
    yield check, "\\v", "\v"
    yield check, "\\'", "'"
    yield check, '\\"', '"'
    yield check, "\\\\", "\\"
    yield check, "\\x30", "0"
    yield check, "\\xFF", "\xFF"
    yield check, "\\056", "."
   

# Generated at 2022-06-21 10:13:15.178497
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x[0-9A-Fa-f]{2}", "\\x00")) == "\0"
    assert escape(re.match(r"\\x[0-9A-Fa-f]{2}", "\\xAB")) == "\xab"
    assert escape(re.match(r"\\x[0-9A-Fa-f]{2}", "\\xFF")) == "\xff"
    assert escape(re.match(r"\\[a-zA-Z]", "\\a")) == "\a"
    assert escape(re.match(r"\\[a-zA-Z]", "\\b")) == "\b"
    assert escape(re.match(r"\\[a-zA-Z]", "\\f")) == "\f"
    assert escape

# Generated at 2022-06-21 10:13:26.926641
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\000"') == '\x00'
    assert evalString('"\\x00"') == '\x00'
    assert evalString("'\\000'") == '\x00'
    assert evalString("'\\x00'") == '\x00'
    assert evalString("'\\n'") == '\n'
    assert evalString("'\\t'") == '\t'
    assert evalString("'\\t\\n'") == '\t\n'
    assert evalString("'\\t\\n'") == '\t\n'
    assert evalString("'\\t\\n'") == '\t\n'
    assert evalString("'\\t\\n'") == '\t\n'
    assert evalString("'\\t'") == '\t'
   

# Generated at 2022-06-21 10:13:27.256044
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:36.135576
# Unit test for function escape
def test_escape():
    import pytest
    # Check negative tests for escape function
    for tail in ["a", "z", "Q", "", "  ", "\n"]:
        with pytest.raises(ValueError):
            escape(re.match(r"\\{0}".format(tail), "\\{0}".format(tail)))

    # Check edge case
    assert escape(re.match(r"\\x{0}".format(""), "\\x")) == "x"

    # Check posix character classes
    for tail in ["d", "s", "w", "D", "S", "W", "b", "B"]:
        assert escape(re.match(r"\\{0}".format(tail), "\\{0}".format(tail))) == chr(ord(tail))

    # Check escapes that should work
    assert escape

# Generated at 2022-06-21 10:13:42.111635
# Unit test for function evalString
def test_evalString():
    assert evalString("'hi'") == 'hi'
    assert evalString('"hi"') == 'hi'
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        # print i, c, s, e
        assert e == c, (i, c, s, e)

# Generated at 2022-06-21 10:13:45.447385
# Unit test for function test
def test_test():
    """test for function test"""
    try:
        test()
    except Exception as e:
        raise Exception("Test Failure in function test: " + str(e))

# Generated at 2022-06-21 10:14:09.520197
# Unit test for function test
def test_test():
    import copy
    import imp
    import os
    import pprint
    import re
    import tempfile
    import unittest

    from test import support


    # Figure out where to look for the tests
    try:
        test_source = support.findfile("tokenize_tests.txt",
                                       subdir="testdata")
    except AttributeError:
        # No findfile() in Python 3.2
        test_source = os.path.join(os.path.dirname(__file__),
                                   "tokenize_tests.txt")


    class TestEvalString(unittest.TestCase):

        def setUp(self):
            self.test_support = support.import_fresh_module('test.test_support')

            # Create a temporary file to hold the tests

# Generated at 2022-06-21 10:14:10.855885
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\0", "\\0")) == "\0"

# Generated at 2022-06-21 10:14:17.888670
# Unit test for function evalString

# Generated at 2022-06-21 10:14:29.306146
# Unit test for function evalString
def test_evalString():
    # test single- and double-quoted strings with all kinds of escapes:
    assert evalString("'''a\\'b\\\'c'\\'d'''") == """a'b\'c'd"""
    assert evalString('"""a\\"b\\"\'c"\\"d"""') == """a"b\"'c"d"""
    assert evalString("'a\\\\nb\\\\tc'") == "a\\nb\\tc"
    assert evalString('"a\\\\nb\\\\tc"') == "a\\nb\\tc"

    # test various malformed strings:
    try:
        evalString("")
    except ValueError:
        pass
    else:
        assert False, "didn't detect an invalid string"

    try:
        evalString("'abc\\")
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-21 10:14:30.832511
# Unit test for function escape
def test_escape():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 10:14:39.781802
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"

# Generated at 2022-06-21 10:14:41.373383
# Unit test for function test
def test_test():
    # We don't really care that test returns nothing, so we ignore its return
    # value.
    test()

# Generated at 2022-06-21 10:14:42.303744
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:54.204480
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", r"\x12")) == "\x12"
    assert escape(re.match(r"\\x12", r"\x12")) == "\x12"
    assert escape(re.match(r"\\123", r"\123")) == "\x13"
    assert escape(re.match(r"\\12", r"\12")) == "\x0a"
    assert escape(re.match(r"\\5", r"\5")) == "\x05"
    assert escape(re.match(r"\\2", r"\2")) == "\x02"
    assert escape(re.match(r"\\x", r"\x")) == "\\x"
    assert escape(re.match(r"\\u", r"\u")) == "\\u"

# Generated at 2022-06-21 10:14:55.057033
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:14.916095
# Unit test for function escape
def test_escape():
    assert escape(None) is None
    assert escape(["\\a", "b"]) == "ab"
    assert escape(["\\a", "\\b"]) == "a\\b"
    assert escape(["\\xab", "\\b"]) == "\n\\b"
    assert escape(["\\xab", "\\b0"]) == "\n0"
    assert escape(["\\a", "0"]) == "a0"
    assert escape(["\\a", "0xab"]) == "a0xab"



# Generated at 2022-06-21 10:15:24.547525
# Unit test for function escape

# Generated at 2022-06-21 10:15:24.952523
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:26.804845
# Unit test for function escape
def test_escape():
    # Test escape of non-control characters
    # Test escape of whitespace characters
    # Test escape of control character 
    # Test escape of octal character
    # Test escape of hex character
    # Test escape of unicode character
    pass

# Generated at 2022-06-21 10:15:27.805292
# Unit test for function test
def test_test():
    assert test() is None


# Generated at 2022-06-21 10:15:36.255086
# Unit test for function evalString
def test_evalString():
    # Pass some simple strings
    assert evalString('"this is a test"') == "this is a test"
    assert evalString("'this is a test'") == "this is a test"
    assert evalString('"this is a test"') == evalString("'this is a test'")
    # Pass some double-quoted strings
    assert evalString('"""this is a test"""') == "this is a test"
    assert evalString('"this is a \"test\""') == 'this is a "test"'
    assert evalString('"this is a \'test\'"') == "this is a 'test'"
    assert evalString('"this\nis\na\rtest\r\n\\"') == "this\nis\na\rtest\r\n\\"
    # Pass some single-quoted strings
    assert evalString

# Generated at 2022-06-21 10:15:40.888360
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, (i, c, s, e)

# Generated at 2022-06-21 10:15:52.382665
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'''abc'''") == "abc"
    assert evalString('"""abc"""') == "abc"
    assert evalString("'\\\\a\\\\b'") == "\\a\\b"
    assert evalString("'\\'\\'\\''") == "'''"
    assert evalString("'\\'\\'\\''") == "'''"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\141\\142\\143'") == "abc"
    assert evalString("'\\071\\142\\143'") == "abc"
    assert evalString("'\\0x61\\142\\x63'") == "abc"

# Generated at 2022-06-21 10:15:54.106297
# Unit test for function test
def test_test():
    test()
    assert True  # Used only to remind us to add real tests here

# Unit tests for function evalString

# Generated at 2022-06-21 10:16:01.078084
# Unit test for function escape

# Generated at 2022-06-21 10:16:32.590979
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r"'''\'''") == "'''"
    assert evalString(r"'\x00'") == "\x00"
    assert evalString(r"'\000'") == "\000"
    assert evalString(r"'\0000'") == "\0000"
    assert evalString(r"'\x01'") == "\x01"
    assert evalString(r"'\001'") == "\001"
    assert evalString(r"'\0001'") == "\0001"
    assert evalString(r"'\x7f'") == "\x7f"
    assert evalString(r"'\177'") == "\177"

# Generated at 2022-06-21 10:16:33.069392
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:16:45.438667
# Unit test for function escape
def test_escape():
    # Test basic escapes
    assert escape(('\\a', 'a')) == "\a"
    assert escape(('\\b', 'b')) == "\b"
    assert escape(('\\f', 'f')) == "\f"
    assert escape(('\\n', 'n')) == "\n"
    assert escape(('\\r', 'r')) == "\r"
    assert escape(('\\t', 't')) == "\t"
    assert escape(('\\v', 'v')) == "\v"
    assert escape(('\\\'', '\'')) == "'"
    assert escape(('\\"', '"')) == '"'
    assert escape(('\\\\', '\\')) == "\\"
    # Test invalid hexadecimal escapes

# Generated at 2022-06-21 10:16:48.413547
# Unit test for function test
def test_test():
    try:
        test()
    except:
        print("Undefined behaviour of evalString() detected.")
        import sys; sys.exit(1)

# Generated at 2022-06-21 10:16:54.144853
# Unit test for function escape
def test_escape():
    for i in range(128, 256):
        c = chr(i)
        s = repr(c)[1:-1]  # Remove quotes
        s = "\\" + s
        c1 = escape(re.match(r"\\(.*)", s))
        assert c == c1, (
            f"Bad result: '{c}' -> '{c1}' with input {s}"
        )

# Generated at 2022-06-21 10:17:01.270242
# Unit test for function test
def test_test():
    import os
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    os.close(fd)

    import sys

    orig_stderr = sys.stderr
    sys.stderr = open(fname, "w")

    try:
        test()
        assert os.path.getsize(fname) == 0
    finally:
        sys.stderr.close()
        sys.stderr = orig_stderr
        os.remove(fname)



# Generated at 2022-06-21 10:17:09.040686
# Unit test for function evalString
def test_evalString():
    # Tests whether evalString() converts a Python literal string
    # (i.e. a sequence of characters enclosed in quotes) correctly
    # into a Python string. A test is generated for each possible
    # character value; the generated test consists of a Python string
    # literal containing that character, which is then passed to
    # evalString(), which should return the corresponding Python
    # string containing just that character. The original character
    # and resulting string are then compared to make sure they are
    # equal.
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, "%r -> %r -> %r" % (s, e, c)


# Generated at 2022-06-21 10:17:16.858322
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\x61") == "a"
    assert escape("\\x7f") == "\x7f"
    assert escape("\\377") == "\xff"

# Generated at 2022-06-21 10:17:17.499417
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:27.884769
# Unit test for function escape
def test_escape():
    from .string_escape import escape
    
    # Test cases for function escape
    assert escape("\\'") == "'"
    assert escape("\\\"") == '"'
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\x41") == "A"
    assert escape("\\x65") == "e"
    assert escape("\\x61") == "a"
    assert escape("\\x20") == " "


# Generated at 2022-06-21 10:18:17.665396
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert (e == c)

# Generated at 2022-06-21 10:18:24.215421
# Unit test for function escape
def test_escape():
    test_escape_escaped_ascii_simple_chars()
    test_escape_unicode_simple_chars()
    test_escape_escaped_ascii_hex_string()
    test_escape_unicode_hex_string()
    test_escape_escaped_ascii_octal_string()
    test_escape_unicode_octal_string()


# Generated at 2022-06-21 10:18:33.313254
# Unit test for function escape
def test_escape():

    import ast

    # test some simple escapes
    assert escape(re.match(r"\\.", "\\a")).encode() == b"\x07"
    assert escape(re.match(r"\\.", "\\b")).encode() == b"\x08"
    assert escape(re.match(r"\\.", "\\f")).encode() == b"\x0c"
    assert escape(re.match(r"\\.", "\\n")).encode() == b"\n"
    assert escape(re.match(r"\\.", "\\r")).encode() == b"\r"
    assert escape(re.match(r"\\.", "\\t")).encode() == b"\t"
    assert escape(re.match(r"\\.", "\\v")).encode() == b

# Generated at 2022-06-21 10:18:34.393020
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-21 10:18:43.238720
# Unit test for function escape
def test_escape():
    # Test with single quotes
    m = re.match('\\', "\\")
    assert m.group(0) == "\\", repr(m.group(0))
    assert m.group(1) == "", repr(m.group(1))
    assert escape(m) == "\\"
    m = re.match('\\x', "\\x")
    assert m.group(0) == "\\x", repr(m.group(0))
    assert m.group(1) == "x", repr(m.group(1))
    assert escape(m) == "x"
    m = re.match('\\a', "\\a")
    assert m.group(0) == "\\a", repr(m.group(0))
    assert m.group(1) == "a", repr(m.group(1))


# Generated at 2022-06-21 10:18:53.778768
# Unit test for function evalString
def test_evalString():
    assert evalString("'abcd'") == "abcd"
    assert evalString("'abcd\n'") == "abcd\n"
    assert evalString("'abcd\n") == "abcd\n"
    assert evalString("'abcd\t'") == "abcd\t"
    assert evalString("'abcd\t") == "abcd\t"
    assert evalString("\"abcd\"") == "abcd"
    assert evalString("\"abcd\n\"") == "abcd\n"
    assert evalString("\"abcd\n") == "abcd\n"
    assert evalString("\"abcd\t\"") == "abcd\t"
    assert evalString("\"abcd\t") == "abcd\t"


# Generated at 2022-06-21 10:18:59.950290
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\r"') == "\r"
    assert evalString("'''hello'''") == "hello"
    assert evalString("'a'") == "a"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\r'") == "\r"

# Generated at 2022-06-21 10:19:01.636788
# Unit test for function escape
def test_escape():
    assert escape('\\x20') == ' '


# Generated at 2022-06-21 10:19:02.281081
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:19:08.108047
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\\'\\"\\\\\\x00\\001\\2\\00\\00\\01"') == (
        "\a\b\f\n\r\t\v'\"\\\0\x01\x02\0\0\x01"
    )
    # Issue #24558
    assert evalString('"""') == ""
    assert evalString('r"""') == ""

