

# Generated at 2022-06-21 10:10:35.137403
# Unit test for function evalString
def test_evalString():
    from py_stringescape import evalString
    assert evalString('"a"'), 'a'
    assert evalString("'a'"), 'a'
    assert evalString(r'"\""'), '"'
    assert evalString(r'"\'"'), "'"
    assert evalString(r'"\\"'), '\\'
    assert evalString(r'"\a"'), chr(7)
    assert evalString(r'"\b"'), chr(8)
    assert evalString(r'"\f"'), chr(12)
    assert evalString(r'"\n"'), chr(10)
    assert evalString(r'"\r"'), chr(13)
    assert evalString(r'"\t"'), chr(9)
    assert evalString(r'"\v"'), chr(11)
    assert evalString

# Generated at 2022-06-21 10:10:37.771119
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\", "\\")) == "\\"
    assert escape(re.match(r"\\", "\\")) == escape(re.match(r"\\", "\\"))


# Generated at 2022-06-21 10:10:45.137561
# Unit test for function evalString
def test_evalString():
    s = evalString('"abc"')
    assert(s == "abc")
    s = evalString("'abc'")
    assert(s == "abc")
    s = evalString("'abc\\n'")
    assert(s == "abc\n")
    s = evalString("'abc\\x00'")
    assert(s == "abc\x00")
    s = evalString("'abc\\127'")
    assert(s == "abc\x7f")

# Generated at 2022-06-21 10:10:46.607112
# Unit test for function test
def test_test():
    # Test docstring
    test()
    pass

# Generated at 2022-06-21 10:10:51.294425
# Unit test for function escape
def test_escape():
    from mypy_extensions import String
    
    match: Match[String] = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")
    escape(match)

# Generated at 2022-06-21 10:11:00.366377
# Unit test for function escape

# Generated at 2022-06-21 10:11:01.328744
# Unit test for function evalString
def test_evalString():
    assert evalString('"\'"') == "'"

# Generated at 2022-06-21 10:11:09.519415
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\xFF'") == "\xFF"
    assert evalString("'\\377'") == "\377"

    try:
        evalString("'\\x1234'")
    except ValueError:
        pass
    else:
        assert False, "expected ValueError"  # pragma: no cover

    try:
        evalString("'\\8'")
    except ValueError:
        pass
    else:
        assert False, "expected ValueError"  # pragma: no cover

    try:
        evalString("'\\0'")
    except ValueError:
        pass
    else:
        assert False, "expected ValueError"  # pragma: no cover


# Generated at 2022-06-21 10:11:10.188959
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:19.739708
# Unit test for function evalString
def test_evalString():
    assert evalString('"""a"""') == 'a'
    assert evalString('"""\\"""') == '\\'
    assert evalString('"""\\a"""') == '\\a'
    assert evalString('"""\\x61"""') == 'a'
    assert evalString('"""\\"""') == '\\'
    assert evalString('"""\\\n"""') == ''
    assert evalString('"""\\""""') == '\\""'
    assert evalString('r"""\\""""') == 'r"""\\""'

# Generated at 2022-06-21 10:11:50.622907
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = escape(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-21 10:11:51.602534
# Unit test for function test
def test_test(): # Dummy function
    pass

# Generated at 2022-06-21 10:11:52.570029
# Unit test for function test
def test_test():
    # This should not throw an exception
    test()

# Generated at 2022-06-21 10:11:53.164266
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:03.254198
# Unit test for function evalString
def test_evalString():
    assert evalString('"\a"') == "\a"
    assert evalString("'\b'") == "\b"
    assert evalString("'\f'") == "\f"
    assert evalString("'\n'") == "\n"
    assert evalString("'\r'") == "\r"
    assert evalString("'\t'") == "\t"
    assert evalString("'\v'") == "\v"
    assert evalString("'\''") == "'"
    assert evalString('"\\"') == "\\"
    assert evalString("'\x1c'") == "\x1c"
    assert evalString("'\030'") == "\x18"

# Generated at 2022-06-21 10:12:08.075774
# Unit test for function escape
def test_escape():
    test_cases = [
        (r"\x01", "\x01"),
        (r"\x0a", "\n"),
    ]
    for pattern, expect in test_cases:
        assert escape(re.match(r"\\(.*)", pattern)) == expect

# Generated at 2022-06-21 10:12:09.378217
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-21 10:12:20.844062
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x1b"') == '\x1b'
    assert evalString('"\\x0b"') == '\x0b'
    assert evalString('"\\x00"') == '\x00'
    assert evalString('"\\x0B"') == '\x0B'
    assert evalString('"\\x01"') == '\x01'
    assert evalString('"\\x1B"') == '\x1B'
    assert evalString('"\\x04"') == '\x04'
    assert evalString('"\\x11"') == '\x11'
    assert evalString('"\\x17"') == '\x17'
    assert evalString('"\\x1f"') == '\x1f'

# Generated at 2022-06-21 10:12:31.953252
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"a"') == "a"
    assert evalString(r'"\\"') == "\\"
    assert evalString(r'"\'"') == "'"
    assert evalString(r'"\a"') == "\a"
    assert evalString(r'"\b"') == "\b"
    assert evalString(r'"\f"') == "\f"
    assert evalString(r'"\n"') == "\n"
    assert evalString(r'"\r"') == "\r"
    assert evalString(r'"\t"') == "\t"
    assert evalString(r'"\v"') == "\v"
    assert evalString(r'"\x00"') == "\x00"
    assert evalString(r'"\00"') == "\000"

# Generated at 2022-06-21 10:12:32.752262
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:44.762719
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:55.528924
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\r")) == "\r"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\xFF")) == "\xFF"

# Generated at 2022-06-21 10:12:59.335278
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\103'") == "C"

# Generated at 2022-06-21 10:13:04.306196
# Unit test for function evalString
def test_evalString():
    assert evalString("'string'") == 'string'
    assert evalString("'string with \"\'escapes\'\"'") == 'string with "\\\'escapes\\\'"'
    assert evalString("'1''2'") == '1\x00'



# Generated at 2022-06-21 10:13:04.989450
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:13:06.002206
# Unit test for function test
def test_test():
    # Test for the input string using ASCII characters
    test()

# Generated at 2022-06-21 10:13:06.656171
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:15.208822
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\.', "\\0")) == "\x00"
    assert escape(re.match(r'\\.', "\\1")) == "\x01"
    assert escape(re.match(r'\\.', "\\07")) == "\x07"
    assert escape(re.match(r'\\.', "\\011")) == "\t"
    assert escape(re.match(r'\\.', "\\101")) == "\x01"
    assert escape(re.match(r'\\.', "\\x0a")) == "\n"
    assert escape(re.match(r'\\.', "\\x1q")) == "\x01q"

# Generated at 2022-06-21 10:13:26.927052
# Unit test for function evalString
def test_evalString():
  assert evalString('""') == ''
  assert evalString('"a"') == 'a'
  assert evalString('"ab"') == 'ab'
  assert evalString('"abc def"') == 'abc def'
  assert evalString('"\\151"') == 'a'
  assert evalString('"\\x61"') == 'a'
  assert evalString('"\\a"') == '\a'
  assert evalString('"\\b"') == '\b'
  assert evalString('"\\f"') == '\f'
  assert evalString('"\\n"') == '\n'
  assert evalString('"\\r"') == '\r'
  assert evalString('"\\t"') == '\t'
  assert evalString('"\\v"') == '\v'

# Generated at 2022-06-21 10:13:35.891971
# Unit test for function escape

# Generated at 2022-06-21 10:13:59.027976
# Unit test for function test
def test_test():
    try:
        test()
    except:
        raise AssertionError



# Generated at 2022-06-21 10:14:11.175556
# Unit test for function escape
def test_escape():
    # test escape append
    assert escape("\\x41") == "A"
    assert escape("\\x4a") == "J"
    assert escape("\\x52") == "R"
    assert escape("\\x53") == "S"
    assert escape("\\x61") == "a"
    assert escape("\\x62") == "b"
    assert escape("\\x63") == "c"
    assert escape("\\x64") == "d"
    assert escape("\\x65") == "e"
    assert escape("\\x66") == "f"
    assert escape("\\x67") == "g"
    assert escape("\\x68") == "h"
    assert escape("\\x69") == "i"
    assert escape("\\x6A") == "j"
    assert escape("\\x6B")

# Generated at 2022-06-21 10:14:18.046844
# Unit test for function evalString
def test_evalString():
    assert evalString('"x"') == "x"
    assert evalString('"\\"x\\""') == '"x"'
    assert evalString("'\\'x\\''") == "'x'"
    assert evalString('"x\\nx"') == "x\nx"
    assert evalString('"x\\r\\nx"') == "x\r\nx"
    assert evalString('"x\\r\\nx"') == "x\r\nx"
    assert evalString('"x\\r\\"\\"\\nx"') == "x\r\"\"\nx"
    assert evalString('"x"b') == "x"
    assert evalString('"x"b') == "x"

    assert evalString('"\\117"') == "O"

# Generated at 2022-06-21 10:14:29.449367
# Unit test for function escape
def test_escape():
    import pytest
    simple_escapes_test = {
        "a": "\a",
        "b": "\b",
        "f": "\f",
        "n": "\n",
        "r": "\r",
        "t": "\t",
        "v": "\v",
        "'": "'",
        '"': '"',
        "\\": "\\",
    }
    for key, value in simple_escapes_test.items():
        assert escape(re.match(r"\\" + key, None)) == value
    with pytest.raises(ValueError):
        escape(re.match(r"\\.", None))
    with pytest.raises(ValueError):
        escape(re.match(r"\\x", None))
    with pytest.raises(ValueError):
        escape

# Generated at 2022-06-21 10:14:37.085156
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString('"abc\\x61\\x62\\x63"') == 'abcabc'
    assert evalString('"abc\\141\\142\\143"') == 'abcabc'
    assert evalString('"abc\\141\\x62\\u0063"') == 'abcabc'
    assert evalString('"abc\\141\\0x62\\u0063"') == 'abcabc'

# Generated at 2022-06-21 10:14:41.962205
# Unit test for function escape
def test_escape():
    assert escape("\\x41") == "@"
    assert escape("\\077") == "?"
    assert escape("\\'") == "'"
    assert escape("\\\"") == "\""
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"



# Generated at 2022-06-21 10:14:53.929804
# Unit test for function evalString
def test_evalString():
    assert evalString('"good"') == "good"
    assert evalString('"goodbye"') == "goodbye"
    assert evalString("'hello'") == "hello"
    assert evalString("'escape \\' single quote'") == "escape ' single quote"
    assert evalString('"escape \\" double quote"') == 'escape " double quote'
    assert evalString(r'"escape \a\b\f\n\r\t\v"') == "escape \x07\x08\x0c\n\r\t\x0b"
    assert evalString(r'"escape \x41"') == "escape \x41"
    assert evalString(r'"escape \x41\x42\x43"') == "escape \x41\x42\x43"

# Generated at 2022-06-21 10:15:01.616338
# Unit test for function escape

# Generated at 2022-06-21 10:15:08.506633
# Unit test for function evalString
def test_evalString():
    # Only single line string is supported for now
    assert evalString('"""test"""') == '"""test"""'
    assert evalString('"test"') == '"test"'
    assert evalString('"""') == '"""'
    assert evalString('"t\ne\0st"') == '"t\ne\0st"'
    assert evalString('r"""t\ne\0st"""') == r'"""t\ne\0st"""'

# Generated at 2022-06-21 10:15:12.021373
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"



# Generated at 2022-06-21 10:15:57.050613
# Unit test for function test
def test_test():
    import unittest
    class Testtest(unittest.TestCase):
        def test_test(self):
            test()
    unittest.main()

# Generated at 2022-06-21 10:15:57.527467
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:59.650633
# Unit test for function escape
def test_escape():
    assert escape(None) == ''
    assert escape('') == ''
    assert escape('test') == ''

# Generated at 2022-06-21 10:16:04.894782
# Unit test for function evalString
def test_evalString():
    assert evalString("'abcd'") == "abcd"
    assert evalString("\"abcd\"") == "abcd"
    assert evalString("'abc\\ndef'") == "abc\ndef"
    assert evalString("\"abc\\ndef\"") == "abc\ndef"

# Generated at 2022-06-21 10:16:16.065257
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv]|'|\\|\")", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv]|'|\\|\")", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv]|'|\\|\")", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv]|'|\\|\")", r"\n")) == "\n"
    assert escape(re.match(r"\\([abfnrtv]|'|\\|\")", r"\r")) == "\r"

# Generated at 2022-06-21 10:16:24.148950
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == "foo"
    assert evalString('"foo\n"') == "foo\n"
    assert evalString('"foo\r"') == "foo\r"
    assert evalString('"foo\r\n"') == "foo\r\n"
    assert evalString('"foo\\r\\n"') == "foo\\r\\n"
    assert evalString("'foo\\r\\n'") == "foo\\r\\n"
    assert evalString("'foo\r\n'") == "foo\r\n"
    assert evalString("'foo\r'") == "foo\r"
    assert evalString("'foo\n'") == "foo\n"
    assert evalString("'foo'") == "foo"
    assert evalString('"\\x61"')

# Generated at 2022-06-21 10:16:28.635196
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", "'")).strip() == "'"
    assert escape(re.match(r'\\"', '"')).strip() == '"'
    # assert escape(re.match(r"\\", "\\")).strip() == "\\"

# Generated at 2022-06-21 10:16:35.425225
# Unit test for function escape
def test_escape():
    tests = [
        ("\\x01", "\x01"),
        ("\\1", "\x01"),
        ("\\001", "\x01"),
        ("\\x01\\x02\\x03\\x04", "\x01\x02\x03\x04"),
        ("\\x01\\0x02\\0x03\\0x04", "\x01\x02\x03\x04"),
        ("\\x01\\1\\2\\3\\4", "\x01\x01\x02\x03\x04"),
    ]
    for (esc, res) in tests:
        assert escape(re.search(r"\\(.+)", esc)) == res



# Generated at 2022-06-21 10:16:48.115291
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\xe9'") == "\u00e9"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\r\\n'") == "\r\n"
    assert evalString("'\\r\\n'") == "\r\n"

# Generated at 2022-06-21 10:16:51.383473
# Unit test for function escape
def test_escape():
    """
    >>> escape('\\x0A')
    '\\n'
    >>> escape('\\07')
    '\\x07'
    >>> escape('\\x')
    '\\x'
    """

# Generated at 2022-06-21 10:18:24.333012
# Unit test for function evalString
def test_evalString():
    assert evalString('"\x00\xff"') == "\x00\xff"

# Generated at 2022-06-21 10:18:32.666332
# Unit test for function escape
def test_escape():
    # Valid inputs
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"

# Generated at 2022-06-21 10:18:42.748634
# Unit test for function evalString
def test_evalString():
    test_expect_result = "'test'"
    assert evalString(test_expect_result) == test_expect_result
    test_expect_result = '"test"'
    assert evalString(test_expect_result) == test_expect_result
    test_expect_result = ''''"test"'''
    assert evalString(test_expect_result) == test_expect_result
    test_expect_result = """'test'"""
    assert evalString(test_expect_result) == test_expect_result
    test_expect_result = "'''test'''"
    assert evalString(test_expect_result) == test_expect_result
    test_expect_result = "\"\"\"test\"\"\""

# Generated at 2022-06-21 10:18:53.370270
# Unit test for function escape
def test_escape():
    assert escape('"\a"') == "\a"
    assert escape('"\b"') == "\b"
    assert escape('"\f"') == "\f"
    assert escape('"\n"') == "\n"
    assert escape('"\r"') == "\r"
    assert escape('"\t"') == "\t"
    assert escape('"\v"') == "\v"
    assert escape('"\\"') == "\\"
    assert escape('"\'"') == "\'"
    assert escape('"\""') == '"'

    assert escape('"\x00"') == "\x00"
    assert escape('"\x0a"') == "\x0a"
    assert escape('"\xff"') == "\xff"

    assert escape('"\377"') == "\xff"

# Generated at 2022-06-21 10:19:02.975360
# Unit test for function evalString
def test_evalString():
    from hypothesis import given
    from hypothesis.strategies import characters, one_of, text, tuples
    from itertools import chain

    # Hypothesis does not generate (or at least does not generate in a reasonable
    # length of time) all legal valid python string literals.  Focus on the most
    # common cases.
    python_chars = characters(blacklist_characters=['\\'])

    valid_octals = "".join(map(str, chain(range(8), range(9, 100, 10))))
    valid_quintals = text(valid_octals, min_size=1, max_size=2)

    valid_hexes = "".join(map(str, chain(range(10), "abcdefABCDEF")))

# Generated at 2022-06-21 10:19:11.429879
# Unit test for function evalString
def test_evalString():
    # Test for simple cases
    assert evalString(r'"abc"') == "abc"
    assert evalString(r"'''abc'''") == "abc"
    assert evalString(r"r'abc'") == "abc"
    assert evalString(r'"""abc"""') == "abc"
    assert evalString(r"u'''abc'''") == "abc"
    assert evalString(r"ur'''abc'''") == "abc"
    assert evalString(r"br'''abc'''") == "abc"
    assert evalString(r"b'''abc'''") == "abc"
    assert evalString(r"f'''abc'''") == "abc"
    assert evalString(r"fr'''abc'''") == "abc"

# Generated at 2022-06-21 10:19:11.973266
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:19:15.302445
# Unit test for function evalString
def test_evalString():
    assert evalString("'test'") == "test"
    assert evalString('"test"') == "test"
    assert evalString("'test: \\x61'") == "test: a"
    assert evalString("'test: \\b'") == "test: \x08"

# Generated at 2022-06-21 10:19:24.354332
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\xFF") == "ÿ"
    assert escape("\\377") == "\xff"
    assert escape("\\40") == " "
    assert escape("\\77") == "?"



# Generated at 2022-06-21 10:19:34.425747
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString('"abc\n"') == 'abc\n'
    assert evalString('r"abc\n"') == 'abc\\n'
    assert evalString('"abc" + "def"') == 'abcdef'
    assert evalString(r'r"abc\"def"') == 'abc\\"def'
    assert evalString(r'"abc\"def"') == 'abc"def'
    # Test boundarie cases
    assert evalString(r'"\"') == '"'
    assert evalString(r'"\\"') == '\\'
    assert evalString(r'"\a"') == '\a'
    assert evalString(r'"\b"') == '\b'
    assert evalString(r'"\f"') == '\f'