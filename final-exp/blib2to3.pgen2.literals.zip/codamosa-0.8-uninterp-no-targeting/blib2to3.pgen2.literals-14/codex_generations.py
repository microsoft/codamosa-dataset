

# Generated at 2022-06-21 10:10:35.672989
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\101"') == "A"
    assert evalString("'\\101'") == "A"
    assert evalString('"\\\\101"') == "\\101"

# Generated at 2022-06-21 10:10:41.734986
# Unit test for function evalString
def test_evalString():
    """
    >>> evalString("'\\r\\n\\x61'")
    '\\r\\n\\x61'
    >>> evalString("u'\\r\\n\\x61'")
    '\\r\\n\\x61'
    >>> evalString("U'\\r\\n\\x61'")
    '\\r\\n\\x61'
    >>> evalString("r'\\r\\n\\x61'")
    '\\\\r\\\\n\\\\x61'
    >>> evalString("R'\\r\\n\\x61'")
    '\\\\r\\\\n\\\\x61'
    """
    return 0

# Generated at 2022-06-21 10:10:48.296545
# Unit test for function escape
def test_escape():
    print("Testing escape")

    # Assert that the function still works if called directly
    assert(escape("\\r") == "\r")

    # Assert that all dictionary keys have a valid value
    for key in simple_escapes.keys():
        print("Testing %s" % key)
        assert(escape("\\%s" % key) == simple_escapes[key])
        pass
    pass



# Generated at 2022-06-21 10:10:58.492214
# Unit test for function escape
def test_escape():
    # Test single escape
    assert escape(re.match('\a', '\\a')) == "\a"
    assert escape(re.match('\b', '\\b')) == "\b"
    assert escape(re.match('\f', '\\f')) == "\f"
    assert escape(re.match('\n', '\\n')) == "\n"
    assert escape(re.match('\r', '\\r')) == "\r"
    assert escape(re.match('\t', '\\t')) == "\t"
    assert escape(re.match('\v', '\\v')) == "\v"

    # Test multiple escapes
    assert escape(re.match('\\n\\r', '\\n\\r')) == "\n\r"

# Generated at 2022-06-21 10:11:04.047314
# Unit test for function escape
def test_escape():
    assert escape("abc") == "abc"
    assert escape("\\b") == "\\x08"
    assert escape("\\n") == "\\x0a"
    assert escape("\\r") == "\\x0d"
    assert escape("\\x12") == "\\x12"
    assert escape("\\101") == "\\101"
    raise Exception("test_escape failed")

# Generated at 2022-06-21 10:11:16.032515
# Unit test for function escape

# Generated at 2022-06-21 10:11:27.914712
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\000"') == '\x00'
    assert evalString('"\\001"') == '\x01'
    assert evalString('"\\002"') == '\x02'
    assert evalString('"\\003"') == '\x03'
    assert evalString('"\\004"') == '\x04'
    assert evalString('"\\005"') == '\x05'
    assert evalString('"\\006"') == '\x06'
    assert evalString('"\\007"') == '\x07'
    assert evalString('"\\010"') == '\x08'
    assert evalString('"\\011"') == '\t'
    assert evalString('"\\012"') == '\n'

# Generated at 2022-06-21 10:11:39.801878
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape

# Generated at 2022-06-21 10:11:47.712931
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\""') == '"'
    assert evalString(r'"\'"') == "'"
    assert evalString(r"'\"'") == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r'"\\"') == "\\"
    assert evalString(r"'\\'") == "\\"
    assert evalString(r'"\a"') == "\a"
    assert evalString(r'"\b"') == "\b"
    assert evalString(r'"\f"') == "\f"
    assert evalString(r'"\n"') == "\n"
    assert evalString(r'"\r"') == "\r"
    assert evalString(r'"\t"') == "\t"
    assert evalString(r'"\v"') == "\v"
   

# Generated at 2022-06-21 10:11:49.299341
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'


# Generated at 2022-06-21 10:12:05.204911
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'\\''") == "'"
    s = r'"\""'
    assert evalString(s) == "\\"
    s = r'"\\"'
    assert evalString(s) == "\\"

# Generated at 2022-06-21 10:12:11.493417
# Unit test for function escape
def test_escape():
    # Valid escape sequences
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\"') == '"'
    assert escape('\\\\') == '\\'
    assert escape('\\x08') == '\x08'
    assert escape('\\xFF') == '\xFF'
    assert escape('\\377') == '\377'

    # Invalid escape sequences

# Generated at 2022-06-21 10:12:13.334855
# Unit test for function test
def test_test():
    import sys

    test()
    # Check that the above 

# Generated at 2022-06-21 10:12:25.724655
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == 'hello'
    assert evalString('''"hello"''') == 'hello'
    assert evalString('''"\"hello\""''') == '"hello"'
    assert evalString('''"hello\\"''') == 'hello\\'
    assert evalString('''"hello\\n"''') == "hello\n"
    assert evalString('''"hello\\x7f"''') == "\x7f"
    assert evalString('''"hello\\x7fg"''') == "\x7f" + "g"

# Generated at 2022-06-21 10:12:26.350757
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-21 10:12:27.385517
# Unit test for function test
def test_test():
    assert test() is None



# Generated at 2022-06-21 10:12:37.464933
# Unit test for function escape
def test_escape():

    # Test simple escapes
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\\")) == "\\"

# Generated at 2022-06-21 10:12:40.251763
# Unit test for function escape
def test_escape():
    s = "\\x00"
    for i in range(256):
        c = chr(i)
        s = s + c
        assert evalString(s) == s

# Generated at 2022-06-21 10:12:41.161878
# Unit test for function escape
def test_escape():
    assert escape("\\b") == "\b"

# Generated at 2022-06-21 10:12:47.774749
# Unit test for function escape
def test_escape():

    from lib2to3.pgen2.tokenize import generate_tokens, untokenize

    import unittest
    import io

    class TestEscape(unittest.TestCase):

        def test_escape(self):
            test_data = [
                "\\x22 \\t \\n \\r \\b \\a",
                "\\x22 \\t \\n \\r \\b \\a\\x22 \\t \\n \\r \\b \\a",
                "\\",
            ]

            for t in test_data:
                # Evaluate the original string
                fp = io.StringIO(u"print('" + t + "');")
                tokengen = generate_tokens(fp.readline)
                token = next(tokengen)
                evaluated_string = eval(token[1])
               

# Generated at 2022-06-21 10:12:59.081526
# Unit test for function test
def test_test():
    # TODO: pass
    pass

# Generated at 2022-06-21 10:13:10.428443
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\'", r"\'")) == "'"
    assert escape(re.match("\\''", r"\''")) == "\\'"
    assert escape(re.match("\\xab", r"\xab")) == "«"
    assert escape(re.match("\\164", r"\164")) == "t"
    assert escape(re.match("\\45", r"\45")) == "%"
    assert escape(re.match("\\xabcd", r"\xabcd")) == r"«cd"
    assert escape(re.match("\\1234", r"\1234")) == "234"
    assert escape(re.match("\\1", r"\1")) == "\x01"

# Generated at 2022-06-21 10:13:22.234430
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})",
                           r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})",
                           r"\z")) is None

    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})",
                           r"\x07")) == "\x07"

# Generated at 2022-06-21 10:13:23.129238
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:24.739870
# Unit test for function test
def test_test():
    s = "print"
    e = evalString(s)
    assert e == s

# Generated at 2022-06-21 10:13:27.978750
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-21 10:13:28.597597
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:37.092722
# Unit test for function escape
def test_escape():
  # Normal case
  assert escape(re.match(r"\\([abfnrtv\'\"\\])", "\\a")) == "\a"
  assert escape(re.match(r"\\([abfnrtv\'\"\\])", "\\b")) == "\b"
  assert escape(re.match(r"\\([abfnrtv\'\"\\])", "\\f")) == "\f"
  assert escape(re.match(r"\\([abfnrtv\'\"\\])", "\\n")) == "\n"
  assert escape(re.match(r"\\([abfnrtv\'\"\\])", "\\r")) == "\r"
  assert escape(re.match(r"\\([abfnrtv\'\"\\])", "\\t")) == "\t"

# Generated at 2022-06-21 10:13:39.917447
# Unit test for function evalString
def test_evalString():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-21 10:13:43.240334
# Unit test for function escape
def test_escape():
    assert escape("\\x20") == " "
    assert escape("\\114") == "R"
    assert escape("\\074") == "J"

# Generated at 2022-06-21 10:14:04.907807
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert False, "test() raised exception"

# Generated at 2022-06-21 10:14:14.566963
# Unit test for function escape

# Generated at 2022-06-21 10:14:25.890663
# Unit test for function evalString
def test_evalString():
    # Test single-quoted string
    assert evalString("'abc'") == 'abc'
    assert evalString("'a\\nbc'") == "a\nbc"
    assert evalString("'a\\'bc'") == "a'bc"
    assert evalString("'a\\\\bc'") == "a\\bc"
    assert evalString("'a\\\\\\'bc'") == "a\\'bc"
    assert evalString("'''a\\nbc'''") == "a\nbc"
    assert evalString("'''a''bc'") == "a'bc"
    assert evalString("'''a\\'bc'") == "a\\'bc"
    assert evalString("'''a\\'b'c'") == "a\\'b'c"

# Generated at 2022-06-21 10:14:32.803940
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(.)', r'\x1f')) == chr(31)
    assert escape(re.match(r'\\(.)', r'\x7f')) == chr(127)
    assert escape(re.match(r'\\(.)', r'\x80')) == chr(128)
    assert escape(re.match(r'\\(.)', r'\xff')) == chr(255)

# Generated at 2022-06-21 10:14:38.187506
# Unit test for function escape
def test_escape():
    assert not simple_escapes["a"]
    assert "\a" == simple_escapes.get("a")
    assert simple_escapes.get("b") == "\b"
    assert simple_escapes.get("x") is None
    assert escape("\a") == "a"
    assert escape("\b") == "b"
    assert escape("x") is None
    assert escape("\x41") == "A"



# Generated at 2022-06-21 10:14:50.163312
# Unit test for function evalString
def test_evalString():
    assert evalString('"line one\\nline two"') == 'line one\nline two'
    assert evalString('"\\x61pple"') == 'apple'
    assert evalString('"\\47"') == "'"
    assert evalString('"\\n"') == '\n'
    assert evalString('"\\011"') == '\t'
    assert evalString('"\\x07"') == '\x07'
    #assert evalString('"\\8"') # raises ValueError
    #assert evalString('"\\18"') # raises ValueError
    #assert evalString('"\\118"') # raises ValueError

# Generated at 2022-06-21 10:14:56.389672
# Unit test for function escape

# Generated at 2022-06-21 10:15:04.120226
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\x', '\\x')) == '\\x' # type: ignore
    assert escape(re.match('\\11', '\\11')) == '\\11' # type: ignore
    assert escape(re.match('\\\\', '\\\\')) == '\\\\' # type: ignore
    assert escape(re.match('\\3', '\\3')) == '\\3' # type: ignore
    assert escape(re.match('\\5', '\\5')) == '\\5' # type: ignore
    assert escape(re.match('\\6', '\\6')) == '\\6' # type: ignore
    try:
        escape(re.match('\\78', '\\78')) # type: ignore
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 10:15:04.726742
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:10.794206
# Unit test for function evalString
def test_evalString():
    s = r"\x63"
    e = evalString(s)
    assert e == "c"

    s = r"\x6e"
    e = evalString(s)
    assert e == "n"

    s = r"\x6f"
    e = evalString(s)
    assert e == "o"



# Generated at 2022-06-21 10:15:31.549977
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:32.167946
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:38.302926
# Unit test for function escape
def test_escape():
    assert escape(re.search(r'\a', 'a')) == 'a'
    assert escape(re.search(r'\b', 'b')) == 'b'
    assert escape(re.search(r'\f', 'f')) == 'f'
    assert escape(re.search(r'\n', 'n')) == 'n'
    assert escape(re.search(r'\r', 'r')) == 'r'
    assert escape(re.search(r'\t', 't')) == 't'
    assert escape(re.search(r'\v', 'v')) == 'v'
    assert escape(re.search("\\'", "'")) == "'"
    assert escape(re.search("\\\"", '"')) == '"'

# Generated at 2022-06-21 10:15:38.980782
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:15:40.888678
# Unit test for function test
def test_test():
    assert callable(test) and test() is None

# Generated at 2022-06-21 10:15:49.847397
# Unit test for function escape
def test_escape():
    import random
    import string
    from os import urandom
    random.seed(1)
    for i in range(100):
        s = "\\x{0:02x}".format(int(random.random() * 256)).encode()
        s = s.decode()
        assert s == chr(int(s, 16))
        assert evalString(s) == escape(s)
    for i in range(100):
        s = urandom(1).decode()
        s = s.decode()
        assert s == chr(int(s, 16))
        assert evalString(s) == escape(s)


# Generated at 2022-06-21 10:15:51.241012
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:59.414204
# Unit test for function test
def test_test():
    import io
    import os
    import sys

    # Capture output
    oldstdout = sys.stdout
    newstdout = io.StringIO()
    sys.stdout = newstdout

    # Call function
    test()

    # Restore output
    sys.stdout = oldstdout

    # Evaluate captured output
    if sys.platform.startswith("win"):
        out = newstdout.getvalue().splitlines()
        assert os.linesep in out[0], "First line must contain os.linesep"
        assert out[0].split(os.linesep) == [
            "91 [ 91 ] '['"
        ], "First line output is incorrect: {}".format(out[0])

# Generated at 2022-06-21 10:16:04.461706
# Unit test for function escape
def test_escape():
    import unittest
    import re
    
    class TestEscape(unittest.TestCase):
        def test_escape(self):
            self.assertEqual(re.sub(r'\\(.)', escape, r"\nfoo \n"), "\nfoo \n")

    unittest.main()

# Generated at 2022-06-21 10:16:05.606364
# Unit test for function test
def test_test():
    test()
    assert True

# Generated at 2022-06-21 10:16:47.772022
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\n"') == "\n"
    assert evalString("'foo'") == "foo"
    assert evalString('"\\xf0"') == "\xf0"
    assert evalString('"foo"') == "foo"

# Generated at 2022-06-21 10:16:50.642459
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\x7F"') == "\u007F"

# Generated at 2022-06-21 10:16:59.443120
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\"')) == '"'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"

# Generated at 2022-06-21 10:17:07.907772
# Unit test for function escape
def test_escape():
    assert escape("\a") == "\\a"
    assert escape("\b") == "\\b"
    assert escape("\f") == "\\f"
    assert escape("\n") == "\\n"
    assert escape("\r") == "\\r"
    assert escape("\t") == "\\t"
    assert escape("\v") == "\\v"
    assert escape("'") == "\\'"
    assert escape('"') == '\\"'
    assert escape("\\") == "\\\\"

# Generated at 2022-06-21 10:17:08.964965
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:17:17.905825
# Unit test for function escape
def test_escape():
    # f-strings not available before 3.6
    single_quote_escapes = [
        ("\\'", "'"),
        ("\\\\", "\\"),
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\r", "\r"),
        ("\\v", "\v"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\t", "\t"),
    ]
    double_quote_escapes = [
        ('\\"', '"'),
        ("\\\\", "\\"),
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\r", "\r"),
        ("\\v", "\v"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\t", "\t"),
    ]
    hex

# Generated at 2022-06-21 10:17:28.647962
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'abc' + 'def'") == "abcdef"
    assert evalString("\'" + "a" * 1000 + "\'") == "a" * 1000
    assert evalString("\"abc\"") == "abc"
    assert evalString("\"abc\" + \"def\"") == "abcdef"
    assert evalString("\"" + "a" * 1000 + "\"") == "a" * 1000

    assert evalString("r'abc'") == "abc"
    assert evalString("r'abc' + 'def'") == "abcdef"
    assert evalString("r\'" + "a" * 1000 + "\'") == "a" * 1000
    assert evalString("r\"abc\"") == "abc"

# Generated at 2022-06-21 10:17:29.472146
# Unit test for function test
def test_test():
    test()
    assert True

# Generated at 2022-06-21 10:17:35.722448
# Unit test for function evalString
def test_evalString():
    assert evalString("'''A Python string'''") == "A Python string"
    assert evalString('"""Another Python string"""') == "Another Python string"
    assert evalString("b'\\xe4\\xf6'") == b"\xe4\xf6"
    assert evalString("r'\\xe'") == r"\xe"

# Generated at 2022-06-21 10:17:43.974999
# Unit test for function escape
def test_escape():
    escaped_chars = ['\\"\\r\\x1c\\u0761', '\\n\\n']
    escapes = [
            ('\\"', '\"'),
            ('\\r', '\r'),
            ('\\x1c', '\x1c'),
            ('\\u0761', '\u0761'),
            ('\\n', '\n'),
            ('\\n', '\n')]

    def check(esc, char):
        assert escape(esc) == char

    for esc, char in zip(escaped_chars, escapes):
        yield check, esc, char[1]

# Generated at 2022-06-21 10:18:40.953006
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:18:44.017878
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x7F'") == "\x7F"

# Generated at 2022-06-21 10:18:54.532486
# Unit test for function escape
def test_escape():
    # Test simple backslash escapes
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\\'", r"\'")) == "'"
    assert escape(re.match(r'\\\"', r'\"')) == '"'

# Generated at 2022-06-21 10:19:06.225450
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\0xX]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\0xX]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\0xX]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"

# Generated at 2022-06-21 10:19:15.645797
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|[x][0-9a-fA-F]{2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|[x][0-9a-fA-F]{2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|[x][0-9a-fA-F]{2}|[0-7]{1,3})", "\\f")) == "\f"

# Generated at 2022-06-21 10:19:27.467057
# Unit test for function escape
def test_escape():
    from pytest import raises

    # Test that escape correctly handles the simple escapes
    for c, escaped in simple_escapes.items():
        assert escape(re.search('\\' + c, c)) == escaped

    # Test the backslash handler
    assert escape(re.search(r'\\', r'\\')) == r'\\'

    # Test the octal handler
    assert escape(re.search(r'\0', r'\0')) == r'\x00'
    assert escape(re.search(r'\000', r'\000')) == r'\x00'
    assert escape(re.search(r'\777', r'\777')) == r'\xFF'

    # Test the too-short octal handler

# Generated at 2022-06-21 10:19:36.171486
# Unit test for function evalString
def test_evalString():
    """Test the evalString() function"""

# Generated at 2022-06-21 10:19:44.985970
# Unit test for function escape
def test_escape():
    def check(s, v):
        result = escape(s)
        assert result == v

    check(r'\a', '\a')
    check(r'\x01', '\x01')
    check(r'\001', '\001')
    check(r'\b', '\b')
    check(r'\x7f', '\x7f')
    check(r'\177', chr(0x7f))
    check(r'\200', chr(0x80))
    check(r'\377', chr(0xff))
    check(r'\x0F', '\x0F')
    check(r'\654', chr(0x254))
    check(r'\999', chr(0x3e7))



# Generated at 2022-06-21 10:19:45.806140
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:19:56.904608
# Unit test for function escape
def test_escape():

    assert escape(re.match(r"\\.", "\\'")) == "'"
    assert escape(re.match(r"\\.", '\\"')) == '"'
    assert escape(re.match(r"\\.", "\\\\")) == "\\"

    for c, e in simple_escapes.items():
        assert escape(re.match(r"\\.", "\\" + c)) == e

    for i in range(8):
        assert escape(re.match(r"\\\d{1,3}", "\\" + str(i))) == chr(i)
    assert escape(re.match(r"\\\d{1,3}", "\\8")) == "8"
    assert escape(re.match(r"\\\d{1,3}", "\\9")) == "9"