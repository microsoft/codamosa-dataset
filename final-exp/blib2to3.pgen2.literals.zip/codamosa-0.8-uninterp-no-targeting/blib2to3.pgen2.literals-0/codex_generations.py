

# Generated at 2022-06-21 10:10:42.822322
# Unit test for function evalString
def test_evalString():
    assert evalString("'''foo'''") == "foo"
    assert evalString("'foo'") == "foo"
    assert evalString('"foo"') == "foo"
    assert evalString("'foo") == "foo"
    assert evalString("'\\n'") == "\n"
    assert evalString("'''\\n'''") == "\n"
    assert evalString("'\\260'") == chr(0x260)
    assert evalString("'\\x260'") == chr(0x260)
    try:
        evalString("'\\x2'")
        assert False, "expected ValueError"
    except ValueError:
        pass
    try:
        evalString("'\\x1g'")
        assert False, "expected ValueError"
    except ValueError:
        pass

# Generated at 2022-06-21 10:10:43.487904
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:10:44.149102
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:10:56.274052
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"hey"') == "hey"
    assert evalString('"\\x00"') == "\x00"
    assert evalString('"\\x00\\x01"') == "\x00\x01"
    assert evalString('"\\x00\\x01\\x02"') == "\x00\x01\x02"
    assert evalString("'hey'") == "hey"
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\x00\\x01'") == "\x00\x01"
    assert evalString("'\\x00\\x01\\x02'") == "\x00\x01\x02"

# Generated at 2022-06-21 10:10:56.946413
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:01.239373
# Unit test for function escape
def test_escape():
    s = r"And\x20now\x3Afor\x20something\x20\x66ully\x20\x64ifferent"
    assert s == escape(re.match(r"\\x(.{2})", s))

# Generated at 2022-06-21 10:11:04.220726
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x0A", "\\x0A")) == "\n"
    assert escape(re.match(r"\\x0", "\\x0")) == "\\x0"

# Generated at 2022-06-21 10:11:11.764250
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\t"') == "\t"
    assert evalString("'''\\t'''") == "\t"
    assert evalString("'''\\'''") == "'"
    assert evalString("'''\\'\"'") == "'\""
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\\\\\'\\\"'") == "\a\b\f\n\r\t\v\\'\""
    assert evalString("'\\000'") == "\0"
    assert evalString("'\\001'") == "\1"
    assert evalString("'\\177'") == "\177"
    assert evalString("'\\200'") == "\200"
    assert evalString("'\\377'") == "\377"

# Generated at 2022-06-21 10:11:20.186561
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\11\\12\\13"') == "\t\n\r"
    assert evalString("'\\11\\12\\13'") == "\t\n\r"

    assert evalString("'\\x0A'") == "\n"
    assert evalString('"\\x0A"') == "\n"
    assert evalString('"\\x0a"') == "\n"

    assert evalString("'\\11'") == "\t"
    assert evalString('"\\11"') == "\t"

    assert evalString("'\\377'") == "\xff"
    assert evalString('"\\377"') == "\xff"

    assert evalString("'\\1111'") == "\t\t"
    assert evalString('"\\1111"') == "\t\t"

# Generated at 2022-06-21 10:11:30.873154
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'\\''") == "'"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x07'") == "\x07"
    assert evalString("'\\x7F'") == "\x7F"
    assert evalString("'\\u0061'") == "a"
    assert evalString("'\\uffff'") == "\uffff"
    assert evalString("'\\U00010000'") == "\U00010000"
    assert evalString("'\\U0010ffff'") == "\U0010ffff"
    assert evalString("'\\Uffffffff'") == "\ufffd\ufffd\ufffd\ufffd"

# Generated at 2022-06-21 10:12:05.859251
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\"') == '"'
    assert escape("\\'") == "'"
    assert escape('\\\\') == '\\'
    assert escape('\\x41') == 'A'
    assert escape('\\x00') == '\x00'
    assert escape('\\x7f') == '\x7f'
    assert escape('\\x80') == '\x80'
    assert escape('\\xff') == '\xff'

# Generated at 2022-06-21 10:12:06.597850
# Unit test for function test
def test_test():
    test() # type: ignore

# Generated at 2022-06-21 10:12:18.410983
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc\\ndef"') == 'abc\ndef'
    assert evalString('"abc\\ndef"') == 'abc\ndef'
    assert evalString('r"abc\\ndef"') == r'abc\ndef'
    assert evalString('r"abc\\ndef"') == r'abc\ndef'
    assert evalString('u"abc\\ndef"') == 'abc\ndef'
    assert evalString('u"abc\\ndef"') == 'abc\ndef'
    assert evalString('ur"abc\\ndef"') == r'abc\ndef'
    assert evalString('ur"abc\\ndef"') == r'abc\ndef'
   

# Generated at 2022-06-21 10:12:30.697518
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"a\a\b\f\n\r\t\v\047\042\134\x61\x62\x63\001\002\xEg\170"') == "a\a\b\f\n\r\t\v'\"\\abc\x01\x02\x0eg\x7a"
    assert evalString(r'"""a\a\b\f\n\r\t\v\047\042\134\x61\x62\x63\001\002\xEg\170"""') == "\na\a\b\f\n\r\t\v'\"\\abc\x01\x02\x0eg\x7a\n"

# Generated at 2022-06-21 10:12:36.454600
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\x01', r'\x01')) == chr(1)
    assert escape(re.match(r'\\001', r'\001')) == chr(1)
    assert escape(re.match(r'\\[]', '\\n')) == '\n'

# Generated at 2022-06-21 10:12:45.171209
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc\\n"') == 'abc\n'
    assert evalString('"abc\\n\\n"') == 'abc\n\n'
    assert evalString('"abc\\n\\n"') == 'abc\n\n'
    assert evalString('"abc\\n"') == 'abc\n'
    assert evalString('"abc\\n"') == 'abc\n'
    assert evalString('"abc\\n  "') == 'abc\n  '
    assert evalString('"abc\\n  "') == 'abc\n  '
    assert evalString('"abc\\n  "') == 'abc\n  '
    assert evalString('"abc\\n  "') == 'abc\n  '
    assert evalString('"abc\\n  "') == 'abc\n  '
   

# Generated at 2022-06-21 10:12:56.280854
# Unit test for function evalString
def test_evalString():
    # Tests for correct evaluation of simple strings
    assert evalString(r"'abc'") == 'abc'
    assert evalString(r'"abc"') == 'abc'
    assert evalString(r"'\''") == "'"
    assert evalString(r'"\""') == '"'
    assert evalString(r"'""'") == '"'
    assert evalString(r'"\'\'"') == "'"
    assert evalString(r"'x'") == 'x'
    assert evalString(r'"x"') == 'x'

    # Tests for correct evaluation of escaped characters
    assert evalString(r"'" + r"'\a\b\f\n\r\t\v\\\'\"'") == "\a\b\f\n\r\t\v\\\'\""

# Generated at 2022-06-21 10:13:07.942901
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString('"abc\\ndef"') == "abc\ndef"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\'\\\"\\\\'") == "\a\b\f\n\r\t\v\'\"\\"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\"') == "\a\b\f\n\r\t\v\'\"\\"
    assert evalString("'\\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString('"\\\'"') == "'"
    assert evalString("'\\'") == "'"
    assert eval

# Generated at 2022-06-21 10:13:15.923578
# Unit test for function evalString

# Generated at 2022-06-21 10:13:27.463819
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == "foo"
    assert evalString(r"'foo\nbar'") == "foo\nbar"
    assert evalString(r"'\"\'\"'") == "\"\'\""
    assert evalString(r"'\x00\x01\x02\x03\x04\x05\x06\x07'") == "\x00\x01\x02\x03\x04\x05\x06\x07"
    assert evalString(r"'\x0e\x0f\x10\x11\x12\x13\x14\x15'") == "\x0e\x0f\x10\x11\x12\x13\x14\x15"

# Generated at 2022-06-21 10:13:51.735342
# Unit test for function test
def test_test():
    from io import StringIO
    from unittest import mock

    # store stdout, so we can restore it later
    stdout = StringIO()
    backup = sys.stdout

# Generated at 2022-06-21 10:13:52.340547
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:01.000778
# Unit test for function evalString
def test_evalString():
    # Tests for function evalString
    assert evalString('""') == ""
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\' + "'" + '\\"' + '\\' + '\\\\"') == "\a\b\f\n\r\t\v'" + '"' + "\\"
    assert evalString('"\\111\\222\\333\\444\\555\\666\\777"') == "\111\222\333\444\555\666\777"
    assert evalString('"\\x01\\x10\\xff"') == "\x01\x10\xff"
    assert evalString('"a\\\nb"') == "a\nb"

# Generated at 2022-06-21 10:14:12.558656
# Unit test for function escape
def test_escape():
    t = {
        "alice": "\\alice",
        "\\alice": "\\alice",
        "bob": "\\bob",
        "\\bob": "\\bob",
        "charlie": "\\charlie",
        "\\charlie": "\\charlie",
        "dave": "\\dave",
        "\\dave": "\\dave",
        "edith": "\\edith",
        "\\edith": "\\edith",
        "fred": "\\fred",
        "\\fred": "\\fred",
        "george": "\\george",
        "\\george": "\\george",
    }
    for s in t:
        assert not escape(re.match(r"^\\(.*)$", s))

# Generated at 2022-06-21 10:14:22.671880
# Unit test for function evalString
def test_evalString():

    def test(s, expected, expected_type):
        print("Testing %s" % repr(s))
        v = evalString(s)
        print("   v == %s" % repr(v))
        assert v == expected, "evalString(%s) should return %s, not %s" % (
            repr(s),
            repr(expected),
            repr(v),
        )
        assert isinstance(v, expected_type), "evalString(%s) should return %s, not %s" % (
            repr(s),
            expected_type,
            type(v),
        )

    test('""', "", str)
    test(
        '""',
        b"",
        bytes,
    )  # the function is already called with bytes, so this is a no-op

# Generated at 2022-06-21 10:14:33.642017
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\x3A", r"\x3A")) == ":"
    assert escape(re.search(r"\\113", r"\113")) == "K"
    assert escape(re.search(r"\\a", r"\a")) == "\a"
    assert escape(re.search(r"\\b", r"\b")) == "\b"
    assert escape(re.search(r"\\f", r"\f")) == "\f"
    assert escape(re.search(r"\\n", r"\n")) == "\n"
    assert escape(re.search(r"\\r", r"\r")) == "\r"
    assert escape(re.search(r"\\t", r"\t")) == "\t"

# Generated at 2022-06-21 10:14:35.280201
# Unit test for function test
def test_test():
    """Function test, which tests function evalString."""

    test()

# Generated at 2022-06-21 10:14:42.298204
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == 'foo'
    assert evalString('"foo"') == 'foo'
    assert evalString('"foo\"bar"') == 'foo"bar'
    assert evalString("'foo'") == 'foo'
    assert evalString("'foo\'bar'") == 'foo\'bar'
    assert evalString('"foo\nbar"') == "foo\nbar"
    assert evalString('"foo\nbar"') == "foo\nbar"
    assert evalString("'foo\\nbar'") == "foo\nbar"
    assert evalString("'foo\\\'bar'") == "foo'bar"
    assert evalString("'foo\\" + "'" + "bar'") == 'foo"bar'

# Generated at 2022-06-21 10:14:47.618387
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'\\'abc'") == "'abc"
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\t\\xe9\\x95'") == "\t\xe9\x95"

# Generated at 2022-06-21 10:14:48.251065
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:12.284469
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:22.612798
# Unit test for function test
def test_test():
    import io
    import sys
    import unittest
    import unittest.mock

    f = io.StringIO()
    with unittest.mock.patch("sys.stdout", new=f):
        test()
    assert f.getvalue() == ""

    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'a\\'b\\'c'") == "a'b'c"
    assert evalString('"a\\"b\\"c"') == 'a"b"c'
    assert evalString("'a\\bc'") == "abc"

# Generated at 2022-06-21 10:15:23.582452
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-21 10:15:25.838999
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello'") == "hello"
    assert evalString('"hello"') == "hello"
    assert evalString("'\\x41pple'") == "Apple"
    assert evalString("'\\u41pple'") == "u41pple"
    assert evalString("'\\U41pple'") == "U41pple"

# Generated at 2022-06-21 10:15:35.226457
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\n")) == '\n'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\r")) == '\r'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\t")) == '\t'

# Generated at 2022-06-21 10:15:47.410276
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString('""') == ""
    assert evalString("'a'") == "a"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\''") == "'"
    assert evalString('\'\\"\'') == '"'
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\0'") == "\0"
    assert eval

# Generated at 2022-06-21 10:15:57.575527
# Unit test for function evalString
def test_evalString():

    def get():
        x = 1
        while x < 20:
            if x % 2 == 0:
                yield x
            x += 1

    assert evalString("'evalString'") == "evalString"
    assert evalString('"%s"' % "evalString") == "evalString"
    assert evalString("'%r'" % "evalString") == "'evalString'"
    assert evalString("'%s'" % "eval'String") == "eval'String"
    assert evalString('"%s"' % "eval'String") == "eval'String"
    assert evalString("'%s'" % "eval\"String") == "eval\"String"
    assert evalString('"%s"' % "eval\"String") == "eval\"String"
    assert evalString("'eval\\'String'") == "eval'String"
   

# Generated at 2022-06-21 10:16:01.321779
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(.+)", '\\a')
    assert m.group(0) == '\\a'
    assert m.group(1) == 'a'
    assert escape(m) == '\a'



# Generated at 2022-06-21 10:16:10.285554
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x41"') == 'A'
    assert evalString("'\\x41'") == 'A'
    assert evalString('"\\102"') == 'B'
    assert evalString("'\\102'") == 'B'
    assert evalString('"\\x09"') == '\t'
    assert evalString("'\\x09'") == '\t'
    assert evalString('"\\a"') == '\a'
    assert evalString("'\\a'") == '\a'

# Generated at 2022-06-21 10:16:10.613124
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:00.249097
# Unit test for function test
def test_test():
    test()
    # Verify that a NUL character cannot occur in the result
    try:
        evalString("'hello\\0world'")
    except ValueError:
        pass
    else:
        assert False, "evalString() should not accept NUL character"

# Generated at 2022-06-21 10:17:07.729093
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x80", "\\x80")) == chr(128)
    assert escape(re.match(r"\\\x80", "\\\x80")) == chr(128)
    assert escape(re.match(r"\\376", "\\376")) == chr(254)
    assert escape(re.match(r"\\255", "\\255")) == chr(1 * 8 ** 2 + 7 * 8 + 5)
    assert escape(re.match(r"\\\255", "\\\255")) == chr(1 * 8 ** 2 + 5 * 8 + 5)
    assert escape(re.match(r"\\\05", "\\\05")) == chr(5)

# Generated at 2022-06-21 10:17:17.471167
# Unit test for function escape

# Generated at 2022-06-21 10:17:25.432294
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\x10b'") == "\x10b"
    assert evalString("'\\x10b\\123'") == "\x10b\123"
    assert evalString("'\\n\\0\\n'") == "\n\0\n"

# Generated at 2022-06-21 10:17:26.029290
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:27.293633
# Unit test for function escape
def test_escape():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 10:17:38.903309
# Unit test for function escape
def test_escape():
    import unittest

    class Test_escape(unittest.TestCase):
        def test_b(self):
            self.assertEqual(escape('\b'), '\b')

        def test_f(self):
            self.assertEqual(escape('\f'), '\f')

        def test_n(self):
            self.assertEqual(escape('\n'), '\n')

        def test_r(self):
            self.assertEqual(escape('\r'), '\r')

        def test_t(self):
            self.assertEqual(escape('\t'), '\t')

        def test_v(self):
            self.assertEqual(escape('\v'), '\v')


# Generated at 2022-06-21 10:17:39.699709
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:44.172501
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\\"') == "\\"
    assert evalString(r"'" + chr(0) + "'") == chr(0)
    assert evalString(r"'\xff'") == chr(0xff)
    assert evalString(r'"\0"') == "\x00"

# Generated at 2022-06-21 10:17:54.473610
# Unit test for function evalString
def test_evalString():
    tests = {
        "": "",
        "'\\n'": "\n",
        "'\\\\\\''": "\\'",
        '"\\"\\""': '""',
        # Invalid string literals.
        "'\\z'": "\\z",
        "'\\x1'": "\\x1",
        "'\\08'": "\\08",
        "'\\x0'": "\\x0",
        "'\\x1z'": "\\x1z",
        "'\\181'": "\\181",
        "'\\077'": "\\077",
    }
    for string, exp in tests.items():
        result = evalString(string)
        assert result == exp, "%s should be %s, not %s" % (string, exp, result)

# Generated at 2022-06-21 10:19:30.822126
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:19:38.642138
# Unit test for function evalString
def test_evalString():
    print("hello")
    assert evalString("'Hello, World!'") == "Hello, World!"
    assert evalString('"Hello, World!"') == "Hello, World!"
    # TODO: assert evalString("'''Hello, World!'''") == "Hello, World!"
    assert evalString("r'Hello, World!'") == "Hello, World!"
    assert evalString("'''Hello, \nWorld!'''") == "Hello, \nWorld!"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\'\\\"\\\\'") == "\a\b\f\n\r\t\v\'\"\\"

# Generated at 2022-06-21 10:19:47.272631
# Unit test for function escape
def test_escape():
    tests = [
        ('\a', "a"), ('\b', "b"), ('\f', "f"), ('\n', "n"), ('\r', "r"), ('\t', "t"), ('\v', "v"),
        ('\'', "'"), ('"', '"'), ('\\', "\\"), ('\x00', "x00"), ('\x11', "x11"), ('\xff', "xff")
    ]

    for input, expected in tests:
        m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", input)
        assert m is not None
        assert escape(m) == expected

# Generated at 2022-06-21 10:19:48.506490
# Unit test for function test
def test_test():
    try:
        test()
    except:
        pass

# Generated at 2022-06-21 10:19:49.145009
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:19:58.996876
# Unit test for function escape
def test_escape():
    import sys
    import os
    import unittest
    import test.support

    # Return regular expression for escape or raise ValueError if error.

    def make_re(expect: Text) -> re.Pattern[Text]:
        return re.compile(r"\\x5c(.)")

    def bad_escape(e: Text) -> None:
        assert make_re(e)

    def good_escape(e: Text, expect: Text) -> None:
        mobj = make_re(e)
        assert mobj.match(r"\%s" % e).group(1) == expect

    # Characters 0 through 7 fail (\x is not allowed)

    bad_escape(r"%o" % 0)
    bad_escape(r"%o" % 1)

# Generated at 2022-06-21 10:20:00.225478
# Unit test for function test
def test_test():
    try:
        test()
    except:
        raise AssertionError("test failed")

# Generated at 2022-06-21 10:20:03.878312
# Unit test for function evalString
def test_evalString():
    S = '"\\n\\r\\U00010000\\U00110000"'