

# Generated at 2022-06-21 10:10:34.449143
# Unit test for function evalString
def test_evalString():
    from .pytree import Leaf

    def t(s, result):
        assert evalString(Leaf(1, s)) == result

    t('"abc"', "abc")
    t("'abc'", "abc")
    t('"\\a\\b\\f\\n\\r\\t\\v\\"\\\'\\\\"', "\a\b\f\n\r\t\v\"\'\\")
    t("'\\a\\b\\f\\n\\r\\t\\v\\\"\\\'\\\\'", "\a\b\f\n\r\t\v\"\'\\")
    t('"\\x41BC"', "ABC")
    t('"\\0\\41\\101"', "\x00A\x41")

# Generated at 2022-06-21 10:10:45.774309
# Unit test for function evalString
def test_evalString():
    try:
        evalString("'''")
        assert False
    except ValueError:
        assert True

    try:
        evalString("'foo")
        assert False
    except ValueError:
        assert True

    try:
        evalString("'foo\x01'")
        assert False
    except ValueError:
        assert True

    try:
        evalString('"foo\nbar"')
        assert False
    except ValueError:
        assert True

    try:
        evalString("'foo\\x1")
        assert False
    except ValueError:
        assert True

    assert evalString("''") == ""
    assert evalString("'a'") == "a"
    assert evalString('"b"') == "b"
    assert evalString("'\\a'") == "\x07"
    assert evalString

# Generated at 2022-06-21 10:10:56.228373
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"spam"') == "spam"
    assert evalString("'spam'") == "spam"
    assert evalString("'a\\\'b'") == "a'b"
    assert evalString('"a\\\"b"') == 'a"b'
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"

# Generated at 2022-06-21 10:11:06.807172
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r"\\x78", r"\x78")) == "x"
    assert escape(re.match(r"\\x08", r"\x08")) == "\x08"
    assert escape(re.match(r"\\08", r"\08")) == "\x08"
    assert escape(re.match(r"\\1", r"\1")) == "\x01"
    assert escape(re.match(r"\\F", r"\F")) == "\x0c"
    assert escape(re.match(r"\\a", r"\a")) == "\x07"
    assert escape(re.match(r"\\b", r"\b")) == "\x08"

# Generated at 2022-06-21 10:11:07.761061
# Unit test for function test
def test_test():
    # check that test runs without raising exceptions
    test()

# Generated at 2022-06-21 10:11:18.470321
# Unit test for function evalString
def test_evalString():
    s = "'''hi there'''"
    assert evalString(s) == "hi there"
    s = '""hi there""'
    assert evalString(s) == "hi there"
    s = "''''hi there''''"
    assert evalString(s) == "'hi there'"
    s = '""""hi there""""'
    assert evalString(s) == '"hi there"'
    s = "'\\n'"
    assert evalString(s) == "\n"
    s = "'\\'"
    assert evalString(s) == "\\"
    s = "'\\x61bc'"
    assert evalString(s) == "abc"
    s = "'\\xabcd'"
    assert evalString(s) == "\xabcd"
    s = "'\\067'"

# Generated at 2022-06-21 10:11:30.156736
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello world'") == 'hello world'
    assert evalString("'\\'hello world\\''") == "'hello world'"
    assert evalString("'\\'hello") == "'hello"

    assert evalString('"hello world"') == 'hello world'
    assert evalString('"\\"hello world\\""') == '"hello world"'
    assert evalString('"\\"hello') == '"hello'

    assert evalString("'hello\\tworld'") == 'hello\tworld'
    assert evalString("'hello\\nworld'") == 'hello\nworld'

    assert evalString("'\\x7f'") == ""
    assert evalString("'\\xff'") == "ÿ"

    assert evalString("'\\377'") == "ÿ"

# Generated at 2022-06-21 10:11:42.300673
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\\([^0-7xu])', '\\a')) == '\a'
    assert escape(re.match('\\\\([^0-7xu])', '\\b')) == '\b'
    assert escape(re.match('\\\\([^0-7xu])', '\\f')) == '\f'
    assert escape(re.match('\\\\([^0-7xu])', '\\n')) == '\n'
    assert escape(re.match('\\\\([^0-7xu])', '\\r')) == '\r'
    assert escape(re.match('\\\\([^0-7xu])', '\\t')) == '\t'

# Generated at 2022-06-21 10:11:44.625153
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x05", r"\\x05")) == "\x05"

# Generated at 2022-06-21 10:11:55.469396
# Unit test for function escape
def test_escape():
    import io
    import tokenize
    from unittest import TestCase

    class TestEscape(TestCase):

        def test_escape(self):
            code = "evalString('\\\\', '\\\\')"
            f = io.StringIO(code)
            tokens = list(tokenize.generate_tokens(f.readline))
            self.assertEqual(tokens[1][1], "\\")
            self.assertEqual(tokens[2][1], ",")
            self.assertEqual(tokens[3][1], " ")
            self.assertEqual(tokens[4][1], "'\\\\'")
            self.assertEqual(tokens[5][1], ",")
            self.assertEqual(tokens[6][1], " ")
           

# Generated at 2022-06-21 10:12:19.588518
# Unit test for function evalString

# Generated at 2022-06-21 10:12:31.348802
# Unit test for function escape
def test_escape():
    assert escape('\\\n') == '\n'
    assert escape(r'\\\n') == '\\\n'
    assert escape('\\') == '\\'
    assert escape('\\\\') == '\\'
    assert escape('"') == '"'
    assert escape("\\\"") == '"'
    assert evalString("'\\\n'") == '\\\n'
    assert evalString("'\\\\\n'") == '\\\n'
    assert evalString("'\\'") == '\\'
    assert evalString('"\\\n"') == '\\\n'
    assert evalString('"\\\\\n"') == '\\\n'
    assert evalString('"\\"') == '\\'
    assert evalString("'abc'") == 'abc'
    assert evalString("'\\x20'")

# Generated at 2022-06-21 10:12:34.592472
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\((\')|(\"))", r"\'")).group(1) == "\'"

# Generated at 2022-06-21 10:12:36.313639
# Unit test for function test
def test_test():
    # we do not need to test anything here because this function only prints
    # and we are not going to read the output
    pass

# Generated at 2022-06-21 10:12:44.681023
# Unit test for function escape
def test_escape():
    # double quotes should work within single quotes and vice versa
    assert escape("'\\''") == "'"
    assert escape('"\\""') == '"'
    # hex values of 4 digits should work
    assert escape("xffff") == "\uffff"
    # hex values of more than 4 digits should fail
    try:
        escape("xffffffff")
        raise AssertionError("Failed to raise expected ValueError")
    except ValueError:
        pass
    # 7 octal digits should work
    assert escape("\\3777777") == "\uffff"
    # 8 octal digits should fail
    try:
        escape("\\37777777")
        raise AssertionError("Failed to raise expected ValueError")
    except ValueError:
        pass

# Generated at 2022-06-21 10:12:52.661785
# Unit test for function escape
def test_escape():
    from unittest.mock import patch
    from io import StringIO
    import sys

    test_values = [
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\x41", "A"),
        ("\\xAA", "ª"),
        ("\\xBB", "»"),
    ]

    with patch.object(sys, "stdout", new_callable=StringIO) as mock_stdout:
        for (string, expected) in test_values:
            output = escape(string)
            assert output == expected


test_escape()

# Generated at 2022-06-21 10:13:04.885904
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello'") == "hello"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\\''") == "'"

# Generated at 2022-06-21 10:13:11.638539
# Unit test for function escape
def test_escape():
    # Make sure function raises ValueError for invalid octal string escape
    from unittest import TestCase

    class T(TestCase):
        def test_octal(self):
            with self.assertRaises(ValueError):
                escape(re.search('\\\\8', '\\8'))

            with self.assertRaises(ValueError):
                escape(re.search('\\\\27', '\\27'))

            with self.assertRaises(ValueError):
                escape(re.search('\\\\271', '\\271'))

    T().test_octal()

# Generated at 2022-06-21 10:13:23.339546
# Unit test for function evalString
def test_evalString():
    from .evalString import evalString
    assert evalString("'abc'") == "abc"
    assert evalString(r'"\"c\\a\nb"') == r'"c\a\nb'
    assert evalString(r'"one\"two\three"') == r'"one"two\three'
    assert evalString('"0\\x1\\x2\\x3\\x4\\x5\\x6\\x7"') == "\x00\x01\x02\x03\x04\x05\x06\x07"
    assert evalString('"\\0\\1\\2\\3\\4\\5\\6\\7"') == "\x00\x01\x02\x03\x04\x05\x06\x07"

# Generated at 2022-06-21 10:13:24.134799
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:39.037396
# Unit test for function evalString
def test_evalString():
    s = evalString(r'"\\x33"')
    assert s == r'\x33'

    s = evalString("'\\x33'")
    assert s == r'\x33'

# Generated at 2022-06-21 10:13:51.893833
# Unit test for function escape
def test_escape():
    """Simple smoke test for evalString's escape() function, which uses
    regular expressions to parse python string escapes (eg. \n, \x41)
    """

    # Simple escapes
    assert escape(re.match('\\a', '\\a')) == '\a'
    assert escape(re.match('\\b', '\\b')) == '\x08'
    assert escape(re.match('\\f', '\\f')) == '\x0c'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'

# Generated at 2022-06-21 10:13:52.514754
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:01.085102
# Unit test for function escape
def test_escape():
  assert escape(re.match(r'\\[abfnrtv]', '\\t')) == '\t'
  assert escape(re.match(r'\\[abfnrtv]', '\\n')) == '\n'
  assert escape(re.match(r'\\[abfnrtv]', '\\r')) == '\r'
  assert escape(re.match(r'\\[abfnrtv]', '\\a')) == '\a'
  assert escape(re.match(r'\\[abfnrtv]', '\\b')) == '\b'
  assert escape(re.match(r'\\[abfnrtv]', '\\v')) == '\v'

# Generated at 2022-06-21 10:14:01.871352
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:02.633550
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:13.491748
# Unit test for function escape
def test_escape():
    test = re.compile(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})").match

    assert escape(test("\\a")) == "\x07"
    assert escape(test("\\b")) == "\x08"
    assert escape(test("\\f")) == "\x0c"
    assert escape(test("\\n")) == "\n"
    assert escape(test("\\r")) == "\r"
    assert escape(test("\\t")) == "\t"
    assert escape(test("\\v")) == "\x0b"
    assert escape(test("\\'")) == "'"
    assert escape(test('\\"')) == '"'
    assert escape(test("\\\\")) == "\\"

    assert escape(test("\\x07"))

# Generated at 2022-06-21 10:14:24.268298
# Unit test for function evalString

# Generated at 2022-06-21 10:14:35.278615
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"(\\['\"\\abfnrtv]|\\x.{0,2}|\\[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"(\\['\"\\abfnrtv]|\\x.{0,2}|\\[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"(\\['\"\\abfnrtv]|\\x.{0,2}|\\[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"(\\['\"\\abfnrtv]|\\x.{0,2}|\\[0-7]{1,3})", r"\n"))

# Generated at 2022-06-21 10:14:37.282503
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\x0a"') == "\n"
    assert evalString('"\\012"') == "\n"



# Generated at 2022-06-21 10:14:54.363528
# Unit test for function escape
def test_escape():

    assert escape(re.match(r'\\x123', '\\x123')) == '\\x123'
    assert escape(re.match(r'\\x123', '\\x123')) == '\\x123'
    assert escape(re.match(r'\\x12', '\\x12')) == '\\x12'
    assert escape(re.match(r'\\x12', '\\x12')) == '\\x12'
    assert escape(re.match(r'\\x1', '\\x1')) == '\\x1'
    assert escape(re.match(r'\\x1', '\\x1')) == '\\x1'
    assert escape(re.match(r'\\x', '\\x')) == '\\x'

# Generated at 2022-06-21 10:14:55.198502
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:03.396144
# Unit test for function escape
def test_escape():
    for m in (
        "\\a",
        "\\b",
        "\\f",
        "\\n",
        "\\r",
        "\\t",
        "\\v",
        "\\'",
        '\\"',
        "\\\\",
        "\\x41",
        "\\x00",
        "\\007",
        "\\0",
        "\\077",
        "\\0077",
        "\\x1f",
        "\\x1ff",
    ):
        result = escape(re.match("^\\\\.{1,3}", m))
        assert m == repr(result), f"{m!r} != {result!r}"


# Generated at 2022-06-21 10:15:03.971780
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:16.328816
# Unit test for function escape
def test_escape():  # D402
    from unittest import TestCase


# Generated at 2022-06-21 10:15:25.509642
# Unit test for function evalString
def test_evalString():
    assert evalString("'Hello World'") == "Hello World"
    assert evalString('"Hello World"') == "Hello World"
    assert evalString('"\nHello World"') == "\nHello World"
    assert evalString('"\\nHello World"') == "\\nHello World"
    assert evalString('r"Hello World"') == "Hello World"
    assert evalString('r"\nHello World"') == "\\nHello World"
    assert evalString('r"\\nHello World"') == "\\\\nHello World"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\0"') == "\x00"
    assert evalString('"\\x1f"') == "\x1f"
    assert evalString('"\\x7f"') == "\x7f"


# Generated at 2022-06-21 10:15:34.252748
# Unit test for function evalString
def test_evalString():
    tests = [
        (r'"\'"', "'"),
        (r'"\""', '"'),
        (r'"\\"', "\\"),
        (r'"\a\b\f\n\r\t\v"', "\a\b\f\n\r\t\v"),
        (r'"\011\011"', "\011\011"),
        (r'"\011\011"', "\011\011"),
        (r'"\x61\x62\x63"', "abc"),
        (r'"\u1234\U00010111"', "\u1234\U00010111"),
    ]
    for s, result in tests:
        assert evalString(s) == result

# Generated at 2022-06-21 10:15:45.908599
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\\x?28', '\\x28')) == '('
    assert escape(re.match('\\\\x?28', '\\x2x')) == '\\x2x'
    assert escape(re.match('\\\\x?28', '\\x2')) == '\\x2'
    assert escape(re.match('\\\\x?28', '\\x')) == '\\x'
    # Unit test for function evalString
    assert evalString("'abcde'") == 'abcde'
    assert evalString("'a\\'bcd\\'e'") == "a'bcd'e"
    assert evalString('"abcde"') == 'abcde'
    assert evalString('"a\\"bcd\\"e"') == 'a"bcd"e'

# Generated at 2022-06-21 10:15:47.070191
# Unit test for function evalString

# Generated at 2022-06-21 10:15:57.288201
# Unit test for function evalString
def test_evalString():
    assert evalString('\'asdf\'') == 'asdf'
    assert evalString('"asdf"') == 'asdf'
    assert evalString('\'\\\'\'') == '\''
    assert evalString('\'\\\'\\\'\'') == '\''
    assert evalString('"\\""') == '"'
    assert evalString('"\\"\\""') == '"'
    assert evalString('"foo\\tbar"') == 'foo\tbar'
    assert evalString('"foo\\x09bar"') == 'foo\tbar'
    assert evalString('"foo\\x09"') == 'foo\t'
    assert evalString('"foo\\011"') == 'foo\t'
    assert evalString('"foo\\11"') == 'foo\t'

# Generated at 2022-06-21 10:16:23.446132
# Unit test for function escape
def test_escape():
    assert escape(Match(r"\x41", "41")).encode() == b'A'
    assert escape(Match(r"\123", "123")).encode() == b'S'
    print("test_escape() passed!")

# Generated at 2022-06-21 10:16:28.287816
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\s", r"\s")) == " "
    assert escape(re.search(r"\\x20", r"\x20")) == " "
    assert escape(re.search(r"\\042", r"\042")) == "\""



# Generated at 2022-06-21 10:16:36.111707
# Unit test for function evalString
def test_evalString():
    string = '"String with single-quoted string \' inside double-quoted" string'

# Generated at 2022-06-21 10:16:36.926405
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:16:49.541618
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'abc'") == "abc"
    assert evalString(r'"abc"') == "abc"
    assert evalString(r"'\"'") == '"'
    assert evalString(r'"\'\""') == '\'"'
    assert evalString(r"'\a\b\f\n\r\t\v\\\"\''") == "\a\b\f\n\r\t\v\\\"'"
    assert evalString(r"'\111'") == chr(73)
    assert evalString(r"'\111\122'") == chr(73) + chr(82)
    assert evalString(r"'\x61c'") == "ac"
    assert evalString(r"'\x61\x63'") == "ac"
    assert evalString(r"'\700'")

# Generated at 2022-06-21 10:16:58.739773
# Unit test for function escape
def test_escape():
    import unittest
    class TestEscape(unittest.TestCase):
        def test_escape(self):
            self.assertEqual(escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\n')), '\n')
            self.assertEqual(escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\xad')), '\xad')
            self.assertEqual(escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\222')), '\222')

# Generated at 2022-06-21 10:17:00.161428
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert False, "Unexpected exception raised"

# Generated at 2022-06-21 10:17:08.358740
# Unit test for function evalString
def test_evalString():

    # Describe the expected, received, and comparison value
    expected, received, comparison = '', '', ''

    # Should be able to evaluate single quote string
    expected = 'single quote'
    received = evalString("'single quote'")
    comparison = expected == received
    assert comparison, 'test_1 failed'

    # Should be able to evaluate double quote string
    expected = 'double quote'
    received = evalString('"double quote"')
    comparison = expected == received
    assert comparison, 'test_2 failed'

    # Should be able to evaluate a string with escape sequences
    expected = 'I am a \n string'
    received = evalString('"I am a \\n string"')
    comparison = expected == received
    assert comparison, 'test_3 failed'

    # Should be able to evaluate a string with escape sequences 2
    expected

# Generated at 2022-06-21 10:17:17.780296
# Unit test for function escape
def test_escape():
    # Please note that the match objects are being used in a different way
    # so we need to fake that for the tests
    def _replace(match):
        return escape(match)

    assert _replace(re.match(r"\\([0-7]{1,3})", "\\000")) == chr(0)
    assert _replace(re.match(r"\\([0-7]{1,3})", "\\377")) == chr(255)
    assert _replace(re.match(r"\\([0-7]{1,3})", "\\377")) == chr(255)
    assert _replace(re.match(r"\\x(.{2})", "\\x00")) == chr(0)
    assert _replace(re.match(r"\\x(.{2})", "\\xff"))

# Generated at 2022-06-21 10:17:23.480598
# Unit test for function escape
def test_escape():
    assert r"\a\b\c\d\\\"" == escape(r"\a\b\c\d\\\"")
    assert "\a\b\c\d\\\"" == escape(r"\\a\\b\\c\\d\\\\\"")
    assert "ab" == escape(r"\x61\x62")

# Generated at 2022-06-21 10:18:10.647528
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:18:16.919851
# Unit test for function escape
def test_escape():
    escape_test_cases = [
        ('\\x41', 'A'),
        ('\\x005A', 'Z'),
        ('\\a', '\a'),
        ('\\b', '\b'),
        ('\\f', '\f'),
        ('\\n', '\n'),
        ('\\r', '\r'),
        ('\\t', '\t'),
        ('\\v', '\v'),
        ('\\x', 'x'),
        ('\\0', '\x00'),
        ('\\5', '\x05'),
        ('\\10', '\x08'),
        ('\\042', '"'),
        ('\\' + '\\', '\\'),
        ('\\x0', 'x0'),
        ('\\125', 'U'),
        ('\\x125', 'x125'),
    ]
   

# Generated at 2022-06-21 10:18:28.561427
# Unit test for function evalString
def test_evalString():
    print(evalString(r"'Hi there'"))
    print(evalString(r'"Hi there"'))
    print(evalString(r"'''Hi there'"))
    print(evalString(r'"Hi\" there"'))
    print(evalString(r'"Hi\' there"'))
    print(evalString(r"'Hi\n there'"))
    print(evalString(r"'Hi\b there'"))
    print(evalString(r"'Hi\f there'"))
    print(evalString(r"'Hi\t there'"))
    print(evalString(r"'Hi\r there'"))
    print(evalString(r"'Hi\v there'"))
    print(evalString(r"'Hi\a there'"))
    print(evalString(r"'Hi\001 there'"))

# Generated at 2022-06-21 10:18:36.429749
# Unit test for function escape
def test_escape():
    """Test function escape.

    Function escape should return a byte string. In the byte string,
    the first two bytes are the backslash character, followed by
    the byte representing the remaining tail of the current match.
    """
    # The regex engine used in re.sub() below matches and replaces
    # one character at a time, so any other backslash characters
    # are not considered when evaluating the escape string.
    input_string = b"v\n\ta\t\nb\\f\\\\n\t\\v\t\\\x11"
    expected_output = b"v\n\ta\t\nb\\f\\\\n\t\\v\t\\\x11"


# Generated at 2022-06-21 10:18:37.417246
# Unit test for function test
def test_test():
    # Basic test
    test()



# Generated at 2022-06-21 10:18:47.704585
# Unit test for function evalString
def test_evalString():
    assert(evalString("'Hello, world!'") == "Hello, world!")
    assert(evalString("'\\u1234'") == '\u1234')
    assert(evalString("'''Hello, world!\\n'") == "Hello, world!\n")
    assert(evalString("'\\\\'") == "\\")
    assert(evalString("b'\\\\'") == "\\")
    assert(evalString("'\\\\\\''") == "\\'")
    assert(evalString("'\\\\\\\"'") == '\\"')
    assert(evalString("'\\\\a'") == '\a')
    assert(evalString("'\\\\b'") == '\b')
    assert(evalString("'\\\\f'") == '\f')

# Generated at 2022-06-21 10:18:48.467042
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:18:58.930458
# Unit test for function escape
def test_escape():
    assert escape(r"\x01") == "\x01"

# Generated at 2022-06-21 10:19:06.595272
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\''") == "'"
    assert evalString("'\\r'") == "\r"
    assert evalString('"\\x12a"') == "\x12a"
    assert evalString('"\\141"') == "a"
    assert evalString('"\\u005cn"') == "\\n"
    assert evalString('"\\141"') == "a"
    assert evalString('"\\141"') == "a"

# Generated at 2022-06-21 10:19:11.675268
# Unit test for function test
def test_test():
    import io
    import sys
    import unittest
    from test.support import captured_stdout

    class Test(unittest.TestCase):
        def test_test(self):
            out = captured_stdout(test)
            self.assertEqual(out, "")

        if __name__ == "__main__":
            unittest.main()