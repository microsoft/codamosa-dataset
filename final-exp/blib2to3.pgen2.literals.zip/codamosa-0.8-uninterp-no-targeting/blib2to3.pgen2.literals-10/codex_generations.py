

# Generated at 2022-06-21 10:10:42.772835
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:10:55.221361
# Unit test for function evalString
def test_evalString():
    assert evalString('"ab"') == 'ab'
    assert evalString('"\\"\\t"') == '\t'
    assert evalString("'a\\x41b'") == 'aAb'
    assert evalString("'a\\141b'") == 'aAb'
    assert evalString("'a\\141\\142'") == 'aAb'
    assert evalString("'a\\0141b'") == 'aAb'
    assert evalString("'a\\0o141b'") == 'aAb'
    assert evalString("'a\\0x141b'") == 'aAb'
    raises (ValueError, evalString, "'a\\0x14x1b'")
    raises (ValueError, evalString, "'a\\0x1")
    raises (ValueError, evalString, "'a\\0")

# Generated at 2022-06-21 10:11:06.693249
# Unit test for function escape
def test_escape():
    escape_test_pairs = [
        ('\\a', '\a'),
        ('\\b', '\b'),
        ('\\f', '\f'),
        ('\\n', '\n'),
        ('\\r', '\r'),
        ('\\t', '\t'),
        ('\\v', '\v'),
        ('\\"', '"'),
        ("\\'", "'"),
        ("\\\\", "\\"),
        ("\\x41", "A"),
        ("\\xfc", "ü"),
        ("\\xE2\\x82\\xAC", "€"),
        ("\\071", "9"),
        ("\\079", "9"),
        ("\\184", "\x01"),
        ("\\x1A", "Z")
    ]


# Generated at 2022-06-21 10:11:07.985966
# Unit test for function test
def test_test():
    try:
        test()
    except NameError as e:
        print(e)

# Generated at 2022-06-21 10:11:17.791425
# Unit test for function escape
def test_escape():
    # Check that simple escapes are converted correctly

    for i in range(256):
        # Create octal string escape
        octal = "\\%03o"%i
        r = escape(re.match(r"\\(.*)",octal))
        assert ord(r) == i

        # Create decimal string escape
        decimal = "\\%d"%i
        r = escape(re.match(r"\\(.*)",decimal))
        assert ord(r) == i

        # Create hex string escape
        hexstring = "\\x%02x"%i
        r = escape(re.match(r"\\(.*)",hexstring))
        assert ord(r) == i


# Generated at 2022-06-21 10:11:29.146013
# Unit test for function escape
def test_escape():
    m = re.match(r"\\('|'|\|)|(.)", '\\')
    assert escape(m) == "\\"
    m = re.match(r"\\('|'|\|)|(.)", '"')
    assert escape(m) == '"'
    m = re.match(r"\\('|'|\|)|(.)", 'a')
    assert escape(m) == chr(7)
    m = re.match(r"\\('|'|\|)|(.)", 'x4')
    assert escape(m) == chr(4)
    m = re.match(r"\\('|'|\|)|(.)", 'x40')
    assert escape(m) == chr(64)


# Generated at 2022-06-21 10:11:41.368924
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == 'abc'
    assert evalString("'\\\\'") == '\\'
    assert evalString("'\\x7f'") == '\x7f'
    assert evalString("'\\77'") == '?'
    assert evalString("'\\17'") == '\x0f'
    assert evalString("'\\07'") == '\x07'
    assert evalString("'\\007'") == '\x07'
    assert evalString("'\\00017'") == '\x0f'
    assert evalString("'\\217'") == '\x0f'
    assert evalString("'\\" + "0" * 100 + "217'") == '\x0f'
    assert evalString('"abc"') == 'abc'

# Generated at 2022-06-21 10:11:44.913270
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"abc\x41"') == 'abcA'
    assert evalString(r'"abc\141"') == 'abcA'
    assert evalString(r"'abc\x41'") == 'abcA'
    assert evalString(r"'abc\141'") == 'abcA'

# Generated at 2022-06-21 10:11:46.865758
# Unit test for function escape
def test_escape():
    assert escape(m=re.match(r"\\([^\\\'\"]+)", "\\x")) == "\x00"

# Generated at 2022-06-21 10:11:50.719787
# Unit test for function test
def test_test():
    import io
    import sys

    r = io.StringIO()
    w = sys.stdout
    try:
        sys.stdout = r
        test()
    finally:
        sys.stdout = w
    assert r.getvalue() == ""



# Generated at 2022-06-21 10:12:22.076103
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"a"') == "a"
    assert evalString('"a"') == "a"
    assert evalString('"a"') == "a"
    assert evalString('"a"') == "a"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\f"') == "\f"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\v"') == "\v"
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\\'"') == "\'"


# Generated at 2022-06-21 10:12:22.774084
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:32.985545
# Unit test for function escape
def test_escape():
    from . import string_escape as m
    m.evalString("'str'")
    m.evalString('"str"')
    m.evalString('"""str""""')
    m.escape("\\x0a")
    m.escape("\\x0A")
    m.escape("\\xfF")
    m.evalString("'\\\\x0a'")
    m.evalString("'\\\\x0A'")
    m.evalString("'\\\\xfF'")
    m.escape("\\0a")
    m.escape("\\0A")
    m.escape("\\77")
    m.evalString("'\\\\0a'")
    m.evalString("'\\\\0A'")
    m.evalString("'\\\\77'")
    m.escape("\\a")

# Generated at 2022-06-21 10:12:42.989085
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\x07'") == "\x07"
    assert evalString("'\\07'") == "\x07"
    assert evalString("'\\7'") == "\x07"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\x01'") == "\x01"

# Generated at 2022-06-21 10:12:45.228092
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        assert False

# Generated at 2022-06-21 10:12:56.373587
# Unit test for function evalString
def test_evalString():
    # Valid single quote and double quote string literals
    assert evalString("'Single quoted string'") == 'Single quoted string'
    assert evalString('"Double quoted string"') == 'Double quoted string'

    # Valid triple single quote and triple double quote string literals
    assert evalString("'''Triple single quoted string'''") == 'Triple single quoted string'
    assert evalString('"""Triple double quoted string"""') == 'Triple double quoted string'

    # Test that escaped characters are decoded correctly
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\'\\\"\\\\'") == "\a\b\f\n\r\t\v\'\"\\"
    assert evalString("'\\x41\\x42\\x43\\x44'") == 'ABCD'

# Generated at 2022-06-21 10:13:08.036668
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'abc'") == "abc"
    assert evalString(r"'\''") == "'"
    assert evalString(r"'\"'") == '"'
    assert evalString(r"'a\nb'") == "a\nb"
    assert evalString(r"'\x61'") == "a"
    assert evalString(r"'\061'") == "1"
    assert evalString(r"'\061\062'") == "12"
    assert evalString(r"'\077'") == "?"
    assert evalString(r"'\100'") == "\100"
    assert evalString(r'"abc"') == "abc"
    assert evalString(r'"\'"') == "'"
    assert evalString(r'"\""') == '"'

# Generated at 2022-06-21 10:13:10.071776
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(" + "[a-zA-Z0-9]" + ")", "\\x")) == '\x00'

# Generated at 2022-06-21 10:13:16.994809
# Unit test for function escape

# Generated at 2022-06-21 10:13:17.673972
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:01.247933
# Unit test for function escape
def test_escape():
    escape_cases = {r'\\x0F': '\x0F',
                    r"\\b": '\b',
                    r"\\v": '\v',
                    r"\\t": '\t',
                    r'\\"': '"',
                    r"\\'": "'",
                    r"\a": "\a",
                    r"\\n": '\n',
                    r"\\f": '\f',
                    r"\\r": '\r',
                    r"\\'": "'",
                    r'\\"': '"',
                    r"\\\\": "\\",
                    r"\\'": "'",
                    r'\\"': '"',
                    r"\\x": "\\x"
                    }


# Generated at 2022-06-21 10:14:12.554996
# Unit test for function evalString
def test_evalString():
    splits = r'(\s+|#[^\r\n]*|/\*.*?\*/)+'
    splits = r'([\s|#[^\r\n]*|/\*.*?\*/]+)'
    splits = r'([\s#/][^\r\n]*|/\*.*?\*/)+'
    splits = r'([\s#/][^\n]*|/\*.*?\*/)+'
    test_string = """
        abc  #def
        /*ghi*/ xyz  #lmn
        /*opq*/  #rst
        """
    splits = r'([\s#/][^\n]*|/\*.*?\*/)+'

# Generated at 2022-06-21 10:14:14.270895
# Unit test for function test
def test_test():
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            test()
    unittest.main()

# Generated at 2022-06-21 10:14:19.018044
# Unit test for function evalString
def test_evalString():
    # Test simple strings
    assert evalString('"hello"') == "hello"
    assert evalString("'hello'") == "hello"
    assert evalString('"hello\\nworld"') == "hello\nworld"
    assert evalString("'hello\\nworld'") == "hello\nworld"

    # Test that the string length is not limited by evalString
    assert evalString("('x' * (1<<16))") == "x" * (1<<16)

    # Test that all possible bytes are correctly parsed
    assert evalString("(" + ", ".join("\"\\x%02x\"" % i for i in range(256)) + ")") == b"".join(bytes([i]) for i in range(256))

# Generated at 2022-06-21 10:14:19.613327
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:31.383395
# Unit test for function escape
def test_escape():
    # Test for tail.startswith('x')
    assert escape(re.match(r'\\x.{0,2}', '\\x00')) == '\x00'
    assert escape(re.match(r'\\x.{0,2}', '\\xff')) == '\xff'
    assert escape(re.match(r'\\x.{0,2}', '\\x000')) == '\x00'

    # Test for simple_escapes.get(tail)
    for c in simple_escapes.keys():
        assert escape(re.match(r'\\[abfnrtv\'"\\]', f'\\{c}')) == simple_escapes[c]

    # Test for int(tail, 8)

# Generated at 2022-06-21 10:14:31.992361
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:33.733229
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\\\'") == "\\"

# Generated at 2022-06-21 10:14:40.195049
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x61'") == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\071"') == "!"
    assert evalString('"\\071a"') == "!a"
    assert evalString('"""\\071"""') == "!\n"
    assert evalString("'''\\071'''") == "!\n"

# Generated at 2022-06-21 10:14:47.233089
# Unit test for function evalString
def test_evalString():
    def test(s):
        act = evalString(s)
        exp = eval(s)
        assert act == exp, "%r => %r, wanted %r" % (s, act, exp)

    yield test, '"A"'
    yield test, '"\\x41"'
    yield test, '"\\x61"'
    yield test, "'A'"
    yield test, "'\\x41'"
    yield test, "'\\x61'"

# Generated at 2022-06-21 10:15:13.588270
# Unit test for function evalString
def test_evalString():
    # evalString(s) -> string

    print(evalString("'a\nb'"))
    print(evalString('"a\nb"'))
    print(evalString("'abc'"))
    print(evalString("'\\n'"))
    print(evalString("'\\001'"))
    print(evalString("'\\x61'"))

# Generated at 2022-06-21 10:15:17.549788
# Unit test for function escape
def test_escape():
    m = re.search(r"\\(.|$)", '\\a')
    tail = m.group(1)
    esc = escape(m)
    assert esc == '\a'
    assert esc != tail


# Generated at 2022-06-21 10:15:20.742082
# Unit test for function escape
def test_escape():
    # Test that escape handles backslash followed by text.
    a = "\\r\\n\\"
    b = escape(re.match(r"\\r\\n\\", a))
    assert b == "\r\n\\"

# Generated at 2022-06-21 10:15:33.432252
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString('"\\\\a\\\\b"') == '\\a\\b'
    assert evalString("'\\\\a\\\\b'") == '\\a\\b'
    assert evalString("'\\\\'") == '\\'
    assert evalString('"\\\\"') == '\\'
    assert evalString("'abc\\ndef'") == 'abc\ndef'
    assert evalString("'abc\\ndef'") == 'abc\ndef'
    assert evalString('"abc\\ndef"') == 'abc\ndef'
    assert evalString("'\\\\x61\\\\x62\\\\x63'") == 'abc'

# Generated at 2022-06-21 10:15:37.566277
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == 'foo'
    assert evalString("'bar'") == 'bar'
    assert evalString('"""bar"""') == 'bar'
    assert evalString("'''foo'''") == 'foo'

# Generated at 2022-06-21 10:15:38.777562
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-21 10:15:51.329580
# Unit test for function escape
def test_escape():
    from .parser import LiteralString

    assert LiteralString.from_string(r"'\\\x20'").value == " "
    assert LiteralString.from_string(r"'\\\42'").value == "*"
    assert LiteralString.from_string(r"'\\\x21'").value == "!"
    assert LiteralString.from_string(r"'\\\x61'").value == "a"
    assert LiteralString.from_string(r"b'\\\x20'").value == b" "
    assert LiteralString.from_string(r"b'\\\42'").value == b"*"
    assert LiteralString.from_string(r"b'\\\x21'").value == b"!"

# Generated at 2022-06-21 10:15:59.471319
# Unit test for function evalString
def test_evalString():
    tests = [
        ("''", ""),
        ("'   '", "   "),
        ('""', ""),
        ('"   "', "   "),
        ('"\\n\\r\\t"', "\n\r\t"),
        ('"\'"', "'"),
        ('"\\0"', "\0"),
        ('"\\1"', "\1"),
        ('"\\7"', "\7"),
        ('"\\13"', "\13"),
        ('"\\40"', " "),
        ('"\\100"', "\100"),
        ('"\\177"', "\177"),
        ('"\\200"', "\200"),
        ('"\\377"', "\377"),
    ]
    for (s, expect) in tests:
        got = evalString(s)

# Generated at 2022-06-21 10:16:11.826849
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc", evalString("'abc'")
    assert evalString("\"abc\"") == "abc", evalString("\"abc\"")
    assert evalString("'\\''") == "'", evalString("'\\''")
    assert evalString("\"\\\"\"") == '"', evalString("\"\\\"\"")
    assert evalString("'\\'\"'") == "'\"'", evalString("'\\'\"'")
    assert evalString("\"\\'\\\"\"") == "'\"'", evalString("\"\\'\\\"\"")
    assert evalString("'foo\\nbar'") == "foo\nbar", evalString("'foo\\nbar'")
    assert evalString("'foo\\tbar'") == "foo\tbar", evalString("'foo\\tbar'")


# Generated at 2022-06-21 10:16:19.093084
# Unit test for function test
def test_test():
    import io
    import contextlib
    from . import os
    from . import sys

    try:
        from . import StringIO

    except ImportError:  # pragma: no cover
        StringIO = io.StringIO

    try:
        import unittest2 as unittest

    except ImportError:  # pragma: no cover
        import unittest

    @contextlib.contextmanager
    def test_stream(s):

        # In Python 2.7 io, StringIO fails the isatty() test.
        @contextlib.contextmanager
        def patch(target, new):
            old = getattr(target, new)
            setattr(target, new, lambda _: False)
            try:
                yield
            finally:
                setattr(target, new, old)


# Generated at 2022-06-21 10:17:08.110320
# Unit test for function evalString

# Generated at 2022-06-21 10:17:14.582330
# Unit test for function test
def test_test():
    try:
        test()
    except NameError:
        assert False, "NameError exception"
    except ValueError:
        assert False, "ValueError exception"
    except AssertionError:
        assert False, "AssertionError exception"
    except SyntaxError:
        assert False, "SyntaxError exception"
    except BaseException:
        assert False, "BaseException exception"
    assert True

# Generated at 2022-06-21 10:17:15.458372
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:26.876940
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('" "') == " "
    assert evalString('"\n"') == "\n"
    assert evalString('"\\\\"') == "\\"

# Generated at 2022-06-21 10:17:38.682976
# Unit test for function escape
def test_escape():
    s = "hi"
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", s)
    assert m is None
    s = r"\x34\n\t\\"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", s)) == "\x34\n\t\\"
    s = r"\4\4"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", s)) == "\004\004"
    s = r

# Generated at 2022-06-21 10:17:49.673256
# Unit test for function escape
def test_escape():
    from hypothesis import assume, given, strategies as st

    @given(st.text())
    def test_fails_for_unescaped_text(text):
        try:
            escape(text)
        except ValueError:
            pass
        except AssertionError:
            pass
        else:
            raise AssertionError("Expected exception")

    @given(st.text(min_size=1))
    def test_escapes_work_after_backslash(text):
        assume(text[0] == "\\")
        try:
            esc = escape(text)
        except ValueError:
            pass
        else:
            assert escape(text) == evalString("'" + text + "'")

    test_fails_for_unescaped_text()
    test_escapes_work_after_backsl

# Generated at 2022-06-21 10:17:50.239241
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:17:50.798180
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:56.043994
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc") == "abc"
    assert evalString("'''abc") == "'abc"
    assert evalString('"""abc') == '"abc'
    assert evalString("'\\'abc'") == "'abc"
    assert evalString("'\"abc'") == '"abc'
    assert evalString("'\\'") == "'"
    assert evalString("'\\x27'") == "'"

# Generated at 2022-06-21 10:18:07.661148
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\'")) == "'"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r'\"')) == '"'
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\0")) == "\0"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\7")) == "\a"
   

# Generated at 2022-06-21 10:19:37.485379
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\uabcd"') == "\uabcd"
    assert evalString('"\\U00012345"') == "\U00012345"
    assert evalString('"\\u0061"') == "\u0061"
    assert evalString('"\\U00000061"') == "\U00000061"
    assert evalString('"\\uabcd"') == "\uabcd"
    assert evalString('"\\xabcd"') == "\uabcd"
    assert evalString('"\\u0061"') == "\u0061"
    assert evalString('"\\x0061"') == "\u0061"

# Generated at 2022-06-21 10:19:37.958122
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-21 10:19:48.071677
# Unit test for function escape
def test_escape():
    # Test function escape
    # These should all succeed
    assert escape(re.match(r"\\'", "'")) == "'"
    assert escape(re.match(r'\\"', '"')) == '"'
    assert escape(re.match(r"\\\\", "\\")) == "\\"
    assert escape(re.match(r"\\a", "a")) == "\a"
    assert escape(re.match(r"\\b", "b")) == "\b"
    assert escape(re.match(r"\\f", "f")) == "\f"
    assert escape(re.match(r"\\n", "n")) == "\n"
    assert escape(re.match(r"\\r", "r")) == "\r"
    assert escape(re.match(r"\\t", "t")) == "\t"
   

# Generated at 2022-06-21 10:19:58.351280
# Unit test for function evalString
def test_evalString():
    assert evalString("'abcdefg'") == "abcdefg"
    assert evalString('"abcdefg"') == "abcdefg"
    assert evalString("r'abcdefg'") == "abcdefg"
    assert evalString(r'"abcdefg"') == "abcdefg"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\x61'") == "a"
    assert evalString('"\\x61"') == "a"
    assert evalString("'\\141'") == "a"
    assert evalString('"\\141"') == "a"
    assert evalString("'\\061'") == "1"
    assert evalString('"\\061"') == "1"

# Generated at 2022-06-21 10:20:04.750961
# Unit test for function escape
def test_escape():
    m = re.match(r"\\([abfnrtv\'" + "".join(
        "\\" + x  # The backslashes are required for python syntax
        for x in "xX0123456789"
    ) + "]|x.{0,2}|[0-7]{1,3})", "\\x3")
    assert escape(m) == '\x03'