

# Generated at 2022-06-21 10:10:35.394294
# Unit test for function evalString
def test_evalString():
    assert evalString("'ab'") == "ab"
    assert evalString('"ab"') == "ab"
    assert evalString("'\\\\ab'") == "\\ab"
    assert evalString('"\\\\ab"') == "\\ab"
    assert evalString("'\\\\xab'") == "\\xab"
    assert evalString('"\\\\xab"') == "\\xab"
    assert evalString("'\\\\101'") == "A"
    assert evalString('"\\\\101"') == "A"

# Generated at 2022-06-21 10:10:42.853972
# Unit test for function evalString
def test_evalString():
    assert evalString("") == ""
    assert evalString("''") == ""
    assert evalString("'a'") == "a"
    assert evalString("' '") == " "
    assert evalString("'a b'") == "a b"
    assert evalString("'abc'") == "abc"
    assert evalString("'\\''") == "'"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"

# Generated at 2022-06-21 10:10:44.964741
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        print(e)

# Generated at 2022-06-21 10:10:56.849172
# Unit test for function escape
def test_escape():
    from pytest import raises
    from io import StringIO
    import sys

    # Simple escapes
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"

# Generated at 2022-06-21 10:11:07.220485
# Unit test for function evalString
def test_evalString():
    import coverage
    cover = coverage.Coverage()
    cover.start()

    # Success cases

    # Single quote
    assert evalString("'a'") == "a"
    assert evalString("'aaa'") == "aaa"

    # Double quote
    assert evalString('"a"') == "a"
    assert evalString('"aaa"') == "aaa"

    # Raw string
    assert evalString("r'a'") == "a"
    assert evalString("r'aaa'") == "aaa"
    assert evalString("r'\\a'") == "\\a"
    assert evalString("r'\\\\a'") == "\\\\a"
    assert evalString("r'\\'") == "\\'"
    assert evalString("r'\\\n'") == "\\\n"

    # Literals
   

# Generated at 2022-06-21 10:11:18.096761
# Unit test for function evalString
def test_evalString():
    # testing ' and "
    for q in ("'", '"'):
        assert evalString(q) == q
        assert evalString(q * 3) == q * 2
        assert evalString(q * 5) == q * 4
        assert evalString(q + "\\" + q) == "\\"
        assert evalString(q + "\\\\" + q) == "\\\\"
        assert evalString(q + "\\\\\\\\" + q) == "\\\\\\\\"
        # test strings with no escapes
        for c in (q + "abc" + q, q + "a" + q + "b" + q + "c" + q):
            assert evalString(c) == c[1:-1]
        # test escapes

# Generated at 2022-06-21 10:11:21.107745
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString('"\\\\"') == "\\"

# Generated at 2022-06-21 10:11:21.709490
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-21 10:11:27.373485
# Unit test for function test
def test_test():
    import sys
    import cStringIO
    s = cStringIO.StringIO()
    # Monkey patch stdout so we see it
    old_stdout = sys.stdout
    sys.stdout = s
    test()
    # Restore stdout
    sys.stdout = old_stdout

    # Check if we have output
    assert s.getvalue() == ""



# Generated at 2022-06-21 10:11:39.238112
# Unit test for function escape
def test_escape():
    # Test for octal escape sequences
    assert escape(re.search('\\\\[0-7][0-7]?', "\\177")) == '\177'
    assert escape(re.search('\\\\[0-7][0-7]?[0-7]', "\\177")) == '\177'
    assert escape(re.search('\\\\[0-7]', "\\5")) == '\5'
    with pytest.raises(ValueError):
        escape(re.search('\\\\[0-7][0-7]?[0-7]', "\\58"))
    with pytest.raises(ValueError):
        escape(re.search('\\\\[0-7][0-7]?', "\\8"))

# Generated at 2022-06-21 10:12:06.440351
# Unit test for function test
def test_test():
    try:
        test()
    except (SyntaxError, ValueError) as e:
        assert False, str(e)

# Generated at 2022-06-21 10:12:18.148823
# Unit test for function evalString
def test_evalString():
    assert evalString("'\x00'") == "\x00"
    assert evalString("'\x00'") != "\x01"
    assert evalString("'a'") == "a"
    assert evalString("'a'") != "b"
    assert evalString("'a'") != "b"
    assert evalString('"a"') == "a"
    assert evalString('"a"') != "b"
    assert evalString("'\\x07'") == "\x07"
    assert evalString("'\\x07'") != "\x08"
    assert evalString("'\\x07'") != "\x07"
    assert evalString("'\\a'") == "\x07"
    assert evalString("'\\b'") == "\x08"

# Generated at 2022-06-21 10:12:26.297067
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x3F", "\\x3F")) == "?"
    assert escape(re.match(r"\\x3F", "\\x3F")) == "?"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r"\\'", "\\'")) == "'"

# Generated at 2022-06-21 10:12:26.922558
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-21 10:12:28.405307
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-21 10:12:38.350278
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == "hello"
    assert evalString("'hello'") == "hello"
    assert evalString("'hel\\x6co'") == "hello"
    assert evalString('"hel\\x6co"') == "hello"
    assert evalString('"hel\\x6co"') == "hello"
    assert evalString("'hel\\x6c\\157'") == "hello"
    assert evalString('"hel\\x6c\\157"') == "hello"
    assert evalString("'hel\\x6c\\x6f'") == "hello"
    assert evalString('"hel\\x6c\\x6f"') == "hello"
    assert evalString("'hello'") == "hello"

# Generated at 2022-06-21 10:12:40.430252
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        assert False, "Unhandled exception in test():\n{}".format(e)

# Generated at 2022-06-21 10:12:46.276079
# Unit test for function test
def test_test():
    import io
    import sys
    import unittest

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    if sys.version_info[:2] >= (3, 6):
        expected = "AssertionError: 224"
    else:
        expected = "AssertionError"

    s = io.StringIO()
    with patch("sys.stdout", s):
        with self.assertRaisesRegex(AssertionError, expected):
            test()
    output = s.getvalue().strip()
    self.assertEqual(output, "")

# Generated at 2022-06-21 10:12:47.269489
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:58.187253
# Unit test for function evalString

# Generated at 2022-06-21 10:13:28.205401
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"

# Generated at 2022-06-21 10:13:34.259751
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\071"') == '!'
    assert evalString('"\\"') == '"'
    assert evalString('"\\\'"') == "'"

# Generated at 2022-06-21 10:13:46.642568
# Unit test for function test
def test_test():
    import sys
    import io
    import unittest
    class TestTest(unittest.TestCase):
        def test_test(self: 'TestTest') -> None:
            captured_output = io.StringIO()
            sys.stdout = captured_output
            string_literal_test.test()
            sys.stdout = sys.__stdout__

# Generated at 2022-06-21 10:13:57.643618
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\a')) == "\a"
    assert escape(re.match('\\\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\b')) == "\b"
    assert escape(re.match('\\\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\f')) == "\f"
    assert escape(re.match('\\\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\n')) == "\n"

# Generated at 2022-06-21 10:13:59.164295
# Unit test for function test
def test_test():
    try:
        test()
    except:
        print('test_test failed')
        raise

# Generated at 2022-06-21 10:14:00.029930
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:03.334955
# Unit test for function evalString
def test_evalString():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(EvaluationTestCase))
    return suite



# Generated at 2022-06-21 10:14:13.860283
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", u"\\a")) == "\a"
    assert escape(re.match(r"\\b", u"\\b")) == "\b"
    assert escape(re.match(r"\\f", u"\\f")) == "\f"
    assert escape(re.match(r"\\n", u"\\n")) == "\n"
    assert escape(re.match(r"\\r", u"\\r")) == "\r"
    assert escape(re.match(r"\\t", u"\\t")) == "\t"
    assert escape(re.match(r"\\v", u"\\v")) == "\v"
    assert escape(re.match(r"\\'", u"\\'")) == "'"

# Generated at 2022-06-21 10:14:18.823861
# Unit test for function escape
def test_escape():
    for test, answer in simple_escapes.items():
        res = escape(re.match('\\'+test, '\\'+test))
        print(res, answer)
        assert res == answer
        # Note: no need to test octal and hex escapes
        # as they are tested in unit test for function evalString

if __name__ == '__main__':
    test_escape()

# Generated at 2022-06-21 10:14:30.650367
# Unit test for function escape

# Generated at 2022-06-21 10:15:20.938303
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"

# Generated at 2022-06-21 10:15:28.172021
# Unit test for function escape
def test_escape():
    bad_escape = r'\8'
    good_escape = r'\a'
    assert escape(re.search(r'\\.{1}', bad_escape)) == '\x00'
    assert escape(re.search(r'\\.{1}', good_escape)) == '\a'



# Generated at 2022-06-21 10:15:28.547110
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:36.634508
# Unit test for function escape
def test_escape():
    import re
    from lib2to3.pgen2.tokenize import _escape
    assert re.findall(_escape, "\\x") == []

# Generated at 2022-06-21 10:15:49.309188
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(')$", "\\'")) == "'"
    assert escape(re.match(r'\\(")$', '\\"')) == '"'
    assert escape(re.match(r"\\(\\)$", "\\\\")) == "\\"
    assert escape(re.match(r"\\(b)$", "\\b")) == "\b"
    assert escape(re.match(r"\\(f)$", "\\f")) == "\f"
    assert escape(re.match(r"\\(n)$", "\\n")) == "\n"
    assert escape(re.match(r"\\(r)$", "\\r")) == "\r"
    assert escape(re.match(r"\\(t)$", "\\t")) == "\t"

# Generated at 2022-06-21 10:15:58.667675
# Unit test for function escape
def test_escape():

    # Valid octal (\ooo)
    assert escape(re.match(r"\\[0-7]{1,3}", "\\42")) == chr(34)
    assert escape(re.match(r"\\[0-7]{1,3}", "\\123")) == chr(83)
    assert escape(re.match(r"\\[0-7]{1,3}", "\\05")) == chr(5)

    # Valid hex (\xhh)
    assert escape(re.match(r"\\x[0-9a-fA-F]{2}", "\\x6f")) == chr(111)
    assert escape(re.match(r"\\x[0-9a-fA-F]{2}", "\\x1E")) == chr(30)



# Generated at 2022-06-21 10:16:11.133138
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\\'", "\\'")) == "\'"
    assert escape(re.match(r"\\\"", "\\\"")) == "\""
    assert escape(re.match(r"\\\\", "\\\\")) == "\\"
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape

# Generated at 2022-06-21 10:16:21.377851
# Unit test for function escape

# Generated at 2022-06-21 10:16:31.690828
# Unit test for function escape
def test_escape():
	good_cases = [
		("\\a", "\a"),
		("\\b", "\b"),
		("\\f", "\f"),
		("\\n", "\n"),
		("\\r", "\r"),
		("\\t", "\t"),
		("\\v", "\v"),
		("\\\'", "'"),
		("\\\"", '"'),
		("\\\\", "\\"),
		("\\x0a", "\n"),
		("\\x0A", "\n"),
		("\\07", "\a"),
		("\\017", "\x0f"),
		("\\101", "A"),
		("\\1010", "A0"),
	]

# Generated at 2022-06-21 10:16:32.288636
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:50.838362
# Unit test for function test
def test_test():
    """Test the "test" function above."""
    test()

# Generated at 2022-06-21 10:17:51.578164
# Unit test for function test
def test_test():
    test() == None

# Generated at 2022-06-21 10:17:52.155094
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:18:02.907579
# Unit test for function evalString
def test_evalString():
    # Test empty string
    assert evalString('""') == ""
    assert evalString("''") == ""

    # Test simple cases
    assert evalString(r"'abc\ndef'") == "abc\ndef"
    assert evalString(r'"abc\ndef"') == "abc\ndef"
    assert evalString(r"'a \'quote\''") == "a 'quote'"
    assert evalString(r"'a \"quote\"'") == 'a "quote"'
    assert evalString(r'"a \'quote\'"') == 'a \'quote\''
    assert evalString(r'"a \"quote\""') == "a \"quote\""

    # Test backslash escapes
    assert evalString(r"'abc\tdef'") == "abc\tdef"

# Generated at 2022-06-21 10:18:10.044881
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == 'a'
    assert evalString('"\\a"') == '\a'
    assert evalString('"a\\a"') == 'a\a'
    assert evalString('"\\x65"') == 'e'
    # \u and \U require surrogate pairs:
    # assert evalString('u"x"') == 'x'
    # assert evalString('U"x"') == 'x'
    # Not sure why evalString('"\\U0020"') == '\U0020' instead of ' ':
    # assert evalString('"\\U0020"') == ' '

# Generated at 2022-06-21 10:18:16.517513
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\""') == '"'
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\f"') == "\f"
    assert evalString('"\\r"') == "\r"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\v"') == "\v"
    assert evalString('"\\113"') == "I"
    assert evalString('"\\117"') == "O"

# Generated at 2022-06-21 10:18:25.091702
# Unit test for function evalString
def test_evalString():
    if evalString("'a string'") != "a string":
        raise AssertionError("wrong result")
    if evalString("'abc\\ndef\\u0123'") != "abc\ndef\u0123":
        raise AssertionError("wrong result")
    try:
        evalString("'a backslash at the end\\}")
    except ValueError as e:
        if str(e) != "invalid octal string escape ('\\\\')":
            raise AssertionError("wrong exception")
    else:
        raise AssertionError("expected ValueError")

# Generated at 2022-06-21 10:18:33.777865
# Unit test for function escape

# Generated at 2022-06-21 10:18:34.569108
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:18:43.347876
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(x.{0,2}|.)", "\\x41")
    assert m is not None
    assert escape(m) == "A"
    m = re.match(r"\\(x.{0,2}|.)", "\\x4")
    assert m is not None
    try:
        escape(m)
    except ValueError:
        pass
    else:
        assert False, "invalid hex string escape ('\\x4') did not raise"
    m = re.match(r"\\(x.{0,2}|.)", "\\x4z")
    assert m is not None
    try:
        escape(m)
    except ValueError:
        pass