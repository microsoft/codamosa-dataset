

# Generated at 2022-06-21 10:10:24.801247
# Unit test for function evalString
def test_evalString():

    import string
    import random

    for i in range(0x110000):
        s = chr(i)
        assert evalString(repr(s)) == s, "Failed at " + s

    # Mix of ASCII chars and non-ASCII chars
    s = "%d %s %f" % (random.randrange(10000),
                      random.choice(string.printable),
                      random.uniform(100, 1000))
    assert evalString(repr(s)) == s, "Failed at " + s

# Generated at 2022-06-21 10:10:25.304013
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:10:36.361308
# Unit test for function escape

# Generated at 2022-06-21 10:10:37.591078
# Unit test for function test
def test_test():
    with pytest.raises(SystemExit):
        test()

# Generated at 2022-06-21 10:10:49.842223
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x7a", "\\x7a")) == 'z'  # hex
    assert escape(re.match(r"\\x7a", "\\x7az")) == 'z'  # hex
    assert escape(re.match(r"\\x7a", "\\x7aA")) == 'z'  # hex
    assert escape(re.match(r"\\x7a", "\\x7a\\")) == 'z'  # hex
    assert escape(re.match(r"\\x7a", "\\x7")) == 'z'  # hex
    assert escape(re.match(r"\\x7a", "\\x7a ")) == 'z'  # hex
    assert escape(re.match(r"\\x7a", "\\x7a\n"))

# Generated at 2022-06-21 10:10:59.770949
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\'", r"\'")) == "'"

# Generated at 2022-06-21 10:11:08.600859
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(.|$)", '\\')
    assert escape(m) == "\\"

    m = re.match(r"\\(.|$)", '\\x')
    msg = "invalid hex string escape ('\\x')"
    try:
        escape(m)
    except ValueError as exc:
        assert str(exc) == msg
    else:
        raise ValueError(msg)

    m = re.match(r"\\(.|$)", '\\xab')
    assert escape(m) == chr(0xab)

    m = re.match(r"\\(.|$)", '\\0')
    assert escape(m) == chr(0)

    m = re.match(r"\\(.|$)", '\\1')
    assert escape(m)

# Generated at 2022-06-21 10:11:18.926436
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\x20', '\\x20')) == ' '
    assert escape(re.match(r'\\a', '\\a')) == '\a'
    assert escape(re.match(r'\\r', '\\r')) == '\r'
    assert escape(re.match(r'\\f', '\\f')) == '\f'
    assert escape(re.match(r'\\v', '\\v')) == '\v'
    assert escape(re.match(r'\\n', '\\n')) == '\n'
    assert escape(re.match(r'\\t', '\\t')) == '\t'
    assert escape(re.match(r'\\b', '\\b')) == '\b'

# Generated at 2022-06-21 10:11:19.774909
# Unit test for function escape
def test_escape():
    assert escape('"\\"') == '"'

# Generated at 2022-06-21 10:11:21.305967
# Unit test for function test
def test_test():
    # Call the function and check the output
    test()

# Generated at 2022-06-21 10:11:29.815839
# Unit test for function evalString
def test_evalString():
    assert evalString('"")') is '"'

# Generated at 2022-06-21 10:11:35.304484
# Unit test for function evalString
def test_evalString():
    assert evalString("'x'") == "x"
    assert evalString("'\\''") == "'"
    assert evalString("'\\x5f'") == "_"
    assert evalString("'\\005'") == "\x05"

    assert evalString("'\\n'") == "\n"
    assert evalString("'\\077'") == "?"
    assert evalString("'\\000'") == "\0"
    assert evalString("'\\x7f'") == "\x7f"
    assert evalString("'\\u1234'") == "ሴ"
    assert evalString("'\\U0001d120'") == "\U0001d120"
    assert evalString("'\\N{HIRAGANA LETTER A}'") == "\N{HIRAGANA LETTER A}"


# Generated at 2022-06-21 10:11:39.576416
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(x.)", "\\xAA")) == chr(170)
    assert escape(re.match(r"\\[xabfnrtv'\"\\]", r"\\b")) == "\b"



# Generated at 2022-06-21 10:11:41.455790
# Unit test for function test
def test_test():
    s = "'\\x3d'"
    val = evalString(s)
    assert val == '='

# Generated at 2022-06-21 10:11:47.922377
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\''") == "'"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x00'") == "\x00"
    assert evalString('"\\""') == '"'

    try:
        evalString("'\\x'")
        assert False
    except ValueError:
        pass

    try:
        evalString("'\\x000'")
        assert False
    except ValueError:
        pass

    assert evalString('"""#"""') == "#"
    assert evalString('"""\\"""') == "\\"
    assert evalString("'''''#'''") == "#"
    assert evalString("'''''\\''''") == "\\"

# Generated at 2022-06-21 10:11:59.655493
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\\a")).encode("ascii") == b"\x07"
    assert escape(re.match(r"\\(.)", r"\\b")).encode("ascii") == b"\x08"
    assert escape(re.match(r"\\(.)", r"\\f")).encode("ascii") == b"\x0c"
    assert escape(re.match(r"\\(.)", r"\\n")).encode("ascii") == b"\n"
    assert escape(re.match(r"\\(.)", r"\\r")).encode("ascii") == b"\r"

# Generated at 2022-06-21 10:12:08.280843
# Unit test for function evalString
def test_evalString():
    assert evalString(r'""') == ""
    assert evalString(r"''") == ""
    assert evalString(r'"a"') == "a"
    assert evalString(r"'a'") == "a"
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r'"\a\b\f\n\r\t\v"') == "\a\b\f\n\r\t\v"
    assert evalString(r"'\a\b\f\n\r\t\v'") == "\a\b\f\n\r\t\v"
    assert evalString(r'"\\"') == "\\"
    assert evalString(r"'\\'") == "\\"

# Generated at 2022-06-21 10:12:09.443723
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:21.460884
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\t")) == "\t"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\7")) == "\a"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\042")) == '"'

# Generated at 2022-06-21 10:12:22.129766
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:41.327161
# Unit test for function escape
def test_escape():
    for c in range(256):
        u = chr(c)
        s = repr(u)[1:-1]
        if not s:
            continue
        if s[0] == "\\" and s[1] not in "abfnrtv\\x":
            continue
        escaped = escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", s))
        assert escaped == u, "{!r} != {!r} for {!r}".format(escaped, u, s)

# Generated at 2022-06-21 10:12:52.295018
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\a')) == '\a'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\b')) == '\b'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\f')) == '\f'

# Generated at 2022-06-21 10:13:04.464148
# Unit test for function evalString
def test_evalString():
    assert evalString("'foo'") == "foo"
    assert evalString("'foo\'bar'") == "foo\'bar"
    assert evalString("'foo\\nbar'") == "foo\\nbar"
    assert evalString('"foo"') == "foo"
    assert evalString("'\\xff'") == "\xff"
    assert evalString("'\\u0100'") == "\x01\x00"
    assert evalString("'\\U00010101'") == "\x01\x01\x01"
    try:
        evalString("'foo")
        assert False, "failed to raise SyntaxError"
    except ValueError:
        pass
    try:
        evalString("'\\x'")
        assert False, "failed to raise SyntaxError"
    except ValueError:
        pass

# Generated at 2022-06-21 10:13:06.385192
# Unit test for function test
def test_test():
    try:
        test()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-21 10:13:15.057818
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\a", "\\a")) == "\a"
    assert escape(re.match("\\b", "\\a")) == "\b"
    assert escape(re.match("\\f", "\\a")) == "\f"
    assert escape(re.match("\\n", "\\a")) == "\n"
    assert escape(re.match("\\r", "\\a")) == "\r"
    assert escape(re.match("\\t", "\\a")) == "\t"
    assert escape(re.match("\\v", "\\a")) == "\v"
    assert escape(re.match("\\'", "\\a")) == "'"
    assert escape(re.match('\\"', "\\a")) == '"'
    assert escape(re.match("\\\\", "\\a")) == "\\"

# Generated at 2022-06-21 10:13:16.680187
# Unit test for function test
def test_test():
    assert evalString('"\\n"') == '\n'

# Generated at 2022-06-21 10:13:17.280058
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:20.299379
# Unit test for function test
def test_test():
    from unittest.mock import call, patch

    with patch("builtins.print") as mocked_print:
        test()
        mocked_print.assert_has_calls([])

# Generated at 2022-06-21 10:13:22.597118
# Unit test for function evalString
def test_evalString():
    test_string1 = r'"\\0059\x59"'
    test_string2 = r"'\a'"
    test_string3 = r"'\x31'"

    assert evalString(test_string1) == '\\0059Y'
    assert evalString(test_string2) == '\x07'
    assert evalString(test_string3) == '1'

# Generated at 2022-06-21 10:13:23.090705
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:55.593579
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\x42") == "B"
    assert escape("\\078") == "x"
    assert escape("\\x1f") == "\x1f"
    assert escape("\\071") == "\x09"


# --------------------------------------------------------------------
# Copyright 2001-2002,2004 by Just van Rossum and friends.
#
# This is

# Generated at 2022-06-21 10:14:07.441106
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"

# Generated at 2022-06-21 10:14:14.331166
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\141"') == 'a'
    assert evalString('"\\x000041"') == '\\x000041'
    assert evalString('"\\041"') == '!'
    assert evalString('"\\41"') == '!'
    assert evalString('"\\&"') == '\\&'
    assert evalString('"&"') == '&'
    assert evalString('"\\"' + '"') == '"'
    assert evalString('"x"') == 'x'
    assert evalString("'a'") == 'a'
    assert evalString("'\\x61'") == 'a'
    assert evalString("'\\141'") == 'a'
   

# Generated at 2022-06-21 10:14:25.541026
# Unit test for function evalString
def test_evalString():
    assert evalString("'Hello World'") == "Hello World"
    assert evalString('"Hello World"') == "Hello World"
    assert evalString('"\\u0039\\u0038"') == "98"
    assert evalString('"\\U00000039\\U00000038"') == "98"
    assert evalString('"\\x39\\x38"') == "98"
    assert evalString('"\\39\\38"') == "987"
    assert evalString('"\\9\\8"') == "987"
    assert evalString('"\\0"') == "\x00"
    assert evalString('"\\9\\8"') == "987"
    assert evalString('"\\8"') == "\x08"
    assert evalString('"\\8\\09"') == "\x08\x00\x09"

# Generated at 2022-06-21 10:14:34.968876
# Unit test for function evalString
def test_evalString():
  assert evalString('"\\x61"') == 'a'
  assert evalString('"\\62"') == 'b'
  assert evalString('"\\073"') == ';'
  assert evalString('"\\073abc"') == ';abc'
  assert evalString("'abc\\nabc'") == 'abc\nabc'
  assert evalString("'abc\\'abc'") == "abc'abc"
  assert evalString("'abc\\\"abc'") == 'abc"abc'
  assert evalString("'abc\\a\\b\\f\\n\\r\\t\\vabc'") == 'abc\a\b\f\n\r\t\vabc'

# Generated at 2022-06-21 10:14:44.734469
# Unit test for function escape
def test_escape():
    escape_funct = evalString._escape
    assert escape_funct is escape
    assert escape_funct('\\a') == "\a"
    assert escape_funct('\\b') == "\b"
    assert escape_funct('\\f') == "\f"
    assert escape_funct('\\n') == "\n"
    assert escape_funct('\\r') == "\r"
    assert escape_funct('\\t') == "\t"
    assert escape_funct('\\v') == "\v"
    assert escape_funct('\\\'') == "'"
    assert escape_funct('\\\"') == '"'
    assert escape_funct('\\\\') == "\\"
    assert escape_funct('\\x0a') == "\n"
    assert escape_funct('\\x1E') == ch

# Generated at 2022-06-21 10:14:50.870735
# Unit test for function test
def test_test():
    import io
    import sys

    from unittest import mock

    # We mock out stdout so we can capture the output, and sys.exit so that we can
    # check for an error condition.
    with mock.patch.object(sys, "stdout", new_callable=io.StringIO) as stdout:
        test()
        assert not stdout.getvalue()

# Generated at 2022-06-21 10:14:55.784541
# Unit test for function evalString
def test_evalString():
    assert evalString('"\a\b\f\n\r\t\v\'"') == "\a\b\f\n\r\t\v\'"
    assert evalString('"\\x3f\\x3f\\x3f"') == "???"
    assert evalString('"\\377\\377\\377"') == "???"
    assert evalString("'\n'") == "\n"
    assert evalString("'\\\n'") == "\\\n"
    assert evalString("'''\n'''") == "\n"
    assert evalString("'''\\\n'''") == "\\\n"

# Generated at 2022-06-21 10:15:01.294964
# Unit test for function escape
def test_escape():
    from astroid import test_utils
    module = test_utils.build_module("""
        def test_escape():
            from ast.literal_parser import escape
            assert escape(r'\n') == '\\n'
            assert escape(r'\x2f') == '\\x2f'
            assert escape(r'\127') == '\\127'
            assert escape(r'\a') == '\\a'
        test_escape()
    """)
    assert not module.body

# Generated at 2022-06-21 10:15:01.754758
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:45.503671
# Unit test for function test
def test_test():
    try:
        test()
    except:
        pass

# Generated at 2022-06-21 10:15:56.181414
# Unit test for function escape
def test_escape():
    assert escape('\\\'"') == '\\', "'\\\'"
    assert escape('\\a') == '\a', "'\\a'"
    assert escape('\\b') == '\x08', "'\\b'"
    assert escape('\\f') == '\x0c', "'\\f'"
    assert escape('\\n') == '\n', "'\\n'"
    assert escape('\\r') == '\r', "'\\r'"
    assert escape('\\t') == '\t', "'\\t'"
    assert escape('\\v') == '\x0b', "'\\v'"
    assert escape('\\\'') == '\'', "'\\\''"
    assert escape('\\\"') == '\"', "'\\\"'"
    assert escape('\\\\') == '\\', "'\\\\'"

# Generated at 2022-06-21 10:15:56.643856
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-21 10:16:08.214851
# Unit test for function escape
def test_escape():
    from asteval import escape
    from textwrap import dedent

    assert escape(re.match(r"^\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"^\\(.)", r"\'")) == "\'"
    assert escape(re.match(r"^\\(.)", r"\"")) == "\""
    assert escape(re.match(r"^\\(.)", r"\\")) == "\\"
    assert escape(re.match(r"^\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"^\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"^\\(.)", r"\f")) == "\f"

# Generated at 2022-06-21 10:16:09.746893
# Unit test for function test
def test_test():
    """Test for function test."""
    test()

# Generated at 2022-06-21 10:16:20.277332
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'a\\\\b'") == "a\\b"
    assert evalString("'a\\tb'") == "a\tb"
    assert evalString("'a\\'b'") == "a'b"
    assert evalString("'a\\\"b'") == 'a"b'
    assert evalString("'a\\\\\\'b'") == "a\\'b"
    assert evalString("'a\\b'") == "\x08"
    assert evalString("'a\\077'") == "a?"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x7f'") == "\x7f"

# Generated at 2022-06-21 10:16:27.127718
# Unit test for function escape
def test_escape():

    def check(one, two):
        m = re.search(r"\\(\\|'|\"|[abfnrtv]|x.{0,2}|[0-7]{1,3})", one)
        assert m is not None
        assert m.group(1) == two
        assert escape(m) == two

    check(r"\0", "0")
    check(r"\1", "1")
    check(r"\12", "12")
    check(r"\123", "123")
    check(r"\x3f", "?")
    check(r"\x3F", "?")
    check(r"\xa5", "¥")
    check(r"\n", "\n")
    check(r"\r", "\r")

# Generated at 2022-06-21 10:16:33.179683
# Unit test for function test
def test_test():
    """Tests to make sure the test function works as intended.
    """

    with pytest.raises(AssertionError):
        evalString("'\\d'")

    with pytest.raises(AssertionError):
        evalString('"\\456"')

    with pytest.raises(AssertionError):
        evalString('"\\x01234"')

    with pytest.raises(Exception):
        evalString("'fds'")

# Generated at 2022-06-21 10:16:34.345280
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:16:34.881289
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:18:11.426300
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"b"') == "b"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\t'") == "\t"
    assert evalString('"\\123"') == "\123"
    assert evalString('"\\xFF"') == "\xFF"

# Generated at 2022-06-21 10:18:17.347485
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString('"\\x5C"') == "\\"
    assert evalString("'''a'") == "'a"
    assert evalString('"""a"') == '"a'
    assert evalString("'a' + 'b'") == "ab"



# Generated at 2022-06-21 10:18:17.932727
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:18:19.852271
# Unit test for function test
def test_test():
    """Unit test for function test"""
    test()



# Generated at 2022-06-21 10:18:29.899300
# Unit test for function escape
def test_escape():
    tests = [
        ('\\a', r'\a'),
        ('\\b', r'\b'),
        ('\\f', '\f'),
        ('\\n', '\n'),
        ('\\r', '\r'),
        ('\\t', '\t'),
        ('\\v', '\v'),
        ('\\\'', r'\''),
        ('\\"', r'"'),
        ('\\\\', '\\'),
        ('\\x7f', '\x7f'),
        ('\\0', '\0'),
        ('\\031', '\031'),
        ('\\056', '\056'),
    ]
    for test in tests:
        yield check_escape, test[0], test[1]



# Generated at 2022-06-21 10:18:31.153946
# Unit test for function test
def test_test():
    # Should not crash in any way.
    test()

# Generated at 2022-06-21 10:18:34.437078
# Unit test for function evalString
def test_evalString():
    # pylint: disable=eval-used
    assert evalString(repr(eval('"TEST"'))) == "TEST"

# Generated at 2022-06-21 10:18:39.805403
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"s"') == "s"
    assert evalString('"s\n"') == "s\n"

    assert evalString('"""') == ""
    assert evalString('"s"') == "s"
    assert evalString('"s\n"') == "s\n"

    assert evalString('\'"\'', '\'\'"\'') == "\""

# Generated at 2022-06-21 10:18:43.073251
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\007'") == "\a"
    assert evalString("'\\x07'") == "\a"
    assert evalString("'\\007'") == "\a"
    assert evalString("'\\0'") == "\x00"

# Generated at 2022-06-21 10:18:53.678696
# Unit test for function evalString