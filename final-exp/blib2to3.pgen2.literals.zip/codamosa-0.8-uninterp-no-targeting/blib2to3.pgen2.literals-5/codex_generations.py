

# Generated at 2022-06-21 10:10:27.516863
# Unit test for function evalString
def test_evalString():
    raises(ValueError, evalString, "\\")
    raises(ValueError, evalString, "\\q")
    raises(ValueError, evalString, "\\x1")
    raises(ValueError, evalString, "\\11")
    raises(ValueError, evalString, "\\1111")
    raises(ValueError, evalString, "\\11111111")
    assert evalString('"foo"') == "foo"
    assert evalString("'foo'") == "foo"
    assert evalString('"foo\\n"') == "foo\n"
    assert evalString("'foo\\n'") == "foo\n"
    assert evalString('"foo\\n\\t"') == "foo\n\t"
    assert evalString("'foo\\n\\t'") == "foo\n\t"

# Generated at 2022-06-21 10:10:38.614916
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc\\nabc\\"abc\\\\abc"') == 'abc\nabc"abc\\abc'
    assert evalString("'abc\\nabc\\'abc\\\\abc'") == 'abc\nabc\'abc\\abc'
    assert evalString(
        '"abc\\nabc\\"abc\\\\abc\\x45\\042\\x42\\x42\\x42\\041\\045\\044\\042\\042\\x42\\42\\42"'
    ) == 'abc\nabc"abc\\abcE"BBBB!!%&&"**BBB'

# Generated at 2022-06-21 10:10:50.847571
# Unit test for function escape
def test_escape():
    # Tests the escape function

    t1 = r'\a'
    ans1 = '\a'
    t2 = r'\x01'
    ans2 = '\x01'
    t3 = r'\01'
    ans3 = '\x01'
    t4 = r'\z'
    ans4 = 'z'
    t5 = r'\xz0'
    ans5 = 'xz0'

    m1 = re.search(r'(\\a)', t1)
    assert escape(m1) == ans1
    m2 = re.search(r'(\\x01)', t2)
    assert escape(m2) == ans2
    m3 = re.search(r'(\\01)', t3)
    assert escape(m3) == ans3
   

# Generated at 2022-06-21 10:10:51.451054
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:10:52.435988
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:10:53.548024
# Unit test for function test
def test_test():
    _test_test(b"abc")

# Generated at 2022-06-21 10:11:01.391320
# Unit test for function evalString
def test_evalString():
    assert evalString("'nothing to see here'") == "nothing to see here"
    assert evalString('"nothing to see here"') == "nothing to see here"
    assert evalString("'this is a \"string\"'") == "this is a \"string\""
    assert evalString("'this is a \\'string\\''") == "this is a 'string'"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\n"') == "\n"
    assert evalString(r"'\t'") == "\t"
    assert evalString(r'"\t"') == "\t"
    assert evalString(r"'\a'") == "\a"
    assert evalString(r'"\a"') == "\a"
    assert evalString("'\\n'") == "\n"

# Generated at 2022-06-21 10:11:09.587939
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r"\\\"", '\\"')) == '"'
    assert escape(re.match(r"\\a", "\\a")) == "a"
    assert escape(re.match(r"\\b", "\\b")) == "b"
    assert escape(re.match(r"\\f", "\\f")) == "f"
    assert escape(re.match(r"\\n", "\\n")) == "n"
    assert escape(re.match(r"\\r", "\\r")) == "r"
    assert escape(re.match(r"\\t", "\\t")) == "t"
    assert escape(re.match(r"\\v", "\\v")) == "v"
    assert escape

# Generated at 2022-06-21 10:11:10.775338
# Unit test for function test
def test_test():
    # no exceptions raised
    test()
    return

# Generated at 2022-06-21 10:11:11.696074
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:21.966108
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:31.761469
# Unit test for function escape
def test_escape():
    try:
        escape('\\0')
    except ValueError:
        pass
    else:
        assert 0, "Failed to raise ValueError"
    assert escape(r'\x07') == '\a'
    assert escape(r'\x0A') == '\n'
    assert escape(r'\x1B') == '\x1b'
    assert escape(r'\x20') == ' '
    assert escape(r'\x7F') == '\x7f'
    for i in range(4):
        try:
            escape('\\x{:02}'.format(i))
        except ValueError:
            pass
        else:
            assert 0, "Failed to raise ValueError"
    try:
        escape('\\x0')
    except ValueError:
        pass

# Generated at 2022-06-21 10:11:34.418131
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\x12\\34', r'\x12\34')) == '\x12\x34'

# Generated at 2022-06-21 10:11:35.469588
# Unit test for function test
def test_test():
    # test()
    assert True



# Generated at 2022-06-21 10:11:45.606382
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\[xX][0-9a-fA-F]{2}", r"\x0a")) == "\n"
    assert escape(re.match(r"\\[xX][0-9a-fA-F]{2}", r"\x0a" * 2)) == "\n"
    assert escape(re.match(r"\\[xX][0-9a-fA-F]{2}", r"\x0a" * 3)) == "\n"
    assert escape(re.match(r"\\[xX][0-9a-fA-F]{2}", r"\x0a" * 4)) == "\n"

# Generated at 2022-06-21 10:11:57.624902
# Unit test for function escape
def test_escape():
    assert evalString("'\\\\x61'") == '\x61'
    assert evalString("'\\x61'") == '\x61'
    assert evalString("'\\61'") == '\x31'
    assert evalString("'\\a'") == '\x07'
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x10x'") == "\x10x"
    assert evalString("'\\x10'") == "\x10"

    # The following are allowed by 'escape', but are invalid escapes in Python
    assert evalString("'\\09'") == "\t9"
    assert evalString("'\\90'") == "9\x30"
    assert evalString("'\\990'") == "9\x39\x30"

# Generated at 2022-06-21 10:12:02.065543
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x[\da-fA-F]{2}", "\\x00")) == "\x00"
    assert escape(re.match(r"\\[0-7]{3}", "\\000")) == "\000"

# Generated at 2022-06-21 10:12:02.596275
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:15.585978
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(?P<tail>['\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")
    assert m.group("tail") == "a"
    assert escape(m) == "\a"
    m = re.match(r"\\(?P<tail>['\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x61")
    assert m.group("tail") == "x61"
    assert escape(m) == "a"
    m = re.match(r"\\(?P<tail>['\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\077")
   

# Generated at 2022-06-21 10:12:28.356650
# Unit test for function evalString

# Generated at 2022-06-21 10:12:39.723868
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-21 10:12:50.645122
# Unit test for function escape
def test_escape():
    bad_values = ["\\", "\\i"]
    for i in bad_values:
        try:
            escape(i)
            assert False, "Expected exception for bad escape: " + i
        except ValueError:
            pass

    assert escape("\\x16".encode('ascii')) == b"\x16"
    assert escape(b"\\x16") == b"\x16"

# Generated at 2022-06-21 10:13:01.179267
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString('""') == ""
    assert evalString("'a'") == "a"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x41'") == "A"
    assert evalString("'\\0'") == "\x00"
    assert evalString("'\\001'") == "\x01"
    assert evalString("'\\11'") == "\t"
    assert evalString("'\\011'") == "\t"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x07'") == "\x07"
    assert evalString("'\\0\\0'") == "\x00\x00"

# Generated at 2022-06-21 10:13:12.141832
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'abc\\n'") == "abc\n"
    assert evalString("'\\t '") == "\t "
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\xff'") == "\xff"
    assert evalString("'\\0o77'") == chr(0o77)
    assert evalString("'\\00o77'") == chr(0o77)

# Generated at 2022-06-21 10:13:18.049290
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\\'"') == "'"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\x61"') == "a"

# Generated at 2022-06-21 10:13:29.637155
# Unit test for function evalString
def test_evalString():
    assert evalString('"a string"') == "a string"
    assert evalString("'a string'") == "a string"
    assert evalString("'''a string'''") == "a string"
    assert evalString('"""a string"""') == "a string"
    assert evalString("'''a 'string' with ''quotes'''") == "a 'string' with 'quotes'"
    assert evalString('"""a "string" with ""quotes"""') == 'a "string" with "quotes"'
    assert evalString("'''a string with \\x3b strange escapes'''") == "a string with ; strange escapes"
    assert evalString("'''a string with \\x26 strange escapes'''") == "a string with & strange escapes"

# Generated at 2022-06-21 10:13:37.374117
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(?P<tail>'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")).__eq__("'")
    assert escape(re.match(r"\\(?P<tail>'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\\')).__eq__("\\")
    assert escape(re.match(r"\\(?P<tail>'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\a')).__eq__("\a")

# Generated at 2022-06-21 10:13:50.193117
# Unit test for function escape
def test_escape():
    r = r'(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})'
    assert escape(re.search(r'\\%s' % r, r"\a")) == "\a"
    assert escape(re.search(r'\\%s' % r, r"\b")) == "\b"
    assert escape(re.search(r'\\%s' % r, r"\f")) == "\f"
    assert escape(re.search(r'\\%s' % r, r"\n")) == "\n"
    assert escape(re.search(r'\\%s' % r, r"\r")) == "\r"

# Generated at 2022-06-21 10:13:59.726035
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\x61\\u0162"') == 'a\\u0162'
    assert evalString('"\\x61\\u0162\\U00012345"') == 'a\\u0162\\U00012345'
    assert evalString('"\\x61\\u0162\\U00012345\\x66"') == 'a\\u0162\\U00012345f'
    assert evalString('"\\x61\\u0162\\U00012345\\x66\\u0123"') == 'a\\u0162\\U00012345f\\u0123'

# Generated at 2022-06-21 10:14:10.945246
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(x[0-9a-fA-F]{1,2}|[0-7]{1,3})", '\\xFF')
    assert m.group(1) == 'xFF'
    m = re.match(r"\\(x[0-9a-fA-F]{1,2}|[0-7]{1,3})", '\\777')
    assert m.group(1) == '777'
    m = re.match(r"\\(x[0-9a-fA-F]{1,2}|[0-7]{1,3})", '\\0')
    assert m.group(1) == '0'

# Generated at 2022-06-21 10:14:53.885704
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x41", "A")) == "A"
    assert escape(re.match(r"\\x41", "\\x41")) == "\\x41"
    assert escape(re.match(r"\\x41", "\\x41Z")) == "\\x41Z"
    assert escape(re.match(r"\\x41", "\\x41Z")) == "\\x41Z"
    assert escape(re.match(r"\\x41", "\\x4Z1")) == "\\x4Z1"
    assert escape(re.match(r"\\x41", "\\x4Z1")) == "\\x4Z1"
    assert escape(re.match(r"\\x41", "\\x4Z1")) == "\\x4Z1"


# Generated at 2022-06-21 10:14:55.105235
# Unit test for function test
def test_test():
    assert evalString("'a'") == "a"

# Generated at 2022-06-21 10:14:57.971184
# Unit test for function evalString
def test_evalString():
    """
    >>> test_evalString()
    """
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-21 10:15:05.155153
# Unit test for function escape
def test_escape():
    from unittest import TestCase
    from typing import Dict, Text
    import sys

    class TestStringEscape(TestCase):
        def __init__(self, *args, **kwds):
            self.escape = escape
            super(TestStringEscape, self).__init__(*args, **kwds)


# Generated at 2022-06-21 10:15:07.761851
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x2a", "\\x2a")) == "*"

# Generated at 2022-06-21 10:15:08.426890
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:19.920918
# Unit test for function evalString
def test_evalString():
    # Simple cases
    assert evalString('"123"') == "123"
    assert evalString("'123'") == "123"
    # Edge cases
    assert evalString('"\\\'"') == "'"
    assert evalString("'\\\'\"'") == '"'
    # Empty string
    assert evalString('""') == ""
    assert evalString("''") == ""
    # Test escaping
    assert evalString(r'"\'"') == "'"
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r"'\"'") == '"'
    assert evalString(r'"\x20"') == " "
    assert evalString(r'"\040"') == " "

# Generated at 2022-06-21 10:15:32.837327
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'abc'") == 'abc'
    assert evalString(r"'a\\'bc'") == "a'bc"

# Generated at 2022-06-21 10:15:43.841489
# Unit test for function evalString
def test_evalString():
    from pytest import raises
    from .pysource import getsource
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'
    raises(ValueError, "evalString('abc')")
    raises(ValueError, "evalString('\"')")
    raises(ValueError, "evalString('\'')")
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\x"') == "x"
    assert evalString('"\\f"') == "\f"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\a"') == "\a"

# Generated at 2022-06-21 10:15:55.071355
# Unit test for function escape
def test_escape():
    result = escape(re.match(r"\\(a)", r"\a"))
    assert result == "ab"
    result = escape(re.match(r"\\(b)", r"\b"))
    assert result == "ab"
    result = escape(re.match(r"\\(f)", r"\f"))
    assert result == "af"
    result = escape(re.match(r"\\(n)", r"\n"))
    assert result == "an"
    result = escape(re.match(r"\\(r)", r"\r"))
    assert result == "ar"
    result = escape(re.match(r"\\(t)", r"\t"))
    assert result == "at"
    result = escape(re.match(r"\\(v)", r"\v"))

# Generated at 2022-06-21 10:16:20.471821
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:16:27.227510
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\[abfnrtv]", "\\a")) == "\a"
    assert escape(re.match(r"\\[abfnrtv]", "\\b")) == "\b"
    assert escape(re.match(r"\\[abfnrtv]", "\\f")) == "\f"
    assert escape(re.match(r"\\[abfnrtv]", "\\n")) == "\n"
    assert escape(re.match(r"\\[abfnrtv]", "\\r")) == "\r"
    assert escape(re.match(r"\\[abfnrtv]", "\\t")) == "\t"
    assert escape(re.match(r"\\[abfnrtv]", "\\v")) == "\v"

# Generated at 2022-06-21 10:16:28.420195
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-21 10:16:36.195030
# Unit test for function test
def test_test():  # noqa: D103
    check = evalString
    assert check('"\\a\\b\\f\\n\\r\\t\\v\\\'\\"\\\\"') == "\a\b\f\n\r\t\v\'\"\\"
    assert check('"\\a\\b\\f\\n\\r\\t\\v\\\'\\"\\\\"') == "\a\b\f\n\r\t\v\'\"\\"
    assert check(r"'\a\b\f\n\r\t\v\'\"\\'") == "\a\b\f\n\r\t\v\'\"\\"
    assert check(r"'\a\b\f\n\r\t\v\'\"\\'") == "\a\b\f\n\r\t\v\'\"\\"

# Generated at 2022-06-21 10:16:48.842817
# Unit test for function evalString
def test_evalString():
  assert evalString("''") == ''
  assert evalString('""') == ''
  assert evalString("'abc'") == 'abc'
  assert evalString("'abc\\ndef\\n'") == 'abc\ndef\n'
  assert evalString("'\\u1234'") == '\u1234'
  assert evalString("'\\uFFFF'") == '\uFFFF'

# Generated at 2022-06-21 10:16:58.312066
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\'")).strip() == r'\''
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\x45")).strip() == r'\x45'
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\x4a")).strip() == r'\x4a'

# Generated at 2022-06-21 10:16:59.164145
# Unit test for function escape
def test_escape():
    assert escape("\\x41") == "A"

# Generated at 2022-06-21 10:16:59.782499
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:00.939926
# Unit test for function test
def test_test():
    # Zero test to pass Travis CI
    pass

# Generated at 2022-06-21 10:17:08.811537
# Unit test for function escape
def test_escape():
    assert escape('0', '0') == '0'
    assert escape('\\a', 'a') == '\a'
    assert escape('\\b', 'b') == '\b'
    assert escape('\\f', 'f') == '\f'
    assert escape('\\n', 'n') == '\n'
    assert escape('\\r', 'r') == '\r'
    assert escape('\\t', 't') == '\t'
    assert escape('\\v', 'v') == '\v'
    assert escape('\\\'', '\'') == '\''
    assert escape('\\"', '"') == '"'
    assert escape('\\\\', '\\') == '\\'
    assert escape('\\x000', 'x000') == chr(0)
    assert escape('\\377', '377')

# Generated at 2022-06-21 10:18:08.216322
# Unit test for function evalString
def test_evalString():
    assert evalString("'''abc'''") == "abc"
    assert evalString('"""abc"""') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString('"\\\'abc"') == "'abc"
    assert evalString("'\\\"abc'") == '"abc'
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x5a'") == "Z"
    assert evalString("'\\x30'") == "0"


# Generated at 2022-06-21 10:18:09.012434
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-21 10:18:15.812421
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\xff"') == '\xff'
    assert evalString('"""\\x00"""') == '\x00'
    assert evalString(r'"\\ff"') == '\\ff'
    try:
        evalString('"\\x1"')
    except ValueError:
        pass
    else:
        print('Expected ValueError, got none')
    try:
        evalString('"\\777"')
    except ValueError:
        pass
    else:
        print('Expected ValueError, got none')
    try:
        evalString('"\\08"')
    except ValueError:
        pass
    else:
        print('Expected ValueError, got none')
    try:
        evalString('"\\18"')
    except ValueError:
        pass

# Generated at 2022-06-21 10:18:27.278298
# Unit test for function escape
def test_escape():
    import pytest
    assert escape(re.match('\\"', '"')) == '"'
    assert escape(re.match("\\'", "'")) == "'"
    assert escape(re.match("\\b", "b")) == "\b"
    assert escape(re.match("\\f", "f")) == "\f"
    assert escape(re.match("\\n", "n")) == "\n"
    assert escape(re.match("\\r", "r")) == "\r"
    assert escape(re.match("\\t", "t")) == "\t"
    assert escape(re.match("\\v", "v")) == "\v"
    assert escape(re.match("\\\\", "\\")) == "\\"
    assert escape(re.match("\\xFF", "xFF")) == 'ÿ'

# Generated at 2022-06-21 10:18:38.813992
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'a'") == 'a'
    assert evalString(r"'\n'") == '\n'
    assert evalString(r"'\t'") == '\t'
    assert evalString(r"'\''") == '\''
    assert evalString(r"'\"'") == '"'
    assert evalString(r"'\\'") == '\\'
    assert evalString(r"'\x41'") == 'A'
    assert evalString(r"'\077'") == '?'
    assert evalString(r"'\141'") == 'a'
    assert evalString(r"'''abc\ndef\n'ghi'\njkl'''") == "abc\ndef\n'ghi'\njkl"

# Generated at 2022-06-21 10:18:48.883141
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\a") == "\a"
    assert escape("\b") == "\b"
    assert escape("\f") == "\f"
    assert escape("\n") == "\n"
    assert escape("\r") == "\r"
    assert escape("\t") == "\t"
    assert escape("\v") == "\v"
    assert escape("\\\'") == "\'"
    assert escape("\\\'") == "\'"

# Generated at 2022-06-21 10:18:53.777030
# Unit test for function test
def test_test():
    import io
    import sys

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out
        test()
        output = out.getvalue().strip()
        sys.stdout = saved_stdout
    finally:
        sys.stdout = saved_stdout
    assert output == ""

# Generated at 2022-06-21 10:18:54.783217
# Unit test for function test
def test_test():
    assert True  # nopep8

# Generated at 2022-06-21 10:19:00.413664
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x79"') == chr(121)
    assert evalString("'\\x79'") == chr(121)
    assert evalString('"\\x5c"') == chr(92)
    assert evalString("'\\x5c'") == chr(92)
    assert evalString("'\\x79'") == chr(121)
    assert evalString("'\\072'") == chr(58)

# Generated at 2022-06-21 10:19:01.579104
# Unit test for function test
def test_test():
    test()