

# Generated at 2022-06-21 10:10:42.678534
# Unit test for function evalString
def test_evalString():
    x = evalString('"abc"')
    assert x == 'abc'
    x = evalString("'abc'")
    assert x == 'abc'
    x = evalString('"a\'b\'"')
    assert x == "a'b'"
    x = evalString('\'a\"b\"\'')
    assert x == 'a"b"'
    x = evalString('r"a\'b\"c\ndef\n"')
    assert x == "a\'b\"c\ndef\n"
    x = evalString('r\'a"b\'c\ndef\n\'')
    assert x == 'a"b\'c\ndef\n'
    x = evalString('"""he\'\\"ll\'o"""')
    assert x == "he\'\\\"ll\'o"
    x = eval

# Generated at 2022-06-21 10:10:48.795775
# Unit test for function test
def test_test():
    import StringIO
    import os

    old_stdout = os.sys.stdout
    os.sys.stdout = StringIO.StringIO()
    try:
        test()
        assert os.sys.stdout.getvalue() == ""
    finally:
        os.sys.stdout.close()
        os.sys.stdout = old_stdout


# Generated at 2022-06-21 10:10:57.960393
# Unit test for function escape
def test_escape():
    from pytest import raises

    # Test simple escapes
    for k, v in simple_escapes.items():
        s = '\\%s' % k
        assert escape(re.match(r'\\[%s]' % k, s)) == v

    # Test hex escape
    for i in range(16):
        for j in range(16):
            s = '\\x%x%x' % (i, j)
            c = chr(i * 16 + j)
            assert escape(re.match(r'\\x..', s)) == c

    # Test octal escape

# Generated at 2022-06-21 10:11:03.410616
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == "hello"
    assert evalString("'hello'") == "hello"
    assert evalString('"\t"') == "\t"
    assert evalString("'\t'") == "\t"
    assert evalString('"\\\t"') == "\\\t"
    assert evalString("'\\\t'") == "\\\t"

# Generated at 2022-06-21 10:11:10.785691
# Unit test for function evalString
def test_evalString():
    def check(s):
        assert evalString(s) == eval(s)

    check('""')
    check('"hi"')
    check('"\\\\"')
    check('"\\""')
    check("'hi'")
    check("'\\\\'")
    check("'\\''")

    check('"\\\\x00"')
    check('"\\x01"')
    check('"\\x0f"')
    check('"\\x10"')
    check('"\\x1f"')
    check('"\\x20"')
    check('"\\x7e"')
    check('"\\x7f"')
    check('"\\x80"')
    check('"\\xff"')
    check("'\\\\x00'")
    check("'\\x01'")
    check

# Generated at 2022-06-21 10:11:19.451363
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x00"') == "\x00"
    assert evalString("'\\x00'") == "\x00"
    assert evalString('"""\\x00""")') == "\x00"
    assert evalString("'''\\x00'''") == "\x00"
    assert evalString('"\\"') == '"'
    assert evalString("'\\''") == "'"
    assert evalString('"""\\"""') == '"'
    assert evalString("'''\\''''") == "'"
    assert evalString('"\\0"') == "\x00"
    assert evalString('"\\00"') == "\x00"
    assert evalString('"\\000"') == "\x00"
    print("Success!")

# Generated at 2022-06-21 10:11:30.422827
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([abfnrtv\'"\\]|x.{0,2}|[0-7]{1,3})', r'\x12')) == '\x12'
    assert escape(re.match(r'\\([abfnrtv\'"\\]|x.{0,2}|[0-7]{1,3})', r'\12')) == '\x0a'
    assert escape(re.match(r'\\([abfnrtv\'"\\]|x.{0,2}|[0-7]{1,3})', r'\012')) == '\x0a'

# Generated at 2022-06-21 10:11:34.420314
# Unit test for function test
def test_test():
    import builtins

    _print = builtins.print

    builtins.print = lambda *values, sep=None, end=None, file=None: None

    test()

    builtins.print = _print

# Generated at 2022-06-21 10:11:36.248620
# Unit test for function test
def test_test():
    e = evalString("'\a'")
    assert e != "'\a'"
    assert e == "\a"

# Generated at 2022-06-21 10:11:46.043791
# Unit test for function escape
def test_escape():
    # Ensure that escape function works correctly, even if the
    # literal string doesn't use the escapes.
    #
    # Each string below evaluates to the corresponding string
    # after the comment character.
    assert evalString("'''\\x00\\x41\\x42\\x43'") == "ABC"
    assert evalString("'''\\000\\101\\102\\103'") == "ABC"
    assert evalString("'''\\u0000\\u0041\\u0042\\u0043'") == "ABC"
    assert evalString("'''\\U00000000\\U00000041\\U00000042\\U00000043'") == "ABC"

    assert evalString('\"\"\"\\x00\\x41\\x42\\x43\"') == "ABC"

# Generated at 2022-06-21 10:11:59.291737
# Unit test for function escape
def test_escape():
    for escape_sequence, expected_char in simple_escapes.items():
        match = re.match(r'\\' + escape_sequence, "\\" + escape_sequence)  # type: Match[str]
        assert match is not None
        assert escape(match) == expected_char

    assert escape(re.match(r'\\x00', "\\x00")) == "\x00"

    assert escape(re.match(r'\\000', "\\000")) == "\x00"

# Generated at 2022-06-21 10:12:00.600423
# Unit test for function test
def test_test():
    pass


# Generated at 2022-06-21 10:12:01.210329
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:04.048618
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\x", "\\x12")) == "\\x12"
    assert escape(re.match(r"\\x", "\\\\x12")) == "\\\\x12"


# Generated at 2022-06-21 10:12:16.441605
# Unit test for function escape
def test_escape():
    test_cases = {
        "\\a": "\a",
        "\\b": "\b",
        "\\f": "\f",
        "\\n": "\n",
        "\\r": "\r",
        "\\t": "\t",
        "\\v": "\v",
        "\\'": "'",
        '\\"': '"',
        "\\\\": "\\",
        "\\x42": "B",
        "\\x4a": "J",
        "\\x2": "",
        "\\x": "",
        "\\0123": "S",
        "\\01": "\x01",
        "\\0": "\x00",
        "\\1": "",
    }

    for case in test_cases:
        assert escape(case) == test_cases[case]

# Generated at 2022-06-21 10:12:29.176312
# Unit test for function evalString
def test_evalString():
    assert evalString('"') == ""
    assert evalString('""') == ""
    assert evalString('"""') == ""
    assert evalString('"b"') == "b"
    assert evalString('"\\b"') == "\b"
    assert evalString("'\\b'") == "\b"
    assert evalString('"\\x61"') == "a"
    assert evalString('"\\x61\\x61"') == "aa"
    assert evalString('"\\x100"') == "\u0100"
    assert evalString(r"'\x100'") == "\u0100"

# Generated at 2022-06-21 10:12:40.436917
# Unit test for function escape
def test_escape():
    import sys, io
    import pytest
    
    # No need to be exhaustive

# Generated at 2022-06-21 10:12:51.460904
# Unit test for function evalString
def test_evalString():
    '''Test that all names in the string module are present in the __all__
    global.
    '''

    assert evalString(r'a "b" \'c\'') == 'a "b" \'c\''
    assert evalString(r'a "b" \'c\'') == 'a "b" \'c\''
    assert evalString(r'a "b\"c" \'d\\e\'') == 'a "b\"c" \'d\\e\''
    assert evalString(r"a \097'b\'c' d\x65 f\\g \h\i") == "a a'b'c d\x65 f\\g i"
    assert evalString(r"a\0b\nc\td\be\rf") == "a\0b\nc\td\be\rf"
   

# Generated at 2022-06-21 10:13:02.996730
# Unit test for function escape
def test_escape():
    # simple escapes
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\x1e", "\\x1e")) == "\x1e"

    # Unicode escapes: the first letter represents the number of hex digits in
    # the second half of the escape
    assert escape(re.match(r"\\u007f", "\\u007f")) == "\\x7f"
    assert escape(re.match(r"\\u00ff", "\\u00ff")) == "\\xff"
    assert escape(re.match(r"\\u0fff", "\\u0fff")) == "\\xfff"
    assert escape(re.match(r"\\uffff", "\\uffff")) == "\\xffff"
    # mixed case

# Generated at 2022-06-21 10:13:13.257794
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\a')) == '\a'
    assert escape(re.search(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\b')) == '\b'
    assert escape(re.search(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\f')) == '\f'
    assert escape(re.search(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\n')) == '\n'

# Generated at 2022-06-21 10:13:30.097245
# Unit test for function escape
def test_escape():
    assert escape('\\"') == '"'
    assert escape('\\\'') == '\''
    assert escape('\\\'') == '\''
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\t') == '\t'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\v') == '\v'

    # utf-8 encoded characters
    assert escape('\\x61') == 'a'
    assert escape('\\x80') == '\u0080'

    # utf-8 two-byte characters
    assert escape('\\xc2\\x80') == '\u0080'

    # utf-8 three-byte characters

# Generated at 2022-06-21 10:13:33.073408
# Unit test for function escape
def test_escape():
    m = escape(re.match(r'\\x31', '\\x31'))
    assert m == '1'
    m = escape(re.match(r'\\141', '\\141'))
    assert m == 'a'

# Generated at 2022-06-21 10:13:35.785472
# Unit test for function escape
def test_escape():
    assert '\\' == escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\\\'))


# Generated at 2022-06-21 10:13:36.422622
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:49.008473
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")).__eq__("'")
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\"")).__eq__("\"")
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")).__eq__("\a")

# Generated at 2022-06-21 10:13:59.002676
# Unit test for function evalString
def test_evalString():
    # There is a special-case for '' (see issue #25285)
    assert evalString("''") == ""
    assert evalString('''"'\\""''') == '"\\"'
    assert evalString('''"'\\'a'"''') == "'''a'"
    assert evalString("'\\''") == "'"
    assert evalString(r"'a\nb'") == 'a\nb'
    assert evalString(r"'a\0b'") == 'a\0b'
    assert evalString(r"'\r\n'") == '\r\n'
    assert evalString(r'"\r\n"') == '\r\n'
    assert evalString('"\\""') == '"'
    assert evalString('"\\"\\\\"') == '"\\'

# Generated at 2022-06-21 10:14:04.758181
# Unit test for function escape

# Generated at 2022-06-21 10:14:14.493196
# Unit test for function escape
def test_escape():
    assert escape("\a") == "\\a"
    assert escape("\b") == "\\b"
    assert escape("\f") == "\\f"
    assert escape("\n") == "\\n"
    assert escape("\r") == "\\r"
    assert escape("\t") == "\\t"
    assert escape("\v") == "\\v"
    assert escape("\"") == "\\\""
    assert escape("'") == "\\'"
    assert escape("\\") == "\\\\"
    assert escape(chr(0)) == "\\x00"
    assert escape(chr(1)) == "\\x01"
    assert escape(chr(2)) == "\\x02"
    assert escape(chr(14)) == "\\x0e"
    assert escape(chr(15))

# Generated at 2022-06-21 10:14:15.438419
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:16.395053
# Unit test for function test
def test_test():
    # Tests that test does not raise any errors
    test()

# Generated at 2022-06-21 10:14:38.860647
# Unit test for function escape
def test_escape():
    assert escape("\a") == "\\a"
    assert escape("\b") == "\\b"
    assert escape("\f") == "\\f"
    assert escape("\n") == "\\n"
    assert escape("\r") == "\\r"
    assert escape("\t") == "\\t"
    assert escape("\v") == "\\v"
    assert escape("'") == "\\'"
    assert escape('"') == '\\"'
    assert escape("\\") == "\\\\"
    assert escape("\x7f") == "\\x7f"
    assert escape("\x80") == "\\x80"
    assert escape("\xFF") == "\\xFF"
    assert escape("\x0a") == "\\x0a"

# Generated at 2022-06-21 10:14:40.535031
# Unit test for function test
def test_test():
    test()
    assert True

# Unit tests for function evalString

# Generated at 2022-06-21 10:14:41.110072
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:53.400288
# Unit test for function evalString
def test_evalString():
    test_values = [("'\\'", '\''),
                   ('"\\\\\\"\\b\\f\\n\\r\\t\\v\\x1b"', '\\"!\b\f\n\r\t\v\x1b'),
                   ('"\\\' \\\\\\\'"', "' \\'"),
                   ('\'"\\\' \\\\\\\'"', '"\\\' \\\\\\\''),
                   ('"""\\\' \\\\\\\'""""', '"""\\\' \\\\\\\'"""'),
                   ('"""\\\' \\\\\\\'"""""', '"""\\\' \\\\\\\'"""'),
                   ('"""\\\' \\\\\\\'"""""', '"""\\\' \\\\\\\'"""')]
    for code_string, output in test_values:
        assert evalString(code_string) == output


test_evalString()

# Generated at 2022-06-21 10:15:02.296551
# Unit test for function evalString
def test_evalString():
    # Test simple escapes
    check("'\\a'", "\a")
    check("'\\b'", "\b")
    check("'\\f'", "\f")
    check("'\\n'", "\n")
    check("'\\r'", "\r")
    check("'\\t'", "\t")
    check("'\\v'", "\v")
    check("'\\\''", "'")
    check("'\\\"'", '"')
    check("'\\\\'", "\\")
    # Test hex escapes
    check("'\\xff'", "\xff")
    check("'\\x0a'", "\n")
    check("'\\x00'", "\x00")
    check("'\\xFF'", "\xFF")
    check("'\\x10'", "\x10")
   

# Generated at 2022-06-21 10:15:09.047468
# Unit test for function test
def test_test():
    # The function test prints output
    # which we don't want in a unit test
    # so we capture output on stdout
    import sys
    from io import StringIO
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        test()
        output = out.getvalue().strip()
        assert output == '', output
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-21 10:15:10.223667
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:20.977545
# Unit test for function escape
def test_escape():
    print(escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")))
    print(escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\123")))
    print(escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x45")))
    print(escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")))

# Generated at 2022-06-21 10:15:23.021951
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:34.028958
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("'\\x00'") == "\0"
    assert evalString("'\\''") == "'"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\\"'") == '"'
    assert evalString("'\\a'") == "\x07"
    assert evalString("'\\b'") == "\x08"
    assert evalString("'\\f'") == "\x0c"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\x0b"
    assert evalString("'\\101'") == "\101"

# Generated at 2022-06-21 10:16:14.627360
# Unit test for function escape
def test_escape():
    m = re.compile("\\x41").search("\\x41")
    assert escape(m) == "A"

    m = re.compile("\\12").search("\\12")
    assert escape(m) == "\x0a"

# Generated at 2022-06-21 10:16:15.284288
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:16:16.023994
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:16:21.821307
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\['\"\\abfnrtv]", r"\'")).strip() == "\'"
    assert escape(re.match(r"\\x.{0,2}", r"\x45")).strip() == "E"
    assert escape(re.match(r"\\[0-7]{1,3}", r"\0")).strip() == "\x00"



# Generated at 2022-06-21 10:16:32.226588
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\'", r"\'")) == "'"
    assert escape(re.search(r"\\\"", r'\"')) == '"'
    assert escape(re.search(r"\\\\", r"\\")) == "\\"
    assert escape(re.search(r"\\a", r"\a")) == "\a"
    assert escape(re.search(r"\\b", r"\b")) == "\b"
    assert escape(re.search(r"\\f", r"\f")) == "\f"
    assert escape(re.search(r"\\n", r"\n")) == "\n"
    assert escape(re.search(r"\\r", r"\r")) == "\r"
    assert escape(re.search(r"\\t", r"\t"))

# Generated at 2022-06-21 10:16:44.274479
# Unit test for function escape
def test_escape():
    r = re.compile(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})")
    a = r.search("\\a")
    assert escape(a).__eq__("\a"), "error \\a"

    b = r.search("\\b")
    assert escape(b).__eq__("\b"), "error \\b"

    f = r.search("\\f")
    assert escape(f).__eq__("\f"), "error \\f"

    n = r.search("\\n")
    assert escape(n).__eq__("\n"), "error \\n"

    rr = r.search("\\r")
    assert escape(rr).__eq__("\r"), "error \\r"


# Generated at 2022-06-21 10:16:51.211487
# Unit test for function evalString
def test_evalString():
    assert evalString('"hello"') == "hello"
    assert evalString("'hello'") == "hello"
    assert evalString('"hello\\n"') == "hello\\n"
    assert evalString("'hello\\n'") == "hello\\n"
    assert evalString('"hello\\t"') == "hello\\t"
    assert evalString("'hello\\t'") == "hello\\t"

# Generated at 2022-06-21 10:16:52.612019
# Unit test for function test
def test_test():
    expected = None
    assert expected == test()


# Generated at 2022-06-21 10:17:00.616057
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x01\\x02"') == "\x01\x02"
    assert evalString('"\\x00\\x00"') == "\x00\x00"
    assert evalString('"\\x10\\x10"') == "\x10\x10"
    assert evalString('"\\x10\\x00"') == "\x10\x00"
    assert evalString('"\\x10\\x00\\x00"') == "\x10\x00\x00"
    assert evalString('"\\x10\\x00\\x00\\x10"') == "\x10\x00\x00\x10"
    assert evalString('"\\x00\\x10\\x00\\x10"') == "\x00\x10\x00\x10"

# Generated at 2022-06-21 10:17:01.182759
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:54.214401
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x", "x")) == 'x'
    assert escape(re.match(r"\\a", "a")) == '\a'

# Generated at 2022-06-21 10:18:00.792043
# Unit test for function evalString
def test_evalString():
    # Test for normal cases
    assert evalString("'a'") == "a"
    assert evalString("'abc'") == "abc"
    assert evalString("'  abc  '") == "  abc  "
    assert evalString("'\\x41\\x42\\x43'") == "ABC"
    assert evalString("'\\141\\142\\143'") == "abc"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString('"\\\'"') == '"\\\'"'
    assert evalString("'\\\\\\''") == "\\'"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\''") == "'"
    assert evalString

# Generated at 2022-06-21 10:18:02.083332
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert False, "test failed!"

# Generated at 2022-06-21 10:18:10.900464
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString("'a\"bc'") == 'a"bc'
    assert evalString('"a\'bc"') == "a'bc"
    assert evalString('"a\\\nbc"') == "abc"
    assert evalString("'a\\\\bc'") == r"a\\bc"
    assert evalString(r"'a\\\"bc'") == r'a\"bc'
    assert evalString(r'"a\\\'bc"') == r"a\'bc"
    assert evalString(r'"\\"') == r'\\'

    raises(ValueError, evalString, r'"\\x"')
    raises(ValueError, evalString, r'"\9"')

# Generated at 2022-06-21 10:18:22.643570
# Unit test for function evalString
def test_evalString():
    assert evalString('hello') == 'hello'
    assert evalString('"hello"') == 'hello'
    assert evalString("'hello'") == 'hello'
    assert evalString(r'"hi there\""') == 'hi there"'
    assert evalString('"\\x62"') == 'b'
    assert evalString('"\\66"') == 'b'
    assert evalString('"\\062"') == 'b'
    assert evalString("'\\062'") == 'b'
    # from test_evalString issue 2683
    assert evalString(r'"\u2026"') == u"\u2026"
    assert evalString(r'"\U00010348"') == u"\U00010348"

# Generated at 2022-06-21 10:18:32.302937
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"

    # Test for invalid escape sequences
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"

# Generated at 2022-06-21 10:18:42.508609
# Unit test for function escape
def test_escape(): 
    assert escape("\\0") == "\x00"
    assert escape("\\01") == "\x01"
    assert escape("\\012") == "\x0a"
    assert escape("\\07777") == "\xff"
    assert escape("\\377") == "\xff"
    assert escape("\\xb") == "\x0b"
    assert escape("\\xb1") == "\xb1"
    assert escape("\\x0") == "\x00"
    assert escape("\\x00") == "\x00"
    assert escape("\\xbc") == "\xbc"
    assert escape("\\xbcde") == "\xbc"
    assert escape("\\xBcDe") == "\xbc"
    assert escape("\\x1bc") == "\x1b"
    assert escape("\\x1bcde") == "\x1b"

# Generated at 2022-06-21 10:18:43.178941
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:18:53.730091
# Unit test for function escape
def test_escape():

    # Test escaping of octal, hexadecimal, and special characters
    assert escape(re.match(r"\\([0-9a-fA-F]+)", r"\00ff")) == chr(255)
    assert escape(re.match(r"\\([0-7]+)", r"\077")) == chr(63)
    assert escape(re.match(r"\\([abfnrtv]+)", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv]+)", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv]+)", r"\f")) == "\f"

# Generated at 2022-06-21 10:18:54.384415
# Unit test for function test
def test_test():
    test()