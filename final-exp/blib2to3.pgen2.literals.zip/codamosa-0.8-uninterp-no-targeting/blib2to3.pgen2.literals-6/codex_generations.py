

# Generated at 2022-06-21 10:10:37.251832
# Unit test for function escape
def test_escape():
    escape1 = "\\x41"
    escape2 = "\\x213"
    escape3 = "\\x5"
    escape4 = "\\x2q3"
    escape5 = "\\x12z3"

    m1 = re.match(r"\\(x.{1,2})", escape1).group(1)
    m2 = re.match(r"\\(x.{1,2})", escape2).group(1)
    m3 = re.match(r"\\(x.{1,2})", escape3).group(1)
    m4 = re.match(r"\\(x.{1,2})", escape4).group(1)
    m5 = re.match(r"\\(x.{1,2})", escape5).group(1)


# Generated at 2022-06-21 10:10:40.656531
# Unit test for function escape
def test_escape():
    """Test the function escape

    Args:
        None

    Returns:
        Nothing
    """

    # Is the function callable?
    assert callable(escape)

# Generated at 2022-06-21 10:10:41.263135
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:10:41.841421
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:10:54.367172
# Unit test for function evalString
def test_evalString():
    print("Running test_evalString...")
    assert evalString(r'"a"') == 'a'
    assert evalString(r"'a'") == 'a'
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\"'") == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r"'" + "\\" * 100 + r"'") == "\\" * 100
    assert evalString(r"'" + "\\" * 99 + r"a" + "\\" * 100 + r"'") == "\\" * 99 + "a" + "\\" * 100
    assert evalString(r"'" + "\\" * 101 + "a" + "\\" * 100 + "'") == "\\" * 100 + "a" + "\\" * 100
   

# Generated at 2022-06-21 10:11:01.844325
# Unit test for function evalString
def test_evalString():

    # Test valid strings
    # Test single quote strings
    assert evalString("''") == ""
    assert evalString("'abcdefg'") == "abcdefg"
    assert evalString("'\\''") == "'"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\141'") == "a"
    assert evalString("'\\077'") == "?"
    assert evalString("'\\41'") == "!"
    assert evalString("'aaa\\'aaa'") == "aaa'aaa"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"

# Generated at 2022-06-21 10:11:05.448887
# Unit test for function test
def test_test():
    """
    Verfies that the evalString function works for every ascii character
    """
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, i

# Generated at 2022-06-21 10:11:08.738766
# Unit test for function evalString
def test_evalString():
    assert evalString('"text"') == 'text'
    assert evalString("'text'") == 'text'
    assert evalString("'text \\n text'") == 'text \n text'


# Unit tests for function evalInt

# Generated at 2022-06-21 10:11:18.983120
# Unit test for function evalString
def test_evalString():
    # This code example is from the Rietveld code review tool,
    # http://codereview.appspot.com/23741
    import unittest

    class TestEvalString(unittest.TestCase):
        def test_evalString(self):
            self.assertEqual(evalString('"ab\\ncd\\x20efg"\n'), "ab\ncd\x20efg")
            self.assertEqual(evalString('"ab\\tcd\\x20efg"\n'), "ab\tcd\x20efg")
            self.assertEqual(evalString('"ab\\cd\\x20efg"\n'), "abcd\x20efg")

# Generated at 2022-06-21 10:11:30.304916
# Unit test for function escape
def test_escape():

    import io
    import unittest

    # Test that escape() properly raises exceptions for invalid escapes.
    class EscapeTest(unittest.TestCase):
        def test_valid(self) -> None:
            self.assertEqual(escape(io.StringIO("\\a").match("\\a")), "\a")
            self.assertEqual(escape(io.StringIO("\\b").match("\\b")), "\b")
            self.assertEqual(escape(io.StringIO("\\f").match("\\f")), "\f")
            self.assertEqual(escape(io.StringIO("\\n").match("\\n")), "\n")
            self.assertEqual(escape(io.StringIO("\\r").match("\\r")), "\r")

# Generated at 2022-06-21 10:12:01.601785
# Unit test for function evalString

# Generated at 2022-06-21 10:12:08.185354
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\t\\n"') == "\t\n"
    # Broken by Python 3.7.0
    assert evalString("'\\u03B1'") == "\u03B1"
    assert evalString("'\\U000003B1'") == "\u03B1"

# Generated at 2022-06-21 10:12:20.682450
# Unit test for function escape
def test_escape():
    result = escape(re.match('\\x01', '\\x01'))
    assert result == '\x01'
    result = escape(re.match('\\012', '\\012'))
    assert result == '\n'
    result = escape(re.match('\\a', '\\a'))
    assert result == '\x07'
    result = escape(re.match('\\b', '\\b'))
    assert result == '\x08'
    result = escape(re.match('\\f', '\\f'))
    assert result == '\x0c'
    result = escape(re.match('\\n', '\\n'))
    assert result == '\n'
    result = escape(re.match('\\r', '\\r'))
    assert result == '\r'

# Generated at 2022-06-21 10:12:31.842586
# Unit test for function escape
def test_escape():
    from unittest import TestCase

    class MyTest(TestCase):
        def setUp(self):
            self._valid_escapes = {
                "a": "\a",
                "b": "\b",
                "f": "\f",
                "n": "\n",
                "r": "\r",
                "t": "\t",
                "v": "\v",
                "'": "'",
                '"': '"',
                "\\": "\\",
                "x0A": "\n",
                "012": "\n",
            }
            self._invalid_escapes = ("x", "X0a", "x0", "0x0A", "0x41")

# Generated at 2022-06-21 10:12:42.287903
# Unit test for function evalString
def test_evalString():
    assert evalString("'a\\nb'") == "a\\nb"
    assert evalString("'\\x61\\n\\x62'") == "a\\nb"
    assert evalString("'a\\n\\02b'") == "a\\n\x02b"
    assert evalString("'a\\n\\01b'") == "a\\n\x01b"
    assert evalString("'a\\n\\021b'") == "a\\n\x11b"
    assert evalString("'a\\n\\x21b'") == "a\\n\x21b"
    assert evalString("'''a\\nb'") == "a\\nb"
    assert evalString('"""a\\nb"') == "a\\nb"

    # valid hex escapes

# Generated at 2022-06-21 10:12:53.457261
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString('""') == ""
    assert evalString("'single quote'") == "single quote"
    assert evalString('"double quote"') == "double quote"
    assert evalString("'double quote \"inside quote\"'") == 'double quote "inside quote"'
    assert evalString('"single quote \'inside quote\'"') == "single quote 'inside quote'"
    assert evalString("""'it\'s a "tricky" string'""") == "it's a \"tricky\" string"
    assert evalString("""'it\'s another "tricky" string'""") == "it's another \"tricky\" string"
    assert evalString("'too few quotes'") == "too few quotes"
    assert evalString('"too few quotes"') == "too few quotes"
    assert eval

# Generated at 2022-06-21 10:13:05.756438
# Unit test for function escape
def test_escape():

    assert escape(re.match(r'\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\a')) == '\a'
    assert escape(re.match(r'\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\b')) == '\b'
    assert escape(re.match(r'\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\f')) == '\f'
    assert escape(re.match(r'\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\n')) == '\n'

# Generated at 2022-06-21 10:13:14.712420
# Unit test for function escape
def test_escape():
    # test escaping
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"

# Generated at 2022-06-21 10:13:26.467300
# Unit test for function escape
def test_escape():
    # function escape should handle \x escapes and octal escapes
    assert escape("\\x41") == "\x41"
    assert escape("\\0a1") == "\n"
    assert escape("\\0") == "\x00"
    assert escape("\\01") == "\x01"
    assert escape("\\02") == "\x02"
    assert escape("\\03") == "\x03"
    assert escape("\\04") == "\x04"
    assert escape("\\05") == "\x05"
    assert escape("\\06") == "\x06"
    assert escape("\\07") == "\x07"
    # function escape should handle string literals that start and end with
    # single quotes
    assert evalString("'''abc'''") == "abc"
    assert evalString("'abc'") == "abc"
    assert eval

# Generated at 2022-06-21 10:13:35.606342
# Unit test for function escape
def test_escape():
    # Test simple escapes
    for i, c in enumerate("\a\b\f\n\r\t\v''\"\"\\"):
        m = escape(re.match(r"\\[abfnrtv'\"\\]", "\\" + "abfnrtv'\"\\"[i]))
        assert m == c

    # Test hex escapes
    assert escape(re.match("\\\\x", "\\x")) == "\\x"
    assert escape(re.match("\\\\xz", "\\xz")) == "\\xz"
    assert escape(re.match("\\\\xz", "\\xz")) == "\\xz"
    assert escape(re.match("\\\\x0", "\\x0")) == "\x00"

# Generated at 2022-06-21 10:14:00.625226
# Unit test for function escape
def test_escape():
    assert escape('\n') == '\n'
    assert escape('\t') == '\t'
    assert escape('\'') == '\''
    assert escape('\"') == '\"'
    assert escape('\\') == '\\'
    assert escape('\0') == '\x00'
    #assert escape('\01') == '\x01' #Incompatible types in assignment
    #assert escape('\012') == '\n'
    #assert escape('\40') == ' '
    #assert escape('\100') == '@' #Incompatible types in assignment
    #assert escape('\141') == 'a'
    #assert escape('\x41') == 'A'
    #assert escape('\u1234') == '\u1234'
    #assert escape('\U00010111') == '\

# Generated at 2022-06-21 10:14:05.932762
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\n"') == "\n"
    assert evalString("'ab\\r'") == "ab\r"
    assert evalString('"\\xf9"') == chr(0xf9)

# Generated at 2022-06-21 10:14:15.225205
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(')", r"\\'")) == r"\'"
    assert escape(re.match(r"\\(')", r"\\'")) == r"\'"
    assert escape(re.match(r"\\(')", r"\\'")) == r"\'"
    assert escape(re.match(r"\\(')", r"\\'")) == r"\'"
    assert escape(re.match(r"\\(')", r"\\'")) == r"\'"
    assert escape(re.match(r"\\(')", r"\\'")) == r"\'"
    assert escape(re.match(r"\\(')", r"\\'")) == r"\'"
    assert escape(re.match(r"\\(')", r"\\'")) == r"\'"

# Generated at 2022-06-21 10:14:22.350728
# Unit test for function evalString
def test_evalString():
    assert evalString("'asdf'") == "asdf"
    assert evalString('"asdf"') == "asdf"
    assert evalString("'\\t\\n'") == "\t\n"
    assert evalString(r"'as\'df'") == "as'df"
    assert evalString(r"'as\"df'") == "as\"df"
    assert evalString('"as\'df"') == "as'df"
    assert evalString('"as\"df"') == 'as"df'

# Generated at 2022-06-21 10:14:33.371118
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString('""') == ""
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\''") == "'"

# Generated at 2022-06-21 10:14:37.726322
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\1") == "\1"
    assert escape("\\x61") == "a"
    assert escape("\\127") == "\127"
    assert escape("\\x7f") == "\x7F"

    raises(ValueError, escape, "\\x7")



# Generated at 2022-06-21 10:14:38.515217
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:41.197161
# Unit test for function escape
def test_escape():
    # raises error if given an incomplete octal
    try:
        escape(re.search(r"m", "\x01"))
    except ValueError:
        pass

# Generated at 2022-06-21 10:14:53.488244
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape

# Generated at 2022-06-21 10:15:02.360691
# Unit test for function escape
def test_escape():
    from io import StringIO
    import sys

    # Capture stderr to check for exception
    old_stderr = sys.stderr
    sys.stderr = my_stderr = StringIO()

    # Test escapes
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"

# Generated at 2022-06-21 10:15:34.776207
# Unit test for function test
def test_test():
    import io
    import sys
    import unittest

    save_stderr = sys.stderr
    try:
        sys.stderr = errors = io.StringIO()
        test()
    finally:
        sys.stderr = save_stderr

    count = 0
    for line in errors.getvalue().splitlines():
        if "\\x" in line:
            count += 1
    assert count == 0
    assert errors.getvalue() == ""



# Generated at 2022-06-21 10:15:37.341350
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\\'\\\"\\\\"') == "\a\b\f\n\r\t\v\'\"\\"

# Generated at 2022-06-21 10:15:49.575579
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\x34", "\\x34")) == "\x34"
    assert escape(re.match(r"\\x56", "\\x56")) == "\x56"
    assert escape(re.match(r"\\x78", "\\x78")) == "\x78"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r"\\\"", "\\\"")) == '"'
    assert escape(re.match(r"\\\n", "\\\n")) == "\n"

# Generated at 2022-06-21 10:15:58.825301
# Unit test for function evalString
def test_evalString():
    assert evalString('"\u00A9"') == '\u00A9'
    assert evalString('"\\"') == '"'
    assert evalString('"foo"') == 'foo'
    assert evalString('"foo\\nbar"') == 'foo\nbar'
    assert evalString('"foo\\vbar"') == 'foo\vbar'
    assert evalString('"foo\\rbar"') == 'foo\rbar'
    assert evalString('"foo\\tbar"') == 'foo\tbar'
    assert evalString('"foo\\fbar"') == 'foo\fbar'
    assert evalString('"foo\\bbar"') == 'foo\bbar'
    assert evalString('"foo\\"bar"') == 'foo"bar'
    assert evalString('"foo\\\\bar"')

# Generated at 2022-06-21 10:15:59.519460
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:16:11.875036
# Unit test for function test
def test_test():
    expected = (
        "65 A 'A' A\n"
        "94 ^ '^' ^\n"
        '97 a "\'" \'\n'
        '98 b "\'" \'\n'
        '102 f "\'" \'\n'
        '110 n "\'" \'\n'
        '114 r "\'" \'\n'
        '116 t "\'" \'\n'
        '118 v "\'" \'\n'
        '39 \' "\'" \'\n'
        '34 " "\'" \'\n'
        '92 \\ "\'" \\\n'
    )

    from StringIO import StringIO
    import sys


# Generated at 2022-06-21 10:16:19.151079
# Unit test for function evalString
def test_evalString():

    assert evalString(r""""aaa\"aaa" """) == "aaa\"aaa"
    assert evalString(r""" "aaa\\aaa" """) == "aaa\\aaa"
    assert evalString(r""" 'aaa\\\'aaa' """) == "aaa\\\'aaa"
    assert evalString(r"""'\n'""") == "\n"
    assert evalString(r""" '\\n' """) == "\\n"
    assert evalString(r""" '\n' """) == "\n"
    assert evalString(r""" '\\a' """) == "\\a"
    assert evalString(r""" '\\\n' """) == "\\\n"
    assert evalString(r""" '\t' """) == "\t"
    assert evalString(r""" '\\0' """) == "\0"
    assert eval

# Generated at 2022-06-21 10:16:26.535453
# Unit test for function evalString
def test_evalString():

    assert evalString('"abc"') == "abc", "evalString('\"abc\"') != \"abc\""
    assert evalString("'abc'") == "abc", "evalString(\"'abc'\") != \"abc\""

    assert evalString("'\\\\'") == "\\", "evalString('\"\\\\\"') != \"\\\""
    assert evalString('"\\\\"') == "\\", "evalString(\"'\\\\'\") != \"\\\""

    assert evalString("'ab\\'c'") == "ab'c", "evalString('\"ab\\\'c\"') != \"ab\'c\""
    assert evalString('"ab\\"c"') == 'ab"c', 'evalString(\"\'ab\\\"c\'\") != \"ab\"c\"'


# Generated at 2022-06-21 10:16:35.425308
# Unit test for function escape
def test_escape():
    assert escape('\n') == '\\\n'
    assert escape('\r') == '\\\r'
    assert escape('\t') == '\\\t'
    assert escape('\\') == '\\\\'
    assert escape('\"') == '\\\"'
    assert escape('\'') == '\\\''

# Generated at 2022-06-21 10:16:36.053490
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:31.380502
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        assert False, "test() raises exception"

# Generated at 2022-06-21 10:17:43.465086
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello \\'world\\''") == "hello 'world'", evalString("'hello \\'world\\''")
    assert (
        evalString("'hello \\'world\\''") == "hello 'world'",
        evalString("'hello \\'world\\''"),
    )
    assert evalString("'hello \\'world\\''") == "hello 'world'"
    assert evalString('"hello \'world\' "') == "hello 'world' ", evalString('"hello \'world\' "')
    assert (
        evalString('"hello \'world\' "') == "hello 'world' ",
        evalString('"hello \'world\' "'),
    )
    assert evalString('"hello \'world\' "') == "hello 'world' "

# Generated at 2022-06-21 10:17:54.215364
# Unit test for function escape
def test_escape():
    import pytest
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x05")
    assert evalString(escape(m)) == chr(0x05)
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\125")
    assert evalString(escape(m)) == chr(0x25)
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")
    assert evalString(escape(m)) == "\a"

# Generated at 2022-06-21 10:18:00.813810
# Unit test for function evalString
def test_evalString():
    def _test_evalString(s, expect):
        s2 = evalString(s)
        assert s2 == expect, "evalString(%s) = %s; want %s" % (s, s2, expect)

    _test_evalString('"abc"', "abc")
    _test_evalString("'abc'", "abc")
    _test_evalString('"\'"', "'")
    _test_evalString("'\"'", '"')
    _test_evalString('"\\"', '\\')
    _test_evalString("'\\'", '\\')
    _test_evalString('"\\\\"', '\\\\')
    _test_evalString("'\\\\'", '\\\\')

# Generated at 2022-06-21 10:18:09.567449
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\a")) == r"\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\b")) == r"\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r"\f")) == r"\f"

# Generated at 2022-06-21 10:18:14.441525
# Unit test for function escape
def test_escape():

    # If a character is matched
    def test_escape_valid_char():
        s = "hello"
        e = "\\e"
        result = escape(re.search(r"\\[a-z]", e))

        assert result == "e"

    # If no character is matched
    def test_escape_invalid_char():
        s = "hello"
        e = "\\"
        result = escape(re.search(r"\\[a-z]", e))

        assert result is None



# Generated at 2022-06-21 10:18:25.716793
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\[^]", "\\a")) == "\a"
    assert escape(re.match(r"\\[^]", "\\b")) == "\b"
    assert escape(re.match(r"\\[^]", "\\t")) == "\t"
    assert escape(re.match(r"\\[^]", "\\n")) == "\n"
    assert escape(re.match(r"\\[^]", "\\v")) == "\v"
    assert escape(re.match(r"\\[^]", "\\f")) == "\f"
    assert escape(re.match(r"\\[^]", "\\r")) == "\r"
    assert escape(re.match(r"\\[^]", "\\")) == "\\"

# Generated at 2022-06-21 10:18:34.493428
# Unit test for function evalString
def test_evalString():
    from io import StringIO
    from tokenize import generate_tokens
    from typing import Dict, List, Tuple
    from unittest.mock import Mock, patch
    from .token import STRING

    def tokenize(
        src: Text,
    ) -> List[Tuple[int, Text, Tuple[int, int], Tuple[int, int], Text]]:
        buf = StringIO(src)
        tokens = generate_tokens(buf.readline)
        return list(tokens)


# Generated at 2022-06-21 10:18:43.295407
# Unit test for function escape
def test_escape():
    # Single character
    assert escape(re.match(r"^\\'$", "\\'")) == "'"
    assert escape(re.match(r'^\\"$', '\\"')) == '"'
    assert escape(re.match(r"^\\\\$", "\\\\")) == "\\"
    assert escape(re.match(r"^\\a$", "\\a")) == chr(7)
    assert escape(re.match(r"^\\b$", "\\b")) == '\b'
    assert escape(re.match(r"^\\f$", "\\f")) == '\f'
    assert escape(re.match(r"^\\n$", "\\n")) == '\n'
    assert escape(re.match(r"^\\r$", "\\r")) == '\r'


# Generated at 2022-06-21 10:18:44.210037
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\x12", "\\x12")) == "\x12"