

# Generated at 2022-06-21 10:10:47.337376
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\U00000060"') == '`'
    assert evalString(r'"\U0001D4E0"') == '\U0001D4E0'
    assert evalString(r'"\u0060"') == '`'
    assert evalString(r'"\u1d4e0"') == '\U0001d4e0'
    assert evalString(r"'\U00000060'") == '`'
    assert evalString(r"'\U0001D4E0'") == '\U0001D4E0'
    assert evalString(r"'\u0060'") == '`'
    assert evalString(r"'\u1d4e0'") == '\U0001d4e0'
    assert evalString(r"\xff") == '\xff'
    assert eval

# Generated at 2022-06-21 10:10:54.927997
# Unit test for function evalString
def test_evalString():

    import ast
    import random
    import string

    for _ in range(100):
        n = random.randint(2,100)
        s = ''.join(random.choice(string.printable) for _ in range(n))
        q = random.choice(['"','\''])

        if s.find(q) != -1: continue

        assert evalString(q + s + q) == ast.literal_eval(q + s + q)

# Generated at 2022-06-21 10:10:55.843565
# Unit test for function test
def test_test():
    """Test to run test function"""
    test()

# Generated at 2022-06-21 10:10:59.180573
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\r"') == "\r"
    assert evalString("'\\r'") == "\r"

# Generated at 2022-06-21 10:10:59.927218
# Unit test for function test
def test_test():
    test()
    # assert test() == None

# Generated at 2022-06-21 10:11:02.095023
# Unit test for function escape
def test_escape():
    assert escape('\\x00') == '\x00'
    assert escape('\\x1F') == '\x1f'

# Generated at 2022-06-21 10:11:08.074706
# Unit test for function escape
def test_escape():
    assert escape("\a") == "\\x07"
    assert escape("\b") == "\\x08"
    assert escape("\f") == "\\x0c"
    assert escape("\n") == "\\n"
    assert escape("\r") == "\\r"
    assert escape("\t") == "\\t"
    assert escape("\v") == "\\x0b"
    assert escape("'") == "\\'"
    assert escape('"') == '\\"'
    assert escape("\\") == "\\\\"



# Generated at 2022-06-21 10:11:18.674567
# Unit test for function evalString
def test_evalString():
    # Test simple strings
    assert evalString('"Hi"') == "Hi"
    assert evalString("'Hi'") == "Hi"

    # Test empty string
    assert evalString('""') == ""
    assert evalString("''") == ""

    # Test basic escapes
    assert evalString('"\\a\\b\\f\\n\\r\\t\\v\\\\\\"\\\'"') == "\a\b\f\n\r\t\v\\\"\'"

    # Test escaped newline
    assert evalString('"""\\\n"""') == ""

    # Test escaped escape

# Generated at 2022-06-21 10:11:30.264101
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\\'", "\\\'")) == "'"
    assert escape(re.match(r'\\\"', '\\\"')) == '"'
   

# Generated at 2022-06-21 10:11:30.813910
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:59.958725
# Unit test for function escape
def test_escape():
    # Basic tests
    assert escape(re.match(r'\\a', r'\a')) == '\a'
    assert escape(re.match(r'\\b', r'\b')) == '\b'
    assert escape(re.match(r'\\f', r'\f')) == '\f'
    assert escape(re.match(r'\\n', r'\n')) == '\n'
    assert escape(re.match(r'\\r', r'\r')) == '\r'
    assert escape(re.match(r'\\t', r'\t')) == '\t'
    assert escape(re.match(r'\\v', r'\v')) == '\v'

# Generated at 2022-06-21 10:12:05.466789
# Unit test for function test
def test_test():
    import io
    import sys

    count = 0

    stdout = sys.stdout
    try:
        sys.stdout = io.StringIO()
        test()
        sys.stdout.seek(0)
        output = sys.stdout.read()
        count = len(output.split("\n"))
    finally:
        sys.stdout = stdout

    assert count == 1
    assert output == ""



# Generated at 2022-06-21 10:12:17.525774
# Unit test for function escape
def test_escape():
    import ast

    trees = [
        "ast.parse(code, 'exec').body[0].value.s",
        "ast.literal_eval(code)",
        "exec(code)",
        "eval(code)",
    ]

# Generated at 2022-06-21 10:12:23.147741
# Unit test for function test
def test_test():
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    try:
        test()
        s = mystdout.getvalue()
    finally:
        sys.stdout = old_stdout
    assert not s

# Unit tests for function test


# Generated at 2022-06-21 10:12:28.850339
# Unit test for function evalString
def test_evalString():
    """Test evalString function.

    The function executes a string literal without using the eval()
    function.

    Parameters
    ----------
    None

    Returns
    -------
    None
    """
    assert evalString('"Hello"') == "Hello"
    assert evalString("'Hello'") == "Hello"



# Generated at 2022-06-21 10:12:31.108556
# Unit test for function test
def test_test():
    # pylint: disable=line-too-long
    assert evalString("'\\a'") == "\a"
    # pylint: enable=line-too-long

# Generated at 2022-06-21 10:12:33.364204
# Unit test for function test
def test_test():
    result = test()
    assert result == None


# Generated at 2022-06-21 10:12:34.168397
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:40.949145
# Unit test for function escape
def test_escape():
    assert escape('\n') == '\n'
    assert escape('\t') == '\t'
    assert escape('\\') == '\\'
    assert escape('\a') == '\a'
    assert escape('\r') == '\r'
    assert escape('\b') == '\b'
    assert escape('\f') == '\f'
    assert escape('\v') == '\v'
    assert escape('x0B') == '\x0B'
    assert escape('xFa') == '\xFa'

# Generated at 2022-06-21 10:12:41.952383
# Unit test for function test
def test_test():
    # This test is not needed
    pass

# Generated at 2022-06-21 10:13:07.890716
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\a', r'\a')) == '\a'
    assert escape(re.match(r'\\b', r'\b')) == '\b'
    assert escape(re.match(r'\\f', r'\f')) == '\x0c'
    assert escape(re.match(r'\\n', r'\n')) == '\n'
    assert escape(re.match(r'\\r', r'\r')) == '\r'
    assert escape(re.match(r'\\t', r'\t')) == '\t'
    assert escape(re.match(r'\\v', r'\v')) == '\x0b'

# Generated at 2022-06-21 10:13:15.897322
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString('"a\\\\bc"') == 'a\\bc'
    assert evalString('"\\"\\n\\t\\u1234"') == '"\n\t\u1234'
    assert evalString('"\\\\"') == '\\'
    assert evalString('"ab\\\\c"') == 'ab\\c'
    assert evalString('"\\\\"') == '\\'
    assert evalString('"\\"\\\\\\"\\""') == '"\\""'
    assert evalString('"\\n\\n\\n\\n"') == "\n" * 4
    assert evalString('"a\\x61c"') == 'aac'
    assert evalString('"a\\x61\\x62c"') == 'aabc'

# Generated at 2022-06-21 10:13:27.411603
# Unit test for function test
def test_test():
    from textwrap import dedent


# Generated at 2022-06-21 10:13:29.544400
# Unit test for function evalString
def test_evalString():
    # Test the evalString function
    assert evalString('"Hello, world!"') == 'Hello, world!'
    assert evalString("'Hello, world!'") == 'Hello, world!'


# You can run this test using the following command:
# python3 -m libcst.codegen.eval_string.eval_string

# Generated at 2022-06-21 10:13:30.453982
# Unit test for function test
def test_test():
    # Can't call test directly
    pass

# Generated at 2022-06-21 10:13:38.034535
# Unit test for function escape
def test_escape():
    assert escape("blah") == 'blah'
    assert escape("\\u1234") == '\\u1234'
    assert escape("\\a") == '\a'
    assert escape("\\b") == '\b'
    assert escape("\\f") == '\f'
    assert escape("\\n") == '\n'
    assert escape("\\r") == '\r'
    assert escape("\\t") == '\t'
    assert escape("\\v") == '\v'
    assert escape("\\x61") == 'a'
    assert escape("\\x1") == '\x01'
    assert escape("\\x") == '\\x'
    assert escape("\\x0") == '\x00'
    assert escape("\\x12") == '\x12'
    assert escape("\\1")

# Generated at 2022-06-21 10:13:40.541157
# Unit test for function escape
def test_escape():
    assert escape("\\x41") == "A"
    assert escape("\\0") == "\x00"


# Generated at 2022-06-21 10:13:41.214779
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:53.717797
# Unit test for function evalString
def test_evalString():
    test_cases = [
        ('"\\\\"', '\\'),
        ('"\\"', '"'),
        ('"\'"', '\''),
        ('"\\n"', '\n'),
        ('"\\r"', '\r'),
        ('"\\a"', '\a'),
        ('"\\b"', '\b'),
        ('"\\f"', '\f'),
        ('"\\v"', '\v'),
        ('"\\t"', '\t'),
        ('"\\x"', 'x'),
        ('"\\xff"', 'ÿ'),
        ('"\\000"', '\0'),
        ('"\\377"', 'ÿ'),
    ]
    for eval_str, expect_result in test_cases:
        result = evalString(eval_str)
       

# Generated at 2022-06-21 10:14:01.583475
# Unit test for function evalString
def test_evalString():
    from . import safe_literal_eval
    assert safe_literal_eval.evalString('"abc"') == "abc"
    assert safe_literal_eval.evalString("'abc'") == "abc"
    assert safe_literal_eval.evalString(r'"abc\"def"') == r'abc\"def'
    assert safe_literal_eval.evalString(r'"abc\\"def"') == r'abc\\"def'
    assert safe_literal_eval.evalString(r'"abc\def"') == r'abc\def'
    assert safe_literal_eval.evalString(r'"abc\n\r\t\v\b\fdef"') == "abc\n\r\t\v\b\fdef"

# Generated at 2022-06-21 10:14:24.366320
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        print("Exception while trying to run test().")
        return False
    return True

# Unit tests for function evalString()

# Generated at 2022-06-21 10:14:25.388473
# Unit test for function test
def test_test():
    """Test test()"""
    assert test() is None

# Generated at 2022-06-21 10:14:25.984352
# Unit test for function test
def test_test():
    assert True

# Generated at 2022-06-21 10:14:36.791067
# Unit test for function evalString
def test_evalString():
    # single character
    assert evalString("'a'") == "a"
    # single character with single quote inside
    assert evalString("'''a'") == "'a"
    # multiple characters with single quote inside
    assert evalString("'a''b'") == "a'b"
    # multiple characters with two single quotes inside
    assert evalString("'a'''b'") == "a'b"
    # multiple characters with double quotes inside
    assert evalString("'a\"b'") == 'a"b'
    # multiple characters with two double quotes inside
    assert evalString("'a\"\"b'") == 'a""b'
    # different kinds of escapes

# Generated at 2022-06-21 10:14:48.201083
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ''
    assert evalString('"a"') == 'a'
    assert evalString('"\\a"') == "\a"
    assert evalString('"\'"') == "'"
    assert evalString('r"\'"') == 'r"\\\'"'
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\f"') == "\f"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\v"') == "\v"
    assert evalString('"\\x41"') == "A"
    assert evalString('"\\x2f"') == "/"

# Generated at 2022-06-21 10:14:55.065768
# Unit test for function escape
def test_escape():
	assert escape(r"\a") == "\a"
	assert escape(r"\b") == "\b"
	assert escape(r"\f") == "\f"
	assert escape(r"\n") == "\n"
	assert escape(r"\r") == "\r"
	assert escape(r"\t") == "\t"
	assert escape(r"\v") == "\v"
	assert escape(r"\'") == "\'"
	assert escape(r'\"') == '\"'
	assert escape(r"\\") == "\\"
	assert escape(r"\xFF") == chr(255)
	assert escape(r"\377") == chr(255)
	assert escape(r"\000") == chr(0)

# Generated at 2022-06-21 10:14:56.538257
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert False

# Generated at 2022-06-21 10:14:57.122656
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:15:03.152765
# Unit test for function escape
def test_escape():
    tests_passed = True
    # Test 1: Empty string
    assert escape(re.search(r"\\", "")) == ""
    # Test 2: Normal
    assert escape(re.search(r"\\", "\\")) == "\\"
    # Test 3: Hex
    assert escape(re.search(r"\\", "\\x")) == ""
    # Test 4: Octal
    assert escape(re.search(r"\\", "\\0")) == "\x00"

    return tests_passed

# Generated at 2022-06-21 10:15:04.153025
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"

# Generated at 2022-06-21 10:16:16.154217
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\"n"') == '"n'
    assert evalString(r"r'n'") == 'n'
    assert evalString(r"r'\n'") == '\\n'
    assert evalString(r"'\n'") == '\n'
    assert evalString(r"'\\n'") == '\\n'
    assert evalString(r"'\7'") == '\x07'
    assert evalString(r"'\x07'") == '\x07'

# Generated at 2022-06-21 10:16:17.320144
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:16:20.060344
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as err:
        print("Error in unittest test_test: {}".format(err))
        assert False


# Unit tests for function evalString

# Generated at 2022-06-21 10:16:22.293461
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-21 10:16:25.765597
# Unit test for function test
def test_test():
    from mypy_extensions import NoReturn
    with pytest.raises(SystemExit, match=r"To exit, use 'exit', 'quit', or Ctrl-D."):
        test() # pragma: no cover
    raise NoReturn

# Generated at 2022-06-21 10:16:33.140682
# Unit test for function escape
def test_escape():
    for c in ('foo', 'a', '\\', '"', "'", 'xab', 'xaf', 'xadf', 'xaf0', 'xadff',
              'xaf0f', 'xadfff', 'xadffff', 'octal', '000', '11', '37',
              '117', '177', '377'):
        try:
            escape('\\' + c, None)
        except ValueError:
            pass
        else:
            assert False, 'escape() did not raise ValueError for escape \\{0}'.format(c)


# Generated at 2022-06-21 10:16:45.532142
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\'", "'")) == "'"
    assert escape(re.match('\\"', '"')) == '"'
    assert escape(re.match("\\\\", "\\")) == "\\"
    assert escape(re.match("\\x61", "a")) == "a"
    assert escape(re.match("\\a", "a")) == "\a"
    assert escape(re.match("\\b", "a")) == "\b"
    assert escape(re.match("\\f", "a")) == "\f"
    assert escape(re.match("\\n", "a")) == "\n"
    assert escape(re.match("\\r", "a")) == "\r"
    assert escape(re.match("\\t", "a")) == "\t"

# Generated at 2022-06-21 10:16:56.440363
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\''") == "'"
    assert evalString("'abc'") == "abc"
    assert evalString("'abc\\ndef'") == "abc\ndef"
    assert evalString("'\\x00'") == "\x00"
    assert evalString('"\\""') == '"'
    assert evalString('"abc"') == "abc"
    assert evalString('"abc\\ndef"') == "abc\ndef"
    assert evalString('"\\x00"') == "\x00"
    assert evalString("r'\\''") == "\\'"
    assert evalString("r'abc'") == "abc"
    assert evalString("r'abc\\ndef'") == "abc\\ndef"
    assert evalString("r'\\x00'") == "\\x00"
   

# Generated at 2022-06-21 10:16:57.118943
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:06.678498
# Unit test for function evalString
def test_evalString():
    assert evalString('\'"\'') == '\'"\''
    assert evalString('\'abc\'') == 'abc'
    assert evalString('\'"abc"\'') == '"abc"'
    assert evalString('\'\\t\\n\'') == '\t\n'

# test this in 3.x to see if the evalString function annotates properly
if 0:
    from typing import Optional
    from typing import Tuple


# Generated at 2022-06-21 10:19:02.163840
# Unit test for function escape
def test_escape():
    s = "'\\''"
    assert evalString(s) == "'"

    s = '"\\""'
    assert evalString(s) == '"'

    s = "'\\a'"
    assert evalString(s) == "\a"

    s = "'\\b'"
    assert evalString(s) == "\b"

    s = "'\\n'"
    assert evalString(s) == "\n"

    s = "'\\r'"
    assert evalString(s) == "\r"

    s = "'\\t'"
    assert evalString(s) == "\t"

    s = "'\\v'"
    assert evalString(s) == "\v"

    s = "'\\f'"
    assert evalString(s) == "\f"

    s = "'\\0'"
    assert evalString(s) == "\0"



# Generated at 2022-06-21 10:19:06.374561
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(')", r"\\'")) == "'"
    assert escape(re.match(r"\\(x00)", r"\\x00")) == "\x00"
    assert escape(re.match(r"\\(377)", r"\\377")) == "\xff"



# Generated at 2022-06-21 10:19:15.841012
# Unit test for function escape
def test_escape():
    assert escape('\\' + 'a') == '\a'
    assert escape('\\' + 'b') == '\b'
    assert escape('\\' + 'f') == '\f'
    assert escape('\\' + 'n') == '\n'
    assert escape('\\' + 'r') == '\r'
    assert escape('\\' + 't') == '\t'
    assert escape('\\' + 'v') == '\v'
    assert escape('\\' + '\'') == '\''
    assert escape('\\' + '"') == '"'
    assert escape('\\' + '\\') == '\\'

    assert escape('\\x07') == '\x07'
    assert escape('\\x1f') == '\x1f'


# Generated at 2022-06-21 10:19:27.698728
# Unit test for function evalString

# Generated at 2022-06-21 10:19:36.333555
# Unit test for function test
def test_test():
    assert evalString("'foo'") == 'foo'
    assert evalString('"foo"') == 'foo'
    assert evalString("'foo\\nfoo'") == 'foo\nfoo'
    assert evalString('"foo\\nfoo"') == 'foo\nfoo'
    assert evalString("'foo\\\'foo'") == "foo'foo"
    assert evalString('"foo\\\"foo"') == 'foo"foo'
    assert evalString("'foo\\\\foo'") == "foo\foo"
    assert evalString('"foo\\\\foo"') == 'foo\\foo'

    try:
        evalString("'foo\\xfoo'")
    except ValueError as e:
        assert str(e) == "invalid hex string escape ('\\xfoo')"

# Generated at 2022-06-21 10:19:45.461836
# Unit test for function evalString
def test_evalString():
    # test empty string
    # test cases verified with Python 3.7.2
    assert evalString('""') == ""
    assert evalString('\'\'') == ""
    # test characters
    assert evalString('" "') == " "
    assert evalString('\'"\'\'') == "'"
    # test escape sequences
    assert evalString('"\\n\\t\\a"') == "\n\t"
    assert evalString('"\\v\\r"') == "\v\r"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\\\"') == "\\"
    # test octal escape sequences
    assert evalString('"\\141"') == "a"
    assert evalString('"\\145"') == "e"

# Generated at 2022-06-21 10:19:56.562806
# Unit test for function escape
def test_escape():
    assert escape(Match(r"\n", r"\n")) == "\n"
    assert escape(Match(r"\x00", r"\x00")) == "\x00"
    assert escape(Match(r"\xaa", r"\xaa")) == "\xaa"
    assert escape(Match(r"\777", r"\777")) == "\u01ff"
    assert escape(Match(r"\800", r"\800")) == "\u0800"
    assert escape(Match(r"\400", r"\400")) == "\u0200"
    assert escape(Match(r"\40", r"\40")) == " "
    assert escape(Match(r'\"', r'\"')) == '"'
    assert escape(Match(r"\'", r"\'")) == "'"

# Generated at 2022-06-21 10:19:58.006802
# Unit test for function test
def test_test():
    try:
        test()
    except SystemExit:
        assert False, 'test raised SystemExit'

# Generated at 2022-06-21 10:20:03.537451
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'def'") == "def"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\x30'") == "0"
    assert evalString("'\\000'") == "\0"