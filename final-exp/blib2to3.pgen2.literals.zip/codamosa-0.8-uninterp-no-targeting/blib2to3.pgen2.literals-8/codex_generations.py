

# Generated at 2022-06-21 10:10:28.454206
# Unit test for function test
def test_test():
    import doctest
    doctest.run_docstring_examples(test, globals())


# Generated at 2022-06-21 10:10:39.768206
# Unit test for function escape
def test_escape():
    with pytest.raises(ValueError):
        assert escape(re.match(r"\\x(ff)*", "\\x"))
    with pytest.raises(ValueError):
        assert escape(re.match(r"\\[0-8]{3,4}", "\\1234"))
    assert escape(re.match(r"\\x(ff)*", "\\xff")) == "\xff"
    assert escape(re.match(r"\\[0-7]{1,3}", "\\777")) == "\xff"
    assert escape(re.match(r"\\[abfnrtv]", "\\a")) == "\a"
    assert escape(re.match(r"\\[abfnrtv]", "\\b")) == "\b"

# Generated at 2022-06-21 10:10:46.438786
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x64")) == "d"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\3")) == "\x03"

# Generated at 2022-06-21 10:10:52.826661
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([\'" + "".join(simple_escapes.keys()) + "])", r"\'\'\'")) == r"\'"
    assert escape(re.match(r"\\x", "\\xZ7")) == "xZ7"
    assert escape(re.match(r"\\x", "\\x")) == "x"

# Generated at 2022-06-21 10:11:01.203750
# Unit test for function escape
def test_escape():
    # verify that escape() escapes chars into 2-digit hex strings
    import codecs
    for i in range(256):
        ch = chr(i)
        escaped_ch = escape(ch)
        assert len(escaped_ch) == 4 and escaped_ch[:2] == '\\x' and len(codecs.decode(escaped_ch[2:], 'hex')) == 1

# Generated at 2022-06-21 10:11:03.455631
# Unit test for function evalString
def test_evalString():
    s = "'''"


# Generated at 2022-06-21 10:11:04.051898
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:04.980026
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:16.598833
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == "foo"
    assert evalString("'foo'") == "foo"
    assert evalString("'''foo'") == "foo"
    assert evalString("""'''foo'""") == "foo"
    assert evalString("""'''foo'''""") == "foo"
    for i in range(256):
        assert evalString(repr(chr(i))) == chr(i)
    assert evalString("\\x41") == "A"
    assert evalString("\\041") == "!"
    assert evalString("\\41") == "!"
    assert evalString("\\x41;") == "A"
    assert evalString("\\041;") == "!"
    assert evalString("\\41;") == "!"
    assert evalString("\\x") == "x"


# Generated at 2022-06-21 10:11:28.538972
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", '\\a')) == '\a'
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\x1")) == "\x01"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\x12")) == "\x12"

# Generated at 2022-06-21 10:12:03.214902
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"ab\'c"') == "ab'c"
    assert evalString("'ab\"c'") == 'ab"c'
    assert evalString("'a\x00c'") == "\x00"
    assert evalString(r'"a\0c"') == "a\x00c"
    assert evalString(r'"a\\c"') == r"a\c"



# Generated at 2022-06-21 10:12:08.074750
# Unit test for function test
def test_test():
    import io
    from contextlib import redirect_stdout

    #Empty output
    f = io.StringIO()
    with redirect_stdout(f):
        test()
    s = f.getvalue()
    assert s == '', s


# Generated at 2022-06-21 10:12:13.427990
# Unit test for function evalString
def test_evalString():
    result = evalString("'\\\\U0001F601'")
    assert result == "\\U0001F601"
    result = evalString("'''a'''")
    assert result == "'a'"
    result = evalString("'\\\\U0001F601'")
    assert result == "\\U0001F601"

# Generated at 2022-06-21 10:12:23.779215
# Unit test for function evalString
def test_evalString():
    t = evalString('"hi"')
    assert t == "hi"
    t = evalString('"hi\\t"')
    assert t == "hi\t"
    t = evalString('"hi\\t"')
    assert t == "hi\t"
    t = evalString('"hi\\07"')
    assert t == "hi\x07"
    t = evalString('"hi\\x07"')
    assert t == "hi\x07"
    t = evalString('"hi\\x007"')
    assert t == "hi\x00"
    t = evalString('"hi\\n"')
    assert t == "hi\n"

# Generated at 2022-06-21 10:12:31.659304
# Unit test for function evalString
def test_evalString():
    assert evalString("'ab'") == 'ab'
    assert evalString('"ab"') == 'ab'
    assert evalString("'a\\x41'") == 'aA'
    assert evalString("'a\\r\\n'") == 'a\r\n'
    assert evalString("'''a\\r\\n'''") == 'a\\r\\n'
    assert evalString("'a\\'a'") == 'a\'a'
    assert evalString("'a\\" + '\\' + "'a'") == 'a' + '\\' + 'a'

# Generated at 2022-06-21 10:12:32.708590
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:40.820080
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\[x][0-9A-Za-z]', '\\x1f')) == '\x1f'

# Generated at 2022-06-21 10:12:42.649265
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\.", r"\z")) == "z"



# Generated at 2022-06-21 10:12:44.003102
# Unit test for function test
def test_test():
    try:
        test()
    except:  # noqa: E722
        return 1
    return 0

# Generated at 2022-06-21 10:12:55.014422
# Unit test for function escape
def test_escape():
    # test OK
    s = '\\x4e\\x75'
    assert escape(re.match(r'\\x.{0,2}', s)) == 'Nu'
    s = '\\x3a\\x3b'
    assert escape(re.match(r'\\x.{0,2}', s)) == ':;'
    # test error with invalid format
    with pytest.raises(ValueError):
        s = '\\x4e'
        escape(re.match(r'\\x.{0,2}', s))
    with pytest.raises(ValueError):
        s = '\\x4e\\x'
        escape(re.match(r'\\x.{0,2}', s))

# Generated at 2022-06-21 10:13:08.650004
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:09.230926
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:13:10.157155
# Unit test for function test
def test_test():
    test()  # there's really nothing useful to test here

# Generated at 2022-06-21 10:13:15.732791
# Unit test for function test
def test_test():

    import io
    import sys
    import traceback

    sio = io.StringIO()
    c_stderr = sys.stderr
    sys.stderr = sio

    try:
        test()
    except SystemExit as e:
        if e.code != 0:
            raise
    except:
        traceback.print_exc(file=sio)
        raise
    finally:
        sys.stderr = c_stderr

    if sio.tell():
        raise AssertionError(repr(sio.getvalue()))

# Generated at 2022-06-21 10:13:27.272790
# Unit test for function evalString
def test_evalString():
    # Simple test string
    s = "abcd 1234"
    assert evalString(repr(s)) == s

    # Unicode string
    t = "abc\u1234"
    assert evalString(repr(t)) == t

    # Single quote test
    t = "abc'def"
    assert evalString(repr(t)) == t

    # Double quote test
    t = '"abc"'
    assert evalString(repr(t)) == t

    # Escape characters
    t = "a\nb"
    assert evalString(repr(t)) == t
    t = "a\tb"
    assert evalString(repr(t)) == t

    # Hex escapes
    t = "\x61"
    assert evalString(repr(t)) == t

# Generated at 2022-06-21 10:13:28.617406
# Unit test for function test
def test_test():
    test()
    # print(re.sub(r'\\(\'|\"|\\)', r'\\\1', '\'"\\'))

# Generated at 2022-06-21 10:13:37.094296
# Unit test for function escape
def test_escape():
    # Ensure escape handles valid inputs
    assert escape(re.match(r"\\x2F", "\\x2F")) == "/"
    assert escape(re.match(r"\\x02", "\\x02")) == "\x02"
    assert escape(re.match(r"\\xF0", "\\xF0")) == "\xF0"
    assert escape(re.match(r"\\xFf", "\\xFf")) == "\xFf"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"
    assert escape(re.match(r"\\xff", "\\xff")) == "\xff"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"

# Generated at 2022-06-21 10:13:49.812556
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\x7f'") == "\x7f"
    assert evalString("'\\100'") == "\100"
    assert evalString("'\\200'") == "\200"
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\xff'") == "ÿ"

# Generated at 2022-06-21 10:13:51.790147
# Unit test for function evalString
def test_evalString():
    assert evalString(r"'\''") == r"'"
    assert evalString('"\\""') == r'"'

# Generated at 2022-06-21 10:14:00.662595
# Unit test for function escape
def test_escape():
    """Return the Python constant expression for a string of bytes."""

    assert escape(re.match('\\"', '\\"')) == '"'
    assert escape(re.match("\\'", "\\'")) == "'"
    assert escape(re.match("\\\\", "\\\\")) == "\\"

    assert escape(re.match("\\a", "\\a")) == "\a"
    assert escape(re.match("\\b", "\\b")) == "\b"
    assert escape(re.match("\\f", "\\f")) == "\f"
    assert escape(re.match("\\n", "\\n")) == "\n"
    assert escape(re.match("\\r", "\\r")) == "\r"
    assert escape(re.match("\\t", "\\t")) == "\t"

# Generated at 2022-06-21 10:14:23.692819
# Unit test for function evalString
def test_evalString():
    assert evalString("'oops'") == "oops"
    assert evalString("'oops\\n'") == "oops\\n"
    assert evalString("'oops\\x01'") == "oops\\x01"
    assert evalString("'oops\\777'") == "oops\\777"
    assert evalString("'oops\\u1234'") == "oops\\u1234"
    assert evalString("'oops\\U00012345'") == "oops\\U00012345"
    assert evalString("'oops\\xab'") == "oops\\xab"
    assert evalString("'oops\\xAB'") == "oops\\xAB"
    assert evalString("'oops\\xab\\n'") == "oops\\xab\\n"

# Generated at 2022-06-21 10:14:25.120160
# Unit test for function test
def test_test():
    """
    Unit test for function test
    """
    pass

# Generated at 2022-06-21 10:14:33.924136
# Unit test for function evalString
def test_evalString():
    assert evalString("'''hello'''") == 'hello'
    assert evalString('"""hello"""') == 'hello'
    assert evalString("'\\'hello\\''") == "'hello'"
    assert evalString("'\\'hello\\''") == "'hello'"
    assert evalString("'hello\\n'") == 'hello\n'
    assert evalString("'hello\\x41'") == 'helloA'
    assert evalString("'hello\\101'") == 'helloA'
    assert evalString("'hello\\x41\\x41'") == 'helloAA'
    assert evalString("'hello\\101\\101'") == 'helloAA'

# Generated at 2022-06-21 10:14:41.690540
# Unit test for function evalString
def test_evalString():
    expected = ["\\a", "\\b", "\\f", "\\n", "\\r", "\\t", "\\v"]
    for i in range(len(expected)):
        result = evalString("'" + simple_escapes[i] + "'")
        assert result == expected[i]

    expected = ["'", '"', "\\"]
    for i in range(len(expected)):
        result = evalString('"\\' + simple_escapes[i] + '"')
        assert result == expected[i]

    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x61\\x62'") == "ab"
    assert evalString("'\\x61\\x62\\x63'") == "abc"

# Generated at 2022-06-21 10:14:42.405973
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:14:43.850570
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-21 10:14:50.766957
# Unit test for function evalString
def test_evalString():
    test_cases = [
        ("'simple'", "simple"),
        ('"simple"', "simple"),
        ("'Already escaped: \\'\\'\\''", "Already escaped: '''"),
        ('"Already escaped: """"', 'Already escaped: """')
    ]
    for test_case, expected in test_cases:
        assert evalString(test_case) == expected
        print(test_case, "passed")

# Generated at 2022-06-21 10:15:00.557385
# Unit test for function evalString
def test_evalString():
    assert evalString('"a string"') == "a string"
    assert evalString("'a string'") == "a string"
    assert evalString("\"\'a string\'\"") == "'a string'"
    assert evalString("\"\"\"a string\"\"\"") == "a string"
    assert evalString("\"\"\"a string\"\"\"") == "a string"
    assert evalString("\'\'\'a string\'\'\'") == "a string"
    assert evalString("\'\'\'a string\'\'\'") == "a string"
    assert evalString("\"a string") == "a string"
    assert evalString("\'a string") == "a string"
    assert evalString("\"\"\"a string") == "\"a string"
    assert evalString("\'\'\'a string") == "\'a string"
    assert eval

# Generated at 2022-06-21 10:15:01.810131
# Unit test for function test
def test_test():
    # pylint: disable=no-member
    assert test() is None

# Generated at 2022-06-21 10:15:02.518251
# Unit test for function test
def test_test():
    result = test()
    assert result == None

# Generated at 2022-06-21 10:15:24.796896
# Unit test for function escape
def test_escape():
    # Simple characters
    assert escape(re.match(r"\\([abfnrtv])", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv])", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv])", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv])", r"\n")) == "\n"
    assert escape(re.match(r"\\([abfnrtv])", r"\r")) == "\r"
    assert escape(re.match(r"\\([abfnrtv])", r"\t")) == "\t"

# Generated at 2022-06-21 10:15:34.742729
# Unit test for function escape
def test_escape():
    assert escape('\\0') == chr(0)
    assert escape('\\077') == chr(63)
    assert escape('\\377') == chr(255)

    assert escape('\\x00') == chr(0)
    assert escape('\\x77') == chr(119)
    assert escape('\\xff') == chr(255)

    assert escape('\\a') == chr(7)
    assert escape('\\b') == chr(8)
    assert escape('\\f') == chr(12)
    assert escape('\\n') == chr(10)
    assert escape('\\r') == chr(13)
    assert escape('\\t') == chr(9)
    assert escape('\\v') == chr(11)

    assert escape("\\\\") == chr(92)
   

# Generated at 2022-06-21 10:15:42.287058
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == 'a'
    assert evalString("'abc'") == 'abc'
    assert evalString('"abc"') == 'abc'
    assert evalString("'\\\\'") == '\\'
    assert evalString("'\\x7f'") == chr(0x7f)

# Generated at 2022-06-21 10:15:48.300523
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\x41", "A")) == "A"
    assert escape(re.match("\\x41", "AB")) == "A"
    assert escape(re.match("\\x41", "ABC")) == "A"
    assert escape(re.match("\\x41", "AB\\")) == "A"
    assert escape(re.match("\\x41", "AB\\C")) == "A"

# Generated at 2022-06-21 10:15:57.992268
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\t"') == "\t"
    assert evalString("\"\\'\"") == "'"
    assert evalString("\"\\\"\"") == '"'
    assert evalString("\"\\\\\"") == "\\"
    assert evalString("\"\\a\"") == "\a"
    assert evalString("\"\\b\"") == "\b"
    assert evalString("\"\\f\"") == "\f"
    assert evalString("\"\\n\"") == "\n"
    assert evalString("\"\\r\"") == "\r"
    assert evalString("\"\\t\"") == "\t"
    assert evalString("\"\\v\"") == "\v"
    assert evalString("\"\\x00\"") == "\x00"
    assert evalString("\"\\xFF\"") == "\xFF"
    assert eval

# Generated at 2022-06-21 10:15:58.720819
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:59.528401
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:16:02.040868
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\\a\nb\\\r\\"\'') == """\\a\nb\\\r\\"\'"""

# Generated at 2022-06-21 10:16:06.004572
# Unit test for function evalString
def test_evalString():
    assert evalString('"') == '"'
    assert evalString("'") == "'"
    assert evalString('"a"') == 'a'
    assert evalString("'a'") == 'a'
    assert evalString('"""a"""') == 'a'
    assert evalString('""""a""""') == '"a"'
    assert evalString('""""a"""') == '"a'
    assert evalString('"""a""""') == 'a"'
    assert evalString('"""\tabc"""') == '\tabc'
    assert evalString('"""\tabc""""') == '\tabc"'
    assert evalString('"""\\tabc"""') == '\\tabc'
    assert evalString('"""\\tabc""""') == '\\tabc"'

# Generated at 2022-06-21 10:16:06.665628
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:16:51.086074
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\'") == "'"
    assert evalString("'\"'") == '"'
    assert evalString('"\'"') == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\0'") == chr(0)

# Generated at 2022-06-21 10:16:52.522367
# Unit test for function test
def test_test():
    if __name__ == "__main__":
        test()

# Generated at 2022-06-21 10:16:56.478079
# Unit test for function test
def test_test():
    import io
    import contextlib
    f = io.StringIO()
    with contextlib.redirect_stdout(f):
        test()
    s = f.getvalue()
    # No errors should occur
    assert s == "", "Unexpected errors occurred:\n{}".format(s)

# Generated at 2022-06-21 10:16:57.439024
# Unit test for function test
def test_test():
    """Test the function test()"""
    test()

# Generated at 2022-06-21 10:17:03.499207
# Unit test for function evalString
def test_evalString():
    test_str = '"abc"'
    assert evalString(test_str) == "abc"
    test_str = "'abc'"
    assert evalString(test_str) == "abc"
    test_str = "'\\\\'"
    assert evalString(test_str) == "\\"
    test_str = "'\\\"'"
    assert evalString(test_str) == '"'
    test_str = r'"\""'
    assert evalString(test_str) == '"'
    test_str = r'"\\x61"'
    assert evalString(test_str) == 'a'
    test_str = r'"\\x"'
    try:
        evalString(test_str)
    except ValueError:
        pass
    else:
        raise AssertionError
    test_str = r'"\\0"'

# Generated at 2022-06-21 10:17:14.795120
# Unit test for function escape
def test_escape():
    r = evalString(r'\'\\t\'')
    assert len(r) == 1
    assert r == '\t'
    r = evalString(r'\'\\n\'')
    assert len(r) == 1
    assert r == '\n'
    r = evalString(r'\'\\r\'')
    assert len(r) == 1
    assert r == '\r'
    r = evalString(r'\'\\a\'')
    assert len(r) == 1
    assert r == '\a'
    r = evalString(r'\'\\v\'')
    assert len(r) == 1
    assert r == '\v'
    r = evalString(r'\'\\f\'')
    assert len(r) == 1
    assert r == '\f'
   

# Generated at 2022-06-21 10:17:15.937044
# Unit test for function test
def test_test():
    # Tests the test method
    test()

# Generated at 2022-06-21 10:17:27.252401
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61\\x62\\x63"') == 'abc'
    assert evalString('"\'"') == "'"
    assert evalString('"\x01\x02\n\r\t\x7f\\\\"') == "\x01\x02\n\r\t\x7f\\"
    assert evalString('"""\x01\x02\n\r\t\x7f\\\\"""') == "\x01\x02\n\r\t\x7f\\"
    assert evalString('r"\\x61\\x62\\x63"') == r"\x61\x62\x63"
    assert evalString('r"\'"') == r"'"

# Generated at 2022-06-21 10:17:38.855272
# Unit test for function escape
def test_escape():
    tests = (
        (r"\a", "\a"),
        (r"\b", "\b"),
        (r"\f", "\f"),
        (r"\n", "\n"),
        (r"\r", "\r"),
        (r'\"', '"'),
        (r"\'", "'"),
        (r"\t", "\t"),
        (r"\v", "\v"),
        (r"\\", "\\"),
        (r"\x20", " "),
        (r"\xFF", "\xFF"),
        (r"\x7f", "\x7f"),
        (r"\x1f", "\x1f"),
        (r"\040", " "),
        (r"\377", "\377"),
    )

# Generated at 2022-06-21 10:17:42.643633
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"
    assert escape("\\x61") == "a"
    assert escape("\\072") == ":"
    try:
        escape("\\08")
        assert False
    except ValueError:
        pass



# Generated at 2022-06-21 10:18:29.308248
# Unit test for function evalString
def test_evalString():
    if evalString("'\\x93'") != '\x93':
        raise RuntimeError("test_evalString failed")

    try:
        evalString("'\\x9z'")
        raise RuntimeError("test_evalString failed")
    except ValueError:
        pass
    try:
        evalString("'\\x9'")
        raise RuntimeError("test_evalString failed")
    except ValueError:
        pass

# Generated at 2022-06-21 10:18:39.996036
# Unit test for function escape
def test_escape():
    assert evalString("'foo\\n'") == r"foo\n"
    assert evalString("'foo\\\'bar'") == "foo\'bar"
    assert evalString("'foo\\\"bar'") == "foo\"bar"
    assert evalString("'foo\\\\bar'") == "foo\\bar"
    assert evalString("'foo\\a'") == "foo\\a"
    assert evalString("'foo\\b'") == "foo\\b"
    assert evalString("'foo\\f'") == "foo\\f"
    assert evalString("'foo\\r'") == "foo\\r"
    assert evalString("'foo\\t'") == "foo\\t"
    assert evalString("'foo\\v'") == "foo\\v"

# Generated at 2022-06-21 10:18:50.114071
# Unit test for function evalString
def test_evalString():
    for i in range(32):
        assert evalString(repr(chr(i))) == chr(i)
    for i in range(32, 127):
        assert evalString(repr(chr(i))) == chr(i)
    for i in range(32):
        assert evalString(repr(chr(i))) == chr(i)
    for i in range(32, 127):
        assert evalString(repr(chr(i))) == chr(i)

# Generated at 2022-06-21 10:18:50.740948
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:18:51.363170
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:18:54.784420
# Unit test for function test
def test_test():
    # Not clear what is meant by this test,
    # and it does not work without a real stdin:
    #  test()
    # No output, so assume it would be OK.
    pass

# Generated at 2022-06-21 10:19:01.156331
# Unit test for function escape
def test_escape():
    tests = [
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ('\\"', '"'),
        ("\\'", "'"),
        ("\\\\", "\\"),
    ]
    for s, c in tests:
        assert escape(re.match("(.*)", s)) == c, s

# Generated at 2022-06-21 10:19:04.478815
# Unit test for function evalString
def test_evalString():
    assert evalString('"\n"') == "\n"
    assert evalString('"\xFF"') == "\xFF"
    assert evalString('"\uABCD"') != "\uABCD"

# Generated at 2022-06-21 10:19:04.975909
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:19:14.558016
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString('"A"') == "A"
    assert evalString('"\n"') == "\n"
    assert evalString('"\x00"') == "\x00"
    assert evalString('"\x72"') == "\x72"
    assert evalString('"\u00e9"') == "\u00e9"
    assert evalString("'a'") == "a"
    assert evalString("'A'") == "A"
    assert evalString("'\n'") == "\n"
    assert evalString("'\x00'") == "\x00"
    assert evalString("'\x72'") == "\x72"
    assert evalString("'\u00e9'") == "\u00e9"