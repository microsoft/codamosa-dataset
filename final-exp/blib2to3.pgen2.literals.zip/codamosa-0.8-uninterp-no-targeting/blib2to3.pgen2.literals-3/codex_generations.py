

# Generated at 2022-06-21 10:10:27.828193
# Unit test for function evalString
def test_evalString():
    import unittest

    class TestEvalString(unittest.TestCase):
        def test_simple_cases(self):
            tests = [
                ("a", "a"),
                ("'a'", "a"),
                ('"a"', "a"),
                ("abc", "abc"),
                ("'abc'", "abc"),
                ('"abc"', "abc"),
                ("'\\''", "'"),
                ('"\\""', '"'),
                ('"\\\\"', "\\"),
            ]
            for input, expected in tests:
                actual = evalString(input)
                self.assertEqual(expected, actual, input)


# Generated at 2022-06-21 10:10:29.342897
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-21 10:10:37.111375
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\x0", "\\x0")) == chr(0)
    assert escape(re.match("\\x00", "\\x00")) == chr(0)
    assert escape(re.match("\\x000", "\\x000")) == chr(0)
    assert (
        escape(re.match("\\x0000000", "\\x0000000")) == chr(0)
    ), "so long hex should pass too"
    assert (
        escape(re.match("\\00000000", "\\00000000")) == chr(0)
    ), "so long oct should pass too"

# Generated at 2022-06-21 10:10:41.931440
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\t\\n"') == '\t\n'
    assert evalString('"\\t\\n"') == '\t\n'
    assert evalString('"\\u1234\\U00012345"') == '\u1234\U00012345'
    assert evalString('"\\x01\\x10"') == '\x01\x10'
    assert evalString('"\\x01"') == '\x01'
    assert evalString('"\\072"') == ':'

# Generated at 2022-06-21 10:10:43.995541
# Unit test for function test
def test_test():
    try:
        test()
    except SystemExit:
        raise Exception("test() raised SystemExit")

# Generated at 2022-06-21 10:10:56.144648
# Unit test for function test
def test_test():
    rval = eval('1 + 1')
    assert rval == 2
    rval = eval("'1 + 1'")
    assert rval == '1 + 1'
    rval = eval("'''1 + 1'''")
    assert rval == '1 + 1'
    rval = eval("'1 \\\\+ 1'")
    assert rval == '1 \\+ 1'
    rval = eval("'1 \\\\''")
    assert rval == "1 \\"
    rval = eval("'1 \\\\' + \"'\"")
    assert rval == "1 \\"
    # Now test the function itself
    rval = evalString("'''1 + 1'''")
    assert rval == '1 + 1'
    rval = evalString("'1 \\\\+ 1'")


# Generated at 2022-06-21 10:10:56.947007
# Unit test for function test
def test_test():
    pass

# Generated at 2022-06-21 10:11:00.046476
# Unit test for function test
def test_test():
    assert evalString('"abc"') == 'abc'
    assert evalString(r'"\n\\abc"') == "\n\\abc"

# Generated at 2022-06-21 10:11:08.744849
# Unit test for function escape
def test_escape():
    cases = (
        (r"\\", "\\"),
        (r"\a", "\a"),
        (r"\b", "\b"),
        (r"\f", "\f"),
        (r"\n", "\n"),
        (r"\r", "\r"),
        (r"\t", "\t"),
        (r"\v", "\v"),
        (r"\"", '"'),
        (r"\'", "'"),
        (r"\325", "\xc5"),
        (r"\x4f", "O"),
        (r"\x4F", "O"),
    )

    for s, r in cases:
        m = re.match(r"\\(.|x.{0,2}|[0-7]{1,3})", s)
        assert m

# Generated at 2022-06-21 10:11:11.956138
# Unit test for function escape
def test_escape():
    s = "\\xae"
    e = escape(re.match("\\x", s))
    assert e == "\xae"


# Generated at 2022-06-21 10:11:26.758950
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:33.843256
# Unit test for function evalString
def test_evalString():
    # Testing evalString
    assert evalString("''") == ""
    assert evalString("'a'") == "a"
    assert evalString("'abc'") == "abc"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\'") == "\\"
    assert evalString("'''a'b'c'") == "a'b'c"
    assert evalString("'\"'") == '"'
    assert evalString("'\\\"'") == '\\"'
    assert evalString('"\\""') == '\\"'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\n'") == "\n"

# Generated at 2022-06-21 10:11:34.484655
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:44.913219
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == 'foo'
    assert evalString("'foo'") == 'foo'
    assert evalString("'''foo'") == "'foo"
    assert evalString('"""foo"') == '"foo'
    assert evalString('"\n"') == "\n"
    assert evalString("'\n'") == "\n"
    assert evalString("'''\n'") == "\n'"
    assert evalString('"""\n"') == '"\n'
    assert evalString('"\\"') == '"'
    assert evalString("'\\''") == "'"
    assert evalString("'foo\\\n'") == 'foo\n'
    assert evalString('"""foo\\\n"') == '"foo\n'

# Generated at 2022-06-21 10:11:45.393269
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:11:46.751602
# Unit test for function test
def test_test():
    assert test() is None


# Generated at 2022-06-21 10:11:58.456348
# Unit test for function evalString
def test_evalString():
    # Single-quoted string
    assert evalString(r"'x'") == 'x'
    assert evalString(r"'\\'") == '\\'
    assert evalString(r"'\''") == "'"
    assert evalString(r"'abc'") == 'abc'
    assert evalString(r"'\x61\x62\x63'") == 'abc'
    assert evalString(r"'\u1234\U00012345'") == '\u1234\U00012345'

# Generated at 2022-06-21 10:12:05.926629
# Unit test for function escape
def test_escape():
    test_pass = True
    if (
        escape(re.match("\\x01", "\\x01")) != "\x01"
        or escape(re.match("\\x10", "\\x10")) != "\x10"
        or escape(re.match("\\x01", "\\x01")) != "\x01"
        or escape(re.match("\\x7f", "\\x7f")) != "\x7f"
    ):
        test_pass = False
    if test_pass:
        print("Escape pattern matching test passed")
    else:
        print("Escape pattern matching test failed")



# Generated at 2022-06-21 10:12:16.538268
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"
    assert escape("\\a") == '\x07'
    assert escape("\\b") == '\x08'
    assert escape("\\f") == '\x0c'
    assert escape("\\n") == '\n'
    assert escape("\\r") == '\r'
    assert escape("\\t") == '\t'
    assert escape("\\v") == '\x0b'
    assert escape("\\\"") == '"'
    assert escape("\\x12") == chr(int("12", 16))
    assert escape("\\07") == chr(int("07", 8))
    # XXX: should we get an exception on invalid escapes?

# Generated at 2022-06-21 10:12:17.583148
# Unit test for function test
def test_test():
    test()
    assert True

# Generated at 2022-06-21 10:12:32.878093
# Unit test for function test
def test_test():
    import pytest
    with pytest.raises(AssertionError):
        test()


# Generated at 2022-06-21 10:12:42.911773
# Unit test for function evalString
def test_evalString():
    # Basic string tests
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"""abc"""') == "abc"
    assert evalString("'''abc'''") == "abc"
    assert evalString('"\\u0061bc"') == "abc"
    assert evalString("'\\u0061bc'") == "abc"
    assert evalString('"""\\u0061bc"""') == "abc"
    assert evalString("'''\\u0061bc'''") == "abc"
    # Escape tests
    assert evalString('"abc\\nabc"') == "abc\nabc"
    assert evalString("'abc\\nabc'") == "abc\nabc"

# Generated at 2022-06-21 10:12:48.529587
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\""') == '"'
    assert evalString("'a'") == "a"
    assert evalString("'\\''") == "'"
    assert evalString("'\\x07'") == "\x07"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\01'") == "\001"

# Generated at 2022-06-21 10:12:50.604190
# Unit test for function escape
def test_escape():
    # Escape must not modify non-escaped characters
    assert eval(escape('Test of escape function')) == 'Test of escape function'



# Generated at 2022-06-21 10:12:52.616324
# Unit test for function test
def test_test():
    test()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-21 10:12:53.586807
# Unit test for function test
def test_test():
    # test()
    # does not return anything
    pass

# Generated at 2022-06-21 10:12:54.975005
# Unit test for function test
def test_test():
    assert callable(test)

# Generated at 2022-06-21 10:13:06.923888
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc\r\t\n\r\n"') == 'abc\r\t\n\r\n'
    assert evalString("'abc\r\t\n\r\n'") == 'abc\r\t\n\r\n'
    assert evalString('"abc\\\'\'"') == "abc\\'"
    assert evalString("'abc\\\"'") == 'abc\\"'
    assert evalString("'abc\\'\\'\\''") == "abc\\'\\'\\'"
    assert evalString('"abc\"\"\""') == 'abc"""'
    assert evalString("'abc\\r'") == 'abc\r'
    assert evalString("'abc\\r\\n'") == 'abc\r\n'

# Generated at 2022-06-21 10:13:15.356655
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x62'") == "b"
    assert evalString("'\\0'") == "\x00"
    assert evalString("'\\03e'") == "\x1e"
    assert evalString("'\\x3e'") == ">"
    assert evalString("''") == ""
    assert evalString("'abc'") == "abc"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\''") == "'"
    assert evalString("'\"'") == '"'
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\x00'") == "\x00"
    assert evalString("'\\31'") == "1"

# Generated at 2022-06-21 10:13:27.027034
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\.", "\\'")) == "'"
    assert escape(re.match(r"\\.", '\\"')) == '"'
    assert escape(re.match(r"\\.", "\\\\")) == "\\"

    assert escape(re.match(r"\\.", "\\a")) == "\a"
    assert escape(re.match(r"\\.", "\\b")) == "\b"
    assert escape(re.match(r"\\.", "\\f")) == "\f"
    assert escape(re.match(r"\\.", "\\n")) == "\n"
    assert escape(re.match(r"\\.", "\\r")) == "\r"
    assert escape(re.match(r"\\.", "\\t")) == "\t"

# Generated at 2022-06-21 10:13:56.328080
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", "\\n")) == "\n"
    assert escape

# Generated at 2022-06-21 10:14:08.392958
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'abc'") == "abc"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\12"') == "\n"
    assert evalString('"\\012"') == "\n"
    assert evalString('"\\71"') == "G"
    assert evalString('"\\071"') == "G"
    assert evalString('"\\71"') == "G"
    assert evalString('"\\071"') == "G"
    assert evalString('"\\x71"') == "q"
    assert evalString('"\\x071"') == "q"
    assert evalString('"\\x071"') == "q"

# Generated at 2022-06-21 10:14:09.002499
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:16.670289
# Unit test for function evalString
def test_evalString():
    assert evalString("'''a'''") == 'a'
    assert evalString("'''\\'\\'\'a'''") == "'''"
    assert evalString("r'\\'\\'r'") == "\\''r"
    assert evalString("r'\\\"\\\"r'") == '\\""r'
    assert evalString("r'\\a\\br'") == "\\a\\br"
    assert evalString("'\\a\\b'") == "\a\b"
    assert evalString("'\\x61\\x62'") == "ab"
    assert evalString("'\\x6a\\x6b'") == "jk"
    assert evalString("'\\x6A\\x6b'") == "jk"

# Generated at 2022-06-21 10:14:17.357416
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:19.166254
# Unit test for function escape
def test_escape():
    assert escape("\\x20") == " "
    assert escape("\\n") == "\n"

# Generated at 2022-06-21 10:14:30.969096
# Unit test for function evalString
def test_evalString():
    # First test that the function handles triple quotes
    testStr = """'''"'""""''"""

# Generated at 2022-06-21 10:14:32.318526
# Unit test for function test
def test_test():
    """
    Unit test for function test
    """
    test()

# Generated at 2022-06-21 10:14:40.773598
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(x[0-9a-fA-F]{2}|[0-7]{1,3}|[abfnrtv'\"\\])", r"\x1f")
    assert m is not None
    assert m.group(1) == "x1f"
    m = re.match(r"\\(x[0-9a-fA-F]{2}|[0-7]{1,3}|[abfnrtv'\"\\])", r"\x1")
    assert m is not None
    assert m.group(1) == "x1"

# Generated at 2022-06-21 10:14:45.964052
# Unit test for function escape
def test_escape():
    string = r"\x0c"
    esc = escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", string))
    assert repr(esc) == repr("\x0c")

# Generated at 2022-06-21 10:15:27.362494
# Unit test for function evalString
def test_evalString():
    assert evalString("'hello'") == 'hello'
    assert evalString('"hello"') == 'hello'
    assert evalString('"hello\\tworld"') == 'hello\tworld'
    assert evalString(r'"hello\tworld"') == 'hello\tworld'



# Generated at 2022-06-21 10:15:31.602294
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\"\\\\\\""') == '"\\"\\\\\\""'
    assert evalString('"\\xb0"') == '\xb0'
    assert evalString('"\\xab"') == '\xab'
    assert evalString('"\\xba"') == '\xba'

# Generated at 2022-06-21 10:15:32.642093
# Unit test for function test
def test_test():  # TODO: implement
    pass

# Generated at 2022-06-21 10:15:43.638240
# Unit test for function escape
def test_escape():
    # Static
    assert escape(re.match("\\a", "a")) == "\a", "'a' should equal escape('\\a')"
    assert escape(re.match("\\b", "b")) == "\b", "'b' should equal escape('\\b')"
    assert escape(re.match("\\f", "f")) == "\f", "'f' should equal escape('\\f')"
    assert escape(re.match("\\n", "n")) == "\n", "'n' should equal escape('\\n')"
    assert escape(re.match("\\r", "r")) == "\r", "'r' should equal escape('\\r')"
    assert escape(re.match("\\t", "t")) == "\t", "'t' should equal escape('\\t')"

# Generated at 2022-06-21 10:15:54.860476
# Unit test for function evalString
def test_evalString():
    # <AK> added
    assert evalString('"\\001"') == '\x01'
    assert evalString('"\\002"') == '\x02'
    assert evalString('"\\003"') == '\x03'
    assert evalString('"\\004"') == '\x04'
    assert evalString('"\\005"') == '\x05'
    assert evalString('"\\006"') == '\x06'
    assert evalString('"\\007"') == '\x07'
    assert evalString('"\\010"') == '\x08'
    assert evalString('"\\011"') == '\t'
    assert evalString('"\\012"') == '\n'
    assert evalString('"\\013"') == '\x0b'

# Generated at 2022-06-21 10:15:59.413811
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(b)", r"\b")) == "\b"
    assert escape(re.search(r"\\(x)", r"\x")) == "\\x"
    assert escape(re.search(r"\\(x7)", r"\x7")) == "\u0007"
    assert escape(re.search(r"\\(x7f)", r"\x7f")) == "\u007f"


# Generated at 2022-06-21 10:16:11.782391
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\a", r"\a")) == "\a"
    assert escape(re.match("\\b", r"\b")) == "\b"
    assert escape(re.match("\\f", r"\f")) == "\f"
    assert escape(re.match("\\n", r"\n")) == "\n"
    assert escape(re.match("\\r", r"\r")) == "\r"
    assert escape(re.match("\\t", r"\t")) == "\t"
    assert escape(re.match("\\v", r"\v")) == "\v"
    assert escape(re.match("\\'", r"\'")) == "'"
    assert escape(re.match("\\\"", r"\"")) == "\""

# Generated at 2022-06-21 10:16:13.426702
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\a'") == '\a'
    assert evalString("'\\''") == "'"

# Generated at 2022-06-21 10:16:23.303006
# Unit test for function escape
def test_escape():
    # Matches single-char escape
    m = re.search(r"\\a", r"a")
    assert m
    assert escape(m) == "\a"

    # Matches multi-char escape
    m = re.search(r"\\b", r"b")
    assert m
    assert escape(m) == "\b"

    # Matches hex escape
    m = re.search(r"\\x61", r"a")
    assert m
    assert escape(m) == "a"

    # Raises an error if the hex escape is shorter than two characters
    m = re.search(r"\\x1", r"a")
    assert m
    with pytest.raises(ValueError):
        escape(m)

    # Raises an error on an invalid hex escape

# Generated at 2022-06-21 10:16:27.110011
# Unit test for function test
def test_test():
    """Test the evalString() function."""

    for i in range(256):
        s = repr(chr(i))
        c = evalString(s)
        assert (c, s) == (chr(i), repr(chr(i)))



# Generated at 2022-06-21 10:17:44.847757
# Unit test for function test
def test_test():
    import io
    result = io.StringIO()
    orig_stdout = sys.stdout
    try:
        sys.stdout = result
        test()
    finally:
        sys.stdout = orig_stdout
    # result.getvalue() will get the text that was written to the stream
    # by the call to test. It will be an empty string "'" if the test
    # didn't write anything. It will have a newline character at the end.
    assert result.getvalue() == '', 'Expected no output from test'

# Generated at 2022-06-21 10:17:45.416690
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:55.907131
# Unit test for function evalString
def test_evalString():
    assert evalString(r"""b'\U0001f44d'""") == '👍'
    assert evalString(r"""'\U0001f44d'""") == '👍'
    assert evalString(r"""'\uA4A4'""") == '꒤'
    assert evalString(r"""'\u2713\ufe0f'""") == '✓️'
    assert evalString(r"""'\u2713\uFE0F'""") == '✓️'
    assert evalString(r"""b"\u2713\uFE0F" # a comment""") == '✓️'
    assert evalString(r"""b"\\\u2713" # a comment""") == '\\✓'

# Generated at 2022-06-21 10:18:07.661619
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'abc' ") == "abc"
    assert evalString("'abc'\n") == "abc"
    assert evalString("'abc'\t") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString(r"'\x61\x62\x63'") == "abc"
    assert evalString(r"'\x61\x62\x6'") == "ab"

# Generated at 2022-06-21 10:18:14.865482
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', '\\a')) == '\a'
    assert escape(re.match('\\b', '\\b')) == '\b'
    assert escape(re.match('\\f', '\\f')) == '\x0c'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'
    assert escape(re.match('\\v', '\\v')) == '\x0b'
    assert escape(re.match('\\\\\\\\', '\\\\\\\\')) == '\\'
    assert escape(re.match('\\\'', '\\\'')) == '\''
   

# Generated at 2022-06-21 10:18:26.263451
# Unit test for function test
def test_test():
    string_list = [
        # Positive Testing
        ('"' + chr(i) + '"', chr(i)) for i in range(0x100)
        if chr(i) not in "\\'\"\n\r\t\b\f"
    ]
    string_list.extend(
        (f"'{chr(i)}'", chr(i))
        for i in range(0x100)
        if chr(i) not in "\\'\"\n\r\t\b\f" and i not in (0x27, 0x5C)
    )

# Generated at 2022-06-21 10:18:28.223943
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString("'\\\\'") == "\\"

# Generated at 2022-06-21 10:18:39.365307
# Unit test for function escape
def test_escape():
    import pytest
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) == "\b"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) == "\f"

# Generated at 2022-06-21 10:18:40.674003
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\\x41', '\\x41')) == 'A'

# Generated at 2022-06-21 10:18:42.330059
# Unit test for function evalString
def test_evalString():
    from .test.test_string_literals import test_evalString
    test_evalString()