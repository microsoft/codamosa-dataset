

# Generated at 2022-06-21 10:10:23.528578
# Unit test for function evalString
def test_evalString():
    import sys
    from .asttools import test_evalString as t
    sys.modules[__name__] = t
    from . import asttools
    del sys.modules[__name__]
    asttools.test_evalString()

# Generated at 2022-06-21 10:10:31.375063
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == 'a'
    assert evalString("'\\''") == "'"
    assert evalString("'\\x61'") == 'a'
    assert evalString("'\\x41'") == 'A'
    assert evalString("'\\101'") == 'A'
    assert evalString("'\\001'") == '\x01'
    assert evalString("'\\n'") == '\n'
    assert evalString('"\\n"') == '\n'

# Generated at 2022-06-21 10:10:41.364761
# Unit test for function evalString
def test_evalString():
    assert evalString("'''a'''") == "a"
    assert evalString("'''abc'''") == "abc"
    assert evalString("'''\\'''") == "'"
    assert evalString('"""a"""') == "a"
    assert evalString('"""\\"""') == '"'
    assert evalString('"""\\\\"""') == "\\"
    assert evalString('"""\\\'"' + chr(1) + '"""') == '"\'\x01'
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, "%d %s %s %s" % (i, c, s, e)

# Generated at 2022-06-21 10:10:53.911028
# Unit test for function evalString
def test_evalString():
    # Single quoted strings
    assert evalString("'''x'x'x'''") == "'x'x'x'"
    assert evalString("'foo'") == "foo"
    assert evalString("'bar\nbaz'") == 'bar\nbaz'
    assert evalString("'a\\\\b'") == 'a\\b'
    assert evalString("'a\\'b'") == "a'b"
    assert evalString("'a\"b'") == 'a"b'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'\\xaa'") == chr(0xaa)
    assert evalString("'\\377'") == chr(0xff)
    assert eval

# Generated at 2022-06-21 10:10:55.309682
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError:
        pass

# Generated at 2022-06-21 10:11:06.692750
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-21 10:11:17.654144
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\x01", "\\x01")) == "\x01"
    assert escape(re.search(r"\\X01", "\\X01")) == "\x01"
    assert escape(re.search(r"\\123", "\\123")) == "\123"
    assert escape(re.search(r"\\\n", "\\\n")) == "\n"
    assert escape(re.search(r"\\z", "\\z")) == "z"
    assert escape(re.search(r"\\xff", "\\xff")) == "\xff"
    assert escape(re.search(r"\\x1234", "\\x1234")) == "\x1234"
    assert escape(re.search(r"\\777", "\\777")) == "\777"

# Generated at 2022-06-21 10:11:29.365679
# Unit test for function escape
def test_escape():
    assert escape("\\") == "\\"
    assert escape("\\a") == "\a"
    assert escape("\\0") == "\0"
    assert escape("\\00") == "\0"
    assert escape("\\000") == "\0"
    assert escape("\\01") == "\1"
    assert escape("\\012") == "\12"
    assert escape("\\0123") == "\123"
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"

# Generated at 2022-06-21 10:11:30.609029
# Unit test for function test
def test_test():
    with pytest.raises(AssertionError):
        test()

# Generated at 2022-06-21 10:11:31.152658
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-21 10:11:46.828639
# Unit test for function test
def test_test(): test()

# Generated at 2022-06-21 10:11:51.909111
# Unit test for function evalString
def test_evalString():
    assert evalString('""') == ""
    assert evalString('"test"') == "test"

    assert evalString('"test\\""') == "test\""
    assert evalString('"test\\xFF"') == "test\\xFF"

    # Unsupported
    with raises(ValueError):
        evalString('"test\\r\\n"')

# Generated at 2022-06-21 10:12:03.467305
# Unit test for function escape
def test_escape():
    s = r"\a, \b, \f, \n, \r, \t, \v, \\, \x61, \0, \042"
    e = escape(re.search(r"\\[abfnrtv\\x042]", s))
    assert e == "\a"
    e = escape(re.search(r"\\[abfnrtv\\x042]", s[2:]))
    assert e == "\b"
    e = escape(re.search(r"\\[abfnrtv\\x042]", s[4:]))
    assert e == "\f"
    e = escape(re.search(r"\\[abfnrtv\\x042]", s[6:]))
    assert e == "\n"

# Generated at 2022-06-21 10:12:15.872432
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == 'a'
    assert evalString('"ab"') == 'ab'
    assert evalString('"a\\nb"') == 'a\nb'
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\n'") == "\n"
    assert evalString('"a\\nb\\tc"') == "a\nb\tc"
    assert evalString('"\\u1234"') == "\u1234"

# Generated at 2022-06-21 10:12:28.656893
# Unit test for function escape
def test_escape():
    # Verify that escape will correctly process all escape codes
    for code, char in simple_escapes.items():
        assert escape(re.match(f"\\\{code}", "\\" + code)) == char
    assert escape(re.match(r"\\x01", "\\x01")) == chr(1)
    assert escape(re.match(r"\\x42", "\\x42")) == chr(66)
    assert escape(re.match(r"\\x0a", "\\x0a")) == chr(10)
    assert escape(re.match(r"\\x0f", "\\x0f")) == chr(15)
    assert escape(re.match(r"\\xab", "\\xab")) == chr(171)

# Generated at 2022-06-21 10:12:29.049164
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:29.548865
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:12:32.706196
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        print(e)
test_test()

# Generated at 2022-06-21 10:12:33.628178
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'

# Generated at 2022-06-21 10:12:43.505527
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\011"') == "\t"
    assert evalString("'\\011'") == "\t"
    assert evalString("'\\x1A'") == "\x1a"
    assert evalString('"\\x1A"') == "\x1a"
    assert evalString("'\\xaa'") == "\xaa"
    assert evalString('"\\xaa"') == "\xaa"
    assert evalString("'\\0'") == "\x00"
    assert evalString("'\\0'") == "\x00"
    assert evalString("'\\0\\''") == "\x00'"
    assert evalString("'\\0\\''") == "\x00'"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\\\'") == "\\"
    assert eval

# Generated at 2022-06-21 10:12:55.119781
# Unit test for function escape
def test_escape():
    for x in simple_escapes:
        assert escape(re.match('\\' + x, '')) == simple_escapes[x]


# Generated at 2022-06-21 10:13:07.079482
# Unit test for function escape
def test_escape():
    assert escape(r'\x41') == 'A'
    assert escape(r'\xAE') == '®'
    assert escape(r'\u0041') == 'A'
    assert escape(r'\u00AE') == '®'
    assert escape(r'\u1F641') == '🙁'
    assert escape(r'\U0001F641') == '🙁'
    assert escape(r'\x0A') == '\n'
    assert escape(r'\x0D') == '\r'
    assert escape(r'\x09') == '\t'
    assert escape(r'\x20') == ' '
    assert escape(r'\x5c') == '\\'
    assert escape(r'\x5C') == '\\'

# Generated at 2022-06-21 10:13:12.056836
# Unit test for function evalString
def test_evalString():
    s = "'abc'"
    assert evalString(s) == "abc"
    s = '"abc"'
    assert evalString(s) == "abc"
    s = '"ab\'c"'
    assert evalString(s) == "ab'c"
    s = '"ab"c"'
    assert evalString(s) == 'ab"c'
    s = '"ab\"c"'
    assert evalString(s) == 'ab"c'
    s = '"ab\\"c"\n'
    assert evalString(s) == 'ab"c'
    s = "'''ab\'c'''"
    assert evalString(s) == "ab'c"
    s = 'r"ab\\"c",\n'
    assert evalString(s) == r'ab\"c'

# Generated at 2022-06-21 10:13:23.635130
# Unit test for function escape

# Generated at 2022-06-21 10:13:33.729299
# Unit test for function escape
def test_escape():
    # test when escape sequence is a in "\a"
    assert escape(re.search(r"\\a", r"\a")) == "\a"
    # test when escape sequence is b in "\b"
    assert escape(re.search(r"\\b", r"\b")) == "\b"
    # test when escape sequence is f in "\f"
    assert escape(re.search(r"\\f", r"\f")) == "\f"
    # test when escape sequence is n in "\n"
    assert escape(re.search(r"\\n", r"\n")) == "\n"
    # test when escape sequence is r in "\r"
    assert escape(re.search(r"\\r", r"\r")) == "\r"
    # test when escape sequence is t in "\t"

# Generated at 2022-06-21 10:13:46.110010
# Unit test for function evalString

# Generated at 2022-06-21 10:13:46.691160
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-21 10:13:48.671272
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        assert False, "test function failed"

# Generated at 2022-06-21 10:13:58.780332
# Unit test for function escape
def test_escape():
    import pytest

    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x99", "\\x99")) == "\x99"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xff"


# Generated at 2022-06-21 10:13:59.333335
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:14:33.188738
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x55\\x6e\\x69\\x63\\x6f\\x64\\x65"') \
        == 'unicode'
    assert evalString("'\\x55\\x6e\\x69\\x63\\x6f\\x64\\x65'") \
        == 'unicode'
    assert evalString('"\a"') == '\a'

# Generated at 2022-06-21 10:14:35.543072
# Unit test for function escape
def test_escape():
    assert escape("\\x0a") == "\n", "  +++Failed test escape() with \\x0a"


# Generated at 2022-06-21 10:14:37.123847
# Unit test for function test
def test_test():
    try:
        test()
    except SystemExit as e:
        raise AssertionError(e)

# Generated at 2022-06-21 10:14:44.827530
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\000"') == "\x00"
    assert evalString('"\\000\\001\\002"') == "\x00\x01\x02"
    assert evalString('"\\x00"') == "\x00"
    assert evalString('"\\x00\\x01\\x02"') == "\x00\x01\x02"
    assert evalString('"\\073"') == "#"
    assert evalString("'\\073'") == "#"
    assert evalString("'''\\073'''") == "#"

# Generated at 2022-06-21 10:14:50.145565
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\x61"') == "a"
    assert evalString('"a"') == "a"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\07"') == "\x07"
    assert evalString('"\\057"') == "/"
    assert evalString('"\\6"') == "\x06"
    assert evalString('"\\06"') == "\x06"
    assert evalString('"\\006"') == "\x06"
    assert evalString('"\\1106"') == "N6"
    assert evalString('"\\11106"') == "\x19\x06"
    assert evalString('"\\1111106"') == "\x19\x19\x06"

# Generated at 2022-06-21 10:14:50.819931
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:15:00.648093
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\xac\\u1234\\U00008000"') == u'\xac\u1234\U00008000'
    assert evalString('"\\u1234\\U00008000"') == u'\u1234\U00008000'
    assert evalString('"\\U00008000"') == u'\U00008000'
    assert evalString('"\xac\u1234\U00008000"') == u'\xac\u1234\U00008000'
    assert evalString('"\u1234\U00008000"') == u'\u1234\U00008000'
    assert evalString('"\U00008000"') == u'\U00008000'

# Generated at 2022-06-21 10:15:12.218532
# Unit test for function escape
def test_escape():
    # Test a variety of escape sequences
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"

# Generated at 2022-06-21 10:15:12.823116
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-21 10:15:23.147860
# Unit test for function evalString
def test_evalString():
    # test for normal string case
    assert evalString("'abcd'") == "abcd"
    assert evalString("'abcd\nefg'") == "abcd\nefg"
    assert evalString("'abcd\tefg'") == "abcd\tefg"
    assert evalString('"abcd"') == "abcd"
    assert evalString('"abcd\nefg"') == "abcd\nefg"
    assert evalString('"abcd\tefg"') == "abcd\tefg"

    # test for invalid case
    passed = True
    try:
        evalString("'abcd'e")
    except ValueError:
        passed = False
    assert not passed

    try:
        evalString('"abcd"e')
    except ValueError:
        passed = False

# Generated at 2022-06-21 10:16:52.611885
# Unit test for function escape
def test_escape():
    import pytest

    # test tail is in escape map
    test_tail = [
        ("a", "\a"),
        ("b", "\b"),
        ("f", "\f"),
        ("n", "\n"),
        ("r", "\r"),
        ("t", "\t"),
        ("v", "\v"),
        ("'", "'"),
        ('"', '"'),
        ("\\", "\\"),
    ]
    for tail, esc in test_tail:
        m = re.match("\\" + tail, "\\" + tail)
        assert escape(m) == esc

    # test tail is not in escape map

# Generated at 2022-06-21 10:16:59.912139
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", "\\x12")) == chr(int("12",16))
    assert escape(re.match(r"\\x1", "\\x1")) == chr(int("1",16))
    assert escape(re.match(r"\\x", "\\x")) == chr(int("x",16))
    assert escape(re.match(r"\\xg", "\\xg")) == chr(int("g",16))
    assert escape(re.match(r"\\5", "\\5")) == chr(5)
    assert escape(re.match(r"\\a", "\\a")) == "\a"


# Generated at 2022-06-21 10:17:01.264903
# Unit test for function test
def test_test():
    with capture_out() as s:
        test()
    assert not s.getvalue()

# Generated at 2022-06-21 10:17:03.498958
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"
    assert escape("\\x1b") == "\x1b"



# Generated at 2022-06-21 10:17:10.086236
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\n"') == "\n"
    assert evalString("'''\\n'") == "\n"
    assert evalString("'a'") == "a"
    assert evalString("'abc'") == "abc"
    assert evalString('"abc"') == "abc"
    assert evalString("'a' * 20") == "a" * 20
    assert evalString('"a" * 20') == "a" * 20
    assert evalString("''''") == ""
    assert evalString('""""') == ""
    assert evalString("'x" "y'") == "xy"
    assert evalString('"x" "y"') == "xy"
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)


# Generated at 2022-06-21 10:17:11.441292
# Unit test for function test
def test_test():
    _input = test()
    assert _input == None

# Generated at 2022-06-21 10:17:14.408405
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\n'") == "\n"
    assert evalString('"\\x63"') == "c"
    assert evalString('"\\07"') == "\x07"

# Generated at 2022-06-21 10:17:26.118452
# Unit test for function evalString

# Generated at 2022-06-21 10:17:26.705522
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-21 10:17:27.489663
# Unit test for function test
def test_test():
    test()