

# Generated at 2022-06-11 19:35:15.658542
# Unit test for function evalString

# Generated at 2022-06-11 19:35:24.187246
# Unit test for function test
def test_test():
    import warnings
    import io

    class TestError(Exception):
        pass

    class StdOut(io.StringIO):
        def __init__(self, max_output=100):
            self.max_output = max_output
            super().__init__()

        def getvalue(self):
            value = super().getvalue()
            if len(value) > self.max_output:
                raise TestError("Expected output of %s should not exceed %s. Be more specific"
                                % (value, self.max_output))
            return value

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        real_stdout = sys.stdout
        sys.stdout = StdOut(max_output=70)

# Generated at 2022-06-11 19:35:28.974526
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "'\n'")) == "\n"

# Generated at 2022-06-11 19:35:32.028873
# Unit test for function evalString
def test_evalString():
    # NOTE: This function is not used anywhere in the library so this unit
    # test is just a smoke test.
    evalString('"""foo"""')
    evalString("'foo'")

# Generated at 2022-06-11 19:35:37.390848
# Unit test for function evalString
def test_evalString():
    assert evalString('"foo"') == 'foo'
    assert evalString("'foo'") == 'foo'
    assert evalString('"foo bar"') == 'foo bar'
    assert evalString("'foo bar'") == 'foo bar'
    assert evalString('"foo \'bar\'"') == "foo 'bar'"
    assert evalString("'foo \"bar\"'") == 'foo "bar"'

# test_evalString()

# Generated at 2022-06-11 19:35:38.809477
# Unit test for function escape
def test_escape():
    assert escape('\\x0b') == '\x0b'

# Generated at 2022-06-11 19:35:47.355352
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == 'abc'
    assert evalString("'abc'") == eval("'abc'")

    assert evalString("'ab\'c'") == 'ab\'c'
    assert evalString("'ab\\\''") == 'ab\\\''
    assert evalString("'ab\\\'c'") == 'ab\\\'c'
    assert evalString("'ab\\\\c'") == 'ab\\\\c'

    assert evalString("'ab\\\'c'") == eval("'ab\\\'c'")
    assert evalString("'ab\\\\c'") == eval("'ab\\\\c'")

    assert evalString("'ab\\\''") == eval("'ab\\\''")
    assert evalString("'ab\\\''") == eval("r'ab\\\'")


# Generated at 2022-06-11 19:35:52.888800
# Unit test for function escape

# Generated at 2022-06-11 19:35:59.683763
# Unit test for function evalString
def test_evalString():
    # Some basic tests of correctness.
    print("Basic tests:")
    print('evalString("\'\t\\x07\\007\\0007\'") == ', evalString("'\t\\x07\\007\\0007'"))
    print('evalString("\'\\n\\r\\b\\t\\f\\v\\a\'") == ', evalString("'\\n\\r\\b\\t\\f\\v\\a'"))
    print("evalString('\'\\\\\\'\'') == '\\''", evalString("'\\\\\\''") == "\\'")
    print("evalString('\"\\\\\"\"') == '\"'", evalString('"\\\\\""') == '"')
    print("evalString('\"\\\\\'\"') == '\\''", evalString("'\\\\\\''") == "\\'")

# Generated at 2022-06-11 19:36:10.371034
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\v")) == "\v"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\xFF")) == "\xff"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\'\"\\0rtv\xFF")) == "'\"\\\x00rtv\xff"

# Generated at 2022-06-11 19:36:32.173112
# Unit test for function escape
def test_escape():
    # print(escape('a'))
    # print(escape('b'))
    # print(escape('f'))
    # print(escape('n'))
    # print(escape('r'))
    # print(escape('t'))
    # print(escape('v'))
    # print(escape('\''))
    # print(escape('\\'))
    # print(escape('x3c'))
    # print(escape('x3a'))
    # print(escape('x1'))
    print(escape(r'\u'))
    print(escape(r'\U'))

# Generated at 2022-06-11 19:36:32.694338
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:36:41.470498
# Unit test for function escape
def test_escape():
    """
    >>> escape(re.match(r'\\', 'a'))
    Traceback (most recent call last):
    ValueError: invalid hex string escape ('\\a')
    >>> escape(re.match(r'\\([abfnrtv]|x.{0,2}|[0-7]{3})', '\\01'))
    Traceback (most recent call last):
    ValueError: invalid octal string escape ('\\01')
    >>> escape(re.match(r'\\([abfnrtv]|x.{0,2}|[0-7]{3})', '\\x1'))
    Traceback (most recent call last):
    ValueError: invalid hex string escape ('\\x1')
    """
    pass


if __name__ == "__main__":
    import doctest

    doct

# Generated at 2022-06-11 19:36:41.950668
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:36:53.357057
# Unit test for function escape
def test_escape():
    # This unit test is to test octal escape sequence since its behavior varies
    # with Python version.
    # Python 2 allows stray digits at the end of octal escape sequence.
    # Python 3 does not.  The behavior is changed in Python 3.1.
    class unit_test(object):
        def __init__(self, actual, expected):
            self.actual = actual
            self.expected = expected


# Generated at 2022-06-11 19:37:03.869564
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape('\\x') == '\\x'
    assert escape('\\xx') == '\\xx'
    assert escape('\\xxx') == '\x78'
    assert escape('\\x00') == '\x00'
    assert escape('\\xAB') == '\xAB'
    assert escape('\\xab') == '\xab'
    assert escape('\\xABc') == '\xABc'
    assert escape('\\0') == '\x00'
    assert escape('\\07') == '\x07'
    assert escape('\\077') == '?'

# Generated at 2022-06-11 19:37:11.193835
# Unit test for function escape
def test_escape():
    expected_mapping_list = [
        ("\\\\", "\\"),
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\x00", "\x00"),
        ("\\777", "\xff"),
    ]
    for escaped_string, actual_string in expected_mapping_list:
        match = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", escaped_string)
        assert match is not None

# Generated at 2022-06-11 19:37:14.020120
# Unit test for function escape
def test_escape():
    assert escape("\\n") == "\n"
    assert escape("\\'") == "'"
    assert escape("\\x3a") == ":"

# Generated at 2022-06-11 19:37:20.710258
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\(x.{0,2})", "NS\\x11")) == "\x11"
    assert escape(re.search(r"\\(x.{0,2})", "NS\\x0")) == "\x00"
    assert escape(re.search(r"\\(x.{0,2})", "NS\\x00")) == "\x00"
    assert escape(re.search(r"\\(x.{0,2})", "NS\\x")) == "\\x"

    assert escape(re.search(r"\\([0-7]{1,3})", "NS\\501")) == "\x01"
    assert escape(re.search(r"\\([0-7]{1,3})", "NS\\512")) == "\x12"

# Generated at 2022-06-11 19:37:30.764693
# Unit test for function escape
def test_escape():
    if escape(re.match('a', '\a')) == '\a':
        print("Passed 1")
    else:
        print("Failed 1")
    if escape(re.match('b', '\b')) == '\b':
        print("Passed 2")
    else:
        print("Failed 2")
    if escape(re.match('f', '\f')) == '\f':
        print("Passed 3")
    else:
        print("Failed 3")
    if escape(re.match('n', '\n')) == '\n':
        print("Passed 4")
    else:
        print("Failed 4")
    if escape(re.match('r', '\r')) == '\r':
        print("Passed 5")
    else:
        print

# Generated at 2022-06-11 19:37:54.912926
# Unit test for function escape
def test_escape():
    try:
        m = re.match(r"\\(x[0-9A-Fa-f]{1,2})", "\\x1aX")
        escape(m)
    except ValueError as e:
        assert str(e) == ("invalid hex string escape ('\\x1a')")
    try:
        m = re.match(r"\\(x[0-9A-Fa-f]{1,2})", "\\x1a")
        escape(m)
    except ValueError as e:
        assert str(e) == ("invalid hex string escape ('\\x1a')")

# Generated at 2022-06-11 19:37:57.858701
# Unit test for function test
def test_test():
    import pytest
    from . import cStringIO

    capture = cStringIO.StringIO()
    try:

        with pytest.raises(AttributeError) as excinfo:
            test()
    finally:
        pass
    return

# Generated at 2022-06-11 19:37:58.861634
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:38:10.242655
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"

# Generated at 2022-06-11 19:38:21.424881
# Unit test for function escape
def test_escape():
    assert escape(re.search('\\a', '\a')) == '\a'
    assert escape(re.search('\\b', '\b')) == '\b'
    assert escape(re.search('\\f', '\f')) == '\f'
    assert escape(re.search('\\n', '\n')) == '\n'
    assert escape(re.search('\\r', '\r')) == '\r'
    assert escape(re.search('\\t', '\t')) == '\t'
    assert escape(re.search('\\v', '\v')) == '\v'
    assert escape(re.search('\\\'', '\'')) == '\''
    assert escape(re.search('\\"', '"')) == '"'

# Generated at 2022-06-11 19:38:30.040041
# Unit test for function escape
def test_escape():
    import textwrap
    code = 'test_escape(r"\\x49\\x99\\x99\\x99\\x99\\x99\\xF9\\x3F")'
    expected = textwrap.dedent("""\
    125
    1   def test_escape(s):
    2       if evalString(s) != 1.1:
    3           print(s, evalString(s))
    4   test_escape("\\\\x49\\\\x99\\\\x99\\\\x99\\\\x99\\\\x99\\\\xF9\\\\x3F")""")
    assert evalString(code) == expected

# Generated at 2022-06-11 19:38:32.921938
# Unit test for function test
def test_test():
    try:
        test()
    # We need to catch all exceptions
    except Exception:
        assert False

# Generated at 2022-06-11 19:38:35.422167
# Unit test for function test
def test_test():
    # Test for simple cases
    assert evalString("'a'") == "a"


# Generated at 2022-06-11 19:38:46.335522
# Unit test for function escape

# Generated at 2022-06-11 19:38:51.731449
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x48", "\\x48")) == 'H'
    assert escape(re.match(r"\\xH", "\\xH")) == 'H'
    # assert escape(re.match(r"\\xHH", "\\xHH")) == 'HH'
    assert escape(re.match(r"\\xHH", "\\xHH")) == '\x00H'

# Generated at 2022-06-11 19:39:16.307976
# Unit test for function escape
def test_escape():
    assert escape('abc') == 'abc'
    assert escape('\\') == '\\'
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'


# Generated at 2022-06-11 19:39:18.185234
# Unit test for function test
def test_test():
    try:
        test()
    except AssertionError:
        print("Unit test failed")

# Generated at 2022-06-11 19:39:19.374241
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:26.111259
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\t")) == "\t"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"

# Generated at 2022-06-11 19:39:28.221398
# Unit test for function test
def test_test():
    import io
    from contextlib import redirect_stdout

    f = io.StringIO()
    with redirect_stdout(f):
        test()
    assert f.getvalue() == ""

# Generated at 2022-06-11 19:39:30.853126
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(.)", r"\x123")
    assert m is not None
    esc = escape(m)
    assert esc == "S"


# Generated at 2022-06-11 19:39:34.624576
# Unit test for function escape
def test_escape():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        if e != c:
            print(i, c, s, e)

# Generated at 2022-06-11 19:39:35.407937
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:40.990220
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        assert False, "Unit test for function test failed."


__test__ = {name: value for name, value in locals().items() if name.startswith("test_")}

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 19:39:46.699834
# Unit test for function escape
def test_escape():
    def check(s, want):
        # type: (str, str) -> None
        got = escape(re.match(r"\\(.)", s))
        if got != want:
            raise ValueError("%r -> %r, but want %r" % (s, got, want))

    check("\\a", "\a")  # a single character
    check("\\'", "'")  # a single character
    check("\\001", "\1")  # an octal escape
    check("\\x001", "\x01")  # a hex escape


# Generated at 2022-06-11 19:40:42.788804
# Unit test for function escape
def test_escape():
    test_string = "\\'\\a\\b\\f\\n\\r\\t\\v\\x61\\101\\1\\"

# Generated at 2022-06-11 19:40:43.375590
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:40:48.832773
# Unit test for function escape
def test_escape():
    assert escape(re.match("\\", "\\")) == "\\"
    assert escape(re.match("\\'", "\\'")) == "'"
    assert escape(re.match("\\x", "\\x")) == "x"
    assert escape(re.match("\\x'", "\\x'")) == "x'"
    assert escape(re.match("\\x'", "\\xa")) == "\n"

# Generated at 2022-06-11 19:40:59.303629
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\"') == '"'
    assert escape('\\\\') == '\\'
    assert escape('\\xFF') == '\xFF'
    assert escape('\\xF') == '\x0F'
    assert escape('\\377') == '\xFF'
    assert escape('\\377') == '\xFF'
    assert escape('\\3') == '\x03'


# Generated at 2022-06-11 19:41:01.804943
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:41:03.105126
# Unit test for function test
def test_test():
    test()

# vim:sts=4:ts=4:sw=4:et

# Generated at 2022-06-11 19:41:04.020574
# Unit test for function test
def test_test():
    # Nothing to do here
    return

# Generated at 2022-06-11 19:41:14.793200
# Unit test for function escape
def test_escape():
    test_cases = [
        ("\\x41", "A"),
        ("\\c", "c"),
        ("\\", "\\"),
        ("\\x1", "x1"),
        ("\\999", "999"),
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\ ", " "),
    ]
    for test_case in test_cases:
        code = test_case[0]
        expected = test_case[1]
        result = escape(re.match("^\\.{1}", code))

# Generated at 2022-06-11 19:41:15.230749
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:41:17.489569
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:21.757626
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-11 19:42:22.439364
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:23.468131
# Unit test for function test
def test_test():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 19:42:24.766656
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:27.301030
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\xaf', '\\xaf')) == '\xaf'
    assert escape(re.match(r'\\xfr', '\\xfr')) == '\x0fr'

# Generated at 2022-06-11 19:42:27.843054
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:36.713727
# Unit test for function escape
def test_escape():

    # Test escapes
    from unittest import TestCase

    class Escape(TestCase):
        def test_basic(self):
            for key, value in simple_escapes.items():
                with self.subTest(key=key, value=value):
                    match = re.match(
                        r"\\" + key, escape(re.match(r"\\" + key + r"(.)", "x"))
                    )
                    self.assertIsNotNone(match)
                    self.assertEqual(match.group(1), value)

# Generated at 2022-06-11 19:42:43.408661
# Unit test for function escape
def test_escape():
    # Invalid strings
    invalid_strings = [
        ("\\x", "should not be greater than 2"),
        ("\\x1", "should not be greater than 2"),
        ("\\000", "should not be greater than 3"),
        ("\\0000", "should not be greater than 3"),
    ]

    for esc_str, error_msg in invalid_strings:
        try:
            escape(re.match(r"\\(.*)", esc_str))
        except ValueError as exc:
            assert error_msg in str(exc)

# Generated at 2022-06-11 19:42:44.920848
# Unit test for function test
def test_test():
    """Should not cause an exception"""
    test()

# Generated at 2022-06-11 19:42:45.526371
# Unit test for function test
def test_test():
    test()