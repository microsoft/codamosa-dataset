

# Generated at 2022-06-11 19:34:51.937868
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:35:00.006000
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'a\\\\bc'") == "a\\bc"
    assert evalString("'a\\'bc'") == "a'bc"
    assert evalString('"a\\"bc"') == 'a"bc'
    assert evalString("'\\x61\\x62\\x63'") == "abc"
    assert evalString("'\\061\\062\\063'") == "abc"
    assert evalString("'\\141\\142\\143'") == "abc"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"

# Generated at 2022-06-11 19:35:04.237707
# Unit test for function escape
def test_escape():
    test_str = r"\\xab\\xaf"
    assert escape(re.match(r"\\xaf", test_str)) == chr(0xaf)
    assert escape(re.match(r"\\xab", test_str)) == chr(0xab)

# Generated at 2022-06-11 19:35:09.875789
# Unit test for function escape
def test_escape():
    test_input = r"\\xf"
    test_expect = "\\x0f"
    actual = escape(re.match(fr"\\(.*)", test_input))
    print('f"{actual}", expected=f"{test_expect}" ')
    assert actual == test_expect


# Generated at 2022-06-11 19:35:21.543075
# Unit test for function escape
def test_escape():

    def test_one(input, result):
        assert escape(re.match(r'\\' + input, "")) == result

    # simple escapes
    for code, char in simple_escapes.items():
        test_one(code, char)

    # hex escapes
    for i in range(256):
        test_one(r'x' + "{:02x}".format(i), chr(i))

    # octal escapes
    for i in range(256):
        test_one(r'{:03o}'.format(i), chr(i))

    # Invalid escapes
    import pytest

    with pytest.raises(ValueError):
        escape(re.match(r"\x", ""))

# Generated at 2022-06-11 19:35:31.322877
# Unit test for function escape
def test_escape():
    for esc, target in simple_escapes.items():
        assert escape(re.match("\\" + esc + "$", esc)) == target
    assert escape(re.match("\\x41$", "A")) == "A"
    assert escape(re.match("\\41$", "A")) == "A"
    assert escape(re.match("\\041$", "A")) == "A"
    assert escape(re.match("\\x0$", "\x00")) == "\x00"
    assert escape(re.match("\\00$", "\x00")) == "\x00"
    assert escape(re.match("\\000$", "\x00")) == "\x00"
    assert escape(re.match("\\x$", "")) == ""
    assert escape(re.match("\\369$", "A")) == "A"


# Generated at 2022-06-11 19:35:35.196219
# Unit test for function escape
def test_escape():
    test_data = {'\\x48': 'H', '\\x48\\x49': 'HI', '\\x48\\x49\\x50': 'HIP'}
    for key in test_data:
        assert escape(key) == test_data[key]

# Generated at 2022-06-11 19:35:36.495116
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-11 19:35:43.096054
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", "\\x12")) == "x12"
    assert escape(re.match(r"\\(.)", "\\12")) == "12"
    assert escape(re.match(r"\\(.)", "\\")) == "\\"
    assert escape(re.match(r"\\(.)", "\\'")) == "'"
    assert escape(re.match(r"\\(.)", '\\"')) == '"'


# Generated at 2022-06-11 19:35:55.411185
# Unit test for function evalString
def test_evalString():
    # test a bunch of edge cases

    # this was a problem
    assert evalString(r'"\""') == '"'
    assert evalString(r"'\''") == "'"
    assert evalString(r'"\a\b\f\n\r\t\v"') == "\a\b\f\n\r\t\v"
    assert evalString(r'"\"\'"') == '"\''
    assert evalString(r'"\'"') == '\''
    assert evalString(r"'" + repr("'") + "'") == repr("'")
    assert evalString(r"'" + repr("'") + r"'") == repr("'")
    assert evalString(r"'" + repr(r"\'") + r"'") == repr(r"\'")

# Generated at 2022-06-11 19:36:27.770614
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\'") == "'"
    assert evalString("'\\x20'") == " "
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\v'") == "\v"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\001'") == "\x01"
    assert evalString("'\\111'") == "\x49"
    assert evalString

# Generated at 2022-06-11 19:36:37.278229
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\x00'") == '\x00'
    assert evalString('"\\x00"') == '\x00'
    assert evalString("'\\a'") == '\a'
    assert evalString('"\\a"') == '\a'
    assert evalString("'foo'") == 'foo'
    assert evalString('"foo"') == 'foo'
    assert evalString("''") == ''
    assert evalString('""') == ''
    assert evalString("'foo-bar\\xbaz'") == 'foo-bar\xbaz'
    assert evalString('"foo-bar\\xbaz"') == 'foo-bar\xbaz'
    assert evalString("'foo-bar\\13'") == 'foo-bar\r'
    assert evalString('"foo-bar\\13"')

# Generated at 2022-06-11 19:36:48.751360
# Unit test for function escape
def test_escape():
    # Test a single, normal character
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    # Test a single hex character
    assert escape(re.match(r"\\x00", r"\x00")) == "\x00"
    assert escape(re.match(r"\\xFF", r"\xFF")) == "\xFF"
    # Test a single hex character with invalid number of pure hex digits
    with pytest.raises(ValueError):
        escape(re.match(r"\\x0", r"\x0"))
    with pytest.raises(ValueError):
        escape(re.match(r"\\x000000", r"\x000000"))
    # Test a single hex character with invalid pure hex digits

# Generated at 2022-06-11 19:36:56.637865
# Unit test for function evalString
def test_evalString():
    assert len(evalString('""')) == 0
    assert len(evalString('"\\n"')) == 1
    assert len(evalString("'")) == 0
    assert len(evalString("'\\n'")) == 1
    assert evalString('""') == evalString("''")
    assert evalString('"\\n"') == evalString("'\\n'")
    assert evalString('"\\n"') == evalString('"\\n"')

    assert evalString(r'"abc"') == 'abc'
    assert evalString(r"'xyz'") == 'xyz'
    assert evalString(r'"a\'b"') == "a'b"
    assert evalString(r"'a\"b'") == 'a"b'
    assert evalString(r'"a\"b"') == 'a"b'
   

# Generated at 2022-06-11 19:36:57.327938
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:37:07.578721
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == "abc"
    assert evalString("'\n'") == "\n"
    assert evalString("'\xFF'") == "\xFF"
    assert evalString('"\xFF"') == "\xFF"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\n\\t"') == "\n\t"
    assert evalString('"\\\\n"') == "\\n"
    assert evalString('"\\"abc\\""') == '"abc"'
    assert evalString('"\'abc\'"') == "'abc'"
    assert evalString('"\\a"') == "\a"

# Generated at 2022-06-11 19:37:10.453154
# Unit test for function evalString
def test_evalString():
    s = "b'abc123'"
    assert evalString(s) == s[2:]

# Generated at 2022-06-11 19:37:18.452728
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\a')) == '\a'
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\x61')) == 'a'
    assert escape(re.match(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', '\\\'')) == '\''



# Generated at 2022-06-11 19:37:23.509068
# Unit test for function test
def test_test():
    tests = []
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        tests.append(e == c)
    assert all(tests)

# Generated at 2022-06-11 19:37:31.665464
# Unit test for function evalString
def test_evalString():
    assert evalString('"abc"') == 'abc'
    assert evalString("'abc'") == 'abc'
    assert evalString('"a\nb"') == 'a\nb'
    assert evalString("'a\nb'") == 'a\nb'
    assert evalString('"\\a\\t\\\\"') == '\a\t\\'
    assert evalString("'\\a\\t\\\\'") == '\a\t\\'
    assert evalString('"\\xff"') == '\xff'
    assert evalString("'\\xff'") == '\xff'
    assert evalString('"\\x00"') == '\x00'
    assert evalString("'\\x00'") == '\x00'
    assert evalString('"""a"""') == "a"

# Generated at 2022-06-11 19:37:53.623287
# Unit test for function escape
def test_escape():
    assert(escape(re.match('\a','\a')) == '\x07')
    assert(escape(re.match('\b','\b')) == '\x08')
    assert(escape(re.match('\f','\f')) == '\x0c')
    assert(escape(re.match('\n','\n')) == '\x0a')
    assert(escape(re.match('\r','\r')) == '\x0d')
    assert(escape(re.match('\t','\t')) == '\x09')
    assert(escape(re.match('\v','\v')) == '\x0b')
    assert(escape(re.match("'","'")) == "'")

# Generated at 2022-06-11 19:38:01.473632
# Unit test for function test
def test_test():
    assert evalString(repr("a")) == "a"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\f"') == "\f"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\v"') == "\v"
    assert evalString('"\'"') == "'"
    assert evalString('"\\""') == '"'
    assert evalString('"\\\\"') == "\\"
    assert evalString('"\\x00"') == "\0"
    assert evalString('"\\377"') == "\377"

# Generated at 2022-06-11 19:38:02.465529
# Unit test for function test
def test_test():
    test()
    assert True is True

# Generated at 2022-06-11 19:38:12.690291
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([abfnrtv]|"|\\|\')', r'\b')) == '\b'
    assert escape(re.match(r'\\([abfnrtv]|"|\\|\')', r'\t')) == '\t'
    assert escape(re.match(r'\\([abfnrtv]|"|\\|\')', r'\n')) == '\n'
    assert escape(re.match(r'\\([abfnrtv]|"|\\|\')', r'\v')) == '\x0b'
    assert escape(re.match(r'\\([abfnrtv]|"|\\|\')', r'\f')) == '\x0c'

# Generated at 2022-06-11 19:38:22.523200
# Unit test for function escape
def test_escape():

    # Check unicode escapes
    assert escape(re.match(r"\\u([0-9a-f]{4})", "\\u0024")) == "\u0024"
    assert escape(re.match(r"\\u([0-9a-f]{4})", "\\ub000")) == "\ub000"
    assert escape(re.match(r"\\u([0-9a-f]{4})", "\\U00000d6f")) == "\U00000d6f"
    assert escape(re.match(r"\\u([0-9a-f]{4})", "\\U0000aadd")) == "\U0000aadd"

    # Check simple escapes

# Generated at 2022-06-11 19:38:23.870754
# Unit test for function escape
def test_escape():
    assert escape("\x04") == "\\x04"

# Generated at 2022-06-11 19:38:32.360320
# Unit test for function escape
def test_escape():
    test_cases_successes = [("\\x7e", "~"), ("\\t", "\t"), ("\\n", "\n")]
    for test_case in test_cases_successes:
        assert escape(re.search("^\\" + test_case[0] + "$", test_case[0])) == test_case[1]

    test_cases_failures = [("\\nj"), ("\\xj")]
    for test_case in test_cases_failures:
        try:
            escape(re.search("^\\" + test_case[0] + "$", test_case[0]))
            assert False  # should not get here
        except ValueError:
            pass

# Generated at 2022-06-11 19:38:36.119268
# Unit test for function test
def test_test():
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c, e

# Generated at 2022-06-11 19:38:46.721435
# Unit test for function escape
def test_escape():
    import inspect
    # Test simple escape sequences
    for c in simple_escapes.keys():
        assert escape(re.match(r"\\%s" % c, inspect.currentframe())) == simple_escapes[c]
    # Test hex escape sequences
    assert escape(re.match(r"\\x00", inspect.currentframe())) == chr(0)
    assert escape(re.match(r"\\x0A", inspect.currentframe())) == chr(10)
    assert escape(re.match(r"\\x7F", inspect.currentframe())) == chr(127)
    assert escape(re.match(r"\\xFF", inspect.currentframe())) == chr(255)
    # Test octal escape sequences
    assert escape(re.match(r"\\0", inspect.currentframe()))

# Generated at 2022-06-11 19:38:58.418437
# Unit test for function escape
def test_escape():
    assert escape("\x00") == '\x00'
    assert escape("\x01") == '\x01'
    assert escape("\x02") == '\x02'
    assert escape("\x03") == '\x03'
    assert escape("\x04") == '\x04'
    assert escape("\x05") == '\x05'
    assert escape("\x06") == '\x06'
    assert escape("\x07") == '\x07'
    assert escape("\x08") == '\x08'
    assert escape("\t") == '\t'
    assert escape("\n") == '\n'
    assert escape("\x0b") == '\x0b'
    assert escape("\x0c") == '\x0c'

# Generated at 2022-06-11 19:39:21.970234
# Unit test for function test
def test_test():
    test()  # OK if no exceptions

# Generated at 2022-06-11 19:39:31.093778
# Unit test for function escape
def test_escape():
    assert escape('\\') == '\\'
    assert escape('n') == "\n"
    assert escape('x88') == "X"
    assert escape('x88', '\x88') == "\x88"
    assert escape('x88', '\x88\x88') == "\x88\x88"
    assert escape('n', '\n') == "\n"
    assert escape('t', '\t') == "\t"
    assert escape('u8888') == "Ï"
    assert escape('u8888', '\u8888') == "\u8888"
    assert escape('66') == "f"
    assert escape('66', '\x66') == "\x66"
    assert escape('0066') == "\x00f"

# Generated at 2022-06-11 19:39:43.208479
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', '\\a')) == '\a'
    assert escape(re.match('\\b', '\\b')) == '\b'
    assert escape(re.match('\\f', '\\f')) == '\f'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'
    assert escape(re.match('\\v', '\\v')) == '\v'
    assert escape(re.match("\\'", "\\'")) == "'"
    assert escape(re.match('\\"', '\\"')) == '"'

# Generated at 2022-06-11 19:39:55.570074
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\a', '\\a')) == '\a'
    assert escape(re.match(r'\\b', '\\b')) == '\b'
    assert escape(re.match(r'\\f', '\\f')) == '\f'
    assert escape(re.match(r'\\n', '\\n')) == '\n'
    assert escape(re.match(r'\\r', '\\r')) == '\r'
    assert escape(re.match(r'\\t', '\\t')) == '\t'
    assert escape(re.match(r'\\v', '\\v')) == '\v'
    assert escape(re.match(r"\\'", "\\'")) == "'"

# Generated at 2022-06-11 19:40:06.966768
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\x2",'\\x2')) == '\x02'
    assert escape(re.search(r"\\x2",'\\x2')) != 'x2'
    assert escape(re.search(r"\\x2",'\\x20')) == ' '
    assert escape(re.search(r"\\x2",'\\x20')) != '20'
    assert escape(re.search(r"\\r",r"\\r")) == "\r"
    assert escape(re.search(r"\\r",r"\\r")) != "r"
    assert escape(re.search(r"\\\r",r"\\\r")) == ""
    assert escape(re.search(r"\\\r",r"\\\r")) != "\r"
    assert escape

# Generated at 2022-06-11 19:40:14.200617
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\x07"
    assert escape(re.match(r"\\(.)", r"\b")) == "\x08"
    assert escape(re.match(r"\\(.)", r"\f")) == "\x0c"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\x0b"
    assert escape(re.match(r"\\(.)", r"\'")) == "\'"

# Generated at 2022-06-11 19:40:24.152851
# Unit test for function escape
def test_escape():
    assert escape("\a") == "\a"
    assert escape("\b") == "\b"
    assert escape("\f") == "\f"
    assert escape("\n") == "\n"
    assert escape("\r") == "\r"
    assert escape("\t") == "\t"
    assert escape("\v") == "\v"
    assert escape("\'") == "\'"
    assert escape("\"") == "\""
    assert escape("\\") == "\\"

    assert escape("\x07") == "\x07"
    assert escape("\x7f") == "\x7f"
    assert escape("\xff") == "\xff"

    assert escape("\140") == "\040"
    assert escape("\07") == "\x07"
    assert escape("\077") == "\x3f"
   

# Generated at 2022-06-11 19:40:32.126229
# Unit test for function escape
def test_escape():
    # Test hex encoding
    s = r"\x42"
    assert escape(re.match(r"\\x.{0,2}", s)) == "B", escape(s)

    # Test octal encoding
    s = r"\052"
    assert escape(re.match(r"\\[0-7]{1,3}", s)) == "*", escape(s)

    # Test simple encoding
    s = r"\a"
    assert escape(re.match(r"\\[abfnrtv]", s)) == "\a", escape(s)

    # Test string encoding
    s = r"\'\"\\"
    assert escape(re.match(r"\\(.|$)", s)) == "'", escape(s)

    # Test illegal encoding
    s = r"\x4"

# Generated at 2022-06-11 19:40:33.934619
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:40:39.643876
# Unit test for function escape
def test_escape():
    assert repr(escape(re.search(r'\\v', '\\v'))) == repr('\x0b')
    assert repr(escape(re.search(r'\\x7f', '\\x7f'))) == repr('\x7f')
    assert repr(escape(re.search(r'\\x7f', '\\x7g'))) == repr('x7g')

# Generated at 2022-06-11 19:42:15.699738
# Unit test for function escape
def test_escape():
    def _unpack(s):
        return escape(re.match(r'\\([abfnrtv\'\"\\x{}{}]|0?0?0?)'.format(*s), r'\{}'.format(s)))
    assert _unpack('abfnrtv') == '\a\b\f\n\r\t\v'
    assert _unpack('u0022') == '"'
    assert _unpack('u0027') == "'"
    assert _unpack('0') == '\x00'
    assert _unpack('00') == '\x00'
    assert _unpack('000') == '\x00'
    assert _unpack('xAB') == '\xab'
    assert _unpack('xabc') == '\xabc'


# Generated at 2022-06-11 19:42:22.912656
# Unit test for function test
def test_test():
    import io
    import unittest
    import sys

    class TestTest(unittest.TestCase):
        def test_test(self):
            with self.assertRaises(ValueError):
                sys.stdout = io.StringIO()
                test()
                output = sys.stdout.getvalue().strip()
                sys.stdout = sys.__stdout__
                self.assertEqual(output, "")

    unittest.main(module="__main__", exit=False)

# Generated at 2022-06-11 19:42:31.279291
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"^\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'a")) == "'"
    assert escape(re.match(r"^\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\"a')) == '"'
    assert escape(re.match(r"^\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) == "\a"

# Generated at 2022-06-11 19:42:35.304680
# Unit test for function escape
def test_escape():
    escape("\x1f") == '\x0f'
    escape("\x0f") == '\x0f'
    escape("\x12") == '\x12'
    escape("\x12") == '\x12'

# Generated at 2022-06-11 19:42:46.188107
# Unit test for function test

# Generated at 2022-06-11 19:42:52.942841
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\[abfnrtv]"', r'\\b"')).encode('unicode-escape') == b'\\x08'
    assert escape(re.match(r'\\x..', r'\\xA4')).encode('unicode-escape') == b'\\u00a4'

# Generated at 2022-06-11 19:42:53.817977
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:43:02.923169
# Unit test for function escape
def test_escape():
    import pytest

    # odd length
    with pytest.raises(ValueError, match=r".*invalid hex string escape.*"):
        escape(re.match(r"\x1", "\\x1"))
    # bad character
    with pytest.raises(ValueError, match=r".*invalid hex string escape.*"):
        escape(re.match(r"\xafz", "\\xafz"))
    # bad octal
    with pytest.raises(ValueError, match=r".*invalid octal string escape.*"):
        escape(re.match(r"\8", "\\8"))
    with pytest.raises(ValueError, match=r".*invalid octal string escape.*"):
        escape(re.match(r"\888", "\\888"))

    #

# Generated at 2022-06-11 19:43:13.937818
# Unit test for function escape

# Generated at 2022-06-11 19:43:25.004887
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(xab)', r'\xab')) == "\xab"
    assert escape(re.match(r'\\(xa333)', r'\xa333')) == "\xa3"