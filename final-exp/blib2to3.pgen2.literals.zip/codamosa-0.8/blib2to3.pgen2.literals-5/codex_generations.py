

# Generated at 2022-06-11 19:34:48.582827
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x(..)", "\\x80")) == "\u0080"
    assert escape(re.match(r"\\u(....)", "\\u8000")) == "\U00008000"

# Generated at 2022-06-11 19:34:59.184321
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"hello"') == 'hello'
    assert evalString(r"'hello'") == 'hello'
    assert evalString(r'"hell\no"') == 'hell\no'
    assert evalString(r"'hell\no'") == 'hell\no'
    assert evalString(r'"\x68ello"') == 'hello'
    assert evalString(r"'\x68ello'") == 'hello'
    assert evalString(r'"hello\n"') == 'hello\n'
    assert evalString(r"'hello\n'") == 'hello\n'
    assert evalString(r"'hello\xff'") == 'hello\xff'
    assert evalString(r"'hello\177'") == 'hello\177'
    assert evalString(r"'hello\0'") == 'hello\0'


# Generated at 2022-06-11 19:35:10.999313
# Unit test for function escape
def test_escape():

    # Parse a single simple escape
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\n")) == "\n"
    assert escape(re.match(r"\\([abfnrtv]|'|\"|\\)", r"\r")) == "\r"

# Generated at 2022-06-11 19:35:22.147360
# Unit test for function evalString
def test_evalString():
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v'") == "\a\b\f\n\r\t\v"
    assert evalString("'ab\n'") == "ab\n"
    assert evalString("'\\x61b'") == "ab"
    assert evalString("'\\077b'") == "?b"
    assert evalString("'\\x77b'") == "wb"
    assert evalString("'fr\\xe9d'") == "fr\xe9d"

    # Bug 1629: evalString() accepts out of range octal values
    assert evalString("'\\0'") == "\0"
    assert evalString("'\\01'")

# Generated at 2022-06-11 19:35:31.792362
# Unit test for function escape
def test_escape():
    import unittest


# Generated at 2022-06-11 19:35:39.534181
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\"') == '"'
    assert escape('\\\\') == '\\'
    assert escape('\\x45') == chr(int('45', 16))
    assert escape('\\045') == chr(int('45', 8))

# Generated at 2022-06-11 19:35:43.502619
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\" + chr(255))
    assert escape(m) == chr(255)

# Generated at 2022-06-11 19:35:55.489741
# Unit test for function evalString
def test_evalString():
    assert evalString("'abc'") == "abc"
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\''") == "'"
    assert evalString("'\\a\\b\\f\\n\\r\\t\\v\\x41'") == "\a\b\f\n\r\t\vA"
    assert evalString("'\\x01'") == ""
    assert evalString("'\\001'") == ""
    assert evalString(r"""'''abc\
def'''""") == "abcdef"
    assert evalString("'abc\def'") == "abc\def"
    assert evalString("'\\\nabc'") == "abc"
    assert evalString("'\\\rabc'") == "\rabc"

# Generated at 2022-06-11 19:36:01.152760
# Unit test for function escape
def test_escape():
    def check(m):
        assert m.group(0) == '\\' + m.group(1)
        assert escape(m) == simple_escapes[m.group(1)]
        return ''
    simple_escapes_pat = '([' + ''.join(simple_escapes) + '])'
    assert re.sub(simple_escapes_pat, check, "abfnrtv'\"\\") == ''

# Generated at 2022-06-11 19:36:02.068458
# Unit test for function test
def test_test():
    # test()
    assert True

# Generated at 2022-06-11 19:36:18.946978
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"

# Generated at 2022-06-11 19:36:24.411379
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == "a"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\xe9"') == "é"
    assert evalString('"\\u00e9"') == "é"
    assert evalString('"\\U000000e9"') == "é"
    assert evalString('"\\a"') == "\a"
    assert evalString('"\\b"') == "\b"
    assert evalString('"\\f"') == "\f"
    assert evalString('"\\n"') == "\n"
    assert evalString('"\\r"') == "\r"
    assert evalString('"\\t"') == "\t"
    assert evalString('"\\v"') == "\v"

# Generated at 2022-06-11 19:36:35.455363
# Unit test for function evalString
def test_evalString():
    assert evalString("''") == ""
    assert evalString("'a string'") == "a string"
    assert evalString("'\\nasdf'") == "\nasdf"
    assert evalString("'\\tasdf'") == "\tasdf"
    assert evalString("'\\x12asdf'") == "\x12asdf"
    assert evalString("'\\x12\\x34asdf'") == "\x12\x34asdf"
    assert evalString("'\\x12\\x34\\x56asdf'") == "\x12\x34\x56asdf"
    assert evalString("'\\x123asdf'") == "\x12\x33asdf"
    assert evalString("'\\x123\\x45asdf'") == "\x12\x33\x45asdf"

# Generated at 2022-06-11 19:36:41.853790
# Unit test for function escape
def test_escape():
    assert escape("\\x45") == chr(69)
    assert escape("\\255") == chr(255)
    assert escape("\\a") == "\x07"
    assert escape("\\b") == "\x08"
    assert escape("\\f") == "\x0c"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\x0b"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"

# Generated at 2022-06-11 19:36:53.317485
# Unit test for function test
def test_test():
    from .support import run_unittest


# Generated at 2022-06-11 19:36:55.379739
# Unit test for function test
def test_test():
    #assert test() == None
    pass

# Generated at 2022-06-11 19:37:06.658848
# Unit test for function escape
def test_escape():
    assert escape('\\x41') == 'A'
    assert escape('\\x4s') == '4s'
    assert escape('\\7') == '\\7'
    assert escape('\\09') == '\t'
    assert escape('\\011') == '\t'
    assert escape('\\t') == '\t'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\v') == '\v'
    assert escape('\\f') == '\f'
    assert escape('\\a') == '\x07'
    assert escape('\\b') == '\x08'
    assert escape('\\\'') == '\\\''
    assert escape('\"') == '\"'
    assert escape('\\"') == '\"'

# Generated at 2022-06-11 19:37:18.486045
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\[3-7]{3}", r"\777")) == "\x1b"
    assert escape(re.match(r"\\[3-7]{3}", r"\400")) == "\x00"
    assert escape(re.match(r"\\x[0-9a-fA-F]{2}", r"\x05")) == "\x05"

# Generated at 2022-06-11 19:37:29.701150
# Unit test for function escape
def test_escape():
    import unittest

    class TestStringEscape(unittest.TestCase):
        def test_simple_1(self):
            self.assertEqual(escape(re.match(r"\\a", "\\a")), "\a")

        def test_simple_2(self):
            self.assertEqual(escape(re.match(r"\\b", "\\b")), "\b")

        def test_simple_3(self):
            self.assertEqual(escape(re.match(r"\\f", "\\f")), "\f")

        def test_simple_4(self):
            self.assertEqual(escape(re.match(r"\\n", "\\n")), "\n")


# Generated at 2022-06-11 19:37:38.864396
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\['\"]", r"\"")) == '"'
    assert escape(re.match(r"\\[xX][0-9A-Fa-f]{2}", r"\x20")) == " "
    assert escape(re.match(r"\\[abfnrtv]", r"\t")) == "\t"
    assert escape(re.match(r"\\\\", r"\\")) == "\\"
    assert escape(re.match(r"\\[0-7]{1,3}", r"\000")) == "\x00"

# Generated at 2022-06-11 19:37:53.342847
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:37:59.380749
# Unit test for function escape
def test_escape():
    assert escape("\a") == "\\x07"
    assert escape("\b") == "\\x08"
    assert escape("\f") == "\\x0c"
    assert escape("\n") == "\\x0a"
    assert escape("\r") == "\\x0d"
    assert escape("\t") == "\\x09"
    assert escape("\v") == "\\x0b"

    assert escape("\'") == "\\'"
    assert escape("\"") == '\\"'
    assert escape("\\") == "\\\\"

# Generated at 2022-06-11 19:38:00.526429
# Unit test for function test
def test_test():
    try:
        test()
    except Exception:
        assert 0, "test() failed"

# Generated at 2022-06-11 19:38:06.144314
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\w)", "\\x")
    expected = ValueError("invalid hex string escape ('\\x')")
    try:
        result = escape(m)
    except ValueError as err:
        assert str(err) == str(expected)
    else:
        assert False, f"Did not raise, returned {result!r}"

# Generated at 2022-06-11 19:38:07.273829
# Unit test for function test
def test_test():
    test()
assert True

# Generated at 2022-06-11 19:38:13.600283
# Unit test for function escape
def test_escape():
    assert '\n' == escape(re.match('\\n', '\n'))
    assert '\'' == escape(re.match("\\'", '\''))
    assert '\"' == escape(re.match('\\"', '\"'))
    assert '\b' == escape(re.match('\\b', '\b'))
    assert '\f' == escape(re.match('\\f', '\f'))
    assert '\t' == escape(re.match('\\t', '\t'))
    assert '\v' == escape(re.match('\\v', '\v'))
    assert '\\' == escape(re.match('\\\\', '\\'))


# Generated at 2022-06-11 19:38:23.643555
# Unit test for function escape
def test_escape():
    # Testing the invalid escape sequences
    try:
        assert escape(re.match(r"\\", "\\")) == "\\"
    except ValueError:
        pass
    try:
        assert escape(re.match(r"\\x1", "\\x1")) == "\\x1"
    except ValueError:
        pass
    try:
        assert escape(re.match(r"\\1", "\\1")) == "\\1"
    except ValueError:
        pass

    # Testing the rest of escape sequences
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"

# Generated at 2022-06-11 19:38:32.432397
# Unit test for function escape
def test_escape():
    tests = {
        '\\a': "\a",
        '\\b': "\b",
        '\\f': "\f",
        '\\n': "\n",
        '\\r': "\r",
        '\\t': "\t",
        '\\v': "\v",
        "\\'": "'",
        '\\"': '"',
        '\\\\': "\\",
        "\\x41": "A",
        "\\x4d": "M",
        "\\x4dz": "Mz",
        "\\x4": "",
    }
    for pattern, expected in tests.items():
        assert escape(re.match(r"\\(.*)", pattern)[1]) == expected



# Generated at 2022-06-11 19:38:33.960472
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-11 19:38:39.597456
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x.{0,2}", "\\xFF")) == chr(255)
    assert escape(re.match(r"\\x.{0,2}", "\\xFFq")) == chr(255)
    raises(ValueError, escape, re.match(r"\\x.{0,2}", "\\xF"))
    raises(ValueError, escape, re.match(r"\\x.{0,2}", "\\xFq"))
    raises(ValueError, escape, re.match(r"\\x.{0,2}", "\\xFqq"))

# Generated at 2022-06-11 19:38:59.232464
# Unit test for function escape
def test_escape():
    assert escape(None) == None

# Generated at 2022-06-11 19:39:03.559581
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\n', r'\n')) == '\n'
    assert escape(re.match('\\x3f', r'\x3f')) == '?'
    assert escape(re.match('\\07', r'\07')) == '\x07'
    assert escape(re.match('\\012', r'\012')) == '\n'


# Generated at 2022-06-11 19:39:12.266619
# Unit test for function escape
def test_escape():
    """
    >>> test_escape.__test__ = False
    >>> escape(re.match(r'\\x12', '\\x12'))
    '\\x12'
    >>> escape(re.match(r'\\012', '\\012'))
    '\\x0a'
    >>> escape(re.match(r'\\[', '\\['))
    Traceback (most recent call last):
      ...
    ValueError: invalid octal string escape ('\\[')
    >>> escape(re.match(r'\\x12', '\\x12'))
    '\\x12'
    >>> escape(re.match(r'\\x12', '\\x12'))
    '\\x12'
    """

# Generated at 2022-06-11 19:39:22.763520
# Unit test for function escape
def test_escape():
    # Some simple tests, more complex tests are done in testStringEval
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r'\\a', r'\a')) == '\x07'
    assert escape(re.match(r'\\x41', r'\x41')) == 'A'
    assert escape(re.match(r'\\377', r'\377')) == '\xff'
    try:
        escape(re.match(r'\\x', r'\x'))
    except ValueError:
        pass
    else:
        raise AssertionError('Did not detect invalid \\x escape')
    try:
        escape(re.match(r'\\41', r'\41'))
    except ValueError:
        pass

# Generated at 2022-06-11 19:39:31.502996
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\a')) == '\a'
    assert escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\b')) == '\b'
    assert escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\f')) == '\f'

# Generated at 2022-06-11 19:39:43.480925
# Unit test for function escape
def test_escape():
    assert escape('\x41') == 'A'
    assert escape('\x00') == '\x00'
    assert escape('\a') == 'a'
    assert escape('\n') == 'n'
    assert escape('\x41') == 'A'
    assert escape('\x00') == '\x00'
    assert escape('\a') == '\x07'
    assert escape('\n') == '\n'

# Generated at 2022-06-11 19:39:54.978623
# Unit test for function escape
def test_escape():
    assert escape(r"\a") == r"\a"
    assert escape(r"\b") == r"\b"
    assert escape(r"\f") == r"\f"
    assert escape(r"\n") == r"\n"
    assert escape(r"\r") == r"\r"
    assert escape(r"\t") == r"\t"
    assert escape(r"\v") == r"\v"
    assert escape(r"\'") == r"\'"
    assert escape(r'\"') == r'\"'
    assert escape(r"\\") == r"\\"
    assert escape(r"\1234") == r"\1234"


# Generated at 2022-06-11 19:40:03.576485
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\'.*\\\'', '\\\'')) == '\''
    assert escape(re.match('\\\'.*\\\'', '\\\'')) == "'"
    assert escape(re.match('\\\'.*\\\'', '\\\'')) == "'"
    assert escape(re.match('\\\'.*\\\'', '\\\'')) == "'"
    assert escape(re.match('\\\'.*\\\'', '\\\'')) == "'"
    assert escape(re.match('\\\'.*\\\'', '\\\'')) == "'"



# Generated at 2022-06-11 19:40:12.734942
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\x[0-9a-fA-F]{2}', "\\x1f")) == '\x1f'
    assert escape(re.match(r'\\x[0-9a-fA-F]{2}', "\\xAF")) == '\xaf'
    assert escape(re.match(r'\\x[0-9a-fA-F]{2}', "\\xFF")) == '\xff'

    q = "'"
    assert evalString('"a\a\b\f\n\r\t\v\"\\' + q + '"') == "a\a\b\f\n\r\t\v\"\\" + q

# Generated at 2022-06-11 19:40:20.326716
# Unit test for function escape
def test_escape():
    assert escape(re.match("abc", "abc")) == "abc"
    assert escape(re.match("\\b", "\\b")) == "\b"
    assert escape(re.match("\\x12", "\\x12")) == "\x12"
    assert escape(re.match("\\", "\\")) == "\\"
    for c in "\\'\"abfnrtv":
        # Make sure escape doesn't crash
        escape(re.match(f"\\{c}", f"\\{c}"))

# Generated at 2022-06-11 19:41:07.813733
# Unit test for function escape
def test_escape():
    assert escape(re.search(r'(")', '"')) == '"'
    assert escape(re.search(r'(\\)', '\\')) == '\\'
    assert escape(re.search(r'(a)', 'a')) == '\a'
    assert escape(re.search(r'(b)', 'b')) == '\b'
    assert escape(re.search(r'(f)', 'f')) == '\f'
    assert escape(re.search(r'(n)', 'n')) == '\n'
    assert escape(re.search(r'(r)', 'r')) == '\r'
    assert escape(re.search(r'(t)', 't')) == '\t'

# Generated at 2022-06-11 19:41:17.080889
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"(\a)", '\\a')) == r"\a"
    assert escape(re.match(r"(\b)", '\\b')) == r"\b"
    assert escape(re.match(r"(\f)", '\\f')) == r"\f"
    assert escape(re.match(r"(\n)", '\\n')) == r"\n"
    assert escape(re.match(r"(\r)", '\\r')) == r"\r"
    assert escape(re.match(r"(\t)", '\\t')) == r"\t"
    assert escape(re.match(r"(\v)", '\\v')) == r"\v"
    assert escape(re.match(r"(')", "\\'")) == r"'"
    assert escape

# Generated at 2022-06-11 19:41:18.279353
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:41:19.294151
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:41:26.539876
# Unit test for function escape
def test_escape():
    assert escape(r"\x20") == r" "
    assert escape(r"\x0a") == "\n"
    assert escape(r"\n") == "\n"
    # assert escape(r"\x00") == "\x00"
    # assert escape(r"\x7f") == "\x7f"
    # assert escape(r"\x80") == "\x80"
    # assert escape(r"\xff") == "\xff"
    # assert escape(r"\u1234") == "\u1234"

# Generated at 2022-06-11 19:41:28.880721
# Unit test for function test
def test_test():
    # The code in `test()` does not have any unit-testable branches, so
    # for now our test for `test()` is just that it doesn't crash.
    test()

# Generated at 2022-06-11 19:41:38.984568
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")) == "'"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\"")) == "\""
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\1")) == "1"

# Generated at 2022-06-11 19:41:42.825831
# Unit test for function escape
def test_escape():
    result = ''
    for i in range(256):
        c = chr(i)
        s = repr(c)
        result = escape(re.match(r"\\(.)", s))
        assert result == c

# Generated at 2022-06-11 19:41:44.261308
# Unit test for function test
def test_test():
    if __name__ == "__main__":
        test()

# Generated at 2022-06-11 19:41:51.743025
# Unit test for function escape
def test_escape():

    assert escape(re.search(r"\\([abfnrtv'\"\\]|.{0,2})", r"\\a")) == "\a"
    assert escape(re.search(r"\\([abfnrtv'\"\\]|.{0,2})", r"\\b")) == "\b"
    assert escape(re.search(r"\\([abfnrtv'\"\\]|.{0,2})", r"\\f")) == "\f"
    assert escape(re.search(r"\\([abfnrtv'\"\\]|.{0,2})", r"\\n")) == "\n"
    assert escape(re.search(r"\\([abfnrtv'\"\\]|.{0,2})", r"\\r")) == "\r"

# Generated at 2022-06-11 19:42:28.234030
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:29.063194
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:40.298830
# Unit test for function escape
def test_escape():
    e = {r"\\": "\\", r"\"": "\"", r"\a": "\a", r"\\\\": "\\", r'\\"': '"'}
    for i in e:
        assert escape(re.match(r"\\.?", i)) == e[i]
    assert escape(re.match(r"\x.{0,2}", r"\x41")) == "A"
    assert escape(re.match(r"\x.{0,2}", r"\x4")) == "4"
    assert escape(re.match(r"\x.{0,2}", r"\x4g")) == "4g"
    assert escape(re.match(r"\077", r"\077")) == "?"

# Generated at 2022-06-11 19:42:43.217340
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-11 19:42:44.779218
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-11 19:42:52.292154
# Unit test for function escape
def test_escape():
    def test(string):
        return re.sub(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", escape, string)

    assert test("\\a") == "\a"
    assert test("\\b") == "\b"
    assert test("\\f") == "\f"
    assert test("\\n") == "\n"
    assert test("\\r") == "\r"
    assert test("\\t") == "\t"
    assert test("\\v") == "\v"
    assert test("\\'") == "'"
    assert test('\\"') == '"'
    assert test("\\x00") == "\x00"
    assert test("\\11") == "\t"
    assert test("\\011") == "\t"
   

# Generated at 2022-06-11 19:43:01.805999
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([a-z]|x[0-9A-Za-z]{2})", "\\0")).encode(
        "utf-8"
    ) == "\\0".encode("utf-8")
    assert escape(re.match(r"\\([a-z]|x[0-9A-Za-z]{2})", "\\x2C")).encode(
        "utf-8"
    ) == "\"".encode("utf-8")
    assert escape(re.match(r"\\([a-z]|x[0-9A-Za-z]{2})", "\\0")).encode(
        "utf-8"
    ) == "\\0".encode("utf-8")

# Generated at 2022-06-11 19:43:12.978325
# Unit test for function escape
def test_escape():
    from unittest import TestCase, main

    class EscapeTestCase(TestCase):
        def check(self, string, result):
            self.assertEqual(escape(string), result)

    e = EscapeTestCase()
    e.check('\\n', '\n')
    e.check('\\r', '\r')
    e.check('\\07', '\x07')
    e.check('\\x07', '\x07')
    e.check('\\xff', '\xff')
    e.check('\\x0a', '\n')
    e.check('\\x0A', '\n')
    e.check('\\xaa', '\xaa')
    e.check('\\xAA', '\xaa')
    e.check('\\u1234', '\u1234')


# Generated at 2022-06-11 19:43:14.707947
# Unit test for function test
def test_test():
    test()
    assert True # did not crash

# Generated at 2022-06-11 19:43:26.436613
# Unit test for function escape
def test_escape():
    import pytest

    with pytest.raises(ValueError):
        escape(None) # type: ignore

    assert escape(re.match("\\", "\\")) == "\\"
    assert escape(re.match("\\x", "\\x")) == "x"
    assert escape(re.match("\\xasd", "\\xasd")) == "x"
    assert escape(re.match("\\xasd", "\\xasd")) == "x"
    assert escape(re.match("\\xas", "\\xas")) == "x"
    assert escape(re.match("\\x12", "\\x12")) == "x"

    assert escape(re.match("\\0", "\\0")) == "\0"
    assert escape(re.match("\\1", "\\1")) == "\1"