

# Generated at 2022-06-11 19:34:46.263512
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:34:51.349826
# Unit test for function escape
def test_escape():
    test_str = "\\x12\\'\\\"\\\\\\n\\r\\b\\f\\t\\v"
    result = escape(test_str)
    assert result == '\x12\'\"\\\n\r\b\f\t\v'

# Generated at 2022-06-11 19:34:59.793538
# Unit test for function escape
def test_escape():
    escape_test_cases = {
        r"\n": "\n",
        r"\x20": " ",
        r"\x7F": "\x7F",
        r"\xC2": "\xC2",
        r"\xC3": "\xC3",
        r"\xC4": "\xC4",
        r"\xC5": "\xC5",
        r"\XC2": "\xC2",
        r"\XC3": "\xC3",
        r"\XC4": "\xC4",
        r"\XC5": "\xC5",
    }


# Generated at 2022-06-11 19:35:04.651880
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\', '\\')) == '\\'
    assert escape(re.match(r'\\x', '\\x')) == 'x'
    assert escape(re.match(r'\\xFF', '\\xFF')) == 'ÿ'
    assert escape(re.match(r'\\777', '\\777')) == '?'
    assert escape(re.match(r'\\111', '\\111')) == 'I'
    assert escape(re.match(r'\\11', '\\11')) == '\t'
    assert escape(re.match(r'\\1', '\\1')) == '\x01'
    # assert escape(re.match(r'\\0', '\\0')) == '\x00'

# Generated at 2022-06-11 19:35:14.337489
# Unit test for function evalString
def test_evalString():
    from pickletester import AbstractPickleTests, AbstractPickleModuleTests
    from test.support import (
        unlink,
        import_module,
        run_unittest,
        check_warnings,
        check_py3k_warnings,
    )

    import pickle
    import os
    import sys

    class TestPickleTests(AbstractPickleTests):
        module = pickle
        error = RuntimeError

        expected_warnings = []

        def loads(self, *args):
            return self.module.loads(*args)

        def dumps(self, *args):
            return self.module.dumps(*args)

        def loads_in_memory(self, *args):
            return self.module.loads_in_memory(*args)


# Generated at 2022-06-11 19:35:16.776379
# Unit test for function escape
def test_escape():
    assert escape(re.search("\\0", "\\0")) == "\x00"

# Generated at 2022-06-11 19:35:24.610444
# Unit test for function escape

# Generated at 2022-06-11 19:35:31.898947
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([a-z]|[A-Z])", '\\o')) == '\\o'
    assert escape(re.match(r"\\([a-z]|[A-Z])", '\\x1f')) == chr(0x1f)
    assert escape(re.match(r"\\([a-z]|[A-Z])", '\\73')) == chr(0x73)

# Generated at 2022-06-11 19:35:32.474283
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:35:42.504515
# Unit test for function escape
def test_escape():
    from cStringIO import StringIO
    import sys

    saved_stderr = sys.stderr

# Generated at 2022-06-11 19:36:27.243140
# Unit test for function escape
def test_escape():
    m = re.search(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\t")
    assert escape(m) == "\t"
    assert escape(re.search(r"\\(...)", r"\255")) == "\xff"
    assert escape(re.search(r"\\(...)", r"\312\255")) == "\u01ff"

    try:
        escape(re.search(r"\\(...)", "\\x"))
        assert False, "Escape must raise ValueError"
    except ValueError:
        pass



# Generated at 2022-06-11 19:36:27.924987
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:36:37.398353
# Unit test for function escape
def test_escape():
    """All test cases for function escape
    Function test_escape tests the function `escape` in the module `ast`
    """
    from typing import Any, Dict, Union

    # Type inference bug
    # Case 1
    x = escape("char")
    assert type(x) is str

    # Case 2
    x = escape("\\\\")
    assert type(x) is str

    # Case 3
    x = escape("\\'")
    assert type(x) is str

    # Case 4
    x = escape("\\")
    assert type(x) is str

    # Case 5
    x = escape("\\n")
    assert type(x) is str

    # Case 6
    x = escape("\\x")
    assert type(x) is str

    # Case 7
    x = escape("\\a")
    assert type

# Generated at 2022-06-11 19:36:48.799664
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert (
        escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\'"))
        == "'"
    )
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\xAF")) == chr(
        175
    )

# Generated at 2022-06-11 19:36:56.637403
# Unit test for function escape
def test_escape():
    # From the `str` type docs.
    assert escape(re.match(r"\\a", "\a")) == "\a"
    assert escape(re.match(r"\\b", "\b")) == "\b"
    assert escape(re.match(r"\\f", "\f")) == "\f"
    assert escape(re.match(r"\\n", "\n")) == "\n"
    assert escape(re.match(r"\\r", "\r")) == "\r"
    assert escape(re.match(r"\\t", "\t")) == "\t"
    assert escape(re.match(r"\\v", "\v")) == "\v"
    assert escape(re.match(r"\\'", "'")) == "'"
    assert escape(re.match(r'\\"', '"')) == '"'

# Generated at 2022-06-11 19:36:57.706025
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-11 19:37:06.657341
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r"\\'", r"\\'")) == "\\'"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\012", r"\012")) == "\n"
    assert escape(re.match(r"\\x6e", r"\x6e")) == "n"
    assert escape(re.match(r"\\x0a", r"\x0a")) == "\n"

# Generated at 2022-06-11 19:37:09.979801
# Unit test for function test
def test_test():
    try:
        test()
    except:
        raise Exception("test failed")

# Generated at 2022-06-11 19:37:10.966343
# Unit test for function test
def test_test():
    test()
    # test_test()

# Generated at 2022-06-11 19:37:11.539192
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:37:31.293546
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', 'a')) == '\a'
    assert escape(re.match('\\0', '0')) == '\x00'
    assert escape(re.match('\\x00', 'x00')) == '\x00'
    assert escape(re.match("\\'", "'")) == "'"
    assert escape(re.match("\\\"", "\"")) == '"'
    assert escape(re.match("\\\\", "\\")) == '\\'
    assert escape(re.match('\\b', 'b')) == '\x08'
    assert escape(re.match('\\f', 'f')) == '\x0c'
    assert escape(re.match('\\n', 'n')) == '\n'

# Generated at 2022-06-11 19:37:34.389302
# Unit test for function test
def test_test():
    try:
        test()
    except ImportError:  # pragma: nocover
        pass

# Generated at 2022-06-11 19:37:41.976065
# Unit test for function escape
def test_escape():
    test_data = [
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\\\", "\\"),
        ("\\x00", "\x00"),
        ("\\xff", "\xff"),
        ("\\x0a", "\n"),
        ("\\777", "\x1f"),
        ("\\400", "\x80"),
    ]
    for test_string, expected_result in test_data:
        m = re.match(r"\\(.{0,8})", test_string)
        assert m is not None
        actual_result

# Generated at 2022-06-11 19:37:45.087793
# Unit test for function escape
def test_escape():
    assert escape("\\x41") == "A"
    assert escape("\\x9f") == "\x9f"

# Generated at 2022-06-11 19:37:55.278929
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\\'")) == "'"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r'\\"')) == '"'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\\\"")) == '"'

# Generated at 2022-06-11 19:38:01.474358
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\0')) == '\x00'
    assert escape(re.match(r'\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\x0')) == '\x00'
    assert escape(re.match(r'\\([abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\x00')) == '\x00'
    # test_escape()


# Generated at 2022-06-11 19:38:07.843040
# Unit test for function escape
def test_escape():
    global escape
    # Simple escapes
    assert escape(re.match(r"\\.", "\\'")) == "'"
    assert escape(re.match(r"\\.", '\\"')) == '"'
    assert escape(re.match(r"\\.", "\\\\")) == "\\"

    # Hexadecimal escapes (\x..)
    raise Exception  # TODO: Support hexadecimal escape in 'escape'

# Generated at 2022-06-11 19:38:12.168274
# Unit test for function test
def test_test():
    import io
    from io import StringIO

    # Capture output to stdout
    out = io.StringIO()
    stdout = sys.stdout
    sys.stdout = out

    test()

    # Restore stdout
    sys.stdout = stdout
    out.seek(0)

    assert out.read() == ''

# Generated at 2022-06-11 19:38:13.430822
# Unit test for function test
def test_test():
    assert True


# Generated at 2022-06-11 19:38:23.557499
# Unit test for function escape
def test_escape():
    assert escape(r'\a') == '\a'
    assert escape(r'\b') == '\b'
    assert escape(r'\f') == '\f'
    assert escape(r'\n') == '\n'
    assert escape(r'\r') == '\r'
    assert escape(r'\t') == '\t'
    assert escape(r'\v') == '\v'
    assert escape(r'\"') == '"'
    assert escape(r'\'') == '\''
    assert escape(r'\x20') == ' '
    assert escape(r'\x7e') == '~'
    assert escape(r'\x7f') == chr(0x7f)

    # Invalid Unicode escape characters

# Generated at 2022-06-11 19:38:38.837648
# Unit test for function escape
def test_escape():
#    assert escape(r"\)") == r"\", "escape: {0}, expected: {1}".format(escape(r"\)"),r"\")
#    assert escape(r"\x00") == chr(0), "escape: {0}, expected: {1}".format(escape(r"\x00"),chr(0))
    pass

# Generated at 2022-06-11 19:38:39.812696
# Unit test for function test
def test_test():
    test()


# Generated at 2022-06-11 19:38:43.300284
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x3F", "\\x3F")) == "?"
    assert escape(re.match(r"\\077", "\\077")) == "?"

# Generated at 2022-06-11 19:38:50.913739
# Unit test for function escape
def test_escape():
    import pytest

    assert escape(r"\a") == "\a"
    assert escape(r"\b") == "\b"
    assert escape(r"\f") == "\f"
    assert escape(r"\n") == "\n"
    assert escape(r"\r") == "\r"
    assert escape(r"\t") == "\t"
    assert escape(r"\v") == "\v"
    assert escape(r"\'") == "\'"
    assert escape(r'\"') == '\"'
    assert escape(r"\x7f") == "\x7f"
    assert escape(r"\127") == "\x7f"
    assert escape(r"\400") == "\x40"
    with pytest.raises(ValueError):
        escape(r"\x")
   

# Generated at 2022-06-11 19:39:02.841455
# Unit test for function escape
def test_escape():
    m = re.match(r'\\(.+)', r'\0')
    assert escape(m) == '\0'

    m = re.match(r'\\(.+)', r'\1')
    assert escape(m) == '\1'

    m = re.match(r'\\(.+)', r'\10')
    assert escape(m) == '\10'

    m = re.match(r'\\(.+)', r'\11')
    assert escape(m) == '\11'

    m = re.match(r'\\(.+)', r'\7')
    assert escape(m) == '\7'

    m = re.match(r'\\(.+)', r'\72')
    assert escape(m) == '\72'


# Generated at 2022-06-11 19:39:06.650653
# Unit test for function test
def test_test():
    import io
    import sys
    import unittest

    with io.StringIO() as buf, unittest.mock.patch("sys.stdout", buf):
        test()
        assert buf.getvalue() == ""



# Generated at 2022-06-11 19:39:15.199728
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r"\\\"", r'\"')) == '"'
    assert escape(re.match(r"\\\\", r"\\")) == "\\"
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"

# Generated at 2022-06-11 19:39:22.226296
# Unit test for function escape
def test_escape():
    assert escape("\\z") == "z"
    assert escape("\\\x1b") == "\x1b"
    assert escape("\\12") == "\14"
    assert escape("\\012") == "\n"
    assert escape("\\142") == "B"
    assert escape("\\x42") == "B"
    assert escape("\\x4g") == "Bg"
    assert escape("\\x4") == "B"
    assert escape("\\x") == "x"

# Generated at 2022-06-11 19:39:22.761275
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:24.212636
# Unit test for function escape
def test_escape():
    pass

# Generated at 2022-06-11 19:39:45.562682
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:57.551664
# Unit test for function escape
def test_escape():
    # The first argument to the escape function is a MatchObject,
    # containing two groups (0 and 1).  The first group is the
    # whole matched string (including the backslash), and the
    # second is the string after the backslash.
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r'\a')) == '\a'
    assert escape(re.match(r"\\([abfnrtv'\"\\]|x.{0,2}|[0-7]{1,3})", r'\b')) == '\b'

# Generated at 2022-06-11 19:40:01.150820
# Unit test for function escape
def test_escape():
    assert escape(re.match("blah\\y", 'blah\\y')) == 'y'
    assert escape(re.match("blah\\x0y", 'blah\\x0y')) == '\x00y'

# Generated at 2022-06-11 19:40:02.436330
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:40:03.835348
# Unit test for function test
def test_test():
    # At the time of the introduction of this code,
    # there were no tests
    # So this is a bare-bones test that there is no exception
    test()

# Generated at 2022-06-11 19:40:04.492758
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:40:07.660213
# Unit test for function test
def test_test():
    try:
        test()
    except (AssertionError, ValueError) as e:
        assert False, "test() raised {0}".format(e)



# Generated at 2022-06-11 19:40:10.561918
# Unit test for function test
def test_test():
    try:
        test()
    except BaseException:
        pass

# Generated at 2022-06-11 19:40:20.093727
# Unit test for function escape
def test_escape():
    escape_simple_escapes = {
        "a": "\a",
        "b": "\b",
        "f": "\f",
        "n": "\n",
        "r": "\r",
        "t": "\t",
        "v": "\v",
        "'": "'",
        '"': '"',
        "\\": "\\",
    }

# Generated at 2022-06-11 19:40:30.288897
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\'", 0)) == "\'"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\"", 0)) == '"'
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\\", 0)) == "\\"

# Generated at 2022-06-11 19:41:19.005350
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\\x00', '\\\\x00')) == '\x00'
    assert escape(re.match('\\\\000', '\\\\000')) == '\x00'
    assert escape(re.match('\\\\xFF', '\\\\xFF')) == '\xFF'
    assert escape(re.match('\\\\377', '\\\\377')) == '\xFF'
    assert escape(re.match('\\\\t', '\\\\t')) == '\t'
    assert escape(re.match('\\\\"', '\\\\"')) == '"'
    assert escape(re.match('\\\\\\\\', '\\\\\\\\')) == '\\\\'
    assert escape(re.match('\\\\x', '\\\\x')) == 'x'
    assert escape(re.match('\\\\\\', '\\\\\\')) == '\\'
   

# Generated at 2022-06-11 19:41:28.848747
# Unit test for function escape
def test_escape():
    # test all the valid cases
    for char, output in simple_escapes.items():
        assert escape(re.match("\\" + char, "\\{}".format(char))) == output
    for i in range(0, 8):
        assert escape(re.match("\\0{}".format(i), "\\0{}".format(i))) == chr(i)
    for i in range(0, 8):
        assert escape(re.match("\\0{}".format(i * 10), "\\0{}".format(i * 10))) == chr(i * 8)
    for i in range(0, 8):
        assert escape(re.match("\\0{}".format(i * 100), "\\0{}".format(i * 100))) == chr(i * 64)

# Generated at 2022-06-11 19:41:38.986633
# Unit test for function escape
def test_escape():
    class Test:
        def __init__(self, string, expected_output):
            self.string = string
            self.expected_output = expected_output

    tests = [Test("\\a", "\a"), Test("\\b", "\b"), Test("\\f", "\f"), Test("\\n", "\n"), Test("\\r", "\r"),
             Test("\\t", "\t"), Test("\\v", "\v"), Test("\\'", "'"), Test('\\"', '"'), Test("\\\\", "\\"),
             Test("\\x0a", "\n"), Test("\\010", "\b"), Test("\\n", "\n")]

    def run_test(test):
        output = escape(re.match("(.+)", test.string))

# Generated at 2022-06-11 19:41:49.209718
# Unit test for function escape
def test_escape():
    import string
    import random
    # check escape of ascii values 0 to 127
    s = string.printable
    s = "".join(s[i] + "\\" + s[i] for i in range(10))
    for i in range(10):
        s += "".join(random.choice(string.printable) for j in range(100))
    assert evalString(repr(s)) == s

    # check unicode escape
    h1 = "\\u1234"
    h2 = "\\U00001234"
    for hexescape in (h1, h2):
        for i in range(1, 20, 2):
            s = "".join(random.choice(string.printable) for j in range(100))
            s = hexescape + s

# Generated at 2022-06-11 19:41:54.302503
# Unit test for function escape
def test_escape():
    s = '\\a\\b\\f\\n\\r\\t\\v\\\'\\"\\\\\\x80'
    s2 = re.sub(r'\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})', escape, s)
    assert len(s) == len(s2)
    return s2

# Generated at 2022-06-11 19:42:03.528005
# Unit test for function escape
def test_escape():

    # Simple cases
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xff"
    assert escape(re.match(r"\\377", "\\377")) == "\xff"
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\", "\\")) == "\\"
    assert escape(re.match(r"\\'", "\\'")) == "'"

    # Improper escapes
    try:
        escape(re.match(r"\\x", "\\x"))
    except ValueError:
        pass
    else:
        raise AssertionError

    try:
        escape(re.match(r"\\x00", "\\x00"))
    except ValueError:
        pass
    else:
        raise

# Generated at 2022-06-11 19:42:04.125316
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:08.676542
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x7f", r"\x7f")) == "\x7f"
    assert escape(re.match(r"\\xff", r"\xff")) == "\xff"
    assert escape(re.match(r"\\xab", r"\xab")) == "\xab"

# Generated at 2022-06-11 19:42:10.686818
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\x22', 'x22')) == '"'
    assert escape(re.match('\\x22', 'x22')) == '"'

# Generated at 2022-06-11 19:42:13.069378
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"
    assert escape("\\\"") == "\""
    assert escape("\\xFF") == "\xFF"
    assert escape("\\377") == "\377"

# Generated at 2022-06-11 19:43:35.653065
# Unit test for function escape
def test_escape():
  for i in range(256):
      c = chr(i)
      s = repr(c)
      e = escape(s)
      if e != c:
          print(i, c, s, e)

# Generated at 2022-06-11 19:43:46.096998
# Unit test for function escape
def test_escape():
    """Escape testing."""
    assert escape('\\"') == '"'
    assert escape('\\\'') == '\''
    assert escape('\\x20') == ' '
    assert escape('\\a') == '\x07'
    assert escape('\\b') == '\x08'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\x0b'
    assert escape('\\f') == '\x0c'
    assert escape('\\0') == '\x00'
    assert escape('\\07') == '\x07'
    assert escape('\\012') == '\n'
    assert escape('\\377') == '\xff'

# Generated at 2022-06-11 19:43:50.846343
# Unit test for function test
def test_test():
    from io import StringIO
    import sys
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        test()
        out.seek(0)
        assert out.read() == ""
    finally:
        sys.stdout = saved_stdout


# Generated at 2022-06-11 19:43:51.353113
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:43:52.979418
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-11 19:43:53.608686
# Unit test for function test
def test_test():
    try:
        test()
    except SystemExit:
        pass

# Generated at 2022-06-11 19:43:54.954053
# Unit test for function test
def test_test():
  with pytest.raises(TypeError):
    test(True)

# Generated at 2022-06-11 19:44:03.943827
# Unit test for function escape

# Generated at 2022-06-11 19:44:07.486881
# Unit test for function escape
def test_escape():
    assert not escape("b")
    assert escape("\b") == "\b"
    assert escape("\\xFF") == "\xFF"
    assert escape("\\057") == "/"

# Generated at 2022-06-11 19:44:10.833033
# Unit test for function test
def test_test():
    test()

try:
    test.__name__
except AttributeError:
    pass