

# Generated at 2022-06-11 19:34:57.943611
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\)", r"\\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\)", r"\\b")) == "\b"
    assert escape(re.match(r"\\('|\"|\\)", r"\\f")) == "\f"
    assert escape(re.match(r"\\('|\"|\\)", r"\\n")) == "\n"
    assert escape(re.match(r"\\('|\"|\\)", r"\\r")) == "\r"
    assert escape(re.match(r"\\('|\"|\\)", r"\\t")) == "\t"
    assert escape(re.match(r"\\('|\"|\\)", r"\\v")) == "\v"

# Generated at 2022-06-11 19:34:59.383167
# Unit test for function escape
def test_escape():
    # Call function
    result = escape("\\a")
    assert result == "\a"

# Generated at 2022-06-11 19:35:11.204958
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\x41", "\\x41")) == "A"
    assert escape(re.match(r"\\x7E", "\\x7E")) == "~"
    assert escape(re.match(r"\\x7f", "\\x7f")) == "\x7f"
    assert escape(re.match(r"\\x80", "\\x80")) == "\x80"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"
    assert escape(re.match(r"\\x0A", "\\x0A")) == "\n"

# Generated at 2022-06-11 19:35:22.363148
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\\'', '\\\'')) == '\''
    assert escape(re.match('\\\"', '\\\"')) == '\"'
    assert escape(re.match('\\a', '\\a')) == '\a'
    assert escape(re.match('\\b', '\\b')) == '\b'
    assert escape(re.match('\\f', '\\f')) == '\f'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'
    assert escape(re.match('\\v', '\\v')) == '\v'
    assert escape

# Generated at 2022-06-11 19:35:31.943213
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\)", r"\\'")) == "'"
    assert escape(re.match(r"\\('|\"|\\)", '\\"')) == '"'
    assert escape(re.match(r"\\('|\"|\\)", r"\\\"")) == "\\"
    assert escape(re.match(r"\\('|\"|\\)", r"\\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\)", r"\\b")) == "\b"
    assert escape(re.match(r"\\('|\"|\\)", r"\\f")) == "\f"
    assert escape(re.match(r"\\('|\"|\\)", r"\\n")) == "\n"

# Generated at 2022-06-11 19:35:36.749157
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\x00', 'x00')) == '\x00'
    assert escape(re.match('\\b', 'b')) == '\x08'
    assert escape(re.match('\\1', '1')) == '\x01'

    m = re.match('\\x32', 'x32')
    assert escape(m) == '2'

# Generated at 2022-06-11 19:35:39.474026
# Unit test for function escape
def test_escape():
    x = '"hello"'
    y = "\\" + x[1]
    assert escape(re.search(r"(.)", y)) == x[1]


# Generated at 2022-06-11 19:35:48.060268
# Unit test for function evalString
def test_evalString():
    assert evalString('"\\007"') == '\x07'
    assert evalString('"Hello"') == 'Hello'
    assert evalString("'Hello'") == 'Hello'
    assert evalString("'''Hello'''") == 'Hello'
    assert evalString('"Hello\\n"') == 'Hello\n'
    assert evalString("'Hello\\n'") == 'Hello\n'
    assert evalString("'''Hello\\n'''") == 'Hello\n'
    assert evalString('"Hello\\012World"') == 'Hello\nWorld'
    assert evalString("'Hello\\012World'") == 'Hello\nWorld'
    assert evalString("'''Hello\\012World'''") == 'Hello\nWorld'

# Generated at 2022-06-11 19:35:52.019318
# Unit test for function evalString
def test_evalString():
    assert(evalString('"ab\x07cdef"') == 'ab\x07cdef')
    assert(evalString("'a\nbc'") == 'a\nbc')

# Generated at 2022-06-11 19:36:01.465513
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\\a', r'\a')) == '\a'
    assert escape(re.match(r'\\\b', r'\b')) == '\x08'
    assert escape(re.match(r'\\\f', r'\f')) == '\x0c'
    assert escape(re.match(r'\\\n', r'\n')) == '\n'
    assert escape(re.match(r'\\\r', r'\r')) == '\r'
    assert escape(re.match(r'\\\t', r'\t')) == '\t'
    assert escape(re.match(r'\\\v', r'\v')) == '\x0b'

# Generated at 2022-06-11 19:36:25.377993
# Unit test for function evalString
def test_evalString():

    # Create a test string with all the escape characters
    s = ('\n\\\'"abfnrtv\\x23\\123\\0123\\u4567\\U89ABCDEF\\'
         'N{LATIN CAPITAL LETTER A}\\N{LATIN CAPITAL LETTER A WITH DIAERESIS}\\'
         'N{LATIN SMALL LETTER A WITH GRAVE}\\N{GREEK CAPITAL LETTER ALPHA}'
         '\\U0001D49C\\N{LATIN SUBSCRIPT SMALL LETTER I}')
    # escape() returns Unicode strings, so we encode them as utf-8
    s = s.encode('utf-8')
    # Create a string literal with all these characters
    t = repr(s)[2:-1]
    # evalString() returns Unicode strings

# Generated at 2022-06-11 19:36:34.967000
# Unit test for function escape

# Generated at 2022-06-11 19:36:42.830716
# Unit test for function evalString
def test_evalString():
    assert evalString('"a"') == 'a'
    assert evalString('"\\x61"') == 'a'
    assert evalString('"\\141"') == 'a'
    assert evalString('"\\1"') == '\x01'
    assert evalString('"\\01"') == '\x01'
    assert evalString('"\\001"') == '\x01'
    assert evalString('"\\0001"') == '\x01\x00\x30\x31'
    assert evalString('"\\00001"') == '\x01\x30\x30\x31'

    # Not used, but supported by CPython
    assert evalString('"\\a"') == '\a'
    assert evalString('"\\b"') == '\b'

# Generated at 2022-06-11 19:36:49.326714
# Unit test for function escape
def test_escape():
	assert escape('\\u') == 'u'
	assert escape('\\0') == '\x00'
	assert escape('\\x') == 'x'
	assert escape('\\b') == '\b'
	assert escape('\\xab') == '\xab'
	assert escape('\\377') == '\xff'
	assert escape('\\777') == '\x1b'

# Generated at 2022-06-11 19:36:56.789994
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"
    assert escape(re.match(r"\\(.)", r'\"')) == '"'

# Generated at 2022-06-11 19:37:07.714382
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x00", "\\x00")) == "\x00"
    assert escape(re.match(r"\\xFF", "\\xFF")) == "\xFF"
    assert escape(re.match(r"\\x12", "\\x12")) == "\x12"
    assert escape(re.match(r"\\xAB", "\\xAB")) == "\xAB"
    assert escape(re.match(r"\\xef", "\\xef")) == "\xef"
    assert escape(re.match(r"\\x1f", "\\x1f")) == "\x1f"
    assert escape(re.match(r"\\x0", "\\x0")) == "\x00"

# Generated at 2022-06-11 19:37:18.807072
# Unit test for function evalString
def test_evalString():

    # Simple test
    assert evalString("'hello'") == "hello"

    # Escape characters
    assert evalString("'\\a'") == "\a"
    assert evalString("'\\b'") == "\b"
    assert evalString("'\\f'") == "\f"
    assert evalString("'\\n'") == "\n"
    assert evalString("'\\r'") == "\r"
    assert evalString("'\\t'") == "\t"
    assert evalString("'\\v'") == "\v"

    # Backslash and double quote are literal characters
    assert evalString("'\\\\'") == "\\"
    assert evalString("'\\\''") == "'"

    # Hex escape
    assert evalString("'\\x61'") == "a"

# Generated at 2022-06-11 19:37:29.701615
# Unit test for function escape
def test_escape():
    # simple escapes
    for key in simple_escapes:
        # two different ways of escaping quotes
        for quote in ('"', "'"):
            assert evalString(quote + '\\' + key + quote) == quote + simple_escapes[key] + quote
            assert evalString(quote + '\\\\' + key + quote) == quote + '\\' + key + quote
    # octal escapes
    assert evalString("'\\0'") == "'\0'"
    assert evalString("'\\00'") == "'\0'"
    assert evalString("'\\000'") == "'\0'"
    assert evalString("'\\01'") == "'\x01'"
    assert evalString("'\\012'") == "'\x0a'"
    assert evalString("'\\0123'") == "'\x53'"
    assert eval

# Generated at 2022-06-11 19:37:40.551353
# Unit test for function escape
def test_escape():

    # Just a few tests as we rely on test_evalString for more thorough checking
    assert escape(re.match('\\\\([\'\"\\\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\\'')) == '\''
    assert escape(re.match('\\\\([\'\"\\\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\\\')) == '\\'
    assert escape(re.match('\\\\([\'\"\\\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\x01')) == '\x01'

    # Test if ValueError is raised

# Generated at 2022-06-11 19:37:52.146873
# Unit test for function escape
def test_escape():
    assert escape(re.search(r'\\([abfnrtv\\\'"x]|[0-7]{1,3})', '\\a')) == '\a'
    assert escape(re.search(r'\\([abfnrtv\\\'"x]|[0-7]{1,3})', '\\b')) == '\b'
    assert escape(re.search(r'\\([abfnrtv\\\'"x]|[0-7]{1,3})', '\\f')) == '\f'
    assert escape(re.search(r'\\([abfnrtv\\\'"x]|[0-7]{1,3})', '\\n')) == '\n'

# Generated at 2022-06-11 19:38:20.930874
# Unit test for function escape

# Generated at 2022-06-11 19:38:21.474697
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:38:31.791311
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', '\\a')) == '\a'
    assert escape(re.match('\\b', '\\b')) == '\b'
    assert escape(re.match('\\f', '\\f')) == '\f'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'
    assert escape(re.match('\\v', '\\v')) == '\v'
    assert escape(re.match('\\\'', '\\\'')) == '\''
    assert escape(re.match('\\"', '\\"')) == '"'

# Generated at 2022-06-11 19:38:38.843438
# Unit test for function escape
def test_escape():
    test_str = b"\x01foobar\xff"
    test_str_hex = b"\\x01foobar\\xff"
    assert escape(re.search(r"\\x01", test_str_hex)) == test_str[0]
    assert escape(re.search(r"\\xff", test_str_hex)) == test_str[-1]
    assert escape(re.search(r"\\x", test_str_hex)) == b"\\x"
    assert escape(re.search(r"\\", test_str_hex)) == b"\\"
    assert escape(re.search(r"\\a", b"\\a")) == b"\a"
    assert escape(re.search(r"\\t", b"\\t")) == b"\t"

# Generated at 2022-06-11 19:38:45.182119
# Unit test for function test
def test_test():
    try:
        test()
    except Exception as e:
        excType, excObj, excTb = sys.exc_info()
        fname = os.path.split(excTb.tb_frame.f_code.co_filename)[1]
        raise Exception(str(e) + " | "+str(excType) + " | "+str(fname)+" | "+str(excTb.tb_lineno))

# Generated at 2022-06-11 19:38:56.381883
# Unit test for function escape
def test_escape():
    assert "ab" == escape(re.match(r"\\a", "\\ab"))
    assert "\n" == escape(re.match(r"\\n", "\\n"))
    assert "\\" == escape(re.match(r"\\\\", "\\\\"))
    assert "\\ " == escape(re.match(r"\\\\ ", "\\\\ "))

    assert "1" == escape(re.match(r"\\x31", "\\x31"))
    assert "\u0100" == escape(re.match(r"\\xC4", "\\xC4"))
    assert "\u0100" == escape(re.match(r"\\u0100", "\\u0100"))

    assert "ab" == escape(re.match(r"\\0a", "\\0ab"))

# Generated at 2022-06-11 19:39:06.502128
# Unit test for function escape
def test_escape():
    import string
    for c in string.digits + string.ascii_letters + "BW":
        s = "\\" + c  # type: Text
        assert escape(re.match(r"\\[abfnrtv]", s)) == simple_escapes[c]  # type: ignore

    for i in range(256):
        s = "\\%03o" % i  # type: Text
        assert escape(re.match(r"\\[abfnrtv]", s)) == chr(i)  # type: ignore

    for i in range(256):
        s = "\\x%02X" % i  # type: Text
        assert escape(re.match(r"\\[abfnrtv]", s)) == chr(i)  # type: ignore


# Generated at 2022-06-11 19:39:15.075816
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\.", r"\x")) == 'x'
    assert escape(re.match(r"\\.", r"\x2")) == 'x2'
    assert escape(re.match(r"\\.", r"\x20")) == ' '

    assert escape(re.match(r"\\.", r"\xgg")) == 'xgg'
    assert escape(re.match(r"\\.", r"\xg2")) == 'xg2'
    assert escape(re.match(r"\\.", r"\xg20")) == 'xg20'

    assert escape(re.match(r"\\.", r"\4")) == '4'
    assert escape(re.match(r"\\.", r"\40")) == ' '

# Generated at 2022-06-11 19:39:25.847999
# Unit test for function escape
def test_escape():
    assert escape('\a') == '\a'
    assert escape('\b') == '\b'
    assert escape('\f') == '\f'
    assert escape('\n') == '\n'
    assert escape('\r') == '\r'
    assert escape('\t') == '\t'
    assert escape('\v') == '\v'
    assert escape("\'") == "\'"
    assert escape('\"') == '\"'
    assert escape('\\') == '\\'
    assert escape('\x7f') == chr(127)
    assert escape('\377') == chr(255)
    assert escape('\777') == chr(511 & 255)



# Generated at 2022-06-11 19:39:32.540459
# Unit test for function escape
def test_escape():
    m = [8, b"\\008"]
    assert escape(m) == chr(8)
    m = [9, b"\\09"]
    assert escape(m) == chr(9)
    m = [10, b"\\10"]
    assert escape(m) == chr(10)
    m = [11, b"\\11"]
    assert escape(m) == chr(11)
    m = [12, b"\\12"]
    assert escape(m) == chr(12)
    m = [13, b"\\13"]
    assert escape(m) == chr(13)
    m = [77, b"\\x4D"]
    assert escape(m) == chr(77)
    m = [45, b"\\x2d"]
    assert escape(m) == ch

# Generated at 2022-06-11 19:39:57.558285
# Unit test for function test
def test_test():
    try:
        test()
    except:
        print("test() raised exception.")

# Generated at 2022-06-11 19:40:09.294436
# Unit test for function escape
def test_escape():
    """Test each byte of the ascii table's escape sequence"""
    assert escape(re.match(r"\\([\x01-\x07])", r"\1")) == "\x01"
    assert escape(re.match(r"\\([\x10-\x17])", r"\10")) == "\x10"
    assert escape(re.match(r"\\([\x20-\x27])", r"\20")) == "\x20"
    assert escape(re.match(r"\\([\x30-\x37])", r"\30")) == "\x30"
    assert escape(re.match(r"\\([\x40-\x47])", r"\40")) == "\x40"

# Generated at 2022-06-11 19:40:12.356474
# Unit test for function test
def test_test():
    try:
        test()
        assert True
    except:
        assert False

# Generated at 2022-06-11 19:40:17.881352
# Unit test for function escape
def test_escape():
    m = "\\x09"
    assert escape(m) == "\t"
    del m
    m = "\\09"
    assert escape(m) == "\t"
    del m
    m = "\\010"
    assert escape(m) == "\n"
    del m

# Generated at 2022-06-11 19:40:27.017976
# Unit test for function escape
def test_escape():
    # Test valid escapes
    assert escape(re.match('\\x\x00', '\\x00')) == '\x00'
    assert escape(re.match('\\x\x10', '\\x10')) == '\x10'
    assert escape(re.match('\\x\xF0', '\\xF0')) == '\xF0'
    assert escape(re.match('\\x\xFF', '\\xFF')) == '\xFF'
    assert escape(re.match('\\x\xFF', '\\xFF')) == '\xFF'
    assert escape(re.match('\\111', '\\111')) == 'I'
    assert escape(re.match('\\11', '\\11')) == '\t'

# Generated at 2022-06-11 19:40:35.361634
# Unit test for function escape

# Generated at 2022-06-11 19:40:47.168420
# Unit test for function escape
def test_escape():
    # Valid input
    assert escape("\\0") == "\0"
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\x1a") == "\x1a"
    assert escape("\\x1A") == "\x1a"
    assert escape("\\377") == "\xff"
    assert escape("\\377\\000") == "\xff\0"

    # Invalid input

# Generated at 2022-06-11 19:40:58.630242
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\x01", "\\x01")) == "\x01"
    assert escape(re.match(r"\\x07", "\\x07")) == "\x07"
    assert escape(re.match(r"\\x0A", "\\x0A")) == "\x0A"
    assert escape(re.match(r"\\x0F", "\\x0F")) == "\x0F"
    assert escape(re.match(r"\\x10", "\\x10")) == "\x10"
    assert escape(re.match(r"\\x1F", "\\x1F")) == "\x1F"

# Generated at 2022-06-11 19:41:09.000456
# Unit test for function escape
def test_escape():
    import unittest

    class TestEscape(unittest.TestCase):
        def test_good_escapes(self):
            self.assertEqual(escape(re.match("", "\\a")), "\a")
            self.assertEqual(escape(re.match("", "\\b")), "\b")
            self.assertEqual(escape(re.match("", "\\f")), "\f")
            self.assertEqual(escape(re.match("", "\\n")), "\n")
            self.assertEqual(escape(re.match("", "\\r")), "\r")
            self.assertEqual(escape(re.match("", "\\t")), "\t")
            self.assertEqual(escape(re.match("", "\\v")), "\v")
            self.assertEqual

# Generated at 2022-06-11 19:41:11.596723
# Unit test for function test
def test_test():
    """
    Function test() does not return anything
    """
    test()
    assert True


# Generated at 2022-06-11 19:42:06.075129
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'

# Generated at 2022-06-11 19:42:14.223924
# Unit test for function escape
def test_escape():
    assert escape(re.search(r"\\\d{1,3}", "\\1")) == "\x01"
    assert escape(re.search(r"\\\d{1,3}", "\\11")) == "\x09"
    assert escape(re.search(r"\\\d{1,3}", "\\123")) == "{"
    assert escape(re.search(r"\\x.{0,2}", "\\x3")) == "\x03"
    assert escape(re.search(r"\\x.{0,2}", "\\x03")) == "\x03"
    assert escape(re.search(r"\\x.{0,2}", "\\x003")) == "\x03"
    assert escape(re.search(r"\\\w", "\\a")) == "\x07"


# Generated at 2022-06-11 19:42:15.220655
# Unit test for function test
def test_test():
    from testing import run

    run(test)

# Generated at 2022-06-11 19:42:16.910515
# Unit test for function escape
def test_escape():
    pass


# Generated at 2022-06-11 19:42:27.474574
# Unit test for function escape
def test_escape():
    import unittest
    import re

    class TestEscape(unittest.TestCase):
        def test_escape_1(self):
            # test simple escape
            self.assertEqual(escape(re.match(r"\\([abfnrtv\'\"\\])", "\\a")), "\a")
            self.assertEqual(escape(re.match(r"\\([abfnrtv\'\"\\])", "\\b")), "\b")
            self.assertEqual(escape(re.match(r"\\([abfnrtv\'\"\\])", "\\f")), "\f")
            self.assertEqual(escape(re.match(r"\\([abfnrtv\'\"\\])", "\\n")), "\n")

# Generated at 2022-06-11 19:42:39.208941
# Unit test for function escape
def test_escape():

    assert escape(re.match(r"\\a", r"\a")) == r"\a"
    assert escape(re.match(r"\\b", r"\b")) == r"\b"
    assert escape(re.match(r"\\f", r"\f")) == r"\f"
    assert escape(re.match(r"\\n", r"\n")) == r"\n"
    assert escape(re.match(r"\\r", r"\r")) == r"\r"
    assert escape(re.match(r"\\t", r"\t")) == r"\t"
    assert escape(re.match(r"\\v", r"\v")) == r"\v"
    assert escape(re.match(r"\\\'", r"\'")) == r"\'"


# Generated at 2022-06-11 19:42:42.833220
# Unit test for function test
def test_test():
    """Check if function that tests function test works.

    test_test should call evalString, which should then call escape, which should then call evalString which should then call escape
    """
    if evalString("'abc'") != 'abc':
        raise ValueError

# Generated at 2022-06-11 19:42:51.562588
# Unit test for function escape
def test_escape():
    # Test simple escapes
    assert escape('\\x41') == 'A'
    assert escape('\\141') == 'a'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'

    # Test hexadecimal escapes
    assert escape('\\x41') == 'A'
    assert escape('\\x0a') == '\n'
    assert escape('\\x0A') == '\n'
    assert escape('\\x41') == 'A'
    assert escape('\\x0401') == '\u0401'
    assert escape('\\U00000401') == '\u0401'

# Generated at 2022-06-11 19:43:01.420847
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\'", r"\'")) == "'"

# Generated at 2022-06-11 19:43:12.743580
# Unit test for function escape
def test_escape():
    # Test normal escapes
    escape_tests = [
        r"\0",
        r"\a",
        r"\b",
        r"\f",
        r"\n",
        r"\r",
        r"\t",
        r"\v",
        r"\x0c",
        r"\x7f",
    ]
    for t in escape_tests:
        assert escape(re.match(r"\\.+", t)) == t[1]

    # Test octal escapes
    assert escape(re.match(r"\\.+", r"\077")) == chr(0o77)
    with pytest.raises(ValueError):
        escape(re.match(r"\\.+", r"\0777777777"))

# Generated at 2022-06-11 19:44:10.647009
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:44:21.424191
# Unit test for function escape
def test_escape():
    m = re.match(r'\\([bvtrnfa\\\'"x]|\d{1,3})', '\\b')
    assert escape(m) == "\b"
    m = re.match(r'\\([bvtrnfa\\\'"x]|\d{1,3})', '\\x20')
    assert escape(m) == " "
    m = re.match(r'\\([bvtrnfa\\\'"x]|\d{1,3})', '\\160')
    assert escape(m) == " "
    m = re.match(r'\\([bvtrnfa\\\'"x]|\d{1,3})', '\\0')
    assert escape(m) == "\0"

# Generated at 2022-06-11 19:44:33.170762
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\x41") == "A"
    assert escape("\\xA2") == "¢"
    assert escape("\\xaa") == "ª"
    assert escape("\\xFF") == "ÿ"
    assert escape("\\777") == "?"
    assert escape("\\000") == "\x00"
    assert escape