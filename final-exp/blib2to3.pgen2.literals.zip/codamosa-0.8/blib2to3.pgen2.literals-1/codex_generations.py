

# Generated at 2022-06-11 19:35:12.221198
# Unit test for function escape
def test_escape():
    assert escape(r'\a') == '\x07', escape(r'\a')
    assert escape(r'\b') == '\x08', escape(r'\b')
    assert escape(r'\f') == '\x0c', escape(r'\f')
    assert escape(r'\n') == '\n', escape(r'\n')
    assert escape(r'\r') == '\r', escape(r'\r')
    assert escape(r'\t') == '\t', escape(r'\t')
    assert escape(r'\v') == '\x0b', escape(r'\v')
    assert escape(r'\xfe') == '\xfe', escape(r'\xfe')

# Generated at 2022-06-11 19:35:13.010176
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:35:23.123456
# Unit test for function escape
def test_escape():
    m1 = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")
    m2 = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\x41")
    m3 = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\101")
    assert escape(m1) == "\a"
    assert escape(m2) == "A"
    assert escape(m3) == "A"


# Generated at 2022-06-11 19:35:30.986695
# Unit test for function escape
def test_escape():
    # This unit test actually checks the behavior of re.sub()
    test_string = "\\x1g"
    pattern = "\\x[0-9a-fA-F]{2}"
    expected_result = "?g"
    result = re.sub(pattern, "?", test_string)
    assert result == expected_result
    test_string = "\\07g"
    pattern = "\\0?[0-7]{1,2}"
    expected_result = "?g"
    result = re.sub(pattern, "?", test_string)
    assert result == expected_result



# Generated at 2022-06-11 19:35:35.531410
# Unit test for function test
def test_test():
    import sys
    import io
    from . import TestSupport

    with TestSupport.captured_output("stdout") as out:
        test()
    output = out.getvalue()
    assert output == ""
    assert sys.stdout.encoding == "UTF-8"
    assert isinstance(out, io.StringIO)

# Generated at 2022-06-11 19:35:45.498270
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\.+", '\\a')) == "\a"
    assert escape(re.match(r"\\.+", '\\b')) == "\b"
    assert escape(re.match(r"\\.+", '\\f')) == "\f"
    assert escape(re.match(r"\\.+", '\\n')) == "\n"
    assert escape(re.match(r"\\.+", '\\r')) == "\r"
    assert escape(re.match(r"\\.+", '\\t')) == "\t"
    assert escape(re.match(r"\\.+", '\\v')) == "\v"
    assert escape(re.match(r"\\.+", "\\'")) == "'"

# Generated at 2022-06-11 19:35:50.191078
# Unit test for function evalString
def test_evalString():
    assert evalString('"1"') == '1'
    assert evalString('"\\t"') == '\t'
    assert evalString("'1'") == '1'
    assert evalString("'\\t'") == '\t'

# No coverage for these tests

# Generated at 2022-06-11 19:35:58.569582
# Unit test for function escape
def test_escape():
    import pytest
    assert escape(re.match(r"\\a", r'\a')) == "\a"
    assert escape(re.match(r"\\b", r'\b')) == "\b"
    assert escape(re.match(r"\\f", r'\f')) == "\f"
    assert escape(re.match(r"\\n", r'\n')) == "\n"
    assert escape(re.match(r"\\r", r'\r')) == "\r"
    assert escape(re.match(r"\\t", r'\t')) == "\t"
    assert escape(re.match(r"\\v", r'\v')) == "\v"
    assert escape(re.match(r"\\\'", r"\'")) == "'"

# Generated at 2022-06-11 19:36:09.743256
# Unit test for function escape
def test_escape():
    assert escape(re.search(r'\\([\'"])', '"\"\'"')) == '\''
    assert escape(re.search(r'\\t', ' "\t"')) == '\t'
    assert escape(re.search(r'\\n', ' "\n"')) == '\n'
    assert escape(re.search(r'\\[x]12', ' "\x12"')) == '\x12'


# Generated at 2022-06-11 19:36:18.230131
# Unit test for function escape
def test_escape():
    # Test an empty escape sequence
    assert escape(re.match("\\","")) == '\\'

    # Test some common escape sequences
    assert escape(re.match("\\a","")) == escape(re.match("\\x61","")) == "\a"
    assert escape(re.match("\\b","")) == "\b"
    assert escape(re.match("\\f","")) == "\f"
    assert escape(re.match("\\n","")) == "\n"
    assert escape(re.match("\\r","")) == "\r"
    assert escape(re.match("\\t","")) == "\t"
    assert escape(re.match("\\v","")) == "\v"
    assert escape(re.match("\\'","")) == "'"
    assert escape(re.match("\\\"","")) == '"'

# Generated at 2022-06-11 19:36:43.164965
# Unit test for function escape
def test_escape():
    from unittest import TestCase, main

    class Test(TestCase):

        def test_escape(self):
            self.assertEqual(escape(re.match(r"\\.", "\\a")), "\a")
            self.assertEqual(escape(re.match(r"\\.", "\\b")), "\b")
            self.assertEqual(escape(re.match(r"\\.", "\\f")), "\f")
            self.assertEqual(escape(re.match(r"\\.", "\\n")), "\n")
            self.assertEqual(escape(re.match(r"\\.", "\\r")), "\r")
            self.assertEqual(escape(re.match(r"\\.", "\\t")), "\t")

# Generated at 2022-06-11 19:36:54.155029
# Unit test for function evalString
def test_evalString():
    assert evalString("'a'") == "a"
    assert evalString('"a"') == "a"
    assert evalString("'\\\\'") == "\\"
    assert evalString('"\\\\"') == "\\"
    assert evalString("'\\''") == "'"
    assert evalString('"\\""') == '"'
    assert evalString(r"'\\a'") == "\a"
    assert evalString(r'"\\a"') == "\a"
    assert evalString(r"'\\b'") == "\b"
    assert evalString(r'"\\b"') == "\b"
    assert evalString(r"'\\f'") == "\f"
    assert evalString(r'"\\f"') == "\f"
    assert evalString(r"'\\r'") == "\r"

# Generated at 2022-06-11 19:37:06.099196
# Unit test for function evalString
def test_evalString():
    # Check that evalString raises a ValueError for ill-formed strings
    with pytest.raises(ValueError, match="invalid octal string escape"):
        evalString('"\\08"')
    with pytest.raises(ValueError, match="invalid octal string escape"):
        evalString('"\\789"')
    with pytest.raises(ValueError, match="invalid octal string escape"):
        evalString('"\\0"')
    with pytest.raises(ValueError, match="invalid octal string escape"):
        evalString('"\\0789"')
    with pytest.raises(ValueError, match="invalid hex string escape"):
        evalString('"\\x0"')

# Generated at 2022-06-11 19:37:17.830947
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\x00") == "\x00"
    assert escape("\\xff") == "\xff"
    assert escape("\\377") == "\x7f"
    assert escape("\\785") == "\x17"
    assert escape("\\015") == "\n"
    assert escape("\\x1") == "x1"  # error:

# Generated at 2022-06-11 19:37:29.332517
# Unit test for function escape
def test_escape():
    from typing import Any

    # Test escaped octal
    for c in range(0,256):
        if c < 8:
            continue
        ctr = chr(c)
        assert escape(ctr) == ctr, otr
        assert escape(ctr) == evalString(esc), otr
    # Test escaped hex
    for c in range(0,256):
        ctr = chr(c)
        out = test_escape.escape_hex(c)
        assert escape(ctr) == out, out
        assert escape(ctr) == evalString(out), out

    # Test escaped string
    for c in range(0,256):
        if c in range(ord("'"),ord("~")):
            continue
        ctr = chr(c)
        out = test_escape.escape_str(c)
       

# Generated at 2022-06-11 19:37:29.893385
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:37:30.600284
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:37:35.168173
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\[tn]', r'\t')) == '\t'
    assert escape(re.match(r'\\[tn]', r'\n')) == '\n'

# Generated at 2022-06-11 19:37:43.339129
# Unit test for function escape
def test_escape():

    test_data = [
        ("\\'", "'"),
        ("\\0", "\x00"),
        ("\\9", "\t"),
        ("\\12", "\x0c"),
        ("\\41", "A"),
        ("\\x", ""),
        ("\\x1", "\x01"),
        ("\\xa", "\n"),
        ("\\xff", "\xff"),
        ("\\u1234", "\u1234"),
        ("\\U00010111", "\U00010111"),
    ]

    for ts in test_data:
        assert escape(re.match(r"\\", ts[0])) == ts[1]



# Generated at 2022-06-11 19:37:52.881996
# Unit test for function escape
def test_escape():
    assert escape("\\x61") == "a"
    assert escape("\\x61 ") == "a "
    try:
        escape("\\x6")
        assert False
    except ValueError:
        pass
    try:
        escape("\\x6z")
        assert False
    except ValueError:
        pass
    try:
        escape("\\x6 1")
        assert False
    except ValueError:
        pass
    try:
        escape("\\o")
        assert False
    except ValueError:
        pass
    try:
        escape("\\8")
        assert False
    except ValueError:
        pass
    try:
        escape("\\89")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 19:38:17.701261
# Unit test for function escape
def test_escape():
    for value in simple_escapes:
        assert escape(MatchObject(value)) == simple_escapes[value]



# Generated at 2022-06-11 19:38:29.602864
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(a)", "\\a")) == "\a"
    assert escape(re.match(r"\\(b)", "\\b")) == "\b"
    assert escape(re.match(r"\\(f)", "\\f")) == "\f"
    assert escape(re.match(r"\\(n)", "\\n")) == "\n"
    assert escape(re.match(r"\\(r)", "\\r")) == "\r"
    assert escape(re.match(r"\\(t)", "\\t")) == "\t"
    assert escape(re.match(r"\\(v)", "\\v")) == "\v"
    assert escape(re.match(r"\\(x0)", "\\x0")) == "\x00"

# Generated at 2022-06-11 19:38:42.504977
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\x61") == "a"
    assert escape("\\x000061") == "a"
    assert escape("\\0001") == "\x01"
    assert escape("\\x0001") == "\x01"
    assert escape("\\001") == "\x01"
    assert escape("\\x0061") == "a"
   

# Generated at 2022-06-11 19:38:45.537477
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\xFA", r"\xFA")) == r"\xfa"
    assert escape(re.match(r"\xFD", r"\xFD")) == r"\xfd"

# Generated at 2022-06-11 19:38:46.198186
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:38:52.191560
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\a', '\\a')) == '\a'
    assert escape(re.match(r'\\b', '\\b')) == '\b'
    assert escape(re.match(r'\\f', '\\f')) == '\f'
    assert escape(re.match(r'\\n', '\\n')) == '\n'
    assert escape(re.match(r'\\r', '\\r')) == '\r'
    assert escape(re.match(r'\\t', '\\t')) == '\t'
    assert escape(re.match(r'\\v', '\\v')) == '\v'

    assert escape(re.match(r"\\'", "\\'")) == "'"

# Generated at 2022-06-11 19:38:52.958818
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:38:55.175984
# Unit test for function escape
def test_escape():
    assert escape("\\n") == "\n"



# Generated at 2022-06-11 19:38:59.529288
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-11 19:39:09.375170
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', '\\a')) == '\a'
    assert escape(re.match('\\b', '\\b')) == '\b'
    assert escape(re.match('\\f', '\\f')) == '\f'
    assert escape(re.match('\\n', '\\n')) == '\n'
    assert escape(re.match('\\r', '\\r')) == '\r'
    assert escape(re.match('\\t', '\\t')) == '\t'
    assert escape(re.match('\\v', '\\v')) == '\v'
    assert escape(re.match("\\'", "\\'")) == "'"
    assert escape(re.match('\\"', '\\"')) == '"'

# Generated at 2022-06-11 19:39:53.916740
# Unit test for function escape
def test_escape():
    assert escape('\\0') == '\x00'
    assert escape('\\1') == '\x01'
    assert escape('\\7') == '\x07'
    assert escape('\\10') == '\x08'
    assert escape('\\11') == '\t'
    assert escape('\\17') == '\x0f'
    assert escape('\\20') == '\x10'
    assert escape('\\37') == '\x1f'
    assert escape('\\40') == ' '
    assert escape('\\177') == '\x7f'
    assert escape('\\200') == '\x80'
    assert escape('\\377') == '\xff'
    assert escape('\\x00') == '\x00'
    assert escape('\\x01') == '\x01'
    assert escape

# Generated at 2022-06-11 19:40:05.113044
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\a')) == '\a'
    assert escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\b')) == '\b'
    assert escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\f')) == '\f'

# Generated at 2022-06-11 19:40:12.588570
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x12", r"\x12")) == "\x12"

# Generated at 2022-06-11 19:40:15.118095
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x1", r"\x1")) == "\x01"

# Generated at 2022-06-11 19:40:24.665487
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\x08"
    assert escape("\\f") == "\x0c"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\x0b"
    assert escape("\\b") == "\x08"
    assert escape("\\'") == "\'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"

    assert escape("\\0") == "\x00"
    assert escape("\\x00") == "\x00"
    assert escape("\\007") == "\x07"
    assert escape("\\x07") == "\x07"
    assert escape("\\77") == "?"

# Generated at 2022-06-11 19:40:33.427462
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\(?P<tail>(?P<all>\\\\)n)', '\\\n')) == '\\\n'
    assert escape(re.match(r'\\(?P<tail>(?P<all>\\\\)n)', '\\\x03')) == '\\\x03'
    assert escape(re.match(r'\\(?P<tail>(?P<all>\\\\)n)', '\\\b')) == '\\\b'
    assert escape(re.match(r'\\(?P<tail>(?P<all>\\\\)n)', '\\\'')) == '\\\''
    assert escape(re.match(r'\\(?P<tail>(?P<all>\\\\)n)', '\\\v')) == '\\\v'

# Generated at 2022-06-11 19:40:45.851760
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})", '\\a')) == '\a'
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})", '\\b')) == '\b'
    assert escape(re.match(r"\\([abfnrtv\'\"\\]|x.{0,2}|[0-7]{1,3})", '\\f')) == '\x0c'

# Generated at 2022-06-11 19:40:52.595547
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\\"') == '\"'
    assert escape('\\\\') == '\\'
    #
    assert escape('\\x41') == 'A'
    assert escape('\\x4a') == 'J'
    assert escape('\\x4f') == 'O'
    assert escape('\\x4e') == 'N'
    #
    assert escape('\\101') == 'A'

# Generated at 2022-06-11 19:41:00.913610
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', '\a')).encode('utf-8') == b'\x07'
    assert escape(re.match('\\b', '\b')).encode('utf-8') == b'\x08'
    assert escape(re.match('\\f', '\f')).encode('utf-8') == b'\x0c'
    assert escape(re.match('\\n', '\n')).encode('utf-8') == b'\n'
    assert escape(re.match('\\r', '\r')).encode('utf-8') == b'\r'
    assert escape(re.match('\\t', '\t')).encode('utf-8') == b'\t'

# Generated at 2022-06-11 19:41:09.322455
# Unit test for function escape
def test_escape():
    assert escape("\\a").startswith("\u0007")
    assert escape("\\b").startswith("\u0008")
    assert escape("\\f").startswith("\u000C")
    assert escape("\\n").startswith("\u000A")
    assert escape("\\r").startswith("\u000D")
    assert escape("\\t").startswith("\u0009")
    assert escape("\\v").startswith("\u000B")
    assert escape("\\'").startswith("'")
    assert escape('\\"').startswith('"')
    assert escape("\\\\").startswith("\\")

    raises(ValueError, escape, "\\")
    raises(ValueError, escape, "\\x")
    raises(ValueError, escape, "\\25")
   

# Generated at 2022-06-11 19:42:46.623872
# Unit test for function test
def test_test():
    # Function called.
    test()

# Generated at 2022-06-11 19:42:58.024662
# Unit test for function escape
def test_escape():
    """Test for escape method
    """
    assert escape(re.search("\\'", "\''")) == "'"
    assert escape(re.search("\\'", "\\'")) == "'"
    assert escape(re.search("\\'", "\\x1a")) == '\x1a'
    assert escape(re.search("\\'", "\\x1A")) == '\x1a'
    assert escape(re.search("\\'", "\\07")) == '\x07'
    assert escape(re.search("\\'", "\\10")) == '\x08'
    assert escape(re.search("\\'", "\\xFF")) == '\xff'
    # Test all the other characters
    assert escape(re.search("\\'", "\\a")) == "\a"

# Generated at 2022-06-11 19:43:00.432509
# Unit test for function escape
def test_escape():
    import sys
    if sys.version_info[0] > 2:
        global escape

# Generated at 2022-06-11 19:43:11.727206
# Unit test for function escape
def test_escape():
    assert escape('\'') == '\''
    assert escape('\\\'') == '\''
    assert escape('b') == '\b'
    assert escape('\\b') == '\b'

# Generated at 2022-06-11 19:43:17.810363
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"

    assert escape("\\x61") == "a"
    assert escape("\\x42") == "B"
    assert escape("\\x03") == "\x03"
    assert escape("\\x004") == "\x04"
    assert escape("\\x00005") == "\x05"

    assert escape("\\000") == "\x00"


# Generated at 2022-06-11 19:43:28.354231
# Unit test for function escape
def test_escape():
    assert r'\x18' == escape(r'\x18')
    assert r'\x19' == escape(r'\x19')
    assert r'\19' == escape(r'\19')
    assert r'\10' == escape(r'\10')
    assert r'\1' == escape(r'\1')
    assert r'"' == escape(r'"')
    assert r'\\' == escape(r'\\')
    assert r"'" == escape(r"'")
    assert r'\t' == escape(r'\t')
    assert r'\v' == escape(r'\v')
    assert r"\n" == escape(r"\n")
    assert r'\b' == escape(r'\b')

# Generated at 2022-06-11 19:43:28.809841
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:43:29.563400
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:43:38.830813
# Unit test for function escape

# Generated at 2022-06-11 19:43:40.530586
# Unit test for function test
def test_test():
    import sys

    import pytest

    pytest.main([sys.argv[0], "-v"])