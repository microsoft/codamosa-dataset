

# Generated at 2022-06-11 19:34:58.980606
# Unit test for function evalString
def test_evalString():
    assert evalString('"A"') == "A"
    assert evalString("'B'") == "B"
    assert evalString("'''C'''") == 'C'
    assert evalString('"\\n"') == "\n"
    assert evalString("'\\''") == "'"
    assert evalString("'\\x61'") == "a"
    assert evalString("'\\xA9'") == "\u00a9"
    assert evalString("'\\x1e6b\\x0302'") == "\u1e6b\u0302"
    assert evalString("'\\U0001d120'") == "\U0001d120"
    assert evalString("'\\U0001d11e\\U0000305f'") == "\U0001d11e\U0000305f"

# Generated at 2022-06-11 19:35:10.791059
# Unit test for function escape
def test_escape():
    assert escape('\\xFF') == '\xff'
    assert escape('\\377') == '\xff'
    assert escape('\\xff') == '\xff'
    assert escape('\\7') == '\x07'
    assert escape('\\7') == '\x07'
    assert escape('\\07') == '\x07'
    assert escape('\\007') == '\x07'
    assert escape('\\27') == '\x17'
    assert escape('\\227') == '\x17'
    assert escape('\\a') == '\x07'
    assert escape('\\b') == '\x08'
    assert escape('\\r') == '\x0d'
    assert escape('\\n') == '\x0a'
    assert escape('\\f') == '\x0c'

# Generated at 2022-06-11 19:35:17.118173
# Unit test for function escape
def test_escape():
    d = dict(zip('abfnrtv', '\a\b\f\n\r\t\v'))
    for c, e in d.items():
        m = re.match(r'\\'+c+'$', r'\%s' % c)
        assert escape(m) == e


# Generated at 2022-06-11 19:35:24.667209
# Unit test for function escape

# Generated at 2022-06-11 19:35:36.223764
# Unit test for function escape
def test_escape():
    # test the escape function
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape("\\\"") == '"'
    assert escape("\\\\") == "\\"
    assert escape("\\x41") == "A"
    assert escape("\\x4A") == "J"
    assert escape("\\x4j") == "\\x4j"
    assert escape("\\x4") == "\\x4"
    assert escape("\\12") == "\x0a"

# Generated at 2022-06-11 19:35:45.829497
# Unit test for function evalString
def test_evalString():
    assert evalString(r"\'") == "'"
    assert evalString(r'\"') == '"'
    assert evalString(r'\'') == r'\''
    assert evalString(r'\"') == r'\"'
    assert evalString(r'\\') == r'\\'
    assert evalString(r'''\n''') == r'''
'''
    assert evalString(r'\a') == "\x07"
    assert evalString(r'\b') == "\x08"
    assert evalString(r'\f') == "\x0c"
    assert evalString(r'\r') == "\r"
    assert evalString(r'\t') == "\t"
    assert evalString(r'\v') == "\x0b"

# Generated at 2022-06-11 19:35:55.135097
# Unit test for function escape
def test_escape():
    # simple escapes
    for s, result in simple_escapes.items():
        assert escape(re.search(f"\\{s}", '')) == result
    # octal escapes
    assert escape(re.search('\\0', '')) == "\0"
    assert escape(re.search('\\7', '')) == "\7"
    assert escape(re.search('\\77', '')) == "\77"
    assert escape(re.search('\\177', '')) == "\177"
    # hex escapes
    assert escape(re.search('\\x1', '')) == "\x01"
    assert escape(re.search('\\xff', '')) == "\xff"



# Generated at 2022-06-11 19:35:59.498982
# Unit test for function evalString
def test_evalString():
    assert evalString(r'"\'"') == r"'"
    assert evalString(r'"\""') == r'"'

# Generated at 2022-06-11 19:36:03.050591
# Unit test for function escape
def test_escape():
    assert escape("\\x1f") == "\x1f"
    assert escape("\\01") == "\x01"
    assert escape("\\1") == "\x01"
    assert escape("\\") == "\\"


# Generated at 2022-06-11 19:36:13.843820
# Unit test for function escape
def test_escape():

    assert escape(re.match(r"\\x", "\\x")) == ""

    assert escape(re.match(r"\\x", "\\x0")) == "\x00"
    assert escape(re.match(r"\\x", "\\x1")) == "\x01"
    assert escape(re.match(r"\\x", "\\x2")) == "\x02"

    assert escape(re.match(r"\\x", "\\x01")) == "\x01"
    assert escape(re.match(r"\\x", "\\x10")) == "\x10"
    assert escape(re.match(r"\\x", "\\x20")) == "\x20"

    assert escape(re.match(r"\\x", "\\xa0")) == "\xa0"

# Generated at 2022-06-11 19:36:54.814864
# Unit test for function escape
def test_escape():
    assert escape(Match(0, '\\n')) == '\n'
    assert escape(Match(0, '\\x0')) == '\x00'
    assert escape(Match(0, '\\x5')) == '\x05'
    assert escape(Match(0, '\\x55')) == '\x55'
    assert escape(Match(0, '\\x055')) == '\x55'
    assert escape(Match(0, '\\x55;')) == '\x55'
    assert escape(Match(0, '\\055')) == '\x3f'
    assert escape(Match(0, '\\155')) == '\x55'
    assert escape(Match(0, '\\555')) == '\x2d'

# Generated at 2022-06-11 19:37:03.229231
# Unit test for function escape
def test_escape():
    # Tests copied from test_string.py.
    assert escape(r"\071") == "1"
    assert escape(r"\x71") == "q"
    assert escape(r"\u12e4") == "\u12e4"
    assert escape(r"\U0001f40d") == "\U0001f40d"
    assert escape(r"\N{GREEK SMALL LETTER ALPHA}") == "\u03b1"
    assert escape(r"\400") == "\u0100"
    assert escape(r"\400", True) == "\\400"

# Generated at 2022-06-11 19:37:11.042794
# Unit test for function escape
def test_escape():
    assert escape(re.match('\\a', '\a')) == '\a'
    assert escape(re.match('\\b', '\b')) == '\b'
    assert escape(re.match('\\f', '\f')) == '\f'
    assert escape(re.match('\\n', '\n')) == '\n'
    assert escape(re.match('\\r', '\r')) == '\r'
    assert escape(re.match('\\t', '\t')) == '\t'
    assert escape(re.match('\\v', '\v')) == '\v'
    assert escape(re.match('\\\'', '\'')) == '\''
    assert escape(re.match('\\\"', '\'')) == '\''

# Generated at 2022-06-11 19:37:12.013232
# Unit test for function test
def test_test():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 19:37:17.272440
# Unit test for function escape
def test_escape():
    assert escape("\\n") == r"\n"
    assert escape("\\'") == r"\'"
    assert escape("\\x2b") == r"\x2b"
    assert escape("\\10") == r"\10"
    assert escape("\\x") == r"\x"
    assert escape("\\xh") == r"\xh"

# Generated at 2022-06-11 19:37:19.550241
# Unit test for function escape
def test_escape():
    # Add tests here
    #assert escape("\\x41") == 'A'
    return

# Generated at 2022-06-11 19:37:30.042743
# Unit test for function escape
def test_escape():
    # type: () -> None
    assert escape(re.match("\\a", r"\a")) == "\a"
    assert escape(re.match("\\b", r"\b")) == "\b"
    assert escape(re.match("\\f", r"\f")) == "\f"
    assert escape(re.match("\\n", r"\n")) == "\n"
    assert escape(re.match("\\r", r"\r")) == "\r"
    assert escape(re.match("\\t", r"\t")) == "\t"
    assert escape(re.match("\\v", r"\v")) == "\v"
    assert escape(re.match("\\'", r"\'")) == "'"
    assert escape(re.match('\\"', r'\"')) == '"'

# Generated at 2022-06-11 19:37:35.865432
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\\x', '\\x')) == "x"
    try:
        escape(re.match(r'\\\x', '\\xxx'))
        raise Exception("Expected a ValueError from short hex string escape")
    except ValueError:
        pass


# Generated at 2022-06-11 19:37:45.022172
# Unit test for function escape
def test_escape():
    test_escape_assert_equal(r"\a", "\a")
    test_escape_assert_equal(r"\b", "\b")
    test_escape_assert_equal(r"\f", "\f")
    test_escape_assert_equal(r"\v", "\v")
    test_escape_assert_equal(r"\'", "'")
    test_escape_assert_equal(r'\"', '"')
    test_escape_assert_equal(r"\\", "\\")
    test_escape_assert_equal(r"\x20", " ")
    test_escape_assert_equal(r"\0", "\0")
    test_escape_assert_equal(r"\1", "\1")
    test_escape_assert_equal(r"\12", "\n")
    test_escape

# Generated at 2022-06-11 19:37:55.233050
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\*(.\.))", "\\a")) == "\a"
    assert escape(re.match(r"\\(\*(.\.))", "\\b")) == "\b"
    assert escape(re.match(r"\\(\*(.\.))", "\\f")) == "\f"
    assert escape(re.match(r"\\(\*(.\.))", "\\n")) == "\n"
    assert escape(re.match(r"\\(\*(.\.))", "\\r")) == "\r"
    assert escape(re.match(r"\\(\*(.\.))", "\\t")) == "\t"
    assert escape(re.match(r"\\(\*(.\.))", "\\v")) == "\v"

# Generated at 2022-06-11 19:38:22.298450
# Unit test for function escape
def test_escape():
    m = re.match(r"(\\.)", r"\a")
    assert m is not None
    assert escape(m) == "a"
    assert escape(re.match(r"(\\.)", r"\b")) == "b"
    assert escape(re.match(r"(\\.)", r"\f")) == "f"
    assert escape(re.match(r"(\\.)", r"\n")) == "n"
    assert escape(re.match(r"(\\.)", r"\r")) == "r"
    assert escape(re.match(r"(\\.)", r"\t")) == "t"
    assert escape(re.match(r"(\\.)", r"\v")) == "v"

# Generated at 2022-06-11 19:38:27.629286
# Unit test for function escape
def test_escape():
    import pytest # type: ignore

    with pytest.raises(ValueError) as excinfo:
        m = re.match(r'\\[abfnrtv]', '\\a')
        escape(m)

    assert str(excinfo.value) == "invalid octal string escape ('\\a')"

# Generated at 2022-06-11 19:38:28.250940
# Unit test for function test
def test_test():
    assert test() == None

# Generated at 2022-06-11 19:38:34.416606
# Unit test for function escape

# Generated at 2022-06-11 19:38:44.415875
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\a'
    assert escape('\\b') == '\b'
    assert escape('\\f') == '\f'
    assert escape('\\n') == '\n'
    assert escape('\\r') == '\r'
    assert escape('\\t') == '\t'
    assert escape('\\v') == '\v'
    assert escape('\\\'') == '\''
    assert escape('\\"') == '"'
    assert escape('\\\\') == '\\'
    assert escape('\\x61') == 'a'
    assert escape('\\x1A') == '\x1a'
    assert escape('\\x0a') == '\n'

# Generated at 2022-06-11 19:38:51.405347
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x([0-9A-Fa-f]{2})", "\\x20")) == " "
    assert escape(re.match(r"\\x([0-9A-Fa-f]{2})", "\\x0")) == "\x00"
    assert escape(re.match(r"\\x([0-9A-Fa-f]{2})", "\\xF")) == "\x0f"
    assert escape(re.match(r"\\x([0-9A-Fa-f]{2})", "\\xA0")) == " "
    assert escape(re.match(r"\\0([0-7]{3})", "\\0377")) == "\xFF"

# Generated at 2022-06-11 19:39:03.017217
# Unit test for function test
def test_test():
    p1 = (0, b'\x00', "'\\x00'", '\x00')
    p2 = (34, b'\x22', "'\\\"'", '\x22')
    p3 = (39, b"\'", '"\'"', "'")
    p4 = (92, b'\\', "'\\\\'", '\\')
    p5 = (127, b'\x7f', "'\\x7f'", '\x7f')
    p6 = (34, b'\x22', '\'\\"\'', '\x22')
    p7 = (39, b"\'", '"\'"', "'")
    p8 = (92, b'\\', "'\\\\'", '\\')

# Generated at 2022-06-11 19:39:03.917957
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:04.709807
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:09.479270
# Unit test for function escape
def test_escape():
    escape1 = escape(re.search(r"[\"]", "\\"))
    escape2 = escape(re.search(r"[']", "\\"))
    escape3 = escape(re.search(r"[\']", "\\"))
    assert (escape1 == "\"") and (escape2 == "'") and (escape3 == "\\")

# Generated at 2022-06-11 19:39:28.005447
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:39.711808
# Unit test for function escape
def test_escape():
    assert escape(re.search(r'\\(.(?:..)?)', r"\'\063'")) == "'3'"
    assert escape(re.search(r'\\(.(?:..)?)', r"\"\063\077\"")) == '"3?'
    assert escape(re.search(r'\\(.(?:..)?)', r"\"\063\0\77\"")) == '"30?'
    assert escape(re.search(r'\\(.(?:..)?)', r"\"\063\077")) == '"3?'
    assert escape(re.search(r'\\(.(?:..)?)', r"\"\063\0\77")) == '"30?'

# Generated at 2022-06-11 19:39:46.642918
# Unit test for function escape
def test_escape():
    assert escape('\\a') == '\\a'
    assert escape('\\b') == '\\b'
    assert escape('\\f') == '\\f'
    assert escape('\\n') == '\\n'
    assert escape('\\r') == '\\r'
    assert escape('\\t') == '\\t'
    assert escape('\\v') == '\\v'
    assert escape('\\\'') == '\\\''
    assert escape('\\"') == '\\"'
    assert escape('\\\\') == '\\\\'
    assert escape('\\x22') == '\"'
    assert escape('\\123') == 'S'
    assert escape('\\x45') == 'E'

# Generated at 2022-06-11 19:39:48.283965
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:49.048633
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:53.313235
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    # Invalid octal string escape
    try:
        escape(re.match(r"\\a", "\\a"))
        assert False
    except ValueError:
        pass

# Generated at 2022-06-11 19:39:53.950320
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:39:54.543321
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:40:05.700198
# Unit test for function escape
def test_escape():
    # Test the direct escape characters from simple_escapes
    for i in 'abfnrtv\\':
        assert escape(re.match(r"\\"+i, r'\\'+i)) == i
    
    # Test escape of ascii characters using hex value
    for i in range(256): 
        assert escape(re.match( r'(\\x([0-9a-fA-F][0-9a-fA-F]))', '\\x{x:02x}'.format(x=i) )) == chr(i)
    
    # Test escape of ascii characters using octal value

# Generated at 2022-06-11 19:40:06.330923
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:40:22.669851
# Unit test for function test
def test_test():
    # Should test for Unicode
    test()



# Generated at 2022-06-11 19:40:23.179060
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:40:32.255798
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\a', r'\a')) == '\x07'
    assert escape(re.match(r'\\b', r'\b')) == '\x08'
    assert escape(re.match(r'\\f', r'\f')) == '\x0c'
    assert escape(re.match(r'\\n', r'\n')) == '\n'
    assert escape(re.match(r'\\r', r'\r')) == '\r'
    assert escape(re.match(r'\\t', r'\t')) == '\t'
    assert escape(re.match(r'\\v', r'\v')) == '\x0b'
    assert escape(re.match(r'\\\'', r"\'"))

# Generated at 2022-06-11 19:40:45.584175
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", r"\a")) == "\a"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"
    assert escape(re.match(r"\\v", r"\v")) == "\v"
    assert escape(re.match(r"\\'", r"\'")) == "'"

# Generated at 2022-06-11 19:40:46.185376
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:40:55.724745
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r'\\\"', r'\\"')) == '\\"'
    assert escape(re.match(r"\\x61", r"\x61")) == "a"
    assert escape(re.match(r"\\x6a", r"\x6a")) == "j"
    assert escape(re.match(r"\\x6A", r"\x6A")) == "j"


# Generated at 2022-06-11 19:41:06.215234
# Unit test for function escape
def test_escape():
    assert (
        escape(re.match(r"\\x\w{2}", r"\\x12"))
        == escape(re.match(r"\\x\w{2}", r"\\x34"))
        == chr(0x12)
        == chr(0x34)
    )
    assert escape(re.match(r"\\\d{3}", r"\\012")) == chr(0o12)
    assert escape(re.match(r"\\\d{3}", r"\\345")) == chr(0o345)
    assert escape(re.match(r"\\[abfnrtv]", r"\\a")) == "\a"
    assert escape(re.match(r"\\[abfnrtv]", r"\\b")) == "\b"

# Generated at 2022-06-11 19:41:15.992877
# Unit test for function escape
def test_escape():
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\'")
    assert escape(m) == "'"
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\"')
    assert escape(m) == '"'
    m = re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\\\")
    assert escape(m) == "\\"

# Generated at 2022-06-11 19:41:27.970565
# Unit test for function escape
def test_escape():
    assert(escape(re.match(r'\\a', '\\a')) == "\a")
    assert(escape(re.match(r'\\b', '\\b')) == "\b")
    assert(escape(re.match(r'\\f', '\\f')) == "\f")
    assert(escape(re.match(r'\\n', '\\n')) == "\n")
    assert(escape(re.match(r'\\r', '\\r')) == "\r")
    assert(escape(re.match(r'\\t', '\\t')) == "\t")
    assert(escape(re.match(r'\\v', '\\v')) == "\v")
    assert(escape(re.match(r"\\\'", "\\'")) == "'")

# Generated at 2022-06-11 19:41:38.481043
# Unit test for function escape
def test_escape():
    def test(s, result):
        m = re.match(r"\\(.*)", s)
        if not m:
            return
        elif (escape(m) != result):
            raise ValueError("testing '%s', expected '%s'" % (s, result))
    test('\\a', '\x07')
    test('\\b', '\x08')
    test('\\f', '\x0c')
    test('\\n', '\x0a')
    test('\\r', '\x0d')
    test('\\t', '\x09')
    test('\\v', '\x0b')
    test('\\\'', '\'')
    test('\\"', '"')
    test('\\\\', '\\')
    test('\\x42', 'B')
    test

# Generated at 2022-06-11 19:42:10.727684
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:15.862599
# Unit test for function test
def test_test():
    from six import StringIO
    import sys

    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()

        def tearDown(self):
            sys.stdout = self._stdout

        def test_test(self):
            test()
            self.assertEqual(self._stringio.getvalue(), "")

    import sys

    import test

    mod = sys.modules[__name__]
    test.test_support.run_unittest(Test, mod)

# Generated at 2022-06-11 19:42:26.906942
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})",
                           r"\n")) == "\n"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})",
                           r"\a")) == "\a"
    assert escape(re.match(r"\\('|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})",
                           r"\b")) == "\b"

# Generated at 2022-06-11 19:42:27.978110
# Unit test for function test
def test_test():
    import pytest
    with pytest.raises(SystemExit):
        test()

# Generated at 2022-06-11 19:42:39.824616
# Unit test for function escape
def test_escape():
    # Test for simple escape characters
    for key, value in simple_escapes.items():
        m = re.match(r"\\" + key, r"\a")
        assert escape(m) == value
        m = re.match(r"\\" + key, r"\b")
        assert escape(m) == value
        m = re.match(r"\\" + key, r"\f")
        assert escape(m) == value
        m = re.match(r"\\" + key, r"\n")
        assert escape(m) == value
        m = re.match(r"\\" + key, r"\r")
        assert escape(m) == value
        m = re.match(r"\\" + key, r"\t")
        assert escape(m) == value

# Generated at 2022-06-11 19:42:40.387487
# Unit test for function test
def test_test():
    test()



# Generated at 2022-06-11 19:42:50.092712
# Unit test for function escape
def test_escape():
    import os
    import unittest
    import sys

    if sys.version_info >= (3, 0):
        unichr = chr

    class EscapeTests(unittest.TestCase):

        def assertEscape(self, string, char):
            m = re.match(r"^\\(?:x[0-9a-fA-F]{2}|[0-7]{3}|[abfnrtv'\"\\])$", string)
            self.assertIsNotNone(m, "Not a valid string escape")
            self.assertEqual(escape(m), char)

        def test_escape_ascii(self):
            for i in range(0x20, 0x7f):
                if i == 0x5c:
                    continue

# Generated at 2022-06-11 19:43:00.957261
# Unit test for function escape
def test_escape():
    escapes = {"\a": "a", "\b": "b", "\f": "f", "\n": "n", "\r": "r", "\t": "t", "\v": "v", "'": "'", '"': '"', "\\": "\\"}
    for c in escapes:
        match = re.match(r"\\" + escapes[c], escape(re.match(r"\\" + escapes[c], "\\" + escapes[c])))
        assert match

    # Test the escaping of hex values
    for i in range(256):
        hi = hex(i)[2:]
        if len(hi) == 1:
            hi = "0" + hi
        match = re.match(r"\x" + hi, escape(re.match(r"\\x" + hi, "\\x" + hi)))


# Generated at 2022-06-11 19:43:11.907225
# Unit test for function escape
def test_escape():
    s = r"""\b\t\n\f\r\"\'\\"""
    e = "\b\t\n\f\r\"\'\\"
    assert re.sub(r"\\(['\"\\abfnrtv])", escape, s) == e
    assert re.sub(r"\\([abfnrtv\"\'\\])", escape, s) == e
    assert re.sub(r"\\([0-7]{1,3})", escape, "\\001\\07\\077") == "\001\07\077"

# Generated at 2022-06-11 19:43:12.978608
# Unit test for function escape
def test_escape():
    assert escape("\\'") == "'"

# Generated at 2022-06-11 19:44:24.178047
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\x5c(\x61)', r'\\a')) == "\a"
    assert escape(re.match(r'\x5c(\x62)', r'\\b')) == "\b"
    assert escape(re.match(r'\x5c(\x66)', r'\\f')) == "\f"
    assert escape(re.match(r'\x5c(\x6e)', r'\\n')) == "\n"
    assert escape(re.match(r'\x5c(\x72)', r'\\r')) == "\r"
    assert escape(re.match(r'\x5c(\x74)', r'\\t')) == "\t"

# Generated at 2022-06-11 19:44:26.083229
# Unit test for function test
def test_test():
    t = test
    t()

# Generated at 2022-06-11 19:44:26.695610
# Unit test for function test
def test_test():
    print(None)

# Generated at 2022-06-11 19:44:35.072598
# Unit test for function escape
def test_escape():
    assert escape(r"\x00") == "\x00"
    assert escape(r"\x01") == "\x01"
    assert escape(r"\x02") == "\x02"
    assert escape(r"\x03") == "\x03"
    assert escape(r"\x04") == "\x04"
    assert escape(r"\x05") == "\x05"
    assert escape(r"\x06") == "\x06"
    assert escape(r"\x07") == "\x07"
    assert escape(r"\x08") == "\x08"
    assert escape(r"\x0A") == "\x0A"
    assert escape(r"\x0B") == "\x0B"
    assert escape(r"\x0C") == "\x0C"
   