

# Generated at 2022-06-11 19:35:05.030679
# Unit test for function escape
def test_escape():
    import unittest

    class TestEscape(unittest.TestCase):
        def test_b(self):
            self.assertEqual(escape(re.match("\\\\b", "\\b")), "\b")

        def test_B(self):
            with self.assertRaises(Exception):
                escape(re.match("\\\\[B-Z]", "\\M"))

        def test_slash(self):
            self.assertEqual(escape(re.match("\\\\", "\\")), "\\")

        def test_a(self):
            self.assertEqual(escape(re.match("\\\\a", "\\a")), "\a")


# Generated at 2022-06-11 19:35:14.547748
# Unit test for function escape
def test_escape():

    if escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\a")) != "\a":
        return "Failed"
    if escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\b")) != "\b":
        return "Failed"
    if escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", "\\f")) != "\f":
        return "Failed"

# Generated at 2022-06-11 19:35:19.123249
# Unit test for function escape
def test_escape():
    assert escape(re.match(".*$", "Hello\\n")) == "n"
    # assert escape(re.match(".*$", "Hello\\x00")) == "\x00"
    assert escape(re.match(".*$", "Hello\\a")) == "\a"

# Generated at 2022-06-11 19:35:27.830774
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\x41', '\\x41')) == 'A'
    assert escape(re.match(r'\\x41', '\\x41')) == 'A'
    assert escape(re.match(r'\\x4', '\\x4')) == '4'
    assert escape(re.match(r'\\a', '\\a')) == '\x07'
    assert escape(re.match(r'\\b', '\\b')) == '\x08'

# Generated at 2022-06-11 19:35:33.357238
# Unit test for function escape
def test_escape():
    s = r"\'f\x00oo\077bar\\baz'"
    result = r"'f\x00oo?bar\baz'"
    assert escape(s) == result
    assert evalString(s) == result
    s = r'"\n\"\\\'"'
    result = r'\n"\\\''
    assert escape(s) == result
    assert evalString(s) == result

# Generated at 2022-06-11 19:35:41.545653
# Unit test for function escape

# Generated at 2022-06-11 19:35:48.111296
# Unit test for function escape
def test_escape():
    # Test for single byte characters
    for i in range(256):
        # Get the single byte character
        c = chr(i)
        # Create the input string
        s = "\\" + c
        # Create the expected output string
        e = evalString(s)
        # Test the function
        assert escape(s) == e
    # Test for multi-byte characters
    for i in range(256):
        # Get the multi-byte character
        c = chr(i)
        # Create the input string
        s = "\\x" + str(hex(i))
        # Create the expected output string
        e = evalString(s)
        # Test the function
        assert escape(s) == e


# Generated at 2022-06-11 19:35:58.089073
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(.)", r"\a")) == "\a"
    assert escape(re.match(r"\\(.)", r"\b")) == "\b"
    assert escape(re.match(r"\\(.)", r"\f")) == "\f"
    assert escape(re.match(r"\\(.)", r"\n")) == "\n"
    assert escape(re.match(r"\\(.)", r"\r")) == "\r"
    assert escape(re.match(r"\\(.)", r"\t")) == "\t"
    assert escape(re.match(r"\\(.)", r"\v")) == "\v"
    assert escape(re.match(r"\\(.)", r"\'")) == "'"

# Generated at 2022-06-11 19:36:00.789559
# Unit test for function escape
def test_escape():
    """
    >>> escape(re.match('\\\\(x.{0,2})', '\\x45'))
    'E'
    """

# Generated at 2022-06-11 19:36:01.330025
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:36:43.627200
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\n')) == '\n'
    assert escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\x10')) == '\x10'
    assert escape(re.match(r'\\([\'\"\\abfnrtv]|x.{0,2}|[0-7]{1,3})', '\\155')) == 'M'

# Generated at 2022-06-11 19:36:47.406535
# Unit test for function escape
def test_escape():
    assert escape("\\n").value == "\n"
    assert escape("\\xA9").value == "\xA9"
    assert escape("\\317").value == "\317"

# Generated at 2022-06-11 19:36:56.085281
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\x7e", r"\x7e")) == "~"
    assert escape(re.match(r"\\x7", r"\x7")) == "\\x7"
    assert escape(re.match(r"\\073", r"\073")) == ";"
    assert escape(re.match(r"\\07", r"\07")) == "\\07"
    assert escape(re.match(r"\\0", r"\0")) == "\x00"
    assert escape(re.match(r"\\x", r"\x")) == "\\x"

# Generated at 2022-06-11 19:37:07.289007
# Unit test for function escape
def test_escape():
    _test_escape('\\a', '\a')
    _test_escape('\\b', '\b')
    _test_escape('\\f', '\f')
    _test_escape('\\n', '\n')
    _test_escape('\\r', '\r')
    _test_escape('\\t', '\t')
    _test_escape('\\v', '\v')
    _test_escape('\\\'', '\'')
    _test_escape('\\"', '"')
    _test_escape('\\\\', '\\')
    _test_escape('\\x00', '\x00')
    _test_escape('\\xFF', '\xFF')
    _test_escape('\\377', '\377')
    _test_escape('\\000', '\000')
    _

# Generated at 2022-06-11 19:37:18.804719
# Unit test for function escape
def test_escape():
    from pytest import raises
    from . import _static_escape
    assert _static_escape.escape(re.match(r"\\['\"\\abfnrtv]", "\\\'")) == "\'"
    assert _static_escape.escape(re.match(r"\\x...|\\\d{1,3}", "\\x01")) == "\x01"
    assert _static_escape.escape(re.match(r"\\x...|\\\d{1,3}", "\\000")) == "\x00"
    assert _static_escape.escape(re.match(r"\\x...|\\\d{1,3}", "\\123")) == "\x1b"

# Generated at 2022-06-11 19:37:22.239722
# Unit test for function escape
def test_escape():
    re_group = re.compile(r"\\(?P<tail>.)")
    tail = re_group.match("\\\xe0").groupdict()["tail"]
    assert tail == "\xe0"

# Generated at 2022-06-11 19:37:28.910073
# Unit test for function escape
def test_escape():
    assert escape(r"\U0010FFFF")
    assert escape(r"\U0010fffF")

    # \U is not a valid escape
    try:
        escape(r"\U00")
    except ValueError:
        pass
    else:
        print("ValueError not raised")

    # \U followed by too many digits
    try:
        escape(r"\U1234567")
    except ValueError:
        pass
    else:
        print("ValueError not raised")

if __name__ == "__main__":
    test_escape()

# Generated at 2022-06-11 19:37:40.070157
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\'", r"\\'")) == "'"
    assert escape(re.match(r"\\", r"\\")) == "\\"
    assert escape(re.match(r"\\x1", r"\\x1")) == "\x01"
    try:
        escape(re.match(r"\\x", r"\\x"))
    except ValueError as e:
        assert str(e) == "invalid hex string escape ('\\x')"
    try:
        escape(re.match(r"\\x0", r"\\x0"))
    except ValueError as e:
        assert str(e) == "invalid hex string escape ('\\x0')"

# Generated at 2022-06-11 19:37:40.723285
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:37:52.411465
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\a", "\\a")) == "\a"
    assert escape(re.match(r"\\b", "\\b")) == "\b"
    assert escape(re.match(r"\\f", "\\f")) == "\f"
    assert escape(re.match(r"\\n", "\\n")) == "\n"
    assert escape(re.match(r"\\r", "\\r")) == "\r"
    assert escape(re.match(r"\\t", "\\t")) == "\t"
    assert escape(re.match(r"\\v", "\\v")) == "\v"
    assert escape(re.match(r"\\'", "\\'")) == "'"
    assert escape(re.match(r'\\"', '\\"')) == '"'
    assert escape

# Generated at 2022-06-11 19:38:46.630586
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\"', r'\"')) == '\"'
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\a', r'\a')) == '\a'
    assert escape(re.match(r'\\b', r'\b')) == '\b'
    assert escape(re.match(r'\\f', r'\f')) == '\f'
    assert escape(re.match(r'\\n', r'\n')) == '\n'
    assert escape(re.match(r'\\r', r'\r')) == '\r'
    assert escape(re.match(r'\\t', r'\t')) == '\t'

# Generated at 2022-06-11 19:38:48.362710
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert 0, 'test() failed'

# Generated at 2022-06-11 19:39:00.425546
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(')", r"\\'")) == "'"
    assert escape(re.match(r'\\(")', r'\\"')) == '"'
    assert escape(re.match(r"\\(\\)", r"\\\\")) == "\\"
    # "other" escapes
    assert escape(re.match(r"\\(a)", r"\\a")) == "\a"
    assert escape(re.match(r"\\(b)", r"\\b")) == "\b"
    assert escape(re.match(r"\\(f)", r"\\f")) == "\f"
    assert escape(re.match(r"\\(n)", r"\\n")) == "\n"
    assert escape(re.match(r"\\(r)", r"\\r")) == "\r"

# Generated at 2022-06-11 19:39:07.824170
# Unit test for function escape
def test_escape():
    # General tests
    assert escape(re.match(r"\\'", r"\'")) == "'"
    assert escape(re.match(r'\\"', r'\"')) == '"'
    assert escape(re.match(r"\\\\", r"\\")) == "\\"
    assert escape(re.match(r"\\b", r"\b")) == "\b"
    assert escape(re.match(r"\\f", r"\f")) == "\f"
    assert escape(re.match(r"\\n", r"\n")) == "\n"
    assert escape(re.match(r"\\r", r"\r")) == "\r"
    assert escape(re.match(r"\\t", r"\t")) == "\t"

# Generated at 2022-06-11 19:39:09.322474
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"


# Generated at 2022-06-11 19:39:20.646647
# Unit test for function escape
def test_escape():
    assert escape(r'\r') == '\r'
    assert escape(r'\x41') == 'A'
    assert escape(r'\065') == 'A'

    try:
        escape(r'\06541')
    except ValueError:
        pass
    else:
        assert False, "Did not raise ValueError"

    try:
        escape(r'\65')
    except ValueError:
        pass
    else:
        assert False, "Did not raise ValueError"

    try:
        escape(r'\6541')
    except ValueError:
        pass
    else:
        assert False, "Did not raise ValueError"

    try:
        escape(r'\0x41')
    except ValueError:
        pass

# Generated at 2022-06-11 19:39:30.143574
# Unit test for function escape
def test_escape():
    import unittest

    class TestEscapeFunction(unittest.TestCase):
        def stringEscape(self, s: Text) -> Text:
            m = re.match(r"\\(.|$)", s)
            return escape(m)

        def test_simple(self) -> None:
            self.assertEqual(self.stringEscape("\\a"), "\a")
            self.assertEqual(self.stringEscape("\\b"), "\b")
            self.assertEqual(self.stringEscape("\\f"), "\f")
            self.assertEqual(self.stringEscape("\\n"), "\n")
            self.assertEqual(self.stringEscape("\\r"), "\r")
            self.assertEqual(self.stringEscape("\\t"), "\t")
            self.assertE

# Generated at 2022-06-11 19:39:42.043553
# Unit test for function escape
def test_escape():
    # Test single character escapes (a, b, f, n, r, t, v)
    m = re.search(r"^\\([abfnrtv])$", "\\a")
    assert escape(m) == "\a"

    m = re.search(r"^\\([abfnrtv])$", "\\b")
    assert escape(m) == "\b"

    m = re.search(r"^\\([abfnrtv])$", "\\f")
    assert escape(m) == "\f"

    m = re.search(r"^\\([abfnrtv])$", "\\n")
    assert escape(m) == "\n"

    m = re.search(r"^\\([abfnrtv])$", "\\r")
    assert escape(m) == "\r"

    m

# Generated at 2022-06-11 19:39:49.158739
# Unit test for function escape
def test_escape():
    assert "\\x" == escape(re.match(r"\\(x)", "\\x"))
    assert "\\'" == escape(re.match(r"\\(x)", "\\'"))
    assert "\\'" == escape(re.match(r"\\(x)", "\\'"))
    assert "\\'" == escape(re.match(r"\\(')", "\\'"))
    assert "\'" == escape(re.match(r"\\(')", "\\'"))

    assert "\\n" == escape(re.match(r"\\(x)", "\\n"))
    assert "\n" == escape(re.match(r"\\(x)", "\\n"))

# Generated at 2022-06-11 19:39:59.371773
# Unit test for function escape
def test_escape():
    assert escape('\\\'') == '\\\''
    assert escape(r'\\\'') == r'\\\''
    assert escape('\\\'') == '\\\''
    assert escape(r'\\\'') == r'\\\''
    assert escape('\\\'') == '\\\''
    assert escape(r'\\\'') == r'\\\''
    assert escape('\\\'') == '\\\''
    assert escape(r'\\\'') == r'\\\''
    assert escape('\\\'') == '\\\''
    assert escape(r'\\\'') == r'\\\''
    assert escape('\\\'') == '\\\''
    assert escape(r'\\\'') == r'\\\''
    assert escape('\\\'') == '\\\''

# Generated at 2022-06-11 19:40:24.888335
# Unit test for function escape
def test_escape():
    assert escape("\\a") == "\a"
    assert escape("\\b") == "\b"
    assert escape("\\f") == "\f"
    assert escape("\\n") == "\n"
    assert escape("\\r") == "\r"
    assert escape("\\t") == "\t"
    assert escape("\\v") == "\v"
    assert escape("\\'") == "'"
    assert escape('\\"') == '"'
    assert escape("\\\\") == "\\"

    assert escape("\\x00") == "\x00"
    assert escape("\\xff") == "\xff"
    assert escape("\\x00") == "\x00"
    assert escape("\\x001") == "\x00"
    assert escape("\\xabcd") == "\xab"

# Generated at 2022-06-11 19:40:29.893237
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\[0-7]{1,3}', '\\000')) == "\0"
    assert escape(re.match(r'\\x.{0,2}', '\\x00')) == "\0"
    assert escape(re.match(r'\\[abfnrtv]', '\\x')) == "x"


# Generated at 2022-06-11 19:40:31.745045
# Unit test for function test
def test_test():
    # Test every valid character
    for i in range(256):
        c = chr(i)
        s = repr(c)
        e = evalString(s)
        assert e == c

# Generated at 2022-06-11 19:40:38.353526
# Unit test for function escape
def test_escape():
    def t(pat, repl_pat, s, expected):
        m = re.match(pat, s)
        assert m is not None
        repl = escape(m)
        assert repl == expected
        assert re.sub(repl_pat, escape, s) == expected

    t(r"\\a", r"\\a", r"\a", "\a")

# Generated at 2022-06-11 19:40:49.158319
# Unit test for function escape
def test_escape():
    from operator import itemgetter
    from string import hexdigits, octdigits

    test_pairs = [
        ("\\'", "'"),
        ('\\"', '"'),
        ("\\a", "\a"),
        ("\\b", "\b"),
        ("\\f", "\f"),
        ("\\n", "\n"),
        ("\\r", "\r"),
        ("\\t", "\t"),
        ("\\v", "\v"),
        ("\\\\", "\\"),
        ("\\x00", "\x00"),
        ("\\xff", "\xFF"),
        ("\\377", "\xFF"),
        ("\\0", "\0"),
        ("\\17", "\x0f"),
        ("\\", "\\"),
    ]

# Generated at 2022-06-11 19:40:54.478267
# Unit test for function escape
def test_escape():
    globals()["escape"]('\\a') == '\a'
    globals()["escape"]('\\b') == '\b'
    globals()["escape"]('\\f') == '\f'
    globals()["escape"]('\\n') == '\n'
    globals()["escape"]('\\r') == '\r'
    globals()["escape"]('\\t') == '\t'
    globals()["escape"]('\\v') == '\v'
    globals()["escape"]('\\\'') == '\''
    globals()["escape"]('\\"') == '"'
    globals()["escape"]('\\\\') == '\\'

# Generated at 2022-06-11 19:41:00.385373
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\['\"\\]", "\\'")) == "'"
    assert escape(re.match(r"\\[abfnrtv]", "\\a")) == "\a"
    assert escape(re.match(r"\\x.{0,2}", "\\x20")) == " "
    assert escape(re.match(r"\\[0-7]{1,3}", "\\100")) == "\u0040"

# Generated at 2022-06-11 19:41:09.293611
# Unit test for function escape
def test_escape():
    import sys
    import traceback
    import unittest

    class Test(unittest.TestCase):
        def test_functions(self):
            with self.assertRaises(ValueError) as e:
                escape(re.match(r"\\x(.{0,1})", "\\x1"))
            self.assertRegex(str(e.exception), "invalid hex")
            with self.assertRaises(ValueError) as e:
                escape(re.match(r"\\(.{0,1})", "\\1"))
            self.assertRegex(str(e.exception), "invalid octal")


# Generated at 2022-06-11 19:41:12.893687
# Unit test for function test
def test_test():
    from snakes.tests import test
    from snakes.lang import snakelet
    from snakes.lang import snakelet_annotations
    import pdb
    test(globals(), verbose=True)

# Generated at 2022-06-11 19:41:24.720711
# Unit test for function escape
def test_escape():
    import unittest
    import unittest.mock
    from string import ascii_letters, digits
    import random

    # Test escaped characters, with and without 'escape' function
    r = r"\\"
    e = '\\'
    assert escape(unittest.mock.Mock(group=(r,))).encode() == e.encode()
    assert eval(r) == e
    for c in ["'", '"', 'b', 'n', 'f', 'r', 't', 'v']:
        r = r'\\' + c
        e = simple_escapes.get(c)
        assert escape(unittest.mock.Mock(group=(r,))).encode() == e.encode()
        assert eval(r) == e

    # Test ASCII characters using octal

# Generated at 2022-06-11 19:42:03.729430
# Unit test for function escape
def test_escape():
    assert escape(re.match(r'\\a', '\\ab')) == '\a'
    assert escape(re.match(r'\\b', '\\bc')) == '\b'
    assert escape(re.match(r'\\f', '\\fg')) == '\f'
    assert escape(re.match(r'\\n', '\\ng')) == '\n'
    assert escape(re.match(r'\\r', '\\rg')) == '\r'
    assert escape(re.match(r'\\t', '\\tg')) == '\t'
    assert escape(re.match(r'\\v', '\\vg')) == '\v'
    assert escape(re.match(r'\\\'', "\\'g")) == "'"

# Generated at 2022-06-11 19:42:04.357662
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:13.663464
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\a")) == "\a"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\b")) == "\b"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\f")) == "\f"
    assert escape(re.match(r"\\([abfnrtv]|x.{0,2}|[0-7]{1,3})", r"\n")) == "\n"

# Generated at 2022-06-11 19:42:15.918897
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\x(..)", "\xab")) == chr(0xab)


# Generated at 2022-06-11 19:42:26.986235
# Unit test for function escape
def test_escape():
    r"""Test the escape function.
    
    All escape sequence are tested, except for octal escape using the \000 form,
    which is not implemented in the escape function.
    """
    import re
    from textwrap import dedent
    from pprint import pprint
    
    # Test strings are the same as the ones used in the re module
    # doc, except that we only test octal escapes up to \237.

# Generated at 2022-06-11 19:42:38.442611
# Unit test for function escape
def test_escape():
    # Test valid escape sequence.
    assert escape(re.search('\\\a', r'\a')) == simple_escapes['a']
    assert escape(re.search('\\\b', r'\b')) == simple_escapes['b']
    assert escape(re.search('\\\f', r'\f')) == simple_escapes['f']
    assert escape(re.search('\\\n', r'\n')) == simple_escapes['n']
    assert escape(re.search('\\\r', r'\r')) == simple_escapes['r']
    assert escape(re.search('\\\t', r'\t')) == simple_escapes['t']
    assert escape(re.search('\\\v', r'\v')) == simple_escapes['v']

# Generated at 2022-06-11 19:42:39.170993
# Unit test for function test
def test_test():
    assert test() is None

# Generated at 2022-06-11 19:42:39.783955
# Unit test for function test
def test_test():
  pass

# Generated at 2022-06-11 19:42:40.343362
# Unit test for function test
def test_test():
    test()

# Generated at 2022-06-11 19:42:50.057863
# Unit test for function escape
def test_escape():
    def _test(s, expected):
        if escape(re.match(r"\\.?", s)) != expected:
            assert False, repr((s, expected))

    _test(r"\a", "\a")
    _test(r"\b", "\b")
    _test(r"\f", "\f")
    _test(r"\n", "\n")
    _test(r"\r", "\r")
    _test(r"\t", "\t")
    _test(r"\v", "\v")
    _test(r"\'", "\'")
    _test(r'\"', '\"')
    _test(r"\\", "\\")
    _test(r"\x31", "1")
    _test(r"\x31;", "1")
    _test

# Generated at 2022-06-11 19:43:40.554422
# Unit test for function escape
def test_escape():
    assert escape('\\b') == '\b'
    assert escape('\\x41') == 'A'
    #assert escape('\\x001') == '\x01'  # Depends on CPython/Jython implementation
    assert escape('\\x061') == 'a'
    assert escape('\\077') == '?'
    assert escape('\\377') == '\xff'
    assert escape('\\\"') == '\"'
    assert escape('\\\\') == '\\'
    try:
        escape('\\x1z')
    except ValueError:
        pass
    else:
        assert False, 'Should raise ValueError'
    try:
        escape('\\x')
    except ValueError:
        pass
    else:
        assert False, 'Should raise ValueError'

# Generated at 2022-06-11 19:43:41.992914
# Unit test for function test
def test_test():
    test()

# vim: tabstop=4 expandtab shiftwidth=4

# Generated at 2022-06-11 19:43:43.444695
# Unit test for function test
def test_test():
    try:
        test()
    except:
        assert False, "test unsuccessful"

# Generated at 2022-06-11 19:43:50.774357
# Unit test for function escape

# Generated at 2022-06-11 19:43:59.125568
# Unit test for function escape
def test_escape():
    for s in sorted(simple_escapes):
        m = re.match(r"\\" + s, "\\" + s)
        # print(s, m.group(1))
        e = escape(m)
        # print(s, e, repr(e))
        assert e == simple_escapes[s]

    for s in ["\\\"", "\\'", "\\\\"]:
        m = re.match(r"(\\.)", s)
        # print(s, m.group(1))
        e = escape(m)
        # print(s, e, repr(e))
        assert e == s[1:]


# Generated at 2022-06-11 19:44:08.973662
# Unit test for function escape
def test_escape():
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\\'')) == "'"
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\"')) == '"'
    assert escape(re.match(r"\\(\'|\"|\\|[abfnrtv]|x.{0,2}|[0-7]{1,3})", '\\\\')) == "\\"

# Generated at 2022-06-11 19:44:10.407518
# Unit test for function test
def test_test():
    test()
    assert True

# Generated at 2022-06-11 19:44:20.633853
# Unit test for function escape
def test_escape():
    tests = [
        ('\\a', '\a'),
        ('\\b', '\b'),
        ('\\f', '\f'),
        ('\\n', '\n'),
        ('\\r', '\r'),
        ('\\t', '\t'),
        ('\\v', '\v'),
        ('\\\'', '\''),
        ('\\"', '\"'),
        ('\\\\', '\\'),
        ('\\x20', ' '),
        ('\\x7e', '~'),
        ('\\120', ' '),
        ('\\076', '~'),
    ]

    for (s, e) in tests:
        assert escape(re.match(r'\\.|$', s)) == e

# Generated at 2022-06-11 19:44:32.842854
# Unit test for function escape
def test_escape():
    escaped = escape(re.match(r"\\(.+)", "\\x12"))
    assert escaped == "\\x12", escaped

    escaped = escape(re.match(r"\\(.+)", "\\x1"))
    assert escaped == "\\x1", escaped

    try:
        escaped = escape(re.match(r"\\(.+)", "\\x1x"))
        assert escaped == "\\x1x", escaped
        assert False, "expected ValueError"
    except ValueError as e:
        pass

    escaped = escape(re.match(r"\\(.+)", "\\x111"))
    assert escaped == "\\x111", escaped

    escaped = escape(re.match(r"\\(.+)", "\\x22"))
    assert escaped == "\\x22", escaped


# Generated at 2022-06-11 19:44:38.853857
# Unit test for function escape
def test_escape():
    assert (escape(re.match(r'\\(x.{0,2})', r'\x12')) == '\x12')
    assert (escape(re.match(r'\\(x.{0,2})', r'\xA')) == '\n')
    assert (escape(re.match(r'\\(x.{0,2})', r'\x1')) == '\x01')
    assert (escape(re.match(r'\\(\d{1,3})', r'\0')) == '\x00')
    assert (escape(re.match(r'\\(\d{1,3})', r'\7')) == '\x07')