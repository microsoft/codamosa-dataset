

# Generated at 2022-06-11 22:25:40.371451
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    for attr in ('get', 'keys', 'items', 'values', 'foo'):
        result = has_any_callables(obj, attr)
        if (attr != 'foo') and result:
            print("Wrong result when checking {0!r} in {1!r}".format(
                attr, obj))
        elif (attr == 'foo') and not result:
            print("Wrong result when checking {0!r} in {1!r}".format(
                attr, obj))


# Generated at 2022-06-11 22:25:51.327584
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(None, '__bool__')
    assert has_attrs(None, '__bool__', '__str__')
    assert not has_attrs(None, '__bool__', '__str__', '__repr__')
    assert has_attrs('test', '__len__', '__add__')
    assert has_attrs('test', *'__len__ __add__'.split())
    assert not has_attrs(dict(), 'foo', 'bar')

    class MyClass:
        pass

    my_obj = MyClass()
    assert has_attrs(my_obj, '__class__')
    assert has_attrs(my_obj, '__class__', '__module__')



# Generated at 2022-06-11 22:25:58.013936
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import (
        has_any_attrs
    )
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, "get", "blah") == True
    assert has_any_attrs(obj, "blah") == False
    assert has_any_attrs(obj, "get", "keys", "blah") == True
    assert has_any_attrs(obj, "keys", "blah") == True


# Generated at 2022-06-11 22:26:01.023747
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    obj['hasattr'] = 0
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'hasattr')



# Generated at 2022-06-11 22:26:03.392903
# Unit test for function has_any_callables
def test_has_any_callables():
    # TODO: There should be a more straightforward way to test this.
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:26:07.303694
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class Foo:
        pass

    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(Foo(),'get','keys','items','values','something') == False



# Generated at 2022-06-11 22:26:16.130306
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(list, 'append', 'extend', 'insert', 'remove') is True
    assert has_callables(list, 'append', 'extend', 'insert', 'remove', 'foo') is False
    assert has_callables(str, 'upper', 'lower', 'capitalize') is True
    assert has_callables(str, 'upper', 'lower', 'capitalize', 'foo') is False


# Generated at 2022-06-11 22:26:26.734655
# Unit test for function has_any_callables
def test_has_any_callables():
    # testing with a dict
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo', 'baz')
    # testing with a function
    def add(x, y):
        return x+y
    assert has_any_callables(add, '__call__', 'baz')
    assert not has_any_callables(add, '__call__', 'baz', 'bar')
    # testing with a class
    x = 'this is a test'
    assert has_any_callables(x, 'startswith', 'endswith', 'foo')
    assert not has_

# Generated at 2022-06-11 22:26:35.705434
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'keys', 'values') is True
    assert has_any_callables({}, 'keys', 'foo') is True
    assert has_any_callables({}, 'foo', 'bar') is False
    assert has_any_callables('foo', 'bar', 'baz') is False
    assert has_any_callables('foo', 'upper', 'isupper') is True
    assert has_any_callables(1, 'upper', 'isupper') is False
    assert has_any_callables([1, 2, 3], 'upper', 'isupper') is False
    assert has_any_callables(lambda x: x, 'upper', 'isupper') is True
    assert has_any_callables(lambda x: x, 'upper', 'isupper', 'foo') is True
    assert has

# Generated at 2022-06-11 22:26:41.252924
# Unit test for function has_any_attrs
def test_has_any_attrs():
    test_obj = {0: 'value'}
    test_attrs = ('values', 'keys', 'items', 'foo')
    result = has_any_attrs(test_obj, *test_attrs)
    assert result == True


# Generated at 2022-06-11 22:26:45.355615
# Unit test for function has_callables
def test_has_callables():
    print('Testing has_callables')
    assert has_callables(dict(), 'get', 'keys') == True


# Generated at 2022-06-11 22:26:47.629281
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1,b=2)
    assert has_any_callables(obj,'get','keys','foo') is True

# Generated at 2022-06-11 22:26:49.889928
# Unit test for function has_attrs
def test_has_attrs():
    d = dict()
    assert has_attrs(d, 'keys', 'items', 'values')


# Generated at 2022-06-11 22:26:59.820434
# Unit test for function has_attrs
def test_has_attrs():
    print('Testing has_attrs')
    dmap = dict(a=1, b=2)
    assert has_attrs(obj=dmap, attr1='a', attr2='b')
    assert has_attrs(obj=dmap, attr1='a', attr2='b', attr3='c') is False
    assert has_attrs(obj=dmap, attr1='a', attr2='b', attr3='c', attr4='d') \
        is False
    print('Done testing has_attrs')



# Generated at 2022-06-11 22:27:02.371595
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj,'get','keys','items','values','bar')



# Generated at 2022-06-11 22:27:13.435674
# Unit test for function has_callables
def test_has_callables():
    # Tests for has_callables
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','foo') == False
    # Tests for has_any_callables
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items','foo') == True
    assert has_any_callables(dict(),'foo','bar') == False
    # Tests for has_attrs
    assert has_attrs(dict(),'get','keys','items','values') == True
    assert has_attrs(dict(),'get','keys','items','foo') == False
    # Tests for has_any_attrs

# Generated at 2022-06-11 22:27:15.741628
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:27:19.385250
# Unit test for function has_any_callables
def test_has_any_callables():
    '''
    >>> from flutils.objutils import has_any_callables
    >>> has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    True
    '''


# Generated at 2022-06-11 22:27:22.366313
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj,'get','keys','items','values') == True


# Generated at 2022-06-11 22:27:24.963057
# Unit test for function has_any_callables
def test_has_any_callables():
    o = dict()
    assert has_any_callables(o, 'get') is True



# Generated at 2022-06-11 22:27:33.188231
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import (
        UserDict,
        UserList,
        UserString,
    )
    from collections.abc import (
        Collection,
        Mapping,
        MutableMapping,
        MutableSequence,
        MutableSet,
    )

    # Check objects from Python standard library
    assert has_callables(dict(), 'keys', 'values', 'items') is True
    assert has_callables(dict(), 'keys', 'values', 'items', 'foo') is False
    assert has_callables(list(), 'append', 'extend', 'insert') is True
    assert has_callables(list(), 'append', 'extend', 'insert', 'foo') is False
    assert has_callables(set(), 'add', 'clear', 'pop') is True

# Generated at 2022-06-11 22:27:35.055680
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=1, c=1)
    assert has_any_callables(obj,'get','keys','items','values','foo')



# Generated at 2022-06-11 22:27:38.443021
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something') is True
    assert has_any_callables(dict(),'get','keys','items','values','__dict__') is True
    assert has_any_callables(dict(),'foo','bar','baz') is False
    assert has_any_callables(None,'foo','bar','baz') is False


# Generated at 2022-06-11 22:27:42.904921
# Unit test for function has_callables

# Generated at 2022-06-11 22:27:51.300722
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values') is True
    assert has_any_callables({'foo':'bar'},'get','keys','items','values') is True
    assert has_any_callables(dict(),'get','keys','items') is True
    assert has_any_callables(dict(),'keys','items','values') is True
    assert has_any_callables(dict(),'get','foo','bar') is False
    assert has_any_callables(dict(),'foo','bar') is False
    assert has_any_callables(dict(),'foo') is False


# Generated at 2022-06-11 22:27:56.861696
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    from typing import Dict
    from pprint import pprint
    from flutils.objutils import has_any_callables

    dd: Dict[str, Dict[str, str]] = defaultdict(dict)

    pprint(dd.items())

    assert has_any_callables(dd.items(), 'insert', 'extend', 'append') is False



# Generated at 2022-06-11 22:28:04.169233
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(list(), 'get', 'keys', 'items', 'values', 'foo') is False
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj.keys(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj.values(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj.values(), 'get', 'keys', 'items', 'values', 'foo', 'pop') is False

# Generated at 2022-06-11 22:28:16.277083
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values','foo'))
    assert(has_any_callables(dict(a=1,b=2,c=3),'get','keys','items','values','foo'))
    assert(has_any_callables([1,2,3,4,5,6,7,8,9,0],'count','index','copy','reverse','sort'))
    assert(has_any_callables(set(),'add','remove','copy','intersection','union','difference','update','pop','clear','difference'))
    assert(has_any_callables(frozenset(),'copy','intersection','union','difference','update','pop','clear','difference'))

# Generated at 2022-06-11 22:28:18.356382
# Unit test for function has_any_callables
def test_has_any_callables():
    input = 'dummy_input'
    assert has_any_callables(input, 'bar', 'len') == False


# Generated at 2022-06-11 22:28:22.300026
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__init__') == True



# Generated at 2022-06-11 22:28:30.153422
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(set(), 'discard', 'remove') == True
    assert has_any_callables(None, 'discard', 'remove') == False



# Generated at 2022-06-11 22:28:39.488824
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(
        dict(), 'get', 'keys', 'items', 'values', 'foo'
    )
    assert has_any_callables(dict(), '__getitem__', '__len__') is True
    assert has_any_callables(dict(), '__getitem__', '__len__', '__iter__') is False
    assert has_any_callables(dict(), '__delete__', '__len__', '__iter__') is False


# Generated at 2022-06-11 22:28:42.586589
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'))
    assert(not has_any_callables(dict(), 'foo'))


# Generated at 2022-06-11 22:28:48.796627
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections.abc import Iterator
    from collections import deque
    from collections import UserList

    assert has_any_callables(dict(), 'get', 'keys',
                             'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys',
                             'items', 'values', 'foo') == True
    assert has_any_callables(tuple(), '__eq__', '__ne__', '__ge__', 'index') == True
    assert has_any_callables(frozenset(), '__eq__', '__ne__',
                             '__le__', '__ge__', '__getitem__') == True
    assert has_any_callables(set(), '__eq__', '__ne__', '__le__', '__ge__') == True

# Generated at 2022-06-11 22:28:54.692804
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'items', 'values', 'pop') == True
    assert has_callables(dict(), 'get', 'notexist') == False
    assert has_callables(dict(), 'notexist') == False


# Generated at 2022-06-11 22:28:59.217205
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = {'a': 5, 'b': 6}
    a = has_any_callables(obj, 'keys', 'values')
    assert a is True



# Generated at 2022-06-11 22:29:07.034189
# Unit test for function has_attrs
def test_has_attrs():
    """Test for function :func:`has_attrs <flutils.objutils.has_attrs>`."""
    funcs = {
        'has_attrs': has_attrs,
        'has_callables': has_callables,
        'has_any_attrs': has_any_attrs,
        'has_any_callables': has_any_callables,
    }
    obj = {
        'get': lambda: 'get',
        'keys': lambda: 'keys',
        'items': lambda: 'items',
        'values': lambda: 'values',
    }
    attrs = ('get', 'keys', 'items', 'values')

# Generated at 2022-06-11 22:29:11.109892
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-11 22:29:14.263736
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','foo') == True
    assert has_any_callables(dict(),'foo') == False


# Generated at 2022-06-11 22:29:15.812606
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:29:42.649277
# Unit test for function has_callables
def test_has_callables():
    """Tests the is_list_like function."""

    a = dict(a=1, b=2)
    assert has_callables(a, 'get', 'keys', 'items', 'values') == True
    assert has_callables(a, 'get', 'keys', 'items', 'values', 'foo') == False
    assert has_callables(a, 'get', 'keys', 'items') == True
    assert has_callables(a, 'get', 'keys') == True
    assert has_callables(a, 'get') == True
    assert has_callables(a, 'foo') == False
    assert has_callables(a, '') == False
    assert has_callables(a, '', '') == False
    assert has_callables(a, '') == False

# Generated at 2022-06-11 22:29:44.250375
# Unit test for function has_callables
def test_has_callables():
    actual_result = has_callables(dict(),'get','keys','items','values')
    assert actual_result == True, f"Dict with callables: {actual_result}"


# Generated at 2022-06-11 22:29:48.041423
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    from flutils.objutils import has_callables
    assert has_callables(dict, 'get', 'keys', 'items') is True



# Generated at 2022-06-11 22:29:53.161960
# Unit test for function has_attrs
def test_has_attrs():
    class A:
        def __init__(self):
            self.x = 1
            self.y = 2
            self.z = 3
    obj = A()
    assert(has_attrs(obj,'x','y','z') is True)


# Generated at 2022-06-11 22:29:57.163526
# Unit test for function has_callables
def test_has_callables():
    # positive
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    # negative
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-11 22:30:06.693012
# Unit test for function has_callables
def test_has_callables():
    from decimal import Decimal
    cls = Decimal

    for attr in ('as_tuple', 'compare', 'compare_signal', 'copy_abs', 'copy_negate', 'copy_sign'):
        assert has_callables(cls, attr) is True

    assert has_callables(cls, 'as_tuple', 'compare', 'compare_signal', 'copy_abs', 'copy_negate', 'copy_sign') is True

    assert has_callables(cls, 'foo') is False
    assert has_callables(cls, 'foo', 'bar') is False
    assert has_callables(cls, 'foo', 'bar', 'baz') is False



# Generated at 2022-06-11 22:30:09.961934
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'values', 'items', 'get') == True



# Generated at 2022-06-11 22:30:19.130467
# Unit test for function has_callables
def test_has_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
    )
    from decimal import Decimal
    from typing import (
        Any,
        Dict,
        List,
        Set,
        Union,
    )
    from unittest import mock

    #
    # Tests with ChainMap objects that are empty
    #

    # noinspection PyTypeChecker
    c1: ChainMap[str, Any] = ChainMap({})  # type: ignore
    # noinspection PyTypeChecker
    c_empty: ChainMap[str, Any] = ChainMap()  # type: ignore
    # noinspection PyTypeChecker
    c_iter: ChainMap[str, Any] = ChainMap(iter([]))  # type: ignore
    # noinspection PyTypeChecker
    c

# Generated at 2022-06-11 22:30:22.673674
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(callable, '__call__') == True
    assert has_callables(1, '__call__') == False


# Generated at 2022-06-11 22:30:29.519664
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(dict(a=1, b=2), 'keys', 'values', 'items'))
    assert(not has_callables(dict(a=1, b=2), 'get', 'keys', 'values', 'items'))
    assert(not has_callables(dict(a=1, b=2), 'keys', 'values', 'foo'))


# Generated at 2022-06-11 22:30:45.577004
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo') is False


# Generated at 2022-06-11 22:30:50.822545
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'clear','pop','popitem','setdefault','update')
    assert has_callables(dict(),'clear')
    assert not has_callables(dict(),'foo')
    assert not has_callables(dict(),'foo','bar')

# Generated at 2022-06-11 22:30:58.228488
# Unit test for function has_any_callables
def test_has_any_callables():
    print('Testing has_any_callables()')
    d = dict(a=1, b=2)
    assert has_any_callables(d, 'get', 'keys', 'items', 'values', 'foo') is True, 'has_any_callables() failed'
    assert has_any_callables(d, 'has_key', 'keys', 'items', 'values', 'foo') is False, 'has_any_callables() failed'



# Generated at 2022-06-11 22:31:07.218390
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import (
        Counter,
        OrderedDict,
        defaultdict
    )
    from decimal import Decimal
    from flutils.objutils import (
        has_any_callables,
        has_callables
    )


# Generated at 2022-06-11 22:31:16.670639
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'something')
    assert not has_any_callables(dict(), 'something', 'another', 'get')
    assert not has_any_callables('some string', 'get', 'keys', 'items', 'something')


# Generated at 2022-06-11 22:31:20.674835
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') == True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(obj, 'foo') == False



# Generated at 2022-06-11 22:31:26.809535
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values')


# Generated at 2022-06-11 22:31:29.209239
# Unit test for function has_any_callables
def test_has_any_callables():
    cls = dict
    assert has_any_callables(cls,"get","keys","items","values","foo") == True


# Generated at 2022-06-11 22:31:34.529738
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj.keys(), 'pop', 'add', 'remove') is True
    assert has_any_callables(obj.keys(), 'pop', 'add', 'remove') is True
    assert has_any_callables(obj.values(), 'pop', 'add', 'remove') is False


# Generated at 2022-06-11 22:31:37.495773
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(obj, 'foo', 'bar')



# Generated at 2022-06-11 22:31:48.774185
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1)
    assert has_callables(obj, 'get')
    assert has_callables(obj, 'get', 'keys')
    assert has_callables(obj, 'get', 'keys', 'values')
    assert not has_callables(obj, 'foo')
    assert not has_callables(obj, 'get', 'foo')
    assert not has_callables(obj, 'get', 'foo', 'bar')


# Generated at 2022-06-11 22:31:52.647867
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:32:01.750246
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import Counter
    from datetime import datetime
    assert has_callables(datetime.now(),"__add__","__sub__")
    assert has_callables(Counter([]), "update", "most_common")
    assert has_callables([], "__contains__", "__iter__", "append")
    assert not has_callables([], "bar", "baz", "foo")
    assert not has_callables(Counter([]), "foo", "bar")


# Generated at 2022-06-11 22:32:07.623844
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar','baz','qux') == False
    assert has_any_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:32:11.407973
# Unit test for function has_callables
def test_has_callables():
    class foo:
        def bar(self, *args):
            return args

    assert has_callables(foo(),'bar', 'baz') == False
    assert has_callables(foo(), 'bar') == True



# Generated at 2022-06-11 22:32:19.456761
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import ChainMap
    from flutils.objutils import has_any_callables

    obj = ChainMap(dict(a=1, b=2), dict(c=3, d=4))
    attrs = ['get', 'update']
    assert has_any_callables(obj, *attrs)

    obj = [1, 2, 3, 4, 5]
    attrs = ['get', 'update']
    assert has_any_callables(obj, *attrs)

    obj = tuple(range(6))
    attrs = ['get', 'update']
    assert has_any_callables(obj, *attrs) is False



# Generated at 2022-06-11 22:32:21.475215
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-11 22:32:24.099903
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-11 22:32:28.280239
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') # returns True
    assert not has_callables(dict(), 'get', 'keys', 'items', 'test') # returns False

# Generated at 2022-06-11 22:32:34.860404
# Unit test for function has_callables
def test_has_callables():
    import pytest
    from collections import defaultdict
    from decimal import Decimal
    classes = (
        defaultdict,
        Decimal,
        dict,
        frozenset,
        int,
        list,
        set,
        tuple,
        type(None),
        type,
    )
    for cls in classes:
        obj = cls()
        attrs = ('keys', 'items', 'values')
        if has_callables(obj, *attrs):
            assert has_callables(obj, *attrs)
        else:
            with pytest.raises(AssertionError):
                assert has_callables(obj, *attrs)

# Generated at 2022-06-11 22:32:57.801983
# Unit test for function has_callables
def test_has_callables():
    from types import FunctionType
    from flutils.objutils import has_callables
    from collections import Counter
    from flutils.collections import DictList
    @has_callables(obj=[DictList, Counter],
              funcs=('get', 'append', 'update', 'keys'))
    def foo(obj):
        return obj
    obj1 = foo(a=1, b=2)
    assert(isinstance(obj1, DictList))
    obj2 = foo(a=1, b=2)
    assert(isinstance(obj2, Counter))
    try:
        foo(a=1, b=2, c=3)
    except Exception as err:
        assert(str(err) == "obj should hasattr [get, append, update, keys]")
    
    # test func_type


# Generated at 2022-06-11 22:33:01.307574
# Unit test for function has_any_callables
def test_has_any_callables():
    # Inputs
    obj = None
    attrs = ('get', 'keys', 'items', 'values', 'foo')
    # Output
    actual = has_any_callables(obj, *attrs)
    # Expected
    expected = False
    # Check
    assert actual == expected



# Generated at 2022-06-11 22:33:12.021011
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test 1
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    # Test 2
    assert has_any_callables(float, 'fromhex', 'hex')
    # Test 3
    assert has_any_callables(dict(), 'copy', 'fromkeys', 'get', 'fromkeys')
    # Test 4
    assert not has_any_callables(dict(a=1, b=2, c=3), 'foo')
    # Test 5
    assert not has_any_callables(float, 'fromkeys', 'fromhex', 'hex')
    # Test 6
    assert not has_any_callables(list, 'foo')

    print('func callables: has_any_callables: Tests Passed')


# Generated at 2022-06-11 22:33:13.445232
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:33:17.860801
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:33:30.029687
# Unit test for function has_any_callables

# Generated at 2022-06-11 22:33:35.600365
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(set(),'get','keys','items','values','foo') == True
    assert has_any_callables(list(),'get','keys','items','values','foo') == False
    assert has_any_callables(str(),'get','keys','items','values','foo') == False


# Generated at 2022-06-11 22:33:41.617515
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'values', 'items') == True
    assert has_any_callables(obj, 'keys', 'values', 'items', 'foo') == True
    assert has_any_callables(obj, 'keys', 'values', 'items', 'foo', 'bar') == True
    assert has_any_callables(obj) == False


# Generated at 2022-06-11 22:33:43.673751
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','values','foo') == False


# Generated at 2022-06-11 22:33:50.048143
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'something')
    assert not has_any_callables(dict(), 'something')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'something1', 'something2')

