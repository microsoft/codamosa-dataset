

# Generated at 2022-06-11 22:25:36.385001
# Unit test for function has_any_callables
def test_has_any_callables():
    print('has_any_callables=', has_callables(dict(),'get','keys','values','set'))
    print('has_any_callables=', has_callables(dict(),'get','keys','values','foo'))

# Generated at 2022-06-11 22:25:37.970987
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:25:41.713406
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for the function has_callables.
    """
    test_obj = [1, 2, 3]

    assert has_callables(test_obj, 'append', 'extend') == True
    assert has_callables(test_obj, 'copy', 'clear') == False
    assert has_callables(test_obj, 'extend') == True
    assert has_callables(test_obj, 'copy') == False

# Generated at 2022-06-11 22:25:45.394181
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:25:53.049090
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') == (True)
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') == (False)
    assert has_any_attrs(int(), 'real', 'imag', 'denominator', 'numerator') == (True)
    assert has_any_attrs(int(), 'bar', 'baz') == (False)
    return True


# Generated at 2022-06-11 22:25:58.938745
# Unit test for function has_attrs
def test_has_attrs():
    # Test: False case
    obj = dict(a=1)
    if has_attrs(obj, 'get', 'keys', 'items') is False:
        print('Pass')
    else:
        raise ValueError

    # Test: True case
    obj = dict(a=1)
    if has_attrs(obj, 'get', 'keys', 'items', 'values') is True:
        print('Pass')
    else:
        raise ValueError



# Generated at 2022-06-11 22:26:02.791447
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(str(),'get','keys','items','values','foo') == False


# Generated at 2022-06-11 22:26:10.970266
# Unit test for function has_any_callables
def test_has_any_callables():
    # Arrange
    as_str = 'a string'
    as_num = 6
    as_list = ['a', 'list']
    as_tuple = ('a', 'tuple')
    as_dict = {'a': 'dict'}
    as_func = lambda x: x+1
    as_obj = object()

    # Act
    # Assert
    assert has_any_callables(as_str, 'lower', 'upper') == True
    assert has_any_callables(as_num, '__add__', '__mul__') == True
    assert has_any_callables(as_list, 'append') == True
    assert has_any_callables(as_tuple, 'count') == True
    assert has_any_callables(as_dict, 'pop') == True
   

# Generated at 2022-06-11 22:26:15.445503
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict().keys(),'__contains__')
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict(),'get')
    assert has_callables(dict(),'keys')
    assert has_callables(dict(),'items')
    assert has_callables(dict(),'values')
    assert not has_callables(dict(),'foo')


# Generated at 2022-06-11 22:26:24.568316
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables({}, 'get', 'keys', 'items', 'values') is True
    assert has_callables({}, 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(list(), 'get', 'keys', 'items', 'values') is False
    assert has_callables(list(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-11 22:26:33.625583
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    # returns True

    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    # returns True

    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    # returns True



# Generated at 2022-06-11 22:26:34.200824
# Unit test for function has_callables
def test_has_callables():
    pass

# Generated at 2022-06-11 22:26:36.899916
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:26:38.554896
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(UserList()) is True



# Generated at 2022-06-11 22:26:45.571595
# Unit test for function has_callables
def test_has_callables():
    import pytest
    t = dict(a=1,b=2)
    assert has_callables(t,"items") ==  True
    assert has_callables(t,"a") ==  False
    assert has_callables(t,"b") ==  False
    assert has_callables(t,"next") ==  False
    assert has_callables(t,"get") ==  True


# Generated at 2022-06-11 22:26:49.442518
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(a=1,b=2),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:26:52.345425
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict(),'get','keys','items','values','foo') == False


# Generated at 2022-06-11 22:27:00.961889
# Unit test for function has_callables
def test_has_callables():
    """Test the function has_callables."""
    import time

    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(time, 'sleep')
    assert not has_callables(dict(), 'get', 'keys', 'items', 'something')
    assert not has_callables(dict(), 'get', 'keys', 'items', 'items')
    assert not has_callables(time, 'sleep', 'something')



# Generated at 2022-06-11 22:27:09.100340
# Unit test for function has_any_callables
def test_has_any_callables():
    import flutils.objutils
    import collections

    assert (flutils.objutils.has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True)
    assert (flutils.objutils.has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__contains__') == True)
    assert (flutils.objutils.has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__len__') == True)
    assert (flutils.objutils.has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__setitem__') == True)

# Generated at 2022-06-11 22:27:11.023289
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-11 22:27:17.735300
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import has_any_attrs
    assert has_any_attrs(dict(),'get','keys','items','values','something')==True


# Generated at 2022-06-11 22:27:21.678553
# Unit test for function has_callables
def test_has_callables():
    """Unit test for has_callables"""
    assert has_callables(dict(), 'get', 'keys', '__contains__', 'values', 'items')



# Generated at 2022-06-11 22:27:28.398024
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'keys')
    assert has_callables(dict(), 'keys', 'setdefault')
    assert not has_callables(dict(), 'keys', 'setdefault', 'smellymethod')
    assert not has_callables(dict(), 'a', 'setdefault', 'keys')


# Generated at 2022-06-11 22:27:29.373172
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:27:33.602790
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values')
    assert has_any_attrs(dict(),'foo','bar','baz')
    assert has_any_attrs(dict(),'get','keys','items','values','foo')
    assert has_any_attrs(dict(),'get','keys',None,'values','foo')
    assert has_any_attrs(dict(),'get','keys',False,'values','foo')



# Generated at 2022-06-11 22:27:36.515434
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert (
        has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')
    ) is True
    assert (
        has_any_attrs(obj, 'foo', 'bar', 'boo', 'whatever')
    ) is False



# Generated at 2022-06-11 22:27:38.543077
# Unit test for function has_attrs
def test_has_attrs():
    class Foobar:
        def foo(self):
            pass
    assert has_attrs(Foobar, 'foo') is True
    assert has_attrs(Foobar, 'foo', 'bar') is False


# Generated at 2022-06-11 22:27:41.432365
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-11 22:27:48.263555
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foobar')
    assert has_any_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'foobar')


# Generated at 2022-06-11 22:27:52.635953
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(), 'get', 'keys', 'items', 'something')


# Generated at 2022-06-11 22:28:02.526029
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:28:11.545696
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'keys') is True
    assert has_any_attrs(dict(), 'keys', 'values') is True
    assert has_any_attrs(dict(), 'keys', 'values', 'items') is True
    assert has_any_attrs(dict(), 'keys', 'values', 'items', 'foo') is True
    assert has_any_attrs(dict(), 'keys', 'values', 'items', 'foo', 'bar') is True


# Generated at 2022-06-11 22:28:15.846436
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print("Testing function has_any_attrs")
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is not False


# Generated at 2022-06-11 22:28:22.970832
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', '__setitem__') is True
    assert has_any_callables(obj, 'a', 'b', 'c', 'd', 'e') is False


# Generated at 2022-06-11 22:28:30.411582
# Unit test for function has_callables
def test_has_callables():
    from decimal import Decimal

    class DecimalDigit(Decimal):
        def __init__(self, value: int):
            if not 0 <= value < 10:
                raise ValueError("value must be [0-9]")
            super().__init__(value)

    dd = DecimalDigit(1)
    print(isinstance(dd, Decimal))
    print(hasattr(dd, 'as_tuple'))
    print(hasattr(dd, 'sqrt'))


# Generated at 2022-06-11 22:28:37.640544
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'values', 'items', 'get')
    assert not has_any_callables(obj, 'get', 'keys', 'items', 'foo')
    assert not has_any_callables(obj, 'foo', 'bar', 'baz', 'quux')



# Generated at 2022-06-11 22:28:42.870413
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False



# Generated at 2022-06-11 22:28:53.803129
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict()
    assert has_any_callables(d, 'keys', 'values', 'items')
    assert has_any_callables(d, 'not_there') is False
    assert has_any_callables(dict, 'keys', 'values', 'items')
    assert has_any_callables(dict, 'not_there') is False
    assert has_any_callables(dict(), 'keys', 'values', 'items')
    assert has_any_callables(dict(), 'not_there') is False
    assert has_any_callables(dict, 'keys', 'values', 'items')
    assert has_any_callables(dict, 'not_there') is False

# Generated at 2022-06-11 22:28:58.369674
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs."""

    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'items', 'values', 'something')

    # Check if has_any_attrs returns True for any of the given *attrs
    assert has_any_attrs(obj, *attrs) is True



# Generated at 2022-06-11 22:29:01.387738
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'something') is False



# Generated at 2022-06-11 22:29:25.069433
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables."""
    class X:
        def get(self):
            return self

        def set(self):
            return self

    x = X()

    assert has_any_callables(x, 'get', 'foo') is True
    assert has_any_callables(x, 'set', 'foo') is True
    assert has_any_callables(x, 'foo') is False


# Generated at 2022-06-11 22:29:36.439061
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({'get': None, 'foo': None}, 'get', 'foo') is True
    assert has_callables({'get': None}, 'get', 'foo') is False
    assert has_callables(dict(), 'get', 'foo') is False
    assert has_callables(dict(get=None, foo=None), 'get', 'foo') is False
    assert has_callables(dict(get='hi', foo=None), 'get', 'foo') is False
    assert has_callables(dict(get='hi', foo=None, keys=None),
                         'get', 'foo', 'keys') is False
    assert has_callables(dict(get=lambda: 0, foo=0), 'get', 'foo') is True


# Generated at 2022-06-11 22:29:40.004593
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'translate', 'keys', 'items') is True
    assert has_any_callables(1, 'get', 'translate', 'keys', 'items') is False
    assert has_any_callables(1, 'get') is False


# Generated at 2022-06-11 22:29:42.822065
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'get')
    assert has_any_callables((1, 2, 3), 'pop', 'count')
    assert not has_any_callables('hello', 'pop', 'count')


# Generated at 2022-06-11 22:29:49.407306
# Unit test for function has_callables
def test_has_callables():
    """Tests the function 'has_callables'"""
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict, 'get', 'keys', 'items', 'values')
    assert not has_callables(dict(), 'getter', 'keys', 'items', 'values')
    assert not has_callables(dict, 'get', 'keyser', 'items', 'values')
    assert not has_callables(dict, 'get', 'keys', 'itemser', 'values')
    assert not has_callables(dict, 'get', 'keys', 'items', 'valuers')

if __name__ == '__main__':
    from flutils.objutils import (
        is_list_like,
        has_callables,
    )
    import doctest


# Generated at 2022-06-11 22:29:54.095432
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables"""
    from flutils.objutils import has_any_callables
    obj = dict()
    assert has_any_callables(obj, attrs=('get', 'something'),)



# Generated at 2022-06-11 22:29:58.978712
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get', 'nonexistent') is True
    assert has_any_callables(dict(),'nonexistent') is False
    assert has_any_callables(dict(a=1, b=2),'get', 'items') is True


# Generated at 2022-06-11 22:30:04.369142
# Unit test for function has_any_callables
def test_has_any_callables():
    def foo():
        pass
    assert has_any_callables(foo, '__call__') is True
    assert has_any_callables([1,2,3], 'sort') is True
    assert has_any_callables(range(3), 'sort') is False
    assert has_any_callables({'a':'b'}, 'sort') is False


# Generated at 2022-06-11 22:30:09.726598
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserDict

    assert has_any_callables('hello', 'lower', 'upper', 'something') is True
    assert has_any_callables(None, 'lower', 'upper', 'something') is False
    assert has_any_callables(True, 'lower', 'upper', 'something') is False
    assert has_any_callables(UserDict(), 'values', 'keys', 'something') is False
    assert has_any_callables(UserDict(), 'values', 'keys', 'items') is True



# Generated at 2022-06-11 22:30:12.331819
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, *obj.keys())


# Generated at 2022-06-11 22:30:24.714336
# Unit test for function has_any_callables
def test_has_any_callables():
    a = dict(a=1, b=2)
    assert has_any_callables(a, "get", "keys", "items", "values", "foo") is True
    assert has_any_callables(a, "get", "keys", "items", "values", "foo", "bar") is False


# Generated at 2022-06-11 22:30:29.341999
# Unit test for function has_callables
def test_has_callables():
    results = {
        'dict': True,
        'None': False,
    }
    for key, val in results.items():
        assert has_callables(eval(key), 'get', 'keys', 'items', 'values') == val



# Generated at 2022-06-11 22:30:32.950084
# Unit test for function has_callables
def test_has_callables():

    obj = dict(a=1, b=2)

    assert has_callables(obj, 'keys', 'items', 'values', 'get') is True



# Generated at 2022-06-11 22:30:39.746158
# Unit test for function has_callables
def test_has_callables():
    from collections.abc import Callable
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(list(),'pop','append') == True
    assert has_callables(tuple(),'pop','append') == False
    assert has_callables(True, 'capitalize') == False
    assert has_callables('foo', 'capitalize') == True
    assert has_callables(False, 'capitalize') == False
    assert has_callables(Callable, 'capitalize') == False


# Generated at 2022-06-11 22:30:46.125272
# Unit test for function has_callables
def test_has_callables():
    '''
    Tests the function has_callables
    '''

    #create tests
    test1 = TypeError
    test2 = AttributeError

    #check if both test1 and test2 are callable
    assert has_callables(test1, '__init__', '__str__') == True and has_callables(test2, '__init__', '__str__') == True

    #check that test1 has the correct name
    assert test1.__name__ == 'TypeError' and test2.__name__ == 'AttributeError'

# Generated at 2022-06-11 22:30:53.023355
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','foo','values') is False
    assert has_callables(dict(),'get','keys','items','values','foo') is False
    assert has_callables(dict(),'bar','foo','items','values','foo') is False


# Generated at 2022-06-11 22:30:58.637137
# Unit test for function has_callables
def test_has_callables():

    assert has_callables(dict(), 'keys','values','items','get') == True
    assert has_callables(dict(), 'keys','values','items') is False
    assert has_callables(dict(), 'keys','values','items','foo') is False
    assert has_callables(dict(), 'keys','values','items','foo','get') == True


# Generated at 2022-06-11 22:31:06.087409
# Unit test for function has_callables
def test_has_callables():
    class Foo(object):
        def __init__(self, f=None):
            self.f = f

        def foo(self):
            return 'FOO'

    assert has_callables(Foo(), 'f', 'foo') is True
    assert has_callables(Foo(f=Foo()), 'f', 'foo') is True
    assert has_callables(Foo('foo'), 'f', 'foo') is True
    assert has_callables(Foo(), 'f', 'bar') is False
    assert has_callables(Foo(), 'bar') is False



# Generated at 2022-06-11 22:31:18.823261
# Unit test for function has_callables
def test_has_callables():
    print(f"is hasattr(dict(),'get','keys','items','values') True? {has_callables(dict(),'get','keys','items','values')}")
    print(f"is hasattr(dict(),'get','keys','items','something') True? {has_callables(dict(),'get','keys','items','something')}")
    print(f"is hasattr(dict(),'get','keys','items') True? {has_callables(dict(),'get','keys','items')}")
    print(f"is hasattr(dict(),'get','keys','something') True? {has_callables(dict(),'get','keys','something')}")
    print(f"is hasattr(dict(),'get','something') True? {has_callables(dict(),'get','something')}")

# Generated at 2022-06-11 22:31:26.478368
# Unit test for function has_callables
def test_has_callables():
    class Test:
        def get(self):
            pass

    assert has_callables(Test(), 'get') is True
    assert has_callables({}, 'get') is False
    assert has_callables(dict(), 'get') is True

if __name__ == '__main__':

    test_has_callables()

# Generated at 2022-06-11 22:31:50.912088
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils import objutils

    class x(object):

        t = 'hello'
        t2 = 'world'

        @classmethod
        def h(cls, a, b='its'):
            return a + b + cls.t + cls.t2

    print(objutils.has_any_callables(object, '__init__', '__new__'))
    print(objutils.has_any_callables(x, 'h'))
    print(objutils.has_any_callables(x, 'h', 't'))
    print(objutils.has_any_callables(x, 'h', 't', 't2'))

if __name__ == '__main__':
    test_has_any_callables()
# vim: set fileencoding=utf-8 ts

# Generated at 2022-06-11 22:31:55.017831
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj,'get','keys')
    assert not has_any_callables(obj,'foo','bar','baz')


# Generated at 2022-06-11 22:32:01.979457
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables"""
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'items', 'values')
    assert has_callables(obj, 'keys', 'items')
    assert not has_callables(obj, 'keys', 'values', 'foo')
    assert has_callables(obj, 'keys')
    assert not has_callables(obj, 'foo')


# Generated at 2022-06-11 22:32:15.241922
# Unit test for function has_callables
def test_has_callables():
    """
    Test passing the callables the function has_callables
    """

    class TestClass(object):
        def __init__(self, a=True, b=True):
            self.a = a
            self.b = b

        # a is optional
        def test1(self, a=None):
            pass

        def test2(self):
            pass

    # Test that getattr returns a callable
    assert has_callables(TestClass, "test1", "test2") is True
    assert has_callables(TestClass, "foo") is False

    # Test that getattr returns a callable
    test_obj = TestClass()

    assert has_callables(test_obj, "test1", "test2") is True

    # Test that getattr returns a callable

# Generated at 2022-06-11 22:32:17.274884
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True



# Generated at 2022-06-11 22:32:25.245885
# Unit test for function has_any_callables
def test_has_any_callables():
    class foo():
        def bar1(self):
            pass
        def bar2(self):
            pass

    f = foo()
    assert has_any_callables(f, 'bar1', 'bar2') is True
    assert has_any_callables(f, 'bar1', 'bar2', 'bar3') is True
    assert has_any_callables(f, 'bar1', 'bar3') is True
    assert has_any_callables(f, 'bar3') is False

# Generated at 2022-06-11 22:32:28.597048
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:32:31.311976
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-11 22:32:34.649948
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    obj = OrderedDict(a=1, b=2)
    attrs = ['get', 'keys', 'items', 'values']
    assert has_callables(obj, *attrs) is True


# Generated at 2022-06-11 22:32:41.141482
# Unit test for function has_callables
def test_has_callables():
    # Function has_callables returns True when all given attrs are callable
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    # Function has_callables returns False if any given attrs are non-callable
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-11 22:33:10.261713
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values'))
    assert (has_any_callables(dict(), 'get', 'keys', 'items', 'values',
    'foo'))


# Generated at 2022-06-11 22:33:12.653067
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-11 22:33:18.753670
# Unit test for function has_callables
def test_has_callables():
    this = dict(a=-1, b=-2, c=-3)
    assert has_callables(this, 'keys', 'items', 'values') is True
    assert has_callables(this, 'keys', 'items', 'something') is False
    assert has_callables(this, 'keys', 'items', 'values', 'something') is False


# Generated at 2022-06-11 22:33:22.794702
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'values', 'items', 'foo')


test_has_any_callables()

# Generated at 2022-06-11 22:33:32.900108
# Unit test for function has_callables
def test_has_callables():
    obj = 'hello'
    attrs = ('lower', 'upper', 'title', 'split')
    assert has_callables(obj, *attrs) is True
    obj = 'Hello'
    attrs = ('lower', 'upper', 'title', 'split')
    assert has_callables(obj, *attrs) is True
    obj = 'Hello'
    attrs = ('lower', 'upper', 'title', 'split', 'foo')
    assert has_callables(obj, *attrs) is False
    obj = 'Hello'
    attrs = ('lower', 'upper', 'title', 'split', 'capitalize')
    assert has_callables(obj, *attrs) is True
    obj = 'Hello'
    attrs = ('lower', 'upper', 'title', 'split', 'capitalize', 'foo')
   

# Generated at 2022-06-11 22:33:38.138925
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(bytes(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-11 22:33:50.093887
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(list(),'append','pop','reverse','foo') == True
    assert has_any_callables(set(),'__contains__','__iter__','__len__','foo') == True
    assert has_any_callables(frozenset(),'__contains__','__iter__','__len__','foo') == True
    assert has_any_callables('hello','__contains__','__iter__','__len__','foo') == False
    assert has_any_callables(tuple(),'__contains__','__iter__','__len__','foo') == False

# Generated at 2022-06-11 22:33:58.021867
# Unit test for function has_any_callables
def test_has_any_callables():
    # Given an object obj a function func and an attribute attr
    obj = 'foo'
    func = lambda: None
    attr = 'foo'
    # When the function has_any_callables is called
    # Then the result should be false
    assert(has_any_callables(obj, func, attr) is False)

    # Given an object obj a function func and an attribute attr
    obj = 'foo'
    func = lambda: None
    attr = 'foo'
    # When the function has_any_callables is called
    # with both function and attribute
    # Then the result should be false
    assert(has_any_callables(obj, func, attr) is False)

    # Given an object obj a function func and an attribute attr
    obj = 'foo'
    func = lambda: None


# Generated at 2022-06-11 22:34:07.130228
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables."""
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables([1, 2, 3], 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(set(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-11 22:34:11.258681
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','foo','values') == False
    assert has_callables(dict(),'get','keys','items','exists') == False
#

# Generated at 2022-06-11 22:35:10.315523
# Unit test for function has_any_callables
def test_has_any_callables():
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(a=1, b=2), 'foo', 'bar', 'baz')
    assert has_any_callables(dict(a=1, b=2), 'items', 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(a=1, b=2), 'foo', 'bar', 'baz', 'items')


# Generated at 2022-06-11 22:35:13.537873
# Unit test for function has_any_callables
def test_has_any_callables():
    '''
    Test function has_any_callables
    '''
    obj = dict(a=1, b=2)
    items = has_any_callables(obj.keys(), 'get', 'keys', 'items', 'values')
    assert items == True



# Generated at 2022-06-11 22:35:18.236796
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-11 22:35:27.229222
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    from flutils.objutils import has_callables
    assert has_callables(OrderedDict(),
                         '__class__',
                         '__contains__', ) is True
    assert has_callables(OrderedDict(),
                         '__class__',
                         '__contains__',
                         ) is True
    assert has_callables(OrderedDict(),
                         'get',
                         'keys',
                         'items',
                         ) is True
    assert has_callables(OrderedDict(),
                         '__class__',
                         '__contains__',
                         'get',
                         'keys',
                         'items',
                         ) is True

# Generated at 2022-06-11 22:35:33.358420
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(a=1, b=2)
    assert has_any_callables(d, 'get', 'foo', 'keys') is True
    assert has_any_callables(d, 'keys', 'bar', 'items') is True
    assert has_any_callables(d, 'geet', 'foo', 'bar') is False

