

# Generated at 2022-06-11 22:25:37.177734
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


if __name__ == '__main__':
    """
    Unit test for function has_any_callables
    """
    test_has_any_callables()

# Generated at 2022-06-11 22:25:48.851711
# Unit test for function has_any_callables
def test_has_any_callables():
    from sys import modules
    from types import ModuleType
    from random import randint
    from .helpers import ci_skip
    from flutils.objutils import has_any_callables
    # Ensure that ModuleType modules has the attributes of has_any_callables
    # parameters.
    obj = randint(1, 3)
    assert has_any_callables(
        obj,
        'bit_length', 'numerator', 'denominator', 'imag', 'real', 'to_bytes'
    ) is False
    # Bit length, numerator, denominator, imag, real, to_bytes are attributes
    # of int.
    obj = randint(1, 3) + 7j

# Generated at 2022-06-11 22:25:56.049412
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_callables(tuple(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_any_callables(1, 'get', 'keys', 'items', 'values', 'something') is False


# Generated at 2022-06-11 22:25:59.602780
# Unit test for function has_callables
def test_has_callables():
    from collections import Callable
    from types import FunctionType
    from types import MethodType
    obj = Callable()
    assert has_callables(obj, '__call__') == True

# Generated at 2022-06-11 22:26:02.998966
# Unit test for function has_callables
def test_has_callables():
    L = [1, 2, 3]
    assert has_callables(L, 'append') == True
    assert has_callables(L, 'append_with_no_args') == False

# Generated at 2022-06-11 22:26:07.388973
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for function has_callables
    """
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', outer=None)
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', outer='A')


# Generated at 2022-06-11 22:26:09.414973
# Unit test for function has_any_callables
def test_has_any_callables():
    assert (has_any_callables(dict(),'get','keys','items','values','foo') == True)


# Generated at 2022-06-11 22:26:20.530584
# Unit test for function has_callables
def test_has_callables():
    tests = {
        'dict': dict,
        'list': list,
        'dict_with_attr': mock.MagicMock(spec=dict),
        'mock_dict': mock.MagicMock,
    }

    @has_callables('a', 'b')
    class C(object):
        def __init__(self):
            self.a = 1
            self.b = 2

        def __call__(self):
            return self.a + self.b

    @has_callables('a')
    class D(C):
        def __init__(self):
            self.a = 1

        def __call__(self):
            return self.a

    # test basic functionality
    assert has_callables(tests['dict'], '__delitem__') is True

# Generated at 2022-06-11 22:26:23.663557
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar') is False


# Generated at 2022-06-11 22:26:28.062195
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        assert (has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-11 22:26:41.514437
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserList
    from collections.abc import ValuesView, KeysView
    l1 = [1, 2, 3, 4, 5]
    s1 = {1, 2, 3, 4, 5}
    t1 = (1, 2, 3, 4, 5)
    d1 = dict(a=1, b=2, c=3, d=4, e=5)
    # empty UserList
    ul1 = UserList()
    # empty set
    s2 = set()
    # empty dict
    d2 = dict()
    # empty deque
    dq1 = deque()
    # empty tuple
    t2 = tuple()
    # str
    s = 'hello'
    # int
    i = 123456789
    # float
    f = 123456789.12345
    #

# Generated at 2022-06-11 22:26:48.940572
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from pprint import pprint
    from collections import ChainMap

    assert has_any_attrs([], 'append') is True
    assert has_any_attrs({}, 'get') is True
    assert has_any_attrs(set(), 'add') is True
    assert has_any_attrs(ChainMap(), 'maps') is True

    assert has_any_attrs([], 'foo', 'bar', 'baz') is False
    assert has_any_attrs({}, 'foo', 'bar', 'baz') is False
    assert has_any_attrs(set(), 'foo', 'bar', 'baz') is False
    assert has_any_attrs(ChainMap(), 'foo', 'bar', 'baz') is False



# Generated at 2022-06-11 22:26:54.015278
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','items','keys','values') == True
    assert has_callables(dict(),'foo','bar','baz') == False

if __name__ == '__main__':
    # Unit test has_callables
    test_has_callables()

# Generated at 2022-06-11 22:26:56.890506
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True



# Generated at 2022-06-11 22:26:59.410537
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo') == True
    assert has_any_attrs(dict(),'foo','bar','baz','qux') == False
    assert has_any_attrs(dict(),'foobar') == False


# Generated at 2022-06-11 22:27:02.371027
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_callables(dict(), 'put', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:27:07.447238
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(list(),'get','keys','items','values','foo') == False
    assert has_any_callables(list(),'get','keys','items','values','append') == True


# Generated at 2022-06-11 22:27:12.830680
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_callables('Something', 'get', 'keys', 'items', 'values', 'something') is False


# Generated at 2022-06-11 22:27:15.925403
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import has_any_attrs
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-11 22:27:17.465262
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:27:25.190438
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:27:29.485191
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert  not has_any_callables(dict(),'foo','bar')
    assert  not has_any_callables(1, 'foo', 'bar')


# Generated at 2022-06-11 22:27:35.653852
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import ChainMap
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(),'foo','bar','baz') == False
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(ChainMap(),'foo','bar','baz') == False
    assert has_any_callables(ChainMap(),'maps','parents') == True
    assert has_any_callables(ChainMap(),'new_child','new_child') == True
    assert has_any_callables(ChainMap(),'maps','parents','new_child') == True
    assert has_any_callables(ChainMap(),'maps','parents','get') == True


# Generated at 2022-06-11 22:27:37.394915
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert (has_callables(obj, 'keys', 'items', 'values')) == True



# Generated at 2022-06-11 22:27:38.670258
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-11 22:27:40.554386
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(), 'has_callables', 'keys') == False
    assert has_callables(dict(),'get','keys','has_callables','values') == False


# Generated at 2022-06-11 22:27:51.025880
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'something') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'something', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'something', 'bar', 'baz') is True

# Generated at 2022-06-11 22:27:53.998630
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Verification test for function has_any_callables

# Generated at 2022-06-11 22:27:57.376956
# Unit test for function has_callables
def test_has_callables():
    def function1():
        return
    d = {'function1': function1}
    assert has_callables(d, 'function1') is True
    assert has_callables(d, 'function2') is False
    return

# Generated at 2022-06-11 22:28:06.805421
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test a class with a callable
    class X:
        def __init__(self):
            self.a = 5

        def _callable(self):
            return self.a

        def _not_callable(self):
            return self.a

    _x = X()
    assert has_any_callables(_x, '_callable', '_not_callable')

    # Test a class with no callable
    class Y:
        def __init__(self):
            self.a = 5

        def _not_callable(self):
            return self.a

    _y = Y()
    assert not has_any_callables(_y, '_callable')

    # Test an instance with no attribute
    class Z:
        def __init__(self):
            self.a = 5

    _

# Generated at 2022-06-11 22:28:18.603026
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get')
    assert not has_callables(dict(), 'foo')
    assert not has_callables(dict(), 'get', 'foo')
    assert not has_callables(dict(), 'something', 'foo')


# Generated at 2022-06-11 22:28:29.954957
# Unit test for function has_any_callables
def test_has_any_callables():
    # test positive results
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foobar')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar')
    assert has_any_callables(dict(), 'foo', 'bar', 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'foo', 'bar', 'get', 'keys', 'items', 'values', 'foobar')
    assert has_any_callables(dict(), 'foo', 'bar', 'foobar', 'get', 'keys', 'items', 'values')
    # test negative results
    assert not has_any_callables(dict(), 'foobar', 'foo', 'bar')
    assert not has_any_call

# Generated at 2022-06-11 22:28:35.224344
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'values') is True
    assert has_any_callables(obj, 'foo') is False



# Generated at 2022-06-11 22:28:40.271567
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    make test_has_any_callables
    """
    obj = dict(a=1, b=2)
    callables = has_any_callables(obj, 'get', 'keys', 'items', 'values', 'pop')
    assert callables is True


# Generated at 2022-06-11 22:28:44.275110
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert not has_any_callables(dict(),'foo','bar','baz')


# Generated at 2022-06-11 22:28:54.588506
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'items', 'values')
    assert has_callables({}, ['get', 'keys', 'items', 'values'])
    assert has_callables(dict, 'get', 'keys', 'items', 'values')
    assert has_callables(dict, ['get', 'keys', 'items', 'values'])
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), ['get', 'keys', 'items', 'values'])


# Generated at 2022-06-11 22:29:01.978899
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_ = dict(a=1, b=list(range(3)))
    assert has_any_callables(dict_, 'keys', 'items', 'values', 'something') is True
    assert has_any_callables(dict_, 'keys', 'items', 'values', 'something') is True
    assert has_any_callables(dict_, 'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-11 22:29:04.642883
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'keys','items','values','get') == True
    assert has_callables(dict(),'keys','items','values','something') == False


# Generated at 2022-06-11 22:29:07.260601
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'))


# Generated at 2022-06-11 22:29:11.648809
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'foo','bar','baz') == False
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:29:36.164161
# Unit test for function has_callables
def test_has_callables():
    import datetime

    # Check callables exist on object
    assert has_callables(datetime, "date", "datetime") is True
    assert has_callables(datetime, "date", "datetime", "time") is True
    assert has_callables(datetime, "datetime", "time") is False
    assert has_callables(datetime, "date", "time") is False
    assert has_callables(datetime, "datetime") is False
    assert has_callables(datetime, "date") is False
    assert has_callables(datetime, "time") is False



# Generated at 2022-06-11 22:29:39.509641
# Unit test for function has_callables
def test_has_callables():
    # Creating an object of 'dict' class
    Dict = dict(a=1, b=2)

    # Calling function
    x= has_callables(Dict, 'get', 'keys', 'items', 'values')

    # Printing output
    print(x)


# Generated at 2022-06-11 22:29:41.032633
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','bar') == True


# Generated at 2022-06-11 22:29:48.316705
# Unit test for function has_callables

# Generated at 2022-06-11 22:29:58.324093
# Unit test for function has_callables
def test_has_callables():
    """

    The :func:`has_callabls <flutils.objutils.has_callables>` function should
    check if the given ``obj`` has all the given ``attrs`` and are callable.

    Example:

        >>> from flutils.objutils import has_callables
        >>> has_callables(dict(), 'get', 'keys', 'items', 'values')
        True
    """
    if has_callables(dict(), 'get', 'keys', 'items', 'values') is False:
        raise Exception("test_has_callables 1 failed.  "
                        "Expected 'True'.")
    if has_callables(str(), 'upper', 'lower', '__add__') is False:
        raise Exception("test_has_callables 2 failed.  "
                        "Expected 'True'.")

# Generated at 2022-06-11 22:30:02.092748
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False


# Generated at 2022-06-11 22:30:05.033931
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'foo', 'bar', 'baz')



# Generated at 2022-06-11 22:30:16.134479
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1, 2], 'append', 'pop') is False
    assert has_any_callables([1, 2], 'append', 'pop', '__getitem__') is True
    assert has_any_callables([1, 2], '__getitem__', '__len__') is True
    assert has_any_callables((1, 2), 'append', 'pop') is False
    assert has_any_callables((1, 2), 'append', 'pop', '__getitem__') is True
    assert has_any_callables((1, 2), '__getitem__', '__len__') is True
    assert has_any_callables(dict(), 'append', 'pop') is False
    assert has_any_callables(dict(), 'append', 'pop', 'keys') is True

# Generated at 2022-06-11 22:30:19.309975
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-11 22:30:22.904666
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-11 22:31:19.021875
# Unit test for function has_callables
def test_has_callables():
    import unittest
    import subprocess
    import sys

    def check_processes(processes):
        return [p.poll() is None for p in processes]

    # Start a local server (in a subprocess)
    p_list = [
        subprocess.Popen(['python', '-m', 'http.server', '8000']),
        subprocess.Popen(['python', '-m', 'http.server', '8001']),
        subprocess.Popen(['python', '-m', 'http.server', '8002'])
    ]

    class TestHasCallables(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_has_callables(self):
            # Check the import works
            import flutils


# Generated at 2022-06-11 22:31:27.293985
# Unit test for function has_callables
def test_has_callables():
    test_dict = dict(a=1, b=2, c=3)
    actual = has_callables(test_dict, 'get', 'keys', 'items', 'values')
    expected = True
    assert actual == expected

    actual = has_callables(test_dict, 'get', 'keys', 'items', 'values', 'foo')
    expected = False
    assert actual == expected



# Generated at 2022-06-11 22:31:38.109409
# Unit test for function has_callables
def test_has_callables():
    class HasCallables(object):
        def get(self): pass

        def keys(self): pass

        def values(self): pass

        def items(self): pass

    class HasAttrs(object):
        name = 'spam'

        def func(self): pass

    assert has_callables(dict, 'get', 'keys', 'values', 'items') is True
    assert has_callables(HasCallables(), 'get', 'keys', 'values', 'items') is True

    assert has_callables(None, 'get') is False
    assert has_callables(HasAttrs(), 'get') is False
    assert has_callables(HasAttrs(), 'name', 'func') is False
    assert has_callables(HasAttrs(), 'name', 'func', 'something') is False



# Generated at 2022-06-11 22:31:45.483436
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'fromkeys', 'get') is True
    assert has_callables(dict(), 'fromkeys', 'bar') is False
    assert has_callables(dict(), ['fromkeys', 'get']) is True
    assert has_callables(dict(), ['fromkeys', 'bar']) is False
    assert has_callables(dict(), 'fromkeys') is True
    assert has_callables(dict(), 'bar') is False


# Generated at 2022-06-11 22:31:49.305527
# Unit test for function has_callables
def test_has_callables():
    try:
        class A: pass

        a = A()
        a.bar = lambda: None
        a.baz = 42
        assert has_callables(a, 'bar') is True, 'Failed to return True'
        assert has_callables(a, 'bar', 'baz') is False, 'Failed to return False'
    except Exception as e:
        print(e)


# Generated at 2022-06-11 22:31:58.398657
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') == False


if __name__ == '__main__':

    # Unit test for function has_any_callables
    def test_has_any_callables():
        assert has_any_callables(dict(), 'get', 'keys', 'items', 'foo') == True

    test_has_any_callables()

# Generated at 2022-06-11 22:32:05.522898
# Unit test for function has_callables
def test_has_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        ChainMap,
        defaultdict
    )

    from decimal import Decimal

    for cls in (
            ChainMap,
            Counter,
            OrderedDict,
            UserDict,
            UserString,
            defaultdict,
            Decimal,
    ):
        assert has_callables(cls(), '__contains__', '__iter__') is True
        assert has_callables(cls(), '__getitem__', '__iter__') is True
        assert has_callables(cls(), '__len__', '__iter__') is True


# Generated at 2022-06-11 22:32:16.802836
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'update', '__iter__')
    assert not has_callables({}, 'update', 'get')
    assert has_callables([], 'extend', 'count')
    assert not has_callables([], 'extend', 'insert')
    assert has_callables({}.keys(), '__contains__', '__iter__')
    assert not has_callables({}.keys(), '__contains__', 'add')
    assert has_callables(map(lambda x: x, []), '__next__', '__iter__')
    assert not has_callables(map(lambda x: x, []), '__next__', 'append')
    assert has_callables(sorted([]), '__getitem__', '__iter__')

# Generated at 2022-06-11 22:32:25.245665
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter
    _c = Counter()
    # _c.most_common should be a method
    assert has_callables(_c, 'most_common') is True
    # _c.most_common should not be a method
    assert has_callables(_c, '__sub__') is False
    # _c.most_common should not be a method
    assert has_callables(_c, 'most_common', '__sub__') is False

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:32:29.295008
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False



# Generated at 2022-06-11 22:32:58.718302
# Unit test for function has_callables
def test_has_callables():
    # Testing parameters
    class D1(dict):
        pass
    class D2:
        pass
    res = []
    target = dict(
        obj1=D1(a=1,b=2,c=3),
        obj2=D2(),
        attrs1=('a','b','c'),
        attrs2=('a','b')
    )

    try:
        assert has_callables(target['obj1'],*target['attrs1'])==True, \
            "Expecting has_callables to return True but got False"
        res.append("Unit test has_callables: PASS")
    except AssertionError as e:
        res.append("Unit test has_callables: FAIL")
        raise AssertionError("{}\n{}".format(e,target))

   

# Generated at 2022-06-11 22:33:07.966753
# Unit test for function has_callables
def test_has_callables():

    def f():pass
    class fc:
        def f(self):pass

    tests = [
        (((),None,),(None,)),
        (((None, f), (None,fc)),(None, f)),
        (((f,fc),),(f,))
    ]

    exp = [False, True, True]

    for test, types in tests:
        for inp, cls in zip(test, types):
            res = has_callables(*inp)
            assert res == exp[types.index(cls)]

# Generated at 2022-06-11 22:33:11.612611
# Unit test for function has_callables
def test_has_callables():
    test_str = '12345'
    assert has_callables(test_str,'upper','strip','split') == True
    assert has_callables(test_str,'upper','strip','something') == False


# Generated at 2022-06-11 22:33:15.991244
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables('', 'rstrip', 'strip', 'lstrip')
    assert has_callables(5, 'to_bytes')
    assert has_callables(bytes(), 'decode')
    assert not has_callables(dict(),'get')
    assert not has_callables('', 'rstrip', 'strip', 'lstrip', 'foo')
    assert not has_callables(None, 'foo')



# Generated at 2022-06-11 22:33:28.154355
# Unit test for function has_callables
def test_has_callables():
    # Define classes for testing has_callables
    class testObj:
        def __init__(self,foo=None,bar=None):
            self.foo = foo
            self.bar = bar

        def get_foo(self):
            return self.foo

    class testObj2:
        def __init__(self,foo=None,bar=None):
            self.foo = foo
            self.bar = bar

        def get_foo(self):
            return self.foo

    # Initialize test object
    test_obj = testObj(foo=1,bar=2)
    # Check that all fields are callable and exist as expected
    assert has_callables(test_obj,'get_foo','bar')==True
    # Check that a non-callable field is skipped

# Generated at 2022-06-11 22:33:37.806567
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'update') is True
    assert has_callables(dict(), 'get', 'keys', 'items') is True
    assert has_callables(dict(), 'get', 'keys') is True
    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(), 'foo') is False
    assert has_callables(dict(), 'get', 'foo') is False
    assert has_callables('hello', 'count', 'encode', 'endswith', 'find', 'foo') is True
    assert has_

# Generated at 2022-06-11 22:33:49.776607
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables({}, 'get', 'keys', 'items', 'values')
    assert has_callables({}.get, 'pop')
    assert has_callables([], 'get', 'keys', 'items', 'values')
    assert has_callables(set(), 'get', 'keys', 'items', 'values')
    assert has_callables(frozenset(), 'get', 'keys', 'items', 'values')
    assert has_callables(tuple(), 'get', 'keys', 'items', 'values')
    assert has_callables(reversed([]), 'get', 'keys', 'items', 'values')
    assert has_callables(reversed(''), 'get', 'keys', 'items', 'values')

# Generated at 2022-06-11 22:33:53.116279
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables"""
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False


# Generated at 2022-06-11 22:33:55.447731
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-11 22:34:01.263703
# Unit test for function has_callables
def test_has_callables():
    from collections.abc import Iterator as _Iterator
    import re as _re
    from os import tmpfile as _tmpfile
    from io import TextIOWrapper as _TextIOWrapper
    from typing import Any as _Any
    from typing import Callable as _Callable
    from typing import Collection as _Collection
    from typing import Generator as _Generator
    from typing import Hashable as _Hashable
    from typing import Literal as _Literal
    from typing import Mapping as _Mapping
    from typing import Optional as _Optional
    from typing import Protocol as _Protocol
    from typing import Tuple as _Tuple
    from typing import Type as _Type
    from typing import Union as _Union
    from typing import cast as _cast
    from unittest import TestCase as _TestCase
    from uuid import UUID as _