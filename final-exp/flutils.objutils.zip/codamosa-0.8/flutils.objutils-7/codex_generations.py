

# Generated at 2022-06-11 22:25:38.940279
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items') is True
    assert has_callables(dict(), 'get', 'keys') is True
    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(), 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'things', 'stuff') is False
    assert has_callables(dict(), 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-11 22:25:41.317762
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-11 22:25:52.060010
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print("\n=== Function has_any_attrs ===")
    attrs = set(['get', 'keys', 'items', 'values', 'something'])
    obj = dict()
    print("obj is dict() and attrs are", attrs)
    for attr in attrs:
        assert has_any_attrs(obj, attr)
    print("PASSED")

# Generated at 2022-06-11 22:26:00.675310
# Unit test for function has_callables
def test_has_callables():
    testobj_a = dict()
    testobj_b = 1
    testobj_c = ['a']
    testobj_d = {'a': 1}
    testobj_e = {'a': 1, 'b': 2}
    testobj_f = {'a': 1, 'b': 2, 'c': 3}
    result_a = has_callables(testobj_a, 'get', 'keys', 'items', 'values')
    result_b = has_callables(testobj_b, 'a', 'b', 'c')
    result_c = has_callables(testobj_c, 'a', 'b', 'c')
    result_d = has_callables(testobj_d, 'get', 'keys', 'items', 'values')

# Generated at 2022-06-11 22:26:05.157960
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables."""

    obj = dict()

    assert has_any_callables(
        obj,
        'get',
        'keys',
        'items',
        'values',
        'something'
    ) is True



# Generated at 2022-06-11 22:26:08.611099
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__init__') == False


# Generated at 2022-06-11 22:26:12.262029
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for function has_attrs."""
    import doctest
    doctest.testmod()
    doctest.run_docstring_examples(has_attrs, globals())


# Generated at 2022-06-11 22:26:22.305228
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for function has_attrs."""

    from itertools import chain
    from flutils.objutils import has_attrs

    x = 'foobar'

# Generated at 2022-06-11 22:26:28.199506
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_attrs(dict(), 'foo')
    assert has_any_attrs(dict(), 'foo', 'bar') is False


# Generated at 2022-06-11 22:26:36.533986
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import has_any_attrs
    from flutils.pyutils import get_callable_name
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(obj, 'foo') is False
    assert has_any_attrs(get_callable_name, '__name__', '__qualname__') is True
    assert has_any_attrs(get_callable_name, '__name__', '__qualname__', 'foo') is True

# Generated at 2022-06-11 22:26:43.434646
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'foo') is False
    assert has_any_callables('foo','upper','lower','strip','trim','count') is True


# Generated at 2022-06-11 22:26:45.586857
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'foo',
    ) == True


# Generated at 2022-06-11 22:26:49.443839
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(),'get','keys','items','something')
    assert has_any_callables(dict(),'foo','bar') is False


# Generated at 2022-06-11 22:26:50.349736
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True



# Generated at 2022-06-11 22:27:02.856013
# Unit test for function has_any_callables
def test_has_any_callables():
    def foo():
        pass

    class Test(object):
        foo = foo

    t = Test()
    assert has_any_callables(t, 'foo', 'bar') is True
    t.foo = 1
    assert has_any_callables(t, 'foo', 'bar') is False
    assert has_any_callables(t, 'bar') is False
    assert has_any_callables(t) is False
    assert has_any_callables(t, '__repr__') is True
    assert has_any_callables(t, '__add__') is True
    assert has_any_callables(t, '__getitem__') is True

    for datatype in (dict, frozenset, int, float, complex, str, list, tuple,
                     set):
        test_obj = dat

# Generated at 2022-06-11 22:27:04.699587
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-11 22:27:14.063196
# Unit test for function has_any_callables
def test_has_any_callables():
    print('Testing has_any_callables')
    foo = dict(a=1, b=2, c=3)
    assert has_any_callables(foo, 'keys', 'values') is True
    assert has_any_callables(foo, 'keys', 'values', 'get') is True
    assert has_any_callables(foo, 'keys', 'values', 'bar') is True
    assert has_any_callables(foo, 'foo', 'bar', 'baz') is False
    assert has_any_callables(foo, 'keys', 'values', 'baz') is True

# Generated at 2022-06-11 22:27:19.074608
# Unit test for function has_callables
def test_has_callables():
    print('Testing has_callables...')
    obj1 = dict(a=1, b=2)
    obj2 = {'a': 1, 'b': 2}
    assert has_callables(obj1, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj2, 'get', 'keys', 'items', 'values') is True
    print('has_callables passed')


# Generated at 2022-06-11 22:27:25.551701
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(obj, 'get', 'foo', 'bar') is True
    assert has_any_callables(obj, 'foo', 'bar', 'baz') is False



# Generated at 2022-06-11 22:27:31.986978
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'foo','bar','baz','qux') == False
    assert has_any_callables(list(),'append','extend','insert','foo') == True
    assert has_any_callables(list(),'foo','bar','baz','qux') == False


# Generated at 2022-06-11 22:27:35.521393
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:27:37.275243
# Unit test for function has_any_callables
def test_has_any_callables():
    print('Testing function has_any_callables')
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-11 22:27:40.910968
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    obj = dict()
    rtn = has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert rtn is True
    rtn = has_any_callables(obj, 'foo')
    assert rtn is False


# Generated at 2022-06-11 22:27:43.204503
# Unit test for function has_callables
def test_has_callables():
    foo = dict()
    assert(has_callables(foo,'get','keys','items','values'))
    return True


# Generated at 2022-06-11 22:27:49.548967
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__doc__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__name__') is False


# Generated at 2022-06-11 22:27:58.311570
# Unit test for function has_attrs
def test_has_attrs():
    """test function has_attrs"""
    from flutils.objutils import has_attrs as ha

    mustfind_attrs = ('get', 'keys', 'items', 'values')
    attrs = ('get', 'keys', 'items', 'values', 'something')
    obj = dict()
    assert ha(obj, *mustfind_attrs) is True, 'in obj should be all attrs'
    assert ha(obj, *attrs) is False, 'in obj should not be attr "something"'
    assert ha(obj, *attrs[:-1]) is True, 'in obj should be attr "values"'



# Generated at 2022-06-11 22:28:04.203996
# Unit test for function has_callables
def test_has_callables():
    print('Function has_callables()')
    class X():
        def __init__(self):
            self.a = 1
            self.b = lambda: True
            self.c = lambda: True
            self.d = False

    x = X()
    print(has_callables(x, 'a','b','c'))
    print(has_callables(x, 'a','c','d'))


# Generated at 2022-06-11 22:28:11.238800
# Unit test for function has_callables
def test_has_callables():
    # noinspection PyShadowingBuiltins
    class foo(object):
        def __init__(self, *args, **kwargs):
            pass

        def bar(self, *args, **kwargs):
            pass

    obj = foo()

    for i in ('baz', 'bar'):
        print(has_callables(obj, i))



# Generated at 2022-06-11 22:28:14.892915
# Unit test for function has_any_callables
def test_has_any_callables():
    assert not has_any_callables(dict(),'x','y')
    assert not has_any_callables(dict(),'keys','y')
    assert has_any_callables(dict(),'keys', 'items')


# Generated at 2022-06-11 22:28:18.617076
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') != False


# Generated at 2022-06-11 22:28:31.955445
# Unit test for function has_any_callables
def test_has_any_callables():
    import unittest

    class Test_has_any_callables(unittest.TestCase):

        def test_has_any_callables(self):
            from flutils.objutils import has_any_callables
            from collections import ValuesView
            obj = dict(a=1, b=2)
            self.assertTrue(
                has_any_callables(obj.keys(), '__init__', 'get', 'values')
            )
            self.assertTrue(
                has_any_callables(obj.keys(), '__init__', 'get', 'items')
            )
            self.assertTrue(
                has_any_callables(obj.keys(), '__init__', 'items', 'values')
            )

# Generated at 2022-06-11 22:28:38.343380
# Unit test for function has_callables
def test_has_callables():

    assert has_callables(dict(), 'get') is False, "has_callables(dict(), 'get')"
    assert has_callables(dict(), 'keys', 'items', 'values') is True, "has_callables(dict(), 'get')"
    assert has_callables(dict(), 'something', 'get') is False, "has_callables(dict(), 'something', 'get')"
    assert has_callables(dict(), 'get', 'keys', 'something', 'values') is True, "has_callables(dict(), 'get', 'keys', 'something', 'values')"
    assert has_callables(dict(), 'something', 'get', 'keys', 'values') is True, "has_callables(dict(), 'something', 'get', 'keys', 'values')"



# Generated at 2022-06-11 22:28:45.623127
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for function has_callables()
    """
    from flutils.objutils import has_callables
    class TestClass:
        def __init__(self, val=6):
            self.val = val

        def sum(self, a, b):
            return self.val + a + b

        @staticmethod
        def mul(a, b):
            return a * b

        @classmethod
        def product(cls, a, b):
            return a * b

    assert has_callables(TestClass(), 'sum', 'mul', 'product')



# Generated at 2022-06-11 22:28:54.949793
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    from flutils.objutils import (
        has_attrs,
        has_callables
    )
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'setdefault')
    assert not has_attrs(UserDict(), 'get', 'keys', 'items', 'values', 'setdefault')
    assert not has_callables(UserDict(), 'get', 'keys', 'items', 'values', 'setdefault')

test_has_callables()

# Generated at 2022-06-11 22:29:05.497898
# Unit test for function has_any_callables
def test_has_any_callables():
    def test_obj():
        def foo(x):
            return x

        def bar(x):
            return x

        def baz(x):
            return x

        return [foo, bar, baz]

    assert has_any_callables(test_obj, 'foo', 'bar', 'baz') is True
    assert has_any_callables(test_obj, 'foo', 'bar', 'quux') is True
    assert has_any_callables(test_obj, 'foo', 'baz', 'asdf') is True
    assert has_any_callables(test_obj, 'baz', 'bar', 'quux') is True
    assert has_any_callables(test_obj, 'bar', 'baz', 'qwerty') is True

# Generated at 2022-06-11 22:29:16.651573
# Unit test for function has_any_callables
def test_has_any_callables():
    '''
    Test for whether or not an object has a callable attribute
    '''
    from collections import Counter, defaultdict, OrderedDict
    from collections.abc import ChainMap, Iterator
    from collections.abc import KeysView, ValuesView
    from decimal import Decimal
    import unittest
    import uuid

    class TestHasAnyCallables(unittest.TestCase):
        '''
        Test whether or not an object has any callable attributes.
        '''

        def test_has_any_callables(self):
            '''
            Test whether or not the has_any_callables function works with
            all types.
            '''
            # Boolean
            self.assertFalse(has_any_callables(True, 'is_integer'))
            # Bytes

# Generated at 2022-06-11 22:29:18.863479
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-11 22:29:20.832648
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')



# Generated at 2022-06-11 22:29:27.563809
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(object(), 'get') is False, 'Callable: None'
    assert has_any_callables(dict(), 'get') is True, 'Callable: Get'
    assert has_any_callables(dict(), 'keys') is True, 'Callable: Keys'
    assert has_any_callables(dict(), 'items') is True, 'Callable: Items'
    assert has_any_callables(dict(), 'values') is True, 'Callable: Values'


# Generated at 2022-06-11 22:29:38.799911
# Unit test for function has_callables
def test_has_callables():
    """Test for function has_callables"""
    from collections import defaultdict
    from collections.abc import (
        MutableMapping,
        Iterable,
    )

    obj = MutableMapping()
    assert has_callables(obj, 'popitem') is True
    assert has_callables(obj, 'popitem', 'items') is True
    obj = defaultdict(lambda x: x)
    assert has_callables(obj, 'popitem', 'items') is True
    assert has_callables(obj, 'popitem', 'items', 'keys') is True
    assert has_callables(obj, 'popitem', 'items', 'keys', 'values') is True

    obj = Iterable()
    assert has_callables(obj, '__contains__', '__getitem__') is True

    obj = set()

# Generated at 2022-06-11 22:29:42.942316
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-11 22:29:54.847633
# Unit test for function has_any_callables
def test_has_any_callables():
    # noinspection PyUnusedLocal
    def func1(param1):
        return True

    # noinspection PyUnusedLocal
    def func2(param1, param2):
        return True

    class Class1(object):
        def func3(self):
            return True

        def func4(self, param2):
            return True

        def func5(self, param1, param2):
            return True

    class Class2(object):
        def func5(self, param1, param2):
            return True

        def func6(self, param1):
            return True

    class OnceCallable(object):
        _called = False

        def func7(self, param1):
            if self._called is False:
                self._called = True
                return True
            return False

    a = 1
   

# Generated at 2022-06-11 22:29:59.123910
# Unit test for function has_any_callables
def test_has_any_callables():

    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:30:04.463625
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'yes', 'no') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get') is False

# Generated at 2022-06-11 22:30:06.525071
# Unit test for function has_any_callables
def test_has_any_callables():
    assert isinstance(has_any_callables(dict(), 'get', 'keys', 'values', 'foo'), bool)



# Generated at 2022-06-11 22:30:16.883995
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables([1, 2, 3], 'append', 'extend', 'insert', 'foo') is True
    assert has_any_callables(set(), 'add', 'clear', 'discard', 'foo') is True
    assert has_any_callables(frozenset(), 'add', 'clear', 'discard', 'foo') is False
    assert has_any_callables('hello', 'capitalize', 'lower', 'upper', 'foo') is True
    assert has_any_callables('hello', 'foo', 'bar', 'baz', 'qux') is False



# Generated at 2022-06-11 22:30:19.855182
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','clear','items') == True
    assert has_any_callables(dict(),'foo','bar') == False


# Generated at 2022-06-11 22:30:31.730378
# Unit test for function has_callables
def test_has_callables():
        class t(object):
            def __init__(self):
                self.name = "t"
                pass
            def get(self):
                return "t"

        class s(t):
            def __init__(self):
                self.name = "s"
                pass
            def get(self):
                return "s"
            def __call__(self):
                return "s"


        # s inherits from t
        if has_callables(s(), 'get') is False:
            raise ValueError
        if has_callables(s(), '__call__') is True:
            raise ValueError
        if has_callables(t(), 'get') is True:
            raise ValueError


# Generated at 2022-06-11 22:30:40.909574
# Unit test for function has_any_callables
def test_has_any_callables():
    # Basic checks
    assert not has_any_callables(dict(), 'get', 'something')
    assert (has_any_callables(dict(), 'get', 'something') ==
            has_any_callables(dict(), 'foo', 'get'))
    assert (has_any_callables(dict(), 'get', 'keys', 'items', 'values') ==
            has_any_callables(dict(), 'get'))
    assert (has_any_callables(dict(), 'get', 'keys', 'items', 'values') !=
            has_any_callables(dict(), 'foo'))

    # Specific checks
    assert has_any_callables(dict(), 'get','keys','items','values','foo')


# Generated at 2022-06-11 22:30:43.033390
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(),'get','keys','items','values')
    assert has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-11 22:30:58.411694
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    from flutils.objutils import (
        has_any_callables,
        has_callables,
        has_any_attrs,
        has_attrs,
    )

    class MyList(list):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.foo = 'hello'
            self.bar = 'world'

        def something(self):
            pass

    my_list = MyList('hello', 'world')

    # Check has_callables

# Generated at 2022-06-11 22:31:00.354583
# Unit test for function has_callables
def test_has_callables():
    fx = has_callables(dict(),'get','keys','items','values')
    assert fx == True

# Generated at 2022-06-11 22:31:04.713754
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'get', 'keys', 'values') == True


# Generated at 2022-06-11 22:31:17.281209
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'keys','items','values') == True
    assert has_any_callables(dict(),'items','values') == True
    assert has_any_callables(dict(),'values') == True
    assert has_any_callables(dict(),'foo') == False
    assert has_any_callables(dict(),'something_else') == False
    assert has_any_callables(dict(),'') == False
    assert has_any_callables(dict(),None) == False
    assert has_any_callables(dict(),0) == False

# Generated at 2022-06-11 22:31:30.585339
# Unit test for function has_callables
def test_has_callables():
    list_1 = [1, 2, 3]
    list_2 = ["a", "b", "c"]
    list_3 = [True, False, False]
    list_4 = [1.1, 2.2, 3.3]
    list_5 = ["a", 2.2, True]

    assert has_callables(list_1, "sort", "reverse", "append")
    assert has_callables(list_2, "sort", "reverse", "append")
    assert has_callables(list_3, "sort", "reverse", "append")
    assert has_callables(list_4, "sort", "reverse", "append")
    assert has_callables(list_5, "sort", "reverse", "append")

test_has_callables()


# Generated at 2022-06-11 22:31:34.839823
# Unit test for function has_callables
def test_has_callables():

    obj = dict(a = 1, b = 2)

    assert has_callables(obj, "values", "keys")

    assert not has_callables(obj, "foo", "bar")


# Generated at 2022-06-11 22:31:37.599560
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:31:42.334679
# Unit test for function has_any_callables
def test_has_any_callables():
    testobj = dict()

    # Test for valid attribute and callable
    assert has_any_callables(testobj, 'get') is True

    # Test for valid attribute but not callable
    assert has_any_callables(testobj, 'get', '__doc__') is False



# Generated at 2022-06-11 22:31:51.421137
# Unit test for function has_any_callables
def test_has_any_callables():
    import unittest
    from flutils.objutils import has_any_callables
    from collections import UserList
    from unittest.mock import Mock


    class A(Mock):
        pass

    class B(Mock):
        pass


    class Test_has_any_callables(unittest.TestCase):

        def test_has_any_callables_false(self):
            A.__module__ = 'module_a'
            B.__module__ = 'module_a'
            self.assertFalse(has_any_callables(A, 'name', 'baz'))

        def test_has_any_callables_true(self):
            A.__module__ = 'module_b'
            B.__module__ = 'module_a'

# Generated at 2022-06-11 22:31:55.949025
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'bat', 'baz') is False


# Generated at 2022-06-11 22:32:05.563245
# Unit test for function has_callables
def test_has_callables():
    a = ['a', 'b', 'c']
    assert has_callables(a, '__getitem__')
    assert not has_callables(a, 'pop')



# Generated at 2022-06-11 22:32:10.099343
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(dict(),'get','keys','items','values') == True)
    assert(has_callables(dict(),'get','keys','items','foo') != True)
    assert(has_callables(dict(),'get','keys','foo','values') != True)


# Generated at 2022-06-11 22:32:18.957152
# Unit test for function has_callables
def test_has_callables():
    # Named tuple test
    Point = namedtuple('Point', ['x', 'y'])
    a = Point(x=11, y=22)
    assert has_callables(a, 'x', 'y'), 'Failed named tuple test'
    # List test
    a = [11, 22]
    assert  has_callables(a, '__getitem__'), 'Failed list test'
    # Dictionary test
    a = {'x': 11, 'y': 22}
    assert  has_callables(a, 'get'), 'Failed dictionary test'
    # Built-in function test
    assert  has_callables(dict, 'fromkeys'), 'Failed built-in function test'

# Generated at 2022-06-11 22:32:23.781765
# Unit test for function has_callables
def test_has_callables():
    class Test(dict):
        def get(self, *args, **kwargs):
            return list()

    obj = Test(a=1, b=2, c=3)
    assert has_callables(obj, 'get') is True



# Generated at 2022-06-11 22:32:33.782145
# Unit test for function has_any_callables
def test_has_any_callables():
    # Verify has_any_callables returns True for two out of three callable
    # attributes
    assert (
        has_any_callables(
            dict(), 'get', 'keys', 'something'
        ) is True
    )
    # Verify has_any_callables returns True for one out of two callable
    # attributes
    assert (
        has_any_callables(
            dict(), 'keys', 'something'
        ) is True
    )
    # Verify has_any_callables returns False for no callable attributes
    assert (
        has_any_callables(dict(), 'something', 'another') is False
    )
    # Verify has_any_callables returns False for no attributes
    assert (
        has_any_callables(dict()) is False
    )
    # Verify has_any_callables returns

# Generated at 2022-06-11 22:32:36.585717
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = [0,1,2,3]
    assert has_any_callables(obj,'count','reverse','insert','index') == True


# Generated at 2022-06-11 22:32:39.210234
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:32:46.969588
# Unit test for function has_callables
def test_has_callables():
    # Pass
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items')
    assert has_callables(dict(), 'get', 'keys')
    assert has_callables(dict(), 'get')
    assert has_callables(dict(), 'keys')
    assert has_callables(dict(), 'values')
    assert has_callables(dict(), 'items')
    assert has_callables(dict(), 'something') is False
    assert has_callables({}, 'get', 'keys', 'items', 'values')
    assert has_callables({}, 'get', 'keys', 'items')
    assert has_callables({}, 'get', 'keys')
    assert has_callables({}, 'get')
    assert has_call

# Generated at 2022-06-11 22:32:57.942854
# Unit test for function has_callables
def test_has_callables():
    import logging
    import pprint
    import unittest
    from typing import Any, Dict
    from unittest.mock import (
        MagicMock,
        patch
    )

    # Set logging to DEBUG to see diagnostic messages
    # logging.basicConfig(level=logging.DEBUG)

    class TestClass():
        def __init__(self, foo: Any) -> None:
            self.foo = foo

        def method1(self) -> Any:
            return self.foo

    class TestClass2(TestClass):
        def __init__(self, foo: Any, bar: Any) -> None:
            TestClass.__init__(self, foo)
            self.bar = bar

        def method1(self) -> Any:
            return self.bar

        def method2(self) -> Any:
            return

# Generated at 2022-06-11 22:33:01.123911
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit Test for function has_any_callables"""
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-11 22:33:15.399341
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(
        dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-11 22:33:20.352181
# Unit test for function has_callables
def test_has_callables():
    obj = {
        "a": 1,
        "b": 2,
        "c": [1, 2, 3],
        "d": {
            "x": "y",
            "z": "1"
        }
    }
    assert has_callables(obj, "get", "items", "values", "keys") is True
    assert has_callables(obj, "get", "values", "keys") is True
    assert has_callables(obj, "get", "values") is True
    assert has_callables(obj, "values") is True

    assert has_callables(obj, "get", "items", "values", "keys", "foo") is False
    assert has_callables(obj, "get", "values", "keys", "foo") is False

# Generated at 2022-06-11 22:33:24.006455
# Unit test for function has_callables
def test_has_callables():
    import operator
    i = operator.itemgetter(1)
    res = has_callables(i,'__call__')
    assert res is True

# Generated at 2022-06-11 22:33:25.962069
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'items', 'values', 'foo') is True


if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-11 22:33:28.758308
# Unit test for function has_callables
def test_has_callables():
    import doctest
    doctest.testmod()
    doctest.run_docstring_examples(has_callables, globals(), verbose=True)



# Generated at 2022-06-11 22:33:33.721050
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'get','keys','items')
    assert not has_callables(dict(),'get')



# Generated at 2022-06-11 22:33:39.990865
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'things', 'values') is False
    assert has_any_callables(dict(), 'foo', 'bar') is False



# Generated at 2022-06-11 22:33:42.177813
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:33:44.590111
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('foo', 'strip', 'split', 'upper') is True



# Generated at 2022-06-11 22:33:54.873940
# Unit test for function has_any_callables
def test_has_any_callables():
    import unittest
    class TestHasAnyCallables(unittest.TestCase):
        def test_has_any_callables(self):
            class Foo(object):
                def __init__(self):
                    self.foo = None
                    self.bar = lambda x: None
            self.assertTrue(has_any_callables(Foo(), 'foo', 'bar'))
            self.assertTrue(has_any_callables(Foo(), 'foo', 'bar', 'unknown'))
            self.assertFalse(has_any_callables(Foo(), 'foo'))
            self.assertFalse(has_any_callables(Foo(), 'foo', 'unknown'))
            self.assertFalse(has_any_callables(Foo(), 'unknown'))
    return TestHasAnyCallables


# Generated at 2022-06-11 22:34:17.212619
# Unit test for function has_callables
def test_has_callables():
    args = ('get', 'keys', 'items', 'values')
    obj = dict()
    assert has_callables(obj, *args)



# Generated at 2022-06-11 22:34:25.826598
# Unit test for function has_any_callables
def test_has_any_callables():
    print('function has_any_callables()')
    print('Test 1: ')
    obj = dict(a=1, b=2)
    attrs = 'get', 'keys', 'items', 'values', 'something'
    print('passed obj', obj, 'and attrs', attrs)
    print('result should be True')
    print('result is: ', has_any_callables(obj, 'get', 'keys', 'items', 'something'))
    print()
    print('Test 2: ')
    obj = dict(a=1, b=2)
    attrs = 'get', 'keys', 'items', 'values', 'something'
    print('passed obj', obj, 'and attrs', attrs)
    print('result should be True')

# Generated at 2022-06-11 22:34:35.147429
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(1, 'foo') == False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_any_callables(dict(), 'keys', 'items', 'values') == True
    assert has_any_callables(dict(), 'foo', 'bar') == False
    assert has_any_callables(dict(), 'foo', 'get') == True


# Generated at 2022-06-11 22:34:38.129457
# Unit test for function has_callables
def test_has_callables():
    '''Test for has_callables function.'''
    from collections.abc import ValuesView
    obj = dict(a=1, b=2)
    assert (has_callables(obj.keys(), '__iter__', '__len__'))

# Generated at 2022-06-11 22:34:44.517995
# Unit test for function has_callables
def test_has_callables():
        # Test Normal cases with dict
        assert has_callables(dict(), 'get', 'keys', 'items', 'values')
        assert has_callables(dict(), 'get', 'keys', 'items')
        assert not has_callables(dict(), 'get', 'keys', 'items', 'foo')
        assert not has_callables(dict(), 'keys', 'items', 'values', 'foo')
        # Test Normal cases with list
        assert has_callables(list(), 'get', 'keys', 'items', 'values')
        assert not has_callables(list(), 'get', 'keys', 'items', 'foo')
        # Test Normal cases with string
        assert has_callables('abcde', 'get', 'keys', 'items', 'values')

# Generated at 2022-06-11 22:34:49.531783
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables.
    """
    print('\ntest_has_any_callables')
    obj = dict()

# Generated at 2022-06-11 22:34:52.644114
# Unit test for function has_callables
def test_has_callables():
    tdict = dict(a=1, b=2)
    assert has_callables(tdict, 'get', 'items', 'keys', 'values') is True



# Generated at 2022-06-11 22:34:55.539721
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values')

# Generated at 2022-06-11 22:35:00.998580
# Unit test for function has_callables
def test_has_callables():
    o = object()
    assert has_callables(dict(), 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault',
                         'update', 'values') == True
    assert has_callables(o, 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault',
                         'update', 'values') == False



# Generated at 2022-06-11 22:35:09.367286
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1,b=2)
    assert has_any_callables(obj,'get')
    assert has_any_callables(obj,'keys')
    assert has_any_callables(obj,'items')
    assert has_any_callables(obj,'values')
    assert has_any_callables(obj,'get','keys','items','values')
    assert has_any_callables(obj,'get','keys','items','values','foo') == False

