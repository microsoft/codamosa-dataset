

# Generated at 2022-06-11 22:25:32.463796
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('a', 'find', 'split')
    assert not has_any_callables('a', 'find', 'foo')



# Generated at 2022-06-11 22:25:36.820713
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'something') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-11 22:25:48.522398
# Unit test for function has_callables
def test_has_callables():
    # Test has_callables with a dict with all of the expected callables
    test_dict = dict(a=1, b=2, c=3, d=4)
    assert has_callables(test_dict, 'get', 'keys', 'items', 'values')

    # Test has_callables with a dict with only one of the expected callables
    test_dict = dict(a=1, b=2, c=3, d=4)
    assert has_callables(test_dict, 'get', 'keys', 'values')

    # Test has_callables with a dict with none of the expected callables
    test_dict = dict(a=1, b=2, c=3, d=4)
    assert not has_callables(test_dict, 'foo', 'bar', 'baz')


# Unit test

# Generated at 2022-06-11 22:25:51.401517
# Unit test for function has_callables
def test_has_callables():
    dct = dict(a=1, b=2)

    result = has_callables(dct, "get", "keys", "items", "values")
    expected = True
    assert result == expected


# Generated at 2022-06-11 22:25:59.718005
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'items', 'values') is True
    assert has_callables({'test': 123}, 'get', 'keys', 'items', 'values') is True
    assert has_callables('test', 'get', 'keys', 'items', 'values') is False
    assert has_callables([1, 2, 3], 'get', 'keys', 'items', 'values') is False
    assert has_callables('test', 'replace', 'split', 'upper') is True
    assert has_callables({}, 'replace', 'split', 'upper') is False
    assert has_callables([1, 2, 3], 'replace', 'split', 'upper') is False



# Generated at 2022-06-11 22:26:08.506959
# Unit test for function has_callables
def test_has_callables():
    assert not has_callables('hello', 'this', 'is', 'a', 'test')
    assert not has_callables({'hello': 'world'}, 'get', 'this', 'is', 'a', 'test')
    assert has_callables({'hello': 'world'}, 'getitem', 'this', 'is', 'a', 'test')
    assert not has_callables({'hello': 'world'}, 'getitem', 'this', 'is', 'a', 'test', 'num')
    assert has_callables({'hello': 'world'}, 'getitem', 'this', 'is', 'a', 'test', 'keys')


# Generated at 2022-06-11 22:26:16.231621
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values') is True
    assert has_any_callables(dict(),'get','keys','items') is True
    assert has_any_callables(dict(),'get','keys') is True
    assert has_any_callables(dict(),'get') is True
    assert has_any_callables(dict(),'get','foo') is False


# Generated at 2022-06-11 22:26:19.862725
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'foo','bar','baz',) is False


# Generated at 2022-06-11 22:26:26.218728
# Unit test for function has_any_callables
def test_has_any_callables():
    # test when given "obj" and "attrs" have no callables
    assert has_any_callables(dict(),'foo') == False
    # test when given "obj" and "attrs" have callables
    assert has_any_callables(dict(a=1, b=2),'get','keys') == True
    # test when given "obj" has no callables
    assert has_any_callables(1234567890,'foo','bar','baz') == False


# Generated at 2022-06-11 22:26:30.566066
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values','__str__')
    assert not has_any_callables(dict(),'get','keys','items','values','__abc')


# Generated at 2022-06-11 22:26:35.893667
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-11 22:26:45.826151
# Unit test for function has_callables
def test_has_callables():
    import collections
    class A(object):
        def get(self):
            return None
        @staticmethod
        def keys():
            return None
        @classmethod
        def items(cls):
            return None
        @property
        def values(self):
            return None

    assert has_callables(collections, 'UserList')
    assert not has_callables(object, 'UserList')
    assert has_callables(A, 'get', 'keys', 'items', 'values')
    assert not has_callables(A, 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-11 22:26:59.081456
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values') \
        is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is \
        False
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'foo') \
        is False

    # Test callables with iterables (list, set, tuple, etc.)
    assert has_callables((), '__contains__', '__iter__', 'index', 'count') is \
        True


# Generated at 2022-06-11 22:27:01.065973
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'values', 'items', 'get') is True



# Generated at 2022-06-11 22:27:04.176484
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'values', 'foo') is False


# Generated at 2022-06-11 22:27:08.011316
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Unit test has_any_callables
    :return:
    """
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:27:18.226893
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for function has_callables

    Returns:
         :obj:`bool`:  Returns True for a passed test, False for a failed test

    """

    required_attributes = ['get', 'keys', 'items', 'values']

    for attr in required_attributes:
        assert hasattr(dict, attr)

    # test that function returns True if all attributes are present and callable
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')

    # test that function returns False if one attribute is not present
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

    # test that function returns False if one attribute is not callable
    assert not has_callables(dict(), 'clear', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:27:21.254481
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get', 'keys', 'values', 'something')



# Generated at 2022-06-11 22:27:31.987590
# Unit test for function has_callables
def test_has_callables():
    from . import is_subclass_of_any
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'foo', 'bar') == False
    assert has_callables(dict(), 'foo', 'values') == False
    assert has_callables([1, 2, 3], 'pop', 'append', 'sort') == True
    assert has_callables([1, 2, 3], 'foo', 'bar') == True  # returns True since the object is list-like
    assert has_callables(1, 'foo', 'bar') == False
    assert has_callables(iter([1, 2, 3]), 'pop', 'append', 'sort') == False
    assert has_callables(iter([1, 2, 3]), 'foo', 'bar') == False

# Generated at 2022-06-11 22:27:33.997923
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something')
    assert not has_any_callables(dict.items,'get','keys','items','values','something')


# Generated at 2022-06-11 22:27:51.378137
# Unit test for function has_callables
def test_has_callables():
    # create a dict object with one value.
    dict1 = {'a': 1}
    # create a dict object with multiple values
    dict2 = {'a': 1, 'b': 2}
    # Check if the dict1 has all the attributes, keys, items and values
    assert has_callables(dict1, 'keys', 'items', 'values') is True
    # Check if the dict2 has all the attributes, keys, items and values
    assert has_callables(dict2, 'keys', 'items', 'values') is True
    # create a list object
    list1 = [1, 2, 3]
    # create a deque object
    deque1 = deque([1, 2, 3])
    # Check if the list1 has all the attributes, append, pop, count

# Generated at 2022-06-11 22:27:57.611556
# Unit test for function has_callables
def test_has_callables():
    class Foo:
        def __init__(self):
            self.bar = None
        def baz(self):
            return True

    test = Foo()
    assert has_callables(test, 'bar', 'baz') is True
    assert has_callables(test, 'bar') is False
    assert has_callables(test, 'bar', 'foo') is False
    assert has_callables(test, 'foo', 'baz') is False


# Generated at 2022-06-11 22:28:06.867021
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo1', 'foo2', 'foo3') is False
    assert has_any_callables(None, 'foo1', 'foo2', 'foo3') is False
    assert has_any_callables(int, 'foo1', 'foo2', 'foo3') is False
    assert has_any_callables(float, 'foo1', 'foo2', 'foo3') is False
    assert has_any_callables(str, 'foo1', 'foo2', 'foo3') is False

# Generated at 2022-06-11 22:28:08.774931
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True

# Generated at 2022-06-11 22:28:12.036830
# Unit test for function has_callables
def test_has_callables():
    expected_result = True
    func_list = ('get', 'keys', 'items', 'values')
    result = has_callables(dict(), *func_list)
    assert result == expected_result
    return

# Generated at 2022-06-11 22:28:19.979192
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a='a', b='b')
    assert has_callables(obj, 'items', 'keys')
    assert not has_callables(obj, 'foo')



# Generated at 2022-06-11 22:28:30.974562
# Unit test for function has_callables
def test_has_callables():
    import pandas as pd
    assert has_callables(pd,['DataFrame','Series','Timestamp'])
    assert has_callables(dict(),'get','keys','items','values','foo')
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(set(),'add','intersection','union','difference')
    assert has_callables(UserList(),'pop','sort')
    assert has_callables([1,2,3], 'sort', 'extend', 'append')
    assert has_callables(deque(), 'append', 'appendleft', 'clear', 'extend', 'popleft')
    assert has_callables(Iterator(), '__next__')
    assert has_callables(ValuesView(), '__iter__')

# Generated at 2022-06-11 22:28:43.823083
# Unit test for function has_callables
def test_has_callables():
    from decimal import Decimal
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from collections.abc import MutableMapping
    from collections.abc import MutableSequence
    import collections.abc
    import collections

    test_dict = dict(
        a = 100,
        b = 'a string'
    )
    test_tuple = (1,1,1)
    test_list = [1,2,3]
    test_none = None
    test_bool = False
    test_bytes = b'foo'
    test_chainmap = ChainMap(test_dict)
    test_counter = Counter({'a':100})
    test_ordereddict = OrderedDict()
    test_user

# Generated at 2022-06-11 22:28:49.911067
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj,'get','keys','items','values','foo') == True

    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'foo') == False

    obj = 123
    assert has_any_callables(obj,'get','keys','items','values','foo') == False


# Generated at 2022-06-11 22:28:52.551145
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    assert has_callables(["1","2","3","4"], "append", "pop", "remove", "index")
    assert has_callables({"1","2","3","4"}, "add", "remove", "difference")


# Generated at 2022-06-11 22:29:06.374039
# Unit test for function has_callables
def test_has_callables():
    obj = dict
    assert (has_callables(obj, 'get', 'keys', 'items', 'values') == True)
 

# Generated at 2022-06-11 22:29:17.062045
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    from unittest import TestCase

    class UD(UserDict):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class T(TestCase):
        def test_has_callables(self):
            d = dict()
            u = UD(dict())
            self.assertTrue(has_callables(d, 'get', 'keys', 'items', 'values'))
            self.assertTrue(has_callables(u, 'get', 'keys', 'items', 'values'))
            self.assertFalse(has_callables(u, 'get', 'keys', 'items', 'values', 'foo'))

# Generated at 2022-06-11 22:29:26.670413
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables.

    Returns:
        :obj:`int`

        0 if successful; 1 if not.
    """
    import sys

    # create a dictionary
    test_dict = {'a': 1, 'b': 2}
    # test if any of the following methods are callable
    if not has_any_callables(test_dict, 'get', 'keys', 'items', 'values',
                             'something'):
        return 1
    # test if any of the following methods are callable
    if has_any_callables(test_dict, 'get', 'something', 'bar'):
        return 1
    # success
    return 0



# Generated at 2022-06-11 22:29:38.025561
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'update')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items') is True
    assert has_callables(dict(), 'get', 'keys') is True
    assert has_callables(dict(), 'get', 'items') is True
    assert has_callables(dict(), 'get', 'values') is True

# Generated at 2022-06-11 22:29:42.827874
# Unit test for function has_any_callables
def test_has_any_callables():
    obj=[1,2]
    assert has_any_callables(obj, 'get', 'keys', 'values', 'append', 'join') == True
    assert has_any_callables(obj, 'get', 'keys', 'values', 'append', 'join', 'foo') == True
    assert has_any_callables(obj, 'get', 'keys', 'values') == False



# Generated at 2022-06-11 22:29:54.758823
# Unit test for function has_callables
def test_has_callables():
    obj = collections.namedtuple('Foo', 'bar')
    assert not has_callables(obj, 'bar')
    assert not has_callables(obj, 'bar', 'baz')
    assert not has_callables(obj, 'bar', '__init__')
    obj = collections.namedtuple('Foo', 'bar bizz buzz')
    assert not has_callables(obj, 'bar')
    assert not has_callables(obj, 'bar', 'bizz')
    assert not has_callables(obj, 'bar', '__init__')
    assert not has_callables(obj, '__init__', 'bizz')
    assert not has_callables(obj, '__init__', 'buzz')
    class Foo(object):
        def bar(self):
            return None
    obj = Foo

# Generated at 2022-06-11 22:29:59.440229
# Unit test for function has_callables
def test_has_callables():
    f = has_callables
    assert not f('', 'a')
    assert f('', '__repr__')
    assert f(lambda x: x, '__call__')
    assert f(list, 'append')
    assert not f(list, 'a')


# Generated at 2022-06-11 22:30:01.990286
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values','foo') == True)


# Generated at 2022-06-11 22:30:04.827560
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'get','keys','items','values','foo')
    assert not has_callables(dict(),'keys','items','values')
    assert not has_callables(dict(),'keys','foo','values')



# Generated at 2022-06-11 22:30:09.864115
# Unit test for function has_any_callables
def test_has_any_callables():
    # Basic functionality test
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    # Test to ensure function uses has_any_attrs as a check first.
    assert has_any_callables(dict(), 'foo', 'bar') is False

# Generated at 2022-06-11 22:30:42.857137
# Unit test for function has_callables
def test_has_callables():
    assert (has_callables(dict(), 'get', 'keys', 'items', 'values')) == True
    assert (has_callables(dict(), 'a', 'keys', 'items', 'values')) == False
    assert (has_callables(dict(), 'a', 'keys', 'items', 'values')) == False
    assert (has_callables({}, 'keys', 'items', 'values')) == True
    assert (has_callables(dict(), 'values', 'keys', 'items')) == True
    assert (has_callables(dict(), 'keys', 'items', 'values')) == True
    assert (has_callables(dict(), 'keys', 'items', 'values', 'get')) == True

# Generated at 2022-06-11 22:30:55.554947
# Unit test for function has_callables
def test_has_callables():
    """Test."""
    obj = dict(
        callable_method=lambda: True,
        str_method='string',
        int_method=1,
        float_method=1.234,
        bool_method=True,
        tuple_method=(1, 2, 3),
        list_method=list(range(10)),
        dict_method=dict(
            callable_method=lambda: True,
            str_method='string',
            int_method=1,
            float_method=1.234,
            bool_method=True,
            tuple_method=(1, 2, 3),
            list_method=list(range(10))
        ),
        set_method={1, 2, 3}
    )

    assert has_callables(obj, 'callable_method') is True
    assert has_call

# Generated at 2022-06-11 22:30:58.549161
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(), 'foo') == False


# Generated at 2022-06-11 22:31:07.401385
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test with a class that has the given items
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    # Test with a class that has none of the given items
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux') is False
    # Test with a class that has none of the given items and a custom item
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux', '__class__') is False
    # Test with a class that has none of the given items and a custom callable item
    assert has_any_callables(type(dict()), 'foo', 'bar', 'baz', 'qux', 'mro') is True
    # Test with a class that has all of

# Generated at 2022-06-11 22:31:11.799138
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'something') is False



# Generated at 2022-06-11 22:31:15.127023
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:31:23.493383
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(True, '__bool__') is True
    assert has_any_callables(False, '__bool__') is True
    assert has_any_callables(dict(), 'get', 'items', 'values', 'keys') is True
    assert has_any_callables(set(), 'add') is True
    assert has_any_callables(tuple(), 'count') is True
    assert has_any_callables(UserList([]), 'append', 'remove') is True
    assert has_any_callables(UserList([]), 'foo', 'bar') is False
    assert has_any_callables(False, 'foo', 'bar') is False
    assert has_any_callables(dict(), 'foo', 'bar') is False

# Generated at 2022-06-11 22:31:34.848098
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList

    class Foo(object):
        @property
        def foo(self):
            return 1

        def bar(self):
            return 2

        def baz(self):
            return 3

    class Bar(UserList):
        @property
        def foo(self):
            return 1

        def bar(self):
            return 2

        def baz(self):
            return 3

    assert has_callables(Foo(), 'bar', 'baz') is True
    assert has_callables(Foo(), 'foo', 'bar', 'baz') is False
    assert has_callables(Bar(), 'bar', 'baz') is True
    assert has_callables(Bar(), 'foo', 'bar', 'baz') is False



# Generated at 2022-06-11 22:31:44.426750
# Unit test for function has_callables
def test_has_callables():
    # Given an object with callables
    obj = dict(a=1, b=2, c=3)
    # When I check if object has callables
    result = has_callables(obj, 'get', 'keys', 'items', 'values')
    # Then I see the result returns True
    assert result is True
    # Given an object with callables
    obj = dict(a=1, b=2, c=3)
    # When I check if object has callables
    result = has_callables(obj, 'get', 'keys', 'items', 'bar')
    # Then I see the result returns False
    assert result is False

# Generated at 2022-06-11 22:31:46.403600
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values')



# Generated at 2022-06-11 22:32:44.862856
# Unit test for function has_callables
def test_has_callables():
    # This is a simple example of how you might write tests to assert that
    # the function and class you are writing are operating exactly as
    # you expect.
    obj = dict(a=1,b=2)
    assert has_callables(obj,'get','keys','items','values')
    assert has_callables(obj,'get')
    assert has_callables(obj,'get','keys')
    assert has_callables(obj,'keys')
    assert has_callables(obj,'values')
    assert has_callables(obj,'items')
    assert has_callables(obj,'set') is False
    assert has_callables(obj,'foo') is False
    assert has_callables(obj,'keys','foo') is False
    assert has_callables(obj,'keys','foo','get','set') is False

# Unit test

# Generated at 2022-06-11 22:32:47.025123
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, "get", "keys", "b") is True



# Generated at 2022-06-11 22:32:50.292162
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(dict(),'get','keys','items','values'))
    assert(not has_callables(dict(), 'get', 'keys', 'items', 'not_values'))
    assert(not has_callables(dict(), 'not_get', 'keys', 'items', 'values'))


# Generated at 2022-06-11 22:32:56.573463
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','bar') == False
    assert has_callables(dict(),'get','keys','bar','foo') == False
    assert has_callables(dict(),'foo','bar','baz','qux') == False


# Generated at 2022-06-11 22:33:00.263099
# Unit test for function has_callables
def test_has_callables():
    # arrange
    full_name = dict(
        first='John',
        middle='Henry',
        last='Doe',
    )

    # act
    result = has_callables(full_name, 'keys', 'items', 'values')

    # assert
    assert result is True


# Generated at 2022-06-11 22:33:12.523300
# Unit test for function has_callables
def test_has_callables():
    """Tests function has_callables
    """
    from flutils.objutils import (
        has_any_callables,
        has_any_attrs,
        has_callables,
        has_attrs
    )

    # Test for non-callable attrs
    dct = {}
    assert (
        has_callables(
            dct,
            "values",
            "pop"
        ) is False
    )
    assert (
        has_any_callables(
            dct,
            "values",
            "pop"
        ) is False
    )

    # Test for callable attrs
    dct = dict(a="a", b="b", c="c")

# Generated at 2022-06-11 22:33:24.774897
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(1, '__int__', '__float__') == False
    assert has_callables(dict(), 'get', 'keys', 'values') is True
    assert has_callables([1, 2, 3], '__iter__', '__contains__') is True
    assert has_callables(set([1, 2, 3]), '__iter__', '__contains__') is True
    assert has_callables(list(range(10)), '__iter__', '__contains__') is True
    assert has_callables(tuple(range(10)), '__iter__', '__contains__') is True
    assert has_callables(reversed(range(10)), '__iter__', '__contains__') is True

# Generated at 2022-06-11 22:33:34.065099
# Unit test for function has_any_callables

# Generated at 2022-06-11 22:33:45.551251
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'items', 'values', 'keys')
    assert has_any_callables(['foo', 'bar', 'baz'], 'append', 'count', 'extend',
                             'index', 'insert', 'pop', 'remove', 'reverse')
    assert has_any_callables(b'', '__add__', 'capitalize', 'center')
    assert has_any_callables(set(), 'add', 'clear', 'difference', 'intersection')
    assert has_any_callables(frozenset(), 'add', 'clear', 'difference',
                             'intersection')
    assert has_any_callables(tuple(), 'count', 'index')

# Generated at 2022-06-11 22:33:55.378702
# Unit test for function has_callables
def test_has_callables():
    from collections.abc import MutableMapping
    assert has_callables(dict(),"get","keys","items","values","pop","popitem")
    assert has_callables(MutableMapping,"get","keys","items","values","pop","popitem")
    assert has_callables({},"get","keys","items","values","pop","popitem")
    assert has_callables([],"append","clear","count","extend","index","insert","pop","remove","reverse","sort")
    assert has_callables(list(),"append","clear","count","extend","index","insert","pop","remove","reverse","sort")