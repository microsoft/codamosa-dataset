

# Generated at 2022-06-11 22:25:36.429563
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items','foo') is False
    assert has_callables(dict(),'get','keys','items') is False


# Generated at 2022-06-11 22:25:38.447315
# Unit test for function has_callables
def test_has_callables():
    class Foo(object):
        def __call__(self):
            return 'bar'

    assert has_callables(Foo(), '__call__') is True



# Generated at 2022-06-11 22:25:42.685715
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values', 'items') == True
    assert has_callables(dict(), 'get', 'keys', 'values', 'items', 'foo') == False



# Generated at 2022-06-11 22:25:52.480869
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-11 22:26:00.938006
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict, ChainMap
    from collections.abc import UserDict, UserString
    from collections import Counter, defaultdict
    from decimal import Decimal
    from flutils.objutils import has_callables as hc

    # None
    assert hc(None, '__abs__') is False

    # dict
    assert hc(dict(), 'get', 'keys', 'items', 'values') is True

    # OrderedDict
    assert hc(OrderedDict(), 'get', 'keys', 'items', 'values') is True

    # ChainMap
    assert hc(ChainMap(), 'get', 'keys', 'items', 'values') is True

    # Counter
    assert hc(Counter(a=1, b=2, c=3), 'get', 'keys', 'items', 'values') is True

# Generated at 2022-06-11 22:26:06.260619
# Unit test for function has_any_callables
def test_has_any_callables():
    class Test:
        def __init__(self):
            self.x = self.y = self.bar = self.foo = None
        def foo(self):
            pass
        def bar(self):
            pass
    assert has_any_callables(Test(),'foo','bar','something','nothing') is True

# Generated at 2022-06-11 22:26:09.361754
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test has_any_callables in objutils."""
    from flutils.objutils import has_any_callables
    assert (has_any_callables(dict(), 'items'))



# Generated at 2022-06-11 22:26:20.530479
# Unit test for function has_any_callables
def test_has_any_callables():
    """Testing has_any_callables."""
    test_dict = dict(foo=1, bar=2)
    # Test with base dictionary
    assert has_any_callables(test_dict, 'get', 'keys', 'values', 'items') == True
    assert has_any_callables(test_dict, 'foo', 'bar', 'baz') == False
    # Test with subclass of dictionary
    class TestDict(dict):
        pass
    test_dict_subclass = TestDict(foo=1, bar=2)
    assert has_any_callables(
        test_dict_subclass, 'get', 'keys', 'values', 'items'
    ) == True
    assert has_any_callables(test_dict_subclass, 'foo', 'bar', 'baz') == False
    del test_

# Generated at 2022-06-11 22:26:27.814970
# Unit test for function has_callables
def test_has_callables():
    cls = classmethod
    obj = lambda: None
    obj.foo = lambda x: None
    obj.bar = cls(lambda x: None)
    obj.baz = cls(lambda x: None, obj)
    assert has_callables(obj, 'foo', 'bar', 'baz')
    assert not has_callables(obj, 'foo', 'bar', 'baz', 'missing')
    assert not has_callables(obj, 'foo', 'bar', 'baz', 'baz')
    assert not has_callables(obj, 'foo', 'bar', 'baz', 'foo')



# Generated at 2022-06-11 22:26:32.418501
# Unit test for function has_any_callables
def test_has_any_callables():
    p = {
        'add': 2,
        'multiply': 3
    }
    import collections
    assert has_any_callables(p,'add','multiply')
    assert has_any_callables(collections.OrderedDict,'add','multiply')
    assert has_any_callables(collections.OrderedDict(), 'add', 'multiply')

# Generated at 2022-06-11 22:26:46.875719
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    from functools import partial
    class DummyClass:
        def __init__(self):
            self.data = OrderedDict()
            self.data['foo'] = partial(self.foo)
            self.data['bar'] = partial(self.bar)
            self.data['baz'] = partial(self.baz)

        def foo(self):
            return self.bar() + 1

        def bar(self):
            return self.baz() + 1

        def baz(self):
            return 1

    obj = DummyClass()
    assert has_callables(obj, 'data', 'foo', 'bar', 'baz')

    assert has_callables(obj.data, 'keys', 'values', 'items')


# Generated at 2022-06-11 22:26:55.623151
# Unit test for function has_callables
def test_has_callables():
    import flutils
    from flutils import objutils
    from flutils.testing import assert_true, assert_false
    obj = flutils.configutils.FrozenDotMap(foo=True, bar=False)
    assert_true(objutils.has_callables(obj, 'get', 'getattr', 'items'))
    assert_false(objutils.has_callables(obj, 'get', 'getattr', 'items', 'foo'))



# Generated at 2022-06-11 22:27:03.032310
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'update','setdefault','pop','popitem','clear','_check_key','_check_mutable')
    assert has_callables(dict(),'update','setdefault','pop','popitem','clear','_check_key')
    assert has_callables(dict(),'update','setdefault','pop','popitem','clear')
    assert not has_callables(dict(),'update','setdefault','pop','popitem','clear','something')
    assert not has_callables(dict(),'update','setdefault','pop','popitem','something')
    assert not has_callables(dict(),'update','setdefault','pop','something')
    assert not has_callables(dict(),'update','setdefault','something')
    assert not has_callables(dict(),'update','something')


# Generated at 2022-06-11 22:27:05.617274
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1, 2, 3], "append", "pop") is True
    assert has_any_callables([1, 2, 3], "find", "pop") is False


# Generated at 2022-06-11 22:27:16.989145
# Unit test for function has_callables
def test_has_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString
    )
    from decimal import Decimal
    from flutils.objutils import has_callables

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(**{'a': 1}), 'get', 'keys', 'items', 'values') \
           is True
    assert has_callables(
        dict(**{'a': 1}),
        'get',
        'keys',
        'items',
        'values',
        'pop',
        'popitem'
    ) is True
    assert has_callables(list(), 'pop', 'extend') is True

# Generated at 2022-06-11 22:27:19.628553
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, '__iter__', 'keys') is True



# Generated at 2022-06-11 22:27:31.337395
# Unit test for function has_callables
def test_has_callables():
    # Test object with attribute that can be called.
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'items')

    # Test object with attribute that cannot be called.
    obj = dict(a=1, b=2)
    assert not has_callables(obj, 'not_callable')

    # Test object with multiple attributes that cannot be called.
    obj = dict(a=1, b=2)
    assert not has_callables(obj, 'not_callable1', 'not_callable2')

    # Test object with multiple attributes that can be called.
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'items', 'get')
    assert not has_callables(obj, 'not_callable1', 'get')

   

# Generated at 2022-06-11 22:27:36.419352
# Unit test for function has_callables
def test_has_callables():
    """ Unit test for function has_callables
    """
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict().keys(),'get','keys','items','values')
    assert has_callables(dict(),'get','values','items','keys') is False
    assert has_callables(dict().keys(),'get','values','items','keys') is False
    assert has_callables(dict().keys(),'get','keys','values','items') is False
    assert has_callables(dict().keys(),'get','values','values','keys') is False


# Generated at 2022-06-11 22:27:38.693951
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({'keys': {'foo': [1, 2, 3]}, 'items': {'foo': [4, 5, 6]}, 'values': {'foo': [7, 8, 9]}}, 'keys', 'items', 'values')


# Generated at 2022-06-11 22:27:47.681398
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import Callable

    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','bar') is False
    assert has_any_callables(int(),'numerator') is True
    assert has_any_callables(int(),'denominator') is False
    assert has_any_callables(Callable,'__call__') is True
    assert has_any_callables(Callable,'__gt__') is False

# Generated at 2022-06-11 22:28:01.112424
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'foo') is True
    assert has_any_callables((1, 2, 3), 'append') is False

# Generated at 2022-06-11 22:28:08.567877
# Unit test for function has_any_callables
def test_has_any_callables():
    import flutils
    assert not has_any_callables(1, "get", "keys", "items", "values", "foo")
    assert not has_any_callables(1.0, "get", "keys", "items", "values", "foo")
    assert not has_any_callables(1j, "get", "keys", "items", "values", "foo")
    assert not has_any_callables(True, "get", "keys", "items", "values", "foo")
    assert not has_any_callables(False, "get", "keys", "items", "values", "foo")
    assert not has_any_callables(True, "get", "keys", "items", "values", "foo")

# Generated at 2022-06-11 22:28:12.501248
# Unit test for function has_any_callables
def test_has_any_callables():
    dct = dict()
    assert has_any_callables(dct, 'get', 'keys', 'values', 'items', 'bar') is True
    assert has_any_callables(dct, 'foo', 'bar') is False


# Generated at 2022-06-11 22:28:20.096838
# Unit test for function has_any_callables
def test_has_any_callables():
    class Class1:
        def foo(self):
            pass

    class Class2:
        def foo(self):
            pass

        def bar(self):
            pass

    class Class3:
        def foo(self):
            pass

        def bar(self):
            pass

        def baz(self):
            pass

    class Class4:
        def foo(self):
            pass

        def bar(self):
            pass

        @staticmethod
        def baz():
            pass

    class Class5:
        def foo(self):
            pass

        def bar(self):
            pass

        @staticmethod
        def baz():
            pass

        def foobar(self):
            pass

    class Class6:
        def foo(self):
            pass

        def bar(self):
            pass


# Generated at 2022-06-11 22:28:22.763548
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('', 'find', 'replace') is True
    assert has_any_callables(dict(), 'keys', 'items', 'values') is True



# Generated at 2022-06-11 22:28:30.577224
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','foo') == False
    assert has_callables(dict(),'get','keys','foo','values') == False
    assert has_callables(dict(),'get','foo','items','values') == False
    assert has_callables(dict(),'foo','keys','items','values') == False
    assert has_callables(dict(),'foo','foo','foo','foo') == False


# Generated at 2022-06-11 22:28:34.022306
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True

# Generated at 2022-06-11 22:28:38.664372
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'bar', 'baz', 'qux', 'quux', 'corge')


# Generated at 2022-06-11 22:28:47.040946
# Unit test for function has_callables
def test_has_callables():
    dummy_obj = Dummy(x=1)
    @add_to_dict(dummy_obj.__dict__)
    def foo():
        return 1

    dummy_obj.x
    dummy_obj.y
    dummy_obj.z
    assert has_callables(dummy_obj, 'x', 'y', 'z') is False
    assert has_callables(dummy_obj, 'y', 'z', 'foo') is True
    assert has_callables(dummy_obj, 'y', 'z', 'foobar') is False
    assert has_callables(dummy_obj, 'y', 'z', 'FOO') is True
    assert has_callables(dummy_obj, 'y', 'z', 'FOOBAR') is False

# Generated at 2022-06-11 22:28:49.538808
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-11 22:28:59.363136
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items','foo') is False


# Generated at 2022-06-11 22:29:12.123108
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import namedtuple
    from functools import partial
    Foo = namedtuple('Foo', ['x', 'y', 'z'])
    Bar = namedtuple('Bar', ['x', 'y'])
    foo = Foo(1, 2, 3)
    bar = Bar(1, 2)
    baz = partial(max, 1)

    assert has_callables(bar, 'x') is False
    assert has_callables(baz, 'x') is False
    assert has_callables(bar, 'x', 'y') is False
    assert has_callables(foo, 'x') is True
    assert has_callables(foo, 'x', 'y') is True

# Generated at 2022-06-11 22:29:16.463944
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables()."""

    # Check that a dictionary has all the callables
    # get, keys, items, values
    test_dict = dict(a=1, b=2, c=3)
    res = has_callables(test_dict, 'get', 'keys', 'items', 'values')
    assert res is True

# Generated at 2022-06-11 22:29:22.000043
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    # Test all of them missing
    assert has_callables(dict(), 'foo', 'bar', 'baz', 'fizz') is False
    # Test some missing
    assert has_callables(dict(), 'get', 'keys', 'items', 'fizz') is False

# Generated at 2022-06-11 22:29:30.428445
# Unit test for function has_callables
def test_has_callables():
    dict_obj = dict(a=1, b=2)
    list_obj = [1, 2, 3]
    funct_obj = lambda x : x+1

    assert has_callables(dict_obj, 'get', 'keys') == True
    assert has_callables(dict_obj, 'get', 'keys', 'values') == True
    assert has_callables(dict_obj, 'get', 'keys', 'foo') == True
    assert has_callables(dict_obj, 'get', 'foo', 'bar') == False
    assert has_callables(list_obj, 'append', 'insert') == True
    assert has_callables(list_obj, 'append', 'insert', 'foo') == True



# Generated at 2022-06-11 22:29:32.384988
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')



# Generated at 2022-06-11 22:29:41.978212
# Unit test for function has_callables
def test_has_callables():
    # Test 1
    _l = [1,2,3]
    assert has_callables(dict(), 'update', 'keys')
    assert not hasattr(dict(), 'foo')
    assert not has_callables(dict(), 'items', 'foo')
    assert not has_callables(dict(), 'foo', 'foo')
    assert hasattr(_l, 'insert')
    assert has_callables(_l, 'insert')
    assert has_callables(_l, 'insert', '__iter__')
    assert has_callables(_l, 'insert', '__iter__', '__len__')
    assert has_callables(_l, 'insert', '__iter__', '__len__', '__getitem__')

# Generated at 2022-06-11 22:29:44.515748
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    obj = OrderedDict()
    assert has_callables(obj, 'get', 'keys', '__getitem__') is True
    assert has_callables(obj, 'get', 'keys', '__getitem__', 'foo') is False
    assert has_callables(obj, 'get', 'foo') is False



# Generated at 2022-06-11 22:29:53.124111
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(), 'append')
    assert has_callables(dict(), 'pop')
    assert has_callables(set(), 'pop')
    assert has_callables('abc', 'replace')
    assert has_callables(dict(), 'get', 'keys') is False
    assert has_callables('abc', 'append') is False
    assert has_callables(set(), 'foo') is False
    assert has_callables(list(), '__len__') is True



# Generated at 2022-06-11 22:30:00.304808
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    from string import ascii_lowercase
    test = defaultdict(lambda:0)
    assert has_callables(test, '__len__','__missing__','__setitem__','__getitem__','__iter__','__contains__','keys','values','items','get','append','update','clear','setdefault','pop','popitem') is True
    assert has_callables(test, '__len__','__missing__','__setitem__','__getitem__','__contains__','keys','values','items','get','append','update','clear','setdefault','pop','popitem') is False

# Generated at 2022-06-11 22:30:10.792275
# Unit test for function has_callables
def test_has_callables():
    d = dict(a=1,b=2)
    assert has_callables(d,'keys','items','values') is True
    assert has_callables(d,'foo') is False



# Generated at 2022-06-11 22:30:12.933952
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:30:21.748327
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    obj = dict()
    assert has_callables(obj, 'get', 'keys', 'items', 'values') == True
    obj = {'foo': []}
    assert has_callables(obj, 'get', 'keys', 'items', 'values') == True
    obj = set()
    assert has_callables(obj, 'get', 'keys', 'items', 'values') == False
    obj = {'foo': ()}
    assert has_callables(obj, 'get', 'keys', 'items', 'values') == True



# Generated at 2022-06-11 22:30:32.384027
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(set(), 'isdisjoint', 'add', 'remove', 'difference') == True
    assert has_callables(set(), 'isdisjoint', 'difference_update', 'add', 'remove') == True
    assert has_callables(dict(), 'clear', 'update', 'get', 'items') == True
    assert has_callables(list(), 'append', 'clear', 'insert', 'remove') == True
    assert has_callables(tuple(), 'clear', 'insert', 'append', 'remove') == True
    assert has_callables(deque(), 'clear', 'insert', 'append', 'remove') == True

if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-11 22:30:41.940239
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','foo') == False
    obj = dict()
    assert has_callables(obj,'get','keys','items','values') == True
    assert has_callables(obj,'get','keys','items','foo') == False
    obj = dict(a=1)
    assert has_callables(obj,'get','keys','items','values') == True
    assert has_callables(obj,'get','keys','items','foo') == False
    obj = dict(a=1, b=2, c=3)
    assert has_callables(obj,'get','keys','items','values') == True
    assert has_callables(obj,'get','keys','items','foo') == False

# Unit

# Generated at 2022-06-11 22:30:54.165380
# Unit test for function has_callables
def test_has_callables():
    from collections import ChainMap
    a = dict()
    b = ChainMap()
    assert has_callables(a, "get", "keys", "items", "values")
    assert has_callables(b, "get", "keys", "items", "values") == False
    assert has_callables(a, "get", "keys", "items", "values", "foo", "bar") is False
    assert has_callables(b, "get", "keys", "items", "values", "foo", "bar") == False
    assert has_callables(a, "get", "keys", "items", "values", "foo", "bar", "nonexistent") is False
    assert has_callables(b, "get", "keys", "items", "values", "foo", "bar", "nonexistent") == False

# Unit

# Generated at 2022-06-11 22:31:03.945888
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from types import SimpleNamespace
    from collections import UserList

    class Mock(object):
        def foo(self):
            pass

    mock = Mock()
    assert has_callables(mock, 'foo', 'bar') is True

    sn = SimpleNamespace()
    assert has_callables(sn, 'foo', 'bar') is False

    ul = UserList()
    assert has_callables(ul, 'append', 'extend') is True

    assert has_callables(mock, 'fake') is False

    assert has_callables(sn, 'fake') is False

    assert has_callables(ul, 'fake') is False

# Generated at 2022-06-11 22:31:16.769269
# Unit test for function has_callables
def test_has_callables():
    import os
    import datetime
    import random
    import re
    import collections
    import operator as ops
    import itertools

    import pytest
    from hypothesis import example, given, strategies as st

    @given(st.lists(st.text()), st.lists(st.text()))
    @example([], [])
    def test_has_callables_obj(given_attrs, missing_attrs):
        obj = os
        assert has_callables(obj, *given_attrs) is True
        assert has_callables(obj, *missing_attrs) is False
        for attr in given_attrs:
            assert hasattr(obj, attr) is True
            assert callable(getattr(obj, attr)) is True
        for attr in missing_attrs:
            assert hasattr

# Generated at 2022-06-11 22:31:18.598706
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-11 22:31:22.316783
# Unit test for function has_callables
def test_has_callables():
    d=dict()
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'something')