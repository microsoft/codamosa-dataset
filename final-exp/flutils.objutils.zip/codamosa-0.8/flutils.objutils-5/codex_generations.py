

# Generated at 2022-06-11 22:25:32.688114
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True

# Generated at 2022-06-11 22:25:40.643984
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables.
    """
    obj = dict(a=1, b=2)
    assert has_any_callables(
        obj,
        'get',
        'foo'
    ) is True
    obj = dict(a=1, b=2)
    assert has_any_callables(
        obj,
        'get',
        'keys'
    ) is True
    obj = dict(a=1, b=2)
    assert has_any_callables(
        obj,
        'foo',
        'bar'
    ) is False



# Generated at 2022-06-11 22:25:41.555803
# Unit test for function has_any_attrs
def test_has_any_attrs():
    pass


# Generated at 2022-06-11 22:25:52.272759
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Tests the function has_any_callables()
    """
    d = dict(a=1, b=2)
    
    # test if dict_keys, dict_values and dict_items exist in the object d
    assert has_any_callables(d, 'keys', 'values', 'items')
    assert has_any_callables(d, 'keys', 'values', 'items') is True
    assert has_any_callables(d, 'keys', 'values', 'items', 'foo') is True
    assert has_any_callables(d, 'keys', 'values', 'items', 'foo', 'bar') is True
    assert has_any_callables(d, 'foo', 'bar') is False
    assert has_any_callables(d, 'foo') is False
    assert has_any_callables

# Generated at 2022-06-11 22:25:55.827788
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import Counter
    from flutils.objutils import has_any_attrs
    # Test 1
    obj = Counter()
    assert has_any_attrs(obj, 'elements', 'most_common') is True




# Generated at 2022-06-11 22:26:08.001083
# Unit test for function has_any_callables
def test_has_any_callables():

    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items') == True
    assert has_any_callables(dict(),'get','keys') == True
    assert has_any_callables(dict(),'get') == True
    assert has_any_callables(dict(),'foo') == False
    assert has_any_callables(dict()) == False

    assert has_any_callables(list(),'append','extend','insert','foo') == True
    assert has_any_callables(list(),'append','extend','insert') == True
    assert has_any_callables(list(),'append','extend')

# Generated at 2022-06-11 22:26:18.432358
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Ensure general dictionary operations are working
    dict_obj = dict(a=1, b=2)
    assert has_any_attrs(dict_obj, 'get', 'keys', 'items', 'values') is True

    # Ensure general list operations are working
    list_obj = [1, 2, 3]
    assert has_any_attrs(list_obj, 'append', 'index', 'insert',
                         'pop', 'remove') is True

    # Ensure general set operations are working
    set_obj = set([1, 2, 3])
    assert has_any_attrs(set_obj, 'add', 'clear', 'copy', 'discard',
                         'pop', 'remove') is True

    # Ensure general tuple operations are working
    tuple_obj = (1, 2, 3)

# Generated at 2022-06-11 22:26:28.119883
# Unit test for function has_any_callables
def test_has_any_callables():
    pass
    ## THIS TEST FAILS BECAUSE OF THE ABOVE ISSUB CLASS

# Generated at 2022-06-11 22:26:31.010857
# Unit test for function has_callables
def test_has_callables():
    # Positive test
    assert has_callables(dict(),'get','keys','items','values')
    # Negative test
    assert not has_callables(list(),'get','append','pop','insert')


# Generated at 2022-06-11 22:26:42.537852
# Unit test for function has_any_callables
def test_has_any_callables():
    _cf = has_any_callables
    assert _cf(dict(),'get','keys','items','values','foo')
    assert _cf(dict().keys(),'get','keys','items','values','foo')
    assert _cf(dict().values(),'get','keys','items','values','foo')
    assert _cf(dict().items(),'get','keys','items','values','foo')
    assert _cf(set([]),'get','keys','items','values','foo')
    assert _cf(frozenset([]),'get','keys','items','values','foo')
    assert _cf(tuple(),'get','keys','items','values','foo')
    assert _cf(deque(),'get','keys','items','values','foo')
    assert _cf(UserList(),'get','keys','items','values','foo')
   

# Generated at 2022-06-11 22:26:58.346520
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict()
    assert has_any_callables(d,'get','keys','items','values','foo') == True
    assert has_any_callables(d,'get','keys','items','values','anything') == True
    assert has_any_callables(d,'get','foo') == True
    assert has_any_callables(d,'foo') == False
    assert has_any_callables(d,'foo','bar','something','get','keys','items','values') == True
    assert has_any_callables(d,'foo','bar','something','anything','something','anything','anything') == True
    assert has_any_callables(d,'foo','bar','something','anything','something','anything','something') == True
    assert has_any_callables(d,'foo','bar','something','anything','something','anything','something') == True

# Generated at 2022-06-11 22:27:00.758680
# Unit test for function has_any_attrs
def test_has_any_attrs():
    dict_ = dict
    assert has_any_attrs(dict_(),'get','keys','items','values','something') == True


# Generated at 2022-06-11 22:27:09.003465
# Unit test for function has_callables
def test_has_callables():
    from types import MethodType
    import pytest
    from flutils.objutils import has_callables

    @staticmethod
    def foo(): pass
    @staticmethod
    def bar(): pass

    @classmethod
    def baz(): pass

    def test_has_callables(test_obj):
        assert has_callables(test_obj, 'foo') is True
        assert has_callables(test_obj, 'foo', 'bar') is True
        assert has_callables(test_obj, 'foo', 'bar', 'baz') is False
        assert has_callables(test_obj, 'foo', 'bar', 'baz', 'foo', 'bar') is True

    @pytest.fixture
    def test_obj():
        return TestObj()


# Generated at 2022-06-11 22:27:10.970279
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','foo') == True)


# Generated at 2022-06-11 22:27:14.067932
# Unit test for function has_any_callables
def test_has_any_callables():
    print("Test has_any_callables")
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'))

# Generated at 2022-06-11 22:27:19.121121
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables('','upper','lower','replace','foo') == True
    assert has_any_callables('','upper','lower','replace','foo','swapcase') == False


# Generated at 2022-06-11 22:27:25.233331
# Unit test for function has_any_callables
def test_has_any_callables():
    print("Unit test for function has_any_callables")
    from flutils.objutils import has_any_callables
    obj = dict(a=1, b=2)
    assert(has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True)



# Generated at 2022-06-11 22:27:29.847750
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(
        dict(),
        'get', 'keys', 'items', 'values', 'something'
    )
    assert has_any_attrs(
        dict(),
        'get', 'keys', 'items', 'values'
    ) is False



# Generated at 2022-06-11 22:27:33.297433
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'pop')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'pop', 'update')


# Generated at 2022-06-11 22:27:37.940256
# Unit test for function has_any_attrs
def test_has_any_attrs():
    'Unit Test for function has_any_attrs'
    assert True == has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert True == has_any_attrs(dict(), 'get', 'keys', 'items', 'values', '__class__')
    assert False == has_any_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert False == has_any_attrs('hello', '__class__', '__len__', '__str__')


# Generated at 2022-06-11 22:27:52.909843
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class A: pass
    class B(A): pass
    class C(B): pass
    a,b,c = A(),B(),C()
    assert      has_any_attrs(a,'func1') is False
    assert      has_any_attrs(b,'func1') is False
    assert      has_any_attrs(c,'func1') is False

    a.func1 = lambda: None
    assert      has_any_attrs(a,'func1') is True
    assert      has_any_attrs(b,'func1') is True
    assert      has_any_attrs(c,'func1') is True

    a.func2 = lambda: None
    assert      has_any_attrs(a,'func1','func2') is True

# Generated at 2022-06-11 22:27:57.438224
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    attrs = ('get', 'values', 'keys', 'items', 'foo')
    assert has_any_callables(obj, *attrs) == True

    obj = dict()
    attrs = ('a', 'b', 'c', 'd', 'e')
    assert has_any_callables(obj, *attrs) == False


# Generated at 2022-06-11 22:28:01.478347
# Unit test for function has_any_callables
def test_has_any_callables():
    test_dict = dict(a=1, b=2)
    if has_any_callables(test_dict, 'foo', 'keys', 'values'):
        pass
    return

test_has_any_callables()


# Generated at 2022-06-11 22:28:03.427093
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-11 22:28:07.049700
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'foo')



# Generated at 2022-06-11 22:28:11.501874
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test has_any_callables function with dict type."""
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'foo')
    assert has_any_callables(dict(), 'foo', 'values')


# Generated at 2022-06-11 22:28:16.431840
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(list(), 'append')
    assert has_callables(None, 'foo') is False
    assert has_callables(list(), 'foo') is False
    assert has_callables(list(), 'append', 'foo') is False


# Generated at 2022-06-11 22:28:24.861041
# Unit test for function has_callables
def test_has_callables():
    class TestClass:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = lambda: None
            self.d = lambda x: x
            self.e = lambda x, y, z: x**2 + y**2 == z**2

    obj = TestClass()
    assert has_callables(obj, 'c', 'd', 'e') is True
    assert has_callables(obj, 'c', 'd') is False
    assert has_callables(obj, 'c') is False



# Generated at 2022-06-11 22:28:30.856719
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert not has_any_callables(dict(),'foo')



# Generated at 2022-06-11 22:28:42.685590
# Unit test for function has_callables
def test_has_callables():
    # Example 1:
    x = dict()
    if has_callables(x, 'keys', 'items', 'values') is True:
        print("Success!")
    else:
        raise AssertionError("Failed!")

    # Example 2:
    x = dict()
    if has_callables(x, 'keys', 'items', 'values', 'foo') is False:
        print("Success!")
    else:
        raise AssertionError("Failed!")

    # Example 3:
    x = dict()
    if has_callables(x, 'foo') is False:
        print("Success!")
    else:
        raise AssertionError("Failed!")



# Generated at 2022-06-11 22:28:58.794275
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import values
    from collections import keys
    from collections import items
    from collections import ChainMap
    class Test:
        def __call__(self):
            return 1
        def some_func(self):
            return 2
        def __iter__(self):
            yield 1
            yield 2
            yield 3
        @staticmethod
        def static_func():
            return 4

    test1 = Test()
    tmap = ChainMap({'a':1},{'b':1})
    tkeys = keys({'a':1,'b':2})
    tvals = values({'a':1,'b':2})
    titems = items({'a':1,'b':2})
    assert has_any_callables(tmap,'get','keys','values','items') == True

# Generated at 2022-06-11 22:29:01.601362
# Unit test for function has_callables
def test_has_callables():
    from . import test_objutils
    assert has_callables(test_objutils.testing_classes.Foo,
                         'bar', 'baz', 'foo', '__str__', '__repr__')

# Generated at 2022-06-11 22:29:03.434182
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('', 'upper', 'lower', 'split', 'foo')



# Generated at 2022-06-11 22:29:14.983261
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','__contains__','__dir__','__doc__','__eq__','__format__','__ge__','__getattribute__','__gt__','__hash__','__init__','__init_subclass__','__le__','__lt__','__ne__','__new__','__reduce__','__reduce_ex__','__repr__','__setattr__','__sizeof__','__str__','__subclasshook__','clear','fromkeys','get','items','keys','pop','popitem','setdefault','update','values')

# Generated at 2022-06-11 22:29:20.043682
# Unit test for function has_callables
def test_has_callables():
    cl = dict()
    assert has_callables(cl, 'get', 'keys', 'items', 'values')  == True
    assert has_callables(cl, 'get1', 'keys', 'items', 'values') == False
    assert has_callables(cl, 'get', 'keys1', 'items', 'values') == False
    assert has_callables(cl, 'get', 'keys', 'items1', 'values') == False
    assert has_callables(cl, 'get', 'keys', 'items', 'values1') == False



# Generated at 2022-06-11 22:29:26.505461
# Unit test for function has_callables
def test_has_callables():
    class MyClass(object):
        def meth(self):
            return 'myclass'

    class MyOtherClass(object):
        def meth(self):
            return 'myotherclass'

    assert has_callables(MyClass, 'meth')
    assert not has_callables(MyOtherClass, 'meth', 'meth2')
    assert has_any_callables(MyOtherClass, 'meth', 'meth2')

# Generated at 2022-06-11 22:29:30.461372
# Unit test for function has_attrs
def test_has_attrs():
    """
    Function has_attrs
    """
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:29:40.816430
# Unit test for function has_any_callables
def test_has_any_callables():
    import functools

    class GetterSetter(object):
        def __init__(self, x = None):
            self.x = x

        def getx(self):
            return self.x

        def setx(self, x):
            self.x = x

    def getx(self):
        return self.x

    def setx(self, x):
        self.x = x

    g = GetterSetter('one')

    assert has_any_callables(g, 'getx', 'something')
    assert has_any_callables(g, 'setx', 'something')
    assert has_any_callables(g, 'getx', 'setx')
    assert has_any_callables(g, 'getx', 'setx', 'something')

    g.getx = functools

# Generated at 2022-06-11 22:29:42.650131
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-11 22:29:45.909264
# Unit test for function has_any_callables
def test_has_any_callables():
    assert True is has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert False is has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert False is has_any_callables(dict(), 'foo')


# Generated at 2022-06-11 22:29:56.612658
# Unit test for function has_callables
def test_has_callables():
    class Test:
        def __init__(self):
            self.func = self.atest
            self.func2 = self.atest2

        def atest(self):
            pass

        @staticmethod
        def atest2():
            pass

    obj = Test()
    if not has_callables(obj, 'func', 'func2'):
        raise AssertionError


# Generated at 2022-06-11 22:30:01.084429
# Unit test for function has_callables
def test_has_callables():
    from collections import namedtuple
    """ has_callables checks that a class or a namedtuple has the correct callable functions """
    MyC = namedtuple('MyC', ['x', 'y'])
    assert has_callables(MyC)
    assert not has_callables(MyC, 'z')

# Generated at 2022-06-11 22:30:02.986674
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')


# Generated at 2022-06-11 22:30:10.727338
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(), 'keys') is True
    assert has_callables(dict(), 'items') is True
    assert has_callables(dict(), 'values') is True
    assert has_callables(dict(), '__contains__') is True
    assert has_callables(dict(), 'get', 'keys') is True
    assert has_callables(dict(), 'get', 'items') is True
    assert has_callables(dict(), 'get', 'values') is True
    assert has_callables(dict(), 'get', 'foo') is False
    assert has_callables(dict(), 'keys', 'items') is True
    assert has_callables(dict(), 'keys', 'values') is True

# Generated at 2022-06-11 22:30:13.343206
# Unit test for function has_callables
def test_has_callables():
    if not has_callables(dict(), 'get', 'keys', 'items', 'values'):
        print("has_callables failed.")


# Generated at 2022-06-11 22:30:23.786216
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values') is True
    assert has_callables(set(), 'add') is True
    assert has_callables(list(), 'append') is True
    assert has_callables((1, 2), 'count') is True
    assert has_callables(deque(), 'append') is True
    assert has_callables(dict().keys(), 'pop') is True
    assert has_callables(dict().values(), 'pop') is True
    assert has_callables(dict().items(), 'pop') is True
    assert has_callables(set().union(), 'pop') is True
    assert has_callables(list().union(), 'pop') is True
    assert has_callables((1, 2).union(), 'pop') is True

# Generated at 2022-06-11 22:30:28.006728
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter
    from flutils.objutils import has_callables

    obj = Counter('hello')
    assert has_callables(obj, 'keys','values','items','most_common','something') is True


# Generated at 2022-06-11 22:30:29.909638
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-11 22:30:32.412093
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get', 'something')



# Generated at 2022-06-11 22:30:33.339411
# Unit test for function has_any_callables
def test_has_any_callables():
    import doctest; doctest.testmod()

# Generated at 2022-06-11 22:30:49.033462
# Unit test for function has_callables
def test_has_callables():
    if has_callables(dict(),'get','keys','items','values') is True:
        print("has_callables: Pass")
    else:
        print("has_callables: Fail")

# Generated at 2022-06-11 22:30:53.578419
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables."""
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False



# Generated at 2022-06-11 22:30:57.715327
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test case for has_any_callables"""
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'get', 'keys', 'items') is True



# Generated at 2022-06-11 22:31:06.922029
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from .base import BaseObj
    from .utils import PrintObj

    obj = BaseObj(name='foo')
    assert has_callables(obj, 'foo') is not True
    assert has_callables(obj, 'foo', 'foo') is not True
    assert has_callables(obj, 'foo', 'print_obj') is not True
    assert has_callables(obj, 'print_obj', 'foo') is not True
    assert has_callables(obj, 'print_obj', 'foo', 'text') is not True
    assert has_callables(obj, 'print_obj', 'foo', 'text', 'foo') is not True

    assert has_callables(obj, 'foo', 'print_obj', 'text') is not True

# Generated at 2022-06-11 22:31:10.411892
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values')


# Generated at 2022-06-11 22:31:15.338104
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'foo')



# Generated at 2022-06-11 22:31:23.721937
# Unit test for function has_callables
def test_has_callables():
    from collections.abc import Mapping, Sequence, Sized
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(str(), 'lower', 'upper', 'capitalize')
    assert has_callables([1, 2, 3, 4, 5], 'count', 'index')
    assert has_callables(frozenset(), 'union', 'difference', 'intersection')
    assert has_callables(set(['a', 'b', 'c']), 'union', 'difference', 'intersection')
    assert has_callables(deque(['a', 'b', 'c']), 'append',
                         'pop', 'extend', 'count', 'index')
    assert has_callables(b'ABC', 'lower', 'upper', 'capitalize')
    assert has

# Generated at 2022-06-11 22:31:28.789832
# Unit test for function has_attrs
def test_has_attrs():
    """Test the function has_attrs"""
    assert (has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something'))


if __name__ == '__main__':
    # do some simple tests
    test_has_attrs()

# Generated at 2022-06-11 22:31:31.969503
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values','foo') == True)


# Generated at 2022-06-11 22:31:35.136735
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','something') == False


# Generated at 2022-06-11 22:32:22.823526
# Unit test for function has_callables
def test_has_callables():
    return


"""DisabledContent
"""

# Generated at 2022-06-11 22:32:29.205877
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'foo')
    assert not has_any_callables(dict(),'foo1')


# Generated at 2022-06-11 22:32:32.193281
# Unit test for function has_any_callables
def test_has_any_callables():
    print("Testing has_any_callables.")
    d = {}
    assert has_any_callables(d, '__getitem__','__setitem__','__delitem__','__iter__','keys','values','items')


# Generated at 2022-06-11 22:32:36.535387
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'items') is True
    assert has_callables({}, 'get', 'items', 'keys', 'values') is True
    assert has_callables({}, '__init__', '__iter__', '__next__') is False



# Generated at 2022-06-11 22:32:47.847060
# Unit test for function has_any_callables
def test_has_any_callables():
    _obj = {}
    _attrs = ('get','keys','items','values','blah')
    _expected = True
    _result = has_any_callables(_obj,*_attrs)
    assert _result == _expected, ('has_any_callables({},{})={}\nexpected={}'
                                  .format(_obj,_attrs,_result,_expected))
    #
    _obj = {}
    _attrs = ('blah', 'blah2')
    _expected = False
    _result = has_any_callables(_obj, *_attrs)
    assert _result == _expected, ('has_any_callables({},{})={}\nexpected={}'
                                  .format(_obj, _attrs, _result, _expected))
    #
    _obj = {}
    _attrs

# Generated at 2022-06-11 22:32:50.154801
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys') == True
    #assert has_callables({},'get','keys','foo') == False


# Generated at 2022-06-11 22:33:00.932404
# Unit test for function has_callables
def test_has_callables():
    import collections
    import numbers
    from collections.abc import Mapping

    obj = dict(a=1, b=2, c=3)
    assert has_callables(obj, 'get', 'items') == True
    assert has_callables(obj, 'keys', 'values') == True
    assert has_callables(obj, 'number', 'something') == False
    assert has_callables(obj, 'get', 'items', 'keys', 'values') == True

    obj = list(obj.values())
    assert has_callables(obj, 'append') == True
    assert has_callables(obj, 'pop') == True
    assert has_callables(obj, 'add') == False

    obj = reversed(list(obj))
    assert has_callables(obj, 'append') == False
    assert has_callables

# Generated at 2022-06-11 22:33:10.750602
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'values')
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values')
    assert not has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_callables(dict(a=1, b=2), 'get', 'keys', 'foo', 'values')



# Generated at 2022-06-11 22:33:14.032123
# Unit test for function has_any_callables
def test_has_any_callables():
    _dict = dict(a='a', b='b', c='c')
    _result = has_any_callables(_dict, 'get', 'keys', 'values', 'something')
    assert _result is True, '_result should be True'


# Generated at 2022-06-11 22:33:24.223233
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables.

    Checks if dict(), list() and str() have the proper attributes.

    Raises:
        AssertionError: If test fails
    """
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'something') is False
    assert has_callables(list(), 'append', 'count', 'sort', 'something') is False
    assert has_callables(str(), 'count', 'startswith', 'join', 'endswith') is True


# Generated at 2022-06-11 22:34:16.438727
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get', 'keys', 'values', 'items')
    assert has_any_callables({}.values(), 'get', 'keys', 'values', 'items')
    assert has_any_callables(
        dict(a=1, b=2, c=3), 'get', 'keys', 'values', 'items')
    assert has_any_callables({}, 'get', 'keys', 'values', 'items') is True
    assert has_any_callables({}.values(), 'get', 'keys', 'values', 'items') is True
    assert has_any_callables(
        dict(a=1, b=2, c=3), 'get', 'keys', 'values', 'items') is True

# Generated at 2022-06-11 22:34:18.968161
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'does_not_exist','foo') == False
    assert has_any_callables(dict(),'get','keys','items','values','get') == True


# Generated at 2022-06-11 22:34:22.439442
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values2', 'foo') is False



# Generated at 2022-06-11 22:34:26.649682
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'append') is True
    assert has_any_callables(dict(), 'foo', 'bar') is False



# Generated at 2022-06-11 22:34:38.349113
# Unit test for function has_any_callables
def test_has_any_callables():
    class A:
        def __getitem__(self, item):
            pass

    class B:
        def __getitem__(self, item):
            pass

        @property
        def get(self):
            pass

    class C:
        @property
        def get(self):
            pass

    class D:
        pass

    a = A()
    b = B()
    c = C()
    d = D()

    assert has_any_callables(a, 'get') is False
    assert has_any_callables(b, 'get') is True
    assert has_any_callables(c, 'get') is True
    assert has_any_callables(d, 'get') is False

# Generated at 2022-06-11 22:34:42.457771
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(
        dict,
        'get', 'keys', 'items', 'values'
    ) is True



# Generated at 2022-06-11 22:34:44.976441
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:34:51.917522
# Unit test for function has_callables
def test_has_callables():
    assert has_callables([1, 2, 3], '__len__', 'append') == True
    assert has_callables(set([1, 2, 3]), '__len__', 'add') == True
    assert has_callables(frozenset([1, 2, 3]), '__len__', 'add') == False
    assert has_callables(dict(a=1, b=2, c=3), '__len__', 'get') == True
    assert has_callables(dict(a=1, b=2, c=3), '__len__', 'update') == True
    assert has_callables(dict(a=1, b=2, c=3), '__len__', 'something') == False
    assert has_callables(True, '__len__', 'append') == False
    assert has_

# Generated at 2022-06-11 22:35:02.323305
# Unit test for function has_any_callables
def test_has_any_callables():
    """Nose unit test for has_any_callables.

    Notes:
        Test coverage is 100%
    """
    from unittest import TestCase, TestLoader, TextTestRunner
    from flutils.objutils import has_any_callables

    class TestHasAnyCallables(TestCase):

        def test_has_any_callables(self):
            dict_obj = dict()
            self.assertTrue(has_any_callables(
                dict_obj,
                'get',
                'keys',
                'items',
                'values',
                'pop',
                'popitem',
                'clear',
                'update',
                'setdefault',
                'fromkeys',
                'copy'
            ))


    loader = TestLoader()

# Generated at 2022-06-11 22:35:08.768304
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'items', 'keys', 'values') is True
    assert has_callables(dict(), 'get', 'items', 'keys', 'value') is False
    assert has_callables(dict(), 'get', 'item', 'key', 'values') is False
    assert has_callables(dict(), 'get', 'item', 'key', 'value') is False

