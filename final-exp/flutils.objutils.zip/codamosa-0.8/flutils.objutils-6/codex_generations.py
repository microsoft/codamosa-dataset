

# Generated at 2022-06-11 22:25:41.726147
# Unit test for function has_any_callables
def test_has_any_callables():
    '''Test function has_any_callables'''
    dict1 = dict()
    dict2 = dict(a=1, b=2)
    assert has_any_callables(dict1, 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict2, 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict2, 'get', 'keys', 'items', 'values', 'pop') == True
    assert has_any_callables(dict2, 'get', 'keys', 'items', 'values', 'pop', '__getitem__') == True

# Generated at 2022-06-11 22:25:52.367559
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    from collections import ChainMap
    from functools import partial
    from collections.abc import KeysView
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'values') is True
    assert has_any_callables(obj, 'get', 'keys', 'nonexistent') is True
    assert has_any_callables(obj, 'get', 'nonexistent', 'nonexistent2') is True
    assert has_any_callables(obj, 'nonexistent', 'nonexistent2') is False
    assert has_any_callables(ChainMap(), 'get', 'keys', 'values') is True
    assert has_any_callables(ChainMap(), 'get', 'keys', 'nonexistent') is True
    assert has_any

# Generated at 2022-06-11 22:25:55.916778
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'keys', 'items', 'values') is True


# Generated at 2022-06-11 22:25:58.336934
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'values')


# Generated at 2022-06-11 22:26:08.980421
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo')
    assert has_any_attrs(dict(),'get','foo','items','values','foo')
    assert has_any_attrs(dict(),'get','keys','items','values','foo')
    assert has_any_attrs(dict(),'get','keys','foo','values','foo')
    assert has_any_attrs(dict(),'get','keys','items','values','foo')
    assert has_any_attrs(dict(),'keys','items','values','foo')
    assert has_any_attrs(dict(),'foo','items','values','foo')
    assert has_any_attrs(dict(),'keys','items','values','foo')
    assert has_any_attrs(dict(),'keys','items','foo','foo')


# Generated at 2022-06-11 22:26:19.727894
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'keys') is True
    assert has_callables(obj, 'keys', 'keys') is True
    assert has_callables(obj, 'keys', 'values') is True
    assert has_callables(obj, 'keys', 'values', 'values') is True
    assert has_callables(obj, 'keys', 'values', 'values', 'items') is True
    assert has_callables(obj, 'keys', 'values', 'values', 'items', 'foo') is False
    assert has_callables(obj, 'foo') is False
    assert has_callables(obj, 'foo', 'foo') is False
    assert has_callables(obj, 'foo', 'bar') is False
    assert has_callables(obj, 'foo', 'bar', 'baz')

# Generated at 2022-06-11 22:26:25.244754
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('12345', '__setitem__', '__add__')
    assert has_any_callables(12345, '__setitem__', '__add__')
    assert has_any_callables(b'12345', '__setitem__', '__add__')
    assert has_any_callables(12345, '__add__')


# Generated at 2022-06-11 22:26:29.091272
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')==True
    assert has_any_callables(dict(),'foo')==False
    assert has_any_callables('foo','get')==False


# Generated at 2022-06-11 22:26:30.833280
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-11 22:26:33.923721
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'bar') is True
    assert has_any_callables(dict(), 'keys', 'bar', 'foo') is True


# Generated at 2022-06-11 22:26:45.102120
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import deque
    from functools import partial
    class foo(object):
        def bar(self):
            pass
        @staticmethod
        def baz():
            pass
    assert has_any_callables(foo(),'bar','baz') # pylint: disable=no-value-for-parameter
    assert has_any_callables(deque(),"append","pop")
    assert has_any_callables(partial(lambda: None),"__call__")


# Generated at 2022-06-11 22:26:56.584596
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_callables(
        dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(a=1, b=2, foo='bar'),
                         'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-11 22:27:03.536226
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(foo=1), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(foo=1), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:27:07.668427
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert not has_any_callables(dict(),'foo','blah')


# Generated at 2022-06-11 22:27:09.990767
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'items') == True


# Generated at 2022-06-11 22:27:19.662713
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'copy')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'fromkeys')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'update')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'popitem')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'pop')



# Generated at 2022-06-11 22:27:27.864110
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserDict
    obj1 = dict()
    obj2 = UserDict()
    assert has_any_callables(obj1, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(obj2, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(obj1, 'get', 'keys', 'items', 'values', 'foo', 'bar')


# Generated at 2022-06-11 22:27:28.451215
# Unit test for function has_any_callables
def test_has_any_callables():
    pass

# Generated at 2022-06-11 22:27:32.914312
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        from flutils.objutils import has_any_callables
    except Exception as err:
        print(err)
        assert False

    testobj = dict(a=1, b=2)
    tst = has_any_callables(testobj, 'get', 'keys', 'items', 'values')
    assert tst == True, 'has_any_callables failed'

    tst = has_any_callables(testobj, 'get', 'keys', 'items', 'values', 'foo')
    assert tst == True, 'has_any_callables failed'
    return


# Generated at 2022-06-11 22:27:36.155576
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar','baz','foobar','foobaz') == False
    #assert has_any_callables(dict(),'foo','bar','baz') == False


# Generated at 2022-06-11 22:27:41.710467
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-11 22:27:45.785702
# Unit test for function has_any_callables
def test_has_any_callables():
    obj=dict()
    assert has_any_callables(obj,'get','keys','items','values','foo')


# Generated at 2022-06-11 22:27:53.629153
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(UserList(),'append','extend','insert')
    assert has_any_callables(ChainMap(),'new_child','parents','maps','get')
    assert has_any_callables(Counter(),'most_common','update','subtract')
    assert has_any_callables(OrderedDict(),'fromkeys','popitem','move_to_end')
    assert not has_any_callables(None, 'fromkeys', 'popitem', 'move_to_end')
    assert has_any_callables(UserDict(),'clear','items','keys')
    assert has_any_callables(deque(),'append','appendleft','extend')

# Generated at 2022-06-11 22:28:02.478110
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print(has_any_attrs(dict(), 'get', 'keys', 'items', 'values', ''))

    # Unit test for function has_any_callables
    def test_has_any_callables():
        print(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'))

    # Unit test for function has_attrs
    def test_has_attrs():
        print(has_attrs(dict(), 'get', 'keys', 'items', 'values'))

    # Unit test for function has_callables
    def test_has_callables():
        print(has_callables(dict(), 'get', 'keys', 'items', 'values'))

    # Unit test for function is_list_like

# Generated at 2022-06-11 22:28:15.274908
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables(__name__, 'foo') is False
    assert has_any_callables(__name__, 'replace')

# Generated at 2022-06-11 22:28:26.359366
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values', '__getitem__') is True
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values', '__getitem__', 'foo') is False
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(a=1, b=2), 'foo', 'bar') is False
    assert has_callables(dict(a=1, b=2)) is False

# Generated at 2022-06-11 22:28:31.891836
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'), \
        'has_any_callables(dict(), "get", "keys", "items", "values", "foo") should be True'
    assert not has_any_callables(dict(), 'something', 'foobar', 'foofoo'), \
        'has_any_callables(dict(), "something", "foobar", "foofoo") should be False'



# Generated at 2022-06-11 22:28:38.280734
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test for correct output
    def foo(): True
    assert has_any_callables(dict(),'get','keys','items','foo')
    assert has_any_callables(dict(),'get','foo')
    assert not has_any_callables(dict(),'foo')
    assert has_any_callables(dict(a=1,b=2),'values')
    assert has_any_callables(frozenset([1,2,3]),'pop')
    assert has_any_callables(locals(),'pop')
    assert has_any_callables(locals(),'pop','keys')
    assert has_any_callables(locals(),'keys','pop')
    assert not has_any_callables(locals(),'keys','pop','foo')

# Generated at 2022-06-11 22:28:46.001847
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'nocycle', 'keys', 'items', 'values') is False
    assert has_callables(dict(), 'get', 'nocycle', 'items', 'values') is False
    assert has_callables(dict(), 'get', 'keys', 'nocycle', 'values') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'nocycle') is False
    assert has_callables(dict(), 'nocycle', 'nocycle', 'nocycle', 'nocycle') is False


# Generated at 2022-06-11 22:28:56.493679
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__init__') is True
    assert has_any_callables(dict(), '__init__', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__init__') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False


# Generated at 2022-06-11 22:29:05.252369
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(),'get','keys','items','values','something')
    assert has_any_callables(dict(),'get','keys','items','values','__init__')


# Generated at 2022-06-11 22:29:12.461145
# Unit test for function has_callables
def test_has_callables():
    # Test positive
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    # Test negative
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == False
    # Test negative
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == False


# Generated at 2022-06-11 22:29:15.267574
# Unit test for function has_callables
def test_has_callables():
    # Test begins
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'get','keys','items','values','foo')
    assert not has_callables(dict(),'foo')

# Generated at 2022-06-11 22:29:21.449247
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo', 'bar') is True



# Generated at 2022-06-11 22:29:24.332455
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-11 22:29:33.349310
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables('string', 'upper', 'lower', 'split')
    assert has_any_callables((1, 2, 3), 'append', 'extend', 'insert') is False
    assert has_any_callables(1, 'append', 'extend', 'insert') is False
    assert has_any_callables(True, 'append', 'extend', 'insert') is False


# Generated at 2022-06-11 22:29:42.709245
# Unit test for function has_any_attrs
def test_has_any_attrs():
    ''' Test :func:`~flutils.objutils.has_any_attrs`

    Execute:
        >>> from flutils.objutils import test_has_any_attrs
        >>> test_has_any_attrs()

    Returns:
        :obj:`bool`: :obj:`True` if all tests succeed, :obj:`False` otherwise.
    '''
    from copy import deepcopy
    from flutils.objutils import has_any_attrs
    from flutils.tests.utils import run_tests

    # Test has_any_attrs with a list
    tests = [
        {'name': 'Does list have any of attrs?',
         'func': has_any_attrs,
         'args': [list(), 'pop', 'append'],
         'return': True},
    ]

# Generated at 2022-06-11 22:29:45.194226
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'update') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-11 22:29:47.904481
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'something')


# Generated at 2022-06-11 22:29:53.853615
# Unit test for function has_any_callables
def test_has_any_callables():
    o1 = dict()
    o2 = dict(a=1, b=2)
    o3 = 'hello'

    assert has_any_callables(o1) is True
    assert has_any_callables(o2) is True
    assert has_any_callables(o3) is False



# Generated at 2022-06-11 22:30:05.448869
# Unit test for function has_any_callables
def test_has_any_callables():
    """Function to test `has_any_callables`"""
    assert has_any_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'foo',
        'bar',
    ) is True
    assert has_any_callables(dict(),) is False


# Generated at 2022-06-11 22:30:10.349108
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','foo') == False
    assert has_callables(dict(),'foo','bar','hello') == False


# Generated at 2022-06-11 22:30:12.933756
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj,'get','keys','items','values')


# Unit test function has_any_callables

# Generated at 2022-06-11 22:30:23.496530
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserDict, ChainMap
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(list(), 'append', 'count', 'index', 'insert', 'foo')
    assert has_any_callables(set(), 'add', 'clear', 'copy', 'difference', 'foo')
    assert has_any_callables(frozenset(), 'issubset', 'issuperset', 'union', 'foo')
    assert has_any_callables(UserDict(), 'setdefault', 'update', 'popitem', 'foo')
    assert has_any_callables(ChainMap(), 'new_child', 'pop', 'maps', 'foo')

# Unit test

# Generated at 2022-06-11 22:30:27.282044
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'foo', 'values') is False

# Generated at 2022-06-11 22:30:30.510452
# Unit test for function has_callables
def test_has_callables():
    test_obj1 = {'my_key': 'my_value'}
    test_obj2 = dict(a=1, b=2, c=3)

    print(has_callables(test_obj1, 'get'))
    print(has_callables(test_obj2, ))

# Generated at 2022-06-11 22:30:33.256560
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert (has_callables(obj,'keys','items','values') == True)


# Generated at 2022-06-11 22:30:42.893583
# Unit test for function has_any_callables
def test_has_any_callables():
    def has_any_callables_helper(obj, *attrs):
        try:
            assert has_any_callables(obj, *attrs) == True
        except AssertionError as e:
            print(f'{obj} failed: FAILURE: {e}')
        else:
            print(f'{obj} failed: SUCCESS')

    def has_any_callables_helper_none(obj, *attrs):
        for attr in attrs:
            try:
                assert has_any_callables(obj, *attrs) == False
            except AssertionError as e:
                print(f'{obj} failed: FAILURE: {e}')
            else:
                print(f'{obj} failed: SUCCESS')

    s = set()
    d = dict

# Generated at 2022-06-11 22:30:45.098979
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'clear', 'pop', 'foo') is False



# Generated at 2022-06-11 22:30:49.451200
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values', 'items') is True
    assert has_callables(dict(), 'get', 'keys', 'values', 'foo') is False



# Generated at 2022-06-11 22:31:05.224895
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    obj = dict(
        key=lambda: None,
        val=2
    )
    assert has_any_callables(obj, 'val', 'key') is True
    assert has_any_callables(obj, 'key', 'val') is True
    assert has_any_callables(obj, 'val', 'foo') is True
    assert has_any_callables(obj, 'foo', 'val') is True
    assert has_any_callables(obj, 'foo', 'bar') is False



# Generated at 2022-06-11 22:31:06.988545
# Unit test for function has_any_callables
def test_has_any_callables():
  assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:31:14.059419
# Unit test for function has_callables
def test_has_callables():
    from flutils import objutils
    class Test():
        def __init__(self):
            self.is_callable = True

        def testfunc(self):
            return 'test'

    x = Test()
    assert objutils.has_callables(x, 'testfunc')

    objutils.has_callables(x, 'testfunc', 'is_callable')



# Generated at 2022-06-11 22:31:22.683453
# Unit test for function has_any_callables
def test_has_any_callables():
        s = 'hello world'
        d = dict(
            a=1,
            b=2,
            c=3,
        )
        assert has_any_callables(s,'lower','upper','something_else')
        assert has_any_callables(d,'values','keys','items')
        assert has_any_callables(d,'get')
        assert has_any_callables(d,'something_else')
        assert has_any_callables(d,'something_else','get')
        assert has_any_callables(d,'get','something_else')
        assert has_any_callables(d,'get','foo')
        assert has_any_callables(d,('get','foo'))
        assert has_any_callables(d,('foo','get'))
        assert has_any_callables

# Generated at 2022-06-11 22:31:27.153530
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-11 22:31:30.003304
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'resize', 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')


# Generated at 2022-06-11 22:31:39.526205
# Unit test for function has_callables
def test_has_callables():
    import inspect
    import pdb

    assert has_callables(dict, 'get', 'keys', 'items', 'values')

    assert has_callables(
        dict,
        *[x for x, _ in inspect.getmembers(dict, inspect.isfunction)
          if not x.startswith('_')]
    )

    assert has_callables(set, 'add', 'update', 'remove', 'union', 'clear')

    assert has_callables(
        set,
        *[x for x, _ in inspect.getmembers(set, inspect.isfunction)
          if not x.startswith('_')]
    )

    assert has_callables(list, 'append', 'sort', 'insert', 'remove', 'clear')


# Generated at 2022-06-11 22:31:41.868293
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-11 22:31:47.876640
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict, 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict, 'keys', 'items', 'values') is True



# Generated at 2022-06-11 22:31:50.613549
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import ChainMap
    assert has_any_callables(ChainMap(), 'get', 'keys', 'items') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items') is True



# Generated at 2022-06-11 22:32:18.586898
# Unit test for function has_any_callables
def test_has_any_callables():
    class testclass:
        def __init__(self):
            self.foo = 'foo'
            self.bar = lambda:None
        def spam(self):
            return 'spam'

    assert has_any_callables(testclass(), 'foo', 'bar', 'spam') == True
    assert has_any_callables(testclass(), 'foo', 'bar', 'baz') == True
    assert has_any_callables(testclass(), 'bar', 'spam') == True
    assert has_any_callables(testclass(), 'foo', 'bar') == True

    # Test no args
    assert has_any_callables(testclass()) == False

    # Test bad args
    try:
        has_any_callables(testclass(), None)
    except TypeError:
        pass

# Generated at 2022-06-11 22:32:22.233420
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter
    assert has_callables(Counter(), 'get', 'keys', 'most_common') == True
    assert has_callables(Counter(), 'get', 'keys', 'most_common', 'not_there') == False


# Generated at 2022-06-11 22:32:25.297043
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:32:29.401902
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(dict(),'get','keys','items','values'))
    assert(has_callables(dict(),'__contains__'))
    assert(has_callables(set(),'isdisjoint'))
    assert(has_callables(set(),'symmetric_difference'))
    assert(has_callables(frozenset(),'difference'))
    assert(has_callables(tuple(),'index'))
    assert(has_callables(tuple(),'count'))
    assert(has_callables(list(),'reverse'))
    assert(has_callables(list(),'copy'))
    assert(has_callables(deque(),'extend'))
    assert(has_callables(deque(),'appendleft'))

# Generated at 2022-06-11 22:32:36.247152
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_callable = dict()
    dict_callable["get"] = lambda: 0
    dict_callable["keys"] = lambda: 0
    dict_callable["values"] = lambda: 0
    dict_callable["items"] = lambda: 0
    dict_callable["something"] = 100

    dict_notcallable = dict()
    dict_notcallable["get"] = lambda: 0
    dict_notcallable["keys"] = lambda: 0
    dict_notcallable["values"] = lambda: 0
    dict_notcallable["items"] = lambda: 0
    dict_notcallable["something"] = 100

    assert has_any_callables(dict_callable, "foo") == True
    assert has_any_callables(dict_notcallable, "something") == False
    assert has_any_callables

# Generated at 2022-06-11 22:32:43.356333
# Unit test for function has_callables
def test_has_callables():
    from mock import Mock
    obj = Mock(spec=['my_callable', 'my_not_callable'])
    obj.my_callable = Mock(return_value=False)
    obj.my_not_callable = False
    assert has_callables(obj, 'my_callable')
    assert not has_callables(obj, 'my_callable', 'my_not_callable')



# Generated at 2022-06-11 22:32:46.236252
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True, \
        'has_any_callables() failed!'


# Generated at 2022-06-11 22:32:57.441321
# Unit test for function has_callables
def test_has_callables():
    # Test with a dict with all keys being callable
    obj1 = dict()
    obj1['keys'] = obj1.keys
    obj1['values'] = obj1.values
    obj1['items'] = obj1.items
    assert has_callables(obj1, 'keys', 'values', 'items') is True

    # Test with a dict with a non-callable key, then one of the keys is not
    # callable, so this test should fail
    obj2 = dict()
    obj2['keys'] = obj2.keys
    obj2['values'] = obj2.values
    obj2['items'] = 'items'
    assert has_callables(obj2, 'keys', 'values', 'items') is False

    # Test with a dict with keys missing, so this test should fail
    obj3 = dict()
   

# Generated at 2022-06-11 22:33:04.840004
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(), 'keys') is True
    assert has_callables(dict(), 'values') is True
    assert has_callables(dict(), 'pop') is True
    assert has_callables(dict(), 'popitem') is True
    assert has_callables(dict(), 'clear') is True
    assert has_callables(dict(), 'update') is True
    assert has_callables(dict(), 'items') is True
    assert has_callables(dict(), '__setitem__') is True
    assert has_callables(dict(), '__delitem__') is True
    assert has_callables(dict(), '__getitem__') is True
    assert has_callables(dict(), '__contains__') is True
    assert has_callables

# Generated at 2022-06-11 22:33:11.698820
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items') == True
    assert has_any_callables(dict(),'keys','items') == True
    assert has_any_callables(dict(),'keys') == True
    assert has_any_callables(dict(),'foo') == False
