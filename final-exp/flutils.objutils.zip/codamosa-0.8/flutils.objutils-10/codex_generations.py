

# Generated at 2022-06-11 22:25:35.229152
# Unit test for function has_any_callables
def test_has_any_callables():
    from . import TestObj
    from types import MethodType
    obj = TestObj()
    result = has_any_callables(TestObj, 'private', 'public', 'private_meth')
    assert result is True
    result = has_any_callables(obj, 'private', 'public', 'private_meth')
    assert result is True
    result = has_any_callables(obj, 'private', 'public', 'private_meth', 'something')
    assert result is False
    obj.private_meth = 'hello'
    result = has_any_callables(obj, 'private_meth')
    assert result is False
    obj.private_meth = MethodType(lambda x: None, obj)
    result = has_any_callables(obj, 'private_meth')
    assert result is True


# Generated at 2022-06-11 22:25:37.595710
# Unit test for function has_callables
def test_has_callables():
    assert True == has_callables(
        dict(), 'get', 'keys', 'items', 'values'
    )



# Generated at 2022-06-11 22:25:41.821098
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(a=1, b=2, c=3), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', bar='baz')

# Generated at 2022-06-11 22:25:47.818190
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'setdefault', 'keys', 'items', 'values')


# Generated at 2022-06-11 22:25:53.703727
# Unit test for function has_any_callables
def test_has_any_callables():
    dict = dict(a = 1, b = 2)
    assert has_any_callables(dict, 'get', 'keys', 'items', 'values') == True
    assert has_any_callables(dict, 'get', 'keys', 'items', 'values', 'somthing') == True
    assert has_any_callables(dict, 'get', 'keys', 'items', 'values', 'somthing1') == False


# Generated at 2022-06-11 22:25:57.121086
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False



# Generated at 2022-06-11 22:26:01.941380
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj, 'nothing') is False



# Generated at 2022-06-11 22:26:03.503047
# Unit test for function has_callables
def test_has_callables():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-11 22:26:07.388926
# Unit test for function has_callables
def test_has_callables():
    # Test callable
    assert has_callables(dict, '__init__', '__contains__') is True
    # Test not callable
    assert has_callables(dict, '__init__', 'a', 'b') is False


# Generated at 2022-06-11 22:26:14.109917
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'keys','items','values','get','something') is True
    assert has_callables(dict(),'keys','items','values') is True
    assert has_callables(dict(),'callable') is False
    assert has_callables(dict(),'get') is True
    assert has_callables(dict(),'notacallable') is False
    assert has_callables(dict(a=1,b=2),'items') is True


# Generated at 2022-06-11 22:26:26.068284
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables('a', 'upper', 'lower', 'capitalize', 'foo')
    assert has_any_callables(str, 'upper', 'lower', 'capitalize', 'foo')
    assert not has_any_callables('a', 'upper', 'lower', 'capitalize', 'foo', 'biz')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'biz')
    assert not has_any_callables(str, 'upper', 'lower', 'capitalize', 'foo', 'biz')



# Generated at 2022-06-11 22:26:33.177224
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'values', 'something') is True
    assert has_any_callables(dict(), 'keys', 'values', 'something') is True
    assert has_any_callables(dict(), 'keys', 'values', 'something') is True

    assert has_any_callables(dict(), 'something', 'somethingelse') is False
    assert has_any_callables(dict(), 'something', 'somethingelse') is False
    assert has_any_callables(dict(), 'something', 'somethingelse') is False


# Generated at 2022-06-11 22:26:35.893844
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables


# Generated at 2022-06-11 22:26:44.797702
# Unit test for function has_any_callables
def test_has_any_callables():
    '''Test the has_any_callables function.'''
    test_obj = dict(a=1, b=2)
    test_attrs = ('get', 'keys', 'values', 'items', 'foo')
    test_pass = has_any_callables(test_obj, *test_attrs)
    assert test_pass is True
    test_obj = 2
    test_fail = has_any_callables(test_obj, *test_attrs)
    assert test_fail is False


# Generated at 2022-06-11 22:26:57.833538
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(), 'keys', 'values', 'items', 'get')
    assert has_any_callables(dict(), 'something', 'someotherthing') is False
    assert has_any_callables(list(), 'append', 'pop')
    assert has_any_callables(set(), 'add', 'difference')
    assert has_any_callables(object(), 'something', 'someotherthing') is False
    assert has_any_callables(None, 'get', 'keys', 'items', 'values') is False
    assert has_any_callables(b'\x00', 'decode', 'encode') is False
    assert has_any_callables(1, '__add__', '__sub__') is False
    assert has

# Generated at 2022-06-11 22:27:05.163324
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'keys','items','values','foo') == False
    assert has_any_callables(set(),'get','keys','items',' values','foo') == False
    assert has_any_callables(set(),'keys','items','values','clear','foo') == True
    assert has_any_callables({}, 'get', 'keys', 'items', 'values','clear','foo') == False
    assert has_any_callables({}, 'keys', 'items', 'values', 'clear','foo') == False


# Generated at 2022-06-11 22:27:08.401608
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-11 22:27:10.356130
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:27:13.681668
# Unit test for function has_any_callables
def test_has_any_callables():
    # Arrange
    obj = dict()

    # Act
    result = has_any_callables(obj, 'get', 'keys', 'items', 'values')

    # Assert
    assert result


# Generated at 2022-06-11 22:27:21.480361
# Unit test for function has_any_callables
def test_has_any_callables():
    obj1 = dict()
    obj2 = list()
    obj3 = set()
    obj4 = tuple()
    obj5 = frozenset()
    obj6 = 1
    obj7 = 'foo'
    obj8 = b'bar'
    assert has_any_callables(obj1,'get','keys','items','values') == True
    assert has_any_callables(obj2,'get','keys','items','values') == False
    assert has_any_callables(obj3,'get','keys','items','values') == False
    assert has_any_callables(obj4,'get','keys','items','values') == False
    assert has_any_callables(obj5,'get','keys','items','values') == False
    assert has_any_callables(obj6,'get','keys','items','values') == False
   

# Generated at 2022-06-11 22:27:33.056793
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    from . import (
        has_any_callables,
    )
    from .. import (
        get_regex_dict as _get_regex_dict,
        get_regex_tuple as _get_regex_tuple,
    )

    obj = dict(a=1, b=2)

    tests = (
        (_get_regex_dict('get'), obj, True),
        (_get_regex_tuple(('get', 'keys')), obj, True),
        (_get_regex_dict('foo'), obj, False),
        (_get_regex_tuple(('foo', 'bar')), obj, False),
    )
    for attrs, obj, expected in tests:
        result = has_any_callables(obj, **attrs)

# Generated at 2022-06-11 22:27:35.685843
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values',
                             'something') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values',
                             'something') is True



# Generated at 2022-06-11 22:27:39.435742
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import UserDict, Mapping

    foo = UserDict()
    foo.bar = lambda x: x
    bar = Mapping()
    bar.baz = lambda x: x

    # Check for single object with single attribute
    assert has_callables(foo,'bar')
    with pytest.raises(AssertionError):
        assert not has_callables(foo,'baz')
    with pytest.raises(AssertionError):
        assert not has_callables(bar,'baz')

    # Check for single object with multiple attributes
    assert has_callables(foo,'bar','data')
    with pytest.raises(AssertionError):
        assert not has_callables(foo,'bar','baz')

# Generated at 2022-06-11 22:27:41.709417
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:27:47.190057
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Unit test for function has_any_callables
    """
    x = 'this'
    assert has_any_callables(x, 'join', 'split')
    assert not has_any_callables(x, 'toList', 'time')



# Generated at 2022-06-11 22:27:53.832388
# Unit test for function has_callables
def test_has_callables():
    testObj = dict(a=1, b=2)
    attrs = ('keys', '__setitem__')
    testResult = has_callables(testObj, *attrs)
    assert testResult == True
    attrs2 = ('keys', '__setitem__', 'foo')
    testResult2 = has_callables(testObj, *attrs2)
    assert testResult2 == False


# Generated at 2022-06-11 22:28:02.601155
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables"""

    # noinspection PyTypeChecker
    d = dict(a=1, b=2, c=3)
    assert has_callables(d, 'get', 'keys', 'items', 'values')

    # noinspection PyTypeChecker
    d = dict(a=1, b=2, c=3)
    assert has_callables(d, 'get', 'keys', 'foo', 'items', 'values')

    # noinspection PyTypeChecker
    d = dict(a=1, b=2, c=3)
    assert has_callables(d, 'foo', 'keys', 'items', 'values')

    # noinspection PyTypeChecker
    d = dict(a=1, b=2, c=3)
    assert has_callables

# Generated at 2022-06-11 22:28:04.067997
# Unit test for function has_callables
def test_has_callables():
    pass


# Generated at 2022-06-11 22:28:10.088625
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')

# Generated at 2022-06-11 22:28:13.618688
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'keys', 'values', 'items', 'foo') is True


# Generated at 2022-06-11 22:28:17.519512
# Unit test for function has_any_callables
def test_has_any_callables():
    if has_any_callables(dict(),'get','keys','items','values','something') is False:
        raise AssertionError('has_any_callables is not working')

# Unit Test for function has_any_attrs

# Generated at 2022-06-11 22:28:19.400616
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') == True


# Generated at 2022-06-11 22:28:22.021932
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'keys','items') is False


# Generated at 2022-06-11 22:28:24.809963
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True



# Generated at 2022-06-11 22:28:28.338108
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'something','bar','f00','what','yup') == False

# Generated at 2022-06-11 22:28:32.368522
# Unit test for function has_any_callables
def test_has_any_callables():
    assert not has_any_callables(dict(), 'foo')
    assert has_any_callables(dict(), 'get')
    assert has_any_callables(dict(), 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'foo', 'bar')
    assert has_any_callables(dict(), 'get', 'foo')


# Generated at 2022-06-11 22:28:44.354720
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList
    from collections.abc import KeysView
    from string import ascii_letters
    from random import randint, choice
    from flutils.objutils import has_callables
    for i in range(10000):
        if i <= 1000:
            obj = KeysView((i for i in ascii_letters))
            assert has_callables(obj, '__len__', '__iter__', '__contains__')
        if i > 1000 and i <= 2000:
            obj = UserList((i for i in ascii_letters))
            assert has_callables(obj, '__len__', '__iter__', '__contains__')

# Generated at 2022-06-11 22:28:56.846684
# Unit test for function has_callables
def test_has_callables():
    from collections import (
        UserDict,
        UserList,
    )

    class MyObject(object):
        def __init__(self) -> None:
            pass

        def do_something(self) -> bool:
            return True

    my_obj = MyObject()
    ud = UserDict()
    ul = UserList()

    assert has_callables(my_obj, 'do_something') is True
    assert has_callables(ud, 'keys', 'items', 'values') is True
    assert has_callables(ul, 'insert', 'extend', 'append') is True
    assert has_callables(my_obj, 'foo', 'bar') is False



# Generated at 2022-06-11 22:29:04.796573
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit testing for :obj:`has_any_callables`."""
    obj = {"get": lambda x: x, "keys": [1, 2, 3], "foo": lambda x: x + 1,
           "bar": "foo", "values": None}
    assert has_any_callables(obj, "get", "keys", "items", "values", "foo") == \
                        True, "Failed to recognize any callables"
    assert has_any_callables(obj, "get", "keys", "items", "values", "bar") == \
                        False, "Failed to recognize no callables"



# Generated at 2022-06-11 22:29:07.002792
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something')


# Generated at 2022-06-11 22:29:15.123292
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar') is False
    assert has_any_callables(None, 'foo', 'bar') is False


# Generated at 2022-06-11 22:29:17.892649
# Unit test for function has_any_callables
def test_has_any_callables():
    class Obj:
        def foo(self):
            pass

        def bar(self):
            pass

    obj = Obj()
    out = has_any_callables(obj, 'foo', 'bar')
    assert out is True



# Generated at 2022-06-11 22:29:28.002430
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict, defaultdict, OrderedDict
    from collections.abc import UserDict as UserDictABC
    from typing import Any
    def assert_is_a_dict(type, **kwargs):
        test_dict = type(**kwargs)
        assert has_callables(test_dict, 'get', 'keys', 'items', 'values') is True
        assert has_attrs(test_dict, 'get', 'keys', 'items', 'values') is True
        assert has_callables(test_dict, 'foo') is False
        assert has_attrs(test_dict, 'foo') is False

    def assert_is_not_a_dict(type, **kwargs):
        test_dict = type(**kwargs)
        assert has_callables(test_dict, 'foo') is False

# Generated at 2022-06-11 22:29:30.371734
# Unit test for function has_callables
def test_has_callables():
    expected = True
    actual = has_callables({}, 'get', 'keys')
    assert expected == actual


# Generated at 2022-06-11 22:29:32.345689
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    assert has_callables("", "upper")


# Generated at 2022-06-11 22:29:36.390240
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')


# Generated at 2022-06-11 22:29:38.461969
# Unit test for function has_callables
def test_has_callables():
    w = WeakValueDictionary()
    assert has_callables(w, "setdefault", "popitem", "__getitem__") == True

# Generated at 2022-06-11 22:29:43.655145
# Unit test for function has_callables
def test_has_callables():
    from pytest import raises

    with raises(TypeError) as excinfo:
        has_callables('hello','upper','split')
    assert "obj is not callable." in str(excinfo.value)

    with raises(AttributeError) as excinfo:
        has_callables([1,2,3,4],'foo','bar')
    assert "has no attribute 'foo'." in str(excinfo.value)


# Generated at 2022-06-11 22:29:55.515310
# Unit test for function has_any_callables
def test_has_any_callables():
    import unittest
    import random
    import string
    import collections.abc
    
    # Create a random string for testing purposes
    teststring = ''.join(random.choice(string.ascii_lowercase) for _ in range(10))
    # Set the Base Class and test function
    Base = collections.abc.Container
    testfunc = has_any_callables
    
    # Create a dummy class with no functions, inherit from base
    class sub1(Base):
        def __init__(self, str1):
            self.str1 = str1

    obj1 = sub1(teststring)
    # Check that the test fails on missing function
    with unittest.TestCase() as test:
        test.assertFalse(testfunc(obj1, '__contains__'))

    # Create a dummy class with one

# Generated at 2022-06-11 22:29:58.141227
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:30:07.053019
# Unit test for function has_callables
def test_has_callables():
    """
    >>> from flutils.objutils import has_callables
    """
    assert True == has_callables(dict(),'get','keys','items','values')
    assert False == has_callables(dict(),'get','keys','items','values','foo')
    # check that returning False when missing any of the required callables
    assert False == has_callables(dict(),'keys','items','values')


# Generated at 2022-06-11 22:30:09.970301
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1,b=2)
    assert has_callables(obj,'keys','items','values','get')


# Generated at 2022-06-11 22:30:12.180296
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:30:18.136818
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(
        a=1,
        b=2,
        c=3
    )
    assert has_any_callables(obj, 'keys', 'items') is True
    assert has_any_callables(obj, 'keys', 'values') is True
    assert has_any_callables(obj, 'keys', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(obj, 'keys', 'values', 'foo', 'bar', 'baz', 'syd') is False


# Generated at 2022-06-11 22:30:25.973938
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables({'foo':1,'bar':2},'get','keys','items','values')
    assert has_any_callables({'foo':1,'bar':2}, 'items')
    assert has_any_callables({'foo':1,'bar':2}, 'get')
    assert has_any_callables('hello world!', 'replace')
    assert has_any_callables('hello world!', 'upper')
    assert not has_any_callables('hello world!', 'foo')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(1.0, 'foo')


# Generated at 2022-06-11 22:30:34.138320
# Unit test for function has_callables
def test_has_callables():
    obj_list = [
        dict,
        list,
        bool,
        int,
        float
    ]
    attr_list = [
        'append',
        'clear',
        'copy',
        'extend',
        'index',
        'insert',
        'pop',
        'remove',
        'reverse',
        'sort'
    ]
    for obj in obj_list:
        for attr in attr_list:
            if has_callables(obj, attr):
                pass
            else:
                assert False, 'method has_callables() does not work'


# Generated at 2022-06-11 22:30:43.533330
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import Counter
    from decimal import Decimal
    from typing import ChainMap
    TestList = [
        (dict(), ['get', 'keys', 'items', 'values']),
        (dict(), ['get', 'keys', 'items']),
        (dict(), ['get', 'keys', 'items', 'values', 'foo']),
        (dict(), ['foo']),
        (Counter(), ['get', 'keys', 'items', 'values']),
        (Decimal(345.34), ['check']),
    ]
    ExpectedList = [
        True,
        False,
        False,
        False
    ]
    assert has_callables(TestList[0][0], *TestList[0][1]) == ExpectedList[0]

# Generated at 2022-06-11 22:30:45.810272
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True



# Generated at 2022-06-11 22:30:58.548480
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__setitem__') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'clear') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'keys') is True
    assert has_callables(dict(), 'get', 'items', 'values', 'clear') is True
    assert has_callables(dict(), 'get', 'keys', 'items', '__setitem__') is True

# Generated at 2022-06-11 22:31:07.401792
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert has_any_callables(dict()) == False
    assert has_any_callables(None) == False
    assert has_any_callables(dict().keys(),'get','keys','items','values','foo')
    assert has_any_callables(dict().keys(),'get','keys','items','values')
    assert has_any_callables(dict().keys(),'get','keys','items')
    assert has_any_call

# Generated at 2022-06-11 22:31:17.787482
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values',
                             'something') is True



# Generated at 2022-06-11 22:31:29.446974
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('', '__str__', 'format') is True
    assert has_any_callables((), '__str__', 'format') is True
    assert has_any_callables({}, '__str__', 'format') is True
    assert has_any_callables(dict(), '__str__', 'format') is True
    assert has_any_callables(dict(a=1), '__str__', 'format') is True
    assert has_any_callables(0, '__str__', 'format') is True
    assert has_any_callables(dict(a=1), '__str__', 'format', 'test') is False


# Generated at 2022-06-11 22:31:35.583724
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(
        foo=lambda x:x,
    )
    assert has_any_callables(obj, 'foo', 'bar', 'baz') is True
    assert has_any_callables(obj, 'bar', 'baz') is False
    assert has_any_callables(obj, 'bar') is False



# Generated at 2022-06-11 22:31:48.609611
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import UserList
    from decimal import Decimal
    from typing import List
    from uuid import UUID
    obj_dict = dict(a=1, b=2)
    obj_dict_keys = obj_dict.keys()
    obj_dict_values = obj_dict.values()
    obj_generator = (x for x in obj_dict.keys())
    obj_list = list(obj_dict.keys())
    obj_list_of_dict = [dict(a=1), dict(b=2)]
    obj_list_of_literal = [1, 2]
    obj_list_of_list = [[1, 2], [2, 3]]

# Generated at 2022-06-11 22:31:52.047928
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar') is False

# Generated at 2022-06-11 22:32:03.263486
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict, ChainMap
    from decimal import Decimal
    for c in (
        None, True, False,
        OrderedDict([('a', 1), ('b', 2)]),
        ChainMap(dict(a=1, b=2)),
        Decimal('3.14'), 1, 3.14,
        'hello', [1, 2, 3], (1, 2, 3),
        b'hello', (1, 2, 3), bytes(3),
    ):
        assert has_any_callables(c, 'get', 'keys', 'items', 'values') is True
    for c in (
        {}, set(), frozenset(),
    ):
        assert has_any_callables(c, 'get', 'keys', 'items', 'values') is False


# Generated at 2022-06-11 22:32:08.664519
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items','values','foo') is False
    assert has_callables(dict(),'get','keys','items','values','__init__') is True


# Generated at 2022-06-11 22:32:18.304751
# Unit test for function has_callables
def test_has_callables():
    """Unit test function for function has_callables."""
    import unittest

    class TestHasCallables(unittest.TestCase):
        """Test class for function has_callables."""

        def test_string(self):
            """Test a string as input."""
            output = has_callables('foo', 'foo')
            self.assertEqual(output, False)

        def test_dict(self):
            """Test a dict as input."""
            output = has_callables(dict(), 'get', 'keys', 'items', 'values')
            self.assertEqual(output, True)

    unittest.main(module='test_has_callables', verbosity=2, exit=False)



# Generated at 2022-06-11 22:32:25.766752
# Unit test for function has_callables
def test_has_callables():
    #positive test case
    class TestExample:
        def __init__(self):
            pass
        def create(self):
            return "hi"
    obj = TestExample()
    assert(has_callables(obj,'create') is True)
    #negative test case
    class TestExample:
        def __init__(self):
            pass
    obj = TestExample()
    assert(has_callables(obj,'create') is False)


# Generated at 2022-06-11 22:32:32.193885
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    class MyDict(UserDict):
        pass
    mydict = MyDict(foo=1)
    assert has_callables(mydict, 'foo') == True
    mydict.foo = lambda: 1
    assert has_callables(mydict, 'foo') == True
    mydict.foo = 1
    assert has_callables(mydict, 'foo') == False


# Generated at 2022-06-11 22:32:53.902255
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(a=1)
    assert has_any_callables(d, 'get', 'keys', 'values') is True
    assert has_any_callables(d, 'foo', 'bar', 'baz') is False


# Generated at 2022-06-11 22:32:59.911373
# Unit test for function has_callables
def test_has_callables():
    class C(object):
        def method(self):
            pass
        @classmethod
        def classmtd(cls):
            pass
        @staticmethod
        def staticmtd():
            pass
        @property
        def prop(self):
            pass
    c = C()
    assert has_callables(c, 'method', 'classmtd', 'staticmtd', 'prop') is True

# Generated at 2022-06-11 22:33:06.332482
# Unit test for function has_callables
def test_has_callables():

    class TestClass:
        def __init__(self, name):
            self.name = name

        def get(self):
            return self.name

    obj = TestClass("foo")
    assert has_callables(obj, 'get')

    assert not has_callables(obj, 'name')



# Generated at 2022-06-11 22:33:08.328139
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:33:16.598704
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), '__iter__', '__contains__', '__getitem__')
    assert not has_callables(
        dict(__getitem__=None), '__iter__', '__contains__', '__getitem__')
    assert not has_callables(
        dict(__iter__=None), '__iter__', '__contains__', '__getitem__')
    assert not has_callables(
        dict(__contains__=None), '__iter__', '__contains__', '__getitem__')
    assert not has_callables(('', '', ''), '__iter__', '__contains__', '__getitem__')

# Generated at 2022-06-11 22:33:18.901571
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-11 22:33:22.541448
# Unit test for function has_callables
def test_has_callables():
    print(has_callables(dict(),'get','keys','items','values'))


if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-11 22:33:32.751661
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'bar') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'bar') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-11 22:33:43.629975
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables.
    """
    import unittest

    class HasCallablesTest(unittest.TestCase):
        """Unit test for the function has_callables.
        """

        def test_has_callables(self):
            """Test has_callables.
            """
            from collections import OrderedDict
            from flutils.objutils import has_callables

            obj = OrderedDict([('a', 1), ('b', 2)])
            self.assertTrue(has_callables(obj, 'keys', 'items', 'values'))

            obj = dict([('a', 1), ('b', 2)])
            self.assertTrue(has_callables(obj, 'keys', 'items', 'values'))

            obj = OrderedDict()

# Generated at 2022-06-11 22:33:45.981642
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
