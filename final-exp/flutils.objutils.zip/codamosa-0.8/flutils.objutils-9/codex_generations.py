

# Generated at 2022-06-11 22:25:34.604966
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test case for has_any_callables"""
    class Foo(object):
        def bar(self):
            pass
        def __call__(self):
            pass
    a = Foo()
    assert has_any_callables(a, 'bar', 'baz') is True
    assert has_any_callables(a, 'bar', 'baz', '__call__') is True
    assert has_any_callables(a, 'bar', 'baz', 'call') is True
    assert has_any_callables(a, 'bar', 'baz', '__call__', 'call') is True



# Generated at 2022-06-11 22:25:41.053773
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict().get, 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict().items, 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict().values, 'get', 'keys', 'items', 'values')
    assert has_any_callables(list().count, 'count', 'index', 'foo', 'bar') is False
    assert has_any_callables(list().index, 'count', 'index', 'foo', 'bar')

# Generated at 2022-06-11 22:25:51.851979
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert False is has_any_callables(dict(), 'get', 'keys', 'items', 'values',
                                      'foo', 'bar')
    assert False is has_any_callables(dict(), 'foo', 'bar')
    b = dict(a=1, b=2, c=3)
    assert has_any_callables(b, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(b.keys(), 'get', 'keys', 'items', 'values', 'foo')
    assert False is has_any_callables(b.values(), 'get', 'keys', 'items',
                                      'values', 'foo')



# Generated at 2022-06-11 22:25:59.183734
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'something') is False
    assert has_callables(dict(),'something','fancy') is False
    assert has_callables(dict(),'something','fancy','get') is False
    assert has_callables(dict(),'something','fancy','get','keys') is False
    assert has_callables(dict(),'something','fancy','get','keys','items') is False
    assert has_callables(dict(),'something','fancy','get','keys','items','values') is True


# Generated at 2022-06-11 22:26:04.787607
# Unit test for function has_callables
def test_has_callables():
    # if has_callables() returns True, function has passed test
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    # if has_callables() returns False, function has failed test
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-11 22:26:09.712836
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    obj = OrderedDict(a=1, b=2, c=3)
    assert has_callables(obj, 'popitem') is True
    assert has_callables(obj, 'popitem', 'keys') is True
    assert has_callables(obj, 'popitem', 'foo') is False
    assert has_callables(obj, 'foo', 'bar') is False


# Generated at 2022-06-11 22:26:17.217658
# Unit test for function has_any_callables
def test_has_any_callables():
    class Foo:
        def __init__(self):
            self.bar = lambda x: x

    foo = Foo()
    # noinspection PyTypeChecker
    assert has_any_callables(Foo, '__init__', 'bar') is True
    assert has_any_callables(foo, '__init__', 'bar') is True
    assert has_any_callables(Foo, '__init__', 'blah') is False
    assert has_any_callables(foo, '__init__', 'blah') is False

# Generated at 2022-06-11 22:26:24.141105
# Unit test for function has_callables
def test_has_callables():
    print("Testing has_callables")

    obj = dict(some_dict=dict(key_1="value_1"))
    assert has_callables(obj, "setdefault", "get") is True
    assert has_callables(obj.some_dict, "setdefault", "get") is True

    truthy = has_callables(obj, "setdefault", "get", "foo") is True
    assert truthy is False

    print("All tests executed successfully.")



# Generated at 2022-06-11 22:26:34.402019
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, '__eq__') is True
    assert has_any_callables({}, '__eq__', '__ne__') is True
    assert has_any_callables('', '__eq__', '__ne__') is True
    assert has_any_callables('', '__eq__', '__ne__', '__lt__') is True
    assert has_any_callables('', '__eq__', '__ne__', '__lt__', '__gt__') is True
    assert has_any_callables('', '__eq__', '__ne__', '__lt__', '__gt__',
                             '__ge__') is True

# Generated at 2022-06-11 22:26:38.092141
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'update', 'setdefault') is True
    assert has_attrs(dict(), 'foo', 'bar') is False


# Generated at 2022-06-11 22:26:48.457879
# Unit test for function has_callables

# Generated at 2022-06-11 22:26:57.472391
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), '__init__', '__lt__', '__le__', 'items') is True
    assert not has_any_callables(dict(), '__init__', '__lt__', '__le__', '__gt__')


# Generated at 2022-06-11 22:26:59.557672
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:27:04.073865
# Unit test for function has_any_callables
def test_has_any_callables():
    # test function executions
    assert has_any_callables(dict(),'get','keys','items','values','foo')

    # test function executions
    assert not has_any_callables(dict(),'get','keys','items','values','foo',None)

    # test function executions
    assert has_any_callables(dict(),'get','keys','items','values',None)


# Generated at 2022-06-11 22:27:07.856095
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_callables(dict(),'get','keys','items','values')





# Generated at 2022-06-11 22:27:14.262458
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj) is True
    assert has_any_callables(obj, 'get') is True
    assert has_any_callables(obj, 'get', 'keys', 'foo') is True
    assert has_any_callables(obj, 'foo', 'bar') is False
    assert has_any_callables(obj, 'items') is True


# Generated at 2022-06-11 22:27:19.837153
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj = None
    assert has_any_callables(test_obj, 'get', 'keys', 'items', 'values', 'foo') == False

    test_obj = dict()
    assert has_any_callables(test_obj, 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-11 22:27:24.840506
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')


if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-11 22:27:28.733067
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1,b=2,c=3)
    attrs = ('a','b','c','d','e')
    result = has_attrs(obj,*attrs)
    assert result == False


# Generated at 2022-06-11 22:27:34.538320
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert (has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True)
    assert (has_any_attrs(dict(), 'nothing') is False)
    assert (has_any_attrs(dict()) is False)
    # test for class
    class Test:
        def __init__(self, name):
            self.name = name
    assert has_any_attrs(Test, 'name', 'something') is True


# Generated at 2022-06-11 22:27:53.505780
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-11 22:27:55.009055
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values') is True



# Generated at 2022-06-11 22:27:57.957420
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:28:02.872510
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict({'a': 'b'}), 'get', 'keys', 'items', 'values')
    assert not has_callables(dict({'a': 'b'}), 'foo', 'bar')



# Generated at 2022-06-11 22:28:07.584825
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','something') == True
    assert has_any_callables(dict(),'foo','bar') == False


# Generated at 2022-06-11 22:28:10.451046
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') == True
    assert has_any_callables(obj, 'foo', 'bar') == False



# Generated at 2022-06-11 22:28:14.339892
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict, 'get', 'keys', 'items', 'values', 'foo') == False



# Generated at 2022-06-11 22:28:24.910156
# Unit test for function has_any_callables
def test_has_any_callables():
    print('Testing function has_any_callables')
    from unittest import TestCase, main
    from collections import UserDict

    class Test(UserDict, object):
        pass

    class TestObj(Test):
        def __init__(self, *args, **kwargs):
            self.data = {}
            self.update(*args, **kwargs)

        def __setitem__(self, key, val):
            self.data[key] = val

        def __getitem__(self, key):
            return self.data[key]

        def __call__(self, *args, **kwargs):
            return len(*args)

    class TestObj2(TestObj):
        pass

    class TestObj3(Test):
        pass

    class TestObj4(Test):
        pass


# Generated at 2022-06-11 22:28:27.188179
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test the function ``has_any_callables``.
    """
    import doctest
    doctest.testmod()



# Generated at 2022-06-11 22:28:28.288632
# Unit test for function has_callables
def test_has_callables():
    pass



# Generated at 2022-06-11 22:28:43.650834
# Unit test for function has_callables
def test_has_callables():
    from collections import (
            defaultdict,
            namedtuple,
            UserDict,
            UserList,
            UserString,
            OrderedDict,
            Counter,
            ChainMap,
    )
    from decimal import Decimal

    Dict = dict
    List = list
    Set = set
    Tuple = tuple
    Int = int
    Float = float
    Bool = bool
    Str = str
    Bytes = bytes
    NoneObj = None
    DefaultDict = defaultdict
    NamedTuple = namedtuple
    UserDict = UserDict
    UserList = UserList
    UserString = UserString
    OrderedDict = OrderedDict
    Counter = Counter
    ChainMap = ChainMap
    Decimal = Decimal


# Generated at 2022-06-11 22:28:48.004462
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False


# Generated at 2022-06-11 22:28:59.242312
# Unit test for function has_callables
def test_has_callables():

    from collections import OrderedDict
    from collections.abc import Iterator

    # Testing generic classes
    # -----------------------
    # Generic classes that have attrs
    # ``('__getitem__', '__iter__', '__len__', '__contains__')``.
    #
    # Iterator,
    # ValuesView,
    # KeysView,
    # UserList,
    # frozenset,
    # list,
    # set,
    # tuple,
    # deque
    # Instances of these classes should return ``True`` when called with
    # ``('__getitem__', '__iter__', '__len__', '__contains__')``.
    #

# Generated at 2022-06-11 22:29:01.095556
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True

# Generated at 2022-06-11 22:29:03.143807
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str, 'capitalize', 'strip', 'split') is True



# Generated at 2022-06-11 22:29:10.961011
# Unit test for function has_callables
def test_has_callables():
    func = has_callables
    assert func(dict(), 'get', 'keys', 'items') is True
    assert func(dict(), 'get', 'keys', 'items', 'foo') is False
    assert func(dict(a=1, b=2), 'get', 'keys', 'items') is True
    assert func(dict(a=1, b=2), 'get', 'keys', 'items', 'foo') is False



# Generated at 2022-06-11 22:29:15.431421
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Test a successful call to the function
    """
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    # assert has_any_callables(dict(),'get','keys','items','values')
    # assert has_any_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-11 22:29:19.721108
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-11 22:29:24.152133
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables('foo', 'upper', 'capitalize', 'startswith', 'foo') is True


# Generated at 2022-06-11 22:29:26.732510
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({'d':1}, 'keys', 'values', 'items')


# Generated at 2022-06-11 22:29:38.590018
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables({'foo':'bar'},'get','keys','items','values','foo')
    assert has_any_callables({'foo':'bar'},'get','keys','items','values')
    assert not has_any_callables({'foo':'bar'},'get','keys','items','values','fooo')


# Generated at 2022-06-11 22:29:46.986891
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(bytes(),'hex','decode')
    assert has_any_callables(str(),'capitalize','swapcase')
    assert has_any_callables(set(),'pop','add')
    assert has_any_callables(tuple(),'index','count')
    assert has_any_callables(list(),'append','clear')
    assert has_any_callables(UserList(),'append','sort')
    assert has_any_callables(Iterator(),'__next__','__iter__')
    assert has_any_callables(KeysView(),'__iter__','__contains__')
    assert has_any_callables(ValuesView(),'__iter__','__contains__')

# Generated at 2022-06-11 22:29:55.791541
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    from collections import Iterator
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys')
    assert has_callables([1, 2, 3], 'pop', 'sort')
    assert has_callables(reversed([1, 2, 3]), 'reverse', '__str__') is True
    assert has_callables(Iterator, '__next__') is True
    assert has_callables(Iterator([]), '__next__') is True



# Generated at 2022-06-11 22:30:03.756472
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'foo', 'values') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_callables(dict(), 'foo', 'keys', 'items', 'values') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-11 22:30:07.210483
# Unit test for function has_callables
def test_has_callables():
    assert callable(has_callables)
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:30:10.604669
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test cases for function has_any_callables."""
    assert has_any_callables(dict(), 'get', 'keys', 'foo', 'items', 'values')



# Generated at 2022-06-11 22:30:16.636729
# Unit test for function has_callables
def test_has_callables():
    import datetime
    class Permissible():
        def __init__(self):
            self.a = 1
            self.b = datetime.datetime.now()
            self.c = lambda x : x * 2

    object_ = Permissible()
    res = has_callables(object_, 'a', 'b', 'c')
    assert res == False
    res = has_callables(object_, 'a', 'c')
    assert res == True

# Generated at 2022-06-11 22:30:20.057751
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    attrs = ['get', 'foo', 'bar']
    assert has_any_callables(obj, *attrs)



# Generated at 2022-06-11 22:30:29.474437
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables(dict(), '') is False
    assert has_any_callables(dict(), None) is False
    assert has_any_callables(dict(), []) is False
    assert has_any_callables(dict(), (1,)) is False



# Generated at 2022-06-11 22:30:40.400569
# Unit test for function has_callables
def test_has_callables():
    """Function test for has_callables()."""
    from unittest.mock import Mock

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(Mock(), 'get', 'keys', 'items', 'values') is False
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'foo') is True
    a = dict(a=1, b=2)
    a.get = None
    assert has_callables(a, 'get', 'keys', 'items') is False
    assert has_callables(a, 'keys', 'items') is True


#

# Generated at 2022-06-11 22:30:56.173617
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True

# Generated at 2022-06-11 22:31:06.085809
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'something')
    assert has_any_callables(dict(), 'foo', 'bar') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'foo', 'bar', 'values') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(object(), 'foo', 'bar') is False
    assert (
        has_any_callables(
            object(),
            '__init__',
            '__repr__',
            '__str__',
            '__unicode__'
        )
    )

# Generated at 2022-06-11 22:31:13.233172
# Unit test for function has_any_callables
def test_has_any_callables():
    h = [has_any_callables(dict(),'get','keys','items','values','foo') == True, 
        has_any_callables(dict(),'get','keys','items','values','foo') == True, 
        has_any_callables(dict(),'bar','baz','qux','quux','quuz','corge') == False]
    for i in h:
        assert i == True


# Generated at 2022-06-11 22:31:18.936866
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    od = OrderedDict(a=1, b=2, c=3)
    assert has_callables(od, 'keys', 'items', 'values', 'popitem') is True
    assert not has_callables(od, 'keys', 'items', 'values', 'popitem', 'foo')


# Generated at 2022-06-11 22:31:21.162868
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    

# Generated at 2022-06-11 22:31:27.057332
# Unit test for function has_callables
def test_has_callables():
    """Test flutils.objutils.has_callables.
    """
    # Checks that has_callables works as intended
    assert has_callables(dict(),'get','keys','items','values') == True



# Generated at 2022-06-11 22:31:37.989738
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'items', 'values')
    assert has_any_callables(dict(), 'values')
    assert has_any_callables(dict(), 'keys')
    assert has_any_callables(dict(), 'items')

    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict(), 'this', 'that', 'other')

    class Foo:
        def do_something(self):
            return True


# Generated at 2022-06-11 22:31:41.733451
# Unit test for function has_any_callables
def test_has_any_callables():
    l = [('get', True), ('keys', True), ('items', True), ('values', True), ('foo', False)]
    for i in l:
        print(has_any_callables(dict(), i[0]))


# Generated at 2022-06-11 22:31:43.482072
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-11 22:31:52.994865
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict, defaultdict
    from flutils.objutils import has_callables
    from flutils.textutils import make_sentence as ms

    d = OrderedDict()
    d['a'] = 1
    d['b'] = 2
    d['c'] = 3
    d['d'] = 4
    d['e'] = 5

    l = [1, 2, 3, 4, 5]


# Generated at 2022-06-11 22:32:15.752399
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'values')
    assert has_callables(obj, 'keys', 'get')


# Generated at 2022-06-11 22:32:17.595697
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1)
    assert has_any_callables(obj, 'get', 'something')


# Generated at 2022-06-11 22:32:30.195388
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('Hello World!', 'upper', 'strip') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(a=1, b=2), 'items', 'foo') is True
    assert has_any_callables(dict(a=1, b=2), 'something', 'foo') is False
    assert has_any_callables('Hello World!', 'upper', 'strip', 'special') is True
    assert has_any_callables('Hello World!', 'upper', 'special', 'strip') is True
    assert has_any_callables('Hello World!', 'upper', 'item', 'special') is True

# Generated at 2022-06-11 22:32:41.232805
# Unit test for function has_any_callables
def test_has_any_callables():
    import unittest

    class TestCase(unittest.TestCase):
        def test_dict_get(self):
            obj = dict(abc=123)
            attrs = {'get'}
            self.assertTrue(has_any_callables(obj, *attrs),
                            'has_any_callables returned False')

        def test_dict_keys(self):
            obj = dict(abc=123)
            attrs = {'keys'}
            self.assertTrue(has_any_callables(obj, *attrs),
                            'has_any_callables returned False')

        def test_dict_values(self):
            obj = dict(abc=123)
            attrs = {'values'}

# Generated at 2022-06-11 22:32:48.189875
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict

    obj = OrderedDict([('b', 1), ('a', 2)])
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'update') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(obj, 'get', 'keys', 'items') is True
    assert has_any_callables(obj, 'get', 'keys') is True
    assert has_any_callables(obj, 'get') is True
    assert has_any_callables(obj, 'foo') is False


# Generated at 2022-06-11 22:32:53.317498
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert not has_any_callables(dict(),'get','keys','items')
    assert not has_any_callables(dict(),'setattr','keys','items','values')


# Generated at 2022-06-11 22:32:56.874225
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    print(has_any_callables(obj,'get','keys','items','values','foo'))


# Generated at 2022-06-11 22:33:04.540510
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test the function has_any_callables"""
    variables = dict(
        object1 = dict(
            dictionary = dict(),
            get = dict().get,
            keys = dict().keys,
            items = dict().items,
            values = dict().values,
        ),
        object2 = None
    )
    assert variables['object1']['dictionary'] == dict()
    assert has_any_attrs(variables['object1']['dictionary'], 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_callables(variables['object1']['dictionary'], 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-11 22:33:06.670552
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'items', 'get') == True


# Generated at 2022-06-11 22:33:10.143331
# Unit test for function has_callables
def test_has_callables():
    obj = dict(hello=1)
    assert has_callables(obj, "keys") is True
    assert has_callables(obj, "something") is False
    assert has_callables(obj, "keys", "something") is False
