

# Generated at 2022-06-11 22:25:31.148405
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(a=1, b=2)
    assert has_any_callables(d, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-11 22:25:39.018705
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict(a=1,b=2),'get','keys','items','values')
    assert has_callables(dict(a=1,b=2),'get','keys','items','values','foo') is False
    assert has_callables(dict(a=1,b=2),'foo') is False
    assert has_callables(dict(),'foo') is False


# Generated at 2022-06-11 22:25:50.762811
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), '__contains__', '__getitem__') is True
    assert has_attrs(dict(), '__contains__', '__getitem__', 'get') is False
    assert has_attrs([1, 2, 3], '__contains__', '__getitem__') is True
    assert has_attrs([1, 2, 3], '__contains__', '__getitem__', 'get') is False
    assert has_attrs('foo', '__contains__', '__getitem__') is True
    assert has_attrs('foo', '__contains__', '__getitem__', 'get') is False
    assert has_attrs(1, '__contains__', '__getitem__') is False

# Generated at 2022-06-11 22:25:58.759160
# Unit test for function has_callables
def test_has_callables():
    # Arrange
    list_of_attrs = ['foo', 'bar', 'foobar']
    dict_of_funcs = {
        'foo': lambda: True,
        'bar': lambda : True,
        'foobar': lambda: False,
    }
    expected_result = True, True, False
    # Act
    for i, attr in enumerate(list_of_attrs):
        # Check that the function is being called with the right arguments
        if has_callables(dict_of_funcs, attr) != expected_result[i]:
            raise Exception('Test failed')
        print('Test passed')

# Generated at 2022-06-11 22:26:00.971756
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'values') is True



# Generated at 2022-06-11 22:26:04.590922
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'foo','bar','gob','baz') is False


# Generated at 2022-06-11 22:26:14.583555
# Unit test for function has_any_callables
def test_has_any_callables():
    def foo():
        pass

    class Foo(object):
        def __init__(self, a: str, b: str):
            self._a = a
            self._b = b

        # noinspection PyMethodParameters
        @property
        def a(self) -> str:
            return self._a

        # noinspection PyMethodParameters
        @property
        def b(self) -> str:
            return self._b

    obj = Foo(a='a', b='b')
    assert has_any_callables(obj, 'a', 'b', 'foo') is True
    assert has_any_callables(obj, 'a', 'b', 'foo', 'c') is False
    assert has_any_callables(obj, 'a', 'b', 'foo', 'a') is True
    assert has_any_

# Generated at 2022-06-11 22:26:21.578873
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = {'get': lambda: 'get', 'keys': lambda: 'keys'}
    assert has_any_callables(obj, *['get', 'keys'])
    assert has_any_callables(obj, *['get', 'keys', 'values'])
    assert not has_any_callables(obj, *['get', 'keys', 'values', 'foo'])
    assert not has_any_callables(obj, *['get', 'keys', 'values', 'foo'])
    assert not has_any_callables(None, *['get', 'keys', 'values', 'foo'])



# Generated at 2022-06-11 22:26:24.739194
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables('', 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-11 22:26:27.265209
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-11 22:26:35.849206
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(), 'get', 'items', 'keys', 'values', 'foo'))


# Generated at 2022-06-11 22:26:43.344816
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj = dict(a=1,b=2)
    test_attrs = ('get', 'keys', 'items', 'values', 'foo')
    test_func = has_any_callables(test_obj,*test_attrs)
    if test_func is True:
        print('Test has_any_callables Passed!')
    else:
        print('Test has_any_callables Failed!')


# Generated at 2022-06-11 22:26:45.478648
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-11 22:26:47.193593
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:26:49.600425
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict, 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:27:02.329250
# Unit test for function has_callables
def test_has_callables():
    # a class that has the attributes.
    class TestObj:
        def __init__(self, foo: str = 'bar'):
            self.foo = foo

        def bar(self):
            return None

        def baz(self):
            return None

    test_obj = TestObj()
    assert has_callables(test_obj, 'foo', 'bar', 'baz')

    # a class that doesn't have the attributes.
    class TestObj:
        def __init__(self, foo: str = 'bar'):
            self.foo = foo

        def bar(self):
            return None

        def baz(self):
            return None

    test_obj = TestObj()
    assert has_callables(test_obj, 'foo', 'bar', 'baz', 'qux') is False


# Unit

# Generated at 2022-06-11 22:27:06.030138
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'values', 'something') == True
    assert has_any_callables(obj, 'foo', 'bar', 'bar') == False


# Generated at 2022-06-11 22:27:10.046679
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False


# Generated at 2022-06-11 22:27:15.470847
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Test for function has_any_callables

    Examples:
        >>> from flutils.objutils import has_any_callables
        >>> has_any_callables(dict(),'get','keys','items','values','foo')
        True
    """
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-11 22:27:24.694660
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
        assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something')
        assert not has_any_callables(dict(), 'something1', 'something2', 'something3')
        assert has_any_callables(dict(), 'something1', 'something2', 'something3', 'keys')
    except AssertionError:
        print('test_has_any_callables failed!')

