

# Generated at 2022-06-11 22:25:36.372190
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(), '__init__') is True
    assert has_any_callables(dict(), '__init__', 'keys', 'update') is True
    assert has_any_callables(dict(), 'get') is True
    assert has_any_callables(list(), '__init__') is True
    assert has_any_callables(list(), '__init__', 'append', 'sort') is True
    assert has_any_callables(list(), 'sort') is True
    assert has_any_callables('hello', '__init__') is True
    assert has_any_callables('hello', '__init__', 'join', 'split') is True
    assert has_any_callables('hello', 'join') is True



# Generated at 2022-06-11 22:25:48.184880
# Unit test for function has_callables
def test_has_callables():
    import unittest
    class TestHasCallables(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_has_callables(self):
            class MyObj:
                def __init__(self):
                    self.a = 1
                    self.b = 2
                    self.c = 3
                def func1(self):
                    pass
                def func2(self):
                    pass
            self.assertEqual(
                has_callables(MyObj(),'a'),
                False,
            )
            self.assertEqual(
                has_callables(MyObj(),'a','b'),
                False,
            )

# Generated at 2022-06-11 22:25:50.714078
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:25:53.000666
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-11 22:25:56.136606
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False


# Generated at 2022-06-11 22:26:06.381537
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test with a dict
    test = dict(a=1,b=2)
    assert has_any_attrs(test,'keys','pop','something') is True
    assert has_any_attrs(test,('k','v')) is False
    # Test with an int
    test = 1
    assert has_any_attrs(test,('bit_length','conjugate')) is True
    # Test with a list
    test = [1,2,3]
    assert has_any_attrs(test,'append','pop') is True
    assert has_any_attrs(test,('remove','append')) is False


# Generated at 2022-06-11 22:26:08.400407
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:26:12.466118
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(foo='bar'),'get','keys','items','values','foo') is False


# Generated at 2022-06-11 22:26:16.217090
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    # Check that the object has the required attributes.
    assert has_callables(obj, 'items', 'keys', 'values') is True
    # Check that the object has the required attributes and they are callable.
    assert has_callables(obj, 'items', 'keys', 'values', 'foo') is False


# Generated at 2022-06-11 22:26:23.095534
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get') is False
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables('get', 'foo') is False



# Generated at 2022-06-11 22:26:35.361572
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import unittest
    class Test1(object):
        def __init__(self):
            self.a = 1
            self.c = 2
            self.b = 3

    class Test2(object):
        def __init__(self):
            self.a = 1
            self.b = 2

    class Test3(object):
        def __init__(self):
            self.c = 2
            self.b = 3

    class Test4(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    class Test5(object):
        def __init__(self):
            pass

    def test_has_any_attrs_1():
        t1 = Test1()


# Generated at 2022-06-11 22:26:40.357888
# Unit test for function has_any_callables
def test_has_any_callables():
    actual=has_any_callables(dict(),'get','keys','items','values','something')
    print("actual:",actual)
    if actual == True:
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-11 22:26:44.841171
# Unit test for function has_callables
def test_has_callables():
    d = dict(a=1, b=2)
    assert has_callables(d, "get", "items", "keys", "values") is True
    assert has_callables(d, "get", "items", "keys", "values", "foo") is False


# Generated at 2022-06-11 22:26:50.945575
# Unit test for function has_any_callables
def test_has_any_callables():

    assert(has_any_callables("test", "isalpha", "isalnum", "isdigit"))
    assert(not has_any_callables("test","isdigit", "isdecimal", "isspace"))
    assert(has_any_callables(dict(), "keys", "items", "values"))
    assert(not has_any_callables(dict(), "values", "isalpha"))



# Generated at 2022-06-11 22:26:54.247331
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') == True


# Generated at 2022-06-11 22:26:59.358093
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'values', 'items', 'foo') is True
    assert has_any_callables(obj, 'foo', 'bar', 'baz') is False



# Generated at 2022-06-11 22:27:07.645906
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs((1,2,3),'__getitem__','count','index','pop','something')
    assert has_any_attrs('hello','__getitem__','count','index','pop','something')
    assert has_any_attrs(dict(a=1,b=2),'get','keys','items','values','something')
    assert has_any_attrs(dict(a=1,b=2),'get','keys','items','values','something')
    assert has_any_attrs(dict(a=1,b=2),'get','keys','items','values','something')

# Generated at 2022-06-11 22:27:10.357002
# Unit test for function has_any_callables
def test_has_any_callables():
    d = {'a': 1, 'b': 2}
    assert has_any_callables(d, 'get', 'foo') == True



# Generated at 2022-06-11 22:27:12.406537
# Unit test for function has_callables
def test_has_callables():
    d = dict()
    assert has_callables(d, "keys", "items") is True



# Generated at 2022-06-11 22:27:15.565512
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo') is False



# Generated at 2022-06-11 22:27:30.474156
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'a', '', '__name__') is True
    assert has_any_callables(obj, 'a', '', '__name__', 'foo') is True
    assert has_any_callables(obj, 'a', '', '__name__', 'foo', 'bar') is False
    assert has_any_callables(obj, 'foo', '', '__name__', 'bar') is False



# Generated at 2022-06-11 22:27:36.965483
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get') == True
    assert has_callables(dict.fromkeys(['a', 'b']), 'values') == True
    assert has_callables(dict.fromkeys(['a', 'b']), 'values', 'items') == True
    assert has_callables(dict.fromkeys(['a', 'b']), 'values', 'items', 'keys') == True
    assert has_callables(dict.fromkeys(['a', 'b']), 'values', 'items', 'keys', 'foo') == True
    assert has_callables(dict.fromkeys(['a', 'b']), 'keys', 'items', 'foo') == False
    assert has_callables(dict.fromkeys(['a', 'b']), 'values', 'items', 'keys', 'foo') == True
   

# Generated at 2022-06-11 22:27:38.064855
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:27:39.616867
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert not has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-11 22:27:42.867299
# Unit test for function has_any_callables
def test_has_any_callables():
    print("Test function has_any_callables.")
    assert has_any_callables(dict(),'get','keys','items','values','something')
    assert has_any_callables("hello",'capitalize','isupper','islower')



# Generated at 2022-06-11 22:27:52.395606
# Unit test for function has_callables
def test_has_callables():
    """Unit test for ``has_callables``."""
    from collections import ChainMap
    things = (
        (ChainMap({'a': 1}, {'b': 2}, {'c': 3}), ('get', 'keys', 'values'), True),
        (ChainMap({'a': 1}, {'b': 2}, {'c': 3}), ('get', 'keys', 'values', 'items'), True),

        (ChainMap({'a': 1}, {'b': 2}, {'c': 3}), ('get', 'keys', 'foo'), False),
        (ChainMap({'a': 1}, {'b': 2}, {'c': 3}), ('get', 'keys', 'foo', 'items'), False),
    )


# Generated at 2022-06-11 22:28:02.747860
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables(dict(a=1), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(a=1), 'items') is True
    assert has_any_callables(dict(a=1), 'foo') is False
    assert has_any_callables({1}, 'pop') is True
    assert has_any_callables({1}, 'foo') is False
    assert has_any_callables(set(), 'pop') is True
    assert has_any_callables(set(), 'foo') is False

# Generated at 2022-06-11 22:28:05.182641
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:28:07.523057
# Unit test for function has_callables
def test_has_callables():
    my_obj = dict()
    assert( has_callables(my_obj, 'get', 'keys', 'values') == True)
    assert( has_callables(my_obj, 'get', 'keys', 'foo') == False)


# Generated at 2022-06-11 22:28:14.201557
# Unit test for function has_callables
def test_has_callables():
    print('testing has_callables')
    class O(object):
        @classmethod
        def a(cls):
            pass
        @staticmethod
        def b():
            pass
        @property
        def c(self):
            pass
        def d(self):
            pass
        def e(self):
            pass
    o = O()
    assert has_callables(o, 'a', 'b', 'c', 'd')



# Generated at 2022-06-11 22:28:22.074304
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    assert has_callables(list(),'append','extend','insert','remove','pop')
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(set(),'add','copy','discard','difference','intersection')


# Generated at 2022-06-11 22:28:27.795773
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    from flutils.objutils import has_callables
    dd = UserDict()
    if has_callables(dd,'get','keys','items','values') is True:
        print('has_callables passed!')

if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-11 22:28:29.902227
# Unit test for function has_callables
def test_has_callables():
    #dict has all attributes
    obj = dict()
    assert(has_callables(obj,'get','keys','items','values'))


# Generated at 2022-06-11 22:28:42.821619
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'items', 'foo') is False
    assert has_callables(obj, 'foo', 'bar') is False
    obj = 'hello'
    assert has_callables(obj, 'upper', 'splitlines') is True
    obj = list(range(5))
    assert has_callables(obj, '__iter__', 'append', 'index') is True
    assert has_callables(obj, '__iter__', 'append', 'foo') is False
    assert has_callables(obj, 'foo', 'bar') is False
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:28:46.472841
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'items', 'values') is True
    assert has_callables({}, 'get', 'foo', 'bar') is False
    assert has_callables({}, 'foo', 'bar', 'baz') is False



# Generated at 2022-06-11 22:28:49.488203
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'foobar') is False



# Generated at 2022-06-11 22:28:57.521946
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'keys', 'items', 'values')
    assert has_callables(list(), 'pop')
    assert has_callables(set(), 'pop')
    assert not has_callables(dict(), 'pop')
    assert not has_callables(list(), 'pop', 'keys')
    assert not has_callables(set(), 'pop', 'keys')
    assert not has_callables(dict(), 'pop', 'values')



# Generated at 2022-06-11 22:29:00.472067
# Unit test for function has_callables
def test_has_callables():
    print(has_callables(dict(),'get','keys','items','values'))
    print(has_callables(dict(),'foo'))


# Generated at 2022-06-11 22:29:12.751807
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables"""
    import collections
    import numbers
    from flutils.objutils import has_callables

    assert has_callables(collections.Counter({1: 1}), 'update') is True
    assert has_callables(numbers.Integral(), 'real') is True
    assert has_callables(numbers.Real(), 'real') is True
    assert has_callables(dict(), 'update') is True
    assert has_callables(dict(), 'foo') is False
    assert has_callables(list(), 'append') is True
    assert has_callables(list(), 'foo') is False
    assert has_callables(numbers.Number(), 'real') is True
    assert has_callables(numbers.Real(), 'real') is True

# Generated at 2022-06-11 22:29:15.181221
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    obj = UserDict()
    assert has_callables(obj, 'keys') == True
    assert has_callables(obj, 'something') == False


# Generated at 2022-06-11 22:29:27.072909
# Unit test for function has_callables
def test_has_callables():
    dict_attrs = dict()
    dict_attrs['get'] = "mapping"
    dict_attrs['keys'] = "mapping"
    dict_attrs['items'] = "mapping"
    dict_attrs['values'] = "mapping"
    dict_attrs['foo'] = "mapping"
    expected = True
    assert has_callables(dict_attrs,'get','keys','items','values','foo') == expected


# Generated at 2022-06-11 22:29:38.377693
# Unit test for function has_callables
def test_has_callables():
    import unittest
    from collections import deque
    
    class BadDict(dict):
        def __init__(self, dict_):
            super(BadDict, self).__init__(dict_)
            self.bad_method = 3
    
    class BadDeque(deque):
        def __init__(self, iterable):
            super(BadDeque, self).__init__(iterable)
            self.bad_method = 3
    
    
    bad_dict = BadDict({'1': 'a', '2': 'b'})
    bad_deque = BadDeque([1, 2, 3])
    good_dict = dict(a=1, b=2)
    good_deque = deque([1, 2, 3])
    
    

# Generated at 2022-06-11 22:29:43.752860
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    assert has_callables(OrderedDict, '__setitem__', '__getitem__') == True
    assert has_callables(OrderedDict, 'foo', 'bar') == False
    assert has_callables(dict, '__setitem__', '__getitem__') == True
    assert has_callables(dict, 'foo', 'bar') == False
    assert has_callables('hello', 'upper', 'lower') == True
    assert has_callables('hello', 'foo', 'bar') == False



# Generated at 2022-06-11 22:29:50.425414
# Unit test for function has_callables
def test_has_callables():
    obj = {'a': 1, 'b': 2}
    assert has_callables(obj, 'get', 'values') == True
    assert has_callables(obj, 'get', 'items') == True
    assert has_callables(obj, 'keys', 'keys') == False
    assert has_callables(obj, 'items', 'values', 'foo') == False
    assert has_callables(obj, 'foo') == False


# Generated at 2022-06-11 22:29:55.474369
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == False
    assert has_callables(frozenset(),'get','keys','items','values') == False


# Generated at 2022-06-11 22:30:01.237803
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'items', 'keys', 'values') is True
    assert has_callables({}, 'get', 'items', 'keys', 'values', 'foo') is True
    assert has_callables({}, 'get', 'items', 'keys', 'values', 'foo', 'bar') is False



# Generated at 2022-06-11 22:30:09.756404
# Unit test for function has_callables

# Generated at 2022-06-11 22:30:15.035900
# Unit test for function has_callables
def test_has_callables():
    try:
        assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
        assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False
        assert has_callables(dict(), 'foo', 'bar', 'baz') is False
    except AssertionError:
        return False
    else:
        return True

# Generated at 2022-06-11 22:30:19.353629
# Unit test for function has_callables
def test_has_callables():
    class Test:
        def f(self):
            return 123

    t = Test()
    assert has_callables(t, 'f') is True
    assert has_callables(t, 'g') is False

# Generated at 2022-06-11 22:30:22.945287
# Unit test for function has_callables
def test_has_callables():
    a = {'b':1}
    assert has_callables(a, 'keys') == True
    assert has_callables(a, 'b') == False


# Generated at 2022-06-11 22:30:37.248069
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items') == True
    assert has_callables(dict(),'get','keys') == True
    assert has_callables(dict(),'get') == True
    assert has_callables(dict(),'get','something') == False
    assert has_callables(dict(),'nothing') == False
    assert has_callables(dict(),'something') == False
    assert has_callables(dict(),'nothing','something') == False
    assert has_callables(dict()) == False
    assert has_callables(bytes(),'get','keys','items','values') == False



# Generated at 2022-06-11 22:30:41.537701
# Unit test for function has_callables
def test_has_callables():
    class A:
        def __init__(self):
            self.foo = 'bar'
            self.fizz = 'buzz'

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(A(), 'fizz', 'foo') is False



# Generated at 2022-06-11 22:30:43.621837
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:30:44.849662
# Unit test for function has_callables
def test_has_callables():
    d = dict()
    assert has_callables(d, 'get') is True


# Generated at 2022-06-11 22:30:56.982335
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    obj = OrderedDict(a=1, b=2, c=3)
    assert has_callables(obj, 'clear', 'items', 'keys', 'values') == True
    assert has_callables(obj, 'get', 'keys', 'items', 'values') == True
    assert has_callables(obj, 'clear', 'get', 'items', 'values') == True
    assert has_callables(obj, 'clear', 'get', 'keys', 'values') == True
    assert has_callables(obj, 'clear', 'get', 'items', 'keys') == True
    assert has_callables(obj, 'clear', 'get', 'keys', 'items') == True



# Generated at 2022-06-11 22:30:59.807095
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:31:05.166792
# Unit test for function has_callables
def test_has_callables():
    """Test the has_callables function in objutils

    Example:
    >>> from flutils.objutils import has_callables
    >>> has_callables(dict(),'get','keys','items','values')
    True
    >>> from flutils.objutils import has_callables
    >>> has_callables(dict(),'get','keys','items','foo')
    False
    """
    pass


# Generated at 2022-06-11 22:31:06.932202
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-11 22:31:08.726082
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'pop', 'popitem', 'setdefault') == True

# Generated at 2022-06-11 22:31:19.255510
# Unit test for function has_callables
def test_has_callables():
    try:
        assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    except AssertionError:
        print(
            'AssertionError: has_callables(dict(),'
            '\'get\', \'keys\', \'items\', \'values\') returned False when it should have returned True.'
        )
        raise
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False, (
        'has_callables(dict(),\'get\', \'keys\', \'items\', \'foo\') '
        'returned True when it should have returned False.'
    )

# Generated at 2022-06-11 22:31:39.291393
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    from inspect import Signature
    from string import ascii_letters

    class Test(UserDict):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        def __repr__(self):
            return 'Test(%s)' % str(self.data)

    o = Test(name='Hello', age=100, long_func=len, signature=Signature)
    assert has_callables(o, 'name', 'age', 'long_func') is True
    assert has_callables(o, 'name', 'age', 'long_func', 'signature') is True

# Generated at 2022-06-11 22:31:43.482781
# Unit test for function has_callables
def test_has_callables():
    class SomeClass():

        def __init__(self):
            self.test = 'hello'

        def test_method(self):
            return 'hello world'

    obj = SomeClass()
    assert has_callables(obj, 'test', 'test_method')



# Generated at 2022-06-11 22:31:46.898278
# Unit test for function has_callables
def test_has_callables():
    """test_has_callables: Test that has_callables works as expected
    """
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values')

# Generated at 2022-06-11 22:31:49.693154
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','foo','keys','items','values') is False


# Generated at 2022-06-11 22:31:51.853192
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')



# Generated at 2022-06-11 22:31:55.429428
# Unit test for function has_callables
def test_has_callables():
    o = dict()
    callables = ['get', 'keys', 'items', 'values']
    assert has_callables(o, *callables)



# Generated at 2022-06-11 22:32:03.593212
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(str(), 'split', 'strip') is True
    assert has_callables(str(), 'split', 'foo') is False
    assert has_callables(tuple()) is True
    assert has_callables(list(), 'pop') is True
    assert has_callables(set(), 'pop') is True
    assert has_callables(frozenset(), 'pop') is False


# Generated at 2022-06-11 22:32:06.428906
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'foo','bar')

# Generated at 2022-06-11 22:32:07.940799
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'something', 'items', 'values') is False

# Generated at 2022-06-11 22:32:10.430083
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict, 'foo') is False
    assert has_callables(dict, 'foo', 'bar') is False
