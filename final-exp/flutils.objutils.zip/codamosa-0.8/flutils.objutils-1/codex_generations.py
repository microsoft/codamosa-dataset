

# Generated at 2022-06-11 22:25:42.281688
# Unit test for function has_callables
def test_has_callables():
    """Tests for function has_callables"""
    import unittest
    import types
    from collections import OrderedDict

    class TestHasCallables(unittest.TestCase):
        """Unittest class for function has_callables"""

        def test_has_callables(self):
            """Test case for has_callables"""
            def any_valid_callable(): return 'aadf'
            def none_valid_callable(): return 'aadf'
            any_valid_callable.__call__ = None
            none_valid_callable.__call__ = 'aadf'
            valid_callable_list = [any_valid_callable, none_valid_callable]
            valid_callable_list.__call__ = 'aadf'

# Generated at 2022-06-11 22:25:47.960420
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items') is True


# Generated at 2022-06-11 22:25:52.290007
# Unit test for function has_any_callables
def test_has_any_callables():
    print("UNIT TEST: has_any_callables")
    d = dict(a=1, b=2)
    print(has_any_callables(d,'get','keys','items'))
    print(has_any_callables(d,'x','y','z'))


# Generated at 2022-06-11 22:25:54.546028
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') ==True
    assert has_any_callables(dict(),'get','keys','items','values','foo') !=-True


# Generated at 2022-06-11 22:25:58.900942
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables({}, 'get', 'keys', 'items', 'values')
    assert has_callables(dict(),'setdefault') is False


# Generated at 2022-06-11 22:26:03.144690
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'foo','bar','baz','hello','world') is False


# Generated at 2022-06-11 22:26:07.473717
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'something', 'items', 'values') is False
    assert has_callables(dict(), 'get', 'something', 'items', 'foo') is False


# Generated at 2022-06-11 22:26:17.963256
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', bar=True) is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'bar', bar=True) is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', None) is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', True) is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 1) is False

# Generated at 2022-06-11 22:26:25.162121
# Unit test for function has_callables
def test_has_callables():
    import unittest

    class TestHasCallables(unittest.TestCase):
        def setUp(self):
            self.dict = dict(a=1, b=2)

        def test_has_callables(self):
            self.assertTrue(has_callables(self.dict, 'get', 'valid_keys'))

        def test_has_not_callables(self):
            self.assertFalse(has_callables(self.dict, 'get', 'b'))

    unittest.main()

# Generated at 2022-06-11 22:26:34.620549
# Unit test for function has_any_callables
def test_has_any_callables():
    import functools
    def test_function(arg1: str, arg2: int) -> int:
        return arg1 + arg2

    test_1 = functools.partial(test_function, arg1='arg1')
    test_2 = functools.partial(test_function, arg2='5')
    test_3 = functools.partial(test_function, arg1='arg1', arg2='5')

    assert has_any_callables(test_1, '__call__') == True
    assert has_any_callables(test_2, '__call__') == True
    assert has_any_callables(test_3, '__call__') == True

    assert has_any_callables(test_function, '__call__') == True

# Generated at 2022-06-11 22:26:44.930439
# Unit test for function has_any_callables
def test_has_any_callables():
    class Foo:
        def __init__(self, bar, **kwargs):
            self.bar = bar
            for k, v in kwargs.items():
                setattr(self, k, v)

    d = Foo(bar='hello', baz='world')
    assert has_any_callables(d, 'bar', 'baz') is True
    assert has_any_callables(d, 'hello', 'world') is False



# Generated at 2022-06-11 22:26:46.649581
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:26:49.548810
# Unit test for function has_callables
def test_has_callables():
    expected = True
    actual = has_callables(dict(),'get','keys','items','values')
    assert actual == expected



# Generated at 2022-06-11 22:27:02.286654
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import defaultdict

    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables({}, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(defaultdict(), 'get', 'keys', 'items', 'values',
                             'foo')
    assert has_any_callables(set(), 'add', 'remove', 'pop', 'foo')
    assert has_any_callables(frozenset(), 'foo')
    assert has_any_callables(list(), 'append', 'remove', 'pop', 'foo')
    assert has_any_callables(tuple(), 'foo')
    assert has_any_callables(deque(), 'append', 'remove', 'pop', 'foo')

    d = {}


# Generated at 2022-06-11 22:27:13.437182
# Unit test for function has_any_callables
def test_has_any_callables():
    # test dict with callables
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'something')
    # test dict no callables
    assert not has_any_callables(dict(), 'something')
    # test dict with callables and without
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'something')
    # test class with callables
    assert has_any_callables(lambda: None, '__call__', '__init__', 'something')
    # test class no callables
    assert not has_any_callables(lambda: None, 'something')
    # test class with callables and without
    assert has_any_callables(lambda: None, '__call__', '__init__', 'something')
    # test list with callables
    assert has

# Generated at 2022-06-11 22:27:17.448781
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'foo') is False



# Generated at 2022-06-11 22:27:21.728135
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(builtins,'len') == True 
    assert has_callables(builtins,'foo') == False
    assert has_callables(dict(),'keys') == True

# Generated at 2022-06-11 22:27:30.879315
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux', 'values') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'get', 'qux', 'quux') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'get', 'quux') is True


# Generated at 2022-06-11 22:27:33.153762
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert not has_any_callables(dict(),'foo','something')


# Generated at 2022-06-11 22:27:34.466074
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:27:43.092541
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    result = has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert result == True


# Generated at 2022-06-11 22:27:46.980356
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values','foo') is True)


# Generated at 2022-06-11 22:27:50.962360
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items', 'foo')
    assert not has_any_callables(dict(), 'foo')


# Generated at 2022-06-11 22:27:58.625929
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') \
        is True
    assert has_any_callables(list(), 'append', 'extend', 'insert', 'remove') \
        is True
    assert has_any_callables(list(), 'append', 'extend', 'remove', 'foo') \
        is True
    assert has_any_callables(list(), 'append', 'foo', 'bar', 'baz') is False
    assert has_any_callables(list(), 'foo', 'bar', 'baz') is False



# Generated at 2022-06-11 22:28:02.526183
# Unit test for function has_any_callables
def test_has_any_callables():
    print('Testing function: has_any_callables')
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'values', 'items', 'something') == True


# Generated at 2022-06-11 22:28:08.973493
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict, 'get', 'keys', 'items', 'values', 'something') is False
    assert has_callables(dict, 'get', 'keys', 'items', 'something') is False


# Generated at 2022-06-11 22:28:13.710383
# Unit test for function has_any_callables
def test_has_any_callables():
    # given
    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'items', 'values', 'something')

    # when
    result = has_any_callables(obj, *attrs)

    # then
    assert result is True


# Generated at 2022-06-11 22:28:15.680955
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import KeysView
    from flutils.objutils import obj, has_any_callables
    obj = KeysView(__builtins__)
    has_any_callables(obj,'__build_class__', '__import__', 'license')

# Generated at 2022-06-11 22:28:21.057228
# Unit test for function has_any_callables
def test_has_any_callables():
    def func():
        pass
    class Cls():
        pass
    o = Cls()
    o.func = func
    assert has_any_callables(o, 'func')
    assert has_any_callables(o, 'b','c','d','f','g','h','i','j','func')
    assert not has_any_callables(o, 'func','b')


# Generated at 2022-06-11 22:28:25.845615
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test the has_any_callables function.
    """
    test_obj = dict()
    test_result = has_any_callables(test_obj, 'get', 'keys', 'items', 'values')
    assert test_result is True


# Generated at 2022-06-11 22:28:35.768435
# Unit test for function has_callables
def test_has_callables():
    _Obj = type('Obj', (object,), {'attr': lambda _: True})
    _obj = _Obj()
    assert has_callables(_obj, 'attr') is True
    assert has_callables(_obj, 'foo') is False


# Generated at 2022-06-11 22:28:39.542671
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar') == False


# Generated at 2022-06-11 22:28:43.164662
# Unit test for function has_callables
def test_has_callables():

    # Set up fake class
    class A():
        def foo(self):
            pass
        def bar(self):
            pass
        def baz(self):
            pass

    # Instantiate fake class
    obj = A()

    # Check that we get back true
    assert has_callables(obj, "foo", "bar", "baz")



# Generated at 2022-06-11 22:28:54.693373
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Unit test for function has_any_callables
    """

    def foo():
        """A dummy function"""

    class Foo:
        """A dummy class"""

    foo_object = Foo()
    foo_object.foo = foo

    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(foo_object, 'foo', 'bar', 'baz', 'foo')
    assert not has_any_callables(foo_object, 'foo1', 'bar1', 'baz1', 'foo1')
    assert not has_any_callables(dict(), 'foo1', 'bar1', 'baz1', 'foo1')

# Generated at 2022-06-11 22:29:05.463294
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(),'get','keys','items','values') is True
    assert has_any_callables(dict(\
        a=1,b=2,c=3),'get','values','items') is True
    assert has_any_callables(dict(\
        a=1,b=2,c=3),'get','values','items','foo') is True
    assert has_any_callables(dict(\
        a=1,b=2,c=3),'get','keys','items','foo') is True

# Generated at 2022-06-11 22:29:12.292269
# Unit test for function has_callables
def test_has_callables():
    # Check that is_list_like actually returns True if it should
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    # Check that has_callables actually returns False if it should
    assert has_callables(dict(), 'get', 'keys', 'items', 'asdflkjasdflk') is False


# Generated at 2022-06-11 22:29:14.189669
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:29:18.633447
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(a=1, b=2), 'something') is False
    assert has_callables(1, 'something') is False
    assert has_callables(lambda x: x, '__call__') is True
    assert has_callables(lambda x: x, '__blah__') is False

# Generated at 2022-06-11 22:29:21.509142
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','items','values','foo') is False


# Generated at 2022-06-11 22:29:30.643823
# Unit test for function has_callables
def test_has_callables():
    """Tests the function ``has_callables``."""
    func_name = 'has_callables'
    from flutils.objutils import has_callables
    # Test a dict to make sure the function works for objects with __dict__
    setattr(dict, 'foo', lambda x: x)
    assert has_callables(dict, 'clear', 'copy', 'fromkeys', 'get', 'items',
                         'keys', 'pop', 'popitem', 'setdefault', 'update',
                         'values', 'foo') is True
    assert has_callables(dict, 'clear', 'copy', 'fromkeys', 'get', 'items',
                         'keys', 'pop', 'popitem', 'setdefault', 'update',
                         'values') is True

# Generated at 2022-06-11 22:29:57.201465
# Unit test for function has_callables
def test_has_callables():
    def foo():
        return 'foo'
    class Foo(object):
        def __init__(self):
            self._value = None
        def bar(self):
            """Docstring"""
            return 'bar'
    inner = Foo()
    inner._value = foo
    outer = Foo()
    outer._value = inner
    assert has_callables(inner, 'bar') == True
    assert has_callables(inner, '_value') == True
    assert has_callables(outer, 'bar') == True
    assert has_callables(outer, '_value') == True
    assert has_callables(outer, 'bar', '_value') == True
    assert has_callables(outer, '_value', 'bar') == True
    assert has_callables(outer, 'bar', 'bar', 'bar') == True

# Generated at 2022-06-11 22:29:59.483168
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-11 22:30:02.888245
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables([1,2,3],'append','insert','remove','pop','foo')


# Generated at 2022-06-11 22:30:10.673071
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'bar') is False
    assert has_callables(dict(), 'get', 'foo', 'bar') is False
    assert has_callables(dict(), 'foo') is False

# Unit test

# Generated at 2022-06-11 22:30:19.545227
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter, OrderedDict, defaultdict
    from decimal import Decimal
    from flutils.objutils import has_callables
    from flutils.datastructures import ImmutableDict, ImmutableSet
    from flutils.textutils import get_file_path
    import os
    import random
    import unittest
    import uuid

    class _TestCase(unittest.TestCase):
        def test_has_attrs(self):
            _attrs = ('foo', 'bar')
            self.assertFalse(has_callables(None, *_attrs))
            self.assertFalse(has_callables(True, *_attrs))
            self.assertFalse(has_callables(False, *_attrs))
            self.assertFalse(has_callables(1, *_attrs))

# Generated at 2022-06-11 22:30:32.185584
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get')
    assert has_any_callables(dict(), 'keys')
    assert has_any_callables(dict(), 'items')
    assert has_any_callables(dict(), 'values')
    assert has_any_callables(list(), 'append')
    assert has_any_callables(list(), 'clear')
    assert has_any_callables(list(), 'copy')
    assert has_any_callables(list(), 'count')
    assert has_any_callables(list(), 'extend')

# Generated at 2022-06-11 22:30:41.823091
# Unit test for function has_callables
def test_has_callables():
    """
    Test for the function has_callables
    """
    # Test for types that have all the attributes and are callable
    dict_obj = dict(
        get = dict(),
        keys = dict().keys(),
        items = dict().items(),
        values = dict().values()
    )
    list_obj = list([1,2,3,4,5])
    tuple_obj = tuple((1,2,3,4,5))
    str_obj = str("Hello")

    # Test for types that have all the attributes
    dict_obj_2 = dict(
        get = dict(),
        keys = dict().keys(),
        items = dict().items(),
        values = dict().values(),
        something = dict()
    )

    # Test for types that have some of the attributes and are callable
    dict_obj_

# Generated at 2022-06-11 22:30:44.493722
# Unit test for function has_any_callables
def test_has_any_callables():
    import doctest
    from flutils.objutils import has_any_callables
    doctest.testmod(m=has_any_callables)



# Generated at 2022-06-11 22:30:47.704969
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'items', 'values') is False
    assert has_callables(dict, 'items', 'values') is True



# Generated at 2022-06-11 22:30:52.868657
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test dict
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

    # Test Path
    assert has_any_callables(Path(), 'exists', 'suffix', 'foo') is True



# Generated at 2022-06-11 22:31:14.511150
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    attrs = tuple(obj.keys())
    assert has_callables(obj, *attrs) == True


# Generated at 2022-06-11 22:31:18.140807
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('test', 'capitalize') is True
    assert has_callables(dict(), 'keys') is True
    assert has_callables(dict(), 'foo', 'bar') is False

# Generated at 2022-06-11 22:31:31.625635
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(set(),'add','copy','difference','intersection','pop','remove','update','union','symmetric_difference','issubset','issuperset','update','isdisjoint')
    assert has_callables(frozenset(), 'copy', 'difference', 'intersection', 'union', 'symmetric_difference', 'issubset', 'issuperset', 'isdisjoint')
    assert has_callables(tuple(), 'count', 'index')

# Generated at 2022-06-11 22:31:35.260287
# Unit test for function has_callables
def test_has_callables():
    assert not has_callables(dict(),'get')
    assert not has_callables(dict(),'get','keys')
    assert has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-11 22:31:37.658608
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get','keys','items','values')



# Generated at 2022-06-11 22:31:39.465275
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), "get", "keys", "items", "values") == True



# Generated at 2022-06-11 22:31:45.438556
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-11 22:31:48.035264
# Unit test for function has_callables
def test_has_callables():
    obj = dict({'a': 1, 'b': 2, 'c': 3})
    assert has_callables(obj, 'setdefault', 'pop')
    assert not has_callables(obj, 'items')
    assert not has_callables(obj, 'foo')



# Generated at 2022-06-11 22:31:51.560406
# Unit test for function has_callables
def test_has_callables(): # type: ignore
    from flutils.objutils import has_callables
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict(),'get','keys','items','bar')
    assert not has_callables(dict(),'get','keys','items','bar','baz')


# Generated at 2022-06-11 22:31:53.043221
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')

# Generated at 2022-06-11 22:32:11.464717
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-11 22:32:14.106045
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-11 22:32:17.273888
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'get','keys','items','home')


# Generated at 2022-06-11 22:32:20.773758
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'items', 'values') is True
    assert has_callables({}, 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-11 22:32:25.043447
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items') is True
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'values') is False



# Generated at 2022-06-11 22:32:30.939523
# Unit test for function has_callables
def test_has_callables():
    dct = dict()
    assert hasattr(dct, 'clear') is True
    assert has_callables(dct, 'clear') is True
    assert has_callables(dct, 'clear', 'get') is False
    assert hasattr(dct, 'get') is False
    assert has_callables(dct, 'get') is False



# Generated at 2022-06-11 22:32:33.277867
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True, has_callables(dict(),'get','keys','items','values')



# Generated at 2022-06-11 22:32:44.826138
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter
    from operator import getitem
    from collections import UserDict

    obj = dict()
    attrs = ('get', 'keys', 'items', 'values')
    exp = True
    assert has_callables(obj, *attrs) == exp

    obj = Counter()
    attrs = ('get', 'keys', 'items', 'values')
    exp = True
    assert has_callables(obj, *attrs) == exp

    obj = UserDict()
    attrs = ('get', 'keys', 'items', 'values')
    exp = True
    assert has_callables(obj, *attrs) == exp

    obj = list()
    attrs = ('get', 'keys', 'items', 'values')
    exp = False
    assert has_callables(obj, *attrs) == exp



# Generated at 2022-06-11 22:32:46.990191
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    obj = OrderedDict()
    result = has_callables(obj,'__getitem__','items')
    assert result is True


# Generated at 2022-06-11 22:32:50.405470
# Unit test for function has_callables
def test_has_callables():
    '''
    Test has_callables.

    '''
    obj = dict(a=1)
    assert has_callables(obj,'get','keys') is True
    assert has_callables(obj, 'get', 'keys', 'something') is False