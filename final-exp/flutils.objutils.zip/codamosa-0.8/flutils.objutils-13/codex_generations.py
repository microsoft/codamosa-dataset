

# Generated at 2022-06-11 22:25:31.443357
# Unit test for function has_callables
def test_has_callables():
    """ Testing the has_callables function """
    cls_dict = {'a': 1}
    assert has_callables(cls_dict, 'a') is True, 'callables failed'

# Generated at 2022-06-11 22:25:33.625452
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:25:40.432017
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items') == True
    assert has_any_callables(dict(),'get','keys') == True
    assert has_any_callables(dict(),'get') == True
    assert has_any_callables(dict(),'foo') == False


# Generated at 2022-06-11 22:25:51.363560
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from ddt import ddt, data, unpack

    @ddt
    class Test_has_any_attrs(TestCase):
        def setUp(self):
            self.obj = dict(
                foo = lambda: 1,
                bar = lambda: 2,
                baz = lambda: 3
            )


# Generated at 2022-06-11 22:25:52.907589
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')



# Generated at 2022-06-11 22:25:57.933630
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(set(),'__len__','__iter__') == True
    assert has_callables(tuple(),'__len__','__iter__') == True
    assert has_callables(deque(),'__len__','__iter__') == True


if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-11 22:26:05.564004
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not 0

# Generated at 2022-06-11 22:26:12.068884
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'keys','items','values')
    assert has_any_callables(dict(),'keys','values','foo')
    assert has_any_callables(dict(),'get','keys','values','foo')
    assert has_any_callables(dict(),'keys','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','items','values')
    assert has_any_callables(dict(),'get','items')
    assert has_any_callables(dict(),'get','foo')
    assert has_any_callables(dict(),'get')

# Generated at 2022-06-11 22:26:16.988279
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function ``has_any_callables``."""
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), '__len__', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(
        dict(), '__repr__', 'keys', 'items', 'values', 'foo'
    )


# Generated at 2022-06-11 22:26:22.911034
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    obj = dict(a=1,b=2)
    attrs = (
        'get',
        'keys',
        'items',
        'values',
        'something'
    )
    assert(has_any_callables(obj, *attrs) is True)


# Generated at 2022-06-11 22:26:29.849077
# Unit test for function has_callables
def test_has_callables():
    import pytest
    assert has_callables('hello','isalpha','isdigit','islower')
    assert not has_callables('hello','isalpha','isdigit','islower','something')
    with pytest.raises(AssertionError):
        has_callables('hello',())


# Generated at 2022-06-11 22:26:36.070603
# Unit test for function has_callables
def test_has_callables():
    obj = {}
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'update') is True
    assert has_callables(obj, 'update', 'something', 'get', 'keys', 'items') is False


if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-11 22:26:43.921362
# Unit test for function has_callables
def test_has_callables():
    class A(object):
        def __init__(self, a: int, b: int = 1, c: int = 2) -> None:
            self.a = a
            self.b = b
            self.c = c

    a = A(1, 2)
    print(has_callables(a, 'a', 'b', 'c'))
    print(has_callables(a, 'a', 'b', 'c', 'd'))



# Generated at 2022-06-11 22:26:48.218144
# Unit test for function has_callables
def test_has_callables():
    dict_obj = dict(a=1,b=2)
    assert has_callables(dict_obj,'get','keys','items','values') == True
    assert has_callables(dict_obj,'get','keys','items') == True
    assert has_callables(dict_obj, 'get', 'keys', 'values') == True
    assert has_callables(dict_obj, 'get', 'items') == True
    assert has_callables(dict_obj, 'keys', 'items', 'values') == True
    assert has_callables(dict_obj, 'keys', 'items') == True
    assert has_callables(dict_obj, 'get', 'keys') == True
    assert has_callables(dict_obj, 'get', 'items') == True

# Generated at 2022-06-11 22:26:57.325723
# Unit test for function has_callables
def test_has_callables():
    good_list = ['get', 'keys', 'items', 'values']
    bad_list = ['get', 'keys', 'items', 'values', 'foo']
    good_list_output = has_callables(dict(), 'get', 'keys', 'items', 'values')
    bad_list_output = has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert good_list_output is True
    assert bad_list_output is False


# Generated at 2022-06-11 22:27:04.701657
# Unit test for function has_callables
def test_has_callables():
    from unittest import TestCase as _TestCase
    from collections.abc import Generator
    from io import TextIOWrapper

    class TestCase(_TestCase):
        def test_has_callables(self):
            self.assertTrue(has_callables(iter(''), '__next__'))
            self.assertTrue(has_callables({}, 'get', 'keys', 'items', 'values'))
            self.assertTrue(
                has_callables(
                    {},
                    '__len__',
                    'get',
                    'keys',
                    'items',
                    'values',
                    '__getitem__',
                    '__contains__',
                    '__eq__'
                )
            )

# Generated at 2022-06-11 22:27:12.194278
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables."""
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables({}, 'get', 'keys', 'items', 'values')
    assert has_any_callables([], 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:27:14.263046
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:27:17.348168
# Unit test for function has_any_callables
def test_has_any_callables():
    '''Test function has_any_callables.
    '''
    assert has_any_callables(dict(),'get','keys','items','values','something')


# Generated at 2022-06-11 22:27:20.387196
# Unit test for function has_callables
def test_has_callables():
    # pylint: disable=missing-docstring
    from flutils.objutils import has_callables

    assert has_callables([], 'sort') is True



# Generated at 2022-06-11 22:27:30.185676
# Unit test for function has_callables
def test_has_callables():
    test_object = {"a": "A", "b": "B", "c": "C"}
    test_spec = ('a', 'get', 'b', 'update')
    result = has_callables(test_object, *test_spec)
    assert result is True
    test_spec = ('a', 'update', 'b', 'update')
    result = has_callables(test_object, *test_spec)
    assert result is False


# Generated at 2022-06-11 22:27:31.262495
# Unit test for function has_callables
def test_has_callables():
  assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True



# Generated at 2022-06-11 22:27:33.927307
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar')


# Unit Tests for function has_any_attrs

# Generated at 2022-06-11 22:27:38.390753
# Unit test for function has_callables
def test_has_callables():
    assert has_callables([], '__iter__', '__getitem__', '__len__'), \
        'built-in list is callable'
    assert not has_callables(dict(), 'whatever', 'foo'), \
        'attribute doesn’t exist'
    assert not has_callables(dict(), 'get', 'keys', 'values'), \
        'attributes are not callable'
    assert has_callables(dict(), 'get', 'keys', 'values', 'items'), \
        'attribute is callable'



# Generated at 2022-06-11 22:27:49.768141
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'keys', 'items','values','foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables('abc', 'center', 'endswith', 'find', 'foo') is True
    assert has_any_callables(list(), 'append', 'extend', 'insert', 'pop') is True
    assert has_any_callables(frozenset('abc'), 'difference', 'intersection', 'symmetric_difference', 'union') is True
    assert has_any_callables(set('abc'), 'difference', 'intersection', 'symmetric_difference', 'union') is True
    assert has_any_callables(tuple('abc'), 'count', 'index') is True

# Generated at 2022-06-11 22:27:54.138808
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values'
    ) == True
    assert has_callables(dict(), 'foo') == False


# Generated at 2022-06-11 22:27:56.177490
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str(),'isalpha','split')
    assert not has_callables(dict(),'isalpha','split')


# Generated at 2022-06-11 22:28:00.149795
# Unit test for function has_callables
def test_has_callables():
    from datetime import datetime
    from decimal import Decimal
    from typing import Any as _Any
    obj = dict(
        foo = 'bar',
        baz = datetime.now(),
        bam = Decimal(10.0)
    )
    assert has_callables(obj,'get','foo','baz','bam') is True

test_has_callables()

# Generated at 2022-06-11 22:28:08.089882
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    from collections.abc import Iterator, ValuesView, KeysView

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables((), 'get', 'keys', 'items', 'values') is False
    assert has_callables(OrderedDict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables([1, 2, 3], 'get', 'keys', 'items', 'values') is True

    assert has_callables('hello', 'get', 'keys', 'items', 'values') is False
    assert has_callables(reversed('hello'), 'get', 'keys', 'items', 'values') is True

# Generated at 2022-06-11 22:28:14.379510
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables
    """

    print("--- Testing has_callables...")

    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items', 'update')
    assert not has_callables(dict(), 'get', 'keys', 'items', 'does_not_exist')

    print("--- Done!")

# Generated at 2022-06-11 22:28:29.791090
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'foo') is False
    assert has_callables(dict(), 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-11 22:28:38.715283
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'values', 'items', 'foo') is True
    assert has_any_callables(
        dict(), 'keys', 'values', 'items', 'something') is False
    assert has_any_callables(
        dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(
        dict(), 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-11 22:28:41.253507
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:28:43.737079
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'get', 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')


# Generated at 2022-06-11 22:28:47.606245
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([], 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-11 22:28:50.666768
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'foo') is False



# Generated at 2022-06-11 22:28:56.872287
# Unit test for function has_callables
def test_has_callables():
    class Test:
        def method1(self):
            pass

        def method2(self):
            pass

    t = Test()
    assert has_callables(t, 'method1', 'method2') is True
    assert has_callables(t, 'method1', 'method3') is False


# Generated at 2022-06-11 22:29:00.649113
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-11 22:29:04.565507
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables()"""
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')

# Generated at 2022-06-11 22:29:08.755195
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-11 22:29:26.463750
# Unit test for function has_callables
def test_has_callables():
    # unit test for has_callables
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False

# Generated at 2022-06-11 22:29:31.407373
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), "get", "keys", "items", "values", "foo")
    assert has_any_callables("foo", "get", "keys", "items", "values")
    assert has_any_callables("foo", "replace")
    assert not has_any_callables("foo", "something")


# Generated at 2022-06-11 22:29:38.115514
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','not') == False
    assert has_any_callables(None,'get','keys','items','values','not') == False


# Generated at 2022-06-11 22:29:41.595614
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get') is True
    assert has_callables(obj, 'get', 'foo') is False
    assert has_callables(obj, 'foo') is False


# Generated at 2022-06-11 22:29:44.169869
# Unit test for function has_callables
def test_has_callables():
    """Test the has_callables function in flutils"""
    args = ['get','keys','items','values']
    obj = dict(a=1, b=2)
    assert has_callables(obj, *args) is True



# Generated at 2022-06-11 22:29:47.904224
# Unit test for function has_any_callables
def test_has_any_callables():
    import sys
    obj = sys.modules.__dict__
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') == True
    return True


# Generated at 2022-06-11 22:29:54.935614
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),"get","keys","foo","bar") == True
    assert has_any_callables(dict(),"get","keys","foo") == True
    assert has_any_callables(dict(),"get","keys") == True
    assert has_any_callables(dict(),"get","foo","bar") == True
    assert has_any_callables(dict(),"foo","bar") == False

# Generated at 2022-06-11 22:29:57.246804
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values')

# Generated at 2022-06-11 22:29:59.911908
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(a=1, b=2)
    assert has_any_callables(d, 'get', 'keys', 'items', 'values', 'something') == True

# Generated at 2022-06-11 22:30:03.275496
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:30:34.174047
# Unit test for function has_callables
def test_has_callables():
    # Test with instances that are a subclass of dict
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(OrderedDict(),'get','keys','items','values') == True
    assert has_callables(UserDict(),'get','keys','items','values') == True

    # Test with instances of list, set, and frozenset
    assert has_callables(list(),'get','keys','items','values') == True
    assert has_callables(set(),'get','keys','items','values') == True
    assert has_callables(frozenset(),'get','keys','items','values') == True

    # Test with a string
    assert has_callables('hello','strip','replace') == True
    assert has_callables('hello','strip','upper','lower')

# Generated at 2022-06-11 22:30:38.313868
# Unit test for function has_callables
def test_has_callables():
    # Make the dictionary
    test = dict(a=False,b=1,c='string')
    # Make the list of methods
    methods = ['items','keys','values','get']
    # Test has_callables
    assert has_callables(test,*methods)


# Generated at 2022-06-11 22:30:48.067687
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, '__contains__', '__getitem__',
                             '__iter__', '__len__', 'get', 'keys',
                             'values', 'update', 'items', 'clear') is True
    assert has_any_callables(dict(), '__contains__', '__getitem__',
                             '__iter__', '__len__', 'get', 'keys',
                             'values', 'update', 'items', 'clear') is True
    assert has_any_callables(dict(), '__contains__') is True
    assert has_any_callables(dict(), '__getitem__') is True
    assert has_any_callables(dict(), '__iter__') is True
    assert has_any_callables(dict(), '__len__') is True

# Generated at 2022-06-11 22:31:00.143884
# Unit test for function has_any_callables
def test_has_any_callables():
    # [function has_any_callables]
    def foo(a):
        return a + 1
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'bar')
    assert not has_any_callables(None, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables('123', 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(123, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables

# Generated at 2022-06-11 22:31:03.265197
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(
        a=1,
        b=2
    )
    assert has_any_callables(obj, '__contains__', '__getitem__', 'foo')



# Generated at 2022-06-11 22:31:09.551400
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(obj, 'foo') is False
    assert has_any_callables(obj, 'foo', 'get')
    assert has_any_callables(obj, 'foo', 'keys', 'items', 'values') is False


# Generated at 2022-06-11 22:31:14.740494
# Unit test for function has_callables
def test_has_callables():
    r = has_callables(dict(),'get','keys','items','values')
    if r is True:
        print('test_has_callables is passed')
    else:
        print('test_has_callables is failed')


# Generated at 2022-06-11 22:31:18.331757
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    attrs = ['get', 'keys', 'items', 'values', 'pop']
    assert has_any_callables(obj, *attrs) is True



# Generated at 2022-06-11 22:31:22.144698
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), "get", "keys", "items", "values", "foo") == True

#Unit test for function is_list_like

# Generated at 2022-06-11 22:31:26.808232
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables."""
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:32:12.253483
# Unit test for function has_callables
def test_has_callables():
    import collections
    mydict = collections.defaultdict(str)
    assert has_callables(mydict, '__getitem__') is False
    assert has_callables(mydict, '__getitem__', 'default_factory') is True


# Generated at 2022-06-11 22:32:20.902919
# Unit test for function has_callables
def test_has_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    ACALLABLE = 'title'
    NOTCALLABLE = '__getitem__'

    # Common types that are callable and NOT

# Generated at 2022-06-11 22:32:32.491905
# Unit test for function has_callables
def test_has_callables():
    """Test has_callables
    """
    from collections import defaultdict
    from flutils.objutils import has_callables
    dd = defaultdict(list)

# Generated at 2022-06-11 22:32:36.536440
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'stuff') is False


# Generated at 2022-06-11 22:32:40.220324
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something')
    assert has_any_callables(dict().keys(),'get','keys','items','values','something')


# Generated at 2022-06-11 22:32:44.337827
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'hello','keys','items','values') == False
    assert has_callables(dict(),'get','keys','items','values','hello') == False


# Generated at 2022-06-11 22:32:51.722751
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    # No such attribute exists on obj:
    print(has_callables(obj, 'foo', 'bar', 'baz'))
    # Only some of the attributes are callable:
    print(has_callables(obj, 'items', 'keys', 'values'))
    # All the attributes are callable:
    print(has_callables(obj, 'items', 'keys', 'values', 'clear'))
if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-11 22:32:57.112477
# Unit test for function has_callables
def test_has_callables():
    class Test:
        def callable(self):
            return True

    t = Test()
    assert has_callables(t, 'callable'), 'Callable attribute not found'
    assert has_callables(t, 'callable', 'not_exist') == False, 'Attribute not_exist should not exist'



# Generated at 2022-06-11 22:33:10.153077
# Unit test for function has_callables
def test_has_callables():
    mydict = {'a':1, 'b':2}
    assert has_callables(mydict, '__iter__', 'keys', 'values') == True
    # assert has_callables({}, '__iter__', 'keys', 'values') == False
    # assert has_callables(mydict, '__iter__', 'keys', 'values', 'foobar') == False
    # assert has_callables(mydict, '__iter__', 'keys') == True
    # assert has_callables(mydict, '__iter__', 'keys', 'values') == True
    # assert has_callables(mydict, '__iter__', 'keys', 'values', 'something') == False

    class MyClass():
        def __init__(self, x):
            self.x = x


# Generated at 2022-06-11 22:33:17.345830
# Unit test for function has_any_callables
def test_has_any_callables():
    # Get keys from dict
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    # Fail
    assert has_any_callables(dict(),'foo','bar','baz') == False
    # Inherited mixed
    class A:
        foo = True
    class B(A):
        def __init__(self):
            self.bar = False
        def baz(self):
            return 'baz'
    assert has_any_callables(B(),'foo','bar','baz') == True
    # Class-based mixed
    class A:
        foo = True
    class B:
        def __init__(self):
            self.bar = False
        def baz(self):
            return 'baz'