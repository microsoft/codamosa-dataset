

# Generated at 2022-06-11 22:25:37.692459
# Unit test for function has_any_callables
def test_has_any_callables():
    #Test if has_any_callables() returns True
    import random
    assert has_any_callables(random, 'random', 'randint', 'gauss', 'uniform')==True
    assert has_any_callables(random.randint, 'randint', 'random', 'gauss', 'uniform')==True


# Generated at 2022-06-11 22:25:44.742819
# Unit test for function has_callables
def test_has_callables():
    class DictWrapper:
        def get(self, key, default=None):
            return {'a': 1, 'b': 2.0, 'c': '3'}.get(key, default)

        def keys(self):
            return {'a': 1, 'b': 2.0, 'c': '3'}.keys()

        def items(self):
            return {'a': 1, 'b': 2.0, 'c': '3'}.items()

        def values(self):
            return {'a': 1, 'b': 2.0, 'c': '3'}.values()

        def foo(self):
            return {'a': 1, 'b': 2.0, 'c': '3'}.get("bar")
    d = DictWrapper()

# Generated at 2022-06-11 22:25:56.092408
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from typing import (
        Any as _Any,
        Callable,
        Dict as _Dict,
        List as _List,
        MutableMapping,
        Tuple as _Tuple,
    )
    from unittest.mock import (
        Mock,
        MagicMock,
    )
    from typing import (
        Any,
        Type,
        Union,
    )
    from flutils.objutils import (
        has_any_callables,
    )

    _odict: Type[Union[
        MutableMapping[str, Any],
        _Any,
    ]] = _Any

   

# Generated at 2022-06-11 22:25:58.798825
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-11 22:26:00.971423
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True

# Generated at 2022-06-11 22:26:03.767001
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest

    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'somethingelse') is False


# Generated at 2022-06-11 22:26:06.826976
# Unit test for function has_attrs
def test_has_attrs():
    d = {}
    assert has_attrs(d, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(d, 'foo') is False



# Generated at 2022-06-11 22:26:14.391558
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values') is True
    assert has_any_callables(dict(),'get','keys','items') is True
    assert has_any_callables(dict(),'get','keys') is True
    assert has_any_callables(dict(),'get') is True
    assert has_any_callables(dict(),'foo') is False


# Generated at 2022-06-11 22:26:17.510761
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(a=1, b=2)
    assert has_any_callables(d, 'get', 'keys', 'values') is True
    assert has_any_callables(d, 'something') is False



# Generated at 2022-06-11 22:26:27.585909
# Unit test for function has_attrs
def test_has_attrs():
    d = dict(a=1, b=2, c=3)
    assert has_attrs(d, 'get', 'keys', 'values', 'items') is True
    assert has_attrs(d, 'keys', 'values', 'items') is True
    assert has_attrs(d, 'get', 'keys', 'items') is True
    assert has_attrs(d, 'get', 'values', 'items') is True
    assert has_attrs(d, 'get', 'values') is True
    assert has_attrs(d, 'keys', 'values') is True
    assert has_attrs(d, 'get', 'keys') is True
    assert has_attrs(d, 'get', 'items') is True
    assert has_attrs(d, 'keys', 'items') is True
    assert has_

# Generated at 2022-06-11 22:26:32.528058
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:26:34.194636
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-11 22:26:40.687035
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar') == False


# Generated at 2022-06-11 22:26:48.962559
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'foo', 'keys', 'items', 'values') is \
        False
    assert has_any_callables({}, 'get', 'keys', 'items', 'values') is False
    assert has_any_callables({}, 'foo', 'keys', 'items', 'values') is False
    assert has_any_callables(None, 'get', 'keys', 'items', 'values') is False
    assert has_any_callables(None, 'foo', 'keys', 'items', 'values') is False

# Generated at 2022-06-11 22:27:01.814277
# Unit test for function has_any_callables
def test_has_any_callables():
    def func(x):
        return x
    class TestHasAnyCallables:
        def __init__(self, attr):
            self.attr = attr
        def foo(self, y, z=None):
            return y + z
        @staticmethod
        def bar(a, b, x=None):
            return a, b, x
        @classmethod
        def foobar(cls, x):
            return x
    test1 = TestHasAnyCallables(func)
    test2 = TestHasAnyCallables(func)
    assert has_any_callables(test1, 'get', 'foo') == True
    assert has_any_callables(test2, 'foo') == True
    assert has_any_callables(test1, 'get', 'bar') == True
    assert has_any_callables

# Generated at 2022-06-11 22:27:04.217483
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something') == True



# Generated at 2022-06-11 22:27:07.658320
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-11 22:27:10.355580
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar') is False



# Generated at 2022-06-11 22:27:12.406956
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-11 22:27:16.259891
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'items', 'values', 'get') is True
    assert has_any_callables(obj, 'keys', 'items', 'values', 'bar') is False



# Generated at 2022-06-11 22:27:25.909668
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1, 2, 3], '__getitem__')
    assert has_any_callables('test', 'join')
    assert not has_any_callables('test')
    assert not has_any_callables(dict, 'get')
    assert has_any_callables(dict(), 'get')


# Generated at 2022-06-11 22:27:28.735393
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:27:30.351822
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj,'get','keys','items','values','foo') == True, 'has_any_callables test failure'


# Generated at 2022-06-11 22:27:31.424733
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-11 22:27:33.590102
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert has_any_callables(obj.keys(),ValuesView,KeysView,UserList) is True



# Generated at 2022-06-11 22:27:38.154288
# Unit test for function has_any_callables
def test_has_any_callables():
    # print("Starting function test_has_any_callables")
    obj1=dict()
    obj2=list()
    attribute_list1=['get','keys','items','values','foo']
    attribute_list2=['super','keys','items','values','foo']
    assert has_any_callables(obj1,*attribute_list1) == True
    assert has_any_callables(obj2,*attribute_list2) == False
    # print("Exiting function test_has_any_callables")



# Generated at 2022-06-11 22:27:49.435791
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test 1: Empty object
    assert has_any_callables(dict(),'get','keys','items','values','something') == False

    # Test 2: Empty list of attributes
    assert has_any_callables(dict(),'') == False

    # Test 3: Empty object and empty list of attributes
    assert has_any_callables(dict(), '') == False

    # Test 4: None object
    assert has_any_callables(None,'get','keys','items','values','something') == False

    # Test 5: None object, list with one attribute
    assert has_any_callables(None,'get') == False

    # Test 6: None object, list with one attribute
    assert has_any_callables(None, 'get') == False

    # Test 7: Object with none of the attributes in the list
    assert has_any

# Generated at 2022-06-11 22:27:59.618270
# Unit test for function has_any_callables

# Generated at 2022-06-11 22:28:07.880311
# Unit test for function has_any_callables
def test_has_any_callables():
    class Foo(object):
        def bar(self, *args, **kwargs):
            pass

        def baz(self, *args, **kwargs):
            pass

    obj = Foo()
    # noinspection PyUnresolvedReferences
    assert has_any_callables(obj, 'bar', 'baz', 'missing') is True

    # noinspection PyUnresolvedReferences
    assert has_any_callables(obj, 'missing') is False

    # noinspection PyUnresolvedReferences
    assert has_any_callables(obj, 'missing', 'bar') is True

    class Foo(object):
        def bar(self, *args, **kwargs):
            pass

        def baz(self, *args, **kwargs):
            pass

    obj = Foo()
    # noinspection PyUnresolved

# Generated at 2022-06-11 22:28:17.718078
# Unit test for function has_any_callables
def test_has_any_callables():
    """Tests the function has_any_callables"""
    from collections import defaultdict
    from collections import OrderedDict
    from collections import UserDict
    from collections import ChainMap
    from flutils.objutils import has_any_callables
    # test for dicts
    mydict = {'a': 1, 'b': 2}
    assert has_any_callables(mydict, 'get') == True
    assert has_any_callables(mydict, 'foo_bar') == False
    # test for defaultdict
    mydefaultdict = defaultdict(int)
    mydefaultdict.update(a=1, b=2)
    assert has_any_callables(mydefaultdict, 'get') == True
    assert has_any_callables(mydefaultdict, 'foo_bar') == False
    # test for

# Generated at 2022-06-11 22:28:24.091856
# Unit test for function has_any_callables
def test_has_any_callables():
    """ Verify function has_any_callables returns correct type """
    foo = "bar"
    assert isinstance(has_any_callables(foo, 'get','keys','items','values','foo'), bool)



# Generated at 2022-06-11 22:28:33.145637
# Unit test for function has_callables
def test_has_callables():
    import unittest
    import numpy as np
    from unittest import mock

    class TestObj(object):
        def get(self):
            pass

        def keys(self):
            pass

        def items(self):
            pass

        def values(self):
            pass

        def foo(self):
            pass

    class TestObj2(TestObj):

        def foo(self):
            pass

    class TestSubClass(TestObj):
        pass

    obj = TestObj()
    obj2 = TestObj2()
    obj3 = TestSubClass()

    with unittest.TestCase() as tester:
        tester.assertTrue(has_callables(obj, 'get', 'keys', 'items', 'values'))

# Generated at 2022-06-11 22:28:44.465740
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict
    a = OrderedDict(a=1, b=2)
    assert (has_any_callables(a, 'pop') is True)
    assert (has_any_callables(a, 'pop', 'popitem', 'popitem') is True)
    assert (has_any_callables(a, 'pop', 'popitem', 'popitem', 'pop1') is True)
    assert (has_any_callables(a, 'pop', 'popitem', 'popitem', 'pop1', 'pop2') is True)
    assert (has_any_callables(a, 'pop', 'popitem', 'popitem', 'pop1', 'pop2', 'pop3') is True)

# Generated at 2022-06-11 22:28:48.517610
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1,b=2)

    assert has_any_callables(obj,"get","keys","items","values","foo") is True
    assert has_any_callables(obj,"foo","bar") is False


# Generated at 2022-06-11 22:28:58.604448
# Unit test for function has_callables
def test_has_callables():
    from pprint import pprint
    from flutils.datastructures import DictObject
    d = DictObject(foo=dict(bar=[1, 2, 3, 4]))
    pprint(has_callables(d, 'get', 'keys', 'items', 'values'))
    pprint(has_callables(d, 'get', 'keys', 'items', 'values', 'foo'))
    pprint(has_callables(d, 'get', 'keys', 'items', 'values', 'foo', 'bar'))
    pprint(has_callables(d, 'get', 'keys', 'items', 'values', 'something'))


# Generated at 2022-06-11 22:29:06.841168
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'baz', 'values', 'foo') is False
    assert has_any_callables(dict(a=2), 'get', 'foobar', 'baz', 'values', 'foo') is True
    assert has_any_callables(dict(a=2, b=3), 'get', 'keys', 'baz', 'values', 'foo') is True
    assert has_any_callables(dict(a=2, b=3), 'get', 'keys', 'baz', 'values', 'foobar') is False

# Generated at 2022-06-11 22:29:08.080164
# Unit test for function has_any_callables
def test_has_any_callables():
  obj = dict(a=1,b=2)
  res = has_any_callables(obj,'foo','keys','items','values')
  assert res is True


# Generated at 2022-06-11 22:29:18.012570
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')

    # test of tzlocal
    import datetime
    import tzlocal

    assert has_any_attrs(tzlocal.get_localzone(),'_tzinfos','localize','tzname')
    assert has_any_callables(tzlocal.get_localzone(),'localize','tzname')

    tz = tzlocal.get_localzone()
    assert has_any_callables(tz,'localize','tzname')
    # noinspection PyTypeChecker
    assert has_any_callables(datetime.datetime(2020, 3, 9, 6, 59, 29),'strftime')

# Generated at 2022-06-11 22:29:22.213077
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables

    obj = dict(a=1, b=2)
    attrs = ('keys', 'items', 'values', 'foo')

    assert has_callables(obj=obj, *attrs) is True


# Generated at 2022-06-11 22:29:26.751381
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something')
    assert has_any_callables(list(),'append','pop','remove','something')
    assert has_any_callables(set(),'add','remove','something')
    assert has_any_callables('foo','capitalize','swapcase')


# Generated at 2022-06-11 22:29:36.116664
# Unit test for function has_callables
def test_has_callables():
        x = {'get': 'callable', 'keys': 'callable'}
        assert has_callables(x, 'get', 'keys') is True


# Generated at 2022-06-11 22:29:42.454643
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(a=1,b=2),'get','keys','items','values')
    assert has_any_callables(list(),'get','keys','items','values','foo')
    assert has_any_callables(list(range(5)),'pop','append','reverse','extend','foo')
    assert has_any_callables(str(),'get','keys','items','values','foo')
    assert has_any_callables(str('hello'),'lower','upper','split','capitalize')


# Generated at 2022-06-11 22:29:46.888520
# Unit test for function has_any_callables
def test_has_any_callables():
    '''
    Unit tests for has_any_callables
    '''
    from collections import deque
    from typing import Tuple
    from collections import UserList
    from collections import OrderedDict
    from collections.abc import ValuesView, KeysView
    from flutils.objutils import has_any_callables

    # Test list-like class types
    klass = [1, 2, 3]
    assert has_any_callables(klass, '__getitem__') is True
    assert has_any_callables(klass, '__setitem__') is True
    assert has_any_callables(klass, '__contains__') is True
    assert has_any_callables(klass, '__iter__') is True
    assert has_any_callables(klass, '__len__') is True

# Generated at 2022-06-11 22:29:49.535343
# Unit test for function has_callables
def test_has_callables():
    print('Testing has_callables')
    obj1 = dict()
    assert has_callables(obj1,'get','keys','items','values') is True


# Generated at 2022-06-11 22:29:55.555935
# Unit test for function has_callables
def test_has_callables():
    # test a callable
    class A(object):
        @classmethod
        def get(cls):
            return None
    assert has_callables(A(), 'get')
    # test a non-callable
    assert not has_callables(A(), '__name__')

if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-11 22:29:59.329008
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar','baz') == False



# Generated at 2022-06-11 22:30:03.517720
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'values', 'items')
    assert not has_any_callables(obj, 'keys', 'values', 'items', 'foo')
    return

# Generated at 2022-06-11 22:30:11.009834
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

    assert has_any_callables(
        ChainMap(), 'get', 'keys', 'items', 'values', 'foo'
    )

    assert has_any_callables(Counter(), 'get', 'keys', 'items', 'values', 'foo')

    assert has_any_callables(
        OrderedDict(), 'get', 'keys', 'items', 'values', 'foo'
    )

    assert has_any_callables(UserDict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:30:18.923519
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'items', 'values')
    assert has_any_callables(dict(), 'values')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo')



# Generated at 2022-06-11 22:30:22.105073
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'foo','bar','bar','baz','values','items','keys','get')


# Generated at 2022-06-11 22:30:35.048021
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-11 22:30:38.049275
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'foo', 'bar') is False


# Unit tests for function has_attrs

# Generated at 2022-06-11 22:30:40.480917
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'foo') == True
    assert has_any_callables(dict(), 'foo', 'bar') == False


# Generated at 2022-06-11 22:30:47.766861
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__iter__') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__iter__', '__len__') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__iter__', '__len__', '__getitem__') == True



# Generated at 2022-06-11 22:30:53.694118
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'keys') == True



# Generated at 2022-06-11 22:30:57.123924
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=3, b=2)
    assert has_callables(
        obj,
        '__contains__',
        'get'
    )



# Generated at 2022-06-11 22:31:04.074475
# Unit test for function has_callables
def test_has_callables():
    class TestClass():
        def __init__(self):
            self.foo = self.call_FOO

        def call_FOO(self):
            print("FOO")

    assert has_callables(TestClass(), 'foo', 'call_FOO') == True
    assert has_callables(TestClass(), 'foo') == True
    assert has_callables(TestClass(), 'call_FOO') == True
    assert has_callables(TestClass(), 'foo', 'call_BAR') == False


# Generated at 2022-06-11 22:31:08.777883
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2, c=3)
    assert has_callables(obj, 'get', 'pop') is True
    assert has_callables(obj, 'get', 'foo') is False
    assert has_callables(obj, 'get', 'foo', 'items') is False



# Generated at 2022-06-11 22:31:13.758837
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') == True


# Generated at 2022-06-11 22:31:19.102016
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    class Foo:
        def hello(self):
            return 'world'
    
    obj = Foo()
    assert has_any_callables(obj, 'hello') == True
    assert has_any_callables(obj, 'goodbye') == False



# Generated at 2022-06-11 22:31:38.398649
# Unit test for function has_callables
def test_has_callables():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:31:50.200337
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_call

# Generated at 2022-06-11 22:32:02.272596
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    import unittest
    from flutils.objutils import has_callables

    def mymethod(self) -> str:
        """Just a placeholder method.

        Args:
            self: The current instance.

        :rtype:
            :obj:`str`

        Example:
            >>> from flutils.objutils import has_callables
            >>> def mymethod(self): return "success"
            >>> class myclass:pass
            >>> mc = myclass()
            >>> mc.mymethod = mymethod
            >>> has_callables(mc, 'mymethod')
            True
        """
        return 'success'


# Generated at 2022-06-11 22:32:09.625607
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import (
        UserDict as _UserDict,
    )

    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(_UserDict(),'get','keys','items','values','foo') is True
    assert has_any_callables(_UserDict(),'foo','bar','baz','something') is False



# Generated at 2022-06-11 22:32:11.202741
# Unit test for function has_callables
def test_has_callables():
    # unit test for function has_callables
    raise NotImplementedError

# Generated at 2022-06-11 22:32:20.347943
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from typing import Any as _Any

    _LIST_LIKE = (
        list,
        set,
        frozenset,
        tuple,
        deque,
        Iterator,
        ValuesView,
        KeysView,
        UserList
    )



# Generated at 2022-06-11 22:32:23.838932
# Unit test for function has_callables
def test_has_callables():
    import unittest
    from . import objutils
    class FakeDict(object):
        def get(self, key, default=None):
            return default
    class TestObjUtils(unittest.TestCase):
        def test_has_callables(self):
            fake_dict = FakeDict()
            self.assertEqual(objutils.has_callables(fake_dict, 'get', 'foo'),
                             True)
    unittest.main()

# Generated at 2022-06-11 22:32:32.271185
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict
    d = OrderedDict([
        ('b', 1),
        ('c',2),
        ('a',3),
    ])
    assert has_any_callables(d, 'clear') is True
    assert has_any_callables(d, 'clear', 'items') is True
    assert has_any_callables(d, 'clear', 'items','something') is True
    assert has_any_callables(d, 'clear', 'something','foo') is True
    assert has_any_callables(d, 'something','foo') is False


# Generated at 2022-06-11 22:32:44.124346
# Unit test for function has_any_callables
def test_has_any_callables():
    class Empty:
        pass

    class Bar:
        def foo(self):
            return u''

    class Foo:
        def foo(self):
            return u''

        def bar(self):
            return u''

    obj = {'foo', 'bar'}
    assert has_any_callables(obj, 'foo') is True
    assert has_any_callables(obj, 'foo', 'bar') is False
    assert has_any_callables(obj, 'foo', 'bar', 'baz') is False
    assert has_any_callables(obj, 'foo', 'bar', 'baz', 'copy') is True

    obj = set()
    assert has_any_callables(obj, 'foo') is False

    obj = Bar()
    assert has_any_callables(obj, 'foo') is True

# Generated at 2022-06-11 22:32:49.236136
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False



# Generated at 2022-06-11 22:33:11.698638
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import is_list_like, has_callables
    obj = dict(a=1, b=2)
    res = has_callables(obj, "get", "foo")
    exp = False
    assert res == exp
    res = has_callables(obj, "get", "keys")
    exp = True
    assert res == exp
    res = has_callables(sorted("hello"), "get", "keys")
    exp = False
    assert res == exp
    res = has_callables(sorted("hello"), "get", "__getitem__")
    exp = True
    assert res == exp
    res = is_list_like(sorted("hello"))
    exp = True
    assert res == exp



# Generated at 2022-06-11 22:33:14.554848
# Unit test for function has_callables
def test_has_callables():
    test_obj = dict()
    test_obj['callable'] = lambda: None
    assert has_callables(test_obj, 'callable')



# Generated at 2022-06-11 22:33:20.163173
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'items', 'values')
    assert has_callables(obj=obj, *attrs) is True
    attrs = ('get', 'keys', 'items', 'values', 'foo')
    assert has_callables(obj=obj, *attrs) is False

# Generated at 2022-06-11 22:33:25.265338
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(2,'get','keys','items','values')
    assert not has_callables(dict(),'get','keys','items','hello')

if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-11 22:33:33.272111
# Unit test for function has_callables
def test_has_callables():
    import random

    # Define a dummy class
    class MyClass:
        "A dummy class"
        def __init__(self):
            self._a = random.randint(1,10)
            self._b = random.randint(1,10)

        def method1(self):
            return self._a

        def method2(self):
            return self._b

    myobj = MyClass()
    assert has_callables(myobj, "method1", "method2") is True

    myobj = MyClass()
    assert has_callables(myobj, "method1", "method2", "something") is False



# Generated at 2022-06-11 22:33:37.039271
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    a = dict(a=1)
    assert has_any_callables(a, 'get', 'keys', 'values', 'items') is True



# Generated at 2022-06-11 22:33:40.088245
# Unit test for function has_callables
def test_has_callables():
    d = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert has_callables(d, 'keys', 'items', 'values')



# Generated at 2022-06-11 22:33:45.500573
# Unit test for function has_callables
def test_has_callables():
    """Test has_callables function
    """
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','foobar','values') == False
    assert has_callables(dict(),'get','foobar','items','values') == False


# Generated at 2022-06-11 22:33:50.098382
# Unit test for function has_any_callables
def test_has_any_callables():
    # Testing has_any_callables
    # This test is broken, since the functions being called don't exist
    # and so it should return False
    a = (has_any_callables(dict(), 'keys', 'values'))
    assert a == True


# Generated at 2022-06-11 22:33:52.426086
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'values')
    assert not has_callables(dict(),'get','keys','items','something')



# Generated at 2022-06-11 22:34:17.918705
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'foo')



# Generated at 2022-06-11 22:34:25.269778
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils.tests.objutilshelper import ObjUtilsHelper
    obj_utils_helper = ObjUtilsHelper()

    # Test passing a callable object
    obj = obj_utils_helper.test_func

    attrs = {
        '__call__': True,
        '__class__': True,
        '__doc__': True,
        '__init__': True,
        '__module__': True,
        '__name__': False
    }

    for key in attrs:
        assert has_callables(obj, key) == attrs[key]

    # Test passing a non-callable object
    obj = obj_utils_helper

    for key in attrs:
        assert has_callables(obj, key) == attrs[key]

# Generated at 2022-06-11 22:34:36.167771
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    assert has_any_callables(dict(),'get','keys','items') is True
    assert has_any_callables(dict(),'foo','bar','baz') is False
    assert has_any_callables(dict(),'__init__','__str__') is False
    try:
        assert has_any_callables(dict(),['foo','bar']) is True
    except TypeError as ex:
        assert 'is not iterable' in str(ex)
    assert has_any_callables(dict()) is False


# Generated at 2022-06-11 22:34:42.564487
# Unit test for function has_callables
def test_has_callables():
    import unittest
    from collections import ChainMap

    class Foo:
        def __init__(self, *args, **kwargs):
            self._chain_map = ChainMap(*args, **kwargs)

        def __getattr__(self, item):
            value = getattr(self._chain_map, item)
            if callable(value):
                return value

    class TestHasCallables(unittest.TestCase):
        def test_has_callables(self):
            foo_dict = dict(a=1, b=2)
            foo = Foo(foo_dict, globals(), locals())
            self.assertTrue(has_callables(foo, 'copy', 'maps', 'new_child'))

# Generated at 2022-06-11 22:34:47.671033
# Unit test for function has_any_callables
def test_has_any_callables():
    _dict=dict()
    _list=list()
    _string='hello'
    _int=3
    assert has_any_callables(_dict,'keys')==True
    assert has_any_callables(_list,'keys')==False
    assert has_any_callables(_string,'keys')==False
    assert has_any_callables(_int,'keys')==False


# Generated at 2022-06-11 22:34:58.306834
# Unit test for function has_callables
def test_has_callables():
    # Verify that an object that has all attributes, but not all callable, fails
    d = dict()
    assert has_callables(d, 'get', 'keys', 'items', 'values', 'update') is True
    assert has_callables(d, 'get', 'keys', 'items', 'values', 'update', 'foo') is False

    # Verify that a non-existant attribute fails the check
    assert has_callables(d, 'get', 'keys', 'items', 'values', 'foo') is False

    # Verify that a non-existant attribute and a non-callable attribute fails
    assert has_callables(d, 'get', 'keys', 'items', 'values', 'foo', 'update') is False



# Generated at 2022-06-11 22:35:00.800493
# Unit test for function has_callables
def test_has_callables():
    # Arrange
    obj = dict(a=1, b=2)

    # Act/Assert
    assert has_callables(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:35:11.981384
# Unit test for function has_callables
def test_has_callables():
    d = dict(a=1,b=2)
    assert has_callables(d, 'items') == True
    assert has_callables(d, 'values', 'keys') == True
    assert has_callables(d, 'values', 'items') == True
    assert has_callables(d, 'keys', 'items') == True
    assert has_callables(d, 'values', 'items', 'keys') == True
    assert has_callables(d, 'foo') == False
    assert has_callables(d, 'foo', 'keys') == False
    assert has_callables(d, 'foo', 'bar', 'items') == False



# Generated at 2022-06-11 22:35:18.012557
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True  # noqa
    obj = ''
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False  # noqa
    obj = 1
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False  # noqa
    obj = list()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False  # noqa
    obj = set()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False  # noqa



# Generated at 2022-06-11 22:35:23.764879
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'values') is True
    assert has_any_callables(obj, 'keys', 'values', 'items', 'foo') is True
    assert has_any_callables(obj, 'keys', 'values', 'items', 'foo', 'bar') is False

