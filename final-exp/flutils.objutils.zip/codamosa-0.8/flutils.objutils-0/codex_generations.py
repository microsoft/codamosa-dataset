

# Generated at 2022-06-11 22:25:30.700429
# Unit test for function has_any_callables
def test_has_any_callables():
    a = dict()
    assert has_any_callables(a, 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-11 22:25:33.157378
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'foo','bar','baz','snafu','zorp') is False


# Generated at 2022-06-11 22:25:36.985399
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test actual input
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-11 22:25:42.004754
# Unit test for function has_callables
def test_has_callables():
    # Arrange
    class Test:
        pass

    testObj = Test()
    testObj.callable1 = lambda a: a
    testObj.callable2 = lambda b: b

    # Act
    result = has_callables(testObj, 'callable1', 'callable2')

    # Assert
    assert result is True


# Generated at 2022-06-11 22:25:48.852446
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(a=1,b=2),'keys','items','values') is True
    assert has_any_callables(dict(a=1,b=2),'keys','items','foo') is True
    assert has_any_callables(dict(a=1,b=2),'xxx','yyy','foo') is False


# Generated at 2022-06-11 22:25:51.784634
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get','keys','items','values') == True


# Generated at 2022-06-11 22:25:56.478016
# Unit test for function has_any_callables
def test_has_any_callables():
    assert callable(has_any_callables) is True
    assert has_any_callables({}, *dict.__dict__) is True
    assert has_any_callables({}, *dict.__dict__.keys()) is True
    assert has_any_callables({}, 'pop', 'not') is True



# Generated at 2022-06-11 22:25:59.077601
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-11 22:26:09.408780
# Unit test for function has_callables
def test_has_callables():
    # Given: A dict with keys(), items(), and values() methods
    obj = dict(a=1, b=2)
    # Then: calling has_callables returns True
    # WHEN: checking for keys(), items(), and values()
    assert has_callables(obj, 'keys', 'items', 'values') is True
    # AND: returns False when checking for keys(), items(), and foo()
    assert has_callables(obj, 'keys', 'items', 'foo') is False
    # AND: returns False when checking for keys(), foo(), and values()
    assert has_callables(obj, 'keys', 'foo', 'values') is False
    # AND: returns False when checking for foo(), items(), and values()
    assert has_callables(obj, 'foo', 'items', 'values') is False
    # AND: returns False when checking

# Generated at 2022-06-11 22:26:14.488454
# Unit test for function has_any_callables
def test_has_any_callables():
    class Test:
        def my_callables(self):
            pass
        pass
    test = Test()
    assert has_any_callables(test, 'my_callable') is False
    assert has_any_callables(test, 'my_callables') is True


# Generated at 2022-06-11 22:26:26.973083
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'copy', 'fromkeys', 'get', 'items', 'keys', 'values')
    assert has_attrs(dict(), 'copy', 'fromkeys', 'get', 'items', 'keys', 'values') is True
    assert has_attrs(dict(), 'copy', 'fromkeys', 'get', 'items', 'keys', 'values') is not False
    assert has_attrs(dict(), 'copy', 'fromkeys', 'get', 'items', 'keys', 'values') is not None
    assert has_attrs(dict(), 'copy', 'fromkeys', 'get', 'items', 'keys', 'values') is not str
    assert has_attrs(dict(), 'copy', 'fromkeys', 'get', 'items', 'keys', 'values') is not int

# Generated at 2022-06-11 22:26:35.902216
# Unit test for function has_callables
def test_has_callables():
    original_method = has_callables
    def _has_callables(obj, expected_values, callable_attrs):
        assert all(
            expected_value == original_method(obj, *callable_attr)
            for expected_value, callable_attr in zip(expected_values, callable_attrs)
        ), \
        (
            f'Test failed for params({obj}, *{callable_attrs})\n'
            f'Expected: {expected_values}\n'
            f'Got:      {[original_method(obj, *attrs) for attrs in callable_attrs]}'
        )
    # Test if the length of the callable_attrs is 1
    _has_callables(None, [False], [['__class__']])

# Generated at 2022-06-11 22:26:43.745899
# Unit test for function has_callables
def test_has_callables():
    '''
    Purpose:
        Unit test function has_callables.
    '''
    from collections import defaultdict
    d = defaultdict(dict)
    if has_callables(d, "get", "keys", "items") is True:
        print("The d object has 'get', 'keys', and 'items' attributes.")
    else:
        print("The d object does not have 'get', 'keys', and 'items' \
                attributes.")


# Generated at 2022-06-11 22:26:48.130286
# Unit test for function has_callables
def test_has_callables():
    class myclass():
        def __call__(self):
            pass
        def foo(self):
            pass

    mycls = myclass()

    assert not has_callables(mycls, '__class__')
    assert not has_callables(mycls)
    assert not has_callables(mycls, 'foo', '__class__')
    assert has_callables(mycls, '__call__')
    assert has_callables(mycls, '__call__', 'foo')

    #executed_successfully()
    print("test executed_successfully")


# Generated at 2022-06-11 22:27:01.251700
# Unit test for function has_callables
def test_has_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    )
    import decimal
    import os
    import re
    import time
    obj1 = dict()
    obj2 = 'hello'
    obj3 = 123
    obj4 = (1, 2, 3)
    obj5 = os.path
    obj6 = tuple
    obj7 = int
    obj8 = re.compile(r'\bhello\b')
    obj9 = time.time
    obj10 = time
    obj11 = time.time()
    obj12 = decimal.Decimal
    obj13 = decimal.Decimal('1.1')
    obj14 = decimal
    obj15 = decimal.Decimal.to_eng_string

# Generated at 2022-06-11 22:27:06.948242
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables, has_any_attrs
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-11 22:27:09.839517
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'get', 'items') is True



# Generated at 2022-06-11 22:27:19.565197
# Unit test for function has_callables
def test_has_callables():
    import pytest

    # Create a class with attributes that are callables
    obj1 = type(str('obj1'), (), dict(foo=lambda: 'foo', bar=lambda: 'bar'))

    # Create an instance of the class
    obj = obj1()

    # Ensure we get the expected result
    assert has_callables(obj, 'foo', 'bar') is True

    # Create a class with attributes that are not callables
    obj2 = type(str('obj2'), (), dict(foo='foo', bar='bar'))

    # Create an instance of the class
    obj = obj2()

    # Ensure we get the expected result
    assert has_callables(obj, 'foo', 'bar') is False

    # One of the attributes is callable, one is not
    with pytest.raises(AttributeError):
        has_

# Generated at 2022-06-11 22:27:25.234002
# Unit test for function has_callables
def test_has_callables():
    class Foo:
        def bar(self):
            pass

        def baz(self):
            pass

    foo = Foo()
    assert has_callables(foo, 'bar', 'baz') is True
    assert has_callables(foo, 'bar', 'baz', 'qux') is False



# Generated at 2022-06-11 22:27:33.766597
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables as hc
    from types import FunctionType
    assert hc(range, '__len__', '__iter__') is True
    assert hc(range, '__len__', '__iter__', '__reversed__') is True
    assert hc(range, '__len__', '__iter__', '__next__') is True
    assert hc(range, '__len__', '__iter__', '__sub__') is False
    assert hc(range, '__len__', '__iter__', '__sub__', '__lt__') is False
    assert hc(range, '__len__', '__iter__', '__sub__', '__lt__', '__le__') is \
        False

# Generated at 2022-06-11 22:27:51.711321
# Unit test for function has_callables
def test_has_callables():
    import pytest
    # Functions:
    def my_func():
        pass
    # Objects:
    my_obj = type('MyObj', (), {})
    my_obj.my_func = my_func
    # Tests:
    assert has_callables(my_obj, 'my_func') is True
    assert has_callables(my_obj, 'does_not_exist') is False
    assert has_callables(my_obj, 'my_func', 'does_not_exist') is False
    assert has_callables(my_obj, 'does_not_exist', 'my_func') is False
    assert has_callables(my_obj, 'my_func', 'my_func') is True
    with pytest.raises(TypeError):
        has_callables(my_obj)

# Generated at 2022-06-11 22:27:54.832640
# Unit test for function has_callables
def test_has_callables():
    test = {'foo': 'bar'}

    assert has_callables(test, 'keys') is True
    assert has_callables(test, 'foo') is False
    assert has_callables(test, 'keys', 'foo') is False

# Generated at 2022-06-11 22:27:57.258321
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict()
    f = "size"
    assert has_any_callables(d, f) is False
    assert has_any_callables() is False


# Generated at 2022-06-11 22:28:01.298315
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items') is True
    assert has_callables(obj, 'get', 'keys', 'foo') is False


# Generated at 2022-06-11 22:28:07.345882
# Unit test for function has_callables
def test_has_callables():
    d = {'a': 123}
    assert has_callables(d,'get')
    assert has_callables(d,('get',))
    assert has_callables(d,('get', 'keys', 'values'))
    assert not has_callables(d, ['get', 'keys', 'values'])
    assert not has_callables(d)
    assert not has_callables(d, ['get', 'foobar'])
    assert not has_callables(d, ('get', 'foobar'))
    assert not has_callables(d, 'foobar')


# Generated at 2022-06-11 22:28:10.381461
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict as odict
    result = has_callables(odict(),'get','keys','iterms','values')
    #assert result is False
    assert result == False


# Generated at 2022-06-11 22:28:19.028688
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list, "append")
    assert has_callables(dict, "keys", "values")
    assert has_callables(dict, "keys", "values", "a") is False
    assert has_callables(dict, "items", "values", "a") is False
    assert has_callables(dict, "keys", "values", "update")
    assert has_callables(iter(["a", "b"]), "__next__", "__iter__")
    assert has_callables(tuple(["a", "b"]), "__iter__")
    assert has_callables(1, "__repr__")
    assert has_callables(int, "__repr__", "__add__") is False


# Generated at 2022-06-11 22:28:30.163073
# Unit test for function has_callables
def test_has_callables():
    obj = [(1, 2), (4, 5, 6), (3, )]
    assert has_callables(obj, '__iter__') == True
    assert has_callables(obj, '__iter__', '__getitem__') == True
    assert has_callables(obj, '__iter__', '__getitem__', '__len__') == True

    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items') == True
    assert has_callables(obj, 'get', 'keys', 'items', 'some_other_method') == False

    obj = str
    assert has_callables(obj, 'format', 'capitalize') == True
    assert has_callables(obj, 'format', 'capitalize', '__getattr__') == False

# Generated at 2022-06-11 22:28:33.964760
# Unit test for function has_callables
def test_has_callables():
    dict_obj = dict()
    assert has_callables(dict_obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-11 22:28:44.033388
# Unit test for function has_callables
def test_has_callables():
    def bar(self):
        pass

    class _Dummy:
        def __init__(self):
            self.foo = bar

    # Check callable and attribute exist
    assert has_callables(_Dummy(), 'foo') is True
    # Check callable exists but attribute does not
    assert has_callables(_Dummy(), 'bar') is False
    # Check callable does not exists and attribute does
    assert has_callables(_Dummy(), 'foo', 'bar') is False
    # Check callable and attribute do not exist
    assert has_callables(_Dummy(), 'bar', 'bar1') is False


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])