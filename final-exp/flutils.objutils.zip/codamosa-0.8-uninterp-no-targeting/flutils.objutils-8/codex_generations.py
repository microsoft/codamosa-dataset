

# Generated at 2022-06-21 12:45:05.693768
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'pop', 'popitem', 'update') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False



# Generated at 2022-06-21 12:45:07.417600
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-21 12:45:13.193758
# Unit test for function is_list_like
def test_is_list_like():
    print(is_list_like([1, 2, 3]))      # True
    print(is_list_like(reversed([1, 2, 4]))) # True
    print(is_list_like('hello'))        # False
    print(is_list_like(sorted('hello')))# True


# Generated at 2022-06-21 12:45:21.324843
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        deque,
        namedtuple,
    )
    from decimal import Decimal
    import math
    import operator
    import random
    import types
    import unittest

    class TestListLike(unittest.TestCase):
        """A TestCase for the function `is_list_like`."""

        def test_list_like_none(self):
            """Test that None is NOT list-like."""
            self.assertFalse(is_list_like(None))

        def test_list_like_basic(self):
            """Test that basic Python types are NOT list-like."""

# Generated at 2022-06-21 12:45:25.495861
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    return is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:45:36.022104
# Unit test for function is_list_like
def test_is_list_like():
    import flutils
    import collections
    import decimal

    class C(object):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(D):
        pass

    class G(D):
        pass

    class H(D):
        pass


# Generated at 2022-06-21 12:45:45.979323
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like([1]) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) is True
    assert is_list_like([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) is True
    assert is_list_like([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) is True
    assert is_list_like([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) is True
    assert is_list_like({1, 2, 3, 4, 5, 6, 7, 8, 9, 10}) is True

# Generated at 2022-06-21 12:45:52.228038
# Unit test for function is_list_like
def test_is_list_like():
    """Check that is_list_like() works as expected on some examples."""
    # Check that `is_list_like` returns True for some known list-like objects
    list_like_objs = [
        UserList,
        Iterator,
        ValuesView,
        KeysView,
        deque,
        frozenset,
        list,
        set,
        tuple
    ]
    list_like_objs = [list_like_obj(), list_like_obj]
    assert all(is_list_like(obj) for obj in list_like_objs) is True

    # Check that `is_list_like` returns False for some known non-list-like objs

# Generated at 2022-06-21 12:46:01.769651
# Unit test for function is_list_like
def test_is_list_like():

    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like(sorted('hello'))
    assert not is_list_like('hello')
    assert not is_list_like(None)
    assert not is_list_like(True)
    assert not is_list_like(1)
    assert not is_list_like(1.0)
    assert not is_list_like('hello')
    assert not is_list_like(b'hello')

# Generated at 2022-06-21 12:46:10.755231
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for function has_attrs
    """
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(obj, 'get', 'keys', 'items', 'values', 'something') is False
    assert has_attrs(
        dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'something'
    ) is False
    assert has_attrs(set([1, 2, 3]), '__iter__') is True



# Generated at 2022-06-21 12:46:16.552145
# Unit test for function is_list_like
def test_is_list_like():
    assert(is_list_like([]) == True)
    assert(is_list_like([1]) == True)
    assert(is_list_like([1,2,3]) == True)
    assert(is_list_like(([1,2,3])) == True)
    assert(is_list_like(({1,2,3})) == True)
    assert(is_list_like(({1})) == True)
    assert(is_list_like({}) == False)
    assert(is_list_like((1, 2, 3)) == True)
    assert(is_list_like(tuple()) == True)
    assert(is_list_like(tuple([1, 2, 3])) == True)
    assert(is_list_like(set()) == True)

# Generated at 2022-06-21 12:46:19.524035
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:46:26.229619
# Unit test for function has_callables
def test_has_callables():
    # Test data
    test_dict = {'a':1, 'b':2}
    # Test the function
    retval = has_callables(test_dict, 'keys', 'items', 'values')
    assert retval == True
    retval = has_callables(test_dict, 'keys', 'foo', 'values')
    assert retval == False
    retval = has_callables(test_dict, 'foo')
    assert retval == False
    retval = has_callables(None, 'foo')
    assert retval == False
    retval = has_callables(test_dict, None)
    assert retval == False

# Generated at 2022-06-21 12:46:30.161329
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'keys', 'values') is True
    assert has_attrs(obj, 'foo', 'bar') is False



# Generated at 2022-06-21 12:46:33.009847
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'get','keys','something')


# Generated at 2022-06-21 12:46:35.013264
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-21 12:46:39.458058
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'update') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'update', 'foo') is False



# Generated at 2022-06-21 12:46:43.786606
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict(a=1, b=2),'get','keys','items','values')


# Generated at 2022-06-21 12:46:47.926261
# Unit test for function has_attrs
def test_has_attrs():
    # Arrange
    expected_result = True
    test_obj = dict(a=1, b=2)

    # Act
    result = has_attrs(test_obj, 'get', 'keys', 'items', 'values')

    # Assert
    assert result == expected_result


# Generated at 2022-06-21 12:46:54.557217
# Unit test for function has_any_callables
def test_has_any_callables():
    # Create dict with callables
    obj_callables = dict(
        get=lambda: None,
        keys=lambda: None,
        items=lambda: None,
        values=lambda: None
    )
    assert (has_any_callables(obj_callables,'get','keys','values') == True)
    assert (has_any_callables(obj_callables,'foo','bar','baz','qux') == False)


# Generated at 2022-06-21 12:47:02.586695
# Unit test for function has_attrs
def test_has_attrs():
    from collections import namedtuple
    from flutils.objutils import has_attrs
    TestObj = namedtuple('TestObj', ('a', 'b', 'c'))
    assert has_attrs(dict(a=1, b=1, c=1), 'a', 'b', 'c')
    assert has_attrs(TestObj(a=1, b=1, c=1), 'a', 'b', 'c')
    assert not has_attrs(dict(a=1, b=1, c=1), 'a', 'b', 'c', 'd')
    assert not has_attrs(TestObj(a=1, b=1, c=1), 'a', 'b', 'c', 'd')



# Generated at 2022-06-21 12:47:06.353795
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(a=1), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-21 12:47:13.531298
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Unit test for :func:`is_subclass_of_any <flutils.objutils.is_subclass_of_any>`
    """
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

    assert is_subclass_of_any(obj.values(), UserList, KeysView) == False

# Generated at 2022-06-21 12:47:16.216414
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')



# Generated at 2022-06-21 12:47:19.000658
# Unit test for function has_attrs
def test_has_attrs():
    mydict = {"a": 1, "b": 2}
    assert has_attrs(mydict, "get", "keys", "items", "values") is True



# Generated at 2022-06-21 12:47:29.085785
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test the function has_any_callables
    """
    from random import randint
    from collections import deque
    from collections.abc import Iterator
    from flutils.objutils import (
        has_any_callables,
        has_any_attrs,
        has_callables,
        has_attrs,
    )
    def foo():
        return 'foo'

    d = dict(
        a=1,
        b=2,
        c=3,
        d=4,
        e=5,
        f=6,
        __getitem__=foo,
        get=foo,
        __eq__=foo,
        __hash__=foo,
        __add__=foo,
        __sub__=foo,
    )

# Generated at 2022-06-21 12:47:35.067116
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    import pytest
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any([], list, tuple)
    assert is_subclass_of_any({}, dict) is False
    
test_is_subclass_of_any()

# Generated at 2022-06-21 12:47:40.987084
# Unit test for function has_callables
def test_has_callables():
    d = dict(a=1, b=2)
    assert has_callables(d, 'get', 'keys', 'values', 'items') is True

    d = dict(a=1, b=2)
    assert has_callables(d, 'get', 'keys', 'values', 'items', 'foo') is False

    d = None
    assert has_callables(d, 'get', 'keys', 'values', 'items') is False



# Generated at 2022-06-21 12:47:49.622323
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserList
    from collections.abc import ValuesView


# Generated at 2022-06-21 12:48:01.121141
# Unit test for function is_list_like
def test_is_list_like():
    """Test function :func:`is_list_like`"""

    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import (
        ItemsView,
    )


# Generated at 2022-06-21 12:48:15.424054
# Unit test for function is_list_like
def test_is_list_like():
    # We are not testing the built-in objects
    test_obj = [
        [], UserList([]), OrderedDict(), Iterator([]),
        ValuesView({}), KeysView({}), deque([]),
        frozenset([]), set([]), tuple([]),
        list(), dict_items([]), dict_keys([]), dict_values([]),
        UserList([]), UserSet(set()), UserString(str()),
        defaultdict(), defaultdict(lambda: 1), Counter(),
        OrderedDict(), ChainMap(),
    ]
    for obj in test_obj:
        assert is_list_like(obj) is True

    test_obj = [
        None, bool(), int(), float(), bytes(), str(), Decimal(),
    ]

# Generated at 2022-06-21 12:48:18.026796
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True

# Generated at 2022-06-21 12:48:22.184669
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'keys', 'values', 'items', 'get')
    assert not has_callables(dict(), 'keys', 'values', 'items', 'foo')



# Generated at 2022-06-21 12:48:26.368548
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs('abcd', 'upper', 'lower', 'split')
    assert not has_attrs('abcd', 'upper', 'lower', 'split', 'something')
    assert not has_attrs('abcd', 'something1', 'something2', 'something3')



# Generated at 2022-06-21 12:48:36.300536
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict
    )

    assert not is_subclass_of_any(123, defaultdict)
    assert not is_subclass_of_any(123, OrderedDict)
    assert not is_subclass_of_any('abc', Counter)
    assert not is_subclass_of_any('abc', UserDict)
    assert not is_subclass_of_any('abc', UserString)

    d = defaultdict()
    assert is_subclass_of_any(d, defaultdict)

    ord_d = OrderedDict()
    assert is_subclass_of_any(ord_d, OrderedDict)

# Generated at 2022-06-21 12:48:44.904014
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.general import Null
    assert is_list_like([]) is True
    assert is_list_like([1, 2,3]) is True
    assert is_list_like({'a': 1, 'b': 2}) is False
    assert is_list_like({'a', 'b'}) is True
    assert is_list_like(Null) is False
    assert is_list_like(reversed(Null)) is True
    assert is_list_like('abc') is False
    assert is_list_like(sorted('abc')) is True

# Generated at 2022-06-21 12:48:55.059824
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(UserList([1, 2, 3]))
    assert is_list_like(Iterator(iter([1, 2, 3])))
    assert is_list_like(ValuesView({1: 'a', 2: 'b', 3: 'c'}))
    assert is_list_like(KeysView({1: 'a', 2: 'b', 3: 'c'}))
    assert is_list_like(deque([1, 2, 3]))
    assert is_list_like(frozenset([1, 2, 3]))
    assert is_list_like(list([1, 2, 3]))
    assert is_list_like(set([1, 2, 3]))
    assert is_list_like(tuple([1, 2, 3]))
    assert is_list_like

# Generated at 2022-06-21 12:48:57.076223
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:48:59.939793
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') == True
    assert has_attrs(dict(),'foo') == False


# Generated at 2022-06-21 12:49:02.795464
# Unit test for function has_any_attrs
def test_has_any_attrs():
    x = has_any_attrs(dict(),'get','keys','items','values','foo')
    assert x == True
    x =has_any_attrs(dict(),'foo')
    assert x == False


# Generated at 2022-06-21 12:49:13.735126
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables

    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:49:25.599359
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )

    assert is_list_like(tuple()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(list()) is True
    assert is_list_like(UserList()) is True
    assert is_list_like(tuple(range(0,10))) is True
    assert is_list_like(set(range(0,10))) is True
    assert is_list_like(frozenset(range(0,10))) is True
    assert is_list_like(list(range(0,10))) is True
    assert is_

# Generated at 2022-06-21 12:49:38.783891
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections.abc import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.values(), ValuesView) is True
    assert is_subclass_of_any(obj.keys(), ValuesView) is False
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView) is True
    assert is_subclass_of_any(list(obj), ValuesView, KeysView) is True
    assert is_subclass_of_any(list(obj), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(list(obj), UserList) is True
    assert is_subclass_of_any(list(obj), UserList, str) is False
    return True


# Generated at 2022-06-21 12:49:42.414771
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    try:
        assert has_any_callables(dict(),'get','keys','items','values','foo')
    except Exception:
        raise AssertionError("Failed comparing has_any_callables")


# Generated at 2022-06-21 12:49:48.386591
# Unit test for function has_attrs
def test_has_attrs():
    assert True is has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert True is has_attrs(dict(), 'update', 'get', 'keys', 'items', 'values')
    assert False is has_attrs(dict(), 'foo', 'update', 'get', 'keys', 'items',
                              'values')



# Generated at 2022-06-21 12:49:58.899190
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = ['a', 'b', 'c']
    first, second, third = 'a', 'b', 'c'
    attrs = [
        'a',
        'abc',
        'append',
        'b',
        'c',
        'clear',
        'copy',
        'count',
        'extend',
        'index',
        'insert',
        'pop',
        'remove',
        'reverse',
        'sort',
    ]
    assert has_any_attrs(obj, *attrs) is True
    assert has_any_attrs(obj, *obj) is True
    assert has_any_attrs(obj, first, second, third) is True
    assert has_any_attrs(obj, 'a', 'b', 'c') is True
    assert has_any_

# Generated at 2022-06-21 12:50:02.625054
# Unit test for function has_callables
def test_has_callables():
    # Test object without named attributes
    assert has_callables(None, 'foo') is False
    # Test object with named attributes
    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(a=1), 'pop') is True


# Generated at 2022-06-21 12:50:08.743472
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables"""
    assert has_callables(dict(), 'keys', 'items', 'values')
    assert has_callables(dict(), 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(a=1, b=2), 'keys', 'items', 'values')
    assert sorted(has_callables(dict(a=1, b=2), 'keys', 'items', 'values', 'foo')) == sorted([1, 2])
    assert has_callables(dict(a=1, b=2, foo=3), 'keys', 'items', 'values', 'foo')
    assert has_callables(dict(a=1, b=2, foo=3), 'keys', 'items', 'values') is False

# Generated at 2022-06-21 12:50:19.928240
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','keys','items') is True
    assert has_attrs(dict(),'get','keys') is True
    assert has_attrs(dict(),'get') is True
    assert has_attrs(dict(),'get', 'bar') is False
    assert has_attrs(dict(),'get', 'bar', 'foo') is False
    assert has_attrs(dict(),'bar', 'foo') is False



# Generated at 2022-06-21 12:50:29.536643
# Unit test for function is_list_like
def test_is_list_like():
    # Types that are lists
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 3]))
    assert is_list_like(sorted([1, 2, 3]))
    assert is_list_like(set([1, 2, 3]))
    assert is_list_like(frozenset([1, 2, 3]))
    assert is_list_like(tuple([1, 2, 3]))
    assert is_list_like(deque([1, 2, 3]))
    assert is_list_like(dict.fromkeys([1, 2, 3]))
    assert is_list_like(UserList([1, 2, 3]))

# Generated at 2022-06-21 12:51:04.143949
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(UserList())
    assert is_list_like(Iterator([1, 2, 3]))
    assert is_list_like(KeysView({'a': 1, 'b': 2}))
    assert is_list_like(ValuesView({'a': 1, 'b': 2}))
    assert is_list_like(deque())
    assert is_list_like(frozenset())
    assert is_list_like(list())
    assert is_list_like(set())
    assert is_list_like(tuple())
    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(b'') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_

# Generated at 2022-06-21 12:51:15.146964
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from decimal import Decimal
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )

    assert is_list_like([]) is True
    assert is_list_like(tuple()) is True
    assert is_list_like({}) is False
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(iter([])) is True
    assert is_list_like(dict().keys()) is True
    assert is_list_like(dict().values()) is True
    assert is_list_like(UserList())

# Generated at 2022-06-21 12:51:18.249040
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    print(has_attrs(obj, 'update', 'values'))     # True
    print(has_attrs(obj, 'update', 'a'))          # False



# Generated at 2022-06-21 12:51:27.483073
# Unit test for function is_list_like
def test_is_list_like():
    """ Unit test for function is_list_like """
    # This test function has incomplete coverage
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(list(sorted('hello'))) is True
    assert is_list_like(set()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(frozenset([])) is True
    assert is_list_like(dict(a=1)) is False
    assert is_list_like(deque()) is True



# Generated at 2022-06-21 12:51:31.275062
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'keys', 'items') == True
    assert has_attrs(obj, 'has_key') == False


# Generated at 2022-06-21 12:51:39.136271
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import (
        has_callables,
    )
    from flutils.objutils import (
        has_any_callables,
    )
    class Test(object):
        def __init__(self):
            self.method = lambda x: x
            self.attr = 'attr'
            self.callable = lambda x: x

    test = Test()
    assert has_callables(test, 'method') is True
    assert has_callables(test, 'method', 'callable') is True
    assert has_callables(test, 'method', 'callable', 'attr') is False
    assert has_callables(test, 'method', 'callable', 'foo') is False
    assert has_callables(test, 'foo') is False
    assert has_callables(test) is False


# Generated at 2022-06-21 12:51:44.426005
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'voik', 'yar') is False
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', '__bool__') is False
    # dict.__str__ is not callable, but it exists
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', '__str__') is False


# Generated at 2022-06-21 12:51:55.921453
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables(dict(), 'foo', 'bar') is False
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(a=1, b=2), 'keys', 'items', 'values') is True

# Generated at 2022-06-21 12:51:59.197335
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class A(object):

        def foo(self):
            pass
    a = A()
    assert has_any_attrs(a, 'foo', 'bar') is True
    assert has_any_attrs(a, 'nope', 'bar') is False


# Generated at 2022-06-21 12:52:05.484230
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import (
        Container,
        Hashable,
        Iterable,
        Iterator,
        KeysView,
        Sized,
        ValuesView,
    )
    from decimal import Decimal
    from flutils.objutils import is_list_like

    # Importing the following 3 modules seems to cause the
    # `is_subclass_of_any` function to break.
    # from importlib import reload
    # from io import StringIO
    # from types import SimpleNamespace

    assert is_list_like(list()) is True
    assert is_list_like(tuple()) is True

# Generated at 2022-06-21 12:52:33.497296
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict, '__getitem__') is True
    assert has_attrs(dict, '__getitem__', 'keys') is True
    assert has_attrs(dict, 'foo') is False
    assert has_attrs(dict, 'foo', 'bar') is False
    assert has_attrs(dict, 'keys', 'foo') is False
    assert has_attrs(None, 'foo') is False


# Generated at 2022-06-21 12:52:37.110015
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(), 'get', 'keys', 'something', 'foo')


# Generated at 2022-06-21 12:52:42.984842
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'asdasd') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'update') is True
    assert has_callables(dict(), 'update') is False



# Generated at 2022-06-21 12:52:45.028399
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'values', 'foo') == True


# Generated at 2022-06-21 12:52:46.505927
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True

# Generated at 2022-06-21 12:52:52.757225
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like((1,2,3))
    assert is_list_like(list(range(10)))
    assert is_list_like('hello')
    assert not is_list_like(5)
    assert not is_list_like(dict())
    assert is_list_like(dict().keys())

if __name__ == '__main__':
    test_is_list_like()

# Generated at 2022-06-21 12:52:55.189387
# Unit test for function has_any_callables
def test_has_any_callables():
    # this is a intentional test failure
    assert has_any_callables(dict(), 'get','keys','items','values','something')


# Generated at 2022-06-21 12:53:01.471739
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    assert isinstance(is_subclass_of_any(dict().keys(), ValuesView, KeysView, UserList), bool)
    assert is_subclass_of_any(dict().keys(), ValuesView, KeysView, UserList)
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj.keys(), UserList)

# Generated at 2022-06-21 12:53:11.959201
# Unit test for function has_attrs
def test_has_attrs():
    from collections import ChainMap
    from flutils.objutils import has_attrs
    from collections import Counter
    from collections import OrderedDict
    from collections import UserDict
    from collections import UserString
    from collections import defaultdict
    import decimal
    import datetime
    import re

    obj = ChainMap(dict(a=1, b=2))
    assert has_attrs(obj, 'maps', 'new_child')

    obj = Counter(dict(a=1, b=2))
    assert has_attrs(obj, 'elements', 'most_common')

    obj = OrderedDict(dict(a=1, b=2))
    assert has_attrs(obj, 'move_to_end', 'popitem')

    obj = UserDict(dict(a=1, b=2))
   

# Generated at 2022-06-21 12:53:22.097367
# Unit test for function is_list_like
def test_is_list_like():
    list_like_classes = (
        UserList,
        Iterator,
        ValuesView,
        KeysView,
        deque,
        frozenset,
        list,
        set,
        tuple,
    )
    assert is_list_like([]) is True
    assert is_list_like({}) is False
    assert is_list_like('hello world') is False
    assert is_list_like(sorted('hello world')) is True
    assert is_list_like(list_like_classes) is True

    assert is_subclass_of_any(dict().values(), UserList, *list_like_classes) is True
    assert is_subclass_of_any(dict().values(), UserList, set, deque) is True

# Generated at 2022-06-21 12:53:54.042632
# Unit test for function has_attrs
def test_has_attrs():
    import unittest
    import collections
    class TestClass(object):
        def __init__(self):
            self.one = {}

    class TestClass2(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    class TestClass3(collections.UserDict):
        pass

    class TestClass4(collections.UserList):
        pass

    class TestClass5(collections.UserString):
        pass

    class TestClass6(dict):
        pass

    class TestClass7(list):
        pass

    class TestClass8(set):
        pass

    class TestClass9(str):
        pass

    class TestClass10(tuple):
        pass

    class TestClass11(collections.Counter):
        pass


# Generated at 2022-06-21 12:53:59.785747
# Unit test for function has_attrs
def test_has_attrs():
    # "Dummy object" a dictionary with the required attributes
    obj = dict(req1='val1', req2='val2')
    assert has_attrs(obj, 'req1', 'req2') is True
    assert has_attrs(obj, 'req3', 'req2') is False
    assert has_attrs(obj, 'req1') is True
    assert has_attrs(obj, 'req1', 'req1', 'req1') is True
    assert has_attrs(None, 'req1') is False
    assert has_attrs(None, '') is False



# Generated at 2022-06-21 12:54:02.329480
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True


# Generated at 2022-06-21 12:54:06.530977
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like('hello') is False



# Generated at 2022-06-21 12:54:07.781555
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for function has_attrs"""
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:54:14.559281
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys') is True
    obj = dict(a=1)
    assert has_callables(obj, 'get', 'keys') is True
    assert has_callables(obj, 'get', 'keys', 'keys') is True
    assert has_callables(obj, 'get', 'keys', 'foo') is True
    assert has_callables(obj, 'get', 'keys', '__init__') is True
    assert has_callables(obj, 'get', 'keys', '__init__', 'foo') is True
    assert has_callables(obj, 'get', 'keys', 'foo', '__dict__') is False
    assert has_callables(obj, 'get', 'keys', 'foo', 'foo') is False

# Generated at 2022-06-21 12:54:24.187445
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like."""
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(1) is False
    assert is_list_like(0) is False
    assert is_list_like(0.0) is False
    assert is_list_like(0.1) is False
    assert is_list_like(b'') is False
    assert is_list_like(b'1') is False
    assert is_list_like(b'0') is False
    assert is_list_like(b'0.0') is False
    assert is_list_like(b'0.1') is False
    assert is_list_like('') is False
    assert is_list_like('1') is False

# Generated at 2022-06-21 12:54:25.840489
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), '__iter__', '__next__', 'items', 'keys')



# Generated at 2022-06-21 12:54:34.392493
# Unit test for function is_list_like
def test_is_list_like():
    # List-like tests
    assert is_list_like(UserList())
    assert is_list_like(Iterator([]))
    assert is_list_like(ValuesView({}))
    assert is_list_like(KeysView({}))
    assert is_list_like(deque([]))
    assert is_list_like(frozenset())
    assert is_list_like([])
    assert is_list_like(set())
    assert is_list_like(tuple())

    # Non-list like tests
    assert not is_list_like(None)
    assert not is_list_like(True)
    assert not is_list_like(False)
    assert not is_list_like(b'')
    assert not is_list_like(ChainMap())
    assert not is_list_like

# Generated at 2022-06-21 12:54:38.650899
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) == True
    assert is_list_like(reversed([1, 2, 4])) == True
    assert is_list_like('hello') == False
    assert is_list_like(sorted('hello')) == True
