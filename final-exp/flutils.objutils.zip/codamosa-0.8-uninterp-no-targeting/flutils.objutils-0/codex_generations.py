

# Generated at 2022-06-21 12:45:18.762859
# Unit test for function has_callables
def test_has_callables():
    cls = dict
    if has_callables(cls, 'get', 'keys', 'values'):
        print('class: {0} has the following methods: {1}'.format(cls, 'get, keys, values'))
    if not has_callables(cls, 'foo'):
        print("class: {0} does not have the foo method".format(cls))
    if callable(getattr(cls, 'get')):
        print("class: {0} has the get method and it's callable".format(cls))

# Generated at 2022-06-21 12:45:22.271936
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_callables(dict(), 'something')


# Generated at 2022-06-21 12:45:30.606356
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(
        obj.keys(),
        (ValuesView, KeysView, UserList))
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView)
    assert is_subclass_of_any(obj.keys(), ValuesView)
    assert is_subclass_of_any(obj.keys(), dict) is False

# unit test for function has_any_callables

# Generated at 2022-06-21 12:45:35.977700
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(reversed([1,2,3,4]),'__len__','__sizeof__')
    assert has_any_attrs(dict(),'get','keys','values','items')
    assert not has_any_attrs(int(),'__len__','__sizeof__')


# Generated at 2022-06-21 12:45:40.153462
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:45:43.417801
# Unit test for function has_any_attrs
def test_has_any_attrs():

    class Foo:
        def foo(self):
            pass

    class Bar:
        def bar(self):
            pass

    class FooBar(Foo, Bar):
        def foobar(self):
            pass

    obj = FooBar()
    assert has_any_attrs(obj, 'foo', 'bar', 'foobar') is True
    assert has_any_attrs(obj, 'foo', 'bar', 'something') is True
    assert has_any_attrs(obj, 'something') is False



# Generated at 2022-06-21 12:45:51.556631
# Unit test for function has_any_attrs
def test_has_any_attrs():
    c = dict()
    d = 'hello'
    a = [1, 2, 3, 4]
    b = frozenset([1, 2, 3, 4])
    test=has_any_attrs(c,'items')
    assert(test==True)
    test=has_any_attrs(d,'foo')
    assert(test==False)
    test=has_any_attrs(a,'__len__')
    assert(test==True)
    test=has_any_attrs(b,'foo')
    assert(test==False)


# Generated at 2022-06-21 12:46:03.971859
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(None, 'get', 'keys', 'items', 'values') is False
    assert has_attrs(bool(), 'get', 'keys', 'items', 'values') is False
    assert has_attrs(bytes(), 'get', 'keys', 'items', 'values') is False
    assert has_attrs({}, 'get', 'keys', 'items', 'values') is False
    assert has_attrs(float(), 'get', 'keys', 'items', 'values') is False
    assert has_attrs(int(), 'get', 'keys', 'items', 'values') is False


# Generated at 2022-06-21 12:46:07.838108
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for the function has_any_callables."""
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-21 12:46:15.188361
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(a=1, b=2), 'keys') is True
    assert has_callables(dict(a=1, b=2), 'keys', 'items', 'update') is True
    assert has_callables(dict(a=1, b=2), 'values', 'items', 'update') is True
    assert has_callables(dict(a=1, b=2), 'something') is False



# Generated at 2022-06-21 12:46:26.932534
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True

    # noinspection PyUnresolvedReferences
    class TestClass:
        def __init__(self):
            self.a = 'a'
            self.b = 123
            self.c = (1, 2, 3)
            self.d = [1, 2, 3]
            self.e = {'a': 1}
            self.f = lambda x: True

        def bar(self, *args, **kwargs):
            return True

    assert has_callables(TestClass(), 'bar') is True
    assert has_callables(TestClass(), 'bar', 'a') is False
    assert has_callables(TestClass(), 'non_existent') is False



# Generated at 2022-06-21 12:46:31.228592
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'foo') is True
    assert has_any_attrs(dict(), 'get', 'foo', 'bar') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_attrs(dict(a=1, b=2), 'get', 'values') is True
    assert has_any_attrs(dict(a=1, b=2), 'foo', 'bar', 'baz') is False


# Generated at 2022-06-21 12:46:36.828500
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1,b=2)
    assert has_callables(obj,'get','keys','items','values','foo') is True
    assert has_callables(obj,'get','keys','items','values','foo','non') is False
    assert has_callables(obj,'get','keys','items','foo','values') is False


# Generated at 2022-06-21 12:46:43.574819
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, set) is True


# Generated at 2022-06-21 12:46:50.397255
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    '''
    Test of flutils.objutils.is_subclass_of_any
    '''
    # Test when obj is a subclass of at least one of the classes
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True

    # Test when obj is not a subclass of any of the claasses
    assert is_subclass_of_any(obj.keys(),set,tuple,list) == False

if __name__ == '__main__':
    test_is_subclass_of_any()

# Generated at 2022-06-21 12:46:52.579489
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values') == True


# Generated at 2022-06-21 12:47:04.974173
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like('hello') == False
    assert is_list_like(sorted('hello')) == True
    assert is_list_like((1, 2, 3)) == True
    assert is_list_like([1, 2, 3]) == True
    assert is_list_like(set([4, 5, 6])) == True
    assert is_list_like(tuple({4, 5, 6})) == True
    assert is_list_like(frozenset((7, 8, 9))) == True
    assert is_list_like(sum((7, 8, 9))) == False
    assert is_list_like(0) == False
    assert is_list_like(1.1) == False
    assert is_list_like(None) == False

# Generated at 2022-06-21 12:47:12.381138
# Unit test for function has_callables
def test_has_callables():
    # Should return false for a non-empty list
    assert has_callables([1, 2, 3], '__iter__') is True
    assert has_callables([1, 2, 3], 'append') is True
    assert has_callables([1, 2, 3], 'remove') is True
    assert has_callables([1, 2, 3], '__iter__', 'append', 'remove') is True
    assert has_callables([1, 2, 3], 'append', '__count__') is True
    assert has_callables([1, 2, 3], '__iter__', '__count__') is False
    assert has_callables([1, 2, 3], '__count__', 'remove') is False

# Function to compare the iteration equality of two sequences
# Taken from bug.test_support.py

# Generated at 2022-06-21 12:47:19.657643
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'keys', 'items', 'values', 'get')
    assert has_any_attrs(obj, 'keys', 'items', 'values', 'foo') is False
    assert has_any_attrs(obj, 'foo', 'bar', 'baz') is False
    assert has_any_attrs(obj, 'foo') is False


# Generated at 2022-06-21 12:47:23.630199
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(
        dict(),
        'get',
        'keys',
        'items',
        'values'
    ) is True
    assert has_attrs(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'foo'
    ) is False



# Generated at 2022-06-21 12:47:41.232530
# Unit test for function is_list_like
def test_is_list_like():
    b = is_list_like(1)
    assert b == True
    b = is_list_like(True)
    assert b == True
    b = is_list_like(1.2)
    assert b == True
    b = is_list_like('s')
    assert b == True
    b = is_list_like(None)
    assert b == True
    b = is_list_like(list())
    assert b == True
    b = is_list_like(set())
    assert b == True
    b = is_list_like(frozenset())
    assert b == True
    b = is_list_like(tuple())
    assert b == True
    b = is_list_like(deque())
    assert b == True
    b = is_list_like(Iterator())


# Generated at 2022-06-21 12:47:49.764515
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test function has_any_attrs."""
    test_dict = dict(a=1, b=2)
    test_list = list('abc123')
    test_set = set((1, 2, 3, 4, 5))
    test_tuple = (1, 2, 'a', 'b', 'c')

    # Test strings
    assert has_any_attrs('foo', 'join', 'startswith', 'endswith', 'replace') == True
    assert has_any_attrs('', 'join', 'startswith', 'endswith', 'replace') == True

    # Test dicts
    assert has_any_attrs(test_dict, 'get', 'keys', 'values', 'foo') == True

# Generated at 2022-06-21 12:47:56.530214
# Unit test for function is_list_like
def test_is_list_like():
    """Test unit for function is_list_like."""
    assert(is_list_like([1, 2, 3]) is True)
    assert(is_list_like(reversed([1, 2, 4])) is True)
    assert(is_list_like('hello') is False)
    assert(is_list_like(sorted('hello')) is True)

# Generated at 2022-06-21 12:47:58.684325
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-21 12:48:07.484844
# Unit test for function has_callables
def test_has_callables():
    class DictLike:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

        def get(self, x: int) -> int:
            return x

    assert has_callables(DictLike(), 'get')

    class NotDictLike:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

        @staticmethod
        def get(x: int) -> int:
            return x

    assert not has_callables(NotDictLike(), 'get')



# Generated at 2022-06-21 12:48:12.445783
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), "get") is True
    assert has_any_callables(dict(), "get", "keys", "values") is True
    assert has_any_callables(dict(), "get", "foo", "keys") is True
    assert has_any_callables(dict(), "foo", "bar", "baz") is False


# Generated at 2022-06-21 12:48:20.347413
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(list(),list,tuple)
    assert is_subclass_of_any(dict(),list,tuple,dict)
    assert is_subclass_of_any(dict(),list,tuple,dict)
    assert is_subclass_of_any([],list,tuple)
    assert is_subclass_of_any((),list,tuple)
    assert is_subclass_of_any(set(),list,tuple,frozenset)
    assert is_subclass_of_any(frozenset(),list,tuple,frozenset)
    assert is_subclass_of_any({},list,tuple,frozenset)
    assert is_subclass_of_any(1,int)

# Generated at 2022-06-21 12:48:29.890428
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(list(), 'append', 'index', 'join', 'something')
    assert has_any_attrs(str(), 'capitalize', 'endswith', 'split', 'title')
    assert has_any_attrs({}, 'clear', 'copy', 'fromkeys', 'get')
    assert has_any_attrs(set(), 'add', 'copy', 'difference', 'intersection')
    assert has_any_attrs(frozenset(), 'copy', 'difference', 'intersection', 'symmetric_difference')
    assert has_any_attrs(tuple(), 'count', 'index', 'startswith', 'something')

# Generated at 2022-06-21 12:48:38.406952
# Unit test for function is_list_like
def test_is_list_like():
    print(is_list_like('h')) # False
    print(is_list_like([1, 2, 3])) # True
    print(is_list_like([])) # True
    print(is_list_like(reversed([1, 2, 3]))) # True
    print(is_list_like(set())) # True
    print(is_list_like(frozenset())) # True
    print(is_list_like(tuple())) # True
    print(is_list_like(dict())) # False
    print(is_list_like(1)) # False
    print(is_list_like(True)) # False
    print(is_list_like(None)) # False
    print(is_list_like(deque(maxlen=0))) # True
    print

# Generated at 2022-06-21 12:48:42.963766
# Unit test for function has_attrs
def test_has_attrs():
    _attrs = 'get','keys','items','values'
    assert has_attrs(dict(),*_attrs) is True
    _attrs = 'get','keys','items','values','foo'
    assert has_attrs(dict(),*_attrs) is False


# Generated at 2022-06-21 12:49:00.183771
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.values(),ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.items(),ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(obj,ValuesView, KeysView, UserList) is False

# Generated at 2022-06-21 12:49:03.690145
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables
    """
    assert has_any_callables(dict(),'get','keys','items','values','foo')==True
    assert has_any_callables(dict(),'get','keys','items','values','foo')==True


# Generated at 2022-06-21 12:49:16.035925
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert not is_list_like(reversed([1, 2, 3]))
    assert is_list_like(sorted([1, 2, 3]))
    assert is_list_like({1, 2, 3})
    assert not is_list_like({'a': 1, 'b': 2, 'c': 3})
    assert is_list_like(dict({1: 2, 3: 4}).values())
    assert not is_list_like(dict({1: 2, 3: 4}).keys())
    assert is_list_like(frozenset({1, 2, 3}))
    assert is_list_like(iter({1, 2, 3}))
    assert is_list_like(tuple({1, 2, 3}))
   

# Generated at 2022-06-21 12:49:19.643208
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo') == True
    assert has_any_attrs(dict(),'foo','bar','eggs','spam') == False


# Generated at 2022-06-21 12:49:22.941710
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True


# Generated at 2022-06-21 12:49:26.992701
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    class Test(object):
        pass
        def __init__(self, a, b):
            self.a = a
            self.b = b

    test = Test(1, 2)
    assert (is_subclass_of_any(test, Test)) == True



# Generated at 2022-06-21 12:49:40.241075
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(d=1, e=2, f=3), 'get', 'keys', 'items') is True
    assert has_any_callables(dict(g=1, h=2, i=3), 'get', 'keys') is True
    assert has_any_callables(dict(j=1, k=2, l=3), 'get') is True
    assert has_any_callables(dict(m=1, n=2, o=3), 'keys') is True
    assert has_any_callables

# Generated at 2022-06-21 12:49:47.196468
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    from collections import defaultdict
    from decimal import Decimal
    from typing import ChainMap, Counter, OrderedDict, UserDict, UserString


# Generated at 2022-06-21 12:49:53.003634
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """ Check if is_subclass_of_any function can properly identify a dict
    subclass as a valuesView subclass.
    """
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)


# Generated at 2022-06-21 12:49:56.470806
# Unit test for function is_list_like
def test_is_list_like():
    obj = dict(a=1, b=2)
    assert is_list_like(obj.keys()) == True
    assert is_list_like(obj.values()) == True
    assert is_list_like(obj) == False

# Generated at 2022-06-21 12:50:13.710375
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something', 'foo') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something', 'foo', 'somthing') is False



# Generated at 2022-06-21 12:50:18.277085
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True


# Generated at 2022-06-21 12:50:20.867638
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), "get", "keys", "items", "values") == True



# Generated at 2022-06-21 12:50:24.732628
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    dict_obj = dict()
    assert has_attrs(
        dict_obj, 'get', 'keys', 'values', 'items'
    ) is True, 'has_attrs is not working properly'



# Generated at 2022-06-21 12:50:28.097498
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    d = dict(a=1, b=2)
    res = is_subclass_of_any(d.keys(), ValuesView, KeysView, UserList)
    assert res is True

# Generated at 2022-06-21 12:50:30.326904
# Unit test for function has_any_attrs
def test_has_any_attrs():
    d = dict(foo=1, bar=2)
    assert has_any_attrs(d, 'keys', 'bar') is True



# Generated at 2022-06-21 12:50:42.013139
# Unit test for function has_attrs
def test_has_attrs():
    """
    Create, test and destroy the defined function
    """

    def has_attrs_test():
        """
        Test the function has_attrs

        Returns:
            bool:
                :obj:`True` if the function passed the tests;
                :obj:`False` if the function failed to pass the tests.

        """

        from flutils.objutils import (
            has_attrs,
        )

        # Check that function has_attrs returns expected
        data = (
            (dict(), 'get', 'keys', 'items', 'values'),
            (dict(), 'get', 'keys', 'values'),
            (dict(), 'get', 'keys', 'items', 'values', 'foo'),
        )
        results = (
            True,
            False,
            False,
        )

# Generated at 2022-06-21 12:50:48.225462
# Unit test for function has_callables
def test_has_callables():
    from collections import ChainMap
    assert has_callables(dict, 'get', 'items', 'keys', 'values')
    assert has_callables(ChainMap, 'get', 'items', 'keys', 'values')
    assert has_callables(list, 'count', 'index', 'append', 'extend')
    assert not has_callables(list, 'count', 'index', 'append', 'foo')


# Generated at 2022-06-21 12:50:53.494882
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(type('', (object,), dict(bar=lambda: None)), 'bar')
    assert not has_any_callables(type('', (object,), dict(bar='notcallable')), 'bar')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something')


# Generated at 2022-06-21 12:51:05.822405
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for :func:`is_list_like <flutils.objutils.is_list_like>` function."""
    # noinspection PyUnresolvedReferences
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-21 12:51:23.494947
# Unit test for function has_attrs
def test_has_attrs():
    """Test function has_attrs."""
    from collections import (
        UserList,
        UserString
    )
    from flutils.objutils import has_attrs

    dict_like_objs = (
        dict(),
        {
            'a': 1
        },
    )
    list_like_objs = (
        list(),
        [1, 2, 3],
    )
    str_like_objs = (
        str(),
        'hello',
    )
    tuple_like_objs = (
        tuple(),
        (1, 2, 3),
    )

    # dict
    assert has_attrs(dict, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict, '__init__', '__len__') is True
    assert has_

# Generated at 2022-06-21 12:51:34.628688
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserDict
    from pytest import raises

    with raises(TypeError, match=r'expects 1 positional argument'):
        has_attrs()
    with raises(TypeError, match=r'expects 1 positional argument'):
        has_attrs(UserDict(), 'foo', 'bar')
    with raises(TypeError, match=r'expects strings as only arguments'):
        has_attrs(UserDict(), 1, 2, 3)

    mydict = UserDict()
    assert has_attrs(mydict, 'foo', 'bar') is False
    assert has_attrs(mydict, 'foo', '__add__', '__class__') is False
    assert has_attrs(mydict, '__class__') is True

# Generated at 2022-06-21 12:51:37.208318
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:51:41.755452
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.keys(), UserList, KeysView, ValuesView)
    assert not is_subclass_of_any(obj.keys(), dict, UserList, KeysView, ValuesView)

# Generated at 2022-06-21 12:51:44.036600
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, bool) is False

# Generated at 2022-06-21 12:51:45.778196
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True


# Generated at 2022-06-21 12:51:53.857894
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    # obj.viewkeys()
    # set(iter(obj.keys()))
    # set(obj.keys())
    # ValuesView(obj)
    # UserList(obj)
    # KeysView(obj)

# Generated at 2022-06-21 12:52:02.338577
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables"""
    # List of values to test
    test_values = [
        [dict, 'get', 'keys', 'values', 'items'],
        [dict, 'foo', 'keys', 'values', 'items'],
        [dict, 'get', 'bar', 'values', 'items'],
        [dict, 'get', 'keys', 'foo', 'items'],
        [dict, 'get', 'keys', 'values', 'bar'],
    ]

    # List of expected results
    exp_results = [
        True, False, False, False, False
    ]

    for idx, test_value in enumerate(test_values):
        assert has_callables(test_value[0](), *test_value[1:]) == exp_results[idx]


# Unit

# Generated at 2022-06-21 12:52:06.011303
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True, 'is_subclass_of_any is not returning the desired result.'

# Generated at 2022-06-21 12:52:07.558830
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs('hello', 'title', 'replace') is True



# Generated at 2022-06-21 12:52:35.148462
# Unit test for function is_list_like
def test_is_list_like():
    # True
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(ValuesView((1, 2, 3))) is True
    assert is_list_like(KeysView(dict(a=1, b=2, c=3))) is True
    assert is_list_like(UserList([1, 2, 3])) is True

    # False
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(b'') is False

# Generated at 2022-06-21 12:52:43.176955
# Unit test for function has_attrs
def test_has_attrs():
    """Test function ``has_attrs``.

    Returns:
        :obj:`tuple(bool)`:

        * :obj:`True` if all tests succeeded;
        * :obj:`False` otherwise.

    Example:
        >>> test_has_attrs()
        (True,)
    """
    try:
        result = has_attrs(dict(), 'keys', 'items', 'values')
        if result is False:
            return False,
    except Exception:
        return False,
    return True,

# Generated at 2022-06-21 12:52:48.102877
# Unit test for function has_callables
def test_has_callables():
    obj = dict(get=True, keys=True,
               items=True, values=True,
               foo='bar')
    assert has_callables(obj, 'get', 'keys', 'items', 'values',) is True
    assert has_callables(obj, 'get', 'foo', 'items', 'values',) is False


# Generated at 2022-06-21 12:52:59.489931
# Unit test for function has_callables
def test_has_callables():
    from collections import ChainMap, Counter, OrderedDict, UserDict
    from collections.abc import ChainMap as ChainMapABC, Counter as CounterABC
    from collections.abc import (
        OrderedDict as OrderedDictABC,
        UserDict as UserDictABC
    )
    from collections import (
        UserList,
        UserString,
        defaultdict,
        deque,
        namedtuple,
        OrderedDict,
    )
    from decimal import Decimal
    from datetime import (
        date,
        datetime,
        timedelta,
        time,
        timezone,
    )
    from fractions import Fraction
    from enum import Enum
    from io import BytesIO, StringIO
    import math
    import os
    import re
    import sys
    from time import localtime

# Generated at 2022-06-21 12:53:06.731403
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict()
    assert has_any_callables(d,'get','keys','items','values','foo') is True
    assert has_any_callables(d,'get','keys','items','values') is True
    assert has_any_callables(d,'get','keys','items','values','__init__') is False
    assert has_any_callables(d,'__init__','keys','items','values') is False


# Generated at 2022-06-21 12:53:18.522651
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like(UserList([1, 2, 3])) is True
    assert is_list_like(KeysView({'a': 1, 'b': 2})) is True
    assert is_list_like(ValuesView({'a': 1, 'b': 2})) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(deque([1, 2, 3])) is True

# Generated at 2022-06-21 12:53:20.689325
# Unit test for function has_attrs
def test_has_attrs():
    assert(has_attrs(dict(),'get','keys','items','values') == True)
    return True


# Generated at 2022-06-21 12:53:25.866865
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from datetime import datetime

    assert is_subclass_of_any(datetime.now(), datetime)
    assert is_subclass_of_any(datetime.now(), float, datetime, list)
    assert not is_subclass_of_any("Not a datetime obj", datetime)
    assert not is_subclass_of_any(datetime.now(), list, type, object)
    return


# Generated at 2022-06-21 12:53:31.695287
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    class MyClass:
        def __init__(self):
            self.a = 1
            self.b = 2
    obj = MyClass()
    assert has_attrs(obj, 'a', 'b') is True
    assert has_attrs(obj, 'b', 'c') is False
    assert has_attrs(obj, 'c', 'd') is False


# Generated at 2022-06-21 12:53:37.140194
# Unit test for function has_attrs
def test_has_attrs():
    from collections import defaultdict
    my_attrs = ['keys', 'items', 'values', 'foo']
    obj = dict(a=1, b=2)
    assert has_attrs(obj, *my_attrs) is True

    obj = defaultdict()
    obj['a'] = 1
    obj['b'] = 2

    assert has_attrs(obj, *my_attrs) is True

    obj = list()
    assert has_attrs(obj, *my_attrs) is False

    my_attrs = ['append', 'insert', 'foo']
    assert has_attrs(obj, *my_attrs) is True



# Generated at 2022-06-21 12:53:59.800698
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserDict

    class MyCls(UserDict):
        def __init__(self, *args, **kwargs):
            super(MyCls, self).__init__(*args, **kwargs)

    my_obj = MyCls(data={'a': 1, 'b': 2})
    assert has_attrs(my_obj, '__len__', '__iter__', '__contains__') is True



# Generated at 2022-06-21 12:54:01.450701
# Unit test for function has_attrs
def test_has_attrs():
    class Foo:
        DEF = 'yup'

    foo = Foo()
    assert has_attrs(foo, 'DEF'), 'missing DEF attr on foo'



# Generated at 2022-06-21 12:54:05.550373
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
test_is_list_like()

# Generated at 2022-06-21 12:54:13.647387
# Unit test for function has_any_callables
def test_has_any_callables():
    from unittest import TestCase, main, mock
    from typing import Callable
    from flutils.objutils import has_any_callables


    class MyObj(object):
        def bar(self):
            pass

        def foo(self):
            pass


    class MySubObj(MyObj):
        def bazz(self):
            pass


    class MyOtherSubObj(MySubObj):
        def item(self):
            pass


    class MyOtherOtherSubObj(MyOtherSubObj):
        def items(self):
            pass


    class MyOtherOtherOtherSubObj(MyOtherOtherSubObj):
        def get(self):
            pass


    class MyOtherOtherOtherOtherSubObj(MyOtherOtherOtherSubObj):
        def keys(self):
            pass


    # noinspection PyUnused

# Generated at 2022-06-21 12:54:19.662473
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    from flutils.tests.check.lib import checkme
    obj = UserDict(a=1, b=2)
    result = has_callables(obj, 'keys', 'items', 'values', 'foo')
    assert isinstance(result, bool) is True
    assert checkme(result, 't') is True


# Generated at 2022-06-21 12:54:20.885194
# Unit test for function has_any_callables
def test_has_any_callables():
    assert True == has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-21 12:54:30.794914
# Unit test for function is_list_like
def test_is_list_like():
    from collections import deque, Counter
    from decimal import Decimal
    import os

    objs = {
        # Collections
        'Counter': Counter(),
        # Built-in
        'Deque': deque(),
        'Decimal': Decimal('0'),
        'Dict': dict(),
        'Float': 1.0,
        'Int': 1,
        'List': list(),
        'Set': set(),
        'String': '',
        'Tuple': tuple(),
        # OS
        'Pipe': os.pipe(),
        'File': os.popen('ls'),
        'Dir': os.scandir('.'),
        # Other
        'None': None,
        'Undefined': undefined,
        'Undefined2': undefined if False is True else False,
    }


# Generated at 2022-06-21 12:54:34.003594
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

if __name__ == '__main__':
    test_is_subclass_of_any()

# Generated at 2022-06-21 12:54:42.659616
# Unit test for function is_list_like
def test_is_list_like():
    import itertools
    # TODO: Add all list-like objects

# Generated at 2022-06-21 12:54:53.516119
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test has_any_attrs(obj, *attrs)
    """
    # Check if a given object has any of the listed attributes
    assert has_any_attrs(dict(),'get','keys','items','values')
    assert not has_any_attrs(dict(),'foo','get')
    assert has_any_attrs(dict(),'foo','get','keys','items','values')
    assert not has_any_attrs(dict(),'foo','bar','baz','fro','values')
    # Check that the function raises a TypeError when passed a non-iterable or
    # unindexable object
    try:
        has_any_attrs((1,),'get','keys','items','values')
    except TypeError:
        assert True
    else:
        assert False # Execution should not get here