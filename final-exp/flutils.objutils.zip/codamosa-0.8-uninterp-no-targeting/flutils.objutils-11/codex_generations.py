

# Generated at 2022-06-21 12:45:02.796618
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables({}, 'pop', 'popitem', 'setdefault', 'update')



# Generated at 2022-06-21 12:45:09.379677
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserDict, UserList
    from collections.abc import KeysView, ValuesView
    from collections import deque
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(UserDict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(UserList(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(deque(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(KeysView({}), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-21 12:45:12.189352
# Unit test for function has_any_callables
def test_has_any_callables():
    class A:
        def __init__(self, value):
            self.value = value
    assert has_any_callables(A('test'), '__init__') == True

# Generated at 2022-06-21 12:45:20.844143
# Unit test for function has_attrs
def test_has_attrs():
    from unittest import TestCase
    from types import MethodType, FunctionType
    from functools import partial

    class Foo:
        def bar(self):
            pass

        def __call__(self):
            pass

    foo = Foo()
    bar = foo.bar
    bar2 = foo.__call__
    fn = partial(bar)

    def fn2(obj):
        return has_attrs(obj, *('__delattr__', '__setattr__'))


# Generated at 2022-06-21 12:45:26.219782
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True


# Generated at 2022-06-21 12:45:36.920280
# Unit test for function is_list_like
def test_is_list_like():
    """Test function ``is_list_like()``.
    """
    from flutils._compat import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

# Generated at 2022-06-21 12:45:43.754039
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test module function is_subclass_of_any()"""
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)


if __name__ == '__main__':
    # Unit test for function is_subclass_of_any
    test_is_subclass_of_any()

# Generated at 2022-06-21 12:45:47.613226
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)




# Generated at 2022-06-21 12:45:56.304714
# Unit test for function is_list_like
def test_is_list_like():
    """
    Test function is_list_like

    Code coverage: 100%

    Test id: 15e30d41-d8d8-11ea-9a9a-3417eb1833f8

    :return: (:obj:`tuple` of :obj:`bool`) The test results.
    """

    from flutils.objutils import is_list_like

    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    )
    from decimal import Decimal
    from json import dumps

    from flutils.objutils import is_subclass_of_any

    from flutils_testutils import (
        CallableMixin,
        UnCallableMixin,
    )

    # Objects
    int_obj

# Generated at 2022-06-21 12:46:06.482984
# Unit test for function has_callables
def test_has_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True

    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') == True

    assert is_list_like([1, 2, 3]) == True
    assert is_list_like(reversed([1, 2, 4])) == True
    assert is_list_like('hello') == False
    assert is_list_like(sorted('hello')) == True

    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
   

# Generated at 2022-06-21 12:46:17.329801
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    from collections.abc import Mapping
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(obj,ValuesView,KeysView,UserList) == False
    assert is_subclass_of_any(obj.keys(),Mapping) == False
    assert is_subclass_of_any(obj,Mapping) == True

# Generated at 2022-06-21 12:46:25.808737
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'keys') is True
    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(), 'items') is True
    assert has_callables(dict(), 'values') is True
    assert has_callables(dict(), 'clear', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'clear', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'clear', 'keys') is True
    assert has_callables(dict(), 'clear', 'items') is True
    assert has_callables(dict(), 'clear', 'values') is True

# Generated at 2022-06-21 12:46:30.159919
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    res = is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert res



# Generated at 2022-06-21 12:46:32.463500
# Unit test for function has_callables
def test_has_callables():
    assert not has_callables(dict(), 'awesome', 'stuff')
    assert has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-21 12:46:37.749674
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == False
    assert has_callables(dict(),'get','keys','items','values','foo','bar') == False


# Generated at 2022-06-21 12:46:46.357498
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList,
        UserDict,
        UserString,
    )
    obj = dict(a=1, b=2)

    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj, ValuesView, KeysView, UserList, UserDict)
    assert not is_subclass_of_any(obj, ValuesView, KeysView, UserString)



# Generated at 2022-06-21 12:46:58.097842
# Unit test for function has_attrs
def test_has_attrs():
    """Check if given ``obj`` has all the given ``*attrs``.

    Args:
        obj (:obj:`Any <typing.Any>`): The object to check.
        *attrs (:obj:`str`): The names of the attributes to check.

    :rtype:
        :obj:`bool`

        * :obj:`True` if all the given ``*attrs`` exist on the given ``obj``;
        * :obj:`False` otherwise.

    Example:
        >>> from flutils.objutils import has_attrs
        >>> has_attrs(dict(),'get','keys','items','values')
        True
    """
    assert has_attrs(dict(), "get", "keys", "items", "values") is True

# Generated at 2022-06-21 12:47:03.609630
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(obj.keys(),"ValuesView","KeysView","UserList") == False

# Generated at 2022-06-21 12:47:09.566342
# Unit test for function has_attrs
def test_has_attrs():
    class Foo(object):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
    obj = Foo()
    attrs = ['a', 'b', 'c']
    try:
        assert has_attrs(obj, *attrs) == True
        print("has_attrs works for object with all those attrs")
    except Exception:
        print("has_attrs does not work for object with all those attrs")
        raise


# Generated at 2022-06-21 12:47:19.587477
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict, Sequence
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'foo') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert is_subclass_of_any(dict(), OrderedDict, Sequence, ValuesView) is True
    assert is_list_like(sorted('hello')) is True
    assert is_list_like([1, 2, 3]) is True


# Generated at 2022-06-21 12:47:25.184983
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-21 12:47:29.041714
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1,b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView, KeysView, UserList)

if __name__ == '__main__':
    test_is_subclass_of_any()

# Generated at 2022-06-21 12:47:32.315060
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True


# Generated at 2022-06-21 12:47:34.636444
# Unit test for function has_attrs
def test_has_attrs():
    """Check that function has_attrs works when given ``dict``"""
    assert has_attrs(dict(),'get','keys','items','values') is True


# Generated at 2022-06-21 12:47:44.499557
# Unit test for function is_list_like
def test_is_list_like():
    import os
    import sys
    import datetime
    import decimal
    import operator
    import collections

    from typing import List, Tuple, Union, Dict
    from pathlib import PurePath

    from flutils.fl_types import ex_types

    from flutils.objutils import is_list_like, is_subclass_of_any

    def assert_list_like_results(obj, expected=True):
        assert is_list_like(obj) == expected


# Generated at 2022-06-21 12:47:46.682348
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'keys', 'items', 'values') == False


# Generated at 2022-06-21 12:47:50.470234
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'bar', 'baz', 'qux') is False



# Generated at 2022-06-21 12:48:01.581784
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(()) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like({}) is False
    assert is_list_like({'a': 1, 'b': 2}) is False
    assert is_list_like(dict(a=1, b=2)) is False
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like(set('abc')) is True
    assert is_list_like(frozenset('abc')) is True
    assert is_list_like(filter(lambda x: x < 2, [1, 2])) is True

# Generated at 2022-06-21 12:48:06.347866
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','something') is True
    assert has_any_attrs(dict(a=1),'value','keys','items') is False
    assert has_any_attrs(dict(a=1),'a') is True


# Generated at 2022-06-21 12:48:08.685100
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-21 12:48:19.953479
# Unit test for function has_attrs
def test_has_attrs():
    """Test function has_attrs
    """
    assert has_attrs(str, '__str__', '__repr__')
    assert has_attrs(str, '__str__', '__repr__', '__format__')
    assert not has_attrs(str, '__abs__', '__len__', '__contains__')
    assert has_attrs(int, '__add__', '__mul__', '__floordiv__')
    assert not has_attrs(int, '__add__', '__mul__', '__floordiv__', '__floormod__')



# Generated at 2022-06-21 12:48:23.781866
# Unit test for function has_any_attrs
def test_has_any_attrs():
    dict1 = dict()
    obj1 = dict1
    res1 = has_any_attrs(obj1, 'get', 'keys', 'items', 'values', 'something')
    assert res1 == True


# Generated at 2022-06-21 12:48:31.952778
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    assert is_list_like(None) is False
    assert is_list_like(bool) is False
    assert is_list_like(bytes) is False
    assert is_list_like(ChainMap) is False
    assert is_list_like(Counter) is False
    assert is_list_like(OrderedDict) is False
    assert is_list_like(UserDict) is False
    assert is_list_like(UserString) is False
    assert is_list_like(defaultdict) is False
    assert is_list_like(Decimal) is False
    assert is_list_like(dict) is False

# Generated at 2022-06-21 12:48:34.515485
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj.keys(), ValuesView, 'str', UserList)


# Generated at 2022-06-21 12:48:45.820018
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items') is True
    assert has_any_attrs(dict(), 'get', 'keys') is True
    assert has_any_attrs(dict(), 'get') is True
    assert has_any_attrs(dict(), 'something') is False
    assert has_any_attrs({1, 2, 3}, 'add', 'remove', 'discard') is True
    assert has_any_attrs(reversed([1, 2, 3]), 'add', 'remove', 'discard') is True
    assert has_any_attrs(sorted([1, 2, 3]), 'add', 'remove', 'discard') is True
    assert has_any_attrs

# Generated at 2022-06-21 12:48:47.451903
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables('hello', 'upper', 'lower', 'format') == True


# Generated at 2022-06-21 12:48:52.504251
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict, deque
    from flutils.objutils import has_callables

    obj = defaultdict(int)
    obj['a'] = deque([1, 2, 3])
    obj['b'] = deque([4, 5, 6])

    assert has_callables(obj, 'default_factory', '__getitem__') == True



# Generated at 2022-06-21 12:49:03.808969
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from typing import (
        List,
    )
    import pytest


# Generated at 2022-06-21 12:49:12.686253
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables({},'get','keys','items','values')
    assert has_callables(dict,'__init__','__str__','__repr__','__len__')
    assert has_callables(dict(),'get','keys','items','values','items')
    assert has_callables({},'get','keys','items','values','foo')
    assert not has_callables({},'get','keys','items','values','foo','bar')


# Generated at 2022-06-21 12:49:17.465987
# Unit test for function has_any_attrs
def test_has_any_attrs():
    test_obj = dict()
    test_obj_fail = str()
    assert has_any_attrs(test_obj, 'get', 'keys', 'items', 'values', 'something') == True
    assert has_any_attrs(test_obj_fail, 'get', 'keys', 'items', 'values', 'something') == False



# Generated at 2022-06-21 12:49:26.989250
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs('hello','get','keys','items','values','something') == False
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'values', 'something') == True


# Generated at 2022-06-21 12:49:36.017446
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, UserList) == False
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

if __name__ == '__main__':
    test_is_subclass_of_any()

# Generated at 2022-06-21 12:49:39.613498
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-21 12:49:46.891888
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test that function has_any_attrs returns True for keys, items, and values
    # attributes in a dictionary
    assert has_any_attrs(dict(),'keys','items','values') == True
    # Test that function has_any_attrs returns True when an attribute exists
    # in a dictionary
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    # Test that function has_any_attrs returns False when all attributes don't
    # exist in a dictionary
    assert has_any_attrs(dict(),'foobar') == False
    # Test that function has_any_attrs returns True when at least one of the
    # attributes exists in a string
    assert has_any_attrs('biscuit', 'lower', 'isupper', 'isdigit', 'splat')

# Generated at 2022-06-21 12:49:57.120308
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList, UserDict, UserString
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj.keys(), UserDict, UserString)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(UserList, list)
    assert not is_subclass_of_any(UserList, list, dict)
    assert is_subclass_of_any(UserList, list, dict, UserDict, UserString)


# Generated at 2022-06-21 12:50:04.885330
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from bs4 import BeautifulSoup
    from datetime import datetime

    html = """
    <body>
        <p>
        <date>2019-10-30</date>
        </p>

        <p>
        <date>2019-10-01</date>
        </p>

        <p>
        <date>2019-11-01</date>
        </p>

        <p>
        <date>2019-09-21</date>
        </p>

        <p>
        <date>2019-10-31</date>
        </p>
    </body>
    """

    soup = BeautifulSoup(html, 'lxml')
    tags = soup.find_all('date')

    tag = tags[0]
   

# Generated at 2022-06-21 12:50:09.366307
# Unit test for function has_callables
def test_has_callables():
    class Dummy(object):
        def __init__(self):
            self.func = lambda x: x

    obj = Dummy()
    assert has_callables(obj, 'func'), "has_callables should have returned True"
    assert not has_callables(obj, 'func', 'bar'), "has_callables should have returned False"

    print(obj.func('foo'))

test_has_callables()


# Generated at 2022-06-21 12:50:15.612857
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'step','foo') is False
    assert has_attrs({'step':1, 'foo':2},'step','foo') is True
    assert has_attrs(dict(a=1, b=2, c=3, d=4),'a','b','c','d','e') is False

# Generated at 2022-06-21 12:50:25.900201
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'geti','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keysi','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','itemis','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','valuess','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','fooo') == False


# Generated at 2022-06-21 12:50:31.137195
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like."""
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-21 12:51:09.241833
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1,2,3,4], '__iter__', '__str__') is True
    assert has_any_callables({}, '__iter__', '__str__') is False
    assert has_any_callables(1, '__iter__', '__str__') is False
    assert has_any_callables(None, '__iter__', '__str__') is False
    assert has_any_callables(set(), '__iter__', '__str__') is True
    assert has_any_callables('hello', '__iter__', '__str__') is True
    assert has_any_callables(1.23, '__iter__', '__str__') is False

# Generated at 2022-06-21 12:51:11.625548
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-21 12:51:20.190774
# Unit test for function has_attrs
def test_has_attrs():
    """Test has_attrs"""
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'foo', 'bar') == False
    assert has_attrs(dict(), '__getitem__', '__len__') == True
    assert has_attrs(dict(), '__getitem__', '__foo__') == False
    assert has_attrs(dict(), 'foo', 'bar') == False
    assert has_attrs('hello', 'isalnum', 'title') == True
    assert has_attrs('hello', 'foo', 'bar') == False
    assert has_attrs('hello', '__contains__', 'title') == True

# Generated at 2022-06-21 12:51:32.307702
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like

    # Test list
    try:
        assert is_list_like([])
    except AssertionError:
        raise AssertionError("Test failure in function is_list_like()") from None

    # Test tuple
    try:
        assert is_list_like(())
    except AssertionError:
        raise AssertionError("Test failure in function is_list_like()") from None

    # Test set
    try:
        assert is_list_like(set())
    except AssertionError:
        raise AssertionError("Test failure in function is_list_like()") from None

    # Test frozenset

# Generated at 2022-06-21 12:51:40.233315
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import (
        Mapping,
        MappingView,
        MutableMapping,
        MutableMappingView,
        Sequence,
        MutableSequence,
    )
    from decimal import Decimal
    from itertools import chain
    from pprint import pprint
    from sys import intern

# Generated at 2022-06-21 12:51:44.150193
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test 1: Check has_any_callables with a basic object
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(obj, 'get_', 'keys_', 'items_', 'values_', 'foo')


# Generated at 2022-06-21 12:51:55.621009
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    ''' Test for is_subclass_of_any
    '''
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList

    assert is_subclass_of_any(dict(a=1, b=2).keys(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(dict(a=1, b=2).values(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(reversed(dict(a=1, b=2).keys()),ValuesView,KeysView,UserList)
    assert not is_subclass_of_any(dict(a=1, b=2).keys(),UserList)
    assert not is_subclass_of_any('abcdefg',UserList)

# Generated at 2022-06-21 12:52:03.904045
# Unit test for function is_list_like
def test_is_list_like():
    # Fixed values
    list_like_classes = (
        UserList,
        ValuesView,
        KeysView,
        Iterator,
        deque,
        tuple,
        set,
        frozenset,
        list
    )

    non_list_like_classes = (
        dict,
        int,
        float,
        str,
        bytes,
        bool,
        type(None)
    )

    test_classes = tuple(
        list(list_like_classes) + list(non_list_like_classes)
    )

    log.debug("Test list-like classes: %s", ", ".join([str(c) for c in list_like_classes]))

# Generated at 2022-06-21 12:52:06.784435
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:52:12.452190
# Unit test for function has_attrs
def test_has_attrs():
    User = type('User', (object,), {'__init__': lambda self: None})
    assert has_attrs(User, '__init__') is True
    assert has_attrs(User(), '__init__') is True
    assert has_attrs(User, '__new__', '__init__') is True, 'should check class'
    assert has_attrs(User(), '__new__', '__init__') is True
    assert has_attrs(User(), '__new__', '__init__', 'to_str') is False
    assert has_callables(User, '__new__', '__init__') is True



# Generated at 2022-06-21 12:52:30.666834
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False

# Generated at 2022-06-21 12:52:33.983840
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert issubclass(obj.keys().__class__, KeysView)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-21 12:52:38.190039
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)

    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:52:41.418859
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)

    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-21 12:52:44.702687
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(dict(), 'something', 'nothing')


# Generated at 2022-06-21 12:52:47.277021
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','keys','foo','values') is False
    assert has_attrs([1,2,3],'append','insert','pop','extend') is True
    assert has_attrs([1,2,3],'append','insert','pop','foo') is False


# Generated at 2022-06-21 12:52:58.728371
# Unit test for function has_callables
def test_has_callables():
    # Test case 1
    obj = dict()
    attrs = 'get', 'keys', 'items', 'values'
    assert has_callables(obj, *attrs)

    # Test case 2
    obj = dict(a='a', b=2)
    attrs = 'get', 'keys', 'items', 'values'
    assert has_callables(obj, *attrs)

    # Test case 3
    obj = dict(c='c')
    attrs = 'get', 'keys', 'items', 'values'
    assert has_callables(obj, *attrs) is False

    # Test case 4
    obj = dict(a=1, b=2)
    attrs = 'get', 'keys', 'items', 'values', 'foo'
    assert has_callables(obj, *attrs) is False



# Generated at 2022-06-21 12:53:04.645483
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Given
    obj = dict(a=1, b=2)
    # When
    result = has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')
    # Then
    assert result is True


# Unit test function has_attrs

# Generated at 2022-06-21 12:53:09.123524
# Unit test for function has_attrs
def test_has_attrs():
    class Person:
        name = None
        age = 0

    assert has_attrs(Person, 'name')
    assert has_attrs(Person, 'name', 'age')
    assert not has_attrs(Person, 'name', 'age', 'address')
    assert not has_attrs(Person, 'name', 'address')

# Generated at 2022-06-21 12:53:20.144891
# Unit test for function has_any_attrs
def test_has_any_attrs():
    component_name = "test_has_any_attrs"
    component_description = "Unit test for function has_any_attrs"
    component_epilog = f"Note: {component_name} ..."
    component_output_examples = ["Test passed if function has_any_attrs returns True"]

    component_parser = argparse.ArgumentParser(
        prog=component_name,
        description=component_description,
        epilog=component_epilog
    )
    component_args = component_parser.parse_args()

    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'something')
    assert not has_any_attrs(dict(), 'a', 'b', 'c')


# Generated at 2022-06-21 12:53:40.162636
# Unit test for function has_attrs
def test_has_attrs():
    assert(has_attrs(dict(),'get','keys','items','values') == True)
    assert(has_attrs('foo','get','keys','items','values') == False)
    assert(has_attrs(dict(),'get','keys','items','values','foo') == False)


# Generated at 2022-06-21 12:53:43.573422
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'foo', 'bar', 'car', 'far') is False
    return

# Generated at 2022-06-21 12:53:46.513680
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj.keys(), '__iter__', '__contains__')



# Generated at 2022-06-21 12:53:53.830036
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap, Counter, OrderedDict, UserDict, UserString, defaultdict
    from collections.abc import Set, MutableSet, Sequence, Mapping, MutableMapping
    from decimal import Decimal

# Generated at 2022-06-21 12:54:01.141237
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    import decimal
    # List-like
    assert is_list_like([]) is True
    assert is_list_like(collections.OrderedDict()) is True
    assert is_list_like(collections.UserDict()) is True
    assert is_list_like(collections.UserList()) is True
    assert is_list_like(collections.UserString()) is True
    assert is_list_like(collections.defaultdict()) is True
    assert is_list_like(collections.deque()) is True
    assert is_list_like(collections.frozenset()) is True
    assert is_list_like(collections.Iterator()) is True
    assert is_list_like(collections.KeysView()) is True
    assert is_list_like(collections.ValuesView()) is True

# Generated at 2022-06-21 12:54:10.653685
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """ Test the function has_any_attrs """
    assert has_any_attrs(dict(),'get')
    assert has_any_attrs(dict(),'keys')
    assert has_any_attrs(dict(a=1, b=2),'keys')
    assert has_any_attrs(dict(a=1, b=2),'get')
    assert not has_any_attrs(dict(a=1, b=2),'items')
    assert not has_any_attrs(dict(a=1, b=2),'foo')
    assert not has_any_attrs(dict(),'foo')
    assert has_any_attrs(list(),'foo')
    assert has_any_attrs(list(),'append')

# Generated at 2022-06-21 12:54:14.984837
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)


# Generated at 2022-06-21 12:54:21.034488
# Unit test for function has_attrs
def test_has_attrs():
    test_list = [1, 2, 3, 4, 5]
    try:
        assert has_attrs(test_list, "__iter__", "__setitem__", "__add__")
    except Exception:
        assert False
    assert not has_attrs(test_list, "__iter__", "__setitem__", "__len__", "__eq__")


# Generated at 2022-06-21 12:54:24.338595
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Setup
    obj = dict()

    # Test
    result = has_any_attrs(obj, 'get', 'keys', 'items', 'values')

    # Verify
    assert result is True


# Generated at 2022-06-21 12:54:25.969281
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
