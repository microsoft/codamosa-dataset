

# Generated at 2022-06-21 12:45:14.326008
# Unit test for function is_list_like
def test_is_list_like():
    obj = list()
    assert is_list_like(obj)
    assert is_list_like(obj.__iter__())
    assert is_list_like(Iterable)
    assert is_list_like(ValuesView)
    assert is_list_like(KeysView)
    assert is_list_like(UserList)
    assert is_list_like(deque())
    assert is_list_like(frozenset())
    assert is_list_like(tuple())
    assert is_list_like(set())
    assert is_list_like(reversed(obj))
    assert is_list_like(sorted(obj))

# Generated at 2022-06-21 12:45:17.663232
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # test case
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'something', 'foo', 'bar') is False



# Generated at 2022-06-21 12:45:28.590169
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # type: () -> None
    """Test the function is_subclass_of_any.

    :rtype:
        :obj:`None`

    Example:
        >>> from flutils.objutils import is_subclass_of_any
        >>> from collections import ValuesView, KeysView, UserList
        >>> obj = dict(a=1, b=2)
        >>> is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
        True
    """
    import unittest
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )

    class TestIsSubclassOfAny(unittest.TestCase):
        """Tests for the function is_subclass_of_any."""


# Generated at 2022-06-21 12:45:33.778405
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_attrs(set(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_any_attrs(set(), 'add', 'clear', 'copy', 'remove', 'update') is True


# Generated at 2022-06-21 12:45:36.300334
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')


# Generated at 2022-06-21 12:45:41.677973
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Unit Tests for is_subclass_of_any function"""
    from flutils.objutils import is_subclass_of_any
    from collections import UserList
    obj = UserList(['a', 'b'])
    classes = (tuple, list, UserList)
    assert is_subclass_of_any(obj, *classes)
    return


# Generated at 2022-06-21 12:45:43.416205
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'values', 'items') == True



# Generated at 2022-06-21 12:45:49.740285
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test function has_any_attrs."""
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(list(), 'append', 'clear', 'extend', 'insert', 'pop') is True
    assert has_any_attrs(set(), 'clear', 'pop', 'add', 'remove', 'discard', 'foo') is True



# Generated at 2022-06-21 12:45:52.916305
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test ``has_any_attrs()`` function.
    """
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-21 12:45:57.772498
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    res = is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    print(res)

test_is_subclass_of_any()

# Generated at 2022-06-21 12:46:08.599912
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get') is True
    assert has_callables(dict(),'keys') is True
    assert has_callables(dict(),'items') is True
    assert has_callables(dict(),'values') is True
    assert has_callables(dict(),'foo') is False
    assert has_callables(1,'foo') is False
    assert has_callables(str,'foo') is False
    assert has_callables(None,'foo') is False
    assert has_callables(True,'foo') is False


# Generated at 2022-06-21 12:46:20.266008
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(1,'bit_length') == False
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get') == True
    assert has_callables(dict(),'foo') == False
    assert has_callables(dict(),'keys') == True
    assert has_callables(dict(),'items') == True
    assert has_callables(dict(),'values') == True
    assert has_callables(dict.fromkeys(('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z')),'items') == True
    assert has_callables(list(),'append') == True


# Generated at 2022-06-21 12:46:23.814970
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3]) == True
    assert is_list_like(reversed([1, 2, 4])) == True
    assert is_list_like('hello') == False
    assert is_list_like(sorted('hello')) == True



# Generated at 2022-06-21 12:46:27.438796
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValueView
    from flutils.objutils import is_subclass_of_any
    assert is_subclass_of_any(dict().values(), ValueView) is False

# Generated at 2022-06-21 12:46:39.624780
# Unit test for function has_attrs
def test_has_attrs():
    """Test function has_attrs

    :return:
    """
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), '__getitem__', 'keys', 'items', 'values') is False
    assert has_attrs('hello', 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs('hello', '__getitem__', 'upper', 'lower') is True
    assert has_attrs([], 'keys', 'items', 'values', 'foo') is False
    assert has_attrs([], '__getitem__', 'append') is True

# Generated at 2022-06-21 12:46:47.424892
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import has_any_attrs

    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'get', 'clear', 'update', 'something') is True
    assert has_any_attrs(dict(), 0, 1, 2, 3, 4) is False
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-21 12:46:59.695711
# Unit test for function is_list_like
def test_is_list_like():
    from operator import itemgetter
    from pprint import pprint
    from collections import (
        ChainMap,
        UserDict,
        UserList,
        UserString,
        OrderedDict,
        Counter,
        Iterator,
        ValuesView,
        KeysView,
        deque,
    )
    import decimal
    import json


# Generated at 2022-06-21 12:47:05.323825
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    import collections
    assert is_subclass_of_any(dict().keys(), collections.KeysView)
    assert not is_subclass_of_any(dict().keys(), collections.ValuesView)
    assert is_subclass_of_any(dict().values(), collections.ValuesView)
    assert not is_subclass_of_any(dict().values(), collections.KeysView)

# Generated at 2022-06-21 12:47:06.861985
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:47:13.253304
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like(set('hello')) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(bytearray([1, 2, 3])) is True
    assert is_list_like(b'abc') is False
    assert is_list_like(bytearray('abc')) is True
    assert is_list_like(chainmap({1: 1})) is False

# Generated at 2022-06-21 12:47:21.983301
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, UserList) == False
    assert is_subclass_of_any(obj.keys(), UserList, ValuesView) == False


# Generated at 2022-06-21 12:47:26.851299
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    d = dict(a=1, b=2)
    assert has_callables(d, "keys", "items", "values")
    assert has_callables(d, "keys", "items", "foo") is False
    assert has_callables(d, "foo", "bar") is False


# Generated at 2022-06-21 12:47:30.281353
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello'))


# Generated at 2022-06-21 12:47:36.279299
# Unit test for function has_any_attrs
def test_has_any_attrs():
    dic = 'str'
    assert has_any_attrs(dic, 'strip', 'join', 'find', 'rfind', 'foobar') is True
    dic = dict(a=1, b=2)
    assert has_any_attrs(dic, 'strip', 'join', 'find', 'keys', 'values') is True
    assert has_any_attrs(dic, 'strip', 'join', 'find', 'foo') is False


# Generated at 2022-06-21 12:47:43.485327
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs([], '__len__', '__getitem__', '__iter__') is True
    assert has_any_attrs([], '__len__', '__getitem__', '__iter__', '__foo__') is True
    assert has_any_attrs('hello', '__len__', '__getitem__', '__iter__') is True
    assert has_any_attrs(5, '__len__', '__getitem__', '__iter__') is False
    assert has_any_attrs({}, '__len__', '__getitem__', '__iter__') is True
    assert all([has_any_attrs(None, '__len__'), has_any_attrs(type, '__len__')]) is False

# Generated at 2022-06-21 12:47:50.810443
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict
    )
    from decimal import (
        Decimal,
    )

    assert is_list_like([]) is True
    assert is_list_like({}) is False
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(1) is False
    assert is_list_like(1.0) is False
    assert is_list_like('a') is False
    assert is_list_like(b'a') is False

    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False

# Generated at 2022-06-21 12:48:01.713084
# Unit test for function has_attrs
def test_has_attrs():
    from collections import (
        ChainMap,
        Counter,
    )
    from collections.abc import (
        Iterator,
        ValuesView,
        KeysView,
    )
    from collections.abc import Mapping as _Mapping
    from collections.abc import MappingView
    from collections.abc import MutableSequence  # type: ignore
    from collections.abc import MutableSet
    from collections.abc import Set  # type: ignore
    from collections.abc import Sequence  # type: ignore
    from decimal import Decimal
    from itertools import islice
    from typing import (
        Any as _Any,
        Callable as _Callable,
    )
    from unittest import TestCase
    from unittest.mock import patch

    import arrow  # type: ignore
    import dateutil.parser

# Generated at 2022-06-21 12:48:05.796966
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    from flutils.objutils import has_callables

    dd = defaultdict(list)
    assert has_callables(dd, '__getitem__', 'keys', '__contains__', '__len__') is True



# Generated at 2022-06-21 12:48:07.860151
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:48:13.690485
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'foo', 'bar', 'baz') is False
    assert has_attrs(dict(), 'foo', 'bar', 'baz', 'foo', 'bar', 'baz') is False



# Generated at 2022-06-21 12:48:21.061011
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'foo')
    assert not has_any_callables(dict(a=1, b=2), 'items', 'values', 'foo')


# Generated at 2022-06-21 12:48:30.319234
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True, \
        "`has_any_callables` returned incorrect value for `dict` object!"
    assert has_any_callables(list(), 'append', 'clear', 'copy', 'pop', 'remove', 'foo') is True, \
        "`has_any_callables` returned incorrect value for `list` object!"
    assert has_any_callables(tuple(), 'index', 'count', 'foo') is True, \
        "`has_any_callables` returned incorrect value for `tuple` object!"

# Generated at 2022-06-21 12:48:35.449194
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(), 'keys', 'values', 'items')
    assert has_attrs(dict(), 'values', 'items', 'keys')
    assert not has_attrs(dict(), 'foo', 'bar')
    assert not has_attrs(dict(), 'foo')
    assert not has_attrs(dict(), 'foo', 'bar', 'baz')
    assert not has_attrs(dict(), 'foo', 'bar', 'baz', None)
    assert not has_attrs(dict(), None, None)



# Generated at 2022-06-21 12:48:42.855020
# Unit test for function has_callables
def test_has_callables():
    '''Test a set of attributes to see if they are callable and exist
    '''
    obj = [1, 2, 3, 4, 5]
    assert has_callables(obj, 'append', '__add__', '__len__') is True
    assert has_callables(obj, 'foo', 'bar') is False
    assert has_callables(obj, 'foo', 'bar', 'sort') is False
    assert has_callables(obj, 'len', 'sort') is False


# Generated at 2022-06-21 12:48:53.546834
# Unit test for function is_list_like
def test_is_list_like():
    known_list_like_objects = [
        UserList([]),
        UserList([1, 2, 3]),
        Iterator([]),
        Iterator([1, 2, 3]),
        ValuesView({'a': 1, 'b': 2, 'c': 3}),
        KeysView({'a': 1, 'b': 2, 'c': 3}),
        deque([]),
        deque([1, 2, 3]),
        frozenset([]),
        frozenset([1, 2, 3]),
        list([]),
        list([1, 2, 3]),
        set([]),
        set([1, 2, 3]),
        tuple([]),
        tuple([1, 2, 3]),
    ]

# Generated at 2022-06-21 12:49:00.184157
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'bar') is False


# Generated at 2022-06-21 12:49:01.996916
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True


# Generated at 2022-06-21 12:49:06.947388
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(None) is False


# Generated at 2022-06-21 12:49:11.886998
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'foo', 'bar') == False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-21 12:49:20.539319
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        UserDict,
        UserString,
        KeysView,
        ValuesView,
        ChainMap,
        OrderedDict,
    )

    # Test that a dict is not a subclass of collections.UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj, UserList) == False

    # Test that a dict is a subclass of collections.abc.KeysView
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

    # Test that a dict is a subclass of collections.abc.KeysView
    assert is_subclass_of_any(obj.keys(), UserList, ValuesView, KeysView) == True

    # Test that a dict is not a subclass of collections.UserList

# Generated at 2022-06-21 12:49:27.560046
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import UserList
    class MyList(UserList):
        pass
    test_obj = MyList()
    assert is_subclass_of_any(test_obj, list, UserList)
    assert not is_subclass_of_any(test_obj, dict)

# Generated at 2022-06-21 12:49:31.921225
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(dict(), 'something')



# Generated at 2022-06-21 12:49:43.062221
# Unit test for function is_list_like
def test_is_list_like():
    # List-like objects are instances of:
    #     - :obj:`UserList <collections.UserList>`
    #     - :obj:`Iterator <collections.abc.Iterator>`
    #     - :obj:`KeysView <collections.abc.KeysView>`
    #     - :obj:`ValuesView <collections.abc.ValuesView>`
    #     - :obj:`deque <collections.deque>`
    #     - :obj:`frozenset`
    #     - :obj:`list`
    #     - :obj:`set`
    #     - :obj:`tuple`
    assert is_list_like([1, 2, 3]) == True
    assert is_list_like(reversed([1, 2, 3])) == True

# Generated at 2022-06-21 12:49:51.249434
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import has_any_attrs
    from collections import OrderedDict

    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(dict(), 'foo', 'bar') is False
    assert has_any_attrs(OrderedDict(), 'foo', 'bar') is False
    assert has_any_attrs(OrderedDict(), '__reversed__', '__copy__', '__contains__') is True


# Generated at 2022-06-21 12:49:54.951207
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs((1,2,3), 'append','__add__','index','something') == False
    return True


# Generated at 2022-06-21 12:49:57.858579
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')==True
    assert has_attrs(dict(),'foo','bar','baz')==False


# Generated at 2022-06-21 12:50:02.284496
# Unit test for function has_any_callables
def test_has_any_callables():
    a = dict(a=1,b=2)
    b = dict(a=1,b=2)
    x1 = has_any_callables(a,'keys','values','items')
    x2 = has_any_callables(b,'keys','values','items')
    assert x1 == x2


# Generated at 2022-06-21 12:50:10.156024
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like."""
    import pytest

    from flutils.objutils import is_list_like

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like(dict(a=1, b=2, c=3).values()) is True
    assert is_list_like(dict(a=1, b=2, c=3).keys()) is True
    assert is_list_like(sorted('hello')) is True
    assert is_list_like('hello') is False
    assert is_list_like(None) is False
    assert is_list_like(True)

# Generated at 2022-06-21 12:50:23.289409
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    
    print("##########################")
    print("Test for is_subclass_of_any")
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    # Initialize an object to check 
    obj = dict(a=1, b=2)
    # Check if the object has the right subclass
    print("Is is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)?", is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList))

    print("Is is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList)?", is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList))


# Generated at 2022-06-21 12:50:31.804920
# Unit test for function has_callables
def test_has_callables():
    #Test case 1: Has all attributes and are all callable
    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'values')
    assert has_callables(obj, *attrs) == True
    #Test case 2: Does not have all the attributes and are all callable
    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'values', 'something')
    assert has_callables(obj, *attrs) == False
    #Test case 3: Has all attributes and are not all callable
    obj = dict(a=1, b=2)
    attrs = ('a', 'b', 'keys', 'values')
    assert has_callables(obj, *attrs) == False


# Generated at 2022-06-21 12:50:43.439344
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(
        a=1,
        b=2,
        c=3,
    )
    attrs = (
        'get',
        'keys',
        'items',
        'values',
    )
    result = has_attrs(obj,*attrs)
    assert(result)



# Generated at 2022-06-21 12:50:53.427008
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'items', 'keys', 'values') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux') is False
    assert has_any_callables(list(), 'append', 'index', 'insert') is True
    assert has_any_callables(list(), 'foo', 'bar', 'baz', 'qux') is False
    assert has_any_callables(tuple(), 'count', 'index') is True
    assert has_any_callables(tuple(), 'foo', 'bar', 'baz', 'qux') is False
    assert has_any_callables(set(), 'add', 'difference', 'intersection') is True

# Generated at 2022-06-21 12:50:58.770986
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-21 12:51:10.455827
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(b'hello') is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False
    assert is_list_like(UserDict()) is False
    assert is_list_like(UserString('')) is False
    assert is_list_like(defaultdict()) is False
    assert is_list_like(Decimal(0)) is False
    assert is_list_

# Generated at 2022-06-21 12:51:19.432395
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from flutils.objutils import is_list_like

    # Types that are list-like
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(list()) is True
    assert is_list_like(reversed(list())) is True
    assert is_list_like(sorted(list())) is True
    assert is_list_like(dict().keys()) is True

# Generated at 2022-06-21 12:51:21.920580
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-21 12:51:29.830902
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(getattr,'__call__','__repr__','__str__','__doc__')
    assert not has_any_callables(dict(),'get','keys','items','values','__call__')
    assert not has_any_callables(getattr,'__call__','__repr__','__str__','foo')


# Generated at 2022-06-21 12:51:32.989779
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'items', 'values', 'something')
    assert(has_any_attrs(obj, *attrs) is True)


# Generated at 2022-06-21 12:51:40.866598
# Unit test for function has_attrs
def test_has_attrs():
    import pytest
    dct = dict(a=1,b=2,c=3)
    assert has_attrs(dct,'a','b','c') == True
    assert has_attrs(dct,'a', 'b', 'c', 'foo') == False
    assert has_attrs(dct,'a', 'b', 'c', 'items') == True
    assert has_attrs(dct,'a', 'b', 'c', 'foo', 'items') == False
    assert has_attrs(dct,'a', 'b', 'c', 'foo', 'keys') == True
    assert has_attrs(dct,'a', 'b', 'c', 'foo', 'keys', 'something') == False

# Generated at 2022-06-21 12:51:44.908121
# Unit test for function has_attrs
def test_has_attrs():
    """ Unit test for function has_attrs
    """
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False


# Generated at 2022-06-21 12:52:04.759539
# Unit test for function is_list_like
def test_is_list_like():
    '''Unit test for the function is_list_like'''

    obj_list_like = [1,2,3]
    assert is_list_like(obj_list_like)

    obj_not_list_like = 'hello'
    assert not is_list_like(obj_not_list_like)

    obj_list_like_iterable = reversed('hello')
    assert is_list_like(obj_list_like_iterable)

    obj_list_like_sorted = sorted('hello')
    assert is_list_like(obj_list_like_sorted)



# Generated at 2022-06-21 12:52:10.174011
# Unit test for function has_attrs
def test_has_attrs():
    class C:
        foo = None

    assert has_attrs(C(), 'foo') is True
    assert has_attrs(dict(), 'get') is True
    assert has_attrs(dict(), 'values', 'items') is True
    assert has_attrs(C(), 'foo', 'bar') is False
    assert has_attrs(dict(), 'foo', 'bar', 'get') is False
    assert has_attrs(dict(), 'keys', 'values', 'items', 'foo') is False



# Generated at 2022-06-21 12:52:16.865901
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(tuple(), 'index', 'count', 'foo')
    assert has_any_callables(list(), 'index', 'count', 'foo')
    assert has_any_callables(set(), 'index', 'count', 'foo')
    assert has_any_callables(frozenset(), 'index', 'count', 'foo')



# Generated at 2022-06-21 12:52:26.922273
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'something') is False
    assert has_any_callables(dict(), 'get', 'values', 'foo') is True
    assert has_any_callables(dict(), 'something', 'foo') is False
    assert has_any_callables(list(), 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort') is True
    assert has_any_call

# Generated at 2022-06-21 12:52:31.394197
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict(),'get','keys','items','values','foo') is not True



# Generated at 2022-06-21 12:52:38.095332
# Unit test for function is_list_like
def test_is_list_like():
    """Check that is_list_like functions as expected.

    Examples:
        >>> test_is_list_like()
        doit (tests.test_objutils.test_is_list_like) ... ok
    """
    import pytest
    from collections import (
        deque,
        Iterator,
        KeysView,
        ValuesView,
        UserList,
    )
    from flutils.objutils import is_list_like

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True

    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

    assert is_list_like(dict()) is False

# Generated at 2022-06-21 12:52:49.143791
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from pytest import approx
    from flutils.objutils import has_any_attrs
    from flutils.objutils import has_attrs
    from flutils.objutils import has_any_callables
    from flutils.objutils import has_callables
    from flutils.objutils import is_list_like
    from flutils.objutils import is_subclass_of_any

    # Setup
    obj = dict(a=1, b=2)

    # Test
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values')
    assert not has_any_attrs(obj, 'something')


# Generated at 2022-06-21 12:53:00.208371
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from typing import (
        Generator,
        List,
        Set,
        Tuple,
    )

    listlike = [
        list,
        set,
        frozenset,
        tuple,
        deque,
        Iterator,
        ValuesView,
        KeysView,
        UserList,
        Generator,
        List,
        Set,
        Tuple,
    ]


# Generated at 2022-06-21 12:53:07.495493
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get','keys','items','values') == True
    assert has_any_attrs(dict(),'nothing') == False
    assert has_any_attrs(dict(),['get']) == False
    assert has_any_attrs(dict(),1) == False

# Unit tests for function has_any_callables

# Generated at 2022-06-21 12:53:19.234210
# Unit test for function is_list_like
def test_is_list_like():
    """
    Unit test for function is_list_like.
    """

    # Setup
    import decimal
    import collections

    All_classes = [collections.UserList, collections.Iterator,
                   collections.abc.KeysView, collections.abc.ValuesView,
                   collections.deque, frozenset, list, set, tuple, None, bool,
                   bytes, collections.ChainMap, collections.Counter,
                   collections.OrderedDict, collections.UserDict,
                   collections.UserString, collections.defaultdict,
                   decimal.Decimal, dict, float, int, str]

    List_like_classes = [collections.UserList, collections.Iterator,
                         collections.abc.KeysView,
                         collections.abc.ValuesView, collections.deque,
                         frozenset, list, set, tuple]

    Non_list_like

# Generated at 2022-06-21 12:53:53.532170
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserList
    class DummyClass(UserList):
        def __init__(self,):
            self.foo = True
            self.bar = False
            self.baz = True

    obj = DummyClass()
    assert has_attrs(obj, 'foo') is True
    assert has_attrs(obj, 'foo', 'bar') is True
    assert has_attrs(obj, 'foo', 'bar', 'baz') is True
    assert has_attrs(obj, 'foo', 'bar', 'baz', 'ban') is False
    assert has_attrs(obj, 'bar', 'baz', 'ban') is False
    assert has_attrs(obj, 'bar', 'baz', 'ban', 'foo') is False

# Generated at 2022-06-21 12:53:57.244040
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like(sorted('hello'))
    assert not is_list_like('hello')
    assert not is_list_like(5)


# Generated at 2022-06-21 12:54:02.488380
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'foo', 'bar') is False
    assert has_any_attrs(dict(), 'foo') is False
    assert has_any_attrs(str(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_any_attrs(str(), 'startswith') is True


# Generated at 2022-06-21 12:54:06.031534
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = {'a': 1, 'b': 2}
    expected = True
    result = has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert result == expected



# Generated at 2022-06-21 12:54:09.130112
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert (has_any_attrs(obj, 'get', 'keys', 'items', 'values',
                          'something') is True)


# Generated at 2022-06-21 12:54:17.498581
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(dict().keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(dict().values(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(reversed(dict().keys()), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(reversed(dict().keys()), ValuesView, KeysView, set)



# Generated at 2022-06-21 12:54:25.274541
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    assert is_list_like(list()) is True
    assert is_list_like(dict()) is False
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(UserList()) is True
    assert is_list_like(OrderedDict()) is False
    assert is_list_like(UserDict()) is False
    assert is_list_like(defaultdict()) is False

# Generated at 2022-06-21 12:54:28.412272
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True


if __name__ == "__main__":
    # Run the unit tests
    test_has_callables()

# Generated at 2022-06-21 12:54:32.021019
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'keys') is True
    assert has_callables(dict, 'none') is False
    assert has_callables(dict, 'none', 'keys') is False
    assert has_callables(dict, 'keys', 'none') is False
    

# Generated at 2022-06-21 12:54:39.953524
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(list(), 'append', 'something')
    assert has_any_attrs(set(), 'add', 'something')
    assert has_any_attrs(tuple(), 'something')
    assert not has_any_attrs(tuple(), 'something', 'otherthing')
    assert has_any_attrs({}, 'get', 'something')
    assert not has_any_attrs({}, 'append', 'something')
