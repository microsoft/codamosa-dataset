

# Generated at 2022-06-21 12:45:08.953043
# Unit test for function has_callables
def test_has_callables():
    class Z:
        def count(self: object) -> int:
            return 1

        def most_common(self: object) -> int:
            return 1

        def start(self: object, index: int) -> int:
            return 1

        @staticmethod
        def bar(m: str) -> str:
            return m

        @classmethod
        def foo(cls: object, n: int) -> int:
            return n + 1

    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(), 'keys') is True
    assert has_callables(dict(), 'items') is True
    assert has_callables(dict(), 'values') is True
    assert has_callables(dict(), '__len__') is True
    assert has_callables(dict(), '__iter__')

# Generated at 2022-06-21 12:45:19.306978
# Unit test for function has_attrs
def test_has_attrs():
    print('\n======= START TEST =======')
    print('function: has_attrs()')
    print('Testing for valid input...')
    d = {'a': 1, 'b': 2, 'c': 3}
    print('Testing for valid keys...')
    assert has_attrs(d, 'keys', 'items', 'values') is True
    assert has_attrs(d, 'keys', 'items', 'get') is True
    assert has_attrs(d, 'keys', 'values', 'get') is True
    assert has_attrs(d, 'items', 'values', 'get') is True
    assert has_attrs(d, 'get') is True
    assert has_attrs(d, 'keys') is True
    assert has_attrs(d, 'items') is True
    assert has_att

# Generated at 2022-06-21 12:45:22.947730
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True

# Generated at 2022-06-21 12:45:27.975961
# Unit test for function has_callables
def test_has_callables():
    _attrs = ('__setitem__', '__str__', '__getitem__', 'get')
    _dict = dict()
    assert has_callables(_dict, *_attrs)
    _attrs = ('__setitem__', '__str__', '__getitem__')
    assert not has_callables(_dict, *_attrs)

# Generated at 2022-06-21 12:45:30.724869
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-21 12:45:37.283991
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True)
    assert(is_subclass_of_any(obj,ValuesView,KeysView,UserList) is False)
    assert(is_subclass_of_any(obj,ValuesView,KeysView,UserList) is False)
    assert(is_subclass_of_any(obj.keys(),UserList) is False)
    print('Test: is_subclass_of_any passed.')


# Generated at 2022-06-21 12:45:39.262456
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs({}, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:45:42.029325
# Unit test for function has_attrs
def test_has_attrs():
    pass


# Generated at 2022-06-21 12:45:45.979069
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'values','items','keys','get') == True
    assert has_callables(dict(),'foo','bar','baz') == False


# Generated at 2022-06-21 12:45:52.227997
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Unit test for is_subclass_of_any"""
    cases = ( (dict(a=1, b=2).keys(),ValuesView,KeysView,UserList,True),
              (dict(a=1, b=2).values(),ValuesView,KeysView,UserList,True),
              (dict(a=1, b=2).items(),ValuesView,KeysView,UserList,False),
              (None,ValuesView,KeysView,UserList,False),
              (None,object,object,object,True),
              )
    for inp, *args, out in cases:
        res = is_subclass_of_any(inp, *args)
        if res != out:
            raise AssertionError('Test ${0} != {1}: {2}'.format(res, out, args))


# Unit test

# Generated at 2022-06-21 12:45:59.506938
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('', 'isupper')
    assert has_any_callables('', 'isupper', 'set')
    assert has_any_callables('', 'isupper', 'set', 'foo')
    assert not has_any_callables('', 'set', 'foo')
    assert not has_any_callables('', 'foo')


# Generated at 2022-06-21 12:46:07.651150
# Unit test for function has_any_attrs
def test_has_any_attrs():
    for cls in _LIST_LIKE:
        if cls == UserList:
            obj = cls([1, 2, 3])
        elif cls == frozenset:
            obj = cls({1, 2, 3})
        elif cls == set:
            obj = cls({1, 2, 3})
        else:
            obj = cls([1, 2, 3])
        for func in ('quantize', 'derive', 'conjugate'):
            if has_any_attrs(obj, func, 'foo', 'bar') is True:
                break

# Generated at 2022-06-21 12:46:19.654151
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        UserDict,
        UserList,
        KeysView,
        ValuesView,
        OrderedDict,
        UserString,
        defaultdict
    )
    import string
    import decimal
    import numpy as np

    # List-like objects
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like(sorted('hello'))

    assert is_list_like(set())
    assert is_list_like(set((1, 2, 3)))
    assert is_list_like(frozenset())
    assert is_list_like(frozenset((1, 2, 3)))

# Generated at 2022-06-21 12:46:23.259139
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(dict.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(dict.keys(),KeysView,UserList) == True
    assert is_subclass_of_any(dict.keys(),UserList) == False

# Generated at 2022-06-21 12:46:28.173645
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, UserList) is False
    assert is_subclass_of_any(obj.keys(), tuple, set) is True
    assert is_subclass_of_any(obj.keys(), tuple, set, frozenset) is True

# Generated at 2022-06-21 12:46:41.138798
# Unit test for function is_list_like
def test_is_list_like():
    # type: () -> None
    """
    Check that is_list_like returns the right results
    """
    # list
    obj = [1, 2, 3]
    assert is_list_like(obj) == True
    # frozenset
    obj = frozenset(obj)
    assert is_list_like(obj) == True
    # set
    obj = set(obj)
    assert is_list_like(obj) == True
    # tuple
    obj = tuple(obj)
    assert is_list_like(obj) == True
    # deque
    obj = deque(obj)
    assert is_list_like(obj) == True
    # dict
    obj = dict(obj)
    assert is_list_like(obj) == False
    # bool
    obj = True
    assert is_

# Generated at 2022-06-21 12:46:44.602239
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    obj = dict()
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False

    obj = UserDict()
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'update') is False



# Generated at 2022-06-21 12:46:49.340037
# Unit test for function has_any_callables
def test_has_any_callables():
    assert True == has_any_callables(dict, 'get', 'keys', 'items', 'values',
                                     'foo')
    assert False == has_any_callables(dict, 'get', 'keys', 'items', 'values',
                                      'foo', 'salted')

# Generated at 2022-06-21 12:46:52.041105
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-21 12:47:01.605212
# Unit test for function has_any_attrs
def test_has_any_attrs():
    associated_tests['has_any_attrs'] = {}
    associated_tests['has_any_attrs']['test_1'] = (
        has_any_attrs(dict(),'get','keys','items','values','something'),
        True,
        {'comment': 'test_1: True'}
    )
    associated_tests['has_any_attrs']['test_2'] = (
        has_any_attrs(dict(),'get','keys','items','values','something_else'),
        False,
        {'comment': 'test_2: False'}
    )


# Generated at 2022-06-21 12:47:13.251637
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(str(), 'find') is True
    assert has_any_callables(dict(), 'get') is True
    assert has_any_callables(int(), 'bit_length') is True
    assert has_any_callables(int(), 'to_bytes') is False
    assert has_any_callables(bytes(), 'encode') is True
    assert has_any_callables(bytes(), 'bit_length') is False
    assert has_any_callables(float(), 'conjugate') is True
    assert has_any_callables(float(), 'bit_length') is False
    assert has_any_callables(complex(), 'conjugate') is True
    assert has_any_callables(complex(), 'bit_length') is False

# Generated at 2022-06-21 12:47:24.902543
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'keys', 'items', 'values', 'foo', '__repr__')
    assert has_any_callables('foo', 'lower', 'upper', 'strip', 'split', 'foo')
    assert has_any_callables('foo', 'lower', 'upper', 'strip', 'split')
    assert has_any_callables('foo', 'lower', 'upper', 'strip', 'foo')
    assert has_any_callables('foo', 'lower', 'upper', 'strip')
    assert has_any_callables('foo', 'lower', 'upper', 'foo')
    assert has_any_callables('foo', 'lower', 'upper')
    assert not has_any_callables('foo', 'not', 'real')
    # assert not has_any_callables('foo', 'lower',

# Generated at 2022-06-21 12:47:35.363737
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(Iterator([])) is True
    assert is_list_like(KeysView([])) is True
    assert is_list_like(ValuesView([])) is True
    assert is_list_like(UserList([])) is True
    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(b'') is False
    assert is_list_like(str()) is False
    assert is_list_like(int()) is False


# Generated at 2022-06-21 12:47:38.977394
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1,b=2)
    assert has_any_attrs(obj,'get','keys','values','foo') is True
    assert has_any_attrs(obj,'foo','bar','zip','zap') is False


# Generated at 2022-06-21 12:47:48.331639
# Unit test for function has_attrs
def test_has_attrs():
    import unittest

    class TestHasAttrs(unittest.TestCase):
        def test_has_attrs(self):
            from collections import OrderedDict
            from flutils.collections import EmptyOrderedDict

            dct = dict()
            assert has_attrs(dct, 'pop', 'popitem', 'copy') is True
            assert has_attrs(dct, 'foo', 'bar', 'foobar') is False

            assert has_attrs(OrderedDict(), 'pop', 'popitem', 'copy') is True
            assert has_attrs(OrderedDict(), 'foo', 'bar', 'foobar') is False

            assert has_attrs(EmptyOrderedDict(), 'pop', 'popitem', 'copy') is True

# Generated at 2022-06-21 12:47:52.550129
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    res = has_any_callables(obj, 'keys', 'something')
    assert res



# Generated at 2022-06-21 12:48:02.127658
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )

    from decimal import Decimal

    assert is_list_like(Change('')) is False
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(b'') is False
    assert is_list_like(b'bytes') is False
    assert is_list_like(bytearray(b'')) is False
    assert is_list_like(bytearray(b'bytearray')) is False
    assert is_list_like(ChainMap({}, {})) is False

# Generated at 2022-06-21 12:48:03.364280
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:48:05.231247
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:48:12.882211
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get','keys','something') == True
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get','keys','items','values','foo') == True
    assert has_any_attrs(dict(),'foo','bar') == False
    assert has_any_attrs(dict(),'bar') == False


# Generated at 2022-06-21 12:48:28.519805
# Unit test for function has_callables
def test_has_callables():
    from pprint import pprint
    from collections import UserList
    from collections.abc import Iterator, KeysView, ValuesView
    from collections import deque
    from typing import Dict, List
    obj = dict(username='tux', password='linux', email='tux@linux.org')
    attr_list = ['get', 'keys', 'items', 'values']
    print('has_callables(obj, *attr_list)')
    pprint(obj)
    pprint(attr_list)
    print(has_callables(obj, *attr_list))
    print()

    obj = UserList()
    attr_list = ['append', 'insert', 'extend']
    print('has_callables(obj, *attr_list)')
    pprint(obj)
    pprint(attr_list)


# Generated at 2022-06-21 12:48:34.573324
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    # Classes
    class UnitTestClass:
        pass

    class UnitTestClass2(UnitTestClass):
        pass

    # Objects
    unit_test_obj = UnitTestClass()
    unit_test_obj2 = UnitTestClass2()

    # Unit test for function is_subclass_of_any
    assert is_subclass_of_any(unit_test_obj.__class__, UnitTestClass) is True
    assert is_subclass_of_any(
        unit_test_obj.__class__, UnitTestClass, UnitTestClass2) is True
    assert is_subclass_of_any(unit_test_obj2.__class__, UnitTestClass) is True
    assert is_subclass_of_any(
        unit_test_obj2.__class__, UnitTestClass, UnitTestClass2)

# Generated at 2022-06-21 12:48:38.039932
# Unit test for function has_callables
def test_has_callables():
    from typing import Dict

    my_dict: Dict[str, str] = dict(a='1', b='2', c='3')
    print(my_dict)
    print(has_callables(my_dict, '__len__', '__delitem__', 'a'))

# Generated at 2022-06-21 12:48:43.918641
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList, UserDict
    obj = dict(a=1, b=2)
    if not is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, UserDict):
        print('test failed: is_subclass_of_any, dict')



# Generated at 2022-06-21 12:48:54.227750
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like."""
    from collections import ChainMap, Counter, OrderedDict, UserDict, UserString, defaultdict
    from collections.abc import Sequence
    from decimal import Decimal
    import pytest

# Generated at 2022-06-21 12:48:57.757837
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'keys', 'items', 'values', 'get')



# Generated at 2022-06-21 12:49:01.616092
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(obj, 'something', 'anotherthing')



# Generated at 2022-06-21 12:49:03.853290
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict, 'values', 'items', 'keys', 'update')
    assert not has_attrs(dict, 'values', 'items', 'keys', 'foo')



# Generated at 2022-06-21 12:49:09.403741
# Unit test for function has_any_attrs
def test_has_any_attrs():
    foo = dict(a=1, b=2)
    assert has_any_attrs(foo, 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(foo, 'some_thing', 'other_thing', 'other_other_thing')


# Generated at 2022-06-21 12:49:11.427564
# Unit test for function has_any_callables
def test_has_any_callables():
    dct = dict()
    assert has_any_callables(dct, 'get')



# Generated at 2022-06-21 12:49:23.443674
# Unit test for function is_list_like
def test_is_list_like():
    """Unit tests for is_list_like function"""
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True


# Generated at 2022-06-21 12:49:31.360599
# Unit test for function has_attrs
def test_has_attrs():
    import unittest

    class HasAttrsTests(unittest.TestCase):

        def test_has_attrs(self) -> None:
            from flutils.objutils import has_attrs

            class MyClass(object):

                def __init__(self):
                    self.foo = 1
                    self.bar = 2

            self.assertTrue(has_attrs(MyClass(), 'foo', 'bar'))
            self.assertFalse(has_attrs(MyClass(), 'foo', 'baz'))

        def test_doesnot_have_attrs(self) -> None:
            from flutils.objutils import has_attrs

            self.assertFalse(has_attrs(object(), 'foo', 'bar'))

    unittest.main()


# Generated at 2022-06-21 12:49:41.321044
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) == True
    assert is_list_like(tuple()) == True
    assert is_list_like(set()) == True
    assert is_list_like(frozenset()) == True
    assert is_list_like('hello') == False
    assert is_list_like(None) == False
    assert is_list_like(1) == False
    assert is_list_like(1.0) == False
    assert is_list_like(True) == False
    assert is_list_like(sorted('hello')) == True
    assert is_list_like(reversed('hello')) == True


# Generated at 2022-06-21 12:49:53.529639
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(
        dict(),
        list,
        tuple,
    ) is False

    assert is_subclass_of_any(
        dict(a=1, b=2),
        list,
        tuple,
    ) is False

    assert is_subclass_of_any(
        dict(a=1, b=2).keys(),
        list,
        tuple,
    ) is False

    assert is_subclass_of_any(
        dict(a=1, b=2).values(),
        list,
        tuple,
    ) is False

    assert is_subclass_of_any(
        dict(a=1, b=2).items(),
        list,
        tuple,
    ) is False


# Generated at 2022-06-21 12:49:58.270202
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print('>>> from flutils.objutils import has_any_attrs')
    print('\n>>> has_any_attrs(dict(),\'get\',\'keys\',\'items\','
        '\'values\',\'something\')')
    print( has_any_attrs(dict(),'get','keys','items','values','something') )


# Generated at 2022-06-21 12:50:05.711152
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserList
    class A:
        def __init__(self):
            self.a = 1
            self.b = 2

    class B:
        def __init__(self):
            self.a = 1

    assert has_any_attrs(A(),'a','b','c') == True
    assert has_any_attrs(A(),'c') == False
    assert has_any_attrs(B(),'a','b') == True
    assert has_any_attrs(B(),'b') == False
    assert has_any_attrs(UserList(),'a','b','data') == True
    assert has_any_attrs(UserList(),'a','b') == False
    assert has_any_attrs(UserList(),'hello') == False

# Generated at 2022-06-21 12:50:10.274381
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values',
                         'something') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz', 'qux') is False



# Generated at 2022-06-21 12:50:17.214179
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values') == True
    assert has_any_attrs(dict(),'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z') == True


# Generated at 2022-06-21 12:50:22.413490
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items') is True
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'bar', 'values', 'items') is False

# Generated at 2022-06-21 12:50:31.227635
# Unit test for function has_callables
def test_has_callables():
    """ Check has_callables function is working properly"""
    class TestClass():
        def __init__(self, data=None):
            """Initialises the TestClass object"""
            self.data = data

        def get(self):
            """Gets the value of data"""
            return self.data

        def set(self, value):
            """Sets the value of data"""
            self.data = value

        def name(self, value):
            """Sets the value of name"""
            self.name = value

    test_obj = TestClass(data=1234)
    assert has_callables(test_obj, 'get') == True
    assert has_callables(test_obj, 'get', 'set', 'name') == True