

# Generated at 2022-06-21 12:45:10.654435
# Unit test for function has_attrs
def test_has_attrs():
    from collections import OrderedDict
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'bar', 'baz') is False
    assert has_attrs(OrderedDict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(OrderedDict(), 'foo', 'bar', 'baz') is False


# Generated at 2022-06-21 12:45:14.752448
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Test ``has_any_callables`` function
    """
    from flutils.objutils import has_any_callables

    assert has_any_callables(dict(),'get','keys','items','values','foo')

# Generated at 2022-06-21 12:45:16.675169
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-21 12:45:18.511183
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True

# Generated at 2022-06-21 12:45:20.602880
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-21 12:45:27.479246
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get','keys','items','values','foo') == True
    assert has_any_attrs(dict(),'get','keys','items','values','bar') == False
    assert has_any_attrs(set(),'get','keys','items','values','bar') == False


# Generated at 2022-06-21 12:45:29.109881
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
             

# Generated at 2022-06-21 12:45:34.505265
# Unit test for function has_attrs
def test_has_attrs():
    # Given the following test objects
    class TestObj:
        def __init__(self):
            self.foo = 'bar'
            self.baz = 'foo'

    obj = TestObj()

    # When checking if obj has attributes foo and baz
    result = has_attrs(obj, 'foo', 'baz')

    # Then result should be True
    assert result


# Generated at 2022-06-21 12:45:44.049282
# Unit test for function has_attrs
def test_has_attrs():
    assert not has_attrs(dict(), 'foo')
    assert not has_attrs(dict(), 'foo', 'bar')
    assert has_attrs(dict(), 'get')
    assert has_attrs(dict(), 'get', 'items')
    assert has_attrs(dict(), 'get', 'items', 'keys')
    assert has_attrs(dict(), 'get', 'items', 'keys', 'values')
    assert has_attrs(dict(), 'get', 'items', 'keys', 'values', 'foo')
    assert not has_attrs(dict(), 'get', 'items', 'keys', 'values', 'foo',
                         'bar')


# Generated at 2022-06-21 12:45:46.337320
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(
            dict(),
            'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-21 12:45:51.943025
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-21 12:46:04.128752
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from typing import (
        Any as _Any,
        Dict as _Dict,
    )


# Generated at 2022-06-21 12:46:16.942110
# Unit test for function has_callables
def test_has_callables():

    # Create mock object
    class Mock(object):
        foo = None
        bar = None
        baz = None

    obj = Mock()
    obj.foo = lambda x: x + 1
    obj.bar = lambda x: x + 2
    obj.baz = lambda x: x + 3

    # Create test cases
    tests = (
        (obj, 'foo', 'bar', 'baz', True),
        (obj, 'foo', 'bar', 'qux', False),
        (obj.__dict__, 'foo', 'bar', 'baz', True),
    )

    # Test function
    for test in tests:
        assert has_callables(*test[:-1]) == test[-1], 'FAILED test: {}'.format(test)
    print('PASSED: has_callables')

# Unit

# Generated at 2022-06-21 12:46:28.080988
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([])
    assert is_list_like(reversed([]))
    assert is_list_like(sorted([]))
    assert is_list_like(frozenset([]))
    assert is_list_like({}.keys())
    assert is_list_like({}.values())
    assert is_list_like({}.items())
    assert is_list_like((3,))
    assert is_list_like((1, 2))
    assert is_list_like(tuple([]))
    assert is_list_like({1, 2, 3})
    assert is_list_like(frozenset([]))
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))

# Generated at 2022-06-21 12:46:31.686494
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables((1, 2, 3),'append','pop','remove','foo')


# Generated at 2022-06-21 12:46:34.110606
# Unit test for function has_callables
def test_has_callables():
    example = dict(a=1, b=2)
    assert has_callables(example, 'get', 'keys', 'values')



# Generated at 2022-06-21 12:46:37.640655
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    attrs = ['get',  'keys', 'values', 'items']
    assert has_any_attrs(obj, *attrs) is True



# Generated at 2022-06-21 12:46:42.101727
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:46:44.957249
# Unit test for function has_any_attrs
def test_has_any_attrs():
    d = dict(a=1, b=2)
    assert has_any_attrs(d,'get','keys','items','values','something') is True



# Generated at 2022-06-21 12:46:51.445620
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # noinspection PyUnresolvedReferences
    from flutils.objutils import has_any_attrs

    assert has_any_attrs(dict(), 'get', 'keys', 'values') is True
    assert has_any_attrs(set(), 'add', 'remove', 'whatnot') is True
    assert has_any_attrs(dict(), 'foo', 'baz', 'bar') is False



# Generated at 2022-06-21 12:47:05.275735
# Unit test for function is_list_like
def test_is_list_like():
    """Test for function is_list_like"""
    assert is_list_like(list())
    assert is_list_like(set())
    assert is_list_like(frozenset())
    assert is_list_like(tuple())
    assert is_list_like(deque())
    assert is_list_like(reversed([1, 2, 3]))
    assert not is_list_like(None)
    assert not is_list_like(bytes())
    assert not is_list_like('a')
    assert is_list_like(sorted('a'))
    assert not is_list_like(1)
    assert not is_list_like(1.0)
    assert not is_list_like(dict())

# Generated at 2022-06-21 12:47:08.008288
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj,ValuesView,KeysView,UserList)

# Generated at 2022-06-21 12:47:20.821689
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserList
    from collections.abc import Iterator
    from flutils import objutils
    # Check obj has no attrs
    obj = None
    attrs = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p']
    assert objutils.has_any_attrs(obj,*attrs) is False
    # Check obj has some attrs
    obj = dict(a=1,b=2,c=3)
    attrs = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p']
    assert objutils.has_any_attrs(obj,*attrs) is True
    # Check obj has no attrs

# Generated at 2022-06-21 12:47:29.084902
# Unit test for function is_list_like
def test_is_list_like():
    try:
        assert is_list_like(None) is False
        assert is_list_like(False) is False
        assert is_list_like(True) is False
        assert is_list_like("hello") is False
        assert is_list_like(["hello"]) is True
        assert is_list_like("hello world") is False
        assert is_list_like("hello world".split()) is True
        assert is_list_like({"hello": "world"}.items()) is True
    except AssertionError:
        raise AssertionError("Test Failed")

if __name__ == "__main__":
    test_is_list_like()

# Generated at 2022-06-21 12:47:30.660732
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(),'get','keys','items','values','something'))


# Generated at 2022-06-21 12:47:32.404126
# Unit test for function has_callables
def test_has_callables():
    print(has_callables(dict(), 'get', 'keys', 'items', 'values'))



# Generated at 2022-06-21 12:47:42.095369
# Unit test for function has_attrs
def test_has_attrs():
    from collections import defaultdict
    from decimal import Decimal
    from numbers import Integral
    from typing import ChainMap, Counter, OrderedDict, UserDict, UserString
    assert has_attrs(None, '__bool__') is True
    assert has_attrs(ChainMap(), '__bool__', '__init__') is True
    assert has_attrs(Counter(), '__bool__', '__init__') is True
    assert has_attrs(Counter(a=1), '__bool__', '__init__', 'values') is True
    assert has_attrs(Counter(a=1), '__bool__', '__init__', 'values', 'foo') is False
    assert has_attrs(defaultdict(), '__bool__', '__init__') is True

# Generated at 2022-06-21 12:47:45.270465
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables
    """
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-21 12:47:50.128794
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', '__str__') is True

# Generated at 2022-06-21 12:48:01.378825
# Unit test for function has_attrs
def test_has_attrs():
    from unittest import TestCase
    from collections import Counter
    from pprint import pprint
    class AssertNoSubclass(TestCase): pass
    class AssertSubclass(TestCase): pass
    class FailTest(TestCase): pass

# Generated at 2022-06-21 12:48:06.848687
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'clear', 'set', 'pop', 'foo') is True
    assert has_any_callables(dict(), 'foo') is False



# Generated at 2022-06-21 12:48:16.607115
# Unit test for function has_callables
def test_has_callables():
    import sys
    if sys.version_info < (3,):
        # Python 2
        from mock import Mock
        obj = Mock(
            a=1,
            b=2,
            c=lambda: None,
            d=1,
            f=lambda: 'bar'
        )
        assert has_callables(obj, 'c', 'f') is True
        assert has_callables(obj, 'a', 'b', 'f') is False
        assert has_callables(obj, 'a', 'b', 'd') is False
    else:
        # Python 3
        from unittest.mock import Mock
        obj = Mock(
            a=1,
            b=2,
            c=lambda: None,
            d=1,
            f=lambda: 'bar'
        )
        assert has

# Generated at 2022-06-21 12:48:21.737843
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) == True
    assert is_list_like(reversed([1, 2, 4])) == True
    assert is_list_like('hello') == False
    assert is_list_like(sorted('hello')) == True

# Generated at 2022-06-21 12:48:28.359514
# Unit test for function is_list_like
def test_is_list_like():
    _list_like_obj_list = [
        ''.join(obj.__name__ for obj in _list_like_obj_list),
        ''.join('{}{}'.format(obj.__name__, ', ') for obj in _list_like_obj_list),
    ]
    assert is_list_like(_list_like_obj_list) is True
    assert is_list_like(_list_like_obj_list[0]) is False
    assert is_list_like(_list_like_obj_list[1]) is False

# Generated at 2022-06-21 12:48:32.697598
# Unit test for function has_any_callables
def test_has_any_callables():
    # Case 1: Testing with a wrong parameter.
    # Expected: False
    print(has_any_callables(123,'something','something'))

    # Case 2: Testing successfully
    # Expected: True
    print(has_any_callables(dict(),'get','keys'))


# Generated at 2022-06-21 12:48:34.928441
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class DummyClass(object):
        property_a = 200
        property_b = 300
        property_c = 400
    dummy_instance = DummyClass()
    print(has_any_attrs(dummy_instance, 'property_a', 'property_d'))

# Generated at 2022-06-21 12:48:37.062926
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'keys','items','values')
    assert not has_any_callables(dict(),'something')


# Generated at 2022-06-21 12:48:43.643232
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    obj = 'hello'
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False



# Generated at 2022-06-21 12:48:45.618315
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True

# Generated at 2022-06-21 12:48:52.253748
# Unit test for function has_attrs
def test_has_attrs():
    """ Unit test for function has_attrs.
        Function has_attrs() is used to check if an object
        has attributes that are sought after. The assertion should be
        True if the object is a dictionary and has attributes 'get', 'keys',
        'items', and 'values'.
        The function will return False if any of those attributes don't exist.
    """
    assert has_attrs({}, 'get', 'keys', 'items', 'values')


# Generated at 2022-06-21 12:49:04.827629
# Unit test for function has_callables
def test_has_callables():
    """A unit test for the function has_callables.

    Args:
        None

    :rtype:
        None

    Examples:
        >>> test_has_callables()
        has_callables() test PASSED
    """
    assert has_callables({}, 'get', 'keys', 'values', 'items') is True
    assert has_callables(dict(), 'get', 'keys', 'values', 'items') is True
    assert has_callables(dict(), 'get', 'keys', 'values', 'items', 'foo') \
        is False
    assert has_callables(list(), 'append', 'extend', 'insert') is True
    assert has_callables(range(0), 'append', 'extend', 'insert') is False
    print('has_callables() test PASSED')


# Generated at 2022-06-21 12:49:17.030909
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(None) is False
    assert is_list_like(12) is False
    assert is_list_like(12.0) is False
    assert is_list_like('Hello') is False
    assert is_list_like([]) is True
    assert is_list_like({'a': 1, 'b': 2}) is True
    assert is_list_like({}) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(Iterator) is True
    assert is_list_like(ValuesView) is True
    assert is_list_like(KeysView) is True

# Generated at 2022-06-21 12:49:20.550860
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(str(),'get','keys','items','values','something') is False


# Generated at 2022-06-21 12:49:29.877236
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    cls_list = [
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    ]
    cls_list.extend(_LIST_LIKE)

# Generated at 2022-06-21 12:49:34.996002
# Unit test for function has_attrs
def test_has_attrs():
    def test():
        assert has_attrs(dict(),'get','keys','items') == True
        assert has_attrs(dict(),'get','keys','foo') == False
        assert has_attrs(dict(),'foo') == False
    test()



# Generated at 2022-06-21 12:49:40.673221
# Unit test for function has_any_callables
def test_has_any_callables():
    o = dict(a=1, b=2, c=3)
    assert has_any_callables(o, 'items', 'values') == True
    assert has_any_callables(o, 'items', 'values', 'foo') == True
    assert has_any_callables(o, 'foo', 'bar', 'baz') == False



# Generated at 2022-06-21 12:49:52.791274
# Unit test for function has_callables
def test_has_callables():
    # test for collections
    assert has_callables(dict(), 'get', 'keys') == True
    assert has_callables({}, 'get') == False
    assert has_callables({}, 'keys') == False
    # test for typing
    assert has_callables(list(), 'clear') == True
    assert has_callables(set(), 'clear') == True
    assert has_callables(tuple([]), 'clear') == False
    assert has_callables(dict(), 'clear') == True
    # test for math
    assert has_callables(math, 'ceil') == True
    # test for decimal
    assert has_callables(Decimal('12.34'), 'as_integer_ratio') == True
    # test for datetime

# Generated at 2022-06-21 12:49:56.995320
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables"""
    import flutils.objutils
    assert flutils.objutils.has_any_callables(
        dict(), 'get', 'keys', 'values', 'items', 'foo') is True, (
            "Callables not found!"
        )



# Generated at 2022-06-21 12:50:04.785546
# Unit test for function has_any_callables
def test_has_any_callables():
    def check_any_callables(obj, expected):
        assert has_any_callables(obj, 'get', 'keys', 'items', 'values') \
               is expected

    # List like objects
    check_any_callables(dict(), True)
    # Collections
    check_any_callables(dict(a=1), True)
    # Strings
    check_any_callables('hello', True)
    # Bytes
    check_any_callables(b'hello', False)
    # int
    check_any_callables(100, False)
    # decimal
    check_any_callables(1.1, False)
    # float
    check_any_callables(1.1, False)
    # bool
    check_any_callables(True, False)
    # None
    check

# Generated at 2022-06-21 12:50:11.564804
# Unit test for function has_attrs
def test_has_attrs():
    # print('Testing has_attrs...')
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs({'hello': 'world'}, 'get', 'keys', 'items', 'values')
    assert has_attrs(Counter({'hello': 'world'}), 'get', 'keys', 'items', 'values')
    assert has_attrs(UserDict({'hello': 'world'}), 'get', 'keys', 'items', 'values')
    assert has_attrs(deque([1, 2, 3]), 'get', 'keys', 'items', 'values')
    assert has_attrs(frozenset([1, 2, 3]), 'get', 'keys', 'items', 'values')

# Generated at 2022-06-21 12:50:26.768032
# Unit test for function has_callables
def test_has_callables():
    """Test for has_callables function."""
    obj = {'a': 1, 'b': 2}
    assert has_callables(obj, 'get', 'keys', 'items', 'values')
    assert has_callables(obj, 'get', 'keys', 'items', 'foo') is False
    assert has_callables(obj, 'get', 'keys', 'foo', 'bar') is False
    assert has_callables(obj, 'get', 'foo', 'bar', 'baz') is False
    assert has_callables(obj, 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(obj, 'foo', 'bar', 'baz', 'values') is False
    assert has_callables(obj, 'foo', 'bar', 'items', 'values') is False

# Generated at 2022-06-21 12:50:37.866781
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
        deque,
        namedtuple,
        OrderedDict,
    )
    from decimal import Decimal
    from flutils.objutils import is_list_like
    from fractions import Fraction
    from functools import partial
    from itertools import (
        accumulate,
        chain,
        combinations,
        compress,
        count,
        cycle,
        dropwhile,
        filterfalse,
        groupby,
        islice,
        permutations,
        repeat,
        starmap,
        takewhile,
        tee,
        zip_longest,
    )
    import datetime as dt
    import re



# Generated at 2022-06-21 12:50:49.694124
# Unit test for function has_callables
def test_has_callables():
    print("\n***Unit test for function has_callables***")
    dictionary = dict(a=1, b=2)
    print("Input to function:")
    print("obj:", dictionary, "attrs: get, keys, items")
    print("Output from function:")
    print(has_callables(dictionary, 'get', 'keys', 'items'))
    print("\n")
    print("Input to function:")
    print("obj:", dictionary, "attrs: get, keys, items, values")
    print("Output from function:")
    print(has_callables(dictionary, 'get', 'keys', 'items', 'values'))
    print("\n")
    print("Input to function:")
    print("obj:", dictionary, "attrs: get, keys, items, values, foo")

# Generated at 2022-06-21 12:50:56.450188
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values'), 'Expected True'
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'ab'), 'Expected False'
    assert not has_callables('foobar', 'get', 'keys', 'items', 'values'), 'Expected False'
    assert not has_callables('foobar', 'get', 'keys', 'items', 'values', 'ab'), 'Expected False'


# Generated at 2022-06-21 12:51:00.742608
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import UserDict
    assert has_callables(UserDict(),'clear','keys') == True
    assert has_callables(UserDict(),'foobar') == False


# Generated at 2022-06-21 12:51:11.969595
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserList, UserDict, UserString
    from collections import Counter, OrderedDict, ChainMap
    from collections import defaultdict
    from collections import deque
    from decimal import Decimal
    from typing import Dict, Set, FrozenSet, List, Tuple
    from typing import Iterable, Iterator, Mapping, Sequence, Mapping
    from typing import Awaitable, AsyncIterator, AsyncGenerator, AsyncIterable

    test1 = has_any_callables(dict(), 'get', 'foo')
    assert test1 == True

    test2 = has_any_callables([], 'append', 'foo')
    assert test2 == True

    test3 = has_any_callables(set(), 'add', 'foo')
    assert test3 == True


# Generated at 2022-06-21 12:51:20.397257
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj1 = dict()
    test_obj2 = dict()
    test_obj2['foo'] = 'bar'
    test_attr = 'keys'
    test_attr2 = 'get'
    test_attr3 = '__getattr__'
    test_not_attr = 'foo'
    test_attrs = ['foo', 'bar', 'baz']
    assert has_any_callables(test_obj1, test_attr3) is True  # noqa: S101
    assert has_any_callables(test_obj2, test_attr3) is True  # noqa: S101
    assert has_any_callables(test_obj2, test_attr, test_attr2, test_not_attr) \
        is True  # noqa: S101
    assert has_any_callables

# Generated at 2022-06-21 12:51:27.079034
# Unit test for function is_list_like
def test_is_list_like():
    """Check the function is_list_like.

    API:
        is_list_like
    """
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True


# Generated at 2022-06-21 12:51:33.593256
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)

    assert is_subclass_of_any(obj.keys(), KeysView, UserList) is True 
    assert is_subclass_of_any(obj.keys(), ValuesView, UserList) is False
    assert is_subclass_of_any(1, ValuesView, UserList) is False

# Generated at 2022-06-21 12:51:38.288252
# Unit test for function has_callables
def test_has_callables():
    import pytest
    d = dict(a=1, b=2)
    # Expected to return true
    assert has_callables(d, 'get', 'keys', 'items', 'values') is True
    # Expected to return false
    assert has_callables(d, 'get', 'keys', 'items', 'values', 'foo') is False
    pytest.fail('Unit test has_callables failed')


# Generated at 2022-06-21 12:51:46.818918
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') == True


# Generated at 2022-06-21 12:51:58.038995
# Unit test for function is_list_like

# Generated at 2022-06-21 12:52:00.015920
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-21 12:52:05.757454
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    # Check True
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    # Check False
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,UserList) == False

# Generated at 2022-06-21 12:52:08.859695
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True



# Generated at 2022-06-21 12:52:13.155409
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True



# Generated at 2022-06-21 12:52:17.914642
# Unit test for function has_any_callables
def test_has_any_callables():
    class TestClass(object):
        def __init__(self):
            self.key = True

    tc = TestClass()
    assert has_any_callables(tc,'key')
    assert has_any_callables(tc,'key','test') == False


# Generated at 2022-06-21 12:52:19.308089
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'keys')



# Generated at 2022-06-21 12:52:26.593675
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3]) == True, 'List is list-like'
    assert is_list_like(reversed([1,2,3])) == True, 'reversed list is list-like'
    assert is_list_like('hello') == False, 'String is not list-like'
    assert is_list_like(sorted('hello')) == True, 'sorted is list-like'
    assert is_list_like(None) == False, 'None is not list-like'
    
if __name__ == '__main__':
    test_is_list_like()

# Generated at 2022-06-21 12:52:32.462181
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','values') is True
    assert has_any_callables(None,'get') is False
    assert has_any_callables(None,'get','keys') is False
    assert has_any_callables(None,'get','keys','values') is False


# Generated at 2022-06-21 12:52:46.815782
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-21 12:52:54.451914
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'pop') is False
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'pop') \
        is False



# Generated at 2022-06-21 12:52:59.216702
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar')



# Generated at 2022-06-21 12:53:10.608706
# Unit test for function is_list_like

# Generated at 2022-06-21 12:53:18.751742
# Unit test for function has_any_callables
def test_has_any_callables():
    """ Unit test for function has_any_callables.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    class Foo:
        def bar(self):
            return True
    foo = Foo()
    # Basic test
    assert has_any_callables(foo, 'bar') is True
    assert has_any_callables(foo, 'baz') is False
    # Test passing multiple args
    assert has_any_callables(foo, 'bar', 'baz') is True


# Generated at 2022-06-21 12:53:22.737635
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    result = is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    print (result)


# Generated at 2022-06-21 12:53:30.120643
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserList, UserDict
    from collections.abc import ValuesView, KeysView

    # Test for has_attrs
    value = dict(a=1, b=2)
    assert has_attrs(value, "values", "keys") is True
    assert has_attrs(value, "foo", "bar") is False
    assert has_attrs(range(4), "index", "count", "foo") is False
    assert has_attrs(range(4), "index", "count") is True

    # Test return value when an object has a callable attribute
    assert has_attrs(value, "values", "keys", "foo") is False
    assert has_attrs(value, "foo") is False

    # Test the multiple instances of the same attribute

# Generated at 2022-06-21 12:53:32.636864
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','foo')
    assert not has_any_callables(dict(),'foo','bar')


# Generated at 2022-06-21 12:53:34.302226
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello'))

# Generated at 2022-06-21 12:53:38.781343
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'set', 'keys', 'items', 'values', 'something') is False

