

# Generated at 2022-06-21 12:45:05.233623
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(obj, 'foo', 'bar') is False



# Generated at 2022-06-21 12:45:09.217043
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar')


# Generated at 2022-06-21 12:45:10.856339
# Unit test for function has_callables
def test_has_callables():
    """Unit test for 'has_callables' function."""
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-21 12:45:12.491609
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys')



# Generated at 2022-06-21 12:45:16.127923
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'get_something','something_else')


# Generated at 2022-06-21 12:45:26.121736
# Unit test for function has_attrs
def test_has_attrs():
    # Standard use
    obj = dict()
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True
    # Missing a single attribute
    assert has_attrs(obj, 'get', 'keys', 'items', 'values', 'pop') is False
    # Missing multiple attributes
    assert has_attrs(obj, 'get', 'keys', 'items', 'value', 'pop') is False
    # Passing no attributes
    assert has_attrs(obj) is False
    # Passing an empty list
    assert has_attrs(obj, *[]) is False
    # Unrelated object
    assert has_attrs(list(), 'get', 'keys', 'items', 'values') is False



# Generated at 2022-06-21 12:45:29.522974
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'values', 'items') is True
    assert has_attrs(dict(), 'get', 'keys', 'values', 'something') is False
    assert has_attrs(dict(), 'something') is False



# Generated at 2022-06-21 12:45:37.369293
# Unit test for function has_attrs
def test_has_attrs():
    """
    To run test: python3 -m pytest flutils/tests/test_has_attrs.py

    Or in project: pytest test_has_attrs.py
    """
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'bar') is False
    assert has_attrs('hello', 'encode') is True


# Generated at 2022-06-21 12:45:46.795627
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    import decimal

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(b'hello') is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False
   

# Generated at 2022-06-21 12:45:47.806874
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a = 1, b = 2)
    pass




# Generated at 2022-06-21 12:45:54.228558
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict(),'get','keys','items','values','aaa')
    assert not has_attrs(dict(),'get','keys','items','values','unicode')


# Generated at 2022-06-21 12:45:58.495537
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-21 12:46:02.813366
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3]) is True
    assert is_list_like(reversed([1,2,4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-21 12:46:05.497343
# Unit test for function has_any_attrs
def test_has_any_attrs():
    result = has_any_attrs(dict(),'get','keys','items','values','something')
    assert result == True



# Generated at 2022-06-21 12:46:08.762260
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'items', 'keys', 'values') is True
    assert has_attrs(dict(), 'something', 'else') is False


# Generated at 2022-06-21 12:46:15.059803
# Unit test for function has_any_attrs
def test_has_any_attrs():
    a = dict(a=1, b=2, c=3)
    assert has_any_attrs(a, 'keys', 'items', 'values') is True
    assert has_any_attrs(a, 'keys', 'foo', 'bar') is True
    assert has_any_attrs(a, 'x', 'y', 'z') is False



# Generated at 2022-06-21 12:46:20.525506
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(obj, 'get', 'keys', 'foobar', 'values', 'something') is True
    assert has_any_attrs(obj, 'get', 'keys', 'foobar', 'values', 'nonexistent') is False


# Generated at 2022-06-21 12:46:31.023622
# Unit test for function has_callables
def test_has_callables():
    import pytest
    from flutils.objutils import has_callables

    class Dummy:
        def __init__(self, a, b):
            self.a = a
            self.b = b

        def func(self):
            return None

    dummy = Dummy(1, 2)
    assert has_callables(dummy, 'func', 'a')
    assert not has_callables(dummy, 'func', 'c')
    with pytest.raises(TypeError):
        has_callables(dummy, 1, 2)


# Generated at 2022-06-21 12:46:39.509750
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values') is True
    assert has_any_callables(dict(),'foo') is False
    assert has_any_callables(dict(),'foo','bar') is False
    assert has_any_callables(dict(),'foo','items') is True
    assert has_any_callables(dict(),'foo','bar','items') is True


# Generated at 2022-06-21 12:46:47.990770
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    assert is_subclass_of_any(dict().keys(),ValuesView,KeysView,UserList) is True
    assert is_subclass_of_any(dict().keys(),ValuesView,KeysView,UserDict) is False
    assert is_subclass_of_any(dict().values(),ValuesView,KeysView,UserDict) is True
    assert is_subclass_of_any(dict().values(),KeysView,UserList) is False
    assert is_subclass_of_any(dict(a=1, b=2).keys(),dict,UserList) is True

# Generated at 2022-06-21 12:47:01.327891
# Unit test for function is_list_like
def test_is_list_like():
    """Test the ``is_list_like`` function.

    Examples:
        >>> from flutils.objutils import is_list_like
        >>> is_list_like([1, 2, 3])
        True
        >>> is_list_like(reversed([1, 2, 4]))
        True
        >>> is_list_like('hello')
        False
        >>> is_list_like(sorted('hello'))
        True
    """

# Generated at 2022-06-21 12:47:08.407422
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj,'a','keys','items','values','something') is True
    assert has_any_attrs(obj,'a','keys','items','values','something','none') is False
    obj = 'hello'
    assert has_any_attrs(obj,'a','split','join','upper','lower','something') is True
    assert has_any_attrs(obj,'a','split','join','upper','lower','something','none') is False


# Generated at 2022-06-21 12:47:16.216948
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    assert is_subclass_of_any({}, dict)
    assert is_subclass_of_any({}, dict, list)
    assert not is_subclass_of_any({}, list)
    assert is_subclass_of_any({}.keys(), KeysView)
    assert is_subclass_of_any({}.keys(), ValuesView, KeysView)


# Generated at 2022-06-21 12:47:20.657739
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    '''
    Test if the function is_subclass_of_any() works as intended.
    '''
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True
    obj = 1
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList, int) == True



# Generated at 2022-06-21 12:47:30.322625
# Unit test for function has_attrs
def test_has_attrs():
    """Check that has_attrs works as expected."""
    assert has_attrs(dict(), 'a', 'b', 'c') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs([1, 2, 3], 'append', 'extend', 'index', 'count') is True
    assert has_attrs([1, 2, 3], 'append', 'extend', 'index', 'count', 'foo') is False
    assert has_attrs(str(), 'capitalize', 'casefold', 'count', 'partition') is True

# Generated at 2022-06-21 12:47:37.791947
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # Test returns True for a subclass
    assert is_subclass_of_any('hello', str)

    # Test returns True for multiple subclasses
    assert is_subclass_of_any('hello', str, bytes)

    # Test returns True for the object itself
    assert is_subclass_of_any('hello', str, str)

    # Test returns False for non-subclasses
    assert not is_subclass_of_any('hello', bytes)

    # Test returns False for non-subclasses with multiple classes
    assert not is_subclass_of_any('hello', bytes, str)



# Generated at 2022-06-21 12:47:47.369489
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list()) is True, 'list()'
    assert is_list_like(list((1, 2, 3))) is True, 'list((1, 2, 3))'
    assert is_list_like(set()) is True, 'set()'
    assert is_list_like(set((1, 2, 3))) is True, 'set((1, 2, 3))'
    assert is_list_like(frozenset()) is True, 'frozenset()'
    assert is_list_like(frozenset((1, 2, 3))) is True, 'frozenset((1, 2, 3))'
    assert is_list_like(tuple()) is True, 'tuple()'

# Generated at 2022-06-21 12:47:52.885049
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get', 'keys') is True
    assert has_attrs(dict(),'nope') is False
    print('Test passed')


# Generated at 2022-06-21 12:47:56.316438
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    obj = dict(a=1,b=2)
    attrs = ('keys','values','items')
    assert has_callables(obj,*attrs)

# Generated at 2022-06-21 12:48:01.302812
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserList
    x = UserList([1,2,3])
    assert has_attrs(x, 'pop', 'append') is True
    assert has_attrs(x, 'pop', 'append', 'shuffle') is False


# Generated at 2022-06-21 12:48:07.720098
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    obj = defaultdict(list)
    assert has_callables(obj, 'append') is True



# Generated at 2022-06-21 12:48:12.660684
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'update', 'clear', 'setdefault')
    assert not has_any_attrs(dict(), 'yes', 'no', 'maybe')
    assert not has_any_attrs(None, 'yes', 'no', 'maybe')
    assert has_any_attrs(None, '__class__')



# Generated at 2022-06-21 12:48:20.476152
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        Counter,
        OrderedDict,
        ChainMap,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    # List-like objects are instances of:
    list_like = [
        UserList,
        Iterator,
        ValuesView,
        KeysView,
        deque,
        frozenset,
        list,
        set,
        tuple,
    ]
    # List-like objects are NOT instances of:

# Generated at 2022-06-21 12:48:29.959476
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items','values','__getitem__')
    assert has_any_attrs(dict(),'get','keys','items','values','__setitem__')
    assert has_any_attrs(dict(),'get','keys','items','values','__delitem__')
    assert has_any_attrs(dict(),'get','keys','items','values','__contains__')
    assert has_any_attrs(dict(),'get','keys','items','values','__iter__')
    assert has_any_attrs(dict(),'get','keys','items','values','__len__')

# Generated at 2022-06-21 12:48:36.871421
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(set(), 'add', 'symmetric_difference', 'difference_update') == True
    assert has_any_callables(set(), 'add', 'symmetric_difference', 'difference_update', 'something', 'else') == True
    assert has_any_callables(reversed([1, 2, 3]), 'add', 'symmetric_difference', 'difference_update') == False
    assert has_any_callables(sorted([1, 2, 3]), 'add', 'symmetric_difference', 'difference_update') == True


# Generated at 2022-06-21 12:48:42.370517
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'setdefault', 'pop')
    assert has_callables(list(), 'append', 'reverse', 'clear')
    assert has_callables(set(), 'intersection', 'union', 'difference')


if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-21 12:48:46.343275
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    assert set(['get', 'keys', 'items', 'values']) <= \
        set(has_attrs(obj, "get", "keys", "items", "values"))


test_has_attrs()


# Generated at 2022-06-21 12:48:55.925388
# Unit test for function is_list_like

# Generated at 2022-06-21 12:49:03.083347
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables([], 'append', 'extend', 'pop') == True
    assert has_callables('hello', 'upper', 'lower', 'capitalize') == True

    class Foo(object):

        def __init__(self):
            self.hooray = 'yay'

        def foo(self):
            pass

    assert has_callables(Foo(), 'hooray', 'foo') == True


# Generated at 2022-06-21 12:49:06.840747
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:49:13.128098
# Unit test for function has_callables
def test_has_callables():

    assert has_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-21 12:49:25.439054
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    from datetime import datetime
    from collections import ChainMap
    from flutils.objutils import (
        has_any_callables,
        has_any_attrs,
        has_attrs,
        has_callables,
        is_list_like,
        is_subclass_of_any,
    )
    test_input = (
        True,
        False,
        [],
        set(),
        frozenset(),
        {},
        deque(),
        '',
        0,
        0.0,
        datetime(2018, 1, 1),
        {'foo': 'bar'},
        ChainMap({}),
    )

# Generated at 2022-06-21 12:49:27.212400
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-21 12:49:40.294391
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Unit test for function is_subclass_of_any"""
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert not is_subclass_of_any(obj,ValuesView,KeysView,UserList)
#    assert is_subclass_of_any(obj.keys(),ValuesView,UserList)
#    assert is_subclass_of_any(obj.keys(),KeysView,UserList)
    assert is_subclass_of_any(obj.keys(),UserList)
    assert is_subclass_of_any(obj.keys(),KeysView)
    assert is_subclass_of_any(ValuesView,KeysView,UserList,ValuesView)

# Generated at 2022-06-21 12:49:42.532801
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(object(), _Any) is True


# Generated at 2022-06-21 12:49:50.032683
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    from flutils.objutils import has_callables
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(OrderedDict(), 'get', 'keys', 'items', 'values') ==\
        True
    assert has_callables(OrderedDict(), 'get', 'keys', '_useless', 'values') ==\
        False



# Generated at 2022-06-21 12:49:59.872441
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap, Counter, OrderedDict, \
        UserDict, UserList, UserString, defaultdict
    from decimal import Decimal
    from itertools import chain, count, filterfalse, groupby, \
        repeat, starmap
    from math import e, pi
    from random import choice, shuffle, uniform
    from string import ascii_letters
    from time import ctime, sleep
    from uuid import uuid4
    from wcwidth import wcswidth
    import sys

    T = True
    F = False

    # :obj:`None`:
    assert is_list_like(None) is F

    # :obj:`bool`:
    assert is_list_like(True) is F
    assert is_list_like(F) is F

    # :obj:`bytes

# Generated at 2022-06-21 12:50:04.284683
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') == True
    assert has_attrs(dict(),'get','keys','items','values','something') == False
    assert has_attrs('hello', 'upper', 'split') == True
    assert has_attrs(1, '__add__') == False


# Generated at 2022-06-21 12:50:15.948652
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj1 = dict(a=1, b=2, c=3)
    obj2 = ('hello', 'world')

    assert has_any_attrs(obj1, 'items', 'values', 'something') is True
    assert has_any_attrs(obj1, 'keys', 'something') is True
    assert has_any_attrs(obj1, 'a', 'b', 'c') is True
    assert has_any_attrs(obj1, 'a', 'b', 'd') is True
    assert has_any_attrs(obj1, 'a', 'b', 'd', 'something') is True
    assert has_any_attrs(obj1, 'a', 'b', 'something') is False

    assert has_any_attrs(obj2, 'pop', 'join') is False

# Unit test

# Generated at 2022-06-21 12:50:23.035421
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    print("Checking that object has all attributes")
    assert has_attrs(obj, 'get', 'keys', 'items', 'values'),\
        'Object should have all attributes'

    print("Checking that object does not have all attributes")
    assert has_attrs(obj, 'get', 'keys', 'items', 'values', 'foo') is False,\
        'Object should not have all attributes'


# Generated at 2022-06-21 12:50:31.264790
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

# Generated at 2022-06-21 12:50:34.923922
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert not is_list_like('hello')
    assert not is_list_like(reversed([1, 2, 4]))
    assert is_list_like(sorted('hello'))

# Generated at 2022-06-21 12:50:39.397564
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1,2,3], '__iter__', '__contains__', 'append') is True
    assert has_any_callables([1,2,3], '__iter__', '__contains__', 'appende') is False


# Generated at 2022-06-21 12:50:50.756995
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs([1],[])
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'foo','bar')
    assert has_any_attrs(dict(a=1,b=2),'keys','items','values','something')
    assert has_any_attrs(set(['a','b','c','c']),'difference','intersection','symmetric_difference','union')
    assert has_any_attrs(frozenset(['a','b','c','c']),'difference','intersection','symmetric_difference','union')

# Generated at 2022-06-21 12:50:52.289585
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')



# Generated at 2022-06-21 12:50:58.014668
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = {'a': 1, 'b': 2}
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    return True

# Generated at 2022-06-21 12:51:05.219427
# Unit test for function has_attrs
def test_has_attrs():
    import pytest
    d1 = {'a': 1}
    assert has_attrs(d1, 'keys') == True
    assert has_attrs(d1, 'values') == True
    assert has_attrs(d1, 'items') == True
    assert has_attrs(d1, '__iter__') == True
    assert has_attrs(d1, 'a') == True
    assert has_attrs(d1, 'nothing') == False


# Generated at 2022-06-21 12:51:10.402374
# Unit test for function has_attrs
def test_has_attrs():
    dct = dict(a=1, b=2)
    assert has_attrs(dct.keys(), '__iter__', '__contains__', '__len__') is True
    assert has_attrs(dct.keys(), '__iter__', '__contains__', '__len__', 'foo') is False



# Generated at 2022-06-21 12:51:19.365281
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict(a=1),'get','keys','items','values')
    assert has_attrs(dict(a=1, b=2),'get','keys','items','values')
    assert not has_attrs(dict(a=1, b=2),'get','keys','items','values','foo')
    assert not has_attrs(dict(a=1, b=2),'foo','bar','get','keys','items','values')
    assert not has_attrs(dict(a=1, b=2),'foo','bar','keys','items','values')
    assert not has_attrs(dict(a=1, b=2),'foo','bar','baz','values')


# Generated at 2022-06-21 12:51:31.624132
# Unit test for function has_attrs
def test_has_attrs():
    def _test_type_assertion(obj, attrs):
        assert has_attrs(obj, *attrs) is True

    def _test_type_assertion_failure(obj, attrs):
        assert has_attrs(obj, *attrs) is False

    # Test with list
    _test_type_assertion(list(), 'append')
    _test_type_assertion_failure(list(), 'something')

    # Test with dict
    _test_type_assertion(dict(), 'get')
    _test_type_assertion_failure(dict(), 'something')

    # Test with tuple
    _test_type_assertion(tuple(), 'count')
    _test_type_assertion_failure(tuple(), 'something')

    # Test with set
    _test_type_assert

# Generated at 2022-06-21 12:51:45.196340
# Unit test for function has_any_callables
def test_has_any_callables():
    # Set up test inputs
    obj = dict(x = 1, y = 2)
    attrs = ['keys', 'foo']

    # Run code to be tested
    result = has_any_callables(obj, *attrs)
    assert type(result) is bool
    assert result == True


# Generated at 2022-06-21 12:51:49.558165
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'something')
    assert has_any_attrs(dict(a=1,b=2),'something')


# Generated at 2022-06-21 12:51:55.381511
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import KeysView, UserDict, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(),KeysView,dict,UserDict,UserList))
    assert(not is_subclass_of_any(obj.values(),KeysView,dict,UserDict,UserList))


# Generated at 2022-06-21 12:52:01.998416
# Unit test for function has_callables
def test_has_callables():
    print('')
    print('Testing function has_callables()...')
    print('-' * 80)
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_callables(obj, 'foo', 'bar') is False
    assert has_callables(obj, 'foo', 'bar', '__getitem__') is False
    print('Successful!')
    print('\n' * 2)



# Generated at 2022-06-21 12:52:04.653825
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') == False

# Generated at 2022-06-21 12:52:10.382621
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_attrs([1, 2, 3], 'append', 'insert')
    assert not has_any_attrs(dict(), 'foo')
    assert not has_any_attrs((1, 2, 3), 'foo')
    assert not has_any_attrs(list(), 'foo')



# Generated at 2022-06-21 12:52:21.709589
# Unit test for function is_list_like
def test_is_list_like():
    import unittest
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from decimal import Decimal
    from types import (
        GeneratorType,
        ModuleType,
        SimpleNamespace,
    )

    class _ReverseIter:
        def __init__(self, value):
            self.value = value

        def __reversed__(self):
            return reversed(self.value)

    class _SortIter:
        def __init__(self, value):
            self.value = value

        def __iter__(self):
            return iter(sorted(self.value))


# Generated at 2022-06-21 12:52:27.076012
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(
        a=dict(),
        b=dict(foo=1, bar=2),
        c=dict(baz=3, xyz=4)
    )
    for k in d:
        func_list = list(d[k].keys())
        if k.startswith('a'):
            func_list.append('something')
        assert has_any_callables(d[k], *func_list) is True



# Generated at 2022-06-21 12:52:34.099305
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import random
    random.seed(1234)
    lst = [random.random() for i in range(100)]
    assert has_any_attrs(lst, '__getitem__', '__iter__') == True
    assert has_any_attrs(lst, '__add__', '__class__') == True
    assert has_any_attrs(lst, '__radd__', '__getitem__') == False



# Generated at 2022-06-21 12:52:40.021074
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_attrs(dict(), 'get')
    assert not has_any_attrs(dict(), 'something')


# Generated at 2022-06-21 12:52:53.940478
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'foo') is False



# Generated at 2022-06-21 12:53:01.739075
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(()) == True
    assert is_list_like([]) == True
    assert is_list_like(dict()) == False
    assert is_list_like(frozenset()) == True
    assert is_list_like(list()) == True
    assert is_list_like(None) == False
    assert is_list_like(set()) == True
    assert is_list_like(tuple()) == True
    assert is_list_like(dict().values()) == True
    assert is_list_like(dict().keys()) == True
    assert is_list_like(reversed('hello')) == True

# Generated at 2022-06-21 12:53:06.021798
# Unit test for function has_callables
def test_has_callables():

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'something') is False


# Generated at 2022-06-21 12:53:09.702093
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:53:15.033211
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'clear','keys','items','values') == True
    assert has_any_callables(dict(),'clear','keys','items','values') == True
    assert has_any_callables(dict(),'clear','keys','items','values') == True


# Generated at 2022-06-21 12:53:18.842962
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    test = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert test is True, "KeysView should be a subclass of any"

# Generated at 2022-06-21 12:53:24.103576
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(1, 'foo')
    assert not has_any_callables(1)
    assert has_any_callables(1, '__init__')
    assert not has_any_callables(None, '__init__')

# Generated at 2022-06-21 12:53:34.367566
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs"""
    import unittest
    import collections
    import inspect

    # noinspection PyUnresolvedReferences
    class Frob(object):
        """Class for testing has_any_attrs"""

        def __init__(self):
            pass

    class TestObj(unittest.TestCase):
        """Test case for has_any_callables"""

        def test_any_attrs_pass(self):
            """Unit test for has_any_attrs"""
            frob = Frob()
            self.assertTrue(has_any_attrs(frob, '__init__', '__init__'))
            self.assertTrue(has_any_attrs(
                frob, '__init__', '__init__', '__init__'))

# Generated at 2022-06-21 12:53:39.357072
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        KeysView,
        ValuesView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), KeysView, ValuesView, UserList) is True

# Generated at 2022-06-21 12:53:42.728235
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    attrs = ['get', 'keys', 'items', 'values', 'something']
    res = has_any_attrs(obj, *attrs)
    assert res is True



# Generated at 2022-06-21 12:54:13.069935
# Unit test for function has_attrs
def test_has_attrs():
    from .objutils import has_attrs
    from . import (
        PY2,
        PY3,
        PYPY,
        PYPY3,
    )
    from collections import Counter
    from decimal import Decimal

    # Test with strings
    assert has_attrs('', '__len__', '__iter__', '__str__') is True
    assert has_attrs('', '__len__', '__iter__', '__stR__') is False
    assert has_attrs('') is False

    # Test with integers
    assert has_attrs(5, '__len__', '__iter__', '__int__') is True
    assert has_attrs(5, '__len__', '__iter__', '__itr__') is False
    assert has_attrs(5)

# Generated at 2022-06-21 12:54:14.207361
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo') is True
    assert has_any_attrs(dict(),'foo') is False


# Generated at 2022-06-21 12:54:22.664465
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values')
    assert not has_any_callables(dict(),'has_key','keys','items','values')
    assert has_any_callables('hello','lower','upper','replace')
    assert not has_any_callables('hello','lower','upper','replaces')
    assert has_any_callables('','lower','upper','replace')
    assert not has_any_callables('','lower','upper','replaces')
    assert has_any_callables(True,'__bool__')
    assert not has_any_callables(True,'__bool')



# Generated at 2022-06-21 12:54:28.283739
# Unit test for function is_list_like
def test_is_list_like():
    """
    Unit test for function is_list_like.
    """
    # import pdb; pdb.set_trace()
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-21 12:54:35.489627
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', '__setitem__') == True
    assert has_any_attrs(dict(), 'foo', 'not', 'there') == False
    assert has_any_attrs(dict(a=1, b=2), 'get', 'keys', '__setitem__') == True
    assert has_any_attrs(dict(a=1, b=2), 'foo', 'not', 'there') == False
    assert has_any_attrs(dict(a=1, b=2), 'foo', 'a', 'there') == True
    assert has_any_attrs(dict(a=1, b=2), 'items', 'get', 'there') == True

# Generated at 2022-06-21 12:54:41.057799
# Unit test for function has_attrs
def test_has_attrs():
    test_data = [('get', 'keys', False),
                 ('foo', 'bar', True)]

    for attr_list, expected in test_data:
        assert has_attrs(dict(), *attr_list) == expected

    for attr_list, expected in test_data:
        assert has_attrs((1, 2, 3), *attr_list) == expected

    for attr_list, expected in test_data:
        assert has_attrs('foo', *attr_list) == expected


# Generated at 2022-06-21 12:54:47.065202
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(object, ValuesView, KeysView, UserList) is False


# Generated at 2022-06-21 12:54:55.249965
# Unit test for function has_callables
def test_has_callables():
    def func():
        pass

    assert has_callables(func, '__call__') is True
    assert has_callables(func, '__call__', '__gt__') is True
    assert has_callables(func, '__call__', '__lt__') is True
    assert has_callables(func, '__gt__') is False
    assert has_callables(func, '__gt__', '__lt__') is False
    assert has_callables(dict(), '__call__') is False
    assert has_callables(list(), '__call__', '__gt__') is False
    assert has_callables(list(), '__call__') is False



# Generated at 2022-06-21 12:54:59.759387
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs"""
    assert has_any_attrs(dict(), 'something', 'foo', 'bar') is False
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
