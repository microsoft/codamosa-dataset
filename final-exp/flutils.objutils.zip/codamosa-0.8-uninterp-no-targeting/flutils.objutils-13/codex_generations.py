

# Generated at 2022-06-21 12:45:05.465626
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'get','keys','items','foobar')
    assert has_attrs(dict(),'get','keys','items','values', 'foobar')


# Generated at 2022-06-21 12:45:10.019118
# Unit test for function has_attrs
def test_has_attrs():
    """
    >>> from flutils.objutils import has_attrs
    >>> has_attrs(dict(),'get','keys','items','values')
    True
    >>> has_attrs(dict(),'get','keys','items','values','foo')
    False
    """



# Generated at 2022-06-21 12:45:17.660857
# Unit test for function has_callables
def test_has_callables():
    test_dict = {
        "test_key_1": "test_value_1",
        "test_key_2": "test_value_2",
        "test_key_3": "test_value_3",
    }
    assert has_callables(
        test_dict, "items", "values", "keys"
    ), "test_has_callables returns True"
    assert not has_callables(test_dict, "foo", "bar", "baz"), "test_has_callables returns False"


# Generated at 2022-06-21 12:45:19.324438
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-21 12:45:30.329310
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )

    from decimal import Decimal

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(b"Hello") is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
   

# Generated at 2022-06-21 12:45:32.975274
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(),'get','keys','items','values','something') == True)
    assert (has_any_attrs(dict(),'foo','bar','something') == False)



# Generated at 2022-06-21 12:45:43.287486
# Unit test for function has_callables
def test_has_callables():
    from collections import ChainMap
    from flutils.objutils import has_callables
    cm = ChainMap({'a': 1, 'b': 2}, {'a': 3, 'c': 4})

    assert has_callables(cm, 'get', 'keys', 'values', 'items') is True
    assert has_callables(cm, 'foo') is False
    assert has_callables(cm.get('a'), '__call__') is True
    assert has_callables(cm.get('a'), '__call__', '__iter__') is True
    assert has_callables(cm.get('a'), '__call__', '__iter__', '__bool__') is True


# Generated at 2022-06-21 12:45:50.600999
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    try:
        assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    except AssertionError as e:
        from flutils.objutils import is_subclass_of_any
        print(is_subclass_of_any.__doc__)
        print(obj.keys())
        print(ValuesView, KeysView, UserList)
        raise e

# Generated at 2022-06-21 12:45:57.357080
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
    )
    from collections.abc import (
        Mapping,
        MutableMapping,
    )
    try:
        from collections.abc import UserList as _UserList
    except ImportError:
        from UserList import UserList as _UserList

    root_classes = (
        object,
        UserDict,
    )

    mapping_classes = (
        ChainMap,
        Counter,
        OrderedDict,
        dict,
    )

    iterable_classes = (
        _UserList,
        UserDict,
    )

    containers_classes = (
        Counter,
        OrderedDict,
        UserDict,
    )


# Generated at 2022-06-21 12:46:01.923967
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    obj = object()
    assert has_attrs(obj, '__class__')
    assert has_attrs(obj, '__class__', '__dict__')



# Generated at 2022-06-21 12:46:08.874990
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'values', 'keys', 'items') is True
    assert has_callables(dict(), 'get', 'values', 'keys', 'something') is False


# Generated at 2022-06-21 12:46:12.896379
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')==True
    assert has_any_callables(dict(),'get','keys','items','values',1)==True


# Generated at 2022-06-21 12:46:16.943838
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    return True

# Generated at 2022-06-21 12:46:20.524810
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values')
    assert has_any_attrs(dict(),'get','keys','items','values')
    assert has_any_attrs(dict(),'foo','bar','baz') is False


# Generated at 2022-06-21 12:46:25.220436
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs('something', '__add__', '__len__')
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:46:27.544833
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-21 12:46:31.954745
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get') == True
    assert has_callables({}, 'get', 'keys') == True
    assert has_callables({}, 'get', 'keys', 'items') == True
    assert has_callables({}, 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'keys', 'items', 'values') == True
    assert has_callables(list(), 'remove') == True
    assert has_callables(frozenset(), 'remove') == False
    assert has_callables(tuple(), 'remove') == False
    assert has_callables(set(), 'remove') == True


# Generated at 2022-06-21 12:46:39.050963
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_callables(1, 'get', 'keys', 'items', 'values') is False
    assert has_callables('abc', 'get', 'keys', 'items', 'values') is False

# Generated at 2022-06-21 12:46:48.002441
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict, 'get', 'keys', 'items', 'values') is True, print(f'Unexpected exit')
    assert has_attrs(dict, 'get', 'keys', 'items', 'values', 'foo') is False, print(f'Unexpected exit')
    assert has_attrs([1,2,3], 'get', 'keys', 'items', 'values', 'foo') is False, print(f'Unexpected exit')
    assert has_attrs(dict, 'get', 'items', 'values', 'foo') is False, print(f'Unexpected exit')


# Generated at 2022-06-21 12:46:52.255579
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print("test_has_any_attrs")
    assert has_any_attrs("", "foo", "upper") is True, "String has attrs"
    assert has_any_attrs(None, "bar") is False, "None has no attrs"


# Generated at 2022-06-21 12:47:04.372266
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux') is False
    assert not has_callables(dict(), 'foo', 'bar', 'baz', 'qux')



# Generated at 2022-06-21 12:47:11.994840
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView)
    assert is_subclass_of_any(obj.values(),ValuesView)
    assert is_subclass_of_any(obj.keys(),KeysView)
    assert is_subclass_of_any(obj.values(),ValuesView,KeysView)
    assert is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList)
    assert not is_subclass_of_any(obj.values(),UserList)
    return True


# Generated at 2022-06-21 12:47:17.910585
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert not is_subclass_of_any(obj.keys(),ValuesView)
    assert is_subclass_of_any(obj.keys(),KeysView)
    assert is_subclass_of_any(obj.keys(),UserList)

# Generated at 2022-06-21 12:47:22.460538
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # Setup
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    result = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    # Assertions
    assert result == True
    return



# Generated at 2022-06-21 12:47:30.157116
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_attrs(dict(foo='bar'), 'get', 'items', 'keys', 'values')
    assert has_attrs(None, 'a') is False
    assert has_attrs(1, 'a') is False
    assert has_attrs(1.0, 'a') is False
    assert has_attrs((1,), 'a') is False
    assert has_attrs((1,), '__iter__')



# Generated at 2022-06-21 12:47:39.355858
# Unit test for function has_attrs
def test_has_attrs():
    class Foo:
        def bar(self):
            return 'bar'

        def baz(self):
            return 'baz'

    foo = Foo()

    assert has_attrs(foo, 'bar', 'baz') is True
    assert has_attrs(foo, 'bar') is True
    assert has_attrs(foo, 'baz') is True
    assert has_attrs(foo, 'bar', 'hello') is False
    assert has_attrs(foo, 'bar', 'baz', 'hello') is False
    assert has_attrs(foo, 'baz', 'hello') is False
    assert has_attrs(foo, 'hello') is False
    assert has_attrs(foo) is True  # pragma: no cover


# Generated at 2022-06-21 12:47:45.623217
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    import pytest
    class MySet(collections.Set): pass
    class MyList(collections.List): pass
    class MyDict(collections.Dict): pass
    class MyFrozenSet(collections.FrozenSet): pass

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(UserList([1, 2, 3])) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like(MySet([1, 2, 3])) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(MyFrozenSet([1, 2, 3])) is True

# Generated at 2022-06-21 12:47:54.433977
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables([1, 2, 3], '__getitem__', '__iter__')
    assert has_callables('foobar', 'lower', 'upper')
    assert has_callables((1, 2, 3), '__contains__')
    assert has_callables(-7, '__abs__')
    assert has_callables(Decimal('3.1415'), '__abs__', '__add__')


# Generated at 2022-06-21 12:47:56.881504
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-21 12:48:03.639252
# Unit test for function has_callables
def test_has_callables():
    # Given
    class DummyObject:
        def get(self):
            return True

        def keys(self):
            return True

        def items(self):
            return True

        def values(self):
            return True

        def pop(self):
            return True

    result = has_callables(
        DummyObject(),
        'get',
        'keys',
        'values',
        'pop'  # this is not an attribute of the object
    )

    assert result is False

    result = has_callables(
        DummyObject(),
        'get',
        'keys',
        'values',
    )

    assert result is True


# Generated at 2022-06-21 12:48:15.764785
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:48:27.435934
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test 1
    test = [
        dict(a=1, b=2),
        dict(a=1, b='2'),
        dict(a=1, b=[2]),
        dict(a=1, b=2, c=3),
    ]
    for i in test:
        assert has_any_callables(i, 'keys', 'values', 'items')

    # Test 2
    test = [
        dict(a=1, b=2),
        dict(a=1, b='2'),
        dict(a=1, b=[2]),
        dict(a=1, b=2, c=3),
    ]
    for i in test:
        assert not has_any_callables(i, 'foo', 'bar', 'baz')

    # Test 3

# Generated at 2022-06-21 12:48:31.306654
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict()
    result = is_subclass_of_any(obj.keys(),
                                ValuesView,
                                KeysView,
                                UserList)
    assert result == True

# Generated at 2022-06-21 12:48:33.010961
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1,b=2)
    names = ['get','keys','items','values','foo']
    assert has_any_callables(obj,*names) is True


# Generated at 2022-06-21 12:48:33.827621
# Unit test for function is_list_like
def test_is_list_like():
    is_list_like('hello')




# Generated at 2022-06-21 12:48:39.562851
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items') is True
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'foo','bar') is False
    assert has_attrs(dict(),'get','bar') is False
    assert has_attrs(dict(),'foo','bar','baz') is False
    assert has_attrs(dict(),'items','values') is False


# Generated at 2022-06-21 12:48:42.485679
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'keys','__len__')
    assert has_attrs(dict(),'_data') is False


# Generated at 2022-06-21 12:48:49.826989
# Unit test for function has_any_callables
def test_has_any_callables():
    import os
    import pathlib
    import tempfile

    assert has_any_callables(tempfile, 'mkdtemp', 'gettempdir', 'mkstemp') is True

    if os.name == 'posix':
        assert has_any_callables(os, 'chmod', 'chown', 'listdir', 'mkdir') is True

    assert has_any_callables(pathlib.Path, 'mkdir', 'exists', 'glob') is True

# Generated at 2022-06-21 12:48:52.400156
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert (has_any_attrs(dict(),'get','keys','items','values','something')==True)


# Generated at 2022-06-21 12:49:00.843343
# Unit test for function has_attrs
def test_has_attrs():
    f = []
    assert(has_attrs(f,'append','pop','index','index'))
    assert(not has_attrs(f,'somethingelse','other'))
    f = dict()
    assert(has_attrs(f,'get','keys','values','items'))
    assert(not has_attrs(f,'somethingelse','other'))
    f = {}
    assert(has_attrs(f,'get','keys','values','items'))
    assert(not has_attrs(f,'somethingelse','other'))



# Generated at 2022-06-21 12:49:17.223554
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'foo', 'bar', 'baz', 'xyz') is False
    assert has_callables(list(), 'append', 'count', 'extend', 'index') is True
    assert has_callables(list(), 'foo', 'bar', 'baz', 'xyz') is False
    assert has_callables(tuple(), 'index', 'count') is True
    assert has_callables(tuple(), 'foo', 'bar', 'baz', 'xyz') is False
    assert has_callables(set(), 'add', 'clear', 'copy', 'difference') is True

# Generated at 2022-06-21 12:49:23.502087
# Unit test for function is_list_like
def test_is_list_like():
    with pytest.raises(TypeError):
        assert is_list_like()
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like({1, 2, 3}) is True


# Generated at 2022-06-21 12:49:26.005219
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-21 12:49:34.910201
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test with an object with callables
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'update') is True
    assert has_any_callables(dict(), 'get', 'keys', 'something') is True
    # Test with an object without callables
    assert has_any_callables('foobar', 'get', 'keys', 'values', 'update') is False
    assert has_any_callables('foobar', 'get', 'keys', 'something') is False


# Generated at 2022-06-21 12:49:35.611734
# Unit test for function has_any_callables
def test_has_any_callables():
    pass

# Generated at 2022-06-21 12:49:38.315274
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-21 12:49:43.323509
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Unit tests for function is_subclass_of_any

# Generated at 2022-06-21 12:49:45.797130
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True



# Generated at 2022-06-21 12:49:55.513580
# Unit test for function has_callables
def test_has_callables():
    class Test:
        def __init__(self):
            self._x = "x"

        @property
        def y(self):
            return self._y

        @y.setter
        def y(self, y):
            self._y = y

        @y.deleter
        def y(self):
            del self._y

        def z(self, x):
            return x

    t = Test()
    assert has_callables(t, "y", "z") is True
    assert has_callables(t, "y", "x") is False
    assert has_callables(t, "z", "x") is False


# Generated at 2022-06-21 12:50:03.576680
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import ChainMap, defaultdict
    from collections.abc import MutableMapping
    from unittest import TestCase
    from unittest.mock import MagicMock


    class TestHasAnyCallables(TestCase):
        def setUp(self):
            self.obj = MagicMock(name='obj')
            self.obj.attrs = MagicMock(name='obj.attrs')
            self.obj.attrs.__len__.return_value = 0
            self.obj.attrs.get.return_value = None
            self.obj.attrs.keys.return_value = []
            self.obj.attrs.values.return_value = []
            self.obj.attrs.items.return_value = []
            self.obj.attrs.something.return_value = None

# Generated at 2022-06-21 12:50:16.391325
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    result = is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert result == True

# Generated at 2022-06-21 12:50:20.920989
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'values', 'something') == True
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'values', 'something') != False

# Generated at 2022-06-21 12:50:23.640068
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, '__init__')
    assert has_callables(dict(), 'setdefault', 'get', 'keys')



# Generated at 2022-06-21 12:50:27.477135
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert not is_list_like('hello')
    assert is_list_like(sorted('hello'))
    assert is_list_like(reversed([1, 2, 4]))
    return None

# Generated at 2022-06-21 12:50:30.569803
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == False



# Generated at 2022-06-21 12:50:35.428442
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj.keys(), set, ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:50:47.633533
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__dict__',
                         '__doc__', '__getitem__', '__init__',
                         '__iter__', '__len__', '__module__',
                         '__repr__', '__setitem__', '__str__') == True
    assert has_callables(dict(), '__dict__', '__doc__', '__getitem__',
                         '__init__', '__iter__', '__len__', '__module__',
                         '__repr__', '__setitem__', '__str__') == False

# Generated at 2022-06-21 12:50:50.080661
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo') is False



# Generated at 2022-06-21 12:50:54.037001
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # test a subclass
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

    # test a superclass
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList, dict)

# Generated at 2022-06-21 12:51:06.349762
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(dict()) is False
    assert not is_list_like(dict())
    assert is_list_like(dict()) is False
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like(frozenset({1, 2, 3})) is True
    assert is_list_like(tuple([1, 2, 3])) is True
    assert is_list_like(deque([1, 2, 3])) is True

# Generated at 2022-06-21 12:51:30.641875
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(a=1,b=2),'keys','values')
    assert has_any_attrs(dict(a=1,b=2),'get')
    assert has_any_attrs(sorted('hello'),'__iter__')
    assert has_any_attrs(list(range(0,10)),'copy')
    assert has_any_attrs(sorted('hello'),'__len__')



# Generated at 2022-06-21 12:51:32.359282
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items','values') == False


# Generated at 2022-06-21 12:51:39.518896
# Unit test for function has_attrs
def test_has_attrs():
  class Foo:
    def __init__(self):
      self.bar1 = "bar1"
      self.bar2 = "bar2"
      self.bar3 = "bar3"
  foo = Foo()
  assert (has_attrs(foo, "bar1", "bar2", "bar3") is True)
  assert (has_attrs(foo, "bar1", "bar2") is True)
  assert (has_attrs(foo, "bar1", "bar2", "bar4") is False)
  assert (has_attrs(foo, "bar4", "bar5", "bar6") is False)
  print("test_has_attrs success!")


# Generated at 2022-06-21 12:51:46.530587
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables
    """
    import unittest
    from collections import deque, OrderedDict
    from flutils.objutils import has_any_callables
    from typing import Any
    class TestCase(unittest.TestCase):
        def test_has_any_callables(self):
            def _test_has_any_callables(
                    obj: Any,
                    *attrs: Any
            ) -> None:
                self.assertTrue(has_any_callables(obj, *attrs))

            _test_has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
            _test_has_any_callables(deque(), 'appendleft', 'popleft', 'append', 'pop')
            _test_has_

# Generated at 2022-06-21 12:51:57.757524
# Unit test for function is_list_like
def test_is_list_like():
    # Unit test for function is_list_like
    # test with a list
    assert is_list_like([1, 2, 3])

    # test with a reversed list
    assert is_list_like(reversed([1, 2, 3]))

    # test with a string
    assert is_list_like(str('str')) is False

    # test with a sorted string
    assert is_list_like(sorted('str'))

    # test with a list of dicts
    assert is_list_like([dict(brand='b1', name='name1'), dict(brand='b2', name='name2')])

    # test with a defaultdict
    from collections import defaultdict
    d = defaultdict(dict)
    d['1']['a'] = 'a'

# Generated at 2022-06-21 12:51:59.717941
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'something')


# Generated at 2022-06-21 12:52:03.205727
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'foo') is False

# Generated at 2022-06-21 12:52:04.860456
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), '__getitem__') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False
    return


# Generated at 2022-06-21 12:52:07.650876
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'foo','bar','baz','fuzz') is False


# Generated at 2022-06-21 12:52:19.176783
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get') is True
    assert has_any_attrs(set(), 'add') is True
    assert has_any_attrs(tuple(), '__add__') is True
    assert has_any_attrs(frozenset(), '__add__') is True
    assert has_any_attrs(int(), '__add__') is True
    assert has_any_attrs(int(), 'conjugate') is True
    assert has_any_attrs(int(), 'real') is True
    assert has_any_attrs(float(), '__add__') is True
    assert has_any_attrs(float(), 'conjugate') is True
    assert has_any_attrs(float(), 'real') is True