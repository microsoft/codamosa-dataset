

# Generated at 2022-06-21 12:45:07.946833
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for function has_callables.
    """
    from flutils.objutils import has_callables
    from inspect import ismethod
    from functools import partial

    def mock_func():
        pass

    def mock_func1():
        pass

    class MockClass:
        def __init__(self):
            self.func = mock_func
            self.func1 = mock_func1

    class MockClass1:
        def __init__(self):
            self.func = mock_func
            self.func1 = mock_func1
            self.func2 = mock_func1

    # Try passing callable function as obj
    assert has_callables(mock_func, '__call__') is True

    # Try passing class with __call__ method as obj

# Generated at 2022-06-21 12:45:10.917260
# Unit test for function has_callables
def test_has_callables():
    msg = 'has_callables failure'
    assert has_callables({}, 'get', 'keys', 'values') is True, msg


# Generated at 2022-06-21 12:45:12.937585
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True

# Generated at 2022-06-21 12:45:21.228112
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like.

    Returns:
        True or raises an exception on failure.
    """
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import Mapping
    from decimal import Decimal
    from typing import overload
    import copy

    # noinspection PyUnresolvedReferences
    def _chk_is_list_like(x):
        assert is_list_like(x) is True
    def _chk_not_list_like(x):
        assert is_list_like(x) is False

    # list
    _chk_is_list_like([False, True, None])
    _chk_is_list_like([])
    _chk_

# Generated at 2022-06-21 12:45:25.879247
# Unit test for function has_any_callables
def test_has_any_callables():
    """ Test function has_any_callables()"""
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo') == False


# Generated at 2022-06-21 12:45:28.676036
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    print(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList))

# Generated at 2022-06-21 12:45:36.197872
# Unit test for function is_list_like
def test_is_list_like():
    # true
    print(is_list_like('-'.join(['hello', 'world'])))
    print(is_list_like(1.0))
    print(is_list_like('a'))
    print(is_list_like(1))
    print(is_list_like(dict(a=1)))
    print(is_list_like(dict(a=1).keys()))
    print(is_list_like(dict(a=1).values()))
    print(is_list_like(list(dict(a=1).keys())))
    print(is_list_like(list(dict(a=1).values())))
    print(is_list_like(tuple(dict(a=1).keys())))

# Generated at 2022-06-21 12:45:46.076343
# Unit test for function has_attrs
def test_has_attrs():
    print("Testing has_attrs")

    class MyClass:
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar
            self.baz = "baz"

    obj = MyClass("foo","bar")
    print(has_attrs(obj, "foo", "bar"))

    # list objects
    list_obj = ["one", "two", "three"]
    print(has_attrs(list_obj, "append"))

    # dict objects
    dict_obj = {"one":1, "two":2, "three":3}
    print(has_attrs(dict_obj, "keys", "values","items"))

    # tuple objects
    tuple_obj = ("one", 1, "two", 2, "three", 3)

# Generated at 2022-06-21 12:45:55.618697
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        deque,
        defaultdict,
    )
    from decimal import Decimal

    assert is_list_like([]) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False
    assert is_list_like(UserDict()) is False
    assert is_list_like(UserList()) is True
    assert is_list_like(UserString()) is False
    assert is_list_like(deque()) is True

# Generated at 2022-06-21 12:46:06.108138
# Unit test for function has_attrs
def test_has_attrs():
    import logging

    log = logging.getLogger(__name__ + ".test_has_attrs")
    log.info('\n')

    log.info('Testing function has_attrs()')

# Generated at 2022-06-21 12:46:14.013541
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, None) is False


# Generated at 2022-06-21 12:46:17.647830
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

# Generated at 2022-06-21 12:46:21.724544
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Unit test for the function has_any_callables.
    """
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:46:27.132934
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:46:31.082012
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert (is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True)

# Generated at 2022-06-21 12:46:44.171485
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserDict
    from pprint import pprint
    import unittest

    class testobj(UserDict):

        def __init__(self):
            super().__init__(dict(a=1, b=2))
            self.method = lambda: None

        def method(self):
            pass

    obj = testobj()
    pprint(dict(obj))
    assert has_attrs(obj, 'method', 'a') is True
    # Test attributes that don't exist
    assert has_attrs(obj, 'c', 'b', 'd') is False


if __name__ == '__main__':
    """Run the tests:

    $ python -m flutils.objutils
    """
    import sys
    import unittest

    # noinspection PyUnresolvedReferences
    unitt

# Generated at 2022-06-21 12:46:46.368280
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), "get", "keys", "items", "values", "something")



# Generated at 2022-06-21 12:46:49.971536
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'foobar', 'barfoo') is False


# Generated at 2022-06-21 12:46:53.104280
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_attrs(dict(), 'foo') == False


# Generated at 2022-06-21 12:47:05.426550
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserList
    from collections.abc import ValuesView, KeysView, Iterator

    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(list(), '__getitem__', 'pop') is True
    assert has_attrs(tuple(), '__getitem__', 'pop') is False
    assert has_attrs(dict(), 'something', 'else') is False
    assert has_attrs(set(), '__getitem__', 'pop') is False
    assert has_attrs(frozenset(), '__getitem__', 'pop') is False
    assert has_attrs(UserList(), '__getitem__', 'pop') is True
    assert has_attrs(ValuesView(dict()), '__getitem__', 'pop') is True


# Generated at 2022-06-21 12:47:20.558969
# Unit test for function has_attrs
def test_has_attrs():
    """ Unit test for the function has_attrs.
    """
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','keys','items','values','foo') is False
    assert has_attrs(dict(a=1,b=2),'get','keys','items','values','foo') is False
    assert has_attrs(dict(a=1,b=2),'get','keys','items','values','foo','bar') is False
    assert has_attrs(dict(a=1,b=2),'get','keys','items','values','foo','bar','baz') is False


# Generated at 2022-06-21 12:47:26.320594
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'keys', 'items', 'values') is True
    assert has_any_attrs(obj, 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(obj, 'foo', 'bar') is False
    assert has_any_attrs(obj, 'foo', 'bar', 'get') is True


# Generated at 2022-06-21 12:47:29.776635
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3])
    assert is_list_like(reversed([1,2,4]))
    assert not is_list_like('hello')
    assert is_list_like(sorted('hello'))
    pass


# Generated at 2022-06-21 12:47:31.904874
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-21 12:47:36.012809
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

test_is_subclass_of_any()


# Generated at 2022-06-21 12:47:42.042253
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    from collections import ValuesView, KeysView, UserList, UserDict
    obj = dict(a=1, b=2, c=3)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList, UserDict) is True

# Generated at 2022-06-21 12:47:48.706365
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    attrs = "get keys items values".split(' ')
    assert has_any_attrs(obj, *attrs) == True
    assert has_any_attrs(obj, "foo bar baz".split(' ')) == False
    assert has_any_attrs(obj, 'a', 'b', 'c', 'd') == True
    assert has_any_attrs(obj, 'a', 'b', 'c', 'e') == False
    assert has_any_attrs(obj, 'd', 'e') == False


# Generated at 2022-06-21 12:47:53.374270
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = {'foo': 'bar'}
    attrs = ['get', 'keys', 'items']
    res = has_any_attrs(obj, *attrs)
    assert res


# Generated at 2022-06-21 12:47:57.176777
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'get', 'keys', 'items', 'values')
    assert has_callables(obj, 'get') is False
    assert has_callables(obj, 'foo') is False


# Generated at 2022-06-21 12:48:06.700670
# Unit test for function has_any_callables
def test_has_any_callables():
    expected = False
    actual = has_any_callables(dict(),'get','keys','items','values','foo')
    assert actual == expected

    expected = True
    actual = has_any_callables(dict(),'get','keys','items','values')
    assert actual == expected

    expected = True
    actual = has_any_callables(dict(),'get')
    assert actual == expected

    expected = True
    actual = has_any_callables(dict(),'keys','items','values')
    assert actual == expected

    expected = True
    actual = has_any_callables(dict(),'foo')
    assert actual == expected



# Generated at 2022-06-21 12:48:19.572216
# Unit test for function is_list_like
def test_is_list_like():
    objs = [
        [],
        [[]],
        [[],[]],
        [[1],[2]],
        [[1,2],[]],
        dict(),
        dict(a=1),
        dict(a=1,b=2),
        frozenset(),
        frozenset([1,2]),
        [1,2],
        [1,2,3],
        (),
        (1,),
        (1,2),
        (1,2,3),
        set(),
        set([1,2]),
        {1,2},
        {1,2,3},
        lambda x: str(x),
        set([1,2]),
        {1,2},
        {1,2,3},
    ]

# Generated at 2022-06-21 12:48:21.992490
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import has_any_attrs
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'b') is False


# Generated at 2022-06-21 12:48:25.528960
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'foobar','keys','items','values','foo') is False


# Generated at 2022-06-21 12:48:32.913975
# Unit test for function has_callables
def test_has_callables():
    # import functions for testing
    from flutils.objutils import has_callables
    # create a class
    class Foo:
        def __repr__(self):
            return "Foo"
        def __str__(self):
            return "Foo"
        def mymethod(self, x):
            return x
        @property
        def myprop(self):
            return self
        @myprop.setter
        def myprop(self, value):
            return value
    # instantiate the class
    foo = Foo()
    # test the callable
    assert has_callables(foo, 'myprop', 'myprop', 'mymethod') is True
    assert has_callables(foo, 'myprop', '__str__', 'mymethod') is True

# Generated at 2022-06-21 12:48:42.485986
# Unit test for function has_attrs
def test_has_attrs():
    # Dictionary has .get, .keys, .items, .values
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    # Dictionary doesn't have .foo
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    # Dictionary doesn't have .foo and .bar
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    # Dictionary doesn't have .bar
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'bar') is False
    # Dictionary doesn't have .bar and .foo
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'bar', 'foo') is False

    # Dictionary has .

# Generated at 2022-06-21 12:48:46.443548
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True


# Generated at 2022-06-21 12:48:55.988668
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list((1, 2, 3, 4))) is True
    assert is_list_like(set((5, 6, 7, 8))) is True
    assert is_list_like(frozenset((9, 10, 11, 12))) is True
    assert is_list_like(tuple((13, 14, 15, 16))) is True
    assert is_list_like(deque((17, 18, 19, 20))) is True
    assert is_list_like(Iterator((21, 22, 23, 24))) is True
    assert is_list_like(ValuesView((25, 26, 27, 28))) is True
    assert is_list_like(KeysView((29, 30, 31, 32))) is True
    assert is_list_like(UserList((33, 34, 35, 36))) is True

# Generated at 2022-06-21 12:48:58.533789
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-21 12:49:06.549370
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    # noinspection PyUnresolvedReferences
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    )
    from collections.abc import KeysView, ValuesView
    # noinspection PyUnresolvedReferences
    from decimal import Decimal
    # noinspection PyUnresolvedReferences
    from typing import (
        Any,
        Callable,
        Iterable,
        Iterator,
        Optional,
        Tuple,
    )

    # FUNC: has_callables(obj, *attrs)
    assert has_callables(Counter(), 'most_common')
    assert has_callables(OrderedDict(), 'values')

# Generated at 2022-06-21 12:49:17.785765
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict, UserList, UserString
    from collections.abc import Sequence
    from decimal import Decimal
    from typing import Any as _Any

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'values', 'items') is True
    assert has_callables(dict(), 'keys', 'values', 'items', 'get') is True
    assert has_callables(dict(), 'keys', 'values', 'get', 'items') is True
    assert has_callables(dict(), 'keys', 'items', 'get', 'values') is True
    assert has_callables(dict(), 'keys', 'items', 'values', 'get') is True

# Generated at 2022-06-21 12:49:32.621617
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo') is False
    assert has_any_attrs(None, 'foo') is False
    assert has_any_attrs('hello', '__iter__') is True



# Generated at 2022-06-21 12:49:35.487896
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:49:44.974314
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    # Test is_subclass_of_any with various objects
    assert is_subclass_of_any(None, int) == False
    assert is_subclass_of_any(None, int, type(None)) == True
    assert is_subclass_of_any('', int) == False
    assert is_subclass_of_any('', str, int) == True
    assert is_subclass_of_any(True, bool) == True
    assert is_subclass_of_any(1, int) == True
    assert is_subclass_of_any(1, int, set) == True
    assert is_subclass_of_any(1, dict) == False
    assert is_subclass_of_any(1, dict, list) == False

# Generated at 2022-06-21 12:49:56.328635
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'something')
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'something')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'something')
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'something')
    assert has_any_callables(dict(), 'get', 'keys', 'values') is False
    assert has_any_callables(dict(), 'get', 'foo', 'values') is False
    assert has_any_callables(dict(), 'keys', 'items', 'something') is False
    assert has_any_callables(dict(), 'keys', 'values', 'something') is False

# Generated at 2022-06-21 12:50:05.924898
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from flutils.objutils import has_callables
    from flutils.objutils import has_attrs
    from collections import Counter
    from collections import ChainMap
    from collections import OrderedDict
    from collections import UserDict
    from collections import UserList
    from collections import UserString
    from collections import defaultdict
    from decimal import Decimal

    assert is_list_like([]) == True
    assert is_list_like(set()) == True
    assert is_list_like(tuple()) == True
    assert is_list_like(frozenset()) == True
    assert is_list_like(dict()) == False
    assert is_list_like(OrderedDict()) == False
    assert is_list_like(deque()) == True

# Generated at 2022-06-21 12:50:18.812643
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(1) is False
    assert is_list_like(1.0) is False
    assert is_list_like('hello') is False
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(iter([1, 2, 3])) is True
    assert is_list_like(map(str, [1, 2, 3])) is True

# Generated at 2022-06-21 12:50:29.385749
# Unit test for function is_list_like
def test_is_list_like():
    from pytest import mark, raises

    from flutils.objutils import is_list_like


# Generated at 2022-06-21 12:50:31.307393
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'key', 'values', 'foo') == True


# Generated at 2022-06-21 12:50:43.042919
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    # List-like objects
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(sorted(list())) is True
    assert is_list_like(reversed(list())) is True
    assert is_list_like(UserList()) is True
    assert is_list_like(ValuesView(dict())) is True

# Generated at 2022-06-21 12:50:53.213558
# Unit test for function has_callables
def test_has_callables():
    from typing import Dict, Iterable
    # noinspection PyUnresolvedReferences
    from flutils.objutils import has_callables
    from flutils.objutils import IterDict
    from flutils.lists import IterList
    from flutils.sets import IterSet
    from flutils.typings import StringIterable
    from flutils.typings import StringIterableDict
    from flutils.typings import StringIterableIterable
    from flutils.typings import StringIterableDictIterable
    from flutils.typings import StringIterableIterableIterable

    # noinspection PyTypeChecker

# Generated at 2022-06-21 12:51:11.578158
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(obj.keys(),KeysView,UserList) == True
    assert is_subclass_of_any(obj.keys(),KeysView) == False


# Generated at 2022-06-21 12:51:20.157832
# Unit test for function is_list_like
def test_is_list_like():
    # list-like objects
    assert is_list_like([]) is True
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(Iterator([])) is True
    assert is_list_like(KeysView({})) is True
    assert is_list_like(ValuesView({})) is True
    assert is_list_like(UserList()) is True

    # not list-like
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False

# Generated at 2022-06-21 12:51:32.307531
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import unittest
    from unittest import mock
    from flutils.objutils import has_any_attrs
    class D(dict):
        pass
    class C(object):
        pass
    class F(object):
        def __init__(self):
            super().__setattr__('d', {})
        def __setattr__(self, key, value):
            self.d[key] = value
        def __getattr__(self, key):
            return self.d.get(key)


# Generated at 2022-06-21 12:51:40.233280
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import (
        is_list_like,
    )
    from flutils.objutils import (
        is_subclass_of_any,
    )
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )

    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like('hello')
    assert is_list_like(sorted('hello'))
    assert is_list_like(1)
    assert is_list_like(None)
    assert is_list_like(True)
    assert is_list_like(False)

# Generated at 2022-06-21 12:51:43.627251
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2, c=3)
    assert has_any_attrs(obj, 'd', 'e', 'f') is False
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:51:45.380804
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True


# Generated at 2022-06-21 12:51:49.393475
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList))

# Generated at 2022-06-21 12:51:54.527046
# Unit test for function has_any_callables
def test_has_any_callables():
    _dict = dict(a=1, b=2)
    assert has_any_callables(_dict, 'keys', 'items', 'values') is True
    _list = [1, 2, 3]
    assert has_any_callables(_list, 'keys', 'items', 'values') is False



# Generated at 2022-06-21 12:52:02.629596
# Unit test for function has_any_callables
def test_has_any_callables():
    print('\nTesting function has_any_callables...')

    print('\nTesting object dict...')
    callables = ['get', 'items', 'keys', 'values']
    results = ['get', '','items','','','','values','','','','','','','','',
        {}]
    for callable in callables:
        results[callables.index(callable)] = has_any_callables(
            dict(), callable,
            'foo', 'bar', 'baz', 'spam', 'eggs', 'ham',
            'something', 'completely', 'different', '', '', '', ''
        )
    print('\t', 'Test if all callables are properly identified:')

# Generated at 2022-06-21 12:52:06.000418
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(obj, 'foo', 'bar', 'baz') is False



# Generated at 2022-06-21 12:52:30.292486
# Unit test for function is_list_like
def test_is_list_like():
    from_cls_list = [
        None,
        UserList,
        Iterator,
        KeysView,
        ValuesView,
        deque,
        frozenset,
        list,
        set,
        tuple,
    ]
    for cls in from_cls_list:
        inst = cls()
        assert is_list_like(inst) is True
    not_from_cls_list = [
        bool,
        Callable,
        bytes,
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        defaultdict,
        Decimal,
        dict,
        float,
        int,
        str,
        UserString,
    ]
    for cls in not_from_cls_list:
        inst = cls()

# Generated at 2022-06-21 12:52:32.222655
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:52:37.441797
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import (
        has_callables,
        has_attrs
    )
    class Foo:
        def a(self):
            pass
    assert has_attrs(Foo, 'a') is True
    assert has_callables(Foo, 'a') is True



# Generated at 2022-06-21 12:52:48.340868
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True

# Generated at 2022-06-21 12:52:56.494389
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(a=1, b=2, c=3), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(a=1, b=2, c=3), 'foo', 'bar', 'baz')
    assert not has_attrs(dict(a=1, b=2, c=3), 'foo')
    assert not has_attrs(dict(), 'foo')


# Generated at 2022-06-21 12:52:58.666382
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    test_dictionary = dict(a=1, b=2)
    assert is_subclass_of_any(test_dictionary.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:53:02.333970
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'bar', 'baz') is False


# Generated at 2022-06-21 12:53:05.971281
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'bar','foo') == False


# Generated at 2022-06-21 12:53:17.992742
# Unit test for function is_list_like
def test_is_list_like():
    import flutils.objutils
    import collections
    import decimal

    # classes which are NOT list-like
    not_list_like = [
        collections.ChainMap,
        collections.Counter,
        collections.OrderedDict,
        collections.UserDict,
        collections.UserString,
        int,
        float
    ]
    # instances which are NOT list-like

# Generated at 2022-06-21 12:53:23.166930
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for function has_attrs"""
    cls = dict
    expected = True
    actual = has_attrs(cls(a=1, b=2), 'keys', 'values', 'get')
    assert expected == actual
    assert has_attrs(cls(a=1, b=2), 'keys', 'get')
    assert has_attrs(cls(a=1, b=2), 'keys')



# Generated at 2022-06-21 12:53:59.535615
# Unit test for function has_attrs
def test_has_attrs():
    "Unit test for function has_attrs"
    assert has_attrs(dict(), 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop',
                     'popitem', 'setdefault', 'update', 'values') == True



# Generated at 2022-06-21 12:54:08.661996
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([], 'extend', 'pop', 'append', 'foo')
    assert has_any_callables([], 'extend', 'pop', 'append', 'foo')
    assert has_any_callables(dict, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict, 'pop', 'popitem', 'setdefault', 'foo') is True
    assert has_any_callables(dict, 'pop', 'popitem', 'setdefault') is True
    assert has_any_callables(dict, 'pop', 'popitem', 'setdefault', 'clear') is True
    assert has_any_callables(dict, 'pop', 'popitem', 'setdefault', 'clear', 'copy') is True

# Generated at 2022-06-21 12:54:21.193144
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(1, 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(1.0, 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(1.0, 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(
        'hello world', 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs((1, 2, 3), 'get', 'keys', 'items', 'values', 'something')

# Generated at 2022-06-21 12:54:23.005960
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:54:27.726733
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'keys', 'values', 'items', '__getitem__') is True
    assert has_any_attrs(obj, 'keys', 'values', 'items', '__missing__') is True



# Generated at 2022-06-21 12:54:30.674875
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)



# Generated at 2022-06-21 12:54:33.663120
# Unit test for function is_list_like
def test_is_list_like():
  assert is_list_like([1, 2, 3])
  assert is_list_like(reversed([1, 2, 4]))
  assert not is_list_like('hello')
  assert is_list_like(sorted('hello'))


# Generated at 2022-06-21 12:54:38.238643
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'foo','bar','baz','qux')
    assert not has_attrs(dict(),'get','keys','items','values','foo','bar','baz','qux')


# Generated at 2022-06-21 12:54:48.305509
# Unit test for function is_list_like
def test_is_list_like():
    from pytest import raises

    with raises(TypeError):
        is_list_like(None)
    with raises(TypeError):
        is_list_like(bool())
    with raises(TypeError):
        is_list_like(bytes())
    with raises(TypeError):
        is_list_like(bytes('hello', 'utf-8'))
    with raises(TypeError):
        is_list_like(int())
    with raises(TypeError):
        is_list_like(float())
    with raises(TypeError):
        is_list_like(str())
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True

# Generated at 2022-06-21 12:54:56.556097
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        deque,
        OrderedDict,
        ChainMap,
        UserDict,
        UserString,
        Counter,
        defaultdict,
        OrderedDict,
        KeysView,
        ValuesView,
    )

    assert is_subclass_of_any(UserList(), UserList) is True
    assert is_subclass_of_any(deque([1, 2, 3]), deque) is True
    assert is_subclass_of_any(OrderedDict(a=1, b=2), OrderedDict) is True
    assert is_subclass_of_any(ChainMap(a=1, b=2), ChainMap) is True