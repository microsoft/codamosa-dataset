

# Generated at 2022-06-21 12:45:07.113519
# Unit test for function has_any_attrs
def test_has_any_attrs():
    d1 = dict()
    assert has_any_attrs(d1, 'get', 'keys', 'values')
    assert not has_any_attrs(d1, 'foo', 'bar', 'baz')



# Generated at 2022-06-21 12:45:13.799494
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(b'hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-21 12:45:21.508442
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserList, UserString, UserDict
    from decimal import Decimal
    from decimal import DecimalException

    from flutils.objutils import (
        has_attrs,
    )

    # Test basic types
    assert has_attrs(True, 'numerator', 'denominator') is True
    assert has_attrs(False, 'numerator', 'denominator') is True
    assert has_attrs(None, 'numerator', 'denominator') is False
    assert has_attrs(float('nan'), 'numerator', 'denominator') is False
    assert has_attrs(float('-inf'), 'numerator', 'denominator') is False
    assert has_attrs(float('inf'), 'numerator', 'denominator') is False
    assert has_att

# Generated at 2022-06-21 12:45:22.808402
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'foo','bar','baz') == False


# Generated at 2022-06-21 12:45:26.366960
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False


# Generated at 2022-06-21 12:45:30.044354
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'something','foo','bar','baz') == False
    obj = dict()
    assert has_any_attrs(obj,'__get','__set','__del','__contains__')


# Generated at 2022-06-21 12:45:32.832210
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:45:35.501084
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True


# Generated at 2022-06-21 12:45:45.652082
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(object(), 'foo', '__str__') is False
    assert has_any_callables(object(), 'foo', '__str__') is False
    assert has_any_callables(int, 'foo', '__str__') is False
    assert has_any_callables([], 'foo', 'append') is True
    assert has_any_callables(dict(), 'foo', 'get') is True
    assert has_any_callables(set(), 'foo', 'add') is True
    assert has_any_callables(tuple(), 'foo', 'count') is True
    assert has_any_callables(frozenset(), 'foo', 'difference') is True
    assert has_any_callables(sorted('hello'), 'foo', '__len__') is True
    assert has_

# Generated at 2022-06-21 12:45:55.435413
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        UserList,
        deque,
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    assert is_list_like(UserList()) is True
    assert is_list_like(deque([0])) is True
    assert is_list_like(set()) is True
    assert is_list_like(Counter([0, 1])) is False
    assert is_list_like(OrderedDict({0: 0, 1: 1})) is False
    assert is_list_like(UserDict({0: 0, 1: 1})) is False
    assert is_list_like(UserString('hello')) is False

# Generated at 2022-06-21 12:46:07.824137
# Unit test for function is_list_like
def test_is_list_like():
    class TestList(UserList):
        pass
    tests = [
        (TestList(), True),
        (reversed([1, 2, 3]), True),
        (sorted('hello'), True),
        (sorted('hello', reverse=True), True),
        (list(), True),
        (tuple(), True),
        (set(), True),
        (frozenset(), True),
        (deque(), True),
        (dict(), False),
        (None, False),
        (bool(), False),
        (bytes(), False),
        (str(), False),
        (float(), False),
        (int(), False),
    ]
    for obj, expected in tests:
        result = is_list_like(obj)

# Generated at 2022-06-21 12:46:12.348925
# Unit test for function has_attrs
def test_has_attrs():
    # Test 1
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True

    # Test 2
    assert has_attrs(dict(), 'foo', 'bar') is False



# Generated at 2022-06-21 12:46:20.570979
# Unit test for function has_attrs
def test_has_attrs():
    from collections import (
        UserDict,
        UserList,
    )
    assert has_attrs(UserList(), 'data', 'pop') is True
    assert has_attrs(UserDict(), 'data', 'pop') is True
    assert has_attrs(UserList(), 'data', 'pop', 'foobar') is False
    assert has_attrs(UserDict(), 'data', 'pop', 'foobar') is False
    assert has_attrs(UserList(), 'foobar') is False
    assert has_attrs(UserDict(), 'foobar') is False



# Generated at 2022-06-21 12:46:34.280285
# Unit test for function has_attrs
def test_has_attrs():
    def func():
        pass

    obj = dict()
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True

    obj = 'this is a string'
    assert has_attrs(obj, 'upper', 'lower', 'replace', 'split') is True

    obj = func
    assert has_attrs(obj, '__code__', '__annotations__', '__defaults__') is True

    obj = 36424
    assert has_attrs(obj, 'to_bytes', 'bit_length', 'denominator', 'real') \
        is True

    obj = False
    assert has_attrs(obj, '__bool__', '__and__', '__int__', '__index__') \
        is True

    obj = None

# Generated at 2022-06-21 12:46:41.407058
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'foo', 'values') is False
    obj = dict(a=1, b=2)
    assert has_calleables(obj.keys(), 'a', 'b') is False


# Generated at 2022-06-21 12:46:50.758957
# Unit test for function is_list_like
def test_is_list_like():
    import unittest
    import collections
    import decimal
    from flutils.objutils import is_list_like
    class TestCase(unittest.TestCase):
        def test_is_list_like(self):
            objs = [list, set, frozenset, tuple, collections.deque,
                    collections.Mapping, collections.UserList,
                    collections.ChainMap, collections.Counter,
                    collections.OrderedDict, collections.UserDict,
                    collections.UserString, decimal.Decimal, dict,
                    collections.defaultdict, tuple, int, float, str,
                    collections.abc.Generator, collections.abc.Iterator,
                    collections.abc.KeysView, collections.abc.ValuesView]
            for obj in objs:
                self.assertEqual(is_list_like(obj), False)



# Generated at 2022-06-21 12:47:02.969519
# Unit test for function has_any_callables
def test_has_any_callables():
    class TestClass:
        def __init__(self):
            self.__foo = 'foo'

        @property
        def foo(self):
            return self.__foo

    assert has_any_callables(TestClass, '__init__') is True
    assert has_any_callables(TestClass, 'bar') is False
    assert has_any_callables(TestClass, 'foo') is False
    assert has_any_callables(TestClass, 'foo', 'bar') is False
    assert has_any_callables(TestClass, 'foo', 'bar', '__init__') is True
    assert has_any_callables(TestClass, 'foo', 'bar', '__init__', '__name__') is True

# Generated at 2022-06-21 12:47:07.351618
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1,b=2)
    assert has_any_callables(obj,'get','keys','foo') is True
    assert has_any_callables(obj,'foo','something') is False
    assert has_any_callables(obj,'items','values','keys') is True



# Generated at 2022-06-21 12:47:09.639781
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')


# Generated at 2022-06-21 12:47:22.165648
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert False is is_list_like('hello')
    assert False is is_list_like(None)
    assert True is is_list_like(sorted('hello'))
    assert True is is_list_like(reversed('hello'))
    assert True is is_list_like(tuple(reversed('hello')))
    assert True is is_list_like(list(reversed('hello')))
    assert True is is_list_like(set(reversed('hello')))
    assert True is is_list_like(frozenset(reversed('hello')))
    assert True is is_list_like(deque(reversed('hello')))

# Generated at 2022-06-21 12:47:37.542538
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(None) == False
    assert is_list_like(True) == False
    assert is_list_like(False) == False
    assert is_list_like(0) == False
    assert is_list_like(1) == False
    assert is_list_like(str()) == False
    assert is_list_like(bytes()) == False
    assert is_list_like(u'') == False
    assert is_list_like(set()) == True
    assert is_list_like(frozenset()) == True
    assert is_list_like(tuple()) == True
    assert is_list_like(list()) == True
    assert is_list_like(deque()) == True
    assert is_list_like(UserList()) == True

# Generated at 2022-06-21 12:47:39.102153
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'something')



# Generated at 2022-06-21 12:47:42.879109
# Unit test for function has_callables
def test_has_callables():
    """Test for function has_callables
    """
    try:
        class TestDict(dict):
            def get(self):
                return 'TestDict'
        test_dict = TestDict()
        assert has_callables(test_dict, 'get')
    except Exception as err:
        print('\nFailed test_has_callables: {0}\n'.format(err))
        assert False



# Generated at 2022-06-21 12:47:45.936875
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    '''
    >>> from collections import ValuesView, KeysView, UserList
    >>> obj = dict(a=1, b=2)
    >>> is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    True
    '''
    pass

# Generated at 2022-06-21 12:47:52.197400
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs('hello','count','upper','replace','startswith','something') is True
    assert has_any_attrs(None,'get','keys','items','values','something') is False



# Generated at 2022-06-21 12:47:58.822930
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import defaultdict
    ref = defaultdict(lambda: 'bar')
    assert has_any_callables(ref, 'get') is True
    assert has_any_callables(ref, 'foobar') is False
    assert has_any_callables(ref, 'get', 'keys') is True
    assert has_any_callables(ref, 'foobar', 'keys') is True
    assert has_any_callables(ref, 'foobar', 'somethingelse') is False

# Generated at 2022-06-21 12:48:02.877932
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    obj = defaultdict(list)
    assert has_callables(obj,'get','keys','items','values','default_factory')
    assert not has_callables(obj,'get','keys','items','values')

# Generated at 2022-06-21 12:48:06.199240
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'get','keys','items','values') is True


# Generated at 2022-06-21 12:48:16.134655
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs.
    """

    assert has_any_attrs(None, 'foo') is False
    assert has_any_attrs(1, 'foo') is False
    assert has_any_attrs('string', 'foo') is False
    assert has_any_attrs(Bool(), 'foo') is False
    assert has_any_attrs(1.0, 'foo') is False
    assert has_any_attrs(1, 'foo') is False
    assert has_any_attrs(dict(), 'foo') is False
    assert has_any_attrs(dict(a=1), 'foo') is False
    assert has_any_attrs(dict(a=1), 'foo') is False
    assert has_any_attrs(list(), 'foo') is False
   

# Generated at 2022-06-21 12:48:20.370213
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-21 12:48:31.864847
# Unit test for function has_callables
def test_has_callables():
    import copy

    class A():
        def __call__(self):
            pass
    a = A()
    class B():
        pass
    b = B()

    assert has_callables(a, '__call__')
    assert has_callables(b, 'something') is False
    assert has_callables(copy, 'copy', 'deepcopy')


# Generated at 2022-06-21 12:48:37.988103
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    class MyList(list):
        pass

    class MyUserList(UserList):
        pass

    mylist = MyList()
    myuserlist = MyUserList()

    assert mylist.__class__.__bases__ == (MyList, list, object)
    assert myuserlist.__class__.__bases__ == (MyUserList, UserList, object)

    assert is_subclass_of_any(mylist, list, UserList)
    assert is_subclass_of_any(myuserlist, list, UserList)


# Generated at 2022-06-21 12:48:41.121665
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any(dict().keys(), ValuesView, KeysView, UserList) is True


# Generated at 2022-06-21 12:48:45.052195
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:48:55.142025
# Unit test for function has_any_callables
def test_has_any_callables():
    # for the sake of better code coverage,
    # we are going to have several different examples in this function
    cls1 = type('cls1', (object,), {})  # pylint:disable=unused-variable
    cls2 = type('cls2', (object,), {})  # pylint:disable=unused-variable
    cls3 = type('cls3', (object,), {})  # pylint:disable=unused-variable
    cls4 = type('cls4', (object,), {})  # pylint:disable=unused-variable
    cls5 = type('cls5', (object,), {})  # pylint:disable=unused-variable
    cls6 = type('cls6', (object,), {})  # pylint:disable

# Generated at 2022-06-21 12:48:57.758363
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), "get", "keys", "items", "values")


# Unit Test for function has_attrs

# Generated at 2022-06-21 12:49:04.584559
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    classes = [
        UserList,
        ValuesView,
        KeysView,
    ]
    for cls in classes:
        assert is_subclass_of_any(UserList(), *classes)
        assert is_subclass_of_any(ValuesView({}), *classes)
        assert is_subclass_of_any(KeysView({}), *classes)
        assert is_subclass_of_any(dict(a=1, b=2).values(), *classes)
        assert is_subclass_of_any(dict(a=1, b=2).keys(), *classes)

# Generated at 2022-06-21 12:49:13.390244
# Unit test for function has_any_callables
def test_has_any_callables():
    class Foo:
        def __init__(self):
            self.foo = None
            self.bar = None
            self.baz = lambda: None
            self.foobar = lambda: None

    foo = Foo()

    assert has_any_callables(foo, 'foo', 'bar', 'baz', 'foobar')

    foo.baz = None
    foo.foobar = None

    assert not has_any_callables(foo, 'foo', 'bar', 'baz', 'foobar')


# Generated at 2022-06-21 12:49:18.260898
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'foo','bar','baz') == False
    return


# Generated at 2022-06-21 12:49:19.643545
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict, 'get', 'keys') is True



# Generated at 2022-06-21 12:49:28.948459
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Unit test for function is_subclass_of_any
    """
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),str) == False

# Generated at 2022-06-21 12:49:33.786968
# Unit test for function is_list_like
def test_is_list_like():
    """Check that function is_list_like returns the correct answer
    """
    assert is_list_like([1, 2, 3])
    assert not is_list_like('a string')
    assert is_list_like(iter('a string'))

# Generated at 2022-06-21 12:49:37.478553
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:49:39.665710
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(dict(),'get','keys','items','values') == True)


# Generated at 2022-06-21 12:49:43.064703
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'get','keys','items','values','foo')
    assert has_callables(dict(),'get','keys','items','values','foo','bar')

# Generated at 2022-06-21 12:49:54.738834
# Unit test for function is_list_like
def test_is_list_like():
    """
    Check that function is_list_like() works as expected.

    :rtype:
        :obj:`bool`

        * :obj:`True` if the test passes;
        * :obj:`False` otherwise.
    """
    list_like_objs = [
        UserList([1,2,3]),
        [1,2,3],
        (1,2,3),
        set([1,2,3]),
        frozenset([1,2,3]),
        deque([1,2,3]),
        iter([1,2,3]),
        reversed([1,2,3]),
        sorted([1,2,3]),
        sorted([1,2,3],reverse=True),
    ]


# Generated at 2022-06-21 12:50:00.179621
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(obj, 'foo', 'bar', 'cozy') is False
    assert has_any_callables(obj, '_comparison_key') is False



# Generated at 2022-06-21 12:50:08.794248
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # assert has_any_attrs(dict(),'get','keys','items','values','something')
    # assert has_any_attrs(list(),'append','remove','index')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'bar') is False
    assert has_any_attrs(list(), 'append', 'remove', 'index', 'foo') is False
    assert has_any_attrs(list(), 'append', 'remove', 'index', 'foo', 'bar') is False

# Generated at 2022-06-21 12:50:18.109857
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class MyClass():
        def func1(self):
            pass
        def func2(self):
            pass
        def func3(self):
            pass
    obj = MyClass()
    assert has_any_attrs(obj, "func1", "func2", "func3") == True
    assert has_any_attrs(obj, "func1", "func2", "func9") == True
    assert has_any_attrs(obj, "func9", "func8", "func7") == False



# Generated at 2022-06-21 12:50:28.909540
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(0) is False
    assert is_list_like(1) is False
    assert is_list_like(1.0) is False
    assert is_list_like('hello') is False
    assert is_list_like(b'hello') is False

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(['hello', 'there']) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like(('hello', 'there')) is True
    assert is_list_like({1, 2, 3}) is True
    assert is_

# Generated at 2022-06-21 12:50:48.603293
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # DEBUG
    from pprint import pprint as pp
    from flutils.debugutils import set_tracemask
    set_tracemask()
    # END DEBUG

    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

    # pp(dir(obj.keys()))
    # pp(dir(ValuesView))
    # pp(dir(KeysView))
    # pp(dir(UserList))

    # print('obj is instance of ValuesView',
    #       is_subclass_of_any(obj.keys(),ValuesView))
    # print('obj is instance of KeysView',
    #       is_subclass_of_any(obj.keys(),KeysView

# Generated at 2022-06-21 12:50:50.964974
# Unit test for function has_callables
def test_has_callables():
    """
    Testing has_callables
    :return:
    """
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:50:57.142204
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict
    )
    from decimal import Decimal
    import types

    assert is_list_like([1,2,3])
    assert is_list_like(reversed([1,2,3]))
    assert is_list_like(UserList(list(range(5))))
    assert is_list_like(Counter('abcdeabcdeabcdeabcdeabcde'))
    assert is_list_like(set('abcdeabcdeabcdeabcdeabcde'))
    assert is_list_like(frozenset('abcdeabcdeabcdeabcdeabcde'))
    assert is_

# Generated at 2022-06-21 12:50:59.285871
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get', 'foo', 'bar') == False


# Generated at 2022-06-21 12:51:10.922590
# Unit test for function has_any_callables
def test_has_any_callables():
    from unittest.mock import MagicMock
    obj = MagicMock()

    # Test a mock object with no attributes at all.
    assert has_any_callables(obj, 'foo', 'bar') is False

    obj = MagicMock(foo=True)

    # Test a mock object with boolean attribute.
    # This is not callable
    assert has_any_callables(obj, 'foo', 'bar') is False

    obj = MagicMock(foo=True, bar=True)

    # Test a mock object with two boolean attributes.
    # Again, not callable
    assert has_any_callables(obj, 'foo', 'bar') is False

    obj = MagicMock(foo=None)

    # Test a mock object with NoneType attribute.
    # This is not callable
    assert has_any_

# Generated at 2022-06-21 12:51:13.875721
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'items', 'keys') is True
    assert has_attrs(obj, 'iteritems', 'foo') is False



# Generated at 2022-06-21 12:51:17.697890
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(None) is False


# Generated at 2022-06-21 12:51:28.958666
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), list, set) is False
    assert is_subclass_of_any(obj.keys(), list, dict) is False
    assert is_subclass_of_any(obj.keys(), dict, dict) is False
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(obj, list, set) is False
    assert is_subclass_of_any(obj.keys(), dict, dict) is False

# Generated at 2022-06-21 12:51:30.795258
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj = {'1':1,'2':2,'3':3,'4':4}
    test_list = ['a','b','c']
    assert has_any_callables(test_obj,'keys') == True
    assert has_any_callables(test_list,'pop') == True



# Generated at 2022-06-21 12:51:33.511883
# Unit test for function has_attrs
def test_has_attrs():
    # test_obj = object()
    test_obj = [1, 2, 3]
    assert has_attrs(test_obj, '__iter__', '__getitem__', '__len__')
    assert not has_attrs(test_obj, '__init__')



# Generated at 2022-06-21 12:52:02.799030
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    class Parent:
        pass

    class Child1(Parent):
        pass

    class Child2(Parent):
        pass

    class GrandChild11(Child1):
        pass

    assert is_subclass_of_any(Child1, Parent)
    assert is_subclass_of_any(Child2, Parent)
    assert is_subclass_of_any(GrandChild11, Parent)
    assert is_subclass_of_any(Child1, Child2) is False
    assert is_subclass_of_any(Child1, Child2, GrandChild11)
    assert is_subclass_of_any(Child1, GrandChild11)
    assert is_subclass_of_any(GrandChild11, set)



# Generated at 2022-06-21 12:52:08.409085
# Unit test for function has_attrs
def test_has_attrs():
    try:
        assert has_attrs(dict(),'get','keys','items','values')
        assert has_attrs(dict(),'get','keys','items','values','foo') is False
        assert (has_attrs(dict(),'get','keys','items','values','__class__')
                is False)
    except Exception as e:
        print(e)
        raise
    else:
        print('Passed: "test_has_attrs"')


# Generated at 2022-06-21 12:52:11.344350
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any(dict(a=1,b=2).keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:52:22.491962
# Unit test for function has_callables
def test_has_callables():
    """Test has_callables

    :rtype:
        :obj:`bool`

        * :obj:`True` if the tests pass;
        * :obj:`False` otherwise.
    """
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import (
        MutableMapping,
        Mapping,
    )
    from collections.defaultdict import (
        DefaultDict,
    )
    from decimal import Decimal
    from flutils.objutils import (
        has_callables,
        is_list_like,
    )

    # Check that the given ``obj`` has all the given ``attrs`` and
    # are callable

# Generated at 2022-06-21 12:52:30.134179
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Check that the function is_subclass_of_any returns True if the
    given object is an instance of the class given, False otherwise.
    """
    from flutils.objutils import is_subclass_of_any
    from collections import UserList, UserDict, UserString
    from collections.abc import ValuesView, KeysView
    from flutils.objutils import is_subclass_of_any
    all_classes = [UserList, UserDict, UserString, ValuesView, KeysView]
    # Creation of all instances of the above classes
    items = [[1, 4], {'a': 1, 'b': 2}, 'hello',
             ValuesView({}),
             KeysView({})
             ]
    # We assert that if the object is an instance of any the classes,
    # the function returns True

# Generated at 2022-06-21 12:52:32.775986
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:52:37.496528
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    res = is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    expected = True
    assert res is expected

# Generated at 2022-06-21 12:52:41.985488
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1,b=2,c=3)
    print(has_any_attrs(obj, 'get', 'items', 'keys', 'clear'))
    print(has_any_attrs(obj, 'foo', 'bar', 'baz'))


# Generated at 2022-06-21 12:52:47.057784
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True)
    assert(is_subclass_of_any(obj.keys(),int,KeysView,UserList) == False)

# Generated at 2022-06-21 12:52:51.834146
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-21 12:53:04.042329
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert  has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-21 12:53:06.886373
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'items', 'keys', 'values')

# Generated at 2022-06-21 12:53:09.192954
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True

# Generated at 2022-06-21 12:53:11.432435
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-21 12:53:21.018137
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') == True
    assert has_any_callables(dict(), 'foo', 'bar') == False
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') == False
    assert has_any_callables(dict(), 'foo') == False
    return True



# Generated at 2022-06-21 12:53:25.475960
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    return is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-21 12:53:32.719682
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_ = dict(a=1, b=2)
    for attr in (
            'values', 'keys', 'items', 'something', 'foo', 'get',
            'update', 'clear'
    ):
        assert has_any_callables(dict_, attr)

    set_ = set(['a', 'b'])
    for attr in (
            'values', 'keys', 'items', 'something', 'foo', 'get',
            'update', 'clear'
    ):
        assert not has_any_callables(set_, attr)



# Generated at 2022-06-21 12:53:36.150077
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True


# Generated at 2022-06-21 12:53:42.454947
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'items', 'values')
    assert not has_callables({}, 'get', 'keys', 'foo', 'values')
    assert not has_callables({}, 'get', 'keys', 'items', 'values', 'foo')
    assert has_callables({}.keys(), 'append', 'copy', 'remove')
    assert not has_callables({}.keys(), 'foo', 'copy', 'remove')
    assert not has_callables({}.keys(), 'append', 'copy', 'remove', 'foo')
    assert has_callables([], 'count', 'index', 'append', 'copy')
    assert not has_callables([], 'foo', 'index', 'append', 'copy')

# Generated at 2022-06-21 12:53:47.740878
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables."""
    assert has_any_callables(dict(), 'get', 'keys', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'foo') is False
    assert has_any_callables((), 'get', 'keys', 'foo') is False


# Generated at 2022-06-21 12:54:08.737669
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:54:12.866261
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:54:16.433242
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True

if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-21 12:54:21.583475
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'items', 'values', 'something')
    print(has_any_attrs(obj, *attrs))
    true_value = True

    assert(true_value == has_any_attrs(obj, *attrs))

    # Unit test for function has_any_callables

# Generated at 2022-06-21 12:54:25.756554
# Unit test for function has_attrs
def test_has_attrs():
    # given
    obj = dict(a=1, b=2)
    has_attrs(obj, 'get', 'keys', 'items', 'values')
    # then
    assert has_attrs(obj, 'get', 'keys', 'items', 'values')


# Generated at 2022-06-21 12:54:29.540018
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserList

    assert has_any_callables(UserList(), 'index') is True
    assert has_any_callables(UserList(), 'index', 'something_else') is True
    assert has_any_callables(UserList(), 'something_else') is False



# Generated at 2022-06-21 12:54:36.154738
# Unit test for function is_list_like
def test_is_list_like():
    fstr = 'reversed([1, 2, 3])'
    assert is_list_like(eval(fstr)) is True
    print(f'PASS: {fstr}')
    fstr = 'sorted(reversed([1, 2, 3]))'
    assert is_list_like(eval(fstr)) is True
    print(f'PASS: {fstr}')
    fstr = 'set([1, 2, 3])'
    assert is_list_like(eval(fstr)) is True
    print(f'PASS: {fstr}')
    fstr = 'frozenset([1, 2, 3])'
    assert is_list_like(eval(fstr)) is True
    print(f'PASS: {fstr}')
    fstr = '(1, 2, 3)'


# Generated at 2022-06-21 12:54:39.433644
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'keys','items','values')
    assert has_any_attrs(dict(),'get','keys','items','values','')


# Generated at 2022-06-21 12:54:44.853354
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    from flutils.objutils import has_callables
    _dict = OrderedDict(a=1, b=2)
    assert has_callables(_dict, 'get', 'items', 'values') == True
    assert has_callables(_dict, 'get', 'items', 'values', 'foo') == False


# Generated at 2022-06-21 12:54:50.435312
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_any_callables({}, 'foo', 'bar', 'baz', 'qux', 'quux') is False
