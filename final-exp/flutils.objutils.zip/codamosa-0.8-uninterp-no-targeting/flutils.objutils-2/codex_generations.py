

# Generated at 2022-06-21 12:45:05.898097
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items')



# Generated at 2022-06-21 12:45:09.209301
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get','keys','items','values','foo') == True


# Generated at 2022-06-21 12:45:13.525858
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    obj1 = UserDict(a=1, b=2)
    assert has_callables(obj1, 'get', 'keys') == False
    assert has_callables(obj1, '__setitem__', 'keys') == True



# Generated at 2022-06-21 12:45:21.420076
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import ChainMap
    from collections.abc import Iterator, KeysView, ValuesView
    from decimal import Decimal
    import io
    import os
    import random
    import sys
    import tempfile


# Generated at 2022-06-21 12:45:32.285421
# Unit test for function has_attrs
def test_has_attrs():
    try:
        assert True == has_attrs(dict(),'get','keys','items','values')
    except AssertionError:
        raise AssertionError('Error in function has_attrs')
    try:
        assert False == has_attrs(dict(),'get','keys','items','values','foo')
    except AssertionError:
        raise AssertionError('Error in function has_attrs')
    try:
        assert False == has_attrs(dict(),'get','keys','items','values','foo')
    except AssertionError:
        raise AssertionError('Error in function has_attrs')

# Generated at 2022-06-21 12:45:36.145492
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict, "get", "items", "foo") is True
    assert has_any_attrs(dict, "foo", "bar") is False


# Generated at 2022-06-21 12:45:37.613139
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(tuple(),'index','count') is True


# Generated at 2022-06-21 12:45:40.153522
# Unit test for function has_callables
def test_has_callables():
    with pytest.raises(RuntimeError):
        print(has_callables(dict(), 'foo', 'get'))


# Generated at 2022-06-21 12:45:45.499575
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'something', 'bar')
    assert has_any_callables((2, 3), 'index', 'count', 'foo') is False


# Generated at 2022-06-21 12:45:49.136073
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-21 12:46:03.894317
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict, 'get', 'keys', 'setdefault', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'setdefault', 'items', 'values') is True
    assert has_attrs(dict, 'keys', 'items') is True
    assert has_attrs(dict(), 'keys', 'items') is True
    assert has_attrs(dict, 'get', 'keys') is True
    assert has_attrs(dict(), 'get', 'keys') is True
    assert has_attrs(dict, 'keys') is True
    assert has_attrs(dict(), 'keys') is True
    assert has_attrs(dict, 'foo', 'bar') is False
    assert has_attrs(dict(), 'foo', 'bar') is False



# Generated at 2022-06-21 12:46:16.885514
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    from flutils.objutils import has_any_attrs
    from flutils.objutils import has_callables
    from flutils.objutils import has_any_callables
    from flutils.objutils import is_list_like
    from flutils.objutils import is_subclass_of_any

    obj = dict(k=0)
    assert has_attrs(obj, 'get', 'keys')

    obj = dict(k=0)
    assert has_any_attrs(obj, 'get', 'keys')

    obj = (1, 2, 3)
    assert not has_attrs(obj, 'get', 'keys')

    obj = (1, 2, 3)
    assert has_any_attrs(obj, 'count', 'index')

   

# Generated at 2022-06-21 12:46:21.573362
# Unit test for function is_list_like
def test_is_list_like():
    l1 = [1,2,3]
    l2 = ['a','b','c']
    ll1 = [1,2,3,l1,l2]
    assert is_list_like(l1) == True
    assert is_list_like(l2) == True
    assert is_list_like(ll1) == True

test_is_list_like()

# Generated at 2022-06-21 12:46:22.802127
# Unit test for function has_callables
def test_has_callables():
    pass

# Generated at 2022-06-21 12:46:32.340298
# Unit test for function has_callables
def test_has_callables():
    from flutils.pyutils import f_print
    from flutils.objutils import has_callables

    d = dict(a=1,b=2)
    f_print(has_callables(d,'viewitems','items','keys','values','update','clear','pop','popitem','get','setdefault'))
    f_print(has_callables(d, "get"))
    f_print(has_callables(d, "keys"))
    f_print(has_callables(d, "viewitems"))

# Unit test function is_list_like

# Generated at 2022-06-21 12:46:45.326547
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs([], 'clear', 'reverse', 'pop')
    assert has_any_attrs([], 'copy', 'sort', 'append')
    assert has_any_attrs({}, 'clear', 'items', 'keys')
    assert has_any_attrs(set(), 'discard', 'intersection', 'union')
    assert has_any_attrs(0.0, 'hex', 'is_integer', 'real')
    assert has_any_attrs(0, 'denominator', 'conjugate', 'bit_length')
    assert has_any_attrs('', 'endswith', 'find', 'index')
    assert has_any_attrs(False, '__bool__', '__len__', '__reversed__')

# Generated at 2022-06-21 12:46:49.972647
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items') is False


# Generated at 2022-06-21 12:47:02.353402
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list())
    assert is_list_like([1, 2, 3])
    assert is_list_like(set([1, 2, 3]))
    assert is_list_like(sorted([1, 2, 3]))
    assert is_list_like(reversed([1, 2, 3]))
    assert is_list_like(tuple([1, 2, 3]))
    assert is_list_like([x for x in range(10)])
    assert is_list_like([x for x in range(10) if x % 2 == 0])
    assert is_list_like([x for x in range(10) if x % 2 == 1])
    assert is_list_like(dict())

# Generated at 2022-06-21 12:47:05.792318
# Unit test for function has_any_attrs
def test_has_any_attrs():
    testPassed = False
    if has_any_attrs(dict(),'get','keys','items','values','foo'):
        testPassed = True
    assert testPassed



# Generated at 2022-06-21 12:47:10.932421
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:47:24.902235
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # mycoll is a subclass of deque
    class mycoll(deque):
        pass

    # Test with deque and mycoll
    obj = mycoll([1, 2, 3])
    assert is_subclass_of_any(obj, deque, mycoll) is True

    # Test with mycoll only
    obj = mycoll([1, 2, 3])
    assert is_subclass_of_any(obj, mycoll) is True

    # Test with wrong class
    obj = mycoll([1, 3, 3])
    assert is_subclass_of_any(obj, deque) is False

    # Test with iterable
    obj = [1, 2, 3]
    assert is_subclass_of_any(obj, deque) is False

    # Testing objutils.common.decompose

# Generated at 2022-06-21 12:47:30.157337
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','__add__') is True
    assert has_any_callables(dict(),'get','keys','foo','values','__add__') is False
    assert has_any_callables(dict(),'bar','keys','foo','values','__add__') is False


# Generated at 2022-06-21 12:47:39.640778
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    from collections import UserDict
    from collections import ChainMap
    from collections import Counter
    from collections import OrderedDict
    from collections import UserDict
    from collections import UserList
    from collections import UserString
    from collections import deque
    from collections import frozenset
    from collections import namedtuple
    from collections import OrderedDict
    from collections.abc import Iterator
    from collections.abc import KeysView
    from collections.abc import ValuesView
    from decimal import Decimal
    from numbers import Number
    from typing import Union
    import itertools
    from flutils.objutils import has_callables as _has_callables

    # noinspection PyUnresolvedReferences

# Generated at 2022-06-21 12:47:41.612295
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')==True


# Generated at 2022-06-21 12:47:43.546303
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(a=1),'get','keys','items','values') == True


# Generated at 2022-06-21 12:47:54.996020
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'pop')
    assert has_any_callables(1, 'foo') is False
    assert has_any_callables('test', 'foo') is False
    assert has_any_callables(None, 'foo') is False
    assert has_any_callables([1, 2, 3], 'foo') is False
    assert has_any_callables(('a', 'b', 'c'), 'foo') is False
    assert has_any_callables(True, 'foo') is False
    assert has_any_callables

# Generated at 2022-06-21 12:48:00.238336
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values')
    assert has_attrs(obj.keys(), '__iter__', '__contains__')
    assert not has_attrs(obj, 'foo', 'bar')
    assert not has_attrs(obj, '__call__')



# Generated at 2022-06-21 12:48:11.049869
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_callables([], 'append', 'insert', 'remove', 'foo') is True
    assert has_any_callables([], 'foo', 'bar', 'baz') is False
    assert has_any_callables('', 'split', 'replace', 'upper', 'foo') is True
    assert has_any_callables('', 'foo', 'bar', 'baz') is False
    assert has_any_callables(1, 'bit_length', 'denominator', 'to_bytes', 'foo') is True

# Generated at 2022-06-21 12:48:14.773721
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:48:16.331854
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-21 12:48:20.608575
# Unit test for function has_any_attrs
def test_has_any_attrs():
    d = dict(a=1, b=2)
    assert has_any_attrs(d, 'keys', 'values', 'something')
    assert has_any_attrs(d, 'get', 'values', 'something') is False



# Generated at 2022-06-21 12:48:30.061323
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like"""
    import pytest
    _UNLIST_LIKE = (
        None,
        bool,
        bytes,
        ChainMap,
        Counter,
        Decimal,
        defaultdict,
        dict,
        float,
        int,
        Iterable,
        Mapping,
        MappingView,
        MutableMapping,
        MutableSequence,
        MutableSet,
        MutableSequence,
        OrderedDict,
        Set,
        Sequence,
        str,
        UserDict,
        UserString,
        NamedTuple,
        contextmanager,
    )
    for tl in _LIST_LIKE:
        assert is_list_like(tl()), f'{tl} is not recognized'

# Generated at 2022-06-21 12:48:34.035891
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True



# Generated at 2022-06-21 12:48:35.558374
# Unit test for function is_list_like
def test_is_list_like():
    assert (is_list_like(dict(a=1, b=2)))


# Generated at 2022-06-21 12:48:39.378364
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test function is_subclass_of_any
    """
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:48:43.181045
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict, 'get', 'keys', 'values') is True
    assert has_any_callables(None, 'get', 'keys', 'values') is False



# Generated at 2022-06-21 12:48:45.857688
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    import doctest
    from .objutils import is_subclass_of_any
    doctest.testmod(is_subclass_of_any)

# Generated at 2022-06-21 12:48:52.411760
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj1 = []
    obj2 = {}
    obj3 = lambda: 0
    obj4 = str

    assert(has_any_attrs(obj1, 'remove', 'pop') is True)
    assert(has_any_attrs(obj2, 'remove', 'pop') is True)
    assert(has_any_attrs(obj3, 'remove', 'pop') is False)
    assert(has_any_attrs(obj4, 'remove', 'pop') is True)

# Generated at 2022-06-21 12:48:54.372246
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys') == True


# Generated at 2022-06-21 12:48:57.420654
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-21 12:49:14.343022
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'something') is False
    assert has_callables(dict(), 'get', 'keys', 'something') is False
    assert has_callables(dict(), 'get', 'something') is False
    assert has_callables(dict(), 'something') is False
    assert has_callables(dict(), 'something', 'something2') is False
    assert has_callables(dict(), 'something', 'something2', 'something3') is False
    assert has_callables(dict(), 'something', 'something2', 'something3', 'something4') is False



# Generated at 2022-06-21 12:49:16.783911
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:49:27.561218
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test that ``is_subclass_of_any`` works as expected."""
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict
    )
    from decimal import Decimal

# Generated at 2022-06-21 12:49:40.483984
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(a=1, b=2),'get','keys','items','values','something')
    assert has_any_attrs(list(),'append','count','__contains__','insert','something')
    assert has_any_attrs(list(range(1,6)),'append','count','__contains__','insert','something')
    assert not has_any_attrs(dict(),None)
    assert not has_any_attrs(dict(a=1, b=2),None)
    assert not has_any_attrs(list(),None)
    assert not has_any_attrs(list(range(1,6)),None)

# Generated at 2022-06-21 12:49:43.396527
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'copy', 'update') is True
    assert has_any_callables(obj, 'xyz') is False


# Generated at 2022-06-21 12:49:51.468630
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str, 'replace','find','format','replace') is True
    assert has_callables(str, 'replace','find','format','something') is False
    assert has_callables(None, 'replace','find','format','something') is False
    assert has_callables(int, 'replace','find','format','something') is False
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items','foo') is False


# Generated at 2022-06-21 12:50:01.732325
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(
        obj.keys(), ValuesView, KeysView, UserList
    ) == True
    obj = []
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) == True
    obj = (1, 2, 3)
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) == True
    obj = (1, 2, 3)
    assert is_subclass_of_any(obj, ValuesView, KeysView, list) == True
    obj = (1, 2, 3)
    assert is_subclass_of_any(obj, set, KeysView, list) == False



# Generated at 2022-06-21 12:50:04.255305
# Unit test for function has_any_attrs
def test_has_any_attrs():
    q = dict()
    if has_any_attrs(q, 'get', 'keys', 'items', 'values', 'something') is True:
        print("pass")
    else:
        print("fail")


# Generated at 2022-06-21 12:50:08.310838
# Unit test for function has_any_callables
def test_has_any_callables():
    dict1 = dict()
    dict2 = dict(foo=1,bar=2)
    assert has_any_callables(dict1, 'get', 'keys', 'values', 'items') is True
    assert has_any_callables(dict2, 'get', 'keys', 'values', 'items') is True
    assert has_any_callables(dict1, 'get', 'foo', 'bar') is False
    assert has_any_callables(dict2, 'get', 'foo', 'bar') is False


# Generated at 2022-06-21 12:50:14.513812
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)


if __name__ == '__main__':
    test_is_subclass_of_any()

# Generated at 2022-06-21 12:50:29.423885
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) == True
    assert is_list_like(list()) == True
    assert is_list_like(set()) == True
    assert is_list_like(frozenset()) == True
    assert is_list_like(tuple()) == True
    assert is_list_like([1, 2, 3, 4]) == True
    assert is_list_like(iter([1, 2, 3, 4])) == True
    assert is_list_like(reversed([1, 2, 3, 4])) == True
    assert is_list_like(set([1, 1, 2, 2, 3, 3, 4, 4])) == True
    assert is_list_like(frozenset([1, 2, 3, 4])) == True

# Generated at 2022-06-21 12:50:31.656608
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-21 12:50:34.067956
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

test_has_any_callables()

# Generated at 2022-06-21 12:50:46.060262
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function
    :func:`flutils.objutils.is_list_like <flutils.objutils.is_list_like>`.
    """
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like({}) is False
    assert is_list_like(set([1, 2, 4])) is True
    assert is_list_like(frozenset([1, 2, 4])) is True
    assert is_list_like((1, 2, 4)) is True

# Generated at 2022-06-21 12:50:48.125660
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-21 12:50:50.545079
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'clear','copy','fromkeys')
    assert not has_attrs(dict(),'clear','foo','fromkeys')


# Generated at 2022-06-21 12:50:56.945654
# Unit test for function has_any_attrs

# Generated at 2022-06-21 12:51:08.753474
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like(reversed((1, 2, 3))) is True
    assert is_list_like({'a': 1, 'b': 2}) is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(bytes(b'hello')) is False

# Generated at 2022-06-21 12:51:18.361212
# Unit test for function is_list_like
def test_is_list_like():
    # Create a list of list-like items
    input_items = [
        sorted('hello world'),
        dict(a=1, b=2, c=3),
        [1, 2, 3, 4],
        (i for i in range(1, 5))
    ]
    # Create list of expected results
    expected_results = [
        False,
        False,
        True,
        True
    ]
    # Create list of assertions
    assertions = [is_list_like(item) == expected
                  for item, expected
                  in zip(input_items, expected_results)]
    # Check the assertions
    assert all(assertions)

    # Create list of input items

# Generated at 2022-06-21 12:51:30.443549
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like('my_str') is False
    assert is_list_like(1) is False
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like({'a': 1}) is False
    assert is_list_like(['a', 'b']) is True
    assert is_list_like((1, 2)) is True
    assert is_list_like(('a', 'b')) is True
    assert is_list_like({'a'}) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like(deque([1, 2, 3])) is True
    assert is_list_like(sorted('my_str', reverse=True)) is True


# Generated at 2022-06-21 12:51:34.885236
# Unit test for function has_attrs
def test_has_attrs():
    d = {}
    assert has_attrs(d, "get", "keys", "items", "values") == True



# Generated at 2022-06-21 12:51:43.244674
# Unit test for function is_list_like
def test_is_list_like():
    # Should be True
    # list
    assert is_list_like([1, 2, 3]) is True
    # reversed()
    assert is_list_like(reversed([1, 2, 4])) is True
    # sorted()
    assert is_list_like(sorted('hello')) is True
    # collections.deque
    assert is_list_like(deque([1, 2, 3])) is True
    # collections.UserList
    assert is_list_like(UserList([1, 2, 3])) is True
    # collections.Iterator
    assert is_list_like(iter([1, 2, 3])) is True
    # collections.KeysView
    assert is_list_like(dict(a=1, b=2).keys()) is True
    # collections.ValuesView
    assert is_

# Generated at 2022-06-21 12:51:48.821082
# Unit test for function has_attrs
def test_has_attrs():
    test_items = [
        # test_item, expected_result
        ('foo', False),
        ('get', True),
        ('keys', True),
        ('items', True),
        ('values', True),
    ]
    for test_item, expected_result in test_items:
        assert (has_attrs(dict(), test_item) == expected_result)



# Generated at 2022-06-21 12:51:53.769470
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), "get", "keys", "items", "values") is True
    assert has_callables("foo", "isalpha") is True
    assert has_callables("123", "isalpha") is False
    assert has_callables("123", "isnumeric") is True


# Generated at 2022-06-21 12:51:57.460291
# Unit test for function has_any_attrs
def test_has_any_attrs():

    assert(has_any_attrs(dict(), 'get','keys','items','values','something') == True)
    assert(has_any_attrs(dict(), 'squonk', 'blonk', 'thingy', 'something') == False)


# Generated at 2022-06-21 12:52:07.358304
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print("Testing has_any_attrs()...", end='')
    class X(object):
        """Test class"""
        def __init__(self, a: int, b: int) -> None:
            self.x = a
            self.y = b
            self.z = a + b
    obj = X(1, 2)
    assert has_any_attrs(obj, 'x', 'y', 'z') is True
    assert has_any_attrs(obj, 'x', 'foo', 'y') is True
    assert has_any_attrs(obj, 'foo', 'bar') is False
    # Unit test for function has_any_callables
    print("Done!")
    print("Testing has_any_callables()...", end='')

# Generated at 2022-06-21 12:52:12.641346
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test function is_subclass_of_any"""
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, dict) is False

# Generated at 2022-06-21 12:52:16.484834
# Unit test for function has_any_callables
def test_has_any_callables():
    class tester:
        def get(self):
            pass
        def keys(self):
            pass
    obj = tester()
    assert has_any_callables(obj, 'get','keys','values','something') is True


# Generated at 2022-06-21 12:52:19.530000
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(), 'keys')


# Generated at 2022-06-21 12:52:25.138960
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    return (
        is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList),
        isinstance(obj.keys(),ValuesView),
        isinstance(obj.keys(),KeysView),
        isinstance(obj.keys(),UserList),
        isinstance(obj.keys(),list)
        )

# Generated at 2022-06-21 12:52:34.348980
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(list, '__len__', '__iter__')
    assert has_attrs(list, '__len__')
    assert not has_attrs(list, '__foobar__')
    assert not has_attrs(list, '__foobar__', '__len__')


# Generated at 2022-06-21 12:52:41.947176
# Unit test for function is_list_like
def test_is_list_like():
    '''
    Takes in an object and determines if it is a subclass of the classes contained in the list _LIST_LIKE.
    :return: Boolean value of True or False
    '''
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True


# Generated at 2022-06-21 12:52:45.768767
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') == True
    assert has_attrs(obj, 'get', 'keys', 'items', 'values', 'foo') == False


# Generated at 2022-06-21 12:52:53.707899
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, object) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, set) == False
    assert is_subclass_of_any(obj, ValuesView, KeysView, object) == False


# Generated at 2022-06-21 12:53:03.010140
# Unit test for function is_list_like
def test_is_list_like():
    from decimal import Decimal
    from dataclasses import dataclass
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    )
    import collections as _collections
    import collections.abc as _collections_abc
    import dataclasses as _dataclasses
    import decimal as _decimal

    assert is_list_like([]) is True, \
        'is_list_like([]) should be True'
    assert is_list_like(()) is True, \
        'is_list_like(()) should be True'
    assert is_list_like(set()) is True, \
        'is_list_like(set()) should be True'

# Generated at 2022-06-21 12:53:07.536386
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(list(), 'append', 'extend', 'remove', 'reverse')
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'foo') is False



# Generated at 2022-06-21 12:53:19.234817
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('hello','join','upper','lower','format') == False
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables([1,2,3],'append','extend','copy','reverse') == True
    assert has_callables(list(),'get','keys','items','values') == False
    assert has_callables(set(),'get','keys','items','values') == False
    assert has_callables(frozenset(),'get','keys','items','values') == False
    assert has_callables(tuple(),'get','keys','items','values') == False
    assert has_callables(deque(),'get','keys','items','values') == False

# Generated at 2022-06-21 12:53:27.418467
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList, ValuesView
    d = dict(a=1,b=2)
    assert has_callables(d,'get','items','keys','values','copy','clear','update','pop','popitem','setdefault','__len__','__class__','__contains__','__eq__','__delitem__','__getitem__','__iter__','__delattr__','__format__','__ge__','__getattribute__','__gt__','__hash__','__init__','__init_subclass__','__le__','__lt__','__ne__','__new__','__reduce__','__reduce_ex__','__repr__','__setattr__','__sizeof__','__str__','__subclasshook__')
    assert has_callables(UserList,[])

# Generated at 2022-06-21 12:53:29.552750
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    assert has_any_callables(dict(),'get','keys','items','values','something') == True



# Generated at 2022-06-21 12:53:32.214719
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:53:45.120611
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs({}, 'get', 'keys') is True


# Generated at 2022-06-21 12:53:47.958997
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:53:50.422731
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-21 12:53:57.502287
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(set())
    assert is_list_like(['a', 'b', 'c'])
    assert is_list_like({'a', 'b', 'c'})
    assert is_list_like(('a', 'b', 'c'))
    assert is_list_like(deque(['a', 'b', 'c']))
    assert is_list_like(iter(('a', 'b', 'c')))
    assert is_list_like(UserList(['a', 'b', 'c']))
    assert is_list_like(ValuesView({'a': 1, 'b': 2, 'c': 3}))
    assert is_list_like(KeysView({'a': 1, 'b': 2, 'c': 3}))

# Generated at 2022-06-21 12:54:03.802753
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs as _has_attrs
    assert _has_attrs(dict(),'keys','items','values','update','get','popitem','clear','copy','fromkeys','setdefault','pop') is True

# Generated at 2022-06-21 12:54:11.783965
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(
        obj.keys(), ValuesView, KeysView, UserList
    ) is True
    assert is_subclass_of_any(
        obj.keys(), KeysView, ValuesView, UserList
    ) is True
    assert is_subclass_of_any(
        'a', ValuesView, KeysView, UserList
    ) is False
    assert is_subclass_of_any(
        obj.keys(), UserList, KeysView, ValuesView
    ) is True

# Generated at 2022-06-21 12:54:14.225008
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True



# Generated at 2022-06-21 12:54:23.234587
# Unit test for function is_list_like
def test_is_list_like():
    # Check list-like objects
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(dict(a='a', b='b', c='c')) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like(sorted('hello')) is True

    # Check non-list-like objects
    assert is_list_like('hello') is False
    assert is_list_like(3) is False
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False



# Generated at 2022-06-21 12:54:25.925541
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-21 12:54:32.063050
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__module__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__init__') is False
    assert has_any_callables(None, 'get', 'keys', 'items', 'values', '__init__') is False