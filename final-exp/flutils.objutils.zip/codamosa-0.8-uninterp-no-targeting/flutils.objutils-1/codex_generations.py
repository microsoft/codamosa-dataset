

# Generated at 2022-06-21 12:45:10.549667
# Unit test for function has_callables
def test_has_callables():
    """
    >>> from flutils.objutils import has_callables
    >>> has_callables(dict, 'get', 'keys', 'values', 'items')
    True
    >>> has_callables(dict, 'get', 'keys', 'values', 'kittens')
    False
    >>> has_callables(dict, 'get', 'keys', 'values', 'items', 'kittens')
    False
    """
    pass


# Generated at 2022-06-21 12:45:15.479239
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_callables(dict(), 'foo', 'bar', 'baz', 'zip') is False



# Generated at 2022-06-21 12:45:22.089504
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like"""

    # pylint:disable=global-statement
    global is_list_like

    from unittest.mock import Mock

    # Test list-like objects
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like(deque([1, 2, 3])) is True
    assert is_list_like(reversed(deque([1, 2, 3]))) is True
    assert is_list

# Generated at 2022-06-21 12:45:26.070289
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'get', 'items', 'values') is True
    assert has_callables(obj, 'get', 'items', 'values', 'foo') is False


# Generated at 2022-06-21 12:45:30.682416
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    obji = dict(a='1', b='2')
    assert not is_subclass_of_any(obji.keys(),UserList)

# Generated at 2022-06-21 12:45:32.415794
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'values', 'items') is True



# Generated at 2022-06-21 12:45:39.332559
# Unit test for function has_callables
def test_has_callables():
    str_obj = 'foo'
    list_obj = [1, 2, 3]
    dict_obj = dict(a=1, b=2)
    assert has_callables(str_obj, 'upper', 'capitalize', 'lower')
    assert has_callables(list_obj, 'append', 'insert', 'sort')
    assert has_callables(dict_obj, 'keys', 'items', 'values')



# Generated at 2022-06-21 12:45:41.677883
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs({}, 'get', 'keys', 'items', 'values', 'something') is True

# Generated at 2022-06-21 12:45:46.337924
# Unit test for function has_any_callables
def test_has_any_callables():
    assert True == has_any_callables(dict(),'get','keys','items','values')
    assert False == has_any_callables(dict(),'foo','foo','foo','foo')
    assert True == has_any_callables(dict(),'foo','get','foo','foo')


# Generated at 2022-06-21 12:45:49.887000
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-21 12:46:02.329214
# Unit test for function has_attrs
def test_has_attrs():
    import flutils.objutils
    d = dict(a=1, b=2)
    l = [1,2,3]
    b = True
    assert flutils.objutils.has_attrs(d, 'get', 'keys', 'items', 'values')
    assert not flutils.objutils.has_attrs(l, 'get', 'keys', 'items', 'values')
    assert not flutils.objutils.has_attrs(b, 'get', 'keys', 'items', 'values')
    assert not flutils.objutils.has_attrs(d, 'good', 'keys', 'items', 'values')


# Generated at 2022-06-21 12:46:13.908424
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    attr = 'keys'
    assert has_any_attrs(obj, attr) is True

    obj = dict(a=1, b=2)
    attrs = 'keys', 'items'
    assert has_any_attrs(obj, *attrs) is True

    obj = dict(a=1, b=2)
    attrs = 'foo', 'bar'
    assert has_any_attrs(obj, *attrs) is False

    obj = dict(a=1, b=2)
    attrs = 'foo', 'bar', 'keys', 'values'
    assert has_any_attrs(obj, *attrs) is True


# Generated at 2022-06-21 12:46:18.719473
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1,b=2,c=3)
    attrs = 'get keys items values'.split()
    assert has_attrs(obj, *attrs) is True

    attrs = 'get something keys'.split()
    assert has_attrs(obj, *attrs) is False


# Generated at 2022-06-21 12:46:26.599687
# Unit test for function has_callables
def test_has_callables():
    import re
    import collections

    def foo():
        pass

    class bar(object):
        def __call__(self):
            pass

    class a(list):
        pass

    class b(dict):
        pass

    class c(object):
        pass

    t = re.search('', '')
    u = collections.OrderedDict()
    v = a()
    assert has_callables(u, 'keys', 'values', 'items', 'foo') is True
    assert has_callables(v, '__setitem__', '__getitem__', '__delitem__') is True
    assert has_callables(t, 'groups', 'foo') is True
    assert has_callables(v, 'foo') is False
    assert has_callables(re, 'foo') is False
    assert has_

# Generated at 2022-06-21 12:46:28.984544
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    result = has_attrs(obj, 'keys', 'items')
    assert result is True
    result = has_attrs(obj, 'foo', 'bar')
    assert result is False
    result = has_attrs(obj, 'get', 'keys')
    assert result is True
    result = has_attrs(None, 'foo', 'bar')
    assert result is False



# Generated at 2022-06-21 12:46:42.048011
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for the function :func:`has_attrs <flutils.objutils.has_attrs>`."""
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict(a=2, b=3),'get','keys')
    assert not has_attrs(dict(a=2, b=3),'something', 'foo')
    # Test case sensitivity
    assert has_attrs(dict(),'get','keys','values','items')
    assert not has_attrs(dict(),'GET','KEYS','VALUES','ITEMS')
    assert has_attrs(dict(a=2, b=3),'__len__')
    assert not has_attrs(dict(a=2, b=3),'len')


# Generated at 2022-06-21 12:46:51.044363
# Unit test for function has_attrs
def test_has_attrs():
    """Test function has_attrs."""
    assert has_attrs(('a', 'b'), '__getitem__', '__len__') is True
    assert has_attrs(('a', 'b'), '__getitem__', '__len__', '__foo__') is False
    assert has_attrs(('a', 'b'), '__getitem__') is True
    assert has_attrs(('a', 'b'), '__foo__') is False
    assert has_attrs(('a', 'b')) is True
    assert has_attrs('hello') is True
    assert has_attrs({'a': 1}) is True
    assert has_attrs(123) is True
    assert has_attrs(frozenset()) is True
    assert has_attrs(None) is True
    assert has

# Generated at 2022-06-21 12:46:58.386163
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import UserDict
    from collections.abc import MutableMapping
    assert has_callables(UserDict, '__setitem__', '__getitem__') == True
    assert has_callables(dict, '__setitem__', '__getitem__') == True
    assert has_callables(MutableMapping, '__setitem__', '__getitem__') == True


# Generated at 2022-06-21 12:47:03.360845
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get','keys','items','values') is False
    assert has_attrs(dict(), 'get','keys','items','values','something') is False
    assert has_attrs(dict(), 'get','keys','items','values','__class__') is True


# Generated at 2022-06-21 12:47:11.736880
# Unit test for function has_any_callables
def test_has_any_callables():
    # given
    from collections import OrderedDict
    from itertools import chain

    # when
    r_1 = has_any_callables(dict(), 'get', 'foo')

    # then
    assert r_1 == True

    # when
    r_2 = has_any_callables(dict(), 'foo', 'bar')

    # then
    assert r_2 == False

    # when
    r_3 = has_any_callables(OrderedDict(a=1), 'keys', 'foo', 'bar')

    # then
    assert r_3 == True

    # when
    r_4 = has_any_callables(OrderedDict(a=1), 'foo', 'bar')

    # then
    assert r_4 == False

    # when
    r_5 = has_any_

# Generated at 2022-06-21 12:47:17.136294
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:47:22.506221
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'get')
    assert has_callables(dict, 'get', 'items')
    assert has_callables(dict, 'get', 'items', 'update')
    assert not has_callables(dict, 'keys', 'values')
    assert not has_callables(dict, 'keys', 'values', '__iter__')



# Generated at 2022-06-21 12:47:32.768023
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    # List-like objects
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like(sorted('hello')) is True
    assert is_list_like({1: 2, 3: 4}) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(deque()) is True
    # Non list-like objects
    assert is_list_like('hello') is False
    assert is_list_like(None) is False
    assert is_list_like(True) is False

# Generated at 2022-06-21 12:47:35.109345
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('hello', 'count', 'index', 'upper') == True
    assert has_callables('hello', 'nonexistent') == False


# Generated at 2022-06-21 12:47:44.970439
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(list(),ValuesView,KeysView,UserList) == False
    assert is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(obj.items(), str, list, ValuesView, KeysView) == False
    assert has_callables(obj.items(), str, list, ValuesView, KeysView) == False
    assert has_callables(obj.keys(), str, list, ValuesView, KeysView) == True

# Generated at 2022-06-21 12:47:46.575170
# Unit test for function has_attrs
def test_has_attrs():
    import requests
    assert has_attrs(requests.sessions.Session, 'get', 'post', 'put')


# Generated at 2022-06-21 12:47:50.989342
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(foo='bar')
    assert has_any_callables(obj, 'foo', 'get', 'bar') is True
    assert has_any_callables(obj, 'foo', 'bar') is False


# Generated at 2022-06-21 12:47:54.895809
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:47:58.779315
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True

# Generated at 2022-06-21 12:48:04.042578
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserList
    assert has_attrs([1,2,3],'append','extend') is True
    assert has_attrs(UserList(),'append','extend','data') is True
    assert has_attrs(dict(a=1,b=2),'keys','items','values','get') is True



# Generated at 2022-06-21 12:48:18.645162
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values')
    assert has_callables(
        dict(a=1, b=2),
        'get',
        'keys',
        'items',
        'values',
        'something',
        '__contains__'
    )
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_callables(
        dict(a=1, b=2),
        'get',
        'keys',
        'items',
        'values',
        'something',
        '__contains__',
        'foo'
    )

# Generated at 2022-06-21 12:48:27.674083
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for the function has_callables in the module flutils.objutils.
    :return:
    """
    assert has_callables(dict, 'get', 'keys', 'items', 'values') is True, (
        "has_callables should be true"
    )
    assert has_callables(dict, 'get', 'keys', 'items', 'values', 'foo') is False, (
        "has_callables should be False"
    )
    assert has_callables(dict, 'get', 'foo', 'items', 'values', 'foo') is False, (
        "has_callables should be False"
    )



# Generated at 2022-06-21 12:48:32.589967
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    assert  is_subclass_of_any(dict(a=1,b=2).keys(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(dict(a=1,b=2).values(),ValuesView,KeysView,UserList)
    

# Generated at 2022-06-21 12:48:39.962933
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

# Generated at 2022-06-21 12:48:51.885677
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(a=1, b=2), 'get', 'foo') == True
    assert has_any_attrs(dict(a=1, b=2), 'get', 'foo', 'bar', 'baz') == True
    assert has_any_attrs(dict(a=1, b=2), 'bar', 'foo', 'baz') == False
    assert has_any_attrs([1, 2, 3], 'append', 'foo', 'bar', 'baz') == True
    assert has_any_attrs([1, 2, 3], 'append', 'foo') == True
    assert has_any_attrs([1, 2, 3], 'bar', 'foo', 'baz') == True

# Generated at 2022-06-21 12:48:56.448874
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    attrs = {
        'get',
        'keys',
        'items',
        'values',
        'novalue',
    }
    assert has_attrs(obj, *attrs) is True



# Generated at 2022-06-21 12:48:59.373431
# Unit test for function has_any_attrs
def test_has_any_attrs():
    o = dict(a=1, b=2)
    assert has_any_attrs(o,'get','keys','items','values','something') is True


# Generated at 2022-06-21 12:49:06.942928
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    import decimal
    obj = dict(a=1, b=2)
    assert is_list_like(obj.keys()) is True
    assert is_list_like(obj.items()) is True
    assert is_list_like(obj.values()) is True
    assert is_list_like(decimal.Decimal(1.1)) is False
    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(True) is False
    assert is_list_like(bytes('', encoding='utf-8')) is False
    assert is_list_like(ChainMap()) is False


# Generated at 2022-06-21 12:49:08.350828
# Unit test for function has_any_attrs
def test_has_any_attrs():
    pass



# Generated at 2022-06-21 12:49:11.266935
# Unit test for function has_callables
def test_has_callables():
    d = dict(a=1, b=2)
    assert has_callables(d, 'get', 'keys', 'values') is True


# Generated at 2022-06-21 12:49:25.599685
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        UserList,
        deque,
        Iterator,
        ValuesView,
        KeysView,
    )

# Generated at 2022-06-21 12:49:32.351901
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True



# Generated at 2022-06-21 12:49:40.293667
# Unit test for function has_any_callables
def test_has_any_callables():
    x = dict()
    attr = "__hello__"
    assert has_any_callables(x, attr) is False
    x.__hello__ = lambda : "hello"
    assert has_any_callables(x, attr) is True
    x = dict()
    assert has_any_callables(x, "__hello__", "__init__") is True
    assert has_any_callables(x, "__hello__", "__foo_bar__") is False


# Generated at 2022-06-21 12:49:47.032443
# Unit test for function has_callables
def test_has_callables():
    from collections import ChainMap
    from flutils.objutils import has_callables

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(ChainMap(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(ChainMap(), 'get', 'keys', 'items') is False
    assert has_callables(ChainMap(), 'newattr', 'keys', 'items') is False

    assert has_callables([], 'append', 'pop', 'extend', 'insert') is True
    assert has_callables([], 'append', 'pop', 'extend') is False
    assert has_callables([], 'newattr', 'pop', 'extend') is False


# Generated at 2022-06-21 12:49:51.985611
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test the function has_any_attrs."""
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'keys', 'values', 'get', 'something') is True
    assert has_any_attrs(obj, 'foo', 'bar') is False



# Generated at 2022-06-21 12:49:55.160317
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')==True
    assert has_callables(dict(),'get','keys','items','values12')==False


# Generated at 2022-06-21 12:50:01.905129
# Unit test for function has_any_callables
def test_has_any_callables():
    # Return `True` if `obj` has any of the given `attrs` and they are callable
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'keys', 'items')
    assert has_any_callables(dict(), 'items')
    assert has_any_callables(dict(), 'foo', 'bar') is False



# Generated at 2022-06-21 12:50:03.497499
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-21 12:50:06.093199
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import OrderedDict
    obj = OrderedDict([('a', 1), ('b', 2)])
    assert has_callables(obj, 'items', 'keys', 'values')


# Generated at 2022-06-21 12:50:19.344795
# Unit test for function has_callables
def test_has_callables():
    """Function to test :func:`has_callables`"""

    # Dictionary
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(
        dict(), 'get', 'keys', 'items', 'values', '__setitem__') is True

    # OrderedDict
    assert has_callables(OrderedDict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(
        OrderedDict(), 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-21 12:50:32.208822
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserList
    from collections.abc import Iterator, ValuesView, KeysView
    from collections import deque, tuple
    from typing import Any

    obj = list()
    assert has_any_attrs(obj, 'clear', 'append', 'appendleft', '__len__', 'foo')

    obj = dict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo')

    obj = set()
    assert has_any_attrs(obj, 'add', 'clear', '__len__', 'foo')

    obj = frozenset()
    assert has_any_attrs(obj, 'add', 'clear', '__len__', 'foo')

    obj = Iterator

# Generated at 2022-06-21 12:50:35.025253
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values') is True
    assert has_any_attrs(dict(),'foo') is False


# Generated at 2022-06-21 12:50:40.380165
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict, 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict, 'get', 'keys', 'items', 'values', 'copy') is True


# Generated at 2022-06-21 12:50:51.573558
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        defaultdict,
        OrderedDict,
        UserDict,
        UserString,
        Counter,
    )
    from decimal import Decimal
    from flutils import objutils
    from hashlib import md5

    assert objutils.is_list_like([1, 2, 3]) is True
    assert objutils.is_list_like(reversed([1, 2, 4])) is True
    assert objutils.is_list_like('hello') is False
    assert objutils.is_list_like(sorted('hello')) is True

    # Test that NOT list like objects return False
    assert objutils.is_list_like(None) is False
    assert objutils.is_list_like(True) is False

# Generated at 2022-06-21 12:50:54.633063
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'keys','values','items') is True
    assert has_callables(dict(),'keys','values','items','foo') is False

assert test_has_callables() is None

# Generated at 2022-06-21 12:51:01.245329
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    expected = True
    result = is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    print("test_is_subclass_of_any: expected '%s', result '%s'" % (expected, result))
    assert expected == result

# Generated at 2022-06-21 12:51:08.172797
# Unit test for function has_callables
def test_has_callables():
    # Check we can test for dict methods
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')

    # Check is positive for any method in the list
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'foo')

    # Check is negative if none of the attributes in the list exist
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'item') is False


# Generated at 2022-06-21 12:51:12.192418
# Unit test for function has_callables
def test_has_callables():
    d = {}
    res = has_callables(d, 'get')
    assert res is False, res

    d['foo'] = lambda x: x
    res = has_callables(d, 'foo')
    assert res is True, res



# Generated at 2022-06-21 12:51:20.540453
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
     )
    from collections.abc import (
        AsyncGenerator,
        Awaitable,
        Coroutine,
        Generator,
        Hashable,
        Iterable,
        Iterator,
        KeysView,
        Mapping,
        MappingView,
        MutableSet,
        Reversible,
        Sequence,
        Set,
        Sized,
        ValuesView,
    )
    from collections.abc import (
        Callable,
        Container,
        Collection,
        Hashable,
        ItemsView,
        MappingView,
        Sequence,
        Set,
    )

    from decimal import Decimal

    mybool = False


# Generated at 2022-06-21 12:51:25.948272
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj.keys(), ValuesView, UserList)

# Generated at 2022-06-21 12:51:36.154899
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True

# Generated at 2022-06-21 12:51:42.854728
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        UserList,
        deque,
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    import decimal
    import datetime
    assert is_list_like([]) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like(deque([1, 2, 3])) is True
    assert is_list_like(dict().keys()) is True
   

# Generated at 2022-06-21 12:51:48.448705
# Unit test for function is_list_like
def test_is_list_like():
    """Test function is_list_like."""
    objTest = dict(a=1, b=2)
    objTest_2 = range(1,10)
    objTest_3 = str()
    objTest_4 = list(range(1,10))
    objTest_5 = str('name')
    objTest_6 = bool(1)
    objTest_7 = dict(a=1, b=2, c=3)
    objTest_8 = dict(a=1, b=2, c=3).values()
    objTest_9 = dict(a=1, b=2, c=3).keys()
    objTest_10 = list('1234567890')
    objTest_11 = tuple(range(1,10))
    objTest_12 = range(1,10)
    objTest_

# Generated at 2022-06-21 12:51:58.960766
# Unit test for function is_list_like
def test_is_list_like():
    assert (
        is_list_like(None),
        is_list_like(False),
        is_list_like(True),
        is_list_like(1),
        is_list_like(0),
        is_list_like(1.1),
        is_list_like(0.0),
        is_list_like(b'foo'),
        is_list_like('foo'),
        is_list_like({'a': 1, 'b': 2}),
        is_list_like([('a', 1), ('b', 2)]),
    ) == (
        False, False, False, False, False, False, False, False, False, False,
        False,
    )

# Generated at 2022-06-21 12:52:03.583697
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like( [ 1, 2, 3 ] )
    assert is_list_like( reversed([ 1, 2, 3 ]) )
    assert not is_list_like( 'hello' )
    assert is_list_like( sorted('hello'))
    return True

# Generated at 2022-06-21 12:52:11.505191
# Unit test for function has_callables
def test_has_callables():
    assert has_callables([1, 2, 3], 'append', 'count', 'extend', 'index')
    assert has_callables((1, 2, 3), 'count', 'index')
    assert has_callables('test', 'split')
    assert has_callables({1, 2, 3}, 'pop', 'add')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(frozenset({1, 2, 3}), 'issubset', 'isdisjoint')
    assert has_callables(deque([1, 2, 3]), 'append', 'count', 'popleft', 'index')
    assert has_callables(sorted([1, 2, 3]), '__next__', '__iter__')

# Generated at 2022-06-21 12:52:14.927404
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-21 12:52:23.984141
# Unit test for function has_attrs
def test_has_attrs():

    from types import MethodType

    class Foo(object):
        def a(self):
            pass

        def b(self):
            pass

    class Bar(Foo):
        def c(self):
            pass

    foo = Foo()
    bar = Bar()
    bar.c = MethodType(bar.c, Foo())

    assert has_attrs(foo, 'a', 'b', 'c') is False
    assert has_attrs(foo, 'a', 'b') is True
    assert has_attrs(bar, 'a', 'b', 'c') is False
    assert has_attrs(bar, 'a', 'b') is True


# Generated at 2022-06-21 12:52:34.941367
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like."""
    import pytest
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal


# Generated at 2022-06-21 12:52:38.189409
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:53:07.036190
# Unit test for function is_list_like
def test_is_list_like():
    '''
    Test the is_list_like function of the objutils module.
    '''

    # Import packages
    import sys
    import unittest
    from collections import (
        UserList,
        deque,
        OrderedDict
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from flutils.objutils import is_list_like

    # Define unit test class
    class IsListLikeTests(unittest.TestCase):
        '''
        Class to test the is_list_like function.
        '''

        def test_is_list_like(
                self: 'IsListLikeTests'
        ) -> None:
            '''
            Test that objects are recognized as list-like.
            '''

            #

# Generated at 2022-06-21 12:53:09.325286
# Unit test for function has_attrs
def test_has_attrs():
   assert True == has_attrs(dict(), 'get', 'keys', 'items', 'values')


# Generated at 2022-06-21 12:53:15.509350
# Unit test for function has_callables
def test_has_callables():
    dictobj = dict(a=1, b=2)
    assert has_callables(dictobj, 'get', 'keys', 'items', 'values')
    assert has_callables(dictobj, 'get', 'keys', 'items')
    assert has_callables(dictobj, 'keys')
    assert not has_callables(dictobj, 'foo')


# Generated at 2022-06-21 12:53:22.221785
# Unit test for function is_list_like
def test_is_list_like():
    list_like = ['a', 'b', 'c']
    iter_like = reversed(list_like)
    sort_like = sorted(list_like)

    assert (is_list_like(list_like) is True)
    assert (is_list_like(iter_like) is True)
    assert (is_list_like(sort_like) is True)

    assert (is_list_like('') is False)
    assert (is_list_like(('a', 'b')) is False)


if __name__ == '__main__':
    test_is_list_like()
    exit()

# Generated at 2022-06-21 12:53:24.624853
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar') == False


# Generated at 2022-06-21 12:53:31.578078
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), *['get', 'keys', 'items', 'values']) is True
    assert has_any_callables(dict(), *['items', 'get', 'keys', 'values']) is True
    assert has_any_callables(dict(), *['keys', 'items', 'get', 'values']) is True
    assert has_any_callables(dict(), *['values', 'keys', 'items', 'get']) is True
    assert has_any_callables(dict(), *['values', 'items', 'keys', 'get']) is True
    assert has_any_callables(dict(), *['get', 'keys', 'items']) is True
    assert has_any_callables(dict(), *['keys', 'items', 'get']) is True

# Generated at 2022-06-21 12:53:34.647620
# Unit test for function has_any_callables
def test_has_any_callables():
    class TestCallables:
        def __init__(self):
            self.has_callable = True

        def non_callable(self):
            return 1

    test_callable = TestCallables()
    assert has_any_callables(test_callable, 'has_callable', 'non_callable')



# Generated at 2022-06-21 12:53:41.558329
# Unit test for function has_any_callables
def test_has_any_callables():
    cls = dict()
    assert(has_any_callables(cls, 'get', 'items', 'keys', 'values', 'update'))
    assert(has_any_callables(cls, 'something'))
    assert(has_any_callables(cls, '__add__'))
    assert(not has_any_callables(cls, 'foobar'))


# Generated at 2022-06-21 12:53:43.442096
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == False


# Generated at 2022-06-21 12:53:53.220149
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import Mapping
    import decimal
