

# Generated at 2022-06-21 12:45:15.220903
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'items', 'values', 'foo', 'bar')


# Generated at 2022-06-21 12:45:19.145458
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1,b=2)
    assert has_any_attrs(obj,'get','keys','values','items') == True
    assert has_any_attrs(obj,'get','keys','values','foo') == True
    assert has_any_attrs(obj,'foo','bar') == False



# Generated at 2022-06-21 12:45:23.584412
# Unit test for function has_callables
def test_has_callables():
    d = dict()
    assert has_callables(d, 'get', 'items') is True
    assert has_callables(d, 'get', 'foo') is False
    assert has_callables(d, '__doc__', 'get', 'items') is False



# Generated at 2022-06-21 12:45:26.966570
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items','values','foo') is False


# Generated at 2022-06-21 12:45:32.651291
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') == False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'something') == False
    assert has_attrs(dict(), 'get', 'keys', 'something') == False
    assert has_attrs(dict(), 'get', 'something') == False
    assert has_attrs(dict(), 'something') == False


# Generated at 2022-06-21 12:45:44.091825
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from os import PathLike
    from collections import deque
    from collections.abc import ValuesView
    assert has_any_attrs(tuple(),'a','b','c') is False
    assert has_any_attrs(tuple(),'count','index') is True
    assert has_any_attrs(ValuesView(dict(a=1,b=2)),'keys','values','c') is True
    assert has_any_attrs(ValuesView(dict(a=1,b=2)),'keys','values','c') is True
    assert has_any_attrs(deque(),'append','extend','count','index') is True
    assert has_any_attrs(PathLike,'is_dir','is_file','stat','open') is True

# Generated at 2022-06-21 12:45:46.789701
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs('hasattr','upper','lower')


# Generated at 2022-06-21 12:45:48.998333
# Unit test for function has_attrs
def test_has_attrs():
    d = dict(a=1, b=2, c=3)
    assert has_attrs(d, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:45:53.964317
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'get', 'keys', 'items', 'values') is True
    assert has_callables(user_dict, 'get', 'keys', 'items', 'values') is False
    assert has_callables(user_dict, 'get', 'keys', 'items', 'values',
                         '__missing__') is True



# Generated at 2022-06-21 12:46:01.235425
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','foo') == False
    assert has_callables(dict(),'foo','keys','items','values') == False
    assert has_callables(dict(),'get','keys','bar','values') == False
    assert has_callables(dict(),'get','keys','items','bar') == False


# Generated at 2022-06-21 12:46:12.273141
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import ChainMap
    def foo():
        pass
    test_dict: ChainMap = ChainMap(
        {'test': True}, {'foo': foo}
    )
    assert has_callables(test_dict, 'foo', 'test')
    assert not has_callables(test_dict, 'test')



# Generated at 2022-06-21 12:46:15.866951
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get','keys','items','values','something') is True
    assert has_any_attrs(dict(), 'something_else') is False


# Generated at 2022-06-21 12:46:17.798317
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict
    d = OrderedDict(
        (
            ('c', 3),
            ('a', 1),
            ('b', 2),
        )
    )
    assert has_any_callables(d, 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-21 12:46:20.358284
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)


# Generated at 2022-06-21 12:46:27.593670
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils.tests.test_objutils import (
        create_unittest_list,
        create_unittest_data,
    )
    # Tests
    test_data = create_unittest_data()
    test_list = create_unittest_list()
    # Test cases
    test_cases = (
        (test_list, True, 'Test list of items'),
        (reversed(test_list), True, 'Test reversed list of items'),
        (sorted(test_list), True, 'Test sorted list of items'),
        (test_data.string_data, False, 'Test string data'),
        (dict(test_data.dict_data), False, 'Test dictionary')
    )
    for test_case in test_cases:
        # Then
        result = is_list

# Generated at 2022-06-21 12:46:39.883374
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserDict
    from flutils.objutils import has_attrs

    # obj is a dictionary
    obj = dict()
    assert has_attrs(obj,'get','keys','values','items') == True

    # obj is a dictionary
    obj = {'a': 1, 'b': 2, 'c': 3}
    assert has_attrs(obj,'get','keys','values','items') == True

    # obj is a UserDict
    obj = UserDict()
    assert has_attrs(obj, 'get', 'keys', 'values', 'items') == True

    # obj is neither a dictionary nor a UserDict
    obj = 'hello'
    assert has_attrs(obj, 'get', 'keys', 'values', 'items') == False

    # obj is neither a dictionary nor a UserDict


# Generated at 2022-06-21 12:46:45.852920
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1)
    result1 = has_any_attrs(obj, 'items', 'get', 'foo', 'keys', 'values')
    assert result1 is True

    result2 = has_any_attrs(obj, 'foo', 'bar', 'baz')
    assert result2 is False


# Generated at 2022-06-21 12:46:48.632479
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1,b=2)
    ret = has_callables(obj,'keys','values','items')
    assert ret is True


# Generated at 2022-06-21 12:46:52.255417
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(dict(), 'something')



# Generated at 2022-06-21 12:46:55.874413
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True

# Generated at 2022-06-21 12:47:07.219906
# Unit test for function is_list_like
def test_is_list_like():
    obj = dict(a=1, b=2)
    # test_with_non_empty_variable
    assert is_list_like(obj.keys())
    # test_with_empty_variable
    assert is_list_like(obj.keys()) is False
    # test_with_non_empty_non_iterable_variable
    assert is_list_like(obj) is False
    # test_with_empty_non_iterable_variable
    assert is_list_like(obj.keys()) is False


# Generated at 2022-06-21 12:47:12.158349
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:47:16.349781
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:47:22.177412
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict, 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict, 'get', 'keys', 'items', 'values') is False

# Generated at 2022-06-21 12:47:31.356496
# Unit test for function has_any_callables
def test_has_any_callables():
    import inspect
    import types
    obj = dict()
    result = has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert result is True
    functions = inspect.getmembers(types, inspect.isbuiltin)
    builtins = [f[0] for f in functions]
    result = has_any_callables(builtins, 'append', 'sort', '__contains__', 'foo')
    assert result is True
    result = has_any_callables(builtins, 'append', 'sort', 'foo', 'bar')
    assert result is False
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:47:41.075992
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_attrs(dict(), 'keys', 'values', 'items', 'foo')
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_attrs(dict(), 'keys', 'values', 'items', 'foo')
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_attrs(dict(), 'keys', 'values', 'items', 'foo')
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False


# Unit test

# Generated at 2022-06-21 12:47:49.681105
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from operator import itemgetter
    import random
    import sqlite3
    import uuid

    list_like = (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
        Decimal,
        float,
        int,
        str,
        bytes,
        list,
        set,
        frozenset,
        tuple,
        deque,
        Iterator,
        ValuesView,
        KeysView,
    )

# Generated at 2022-06-21 12:47:54.131421
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:47:56.684739
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-21 12:48:00.810055
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'keys', 'items', 'values', 'get') is True
    assert has_attrs(str(), 'strip', 'swapcase', 'isalnum', 'len') is True
    assert has_attrs(str(), 'strip', 'swapcase', 'isalnum', 'length') is False



# Generated at 2022-06-21 12:48:18.088105
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for has_attrs

    :returns: 
        :obj:`Tuple[bool, str]`: The result of the test and a message.
    """
    from collections import UserDict
    from flutils.tests.dummy_class import DummyClass

    obj = DummyClass()
    assert has_attrs(obj, 'foo', 'bar', 'baz') == True

    # Check that does not matter about capitalization
    assert has_attrs(obj, 'FOO', 'BAR', 'BAZ') == True

    # Check that it returns False if one of the attributes does not exist
    assert has_attrs(obj, 'foo', 'FOO', 'FOO2') == False

    # Check that it works with normal dicts
    obj = dict()

# Generated at 2022-06-21 12:48:20.845991
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-21 12:48:23.334566
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-21 12:48:31.692270
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    import decimal

    # list-like objects
    assert is_list_like(UserList(['hello', 'world', '!'])) is True
    assert is_list_like(reversed(['hello', 'world', '!'])) is True
    assert is_list_like(iter(['hello', 'world', '!'])) is True
    assert is_list_like(set(['hello', 'world', '!'])) is True
    assert is_list_like(frozenset(['hello', 'world', '!'])) is True
    assert is_list_like(tuple(['hello', 'world', '!']))

# Generated at 2022-06-21 12:48:36.104327
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__iter__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'clear') is True


# Generated at 2022-06-21 12:48:39.191660
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:48:43.531426
# Unit test for function has_attrs
def test_has_attrs():
    mydict = dict(a=1,b=2)
    assert has_attrs(mydict,'get','keys','values')
    assert not has_attrs(mydict,'get','keys','values','something')



# Generated at 2022-06-21 12:48:50.231861
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'something','keys','items','values') == False
    assert has_callables(dict(),'get','something','items','values') == False
    assert has_callables(dict(),'get','keys','something','values') == False
    assert has_callables(dict(),'get','keys','items','something') == False


# Generated at 2022-06-21 12:48:58.693119
# Unit test for function has_attrs
def test_has_attrs():
    assert (has_attrs(dict(),'get','keys','items','values') == True)
    assert (has_attrs('hello','__iter__','__next__','lower','replace') == True)
    assert (has_attrs(1,'hex','real','imag','conjugate','as_integer_ratio') == False)
    assert (has_attrs(1,'hex','real','imag','conjugate','as_integer_ratio', '__format__') == True)


# Generated at 2022-06-21 12:49:06.636507
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from copy import copy
    from collections import ChainMap
    from flutils.objutils import is_subclass_of_any

    # Test for True
    for obj in (
            ChainMap(),
            ChainMap(a=1),
            ChainMap(a=1, b=1),
            ChainMap(a=1, b=1).maps,
            copy(ChainMap(a=1, b=1)),
            copy(ChainMap(a=1, b=1).maps),
            ):
        assert is_subclass_of_any(obj, ChainMap) is True

    # Test for False
    for obj in (
            (),
            {},
            [],
            frozenset(),
            set(),
            dict(),
            ChainMap(a=1, b=1).maps,
            ):
        assert is_subclass

# Generated at 2022-06-21 12:49:24.769412
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables"""
    obj = dict(a=1, b=2)

    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-21 12:49:31.304134
# Unit test for function has_any_callables
def test_has_any_callables():
    assert (has_any_callables(dict(),'get','keys','items','values','foo')) == True
    assert (has_any_callables(dict(),'get','keys','items','values')) == True
    assert (has_any_callables(dict(),'get','foo','values')) == True
    assert (has_any_callables('hello','get','foo')) == False
    assert (has_any_callables(None,'get','foo')) == False
    assert (has_any_callables(sorted('hello'),'get','foo')) == False
    assert (has_any_callables([1,2,3])) == False


# Generated at 2022-06-21 12:49:33.249733
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'values', 'items', 'foo')



# Generated at 2022-06-21 12:49:35.700335
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-21 12:49:39.720061
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    output = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert output is True

# Generated at 2022-06-21 12:49:43.104332
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','foo','items','values') is False
    assert has_callables(dict(),'get','foo','items','something','values') is False
    

# Generated at 2022-06-21 12:49:52.695511
# Unit test for function is_list_like
def test_is_list_like():

    assert(is_list_like([1, 2, 3]) is True)
    assert(is_list_like(reversed([1, 2, 4])) is True)
    assert(is_list_like('hello') is False)
    assert(is_list_like(sorted('hello')) is True)
    assert(is_list_like('hello') is False)
    assert(is_list_like(['hello', 'hi']) is True)
    assert(is_list_like('hello') is False)
    assert(is_list_like(['hello', 'hi']) is True)


# Generated at 2022-06-21 12:49:56.217019
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables

    # Assign
    obj = dict(a=1, b=2)

    # Act
    resp = has_callables(obj.keys(), 'append', 'reverse')

    # Assert
    assert resp is False

# Generated at 2022-06-21 12:49:58.788821
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj,'get','foo') == True
    assert has_any_callables(obj,'foo') == False


# Generated at 2022-06-21 12:50:07.865623
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list())
    assert is_list_like(set())
    assert is_list_like(frozenset())
    assert is_list_like(tuple())
    assert is_list_like(deque())
    assert is_list_like(Iterator(list()))
    assert is_list_like(ValuesView(dict()))
    assert is_list_like(KeysView(dict()))
    assert is_list_like(UserList(list()))

    assert is_list_like(sorted('hello'))
    assert is_list_like(reversed('hello'))
    assert is_list_like(reversed([1, 2, 4]))

    assert not is_list_like(None)
    assert not is_list_like(bool())
    assert not is_

# Generated at 2022-06-21 12:50:47.733308
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from unittest.mock import Mock
    from collections import UserList
    assert is_subclass_of_any(UserList(), list)
    assert is_subclass_of_any(UserList(), list, tuple)
    assert is_subclass_of_any(UserList(), tuple, list)
    assert is_subclass_of_any(UserList(), Mock) is False
    assert is_subclass_of_any(UserList(), tuple, list, Mock)


# Generated at 2022-06-21 12:50:49.400155
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'foo') is False



# Generated at 2022-06-21 12:50:56.337072
# Unit test for function is_list_like

# Generated at 2022-06-21 12:51:02.157139
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')

    class Foo:
        def bar(self):
            return 'Hello World!'

    assert has_callables(Foo(), 'bar')



# Generated at 2022-06-21 12:51:05.823054
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    expected = True
    actual = has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert expected == actual


# Generated at 2022-06-21 12:51:16.362523
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True, "has_any_callables(dict(),'get','keys','items','values','foo') should be True"
    assert has_any_callables([3,2,1], 'append', 'insert', 'remove', 'count') is True, "has_any_callables([3,2,1], 'append', 'insert', 'remove', 'count') should be True"
    assert has_any_callables("my string", "startswith", "find", "strip") is True, "has_any_callables('my string', 'startswith', 'find', 'strip') should be True"

# Generated at 2022-06-21 12:51:18.620960
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(), 'append','append','index','index','index','index','index','index','index','index','index') == True



# Generated at 2022-06-21 12:51:22.135318
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True


# Generated at 2022-06-21 12:51:26.930792
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-21 12:51:30.794269
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('hello', 'upper', 'lower', 'count', 'replace')
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-21 12:52:40.972617
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3]) is True
    assert is_list_like(reversed([1,2,4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-21 12:52:48.905834
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any([], ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.items(), ValuesView, KeysView, UserList) is False

# Generated at 2022-06-21 12:52:52.660324
# Unit test for function has_attrs
def test_has_attrs():
    """Test for the flutils.objutils.has_attrs function."""
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values'),\
        'should return True'


# Generated at 2022-06-21 12:52:55.854758
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(), 'foo') is False
    assert has_callables(dict(), 'get', 'foo') is False


# Generated at 2022-06-21 12:53:00.123578
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'Values')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'Bar')


# Generated at 2022-06-21 12:53:10.907681
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(b'hello') is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
   

# Generated at 2022-06-21 12:53:16.644507
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    if is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList):
        print(True)

if __name__ == "__main__":
    test_is_subclass_of_any()

# Generated at 2022-06-21 12:53:20.141668
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )

    obj = dict(a=1, b=2)

    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:53:22.138936
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-21 12:53:25.568573
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert True == has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')

