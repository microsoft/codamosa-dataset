

# Generated at 2022-06-21 12:45:06.545991
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert all([has_attrs(obj, 'get', 'keys', 'items', 'values')]) is True, (
        'has_attrs() should return True')
    assert all([has_attrs(obj, 'get', 'keys', 'items', 'values', 'foo')]) is (
        False), ('has_attrs() should return False')



# Generated at 2022-06-21 12:45:09.430514
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(list(), 'pop', 'remove', 'combine', 'something') is True


# Generated at 2022-06-21 12:45:19.534281
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from unittest import TestCase

    class TestIsListLike(TestCase):
        EXPECTED = {
            None: False,
            bool: False,
            int: False,
            float: False,
            str: False,
            tuple: True,
            frozenset: True,
            list: True,
            set: True,
            dict: False,
            reversed: True,
            sorted: True,
            object: False,

        }

        def test_is_list_like(self):
            for klass, expected in self.EXPECTED.items():  # type: Any, bool
                with self.subTest(klass=klass, expected=expected):
                    self.assertEqual(is_list_like(klass()), expected)

# Generated at 2022-06-21 12:45:30.489526
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import OrderedDict
    from unittest import TestCase
    from unittest.mock import MagicMock
    from unittest import mock

    class TestClass:
        def __init__(self, data: dict):
            self.data = data

        def foo(self):
            pass

    class TestCase1(TestCase):
        def setUp(self):
            self.data = dict(a=1, b=2)
            self.data2 = dict(x=1, y=2)
            self.pdata = mock.patch(
                'flutils.objutils.has_any_attrs',
                return_value=True).start()

        def tearDown(self):
            mock.patch.stopall()


# Generated at 2022-06-21 12:45:33.112254
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-21 12:45:42.676534
# Unit test for function has_callables
def test_has_callables():
    class HelloWorld:
        def __init__(self):
            self.msg = "Hello world!"

        def reverse_msg(self):
            return self.msg[::-1]

    hw = HelloWorld()
    assert(has_callables(hw, "reverse_msg") is True)

    class Foo:
        def __init__(self):
            self.msg = HelloWorld()

    foo = Foo()
    assert (has_callables(foo, "msg") is False)

    assert(has_callables({"Hello": "World"}, "get") is False)

    assert(has_callables(hw, "msg") is False)

# Generated at 2022-06-21 12:45:49.388415
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        ValuesView,
        KeysView,
    )

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, tuple)

# Generated at 2022-06-21 12:45:54.622143
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get1','keys1','items1','values1','something1') == False
    assert has_any_attrs(UserDict()) == False
    assert has_any_attrs(UserDict(),'data','something') == True


# Generated at 2022-06-21 12:46:02.724881
# Unit test for function is_list_like
def test_is_list_like():
    x = [[], [1], [1, 2, 3], set(), {'a':1}, {'a':1, 'b':2}, tuple(), (1, 2, 3), 1, 'hello', str, type, {}, {}.keys(), {}.values()]
    for item in x:
        if is_list_like(item) is True:
            print('%s is list-like' % item)
        else:
            print('%s is NOT list-like' % item)



# Generated at 2022-06-21 12:46:12.159980
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(obj.__class__, ValuesView, KeysView, UserList) is False


# Generated at 2022-06-21 12:46:19.818965
# Unit test for function has_attrs
def test_has_attrs():
    """ Test flutils.objutils.has_attrs function
    """
    # Test with a list
    objL = [0,1,2]
    assert has_attrs(objL, '__len__', '__getitem__') == True

    # Test with a dict
    objD = dict(a=1)
    assert has_attrs(objD, 'keys', 'items', 'values') == True

    # Test with a string
    objS = "foo"
    assert has_attrs(objS, '__len__', '__getitem__') == True

    # Test with a set
    objI = set()
    assert has_attrs(objI, 'add', 'pop') == True

    # Test with a UserList
    from collections import UserList
    objUL = UserList()
    assert has

# Generated at 2022-06-21 12:46:21.873961
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-21 12:46:23.270228
# Unit test for function has_callables
def test_has_callables(): 
    pass

# Generated at 2022-06-21 12:46:35.928344
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    attrs = ['get', 'keys', 'items', 'values']
    assert has_callables(obj, *attrs) == True  # noqa
    attrs = ['get', '__str__', '__eq__', 'values']
    assert has_callables(obj, *attrs) == True  # noqa
    attrs = ['get', 'keys', 'items', 'height']
    assert has_callables(obj, *attrs) == False  # noqa
    attrs = ['get', 'keys', 'height', 'values']
    assert has_callables(obj, *attrs) == False  # noqa
    attrs = ['get', 'height', 'values', 'items']
    assert has_callables(obj, *attrs) == False  # noqa

# Unit test

# Generated at 2022-06-21 12:46:44.275103
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs([1,2,3],'append','insert','remove','extend','something') is True
    assert has_any_attrs([1,2,3],'get','keys','items','values','something') is False


# Generated at 2022-06-21 12:46:52.240491
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap, Counter, OrderedDict, UserDict, \
        UserString, defaultdict
    from decimal import Decimal
    # list-like
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like('abc') is False
    assert is_list_like(reversed('abc')) is True
    assert is_list_like(sorted('abc')) is True
    assert is_list_like(iter('abc')) is True
    # not list-like
    assert is_list_like(None) is False
    assert is_list

# Generated at 2022-06-21 12:47:04.216099
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        defaultdict,
    )

    from decimal import Decimal

    kls_list = [
        None,
        bool,
        bytes,
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        defaultdict,
        Decimal,
        dict,
        float,
        int,
        list,
        object,
        str,
        tuple,
    ]

    bool_list = [
        True if is_list_like(kls()) is False else False
        for kls in kls_list
    ]

    assert all(bool_list) is True

# Generated at 2022-06-21 12:47:05.989192
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'update')
    #assert has_callables(dict(), 'get', 'keys', 'items', 'update', 'something')



# Generated at 2022-06-21 12:47:17.085429
# Unit test for function is_list_like
def test_is_list_like():
    """

    """
    assert is_list_like([1, 2, 3])

    assert is_list_like(reversed([1, 2, 4]))

    assert is_list_like(sorted([1, 2, 4]))

    assert is_list_like({1, 2, 3})

    assert is_list_like(frozenset([1, 2, 3]))

    assert is_list_like((1, 2, 3))

    assert is_list_like(deque([1, 2, 3]))

    assert is_list_like(dict(a=1, b=2).values())

    assert is_list_like(dict(a=1, b=2).keys())


# Generated at 2022-06-21 12:47:22.068209
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)

    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList))
    assert(not is_subclass_of_any(obj.keys(),list,tuple))


# Generated at 2022-06-21 12:47:33.261645
# Unit test for function is_list_like
def test_is_list_like():
    list1 = [1, 2, 3, 4]
    list2 = [5, 6, 7]
    list3 = [8, 9, 10]
    list4 = [True, False]
    list5 = [None, 1]
    list6 = [10.5, 20.3, 30.4]
    list7 = [1, "a", 20.45, True]
    list8 = [[1, 2, 3], [4, 5, 6]]
    list9 = [[7, 8, 9], [10, 11, 12]]
    list10 = [1.2, 3.4, 5.6]
    assert is_list_like(list1)
    assert is_list_like(list2)
    assert is_list_like(list3)
    assert is_list_like(list4)

# Generated at 2022-06-21 12:47:37.738014
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    try:
        from collections import ValuesView, KeysView, UserList
        obj = dict(a=1, b=2)
        assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True, 'is_subclass_of_any failed'
    except:
        assert False, 'is_subclass_of_any failed'
        pass

# Generated at 2022-06-21 12:47:43.434751
# Unit test for function has_callables
def test_has_callables():
    import inspect
    import collections

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', '__class__') == True

    assert has_callables(inspect, 'getmembers', '__all__', '__builtins__', '__cached__', '__doc__', '__file__', '__loader__', '__name__', '__package__', '__spec__') == True

# Generated at 2022-06-21 12:47:45.198128
# Unit test for function has_attrs
def test_has_attrs():
    # Make sure dict has all the attrs
    assert has_attrs(dict(),'get','keys','items','values')



# Generated at 2022-06-21 12:47:48.295436
# Unit test for function has_any_callables
def test_has_any_callables():
    obj1 = dict()
    assert has_any_callables(obj1, 'get', 'keys', 'items', 'values')
    assert has_any_callables(obj1, 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-21 12:47:52.884462
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'something') is False



# Generated at 2022-06-21 12:48:02.410808
# Unit test for function is_list_like
def test_is_list_like():
    """

    Returns:

    """

    class Iterable(object):
        def __init__(self):
            self.i = 0

        def __next__(self):
            if self.i < 10:
                self.i += 1
                return self.i
            else:
                raise StopIteration

        def __iter__(self):
            return self

    class NonIterable(object):
        pass

    class IterableNoClass(object):
        i = 0
        def __len__(self):
            return self.i

        def __getitem__(self, index):
            return index

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like('hello') is False
   

# Generated at 2022-06-21 12:48:09.750634
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like(()) is True
    assert is_list_like({}) is False
    assert is_list_like('') is False
    assert is_list_like(1) is False
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(dict(a=1).keys()) is True


# Generated at 2022-06-21 12:48:11.739775
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    assert has_attrs(obj, 'keys', 'items', 'values') is True
    assert has_attrs(obj, 'foo', 'bar') is False



# Generated at 2022-06-21 12:48:19.903255
# Unit test for function has_callables
def test_has_callables():
    from collections import Iterator
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict(a=1,b=2),'get','keys','items','values')
    assert has_callables(dict(a=1,b=2).items(),'count','index','append','remove')
    assert has_callables(dict(a=1,b=2).values(),'count','index','append','remove')
    assert has_callables(sorted('hello'),'count','index','append','remove')
    assert has_callables(reversed('hello'),'count','index','append','remove')
    assert has_callables(reversed(['a','b','c','d','e']),'count','index','append','remove')

# Generated at 2022-06-21 12:48:25.801922
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo')
    assert (has_any_attrs(dict(),'foo') is False)



# Generated at 2022-06-21 12:48:31.306844
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), UserList) is False



# Generated at 2022-06-21 12:48:33.778464
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    result = has_callables(obj, 'keys', 'values')
    print(result)



# Generated at 2022-06-21 12:48:39.101980
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') != False
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is not False


# Generated at 2022-06-21 12:48:42.370905
# Unit test for function has_callables
def test_has_callables():
    obj = {'somekey': 'somevalue'}
    assert has_callables(obj, 'get', 'keys', 'values') == True



# Generated at 2022-06-21 12:48:46.753572
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables()."""
    dct = {'a': 1, 'b': 2, 'c': 3}
    assert has_any_callables(dct, 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-21 12:48:52.132251
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any('test', str)
    assert not is_subclass_of_any('test', str, float, int)

# Generated at 2022-06-21 12:49:03.530690
# Unit test for function has_callables
def test_has_callables():
    import unittest
    from unittest import mock

    # mock.MagicMock
    class foo(object):
        pass

    obj = foo()
    obj.bar = 4
    obj.baz = mock.MagicMock()

    assert has_callables(obj, 'bar', 'baz') is False
    assert has_callables(obj, 'bar', 'baz', 'another_bar') is False

    # callable
    obj = foo()

    def bar(*args, **kwargs):
        pass

    obj.bar = bar
    obj.baz = mock.MagicMock()

    assert has_callables(obj, 'bar', 'baz') is True
    assert has_callables(obj, 'bar', 'baz', 'another_bar') is False

    # class method
    obj = foo()

# Generated at 2022-06-21 12:49:06.167890
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-21 12:49:17.564260
# Unit test for function has_callables
def test_has_callables():
    """
    Tests for the ``has_callables`` function.
    """
    import pytest

    from flutils.objutils import has_callables

    def class_with_keys():
        class MyClass:
            def keys(self):
                return dict().keys()

        return MyClass

    def class_without_keys():
        class MyClass:
            def keys(self):
                return dict().keys

        return MyClass

    # Test that Object class doesn't pass
    assert has_callables(object, 'keys') is False

    # Test that object with callable 'keys' passes
    assert has_callables(dict, 'keys') is True

    # Test that object with callable 'keys', un-callable 'values' fails
    assert has_callables(dict, 'keys', 'values') is False

    # Test that

# Generated at 2022-06-21 12:49:25.105464
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    assert has_attrs(obj, "get", "keys", "items", "values") is True



# Generated at 2022-06-21 12:49:28.814162
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like('abc') is False
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(dict(a=1, b=2).keys()) is True
    assert is_list_like(dict(a=1, b=2).values()) is True

# Generated at 2022-06-21 12:49:32.778734
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView)


# Generated at 2022-06-21 12:49:36.925206
# Unit test for function is_list_like
def test_is_list_like():
    try:
        assert is_list_like(iterator.__next__)
        assert is_list_like(dict())
        print("is_list_like passed")
    except:
        print("is_list_like failed")


# Generated at 2022-06-21 12:49:40.033690
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap
    from decimal import Decimal
    for obj in (None, ChainMap(), Decimal()):
        assert is_list_like(obj) is False

# Generated at 2022-06-21 12:49:52.157616
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(tuple()) is True
    assert is_list_like([]) is True
    assert is_list_like(list()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(dict().keys()) is True
    assert is_list_like(dict().values()) is True
    assert is_list_like(reversed('flutils')) is True
    assert is_list_like(sorted('flutils')) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(UserList()) is True
    assert is_list_like(None) is False

# Generated at 2022-06-21 12:50:00.446571
# Unit test for function has_attrs
def test_has_attrs():
    # Setup
    print("Testing function has_attrs")
    # Exercise
    print("Checking dict has 'get', 'keys', and 'values'")
    obj = dict()
    result = has_attrs(obj, 'get', 'keys', 'values')
    # Verify
    assert True == result
    # Cleanup - none necessary
    # Exercise
    print("Checking dict has 'get', 'keys', 'values', and 'foo'")
    result = has_attrs(obj, 'get', 'keys', 'values', 'foo')
    # Verify
    assert False == result
    # Cleanup - none necessary
    # Teardown
    print("Finished testing function has_attrs")



# Generated at 2022-06-21 12:50:04.243794
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'something','else','foo','bar')
    assert not has_attrs(dict(a=1,b=2,c=3),'something','else','foo','bar')



# Generated at 2022-06-21 12:50:11.269554
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserList
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'get','keys','items','values') is True
    assert has_any_attrs(dict(),'get','keys') is True
    assert has_any_attrs(dict(),'values') is True
    assert has_any_attrs([], 'append') is True
    assert has_any_attrs(UserList(), 'append') is True
    assert has_any_attrs(0, 'bit_length') is True
    assert has_any_attrs('', 'find') is True
    assert has_any_attrs((), 'index') is True
    assert has_any_attrs({}, 'update') is True
    assert has_any_att

# Generated at 2022-06-21 12:50:20.584788
# Unit test for function is_list_like
def test_is_list_like():
    print(is_list_like([1, 2, 3]))
    print(is_list_like({1, 2, 3}))
    print(is_list_like(set([1,2])))
    print(is_list_like(deque([1,2,3])))
    print(is_list_like(dict(a=1,b=2)))
    print(is_list_like('hello'))
    print(is_list_like(sorted('hello')))


# Generated at 2022-06-21 12:50:44.454546
# Unit test for function is_list_like
def test_is_list_like():
    #List-like objects
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like(sorted('hello')) is True

    class MyList(list):
        pass

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(MyList([1, 2, 4])) is True
    assert is_list_like('hello') is False

    # Not List-like objects
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(1) is False
    assert is_list_like(1.1) is False

# Generated at 2022-06-21 12:50:46.698541
# Unit test for function has_attrs
def test_has_attrs():
    assert(has_attrs(dict(),'get','keys','items','values'))


# Generated at 2022-06-21 12:50:49.462525
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys') is True
    assert has_any_callables(dict(), 'get', 'foo') is True



# Generated at 2022-06-21 12:50:50.809092
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:51:02.757385
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'keys','items','values') == True
    assert has_any_attrs(dict(),'get','keys','items') == True
    assert has_any_attrs(dict(),'get','items','values') == True
    assert has_any_attrs(dict(),'get','keys','values') == True
    assert has_any_attrs(dict(),'get','keys') == True
    assert has_any_attrs(dict(),'keys','items') == True
    assert has_any_attrs(dict(),'items','values') == True
    assert has_any_attrs(dict(),'get','items') == True

# Generated at 2022-06-21 12:51:09.664738
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(None, ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(0, ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(0.0, ValuesView, KeysView, UserList)


# Generated at 2022-06-21 12:51:11.567200
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values') \
        == True


# Generated at 2022-06-21 12:51:15.056842
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert (is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True)


# Generated at 2022-06-21 12:51:20.229556
# Unit test for function is_list_like
def test_is_list_like():
	# Test with a True test
	assert is_list_like([1,2,3]) == True
	# Test with a False test
	assert is_list_like("hello") == False
	# Test with a True test
	assert is_list_like(sorted([1,2,3])) == True
	# Test with a True test
	assert is_list_like(reversed([1,2,3])) == True



# Generated at 2022-06-21 12:51:30.538274
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like(set({'a': 1, 'b': 2})) is True
    assert is_list_like(frozenset({'a': 1, 'b': 2})) is True
    assert is_list_like(range(0, 3)) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(dict(a=1, b=2)) is True
    assert is_list_like(None) is False


# Generated at 2022-06-21 12:52:06.158218
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True

# Generated at 2022-06-21 12:52:12.898939
# Unit test for function has_attrs
def test_has_attrs():
    class HasAttrs(object):

        def __init__(self):
            self.a = 'a'
            self.b = 2
            self.c = [1, 2, 3]

        def foo(self):
            return 'foo'

    class NoAttrs(object):
        pass

    class HasAttrsButNoValues(object):
        a = None
        b = None
        c = None

        def foo(self):
            pass

    class SuperDuper(HasAttrs, HasAttrsButNoValues, NoAttrs):
        pass

    assert has_attrs(
        HasAttrs(),
        'a', 'b', 'c', 'foo'
    ) is True
    assert has_attrs(
        NoAttrs(),
        'a', 'b', 'c'
    ) is False

# Generated at 2022-06-21 12:52:24.088320
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from decimal import Decimal

    assert(is_list_like([]) is True)
    assert(is_list_like(()) is True)
    assert(is_list_like({}) is False)
    assert(is_list_like(set()) is True)
    assert(is_list_like('hello') is False)
    assert(is_list_like(0) is False)
    assert(is_list_like(0.0) is False)
    assert(is_list_like(Decimal()) is False)
    assert(is_list_like((x for x in range(10))) is True)
    assert(is_list_like(enumerate('hello')) is True)
    assert(is_list_like(iter('hello')) is True)

# Generated at 2022-06-21 12:52:35.012083
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables

    # Check the bool object
    assert has_callables(True, 'capitalize', '__str__') is False
    assert has_callables(False, 'capitalize', '__str__') is False
    # Check the string object
    assert has_callables('hello', 'capitalize', 'isalnum') is True
    # Check the dict object
    assert has_callables(dict(), 'get', 'copy') is True
    # Check the list object
    assert has_callables([], 'sort', '__str__') is False
    # Check the set object
    assert has_callables(set(), 'is_subset', '__str__') is False
    # Check the tuple object
    assert has_callables(tuple(), 'count', '__str__') is False
   

# Generated at 2022-06-21 12:52:46.915438
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(True,'get','keys','items','values','foo') == False
    assert has_any_callables(22,'get','keys','items','values','foo') == False
    assert has_any_callables(33.3,'get','keys','items','values','foo') == False
    assert has_any_callables(dict().keys(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict().values(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict().items(),'get','keys','items','values','foo') == True

# Generated at 2022-06-21 12:52:51.101954
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)



# Generated at 2022-06-21 12:53:01.324601
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables

# Generated at 2022-06-21 12:53:04.700734
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-21 12:53:08.128379
# Unit test for function has_callables
def test_has_callables():
  print("Testcase 1:")
  assert has_callables({},"get","keys","items","values") is True
  print("Testcase 2:")
  assert has_callables([],"get","keys","items","values") is False

# Generated at 2022-06-21 12:53:18.378593
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    import unittest

    class TestIsSubclassOfAny(unittest.TestCase):

        def test_is_subclass(self):

            from collections import ValuesView, KeysView, UserList

            obj = dict(a=1, b=2)
            self.assertTrue(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList))

        def test_not_subclass(self):

            from collections import ValuesView, KeysView, UserList

            obj = dict(a=1, b=2)
            self.assertFalse(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList,list))