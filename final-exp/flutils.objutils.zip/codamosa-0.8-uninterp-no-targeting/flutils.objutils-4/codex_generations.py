

# Generated at 2022-06-21 12:45:12.385203
# Unit test for function has_any_attrs
def test_has_any_attrs():
    testcases = [
        {'expected': True,  'given': (dict(), 'get', 'keys', 'items', 'values', 'something')},
        {'expected': False, 'given': (dict(), 'something1', 'something2', 'something3', 'something4', 'something5')},
        {'expected': False, 'given': (None, 'something1', 'something2', 'something3', 'something4', 'something5')}
    ]

    for testcase in testcases:
        assert has_any_attrs(*testcase['given']) == testcase['expected']


# Generated at 2022-06-21 12:45:14.701130
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values')



# Generated at 2022-06-21 12:45:16.628770
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-21 12:45:19.488974
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get')
    assert has_any_callables(dict(),'get','get')
    assert not has_any_callables(dict(),'foo')


# Generated at 2022-06-21 12:45:30.489650
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    test_data = dict()
    test_data['list'] = [1, 2, 3, 4]
    test_data['dict'] = dict(a=1, b=2, c=3, d=4)
    test_data['tuple'] = (1, 2, 3, 4)
    test_data['str'] = "John"
    test_data['int'] = 12345
    test_data['float'] = 1.2345
    test_data['bool'] = True
    for name, obj in test_data.items():
        print("  Testing object: {obj}".format(obj=name))
        # Test it has the callables in the list
        callables = ['copy']

# Generated at 2022-06-21 12:45:33.353079
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like('hello') is False
    assert is_list_like(sorted([1, 2, 3, 4]))


# Generated at 2022-06-21 12:45:38.548016
# Unit test for function has_attrs
def test_has_attrs():
    """
    Test function has_attrs
    """
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'keys','foo') is False
    assert has_attrs(dict(),'foo','bar') is False


# Generated at 2022-06-21 12:45:45.943712
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-21 12:45:51.361322
# Unit test for function has_attrs
def test_has_attrs():
    class Foo:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    obj = Foo()
    assert has_attrs(obj, 'a', 'b', 'c') is True
    assert has_attrs(obj, 'a', 'b', 'd') is False


# Generated at 2022-06-21 12:45:56.198616
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList
    obj = UserList()
    obj.append(1)
    assert has_callables(obj, 'append')
    assert not has_callables(obj, 'foo')
    assert not has_callables(obj, 'foo', 'append')


# Generated at 2022-06-21 12:46:07.020926
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    d = dict(a=1, b=2, c=3)
    assert has_callables(d, 'get', 'keys', 'values', 'items') == True
    assert has_callables(d, 'get') == True
    assert has_callables(d, 'keys') == True
    assert has_callables(d, 'values') == True
    assert has_callables(d, 'items') == True
    assert has_callables(d, 'foo') == False


# Generated at 2022-06-21 12:46:12.105373
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something')
    assert not has_any_callables(dict(),'something','another','and','more')
    assert has_any_callables(dict(),'get','something','more')

# Generated at 2022-06-21 12:46:20.771466
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys') is True
    assert has_any_callables(dict(), 'get', 'keys', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_callables((1, 2, 3), '__contains__', '__getitem__') is True
    assert has_any_callables((1, 2, 3), '__contains__', 'foo') is True
    assert has_any_callables((1, 2, 3), 'foo', 'bar') is False


# Generated at 2022-06-21 12:46:26.001773
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    result = has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert result is True


# Generated at 2022-06-21 12:46:38.579805
# Unit test for function has_attrs
def test_has_attrs():
    # Create dict
    dict_object = dict(a=1, b=2)
    # Tests for dict
    assert has_attrs(dict_object, 'pop', 'popitem', 'setdefault') is True
    assert has_attrs(dict_object, 'pop', 'popitem', 'setdefault', 'foo') is False
    # Create bytearray
    bytearray_object = bytearray(b'abcde')
    # Tests for bytearray
    assert has_attrs(bytearray_object, 'index', 'rindex', 'decode') is True
    assert has_attrs(bytearray_object, 'index', 'rindex', 'decode', 'foo') is False
    # Create set
    set_object = set(bytearray_object)
    # Tests for

# Generated at 2022-06-21 12:46:49.607385
# Unit test for function is_list_like
def test_is_list_like():
    import pytest
    # Test values
    none = None
    false = False
    true = True
    empty_str = ''
    hello = 'hello'
    empty_bytes = bytes()
    non_empty_bytes = bytes(hello, 'utf-8')
    empty_list = []
    non_empty_list = [False, True, 1, 1.2, 'hi', hello]
    empty_tuple = ()
    non_empty_tuple = (False, True, 1, 1.2, 'hi', hello)
    empty_set = set()
    non_empty_set = {False, True, 1, 1.2, 'hi', hello}
    empty_frozenset = frozenset()

# Generated at 2022-06-21 12:46:51.828677
# Unit test for function has_any_attrs
def test_has_any_attrs():
   assert(has_any_attrs(dict(),'get','keys','items','values','something')==True)

# Generated at 2022-06-21 12:47:04.216261
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    d = {'a': 1}
    assert is_list_like(d.keys()) is True
    assert is_list_like(d.items()) is True
    assert is_list_like(d.values()) is True
    assert is_list_like(Counter({'a': 1})) is True
    assert is_list_like(list()) is True
    assert is_list_like(dict()) is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False

# Generated at 2022-06-21 12:47:06.890204
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'foo', 'bar', 'baz') is False
    assert has_callables(obj, 'foo') is False



# Generated at 2022-06-21 12:47:11.994178
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    object_string = "hello world"
    object_dict = {}

    assert(has_callables(object_string, "upper", "lower") == True)
    assert(has_callables(object_dict, "update", "values") == True)

# Generated at 2022-06-21 12:47:25.590764
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables({}, 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(name='Albert'), 'get', 'pizza') is True
    assert has_any_callables(dict(name='Albert'), 'get', 'bacon') is False



# Generated at 2022-06-21 12:47:34.847117
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Tests for has_any_attrs."""
    from pytest import raises

    # No args
    with raises(TypeError):
        assert has_any_attrs()

    # No args
    with raises(TypeError):
        assert has_any_attrs(1)

    # Minimum callable
    valid_result = has_any_attrs(dict(), 'get')
    assert valid_result is True

    valid_result = has_any_attrs(1, 'to_bytes')
    assert valid_result is False

    valid_result = has_any_attrs(1, *['to_bytes'])
    assert valid_result is False

    valid_result = has_any_attrs(dict(), *['get', 'keys', 'foo'])
    assert valid_result is True

    valid_result = has

# Generated at 2022-06-21 12:47:44.710754
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import Mapping
    # Test against an object that isn't an instance of a class
    assert is_subclass_of_any(1, list, dict, Mapping) is False
    # Test with a class that isn't a subclass of the given classes
    assert is_subclass_of_any(list(), Mapping, dict) is True
    assert is_subclass_of_any(list(), dict) is False
    # Test with a class that is a subclass of the given classes
    assert is_subclass_of_any(dict(), Mapping, dict) is True
    # Test with a class that is a subclass of the given classes but not one
    # that makes sense
    assert is_subclass_of_any(dict(), list, dict) is True
    # Test with an object that is an instance of a class that is a subclass of


# Generated at 2022-06-21 12:47:48.104036
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-21 12:48:00.114013
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.collectionsutils import munchify


    class Foo:
        def __init__(self):
            self.a = 5
            self.b = 6
            self.c = 7
            self.d = 8


    class Bar:
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4


    foo = Foo()
    bar = Bar()

    assert has_attrs(foo, 'a', 'b', 'c', 'd')
    assert has_attrs(bar, 'a', 'b', 'c', 'd')
    assert has_attrs(munchify(foo), 'a', 'b', 'c', 'd')

# Generated at 2022-06-21 12:48:10.961848
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import has_any_attrs
    assert has_any_attrs({}, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs({}, 'a', 'b', 'c', 'd', 'e') is False
    assert has_any_attrs(set(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(set(), 'a', 'b', 'c', 'd', 'e') is True
    assert has_any_attrs(list(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(list(), 'a', 'b', 'c', 'd', 'e') is True

# Generated at 2022-06-21 12:48:17.591903
# Unit test for function has_any_callables
def test_has_any_callables():
    class Dummy:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    o = Dummy(1, 2)

    assert has_any_callables(o, 'a', 'b') == False
    assert has_any_callables(o, 'a', 'b', '__hash__') == True
    assert has_any_callables(o, 'a', 'b', '__repr__') == True

if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-21 12:48:20.370370
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:48:21.599322
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'foo') == False


# Generated at 2022-06-21 12:48:25.239409
# Unit test for function has_any_attrs
def test_has_any_attrs():
    '''Test function has_any_attrs
    '''
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'something')


# Generated at 2022-06-21 12:48:35.885197
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    obj.get = lambda: ''
    obj.keys = lambda: ''
    assert has_any_attrs(obj, "get", "keys", "items") is True

    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, "get", "keys", "items") is False



# Generated at 2022-06-21 12:48:47.390923
# Unit test for function has_callables
def test_has_callables():
    '''Test for function has_callables'''
    from flutils.objutils import has_callables
    from collections import ChainMap, Counter, OrderedDict, UserDict, UserString, defaultdict
    from decimal import Decimal
    import json
    import math
    import sys

    # Test misc built-in types.
    assert has_callables(None) is False
    assert has_callables(False) is False
    assert has_callables(True) is False
    assert has_callables(b'foo') is False
    assert has_callables(bytes()) is False
    assert has_callables(bytes('foo')) is False
    assert has_callables(ChainMap({'a': 1})) is False
    assert has_callables(Counter()) is False

# Generated at 2022-06-21 12:48:56.566098
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), ['get', 'keys', 'items', 'values']) is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values',
                         'something') is False
    assert has_callables(dict(), '__len__', '__iter__', '__contains__',
                         '__getitem__') is True
    assert has_callables(dict(), '__len__', '__iter__', '__contains__',
                         '__getitem__', '__setitem__') is True
    assert has_callables(dict(), dict(), '__iter__', '__contains__',
                         '__getitem__', '__setitem__', '__missing__') is False

# Generated at 2022-06-21 12:48:59.939792
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView
    from typing import Any
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView)



# Generated at 2022-06-21 12:49:02.135025
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:49:14.015153
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict().values(),'get','keys','items','values','foo')
    assert has_any_callables(dict().keys(),'get','keys','items','values','foo')
    assert has_any_callables(dict().items(),'get','keys','items','values','foo')
    assert not has_any_callables(dict(),'foo')
    assert not has_any_callables(dict().values(),'foo')
    assert not has_any_callables(dict().keys(),'foo')
    assert not has_any_callables(dict().items(),'foo')
    assert not has_any_callables(dict(),'__subclasshook__')

# Generated at 2022-06-21 12:49:18.367576
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert not has_any_callables('', 'lower', 'upper', 'capitalize')


# Generated at 2022-06-21 12:49:22.223541
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        deque,
        Iterator,
        KeysView,
        ValuesView
    )

    test_obj = dict(a=1, b=2)
    test_obj_keys = test_obj.keys()
    test_obj_val = test_obj.values()
    test_obj_item = test_obj.items()

    assert is_subclass_of_any(test_obj_keys, ValuesView, KeysView, UserList) == True


# Generated at 2022-06-21 12:49:24.657163
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'get', 'items', 'keys', 'values') == True



# Generated at 2022-06-21 12:49:32.571376
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    import decimal
    import inspect
    import operator
    import sys

    # List-like instances
    import_error = list()
    list_like_instances = (
        collections.UserList,
        collections.abc.Iterator,
        collections.abc.KeysView,
        collections.abc.ValuesView,
        collections.deque,
        frozenset,
        list,
        set,
        tuple,
        reversed([1, 2, 3]),
        sorted('hello'),
    )
    for instance in list_like_instances:
        try:
            assert is_list_like(instance) is True
        except ImportError as err:
            import_error.append({
                'instance': instance,
                'err': err
            })

    # List-like subclasses

# Generated at 2022-06-21 12:49:50.920860
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items', '__init__') == True
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items', 'update') == True
    assert has_any_callables(str(), 'get', 'keys', 'values', 'items', 'foo') == False


# Generated at 2022-06-21 12:50:00.559005
# Unit test for function is_list_like
def test_is_list_like():
    # don't put 'from collections import UserList, Iterator, ValuesView, KeysView, deque' in __all__
    # NOTE: should leave as `is_list_like`
    print('\nis_list_like:')
    from collections import UserList, Iterator, ValuesView, KeysView, deque, ChainMap, UserDict, UserString, \
        defaultdict, OrderedDict, Counter
    lst = [1, 2, 3, 4]
    assert is_list_like(lst), "{} is list like".format(lst)
    assert not is_list_like(None), "None is not list like"
    assert not is_list_like(True), "bool is not list like"
    assert not is_list_like(b''), "bytes is not list like"
    assert not is_list

# Generated at 2022-06-21 12:50:02.241493
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-21 12:50:10.127717
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    from collections import OrderedDict
    from collections.abc import Hashable, KeysView
    from flutils.objutils import get_instance_name
    from flutils.objutils import is_subclass_of_any

    for cls in [
        dict,
        OrderedDict,
        Hashable,
        KeysView,
        object,
        object,
        object,
    ]:
        obj = cls()
        func_name = get_instance_name(obj)
        assert has_any_callables(obj, func_name) is True
        assert has_any_callables(obj, func_name, 'pop', 'popitem') is True
        assert has_any_callables(obj, 'pop', 'popitem') is False

    # Ensure class is not an issue.
    assert has

# Generated at 2022-06-21 12:50:13.536585
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'foo') == False



# Generated at 2022-06-21 12:50:26.040757
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class TestClass:
        foo = None
        bar = None
        baz = None

    obj = TestClass()

    assert has_any_attrs(obj, 'foo') is True
    assert has_any_attrs(obj, 'foo', 'bar') is True
    assert has_any_attrs(obj, 'foo', 'bar', 'baz') is True
    assert has_any_attrs(obj, 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_attrs(obj, 'bar', 'baz', 'qux') is True
    assert has_any_attrs(obj, 'baz', 'qux') is True
    assert has_any_attrs(obj, 'qux') is False

# Generated at 2022-06-21 12:50:28.388261
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-21 12:50:32.253544
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict

    test_result = has_any_callables(
        OrderedDict(),
        'setdefault',
        'clear',
        'items',
        'values',
        'something',
    )
    assert test_result is True



# Generated at 2022-06-21 12:50:35.929751
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-21 12:50:39.503239
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    attrs = ('get', 'keys', 'items', 'values', 'update', 'foobar')
    assert has_attrs(obj, *attrs) is True
