

# Generated at 2022-06-21 12:45:06.110644
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    assert has_attrs(obj,'get','keys','items','values') is True


# Generated at 2022-06-21 12:45:11.531187
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(zip(range(4), range(4)))

    func = has_any_attrs
    exp = True
    res = func(obj, 'get', 'keys', 'items', 'values', 'something')
    assert exp == res, 'Expected: {}; Result: {}'.format(exp, res)


# Generated at 2022-06-21 12:45:13.693084
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1], 'append', 'something') == False


# Generated at 2022-06-21 12:45:15.825209
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')


# Generated at 2022-06-21 12:45:26.468516
# Unit test for function is_list_like
def test_is_list_like():

    # Example 1:
    obj = dict(a=1, b=2)
    actual = is_list_like(obj.keys())
    expected = True
    assert actual == expected

    # Example 2:
    obj = dict(a=1, b=2)
    actual = is_list_like(obj.values())
    expected = True
    assert actual == expected

    # Example 3:
    obj = dict(a=1, b=2)
    actual = is_list_like(sorted(obj.values()))
    expected = True
    assert actual == expected

    # Example 4:
    obj = dict(a=1, b=2)
    actual = is_list_like(obj.items())
    expected = True
    assert actual == expected

    # Example 5:

# Generated at 2022-06-21 12:45:28.802520
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'something','another','call',)


# Generated at 2022-06-21 12:45:35.636343
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(), 'foo', 'bar', 'baz', 'qux')
    obj = dict(a=1, b=2, c=3)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values')
    assert not has_attrs(obj, 'foo', 'bar', 'baz', 'qux')


# Generated at 2022-06-21 12:45:45.726007
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(1) is False
    assert is_list_like(1.0) is False
    assert is_list_like('') is False
    assert is_list_like(()) is True
    assert is_list_like(reversed('')) is True
    assert is_list_like(sorted('')) is True
    assert is_list_like([1,2,3,4]) is True
    assert is_list_like([]) is True
    assert is_list_like(set([1,2,3,4])) is True
    assert is_list_like(deque([1,2,3,4])) is True
    assert is_list_like(dict({'a':1,'b':2})) is True
    assert is_list_like(dict().keys()) is True

# Generated at 2022-06-21 12:45:55.462415
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView) is True
    assert is_subclass_of_any(obj.keys(), ValuesView) is False
    assert is_subclass_of_any(obj.keys(), UserList) is False
    assert is_subclass_of_any(obj.values(), ValuesView) is True
    assert is_subclass_of_any(obj.values(), UserList) is False
    assert is_subclass_of_any(obj.values(), KeysView) is False
    assert is_sub

# Generated at 2022-06-21 12:45:59.710120
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'keys') is True
    assert has_attrs(dict(), 'foo') is False
    assert has_attrs(dict(), 'keys', 'foo') is False



# Generated at 2022-06-21 12:46:17.064588
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any(dict(a=1, b=2).keys(), ValuesView, KeysView, UserList) is True, \
        "When obj is an instance of {}, expected True, got {}"\
        .format(repr(ValuesView), is_subclass_of_any(dict(a=1, b=2).keys(), ValuesView, KeysView, UserList))

# Generated at 2022-06-21 12:46:28.312036
# Unit test for function has_any_callables

# Generated at 2022-06-21 12:46:41.465609
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class Tester(object):
        pass

    t = Tester()
    assert has_any_attrs(t, 'foo', 'bar') is False
    t.foo = None
    assert has_any_attrs(t, 'foo', 'bar') is True
    t.bar = None
    assert has_any_attrs(t, 'foo', 'bar') is True

    t2 = dict()
    assert has_any_attrs(t2, 'foo', 'bar') is False
    t2['foo'] = None
    assert has_any_attrs(t2, 'foo', 'bar') is True
    t2['bar'] = None
    assert has_any_attrs(t2, 'foo', 'bar') is True

# Generated at 2022-06-21 12:46:45.326517
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like(sorted('hello'))
    assert not is_list_like('hello')

# Generated at 2022-06-21 12:46:48.927983
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)


# Generated at 2022-06-21 12:47:00.159070
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    # Test for bad input
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_callables(None, 'get', 'keys', 'items', 'values')
    assert not has_callables(str(), 'get', 'keys', 'items', 'values')
    assert not has_callables(int(), 'get', 'keys', 'items', 'values')
    assert not has_callables(float(), 'get', 'keys', 'items', 'values')
    assert not has_callables(bool(), 'get', 'keys', 'items', 'values')

# Generated at 2022-06-21 12:47:09.840585
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(True) is False
    from collections import (UserList,
                             ValuesView,
                             KeysView,
                             Iterator)
    assert is_list_like(UserList(['a', 'b'])) is True
    assert is_list_like(ValuesView(dict(a=1, b=2))) is True
    assert is_list_like(KeysView(dict(a=1, b=2))) is True
    assert is_list_like(Iterator(['a', 'b'])) is True
    assert is_list_like([1, 2, 3, 4]) is True
    assert is_list_like(list(range(100, 1000))) is True
    assert is_list_

# Generated at 2022-06-21 12:47:17.922110
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like({'a': 'b'}) is False
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(12) is False
    assert is_list_like(sum) is False

# Generated at 2022-06-21 12:47:21.712594
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)


# Generated at 2022-06-21 12:47:27.303781
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'keys', 'items') is True
    assert has_any_callables({}, 'keys', 'items', 'something') is True
    assert has_any_callables({'a': 1}, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_callables({'a': 1}, 'get', 'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-21 12:47:49.737543
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({'value': 'dictionary'}, 'get', 'items') == True
    assert has_callables({'value': 'dictionary'}, 'set', 'items') == False
    assert has_callables({'value': 'dictionary'}, 'get', 'set') == False
    assert has_callables(set(), 'intersection', 'issubset') == True
    assert has_callables(set(), 'intersection', 'isset') == False
    assert has_callables(set(), 'intersection', 'isset', 'symmetric_difference') == False
    assert has_callables(frozenset(), 'intersection', 'issubset') == True
    assert has_callables(frozenset(), 'intersection', 'isset') == False

# Generated at 2022-06-21 12:47:56.093992
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'items')
    assert has_any_attrs(dict(), 'foo', 'items')
    assert has_any_attrs(dict(), 'foo', 'bar', 'items')
    assert not has_any_attrs(dict(), 'foo', 'bar', 'baz')


# Generated at 2022-06-21 12:48:04.004527
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    print(is_list_like(dict()), True)
    print(is_list_like(frozenset()), True)
    print(is_list_like(list()), True)
    print(is_list_like(set()), True)
    print(is_list_like('hello'), True)
    print(is_list_like((1, 2, 3)), True)
    print(is_list_like(sorted([1, 2, 3])), True)
    print(is_list_like(reversed([1, 2, 3])), True)
    print(is_list_like('hello'), True)
    print(is_list_like(dict().keys()), True)
    print(is_list_like(dict().values()), True)

# Generated at 2022-06-21 12:48:14.472636
# Unit test for function has_any_callables
def test_has_any_callables():
    #Create a class instance, c, that includes all properties and methods in dict
    c={}
    #Create a dict, obj, that includes all properties and methods in dict
    obj={}
    #Assert that the first property get in obj.get is in c.get and that the obj.get method is callable
    assert has_any_callables(c,'get') is True
    #Assert that the first property keys in obj.keys is in c.keys and that the obj.keys method is callable
    assert has_any_callables(c,'keys') is True
    #Assert that the first property items in obj.items is in c.items and that the obj.items method is callable
    assert has_any_callables(c,'items') is True
    #Assert that the first property values in obj.values is in c.values and

# Generated at 2022-06-21 12:48:19.467760
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__setitem__')



# Generated at 2022-06-21 12:48:25.533863
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """To be able to run unit tests:
        $ python3 -m flutils.objutils.objutils
    """
    assert is_subclass_of_any(dict(a=1, b=2).keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(dict(a=1, b=2), ValuesView, KeysView, UserList) is False

# Generated at 2022-06-21 12:48:35.797927
# Unit test for function is_list_like
def test_is_list_like():
    # Test normal use case
    data = [
        ('kitten', False),
        (1, False),
        (1.1, False),
        ('hello', False),
        (reversed('hello'), True),
        (sorted('hello'), True),
        (None, False),
        (False, False),
        (True, False),
        (dict(), False),
        (dict(a=1), False),
        (set(), False),
        (tuple(), False),
        (tuple('abc'), True),
        (frozenset('abc'), True),
        (deque('abc'), True),
        (iter('abc'), True),
        (reversed('abc'), True),
        (sorted('abc'), True),
    ]

    for obj, expected in data:
        assert is_list_like

# Generated at 2022-06-21 12:48:38.525715
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert not is_list_like('hello')
    assert is_list_like(sorted('hello'))

# Generated at 2022-06-21 12:48:48.257966
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like(set()) is True
    assert is_list_like({}) is False
    assert is_list_like('') is False
    assert is_list_like(0) is False
    assert is_list_like(None) is False
    assert is_list_like(sorted([])) is True
    assert is_list_like(sorted({})) is False
    assert is_list_like(sorted('')) is False
    assert is_list_like(sorted(0)) is False
    assert is_list_like(sorted(None)) is False
    return

# Generated at 2022-06-21 12:48:51.459884
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:49:13.567373
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict(a=1,b=2),'get','keys','items','values')
    assert has_attrs(dict(a=1,b=2)['a'],'bit_length')
    assert not has_attrs(dict(a=1,b=2)['a'],'something')
    assert not has_attrs(dict(a=1,b=2),'something')


# Generated at 2022-06-21 12:49:25.599870
# Unit test for function is_list_like
def test_is_list_like():
    # Test function
    list1 = [1, 2, 3]
    list2 = list(range(4))
    list3 = sorted('hello')
    list4 = reversed([1, 2, 3])
    list5 = [1, 2, 3]
    list6 = ['a', 'b', 'c', 'd']
    list7 = ['a', 'b', 'c', 'd']
    list8 = []
    list9 = []
    list10 = ['a', 'b', 'c', 'd', 'e']
    list11 = ['a', 'b', 'c', 'd', 'e']

    # True
    assert is_list_like(list1)
    assert is_list_like(list2)
    assert is_list_like(list3)
    assert is_list_like(list4)

# Generated at 2022-06-21 12:49:38.786432
# Unit test for function is_list_like
def test_is_list_like():
    examples = [{
        'input': [1],
        'expected': True
    }, {
        'input': [],
        'expected': True
    }, {
        'input': (1,),
        'expected': True
    }, {
        'input': (1, 2),
        'expected': True
    }, {
        'input': 1,
        'expected': False
    }, {
        'input': set([1]),
        'expected': True
    }, {
        'input': frozenset([1]),
        'expected': True
    }, {
        'input': deque([1]),
        'expected': True
    }, {
        'input': '1',
        'expected': False
    }, {
        'input': dict([('1', 2)]),
        'expected': False
    }]
   

# Generated at 2022-06-21 12:49:45.476264
# Unit test for function has_attrs
def test_has_attrs():
    # prints True
    print(has_attrs([1,2,3], '__len__', '__iter__', '__getitem__'))
    # prints False
    print(has_attrs(1, '__len__', '__iter__', '__getitem__'))
    # prints True
    print(has_attrs({
        '__len__': lambda x: len(x),
        '__iter__': lambda x: iter(x),
        '__getitem__': lambda x, i: x[i]
    }, '__len__', '__iter__', '__getitem__'))



# Generated at 2022-06-21 12:49:48.931839
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

# Generated at 2022-06-21 12:49:55.805570
# Unit test for function is_list_like
def test_is_list_like():
    """
    >>> from flutils.objutils import is_list_like
    >>> is_list_like([1, 2, 3])
    True
    >>> is_list_like(reversed([1, 2, 4]))
    True
    >>> is_list_like('hello')
    False
    >>> is_list_like(sorted('hello'))
    True
    >>> is_list_like({'a': 1, 'b': 2})
    False
    """
    pass

# Generated at 2022-06-21 12:49:59.526238
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'foo','bar','baz') == False
    assert has_callables(str(),'split','upper','lower') == True


# Generated at 2022-06-21 12:50:02.928271
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    test = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert test


# Generated at 2022-06-21 12:50:07.222223
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(obj.keys(),UserList) == False

# Generated at 2022-06-21 12:50:11.435330
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True


# Generated at 2022-06-21 12:50:29.280867
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:50:40.636283
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from typing import Any as _Any

    _LIST_LIKE = (
        list,
        set,
        frozenset,
        tuple,
        deque,
        Iterator,
        ValuesView,
        KeysView,
        UserList
    )

    assert not is_subclass_of_any(None, *_LIST_LIKE)
    assert not is_subclass_of_any(False, *_LIST_LIKE)
    assert not is_subclass_of_any(True, *_LIST_LIKE)
    assert not is_subclass_of_any(1, *_LIST_LIKE)

# Generated at 2022-06-21 12:50:47.732023
# Unit test for function has_attrs
def test_has_attrs():
    from collections import OrderedDict
    from flutils.objutils import has_attrs
    od = OrderedDict(a=1, b=2, c=3)
    assert has_attrs(od, 'get', 'keys', 'values', '__getitem__') is True
    assert has_attrs(od, 'get', 'keys', 'values', '__getitem__', 'clear') is False


# Generated at 2022-06-21 12:50:55.969690
# Unit test for function has_attrs

# Generated at 2022-06-21 12:51:08.226264
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('', 'zfill', 'upper', 'lower', 'join') is True
    assert has_any_callables('', 'zfill', 'upper', 'lower', 'foo') is True
    assert has_any_callables('', 'zfill', 'upper', 'lower', 'foo', 'bar') is True
    assert has_any_callables('', 'zfill', 'upper', 'lower', 'foo', 'bar', 'baz') is True
    assert has_any_callables('', 'foo', 'bar') is False
    assert has_any_callables('foo') is False
    assert has_any_callables('foo', 'upper', 'lower', 'join') is False
    assert has_any_callables('foo', 'upper', 'lower') is True

# Generated at 2022-06-21 12:51:11.855213
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True


# Generated at 2022-06-21 12:51:20.309121
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    )
    from decimal import Decimal
    assert is_list_like([]) == True
    assert is_list_like([1]) == True
    assert is_list_like([1, 2, 3]) == True
    assert is_list_like((1, 2, 3)) == True
    assert is_list_like(set([1, 2, 3])) == True
    assert is_list_like({'a': 'A', 'b': 'B'}) == True
    assert is_list_like(deque([1, 2, 3])) == True

# Generated at 2022-06-21 12:51:27.381290
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs."""
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(dict(), 'keys', 'items', 'values')
    assert not has_any_attrs(dict(), 'foo', 'bar')
    assert has_any_attrs(dict(), 'foo', 'bar', 'get')



# Generated at 2022-06-21 12:51:32.223290
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2, c=3)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(obj, 'foo', 'bar', 'baz') is False


# Generated at 2022-06-21 12:51:35.621935
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """
    Test function is_subclass_of_any
    """
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-21 12:52:07.236674
# Unit test for function has_any_attrs
def test_has_any_attrs():
    num = 1
    assert has_any_attrs(num, 'real', 'conjugate') == False
    assert has_any_attrs(num, 'real', 'denominator') == True


# Generated at 2022-06-21 12:52:10.862133
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'something') is False



# Generated at 2022-06-21 12:52:22.045066
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """
    Unit test for function is_subclass_of_any
    """
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView)
    assert is_subclass_of_any(obj.keys(), KeysView, UserList)
    assert is_subclass_of_any(obj.keys(), ValuesView, UserList)
    assert is_subclass_of_any(obj.keys(), ValuesView)
    assert is_subclass_of_any(obj.keys(), KeysView)
    assert is_subclass

# Generated at 2022-06-21 12:52:24.475235
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-21 12:52:25.961235
# Unit test for function has_attrs
def test_has_attrs():
    pass


# Generated at 2022-06-21 12:52:35.479001
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import pytest
    test_obj = dict(a=1, b=2, c=3)
    assert has_any_attrs(test_obj, 'a', 'b', 'c', 'd') is True
    assert has_any_attrs(
        test_obj, 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o') is False
    test_obj_2 = dict()
    assert has_any_attrs(test_obj_2, '__getitem__', '__setitem__') is True
    with pytest.raises(AttributeError):
        assert has_any_attrs(test_obj_2, '__foo__', '__init__') is True


# Generated at 2022-06-21 12:52:38.645552
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') == True


# Generated at 2022-06-21 12:52:43.999630
# Unit test for function has_attrs
def test_has_attrs():
    """Test the :func:`has_attrs` function."""
    rtn = has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert rtn is True
    rtn = has_attrs(dict(), 'foo', 'bar', 'baz', 'quux', 'qux')
    assert rtn is False



# Generated at 2022-06-21 12:52:47.206894
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-21 12:52:55.655030
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True
    obj = [1,2,3]
    assert is_subclass_of_any(obj, UserList) is True
    obj = reversed(obj)
    assert is_subclass_of_any(obj, UserList, Iterator) is True
    obj = None
    assert is_subclass_of_any(obj, int, float) is False

# Generated at 2022-06-21 12:53:34.328780
# Unit test for function is_list_like
def test_is_list_like():
    """Check that is_list_like is working properly."""
    assert is_list_like([1,2,3]) == True
    assert is_list_like(['a', 'b', 'c']) == True
    assert is_list_like([]) == True
    assert is_list_like([1,(2,3),4]) == True
    assert is_list_like(['a', {'b': 'c'}, 'd']) == True
    assert is_list_like(['a', {'b': 'c'}, {'d': 'e'}]) == True
    assert is_list_like(['a', {'b': 'c'}, {'d': 'e'}, [1,2,3]]) == True
    assert is_list_like(()) == True
    assert is_list_like

# Generated at 2022-06-21 12:53:37.302873
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(), 'something') is False


# Generated at 2022-06-21 12:53:39.171591
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    d = dict(a=1, b=2)
    assert is_subclass_of_any(d.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-21 12:53:48.227193
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList
    from functools import partial
    import operator

    assert has_callables(UserList, 'append') is True
    assert has_callables(partial(operator.add, 2), '__call__') is True
    assert has_callables(dict(foo=1), 'pop') is False
    assert has_callables(list(), '__add__') is True
    assert has_callables(dict(foo=1), 'foobar') is False
    assert has_callables(dict(foo=1), 'foo', 'bar') is False
    assert has_callables(dict(foo=1), 'keys', 'foobar') is False



# Generated at 2022-06-21 12:53:51.452851
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test the ``is_subclass_of_any`` function.
    """
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert (is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList))


# Generated at 2022-06-21 12:53:54.040851
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import has_any_attrs
    # 1
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-21 12:54:01.323004
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(foo='bar')
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_attrs(obj, 'baz', 'key', 'monkey', 'foo', 'bar') is True
    assert has_any_attrs(obj, 'baz', 'key', 'monkey', 'foo', 'bar', 'gaz') is False
    assert has_any_attrs(obj, 'monkey', 'gaz', 'boo', 'goo', 'hoo') is False

# Generated at 2022-06-21 12:54:02.172318
# Unit test for function has_callables
def test_has_callables():
    print(has_callables(list(),'append'))


# Generated at 2022-06-21 12:54:11.715898
# Unit test for function has_attrs
def test_has_attrs():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    )

    _TYPES = (
        _LIST_LIKE
        + (
            ChainMap,
            Counter,
            None,
            OrderedDict,
            UserDict,
            UserList,
            UserString,
        )
    )


# Generated at 2022-06-21 12:54:16.611443
# Unit test for function has_attrs
def test_has_attrs():
    # Setup
    obj = dict(a=1, b=2)
    attrs = ['get', 'keys', 'items', 'values']
    # Test
    res = has_attrs(obj, *attrs)
    # Verify
    assert res is True
