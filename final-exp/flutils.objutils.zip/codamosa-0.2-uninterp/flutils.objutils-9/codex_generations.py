

# Generated at 2022-06-17 19:17:58.274755
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items','values')
    assert has_any_attrs(dict(),'get','keys','items')
    assert has_any_attrs(dict(),'get','keys')
    assert has_any_attrs(dict(),'get')
    assert not has_any_attrs(dict(),'something')


# Generated at 2022-06-17 19:18:05.191872
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is True

# Generated at 2022-06-17 19:18:10.945251
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert not has_any_callables(dict(),'foo')
    assert not has_any_callables(dict(),'foo','bar')


# Generated at 2022-06-17 19:18:15.077522
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False


# Generated at 2022-06-17 19:18:19.952961
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False


# Generated at 2022-06-17 19:18:30.602323
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:18:38.973072
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False

# Generated at 2022-06-17 19:18:48.121613
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
   

# Generated at 2022-06-17 19:18:57.361663
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:19:07.476696
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:19:19.978336
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True

# Generated at 2022-06-17 19:19:30.986365
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values') is True
    assert has_any_callables(dict(),'get','keys','items','foo') is True
    assert has_any_callables(dict(),'get','keys','values','foo') is True
    assert has_any_callables(dict(),'get','items','values','foo') is True
    assert has_any_callables(dict(),'keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items') is True
    assert has_any_callables(dict(),'get','keys','values') is True

# Generated at 2022-06-17 19:19:41.071626
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:19:49.280104
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_attrs(dict(), 'get', 'keys', 'items')
    assert has_any_attrs(dict(), 'get', 'keys')
    assert has_any_attrs(dict(), 'get')
    assert not has_any_attrs(dict(), 'something')
    assert not has_any_attrs(dict(), 'something', 'else')


# Generated at 2022-06-17 19:19:59.846849
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:20:06.101220
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-17 19:20:16.254943
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') != False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None

# Generated at 2022-06-17 19:20:23.893107
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') != False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None

# Generated at 2022-06-17 19:20:32.520489
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') != False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None

# Generated at 2022-06-17 19:20:41.755667
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:20:56.384554
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:21:05.836694
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:21:16.313953
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is True

# Generated at 2022-06-17 19:21:26.824486
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:21:28.250183
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-17 19:21:37.648338
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:21:48.027018
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:21:57.619183
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True

# Generated at 2022-06-17 19:22:05.836017
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get','keys','items','values','something') != False
    assert has_any_attrs(dict(),'get','keys','items','values','something') is not False
    assert has_any_attrs(dict(),'get','keys','items','values','something') is not None
    assert has_any_attrs(dict(),'get','keys','items','values','something') is not 0

# Generated at 2022-06-17 19:22:16.076795
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:22:33.423053
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:22:43.932813
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:22:56.675635
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:23:06.108678
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:23:08.707907
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:23:18.559170
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:23:27.981902
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:23:37.067531
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-17 19:23:45.622866
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:23:54.575605
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:24:08.846879
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict())


# Generated at 2022-06-17 19:24:11.731506
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-17 19:24:22.572333
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux')
    assert not has_any_callables

# Generated at 2022-06-17 19:24:27.727716
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False


# Generated at 2022-06-17 19:24:37.651085
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:24:46.847385
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:24:49.588829
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-17 19:24:57.927465
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:24:59.623933
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:25:08.211255
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:25:19.485257
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:25:20.689701
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:25:23.926075
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar','baz') == False


# Generated at 2022-06-17 19:25:28.306108
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False


# Generated at 2022-06-17 19:25:35.445584
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:25:46.509349
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux')
    assert not has_any_callables

# Generated at 2022-06-17 19:25:53.391585
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:26:00.309133
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:26:07.231338
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:26:12.152078
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False


# Generated at 2022-06-17 19:26:35.840423
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:26:45.061699
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:26:46.881711
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-17 19:26:54.425470
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:27:03.656206
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True

# Generated at 2022-06-17 19:27:13.159465
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:27:16.838051
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:27:18.939896
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:27:28.811830
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:27:37.850371
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')