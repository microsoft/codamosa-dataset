

# Generated at 2022-06-17 19:18:01.000660
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get','keys','items','values','something') != False
    assert has_any_attrs(dict(),'get','keys','items','values','something') is not False
    assert has_any_attrs(dict(),'get','keys','items','values','something') is not None
    assert has_any_attrs(dict(),'get','keys','items','values','something') is not 0

# Generated at 2022-06-17 19:18:03.551553
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:18:11.336952
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:18:14.220671
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:18:23.890589
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux')
    assert not has_any_callables

# Generated at 2022-06-17 19:18:25.973701
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')


# Generated at 2022-06-17 19:18:28.442705
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo') == False


# Generated at 2022-06-17 19:18:34.694438
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar')


# Generated at 2022-06-17 19:18:38.945879
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items','values')
    assert not has_any_attrs(dict(),'something')
    assert not has_any_attrs(dict(),'something','something_else')


# Generated at 2022-06-17 19:18:50.447613
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not 0
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not ''

# Generated at 2022-06-17 19:18:59.825178
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert not has_any_callables(dict(),'foo')
    assert not has_any_callables(dict(),'foo','bar')


# Generated at 2022-06-17 19:19:09.553208
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:19:19.343564
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is True

# Generated at 2022-06-17 19:19:22.713190
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','keys','items','values','foo') is False


# Generated at 2022-06-17 19:19:34.135543
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:19:38.822445
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False


# Generated at 2022-06-17 19:19:47.827814
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-17 19:19:58.000708
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') != False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None

# Generated at 2022-06-17 19:20:06.693075
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:20:16.502990
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:20:28.731204
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables"""
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False

# Generated at 2022-06-17 19:20:38.848858
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:20:48.153451
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:20:58.786044
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:21:10.458399
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:21:20.311396
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:21:28.938164
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:21:37.902606
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is True

# Generated at 2022-06-17 19:21:45.563881
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not 0
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not ''

# Generated at 2022-06-17 19:21:56.999288
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is True

# Generated at 2022-06-17 19:22:11.484445
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert not has_any_callables(dict(),'foo')
    assert not has_any_callables(dict(),'foo','bar')


# Generated at 2022-06-17 19:22:19.756095
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:22:30.401836
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:22:37.568861
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux')
    assert not has_any_callables

# Generated at 2022-06-17 19:22:48.756407
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:22:52.028708
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:22:59.039940
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is True

# Generated at 2022-06-17 19:23:07.896347
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is True

# Generated at 2022-06-17 19:23:14.061456
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz')


# Generated at 2022-06-17 19:23:24.534896
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:23:44.859535
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:23:56.835502
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')


# Generated at 2022-06-17 19:24:06.061664
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:24:09.012656
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == False


# Generated at 2022-06-17 19:24:20.114082
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-17 19:24:30.804094
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:24:39.474520
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:24:47.390802
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:24:51.351274
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-17 19:25:00.503957
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:25:24.152274
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:25:33.885995
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:25:45.148513
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__', '__setitem__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__', '__setitem__', '__delitem__') is True

# Generated at 2022-06-17 19:25:57.449056
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux')
    assert not has_any_callables

# Generated at 2022-06-17 19:26:03.130715
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False



# Generated at 2022-06-17 19:26:13.286708
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:26:23.627084
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:26:26.611111
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo') == False


# Generated at 2022-06-17 19:26:36.367949
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:26:43.439551
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:27:14.516422
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-17 19:27:19.938218
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:27:22.995095
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar','baz') == False


# Generated at 2022-06-17 19:27:31.614520
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:27:41.280464
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is True

# Generated at 2022-06-17 19:27:50.770154
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True