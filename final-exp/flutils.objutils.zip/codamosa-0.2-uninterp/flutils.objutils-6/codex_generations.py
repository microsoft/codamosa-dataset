

# Generated at 2022-06-17 19:17:59.990313
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:18:08.043656
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:18:16.467678
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:18:18.654301
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:18:26.762199
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:18:37.376703
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:18:43.348021
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:18:53.359341
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:19:03.047799
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert has_any_callables(dict(),'foo')
    assert has_any_callables(dict(),'foo','bar')
    assert has_any_callables(dict(),'foo','bar','baz')
    assert has_any_callables(dict(),'foo','bar','baz','qux')
    assert has_any_callables(dict(),'foo','bar','baz','qux','quux')
    assert has

# Generated at 2022-06-17 19:19:11.777648
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:19:24.951033
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:19:34.428155
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') != False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None

# Generated at 2022-06-17 19:19:44.849688
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:19:52.797677
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:20:02.157114
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:20:10.658456
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not 0
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not 1

# Generated at 2022-06-17 19:20:18.917686
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'quux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'quux', 'corge') is False
    assert has_

# Generated at 2022-06-17 19:20:28.955785
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is False
    assert has_any_attrs(dict(), 'something') is False
    assert has_any_attrs(dict(), 'something', 'something_else') is False
    assert has_any_attrs(dict(), 'something', 'something_else', 'get') is True
    assert has_any_attrs(dict(), 'something', 'something_else', 'get', 'keys') is True
    assert has_any_attrs(dict(), 'something', 'something_else', 'get', 'keys', 'items') is True

# Generated at 2022-06-17 19:20:34.663041
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True


# Generated at 2022-06-17 19:20:45.827055
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys', 'values')

# Generated at 2022-06-17 19:21:07.166643
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux')
    assert not has_any_callables

# Generated at 2022-06-17 19:21:17.191782
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:21:25.896597
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert has_any_callables(dict(),'foo')
    assert not has_any_callables(dict(),'foo','bar')
    assert not has_any_callables(dict(),'foo','bar','baz')


# Generated at 2022-06-17 19:21:36.547371
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz', 'qux')
    assert not has_any_callables

# Generated at 2022-06-17 19:21:47.367711
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:21:57.501008
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:22:05.728339
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux')

# Generated at 2022-06-17 19:22:15.351124
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:22:25.590700
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'quux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'quux', 'quuux') is False
    assert has

# Generated at 2022-06-17 19:22:36.777641
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:23:06.112257
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has

# Generated at 2022-06-17 19:23:16.028599
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:23:26.076332
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:23:36.387376
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:23:38.061098
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:23:46.225409
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-17 19:23:57.892139
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:24:04.979253
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False


# Generated at 2022-06-17 19:24:13.016692
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:24:23.231583
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:25:18.040304
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:25:20.715585
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-17 19:25:23.982603
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items','values','foo') is False


# Generated at 2022-06-17 19:25:33.438497
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:25:44.715997
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__', '__setitem__') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__', '__setitem__', 'foo') is False

# Generated at 2022-06-17 19:25:57.259683
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:26:03.837592
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:26:10.323896
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False



# Generated at 2022-06-17 19:26:21.312687
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_callables

# Generated at 2022-06-17 19:26:25.772850
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False

