

# Generated at 2022-06-17 19:18:05.006020
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:18:13.873345
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has

# Generated at 2022-06-17 19:18:20.145506
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert has_any_callables(dict(),'foo') is False


# Generated at 2022-06-17 19:18:22.303572
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == False


# Generated at 2022-06-17 19:18:31.858924
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:18:40.043415
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:18:49.972361
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-17 19:18:59.819012
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:19:06.117537
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert not has_any_callables(dict(),'foo')


# Generated at 2022-06-17 19:19:15.614838
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:19:25.745795
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:19:36.308381
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:19:46.822517
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:19:49.925819
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-17 19:20:00.250603
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:20:08.135235
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is True

# Generated at 2022-06-17 19:20:17.492220
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items') == True
    assert has_any_callables(dict(),'get','keys') == True
    assert has_any_callables(dict(),'get') == True
    assert has_any_callables(dict(),'foo') == False
    assert has_any_callables(dict(),'foo','bar') == False
    assert has_any_callables(dict(),'foo','bar','baz') == False
    assert has_any_callables(dict(),'foo','bar','baz','qux') == False

# Generated at 2022-06-17 19:20:20.019032
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-17 19:20:29.844175
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items','foo') == True
    assert has_any_callables(dict(),'get','keys','items') == True
    assert has_any_callables(dict(),'get','keys','foo') == True
    assert has_any_callables(dict(),'get','keys') == True
    assert has_any_callables(dict(),'get','foo') == True
    assert has_any_callables(dict(),'get') == True
    assert has_any_callables(dict(),'foo') == False
    assert has_any_callables(dict()) == False


# Generated at 2022-06-17 19:20:39.539878
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has

# Generated at 2022-06-17 19:20:56.448919
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:21:05.919832
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has

# Generated at 2022-06-17 19:21:16.385825
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items','foo') == True
    assert has_any_callables(dict(),'get','keys','foo','values') == True
    assert has_any_callables(dict(),'get','foo','items','values') == True
    assert has_any_callables(dict(),'foo','keys','items','values') == False
    assert has_any_callables(dict(),'foo','bar','baz','qux') == False
    assert has_any_callables(dict(),'foo') == False

# Generated at 2022-06-17 19:21:26.824450
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:21:31.922973
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:21:40.199564
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:21:49.167002
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:21:51.807350
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:22:00.215691
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:22:08.140801
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:22:26.339868
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:22:36.862997
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:22:48.286157
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:22:57.882277
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:23:01.286048
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:23:10.900632
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:23:19.126296
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:23:24.208877
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False


# Generated at 2022-06-17 19:23:33.253813
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

# Generated at 2022-06-17 19:23:41.749548
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not 0
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not ''

# Generated at 2022-06-17 19:24:11.639558
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True

# Generated at 2022-06-17 19:24:22.503313
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-17 19:24:30.999235
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert not has_any_callables(dict(),'foo')
    assert not has_any_callables(dict(),'foo','bar')
    assert not has_any_callables(dict(),'foo','bar','baz')


# Generated at 2022-06-17 19:24:39.667362
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:24:47.498383
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:24:50.775791
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-17 19:25:00.122840
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo','bar') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo','bar','baz') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo','bar','baz','qux') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo','bar','baz','qux','quux') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo','bar','baz','qux','quux','corge') is True

# Generated at 2022-06-17 19:25:08.537605
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:25:19.464800
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__iter__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__setitem__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__delitem__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__contains__') is True

# Generated at 2022-06-17 19:25:29.212523
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:26:16.059609
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:26:18.374607
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-17 19:26:28.098954
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict(),'get','keys','items','values','foo') is False
    assert has_callables(dict(),'get','keys','items','values','foo','bar') is False
    assert has_callables(dict(),'get','keys','items','values','foo','bar','baz') is False
    assert has_callables(dict(),'get','keys','items','values','foo','bar','baz','qux') is False
    assert has_callables(dict(),'get','keys','items','values','foo','bar','baz','qux','quux') is False
    assert has_callables(dict(),'get','keys','items','values','foo','bar','baz','qux','quux','corge') is False

# Generated at 2022-06-17 19:26:37.161913
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-17 19:26:44.318937
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:26:56.755433
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_

# Generated at 2022-06-17 19:27:07.072490
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__', '__iter__') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__', '__iter__', 'foo') is False

# Generated at 2022-06-17 19:27:15.806837
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-17 19:27:19.443201
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-17 19:27:29.294621
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'qux', 'quux') is False
    assert has_