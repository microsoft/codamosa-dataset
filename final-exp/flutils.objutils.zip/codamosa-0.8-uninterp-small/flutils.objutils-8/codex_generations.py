

# Generated at 2022-06-25 17:20:52.755977
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values')
    assert has_callables(obj, 'get', 'keys', 'items', 'values')
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert has_any_attrs(obj, 'keys')
    assert has_any_callables(obj, 'keys')
    assert is_list_like(reversed([1, 2, 4]))

# Generated at 2022-06-25 17:21:00.872195
# Unit test for function has_callables
def test_has_callables():
    from .nameutils import Name
    from .funcutils import has_callables, has_any_callables

    d = dict(a=1, b=2)
    assert has_callables(d, 'get', 'items', 'keys') is True
    assert has_any_callables(d, 'get', 'items', 'keys', 'foo') is True
    assert has_callables(d, 'get', 'items', 'foo') is False
    assert has_any_callables(d, 'get', 'items', 'foo') is True
    assert has_callables(d, 'as_dict') is False
    assert has_any_callables(d, 'as_dict') is False
    assert has_callables(d, 'get', 'items', 'foo') is False

# Generated at 2022-06-25 17:21:03.399959
# Unit test for function has_any_callables
def test_has_any_callables():
    tuple_0 = ()
    bool_0 = has_any_callables(tuple_0, '__iter__', '__contains__')
    assert bool_0 is False


# Generated at 2022-06-25 17:21:09.550911
# Unit test for function has_any_callables
def test_has_any_callables():
    # When tuple_0 exists, return True
    tuple_0 = (1, 2, 3)
    result = has_any_callables(tuple_0)
    assert result is True

    # When tuple_0 does not exist, return False
    tuple_0 = ()
    result = has_any_callables(tuple_0)
    assert result is False



# Generated at 2022-06-25 17:21:16.928593
# Unit test for function has_any_callables
def test_has_any_callables():
    dict0 = dict()
    dict1 = dict(a=1, b=2)
    assert has_any_callables(dict0, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict1, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict1, 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict1, 'get', 'something')


# Generated at 2022-06-25 17:21:29.717276
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import OrderedDict
    from collections.abc import Mapping, MutableMapping, Sequence, MutableSequence, Set, Iterable
    input = dict(a=1, b=2)
    expected = True
    result = has_any_attrs(input, 'keys', 'items', 'values')
    assert result == expected

    input = dict(a=1, b=2)
    expected = False
    result = has_any_attrs(input, 'keys', 'something', 'values')
    assert result == expected

    input = dict(a=1, b=2)
    expected = True
    result = has_any_attrs(input, '__class__')
    assert result == expected

    input = dict(a=1, b=2)
    expected = True
    result = has_any_att

# Generated at 2022-06-25 17:21:40.381573
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    dict_1 = dict(a=1, b=2, get='c')
    dict_2 = dict(a=1, b=2, get=lambda self: 'c')
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict_1, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict_2, 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-25 17:21:53.279488
# Unit test for function has_callables
def test_has_callables():
    row = r'1,foo,bar,baz'
    row_no_header = r'foo,bar,baz,qux'
    delimiter = ','
    test_df = pd.read_csv(
        StringIO(row + os.linesep + row_no_header),
        names=row.split(delimiter),
        dtype=str,
        delimiter=delimiter,
        header=0,
    )
    assert isinstance(test_df, pd.DataFrame)
    def foo(*args, **kwargs):
        return args, kwargs
    test_df.foo = foo
    assert has_callables(test_df.foo, 'foo') == True

# Generated at 2022-06-25 17:22:01.234945
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(tuple, '__add__', '__contains__', '__eq__', '__ge__', '__getitem__', '__getnewargs__', '__gt__', '__hash__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', 'count', 'index')

# Generated at 2022-06-25 17:22:11.933078
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter, defaultdict
    from datetime import datetime
    from decimal import Decimal
    from fractions import Fraction
    from uuid import uuid4
    assert has_callables(Counter(), 'get') is True
    assert has_callables(datetime(2019, 10, 10), 'strftime', 'round') is True
    assert has_callables(Decimal(1), 'sqrt', 'log10') is True
    assert has_callables(defaultdict(list), 'get') is True
    assert has_callables(Fraction(1, 2), 'numerator', 'denominator') is True
    assert has_callables(uuid4(), 'int') is True


# Generated at 2022-06-25 17:22:20.919280
# Unit test for function has_callables
def test_has_callables():
    # Change default values
    obj = [1, 2, 3, 4, 5]
    attrs = "__getitem__"
    expected_output = True
    # Call function
    actual_output = has_callables(obj, *attrs)
    # Verify output
    assert actual_output == expected_output


# Generated at 2022-06-25 17:22:30.017291
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(tuple(), '__add__') is True
    assert has_callables(dict(), '__add__') is False
    assert has_callables(list(), '__add__') is True
    # assert has_callables(list(), '__iter__') is True
    # assert has_callables(list(), '__iter__', '__add__') is True
    # assert has_callables(list(), '__iter__', '__add__', '__contains__') is True
    assert has_callables(str(), '__add__') is True
    assert has_callables(str(), '__add__', '__contains__') is True
    assert has_callables(str(), '__add__', '__contains__', '__getitem__') is True

# Generated at 2022-06-25 17:22:42.013354
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    dict_0['foo'] = 'bar'

    dict_1 = dict_0.copy()
    del dict_1['foo']

    dict_2 = dict_0.copy()
    del dict_2['foo']
    dict_2['foo'] = lambda : None

    dict_3 = dict_0.copy()
    dict_3['foo'] = lambda : None

    # Test the natural behavior of has_callables
    # We want to test for certain properties, so we expect certain things.
    assert has_callables(dict_0, 'keys') is True          # Pass
    assert has_callables(dict_0, 'clear', 'keys') is True # Pass
    assert has_callables(dict_0, 'keys', 'clear') is True # Pass

# Generated at 2022-06-25 17:22:49.543810
# Unit test for function has_any_callables
def test_has_any_callables():
    '''
    Ensure that the function has_any_callables works as expected
    '''

    assert(has_any_callables(dict(), 'foo'))
    assert(has_any_callables(dict(), 'get', 'foo'))
    assert(has_any_callables(dict(), 'get', 'update'))
    assert(not has_any_callables(dict(), 'foo', 'bar'))


# Generated at 2022-06-25 17:22:54.895622
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    has_any_callables(dict_0, "get", "keys", "items", "values")

# Generated at 2022-06-25 17:23:00.924678
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import OrderedDict
    d_ = OrderedDict([('a', 1), ('b', 2), ('c', 3)])
    assert has_callables(d_, 'keys', 'values')



# Generated at 2022-06-25 17:23:02.755673
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-25 17:23:08.734799
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_1 = dict()
    obj_2 = {'a': 1}
    obj_3 = (1, 2)
    obj_4 = list()
    obj_5 = {'a': 1, 'b': None}
    obj_6 = {'a': 1, 'b': None, 'c': 'foo'}

    assert has_any_callables(obj_1, 'pop', 'popitem', 'keys', 'foo', 'bar')
    assert has_any_callables(obj_2, 'keys', 'a', 'bar')
    assert has_any_callables(obj_3, 'add')
    assert has_any_callables(obj_4, 'clear') is False
    assert has_any_callables(obj_5, 'bar', 'b') is False
    assert has_any_callables

# Generated at 2022-06-25 17:23:20.601487
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = dict(foo=None)
    has_any_callables_result = has_any_callables(obj_0, 'keys', 'values', 'foo')
    # Test assert statement
    assert has_any_callables(obj_0, 'keys', 'values', 'foo') is True
    # Test bool assert fail
    try:
        assert has_any_callables(obj_0, 'keys', 'values', 'foo') is False
    except AssertionError:
        pass
    # Test bencoding.Bencoder assert fail
    try:
        assert has_any_callables_result == 'foo'
    except AssertionError:
        pass


# Generated at 2022-06-25 17:23:26.702754
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    obj['foo'] = 'bar'
    obj.bar = 'foo'
    assert has_callables(obj, 'bar') is True
    assert has_callables(obj, 'foo') is False
    assert has_callables(obj, 'bar', 'foo') is False
    assert has_callables(obj, 'bar', 'bar') is False
    assert has_callables(obj, 'foo', 'foo') is False


# Generated at 2022-06-25 17:23:41.365691
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function :func:`flutils.objutils.has_any_callables`
    """
    import inspect

    from flutils.objutils import has_any_callables

    classes = [int, float, str, set, list, dict, tuple]
    for class_0 in classes:
        obj = class_0()
        for item in inspect.getmembers(obj):
            if item[0].startswith('_'):
                continue
            if has_any_callables(obj, item[0]) is True:
                assert callable(getattr(obj, item[0]))



# Generated at 2022-06-25 17:23:45.919113
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = io.BufferedReader
    assert has_any_callables(obj, 'read', 'close', 'seek', '__init__')



# Generated at 2022-06-25 17:23:50.362610
# Unit test for function has_any_callables
def test_has_any_callables():
    list_object = ['first_element', 'second_element', 'third_element']
    assert(has_any_callables(list_object, 'append', 'extend', 'count'))


# Generated at 2022-06-25 17:24:00.185080
# Unit test for function has_any_callables
def test_has_any_callables():
    obj1 = dict(a=1, b=2)
    obj2 = dict(c=3, d=4)
    obj3 = dict(e=5, f=6)
    expected = True
    result = has_any_callables(obj1, 'keys', 'values', 'foo')
    assert expected == result
    expected = False
    result = has_any_callables(obj2, 'foo', 'bar', 'baz')
    assert expected == result
    expected = True
    result = has_any_callables(obj3, 'foo', 'bar', 'items')
    assert expected == result
    expected = False
    result = has_any_callables(obj3, 'foo', 'bar', 'baz')
    assert expected == result



# Generated at 2022-06-25 17:24:05.163778
# Unit test for function has_any_callables
def test_has_any_callables():
    # SUBJECT UNDER TEST
    from flutils.objutils import has_any_callables
    
    # ASSERT
    assert has_any_callables(tuple(),'get','keys','items','values','foo') == False


# Generated at 2022-06-25 17:24:13.120749
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test dict with all callables
    dict_0 = dict(foo=lambda: None, bar=lambda: None)
    assert has_any_callables(dict_0, 'foo', 'bar')
    # Test dict with only one callable
    dict_0 = dict(foo=lambda: None, bar=None)
    assert has_any_callables(dict_0, 'foo', 'bar')
    # Test dict with no callables
    dict_0 = dict(foo=None, bar=None)
    assert not has_any_callables(dict_0, 'foo', 'bar')
    # Test dict with no attributes
    dict_0 = dict()
    assert not has_any_callables(dict_0, 'foo', 'bar')



# Generated at 2022-06-25 17:24:20.613624
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict()
    assert(has_any_callables(d, 'get', 'keys', 'values', 'items') == True)
    assert(has_any_callables(d, 'get', 'keys', 'values', 'items', 'ouch') == True)
    assert(has_any_callables(d, 'ouch', 'ouch', 'ouch') == False)


# Generated at 2022-06-25 17:24:28.653065
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables({}, 'get', 'keys', 'values', 'items'))
    assert(has_any_callables({}, 'get', 'keys', 'values', 'items', 'foo'))
    assert(has_any_callables(dict(), 'get', 'keys', 'values', 'items'))
    assert(has_any_callables(dict(), 'get', 'keys', 'values', 'items', 'foo'))
    assert(has_any_callables(list(), 'append', 'count', 'extend', 'insert'))
    assert(has_any_callables(list(), 'append', 'count', 'extend', 'insert', 'foo'))
    assert(has_any_callables(tuple(), 'count', 'index'))

# Generated at 2022-06-25 17:24:40.717783
# Unit test for function has_any_callables
def test_has_any_callables():
    # test that a dictionary has all the given attributes
    obj_0 = dict(a=1, b=2)
    assert has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'foo')
    # test that it does not have an attr
    assert not has_any_callables(obj_0, 'foo', 'bar')
    # test a false for any attr
    assert not has_any_callables(obj_0, 'bool', 'str')
    # test a false for any attr
    assert not has_any_callables(obj_0, 'bool', 'str')
    # test a string has no attrs
    obj_1 = 'hello'
    assert not has_any_callables(obj_1, 'foo', 'bar')



# Generated at 2022-06-25 17:24:43.897249
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    list_of_attrs = ['get', 'keys', 'values', 'items', 'not']
    assert has_any_callables(obj, *list_of_attrs) is True


# Generated at 2022-06-25 17:25:03.020062
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test the function has_any_callables() with a variety of list-like objects.
    """
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','items','values','foo')
    assert not has_any_callables(dict(),'get','keys','values')
    assert has_any_callables({'get': 1, 'items': 2, 'values': 3, 'foo': 4}, 'get', 'foo')
    assert has_any_callables({'get': 1, 'items': 2, 'values': 3, 'foo': 4}, 'get', 'foo', 'baz')
    assert not has_any_callables({'get': 1, 'items': 2, 'values': 3, 'foo': 4}, 'baz')

# Generated at 2022-06-25 17:25:15.369776
# Unit test for function has_any_callables
def test_has_any_callables():
    # See if the ResultBlock object has the expected callable attributes:
    from flutils.datautils import ResultBlock
    assert has_any_callables(ResultBlock, 'append', 'dumps', 'extend', 'foo', 'get', 'pretty_print') == True
    assert has_any_callables(ResultBlock, 'foo', 'bar', 'baz') == False
    assert has_any_callables(ResultBlock, 'append', 'dumps', 'foo', 'get', 'pretty_print') == True
    assert ResultBlock.__class__.__bases__ == (UserList,)
    assert has_any_callables(ResultBlock.__class__, 'append', 'dumps', 'extend', 'foo', 'get', 'pretty_print') == True

# Generated at 2022-06-25 17:25:21.161980
# Unit test for function has_any_callables
def test_has_any_callables():

    # Test proper sequence
    actual_result = has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    expected_result = True
    assert actual_result is expected_result

    # Test no sequence
    actual_result = has_any_callables(dict(), 'foo')
    expected_result = False
    assert actual_result is expected_result


# Generated at 2022-06-25 17:25:28.353180
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(a=1, b=2)
    assert has_any_callables(d, 'foo', 'keys', 'values', 'clear') is True


# Generated at 2022-06-25 17:25:35.059916
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items') is True
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'boo', 'bar', 'baz') is False



# Generated at 2022-06-25 17:25:39.899108
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import namedtuple
    # noinspection PyProtectedMember
    for _class in namedtuple('Foo', 'a b c')(*[None] * 3)._fields:
        assert has_any_callables(dict(), _class) is True
    assert has_any_callables(dict(), 'a', 'b', 'c') is False


# Generated at 2022-06-25 17:25:44.559971
# Unit test for function has_any_callables
def test_has_any_callables():

    obj = dict(a=1, b=2, c=3)

    # check with correct attributes
    assert has_any_callables(obj, 'items', 'update')

    # check with correct attributes
    assert has_any_callables(obj, 'update', 'items')

    # check with existing attribute, but not callable
    assert has_any_callables(obj, 'items', 'clear') is False

    # check for non-existing attributes
    assert has_any_callables(obj, 'foo', 'bar') is False


# Generated at 2022-06-25 17:25:47.583713
# Unit test for function has_any_callables
def test_has_any_callables():
    has_any_callables_0_0 = has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables_0_0


# Generated at 2022-06-25 17:25:50.814588
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    has_any_callables(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-25 17:25:56.447732
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','name')
    assert has_any_callables([], 'name')
    assert has_any_callables([], 'name','pop','append','reverse')
    assert has_any_callables(dict(),'name','get','getitem') == True
    assert has_any_callables(dict(),'name','get','getitem', 'keys') == True
    assert has_any_callables({}, 'name', 'get') == True


# Generated at 2022-06-25 17:26:09.518261
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'stuff') is False



# Generated at 2022-06-25 17:26:18.828349
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(get(),'__getitem__') is True
    assert has_any_callables(dict(),'__getitem__') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','whatever') is True
    assert has_any_callables(dict(),'keys','items','values','whatever','get') is True
    assert has_any_callables(dict(),'keys','items','values','whatever','setdefault') is False


# Generated at 2022-06-25 17:26:25.045533
# Unit test for function has_any_callables
def test_has_any_callables():
    '''
    function has_any_callables
    '''
    obj = dict(a=1,b=2,c=3)
    assert(has_any_callables(obj,'get','keys','values') == True)
    assert(has_any_callables(obj,'key','value') == False)
    assert(has_any_callables('my_dict', 'as_dict') == True)



# Generated at 2022-06-25 17:26:35.004435
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo',
                             'bar', 'baz', 'qux') is True

    assert has_any_callables(dict(), 'setdefault', '__contains__', '__delitem__',
                             '__setitem__', '__getitem__') is True
    assert has_any_callables(dict(), 'setdefault', '__contains__', '__delitem__',
                             '__setitem__') is True

# Generated at 2022-06-25 17:26:43.373234
# Unit test for function has_any_callables
def test_has_any_callables():
    # Testing default behavior
    check = None
    if has_any_callables(dict(), "get", "keys", "items", "values", "foo"):
        # Expected behavior
        check = True
    else:
        check = False
    assert check
    # Testing iteration with no values
    check = None
    if has_any_callables(dict(), "foo"):
        # Expected behavior
        check = False
    else:
        check = True
    assert check


# Generated at 2022-06-25 17:26:45.871343
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = dict()
    has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-25 17:26:48.454445
# Unit test for function has_any_callables
def test_has_any_callables():
    from . import objutils

    test_dict = {'a': 1, 'b': 2}
    assert objutils.has_any_callables(test_dict, 'get', 'keys')



# Generated at 2022-06-25 17:27:01.371507
# Unit test for function has_any_callables
def test_has_any_callables():
    # obj: dict
    dict_0 = dict()
    assert has_any_callables(dict_0, 'get', 'items')
    assert not has_any_callables(dict_0, 'foo')

    # obj: dict
    dict_0 = dict(a=1, b=2)
    assert has_any_callables(dict_0, 'get', 'items')
    assert has_any_callables(dict_0, 'values', 'items')
    assert not has_any_callables(dict_0, 'foo')

    # obj: dict
    dict_0 = dict(a=1, b=2)
    assert has_any_callables(dict_0, 'get', 'items')
    assert has_any_callables(dict_0, 'values', 'items')
    assert not has_

# Generated at 2022-06-25 17:27:05.213707
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True


if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:27:14.377600
# Unit test for function has_any_callables
def test_has_any_callables():
    print('Testing function has_any_callables')
    print('Testing has_any_callables with a normal object')
    class MyDict(dict):
        def foo(self):
            return 'foo'
    d = MyDict(a=1, b=2)
    assert has_any_callables(d)
    print('Testing has_any_callables with a non iterable object')
    assert has_any_callables(1) == False
    print('Testing has_any_callables with a collection object')
    d = {}
    assert has_any_callables(d)


# Generated at 2022-06-25 17:27:37.897793
# Unit test for function has_any_callables
def test_has_any_callables():
    #  Testing object does not have any attributes and no attributes were passed
    assert has_any_callables(dict()) is False
    #  Testing object does not have any attributes but attributes were passed
    assert has_any_callables(dict(),'get','keys','items','values','foo') is False
    #  Testing object does have attributes but no attributes were passed
    assert has_any_callables(dict(a=1)) is False
    #  Testing object does have attributes and attributes were passed
    assert has_any_callables(dict(a=1),'get','keys','items','values') is True
    #  Testing object does have attributes and attributes were passed but none can be called
    assert has_any_callables(dict(a=1),'something','foo','bar') is False

if __name__ == '__main__':
    test

# Generated at 2022-06-25 17:27:45.757909
# Unit test for function has_any_callables
def test_has_any_callables():
    # Get the doc string from the function and test
    test_doc = has_any_callables.__doc__
    assert test_doc is not None
    assert type(test_doc) is str
    assert len(test_doc)
    from collections import defaultdict
    dd_0 = defaultdict(dict)
    bool_0 = has_any_callables(
        dd_0,
        'foo',
        'default_factory',
        '__missing__',
        'get',
        'keys',
        'items'
    )
    assert bool_0 is False



# Generated at 2022-06-25 17:27:47.568501
# Unit test for function has_any_callables
def test_has_any_callables():
    print(has_any_callables(dict(),'get','keys','items','values','foo'))

# Generated at 2022-06-25 17:27:55.140069
# Unit test for function has_any_callables
def test_has_any_callables():
    test_dict_0 = {}
    set_0 = set()
    list_0 = []
    tuple_0 = ()
    int_0 = 0
    class_0 = type('class_0', (), {})
    assert has_any_callables(test_dict_0, 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values', '__contains__', '__getitem__')

# Generated at 2022-06-25 17:28:05.707265
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test with a dict
    dict_0 = {
        'foo': 'bar',
        'answer': 42,
        'foo_bar': 'answer',
    }
    # Check the default return value
    assert has_any_callables(dict_0) is False
    # Check for items()
    assert has_any_callables(dict_0, 'items') is True
    # Check for keys()
    assert has_any_callables(dict_0, 'keys') is True
    # Check for values()
    assert has_any_callables(dict_0, 'values') is True
    # Check for insert()
    assert has_any_callables(dict_0, 'insert') is False
    # Check for get()
    assert has_any_callables(dict_0, 'get') is True
    # Check

# Generated at 2022-06-25 17:28:10.572305
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict(a=1)

    try:
        has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo')
        has_any_callables(dict_0, 'foo')
    except Exception as exc:
        print(exc)
        raise
    else:
        print('No exceptions were raised.')


# Generated at 2022-06-25 17:28:18.370565
# Unit test for function has_any_callables
def test_has_any_callables():
    # Make sure True is returned if any of the callable attributes exist
    dummy_obj_0 = Mock()
    # Checking if the mock object has the attribute is False, so it will use
    # has_any_attrs function to check if any of the attributes exist. Since
    # there are no attributes, the function will return False.
    assert has_any_callables(dummy_obj_0, 'get', 'keys', 'items', 'values') == False


# Generated at 2022-06-25 17:28:23.307376
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = list()
    bool_0 = has_any_callables(list_0, '__add__')
    bool_1 = has_any_callables(list_0, '__class__')
    bool_2 = has_any_callables(list_0, '__iter__', '__eq__')


# Generated at 2022-06-25 17:28:34.158808
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([], 'append', 'pop') is True
    assert has_any_callables(list(), 'append', 'pop') is True
    assert has_any_callables({}, 'keys') is True
    assert has_any_callables(dict(), 'keys') is True
    assert has_any_callables('', 'split', 'rsplit') is True
    assert has_any_callables(str(), 'split', 'rsplit') is True
    func_0 = lambda x: x
    assert has_any_callables(func_0, '__call__') is True
    class Obj_0(object):
        def __init__(self, x):
            self.x = x

        def __call__(self, *x):
            self.x = x

    obj_0 = Obj_

# Generated at 2022-06-25 17:28:39.401671
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        class Dummy(dict):
            pass
        dummy = Dummy()
        dummy['foo'] = 'bar'
        dummy['somethingElse'] = 'value'
        assert has_any_callables(dummy, '__setitem__', '__getitem__', '__delitem__', 'foo') is True
    except AssertionError as err:
        print(str(err))

if __name__ == '__main__':
    test_case_0()
    test_has_any_callables()