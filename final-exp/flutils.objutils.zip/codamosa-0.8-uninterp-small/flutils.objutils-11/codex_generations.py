

# Generated at 2022-06-25 17:20:50.575376
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 1223.994223898265
    assert has_any_callables(float_0) is False



# Generated at 2022-06-25 17:20:56.746441
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, "keys", "items", "values") is True
    assert has_callables(obj, "keys", "items", "values", "foo") is False



# Generated at 2022-06-25 17:21:00.182046
# Unit test for function has_any_callables
def test_has_any_callables():
    result = has_any_callables([])
    assert result == True, "expected True, but got {}".format(result)



# Generated at 2022-06-25 17:21:02.617968
# Unit test for function has_any_callables
def test_has_any_callables():
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    test_case_0()
    test_has_any_callables()

# Generated at 2022-06-25 17:21:10.560164
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = hl.tarray([1, 2, 3])
    assert has_any_attrs(obj, 'collect')
    assert has_any_callables(obj, 'map')
    assert not has_any_attrs(obj, 'foo')
    assert has_attrs(obj, 'collect')
    assert not has_attrs(obj, 'foo', 'bar')
    assert has_callables(obj, 'map', 'collect')
    assert not has_callables(obj, 'map', 'collect', 'foo')



# Generated at 2022-06-25 17:21:17.188569
# Unit test for function has_attrs
def test_has_attrs():
    test_obj = {'attr_1': 'test_value', 'attr_2': 'test_value'}
    assert has_attrs(test_obj, 'attr_1') is True
    assert has_attrs(test_obj, 'attr_1', 'attr_2') is True
    assert has_attrs(test_obj, 'attr_1', 'attr_2', 'attr_3') is False
    assert has_attrs(test_obj, '__getitem__', '__iter__') is True


# Generated at 2022-06-25 17:21:29.747283
# Unit test for function has_any_callables
def test_has_any_callables():
    from math import floor, ceil, trunc
    float_0 = 1223.994223898265
    assert has_any_callables(float_0) is True
    assert has_any_callables(float_0, 'foo', 'bar') is False
    assert has_any_callables(float_0, 'as_integer_ratio', 'real') is True
    assert has_any_callables(float_0, 'foo', 'real') is True
    assert has_any_callables(float_0, 'foo', 'bar', 'as_integer_ratio', 'real') is True
    assert has_any_callables(float_0, 'floor', 'ceil', 'trunc') is True
    assert has_any_callables(None) is False

# Generated at 2022-06-25 17:21:35.146011
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Description of test_case_0
    test_val = has_any_attrs(dict(),'get','keys','items','values','something')
    assert test_val == True



# Generated at 2022-06-25 17:21:40.902111
# Unit test for function has_any_attrs
def test_has_any_attrs():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    assert has_any_attrs(test_dict, 'get', 'items') == True
    assert has_any_attrs(test_dict, 'get', 'keys', 'values', 'something') == True
    assert has_any_attrs(test_dict, 'foo', 'bar') == False



# Generated at 2022-06-25 17:21:44.176136
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    obj['a'] = 'a'
    obj['b'] = 'b'
    obj['c'] = 'c'
    assert has_any_attrs(obj, 'get', 'keys')


# Generated at 2022-06-25 17:21:48.492200
# Unit test for function has_any_attrs
def test_has_any_attrs():
    test_case_0()


# Generated at 2022-06-25 17:21:58.669807
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = {}
    bool_0 = has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'something')
    bool_1 = has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'something')
    bool_2 = has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'something')
    bool_3 = has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'something')
    bool_4 = has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'something')
    bool_5 = has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'something')


# Generated at 2022-06-25 17:22:05.129492
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-25 17:22:13.878809
# Unit test for function has_callables
def test_has_callables():
    obj_0 = object()
    assert has_callables(obj_0, '__class__') == False
    obj_0 = object()
    assert has_callables(obj_0, '__getattribute__') == True
    obj_0 = object()
    assert has_callables(obj_0, '__dir__', '__getattribute__') == True
    obj_0 = object()
    assert has_callables(obj_0, 'test') == False
    obj_0 = object()
    assert has_callables(obj_0, 'test', 'test_0') == False
    obj_0 = object()
    assert has_callables(obj_0, 'test_0', '__dir__') == False


# Generated at 2022-06-25 17:22:19.295181
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(dict(), 'get', 'keys', 'items', 'values')==True)
    assert(has_callables(dict(), 'get', 'keys', 'items', 'foo')==False)


# Generated at 2022-06-25 17:22:23.862062
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_attrs(dict(), 'foo')
    assert has_any_attrs({'a': 4, 'b': 5, 'c': 6}, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_attrs({'a': 4, 'b': 5, 'c': 6}, 'foo')


# Generated at 2022-06-25 17:22:25.444144
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Intialize test case 0
    # Run function and tests 
    pass


# Generated at 2022-06-25 17:22:32.684683
# Unit test for function has_callables
def test_has_callables():
    # Simple case of callables in a UserList
    assert has_callables(UserList(), '__iter__', '__len__', '__contains__') is True, 'This fails if there is a callable in a UserList that is not in standard library objects'
    # Simple case of no callables in a UserList
    assert has_callables(UserList(), '__reversed__', '__lt__', '__gt__') is False, 'This fails if there is a callable in a UserList that is not in standard library objects'
    # Simple case of callables in a UserDict
    assert has_callables({}, '__iter__', '__len__', '__contains__') is True, 'This fails if there is a callable in a UserList that is not in standard library objects'
    # simple case of no callables in

# Generated at 2022-06-25 17:22:33.864950
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

if __name__ == '__main__':
    import uuid

    unittest.main()

# Generated at 2022-06-25 17:22:35.845728
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-25 17:22:41.314455
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 1223.994223898265
    assert has_any_callables(float_0) is True


# Generated at 2022-06-25 17:22:52.421067
# Unit test for function has_any_callables
def test_has_any_callables():
    if has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'):
        raise Exception("Unexpected success in has_any_callables")
    if not has_any_callables(dict(), 'get', 'keys', 'items', 'values'):
        raise Exception("Unexpected failure in has_any_callables")
    if has_any_callables(dict(), 'foo'):
        raise Exception("Unexpected success in has_any_callables")
    if has_any_callables(dict(), 'foo', 'bar'):
        raise Exception("Unexpected success in has_any_callables")
    if has_any_callables(dict(), 'foo', 'bar', 'baz'):
        raise Exception("Unexpected success in has_any_callables")


# Generated at 2022-06-25 17:22:56.626805
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 1223.994223898265
    bool_0 = has_any_callables(float_0)
    assert bool_0 == False, "Function not working"
    return


# Generated at 2022-06-25 17:23:05.873496
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str, 'upper', 'lower')
    assert not has_callables(str, 'hey', 'random')
    assert has_callables(UserList, 'append', 'count')
    assert not has_callables(UserList, 'hey', 'random')
    assert has_callables(list, 'append', 'count')
    assert not has_callables(list, 'hey', 'random')
    assert has_callables(dict, 'get', 'items')
    assert not has_callables(dict, 'hey', 'random')
    assert has_callables(tuple, 'count')
    assert not has_callables(tuple, 'hey', 'random')
    assert has_callables(set, 'add', 'copy')
    assert not has_callables(set, 'hey', 'random')


# Generated at 2022-06-25 17:23:19.565275
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(test_case_0() == None)
# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC -----
# MAGIC 
# MAGIC ### DataFrameUtils
# MAGIC 
# MAGIC ##### show_nulls
# MAGIC 
# MAGIC Utility function to display ``DataFrame`` column names and the count of ``null`` values in each column

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### show_first_rows
# MAGIC 
# MAGIC Utility function to display the first ``n`` rows of the ``DataFrame``

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### show_datatypes
# MAGIC 
# MAGIC Utility function to show the ``datatypes`` of the ``Data

# Generated at 2022-06-25 17:23:25.801695
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 1223.994223898265
    # Test case evaluation
    assert callable(float_0.hex) == False



# Generated at 2022-06-25 17:23:32.222946
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj_0 = ['a', 'e', 'i', 'o', 'u']
    assert has_any_callables(test_obj_0) is True
    test_obj_1 = frozenset(['a', 'e', 'i', 'o', 'u'])
    assert has_any_callables(test_obj_1) is True
    test_obj_2 = dict(vowels=['a', 'e', 'i', 'o', 'u'])
    assert has_any_callables(test_obj_2) is True
    test_obj_3 = (('a', 1), ('b', 2), ('c', 3))
    assert has_any_callables(test_obj_3) is True
    test_obj_4 = {1, 2, 3, 4, 5}
    assert has

# Generated at 2022-06-25 17:23:37.521286
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get', 'keys', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'values') is True



# Generated at 2022-06-25 17:23:43.297188
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 1223.994223898265
    float_1 = float_0
    result = has_any_callables(float_1)
    print(result)



# Generated at 2022-06-25 17:23:44.460758
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 1223.994223898265
    bool_0 = has_any_callables(float_0)
    assert bool_0


# Generated at 2022-06-25 17:23:59.790777
# Unit test for function has_callables
def test_has_callables():
    class TestClass:
        def __init__(self, arg):
            self.attribute = arg

        def __call__(self, arg):
            return self.attribute + arg
            
    obj = TestClass('test')
    assert has_callables(obj, '__call__')
    assert (has_callables(obj, '__call__', '__init__') ==
            has_callables(obj, '__init__', '__call__'))
    #assert has_callables(obj, '__call__', '__init__', 'attribute')
    assert has_callables(obj, 'attribute') is False
    assert has_callables(obj, '__init__') is True
    assert has_callables(obj) is False
    assert has_callables(obj, 'to_s') is False
    assert has

# Generated at 2022-06-25 17:24:06.214252
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar')



# Generated at 2022-06-25 17:24:15.182852
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest

    assert has_any_callables(test_case_0) is False
    assert has_any_callables(test_case_0, '__doc__') is True
    assert has_any_callables(test_case_0, '__init__', '__doc__') is True
    assert has_any_callables(test_case_0, '__init__', '__doc__', 'foo') is True
    assert has_any_callables(test_case_0, 'foo') is False

    assert has_any_callables(test_case_0, '__doc__', 'foo') is True
    assert has_any_callables(test_case_0, 'foo', '__doc__') is True


# Generated at 2022-06-25 17:24:26.047065
# Unit test for function has_any_callables
def test_has_any_callables():
    # import_module('importlib').reload(sys.modules['flutils.objutils'])
    from flutils.objutils import has_any_callables
    assert has_any_callables(float, 'as_integer_ratio')

    float_0 = 1223.994223898265
    assert has_any_callables(float_0, 'as_integer_ratio') is True
    assert has_any_callables(float_0, 'as_integer_ratio_dict_keys') is False

    float_0 = 1223.994223898265

# Generated at 2022-06-25 17:24:29.267704
# Unit test for function has_any_callables
def test_has_any_callables():
    # Case 0
    test_case_0()



# Generated at 2022-06-25 17:24:34.485362
# Unit test for function has_any_callables
def test_has_any_callables():
    # Function test_case_0
    # Check type of float_0
    assert isinstance(float_0, float)
    # Assert has_any_callables is True
    assert bool_0 == True
    
    

# Generated at 2022-06-25 17:24:39.304555
# Unit test for function has_any_callables
def test_has_any_callables():

    # Instantiate a float
    float_0 = 1223.994223898265

    # Instantiate a test bool
    bool_1 = False


    # Evaluate an expression
    bool_0 = has_any_callables(float_0)

    # Test the condition
    assert bool_0




# Generated at 2022-06-25 17:24:47.024356
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(float, 'is_integer', 'is_integer')
    assert has_any_callables(float, 'is_integer', 'hex', 'denominator')
    assert not has_any_callables(float, 'is_float', 'denominator')
    # float_0 = float('-0.0')
    # assert not has_any_callables(float_0, 'hex', 'denominator')



# Generated at 2022-06-25 17:24:54.754986
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables.

    Args:
        None

    Returns:
        None

    Examples:
        >>> from flutils.objutils import test_has_any_callables
        >>> test_has_any_callables()
    """
    _ = test_case_0()


if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-25 17:24:55.684008
# Unit test for function has_any_callables
def test_has_any_callables():
    assert test_case_0()


# Generated at 2022-06-25 17:25:08.653716
# Unit test for function has_callables
def test_has_callables():
    """Validate function has_callables"""
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == False
    assert has_callables(dict(),'get','keys','items','values','__init__') == False
    # TODO: Add test case until all branches are executed.


# Generated at 2022-06-25 17:25:21.284891
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(None) == False
    assert has_any_callables(False) == False
    assert has_any_callables(True) == False
    assert has_any_callables(0) == False
    assert has_any_callables(1) == False
    assert has_any_callables(2) == False
    assert has_any_callables(3) == False
    assert has_any_callables(4) == False
    assert has_any_callables(5) == False
    assert has_any_callables(6) == False
    assert has_any_callables(7) == False
    assert has_any_callables(8) == False
    assert has_any_callables(9) == False
    assert has_any_callables(10) == False
    assert has

# Generated at 2022-06-25 17:25:22.136727
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()



# Generated at 2022-06-25 17:25:28.228396
# Unit test for function has_callables
def test_has_callables():
    """
    Author: Ian Davis
    Date  : 2019-04-20
    """

    actual = has_callables(None, 'abs', 'dict', 'items')
    expected = False
    assert actual == expected

    actual = has_callables(True, 'abs', 'dict', 'items')
    expected = False
    assert actual == expected

    actual = has_callables(0, 'abs', 'dict', 'items')
    expected = False
    assert actual == expected

    actual = has_callables('', 'abs', 'dict', 'items')
    expected = False
    assert actual == expected

    actual = has_callables(list(), 'abs', 'dict', 'items')
    expected = False
    assert actual == expected


# Generated at 2022-06-25 17:25:39.680884
# Unit test for function has_callables
def test_has_callables():
    # This function tests the has_callables function.
    print("In test_has_callables")

    def f():
        '''
        This is a dummy function
        '''

    class A:
        def aa():
            '''
            This is a dummy function
            '''

    assert has_callables(float, 'is_integer', '__str__')
    assert not has_callables(float, 'is_integer', '__str__', 'aaa')
    assert not has_callables(float, 'ddd', '__str__')
    assert not has_callables(f, 'is_integer', '__str__')
    assert not has_callables(f)
    assert has_callables(A, 'aa')
    assert not has_callables(A, 'aa', 'bb')

# Generated at 2022-06-25 17:25:41.679145
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 1223.994223898265
    bool_0 = has_any_callables(float_0)


# Generated at 2022-06-25 17:25:43.213166
# Unit test for function has_callables
def test_has_callables():
    pass  # TODO: write tests for `has_callables`


# Generated at 2022-06-25 17:25:53.571067
# Unit test for function has_callables
def test_has_callables():
    from decimal import Decimal
    from decimal import DecimalException
    d : Decimal = Decimal(5)
    assert has_callables(Decimal, '__add__') == True
    assert has_callables(Decimal, '__add__', '__div__') == True
    assert has_callables(Decimal, '__add__', '__div__', '__gt__') == True
    assert has_callables(Decimal, '__add__', '__div__',
            '__gt__', '__lt__') == True
    assert has_callables(Decimal, '__add__', '__div__',
            '__gt__', '__lt__', '__mul__') == True
    assert has_callables(d, '__add__') == True

# Generated at 2022-06-25 17:25:56.744081
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = float(1223.994223898265)
    expected_output = False
    actual_ouput = has_any_callables(float_0)
    assert expected_output == actual_ouput


# Generated at 2022-06-25 17:25:58.683999
# Unit test for function has_any_callables
def test_has_any_callables():
    assert callable(has_any_callables)


# Generated at 2022-06-25 17:26:20.342474
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'to_sorted_list', 'keys', 'items', 'values') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'to_sorted_list') is False



# Generated at 2022-06-25 17:26:27.121043
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(1)
    assert has_any_callables(1.0)
    assert has_any_callables(1 + 0j)
    assert has_any_callables(-1)
    assert has_any_callables([1])
    assert has_any_callables({1})
    assert has_any_callables(range(0))
    assert has_any_callables('')
    assert has_any_callables('a')
    assert has_any_callables('abc')
    assert has_any_callables(b'')
    assert has_any_callables(b'abc')
    assert has_any_callables(b'\x61')
    assert has_any_callables([1, 2, 3])

# Generated at 2022-06-25 17:26:36.368720
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(float, 'fromhex', 'hex', 'is_integer') == True
    assert has_any_callables(dict, 'fromkeys', 'get', 'items', 'keys', 'values')
    assert has_any_callables(dict, 'fromkeys', 'items', 'keys', 'values')
    assert has_any_callables(dict, 'fromkeys', 'get', 'items', 'keys')
    assert has_any_callables(dict, 'fromkeys', 'get', 'items')
    assert has_any_callables(dict, 'fromkeys', 'get')
    assert has_any_callables(dict, 'fromkeys')
    assert has_any_callables(dict, 'fromkeys', 'set', 'pop') == False

# Generated at 2022-06-25 17:26:37.330664
# Unit test for function has_callables
def test_has_callables():
    pass


# Generated at 2022-06-25 17:26:38.768980
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 17:26:49.046300
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test edge cases
    assert has_any_callables(None, 'something') is False
    assert has_any_callables(object, 'something') is False
    assert has_any_callables(bool, 'something') is False
    # Test valid cases
    assert has_any_callables(dict, '__init__') is True
    assert has_any_callables(list, '__init__') is True
    assert has_any_callables(object, '__init__') is True
    assert has_any_callables('hello', '__init__') is True
    assert has_any_callables(1.0, '__init__') is True
    # Test invalid cases
    assert has_any_callables(dict, 'something') is False



# Generated at 2022-06-25 17:27:00.581845
# Unit test for function has_callables
def test_has_callables():
    d = dict(a=1, b=2)
    assert has_callables(d, 'get', 'values', 'items', 'set') is True
    assert has_callables(d, 'gato', 'el', 'cochino', 'y', 'ella') is False
    assert has_callables(123, 'gato') is False
    assert has_callables(None, 'gato') is False
    assert has_callables('feliz', 'gato') is False
    assert has_callables(False, 'foo') is False
    assert has_callables(12.23, 'foo') is False
    assert has_callables(True, 'foo') is False



# Generated at 2022-06-25 17:27:03.813878
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert(has_callables(obj, 'get'))

    assert(has_callables(obj, 'get', 'items', 'keys'))

    assert(not has_callables(obj, 'foo', 'bar'))



# Generated at 2022-06-25 17:27:08.897820
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = dict([(0, '0')])
    assert has_any_callables(obj_0)
    assert not has_any_callables(obj_0, 'foo')
    assert has_any_callables(obj_0, 'foo', 'items')



# Generated at 2022-06-25 17:27:10.133211
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(1)


# Generated at 2022-06-25 17:28:00.103506
# Unit test for function has_callables
def test_has_callables():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 17:28:03.860165
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = has_any_callables('3407')
    bool_1 = has_any_callables('3407', 'isdigit', 'isupper', 'islower', 'isalnum')
    assert bool_0 is False and bool_1 is True



# Generated at 2022-06-25 17:28:07.981942
# Unit test for function has_callables
def test_has_callables():
    OBJ = dict(a=1)
    ATT = ['get', 'setdefault', 'update', 'clear', 'something']
    ANS = True
    RES = has_callables(OBJ, *ATT)
    assert RES == ANS, 'assert has_callables(OBJ, *ATT) == ANS FAILED'



# Generated at 2022-06-25 17:28:10.353334
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict(a=1, b=2, c=3)
    assert has_callables(dict_0, 'keys', 'values') == True



# Generated at 2022-06-25 17:28:22.321370
# Unit test for function has_callables
def test_has_callables():
    """Check that ``has_callables`` returns the correct value.
    """
    float_0 = float()
    float_1 = float(0.0)
    float_2 = float(0)
    float_3 = float('')
    float_4 = float('123.12')
    float_5 = float('0.123')
    dict_0 = dict()
    dict_1 = dict(a=1, b='b', c=object())
    dict_2 = dict(zip(range(10), range(10)))
    dict_3 = dict(zip(['a', 'b', 'c'], [1, 2, 3]))
    dict_4 = dict(zip(['a', 'b', 'c'], ['1', '2', '3']))

# Generated at 2022-06-25 17:28:31.178497
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(1, 'hex') is True)
    assert(has_callables('hello', 'lower', 'upper') is True)
    assert(has_callables([1,2,3], 'pop', 'sort') is True)
    assert(has_callables(dict(a=1, b=2), 'items', 'keys') is True)
    assert(has_callables(dict(a=1, b=2), 'items', 'keys', 'values') is True)
    assert(has_callables(dict(a=1, b=2), 'items', 'keys', 'values', 'something') is False)



# Generated at 2022-06-25 17:28:39.431415
# Unit test for function has_callables
def test_has_callables():
    def has_callables_test(input, expected):
        actual = has_callables(input)
        if actual != expected:
            s = "FAILED:" \
                + "\n input = " + str(input) \
                + "\n actual = " + str(actual) \
                + "\n expected = " + str(expected)
            raise Exception(s)

    has_callables_test(decimal.Decimal(0.0), False)
    has_callables_test(1, False)
    has_callables_test(1.0, False)
    has_callables_test(False, False)
    has_callables_test(True, False)
    has_callables_test([], True)
    has_callables_test({}, True)

# Generated at 2022-06-25 17:28:50.000259
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'something') is True
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo', 'something') is True
    assert has_any_callables(dict(), 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'items', 'values') is True

# Generated at 2022-06-25 17:28:55.460415
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'keys', 'items', 'values')
    assert has_callables(dict(), 'keys', 'items')
    assert not has_callables(dict(), 'foo', 'bar', 'baz')
    assert not has_callables(dict(), 'foo', 'bar')
    assert not has_callables(dict(), 'foo')
    assert has_callables(set(), 'add', 'clear', 'remove')
    assert has_callables(set(), 'add', 'clear')
    assert has_callables(set(), 'add')
    assert not has_callables(set(), 'foo', 'bar', 'baz')
    assert not has_callables(set(), 'foo', 'bar')
    assert not has

# Generated at 2022-06-25 17:29:01.883140
# Unit test for function has_callables
def test_has_callables():
    float_0 = float()
    float_1 = float('nan')
    float_2 = float('inf')
    float_3 = float('-inf')
    float_4 = float('inf')
    float_5 = float('0')
    float_6 = float('0.')
    float_7 = float('nan')
    float_8 = float()
    float_9 = float()
    float_10 = float('nan')
    int_0 = int()
    int_1 = int('1')
    int_2 = int('-1')
    int_3 = int()
    int_4 = int('1')
    int_5 = int('-1')
    int_6 = int()
    int_7 = int()
    int_8 = int('1')