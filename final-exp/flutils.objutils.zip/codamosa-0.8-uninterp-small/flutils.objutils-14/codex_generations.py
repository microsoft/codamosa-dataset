

# Generated at 2022-06-25 17:20:55.414860
# Unit test for function has_callables

# Generated at 2022-06-25 17:21:00.203402
# Unit test for function has_callables
def test_has_callables():
    # test_1
    obj_1 = {'get': lambda: None, 'keys': lambda: None, 'items': lambda: None, 'values': lambda: None}
    res_1 = True
    assert has_callables(obj_1, 'get', 'keys', 'items', 'values') == res_1
    # test_2
    obj_2 = {'get': lambda: None, 'foo': lambda: None, 'bar': lambda: None, 'values': lambda: None}
    res_2 = False
    assert has_callables(obj_2, 'get', 'keys', 'items', 'values') == res_2



# Generated at 2022-06-25 17:21:10.666551
# Unit test for function has_callables
def test_has_callables():
    from unittest import (
        TestCase,
        main as unittest_main,
    )

    class TestHasAttrs(TestCase):
        def test_case_0(self):
            obj = dict(foo=True, bar=True, baz=True)
            bool_0 = has_callables(obj, 'foo', 'bar', 'baz')
            self.assertTrue(bool_0)

        def test_case_1(self):
            class Bar(object):
                @classmethod
                def foo(cls):
                    pass

            obj = Bar()
            bool_0 = has_callables(obj, 'foo')
            self.assertTrue(bool_0)

        def test_case_2(self):
            class Bar(object):
                def foo(self):
                    pass


# Generated at 2022-06-25 17:21:14.129422
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = True
    bool_1 = has_any_callables(bool_0)
    bool_2 = has_any_callables(dict())


# Generated at 2022-06-25 17:21:16.678119
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    func_names = ['get', 'keys', 'items', 'values', 'foo']
    assert has_any_callables(obj, *func_names) is True



# Generated at 2022-06-25 17:21:29.716914
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(True,'__bool__')
    assert has_attrs(True,'__add__','__sub__','__bool__','__enter__','__exit__','__gt__','__lt__','__mul__','__or__','__subclasshook__')
    assert not has_attrs(True,'__abs__')
    assert not has_attrs(True,'__abs__','__mul__')
    assert not has_attrs(False,'__abs__')
    assert not has_attrs(False,'__abs__','__mul__')

# Generated at 2022-06-25 17:21:35.145541
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    keys = ['get', 'keys', 'items', 'values', 'foo']
    ret = has_any_callables(obj, *keys)
    assert ret is True


# Generated at 2022-06-25 17:21:39.788345
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = True
    bool_1 = has_any_callables(bool_0)
    assert bool_0 is bool_1
    assert isinstance(bool_0, bool)
    assert isinstance(bool_1, bool)
    assert bool_0 is True
    assert bool_1 is True


# Generated at 2022-06-25 17:21:44.823126
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), None) == False
    assert has_any_callables(dict(), 'get') == True
    assert has_any_callables(dict(), 'keys') == True
    assert has_any_callables(dict(), 'values') == True
    assert has_any_callables(dict(), 'items') == True
    assert has_any_callables(dict(), 'foo') == False



# Generated at 2022-06-25 17:21:50.648833
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'items') is True
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables(dict(), 'foo', 'bar') is False


# Generated at 2022-06-25 17:21:56.546045
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(list(), '__str__', '__len__') == True
    assert has_attrs(list(), '__str__', '__len__', '__something__') == False


# Generated at 2022-06-25 17:22:03.580742
# Unit test for function has_callables
def test_has_callables():
    """Check the behavior of :obj:`has_callables`."""

    msg = 'Incorrect return value.'
    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'items', 'values')
    assert has_callables(obj, *attrs) is True, msg

# Generated at 2022-06-25 17:22:06.075688
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-25 17:22:08.863088
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list_0) is True

# Generated at 2022-06-25 17:22:16.432786
# Unit test for function has_callables
def test_has_callables():
    list_0 = []
    assert has_callables(list_0, 'append', 'clear', 'copy',
                         'count', 'extend', 'index', 'insert',
                         'pop', 'remove', 'reverse', 'sort') == True
    assert has_callables(list_0, 'foo', 'bar') == False


# Generated at 2022-06-25 17:22:29.462641
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj_0 = [1,2,3,4]
    test_obj_1 = []
    test_obj_2 = ()
    test_obj_3 = (1,2,3,4)
    test_obj_4 = {1,2,3,4}
    test_obj_5 = {}
    test_obj_6 = {1:1, 2:2, 3:3, 4:4}
    test_obj_7 = reversed(test_obj_0)
    test_obj_8 = sorted(test_obj_0)
    for obj in [test_obj_0, test_obj_1, test_obj_2, test_obj_3, test_obj_4, test_obj_5, test_obj_6, test_obj_7, test_obj_8]:
        assert has_

# Generated at 2022-06-25 17:22:34.406711
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = {}
    dict_1 = dict(a=1,b=2)
    assert(has_any_callables(dict_0) is True)
    assert(has_any_callables(dict_0,'get','keys','values','something') is True)
    assert(has_any_callables(dict_1,'get','keys','values','something') is True)


# Generated at 2022-06-25 17:22:43.044871
# Unit test for function has_attrs
def test_has_attrs():
    list_0 = []
    assert not has_attrs(list_0, 'append')
    # test with no attributes
    assert has_attrs(list_0)
    # test with one attribute
    assert has_attrs(list_0, 'append')
    # check for multiple attributes
    assert has_attrs(list_0, 'append', 'pop')
    # test with extra attributes
    assert not has_attrs(list_0, 'append', 'pop', 'something')



# Generated at 2022-06-25 17:22:49.819330
# Unit test for function has_callables
def test_has_callables():

    # Test with error
    thing = {'a': 1, 'b': 2}
    result = has_callables(thing, 'values', 'keys', 'items')
    assert result

    # Test with error
    thing = {'a': 1, 'b': 2}
    result = has_callables(thing, 'foo', 'keys', 'items')
    assert not result



# Generated at 2022-06-25 17:22:52.541478
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    callables = ('get', 'keys', 'items', 'values')
    assert has_callables(obj, *callables) is True


# Generated at 2022-06-25 17:22:56.703907
# Unit test for function has_callables
def test_has_callables():
    floating_point_number = 3.14
    assert has_callables(floating_point_number, 'real', 'imag') is False


# Generated at 2022-06-25 17:23:05.898668
# Unit test for function has_any_callables
def test_has_any_callables():
    # create a list-like object
    user_list_obj = UserList()
    # test for object
    # expect: True
    result = has_any_callables(user_list_obj,'append')
    assert result is True
    # test for object
    # expect: False
    result = has_any_callables(user_list_obj,'notACallable')
    assert result is False
    # Test the has_any_callables function when passing in an object that
    # does not have the given attribute
    # create a int like object
    user_int_obj = int(1)
    # test for object
    # expect: False
    result = has_any_callables(user_int_obj, 'append')
    assert result is False
    # Test the has_any_callables function when passing in an object that

# Generated at 2022-06-25 17:23:19.582682
# Unit test for function has_callables
def test_has_callables():
    # Test for valid call of function has_callables.
    dict_0 = dict()
    dict_0.__setitem__ = lambda *a, **kw: None
    dict_0.__getitem__ = lambda *a, **kw: None
    dict_0.keys = lambda *a, **kw: None
    dict_0.values = lambda *a, **kw: None
    dict_0.items = lambda *a, **kw: None
    assert has_callables(dict_0, '__getitem__', 'keys') is True
    assert has_callables(dict_0, '__setitem__', 'values', 'items') is True
    assert has_callables(dict_0, '__getitem__', '__setitem__', 'keys',
                         'values', 'items') is True
    # Test for invalid

# Generated at 2022-06-25 17:23:24.765224
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Function: has_any_callables
    Purpose: Confirm that has_any_callables returns a True when passed an object that has a callable.
    :return: None
    """
    assert True == has_any_callables(list(), 'count')
    assert False == has_any_callables(list(), 'something_that_does_not_exist')


# Generated at 2022-06-25 17:23:30.001600
# Unit test for function has_callables
def test_has_callables():
    import unittest

    class HasCallablesTest(unittest.TestCase):
        def runTest(self):
            test_case_0()

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-25 17:23:38.810424
# Unit test for function has_callables
def test_has_callables():
    list_0 = []
    bool_0 = has_callables(list_0, 'append')
    assert isinstance(bool_0, bool)
    assert bool_0 is True
    list_0 = []
    bool_0 = has_callables(list_0, 'foo')
    assert isinstance(bool_0, bool)
    assert bool_0 is False
    dict_0 = dict(a=1, b=2, c=3)
    bool_0 = has_callables(dict_0, 'keys', 'items')
    assert isinstance(bool_0, bool)
    assert bool_0 is True
    dict_0 = dict(a=1, b=2, c=3)
    bool_0 = has_callables(dict_0, 'foo', 'bar')

# Generated at 2022-06-25 17:23:50.507554
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        test_case_0()
    except AssertionError as e:
        print(e)
        return False

    try:
        test_case_1()
    except AssertionError as e:
        print(e)
        return False

    try:
        test_case_2()
    except AssertionError as e:
        print(e)
        return False

    try:
        test_case_3()
    except AssertionError as e:
        print(e)
        return False

    try:
        test_case_4()
    except AssertionError as e:
        print(e)
        return False

    try:
        test_case_5()
    except AssertionError as e:
        print(e)
        return False


# Generated at 2022-06-25 17:23:55.982436
# Unit test for function has_callables
def test_has_callables():
    list_0 = []
    assert(has_callables(list_0, 'append') == True)
    assert(has_callables(list_0, 'something') == False)
    dict_0 = dict()
    assert(has_callables(dict_0, 'get') == True)
    assert(has_callables(dict_0, 'keys') == True)
    assert(has_callables(dict_0, 'values') == True)
    assert(has_callables(dict_0, 'items') == True)
    assert(has_callables(dict_0, 'foo') == False)

# Generated at 2022-06-25 17:24:05.849031
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables('test','replace','upper','lower')
    assert has_callables('test','replace','upper','lower')
    assert not has_callables('test','replace','upper','foo')
    assert not has_callables(dict(),'replace','upper','foo')


# Generated at 2022-06-25 17:24:13.613910
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'keys', 'get', 'items', 'values') is True
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'get') is True
    assert has_any_callables(dict(), 'keys', 'items', 'get', 'values') is True
    assert has_any_callables(dict(), 'keys', 'values', 'items', 'get') is True
    assert has_any_callables(dict(), 'keys', 'values', 'get', 'items') is True
    assert has_any_callables(dict(), 'keys', 'values', 'get', 'foo') is False

# Generated at 2022-06-25 17:24:24.058705
# Unit test for function has_any_callables
def test_has_any_callables():
    # Set the name of the test
    test_name = "has_any_callables"
    # Set the name of the test suite
    test_suite_name = __name__

    # Build the test object and run it
    test_object = TestObject(test_case_0, test_name, test_suite_name)
    test_object.run()



# Generated at 2022-06-25 17:24:37.904972
# Unit test for function has_callables
def test_has_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal as _Decimal
    from functools import partial

    list_0 = []
    assert has_callables(list_0, 'append', 'clear', 'extend', 'insert') is True

    iter_0 = iter([])
    assert has_callables(iter_0, '__next__') is True

    str_0 = 'hello'
    assert has_callables(str_0, '__add__', '__contains__', '__eq__') is True

    range_0 = range(0, 3)

# Generated at 2022-06-25 17:24:40.031633
# Unit test for function has_callables
def test_has_callables():
    list_0 = []
    bool_0 = has_callables(list_0)



# Generated at 2022-06-25 17:24:49.151314
# Unit test for function has_callables
def test_has_callables():
    obj1 = dict()
    vm = isinstance(obj1, dict)
    assert vm is True

    has_attr1 = has_attrs(obj1, "get", "keys", "items", "values")
    assert has_attr1 is True

    has_attr2 = has_attrs(obj1, "get", "keys", "item", "values")
    assert has_attr2 is False

    has_any_attr1 = has_any_attrs(obj1, "get", "keys", "item", "values")
    assert has_any_attr1 is True

    has_any_attr2 = has_any_attrs(obj1, "get", "key", "item", "values")
    assert has_any_attr2 is False


# Generated at 2022-06-25 17:24:55.149241
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') \
        is True
    assert has_callables(dict(),'get','keys','items','values','foo') \
        is False
    assert has_callables(dict(),'get','keys','items','values','foo') \
        is False



# Generated at 2022-06-25 17:24:57.896552
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        test_case_0()
    except Exception:
        raise AssertionError('Test case 0 failed')



# Generated at 2022-06-25 17:25:03.547620
# Unit test for function has_any_callables
def test_has_any_callables():
    one_1 = has_any_callables(list_0)
    one_2 = has_any_callables(list_1)
    assert one_1 == True
    assert one_2 == False

# Generated at 2022-06-25 17:25:08.080044
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(),'append','count') == True
    assert has_callables(list(),'append','count','foo') == False
    assert has_callables(list(),"append","count",1,2) == False
    assert has_callables(list(),"append","count",1,2,"foo") == False



# Generated at 2022-06-25 17:25:20.826790
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    bool_0 = has_any_callables(list_0)
    assert bool_0 is False
    bool_0 = has_any_callables(list_0, 'append')
    assert bool_0 is False
    bool_0 = has_any_callables(list_0, '__setitem__')
    assert bool_0 is False
    bool_0 = has_any_callables(list_0, 'append', '__setitem__')
    assert bool_0 is False
    bool_0 = has_any_callables(list_0, 'append', '__getitem__')
    assert bool_0 is False
    list_1 = [1, 2, 3]
    bool_0 = has_any_callables(list_1, 'append')
    assert bool_0 is True

# Generated at 2022-06-25 17:25:25.426740
# Unit test for function has_any_callables
def test_has_any_callables():
    a = dict(a=1, b=2)
    assert has_any_callables(a)
    assert not has_any_callables(a, 'foo')


# Generated at 2022-06-25 17:25:34.221647
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = ['a', 'b', 'c']
    bool_0 = has_any_callables(list_0)
    assert bool_0 == True



# Generated at 2022-06-25 17:25:40.241772
# Unit test for function has_callables
def test_has_callables():
    # TEST CASE # 0
    list_0 = []
    del list_0

    # TEST CASE # 1
    str_0 = 'hello'
    del str_0

    # TEST CASE # 2
    list_0 = [1, 2, 3]
    del list_0

    # TEST CASE # 3
    dict_0 = dict()
    del dict_0

    # TEST CASE # 4
    dict_0 = dict()
    del dict_0


# Generated at 2022-06-25 17:25:44.565378
# Unit test for function has_any_callables
def test_has_any_callables():
    import os
    import re
    import subprocess
    import sys
    import unittest

    from flutils.callutils import stderr

    def get_coverage(path='.'):
        pattern = re.compile(r"^\s+\d+(?:\.\d+)?%$")
        args = [sys.executable, '-m', 'coverage', 'report', '--omit', '*site-packages*']
        env = dict(os.environ, COVERAGE_FILE=os.path.join(path, '.coverage'))
        completed_process = subprocess.run(args, env=env, stdout=subprocess.PIPE)
        assert completed_process.returncode == 0

# Generated at 2022-06-25 17:25:53.789779
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(list(), '__contains__', '__getitem__')
    assert has_any_callables(set(), '__contains__', '__len__')
    assert has_any_callables(frozenset(), '__contains__', '__len__')
    assert has_any_callables(tuple(), '__contains__', '__len__')
    assert has_any_callables(deque(), '__contains__', '__iter__')
    assert has_any_callables(dict().keys(), '__contains__', '__iter__')
    assert has_any_callables(reversed([1, 2, 3]), '__next__', '__contains__')


# Generated at 2022-06-25 17:25:57.078212
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    bool_0 = has_any_callables(list_0)

# Testing has_any_callables unit test
if __name__ == '__main__':
    test_has_any_callables()
    test_case_0()

# Generated at 2022-06-25 17:26:03.056502
# Unit test for function has_callables
def test_has_callables():
    bool_0 = False
    # bool_0 = has_callables(
    #     obj=dict,
    #     attrs='get',
    #     attrs='keys',
    #     attrs='items',
    #     attrs='values'
    # )
    return bool_0


# Generated at 2022-06-25 17:26:09.986902
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    assert has_any_callables(list_0) == True
    list_0 = "hello"
    assert has_any_callables(list_0) == True
    list_0 = dict()
    assert has_any_callables(list_0) == False
    list_0 = dict(a=1, b=2)
    assert has_any_callables(list_0) == True
    assert has_any_callables(list_0, "foo") == False
    assert has_any_callables(list_0, "values") == True
    assert has_any_callables(list_0, "values", "items") == True
    assert has_any_callables(list_0, "values", "foo") == True
    list_0 = "hello".replace
    assert has

# Generated at 2022-06-25 17:26:16.908813
# Unit test for function has_callables
def test_has_callables():
    # This is a test to see if has_callables() will return True when a list is 
    # passed. It should return True since lists are callable.
    list = [1, 2, 3, 4]
    if has_callables(list) == True:
        print("This test has passed!")
    else:
        print("This test has failed!")


# Generated at 2022-06-25 17:26:21.102861
# Unit test for function has_callables
def test_has_callables():
    class A:
        def foo(self):
            """foo"""
        def bar(self):
            """bar"""
    class B:
        def foo(self):
            """foo"""
    assert has_callables(A(), 'foo', 'bar') == True
    assert has_callables(B(), 'foo', 'bar') == False
    assert has_callables(B(), 'foo') == True


# Generated at 2022-06-25 17:26:27.530899
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    dict_1 = dict(a=1, b=2)
    dict_2 = dict(a=(1, 2), b=(3, 4, 5))
    list_0 = list()
    list_1 = list([1, 2])
    set_0 = set()
    set_1 = set([1, 2])
    set_2 = set([1, 2, 3, 4, 5])
    tup_0 = tuple()
    tup_1 = tuple([1, 2])
    tup_2 = tuple([1, 2, 3, 4, 5])
    set_3 = frozenset()
    set_4 = frozenset([1, 2])
    set_5 = frozenset([1, 2, 3, 4, 5])
    deq_0 = deque()


# Generated at 2022-06-25 17:26:43.630321
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, "keys", "items", "values")
    assert not has_callables(obj, "keys", "items", "foo")


# Generated at 2022-06-25 17:26:45.043561
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(list_0) is False

# Generated at 2022-06-25 17:26:47.335104
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test case 0
    list_0 = []
    bool_0 = has_any_callables(list_0)

    assert bool_0 is False
    return


# Generated at 2022-06-25 17:26:50.018369
# Unit test for function has_callables
def test_has_callables():
    obj = list(([0, 3, 1, 2],))
    attrs = 'index', 'append', 'pop', 'remove', 'sort'
    assert has_callables(obj, *attrs) is True


# Generated at 2022-06-25 17:26:53.371015
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(list(), 'append') is True
    assert has_any_callables(list(), 'foo', 'bar') is False


# Generated at 2022-06-25 17:27:04.012208
# Unit test for function has_callables
def test_has_callables():
    # Tests that has_callables returns False when provided an empty iterable
    list_0 = []
    bool_0 = has_callables(list_0)
    if bool_0 != False:
        raise RuntimeError("has_callables failed to return False when provided an empty iterable")
    else:
        print("has_callables(empty iterable) test passed")
    # Tests that has_callables returns True when provided an iterable with only callable objects
    dict_0 = dict()
    dict_0["k0"] = dict
    dict_0["k1"] = lambda: print("Test lambda")
    dict_0["k2"] = "bar"
    bool_0 = has_callables(dict_0, "k0", "k1", "k2")
    if bool_0 != True:
        raise RuntimeError

# Generated at 2022-06-25 17:27:09.192498
# Unit test for function has_callables
def test_has_callables():
    # Test case 1
    # Ensure that the method returns True
    assert has_callables(dict(),'get','keys','items','values') == True

    # Test case 2
    # Ensure that the method returns False
    assert has_callables(dict(),'get','keys','items','foo') == False


# Generated at 2022-06-25 17:27:20.333689
# Unit test for function has_callables
def test_has_callables():
    import unittest
    from collections import UserList
    class test_has_callables(unittest.TestCase):
        def test_0(self):
            list_0 = []
            bool_0 = has_callables(list_0)
            self.assertTrue(bool_0)
            self.assertFalse(not bool_0)
        def test_1(self):
            set_0 = set()
            bool_0 = has_callables(set_0)
            self.assertTrue(bool_0)
            self.assertFalse(not bool_0)
        def test_2(self):
            tuple_0 = ()
            bool_0 = has_callables(tuple_0)
            self.assertTrue(bool_0)
            self.assertFalse(not bool_0)

# Generated at 2022-06-25 17:27:27.634772
# Unit test for function has_callables
def test_has_callables():
    set_0 = set([0])
    assert has_callables(set_0, '__add__', '__and__', '__contains__', '__len__', '__iter__', '__eq__', '__ne__', '__or__', '__rand__', '__rxor__', '__str__', '__sub__', '__xor__', 'add', 'clear', 'copy', 'difference', 'difference_update', 'discard', 'intersection', 'intersection_update', 'isdisjoint', 'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference', 'symmetric_difference_update', 'union', 'update')
    assert has_any_callables(set_0, '__add__', '__and__')

# Generated at 2022-06-25 17:27:30.432084
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(), 'pop', 'index', 'append') == True

