

# Generated at 2022-06-25 17:20:58.257815
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Test function has_any_callables.
    """
    # Test tuple
    t = (1, 2, 3)
    assert(has_any_callables(t, 'count'))
    assert(has_any_callables(t, 'index'))
    assert(not has_any_callables(t, 'foo'))
    assert(not has_any_callables(t, '__iter__'))
    assert(has_any_callables(t, '__contains__'))
    assert(not has_any_callables(t, 'foo', 'bar', 'baz'))
    assert(not has_any_callables(t, 'foo', 'count'))

    # Test list
    lst = [1, 2, 3]

# Generated at 2022-06-25 17:20:59.177537
# Unit test for function has_any_callables
def test_has_any_callables():
    set_0 = set()
    bool_0 = has_any_callables(set_0)


# Generated at 2022-06-25 17:21:10.057993
# Unit test for function has_callables
def test_has_callables():
    import unittest
    import random
    import collections as cl
    import string

    class HasCallablesTest(unittest.TestCase):
        def test_has_callables_with_empty(self):
            self.assertTrue(has_callables(cl.deque()))
            self.assertTrue(has_callables(cl.deque(), "__len__", "append"))

        def test_has_callables_with_uncallable_attrs(self):
            self.assertFalse(has_callables(random, "random"))
            self.assertTrue(has_callables(cl.deque(), "random"))

        def test_has_callables_with_callable_attrs(self):
            self.assertTrue(has_callables(cl.deque(), "__len__"))
            self.assertTrue

# Generated at 2022-06-25 17:21:21.743789
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict
    obj_1 = OrderedDict()
    assert has_any_callables(obj_1, '__contains__', '__getitem__', '__setitem__') is True
    obj_2 = dict()
    assert has_any_callables(obj_2, '__contains__', '__next__', '__setitem__') is True
    assert has_any_callables(dict(), 0, 1, 2) is False
    assert has_any_callables(bytes(), 'name', '__getitem__') is True
    assert has_any_callables(tuple(), '__contains__', 'foo', 'bar', 'name') is True
    assert has_any_callables([], '__contains__', 'foo', 'bar', 'name') is True
    assert has

# Generated at 2022-06-25 17:21:31.854255
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from typing import Any
    from types import MethodType
    from collections import Counter

    class Foo(dict):
        def foo(self: 'Foo') -> bool:
            return True
        def __call__(self: 'Foo') -> bool:
            return True

    foo: 'Foo' = Foo()
    foo_method = MethodType(foo.foo, foo)

    counter: 'Counter' = Counter()
    counter_method = MethodType(counter.most_common, counter)

    list_0: 'List[Any]' = list()
    list_1: 'List[Any]' = list([1, 2, 3])
    list_2: 'List[Any]' = list(map(lambda _i: _i, range(10)))
    dict_0 = dict()


# Generated at 2022-06-25 17:21:38.134501
# Unit test for function has_callables
def test_has_callables():
    items_dict_0 = {'a': 1}
    items_dict_1 = {'b': 2}
    items_dict_2 = {'c': 3}
    items_dict_3 = {'d': 4}
    items_dict_4 = {'e': 5}
    items_dict_5 = {'f': 6}
    items_dict_6 = {'g': 7}
    items_dict_7 = {'h': 8}
    items_dict_8 = {'i': 9}
    items_dict_9 = {'j': 10}

    assert has_callables(items_dict_0, '__contains__') is True
    assert has_callables(items_dict_1, '__contains__') is True

# Generated at 2022-06-25 17:21:41.283068
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict(a=1, b=2)
    assert has_callables(dict_0, 'get', 'keys') is True
    assert has_callables(dict_0, 'something', 'foo') is False


# Generated at 2022-06-25 17:21:48.012224
# Unit test for function has_callables
def test_has_callables():
    import math

    assert has_callables(math, 'cos', 'trunc')
    assert has_callables('hello world', 'split', 'strip')
    assert not has_callables('hello world', 'split', 'foo')
    assert not has_callables(dict(a=1, b=2), 'keys', 'foo')
    assert not has_callables(frozenset([1,2,3]), '__iter__', 'foo')
    assert not has_callables(iter('hello world'), '__iter__', 'foo')
    assert not has_callables([1, 2, 3], '__iter__', 'foo')
    assert not has_callables((1, 2, 3), '__iter__', 'foo')
    assert not has_callables({1, 2, 3}, '__iter__', 'foo')

# Generated at 2022-06-25 17:21:49.545941
# Unit test for function has_callables
def test_has_callables():
    import collections
    assert has_callables(collections.defaultdict())



# Generated at 2022-06-25 17:21:56.827625
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict({1:1, 2:2})
    assert has_any_callables(dict_0, 'keys'), 'has_any_callables'
    list_0 = list([1,2,3])
    assert not has_any_callables(list_0, 'keys', 'foo')



# Generated at 2022-06-25 17:22:06.618616
# Unit test for function has_any_callables
def test_has_any_callables():
    assert (has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True)
    assert (has_any_callables(dict(), 'foo', 'bar', 'baz', 'bang', 'zip') is False)


# Generated at 2022-06-25 17:22:11.742686
# Unit test for function has_callables
def test_has_callables():
    obj = dict(x=1)
    assert has_callables(obj, 'keys') is True
    assert has_callables(obj, 'foo') is False
    assert has_callables(obj, 'foo', 'bar', 'baz') is False


# Generated at 2022-06-25 17:22:16.207304
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    attrs = ['__class__', '__contains__']
    assert has_any_callables(obj, *attrs) is True


# Generated at 2022-06-25 17:22:22.936802
# Unit test for function has_any_callables
def test_has_any_callables():
    print('test_has_any_callables()')
    expected_result = True
    actual_result = has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert actual_result == expected_result
    assert type(actual_result) == bool
    print('test_has_any_callables() - PASSED')



# Generated at 2022-06-25 17:22:31.046010
# Unit test for function has_callables
def test_has_callables():
    # Test exception conditions
    assert has_callables(None) is False
    assert has_callables(1) is False
    assert has_callables('a') is False
    assert has_callables([1, 2, 3]) is False

    # Test None object
    assert has_callables(None, '__eq__') is False
    assert has_callables(None, '__ne__') is False

    # Test strings
    assert has_callables('', '__len__', '__eq__') is True
    assert has_callables('a', '__len__', '__eq__') is True
    assert has_callables('ab', '__len__', '__eq__') is True
    assert has_callables('abc', '__len__', '__eq__') is True

# Generated at 2022-06-25 17:22:32.676228
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    has_any_callables(set())


# Generated at 2022-06-25 17:22:35.297563
# Unit test for function has_any_callables
def test_has_any_callables():
    # Case 1:

    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-25 17:22:41.439305
# Unit test for function has_any_callables
def test_has_any_callables():
    # dict
    dict_0 = dict()
    assert has_any_callables(dict_0) is True
    assert has_any_callables(dict_0, 'clear', 'keys', 'values', 'items') is True
    assert has_any_callables(dict_0, 'clear', 'keys', 'values', 'items',
                                'get', 'something') is True
    assert has_any_callables(dict_0, 'clear', 'keys', 'values', 'items',
                             'something') is False

    # list
    list_0 = list()
    assert has_any_callables(list_0) is True
    assert has_any_callables(list_0, 'insert', 'keys', 'values', 'items') is False

# Generated at 2022-06-25 17:22:43.375416
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys') is True


# Generated at 2022-06-25 17:22:53.282769
# Unit test for function has_callables
def test_has_callables():
    set_0 = set()
    keys_0 = 'keys'
    items_0 = 'items'
    values_0 = 'values'
    foo_0 = 'foo'
    test_0 = has_callables(set_0, keys_0)
    test_1 = has_callables(set_0, keys_0, items_0)
    test_2 = has_callables(set_0, keys_0, items_0, values_0)
    test_3 = has_callables(set_0, keys_0, items_0, values_0, foo_0)
    test_4 = has_callables(set_0, keys_0, items_0, values_0, foo_0, foo_0)


# Generated at 2022-06-25 17:23:05.359360
# Unit test for function has_any_callables
def test_has_any_callables():
    import datetime
    print('TEST: function has_any_callables:')
    print('TEST: int: ', has_any_callables(1))
    print('TEST: str: ', has_any_callables('Hello World'))
    print('TEST: list: ', has_any_callables(['Hello', 'World']))
    print('TEST: tuple: ', has_any_callables(('Hello', 'World')))
    print('TEST: dict: ', has_any_callables({'Hello', 'World'}))
    print('TEST: set: ', has_any_callables({'Hello': 1, 'World': 2}))
    print('TEST: datetime: ', has_any_callables(datetime.datetime.now()))

# Generated at 2022-06-25 17:23:15.196337
# Unit test for function has_any_callables
def test_has_any_callables():
    # test if has_any_callables returns true if obj has any of the methods listed
    set_0 = set()
    bool_0 = has_any_callables(set_0, 'add', 'clear', 'copy', 'difference')
    assert bool_0 == True
    # if obj does not have any of the methods, it should return false
    set_1 = set()
    bool_1 = has_any_callables(set_1, 'foo', 'bar', 'baz', 'example')
    assert bool_1 == False


# Generated at 2022-06-25 17:23:27.310940
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values') is True
    assert has_any_callables(set(), 'intersection') is True
    assert has_any_callables(set(), 'get', 'keys', 'values') is False
    assert has_any_callables(set(), 'get') is False
    assert has_any_callables(set(), 'keys') is False
    assert has_any_callables(set(), 'values') is False
    assert has_any_callables(set(), 'intersection') is True
    assert has_any_callables(set(), 'foo') is False
    assert has_any_callables(frozenset(), 'get', 'keys', 'values') is False
    assert has_any_callables(frozenset(), 'intersection') is True

# Generated at 2022-06-25 17:23:34.830323
# Unit test for function has_callables
def test_has_callables():
    """ Test for has_callables
    """
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from flutils import objutils

    callables_0 = objutils.has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
    )
    assert callables_0 is True

    callables_1 = objutils.has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'foo',
    )
    assert callables_1 is False


# Generated at 2022-06-25 17:23:35.797178
# Unit test for function has_callables
def test_has_callables():
    pass



# Generated at 2022-06-25 17:23:39.516061
# Unit test for function has_any_callables
def test_has_any_callables():
    set_0 = set()
    bool_0 = has_any_callables(set_0, "")
    assert bool_0 == False

test_has_any_callables()


# Generated at 2022-06-25 17:23:44.116639
# Unit test for function has_callables
def test_has_callables():
    set_0 = set()
    bool_0 = has_callables(set_0, 'add')


# Generated at 2022-06-25 17:23:59.126655
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict()) is False
    assert has_callables(dict(), 'get', 'foo') is False
    assert has_callables(dict(), 'keys', 'foo') is False
    assert has_callables(dict(), 'values', 'foo') is False
    assert has_callables(dict(), 'items', 'foo') is False
    assert has_callables(dict(), '__len__', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'foo') is False
    assert has_callables(dict(), 'get', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'items', 'foo') is False
    assert has_callables(dict(), 'get', '__len__', 'foo') is False

# Generated at 2022-06-25 17:24:04.657148
# Unit test for function has_any_callables
def test_has_any_callables():
    """Tests for function ``has_any_callables``."""

    from flutils.objutils import has_any_callables

    obj = dict()

    bool_0 = has_any_callables(obj, 'get')
    assert bool_0 is True

    bool_0 = has_any_callables(obj, 'foo')
    assert bool_0 is False

    bool_0 = has_any_callables(obj, 'get', 'foo')
    assert bool_0 is True

    bool_0 = has_any_callables(obj, 'foo', 'bar')
    assert bool_0 is False


# Generated at 2022-06-25 17:24:09.860903
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(object(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables([], 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-25 17:24:21.423873
# Unit test for function has_callables
def test_has_callables():
    import pytest
    # Test case where obj has all attrs, each with a lambda function
    dict_0 = dict(a=1, b=2)
    result_0 =  has_callables(dict_0, 'update', 'copy', 'clear')
    assert result_0 is True
    result_1 =  has_callables(dict_0, 'update', 'copy', 'clear', 'keys')
    assert result_1 is True
    # Test case where obj has an attr but not a callable attribute
    # with that name
    result_2 =  has_callables(dict_0, 'update', 'copy', 'clear', 'keys', 'foo')
    assert result_2 is False
    # Test case where obj does not have an attr

# Generated at 2022-06-25 17:24:24.938782
# Unit test for function has_any_callables
def test_has_any_callables():
    # True case
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    # False case
    assert not has_any_callables(dict(),'foo','bar','baz')



# Generated at 2022-06-25 17:24:33.433727
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function :func: 'has_any_callables'"""
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something')
    missing = 'non_existing'
    assert not has_any_callables(obj, 'foo', missing)



# Generated at 2022-06-25 17:24:41.029992
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj = dict(a=1, b=2)
    assert has_any_callables(test_obj, 'get', 'keys', 'items', 'values')
    assert has_any_callables(test_obj, 'get', 'keys', 'items', 'something')
    assert has_any_callables(test_obj, 'get', 'keys', 'values', 'something')
    assert not has_any_callables(test_obj, 'foo', 'bar', 'baz', 'fizz')


# Generated at 2022-06-25 17:24:49.174363
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert True == has_any_callables(obj, 'pop', 'popitem', 'update')
    assert True == has_any_callables(obj, 'pop', 'popitem', 'update', 'foo')
    assert False == has_any_callables(obj, 'foo', 'baz')
    assert False == has_any_callables(obj)

    obj = [1, 2, 3]
    assert True == has_any_callables(obj, 'append', 'index', 'sort')
    assert True == has_any_callables(obj, 'append', 'index', 'sort', 'foo')
    assert False == has_any_callables(obj, 'foo', 'baz')
    assert False == has_any_callables(obj)


# Generated at 2022-06-25 17:25:01.750581
# Unit test for function has_callables
def test_has_callables():
    objs = [
        {'get': 1,
         'keys': 1,
         'items': 1,
         'values': 1,
         'something': 1},
        {'something': 1},
        {'something': 1, 'foo': 1},
        {'get': 1,
         'keys': 1,
         'items':1,
         'values': 1,
         'something': 1,
         'foo': 1
         }]
    attrs = ('get', 'keys', 'items', 'values', 'something', 'foo')

# Generated at 2022-06-25 17:25:06.829927
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    bool_0 = has_any_callables(list_0)



# Generated at 2022-06-25 17:25:08.277617
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = dict(foo=0)
    assert has_any_callables(obj_0, 'foo', 'bar', 'baz') is True



# Generated at 2022-06-25 17:25:12.896003
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('a string', 'index')
    assert not has_any_callables('a string', 'test', 'bogus')


# Generated at 2022-06-25 17:25:15.486657
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get','keys','items','values','foo') == True


# Generated at 2022-06-25 17:25:24.800092
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    dict_0['a'] = 1
    dict_0['b'] = 2
    dict_0['c'] = 3
    dict_0['d'] = 4
    dict_0['e'] = 5
    dict_0['f'] = 6

    assert has_callables(dict_0, 'a', 'b', 'c') is False
    assert has_callables(dict_0, 'items', 'keys', 'values') is True
    assert has_callables(dict_0, 'a', 'b', 'items') is True



# Generated at 2022-06-25 17:25:37.951835
# Unit test for function has_any_callables
def test_has_any_callables():
    list_1 = [1, 2, 3]
    bool_1 = has_any_callables(list_1, 'append')

    list_2 = [1, 2, 3]
    bool_2 = has_any_callables(list_2, 'append', 'bar')

    list_3 = [1, 2, 3]
    bool_3 = has_any_callables(list_3, 'bar')

    list_4 = [1, 2, 3]
    bool_4 = has_any_callables(list_4, 'bar', 'foo')

    list_5 = [1, 2, 3]
    bool_5 = has_any_callables(list_5, 'foo')

    list_6 = [1, 2, 3]

# Generated at 2022-06-25 17:25:51.971088
# Unit test for function has_callables
def test_has_callables():
    list_0 = []
    obj_0 = list()
    obj_1 = [1, 2, 3]
    obj_2 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    obj_3 = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    obj_4 = {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 6: 'f'}
    obj_5 = {1: 'a', 2: 'b', 3: 'c', 4: 'd', 5: 'e', 6: 'f', 7: 'g'}

# Generated at 2022-06-25 17:25:56.565624
# Unit test for function has_callables
def test_has_callables():
    list_0 = []
    bool_0 = has_callables(list_0)


# Generated at 2022-06-25 17:26:03.766108
# Unit test for function has_callables
def test_has_callables():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(list(), 'clear', 'extend', 'append', 'pop')
    assert has_callables(UserList(), 'clear', 'extend', 'append', 'pop')
    assert has_callables(UserString(), 'capitalize', 'casefold', 'count', 'endswith')
    assert has_callables(OrderedDict(), 'copy', 'get', 'keys', 'items', 'values')
    assert has_callables(deque(), 'append', 'appendleft', 'clear', 'extend', 'extendleft')

# Generated at 2022-06-25 17:26:10.770531
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []

    # Check that calling has_any_callables with no args returns false
    bool_0 = has_any_callables(list_0)

    # Check that calling has_any_callables with one arg returns false
    bool_0 = has_any_callables(list_0, "index")



# Generated at 2022-06-25 17:26:21.868928
# Unit test for function has_any_callables
def test_has_any_callables():
    # return True when no attributes passed
    assert has_any_callables(list())
    # return True if the callable is found
    assert has_any_callables([], '__copy__')
    # return False if the callable is not found
    assert not has_any_callables([], '__copy')
    # return True if any of the attribute is callable
    assert has_any_callables([], '__copy', '__copy__')
    # return False if any of the attribute is not callable
    assert not has_any_callables([], '__copy__', '__copy')
    # return False if None of the attributes are callable
    assert not has_any_callables([], '__copy', '__copy')
    # return False if None of the attributes are callable
    assert not has_any_callables

# Generated at 2022-06-25 17:26:29.258666
# Unit test for function has_callables
def test_has_callables():
    class TestClass(object):
        def __init__(self, foo: str):
            self.foo = foo

        def get_foo(self) -> str:
            return self.foo

    obj = TestClass("some value")
    v = has_callables(obj, "get_foo", "foo", "baz")
    assert v is True

# Generated at 2022-06-25 17:26:37.284411
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserDict
    from collections.abc import Mapping
    from collections.abc import MutableMapping
    from collections.abc import MutableSequence
    from collections.abc import MutableSet
    from collections.abc import Sequence
    from collections.abc import Set
    from collections.abc import Sequence
    from collections.abc import MutableSequence

    sequential_container_type = (
        List,
        Iterable,
        Sequence,
        MutableSequence,
        Set,
        MutableSet,
        Tuple
    )

    # Ensure no false positives are returned
    assert has_any_callables(
        sequential_container_type,
        'append',
        'foo',
        'bar'
    ) is False


# Generated at 2022-06-25 17:26:48.175242
# Unit test for function has_callables
def test_has_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
        deque,
        namedtuple,
    )
    from decimal import (
        Decimal,
    )
    from fractions import (
        Fraction,
    )
    from functools import (
        partial,
        reduce,
    )
    from itertools import (
        accumulate,
        chain,
        compress,
        count,
        cycle,
        dropwhile,
        filterfalse,
        groupby,
        islice,
        starmap,
        takewhile,
        tee,
        zip_longest,
    )

# Generated at 2022-06-25 17:26:56.276625
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    bool_0 = has_any_callables(list_0)


# Generated at 2022-06-25 17:27:03.238856
# Unit test for function has_callables
def test_has_callables():
    """Test for the function :func:`~has_callables`."""

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False  # noqa: E501
    assert has_callables(dict(k='v'), 'k', 'v') is False
    assert has_callables(dict(k='v'), 'k', 'v', 'values') is True



# Generated at 2022-06-25 17:27:06.890357
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_any_callables(dict(), 'foo') == False


# Generated at 2022-06-25 17:27:18.585116
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    tuple_0 = ()
    str_0 = ''
    bool_0 = has_any_callables(list_0, 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort')
    bool_1 = has_any_callables(tuple_0, 'count', 'index')

# Generated at 2022-06-25 17:27:26.067447
# Unit test for function has_any_callables
def test_has_any_callables():
    assert True == has_any_callables(dict(), 'get', 'keys', 'items', 'values')
#     assert False == has_any_callables(dict(), 'something')
    assert True == has_any_callables(dict(), 'keys', 'values')
#     assert True == has_any_callables(dict(), 'get', 'keys', 'items')
#     assert True == has_any_callables(dict(), 'keys')
#     assert False == has_any_callables(dict(), 'something')
#     assert True == has_any_callables(dict(), 'keys', 'values', 'something')
#     assert True == has_any_callables(dict(), 'something')


# Generated at 2022-06-25 17:27:35.231960
# Unit test for function has_any_callables
def test_has_any_callables():
    _ = has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    _ = has_any_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values')
    _ = has_any_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values',
                          'something')
    _ = has_any_callables(dict(a=1, b=2), 'something1', 'something2')
    _ = has_any_callables(int, 'something1', 'something2')


# Unit tests for function has_attrs.

# Generated at 2022-06-25 17:27:40.934092
# Unit test for function has_callables
def test_has_callables():
    obj_0 = 'Python'
    str_0: str = has_callables(obj_0)
    print(str_0)
    for attr in '0':
        if callable(getattr(obj_0, attr)) is True:
            # "attr" is callable
            print(attr)
        else:
            # "attr" is NOT callable
            print(attr)

# Generated at 2022-06-25 17:27:43.766201
# Unit test for function has_any_callables
def test_has_any_callables():
    # Arrange
    list_0 = []

    # Act
    ret = has_any_callables(list_0)

    # Assert
    assert ret


# Generated at 2022-06-25 17:27:52.853044
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test case 0
    list_0 = []
    obj = dict(a=1, b=2)
    bool_0 = has_any_callables(obj, 'keys', 'foo')
    assert bool_0 == True

    # Test case 1
    dict_0 = dict()
    dict_0['a'] = object()
    dict_0['b'] = object()
    dict_0['c'] = object()
    dict_0['d'] = object()
    dict_0['e'] = object()
    dict_0['f'] = object()
    dict_0['g'] = object()
    dict_0['h'] = object()
    dict_0['i'] = object()
    dict_0['j'] = object()
    dict_0['k'] = object()

# Generated at 2022-06-25 17:28:04.593613
# Unit test for function has_any_callables

# Generated at 2022-06-25 17:28:27.081290
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    bool_0 = has_any_callables(dict_0, '__iter__', '__repr__', '__dict__')
    assert bool_0 is True

    list_1 = []
    bool_1 = has_any_callables(list_1, '__iter__', '__repr__', '__dict__')
    assert bool_1 is True

    dict_1 = dict()
    bool_2 = has_any_callables(dict_1, '__iter__', '__repr__', '__dict__')
    assert bool_2 is True

    tuple_1 = (1, 2, 3)
    bool_3 = has_any_callables(tuple_1, '__iter__', '__repr__', '__dict__')

# Generated at 2022-06-25 17:28:35.880288
# Unit test for function has_any_callables
def test_has_any_callables():
    from pytest import mark, raises

    @mark.parametrize('attrs', [
        ['get', 'keys', 'items', 'values', 'something'],
        [],
    ])
    def test_case(attrs):
        obj = dict()
        if len(attrs) > 0:
            assert has_any_callables(obj, *attrs) is True
        else:
            with raises(TypeError) as excinfo:
                has_any_callables(obj)
            assert 'missing 1 required positional argument: \'attrs\'' in str(excinfo.value)

    test_case(['get', 'keys', 'items', 'values', 'something'])
    test_case([])



# Generated at 2022-06-25 17:28:46.992426
# Unit test for function has_any_callables
def test_has_any_callables():
    # Initialization
    obj_0 = dict()
    fun_0 = getattr(obj_0, "keys")
    fun_0(obj_0)
    # Function call
    fun_0 = has_any_callables(obj_0, "keys")
    fun_0 = has_any_callables(obj_0, "bar")
    fun_0 = has_any_callables(obj_0, "bar", "keys")
    # Boolean value
    fun_0_bool = fun_0
    # Output
    fun_0 = has_any_callables(obj_0)
    # Output
    fun_0 = has_any_callables(obj_0, "keys")
    # Output
    fun_0 = has_any_callables(obj_0, "bar")
    # Output
    fun_

# Generated at 2022-06-25 17:28:51.479629
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = [1, 2, 3]
    attrs = ('append', '__getitem__', '__len__', 'something')
    response = has_any_callables(obj, *attrs)
    assert response == True



# Generated at 2022-06-25 17:28:53.932900
# Unit test for function has_any_callables
def test_has_any_callables():
    list_1 = []
    assert has_any_callables(list_1) == False
    assert has_any_callables(list_1, 'append', 'pop') == True


# Generated at 2022-06-25 17:28:58.913385
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items') is True, 'AssertionError'
    assert has_any_callables(dict(), 'foo', 'get', 'keys', 'items') is True, 'AssertionError'
    assert has_any_callables(dict(), 'foo', 'bar') is False, 'AssertionError'
    assert has_any_callables(1, 'get') is False, 'AssertionError'



# Generated at 2022-06-25 17:29:02.377011
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert True == has_callables(obj, 'get', 'keys', 'items', 'values')


if __name__ == '__main__':
    test_case_0()
    test_has_callables()

# Generated at 2022-06-25 17:29:13.693564
# Unit test for function has_callables
def test_has_callables():
    import sys
    import os
    import unittest
    from collections import deque
    from collections.abc import Iterator, ValuesView, KeysView, UserList
    from fractions import Fraction
    from decimal import Decimal
    from pytest import raises, mark

    class mylist(list):
        def myfunc(self):
            pass
    class mydict(dict):
        def myfunc(self):
            pass
    class myset(set):
        def myfunc(self):
            pass
    class myfrozenset(frozenset):
        def myfunc(self):
            pass
    class mytuple(tuple):
        def myfunc(self):
            pass
    class mydeque(deque):
        def myfunc(self):
            pass

# Generated at 2022-06-25 17:29:17.002531
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj, 'foo') is False



# Generated at 2022-06-25 17:29:27.599254
# Unit test for function has_callables
def test_has_callables():
    # Test the function has_callables with tuple and list
    if has_callables(tuple, '__init__', '__add__'):
        print("Test 1 has callables for tuple passed")
    else:
        print("Test 1 has callables for tuple failed")
    # Test the function has_callables with dict and list
    if has_callables(list, 'pop', 'index'):
        print("Test 2 has callables for list passed")
    else:
        print("Test 2 has callables for list failed")
    # Test the function has_callables with dict and list
    if has_callables(dict, 'get', 'keys'):
        print("Test 3 has callables for dict passed")
    else:
        print("Test 3 has callables for dict failed")
    # Test the function has_callables with str

# Generated at 2022-06-25 17:29:53.374493
# Unit test for function has_callables
def test_has_callables():
    class Foo(object):
        def __getitem__(self, key):
            return key
    foo = Foo()
    assert has_callables(foo, '__getitem__') is True
    assert has_callables(foo, 'foo') is False


# Generated at 2022-06-25 17:29:57.588156
# Unit test for function has_any_callables
def test_has_any_callables():
    '''Unit test for has_any_callables'''
    assert(has_any_callables(dict(),'get','keys','items','values','foo') is True)
    assert(has_any_callables(dict(),'get','keys','items','values') is True)
    assert(has_any_callables(dict(),'get','keys','items','values','something') is True)
    list_0 = []
    assert(has_any_callables(list_0) is False)


# Generated at 2022-06-25 17:30:00.585923
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'foo', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', 'quux') is False


# Unit test function has_callables

# Generated at 2022-06-25 17:30:12.506824
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(), 'append') is True
    assert has_callables(dict(), 'keys') is True
    assert has_callables(set(), 'pop') is True
    assert has_callables(tuple(), 'index') is True
    assert has_callables(str(), 'capitalize') is True
    assert has_callables(dict(a=1), 'get') is True
    assert has_callables(list(range(3)), 'append') is True
    assert has_callables(set(range(3)), 'pop') is True
    assert has_callables(tuple(range(3)), 'index') is True
    assert has_callables('foo', 'capitalize') is True
    assert has_callables(str(range(3)), 'capitalize') is True


# Generated at 2022-06-25 17:30:17.126400
# Unit test for function has_callables
def test_has_callables():
    print('Testing function has_callables...')
    # args_0 = ('a', 'b', 'c')
    # result = has_attrs(list, *args_0)
    # print(f'result: {result}')
    print('Done testing function has_callables')


if __name__ == '__main__':
    test_case_0()
    test_has_callables()

# Generated at 2022-06-25 17:30:20.223512
# Unit test for function has_any_callables
def test_has_any_callables():
    d = {'a': 1, 'b': 2, 'c': 3}
    expected = True
    actual = has_any_callables(d, 'keys', 'values')
    assert expected == actual


# Generated at 2022-06-25 17:30:23.210358
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'keys', 'items', 'values', '__len__')


# Generated at 2022-06-25 17:30:30.804485
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict(foo=0)
    dict_1 = dict(foo=0, bar=1)
    dict_2 = dict()

    assert has_callables(dict_0, 'foo', 'bar') == False
    assert has_callables(dict_1, 'foo') == False
    assert has_callables(dict_1, 'foo', 'bar') == False

    assert has_callables(dict_1, 'get') == True
    assert has_callables(dict_2, 'get') == True
    assert has_callables(list(), 'get') == False
    #assert has_callables(dict_2, 'keys', 'get') == True



# Generated at 2022-06-25 17:30:32.192412
# Unit test for function has_callables
def test_has_callables():
    obj_0 = dict()
    assert has_callables(obj_0, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-25 17:30:41.284890
# Unit test for function has_any_callables
def test_has_any_callables():
    # Check if the given list-like object has any of the specified attributes
    # and any of the attributes are callable
    assert has_any_callables([], 'get', 'keys', 'items', 'values', 'foo')
    # Check if the given list-like object has any of the specified attributes
    # and any of the attributes are callable
    assert has_any_callables({}, 'get', 'keys', 'items', 'values', 'foo')
    # Check if the given list-like object has any of the specified attributes
    # and any of the attributes are callable
    assert has_any_callables(set(), 'get', 'keys', 'items', 'values', 'foo')
    # Check if the given list-like object has any of the specified attributes
    # and any of the attributes are callable
    assert has_any_callables