

# Generated at 2022-06-25 17:20:58.035206
# Unit test for function has_callables
def test_has_callables():
    # assert True == has_callables(list(), '__iter__', '__len__')
    # assert True == has_callables(dict(), '__getitem__', '__setitem__')
    assert True == has_callables(list(), '__iter__', '__len__')
    assert True == has_callables(dict(), '__getitem__', '__setitem__')
    assert True == has_callables(tuple(), '__getitem__', '__len__')
    assert True == has_callables(frozenset(), '__contains__', '__len__')
    assert True == has_callables(set(), '__contains__', '__len__')
    assert True == has_callables(UserList(), '__iter__', '__len__')

# Generated at 2022-06-25 17:21:04.838687
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('abc', 'upper')
    assert has_any_callables('abc', 'upper', 'foo')
    assert has_any_callables('abc', 'upper', 'foo', 'isalpha')
    assert has_any_callables('abc', 'isalpha', 'foo')
    assert has_any_callables('abc', 'isalpha')
    assert not has_any_callables('abc', 'foo')
    assert not has_any_callables('abc', 'foo', 'upper')


# Generated at 2022-06-25 17:21:08.180796
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict())



# Generated at 2022-06-25 17:21:13.155402
# Unit test for function has_attrs
def test_has_attrs():
    class FooClass(object):
        def __init__(self):
            self.a = 1
            self.b = 2

        def get_a(self):
            return self.a

    fc = FooClass()
    assert has_attrs(fc, 'a', 'b') is True
    assert has_attrs(fc, 'c') is False


# Generated at 2022-06-25 17:21:16.836105
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(dict(), 'foo', 'bar') is False


# Generated at 2022-06-25 17:21:27.814604
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserList
    obj = UserList()
    obj.something = 'foo'
    assert(has_any_attrs(obj, 'something'))
    assert(not has_any_attrs(obj, 'something_else'))
    assert(has_any_attrs(obj, 'something', 'something_else'))
    assert(not has_any_attrs(obj, 'something_else', 'something_else_else'))
    assert(has_any_attrs(obj, 'something_else', 'something'))
    assert(has_any_attrs(obj, 'something', 'something'))


# Generated at 2022-06-25 17:21:40.587936
# Unit test for function has_any_callables
def test_has_any_callables():
    # Packages
    import flutils.objutils
    from flutils.objutils import (
        has_any_callables
    )

    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_any_callables(set(), 'add', 'pop', 'clear', 'intersection', 'foo') is True
    assert has_any_callables(set(), 'add', 'pop', 'clear', 'intersection') is True
    assert has_any_callables(list(), 'append', 'pop', 'insert', 'foo') is True
    assert has_any_callables(list(), 'append', 'pop', 'insert') is True
    assert has_any_call

# Generated at 2022-06-25 17:21:46.495628
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import defaultdict
    # obj = {'a': 1, 'b': 2}
    # obj = [1, 2, 3]
    # obj = (1, 2, 3)
    # obj = set([1, 2, 3, 3, 3])
    # obj = frozenset([1, 2, 3, 3, 3])
    # obj = deque([1, 2, 3, 3, 3])
    # obj = Iterator([1, 2, 3, 3, 3])
    # obj = ValuesView({'a': 1, 'b': 2})
    # obj = KeysView({'a': 1, 'b': 2})
    # obj = UserList([1, 2, 3, 3, 3])
    # obj = bool
    # obj = bytes
    # obj = ChainMap
    # obj = Counter
   

# Generated at 2022-06-25 17:21:57.592256
# Unit test for function has_any_callables
def test_has_any_callables():
    fun = has_any_callables
    list_0 = []
    list_1 = has_any_callables(list_0, 'clear', 'pop', 'remove')
    list_2 = has_any_callables(list_0, 'pop', 'remove', 'foo')
    list_3 = has_any_callables(list_0, 'clear', 'pop', 'remove')
    list_4 = has_any_callables(list_0, 'foo', 'bar', 'baz')

    tuple_0 = ()
    tuple_1 = has_any_callables(tuple_0, 'index', 'count', 'foo')
    tuple_2 = has_any_callables(tuple_0, 'index', 'count', 'foo')

    set_0 = set()
    set_1 = has_any

# Generated at 2022-06-25 17:22:11.206108
# Unit test for function has_any_callables
def test_has_any_callables():
    from datetime import datetime
    from flutils.objutils import is_list_like, has_any_callables, has_attrs
    bool_1 = False
    bool_2 = not bool_1
    bool_3 = has_any_callables(bool_1)
    bool_4 = has_attrs(bool_1, 'denominator')
    bool_5 = not bool_4
    bool_6 = has_any_callables(bool_1, 'imag')
    bool_7 = has_any_callables(bool_1, 'real')

    bool_8 = is_list_like(bool_1)
    bool_9 = has_any_callables(bool_1, 'imag', 'real')

    # is_list_like(bool_1)

    # bool_2 = bool_1

# Generated at 2022-06-25 17:22:21.892161
# Unit test for function has_any_callables
def test_has_any_callables():
    def func():
        pass

    assert has_any_callables(func, '__class__', '__dict__', '__call__')
    assert has_any_callables(1, '__class__', '__dict__', '__call__') is False
    assert has_any_callables(1, '__class__', '__dict__') is False
    assert has_any_callables(1, '__class__') is False
    assert has_any_callables(1) is False
    assert has_any_callables(list(), '__class__', '__dict__', '__call__') is False
    assert has_any_callables(list(), '__class__', '__dict__', 'append')
    assert has_any_callables(list(), '__class__', '__dict__')

# Generated at 2022-06-25 17:22:28.438713
# Unit test for function has_attrs
def test_has_attrs():
    test_dict = dict(a=1, b=2, c=3)
    assert has_attrs(test_dict, "items", "keys", "values", "copy")
    assert not has_attrs(test_dict, "foo", "bar", "zar")
    assert not has_attrs(test_dict, "__contains__", "items")
    assert not has_attrs(test_dict, "__contains__", "keys", "items")
    assert not has_attrs(test_dict, "__contains__", "values", "items")


# Generated at 2022-06-25 17:22:40.442156
# Unit test for function has_any_callables
def test_has_any_callables():
    import unittest

    class HasAnyCallablesTestCase(unittest.TestCase):

        def test_case_0(self):
            bool_0 = False
            bool_1 = has_any_callables(bool_0)
            self.assertTrue(bool_1 is False)

        def test_case_1(self):
            bool_0 = False
            bool_1 = has_any_callables(bool_0, '__init__', '__str__', 'foo')
            self.assertTrue(bool_1 is False)

        def test_case_2(self):
            bool_0 = False
            bool_1 = has_any_callables(bool_0, '__init__', '__getitem__', 'foo')
            self.assertTrue(bool_1 is True)


# Generated at 2022-06-25 17:22:50.014732
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test has_any_attrs returns True for the appropriate inputs."""
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_attrs(dict(), 'get')
    assert has_any_attrs(dict(), 'keys')
    assert has_any_attrs(dict(), 'items')
    assert has_any_attrs(dict(), 'values')
    assert not has_any_attrs(dict(), 'something')
    assert has_any_attrs(dict(), 'get', 'keys', 'foo')


# Generated at 2022-06-25 17:22:53.480383
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-25 17:22:56.969538
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    obj1 = object()
    assert not has_any_callables(obj1)


# Generated at 2022-06-25 17:23:06.056031
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    from collections.abc import Mapping
    from datetime import date
    from operator import getitem
    from typing import (
        Any,
        Callable,
        Dict,
        List,
        Tuple,
        Union,
    )
    from uuid import uuid1

    def test_has_callables(
            obj: Any,
            attrs: List[str],
            is_callable: bool,
        ) -> None:
        """Helper function for testing the ``has_callables`` function."""
        # noinspection PyPep8Naming

# Generated at 2022-06-25 17:23:15.522669
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test case 1
    assert(has_any_callables(dict(),'get','keys','items','values','foo') == True)
    assert(has_any_callables(dict(),'foo','bar') == False)

    # Test case 2
    output_list_1 = [1]
    assert(has_any_callables(output_list_1, 'append','clear','extend','foo') == True)
    assert(has_any_callables(output_list_1, 'foo','bar') == False)


# Generated at 2022-06-25 17:23:20.156885
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'keys', 'values')
    assert not has_callables(dict, 'keys', 'values', 'foo')



# Generated at 2022-06-25 17:23:32.567263
# Unit test for function has_any_attrs
def test_has_any_attrs():
    test_cases = (
        dict(obj=dict(), args=('get','keys','items','values'), res=True),
        dict(obj=dict(), args=('foo',), res=False),
        dict(obj=dict(), args=('foo', 'bar'), res=False),
    )
    for test_case in test_cases:
        obj, args, res = test_case['obj'], test_case['args'], test_case['res']
        if has_any_attrs(obj, *args) != res:
            print(obj, args, res)
            raise AssertionError('failed test_has_any_attrs')



# Generated at 2022-06-25 17:23:41.337986
# Unit test for function has_attrs
def test_has_attrs():
    obj = ''
    assert has_attrs(obj, 'zfill') is True
    assert has_attrs(obj, 'zfill', 'join') is True
    assert has_attrs(obj, 'zfill', 'filling') is False
    assert has_attrs(obj, 'zfill', 'join', 'filling') is False
    assert has_attrs(obj, '') is True
    assert has_attrs(obj, '') is True
    assert has_attrs(obj, '') is True


# Generated at 2022-06-25 17:23:47.891437
# Unit test for function has_callables
def test_has_callables():
    var = dict()
    func = lambda x: None
    assert has_callables(var, 'get', 'items') == True
    assert has_callables(var, 'get', 'foo') == False
    assert has_callables(var, 'foo', 'bar') == False
    assert has_callables(func, '__call__') == True
    assert has_callables(var, '__call__') == False



# Generated at 2022-06-25 17:23:59.618698
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from typing import Any as _Any
    #
    # Test 0
    #
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values')

    #
    # Test 1
    #
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', '__getitem__')

    #
    # Test 2
    #
    obj = dict(a=1, b=2)

# Generated at 2022-06-25 17:24:01.340598
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(True) is True


# Generated at 2022-06-25 17:24:12.055348
# Unit test for function has_callables
def test_has_callables():
    class _A(object):
        def callable_0(self, arg0: str) -> str:  # pragma: no cover
            return arg0

    class _B(object):
        def not_callable_0(self, arg0: str) -> str:  # pragma: no cover
            return arg0

        @staticmethod
        def not_callable_1(arg0: str) -> str:  # pragma: no cover
            return arg0

        @classmethod
        def callable_1(cls, arg0: str) -> str:  # pragma: no cover
            return arg0

    assert has_callables(_A(), 'callable_0') is True
    assert has_callables(_B(), 'callable_1') is True

# Generated at 2022-06-25 17:24:23.277382
# Unit test for function has_any_callables
def test_has_any_callables():
    from unittest import TestCase
    from unittest import mock
    from unittest import skip

    # Skip test if on Windows
    if os.name == 'nt':
        skip('Unable to test on Windows')

    import flutils

    def a():
        pass

    def b():
        pass

    def c():
        pass

    class Test(object):
        def __init__(self):
            self.a = a
            self.b = b
            self.c = c

    _res = flutils.objutils.has_any_callables(Test(), 'a', 'b', 'c')
    assert _res is True, 'has_any_callables failed to correctly handle {}'.format(_res)


# Generated at 2022-06-25 17:24:29.663839
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj = {
        'get': lambda: [],
        'foo': []
    }
    assert has_any_callables(test_obj, 'get', 'foo') is True
    assert has_any_callables(test_obj, 'get', 'foo', 'bar') is True
    assert has_any_callables(test_obj, 'bar', 'baz') is False


# Generated at 2022-06-25 17:24:33.145058
# Unit test for function has_any_callables
def test_has_any_callables():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-25 17:24:43.112484
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(None) == False
    assert has_any_callables(False) == False
    assert has_any_callables(list()) == False
    assert has_any_callables(list(),'append') == False
    assert has_any_callables(list(),'append', 'index') == True
    assert has_any_callables(list(),'append', 'index', 'foo') == True
    assert has_any_callables(tuple()) == False
    assert has_any_callables(tuple(),'foo') == False
    assert has_any_callables(set()) == False
    assert has_any_callables(dict()) == False
    assert has_any_callables(dict(),'foo') == False
    assert has_any_callables('hello') == False
    assert has_any

# Generated at 2022-06-25 17:24:45.874061
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something') == True
    assert has_any_callables(dict(a=1),'get','keys','items','values','something') == True


# Generated at 2022-06-25 17:24:58.691164
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('a', 'isalpha') is True
    assert has_any_callables('', 'isalpha') is True
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items') is True
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items', 'foo') \
        is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_callables(list(), 'append', 'extend', 'clear', 'foo') is \
        True


# Generated at 2022-06-25 17:25:08.273850
# Unit test for function has_any_callables
def test_has_any_callables():
    """ Check if the function has_any_callables works as expected. """
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'__getitem__','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','foo','items','values') is True
    assert has_any_callables(dict(),'get','keys','items','foo','values') is True
    assert has_any_callables(dict(),'get','foo','items','values') is True
    assert has_any_callables(dict(),'get','keys','foo','values') is True
    assert has_any_callables(dict(),'foo','keys','items','values') is True

# Generated at 2022-06-25 17:25:21.120626
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict
    from itertools import chain
    from operator import getitem
    from typing import Any
    from typing import Callable
    from typing import Dict
    from typing import Generator
    from typing import Iterator
    from typing import List
    from typing import Set
    from typing import Tuple
    from typing import Type
    from typing import Union
    import decimal
    import pytest
    from flutils.objutils import has_any_callables

    _CALLABLE = (
        Callable,
        decimal.Decimal,
        dict,
        float,
        int,
        list,
        str,
    )


# Generated at 2022-06-25 17:25:31.604085
# Unit test for function has_attrs
def test_has_attrs():
    # create a list of attributes to check for
    attr_list = ['__eq__', '__ge__', '__gt__', '__le__', '__lt__', '__ne__']

    # create a string
    a = 'test'

    # check that a has the attributes in attr_list
    assert has_attrs(a, *attr_list) is True



# Generated at 2022-06-25 17:25:35.065344
# Unit test for function has_callables
def test_has_callables():
    f = open('test.txt', 'w')
    bool_0 = has_callables(f, 'seek', 'tell')
    f.close()


# Generated at 2022-06-25 17:25:39.295149
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = [1, 2, 3]
    bool_0 = has_any_callables(obj, 'append')
    assert bool_0 is True
    bool_1 = has_any_callables(obj, 'remove')
    assert bool_1 is False

# Unit test function has_attrs

# Generated at 2022-06-25 17:25:45.972631
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', '__eq__') is True
    assert has_any_callables(dict(), '__eq__', '__ne__') is False
    assert has_any_callables(dict(), '__eq__', '__add__') is False
    assert has_any_callables({}, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables({}, 'get', 'keys', 'items', 'values', 'foo', '__eq__') is True
    assert has_any_callables({}, '__eq__', '__ne__') is False
    assert has_

# Generated at 2022-06-25 17:25:56.208127
# Unit test for function has_any_callables
def test_has_any_callables():
    # test for type list
    list_0 = [1, 2, 3]
    assert has_any_callables(list_0, "pop", "extend", "sort", "lower") == True
    assert has_any_callables(list_0, "pop", "extend", "sort") == True
    assert has_any_callables(list_0, "pop", "extend") == True
    assert has_any_callables(list_0) == True
    assert has_any_callables(list_0, "toto") == False

    # test for type int
    int_0 = 1
    assert has_any_callables(int_0, "bit_length", "bit_length") == True
    assert has_any_callables(int_0) == True

# Generated at 2022-06-25 17:26:03.857691
# Unit test for function has_callables
def test_has_callables():
    parent_obj = [1, 2, 3]
    parent_obj_clone = []
    # Create a subclass of the list class
    class my_list(list):
        pass
    parent_obj_clone = my_list()
    parent_obj_clone.extend(parent_obj)
    # Evaluate the test case
    assert has_callables(parent_obj_clone, 'extend') == True


# Generated at 2022-06-25 17:26:11.204827
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','keys','items','values','foo') is False
    assert has_attrs('spam','upper','lower','capitalize','__repr__') is True
    assert has_attrs('spam','upper','lower','capitalize','foo') is False



# Generated at 2022-06-25 17:26:20.410968
# Unit test for function has_any_callables
def test_has_any_callables():
    # Check True case 1
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    # Check True case 2
    assert has_any_callables(dict(),'get','keys','items','values')
    # Check True case 3
    assert has_any_callables(dict(),'get')
    assert not has_any_callables(dict(),'foobar')
    assert not has_any_callables(dict(),)


# Generated at 2022-06-25 17:26:23.775732
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(), 'append', 'insert', 'remove', 'pop') is True
    assert has_callables(set(), 'add', 'pop', 'remove', 'discard') is True
    assert has_callables(tuple(), 'index', 'count') is False



# Generated at 2022-06-25 17:26:26.325863
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = False
    bool_1 = has_any_callables(bool_0)
    assert bool_1 == False


# Generated at 2022-06-25 17:26:35.533017
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import (
        has_any_callables,
        has_any_attrs,
        has_callables,
        has_attrs,
        is_list_like,
    )
    result = has_any_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'foo'
    )
    assert result is True
    result = has_any_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
    )
    assert result is True
    result = has_any_callables(
        dict(),
        'get',
        'foo',
    )
    assert result is False



# Generated at 2022-06-25 17:26:46.899515
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from flutils.objutils import (
        has_any_callables,
        has_callables,
        has_any_attrs,
        has_attrs,
        is_list_like,
    )

# Generated at 2022-06-25 17:26:47.789006
# Unit test for function has_any_callables
def test_has_any_callables():
    pass



# Generated at 2022-06-25 17:26:50.190644
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = False
    assert has_any_callables(bool_0) == False


# Generated at 2022-06-25 17:26:56.125507
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = float('nan')
    float_1 = has_any_callables(float_0, '__len__', '__bool__', '__float__')
    float_2 = float_1
    float_3 = has_any_callables(float_2)


# Generated at 2022-06-25 17:27:04.887763
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Test class example
    """
    class TestClass:
        attr_1 = None
        def func_1(self):
            pass
    obj_1 = TestClass()
    assert has_any_callables(obj_1, 'attr_1', 'func_1', 'func_2') is False
    assert has_any_callables(obj_1, 'attr_1', 'func_2', 'func_1') is False
    assert has_any_callables(obj_1, 'func_1') is True
    assert has_any_callables(obj_1, 'func_2') is False
    assert has_any_callables(obj_1) is False
    assert has_any_callables(1) is False
    assert has_any_callables(None) is False
    assert has_any

# Generated at 2022-06-25 17:27:07.954752
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = has_any_callables(bool, "bit_length", "denominator", "from_bytes")
    assert bool_0 is True



# Generated at 2022-06-25 17:27:19.804354
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'something') == False
    assert has_callables(dict, 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict, 'get', 'keys', 'items', 'values', 'something') == False
    assert has_callables(dict, '__init__', '__new__', '__dict__') == True
    assert has_callables(dict, '__init__', '__new__', '__setattr__') == False


# Generated at 2022-06-25 17:27:27.369605
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), "get", "keys", "items", "values", "foo") \
        is True
    assert has_any_callables(
        dict(), "get", "keys", "items", "values", "__iter__"
    ) is True
    assert has_any_callables(dict(), "keys", "items", "values", "__iter__") \
        is True
    assert has_any_callables(dict(), "get", "items", "values", "__iter__") \
        is True
    assert has_any_callables(dict(), "get", "keys", "values", "__iter__") is True
    assert has_any_callables(dict(), "get", "keys", "items", "__iter__") is True

# Generated at 2022-06-25 17:27:30.520422
# Unit test for function has_any_callables
def test_has_any_callables():
    """Checks whether the function works properly"""
    assert has_any_callables(list(),'pop', 'remove', 'count')


# Generated at 2022-06-25 17:27:41.050511
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables"""
    d_0 = dict()
    d_1 = dict()
    f_0 = lambda: None
    f_1 = lambda: None
    t_0 = (1,2,3)
    t_1 = tuple(range(10))
    t_2 = tuple([{'a': 1}, {'b': 2}])
    l_0 = list()
    l_1 = [1, 2, 3]
    l_2 = [{'a': 1}, {'b': 2}]
    assert has_any_callables(None) is False
    assert has_any_callables(d_0, '__iter__', '__len__', 'foo') is True

# Generated at 2022-06-25 17:27:45.881165
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something') is True
    assert has_any_callables(dict(),'get','keys','items','values','__str__') is True
    assert has_any_callables(dict(),'get','keys','items','values','_str__') is False


# Generated at 2022-06-25 17:27:48.672751
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict(a=1, b=2)
    bool_0 = has_callables(dict_0, 'items', 'foo')


# Generated at 2022-06-25 17:27:59.804740
# Unit test for function has_any_callables
def test_has_any_callables():
    assert False == has_any_callables(None)
    assert True == has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert False == has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert True == has_any_callables(dict(), 'clear')
    assert True == has_any_callables(dict(), 'get')
    assert True == has_any_callables(dict(), 'items')
    assert True == has_any_callables(dict(), 'keys')
    assert True == has_any_callables(dict(), 'pop')
    assert True == has_any_callables(dict(), 'popitem')
    assert True == has_any_callables(dict(), 'values')


# Generated at 2022-06-25 17:28:09.125285
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), *('get', 'keys', 'items', 'value'))
    assert has_any_callables(list(), *('append', 'extend', 'insert', 'foo'))
    assert has_any_callables(set(), *('add', 'update', 'clear', 'foo'))
    assert has_any_callables(
            frozenset(),
            *('add', 'update', 'clear', 'foo')
    ) is False
    assert has_any_callables(tuple(), *('foo', 'update', 'clear', 'append'))
    assert has_any_callables(deque(), *('append', 'extend', 'insert', 'foo'))
    assert has_any_callables(Iterable) is False

# Generated at 2022-06-25 17:28:10.722473
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = False
    bool_1 = has_any_callables(bool_0)
    print(bool_1)


# Generated at 2022-06-25 17:28:15.866074
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    >>> from flutils.objutils import has_any_callables
    >>> has_any_callables(dict())
    False
    >>> has_any_callables(dict(),'get','keys','items','values','foo')
    True
    """
    pass



# Generated at 2022-06-25 17:28:19.642272
# Unit test for function has_callables
def test_has_callables():
    bool_0 = False
    bool_1 = has_callables(bool_0)



# Generated at 2022-06-25 17:28:22.908712
# Unit test for function has_callables
def test_has_callables():
    myList = []
    assert has_callables(myList, "append")
    assert not has_callables(myList, "someMethod")


# Generated at 2022-06-25 17:28:33.737350
# Unit test for function has_callables
def test_has_callables():
    class Callables:
        def func_a(self):
            pass

        def func_b(self, param):
            pass

        def func_c(self, param_a, param_b):
            pass

    class NonCallables:
        def func_a(self):
            pass

        def func_b(self, param):
            pass

        def func_c(self, param_a, param_b):
            pass

    assert has_callables(Callables(), 'func_a', 'func_b', 'func_c')

    assert has_callables(Callables(), 'func_a', 'func_b')
    assert has_callables(Callables(), 'func_b', 'func_c')
    assert has_callables(Callables(), 'func_a', 'func_c')

    assert has_call

# Generated at 2022-06-25 17:28:35.278610
# Unit test for function has_callables
def test_has_callables():
    bool_0 = False
    bool_1 = has_callables(bool_0)


# Generated at 2022-06-25 17:28:41.603896
# Unit test for function has_callables
def test_has_callables():
    class plop:
        pass

    class plop2(plop):
        opacity = 3.14

        def __init__(self, a: float = 0.0, b: float = 0.0):
            self.a = a
            self.b = b

        def __call__(self):
            pass

        def __str__(self):
            return 'a = {}, b = {}'.format(self.a, self.b)

        def __repr__(self):
            return '{}: {{a: {}, b: {}}}'.format(self.__class__.__name__,
                                                 self.a,
                                                 self.b)

        def __add__(self, other):
            if not isinstance(other, self.__class__):
                raise TypeError('You cannot sum these types')

# Generated at 2022-06-25 17:28:46.032977
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables.

    :returns: None

    """
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-25 17:28:49.923056
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values')



# Generated at 2022-06-25 17:28:55.558130
# Unit test for function has_any_callables
def test_has_any_callables():
    # dict with keys, values and items
    dict_0 = dict(a=1, b=2, c=3)
    assert has_any_callables(
        dict_0,
        'keys',
        'values',
        'items'
    ) is True

    # dict with keys and items
    dict_1 = dict(a=1, b=2)
    assert has_any_callables(
        dict_1,
        'keys',
        'values',
        'items'
    ) is True


# Generated at 2022-06-25 17:28:59.021659
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(reversed([1, 2, 3]),'next') is True
    assert has_callables(set(),'add','pop') is True


# Generated at 2022-06-25 17:29:10.433283
# Unit test for function has_callables
def test_has_callables():
    from collections.abc import Iterator
    from collections import ChainMap
    from inspect import signature
    from typing import Mapping
    from pprint import pformat
    import doctest


# Generated at 2022-06-25 17:29:14.802722
# Unit test for function has_any_callables
def test_has_any_callables():
    counter_obj = Counter()
    assert has_any_callables(counter_obj) is True


# Generated at 2022-06-25 17:29:16.666672
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = False
    bool_1 = has_any_callables(bool_0)


# Generated at 2022-06-25 17:29:20.469902
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values')
    assert has_callables(obj, 'keys') is False
    assert has_callables(obj, 'foo') is False



# Generated at 2022-06-25 17:29:24.467171
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(list(),'get','keys','items','values','foo') == False


# Generated at 2022-06-25 17:29:32.385209
# Unit test for function has_any_callables
def test_has_any_callables():

    # no args
    assert has_any_callables() is False

    # dict
    _dict = dict(a=1, b=2, c=3)
    assert has_any_callables(_dict, 'item', 'keys', 'get') is True
    assert has_any_callables(_dict, 'foo', 'bar', 'baz') is False

    # defaultdict
    from collections import defaultdict
    _ddict = defaultdict(int, foo=1, bar=2, baz=3)
    assert has_any_callables(_ddict, 'foo', 'bar', 'baz') is True
    assert has_any_callables(_ddict, 'foobar', 'barbaz', 'bazfoo') is False

    # UserDict
    from collections import UserDict
    _udict = UserDict

# Generated at 2022-06-25 17:29:39.206418
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict(a=1, b=2)
    dict_1 = dict(a=1, b=2, items=dict_0.items)
    assert has_callables(dict_0, 'items') is False
    assert has_callables(dict_1, 'items') is True
    assert has_callables(dict_1, 'keys', 'items', 'values') is True



# Generated at 2022-06-25 17:29:47.314499
# Unit test for function has_callables
def test_has_callables():
    my_dict = {'a':1, 'b':2, 'c':3}
    # Test that all attrs exist, and are callable
    assert(has_callables(my_dict, 'get', 'keys', 'values') is True)
    # Test a non-callable attr (missing values)
    assert(has_callables(my_dict, 'get', 'keys') is False)
    # Test for a missing attr
    assert(has_callables(my_dict, 'get', 'keys', 'values', 'foo') is False)
    # Test for a str
    assert(has_callables('hello', 'get', 'keys', 'values') is False)
    # Test for a int
    assert(has_callables(1, 'get', 'keys', 'values') is False)
    # Test for

# Generated at 2022-06-25 17:29:52.160293
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(UserList(), 'pop', 'insert', 'append', 'foo') is False
    assert has_callables([], 'pop', 'insert', 'append', 'foo') is False
    # noinspection PyTypeChecker
    assert has_callables(10, 'foo') is False



# Generated at 2022-06-25 17:29:56.277363
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test is done on list object
    lst = [3, 5, 1, 2, 4]
    # Test for function callable and test for function that does not exist
    assert has_any_callables(lst, 'append', 'foo')
    # Function that does not exist in the object
    assert not has_any_callables(lst, 'bar')


# Generated at 2022-06-25 17:30:00.510802
# Unit test for function has_callables
def test_has_callables():
    # test successful
    obj = bool
    assert has_callables(obj, '__bool__', '__bool__') is True

    # test failure
    obj = float
    assert has_callables(obj, '__bool__', '__bool__') is False

    # test unsuccessful
    obj = int
    assert has_callables(obj, '__bool__', '__bool__') is False



# Generated at 2022-06-25 17:30:15.304612
# Unit test for function has_callables
def test_has_callables():
    # Test: dict
    dict_obj = dict(a=1, b=2)
    bool_0 = has_callables(dict_obj, 'get', 'keys', 'items', 'values')
    # Test: frozenset
    frozenset_obj = frozenset(dict_obj.items())
    bool_1 = has_callables(frozenset_obj, '__contains__')
    # Test: list
    list_obj = list(dict_obj.items())
    bool_2 = has_callables(list_obj, 'append', 'clear', 'count')
    # Test: set
    set_obj = set(dict_obj.keys())
    bool_3 = has_callables(set_obj, 'add', 'clear', 'difference', 'issubset')
    # Test: tuple


# Generated at 2022-06-25 17:30:17.666219
# Unit test for function has_any_callables
def test_has_any_callables():
    l = ['test', '1', '2', '3']
    assert has_any_callables(l, 'append', 'get', 'iter', 'do_something')



# Generated at 2022-06-25 17:30:27.707372
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'value') is False
    assert has_callables(dict(), 'get', 'keys', 'ite', 'values') is False
    assert has_callables(dict(), 'get', 'keys', 'ite', 'value') is False
    assert has_callables(dict(), 'get', 'key', 'items', 'values') is False

# Generated at 2022-06-25 17:30:35.068947
# Unit test for function has_any_callables
def test_has_any_callables():
    test_list = [
        {
            "description":
            "Test has_any_callables with a callable and a non-callable.",
            "inputs":
            [dict([("foo", lambda x:x), ("bar", "string")]), ("foo", "bar")],
            "assertions":
            [lambda x: x is True],
            "cleanup":
            []
        },
        {
            "description":
            "Test has_any_callables with a callable and a non-callable.",
            "inputs":
            [dict([("foo", "bar"), ("bar", "string")]), ("foo", "bar")],
            "assertions":
            [lambda x: x is False],
            "cleanup":
            []
        }
    ]

    return test_list



# Generated at 2022-06-25 17:30:45.891983
# Unit test for function has_callables
def test_has_callables():
    obj_0 = dict(
        a=1,
        b=2,
    )
    obj_1 = dict()
    attrs_0 = 'get', 'keys', 'items', 'values'
    attrs_1 = 'foo'
    attrs_2 = 'get', 'keys', 'items', 'foo'
    attrs_3 = 'foo', 'bar'
    bool_0 = False
    bool_1 = has_callables(obj_0, *attrs_0)
    bool_2 = has_callables(obj_0, *attrs_1)
    bool_3 = has_callables(obj_0, *attrs_2)
    bool_4 = has_callables(obj_0, *attrs_3)