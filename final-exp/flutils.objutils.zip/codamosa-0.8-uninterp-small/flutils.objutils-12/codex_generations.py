

# Generated at 2022-06-25 17:20:52.477025
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1,b=2)
    assert has_callables(obj, 'keys', 'items') is True
    assert has_callables(obj, 'get', 'keys') is False


# Generated at 2022-06-25 17:20:53.474035
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()


# Generated at 2022-06-25 17:21:00.872383
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList, ChainMap, Counter, OrderedDict
    from collections import UserDict, UserString, defaultdict
    from decimal import Decimal


# Generated at 2022-06-25 17:21:14.988965
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(list(), 'get', 'keys', 'items', 'values') is False
    assert has_any_attrs(tuple(), 'get', 'keys', 'items', 'values') is False
    assert has_any_attrs(set(), 'get', 'keys', 'items', 'values') is False
    assert has_any_attrs(frozenset(), 'get', 'keys', 'items', 'values') is False
    assert has_any_attrs(dict(), 'something') is False
    assert has_any_attrs(list(), 'something') is False
    assert has_any_attrs(tuple(), 'something') is False

# Generated at 2022-06-25 17:21:29.012537
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print("---- test_has_any_attrs ----")
    # list
    if has_any_attrs(list(), 'append', ' extends', 'something'):
        print('    - [PASS] exists')
    else:
        print('    - [FAIL] exists')
    # dict
    if has_any_attrs(dict(), 'keys', 'append', 'something'):
        print('    - [PASS] exists')
    else:
        print('    - [FAIL] exists')
    # anything
    if has_any_attrs(42, 'keys', 'append', 'something'):
        print('    - [FAIL] does not exist')
    else:
        print('    - [PASS] does not exist')


# Generated at 2022-06-25 17:21:37.767696
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test for IOError
    try:
        assert has_any_attrs(IOError, 'args', 'errno', 'strerror')
        assert has_any_attrs(IOError, 'args', 'errno', 'strerro') is False
    except:
        raise Exception('Unexpected exception raised')

    # Test for float
    try:
        assert has_any_attrs(float, 'as_integer_ratio', 'conjugate', 'denominator')
        assert has_any_attrs(float, 'as_integer_ratio', 'conjugate', 'denominato') is False
    except:
        raise Exception('Unexpected exception raised')

    # Test for int

# Generated at 2022-06-25 17:21:39.571560
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(0, 'conjugate', 'imag') is True)


# Generated at 2022-06-25 17:21:44.514424
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'something') is True



# Generated at 2022-06-25 17:21:55.958845
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)

    has_any_callables_0 = has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables_0
    # End of test_case_0()

    has_any_callables_1 = has_any_callables(obj, 'get', 'keys', 'items', 'values')
    assert has_any_callables_1
    # End of test_case_1()

    has_any_callables_2 = has_any_callables(obj, 'get', 'keys', 'items')
    assert has_any_callables_2
    # End of test_case_2()


# Generated at 2022-06-25 17:22:10.306648
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'abcdefg'
    str_1 = 'abc'
    list_0 = [1,2,3,4]
    list_1 = [1,2,3]

    assert(has_any_callables(str_0,'__mul__','__add__','__len__') == True)
    assert(has_any_callables(str_1,'__mul__','__add__','__len__') == True)
    assert(has_any_callables(str_1,'__mul__','__add__','__len__','__getitem__') == True)
    assert(has_any_callables(list_0,'__add__','__len__','__getitem__') == True)

# Generated at 2022-06-25 17:22:14.983825
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo') == True
    assert has_any_attrs(dict(),'get','keys','items','values','someattr') == False


# Generated at 2022-06-25 17:22:27.057075
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import UserList, Iterator, KeysView, ValuesView, set
    from collections import deque, tuple, frozenset, list

    # classes
    assert has_callables(set(), 'add') == True
    assert has_callables(set(), 'discard') == True
    assert has_callables(deque(), 'append') == True
    assert has_callables(deque(), 'appendleft') == True
    assert has_callables(list(), 'append') == True
    assert has_callables(tuple(), 'count') == True
    assert has_callables(frozenset(), 'copy') == True
    assert has_callables(Iterator(), '__next__') == True
    assert has_callables(UserList(), 'append') == True
    assert has

# Generated at 2022-06-25 17:22:29.971012
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 527.69414
    assert has_any_callables(float_0) == False
    test_case_0()


# Generated at 2022-06-25 17:22:31.598908
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')

# Generated at 2022-06-25 17:22:33.446384
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values','foo')) == True


# Generated at 2022-06-25 17:22:36.074696
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 527.69414
    bool_0 = has_any_callables(float_0)
    assert isinstance(bool_0, bool) is True
    assert bool_0 is True


# Generated at 2022-06-25 17:22:43.889908
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(
        float_0,
        'is_integer',
        'hex'
    ) is False
    assert has_any_callables(
        float_0,
        'hex',
        'is_integer'
    ) is True
    assert has_any_callables(
        float_0,
        '__add__',
        '__eq__'
    ) is True
    assert has_any_callables(
        float_0,
        'peekitem',
        'popitem'
    ) is False
    assert has_any_callables(
        bool_0,
        'peekitem',
        'popitem'
    ) is False

# Generated at 2022-06-25 17:23:00.484464
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(527.69414) == True
    assert has_any_callables(float(527)) == True
    assert has_any_callables(16 ** 0.5) == True
    assert has_any_callables(int(16 ** 0.5)) == True
    assert has_any_callables(int(15 ** 0.5)) == True
    assert has_any_callables(True) == True
    assert has_any_callables([1, 2, 3]) == True
    assert has_any_callables(float(15)) == True
    assert has_any_callables(float) == True
    assert has_any_callables(tuple) == True
    assert has_any_callables(bool) == True
    assert has_any_callables(int) == True
   

# Generated at 2022-06-25 17:23:04.437416
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(527.69414)


# Generated at 2022-06-25 17:23:06.267337
# Unit test for function has_callables
def test_has_callables():
    try:
        test_case_0()
    except Exception as err:
        print('Error: {0}'.format(err))

# Main function for unit testing
if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-25 17:23:19.177384
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test fixture
    obj_0 = dict()

    # Test
    assert has_any_attrs(obj_0, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(obj_0, 'foo') is False
    # Testing for an iterator
    assert has_any_attrs(range(3), '__iter__') is True
    # Test with an object with an `__iter__`
    object_0 = object()
    assert has_any_attrs(object_0, '__iter__') is False



# Generated at 2022-06-25 17:23:25.454235
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    try:
        test = has_any_callables(obj)
    except Exception as e:
        print('Exception ', e)
        print('type ', type(e))
        print(str(e))
        return False
    if (obj.keys() is not None):
        return (type(test) is bool and 
                test is not False)
    return (test is False)


# Generated at 2022-06-25 17:23:27.969674
# Unit test for function has_callables
def test_has_callables():
    bool_0 = has_callables(float, 'hex')
    assert bool_0 is True
    bool_1 = has_callables(float, '__init__')
    assert bool_1 is False


# Generated at 2022-06-25 17:23:38.774036
# Unit test for function has_any_callables
def test_has_any_callables():
    d = {'a': 1, 'b': 2}
    assert has_any_callables(d, 'get', 'items') is True
    assert has_any_callables(d, 'get', 'foo') is True
    assert has_any_callables(d, 'keys', 'None') is True
    assert has_any_callables(d, 'values', 'items') is True
    assert has_any_callables(d, 'get', 'update') is True
    assert has_any_callables(d, 'keys', 'foo') is True
    assert has_any_callables(d, 'get', 'None') is True
    assert has_any_callables(d, 'iteritems', 'update') is True
    assert has_any_callables(d, 'values', 'update') is True
    assert has

# Generated at 2022-06-25 17:23:43.201647
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(float_0)
    # Add more tests


# Generated at 2022-06-25 17:23:44.245295
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()

# Generated at 2022-06-25 17:23:59.132837
# Unit test for function has_callables
def test_has_callables():
    assert has_attrs(dict(), 'get', 'keys', 'items') is True
    assert has_callables(dict(), 'get', 'keys', 'items') is True
    assert has_callables('hello', '__add__', '__contains__', '__getitem__') is True
    assert has_callables(set(), 'add', 'clear', 'pop', 'remove') is True
    assert is_list_like(list()) is True
    assert is_list_like(dict(a=1, b=2)) is False
    assert is_list_like(set()) is True
    assert is_list_like(sorted('hello')) is True
    assert is_list_like('hello') is False
    assert is_list_like(reversed('hello')) is True

# Generated at 2022-06-25 17:24:01.862204
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(dict(), 'something') is False


# Generated at 2022-06-25 17:24:05.029925
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')


# Generated at 2022-06-25 17:24:11.214290
# Unit test for function has_callables
def test_has_callables():
    """Test for has_callables"""
    # Test for TypeError
    with pytest.raises(TypeError) as excinfo:
        has_callables()
    assert "missing 1 required positional argument" in str(excinfo.value)
    # Test for True
    float_0 = 527.69414
    bool_0 = has_callables(float_0, "__ceil__")
    # Test for False
    bool_1 = has_callables(float_0, "foo")

# Generated at 2022-06-25 17:24:21.271336
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({'1': '2'})
    assert not has_any_callables(1)
    assert not has_any_callables(1, '2')


# Generated at 2022-06-25 17:24:28.356764
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(float(),'mro','keys','items','values') == True
    assert has_any_callables(float(),'foo','bar','baz') == False
    assert has_any_callables(dict(),'mro','keys','items','values') == True
    assert has_any_callables(dict(),'foo','bar','baz') == False



# Generated at 2022-06-25 17:24:41.106160
# Unit test for function has_any_callables

# Generated at 2022-06-25 17:24:43.524155
# Unit test for function has_any_callables
def test_has_any_callables():
    # test_case_0
    test_case_0()



# Generated at 2022-06-25 17:24:54.655264
# Unit test for function has_any_attrs
def test_has_any_attrs():
    dict_0 = dict(a=1, b=2)
    assert has_any_attrs(dict_0, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict_0, 'foo') is False
    assert has_any_attrs(dict_0, 'foo', 'bar') is False
    dict_iter = dict_0.items()
    assert has_any_attrs(dict_iter, 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-25 17:24:57.602960
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print('Calling function:', inspect.stack()[0][3])
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True



# Generated at 2022-06-25 17:25:08.247859
# Unit test for function has_callables
def test_has_callables():
    """Test that ``has_callables(obj, *attrs)`` returns :obj:`True` for
    objects that have all given attributes and are callable.

    """
    # given
    obj_0 = {
        '__add__': lambda x: True,
        'x': 5.5,
    }
    obj_1 = {
        '__add__': object,
        'x': 5.5,
    }

    # test
    assert has_callables(obj_0, '__add__') is True
    assert has_callables(obj_0, '__add__', 'x') is True
    assert has_callables(obj_1, '__add__', 'x') is False
    assert has_callables(obj_1, '__add__') is False



# Generated at 2022-06-25 17:25:21.083230
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test logic:
    #
    # 1. Set up test object
    #   a. Run the function
    #   b. Assert
    # 2. Set up test object
    #   a. Run the function
    #   b. Assert
    #
    # First set up the test object
    #

    # Declare the test object
    test_object = "Hello, world"
    # Declare the expected result
    expected = True
    # Declare the test function
    test_function = has_any_callables

    # Execute the test function
    actual = test_function(test_object)

    # Assert
    assert actual == expected

    # Declare test object 2
    test_object = "Hello, world"

    # Execute function
    actual = test_function(test_object, "upper")



# Generated at 2022-06-25 17:25:25.783285
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 527.69414
    assert has_any_callables(float_0) == True



# Generated at 2022-06-25 17:25:33.487037
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'keys', 'items', 'values')
    assert has_callables(dict(), 'keys', 'get')
    assert has_callables(dict(), 'keys', 'get')
    assert has_callables(dict(), 'get')
    assert not has_callables(dict(), 'foo')


# Generated at 2022-06-25 17:25:42.082132
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()



# Generated at 2022-06-25 17:25:43.225818
# Unit test for function has_any_callables
def test_has_any_callables():
    assert test_case_0() == None


# Generated at 2022-06-25 17:25:53.571930
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test these objects
    objects = [
        dict(a=1, b=2),
        dict(a=1, b=2).keys(),
        dict(a=1, b=2).values(),
        dict(a=1, b=2).items(),
        dict(a=1, b=2).get('c'),
        dict(a=1, b=2).pop('a'),
        list(),
        [],
        1,
        False,
        True,
        None,
        (),
        (1, 2, 3),
        object()
    ]
    # Check for these attributes

# Generated at 2022-06-25 17:25:56.595312
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        test_case_0()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:26:03.237104
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test the has_any_attrs function."""
    from collections import UserList, KeysView, ValuesView, UserDict
    from collections.abc import Set, MutableSet, Mapping, MutableMapping

    # The ordering of these tests is important for code coverage.

# Generated at 2022-06-25 17:26:05.404561
# Unit test for function has_any_callables
def test_has_any_callables():
    _actual = has_any_callables(str)
    _expected = True
    assert _actual == _expected



# Generated at 2022-06-25 17:26:09.518932
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items','values','foo') is False


# Generated at 2022-06-25 17:26:11.494900
# Unit test for function has_callables
def test_has_callables():
    test_case_0()



# Generated at 2022-06-25 17:26:20.507065
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test ``has_any_attrs``.
    """
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo') is False
    assert has_any_attrs(str(), 'title', 'casefold', 'isdecimal') is True
    assert has_any_attrs(str(), 'title', 'foo') is True
    assert has_any_attrs(str(), 'foo') is False



# Generated at 2022-06-25 17:26:27.201604
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs((1,), '__getitem__') == True
    assert has_any_attrs(set(), 'add') == True
    assert has_any_attrs((1, 2, 3), 'add') == False
    assert has_any_attrs((1, 2, 3), '__getitem__', '__hash__') == True
    assert has_any_attrs(dict(), '__getitem__', '__iter__') == True
    assert has_any_attrs(dict(), 'foo', 'bar') == False
    assert has_any_attrs(dict(), '__getitem__', '__iter__', 'foo', 'bar') == True
    assert has_any_attrs('foo', '__getitem__') == True

# Generated at 2022-06-25 17:26:44.170405
# Unit test for function has_callables
def test_has_callables():
    obj = type(None)
    attrs = '__init__', '__new__', '__dict__'
    assert has_callables(obj, *attrs) is True
    attrs = '__init__', '__new__', '__dict__', '__foo__'
    assert has_callables(obj, *attrs) is False



# Generated at 2022-06-25 17:26:45.581700
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test 0
    assert test_case_0() is False



# Generated at 2022-06-25 17:26:46.478327
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()



# Generated at 2022-06-25 17:26:53.367283
# Unit test for function has_callables
def test_has_callables():
    # list
    assert has_callables([], '__len__') is True
    assert has_callables([], '__iter__') is True
    assert has_callables([], '__getitem__') is True
    # set
    assert has_callables(set(), '__len__') is True
    assert has_callables(set(), '__iter__') is True
    assert has_callables(set(), '__getitem__') is True
    # frozenset
    assert has_callables(frozenset(), '__len__') is True
    assert has_callables(frozenset(), '__iter__') is True
    assert has_callables(frozenset(), '__getitem__') is True
    # tuple
    assert has_callables(tuple(), '__len__') is True
   

# Generated at 2022-06-25 17:26:57.053796
# Unit test for function has_callables
def test_has_callables():
    import xml.sax.saxutils
    bool_obj = has_callables(xml.sax.saxutils, 'escape')
    assert bool_obj is True


# Generated at 2022-06-25 17:27:01.702744
# Unit test for function has_any_callables
def test_has_any_callables():
    from pytest import fails

    has_any_callables({}, 'get', 'keys', 'items', 'values', 'foo')

    with fails(AssertionError):
        has_any_callables({}, 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-25 17:27:05.464915
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(float, 1.0)
    assert has_any_callables(float, 'as_integer_ratio')
    assert has_any_callables(float, 'as_integer_ratio', 'hex')



# Generated at 2022-06-25 17:27:16.808313
# Unit test for function has_callables
def test_has_callables():
    """Check the function ``has_callables``.

    Raises:
        :obj:`AssertionError` if any of the following occur:

            * If the given ``obj`` does not have any of the given ``*attrs``
              and none are callable.
            * if the given ``obj`` does not have all of the given ``*attrs``
              and none are callable.

    Example:
        >>> from flutils.objutils import has_callables
        >>> has_callables(str(),'count','strip','upper')
        False
    """
    # Test has_callables with str.
    dict_0 = dict(a=1, b=2, c=3)
    str_0 = 'hello'
    bool_0 = has_callables(dict_0, 'get', 'keys')
    bool_

# Generated at 2022-06-25 17:27:19.397149
# Unit test for function has_callables
def test_has_callables():
    float_0 = 527.69414
    bool_0 = has_any_callables(float_0)

# Generated at 2022-06-25 17:27:27.172675
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(float, 'as_integer_ratio') is True
    assert has_callables(float, 'as_integer_ratio', 'is_integer') is True
    assert has_callables(float, 'is_integer') is True
    assert has_callables(float, 'is_integer', 'as_integer_ratio') is True
    assert has_callables(float, 'as_integer_ratio', 'is_integer_x') is False
    assert has_callables(float, 'as_integer_ratio', 'is_integer', 'is_integer_x') is False
    assert has_callables(123, 'isalnum') is True
    assert has_callables(123, 'isalnum', 'isdigit') is True

# Generated at 2022-06-25 17:27:38.303410
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import deque, ChainMap
    from collections.abc import Iterator, ValuesView, KeysView
    from collections.abc import (
        Reversible,
        MutableMapping,
        Mapping,
        MappingView,
        Iterable,
        Collection,
        Sequence,
        Sized,
        Hashable,
        Container,
    )
    from decimal import Decimal
    from io import (
        RawIOBase,
        BufferedIOBase,
        IOBase,
        TextIOBase,
    )
    from io import BytesIO
    from io import (
        BytesIO,
        BytesIO,
        BufferedReader,
        BufferedWriter,
        BufferedRWPair,
        BufferedRandom,
        TextIOWrapper,
    )

# Generated at 2022-06-25 17:27:48.680951
# Unit test for function has_any_callables
def test_has_any_callables():
    '''
    Test function has_any_callables
    '''
    int_0 = 474
    assert has_any_callables(int_0, 'numerator', 'to_bytes')
    float_0 = 706.2049
    assert has_any_callables(float_0, 'hex', 'fromhex')
    set_0 = set()
    assert has_any_callables(set_0, 'symmetric_difference_update', 'isdisjoint')
    dict_0 = dict()
    assert has_any_callables(dict_0, 'popitem', 'pop')
    list_0 = list()
    assert has_any_callables(list_0, 'copy', 'clear')
    str_0 = 'NtwtrO'

# Generated at 2022-06-25 17:27:55.342268
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables."""
    assert has_any_callables('hello', 'upper', 'lower') is True
    assert has_any_callables(1, 'upper', 'lower') is False
    assert has_any_callables({}, 'get', 'keys', 'values') is True
    assert has_any_callables(OrderedDict(), 'get', 'keys', 'values') is True



# Generated at 2022-06-25 17:27:58.780247
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test function has_any_callables with float
    float_0 = 527.69414
    bool_0 = has_any_callables(float_0)
    assert bool_0 == True


# Generated at 2022-06-25 17:27:59.804420
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()



# Generated at 2022-06-25 17:28:01.954069
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-25 17:28:03.772570
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()

if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:28:04.837404
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()


# Generated at 2022-06-25 17:28:07.493513
# Unit test for function has_any_callables
def test_has_any_callables():
    t0_instance = test_case_0
    assert t0_instance.__name__ == 'test_case_0'
    assert has_any_callables(t0_instance) == True


# Generated at 2022-06-25 17:28:14.701830
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(list(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(str(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(tuple(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(ValuesView([]), 'get', 'keys', 'items', 'values',
                             'foo')
    assert has_any_callables(KeysView({}), 'get', 'keys', 'items', 'values',
                             'foo')

# Generated at 2022-06-25 17:28:21.669337
# Unit test for function has_any_callables
def test_has_any_callables():
    # assert statement fails because a float object does not have any callables.
    assert has_any_callables(527.69414) != True



# Generated at 2022-06-25 17:28:23.495508
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'values', 'items', 'get')



# Generated at 2022-06-25 17:28:26.796296
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict()
    assert has_any_callables(d) is True
    assert has_any_callables(d,'get') is True
    assert has_any_callables(d,'get','keys') is True
    assert has_any_callables(d,'get','keys','items') is True
    assert has_any_callables(d,'get','keys','items','values') is True
    assert has_any_callables(d,'get','keys','items','values','foo') is False
    assert has_any_callables(d,'foo') is False

# Generated at 2022-06-25 17:28:29.065452
# Unit test for function has_any_callables
def test_has_any_callables():
    # test when value is 527.69414
    try:
        test_case_0()
    except Exception:
        raise AssertionError("Unexpected exception")



# Generated at 2022-06-25 17:28:31.490034
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-25 17:28:34.378214
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    bool_1 = has_any_callables(dict(),'get','keys','items','values','something')
    assert bool_1 == True



# Generated at 2022-06-25 17:28:35.278786
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()


# Generated at 2022-06-25 17:28:36.771672
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 527.69414
    assert has_any_callables(float_0) == True


# Generated at 2022-06-25 17:28:46.634683
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = {10,20,30}
    assert has_any_callables(obj,'__iter__','__reversed__')
    assert has_any_callables(obj,'__iter__','__next__') == False
    assert has_any_callables(obj,'__iter__','__getitem__') == False
    assert has_any_callables(obj,'__reversed__','__getitem__')
    assert has_any_callables(obj,'__reversed__','__len__') == False
    assert has_any_callables(1,'__iter__','__reversed__') == False


# Generated at 2022-06-25 17:28:51.763857
# Unit test for function has_any_callables
def test_has_any_callables():
    @given(st.floats())
    def test_has_any_callables(f):
        assert has_any_callables(f) == has_any_callables_check(f)
        print(f)
    test_has_any_callables()


# Generated at 2022-06-25 17:29:04.024906
# Unit test for function has_any_callables
def test_has_any_callables():
    assert not has_any_callables(527.69414)
    assert has_any_callables(
        dict(a=1, b=2),
        'get', 'keys', 'items', 'values'
    )



# Generated at 2022-06-25 17:29:08.837651
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        test_case_0()
    except:
        logging.exception('ERROR in test_case_0')
        raise


if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:29:11.514993
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = has_any_callables(527.69414)
    assert float_0 == False



# Generated at 2022-06-25 17:29:14.719260
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 527.69414
    bool_0 = has_any_callables(float_0)
    assert bool_0 == True, "Function has_any_callables() didn't return True."


# Generated at 2022-06-25 17:29:25.645744
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 1.2
    assert has_any_callables(float_0)
    assert not has_any_callables(float_0, 'hello')
    assert not has_any_callables(float_0, '__setattr__')
    assert has_any_callables(float_0, '__add__', '__sub__')
    assert not has_any_callables(float_0, '__add__', 'hello', '__sub__')
    assert has_any_callables(float_0, 'hello', '__sub__')
    assert not has_any_callables(float_0, 'hello', '__sub__', '__setattr__')
    assert not has_any_callables(float_0, 'hello', '__sub__', '__setattr__', 'hello_again')


# Generated at 2022-06-25 17:29:33.238163
# Unit test for function has_any_callables
def test_has_any_callables():
    float_0 = 527.69414
    assert has_any_callables(float_0) == False

    dct_0 = {
        'b': [1.254056597690857, 7.769960804756173, 0.9284864474794064],
        'a': [6.891153099463592, 8.949925357554384, 8.414075079778503],
        'c': [5.185433258057835, 2.514744442850903, 3.724196170582745]
    }
    assert has_any_callables(dct_0) == True


# Generated at 2022-06-25 17:29:44.419418
# Unit test for function has_any_callables
def test_has_any_callables():
    has_any_callables(list('abc'), '')
    has_any_callables(list('abc'), 'append')
    has_any_callables(list('abc'), 'join')
    has_any_callables(list('abc'), 'append', 'join')
    has_any_callables(list('abc'), 'append', 'join', 'pop')
    has_any_callables(list('abc'), 'append', 'join', 'pop', 'dummy')
    has_any_callables(list('abc'), 'append', 'join', 'pop', 'dummy',
                      'sort')
    has_any_callables(list('abc'), 'append', 'join', 'pop', 'dummy', 'sort',
                      'reverse')

# Generated at 2022-06-25 17:29:52.809204
# Unit test for function has_any_callables
def test_has_any_callables():

    assert(has_any_callables(527.69414))
    assert(has_any_callables(527.69414, '__add__'))
    assert(has_any_callables(527.69414, '__add__', '__bool__'))
    assert(has_any_callables(527.69414, '__add__', '__bool__', '__class__'))
    assert(has_any_callables(527.69414, '__add__', '__bool__', '__class__', '__delattr__'))
    assert(has_any_callables(527.69414, '__add__', '__bool__', '__class__', '__delattr__', '__dir__'))

# Generated at 2022-06-25 17:30:00.058262
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(527.69414, '__sub__', '__floordiv__', '__eq__')
    assert has_any_callables(reversed('hello'), '__sub__', '__floordiv__', '__eq__')
    assert has_any_callables(sorted('hello'), '__sub__', '__floordiv__', '__eq__')
    assert has_any_callables({'a': 1, 'b': 2, 'c': 3}, '__sub__', '__floordiv__', '__eq__')
    assert has_any_callables(('a', 'b', 'c', 'd'), '__sub__', '__floordiv__', '__eq__')



# Generated at 2022-06-25 17:30:11.942264
# Unit test for function has_any_callables
def test_has_any_callables():
  float_0 = 527.69414
  bool_0 = has_any_callables(float_0)
  assert bool_0 == False
  float_1 = 5764.8075
  bool_1 = has_any_callables(float_1)
  assert bool_1 == False
  float_2 = 2.7984385
  bool_2 = has_any_callables(float_2)
  assert bool_2 == False
  float_3 = 0.8489918
  bool_3 = has_any_callables(float_3)
  assert bool_3 == False
  float_4 = 6.379799
  bool_4 = has_any_callables(float_4)
  assert bool_4 == False
  float_5 = 2785.17173
  bool_5 = has_