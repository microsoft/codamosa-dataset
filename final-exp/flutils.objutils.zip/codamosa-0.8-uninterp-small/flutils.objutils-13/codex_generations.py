

# Generated at 2022-06-25 17:20:58.180928
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'value','keys','key','values','something') is False
    assert has_any_attrs(dict(),'value','keys','key','values','something') is False


# Generated at 2022-06-25 17:21:09.590301
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict(a=1, b=2)
    bool_0 = has_callables(dict_0, "get", "keys", "foo")
    bool_1 = has_callables(dict_0, "get", "values", "items")
    bool_2 = has_callables(dict_0, "get", "keys", "foo", "values")
    bool_3 = has_callables(dict_0, "get", "keys", "items")
    bool_4 = has_callables(dict_0, "get", "keys", "items", "foo")
    bool_5 = has_callables(dict_0, "get", "keys", "items", "foo", "values")
    bool_6 = has_callables(dict_0, "get", "keys", "items", "values")


# Generated at 2022-06-25 17:21:18.811329
# Unit test for function has_attrs
def test_has_attrs():
    assert(isinstance(has_attrs, collections.Callable))

    # Test: When param is empty list, returns False.
    assert(has_attrs([], "foo") is False)

    # Test: When param is empty tuple, returns False.
    assert(has_attrs((), "foo") is False)

    # Test: When param is empty dict, returns False.
    assert(has_attrs({}, "foo") is False)

    # Test: When param is None, returns False.
    assert(has_attrs(None, "foo") is False)

    # Test: When param has attr and is callable, returns True.
    assert(has_attrs(str, "isprintable") is True)

    # Test: When param has attr and is NOT callable, returns True.

# Generated at 2022-06-25 17:21:23.495352
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict(a=1, b=2)
    assert has_callables(dict_0, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-25 17:21:27.637877
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(),'bar','baz','foz','fiz','fib')



# Generated at 2022-06-25 17:21:40.215532
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test the case where any of the attributes exist and are callable
    object_1 = dict(a=1, b=2)
    result_1 = has_any_callables(object_1, 'get')
    assert result_1 == True
    # Test the case where none of the attributes exist
    object_2 = dict(a=1, b=2)
    result_2 = has_any_callables(object_2, 'get', 'foo')
    assert result_2 == False
    # Test the case where more than one of the attributes exist and are callable
    object_3 = dict(a=1, b=2)
    result_3 = has_any_callables(object_3, 'get', 'keys')
    assert result_3 == True


# Generated at 2022-06-25 17:21:47.709166
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import Iterator, KeysView, ValuesView, UserList, deque
    set_0 = {'a', 'b', 'c'}
    frozenset_0 = frozenset(set_0)
    list_0 = [set_0, frozenset_0]
    tuple_0 = tuple(list_0)
    deque_0 = deque(tuple_0)
    values_0 = set_0.values()
    keys_0 = set_0.keys()
    items_0 = set_0.items()
    user_list_0 = UserList(deque_0)
    iterator_0 = iter(user_list_0)
    values_view_0 = set_0.values()
    keys_view_0 = set_0.keys()


# Generated at 2022-06-25 17:21:58.646015
# Unit test for function has_any_callables
def test_has_any_callables():
    assert True
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, "get", "keys", "items", "values", "foo") is True
    assert has_any_callables(obj, "foo") is False
    assert has_any_callables(obj, "get", "keys", "items", "values") is True
    assert has_any_callables(obj, "keys", "items", "values") is True
    assert has_any_callables(obj, "get", "items", "values") is True
    assert has_any_callables(obj, "get", "keys", "values") is True
    assert has_any_callables(obj, "get", "keys", "items") is True
    assert has_any_callables(obj, "get", "keys")

# Generated at 2022-06-25 17:22:12.975735
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables('hello', '__str__', 'split', 'foo') is True
    assert has_any_callables('hello', 'foo', 'bar') is False
    # Unit test for function has_any_attrs
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs('hello', '__str__', 'split', 'foo') is True
    assert has_any_attrs('hello', 'foo', 'bar') is False
    # Unit test for function has_attrs
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has

# Generated at 2022-06-25 17:22:19.518050
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'values', 'items', 'pop') is True
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'foo', 'bar', 'baz') is False


# Generated at 2022-06-25 17:22:31.728621
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(bytes_0, 'decode', 'split') == False
    assert has_callables(bytes_0, 'decode') == True

# Generated at 2022-06-25 17:22:33.077238
# Unit test for function has_callables
def test_has_callables():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 17:22:44.470209
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list, 'sort') == True
    assert has_callables(dict, 'keys', 'items', 'values') == True
    assert has_callables(list, 'foo') == False
    assert has_callables(dict, 'keys', 'foo', 'values') == False
    assert has_callables(list, 'foo', 'sort', 'remove') == False
    assert has_callables(dict, 'keys', 'items', 'foo', 'values') == False


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main([__file__] + sys.argv[1:])
    # test_case_0()
    test_has_callables()

# Generated at 2022-06-25 17:22:57.902859
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(b'bytes!', 'upper') is True
    assert has_callables(100, 'upper') is False

    assert has_callables(dict(a=1), 'get', 'values', 'keys') is True
    assert has_callables(dict(a=1), 'nope', 'values', 'keys') is False

    assert has_callables({'a': 1}, 'get', 'values', 'keys') is True
    assert has_callables({'a': 1}, 'nope', 'values', 'keys') is False

# Generated at 2022-06-25 17:23:00.641436
# Unit test for function has_any_callables
def test_has_any_callables():
    assert True is has_any_attrs(dict(), 'get')
    assert True is has_any_callables(dict(), 'get')
    assert False is has_any_callables(dict(), 'foo')


# Generated at 2022-06-25 17:23:01.988135
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test case: has_any_callables"""
    # @TODO
    ...


# Generated at 2022-06-25 17:23:07.827913
# Unit test for function has_any_callables
def test_has_any_callables():
    import sys
    import io
    import io as io
    import io as io
    from io import IOBase as IO_Base
    from io import TextIOBase as Text_IO_Base
    from io import RawIOBase as Raw_IO_Base
    from io import BufferedIOBase as Buffered_IO_Base
    from io import TextIOWrapper as Text_IO_Wrapper
    from io import FileIO as File_IO
    from io import BytesIO as Bytes_IO
    from io import StringIO as String_IO
    import types
    import types as types
    import types as types
    from types import CodeType as Code_Type
    from types import FunctionType as Function_Type
    from types import SimpleNamespace as Simple_Namespace
    from types import TracebackType as Traceback_Type

# Generated at 2022-06-25 17:23:14.473925
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'items', 'values', '__iter__') is True
    assert has_callables(obj, 'keys', 'values', 'items', '__iter__', 'foo') is False  # noqa


# Generated at 2022-06-25 17:23:22.961008
# Unit test for function has_callables
def test_has_callables():
    assert has_callables("0", "isnumeric") == True
    assert has_callables("0", "isnumeric", "islower") == True
    assert has_callables("0", "isnumeric", "islower", "isdecimal") == True
    assert has_callables("0", "isnumeric", "islower", "isdecimal", "isdigit") == True
    assert has_callables("0", "isnumeric", "islower", "isdecimal", "isdigit",
                         "isalnum") == True

    assert has_callables("0", "isalnum") == False
    assert has_callables("0", "islower") == False
    assert has_callables("0", "isdecimal") == False
    assert has_callables("0", "isdigit") == False
   

# Generated at 2022-06-25 17:23:26.415319
# Unit test for function has_callables
def test_has_callables():
    class TestClass():
        def foo():
            pass

    inst = TestClass()

    assert has_callables(inst, 'foo') is True
    assert has_callables(inst, 'bar') is False


# Generated at 2022-06-25 17:23:37.375165
# Unit test for function has_any_callables
def test_has_any_callables():
    bytes_0 = b'"\x9d\xfb\x00'
    actual = has_any_callables(bytes_0)
    expected = True
    assert actual == expected


# Generated at 2022-06-25 17:23:49.777757
# Unit test for function has_callables
def test_has_callables():
    bytes_0 = b'"\x9d\xfb\x00'
    str_0 = 'wscbz'
    dict_0 = dict(a=1, b=2)
    assert (has_callables(dict_0, '__setitem__', '__getitem__', 'keys', 'items')
            is True)
    assert has_callables(bytes_0, '__mod__', '__radd__', '__getitem__') is False
    assert has_callables(str_0, '__mod__', '__radd__', '__getitem__') is False
    assert has_callables(None) is False
    assert has_callables(False) is False
    assert has_callables(bytes_0) is False
    assert has_callables(str_0) is False

# Generated at 2022-06-25 17:23:51.151108
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()


# Generated at 2022-06-25 17:24:00.575237
# Unit test for function has_callables
def test_has_callables():
    test_list = [
        "a",
        "b",
        "c",
        "d",
        "e"
    ]

    test_tuple = (
        "a",
        "b",
        "c",
        "d",
        "e"
    )

    test_set = {
        "a",
        "b",
        "c",
        "d",
        "e"
    }

    test_dict = {
        "a": "apple",
        "b": "banana",
        "c": "cherry",
        "d": "donut",
        "e": "eclair"
    }

    assert has_callables(test_list, "index", "count") == True

# Generated at 2022-06-25 17:24:11.630296
# Unit test for function has_callables
def test_has_callables():
    from unittest import TestCase
    from inspect import signature
    from flutils import objutils

    class TestClass(object):
        def __getattr__(self, item):
            def _func(*args, **kwargs):
                return f'{item} is called'

            return _func

    t = TestClass()

    tc = TestCase()
    tc.assertTrue(objutils.has_attrs(t, 'a', 'b', 'c', 'd'))
    tc.assertFalse(objutils.has_attrs(t, 'a', 'b', 'c', 'd', 'e'))
    tc.assertTrue(objutils.has_callables(t, 'a', 'b', 'c', 'd'))

# Generated at 2022-06-25 17:24:21.051903
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function :func:`has_callables`.

    """
    tests = {
        'dict': (dict, ('get', 'keys', 'items', 'values'), True),
        'list': (list, ('append',), True),
        'set': (set, ('add',), True),
        'frozenset': (frozenset, ('add',), False),
    }

    for key, (obj_type, attrs, expected) in tests.items():
        obj = obj_type()
        result = has_callables(obj=obj, attrs=attrs)
        _msg = f'{key}: Expected {expected} but received {result}'
        assert result == expected, _msg



# Generated at 2022-06-25 17:24:28.211029
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a = 1, b = 2)
    assert has_callables(obj, 'keys', 'values', 'items') is True, \
        'dict has all of those callables'
    assert has_callables(obj, 'a', 'broken_key') is False, \
        'dict does not have a callable called "broken_key"'
    assert has_callables(obj, 'a', 'b') is False, \
        'dict does not have a callable called "a" or "b"'
    assert has_callables(obj, 'keys', 'broken_key') is False, \
        'dict does not have a callable called "broken_key"'


# Generated at 2022-06-25 17:24:34.737153
# Unit test for function has_callables
def test_has_callables():
    if has_callables(dict, 'get', 'keys', 'items', 'values'):
        print('This is a dict.')
    else:
        print('This is not a dict.')


if __name__ == '__main__':

    test_case_0()
    test_has_callables()

# Generated at 2022-06-25 17:24:43.910504
# Unit test for function has_any_callables
def test_has_any_callables():
    dct = {'a': 'b', 'c': 'd'}
    assert has_any_callables(dct, 'get', 'keys', 'items') is True
    # assert has_any_callables(dct, 'get', 'keys', 'items', 'does_not_exist') is False
    assert has_any_callables(dct, 'get', 'keys', 'items_fail') is True
    assert has_any_callables(dct, 'does_not_exist', 'items_fail') is False
    assert has_any_callables(dct, 'get', 'those_things', 'items') is True
    assert has_any_callables(dct, 'get', 'those_things', 'items_fail') is True

# Generated at 2022-06-25 17:24:57.846815
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(set(), 'pop', 'add', 'union', 'intersection')
    assert has_any_callables(reversed('hello'))
    assert has_any_callables(Counter(), 'pop', 'update', 'intersection', 'keys')
    assert not has_any_callables(UserString(), 'pop', 'add', 'union', 'intersection')
    assert not has_any_callables(str(), 'pop', 'add', 'union', 'intersection')
    assert not has_any_callables(int(), 'pop', 'add', 'union', 'intersection')
    assert not has_any_callables(bool(), 'pop', 'add', 'union', 'intersection')
    assert not has_any_callables(None, 'pop', 'add', 'union', 'intersection')
   

# Generated at 2022-06-25 17:25:15.267742
# Unit test for function has_callables
def test_has_callables():
    struct = struct()
    struct.name = 'name'
    struct.substruct = struct()
    struct.substruct.name = 'substruct'
    def get_name(self):
        return self.name
    struct.get_name = get_name
    struct.substruct.get_name = get_name
    assert has_callables(struct, 'get_name', 'substruct') is True
    assert has_callables(struct, 'get_name', 'substruct', 'name') is False

# Generated at 2022-06-25 17:25:21.732321
# Unit test for function has_any_callables
def test_has_any_callables():
    bytes_0 = b'"\x9d\xfb\x00'
    bool_0 = has_any_callables(bytes_0)
    str_0 = 'abcdefg'
    bytes_1 = b'abcdefg'
    dict_0 = dict()
    dict_0['key'] = str_0
    dict_0['key1'] = bytes_1
    bool_1 = has_any_callables(dict_0)


# Generated at 2022-06-25 17:25:25.846854
# Unit test for function has_any_callables
def test_has_any_callables():
    # Corner case with empty list
    expected = False
    actual = has_any_callables([])
    assert expected == actual
    # 1-item list
    expected = True
    actual = has_any_callables(['a'])
    assert expected == actual
    # 1-item list with non-callable
    expected = False
    actual = has_any_callables(['a'], 'upper')
    assert expected == actual
    # 1-item list with callable
    expected = True
    actual = has_any_callables(['a'], 'upper', 'lower')
    assert expected == actual
    # 1-item list with callable and non-callable
    expected = True
    actual = has_any_callables(['a'], 'upper', 'lower', 'isalnum')
    assert expected == actual
   

# Generated at 2022-06-25 17:25:37.951638
# Unit test for function has_callables
def test_has_callables():
    cls = Bunch()
    cls.a = 1
    cls.b = 2
    cls.c = 3
    cls.d = 4
    cls.e = 5
    cls.f = 6

    assert test_any_callables(cls, 'a', 'b', 'c') == True
    assert test_any_callables(cls, 'a', 'b', 'c', 'd') == True
    assert test_any_callables(cls, 'a', 'b', 'c', 'd', 'e') == True
    assert test_any_callables(cls, 'a', 'b', 'c', 'd', 'e', 'f') == True



# Generated at 2022-06-25 17:25:45.635688
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    dict_0['get'] = 'foo'
    dict_0['keys'] = 'bar'
    dict_0['items'] = 'baz'

    ret_0 = has_callables(dict_0, 'get', 'keys', 'items')
    assert (ret_0 == True)


# Generated at 2022-06-25 17:25:55.970369
# Unit test for function has_callables
def test_has_callables():
    # testing with a dict
    obj = {}
    # testing that it returns false with all attributes that aren't callable
    assert has_callables(obj, "clear", "copy", "fromkeys", "get", "pop",
                         "popitem", "setdefault", "update") is False
    # testing that it returns true with all attributes that are callable
    assert has_callables(obj, "keys", "items", "values") is True
    # testing with a str
    obj = ""
    # testing that it returns false with all attributes that aren't callable
    assert has_callables(obj, "isascii", "isdecimal", "isdigit", "isidentifier",
                         "islower", "isnumeric", "isprintable", "isspace",
                         "istitle", "isupper") is False
    # testing

# Generated at 2022-06-25 17:25:58.780866
# Unit test for function has_any_callables
def test_has_any_callables():
    class ObjCat:
        def meow(self):
            return
    obj_cat = ObjCat()
    assert has_any_callables(obj_cat, 'meow'), '''
        has_any_callables is not working as expected
    '''


# Generated at 2022-06-25 17:26:05.069161
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        test_case_0()
        print('Success: assert_has_any_callables')
    except (NameError, AssertionError) as ex:
        print('Failure: assert_has_any_callables')
        print(ex)

if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:26:07.718065
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert type(has_any_callables) is type(test_case_0)
    assert has_any_callables(bytes_0) is True


# Generated at 2022-06-25 17:26:13.698261
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    from flutils.objutils import has_callables

    u_dict = UserDict()

    assert has_callables(u_dict, 'copy', 'update') is True
    assert has_callables(u_dict, 'update', 'foo') is False


# Generated at 2022-06-25 17:26:32.890807
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    assert (has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo'))

    tuple_0 = tuple(['!f!', '', '', '!f!'])
    assert (has_any_callables(tuple_0, 'index', 'count'))

    bytes_0 = b'"\x9d\xfb\x00'
    assert (has_any_callables(bytes_0))

    float_0 = float(3.3)
    assert (has_any_callables(float_0, 'hex', 'fromhex', 'as_integer_ratio'))


# Generated at 2022-06-25 17:26:38.774328
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    dict_1 = {'a': 'b'}
    str_0 = 'hello'
    str_1 = '\x80'
    list_0 = list()
    list_1 = [1, 2, 3]
    bool_0 = has_callables(dict_0, 'get', 'keys', 'items', 'values')
    bool_1 = has_callables(dict_1, 'get', 'keys', 'items', 'values')
    bool_2 = has_callables(str_0, 'find', 'index', 'isdigit', 'isidentifier')
    bool_3 = has_callables(str_1, 'find', 'index', 'isdigit', 'isidentifier')

# Generated at 2022-06-25 17:26:48.092086
# Unit test for function has_callables
def test_has_callables():
    func = has_callables
    assert True == func(dict(), 'get', 'keys', 'items', 'values')
    assert False == func(dict(), 'foo', 'bar', 'baz')
    assert False == func(dict(), 'get', 'keys', 'bar', 'values')
    bytes_0 = b'"\x9d\xfb\x00'
    assert has_any_callables(bytes_0) == has_callables(bytes_0)
    assert has_any_callables(bytes_0) == has_callables(bytes_0, *bytes_0)
    assert False == has_callables(bytes_0, *bytes_0)


# Generated at 2022-06-25 17:27:01.104900
# Unit test for function has_any_callables
def test_has_any_callables():
    bytes_0 = b'"\x9d\xfb\x00'
    assert has_any_callables(bytes_0) == True
    counter_0 = Counter()
    assert has_any_callables(counter_0) == True
    frozenset_0 = frozenset()
    assert has_any_callables(frozenset_0) == True
    int_0 = 0
    assert has_any_callables(int_0) == True
    list_0 = [0]
    assert has_any_callables(list_0) == True
    range_0 = range(0)
    assert has_any_callables(range_0) == True
    set_0 = {0}
    assert has_any_callables(set_0) == True
    str_0 = 'a'
   

# Generated at 2022-06-25 17:27:11.428992
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_callables(dict(), 'get', 'keys', 'items') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_callables(str(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_callables(str(), 'islower', 'isupper', 'get', 'keys', 'items', 'values') is False


# Generated at 2022-06-25 17:27:21.969563
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    from collections.abc import Iterable
    from collections.abc import Mapping
    from decimal import Decimal
    from decimal import ROUND_CEILING
    from decimal import ROUND_FLOOR
    from decimal import ROUND_HALF_DOWN
    from decimal import ROUND_HALF_EVEN
    from decimal import ROUND_HALF_UP
    from decimal import ROUND_UP
    from decimal import DecimalException
    from decimal import Rounded
    from decimal import Context
    from decimal import getcontext
    from decimal import localeconv
    from decimal import setcontext
    from decimal import BasicContext
    from decimal import ExtendedContext

    from flutils.objutils import has_callables
    from flutils.objutils import has_attrs

    assert has_callables(tuple())

# Generated at 2022-06-25 17:27:30.696738
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(b'hello there', 'capitalize', 'split')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(set(), 'add', 'clear', 'copy', 'difference')
    assert has_any_callables(frozenset(), 'add', 'clear', 'copy', 'difference')
    assert has_any_callables([1, 2, 3], 'append', 'extend', 'insert')


# Generated at 2022-06-25 17:27:35.799440
# Unit test for function has_callables
def test_has_callables():
    from . import objutils as flutils_objutils
    class person(object):
        def __init__(self, name, age):
            self.name = name
            self.age = age
            self.address = "Bogor"

    obj = person('john', 22)
    result = flutils_objutils.has_callables(obj,'name', 'address', 'age')
    print('result = ', result)
    assert result



# Generated at 2022-06-25 17:27:37.956673
# Unit test for function has_callables
def test_has_callables():
    bytes_0 = b'"\x9d\xfb\x00'
    bool_0 = has_callables(bytes_0)


# Generated at 2022-06-25 17:27:40.891396
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(bytes(), 'decode', 'encode') is True
    assert isinstance(has_callables(bytes(), 'decode', 'encode'), bool)


# Generated at 2022-06-25 17:28:02.863152
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True, has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-25 17:28:04.421569
# Unit test for function has_callables
def test_has_callables():
    x = dict(a=1, b=2)
    assert has_callables(x.items(), '__iter__')
    assert not has_callables(x.items(), 'foo', 'bar')


# Generated at 2022-06-25 17:28:07.778745
# Unit test for function has_callables
def test_has_callables():
    from collections.abc import Mapping
    from collections import defaultdict
    from decimal import Decimal
    obj = defaultdict(Decimal, {'a': 1, 'b': 2})
    assert has_callables(obj, 'keys', 'values', 'items')


# Generated at 2022-06-25 17:28:14.890842
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(None) == False
    assert has_any_callables(True) == False
    assert has_any_callables(False) == False
    assert has_any_callables(b"foo") == True
    assert has_any_callables("foo") == True
    assert has_any_callables(int) == True
    assert has_any_callables(float) == True
    assert has_any_callables(dict) == True
    assert has_any_callables(list) == True
    assert has_any_callables(tuple) == True
    assert has_any_callables(set) == True
    assert has_any_callables(frozenset) == True
    assert has_any_callables(reversed([1, 2, 3])) == True

# Generated at 2022-06-25 17:28:18.720099
# Unit test for function has_any_callables
def test_has_any_callables():
    values=(
        'a',
        [],
        {},
        {1, 2, 3, 4},
        True,
        4,
    )
    for value in values:
        assert has_any_callables(value) is True



# Generated at 2022-06-25 17:28:30.260971
# Unit test for function has_any_callables
def test_has_any_callables():
    assert not has_any_callables(b'', 'append')
    assert not has_any_callables(b'', 'append', 'extend')
    assert has_any_callables(b'', 'decode')
    assert has_any_callables(b'', 'decode', 'append')
    assert not has_any_callables(b'', 'FOO')
    assert not has_any_callables(False, 'append')
    assert not has_any_callables(False, 'append', 'extend')
    assert not has_any_callables(False, 'decode')
    assert not has_any_callables(False, 'decode', 'append')
    assert not has_any_callables(False, 'FOO')

# Generated at 2022-06-25 17:28:38.755392
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = dict(a=1, b=2)
    assert has_any_callables(obj_0) == True

    obj_1 = dict(a=1, b=2)
    assert has_any_callables(obj_1, 'keys', 'items', 'values', 'something') == True

    obj_2 = dict(a=1, b=2)
    assert has_any_callables(obj_2, 'something') == False

    obj_3 = dict(a=1, b=2)
    assert has_any_callables(obj_3, 'something') == False

    obj_4 = dict(a=1, b=2)
    assert has_any_callables(obj_4, 'get', 'foo') == True

    obj_5 = dict(a=1, b=2)

# Generated at 2022-06-25 17:28:49.513650
# Unit test for function has_any_callables
def test_has_any_callables():
    from fractions import Fraction
    frac_0 = Fraction(2, 3)
    bool_0 = has_any_callables(frac_0, '__add__', '__sub__', '__mul__', '__truediv__')

    from decimal import Decimal
    dec_0 = Decimal('3.14')
    bool_1 = has_any_callables(dec_0, '__add__', '__sub__', '__mul__', '__truediv__')

    int_0 = 2
    bool_2 = has_any_callables(int_0, '__add__', '__sub__', '__mul__', '__truediv__')

    float_0 = float(3.141592653589793)

# Generated at 2022-06-25 17:28:52.131763
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys')
    assert (has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is
            False)



# Generated at 2022-06-25 17:28:54.774230
# Unit test for function has_any_callables
def test_has_any_callables():
    """ Unit test for the function has_any_callables
    """
    bytes_0 = b'"\x9d\xfb\x00'
    assert has_any_callables(bytes_0) == False


# Generated at 2022-06-25 17:29:43.290076
# Unit test for function has_any_callables
def test_has_any_callables():
    class Foo(object):
        def f1(self):
            pass
        def f2(self):
            pass
        def f3(self):
            pass
        def f4(self):
            pass
        def f5(self):
            pass
        def f6(self):
            pass
    foo = Foo()
    assert has_any_callables(foo, 'f1') is True
    assert has_any_callables(foo, 'f2', 'f3', 'f4', 'f5', 'f6') is True

if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:29:53.183832
# Unit test for function has_callables
def test_has_callables():
    sample_types = {
        'None': None,
        'bytes': b'\x00\x01\x02',
        'float': 1.0,
        'int': 1,
        'str': 'Hello, World!',
    }
    # Make sure the function returns False if no attributes are found.
    for _, val in sample_types.items():
        assert has_callables(val, 'foo') is False
    # Make sure the function returns False if the method is not callable
    assert has_callables(sample_types['bytes'], 'encode') is False
    assert has_callables(sample_types['float'], 'hex') is False
    assert has_callables(sample_types['int'], 'hex') is False
    assert has_callables(sample_types['str'], 'encode')

# Generated at 2022-06-25 17:29:59.159965
# Unit test for function has_callables
def test_has_callables():
    import redis
    assert has_callables(redis.Redis(), 'get', 'info')
    assert has_callables(redis.StrictRedis(), 'get', 'info')
    assert has_callables(redis.ConnectionPool(), 'connection_class')
    assert not has_callables(redis.ConnectionPool(), 'connection')
    assert not has_callables(redis.ConnectionPool(), 'connect')
    assert has_callables(redis.ConnectionPool(), 'get_connection')
    assert has_callables(redis.BlockingConnectionPool(), 'get_connection')


# Generated at 2022-06-25 17:30:04.427115
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1,b=2)
    assert isinstance(obj,dict) is True
    assert has_callables(obj,'get','keys','items','values') is True
    assert has_callables(obj,'get','keys','items') is True
    assert has_callables(obj,'get','keys') is True
    assert has_callables(obj,'get','foo') is False


# Generated at 2022-06-25 17:30:15.009592
# Unit test for function has_any_callables
def test_has_any_callables():
    class _Test:
        def __init__(
                self,
                *args,
                **kwargs
        ):
            self.attr_0 = kwargs.get('attr_0')
            self.attr_1 = kwargs.get('attr_1')
            self.attr_2 = kwargs.get('attr_2')

        def func_0(self):
            return self.attr_0

        def func_1(self):
            return self.attr_1

        def func_2(self):
            return self.attr_2

    def _test(obj):
        if not has_callables(obj, 'func_0', 'func_1'):
            return False
        if obj.func_0() != 'foo' or obj.func_1() != 2:
            return False
        return True

# Generated at 2022-06-25 17:30:18.447252
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values') is True) #Test default
    assert(has_any_callables(dict(),'gett','keys','items','values') is False) #Test if false


# Generated at 2022-06-25 17:30:27.335343
# Unit test for function has_callables
def test_has_callables():
    import struct
    obj = struct.Struct('i')

    # obj is a Struct which is a subclass of tuple
    assert not has_callables(obj, '__getitem__') is True
    assert not has_callables(obj, '__getitem__', '__len__') is True

    class MyStruct(struct.Struct):
        def __getitem__(self, key):
            return self.__getitem__(key)

    obj = MyStruct('i')
    # obj is a MyStruct which is a subclass of list
    assert has_callables(obj, '__getitem__') is True
    assert not has_callables(obj, '__getitem__', '__len__') is True



# Generated at 2022-06-25 17:30:34.795137
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables((),'count','index','foo')
    assert has_any_callables(set(),'add','clear','difference','foo')
    assert has_any_callables(frozenset(),'isdisjoint','issubset','foo')
    assert has_any_callables('foo','capitalize','center','isdigit','foo')
    assert has_any_callables(1,'conjugate','from_bytes','foo')
    assert has_any_callables([1,2,3],'append','insert','foo')
    assert has_any_callables(dict(a=1,b=2),'get','items','keys','values','foo')

# Generated at 2022-06-25 17:30:45.697567
# Unit test for function has_callables
def test_has_callables():

    # Case 0 - not callable
    classes = (1, str, list)
    assert has_callables(classes) == False, \
        'Value returned is {}, should be False'.format(has_callables(
            classes))

    # Case 1 - callable
    classes = (1, str, list, dict.get)
    assert has_callables(classes) == True, \
        'Value returned is {}, should be True'.format(has_callables(
            classes))

    # Case 2 - all callable
    classes = (list.insert, str.upper, dict.get)
    assert has_callables(classes) == True, \
        'Value returned is {}, should be True'.format(has_callables(
            classes))

    # Case 3 - all callable

# Generated at 2022-06-25 17:30:47.391078
# Unit test for function has_callables
def test_has_callables():
    c = has_callables(bytes(), 'decode', 'encode')
    print(c)
    assert c == False

