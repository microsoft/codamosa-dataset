

# Generated at 2022-06-25 17:20:55.186366
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    int_0 = has_any_callables(list_0)
    return int_0



# Generated at 2022-06-25 17:21:02.838225
# Unit test for function has_any_callables
def test_has_any_callables():
    import numbers
    my_dict = {}
    assert has_any_callables(my_dict, 'get', 'keys', 'items', 'values')
    assert has_any_callables(my_dict, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(numbers, 'Complex')
    assert has_any_callables(numbers, 'Complex', 'Real')
    assert has_any_callables(numbers, 'Real')
    assert has_any_callables(numbers.Complex, 'real', 'imag')
    assert has_any_callables(numbers.Complex, 'real', 'imag', 'foo')



# Generated at 2022-06-25 17:21:04.953918
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(name='bob', age=0)
    assert has_any_callables(obj, 'name', 'age', 'foo') is True



# Generated at 2022-06-25 17:21:10.364778
# Unit test for function has_any_callables
def test_has_any_callables():
    list_instance = list()
    assert has_any_callables(list_instance) is True
    dict_instance = dict()
    assert has_any_callables(dict_instance, 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-25 17:21:16.033998
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict(a=1, b=2, c=3)
    bool_0 = has_callables(dict_0, 'get')


# Generated at 2022-06-25 17:21:24.464508
# Unit test for function has_callables
def test_has_callables():
    # Case 0: False
    list_0 = []
    bool_0 = has_callables(list_0)
    assert bool_0 is False
    # Case 1: True
    string_0 = 'hello world'
    bool_1 = has_callables(string_0)
    assert bool_1 is True


# Generated at 2022-06-25 17:21:29.367111
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    has_callables(dict_0, 'get', 'items', 'values')


# Generated at 2022-06-25 17:21:33.193281
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'values', 'items', 'get') == True


# Generated at 2022-06-25 17:21:36.547713
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([], 'append', 'clear') is True
    assert has_any_callables([], 'foo', 'bar') is False


# Generated at 2022-06-25 17:21:44.593676
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test for empty obj, attrs should fail
    list_0 = []
    assert has_any_callables(list_0) is False
    # Test for non empty obj, non empty list of attrs
    dict_0 = dict()
    assert has_any_callables(dict_0, 'get', 'keys', 'setdefault', 'items', 'values') is True
    # Test for obj only, no attrs
    set_0 = {1, 2, 3}
    assert has_any_callables(set_0) is False
    # Test for obj with attr that is not callable
    str_0 = 'hello'
    assert has_any_callables(str_0, 'isascii', 'islower', 'count') is False
    # Test for obj with attr that is callable
    assert has_

# Generated at 2022-06-25 17:21:58.645934
# Unit test for function has_callables
def test_has_callables():
    import collections as _collect
    list_0 = [1, 2]
    func_0 = has_callables(list_0, 'extend')
    assert func_0 is True
    #
    set_0 = _collect.Counter({1, 2})
    func_1 = has_callables(set_0, 'keys')
    assert func_1 is True
    #
    datetime_0 = datetime.now()
    func_2 = has_callables(datetime_0, 'month')
    assert func_2 is True
    #
    datetime_1 = datetime.now()
    func_3 = has_callables(datetime_1, 'seconds')
    assert func_3 is True
    #
    datetime_2 = datetime.now()

# Generated at 2022-06-25 17:22:06.703976
# Unit test for function has_callables
def test_has_callables():
    '''
    Check that the function has_callables
    behaves as expected.
    '''
    list_1 = [1, 2, 3]
    bool_1 = has_callables(list_1)
    assert bool_1 == False



# Generated at 2022-06-25 17:22:13.935611
# Unit test for function has_any_callables
def test_has_any_callables():
    # 1. Make sure that empty list is not list-like
    empty_list = []
    assert has_any_callables(empty_list, 'get') == False

    # 2. Make sure that string is not list-like
    test_string = 'Wet floor!'
    assert has_any_callables(test_string, 'get') == False

    # 3. Make sure that list-like object are list-like
    test_list_like = [1, 2, 3, 4]
    assert has_any_callables(test_list_like, 'get') == True



# Generated at 2022-06-25 17:22:26.062529
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test case 0:
    # Given the following input:
    #   obj = "something"
    #   *attrs = "upper", "strip", "something_else"
    #
    # Expected result:
    #   True
    obj = "something"
    *attrs = "upper", "strip", "something_else"
    expected = True
    actual = has_any_callables(obj, *attrs)
    assert expected == actual
    print(actual)  # True
    print()

    # Test case 1:
    # Given the following input:
    #   obj = 1
    #   *attrs = "upper", "strip", "something_else"
    #
    # Expected result:
    #   False
    obj = 1

# Generated at 2022-06-25 17:22:31.898646
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get')
    assert has_callables(dict(), 'get', 'items')
    assert has_callables(dict(), 'keys', 'values')
    assert not has_callables(dict(), 'get', 'items', 'foo')
    assert not has_callables(dict(), 'foo1', 'foo2', 'foo3')
    assert not has_callables(dict(), 'foo')


# Generated at 2022-06-25 17:22:42.217514
# Unit test for function has_callables
def test_has_callables():
    """test_has_callables
    """
    print(f'*** TEST {test_has_callables.__name__} ***')

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(list, 'append') is True
    assert has_callables(str, 'find') is True



# Generated at 2022-06-25 17:22:51.668494
# Unit test for function has_any_attrs
def test_has_any_attrs():
    a = dict()
    b = None
    c = []
    d = ()
    e = {'a':1}
    assert has_any_attrs(a, 'get','keys','items','values','something')
    assert has_any_attrs(b, 'get','keys','items','values','something') == False
    assert has_any_attrs(c, 'get','keys','items','values','something') == False
    assert has_any_attrs(d, 'get','keys','items','values','something') == False
    assert has_any_attrs(e, 'get','keys','items','values','something')



# Generated at 2022-06-25 17:22:59.047365
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'foo')
    assert isinstance(has_any_callables(obj, 'get', 'keys', 'foo'), bool)
    assert not has_any_callables(obj, 'foo')
    assert has_any_callables(obj, 'get')
    assert isinstance(has_any_callables(obj, 'get', 'keys', 'foo'), bool)



# Generated at 2022-06-25 17:23:01.785189
# Unit test for function has_any_attrs
def test_has_any_attrs():
    result = has_any_attrs(dict(),'get','keys','items','values','something')
    assert result is True


# Generated at 2022-06-25 17:23:04.282211
# Unit test for function has_callables
def test_has_callables():
    class Foo:
        def bar():
            print('bar')

    obj = Foo()
    assert has_callables(obj, 'bar') is True
    assert has_callables(obj, 'foo') is False


# Generated at 2022-06-25 17:23:16.550093
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = [1,2,3]
    list_1 = list_0[1:]
    test_0 = has_any_callables(list_0, 'append', 'insert', 'extend', '__getitem__', '__iter__')
    assert test_0, "List instance should have any of the methods checked"
    test_1 = has_any_callables(list_1, 'append', 'insert', 'extend', '__getitem__', '__iter__')
    assert test_1, "Iterator instance should have any of the methods checked"


# Generated at 2022-06-25 17:23:21.588059
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Test function has_any_callables
    """
    testCase = TestCase()
    testCase.assertTrue(has_any_callables([1, 2, 3], 'append', 'remove'))


# Generated at 2022-06-25 17:23:25.574230
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables by checking that obj has the attrs which
    are callables.
    """
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-25 17:23:32.118308
# Unit test for function has_any_callables
def test_has_any_callables():
    test_class1 = type('test_class1', (object,), {'__call__': lambda: 0})
    test_class2 = type('test_class2', (object,), {'__call__': lambda: 0, 'foo': 0})
    test_class3 = type('test_class3', (object,), {'__call__': lambda: 0, 'bar': 0})
    test_class4 = type('test_class4', (object,), {'foo': 0, 'bar': 0})

    test_obj1 = test_class1()
    test_obj2 = test_class2()
    test_obj3 = test_class3()
    test_obj4 = test_class4()

    # test_obj1 obj has callables

# Generated at 2022-06-25 17:23:36.542119
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    bool_0 = has_any_callables(list_0)


# Generated at 2022-06-25 17:23:44.806154
# Unit test for function has_callables
def test_has_callables():
    # Test case 1
    obj = dict()
    actual = has_callables(obj,'get','keys','values')
    assert actual
    # Test case 2
    obj = dict()
    actual = has_callables(obj,'get','keys','values','foo')
    assert not actual


# Generated at 2022-06-25 17:23:59.126163
# Unit test for function has_attrs
def test_has_attrs():
    list_0 = []
    bool_0 = has_attrs(list_0, 'append' )

    dict_0 = {}
    bool_0 = has_attrs(dict_0, 'update' )

    bool_0 = has_attrs(dict_0, 'update', 'get' )
    bool_0 = has_attrs(dict_0, 'update', 'setdefault' )

    int_0 = 0
    bool_0 = has_attrs(int_0, 'bit_length' )

    str_0 = ''
    bool_0 = has_attrs(str_0, 'capitalize' )

    list_0 = []
    bool_0 = has_attrs(list_0, 'append', 'count' )

# Generated at 2022-06-25 17:24:05.554795
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict

    list_0 = list()
    test_result = has_callables(list_0, 'append')
    assert test_result is True

    set_0 = set()
    test_result = has_callables(set_0, 'add')
    assert test_result is True

    tuple_0 = tuple()
    test_result = has_callables(tuple_0)
    assert test_result is False

    frozenset_0 = frozenset()
    test_result = has_callables(frozenset_0)
    assert test_result is False

    ordereddict_0 = OrderedDict()
    test_result = has_callables(ordereddict_0, '__iter__', '__setitem__')
    assert test_result is True

    string_0 = str()

# Generated at 2022-06-25 17:24:09.821599
# Unit test for function has_callables
def test_has_callables():
    '''
    Function test_has_callables
    Author: xfli
    Date: 2020/06/12
    '''
    result = has_callables(dict(),'get','keys','items','values')
    if result:
        print('True')
    else:
        print('False')

# Generated at 2022-06-25 17:24:24.815217
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert(
        has_any_callables(
            [], 'pop', 'append', 'clear', 'copy', 'count', 'extend', 'index',
            'insert', 'pop', 'remove', 'reverse', 'sort'
        ) is True
    )
    assert(
        has_any_callables(
            [], 'pop', 'append', 'clear', 'copy', 'count', 'extend', 'index',
            'insert', 'pop', 'remove', 'reverse'
        ) is True
    )
    assert(
        has_any_callables(
            [], 'pop', 'append', 'clear', 'copy', 'count', 'extend', 'index'
        ) is True
    )

# Generated at 2022-06-25 17:24:35.151625
# Unit test for function has_attrs
def test_has_attrs():
    assert(has_attrs('test') is False)
    assert(has_attrs(dict(), 'keys', 'values') is True)
    assert(has_attrs(dict(), 'keys', 'get_all') is False)
    assert(has_attrs(dict(), 'keys', 'get_all', 'values') is False)


# Generated at 2022-06-25 17:24:43.179110
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str(), '__add__', '__contains__', '__iter__') is True
    assert has_callables(str(), '__add__', '__contains__') is True
    assert has_callables(str(), '__contains__') is True
    assert has_callables(str(), '__add__', '__contains__', '_map') is False
    assert has_callables(str(), '__add__', '__contains__', '_map', '_filter') is False
    assert has_callables(str(), '__add__', '__contains__', '_map', '__iter__') is False


# Generated at 2022-06-25 17:24:44.903013
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True

# Generated at 2022-06-25 17:24:47.751995
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    attr = ['get', 'set']
    result = has_any_callables(obj, *attr)



# Generated at 2022-06-25 17:24:58.224308
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo')
    assert has_callables(dict_0, 'get', 'keys', 'items', 'values') is False
    assert has_callables(dict_0, 'get', 'keys', 'items', 'values', '__len__')
    assert has_attrs(dict_0, 'get', 'keys', 'items', 'values', '__len__')
    assert has_attrs(dict_0, '__len__') is False
    assert has_attrs(dict_0) is False


# Generated at 2022-06-25 17:25:07.364166
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables

    class foo(object):
        @staticmethod
        def z() -> int: return 0

    assert has_callables(list(), 'append', 'pop', 'extend') is True
    assert has_callables(list(), 'append', 'pop', 'extend', 'foo') is False
    assert has_callables(foo, 'append', 'pop', 'extend', 'z') is True
    assert has_callables(foo, 'append', 'pop', 'extend', 'foo') is False
    assert has_callables(foo, 'z') is True
    assert has_callables(foo, 'foo') is False



# Generated at 2022-06-25 17:25:19.705793
# Unit test for function has_attrs
def test_has_attrs():
    list_0 = []
    bool_0 = has_attrs(list_0, 'append', 'extend', 'insert', 'remove', 'sort')
    assert bool_0 is True, f"has_attrs({list_0!r}, 'append', 'extend', 'insert', 'remove', 'sort') returned {bool_0!r}, should have returned True"
    dict_0 = {}
    bool_0 = has_attrs(dict_0, 'get', 'keys', 'items', 'values')
    assert bool_0 is True, f"has_attrs({dict_0!r}, 'get', 'keys', 'items', 'values') returned {bool_0!r}, should have returned True"
    bool_0 = has_attrs(dict_0, 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-25 17:25:29.188694
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables([1, 2, 3], 'append', 'clear', 'extend', 'foo')
    assert has_any_callables(set([1, 2, 3]), 'add', 'clear', 'difference', 'foo')
    assert has_any_callables(
        frozenset([1, 2, 3]), 'difference', 'intersection', 'isdisjoint', 'foo')
    assert has_any_callables(tuple([1, 2, 3]), 'count', 'index', 'foo')
    assert has_any_callables(deque([4, 5, 6]), 'append', 'clear', 'extend', 'foo')

# Generated at 2022-06-25 17:25:31.308291
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'fromkeys','get','keys','items','values') is True


# Generated at 2022-06-25 17:25:41.217581
# Unit test for function has_callables
def test_has_callables():
    prog = 'flutils.utils', 'test_has_callables'
    obj = dict(a=1, b=2)
    attrs = 'keys', 'values', 'items'
    assert has_callables(obj, *attrs) is True
    attrs = 'foo', 'bar', 'baz'
    assert has_callables(obj, *attrs) is False
    attrs = 'a', 'b', 'c'
    assert has_callables(obj, *attrs) is False
    attrs = 'clear', 'get', 'items'
    assert has_callables(obj, *attrs) is True
    attrs = 'clear', 'keys', 'items'
    assert has_callables(obj, *attrs) is True
    attrs = 'clear', 'keys', 'baz'
   

# Generated at 2022-06-25 17:25:53.487555
# Unit test for function has_callables
def test_has_callables():
    import collections

    class ABC(collections.abc.MutableSequence):
        def __getitem__(self, item):
            pass

        def __setitem__(self, key, value):
            pass

        def __delitem__(self, key):
            pass

        def insert(self, key, value):
            pass

    abc = ABC()
    print(has_callables(abc, '__getitem__', '__setitem__', 'insert'))
    print(has_callables(abc, '__getitem__', '__setitem__', '__missing__'))
    print(has_callables(dict(), '__setitem__', '__getitem__', '__missing__'))

# Generated at 2022-06-25 17:26:00.271447
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test when attribute is callable
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'keys','values')
    assert has_any_callables(dict(),'get')

    # Test when attribute is not callable
    assert not has_any_callables(dict(),'__doc__')
    assert not has_any_callables(dict(),'__doc__','__repr__')
    assert not has_any_callables(dict(),'__repr__','__doc__')

    # Test when obj does not have a callable attribute
    assert not has_any_callables(dict(),'foo')
    assert not has_any_callables(dict(),'foo','bar')

# Generated at 2022-06-25 17:26:02.091697
# Unit test for function has_callables
def test_has_callables():
    list_0 = []
    has_callables(list_0, 'sort', 'copy')



# Generated at 2022-06-25 17:26:04.797407
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(
        list_0,
        'get',
        'keys',
        'items',
        'values'
    )


# Generated at 2022-06-25 17:26:08.986074
# Unit test for function has_callables
def test_has_callables():
    assert has_callables([], 'append', 'remove')
    assert has_callables([], 'something', 'something_else') is False



# Generated at 2022-06-25 17:26:11.905940
# Unit test for function has_callables
def test_has_callables():
    dict_0 = {}
    bool_0 = has_callables(dict_0)



# Generated at 2022-06-25 17:26:22.594716
# Unit test for function has_callables
def test_has_callables():
    class Foo(object):
        def __init__(self):
            self.a = 1
            self.b = 2

        def foo(self):
            return 3

        def bar(self):
            return 4

    foo = Foo()
    result = has_callables(foo, 'a')  # False
    assert result is False

    result = has_callables(foo, 'b')  # False
    assert result is False

    result = has_callables(foo, 'a', 'b')  # False
    assert result is False

    result = has_callables(foo, 'foo')  # True
    assert result is True

    result = has_callables(foo, 'bar')  # True
    assert result is True

    result = has_callables(foo, 'foo', 'bar')  # True
    assert result

# Generated at 2022-06-25 17:26:34.164544
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test case 0: values that are list and are populated with values
    test_case_0()
    # Test case 1: values that are empty list
    list_1 = []
    bool_1 = has_any_callables(list_1, 'get', 'keys', 'items', 'values')
    assert bool_1 is False
    # Test case 2: values that are a dictionary and are populated with values
    dict_2 = {}
    bool_2 = has_any_callables(dict_2, 'get', 'keys', 'items', 'values')
    assert bool_2 is True
    # Test case 3: values that are a dictionary and are empty
    dict_3 = {}
    bool_3 = has_any_callables(dict_3, 'get', 'keys', 'items', 'values')
    assert bool_3 is True

# Generated at 2022-06-25 17:26:38.226418
# Unit test for function has_callables
def test_has_callables():
    list_like = []
    result = has_callables(list_like, 'append', 'remove')
    assert result == True

    result = has_callables(list_like, 'foo', 'bar')
    assert result == False


# Generated at 2022-06-25 17:26:48.856889
# Unit test for function has_callables
def test_has_callables():
    list_0 = []
    bool_0 = has_callables(list_0)
    assert bool_0 is False
    float_0 = float()
    bool_0 = has_callables(float_0)
    assert bool_0 is False
    str_0 = str()
    bool_0 = has_callables(str_0)
    assert bool_0 is False
    list_0 = []
    bool_0 = has_callables(list_0, '')
    assert bool_0 is False
    list_0 = []
    bool_0 = has_callables(list_0, '')
    assert bool_0 is False
    int_0 = int()
    bool_0 = has_callables(int_0, '')
    assert bool_0 is False
    str_0 = str()
    bool

# Generated at 2022-06-25 17:27:02.340328
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_dict = dict(a=1, b=2)
    obj_dict_attrs = (
        'clear',
        'copy',
        'fromkeys',
        'get',
        'items',
        'keys',
        'pop',
        'popitem',
        'setdefault',
        'update',
        'values',
        '__contains__',
        '__eq__',
        '__ge__',
        '__getitem__',
        '__gt__',
        '__iter__',
        '__le__',
        '__len__',
        '__lt__',
        '__ne__',
        '__repr__',
        '__reversed__',
        '__setitem__',
    )
    obj_list = list()
    obj_list_attrs

# Generated at 2022-06-25 17:27:14.329295
# Unit test for function has_callables
def test_has_callables():
    '''
    Return True if all items in the attrs lists has callables and True,
    otherwise False.
    '''
    # print(has_callables(tuple(), '__getitem__', '__add__'))

    # tuple returns True
    assert has_callables(
        tuple(), '__getitem__', '__add__') is True

    # tuple returns False
    assert has_callables(tuple(), 'pop', 'append') is False

    # dict returns True
    assert has_callables(dict(), 'pop', 'values') is True

    # dict returns False
    assert has_callables(dict(), 'keys', 'get') is False

    # set returns True
    assert has_callables(set(), 'pop', 'add') is True

    # set returns False

# Generated at 2022-06-25 17:27:24.282369
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserList
    from collections.abc import ValuesView
    from collections import defaultdict
    list_0 = list()
    list_1 = UserList()
    list_2 = ValuesView()
    list_3 = defaultdict(list)
    list_4 = defaultdict(set)
    list_5 = defaultdict(dict)
    list_6 = defaultdict(ValuesView)
    list_7 = defaultdict(lambda: 'foo')

    bool_0 = has_any_callables(list_0, 'append', 'sort', 'clear')
    bool_1 = has_any_callables(list_1, 'append', 'sort', 'clear')
    bool_2 = has_any_callables(list_2, 'append', 'sort', 'clear')

# Generated at 2022-06-25 17:27:30.272667
# Unit test for function has_callables
def test_has_callables():
    try:
        list_0 = []
        list_1 = has_callables(list_0,'append','copy','copy','copy','copy')
        assert list_1 == True
    except (AssertionError,):
        raise
    else:
        print('passed: test_has_callables')



# Generated at 2022-06-25 17:27:37.763268
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    bool_0 = has_any_callables(list_0)
    list_0.append(1)
    bool_0 = has_any_callables(list_0)
    bool_0 = has_any_callables(list_0, "__getitem__")
    bool_0 = has_any_callables(dict(), "__contains__")
    bool_0 = has_any_callables(int(), "__str__")
    bool_0 = has_any_callables(int(), "__str__")
    bool_0 = has_any_callables(list_0)
    bool_0 = has_any_callables(dict(), "__contains__")


# Generated at 2022-06-25 17:27:47.856074
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter, OrderedDict
    from types import SimpleNamespace

    # Test for various types of objects.
    test_objects = (
        b'hello world',
        set('hello world'),
        frozenset('hello world'),
        'hello world',
        1,
        1.1,
        SimpleNamespace(),
        Counter(),
        OrderedDict(),
        dict(),
        list(),
    )

    # Test that our function returns False for 'no' attributes.
    for test_object in test_objects:
        assert has_callables(test_object) is False

    # Test that our fuction returns False for 'some' attributes.
    for test_object in test_objects:
        assert has_callables(test_object, 'clear', 'discard', 'foo') is False

    # Test that our

# Generated at 2022-06-25 17:27:55.254488
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Test function has_any_callables.
    """
    list_0 = []
    assert has_any_callables(list_0, 'append', 'sort') is True

    def add_to_list(number):
        list_0.append(number)

    assert has_any_callables(list_0, 'append', add_to_list) is True
    assert has_any_callables(dict, 'get', 'keys', 'items') is True
    assert has_any_callables(dict, 'foo', 'bar') is False
    assert has_any_callables(list_0, 'append', 'sort', 'foo') is True
    assert has_any_callables(list_0, 'foo', 'bar', 'baz', 'bat') is False


# Generated at 2022-06-25 17:28:02.620154
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(),'append','insert','extend') is True
    assert has_callables(list(),'append','insert','foo') is False
    assert has_callables(list, 'append', 'insert', 'extend') is True
    assert has_callables(list, 'append', 'insert', 'foo') is False
    assert has_callables(tuple(), 'count', 'index') is True
    assert has_callables(tuple(), 'count', 'foo', 'index') is False



# Generated at 2022-06-25 17:28:11.356997
# Unit test for function has_callables
def test_has_callables():
    """Test the has_callables() function."""
    assert has_callables(
        set(),
        'add',
    ) is False
    assert has_callables(
        list(),
        'add',
    ) is False
    assert has_callables(
        dict(),
        'add',
    ) is False
    assert has_callables(
        set([1, 2, 3]),
        'add',
    ) is False
    assert has_callables(
        list([1, 2, 3]),
        'add',
    ) is False
    assert has_callables(
        dict(a=1, b=2, c=3),
        'add',
    ) is False

# Generated at 2022-06-25 17:28:18.171079
# Unit test for function has_any_callables
def test_has_any_callables():
    assert callable(dict().get) is True
    assert callable(dict().foo) is False
    assert callable(dict().items) is True
    assert callable(dict().keys) is True
    assert callable(dict().values) is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'something','foo','bar') is False



# Generated at 2022-06-25 17:28:26.221174
# Unit test for function has_any_callables
def test_has_any_callables():
    def test_case_0():
        dict_0 = dict(a=1, b=2)
        bool_0 = has_any_callables(
            dict_0,
            'get',
            'keys',
            'items',
            'values',
            'foo'
        )
    test_case_0()



# Generated at 2022-06-25 17:28:28.301165
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    assert has_callables(dict_0, 'get', 'keys', 'items') is True



# Generated at 2022-06-25 17:28:30.344696
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = []
    bool_0 = has_any_callables(list_0)


# Generated at 2022-06-25 17:28:38.823900
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables({'foo': 'bar'}, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables({'foo': 'bar'}, 'get', 'keys', 'items', 'values', 'bar')
    assert has_any_callables(dict(a=1, b=2, c=3), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(a=1, b=2, c=3), 'get', 'keys', 'items', 'set')
    assert not has_any_callables({'foo': 'bar'}, 'get', 'keys', 'items', 'set')


# Unit test

# Generated at 2022-06-25 17:28:41.990416
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo','__blah__') is False


# Generated at 2022-06-25 17:28:49.443161
# Unit test for function has_callables
def test_has_callables():
    class A:
        def __init__(self, i):
            self.i = i

        def func(self):
            return self.i

    obj = A(5)
    success_0 = has_callables(obj, 'func')
    success_1 = has_callables(obj, 'func', 'i')
    fail_0 = has_callables(obj, 'not_there')
    fail_1 = has_callables(obj, 'not_there', 'i')


# Generated at 2022-06-25 17:28:50.742944
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values')



# Generated at 2022-06-25 17:28:56.703372
# Unit test for function has_callables
def test_has_callables():
    # Checking that the function returns True if the attributes exist and are callable
    functions_pass = {'get', 'keys', 'items', 'values'}
    functions_fail = {'get', 'keys', 'items', 'values', 'foo'}
    obj = dict()
    has_callables_pass = has_callables(obj, *functions_pass)
    has_callables_fail = has_callables(obj, *functions_fail)
    assert has_callables_pass
    assert not has_callables_fail


# Generated at 2022-06-25 17:28:59.969427
# Unit test for function has_any_callables
def test_has_any_callables():
    if not has_any_callables(dict(), 'has_key', 'enough_values'):
        raise AssertionError

    if not has_any_callables(dict(), 'items', '__getitem__'):
        raise AssertionError

    if has_any_callables(dict(), 'items', '__getitem__'):
        raise AssertionError


# Generated at 2022-06-25 17:29:02.713721
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    result = has_callables(obj, 'get', 'keys', 'items', 'values')
    assert result is True, result



# Generated at 2022-06-25 17:29:14.744832
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj_0 = False
    test_attrs_0 = ['__bool__', '__sizeof__', '__reversed__', '__hash__']
    test_result_0 = has_any_callables(test_obj_0, *test_attrs_0)
    assert test_result_0 is False

    test_obj_1 = True
    test_attrs_1 = ['__bool__', '__sizeof__', '__reversed__', '__hash__']
    test_result_1 = has_any_callables(test_obj_1, *test_attrs_1)
    assert test_result_1 is True

    test_obj_2 = 'hello'

# Generated at 2022-06-25 17:29:17.838013
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(bool, 'bit_length')
    assert has_any_callables(False) is False
    assert has_any_callables(True) is False


# Generated at 2022-06-25 17:29:22.383296
# Unit test for function has_any_callables
def test_has_any_callables():
    '''
    Unit test for function has_any_callables
    '''
    bool_0 = False
    bool_1 = has_any_callables(bool_0)
    # test_case_0
    assert(bool_1 == False)



# Generated at 2022-06-25 17:29:31.096180
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test for False
    bool_0 = False
    assert has_any_callables(bool_0) == False

    # Test for True
    bool_1 = True
    assert has_any_callables(bool_1) == True

    # Test for None
    bool_2 = None
    assert has_any_callables(bool_2) == False

    # Test for dict
    dict_0 = dict(a='b', c='d')
    assert has_any_callables(dict_0) == True

    # Test for list
    list_0 = ['a', 'b', 'c']
    assert has_any_callables(list_0) == True

    # Test for tuple
    tuple_0 = ('a', 'b')
    assert has_any_callables(tuple_0) == True

    #

# Generated at 2022-06-25 17:29:41.944241
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = False
    bool_1 = True
    int_0 = 0
    int_1 = 1
    list_0 = []
    list_1 = [i for i in range(100)]
    list_2 = list(range(100))
    dict_0 = {}
    dict_1 = {i: i for i in range(100)}
    dict_2 = dict(a=1, b=2, c=3)
    obj_0 = object()
    obj_1 = object()
    str_0 = ''
    str_1 = "Hello world"
    str_2 = """Hello world"""
    str_3 = r"""Hello world"""
    str_4 = "Hello world"

    assert has_any_callables(bool_0) is False
    assert has_any_callables(bool_1)

# Generated at 2022-06-25 17:29:51.925446
# Unit test for function has_callables
def test_has_callables():
    """Test has_callables"""
    bool_0 = False
    bool_1 = has_callables(bool_0, '__add__')
    bool_2 = bool(bool_1)
    bool_3 = bool(not bool_2)
    bool_4 = not bool_3
    bool_5 = bool(bool_4)
    bool_6 = bool(not bool_5)
    bool_7 = not bool_6
    bool_8 = bool(bool_7)
    bool_9 = bool(not bool_8)
    bool_10 = not bool_9
    bool_11 = bool(bool_10)
    bool_12 = bool(not bool_11)
    bool_13 = not bool_12
    bool_14 = bool(bool_13)

# Generated at 2022-06-25 17:29:53.338719
# Unit test for function has_any_callables
def test_has_any_callables():
    for _ in range(10):
        test_case_0()


# Generated at 2022-06-25 17:30:01.184613
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = False
    bool_1 = True
    float_0 = float('nan')
    float_1 = float('inf')
    float_2 = float('-inf')
    int_0 = 0
    int_1 = 1
    list_0 = [False, True, float_0, float_1, float_2, int_0, int_1]
    dict_0 = dict(a=bool_0, b=bool_1, c=float_0, d=float_1, e=float_2, f=int_0, g=int_1)
    tuple_0 = (bool_0, bool_1, float_0, float_1, float_2, int_0, int_1)
    str_0 = ''
    str_1 = 'abc'

    bool_0 = has_any

# Generated at 2022-06-25 17:30:07.065631
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(iter(list()), '__next__') == True
    assert has_callables(list(), '__next__') == False
    assert has_callables(dict(), '__iter__') == True
    assert has_callables(dict(), '__next__') == False


# Generated at 2022-06-25 17:30:11.278898
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values','foo') is True)

    #bool_0 = False
    #bool_1 = has_any_callables(bool_0)
    #test_case_0()


# Generated at 2022-06-25 17:30:24.206174
# Unit test for function has_callables
def test_has_callables():
    with pytest.raises(AttributeError):
        test_case_0()
    assert(has_callables(bool, '__add__'))
    assert(not has_callables(bool, 'foobar'))
    assert(has_callables(bool, 'foobar', '__add__'))
    assert(has_callables(bool, '__add__', 'foobar'))
    assert(not has_callables(bool, 'foobar', 'barbaz'))
    assert(not has_callables(bool, 'foobar', 'barbaz', 'catfoo'))
    assert(has_callables(bool, '__add__', 'foobar', 'barbaz', 'catfoo'))

# Generated at 2022-06-25 17:30:27.253872
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False



# Generated at 2022-06-25 17:30:30.339476
# Unit test for function has_callables
def test_has_callables():
    my_str = 'hello'
    if has_callables(my_str, 'upper','lower','capitalize','count','split','swapcase','title','zfill'):
        print(my_str.upper())
    else:
        print('something is wrong')


# Generated at 2022-06-25 17:30:38.520622
# Unit test for function has_callables
def test_has_callables():
    assert not has_callables(None, 'getattr')
    assert not has_callables(True, 'getattr')
    assert not has_callables(False, 'getattr')
    assert not has_callables(True, 'some_other_method')
    assert not has_callables(0, 'some_other_method')
    assert not has_callables(0.0, 'some_other_method')
    assert not has_callables(b'', 'some_other_method')
    assert not has_callables(bytearray(), 'some_other_method')
    assert not has_callables(complex(0, 0), 'some_other_method')
    assert not has_callables(complex(1, 1), 'some_other_method')

# Generated at 2022-06-25 17:30:40.010926
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(bool, 'bit_length', 'denominator', 'numerator')



# Generated at 2022-06-25 17:30:45.224516
# Unit test for function has_any_callables
def test_has_any_callables():
    global bool_0, bool_1
    bool_0 = True
    bool_1 = has_any_callables(bool_0)
    assert(bool_0 == bool_1)

if __name__ == '__main__':
    test_case_0()
    test_has_any_callables()

# Generated at 2022-06-25 17:30:50.161393
# Unit test for function has_any_callables
def test_has_any_callables():
    for t in 'bool', 'int', 'str', 'float', 'UserList', 'UserDict', 'UserString', \
             'ChainMap':
        obj = globals().get(t)()
        try:
            assert not has_any_callables(obj)
        except AssertionError as e:
            print(e)
            assert has_any_callables(obj)

if __name__ == '__main__':
    test_case_0()