

# Generated at 2022-06-25 17:21:04.184773
# Unit test for function has_any_callables
def test_has_any_callables():
    ''' Has any callables test '''
    dict_0 = dict()
    assert has_any_callables(dict_0, 'get', 'keys', 'values', 'popitem') is True
    assert has_any_callables(dict_0, 'foo') is False
    dict_0 = {'a': 1, 'b': 2, 'c': 3}
    assert has_any_callables(dict_0, 'get', 'keys', 'values', 'popitem') is True
    assert has_any_callables(dict_0, 'foo') is False
    set_0 = None
    assert has_any_callables(set_0, 'get', 'keys', 'values', 'popitem') is False
    assert has_any_callables(set_0, 'foo') is False


# Generated at 2022-06-25 17:21:10.798835
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class TestClass(object):

        def __init__(self, name, age):
            self.name = name
            self.age = age

        def compare(self):
            pass

    test_dict = TestClass('test', 30)
    assert has_any_attrs(test_dict, 'name', 'age')
    assert not has_any_attrs(test_dict, 'gender')



# Generated at 2022-06-25 17:21:18.224886
# Unit test for function has_callables
def test_has_callables():
    def test_obj():
        def hello():
            pass

        def bye():
            pass

        return {'hello': hello, 'bye': bye, 'foo': 'bar', 'baz': 3}

    assert has_callables(test_obj(), 'hello', 'bye') is True
    assert has_callables(test_obj(), 'hello', 'bye', 'foo') is False
    assert has_callables(test_obj(), 'hello', 'bye', 'baz') is False
    assert has_callables(test_obj(), 'hello', 'bye', 'foo', 'baz') is False

    try:
        has_callables(test_obj(), 'wazzup')
        raise ValueError
    except AttributeError:
        pass



# Generated at 2022-06-25 17:21:23.446452
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(hello='world')
    attrs = ('keys', 'items', 'values', 'foo')
    assert has_any_callables(obj, attrs) is True


# Generated at 2022-06-25 17:21:26.402199
# Unit test for function has_any_callables
def test_has_any_callables():
    set_0 = None
    bool_0 = has_any_callables(set_0)


# Generated at 2022-06-25 17:21:37.750887
# Unit test for function has_callables
def test_has_callables():
    # Try has_callables on a list
    l = [1,2,3,4]
    assert has_callables(l, 'append', 'clear', 'insert')

    # Try has_callables on a dict
    d = {'a' : 1, 'b' : 2, 'c' : 3}
    assert has_callables(d, 'clear', 'copy', 'popitem')

    # Try has_callable on a str
    s = 'Testing has_callables'
    assert has_callables(s, 'count', 'casefold', 'split')


# Generated at 2022-06-25 17:21:40.892735
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(None,'get','keys','items','values','something')


# Generated at 2022-06-25 17:21:44.647159
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = {
        'a': 1,
        'b': [2, 3, 4],
        'c': {'d': 5, 'e': 6},
    }
    result = has_any_attrs(obj, 'b', 'c', 'd')
    print(result)



# Generated at 2022-06-25 17:21:50.811136
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict_0, 'foo', 'bar', 'baz') is False


# Generated at 2022-06-25 17:21:55.662240
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = [1, 2, 3]
    attrs = ['append', 'keys', 'items', 'foo']
    bool_0 = has_any_callables(list_0, *attrs)



# Generated at 2022-06-25 17:22:11.273615
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserDict, UserList, UserString
    from collections import defaultdict
    from collections import ChainMap
    from collections import Counter
    from collections import OrderedDict
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from collections import namedtuple
    from collections import deque
    import decimal

    assert has_attrs(ChainMap, 'maps')
    assert has_attrs(Counter, 'get')
    assert has_attrs(OrderedDict, 'get')
    assert has_attrs(deque, 'append')
    assert has_attrs(namedtuple, '_fields')
    assert has_attrs(ValuesView, '__iter__')
    assert has_attrs(KeysView, '__iter__')
    assert has_attrs

# Generated at 2022-06-25 17:22:25.047268
# Unit test for function has_any_callables
def test_has_any_callables():
    import unittest
    from collections import UserList

    # Test function has_any_callables
    class TestHasAnyCallables(unittest.TestCase):
        def test_1(self):
            self.assertTrue(has_any_callables('test', 'upper'))
            self.assertFalse(has_any_callables('test', 'bad'))

        def test_2(self):
            self.assertTrue(has_any_callables(UserList(), 'pop'))
            self.assertFalse(has_any_callables(UserList(), 'bad'))

        def test_3(self):
            self.assertTrue(has_any_callables(dict(), 'get'))
            self.assertFalse(has_any_callables(dict(), 'bad'))

    unittest.main()

#

# Generated at 2022-06-25 17:22:32.469994
# Unit test for function has_any_callables
def test_has_any_callables():
    """Check function has_any_callables
    """
    objs_0 = [
        set(),
        frozenset(),
        Counter(),
        OrderedDict(),
        UserDict(),
        defaultdict(),
        defaultdict(int),
        defaultdict(str),
        deque(),
        int(),
        float(),
        str(),
        bool(),
        bytes(),
        decimal.Decimal(),
        list(),
        tuple(),
        dict(),
    ]


# Generated at 2022-06-25 17:22:44.034476
# Unit test for function has_callables
def test_has_callables():
    # Test 1.
    dict_0 = dict(a=1, b=2)
    bool_0 = has_callables(dict_0, 'keys', 'values', 'items')
    if bool_0 is False:
        raise ValueError
    # Test 2.
    list_0 = [1, 2, 3]
    bool_1 = has_callables(list_0, 'append', 'index', 'sort')
    if bool_1 is False:
        raise ValueError
    # Test 3.
    list_0 = [1, 2, 3]
    bool_1 = has_callables(list_0, 'keys', 'values', 'items')
    if bool_1 is True:
        raise ValueError


# Generated at 2022-06-25 17:22:53.011631
# Unit test for function has_callables
def test_has_callables():
    args = (dict(), 'get', 'keys', 'items', 'values')
    assert(has_callables(*args)) is True

    args = (dict(), 'get', 'keys', 'items', 'foo')
    assert(has_callables(*args)) is True

    args = (dict(), 'get', 'keys', 'items', 'foo')
    assert(has_callables(*args)) is True

    args = (dict(), 'get', 'keys', 'iterms', 'foo')
    assert(has_callables(*args)) is False

    # this should not raise an error
    args = (dict(),)
    assert(has_callables(*args)) is False


# Generated at 2022-06-25 17:22:55.491771
# Unit test for function has_attrs
def test_has_attrs():
    is_subclass_of_any(list(), list)


# Generated at 2022-06-25 17:23:02.295753
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(list(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'something', 'something_else')
    assert not has_any_callables(bool(), 'something', 'something_else')



# Generated at 2022-06-25 17:23:08.031719
# Unit test for function has_callables
def test_has_callables():
    """Unit tests for function: has_callables().
    """
    # Checked if has_callables returns True when given an object that
    # has attributes that can be called.
    obj = dict(a=1, b=2)
    attrs = 'get', 'keys', 'items', 'values'
    assert has_callables(obj, *attrs), "has_callables(obj,*attrs) returns False" \
                                       " for obj: {obj} and attrs: {attrs}".format(
                                            obj=obj, attrs=attrs)

    # Checked if has_callables returns False when given an object that
    # has attributes that callable.
    attrs = 'get', 'keys', 'items', 'values', 'foo'

# Generated at 2022-06-25 17:23:12.395464
# Unit test for function has_attrs
def test_has_attrs():
    list_0 = list()
    assert has_attrs(list_0, 'append')

    obj_0 = TestClass()
    assert has_attrs(obj_0, 'foo')



# Generated at 2022-06-25 17:23:26.781016
# Unit test for function has_any_callables
def test_has_any_callables():
    class A:
        def foo(self):
            pass

        def bar(self):
            pass

        def baz(self):
            return 42

    class B:
        def foo(self):
            pass

        def baz(self):
            return 42

        @classmethod
        def moo(cls):
            pass

    a = A()
    assert has_any_callables(a, 'foo', 'bar') is True
    assert has_any_callables(a, 'baz') is False
    assert has_any_callables(a, 'moo') is False
    assert has_any_callables(a, 'foo', 'moo') is True

    assert has_any_callables(a, 'baz', 'bar') is True

# Generated at 2022-06-25 17:23:39.152079
# Unit test for function has_callables
def test_has_callables():
    """Test ``has_callables``"""

    test_obj = dict(
        foo=lambda x: x + 1,
        bar=lambda x, y: x + y,
        baz=lambda x: None,
    )
    # True
    assert has_callables(test_obj, 'foo', 'bar', 'baz') is True

    # False
    assert has_callables(test_obj, 'bar', 'baz') is False



# Generated at 2022-06-25 17:23:45.687951
# Unit test for function has_callables
def test_has_callables():
    var_0 = list()
    var_1 = var_0 != 0 and has_callables( var_0,  "__iter__",  "__setitem__",  "__contains__",  "__len__")
    # assert var_1 == 1


# Generated at 2022-06-25 17:23:51.349694
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    var_0 = has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo')
    # assert var_0 == True


if __name__ == '__main__':
    test_case_0()
    test_has_any_callables()

# Generated at 2022-06-25 17:23:59.348800
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(a=1,b=2),'get','keys','items','values','foo')
    assert has_any_callables(dict(a=1,b=2),'get','keys','items','values')
    assert not has_any_callables(dict(),'get','keys','items','values')
    assert not has_any_callables(dict(a=1,b=2),'foo')
    assert not has_any_callables(dict())


# Generated at 2022-06-25 17:24:07.093767
# Unit test for function has_any_callables
def test_has_any_callables():
    var_0 = list()
    var_1 = has_any_callables(list, 'sort')
    var_2 = has_any_callables(var_0, 'sort')
    var_3 = has_any_callables(var_0, 'sort', 'reverse')
    var_4 = has_any_callables(var_0, 'sort', 'reverse', 'whatever')


# Generated at 2022-06-25 17:24:13.214235
# Unit test for function has_callables
def test_has_callables():
    obj = dict(
        a=lambda: True
    )

    assert has_callables(obj, 'a') is True
    assert has_callables(obj, 'a', 'b') is False
    assert has_callables(obj, 'b', 'c', 'd') is False
    assert has_callables(obj, 'a', 'b', 'c', 'd') is False


# Generated at 2022-06-25 17:24:20.943945
# Unit test for function has_any_callables
def test_has_any_callables():
    c = 0
    assert has_any_callables(test_case_0, 'append', 'extend', 'foo') == True
    # Unit test with bad input
    assert has_any_callables(test_case_0, 'foo', 'foo1', 'foo2') == False
    # Unit test with no input
    assert has_any_callables(test_case_0) == False
    return c

# Generated at 2022-06-25 17:24:25.574782
# Unit test for function has_any_callables
def test_has_any_callables():
    import random
    import string
    var_1 = ''.join(random.choice(string.ascii_lowercase) for x in range(10))
    v = (has_any_callables(var_1, 'zfill'), var_1)
    assert v[0] == False
    assert v[1] == v[1]


# Generated at 2022-06-25 17:24:40.196336
# Unit test for function has_callables
def test_has_callables():
    #
    # Test with a simple class
    #
    class MyClass(object):
        def __init__(
                self,
        ):
            self.a = 1
            self.b = 2
            self.c = [1, 2, 3]
            self.d = 3
            self.e = 4
            self.f = [4, 5, 6]
            self.g = 5
            self.h = 'hello'
            self.i = 'world'
            self.j = '!'.split()

        def do_something(self, a: int, b: int) -> int:
            return a + b

        def do_something_else(
                self,
                a: int,
                b: int,
        ) -> int:
            return a + b

    my_object = MyClass()
   

# Generated at 2022-06-25 17:24:42.476960
# Unit test for function has_any_callables
def test_has_any_callables():
    var_0 = dict(get=None,keys=None,items=None,values=None)
    var_1 = dict(get=None,keys=None,items=None,something=None)


# Generated at 2022-06-25 17:24:55.197002
# Unit test for function has_any_callables
def test_has_any_callables():
    class Foo:
        def foo(self):
            pass
    class Bar:
        def bar(self):
            pass
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'foo') is False
    assert has_any_callables(Foo(),'foo') is True
    assert has_any_callables(Foo(),'bar') is False
    assert has_any_callables(Bar(),'bar') is True
    assert has_any_callables(Bar(),'foo') is False


# Generated at 2022-06-25 17:24:58.581590
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'foo')



# Generated at 2022-06-25 17:25:04.525403
# Unit test for function has_any_callables
def test_has_any_callables():
    var_0 = dict()
    assert has_any_callables(var_0, 'get', 'keys', 'items', 'values', 'foo')
    var_1 = dict()
    assert not has_any_callables(var_1, 'bar', 'foo', 'foobar', 'baz')


# Generated at 2022-06-25 17:25:07.602596
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = list()
    attrs_0 = 'append',
    ret_0 = has_any_callables(obj_0, *attrs_0)
    print(ret_0)


# Generated at 2022-06-25 17:25:20.064915
# Unit test for function has_callables
def test_has_callables():
    obj_0 = dict()
    attr_0 = 'get'
    attr_1 = 'keys'
    attr_2 = 'items'
    attr_3 = 'values'
    attr_4 = 'foo'
    attr_5 = 'bar'
    attr_6 = 'baz'
    attr_7 = 'qux'
    attr_8 = 'quux'
    attr_9 = 'corge'
    attr_10 = 'grault'
    attr_11 = 'garply'
    attr_12 = 'waldo'
    attr_13 = 'fred'
    attr_14 = 'plugh'
    attr_15 = 'xyzzy'
    attr_16 = 'thud'

# Generated at 2022-06-25 17:25:22.781583
# Unit test for function has_callables
def test_has_callables():
    var_1 = dict()
    var_2 = has_callables(var_1, 'get', 'keys', 'items', 'values')
    assert var_2 is True


# Generated at 2022-06-25 17:25:25.061480
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-25 17:25:30.752380
# Unit test for function has_callables
def test_has_callables():
    var_0_obj, var_0_attrs = test_case_0()
    test_1 = has_callables(var_0_obj, var_0_attrs)
    assert test_1


# Generated at 2022-06-25 17:25:39.451473
# Unit test for function has_callables
def test_has_callables():
    print("Testing has_callables()...")
    assert True == has_callables({}, 'get', 'items')
    assert True == has_callables(dict(), 'get', 'items')
    assert True == has_callables(dict(a=1,b=2), 'get', 'items')

    assert False == has_callables({}, 'get', 'items', 'foo')
    assert False == has_callables(dict(), 'get', 'items', 'foo')
    assert False == has_callables(dict(a=1,b=2), 'get', 'items', 'foo')


# Generated at 2022-06-25 17:25:42.020277
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') == False


# Generated at 2022-06-25 17:25:51.611831
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items') == True
    assert has_any_callables(dict(),'get','keys') == True
    assert has_any_callables(dict(),'keys') == True
    assert has_any_callables(dict(),'foo') == False


# Generated at 2022-06-25 17:26:07.426413
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(1, 'append', 'foo', 'bar') == False
    assert has_any_callables(dict(), 'append', 'foo', 'bar') == False
    assert has_any_callables(dict(), 'append', 'foo', 'bar') == False
    assert has_any_callables(list(), 'append', 'foo', 'bar') == True
    assert has_any_callables(set(), 'append', 'add', 'bar') == True
    assert has_any_callables(deque(), 'append', 'foo', 'bar') == True
    assert has_any_callables(
        {'a': 1, 'b': 2, 'c': 3}, 'append', 'items', 'bar') == True

# Generated at 2022-06-25 17:26:13.456657
# Unit test for function has_any_callables
def test_has_any_callables():
    from typing import Any as _Any
    from flutils.objutils import has_any_callables
    var_0 = dict()
    var_1 = has_any_callables(var_0,'get','keys','items','values','foo')
    assert var_1 == True


# Generated at 2022-06-25 17:26:17.206225
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(var_0, 'append', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort') == True


# Generated at 2022-06-25 17:26:21.725486
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(1,'get','keys','items','values','foo') is False
    assert has_any_callables(dict(),'get','keys','items') is True
    assert has_any_callables(1,'get','keys','items') is False
    assert has_any_callables(1,'get','foo','items') is False


# Generated at 2022-06-25 17:26:34.154102
# Unit test for function has_any_callables
def test_has_any_callables():
    test_cases = [
        ('case_0', 'var_0', dict(), ('get', 'keys', 'items', 'values', 'foo'), True),
        ('case_1', 'var_0', dict(), ('keys', 'items', 'values'), True),
        ('case_2', 'var_1', dict(a=1, b=2), ('get', 'keys', 'items', 'values', 'foo'), True),
        ('case_3', 'var_2', dict(a=1, b=2), ('keys', 'items', 'values'), True),
        ('case_4', 'var_3', dict(a=1, b=2), ('pop', 'popitem', 'clear'), True),
    ]

# Generated at 2022-06-25 17:26:40.746927
# Unit test for function has_any_callables
def test_has_any_callables():
    var0 = list()
    assert has_any_callables(var0, 'append', 'extend', 'insert', 'test') is True, "test 0 failed!"
    assert has_any_callables(var0, 'foo', 'bar', 'boo', 'test') is False, "test 1 failed!"
    assert has_any_callables(var0, 'foo', 'bar', 'boo') is False, "test 2 failed!"



# Generated at 2022-06-25 17:26:50.474557
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from typing import (
        Any as _Any,
        Dict as _Dict,
        List as _List,
        Tuple as _Tuple,
    )

    test_cases = _List[Tuple[_Any, _List[str]]]()
    test_cases.append((list(), list()))
    test_cases.append(({}, ['get', 'keys', 'values', 'items']))
    test_cases.append((Counter(), ['get', 'keys', 'values', 'items']))
    test_cases.append((dict(), ['get', 'keys', 'values', 'items']))

# Generated at 2022-06-25 17:26:52.810082
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-25 17:27:01.425393
# Unit test for function has_callables
def test_has_callables():
    print('>>>>> Running function test_has_callables...')
    var_0 = list()
    var_0.append(has_callables(var_0, 'append'))
    var_0 = dict(a=1, b=2)
    var_0.update(dict(c=3))
    var_0.update({'d': 4})
    var_0.pop('a')
    var_0.popitem()
    var_0.popitem()
    var_0.clear()
    print(var_0)


# Generated at 2022-06-25 17:27:17.008224
# Unit test for function has_any_callables
def test_has_any_callables():
    var_0 = list()
    assert has_any_callables(var_0, '__getitem__', '__len__', '__iter__', '__contains__', 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort') is True
    assert has_any_callables(var_0, 'foo', 'bar') is False
    var_1 = dict()
    assert has_any_callables(var_1, '__getitem__', '__iter__', '__contains__', 'copy', 'fromkeys') is True
    assert has_any_callables(var_1, 'foo', 'bar') is False
    var_2 = 'hello'

# Generated at 2022-06-25 17:27:19.999552
# Unit test for function has_any_callables
def test_has_any_callables():
  assert(has_any_callables(dict(),'get','keys','items','values','foo') == True)


# Generated at 2022-06-25 17:27:22.298839
# Unit test for function has_callables
def test_has_callables():
    var_0 = dict(a = 1, b = 1, c = 1)
    assert has_callables(var_0, 'get', 'keys')


# Generated at 2022-06-25 17:27:25.601652
# Unit test for function has_any_callables
def test_has_any_callables():
    var_0 = dict()
    var_1 = (
        'get',
        'keys',
        'items',
        'values'
    )
    var_2 = has_any_callables(var_0, *var_1)
    assert var_2 is True


# Generated at 2022-06-25 17:27:32.315270
# Unit test for function has_any_callables
def test_has_any_callables():
    try:
        assert has_any_callables(dict(), 'get', 'keys', 'values', 'items', 'foo')
        assert not has_any_callables(dict(), 'get', 'keys', 'values', 'items', 'bar')
        assert has_any_callables(dict(), 'foo', 'bar', 'baz')
    except AssertionError:
        assert False



# Generated at 2022-06-25 17:27:34.848297
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict, 'get', 'keys', 'items', 'values', 'something') == True
    assert has_any_callables(dict, 'something') == False


# Generated at 2022-06-25 17:27:38.894231
# Unit test for function has_any_callables
def test_has_any_callables():
    var_0 = set()
    var_1 = (
        callable(var_0.add),
        has_any_callables(var_0, 'add', 'clear'),
    )
    return var_1


# Generated at 2022-06-25 17:27:40.823406
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({'get': lambda: 'foo'}, 'get') is True



# Generated at 2022-06-25 17:27:50.908942
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    # Test for objects that have all the given attrs and are callable.
    var_1 = dict(get=0, keys=1, items=2, values=3)
    print('\nvar_1: ', var_1)
    assert has_callables(var_1, 'get', 'keys', 'items', 'values') is True
    # Test for objects that don't have all the given attrs and are callable.
    var_2 = dict(get=0, keys=1, values=2)
    print('\nvar_2: ', var_2)
    assert has_callables(var_2, 'get', 'keys', 'items', 'values') is False
    # Test for objects that have all the given attrs and are not callable.
    var_

# Generated at 2022-06-25 17:27:57.553092
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'foo') is False
    assert has_any_callables('foo', 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(123, 'foo') is False


# Generated at 2022-06-25 17:28:08.795708
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test each of the examples in the docstring of the function
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-25 17:28:11.474099
# Unit test for function has_any_callables
def test_has_any_callables():
    var_0 = list()
    var_1 = var_0.copy()
    var_2 = var_0.__doc__
    var_3 = var_0.copy
    test_case_0()



# Generated at 2022-06-25 17:28:14.215230
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    test_0 = has_any_callables(dict(), 'update')
    # Should be True
    assert test_0 is True


# Generated at 2022-06-25 17:28:25.768188
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test 1 - Function with one attribute that is not callable.
    class test_has_any_callables_class_1:
        def funct_1(self):
            pass
    if has_any_callables(test_has_any_callables_class_1(), 'funct_1') is True:
        raise AssertionError('Expected False but got True')
    # Test 2 - Function with two attributes, one not callable.
    class test_has_any_callables_class_2:
        def funct_1(self):
            pass
        funct_2 = 'test'
    if has_any_callables(test_has_any_callables_class_2(), 'funct_1', 'funct_2') is True:
        raise AssertionError('Expected False but got True')

# Generated at 2022-06-25 17:28:35.535590
# Unit test for function has_callables
def test_has_callables():
    var_0 = 'foo'
    var_1 = dict()
    var_2 = map(None, reversed(range(0, 10)))
    var_3 = ('foo', 'baz', 0.1, 0.2)
    var_4 = frozenset(range(0, 10))
    var_5 = set([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    var_6 = tuple(range(0, 10))
    var_7 = UserList()
    var_8 = UserList(['foo', 'bar', 'baz'])
    var_9 = UserList(map(None, reversed(range(0, 10))))
    var_10 = UserList(('foo', 'baz', 0.1, 0.2))

# Generated at 2022-06-25 17:28:37.393936
# Unit test for function has_any_callables
def test_has_any_callables():
    print("test_has_any_callables()")
    assert has_any_callables(str(), "startswith", "endswith", "format") is True


# Generated at 2022-06-25 17:28:39.686404
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(test_case_0, 'test_case_0') == True


# Generated at 2022-06-25 17:28:46.221662
# Unit test for function has_any_callables
def test_has_any_callables():
    # Assert True for given test
    var_0 = list()
    assert (has_any_callables(var_0, 'append', 'pop', 'remove') == True)

    # Assert False for given test
    var_1 = False
    assert (has_any_callables(var_1, '__bool__', '__repr__', '__str__') == False)



# Generated at 2022-06-25 17:28:51.398640
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    var_0 = dict()
    assert has_any_callables(var_0, 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-25 17:28:52.633387
# Unit test for function has_callables
def test_has_callables():
    assert has_callables([], 'append')



# Generated at 2022-06-25 17:29:12.651250
# Unit test for function has_callables
def test_has_callables():
    assert has_any_callables(list(), 'append') is True
    assert has_any_callables(list(), 'foo', 'append') is True
    assert has_attrs(list(), 'append', 'count') is True
    assert has_callables(list(), 'append') is True
    assert has_callables(list(), 'count', 'append') is True
    assert has_callables(list(), 'count', 'append', 'foo') is False
    assert has_callables(list(), 'foo') is False
    assert has_callables(list(), 'foo', 'bar') is False
    assert has_callables(list(), 'count', 'foo') is False
    assert has_callables(list(), 'foo', 'count') is False
    assert has_callables(list(), 'foo', 'bar', 'append') is False


# Generated at 2022-06-25 17:29:14.841898
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(list(), 'append', 'clear', 'sort', 'foo') is True



# Generated at 2022-06-25 17:29:25.765517
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(list(), 'append', 'insert', 'extend', 'remove')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(set(), 'add', 'pop', 'difference', 'bar')
    assert has_any_callables(tuple(), 'index', 'count', 'foo', 'bar')
    assert has_any_callables(frozenset(), 'isdisjoint', 'intersection', 'foo', 'bar')
    assert has_any_callables(deque(), 'append', 'popleft', 'remove', 'foo', 'bar')
    assert has_any_callables(dict().keys(), 'copy', 'fromkeys', 'index', 'foo', 'bar')
    assert has_any_

# Generated at 2022-06-25 17:29:29.968740
# Unit test for function has_any_callables
def test_has_any_callables():
    var_1 = dict(a=1, b=2, c=3)
    var_2 = has_any_callables(var_1, 'a', 'b', 'c')
    var_3 = has_any_callables(var_1, 'a')
    var_4 = has_any_callables(var_1, 'd')


# Generated at 2022-06-25 17:29:41.261607
# Unit test for function has_callables
def test_has_callables():
    foobar = 'foobar'
    foobaz = 0
    def foo():
        return None
    qux = has_callables(foobar, 'upper')
    corge = has_callables(foobaz, '__add__')
    grault = has_callables(foo, '__name__')
    garply = has_callables(foobar, '__upper__', 'upper')
    waldo = has_callables(foobar, 'upper', 'lower')
    fred = has_callables(foobaz, '__add__', '__eq__')
    plugh = has_callables(foo, '__name__', '__repr__')
    test_case_0()

# Generated at 2022-06-25 17:29:46.044136
# Unit test for function has_callables
def test_has_callables():
    var_0 = list()
    # test function has_callables
    assert has_callables(var_0, 'append', 'remove', 'clear') is True
    # test function has_callables
    assert has_callables(var_0, 'append', 'clear', 'remove') is True


# Generated at 2022-06-25 17:29:54.430026
# Unit test for function has_callables
def test_has_callables():
    objs_0 = list()
    objs_0.append({})
    objs_0.append(dict())
    objs_0.append(UserDict())
    objs_0.append(UserList())
    names_0 = ['append']
    names_1 = ['keys']
    objs_1 = list()
    objs_1.append(objs_0[0])
    objs_1.append(objs_0[1])
    assert has_callables(objs_1[0], names_0[0]) is False
    assert has_callables(objs_1[1], names_0[0]) is False
    assert has_callables(objs_1[1], names_1[0]) is True

# Generated at 2022-06-25 17:29:55.899861
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-25 17:30:01.329589
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    if has_callables(obj, 'keys', 'items') != True:
        raise AssertionError('Expected: True; Received: {}'.format(
            has_callables(obj, 'keys', 'items')))
    if has_callables(obj, 'keys', 'items', 'something') != False:
        raise AssertionError('Expected: False; Received: {}'.format(
            has_callables(obj, 'keys', 'items', 'something')))


# Generated at 2022-06-25 17:30:13.243330
# Unit test for function has_callables
def test_has_callables():
    var_0 = dict()
    var_1 = dict(a=1, b=2)
    attrs = [
        '__getitem__', '__len__', '__iter__', '__contains__', 'clear', 'copy',
        'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault',
        'update', 'values'
    ]
    assert has_callables(var_0, *attrs) is True
    assert has_callables(var_1, *attrs) is True
    attrs = ['foo', 'bar']
    assert has_callables(var_0, *attrs) is False
    assert has_callables(var_1, *attrs) is False
    attrs = ['get', 'keys', 'foo']
    assert has_call

# Generated at 2022-06-25 17:30:31.362710
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-25 17:30:34.054365
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    assert has_callables({}, 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-25 17:30:37.647440
# Unit test for function has_callables
def test_has_callables():
  assert has_callables([1,2,3], 'extend', 'append', 'insert', 'index', 'remove')
  assert not has_callables(['a','b','c'], 'extend', 'append', 'insert', 'index', 'remove')


# Generated at 2022-06-25 17:30:47.607256
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'get', 'keys', 'values', 'items')
    assert not has_callables(obj, 'get', 'keys', 'values', 'items', 'foo')
    assert not has_callables(obj, 'foo')
    assert has_callables(obj, 'pop', 'popitem', 'clear')
    assert not has_callables(obj, 'pop', 'popitem', 'clear', 'foo')
    assert not has_callables(obj, 'foo')
    assert has_callables(obj, 'update')
    assert not has_callables(obj, 'update', 'foo')
    assert not has_callables(obj, 'foo')
    print('\tFunction "test_has_callables" - Done')
