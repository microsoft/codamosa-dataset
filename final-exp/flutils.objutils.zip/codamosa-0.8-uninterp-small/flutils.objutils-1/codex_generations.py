

# Generated at 2022-06-25 17:21:02.873565
# Unit test for function has_callables
def test_has_callables():
    obj = object()
    assert has_callables(obj) == False

    obj = object()
    assert has_callables(obj, None) == False

    obj = object()
    assert has_callables(obj, '__add__') == False

    obj = object()
    assert has_callables(obj, '__iter__') == False

    obj = object()
    assert has_callables(obj, '__getitem__') == False

    obj = object()
    assert has_callables(obj, '__getitem__', '__add__') == False

    obj = object()
    assert has_callables(obj, '__iter__', '__add__') == False

    obj = object()
    assert has_callables(obj, '__iter__', '__getitem__') == False

    obj = object()

# Generated at 2022-06-25 17:21:16.771961
# Unit test for function has_callables
def test_has_callables():
    class _A(object):
        def _f1(self, a: int) -> int:
            return a + 1
        def _f2(self, a: str) -> str:
            return a + 'abc'
    class _B(_A):
        def _f3(self, a: int) -> int:
            return a + 3
        def _f4(self, a: int) -> int:
            return a + 4
    class _C(_B):
        def _f5(self, a: float) -> float:
            return a + 1.0
        def _f6(self, a: float) -> float:
            return a + 2.0
    class _D(_C):
        def _f7(self, a: int) -> int:
            return a + 7

# Generated at 2022-06-25 17:21:25.447214
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'x', 'y', 'z', 'f') is False


# Generated at 2022-06-25 17:21:29.675424
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-25 17:21:34.768286
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'gkDY\tC"4q'
    bool_0 = has_any_callables(str_0)


# Generated at 2022-06-25 17:21:36.586593
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(str_0, 'split')


# Generated at 2022-06-25 17:21:41.094089
# Unit test for function has_callables
def test_has_callables():
    """
    Test has_callables
    """
    value = has_callables(str(), 'isalnum', 'isalpha', 'isdigit')
    assert value is True

    value = has_callables(str(), 'isalnum', 'isalpha', 'isdigit', 'nonexisting')
    assert value is False



# Generated at 2022-06-25 17:21:47.899382
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),)
    assert has_any_callables(dict(),'foo')
    assert has_any_callables(dict(),'foo','items')
    assert has_any_callables(dict(),'foo','keys')
    assert has_any_callables(dict(),'foo','values')
    assert has_any_callables(dict(),'keys')
    assert has_any_callables(dict(),'values')
    assert has_any_callables(dict(),'foo','get','items','values')
    assert has_any_callables(dict(),'keys','get','items','values')
    assert has_any_callables(dict(),'keys','get','items','foo')
    assert not has_any_callables(dict(),'foo','bar','baz')
    assert not has_any

# Generated at 2022-06-25 17:21:58.045038
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Tests the has_any_callables function
    """
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not None
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is not False


# Generated at 2022-06-25 17:22:04.016671
# Unit test for function has_callables
def test_has_callables():
    test_has_callables_0()
    test_has_callables_1()

# Testing for has_callables with objtype = dict and *attrs = 'get', 'keys', 'items', and 'values'

# Generated at 2022-06-25 17:22:11.686252
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict(a=1, b=2)
    assert has_any_callables(dict_0, 'clear', 'keys', 'foo', 'values') is True
    assert has_any_callables(dict_0) is False



# Generated at 2022-06-25 17:22:15.390886
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(a=0, b=0)
    assert has_any_callables(d, 'items', 'keys', 'values')



# Generated at 2022-06-25 17:22:25.364061
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('', 'upper') == True
    assert has_any_callables('', 'sadf') == False
    assert has_any_callables({'foo': 1}, 'foo', 'values') == True
    assert has_any_callables({'foo': 1}, 'asdf') == True
    assert has_any_callables([1, 2, 3], 'foo', 'values') == False
    assert has_any_callables('', 'zxcv') == False
    assert has_any_callables({'foo': 1}, 'zxcv') == True


# Generated at 2022-06-25 17:22:32.663190
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = [2, 3, 4]
    bool_0 = has_any_callables(obj_0)
    obj_0 = frozenset
    bool_0 = has_any_callables(obj_0)
    print(str(bool_0))
    obj_0 = [0, 0, float(), float()]
    bool_0 = has_any_callables(obj_0)
    print(str(bool_0))
    obj_0 = dict({0: 0})
    bool_0 = has_any_callables(obj_0)
    print(str(bool_0))
    obj_0 = (9, 2, 7)
    bool_0 = has_any_callables(obj_0)
    print(str(bool_0))


# Generated at 2022-06-25 17:22:33.711410
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(a=1, b=2)
    assert has_any_callables(d, 'get', 'keys')



# Generated at 2022-06-25 17:22:39.975744
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(dict, 'get', 'keys', 'items', 'values') == True)
    assert(has_callables(dict, 'get', 'keys', 'items') == False)


# Generated at 2022-06-25 17:22:43.139182
# Unit test for function has_callables
def test_has_callables():
    # Test for default values
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','foo','bar','baz') == False


# Generated at 2022-06-25 17:22:53.413949
# Unit test for function has_any_callables
def test_has_any_callables():
    # Example 1:
    arg_1 = '2)'
    arg_2 = 'upper'
    arg_3 = 'casefold'
    arg_4 = 'lower'
    arg_5 = 'translate'
    arg_6 = 'rfind'
    arg_7 = 'capitalize'
    arg_8 = 'encode'
    arg_9 = 'replace'
    arg_10 = 'swapcase'
    arg_11 = 'center'
    arg_12 = 'find'
    expected_1 = True
    actual_1 = has_any_callables(arg_1, arg_2, arg_3, arg_4, arg_5, arg_6, arg_7, arg_8, arg_9, arg_10, arg_11, arg_12)
    assert actual_1 == expected_1



# Generated at 2022-06-25 17:23:02.585187
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'CypyRtKi1HD'
    dict_0 = dict()
    dict_0['x_Strng_0'] = str_0
    dict_0['x_Strng_0'] = 'K'
    dict_0['x_Dct_0'] = dict()
    dict_0['x_Dct_0']['x_Strng_0'] = 'I'
    dict_0['x_Dct_0']['x_Strng_1'] = '3M'
    dict_0['x_Dct_0']['x_Strng_2'] = 'gO'
    dict_0['x_Dct_0']['x_Strng_3'] = 'hJ'

# Generated at 2022-06-25 17:23:04.317282
# Unit test for function has_callables
def test_has_callables():
    str_0 = 'dSzk6qm\ti9Q'
    bool_0 = has_callables(str_0)


# Generated at 2022-06-25 17:23:11.649562
# Unit test for function has_callables
def test_has_callables():
    str_0 = 'gkDY\tC"4q'
    assert has_callables(str_0) is True



# Generated at 2022-06-25 17:23:17.273728
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict(a=1, b=2, c=3)
    # Check for attributes that exist and are callable
    has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo')
    # Check for attributes that exist but are not callable
    has_any_callables(dict_0, 'keys', 'foo')
    # Check for attributes that don't exist at all
    has_any_callables(dict_0, 'foo', 'bar', 'baz')


# Generated at 2022-06-25 17:23:28.459555
# Unit test for function has_any_callables
def test_has_any_callables():
    err_msg_0 = ''
    str_0 = 'fYT1/b:{\x7f8'
    obj_0 = dict()
    arguments = [obj_0]
    try:
        ret_0 = has_any_callables(*arguments)
    except Exception as exc_0:
        ret_0 = exc_0
    err_msg_0 = err_msg_0 + str_0 + ' ' + str(ret_0) + ' ' + str(type(ret_0)) + '\n'
    assert(ret_0 is not True)
    err_msg_0 = err_msg_0 + str_0 + ' ' + str(ret_0) + ' ' + str(type(ret_0)) + '\n'
    assert(ret_0 is True)

# Generated at 2022-06-25 17:23:35.043332
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables

    assert has_any_callables(
        dict(),
        'get', 'keys', 'items', 'values', 'foo'
    ) is True
    assert has_any_callables(
        dict(),
        'get', 'keys', 'items', 'values', 'foo'
    ) is True
    assert has_any_callables(
        dict(),
        'get', 'keys', 'items', 'values', 'foo'
    ) is True


# Generated at 2022-06-25 17:23:39.546968
# Unit test for function has_any_callables
def test_has_any_callables():
    my_dict = dict()

    my_dict['a'] = 1
    my_dict['b'] = 2
    my_dict['c'] = 3

    if not has_any_callables(my_dict, 'keys'):
        raise AssertionError


# Generated at 2022-06-25 17:23:47.740038
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','bar','values','foo') == False
    assert has_any_callables(12345,'get','keys','bar','values','foo') == False
    assert has_any_callables(None,'get','keys','bar','values','foo') == False


# Generated at 2022-06-25 17:23:50.652337
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1)
    assert has_any_callables(obj) is True


# Generated at 2022-06-25 17:24:00.504368
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import namedtuple
    TestCase = namedtuple('TestCase', 'obj attrs expected_result')

# Generated at 2022-06-25 17:24:11.596374
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'items', 'values')
    assert has_callables(set(), 'intersection')
    assert not has_callables(list(), 'sort')
    assert has_callables(UserList(), 'sort')
    assert has_callables(str_0, 'upper')
    assert not has_callables(str_0, 'upper', 'title')
    assert not has_callables(str_0, 'title')
    assert has_callables(str_0, 'title')
    assert has_callables(str_0, 'title')
    assert has_callables(str_0, 'title')
    assert has_callables(str_0, 'title')
    assert has_callables(str_0, 'title')

# Generated at 2022-06-25 17:24:13.299447
# Unit test for function has_any_callables
def test_has_any_callables():
    nums = [1, 2]
    assert has_any_callables(nums, 'pop') == True



# Generated at 2022-06-25 17:24:23.997738
# Unit test for function has_callables
def test_has_callables():
    from json import loads

    json_0 = '[{"foo":"bar","baz":"quux"}]'
    result = has_callables(loads(json_0))
    assert result



# Generated at 2022-06-25 17:24:37.788188
# Unit test for function has_any_callables

# Generated at 2022-06-25 17:24:46.655863
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test if a list of functions are callable.

    Returns:
        str: JSON.
    """
    from collections import OrderedDict
    json_out = OrderedDict()
    obj = dict(a=1, b=2, c=3)
    for k, v in {'is_callable': [has_any_callables, obj, 'get', 'keys', 'items', 'values', 'foo']}.items():
        json_out[k] = {'args': v[1:], 'returns': v[0](*v[1:])}
        assert callable(v[0])
    return json.dumps(json_out, indent=2)



# Generated at 2022-06-25 17:24:51.220045
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'gkDY\tC"4q'
    bool_0 = has_any_callables(str_0)


# Generated at 2022-06-25 17:25:04.104278
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'gkDY\tC"4q'
    bool_0 = has_any_callables(str_0, 'title', 'center', 'upper', 'join')
    # print('bool(has_any_callables(str_0, "title", "center", "upper", "join"))')
    # print(bool(has_any_callables(str_0, "title", "center", "upper", "join")))
    # print('bool(str_0.title)')
    # print(bool(str_0.title))
    # print('bool(str_0.center)')
    # print(bool(str_0.center))
    # print('bool(str_0.upper)')
    # print(bool(str_0.upper))
    # print('bool(str_0

# Generated at 2022-06-25 17:25:07.563359
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(str.lower))
    assert(has_any_callables(str(),'lower'))
    assert(has_any_callables(str(),'lower', 'upper'))


# Generated at 2022-06-25 17:25:11.702486
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'sV7w\tN:WV'
    assert(has_any_callables(str_0, 'swapcase') == True)


# Generated at 2022-06-25 17:25:18.067126
# Unit test for function has_callables
def test_has_callables():
    """ Unit test for fuction has_callables
    """
    from flutils.objutils import has_callables
    assert has_callables(str_0, 'lower', 'upper', 'replace')
    assert has_callables(str_0, 'lower', 'upper', 'replace', 'foo')
    assert has_callables(str_0, 'lower', 'upper', 'replace', 'foo') is False



# Generated at 2022-06-25 17:25:20.362992
# Unit test for function has_callables
def test_has_callables():
    demo = {'foo': 'bar', 'baz': 'baz'}
    assert has_callables(demo, 'get')


# Generated at 2022-06-25 17:25:22.741126
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'gkDY\tC"4q'
    bool_0 = has_any_callables(str_0)
