

# Generated at 2022-06-25 17:20:52.318630
# Unit test for function has_attrs
def test_has_attrs():
    assert(has_attrs(dict(), 'get', 'keys', 'items', 'values'))
    assert(not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something'))
    assert(has_attrs(dict(), ))


# Generated at 2022-06-25 17:20:58.302432
# Unit test for function has_any_callables
def test_has_any_callables():
    _dict = {}
    _set = set()
    _str = ''
    _int = 0
    _float = 0.0
    _deque = deque()
    _keys = _dict.keys()
    _values = _dict.values()
    _list = [_dict, _set, _str, _int, _float, _deque, _keys, _values]
    _tuple = (_dict, _set, _str, _int, _float, _deque, _keys, _values)
    _int_list = [1, 2, 3, 4]
    _int_tuple = (1, 2, 3, 4)
    _int_deque = deque(_int_list)
    _int_set = set(_int_list)

# Generated at 2022-06-25 17:21:12.492449
# Unit test for function has_any_callables

# Generated at 2022-06-25 17:21:19.527866
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for :func:`.has_callables`.
    """
    # noinspection PyUnusedLocal
    bar = 'foo'

    class Foo:
        # noinspection PyMethodParameters
        def foo(self):
            return True

    foo = Foo()

    assert has_callables(__builtins__, 'abs') is True
    assert has_callables(__builtins__, 'bar') is False
    assert has_callables(__builtins__, 'abs', 'bar') is False
    assert has_callables(__builtins__, 'bar', 'abs') is False
    assert has_callables(foo, 'foo') is True
    assert has_callables(foo, 'bar') is False
    assert has_callables(foo, 'foo', 'bar') is False
    assert has_call

# Generated at 2022-06-25 17:21:25.571636
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_1 = dict(a=1, b=2)
    assert has_any_callables(
        dict_1,
        'get',
        'keys',
        'items',
        'values',
        'something'
    ) is True


# Generated at 2022-06-25 17:21:29.681017
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'bar') is False
    assert has_attrs('hello', 'upper', 'isupper') is True
    assert has_attrs(str(), 'foo', 'bar') is False


# Generated at 2022-06-25 17:21:34.757979
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = "hello"
    bool_0 = has_any_callables(str_0, "upper", "lower")
    assert bool_0 is True



# Generated at 2022-06-25 17:21:43.370629
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for function has_attrs."""
    from collections import OrderedDict

    target_dict = {
        'a': 1,
        'b': 2,
        'c': 3
    }
    ordered_dict = OrderedDict(target_dict)
    assert has_attrs(target_dict, 'items', 'values', 'keys', 'get') is True
    assert has_attrs(ordered_dict, 'items', 'values', 'keys', 'get') is True
    assert has_attrs(target_dict, 'where', 'are', 'the', 'keys') is False
    assert has_attrs(ordered_dict, 'where', 'are', 'the', 'keys') is False



# Generated at 2022-06-25 17:21:45.146071
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items')


# Generated at 2022-06-25 17:21:56.417089
# Unit test for function has_any_callables
def test_has_any_callables():
    _list = [1,2,3]
    _list_str = ['append','__getitem__']
    _dict = {'a':1,'b':1}
    _dict_str = ['pop','popitem']
    _dict_not_callable = ['keys']
    _dict_not_there = ['nothere']

    assert has_any_callables(_list,*_list_str)
    assert has_any_callables(_dict,*_dict_str)
    assert has_any_callables(_dict,*_dict_not_callable)
    assert has_any_callables(_dict,*(_dict_str+_dict_not_callable))
    assert not has_any_callables(_dict,*_dict_not_there)

# Generated at 2022-06-25 17:22:01.566604
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values', 'items') is True



# Generated at 2022-06-25 17:22:13.210686
# Unit test for function has_callables
def test_has_callables():
    # Test 1: Check if has_callables will throw an exception
    try:
        has_callables(list(), 'append', 'sort')
    except:
        raise AssertionError("has_callables is throwing an exception")

    # Test 2: Check if has_callables returns correct value
    obj = dict(get=print, foo="wrong", bar="wrong")
    expected = True
    actual = has_callables(obj, 'get', 'pop', 'keys')
    if not actual == expected:
        raise AssertionError("has_callables didn't return value expected")

    # Test 3: Check if has_callables returns correct value
    obj = dict(get=print, keys="wrong")
    expected = False
    actual = has_callables(obj, 'get', 'pop', 'keys')

# Generated at 2022-06-25 17:22:15.006944
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'something') is True



# Generated at 2022-06-25 17:22:18.479545
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')

# Generated at 2022-06-25 17:22:28.143710
# Unit test for function has_any_callables
def test_has_any_callables():
    """Sample unit test for the ``has_any_callables`` function.
    """
    # noinspection PyUnresolvedReferences
    from collections import (
        Counter,
        ChainMap,
        defaultdict
    )

    class Foo:
        """Sample class with callable and non-callable attributes.
        """
        def __init__(self):
            self.name = 'Foo'
            self.age = 50
            self.date_of_birth = 'April 11, 1969'
            self.is_alive = True

        def bar(self) -> None:
            """Sample callable attribute.
            """
            print(self.bar)

    foo_obj = Foo()
    # noinspection PyUnresolvedReferences

# Generated at 2022-06-25 17:22:35.136314
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')

    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values')

    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

    assert not has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'foo')


if __name__ == '__main__':
    test_case_0()
    test_has_callables()

# Generated at 2022-06-25 17:22:39.428447
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    dict_0['get'] = lambda: None
    dict_0['keys'] = lambda: None
    dict_0['items'] = lambda: None
    dict_0['values'] = lambda: None
    dict_0['something'] = None
    bool_0 = has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'something')
    assert bool_0 == True


# Generated at 2022-06-25 17:22:43.110905
# Unit test for function has_any_callables
def test_has_any_callables():
    class TestObjIterable:

        def __init__(self):
            self.attr1 = False
            self.attr2 = False
            self.attr3 = False

        def __iter__(self):
            return self

        def __next__(self):
            return True

    obj0 = TestObjIterable()

    assert has_any_callables(
        obj0, 'attr1', 'attr2', 'attr3', '__iter__', '__next__'
    ) is True



# Generated at 2022-06-25 17:22:51.173524
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict(a=1, b=2)  # object with methods
    dict_1 = dict(c=3, d=4)  # object without methods
    assert has_any_callables(dict_0, 'items', 'keys', 'values', 'copy') is True, 'has_any_callables is not working'
    assert has_any_callables(dict_1, 'items', 'keys', 'values', 'copy') is False, 'has_any_callables is not working'


# Generated at 2022-06-25 17:22:55.849939
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar','baz') == False


# Generated at 2022-06-25 17:23:01.206251
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    str_0 = 'Sample unit test for the ``has_callables`` function.\n    '


# Generated at 2022-06-25 17:23:02.679841
# Unit test for function has_callables
def test_has_callables():
    str_0 = 'Sample unit test for the ``has_callables`` function.\n    '


# Generated at 2022-06-25 17:23:15.609074
# Unit test for function has_any_callables

# Generated at 2022-06-25 17:23:19.359065
# Unit test for function has_callables
def test_has_callables():
    str_0 = 'Sample unit test for the ``has_callables`` function.\n    '


# Generated at 2022-06-25 17:23:28.732342
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b='hello', c=10.0, d=True)
    print('Sample unit test for the ``has_callables`` function.')
    result = has_callables(obj, 'keys', 'items', 'values', 'pop')
    print(f'Sample unit test for the ``has_callables`` function.\n    has_callables(obj, \'keys\', \'items\', \'values\', \'pop\') == {result}')
    assert result is True
    result = has_callables(obj, 'keys', 'items', 'values', 'pop', 'foo')

# Generated at 2022-06-25 17:23:32.873675
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'Test 0: ``has_any_callables(dict(),\'get\',\'items\')``.'
    obj_0 = dict()
    bool_0 = has_any_callables(obj_0, 'get', 'items')
    bool_1 = True
    assert bool_0 == bool_1, '{} != {}'.format(bool_0, bool_1)


# Generated at 2022-06-25 17:23:39.147545
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values','clear','pop')
    assert not has_callables(dict(),'get','keys','items','values','pop')
    assert not has_callables(dict(),'giter','keys','items','values','clear','pop')

if __name__=='__main__':
    test_has_callables()

# Generated at 2022-06-25 17:23:50.719308
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test has_any_callables"""
    obj_0 = {'foo': 1, 'bar': 2, 'baz': 3, 'qux': 4}
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '
    str_1 = 'yield from obj.items() if callable(getattr(obj, \'items\')) is True else None'
    func_0 = has_any_callables
    func_1 = has_any_callables(obj_0, 'foo', 'bar', 'baz', 'qux', 'items', 'foo_bar')
    func_2 = has_any_callables(obj_0, 'foo', 'bar', 'baz', 'qux', 'foobar')

# Generated at 2022-06-25 17:23:56.768224
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '
    str_1 = '\n    :raises: \n        :exception: (:obj:`AssertionError`) \n            If the result of the function is NOT the expected result.\n    '
    is_result = has_any_callables((1, 2, 3), 'append', 'pop', 'foo')
    exp_result = False
    try:
        assert is_result == exp_result
    except AssertionError:
        raise AssertionError((str_0 + "The result of the function did NOT match the expected result.\n\n" + str_1))



# Generated at 2022-06-25 17:24:10.774800
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '
    obj_0 = dict()
    return_value_0 = has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'foo')
    return_value_1 = has_any_callables(obj_0, 'foo', 'bar', 'baz', 'qux', 'quux')
    return_value_2 = has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'foo')
    return_value_3 = has_any_callables(obj_0, 'foo', 'bar', 'baz', 'qux', 'quux')
    str_1 = str(return_value_0)

# Generated at 2022-06-25 17:24:14.017241
# Unit test for function has_any_callables
def test_has_any_callables():
    """Sample unit test for the ``has_any_callables`` function.

    """
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') == True



# Generated at 2022-06-25 17:24:18.726488
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()
    str_0 = 'Sample unit test for the ``has_callables`` function.\n    '


# Generated at 2022-06-25 17:24:34.984677
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '
    cases = {
        True: {
            'test': {
                'get',
                'keys',
                'values',
            },
            'expected': True,
        },
        False: {
            'test': {
                'foo',
                'bar',
            },
            'expected': False,
        },
    }
    obj = dict(a=1, b=2, c=3, d=4)
    for case, test_data in cases.items():
        for test_attr in test_data['test']:
            actual = has_any_callables(obj, test_attr)
            assert actual == test_data['expected']


# Generated at 2022-06-25 17:24:41.365548
# Unit test for function has_callables
def test_has_callables():
    """
    Test case for ``flutils.objutils`` ``has_callables`` function.
    """
    _obj_0 = dict(a=1, b=2)
    _result_0 = has_callables(_obj_0, 'items', 'values', 'keys')
    assert _result_0 is True
    _result_1 = has_callables(_obj_0, 'items', 'bar', 'keys')
    assert _result_1 is False


# Generated at 2022-06-25 17:24:47.509171
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert(has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something')
           is True)
    assert(has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something'))
    assert(has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something')
           is True)
    assert(has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something'))
    assert(has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something')
           is True)
    dict_0 = dict()

# Generated at 2022-06-25 17:24:49.663321
# Unit test for function has_callables
def test_has_callables():
    str_1 = 'Unit test ``has_callables``'


# Generated at 2022-06-25 17:25:02.087555
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test that the given ``obj`` has **ANY** of the given ``attrs`` and they
    are callable.

    Args:
        obj (:obj:`Any <typing.Any>`): The object to check.
        *attrs (:obj:`str`): The names of the attributes to check.

    :rtype:
        :obj:`bool`

        * :obj:`True` if ANY of the given ``*attrs`` exist on the given ``obj``
          and ANY are callable;
        * :obj:`False` otherwise.

    Example:
        >>> from flutils.objutils import has_any_callables
        >>> has_any_callables(dict(),'get','keys','items','values','foo')
        True
    """
    obj_0 = dict()

# Generated at 2022-06-25 17:25:05.529558
# Unit test for function has_callables
def test_has_callables():
    str_0 = 'Sample unit test for the ``has_callables`` function.\n    '
    str_1 = 'This function will return ``True`` if the given ``obj``\n    '
    str_2 = 'has all the given ``attrs`` and are callable.\n    '


# Generated at 2022-06-25 17:25:08.468564
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '
    str_0 += '\n'
    str_0 += '    '
    obj_0 = dict
    return has_any_callables(obj_0, 'fromkeys')


# Generated at 2022-06-25 17:25:12.072612
# Unit test for function has_callables
def test_has_callables():
    str_0 = 'Sample unit test for the ``has_callables`` function.\n    '


# Generated at 2022-06-25 17:25:18.556646
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    from collections import KeysView, ValuesView, UserList
    obj = dict(a=1, b=2)
    print('\n'+str(has_any_callables(obj.keys(),
        ValuesView,
        KeysView,
        UserList)
    ))


# Generated at 2022-06-25 17:25:21.570357
# Unit test for function has_any_callables
def test_has_any_callables():
    """Sample unit test for the ``has_any_callables`` function.
    """
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-25 17:25:27.042424
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '
    print('{0}'.format(str_0))
    # BEGIN UNIT TEST
    dict_0 = dict(name='Bob', age=42)
    assert has_any_callables(dict_0, 'keys', 'update', 'items') is True
    assert has_any_callables(dict_0, 'keys', 'update', 'bar') is True
    assert has_any_callables(dict_0, 'keys', 'bar', 'foo') is False
    # END UNIT TEST


# Generated at 2022-06-25 17:25:32.199556
# Unit test for function has_any_callables
def test_has_any_callables():
    # Arrange
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '
    # Act
    # Assert
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-25 17:25:41.569460
# Unit test for function has_callables
def test_has_callables():
    # Ensure that it raises `TypeError` if bad arguments are provided
    with pytest.raises(TypeError):
        has_callables()
    # Ensure that it returns `False` if the given attributes do not exist
    assert has_callables(dict(), 'foo') is False
    # Ensure that it returns `False` if the given attributes exist but are not
    # callable
    assert has_callables(dict(), 'keys') is False
    # Ensure that it returns `True` if the given attributes exist and are
    # callable
    assert has_callables(dict(), 'keys', 'values', 'items') is True
    # Ensure that it returns `False` for unordered list-like objects
    assert has_callables(set(), 'append') is False
    # Ensure that it returns `True` for ordered list-like objects
    assert has

# Generated at 2022-06-25 17:25:47.973366
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '

    obj_0 = dict(a=1, b=2, c=3)
    attrs_0 = 'a', 'b', 'c', 'foo'

    assert has_any_callables(obj_0, *attrs_0) is False
    assert has_any_callables(obj_0, *obj_0.keys()) is True


# Generated at 2022-06-25 17:25:52.162974
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '
    obj_0 = dict()
    assert has_any_callables(obj_0, 'items', 'keys', 'values', 'something')



# Generated at 2022-06-25 17:25:53.937055
# Unit test for function has_callables
def test_has_callables():
    # Test case 0
    print(test_case_0())

    # Test case 1
    print(test_case_1())


# Generated at 2022-06-25 17:26:00.608446
# Unit test for function has_callables
def test_has_callables():
    # Define a mock object
    class MockObject:
        """A mock object.
        """

        def __init__(self):
            """Create a mock object.
            """
            # Define a mock callable
            def mock_method():
                """A mock callable.
                """
                return True

            # Set the mock callable as an attribute
            self.mock_method = mock_method

    # Create the mock object
    mock_obj = MockObject()

    # Check that the object has a callable
    assert has_callables(mock_obj, 'mock_method') is True

    # Check that the object has no non-callable callables
    assert has_callables(mock_obj, 'mock') is False

    # Check that the object has no non-callable callables
    assert has_

# Generated at 2022-06-25 17:26:08.896720
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault'
                         'update', 'values')
    assert has_callables({'a': 'a', 'b': 'b'}, 'clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop', 'popitem'
                         'setdefault'
                         'update', 'values')
    assert has_callables([], 'append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse'
                         'sort')

# Generated at 2022-06-25 17:26:22.300254
# Unit test for function has_callables
def test_has_callables():
    assert callable(has_callables)
    assert has_callables(_Any, '__class__', '__subclasses__')
    assert not has_callables(None, '__class__', '__subclasses__')
    assert has_callables(_Any, '__class__')
    assert not has_callables(None, '__class__')
    assert has_callables(_Any, '__subclasses__')
    assert not has_callables(None, '__subclasses__')
    assert not has_callables(_Any, 'foo')
    assert not has_callables(None, 'foo')
    assert has_callables([1, 2, 3], '__add__')
    assert not has_callables(1, '__add__')
    assert has_callables(str, 'join')
    assert not has_

# Generated at 2022-06-25 17:26:27.706298
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = dict()
    assert has_any_callables(obj_0, 'get', 'keys', 'items', 'values', 'foo') == True
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '


# Generated at 2022-06-25 17:26:35.979352
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'Sample unit test for the ``has_any_callables`` function.\n    '
    str_1 = '``get`` and ``keys`` are callable and should return true.\n    '
    str_2 = '``set`` and ``copy`` are not callable and should return false.\n    '
    dct_0 = {'a':1,'b':2,'c':3}
    assert(has_any_callables(dct_0,'get','keys','items','values')) == True, str_0 + str_1
    assert(has_any_callables(dct_0,'set','copy')) == False, str_0 + str_2



# Generated at 2022-06-25 17:26:39.919224
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    dict_0.get('key')
    dict_0.items()
    str_1 = type(dict_0.keys())
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-25 17:26:50.270405
# Unit test for function has_any_callables
def test_has_any_callables():  # noqa: E501
    """Example of a unit test for the 'has_any_callables' function."""

    # The ``has_any_callables`` function should be callable.
    assert callable(has_any_callables)

    # The ``has_any_callables`` function should return ``True`` for a class
    # that is a subclass of ``dict``.
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True

    # The ``has_any_callables`` function should return ``True`` for a class
    # that is a subclass of ``dict``.
    assert has_any_callables(dict(), 'foo') is False

    # The ``has_any_callables`` function should return ``True`` for an instance
    # of ``dict``.

# Generated at 2022-06-25 17:27:02.465466
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import Counter
    assert has_any_callables(Counter(), 'get', 'keys', 'items', 'foo')
    assert has_any_callables(Counter(), 'get', 'keys', 'values', 'foo')
    assert has_any_callables(Counter(), 'get', 'items', 'values', 'foo')
    assert has_any_callables(Counter(), 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo')
   

# Generated at 2022-06-25 17:27:14.426898
# Unit test for function has_callables
def test_has_callables():
    any0 = has_callables({'c': 'sample', 'e': 'sample', 'a': 'sample', 'b': 'sample', 'd': 'sample'}, 'keys', 'values')
    assert any0 == True
    any1 = has_callables(['sample', 'sample'], '__getitem__')
    assert any1 == True
    any2 = has_callables({'c': 'sample', 'a': 'sample', 'b': 'sample'}, 'get', 'pop', 'keys', 'values', 'popitem')
    assert any2 == True
    any3 = has_callables({'c': 'sample', 'e': 'sample', 'a': 'sample', 'b': 'sample', 'd': 'sample'}, 'get', 'pop', 'keys', 'values', 'popitem')
    assert any3 == True

# Generated at 2022-06-25 17:27:24.361551
# Unit test for function has_any_callables
def test_has_any_callables():
    # fmt: off
    # Note:
    #   >> 'something'.startswith('some')
    #   >> True
    #   >> 'something'.endswith('thing')
    #   >> True
    #   >> 'something'.find('one')
    #   >> 8
    #   >> 'something'.find('foo')
    #   >> -1
    # fmt: on
    class A:
        def __init__(self, foo: int) -> None:
            self.foo = foo

        def __str__(self) -> str:
            return f'{self.__class__.__name__}({self.foo})'

        def __repr__(self) -> str:
            return f'<{self}>'


# Generated at 2022-06-25 17:27:33.696182
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'get', 'keys', 'items', 'values')

    # Removed: 2020-07-09
    # If this ``if __name__ == '__main__':`` block is removed,
    # the following error is returned:
    #     E     AssertionError: assert not has_callables(obj, 'foo')
    # If the ``if __main__`` block is present, the following is returned:
    #     ok    
    if __name__ == '__main__':
        assert not has_callables(obj, 'foo')


# Generated at 2022-06-25 17:27:45.718959
# Unit test for function has_any_callables
def test_has_any_callables():
    #
    # Assert that if **any** of the given ``attrs`` exists on the given ``obj`` and **any** are
    # callable that :obj:`True` is returned;
    #
    str_0 = "Testing that if **any** of the given ``attrs`` exists on the given ``obj`` and **any** are callable that :obj:`True` is returned;\n    "
    #
    # >>> from flutils.objutils import has_any_callables
    # >>> from collections import (
    # ...     Counter
    # ... )
    # >>> counter_0 = Counter({'a': 1, 'b': 2})
    # >>> has_any_callables(counter_0, 'get', 'keys', 'items', 'values')
    # True
    # >>> has_any_callables(counter

# Generated at 2022-06-25 17:27:53.387919
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'iXv}uOq3Kj1=*|!S'
    str_1 = 'oET{^hR1Y9&a[M'
    assert has_any_callables(str_0, str_1) is False
    assert has_any_callables(str_0, str_1) is False


# Generated at 2022-06-25 17:27:58.438254
# Unit test for function has_any_callables
def test_has_any_callables():
    int_0 = 0
    str_0 = '{Cnp(6alYh:![Mw6B%wr'
    int_0 = len(str_0)
    assert has_any_callables(str_0)



# Generated at 2022-06-25 17:28:07.737332
# Unit test for function has_any_callables
def test_has_any_callables():
    str_a = 'coding'
    list_a = [1, 2, 3]
    assert has_any_callables(str_a, 'append') == True
    assert has_any_callables(str_a, 'upper', 'lower', 'capitalize', 'swapcase') == True
    assert has_any_callables(str_a, 'index') == False
    assert has_any_callables(str_a, 'index', 'lower', 'capitalize') == True
    assert has_any_callables(list_a, 'join') == False
    assert has_any_callables(list_a, 'append', 'count', 'insert', 'remove') == True
    print('Success: test_has_any_callables')



# Generated at 2022-06-25 17:28:10.286989
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(foo=[1, 2, 3])
    assert has_any_callables(obj, 'items', 'keys', 'values', 'foo')



# Generated at 2022-06-25 17:28:19.970549
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'E:j#L>tYYBm'
    bool_0 = has_any_callables(str_0)
    # Test Case (Test Case)
    str_0 = 'O%d$s\'s&%^l;>G}V8Wb_!LIv6hXU6'
    bool_0 = has_any_callables(str_0)
    assert bool_0
    # Test Case (Test Case)
    str_0 = '8E<$R(`\'FSO<:|:0@Kp'
    bool_0 = has_any_callables(str_0)
    assert bool_0


# Generated at 2022-06-25 17:28:31.582811
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    from flutils.objutils import has_attrs

    # Test for None
    obj_0 = None
    assert has_any_callables(obj_0) == False
    assert has_any_callables(obj_0, 'get', 'keys', 'items', 'values') == False

    # Test for string
    str_0 = '{Cnp(6alYh:![Mw6B%wr'
    assert has_any_callables(str_0) == True
    assert has_any_callables(str_0, 'get', 'keys', 'items', 'values') == False
    assert has_any_callables(str_0, 'get', 'keys', 'items', 'values', 'title') == True

    # Test for list
    l

# Generated at 2022-06-25 17:28:36.702772
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('hello', '__getitem__', '__len__') is True
    assert has_any_callables('hello', 'foo') is False
    assert has_any_callables('hello') is False
    assert has_any_callables({}, 'get', 'keys') is True
    assert has_any_callables({}, 'foo') is False
    assert has_any_callables({}) is False


# Generated at 2022-06-25 17:28:40.310062
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict()
    dict_0.foo = 'bar'
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-25 17:28:43.874824
# Unit test for function has_callables
def test_has_callables():
    str_0 = '{Cnp(6alYh:![Mw6B%wr'
    bool_0 = has_callables(str_0,'__len__')


# Generated at 2022-06-25 17:28:48.187981
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Example:
        >>> from flutils.objutils import has_any_callables
        >>> has_any_callables(dict(),'get','keys','items','values')
        True
    """
    assert has_any_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-25 17:29:00.619398
# Unit test for function has_callables
def test_has_callables():
    num_types_passing = 0

    function_0 = has_callables

    obj_0 = [1,2,3]
    obj_0_attrs = ['append','count','extend','index','insert','pop','remove','reverse','sort']

    obj_1 = 'abc'

# Generated at 2022-06-25 17:29:08.601116
# Unit test for function has_callables
def test_has_callables():
    func_0 = test_case_0
    str_0 = '@[?s)s'
    dict_0 = dict(a=1, b=2, c=3)

    assert has_callables(func_0) is False
    assert has_callables(dict_0, 'get', 'get') is True
    assert has_callables(dict_0, 'get', 'foo') is False
    assert has_callables(str_0, 'upper', 'format', 'isalpha')



# Generated at 2022-06-25 17:29:12.266351
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values', 'items')
    assert not has_callables(dict(), 'get', 'keys', 'values', 'items',
                             'foo')



# Generated at 2022-06-25 17:29:18.857085
# Unit test for function has_callables
def test_has_callables():
    test_obj = DirUtils()
    attrs = test_obj.__dict__
    attrs_to_check = ['get_last_modified', 'get_size']

    # This is True
    assert(test_obj.get_last_modified() is not None)
    assert(test_obj.get_size() is not None)

    # This is True
    assert(has_callables(test_obj, *attrs_to_check) is True)


# Generated at 2022-06-25 17:29:29.094672
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    from random import randint
    from random import randrange
    from random import shuffle
    import string

    class Cat:
        def meow(self):
            pass

        @classmethod
        def meow_classmethod(cls):
            pass

        @staticmethod
        def meow_staticmethod():
            pass

        @property
        def meow_property(self):
            pass

        @meow_property.setter
        def meow_property_setter(self, val: str):
            pass

    def get_random_string(length: int) -> str:
        letters = []
        for _ in range(length):
            letters.append(
                choice(string.ascii_letters + string.digits + string.punctuation)
            )
        shuffle(letters)
        return

# Generated at 2022-06-25 17:29:35.171675
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2, c=3)
    result = has_callables(obj, 'get')
    result.should.be.a(bool)
    result.should.equal(True)
    result = has_callables(obj, 'get', 'items')
    result.should.equal(True)
    result = has_callables(obj, 'get', 'keys', 'values')
    result.should.equal(True)
    result = has_callables(obj, 'get', 'foo')
    result.should.equal(False)
    result = has_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    result.should.equal(False)



# Generated at 2022-06-25 17:29:44.442547
# Unit test for function has_callables
def test_has_callables():
  # Create mock object
  obj_0 = mock.Mock()
  str_0 = '}]=9R]^U$dP.z{6[sw)w'
  str_1 = 'Ea:@m75~b9XnP=lQH'
  # Set return values for mock
  obj_0.__getattr__.return_value = str_0
  obj_0.__getattr__('', str_1, '', str_1).__call__.return_value = str_1
  bool_0 = has_callables(obj_0)
  assert bool_0 == False
  # Set return values for mock
  obj_0.__getattr__.return_value = str_0
  obj_0.__getattr__('', str_1, str_0, str_1).__

# Generated at 2022-06-25 17:29:45.090456
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()



# Generated at 2022-06-25 17:29:48.581808
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something')
    assert not has_any_callables(int(),'something')
    assert not has_any_callables(float(),'something')



# Generated at 2022-06-25 17:29:50.838712
# Unit test for function has_callables
def test_has_callables():
    # Test that calling has_callables with different values
    # raises TypeError
    with pytest.raises(TypeError):
        has_callables()



# Generated at 2022-06-25 17:30:13.241153
# Unit test for function has_callables
def test_has_callables():
    """
    test_has_callables()
    """
    str_0 = '{Cnp(6alYh:![Mw6B%wr'
    list_0 = []
    list_0.extend([list(), list()])
    list_1 = []
    list_1.extend([list_0, list_0])
    list_2 = []
    list_2.extend([list_1, list_1])
    list_3 = []
    list_3.extend([list_2, list_2])
    list_4 = []
    list_4.extend([list_3, list_3])
    list_5 = []
    list_5.extend([list_4, list_4])
    list_6 = []

# Generated at 2022-06-25 17:30:16.800859
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = {
        'a': 1,
        'b': 2
    }
    if has_any_callables(obj, 'get', 'keys', 'values', 'items'):
        print('Success!')
    else:
        print('failure')



# Generated at 2022-06-25 17:30:20.896407
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = object()
    assert has_any_callables(obj) is False
    assert has_any_callables(obj, 'foo') is False
    assert has_any_callables(str, 'foo') is False
    assert has_any_callables(str, 'split') is True
    return



# Generated at 2022-06-25 17:30:30.302018
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values'
    ) is True
    assert has_callables(
        list(),
        'append',
        'remove',
        'extend'
    ) is True
    assert has_callables(
        tuple(),
        'count',
        'index'
    ) is True
    assert has_callables(
        set(),
        'add',
        'remove',
        'pop'
    ) is True

    assert has_callables(
        None,
        'append'
    ) is False
    assert has_callables(
        'my_string',
        'append'
    ) is False
    assert has_callables(
        1,
        'append'
    ) is False




# Generated at 2022-06-25 17:30:36.656623
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test the case where the given object has any of the given attributes.
    def case_0():
        str_0 = '{Cnp(6alYh:![Mw6B%wr'
        bool_0 = has_any_callables(str_0, '__doc__', '__add__', '__sizeof__')
        assert bool_0
    case_0()

    # Test the case where the given object does not have any of the given
    # attributes.
    def case_1():
        bool_0 = has_any_callables(str, 'foobarbaz')
        assert not bool_0
    case_1()

    # Test the case where the given object has one of the given attributes, but
    # the attribute is not callable.
    def case_2():
        bool_0 = has_

# Generated at 2022-06-25 17:30:47.105491
# Unit test for function has_callables
def test_has_callables():
    list_0 = [3, 36, 1, 2, 0]
    bool_0 = has_callables(list_0)
    bool_1 = has_callables(list_0, '__add__')
    bool_2 = has_callables(list_0, '__attr__')
    bool_3 = has_callables(list_0, '__contains__')
    bool_4 = has_callables(list_0, '__eq__')
    bool_5 = has_callables(list_0, '__ge__')
    bool_6 = has_callables(list_0, '__getitem__')
    bool_7 = has_callables(list_0, '__gt__')
    bool_8 = has_callables(list_0, '__iadd__')
    bool_9

# Generated at 2022-06-25 17:30:52.045105
# Unit test for function has_callables
def test_has_callables():

    # Test function with default arguments
    if True:
        # Import standard modules
        import collections
        str_0 = has_callables(collections.Counter, 'most_common')
    assert str_0 == True

    # Test function with multiple arguments
    if True:
        # Import standard modules
        import collections
        str_0 = has_callables(collections.Counter, 'most_common', 'items')
    assert str_0 == True

