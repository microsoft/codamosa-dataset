

# Generated at 2022-06-25 17:20:51.309365
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items') == True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') == False



# Generated at 2022-06-25 17:20:55.835817
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-25 17:20:59.058905
# Unit test for function has_any_callables
def test_has_any_callables():
    test_dict = dict()
    test_dict['get'] = dict.get
    test_dict['keys'] = dict.keys
    test_dict['items'] = dict.items
    test_dict['values'] = dict.values
    test_dict['foo'] = dict.foo
    assert has_any_callables(test_dict,'get','keys','items','values','foo') == True



# Generated at 2022-06-25 17:21:03.595353
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert not has_any_callables(obj)
    assert not has_any_callables(obj, 'keys', 'foo', 'bar')
    assert has_any_callables(obj, 'keys', 'foo', 'items')
    assert has_any_callables(obj, 'get', 'keys')



# Generated at 2022-06-25 17:21:05.035724
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-25 17:21:10.005493
# Unit test for function has_any_callables
def test_has_any_callables():
    func_0 = {'a': 1, 'b': 2, 'c': 3}
    assert has_any_callables(func_0, "get", "keys", "values", "items", "something") is True



# Generated at 2022-06-25 17:21:15.131037
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get') == True


# Generated at 2022-06-25 17:21:20.541606
# Unit test for function has_any_attrs
def test_has_any_attrs():
    str_0 = ""
    assert (has_any_attrs(str_0, "title", "upper", "split") == False)


# Generated at 2022-06-25 17:21:30.880576
# Unit test for function has_attrs
def test_has_attrs():
    # Test 0
    # Called as has_attrs()
    # Should return True
    bool_0 = has_attrs()
    # Check
    assert bool_0 is True, "has_attrs() should return True"

    # Test 1:
    # Called as has_attrs(foo)
    # Should return True
    # Test 1-A:
    # foo is None
    bool_1_a = has_attrs(None)
    # Check
    assert bool_1_a is True, "has_attrs(None) should return True"

    # Test 1-B:
    # foo has no attributes
    class Foo1:
        pass

    bool_1_b = has_attrs(Foo1())
    # Check

# Generated at 2022-06-25 17:21:35.189119
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-25 17:21:43.547908
# Unit test for function has_any_callables
def test_has_any_callables():
    t = (
        (dict(),['get','foo']),
        (dict(),['get','keys','foo']),
        (dict(),['get','keys','items','foo']),
        (dict(),['get','keys','items','values','foo']),
    )
    assert has_any_callables(*t[0]) is True
    assert has_any_callables(*t[1]) is True
    assert has_any_callables(*t[2]) is True
    assert has_any_callables(*t[3]) is True


# Generated at 2022-06-25 17:21:55.442383
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables, has_callables

    class Test0(object):
        def __init__(self, y):
            self.y = y

        def foo(self):
            return self.y ** 2

        def bar(self, z):
            return z ** 3

    obj = Test0(1)
    assert has_any_callables(obj, 'foo', 'bar', 'gar') is True
    assert has_callables(obj, 'foo', 'bar') is True
    assert has_any_callables(obj, 'foo') is True
    assert has_callables(obj, 'foo') is True
    assert has_any_callables(obj, 'foo', 'bar', 'gar', 'a', 'b', 'c') is True

# Generated at 2022-06-25 17:21:57.814436
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    obj.get = 'get'
    obj.keys = 'keys'
    obj.items = 'items'
    obj.values = 'values'
    obj.foo = 'foo'
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') is False


# Generated at 2022-06-25 17:22:03.270023
# Unit test for function has_any_callables
def test_has_any_callables():
    class_0 = dict

    if not has_any_callables(class_0, "foo", "bar"):
        print('Unit test failed')
        exit()


# Generated at 2022-06-25 17:22:11.457008
# Unit test for function has_any_callables
def test_has_any_callables():
    calling = dict(a = dict(b = dict(c = 42)))
    not_calling = dict(a = dict(b = dict(c = 42)))

    assert has_any_callables(calling) is False
    assert has_any_callables(calling, 'a') is True
    assert has_any_callables(calling, 'a', 'b') is True
    assert has_any_callables(calling, 'a', 'b', 'c') is False
    assert has_any_callables(not_calling) is False


# Generated at 2022-06-25 17:22:23.646975
# Unit test for function has_any_callables
def test_has_any_callables():
    string_0 = 'a'
    string_1 = 'b'
    string_2 = 'c'
    string_3 = 'd'
    string = string_0 + string_1 + string_2 + string_3
    list_0 = [string_0, string_1, string_2, string_3]
    bool_0 = has_any_callables(list_0, '__getitem__', '__delitem__')
    bool_1 = has_any_callables(string, '__getitem__', '__delitem__')


if __name__ == '__main__':
    test_case_0()
    test_has_any_callables()

# Generated at 2022-06-25 17:22:31.556136
# Unit test for function has_any_callables
def test_has_any_callables():
    def _foo_1(*args, **kwargs):
        return {'foo': 'bar'}

    def _foo_2(*args, **kwargs):
        return {'bar': 'baz'}

    dict_1 = dict(a=1, b=2)
    list_1 = list()
    tuple_1 = (1, 2, 3)
    dict_1['foo_1'] = _foo_1
    dict_1['foo_2'] = _foo_2
    list_1.extend([_foo_1, _foo_2])
    tuple_1 = tuple([_foo_1, _foo_2])

    assert has_any_callables(dict_1, 'foo_1', 'foo_2', 'keys', 'values') is True

# Generated at 2022-06-25 17:22:43.784308
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test if dict has any of the following callables
    assert(has_any_callables(dict(),'get','keys','items','values','foo') == \
        True)
    # Test if dict has any of the following callables
    assert(has_any_callables(dict(),'something','different','than','before', \
        'get') == True)
    # Test if list has any of the following callables
    assert(has_any_callables([1,2,3],'reverse','copy','sort') == True)
    # Test if int has any of the following callables
    assert(has_any_callables(9,'bit_length','conjugate','denominator') == \
        False)
    # Test if object has any of the following callables

# Generated at 2022-06-25 17:23:00.484463
# Unit test for function has_any_callables
def test_has_any_callables():
    print("has_any_callables: START")
    dict_0 = dict()
    dict_0['k1'] = 'v1'
    dict_0['k2'] = 'v2'
    dict_0['k3'] = 'v3'
    dict_0['k4'] = 'v4'
    dict_0['k5'] = 'v5'
    assert has_any_callables(dict_0, 'k1', 'k2', 'k3', 'k4', 'k5') == False
    dict_0 = dict()
    dict_0['k1'] = 'v1'
    dict_0['k2'] = 'v2'
    dict_0['k3'] = 'v3'
    dict_0['k4'] = 'v4'
    dict_0['k5']

# Generated at 2022-06-25 17:23:14.921572
# Unit test for function has_callables
def test_has_callables():
    # pylint: disable=protected-access
    obj_0 = dict
    assert has_callables(obj_0, 'fromkeys') is True

    obj_0 = dict()
    assert has_callables(obj_0, 'fromkeys') is False
    assert has_callables(obj_0, 'get') is True
    assert has_attrs(obj_0, 'get') is True

    bool_0 = has_callables(obj_0, 'fromkeys', 'get')
    assert bool_0 is False
    bool_0 = has_callables(obj_0, 'get', 'fromkeys')
    assert bool_0 is False

    bool_0 = has_callables(obj_0, 'get')
    assert bool_0 is True



# Generated at 2022-06-25 17:23:29.066875
# Unit test for function has_any_callables
def test_has_any_callables():
    # BAD_CALL_0 - has_any_callables()
    with pytest.raises(TypeError):
        has_any_callables()
    # GOOD_CALL_0 - has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items','values') is True
    # GOOD_CALL_1 - has_any_callables(dict(),'keys','values','foo')
    assert has_any_callables(dict(),'keys','values','foo') is True
    # GOOD_CALL_2 - has_any_callables(dict(),'keys','values','foo')
    assert has_any_callables(dict(),'keys','values','foo') is True
    # GOOD_CALL_3 - has_any_callables(

# Generated at 2022-06-25 17:23:40.221618
# Unit test for function has_any_attrs
def test_has_any_attrs():
    dict_0 = dict(a=1, b=2, c=3)
    keys_0 = dict_0.keys()
    float_0 = float(10)
    bool_0 = has_any_attrs(dict_0, 'get')
    bool_1 = has_any_attrs(keys_0, 'get')
    bool_2 = has_any_attrs(float_0, 'get')
    bool_3 = has_any_attrs(dict_0, 'get', 'keys')
    bool_4 = has_any_attrs(dict_0, 'get', 'keys', 'items', 'values',
                           'something')



# Generated at 2022-06-25 17:23:45.670447
# Unit test for function has_callables
def test_has_callables():
    # Test for dictionaries with required attributes
    # Test for dictionaries with required attributes and for callable
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'update') is True



# Generated at 2022-06-25 17:23:55.398381
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    :return:
    """

    # Create a string variable and see if it has any callables
    test_string = "This is a test sentence."
    assert has_any_callables(test_string) == True

    # Create a list variable and see if it has any callables
    test_list = ['this', 'is', 'a', 'test', 'sentence']
    assert has_any_callables(test_list) == True

    # Create a dictionary variable and see if it has any callables
    test_dict = {'David': 1, 'Floyd': 2}
    assert has_any_callables(test_dict) == True

    # Create an integer variable and see if it has any callables
    test_int = 1
    assert has_any_callables(test_int) == True

    # Create a

# Generated at 2022-06-25 17:24:10.775130
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from math import (
        sqrt,
        pow,
        cos,
        sin,
    )

    list_0 = [1, 2, 3, 4]
    list_1 = [1, 2, 3, 4]
    list_2 = [1, 2, 3, 4, 5]

    obj_0 = sqrt
    obj_1 = pow
    obj_2 = cos
    obj_3 = sin

    if has_any_attrs(list_0, '__len__', '__init__', '__class__') is False:
        print('test_has_any_attrs: FAILURE: initial check for list_0')

# Generated at 2022-06-25 17:24:19.565952
# Unit test for function has_any_callables
def test_has_any_callables():
    """Tests has_any_callables
    """
    a = dict(a=1, b=2)

    assert has_any_callables(a) is True
    assert has_any_callables(a, 'get', 'keys', 'items', 'values') is True

    return True



# Generated at 2022-06-25 17:24:35.452566
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class ClassA(object):
        pass

    class ClassB(object):
        def __init__(self):
            self.foo = True

    class ClassC(object):
        def __init__(self):
            self.bar = True

    class ClassD(ClassB, ClassC):
        pass

    class SubClassD(ClassD):
        def __init__(self):
            self.biz = False

    obj_a = ClassA()

    assert(has_any_attrs(obj_a) is False)
    assert(has_any_attrs(obj_a, 'foo', 'bar') is False)
    assert(has_any_attrs(obj_a, 'foo', 'some_random_attr') is False)

# Generated at 2022-06-25 17:24:44.253144
# Unit test for function has_any_callables
def test_has_any_callables():
    c_0 = dict()
    c_1 = dict(a=1, b=2)
    c_2 = dict(a=1, b=2, c=3)
    c_3 = dict(a=1, b=2, c=3, d=4)
    c_4 = dict(a=1, b=2, c=3, d=4, e=5)
    c_5 = dict(a=1, b=2, c=3, d=4, e=5, f=6)
    c_6 = dict(a=1, b=2, c=3, d=4, e=5, f=6, g=7)

# Generated at 2022-06-25 17:24:57.895198
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils.objutils import has_any_attrs

    # Check that flutils.objutils.has_any_attrs() is callable.
    assert callable(has_any_attrs) is True

    # Check that the function returns True when given the obj and attrs.
    assert has_any_attrs(dict(), 'items') is True
    assert has_any_attrs(dict(), 'keys') is True
    assert has_any_attrs(dict(), 'values') is True
    assert has_any_attrs(dict(), 'items', 'keys', 'values') is True

    # Check that the function returns False when not given the obj and attrs.
    assert has_any_attrs(dict(), 'foo') is False
    assert has_any_attrs(dict(), 'foo', 'bar') is False
   

# Generated at 2022-06-25 17:25:04.488761
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict(a=1, b=2)
    assert has_any_callables(dict_0, 'items', 'values') is True
    assert has_any_callables(dict_0, 'foo', 'bar') is False
    # assert isinstance(dict_0, dict)



# Generated at 2022-06-25 17:25:23.604476
# Unit test for function has_callables
def test_has_callables():
  # Check all valid calls
  my_list = [0, 1, 2]
  my_dict = {
      'a': 'one',
      'b': 'two'
  }
  my_set = {'one', 'two'}
  my_tuple = ('one', 'two')
  my_bytes = bytes('hello', 'utf-8')
  my_str = 'hello'
  my_class = _OldClass()
  assert has_callables(my_list, 'append', 'pop', 'sort') is True
  assert has_callables(my_dict, 'get', 'keys', 'items', 'values') is True
  assert has_callables(my_set, 'add', 'pop', 'remove', 'discard') is True

# Generated at 2022-06-25 17:25:25.942422
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False



# Generated at 2022-06-25 17:25:36.142678
# Unit test for function has_attrs
def test_has_attrs():

    # Test a class
    class Class:

        def __init__(self):
            self.foo = 273
            self.bar = 528

        def method(self):
            """ This is a class method"""
            pass

    c = Class()
    assert has_attrs(c, 'foo') is True
    assert has_attrs(c, 'baz') is False
    assert has_attrs(c, 'foo', 'bar') is True
    assert has_attrs(c, 'foo', 'baz') is False



# Generated at 2022-06-25 17:25:41.391875
# Unit test for function has_any_callables
def test_has_any_callables():
    _dict_0 = dict(a=1, b=2, c=3)
    _expected = 1, 'b', 'c'
    _found = has_any_callables(_dict_0, *_expected)
    assert _found == 1


# Generated at 2022-06-25 17:25:52.491221
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'items', 'keys', 'values') is True
    assert has_callables(list(), 'append', 'extend', 'insert', 'remove') is True
    assert has_callables(
        set(), 'add', 'clear', 'discard', 'remove', 'pop', 'update'
    ) is True
    assert has_callables(
        frozenset(), 'copy', 'difference', 'intersection', 'isdisjoint',
        'issubset', 'issuperset', 'union', 'intersection_update',
        'difference_update', 'add', 'remove', 'discard'
    ) is True
    assert has_callables(tuple(), 'count', 'index') is True

# Generated at 2022-06-25 17:25:59.613254
# Unit test for function has_callables
def test_has_callables():
    class test_class_0:
        def __str__(self):
            return 'test_class_0'
        pass

    # testing function has_callables
    # Testing cases
    # 1. has_callables(True), should return False
    # 2. has_callables('Hello'), should return False
    # 3. has_callables(test_class_0), should return True
    # 4. has_callables(test_class_0, '__str__'), should return True
    # 5. has_callables(test_class_0, '__str__', '__repr__'), should return False
    # 6. has_callables(test_class_0, '__str__', '__repr__', '__str__'), should return False
    # 7. has_callables(test_class_0, '

# Generated at 2022-06-25 17:26:05.430746
# Unit test for function has_any_callables
def test_has_any_callables():
    if __name__ == '__main__':
        # Testing has_any_callables function
        # Test Case 0: Testing with empty dictionary
        print(has_any_callables(dict()))
        # Output: True
        # Test Case 1: Testing with non-empty dictionary
        print(has_any_callables(dict(a=1, b=2)))
        # Output: True


# Generated at 2022-06-25 17:26:10.941922
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = has_any_callables('hello', 'hello')
    bool_1 = has_any_callables('hello', 'hello')
    bool_2 = has_any_callables('hello', 'hello')
    bool_3 = has_any_callables('hello', 'hello')
    bool_4 = has_any_callables('hello', 'hello')
    bool_5 = has_any_callables('hello', 'hello')
    bool_6 = has_any_callables('hello', 'hello')
    bool_7 = has_any_callables('hello', 'hello')
    bool_8 = has_any_callables('hello', 'hello')
    bool_9 = has_any_callables('hello', 'hello')
    bool_10 = has_any_callables('hello', 'hello')
   

# Generated at 2022-06-25 17:26:17.785181
# Unit test for function has_attrs
def test_has_attrs():
    from . import objutils
    from collections import UserDict
    from typing import Dict
    d = UserDict(a=1,b=2)
    d2 = Dict[str,int]
    assert objutils.has_attrs(d, 'clear')
    assert objutils.has_attrs(d, 'pop')
    assert objutils.has_attrs(d2, 'clear')


# Generated at 2022-06-25 17:26:27.091226
# Unit test for function has_callables
def test_has_callables():
    # Unit test for has_callables
    dict_0 = {
        'name': 'Bob',
        'age': 25
    }

    assert has_callables(dict_0, 'items', 'keys', 'values')

    class TestClass():
        def method(self):
            return None

    test_class_0 = TestClass()
    assert has_callables(test_class_0, 'method')

    class TestClass2():
        def method(self, int_0: int, str_0: str, list_0: list) -> None:
            return None

    test_class_1 = TestClass2()
    assert has_callables(test_class_1, 'method')



# Generated at 2022-06-25 17:26:34.652518
# Unit test for function has_any_callables
def test_has_any_callables():
    d = {'a': 1, 'b': 2}
    ret = has_any_callables(d, 'get', 'keys', 'items', 'values')
    assert ret is True



# Generated at 2022-06-25 17:26:39.699380
# Unit test for function has_any_callables
def test_has_any_callables():
    """Tests function has_any_callables."""

    # Initialize instances
    bytes_0 = b'@fC\xbell*\x1dG\x1c\xbd'
    bool_0 = has_any_callables(bytes_0)

    # Test truthiness of returned value
    assert (bool_0)



# Generated at 2022-06-25 17:26:44.429119
# Unit test for function has_any_callables
def test_has_any_callables():
    bytes_0 = b'@fC\xbell*\x1dG\x1c\xbd'
    bool_0 = has_any_callables(bytes_0)
    assert bool_0 == False



# Generated at 2022-06-25 17:26:47.542655
# Unit test for function has_callables
def test_has_callables():
    int_0 = 0
    dict_0 = dict(a=int_0, b=int_0, c=int_0)
    assert has_callables(dict_0, 'get', 'values') is True


# Generated at 2022-06-25 17:26:56.686371
# Unit test for function has_callables
def test_has_callables():
    class SampleObject(object):
        def method(self):
            pass
    obj = SampleObject()
    assert True == has_callables(obj, '__doc__', '__module__', '__repr__',
                           '__str__', 'method')
    assert False == has_callables(obj, '__doc__', '__module__', '__repr__',
                            '__str__', 'foo')

if __name__ == '__main__':
    test_case_0()
    test_has_callables()

# Generated at 2022-06-25 17:27:00.677546
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = has_any_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'foo'
    )
    assert bool_0 is True

# Generated at 2022-06-25 17:27:04.499098
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')


# Generated at 2022-06-25 17:27:08.002560
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False



# Generated at 2022-06-25 17:27:13.990722
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    from collections import UserList
    assert has_attrs(UserList, 'data')
    assert not has_attrs(UserList, 'something')
    assert has_attrs(UserList, 'data', '_UserList__setitem')
    assert not has_attrs(UserList, 'data', 'something')


# Generated at 2022-06-25 17:27:24.000938
# Unit test for function has_callables
def test_has_callables():
    has_callables()
    has_callables(3)
    has_callables("", "", "")
    has_callables("", "", 3)
    has_callables("", 3, 4, 5)
    has_callables("", 3, 4, 5)
    has_callables("", 3, 4, 5)
    has_callables("", 5)
    has_callables("asdf", "")
    has_callables("asdf", 5)
    has_callables("asdf3", "")
    has_callables("asdf3", 5)
    has_callables("asdf3", 5, 4)
    has_callables("asdf3", 5, "")
    has_callables("asdf3", 5, "asdf3")

# Generated at 2022-06-25 17:27:37.736781
# Unit test for function has_any_callables

# Generated at 2022-06-25 17:27:40.045947
# Unit test for function has_callables
def test_has_callables():
    bytes_0 = b'@fC\xbell*\x1dG\x1c\xbd'
    str_0 = has_callables(bytes_0)


# Generated at 2022-06-25 17:27:50.421983
# Unit test for function has_attrs
def test_has_attrs():
    # Create a class containing only a constructor and the two properties
    # to be tested - .get() and .keys()

    class DictSubClass(dict):
        """Dict that has subclass name."""

        def __new__(cls):
            obj = dict.__new__(cls)
            return obj

    # Create an instance of the class
    x = DictSubClass()

    # Verify that has_attrs() returns True
    assert has_attrs(x, 'get', 'keys') is True
    assert has_attrs(x, 'get', 'keys', 'items') is True

    # Verify that has_attrs() returns False
    assert has_attrs(x, 'get', 'keys', 'items', 'values') is False
    assert has_attrs(x, 'get', 'keys', 'values')

# Generated at 2022-06-25 17:28:01.904155
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(list(),'append') == True)
    assert(has_any_callables(list(), 'append', '__contains__', '__iter__') == True)
    assert(has_any_callables(list(), '__contains__', '__iter__', '__not_found__') == True)
    assert(has_any_callables(list(), '__contains__', '__iter__', '__len__') == True)
    assert(has_any_callables(list(), '__contains__', '__iter__', '__not_found__', '__len__') == True)
    assert(has_any_callables(list(), '__contains__', '__iter__', '__not_found__', '__len__', 'append') == True)

# Unit

# Generated at 2022-06-25 17:28:05.331493
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict(a=1, b=2)
    result = has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo')
    assert result == True


# Generated at 2022-06-25 17:28:09.487818
# Unit test for function has_any_callables
def test_has_any_callables():
    d = {'a': 1, 'b': 2}
    assert has_any_callables(d, 'get', 'keys', 'items') is True
    assert has_any_callables(d, 'get', 'keys', 'items', 'bar') is True
    assert has_any_callables(d, 'foo', 'bar', 'baz') is False


# Generated at 2022-06-25 17:28:21.136225
# Unit test for function has_callables
def test_has_callables():

    # Test 1
    # Initialize variables to be used in the test
    bytes_0 = b'@fC\xbell*\x1dG\x1c\xbd'

# Generated at 2022-06-25 17:28:31.951143
# Unit test for function has_attrs
def test_has_attrs():
    from collections import Counter

    int_1 = 1
    str_0 = 'we'
    str_1 = 'world'
    list_0 = ['hello']
    list_1 = [1, 2, 3]
    counter_0 = Counter()
    counter_1 = Counter('hello')

    assert has_attrs(int_1, 'bit_length')
    assert has_attrs(str_0, 'isalnum')
    assert has_attrs(str_1, 'isalpha')
    assert has_attrs(counter_0, 'clear')
    assert has_attrs(counter_1, 'most_common')
    assert has_attrs(list_0, 'pop')
    assert has_attrs(list_1, 'pop')

# Generated at 2022-06-25 17:28:39.961065
# Unit test for function has_callables
def test_has_callables():
    bytes_0 = b'@fC\xbell*\x1dG\x1c\xbd'
    dict_0 = dict(a=1, b=2, c=3)
    assert has_callables(bytes_0) == True
    assert has_callables(bytes_0, "decode", "encode") == True
    assert has_callables(bytes_0, "decode") == True
    assert has_callables(dict_0) == True
    assert has_callables(dict_0, "get", "keys", "values", "items") == True
    assert has_callables(dict_0, "get", "keys", "values", "bar") == True
    assert has_callables(dict_0, "get", "keys", "bar") == True

# Generated at 2022-06-25 17:28:41.175367
# Unit test for function has_callables
def test_has_callables():
    assert callable(has_callables) is True


# Generated at 2022-06-25 17:28:51.081672
# Unit test for function has_callables
def test_has_callables():
    '''
        has_callables is testing for callable objects
    '''
    bytes_0 = b'@fC\xbell*\x1dG\x1c\xbd'
    bool_0 = has_callables(bytes_0)
    # print("bool_0: ", bool_0)
    assert bool_0 is False
    # print("return: ", str(bool_0))


if __name__ == '__main__':
    test_case_0()
    test_has_callables()

# Generated at 2022-06-25 17:28:57.919009
# Unit test for function has_callables
def test_has_callables():
    list_0 = [1, 2, 3]
    str_0 = 'hello'
    cls_0 = dict
    assert(has_callables(list_0, 'append'))
    assert(has_callables(str_0, 'swapcase', 'split'))
    assert(has_callables(cls_0, 'fromkeys', 'clear'))
    assert(not has_callables(list_0, 'swapcase'))
    assert(not has_callables(str_0, 'to_dict'))
    assert(not has_callables(cls_0, 'to_dict'))

# Generated at 2022-06-25 17:29:03.880272
# Unit test for function has_callables
def test_has_callables():
    class obj:
        @staticmethod
        def foo():
            return "foo"
        @staticmethod
        def bar():
            return "bar"
        @staticmethod
        def foobar():
            return "foobar"

    assert has_callables(obj, "foo", "bar") is True
    assert has_callables(obj, "foo", "bar", "foobar") is True
    assert has_callables(obj, "foo", "bar", "foobar", "baz") is False



# Generated at 2022-06-25 17:29:09.081120
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar') == False
    assert has_any_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-25 17:29:13.204029
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList
    ulist = UserList()
    attrs = ('insert', 'append')

    assert has_callables(ulist, *attrs)
    assert not has_callables(ulist)
    assert not has_callables(ulist, *attrs, 'foo')



# Generated at 2022-06-25 17:29:24.527514
# Unit test for function has_attrs
def test_has_attrs():
    import os
    import random
    import string
    import subprocess
    from shlex import split
    from tempfile import mkstemp
    import time
    import unittest
    from subprocess import check_output
    from typing import List, Dict, Any
    from unittest import mock
    from unittest.mock import Mock
    from unittest.mock import MagicMock, PropertyMock
    from unittest.mock import patch
    from unittest.mock import call, mock_open
    from tempfile import NamedTemporaryFile
    from decimal import Decimal
    from random import randrange
    from random import randint
    from random import choice
    from random import sample
    from collections import OrderedDict
    from collections import ChainMap
    from collections import Counter
    from collections import defaultdict

# Generated at 2022-06-25 17:29:29.981090
# Unit test for function has_callables
def test_has_callables():
    x = 1
    assert has_callables(x, 'to_bytes') is False
    x.to_bytes = lambda x, y: y
    assert has_callables(x, 'to_bytes') is True
    class A:
        def __init__(self):
            self.a = 1
            self.b = lambda: self.a
    a = A()
    assert has_callables(a, 'a', 'b') is True
    assert has_callables(a, 'a', 'b', 'c') is False



# Generated at 2022-06-25 17:29:35.204353
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    dict_1 = dict(a=1)
    dict_2 = dict(a=1, b=2)


# Generated at 2022-06-25 17:29:39.151942
# Unit test for function has_callables
def test_has_callables():
    bytes_0 = b'@fC\xbell*\x1dG\x1c\xbd'
    assert has_callables(bytes_0, 'decode')

# Generated at 2022-06-25 17:29:44.132362
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict as ODict
    obj = ODict(a=1, b=2)

    assert has_callables(obj, 'keys') == True
    assert has_callables(obj, '__iter__', 'items') == True

    assert has_callables(obj, 'update') == False
    assert has_callables(obj, '__iter__', 'update') == False

    assert has_callables(obj) == False
    assert has_callables(obj, '') == False

