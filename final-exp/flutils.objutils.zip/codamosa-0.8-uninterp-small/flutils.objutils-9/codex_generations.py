

# Generated at 2022-06-25 17:20:58.619583
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Check that with arguments that satisfy it, as well as those that don't.
    """
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'
                             ) is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values'
                             ) is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'
                             ) is True


# Generated at 2022-06-25 17:21:09.696803
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import (
        Counter,
        OrderedDict,
    )
    from collections.abc import (
        Mapping,
        MutableMapping,
    )
    from collections.abc import (
        Iterable,
        MutableIterable,
    )
    from collections.abc import (
        Sized,
        Container,
    )
    from typing import (
        Any,
        AnyStr,
        Callable,
        Union,
        Iterable as _Iterable,
    )
    from typing import (
        Mapping as _Mapping,
        MutableMapping as _MutableMapping,
        Sequence as _Sequence,
        MutableSequence as _MutableSequence,
    )

# Generated at 2022-06-25 17:21:21.703972
# Unit test for function has_attrs
def test_has_attrs():
    obj_1 = dict()

    def _attrs(*attrs):
        return has_attrs(obj_1, *attrs)

    bool_0 = _attrs('get', 'keys', 'items', 'values')
    bool_1 = has_attrs(obj_1, 'get', 'keys', 'items', 'values', 'foo')
    bool_2 = _attrs('get', 'keys', 'items', 'values', 'foo')
    bool_3 = _attrs('get', 'keys', 'items', 'values', 'foo')
    bool_4 = _attrs('get', 'keys', 'items', 'values', 'foo')
    bool_5 = _attrs('get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-25 17:21:28.158218
# Unit test for function has_callables
def test_has_callables():
    # Test Case 0
    # Test Case 0.0
    assert(has_callables(dict(), 'get', 'keys', 'items', 'values'))
    # Test Case 0.1
    assert(not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'))



# Generated at 2022-06-25 17:21:35.334850
# Unit test for function has_attrs
def test_has_attrs():
    class TestClass:
        def __init__(self):
            self.get = 'get'
            self.keys = 'keys'
            self.items = 'items'
            self.values = 'values'

    obj_0 = TestClass()

    bool_0 = has_attrs(obj_0, 'get', 'keys', 'items', 'values')

    assert bool_0 is True


# Generated at 2022-06-25 17:21:44.182651
# Unit test for function has_any_callables
def test_has_any_callables():
    test_dict = {'foo': 'bar'}
    assert has_any_callables(test_dict, 'greet', 'items', 'keys', 'values') is True, 'test_has_any_callables failed'
    test_dict2 = {'foo': 'bar', 'greet': lambda x:print(x)}
    assert has_any_callables(test_dict2, 'greet', 'items', 'keys', 'values') is True, 'test_has_any_callables failed'
    test_dict3 = {'foo': 'bar', 'greet': 'hello'}
    assert has_any_callables(test_dict3, 'greet', 'items', 'keys', 'values') is True, 'test_has_any_callables failed'

# Generated at 2022-06-25 17:21:51.998218
# Unit test for function has_callables
def test_has_callables():
    # A test for suite with good input
    x = dict(a=1, b=2)
    print(has_callables(x, 'get', 'setdefault'))
    # A test for suite with bad input
    print(has_callables(x, 'len'))
    # A test for suite with mixed input
    print(has_callables(x, 'get', 'len', 'setdefault'))



# Generated at 2022-06-25 17:21:57.223555
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = dict()
    bool_0 = has_any_callables(obj_0,'get','keys','items','values','something')
    assert bool_0 is True
    obj_0 = set()
    bool_0 = has_any_callables(obj_0,'get','keys','items','values','something')
    assert bool_0 is False


# Generated at 2022-06-25 17:22:10.976704
# Unit test for function has_any_callables
def test_has_any_callables():
    '''
    This test is for the function has_any_callables().
    The has_any_callables() function takes an input object and checks if the 
    input object has the attributes and if they are callable.
    This test checks the case when it exists and the case when it doesn't.
    '''
    # Test Case 1
    o1 = dict()
    o1_attrs = ('get', 'keys', 'items', 'values')
    o1_output = has_any_callables(o1, *o1_attrs)
    # Test Case 2
    o2 = dict()
    o2_attrs = ('get', 'keys', 'items', 'values', 'something')
    o2_output = has_any_callables(o2, *o2_attrs)
    # Print the output
   

# Generated at 2022-06-25 17:22:14.643729
# Unit test for function has_callables
def test_has_callables():
    result = has_callables('foo', 'get')
    assert result == False



# Generated at 2022-06-25 17:22:29.043999
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('test','strip','upper','lower','title','isupper','islower','istitle','upper','lower','title','isupper','islower','istitle','split','splitlines','swapcase','zfill','join','replace','capitalize','count','endswith','startswith','expandtabs','find','rfind','index','rindex','format','format_map','isalnum','isalpha','isascii','isdecimal','isdigit','isidentifier','islower','isnumeric','isprintable','isspace','istitle','isupper','ljust','rjust','lower','lstrip','rstrip','strip','swapcase','partition','rpartition','maketrans','translate','center','zfill') is True



# Generated at 2022-06-25 17:22:40.833920
# Unit test for function has_any_callables
def test_has_any_callables():
    assert not has_any_callables(None)
    assert has_any_callables(bool())
    assert has_any_callables(bytes())
    assert has_any_callables(bytearray())
    assert has_any_callables(set())
    assert not has_any_callables(ChainMap())
    assert has_any_callables(Counter())
    assert has_any_callables(UserDict())
    assert has_any_callables(OrderedDict())
    assert has_any_callables(defaultdict())
    assert not has_any_callables(Decimal(0))
    assert has_any_callables(dict())
    assert not has_any_callables(float())
    assert not has_any_callables(frozenset())

# Generated at 2022-06-25 17:22:45.327510
# Unit test for function has_callables
def test_has_callables():
    nodict = dict()
    assert has_callables(nodict, 'get', 'keys', 'items', 'values') == True
    assert has_callables(nodict, 'something') == False
    assert has_callables(nodict, 'something', 'get', 'keys', 'items', 'values') == False


# Generated at 2022-06-25 17:22:52.817862
# Unit test for function has_callables
def test_has_callables():
    obj_0 = list()
    obj_1 = has_callables(obj_0, 'append', '__add__')
    assert obj_1 == True

    obj_0 = list()
    obj_1 = has_callables(obj_0, 'foo', 'bar')
    assert obj_1 == False



# Generated at 2022-06-25 17:23:02.257418
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(bool, '__eq__')
    assert has_any_callables(bool, '__eq__', '__call__', '__bool__')
    assert has_any_callables(bool, '__call__', '__bool__')
    assert not has_any_callables(bool, '__len__', '__exit__')

    # Test lists
    assert has_any_callables([], 'append', 'clear', 'extend')
    assert has_any_callables([], '__add__', '__class__', '__eq__')
    assert not has_any_callables([], '__gt__', '__init__', '__le__')

    # Test dicts
    assert has_any_callables({}, 'clear', 'fromkeys')
    assert has_any_call

# Generated at 2022-06-25 17:23:15.390140
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    dict_1 = dict(a=1,b=2,c=3)
    dict_2 = dict(a=1,b=2,c=3,d=4,e=5,f=6)
    list_0 = list()
    list_1 = list((1, 2, 3))
    list_2 = list((1, 2, 3, 4, 5, 6))
    set_0 = set()
    set_1 = set((1, 2, 3))
    set_2 = set((1, 2, 3, 4, 5, 6))
    tuple_0 = tuple()
    tuple_1 = tuple((1, 2, 3))
    tuple_2 = tuple((1, 2, 3, 4, 5, 6))

# Generated at 2022-06-25 17:23:19.160886
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-25 17:23:20.657254
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(1, "bit_length") is True


# Generated at 2022-06-25 17:23:24.349806
# Unit test for function has_any_callables
def test_has_any_callables():
    assert False
    from flutils.objutils import (
        has_any_callables,
    )
    bool_0 = True
    bool_1 = has_any_callables(bool_0)
    assert bool_1 is True



# Generated at 2022-06-25 17:23:33.851781
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    dict_0.__setitem__ = lambda self, key, value: None
    dict_0.__delitem__ = lambda self, key: None
    dict_0.get = lambda key, default: default
    dict_0.items = lambda: None
    dict_0.keys = lambda: None
    dict_0.values = lambda: None
    dict_0.update = lambda other: None
    test_0(dict_0, '__setitem__', '__delitem__', 'get', 'items', 'keys', 'values', 'update', True)
    dict_0.clear = lambda: None
    test_0(dict_0, '__setitem__', '__delitem__', 'get', 'items', 'keys', 'values', 'update', True)

# Generated at 2022-06-25 17:23:38.774503
# Unit test for function has_callables
def test_has_callables():
    test_case_0()


# Generated at 2022-06-25 17:23:50.480888
# Unit test for function has_callables
def test_has_callables():
    """Test the function has_callables"""
    assert has_callables({}, '__getitem__')
    assert has_callables('hello', '__contains__')
    assert has_callables([1, 2, 3], '__iter__')
    assert not has_callables(bool, '__setitem__')
    assert not has_callables(set, '__add__')
    assert not has_callables({}, '__get')
    assert not has_callables('hello', '__getitem__')
    assert not has_callables([1, 2, 3], '__join')
    assert not has_callables(None, '__contains__')

# This statement is required by the build system to import the unit test
# module.
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:23:53.759216
# Unit test for function has_any_callables
def test_has_any_callables():
    expected = False
    actual = has_any_callables(bool(True))
    assert actual == expected



# Generated at 2022-06-25 17:24:01.264644
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(1, 'bit_length') is True
    assert has_callables(1, 'bit_length', 'foo') is False
    assert has_callables(list(), 'append', 'clear', 'extend', 'insert') is True
    assert has_callables(list(), 'append', 'clear', 'extend', 'insert', 'foo') is False
    assert has_callables(dict(), 'clear', 'copy') is True
    assert has_callables(dict(), 'clear', 'copy', 'foo') is False
    assert has_callables(tuple(), 'count', 'index') is True
    assert has_callables(tuple(), 'count', 'index', 'foo') is False
    assert has_callables(str(), 'capitalize', 'casefold') is True

# Generated at 2022-06-25 17:24:08.792869
# Unit test for function has_callables
def test_has_callables():
    obj_0 = dict(a=1, b=2, c=3)
    assert has_callables(obj_0, 'get', 'items', 'keys', 'values') is True
    assert has_callables(obj_0, 'foo', 'bar', 'baz') is False
    assert has_callables(obj_0, 'get', 'items', 'keys', 'values', 'foo') is False



# Generated at 2022-06-25 17:24:24.244432
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter
    x = Counter()
    print(has_callables(x, "keys"))
    print(has_callables(x, "get"))
    print(has_callables(x, "foo"))
    print(has_callables(x, "keys", "foo"))
    print(has_callables(x, "get", "foo"))
    print(has_callables(x, "foo", "keys"))
    print(has_callables(x, "foo", "get"))
    print(has_callables(x, "foo", "foo"))
    print(has_callables(x, "keys", "get"))
    print(has_callables(x, "keys", "keys"))
    print(has_callables(x, "get", "get"))



# Generated at 2022-06-25 17:24:34.834069
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(bool, '__init__')
    assert not has_any_callables(bool, '__doc__')
    assert has_any_callables(None, '__init__')
    assert has_any_callables(bool, '__abs__', '__eq__')
    assert not has_any_callables(bool, '__abs__', '__doc__')
    assert has_any_callables(bool, '__abs__', '__doc__', '__eq__')


# Generated at 2022-06-25 17:24:40.639203
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables"""
    # if you want to run the tests, execute 'python3 -m pytest' in the
    # top-level folder
    global bool_0
    bool_0 = True
    bool_1 = has_any_callables(bool_0)
    if __name__ == "__main__":
        print(f"{bool_1}")


# Generated at 2022-06-25 17:24:43.352358
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(bool(), '__class__') == True
    assert has_any_callables(bool(), '__class__') == True



# Generated at 2022-06-25 17:24:56.075891
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = True
    bool_1 = None
    bool_2 = False
    bool_3 = False
    bool_4 = bool_1 is bool_3
    bool_4 = has_any_callables(bool_0)
    bool_5 = has_any_callables(bool_0, "imag")
    bool_6 = has_any_callables(bool_0, "is_integer", "numerator", "denominator")
    bool_7 = has_any_callables(bool_0, "is_integer", "numerator", "denominator", "imag")
    return bool_4, bool_5, bool_6, bool_7


# Generated at 2022-06-25 17:25:08.729985
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict()
    dict_0['a'] = 'foo'
    dict_0['b'] = 0
    dict_0['e'] = (1, 2, 3)
    dict_0['f'] = dict()
    dict_0['f']['foo'] = 'blah'

    dict_1 = dict()
    dict_1['a'] = 'foo'
    dict_1['b'] = 0
    dict_1['e'] = (1, 2, 3)
    dict_1['f'] = dict()
    dict_1['f']['foo'] = 'blah'

    dict_2 = dict()
    dict_2['a'] = 'foo'
    dict_2['b'] = 0
    dict_2['e'] = (1, 2, 3)

# Generated at 2022-06-25 17:25:21.027951
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(False) == False
    assert has_callables(True) == False
    assert has_callables(dict()) == True
    assert has_callables(dict(), 'get') == True
    assert has_callables(dict(), 'keys') == True
    assert has_callables(dict(), 'values') == True
    assert has_callables(dict(), 'get', 'keys') == True
    assert has_callables(dict(), 'keys', 'values') == True
    assert has_callables(dict(), 'keys', 'values', 'update') == True
    assert has_callables(dict(), 'keys', 'update', 'values') == True
    assert has_callables(dict(), 'keys', 'update', 'values', 'update') == False


# Generated at 2022-06-25 17:25:28.766598
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(int, 'bit_length')
    assert has_callables(int, '__bool__') is False
    assert has_callables('hello', '__bool__')


# Generated at 2022-06-25 17:25:37.341207
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('test') is False
    assert has_callables(dict(a=1, b=2)) is True
    assert has_callables(dict(a=1, b=2), 'pop', 'keys', 'items') is True
    assert has_callables(dict(a=1, b=2), 'pop', 'keys', 'items', 'foo') is False
    assert has_callables(dict(a=1, b=2), 'pop', 'keys', 'items', 'foo'
                         'bar', 'baz') is False


# Generated at 2022-06-25 17:25:42.824444
# Unit test for function has_callables
def test_has_callables():
    # assert True == has_callables(True)
    assert False == has_callables(True, 'attrs')


test_case_0()
test_has_callables()

# Generated at 2022-06-25 17:25:53.313242
# Unit test for function has_any_callables
def test_has_any_callables():
    assert isinstance(has_any_callables(bool, '__abs__'), bool)
    assert isinstance(has_any_callables(dict, '__setitem__'), bool)
    assert isinstance(has_any_callables(set, 'add'), bool)
    assert isinstance(has_any_callables(tuple, '__getitem__'), bool)
    assert isinstance(has_any_callables(frozenset, '__iter__'), bool)
    assert isinstance(has_any_callables(deque, 'append'), bool)
    assert isinstance(has_any_callables(Iterator, '__next__'), bool)
    assert isinstance(has_any_callables(KeysView, '__contains__'), bool)

# Generated at 2022-06-25 17:25:55.463938
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = "This is a test"
    if not has_any_callables(obj, 'isalnum'):
        print('function has_any_callables did not work.')


# Generated at 2022-06-25 17:26:01.477183
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(bool, '__and__', '__eq__', '__gt__') == True
    assert has_callables(bool, '__and__', '__eq__', '__gt__', '__lt__') == False
    assert has_callables(bool_0, '__and__', '__eq__', '__gt__') == False
    assert has_callables(bool_1, '__and__', '__eq__', '__gt__') == True
    assert has_callables(bytes, '__add__', '__contains__', '__eq__', '__ge__') == True


# Generated at 2022-06-25 17:26:09.309468
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test 0:
    test_case_0()
    # Test 1:
    obj = dict()
    assert (has_any_callables(obj, 'get', 'keys', 'items', 'values'))
    # Test 2:
    obj = {'a': 1, 'b': 2}
    assert (has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo'))
    # Test 3:
    obj = sorted('hello')
    assert (has_any_callables(obj, 'get', 'foo', 'sort'))
    # Test 4:
    obj = sorted('abcd')
    assert (has_any_callables(obj, 'get', 'foo', 'sort', 'join'))
    # Test 5:
    obj = list()

# Generated at 2022-06-25 17:26:21.340666
# Unit test for function has_callables
def test_has_callables():
    from collections import deque
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from flutils.objutils import has_callables
    from typing import (
        Any as _Any,
    )

    _LIST_LIKE = (
        deque,
        Iterator,
        KeysView,
        ValuesView,
    )

    for cls in _LIST_LIKE:
        obj = cls()
        assert has_callables(obj, '__iter__', '__len__') is True

    class Class_0(object):
        def __getitem__(self, item: _Any) -> _Any:
            return item

        def __iter__(self) -> _Any:
            return iter([])


# Generated at 2022-06-25 17:26:30.795264
# Unit test for function has_callables
def test_has_callables():
    from . import objutils
    assert objutils.has_callables({}, 'get', 'keys', 'items', 'values') is False
    #assert objutils.has_callables(5, 'get', 'keys', 'items', 'values') is False


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:26:33.918044
# Unit test for function has_any_callables
def test_has_any_callables():
    class A:
        def foo():
            pass
    a = A()
    assert has_any_callables(a, 'foo', 'bar') is True
    assert has_any_callables(a, 'bar') is False


# Generated at 2022-06-25 17:26:44.079759
# Unit test for function has_any_callables
def test_has_any_callables():
    test_cases = (
        (
            (1, '__add__', '__mod__'),
            True,
        ),
        (
            (2, '__add__', '__mod__'),
            True,
        ),
        (
            (3, '__add__', '__mod__'),
            True,
        ),
        (
            (4, '__add__', '__mod__'),
            True,
        )
    )
    for test_case, expected in test_cases:
        obj, *attrs = test_case
        actual = has_any_callables(obj, *attrs)
        assert actual == expected



# Generated at 2022-06-25 17:26:51.981447
# Unit test for function has_callables
def test_has_callables():
    # Objects that are not iterable or list-like should return False
    assert has_callables(1, '__iter__') == False
    assert has_callables(1.1, '__iter__') == False
    assert has_callables(True, '__iter__') == False
    assert has_callables('hello', '__iter__') == False
    assert has_callables(b'hello', '__iter__') == False
    assert has_callables(dict(), '__iter__') == False
    assert has_callables({'a': 1}, '__iter__') == False

    # List-like objects should return True
    assert has_callables(set(), '__iter__') == True
    assert has_callables(frozenset(), '__iter__') == True

# Generated at 2022-06-25 17:26:55.766378
# Unit test for function has_any_callables
def test_has_any_callables():
    bool_0 = True
    bool_1 = has_any_callables(bool_0)
    assert bool_1 == False

# Generated at 2022-06-25 17:27:04.711419
# Unit test for function has_callables
def test_has_callables():
    from collections import deque
    from collections.abc import (
        KeysView,
        ValuesView,
    )
    from typing import Dict
    from random import randint, random
    from pytest import raises

    # simple class
    class Foo:
        def __init__(self, **kwargs: Dict[str, Any]) -> None:
            for k, v in kwargs.items():
                setattr(self, k, v)

    # generic classes
    str_0 = 'f'
    str_1 = str_0 * randint(2, 5)
    int_0 = randint(0, 10)
    float_0 = random()
    tuple_0 = (
        str_0,
        str_1,
        int_0,
        float_0,
    )

# Generated at 2022-06-25 17:27:11.564984
# Unit test for function has_any_callables
def test_has_any_callables():
    assert ''.join([type(x).__name__ for x in (1,)]) == 'int'
    assert has_any_attrs(bool_0) == bool_0
    assert has_any_callables(bool_0) == bool_0
    assert is_subclass_of_any(bool_0) == bool_0
    assert is_list_like(bool_0) == bool_0


# Generated at 2022-06-25 17:27:22.094205
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(type(bool()), 'mro', '__subclasshook__') is True

    # Base classes
    assert has_callables(
        bool,
        'mro',
        '__subclasshook__'
    ) is True
    assert has_callables(
        int,
        'mro',
        '__subclasshook__'
    ) is True
    assert has_callables(
        float,
        'mro',
        '__subclasshook__'
    ) is True
    assert has_callables(
        complex,
        'mro',
        '__subclasshook__'
    ) is True
    assert has_callables(
        str,
        'mro',
        '__subclasshook__'
    ) is True

# Generated at 2022-06-25 17:27:23.299508
# Unit test for function has_any_callables
def test_has_any_callables():
    x = 42
    assert has_any_callables(x) is True



# Generated at 2022-06-25 17:27:28.455675
# Unit test for function has_callables
def test_has_callables():
    dict_0 = {'k1': 1, 'k2': 2, 'k3': 3}
    dict_1 = {'k1': 1, 'k2': 2, 'k3': 3, 'k4': 4}
    assert has_callables(dict_0, 'keys', 'items', 'values', 'get') is True
    assert has_callables(dict_0, 'keys', 'items', 'values', 'something') is False
    assert has_callables(dict_1, 'keys', 'items', 'values', 'something') is False
    assert has_callables(dict_1, 'keys', 'items', 'values', 'get') is True
