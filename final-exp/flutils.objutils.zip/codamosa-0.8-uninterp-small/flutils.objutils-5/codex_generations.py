

# Generated at 2022-06-25 17:20:59.453359
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test for valid input
    obj = {'a':1, 'b':2, 'c':3}
    arr = ['a','b','c']
    assert(has_any_callables(obj,'keys','items','values'))
    assert(has_any_callables(arr,'count','index'))
    # Test for invalid input

# Generated at 2022-06-25 17:21:03.478585
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = ['get', 'keys', 'items', 'values', 'foo']
    assert has_any_callables(dict(), *list_0) is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
# /test_has_any_callables



# Generated at 2022-06-25 17:21:17.349265
# Unit test for function has_any_callables
def test_has_any_callables():
    # Given a valid dictionary
    obj_0 = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5
    }
    # And a set of valid attributes
    attrs_0 = [
        'move_to_end',
        'setdefault',
        'get',
        'keys',
        'items'
    ]
    # When I call has_any_callables with the dictionary and attributes
    ret_0 = has_any_callables(obj_0, *attrs_0)
    # Then I expect True
    assert ret_0 == True

    # Given a valid dictionary

# Generated at 2022-06-25 17:21:22.628098
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-25 17:21:26.189867
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'bar')


# Generated at 2022-06-25 17:21:37.317421
# Unit test for function has_callables
def test_has_callables():
    def foo():
        return

    obj = {'a': 1, 'b': 2}
    int_0 = -333
    result = has_callables(obj, 'get')
    result_1 = has_callables(obj, 'remove')
    result_2 = has_callables(int_0, '__add__')
    result_3 = has_callables(obj, '__add__')
    result_4 = has_callables(obj, '__add__', 'get', 'remove')
    result_5 = has_callables(obj, 'get', 'remove', '__add__')
    result_6 = has_callables(obj, '__add__', 'remove', 'get')
    result_7 = has_callables(int_0, '__add__', '__sub__')
    result_

# Generated at 2022-06-25 17:21:40.345510
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest

# Generated at 2022-06-25 17:21:52.125705
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(int(), 'real', 'conjugate')
    assert has_any_callables(int, 'real', 'conjugate')
    assert not has_any_callables(int(), 'real', 'conjugate', 'foo')
    assert has_any_callables(dict(), 'real', 'conjugate')
    assert has_any_callables(dict(), 'real', 'conjugate', 'keys')
    assert not has_any_callables(dict(), 'real', 'conjugate', 'foo')



# Generated at 2022-06-25 17:22:01.227624
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Make sure has_any_callables() can find a callable attribute in an object
    """
    def callable_method():
        pass

    class Foo:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    foo = Foo(1, 2)
    if has_any_callables(foo, 'a', 'b', '__init__', 'callable_method'):
        print('1. has_any_callables() passed the test')
    else:
        print('1. has_any_callables() failed the test')


if __name__ == '__main__':
    test_case_0()
    test_has_any_callables()

# Generated at 2022-06-25 17:22:06.788007
# Unit test for function has_any_callables
def test_has_any_callables():
    d = {'a': 1, 'b': 2}
    assert has_any_callables(d, 'get', 'keys', 'items', 'something') is True
    assert has_any_callables(d, 'something', 'nothing') is False



# Generated at 2022-06-25 17:22:10.240468
# Unit test for function has_callables
def test_has_callables():
    test_case_0()


# Generated at 2022-06-25 17:22:22.767788
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    list_like = {
        "get": lambda x:x, "keys": lambda x:x, "values": lambda x:x, "items": lambda x:x
    }
    assert has_any_callables(list_like, "get", "keys", "items", "values") is True
    assert has_any_callables(list_like, "foo", "zoo", "bar", "zar") is False
    assert has_any_callables([], "foo", "zoo", "bar", "zar") is False


# Generated at 2022-06-25 17:22:25.969036
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    result = has_attrs(obj, 'get', 'keys', 'items', 'values')
    assert result is True
    result = has_attrs(obj, 'foo', 'bar')
    assert result is False


# Generated at 2022-06-25 17:22:35.138099
# Unit test for function has_callables
def test_has_callables():
    # Create a test class for has_callables
    class TestClass:
        # Define a test function for has_callables
        def test_function(self):
            # Create a test string for has_callables
            test_str = "test str"
            # return the test str
            return test_str

    # Create the test object
    test_obj = TestClass()
    # test the has_callables
    test_has_callables = has_callables(test_obj, "test_function")
    # Assert True to indicate the test passed
    assert test_has_callables is True

# Generated at 2022-06-25 17:22:38.248471
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList
    list_0 = UserList([1, 2, 3])
    bool_0 = has_callables(list_0, '__getitem__', '__iter__')
    #assert bool_0 == True


# Generated at 2022-06-25 17:22:43.339746
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    from datetime import date
    # Test for True
    assert has_attrs(date(2020, 1, 1), 'year', 'month', 'day')
    assert has_attrs(date(2020, 1, 1), 'ctime', 'timetuple', 'toordinal')
    # Test for False
    assert has_attrs(date(2020, 1, 1), 'year', 'month', 'day', 'hour') is False
    assert has_attrs(date(2020, 1, 1), 'ctime', 'timetuple', 'toordinal',
                     'isoformat') is False

# Generated at 2022-06-25 17:22:53.488209
# Unit test for function has_callables
def test_has_callables():
    dct_0 = {}
    print(has_any_callables(dct_0, 'foo'))
    assert (has_any_callables(dct_0, 'foo')) == False

    dct_1 = {'foo': None}
    print(has_any_callables(dct_1, 'foo'))
    assert (has_any_callables(dct_1, 'foo')) == False

    list_0 = [1, 2, 3]
    print(has_any_callables(list_0, 'pop'))
    assert (has_any_callables(list_0, 'pop')) == True
    
    str_0 = 'foo'
    print(has_any_callables(str_0, 'foo'))

# Generated at 2022-06-25 17:22:56.718336
# Unit test for function has_any_callables
def test_has_any_callables():
    test_case_0()

# Generated at 2022-06-25 17:23:03.293436
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(lambda: None, '__call__')
    assert not has_any_callables(lambda: None, 'not_a_callable')
    assert has_any_callables(dict(),'get','keys','values','items','abc')
    assert not has_any_callables(dict(),'abc','def','ghi','jkl','mno')
    assert not has_any_callables(None)


# Generated at 2022-06-25 17:23:12.041605
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str, 'strip')
    assert has_callables(str, 'upper', 'upper') is False
    assert has_callables(str, 'asdf') is False
    assert has_callables(dict, 'keys', 'values')
    assert has_callables([], 'append', 'pop')
    assert has_callables(None, 'foo') is False
    assert has_callables([], 'foo') is False
    assert has_callables(object(), 'asdf') is False



# Generated at 2022-06-25 17:23:25.101777
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import deque
    sample_list = deque([0, 0, 1], [1, 1, 2])
    assert has_callables(sample_list, 'append')
    assert has_callables(sample_list, 'clear')
    assert not has_callables(sample_list, 'foo')
    sample_list.clear()
    assert has_callables(sample_list, 'append')
    assert not has_callables(sample_list, 'clear')



# Generated at 2022-06-25 17:23:30.640920
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values',
                             'something') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values',
                             'foo') is True



# Generated at 2022-06-25 17:23:35.440133
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1,2,3],'append','pop')
    assert has_any_callables('hello','upper','capitalize')
    assert has_any_callables(True,'real','real')


# Generated at 2022-06-25 17:23:38.781879
# Unit test for function has_callables
def test_has_callables():
    """ Check that has_callables returns true for a list object. """
    assert has_callables([], '__getitem__')


# Generated at 2022-06-25 17:23:50.482170
# Unit test for function has_callables
def test_has_callables():
    list_0 = [1, 2, 3, 4, 5]
    list_1 = []
    str_0 = "What"
    dict_0 = dict()
    dict_1 = {'a': None, 'b': None}
    assert has_callables(list_0, 'append', 'remove') is True
    assert has_callables(list_1, 'append', 'remove') is False
    assert has_callables(str_0, '__add__', '__contains__') is True
    assert has_callables(dict_0, '__copy__') is True
    assert has_callables(dict_1, '__copy__') is False
    assert has_callables(list_0, 'pop') is True

# Generated at 2022-06-25 17:23:57.008614
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys')
    assert not has_any_callables(dict(), 'foo')


# Generated at 2022-06-25 17:24:02.582177
# Unit test for function has_callables
def test_has_callables():
    list_0 = ('a',1,2.0,dict(a=1, b=2))
    assert has_callables(list_0, '__iter__', '__contains__') == False


# Generated at 2022-06-25 17:24:08.161839
# Unit test for function has_any_callables
def test_has_any_callables():
    print('Testing has_any_callables')
    assert has_any_callables({}, 'foo') is False
    assert has_any_callables({}, 'foo', 'get') is True
    print('Done testing has_any_callables')



# Generated at 2022-06-25 17:24:16.355138
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = [1, 2, 3]
    assert has_any_callables(list_0, 'append', 'pop', 'reverse', 'sort') is True


# Unit tests for function has_any_attrs

# Generated at 2022-06-25 17:24:28.550898
# Unit test for function has_callables
def test_has_callables():
    var = has_callables(list)
    assert var is True
    var = has_callables(dict)
    assert var is True
    var = has_callables(dict, 'keys', 'get', 'items', 'values')
    assert var is True
    var = has_callables(dict, 'keys', 'get', 'items', 'values', 'pop')
    assert var is True
    var = has_callables(dict, 'keys', 'get', 'items', 'values', 'pop', 'get')
    assert var is True
    var = has_callables(str, 'keys', 'get', 'items', 'values', 'pop')
    assert var is False
    var = has_callables(str, 'keys', 'get', 'items', 'values', 'pop', 'get')
    assert var is False
    var

# Generated at 2022-06-25 17:24:43.177637
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values','foo')==True)
    assert(has_any_callables('flutils','get','keys','items','values','foo')==False)
    assert(has_any_callables(list(),'get','keys','items','values','foo')==False)
    assert(has_any_callables(tuple(),'get','keys','items','values','foo')==False)
    assert(has_any_callables(reversed('flutils'),'get','keys','items','values','foo')==False)
    assert(has_any_callables(1,'get','keys','items','values','foo')==False)
    assert(has_any_callables(list(range(1, 5)),'get','keys','items','values','foo')==False)

# Generated at 2022-06-25 17:24:52.864515
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test if bool_0 is True
    assert True == has_any_callables(
        {"a": 1, "b": 2, "c": 3}, "keys", "values", "items")
    # Test if bool_0 is False
    assert False == has_any_callables(
        {"a": 1, "b": 2, "c": 3}, "keys", "values", "items", "foo")



# Generated at 2022-06-25 17:24:56.200271
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables((), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-25 17:25:02.028552
# Unit test for function has_callables
def test_has_callables():
    a = dict(a=1, b=2)
    assert has_callables(a, 'keys', 'items', 'values') is True
    assert has_callables(a, 'get', 'foo') is True
    assert has_callables(a, 'foo') is False
    assert has_callables(a, 'keys', 'foo') is False
    try:
        has_callables(a)
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 17:25:13.248900
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    This is a unit test for the function has_any_callables() in the module objutils.py.
    """
    import unittest
    class Testhas_any_callables(unittest.TestCase):
        def test_has_any_callables_0(self):
            self.assertEqual(has_any_callables(list()), True)
        def test_has_any_callables_1(self):
            self.assertEqual(has_any_callables('hello'), False)
        def test_has_any_callables_2(self):
            self.assertEqual(has_any_callables(None), False)
    unittest.main()



# Generated at 2022-06-25 17:25:23.565222
# Unit test for function has_callables
def test_has_callables():
    def function_a():
        return 1
    def function_b():
        return 2

    class TestClass(object):
        def __init__(self):
            self.a = function_a()
            self.b = function_b()
        def function_a(self):
            return 1
        def function_b(self):
            return 2

    test_0 = has_callables(tuple, 'append')
    assert test_0 == False

    test_0 = has_callables(list, 'append')
    assert test_0 == True

    test_0 = has_callables(list, 'append', 'clear')
    assert test_0 == True

    test_0 = has_callables(list, 'append', 'clear', 'index')
    assert test_0 == True

    test_0 = has_call

# Generated at 2022-06-25 17:25:29.304381
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = None
    assert has_any_callables(list_0) is False

    list_0 = [1, 2, 3]
    assert has_any_callables(list_0) is True
    assert has_any_callables(list_0, 'append', 'foo') is True
    assert has_any_callables(list_0, '__getitem__', '__add__', 'foo') is True
    assert has_any_callables(list_0, 'foo', 'bar', 'baz') is False

    dict_0 = {'a': 'b', 'c': 'd'}
    assert has_any_callables(dict_0, 'foo', 'bar', 'baz') is False
    assert has_any_callables(dict_0) is True
    assert has_any_call

# Generated at 2022-06-25 17:25:35.861176
# Unit test for function has_any_callables
def test_has_any_callables():
    list_0 = dict(a=1, b=2)
    assert has_any_callables(list_0,'get','keys','items') == True
    assert has_any_callables(list_0, 'get', 'keys', 'foo') == True
    assert has_any_callables(list_0, 'foo', 'bar', 'items') == False


# Unit tests for function has_any_attrs

# Generated at 2022-06-25 17:25:42.862204
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict(a=1, b=2)
    assert has_any_callables(dict_0) is True
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo', 'bar') is False
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is False
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz', 'buzz') is False

    dict_1 = dict(a=1, b=2)
    assert has_any_

# Generated at 2022-06-25 17:25:50.143469
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_0 = None
    assert has_any_callables(obj_0) == False
    obj_1 = dict(a=0,b=1,c=2)
    assert has_any_callables(obj_1) == True
    obj_2 = dict(a=0,b=1,c=2)
    assert has_any_callables(obj_2, 'get', 'keys', 'items', 'values', 'foo') == True
