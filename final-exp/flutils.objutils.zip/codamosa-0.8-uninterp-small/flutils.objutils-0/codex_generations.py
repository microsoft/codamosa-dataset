

# Generated at 2022-06-25 17:21:02.227616
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(), 'keys', 'items', 'values', 'something') == True)
    assert(has_any_attrs(dict(), 'something') == False)
    assert(has_any_attrs(str(), 'title', 'replace', 'count', 'something') == True)
    assert(has_any_attrs(str(), 'something') == False)
    assert(has_any_attrs(bytes(), 'title', 'replace', 'count', 'something') == True)
    assert(has_any_attrs(bytes(), 'something') == False)
    assert(has_any_attrs(list(), 'title', 'replace', 'count', 'something') == True)
    assert(has_any_attrs(list(), 'something') == False)

# Generated at 2022-06-25 17:21:04.991028
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something')


# Generated at 2022-06-25 17:21:10.940067
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') == True
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'bar') == False



# Generated at 2022-06-25 17:21:17.461150
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(), 'append') is True
    assert has_callables(set(), 'add') is True
    assert has_callables(dict(), 'update') is True
    assert has_callables(tuple(), 'count') is True
    assert has_callables(None, 'count') is False
    assert has_callables(1, 'count') is False
    assert has_callables(2.0, 'count') is False
    assert has_callables('test', 'count') is False
    assert has_callables(list(), 'append', 'update', 'count') is False


# Generated at 2022-06-25 17:21:24.544612
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables({'a': 1}, 'get', 'keys', 'items', 'values',
                         'something') is True
    assert has_callables(dict(), 'keys', 'items', 'values') is False


# Generated at 2022-06-25 17:21:33.751916
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(bool, 'bit_length') == False
    assert has_any_callables(int, 'bit_length') == True
    assert has_any_callables(str, 'bit_length') == False
    assert has_any_callables(dict, 'bit_length') == False



# Generated at 2022-06-25 17:21:38.117971
# Unit test for function has_any_callables
def test_has_any_callables():
    """ Test cases of has_any_callables """
    # Setup
    p = (2, 3, 5)
    p_s = "flutils is awesome"

    # Exercise
    bool_0 = has_any_callables(p, 'count')
    bool_1 = has_any_callables(p_s, 'count', 'find', 'join')
    bool_2 = has_any_callables(p_s, 'reverse', 'find', 'join')

    # Verify
    assert bool_0 == True
    assert bool_1 == True
    assert bool_2 == False



# Generated at 2022-06-25 17:21:42.129512
# Unit test for function has_callables
def test_has_callables():
    class A:
        def a(self):
            return 1

        @staticmethod
        def b():
            return 2

        @classmethod
        def c(cls):
            return 3

    a = A()
    assert has_callables(a, 'a', '__init__', 'b', 'c') is True



# Generated at 2022-06-25 17:21:54.693139
# Unit test for function has_any_callables
def test_has_any_callables():
    from unittest import TestCase
    from unittest.mock import Mock
    from flutils.objutils import has_any_callables
    result = has_any_callables(Mock(), 'foo')
    tc = TestCase()
    tc.assertFalse(result)
    result = has_any_callables(Mock(), 'foo', 'bar', 'baz')
    tc.assertFalse(result)
    result = has_any_callables(dict(), 'foo', 'bar', 'baz')
    tc.assertFalse(result)
    result = has_any_callables([], 'foo', 'bar', 'baz')
    tc.assertFalse(result)
    result = has_any_callables(list(), 'foo', 'bar', 'baz')
    tc.assertFalse(result)

# Generated at 2022-06-25 17:22:01.412768
# Unit test for function has_callables
def test_has_callables():
    class test(): pass
    test_obj = test()
    test_obj.is_callable = True
    assert has_callables(test_obj, 'is_callable')
    test_obj.is_callable = "string"
    assert not has_callables(test_obj, 'is_callable')
    assert not has_callables(test_obj, 'is_callable', 'another')
    assert not has_callables(test_obj, 'is_callable', 'another_one')
    test_obj.another_one = True
    assert not has_callables(test_obj, 'is_callable', 'another_one')
    test_obj.is_callable = True
    test_obj.another_one = True

# Generated at 2022-06-25 17:22:07.725011
# Unit test for function has_any_attrs
def test_has_any_attrs():
    _obj: str = 'this is a test string'
    _attrs: tuple = ('find', 'index', 'upper', 'isupper')
    assert has_any_attrs(_obj, *_attrs) == True


# Generated at 2022-06-25 17:22:19.942164
# Unit test for function has_callables
def test_has_callables():
    str_0 = 'bit_length'
    str_1 = 'denominator'
    str_2 = 'numerator'
    str_3 = 'is_integer'
    str_4 = 'to_bytes'
    str_5 = 'from_bytes'
    str_6 = 'is_signed'
    str_7 = '__pow__'
    str_8 = 'conjugate'
    str_9 = 'as_integer_ratio'
    str_10 = '__bool__'
    str_11 = '__eq__'
    str_12 = '__ne__'
    str_13 = '__lt__'
    str_14 = '__le__'
    str_15 = '__gt__'
    str_16 = '__ge__'

# Generated at 2022-06-25 17:22:30.083971
# Unit test for function has_callables
def test_has_callables():
    # unit test for function has_callables
    from decimal import Decimal
    from collections import ChainMap
    from datetime import date

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(ChainMap({},{}), 'get', 'keys', 'items', 'values') == True
    assert has_callables(date(2018, 1, 24), 'replace', 'weekday', 'month') == True
    assert has_callables(Decimal(1), 'is_nan', 'is_finite', 'log10') == True
    assert has_callables(dict(), 'foo', 'bar', 'baz') == False
    assert has_callables(ChainMap({},{}), 'foo', 'bar', 'baz') == False

# Generated at 2022-06-25 17:22:34.068279
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # test case 1
    assert has_any_attrs(object(), 'foo', 'bar', 'baz') is False

    # test case 2
    str_0 = 'bit_length'
    assert has_any_attrs(str_0, 'foo', 'bar', 'baz') is False



# Generated at 2022-06-25 17:22:42.334174
# Unit test for function has_any_callables
def test_has_any_callables():
    list_1 = [1, 2, 3, 4]
    assert has_any_callables(list_1, '__iter__') is True
    assert has_any_callables(list_1, '__iter__', 'append') is True
    assert has_any_callables(list_1, '__iter__', 'append', '__contains__') is True


if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:22:52.982828
# Unit test for function has_any_callables
def test_has_any_callables():
    from typing import Iterator
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    import decimal
    obj_0 = decimal.Decimal(1)
    obj_1 = dict(a=1, b=2)
    obj_2 = Iterator(range(0, 5))
    obj_3 = None
    obj_4 = str_0 = 'bit_length'
    obj_5 = UserDict()
    obj_6 = UserString('bit_length')
    obj_7 = defaultdict(int)
    obj_8 = OrderedDict()
    obj_9 = Counter()
    obj_10 = ChainMap(obj_1)

# Generated at 2022-06-25 17:23:02.349260
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Unit test for function has_any_attrs. Init.
    obj = dict(A=1, B=2)
    for attr in ('C', 'D'):
        assert has_any_attrs(obj, attr) is False
    assert has_any_attrs(obj, 'A', 'B') is True
    assert has_any_attrs(obj, 'B', 'A') is True
    assert has_any_attrs(obj, 'A', 'C') is True
    assert has_any_attrs(obj, 'C', 'A') is True
    assert has_any_attrs(obj, 'A', 'B', 'C') is True
    assert has_any_attrs(obj, 'C', 'A', 'B') is True

# Generated at 2022-06-25 17:23:08.067274
# Unit test for function has_any_callables
def test_has_any_callables():
    '''Test the function has_any_callables'''
    # Test with a dictionary
    test_dict = dict()
    test_dict['a'] = 1
    test_dict['b'] = 2

    expected = True
    print("Test with dict")
    print("Input: ",test_dict)
    print("Expected: ",expected)
    actual = has_any_callables(test_dict,'keys','items','values','something')
    print("Actual: ",actual)
    assert expected==actual

    # Test with a list
    test_list = [1, 2, 3]

    expected = True
    print("Test with list")
    print("Input: ",test_list)
    print("Expected: ",expected)

# Generated at 2022-06-25 17:23:16.319888
# Unit test for function has_any_attrs
def test_has_any_attrs():
    str_0 = 'bit_length'
    str_1 = 'hello'
    int_0 = 1
    obj_0 = test_case_0
    #assert has_any_attrs(int_0, str_1, str_0)
    #assert not has_any_attrs(obj_0, str_1, str_0)
    assert has_any_attrs(int_0, str_1, str_0)
    assert not has_any_attrs(obj_0, str_1, str_0)


# Generated at 2022-06-25 17:23:20.749714
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(str, str_0) is True

if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:23:33.576365
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'bit_length'
    str_1 = 'append'
    call_0 = callable(str_0)
    call_1 = callable(str_1)
    str_2 = str_0 + str_1
    str_3 = ''
    str_4 = 'abc'
    str_5 = str_4[0]
    str_6 = 'hello'
    call_2 = callable(str_6)
    str_7 = str_6[0]
    str_list = [str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7]

# Generated at 2022-06-25 17:23:38.780521
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = test_case_0
    assert has_any_callables(obj, 'bit_length', 'foo', 'bar')
    assert not has_any_callables(obj, 'foo', 'bar')


# Generated at 2022-06-25 17:23:50.480928
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('abc','upper','lower','encode','isascii','isdigit','find','title','casefold','format','index','capitalize','join','replace','split','strip','swapcase','translate','zfill','format_map','isalnum','isalpha','isidentifier','islower','isnumeric','isprintable','isspace','istitle','isupper','partition','rfind','rindex','rjust','rpartition','rsplit','rstrip','center','count','endswith','expandtabs','ljust','lower','lstrip','maketrans','startswith','splitlines','swapcase','title','zfill') is True

# Generated at 2022-06-25 17:23:58.499663
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'bit_length'
    float_0 = float('inf')
    float_1 = float('nan')
    float_2 = float('-inf')
    return_value = has_any_callables(float_1, str_0, str_0)
    return_value_1 = has_any_callables(float_0, str_0, str_0)
    return_value_2 = has_any_callables(float_2, str_0, str_0)
    return None



# Generated at 2022-06-25 17:24:08.334328
# Unit test for function has_callables
def test_has_callables():

    ###########################################################################
    #
    #   Example #1
    #
    obj_1 = dict(a=1, b=2, c=3)

    assert has_callables(obj_1, 'get', 'update', 'values', 'foo')

    ###########################################################################
    #
    #   Example #2
    #
    obj_2 = dict(a=1, b=2, c=3)

    assert has_callables(obj_2, 'get', 'update', 'values', 'items')



# Generated at 2022-06-25 17:24:18.366662
# Unit test for function has_any_callables
def test_has_any_callables():
    test_list_0 = [1, 2, 3]
    if not has_any_callables(test_list_0, 'bit_length'):
        raise Exception('Problem in function has_any_callables')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:24:35.339736
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('foo', 'lower')
    assert has_any_callables('foo', 'lower', 'upper')
    assert has_any_callables('foo', 'lower', 'upper', 'title')
    assert not has_any_callables('foo', 'bar')
    assert not has_any_callables('foo', 'bar', 'baz')
    assert has_any_callables('foo', 'bar', 'lower')
    assert has_any_callables('foo', 'bar', 'upper')
    assert has_any_callables('foo', 'bar', 'title')
    assert not has_any_callables(None, 'lower')
    assert not has_any_callables(None, 'lower', 'upper')

# Generated at 2022-06-25 17:24:36.756289
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')

# Generated at 2022-06-25 17:24:43.416409
# Unit test for function has_callables
def test_has_callables():
    str_0 = 'bit_length'
    str_1 = is_subclass_of_any(str_0, KeysView, ValuesView, UserList)
    str_2 = issubclass(str_0, KeysView)
    str_3 = issubclass(str_0, UserList)
    str_4 = issubclass(str_0, ValuesView)
    assert(str_1 == False)
    assert(str_2 == False)
    assert(str_3 == False)
    assert(str_4 == False) 


# Generated at 2022-06-25 17:24:50.869215
# Unit test for function has_callables
def test_has_callables():
    obj_0 = 'bit_length'
    str_0 = 'attrs'
    str_1 = 'iter'
    str_2 = 'iter'
    print(has_callables(obj_0,str_0,str_1,str_2))


# Generated at 2022-06-25 17:25:03.910735
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    str_0 = 'bit_length'
    assert has_any_callables(str_0, 'bit_length') == True    
    assert has_any_callables(str_0, 'dsdsdsds') == False
    assert has_any_callables(str_0, 'bit_length', 'dsdsdsds') == True
    assert has_any_callables(str_0, 'bit_length', 'dsdsdsds', 'dsdsdsds') == True
    assert has_any_callables(str_0, 'dsdsdsds', 'dsdsdsds') == False
    assert has_any_callables(str_0, 'dsdsdsds', 'dsdsdsds', 'dsdsdsds') == False


# Generated at 2022-06-25 17:25:09.054703
# Unit test for function has_any_callables
def test_has_any_callables():
    a = dict(a=1, b=2)
    assert has_any_callables(a, 'get', 'iter', 'keys', 'values') is True
    assert has_any_callables(a, 'xxx', 'yyy') is False
    assert has_any_callables(1, 'bit_length') is False
    assert has_any_callables('xxx', 'isalnum') is True


# Generated at 2022-06-25 17:25:13.915373
# Unit test for function has_any_callables
def test_has_any_callables():
    objs = [dict(), set(), list(), str(), int(), print]
    for obj in objs:
        assert has_any_callables(obj, 'append', 'format', 'clear', 'upper')



# Generated at 2022-06-25 17:25:15.665355
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(str_0, 'bit_length', 'isupper') == True


# Generated at 2022-06-25 17:25:25.076941
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    from flutils.objutils import has_any_attrs
    from flutils.objutils import has_attrs
    from flutils.objutils import has_callables

    # has_any_callables
    it = [dict(a=1), {1, 2, 3}, map(None, 'abc'), (lambda x: x), None]
    for obj in it:
        assert has_any_callables(obj, '__contains__', '__iter__', '__next__')

    # has_any_attrs
    it = [dict(a=1), {1, 2, 3}, map(None, 'abc'), (lambda x: x), None]

# Generated at 2022-06-25 17:25:33.806026
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values'),\
        "Fails! (dict(), 'get', 'keys', 'items', 'values')"
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values',
                             'something'),\
        "Fails! (dict(), 'get', 'keys', 'items', 'values', 'something')"


# Generated at 2022-06-25 17:25:42.067603
# Unit test for function has_any_callables
def test_has_any_callables():
    ex_class = collections.UserDict
    assert has_any_callables(ex_class,'pop') 
    assert has_any_callables(ex_class,'pop','keys') 
    assert has_any_callables(ex_class,'pop','keys','_copy') 
    assert has_any_callables(ex_class,'pop','keys','_copy','get') 
    assert has_any_callables(ex_class,'pop','keys','_copy','get','items') 
    assert has_any_callables(ex_class,'pop','keys','_copy','get','items','values') 
    assert ~has_any_callables(ex_class,'pop','keys','_copy','get','items','values','_copy') 

# Generated at 2022-06-25 17:25:45.739021
# Unit test for function has_any_callables
def test_has_any_callables():
    # Create a lambda function
    str_0 = 'bit_length'
    lambda_0 = lambda: str_0
    # Assert
    assert has_any_callables(lambda_0, str_0) == True


# Generated at 2022-06-25 17:25:49.675150
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = "hello"
    assert has_any_callables(obj, 'upper', 'lower', 'title') == True
    assert has_any_callables(obj, 'get', 'keys') == False



# Generated at 2022-06-25 17:25:55.911206
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Return true if any of the attributes in the dict_obj is callable.
    """
    dict_obj = {'a': 10, 'b': 20, 'c': 30}
    if has_any_callables(dict_obj, 'get') is True:
        print('dict_obj is a container object and get is callable')


if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:26:11.047603
# Unit test for function has_callables
def test_has_callables():
    dict_0 = dict((('a', 1), ('b', 2), ('c', 3)))
    bool_0 = has_callables(dict_0, 'get', 'setdefault')
    assert bool_0 == False
    bool_1 = has_callables(dict_0, 'get', 'setdefault', 'items')
    assert bool_1 == True


# Generated at 2022-06-25 17:26:16.637993
# Unit test for function has_any_callables
def test_has_any_callables():
    assert callable(has_any_callables)
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__contains__') is True



# Generated at 2022-06-25 17:26:27.202940
# Unit test for function has_callables
def test_has_callables():
    from typing import ( Any )
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from flutils.objutils import (
        has_callables,
    )
    _LIST_LIKE = (
        list,
        set,
        frozenset,
        tuple,
        deque,
        Iterator,
        ValuesView,
        KeysView,
        UserList
    )
    _LIST_LIKE_KWARGS = {}
    for val in _LIST_LIKE:
        _LIST_LIKE_KWARGS[val] = {}

# Generated at 2022-06-25 17:26:33.917209
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import ChainMap
    from datetime import timedelta
    assert has_any_callables(ChainMap(), 'maps', 'get') is True
    assert has_any_callables(int(), 'bit_length', 'denominator', 'conjugate') is True
    assert has_any_callables(ChainMap(), 'denominator', 'conjugate') is False
    assert has_any_callables(timedelta(), 'denominator', 'conjugate') is False


# Generated at 2022-06-25 17:26:38.575608
# Unit test for function has_callables
def test_has_callables():
    str_0 = '__getitem__'
    list_0 = [1, 2, 3]
    assert has_callables(list_0, str_0)
    str_0 = 'does_not_exist'
    assert not has_callables(list_0, str_0)


# Generated at 2022-06-25 17:26:43.590261
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar') is False
    assert has_any_callables('foo', 'bar') is False


# Generated at 2022-06-25 17:26:51.661152
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(int(), 'bit_length')
    assert has_any_callables(str(), 'isalnum')
    assert has_any_callables(list(), 'append')
    assert has_any_callables(tuple(), 'count')
    assert has_any_callables({}, 'clear')
    assert has_any_callables(set(), 'add')
    assert has_any_callables(frozenset(), 'copy')
    assert has_any_callables(bound_method, '__getattribute__')
    assert has_any_callables(partial, '__getattribute__')
    assert has_any_callables(Exception, '__init__')
    assert has_any_

# Generated at 2022-06-25 17:26:56.675391
# Unit test for function has_callables
def test_has_callables():
    print("======== Test for function has_callables ========")
    print("Test case 0")
    test_case_0()
    print("=================================================")


# if __name__ == '__main__':
#     test_has_callables()

# Generated at 2022-06-25 17:27:00.174847
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'foo', 'bar') is False


# Generated at 2022-06-25 17:27:02.150377
# Unit test for function has_any_callables
def test_has_any_callables():
    assert (has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo'))



# Generated at 2022-06-25 17:27:13.907363
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-25 17:27:18.673263
# Unit test for function has_any_callables
def test_has_any_callables():
    obj_1 = [1, 2, 3]
    obj_2 = 'hello'
    print(has_any_callables(obj_1,'sort'))
    print(has_any_callables(obj_2, 'capitalize', 'format', 'encode'))



# Generated at 2022-06-25 17:27:23.465120
# Unit test for function has_callables
def test_has_callables():
    obj_0 = str_0.bit_length

    # Test if has_callables returns True when the given *attrs actually exist
    assert has_callables(obj_0, 'bit_length')

    # Test if has_callables returns False when the given *attrs actually exists but are not callable
    assert not has_callables(obj_0, 'bit_length', 'split')


# Generated at 2022-06-25 17:27:26.697461
# Unit test for function has_any_callables
def test_has_any_callables():
    # test case 1
    dict_0 = dict()
    if has_any_callables(dict_0, 'get', 'keys', 'items', 'values', 'foo') == True:
        print('Callable: ', dict_0)
    else:
        print('Not callable: ', dict_0)


# Generated at 2022-06-25 17:27:34.416764
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert len(obj) == 2
    assert has_callables(obj, 'get', 'keys') == True
    assert has_any_callables(obj, 'get', 'keys', 'foo') == True

    obj = list(range(10))
    assert len(obj) == 10
    assert has_callables(obj, 'append', 'sort', 'reverse') == True
    assert has_any_callables(obj, 'append', 'sort', 'foo') == True


# Generated at 2022-06-25 17:27:39.444941
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz', 'bat')

# Generated at 2022-06-25 17:27:41.280357
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(str_0, 'bit_length')



# Generated at 2022-06-25 17:27:46.738995
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'bit_length'
    str_1 = 'center'
    test_dict_0 = {
        'bit_length': 1,
        'center': 2
    }
    print(has_any_callables(test_dict_0, str_0, str_1))

if __name__ == '__main__':
    test_case_0()
    test_has_any_callables()

# Generated at 2022-06-25 17:27:52.891714
# Unit test for function has_any_callables
def test_has_any_callables():
    test_dct = {'a':1, 'b':2, 'c':3}
    assert has_any_callables(test_dct,'get','keys','items','values') is True
    assert has_any_callables(test_dct,'get','keys','items','values','foo') is True
    assert has_any_callables(test_dct,'get','keys','items','foo') is False
    assert has_any_callables(test_dct,'get','keys','items','foo','bar') is False


# Generated at 2022-06-25 17:28:04.644551
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj_0 = dict(a=1, b=2)
    test_str_0 = 'get'
    test_str_1 = 'keys'
    test_str_2 = 'items'
    test_str_3 = 'values'
    test_str_4 = 'foo'
    assert test_obj_0 is not None
    assert test_str_0 == 'get'
    assert test_str_1 == 'keys'
    assert test_str_2 == 'items'
    assert test_str_3 == 'values'
    assert test_str_4 == 'foo'
    assert has_any_callables(test_obj_0, test_str_0, test_str_1, test_str_2, test_str_3, test_str_4) == True



# Generated at 2022-06-25 17:28:24.646791
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    from datetime import datetime
    from flutils.objutils import has_callables
    from datetime import timedelta
    obj = OrderedDict(a=1, b=2)
    assert has_callables(obj, 'items', 'keys')
    obj = timedelta(days=30)
    assert has_callables(obj, 'total_seconds')
    obj = datetime.now()
    assert has_callables(obj, 'timestamp')


# Generated at 2022-06-25 17:28:34.531754
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest

    target_0 = dict(a=1, b=2)
    result_0 = has_any_callables(target_0, 'get', 'keys', 'items', 'values')
    assert(result_0)

    target_1 = dict(a=1, b=2)
    result_1 = has_any_callables(target_1, 'get', 'b', 'c', 'values')
    assert(result_1)

    target_2 = dict(a=1, b=2)
    result_2 = has_any_callables(target_2, 'get', 'b', 'c', 'd')
    assert(result_2 == False)

    # Test for error

# Generated at 2022-06-25 17:28:41.243905
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for the function ``has_callables``
    """
    class Foo:
        def __init__(self):
            self._a = 1

        def __repr__(self):
            return f"Foo(a={self._a})"

        def foo(self):
            return self._a

        @property
        def _bar(self):
            return self._a

    f = Foo()
    print(has_callables(f, 'foo', '_bar'))
    print(has_callables(f, 'foo', 'bar'))
    print(has_callables('', 'upper', 'lower'))
    print(has_callables('', 'upper', 'lower', 'foo'))
    print(has_callables(123, 'bit_length'))


# Generated at 2022-06-25 17:28:51.259503
# Unit test for function has_callables
def test_has_callables():
    # Test case 0:
    #   obj: str
    #   attrs: attribute that exists on str, attribute that doens't exist on str
    str_0 = 'bit_length'
    def assert_expr0(obj, attrs):
        return has_callables(obj, *attrs)
    assert assert_expr0(str_0, ['bit_length', 'assert_expr0']) == False
    # Test case 1:
    #   obj: str
    #   attrs: attribute that exists and is callable on str
    str_1 = 'bit_length'
    def assert_expr1(obj, attrs):
        return has_callables(obj, *attrs)
    assert assert_expr1(str_1, ['bit_length']) == True
    # Test case 2:
    #   obj:

# Generated at 2022-06-25 17:28:53.127501
# Unit test for function has_any_callables
def test_has_any_callables():
    str_0 = 'lstrip'
    print(has_any_callables(str_0, str_0))


# Generated at 2022-06-25 17:28:57.687457
# Unit test for function has_callables
def test_has_callables():

    class AA:
        def bar(self):
            return

    assert has_callables(AA(), 'bar') is True
    assert has_callables(AA(), 'foo') is False

    class BB:
        def __call__(self):
            return

    assert has_callables(BB(), '__call__') is True
    assert has_callables(BB(), 'foo') is False



# Generated at 2022-06-25 17:29:08.463110
# Unit test for function has_callables
def test_has_callables():
    dict_1 = dict()
    dict_1['foo'] = 'bar'
    callables_0 = ['__setitem__', '__getitem__', 'values']
    callables_1 = ['bar', 'baz', 'foo']
    # Test that has_callables returns False when there are no matching callables
    assert (has_callables(dict_1, *callables_1) == False)
    # Test that has_callables returns True when there is a matching callable
    assert (has_callables(dict_1, *callables_0) == True)
    assert (has_callables(dict_1, '__setitem__', '__getitem__') == True)
    assert (has_callables(dict_1, '__setitem__') == True)

# Generated at 2022-06-25 17:29:11.516073
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str, '__len__', '__str__') is True
    assert has_callables(str_0, 'bit_length') is True


# Generated at 2022-06-25 17:29:12.945162
# Unit test for function has_callables
def test_has_callables():
    pass


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 17:29:24.271840
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('', 'title', 'upper') is False
    assert has_any_callables('', 'title', 'upper', 'lower') is True

    assert has_any_callables(1, 'bit_length', 'upper') is False
    assert has_any_callables(1, 'bit_length') is True

    assert has_any_callables({}, 'items', 'keys') is True
    assert has_any_callables({}, 'items', 'keys', 'foo') is True
    assert has_any_callables({}, 'foo', 'bar') is False

    assert has_any_callables(True, 'bit_length') is False

    assert has_any_callables(set(), 'add') is True
    assert has_any_callables(set(), 'add', 'difference') is True



# Generated at 2022-06-25 17:29:44.418134
# Unit test for function has_callables
def test_has_callables():
    from types import MethodType
    class Foo():
        def bar():
            pass
    foo = Foo()
    bar = foo.bar
    bar = MethodType(bar, foo)

    assert has_callables(foo, 'bar') is True
    assert has_callables(foo, 'bar', 'foo') is False
    assert has_callables(foo, 'bar', 'bar') is True

    assert has_any_callables(foo, 'bar') is True
    assert has_any_callables(foo, 'bar', 'foo') is True
    assert has_any_callables(foo, 'bar', 'bar') is True

    callable_0 = bar
    assert callable(callable_0) is True

    assert callable_0() is None
    assert callable_0(callable_0) is None
   

# Generated at 2022-06-25 17:29:48.127094
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    bool_0 = False
    bool_1 = has_any_callables(bool_0)
    bool_2 = has_any_callables(bool_0, 'imag')



# Generated at 2022-06-25 17:29:51.044582
# Unit test for function has_callables
def test_has_callables():
    """Tests the has_callables function by calling it on a random object."""
    result = has_callables('test string')
    assert result == True

    result = has_callables(1)
    assert result == False


# Generated at 2022-06-25 17:29:55.822608
# Unit test for function has_any_callables
def test_has_any_callables():
    assert not has_any_callables(str(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(list(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'get', 'keys', 'iems', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-25 17:30:04.768503
# Unit test for function has_any_callables
def test_has_any_callables():
    # 0. `has_any_callables` returns `True` for an object that has a callable
    obj0 = {'a': 1, 'b': 2}
    assert(has_any_callables(obj0, 'get', 'keys', 'items', 'values', 'foo'))

    # 1. `has_any_callables` returns `True` for an object that doesn't have a callable
    obj1 = {'a': 1, 'b': 2}
    assert(has_any_callables(obj1, 'get', 'keys', 'items', 'values'))

    # 2. `has_any_callables` returns `False` for an object that doesn't have any of the given attrs
    obj2 = {'a': 1, 'b': 2}

# Generated at 2022-06-25 17:30:15.303716
# Unit test for function has_callables
def test_has_callables():
    """
    Test for function has_callables()
    """
    from flutils.objutils import has_callables
    from flutils.objutils import is_list_like
    from collections import UserDict
    from typing import Dict, Any

    bool_0 = True
    bool_1 = is_list_like(bool_0)
    bool_2 = has_callables(bool_0)

    num_0 = 1
    num_1 = is_list_like(num_0)
    num_2 = has_callables(num_0)

    str_0 = 'str'
    str_1 = is_list_like(str_0)
    str_2 = has_callables(str_0)

    dict_0: Dict[str, Any] = dict(a=1)
    dict_

# Generated at 2022-06-25 17:30:25.339512
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Notes :
    @param :
    @return:
    """
    #
    # Test cases
    #
    # Test cases for prereqs
    if has_any_callables("hello", "split", "join", "foo") is True:
        assert True
    else:
        assert False
    # Test cases for main functionality
    # check case where no args are given
    if has_any_callables("hello") is True:
        assert False
    else:
        assert True
    # check case where one arg is given
    if has_any_callables("hello", "split") is True:
        assert True
    else:
        assert False
    # check case where two args are given
    if has_any_callables("hello", "split", "join") is True:
        assert True

# Generated at 2022-06-25 17:30:28.693063
# Unit test for function has_any_callables
def test_has_any_callables():
    dict_0 = dict(a=1,b=2)
    attrs = ['popitem', 'pop']
    #Call function has_any_callables
    print(has_any_callables(dict_0, *attrs))


# has_callables tests

# Generated at 2022-06-25 17:30:35.654569
# Unit test for function has_any_callables
def test_has_any_callables():

    # Test case 3
    dict_0 = dict()
    dict_1 = dict(a=1, b=2, c=3)
    dict_2 = dict(a=[1, 2, 3], b=[4, 5, 6], c=[7, 8, 9])
    dict_3 = dict(a=dict(d=1, e=2, f=3), b=dict(g=4, h=5, i=6), c=dict(j=7, k=8, l=9))

# Generated at 2022-06-25 17:30:40.326859
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str, 'lstrip') == True
    assert has_callables(str, 'lstrip', 'capitalize', 'zfill') == True
    assert has_callables(str, 'foo', 'bar', 'baz') == False
    assert has_callables(None, 'lstrip') == False

