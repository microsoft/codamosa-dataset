

# Generated at 2022-06-25 17:20:55.869072
# Unit test for function has_callables
def test_has_callables():
    print(has_callables(dict(),'get','keys','items','values'))


# Generated at 2022-06-25 17:20:57.661918
# Unit test for function has_callables
def test_has_callables():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print("has_callables test failed.")
        assert False


# Generated at 2022-06-25 17:21:09.429190
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'foo') is True
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables(list(), 'index', 'count', 'insert', 'foo') is True
    assert has_any_callables(list(), 'index', 'foo') is True
    assert has_any_callables(list(), 'foo') is False
    assert has_any_callables(tuple(), 'index', 'count', 'foo') is True
    assert has_any_callables(tuple(), 'index', 'foo') is True
    assert has_any_callables(tuple(), 'foo') is False
    assert has_

# Generated at 2022-06-25 17:21:17.774677
# Unit test for function has_any_callables

# Generated at 2022-06-25 17:21:29.752451
# Unit test for function has_any_callables
def test_has_any_callables():
    # case 1
    int_0 = -194
    assert has_any_callables(int_0) == False
    # case 2
    dict_0 = dict(a=1, b=2, c=3)
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values') == True
    # case 3
    dict_1 = dict(a=1, b=2, c=3)
    assert has_any_callables(dict_1, 'ge', 'keys', 'items', 'values') == True
    # case 4
    dict_2 = dict(a=1, b=2, c=3)
    assert has_any_callables(dict_2, 'ge', 'keys', 'items', 'vals') == False
    # case 5
    list_0 = list

# Generated at 2022-06-25 17:21:37.127305
# Unit test for function has_any_attrs
def test_has_any_attrs():
    dict_0 = {}
    dict_1 = {'foo': 'bar'}
    list_0 = []
    list_1 = ['foo', 'bar']
    tuple_0 = ()
    tuple_1 = ('foo', 'bar')
    str_0 = ''
    str_1 = '12345'
    str_2 = 'foo'
    bytes_0 = b''
    bytes_1 = b'12345'
    bytes_2 = b'foo'
    int_0 = 0
    int_1 = 12345
    bool_0 = bool(1)
    bool_1 = bool(0)
    complex_0 = complex(0)
    complex_1 = complex(1, 1)
    float_0 = 0.0
    float_1 = .25
    float_2 = 1.25
    float

# Generated at 2022-06-25 17:21:42.846723
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(list(),'pop') == True
    assert has_callables(list(),'append') == True
    assert has_callables(list(),'POP') == False
    assert has_callables(list(),'append','something') == False
    assert has_callables(list(),'APPEND','POP') == False
    assert has_callables(list(),'append','pop') == True
    assert has_callables(list(),'append','pop','POP','APPEND') == True


# Generated at 2022-06-25 17:21:45.106868
# Unit test for function has_callables
def test_has_callables():
    func_0 = test_case_0
    from flutils.objutils import has_callables
    assert has_callables(func_0)



# Generated at 2022-06-25 17:21:55.236504
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(['a','b'], 'join', 'split', 'append') == True
    assert has_any_callables(('a','b'), 'join', 'split', 'append') == False
    assert has_any_callables({'a','b'}, 'join', 'split', 'append') == False


# Generated at 2022-06-25 17:22:07.561974
# Unit test for function has_callables
def test_has_callables():

    # tests has_callables is true when object has all provided methods
    int_0 = -194
    assert has_callables(int_0, '__add__')
    assert has_callables(int_0, '__sub__', '__floordiv__')
    assert has_callables(int_0, '__sub__', '__floordiv__', '__mod__')

    # tests has_callables is false when object does not have one of the provided methods
    assert not has_callables(int_0, '__sub__', '__floordiv__', '__mod__', '__abs__')
    assert not has_callables(int_0, '__sub__', '__floordiv__', '__mod__', '__repr__')

    # tests has_callables is false when object is not call

# Generated at 2022-06-25 17:22:25.008301
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test the function has_any_callables
    """

# Generated at 2022-06-25 17:22:28.843360
# Unit test for function has_any_callables
def test_has_any_callables():
    print('Testing has_any_callables...', end='')
    try:
        test_case_0()
    except Exception as ex:
        print('FAILED:', repr(ex))
    else:
        print('PASSED')


if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-25 17:22:33.529623
# Unit test for function has_any_callables
def test_has_any_callables():
    from random import randint
    string_0 = str(randint(1, 10))
    string_1 = str(randint(10, 20))
    string_2 = str(randint(20, 30))
    global bool_0
    bool_0 = has_any_callables(string_0, string_1, string_2, 'upper', 'lower')


# Generated at 2022-06-25 17:22:44.151885
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    from flutils.objutils import has_any_callables
    

# Generated at 2022-06-25 17:22:58.922067
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = {
        'foo': 'bar',
        'baz': 'buz',
        'boo': 'moo'
    }
    assert has_any_attrs(obj, 'foo', 'baz') is True
    assert has_any_attrs(obj, 'foo', 'ban') is True
    assert has_any_attrs(obj, 'foo', 'ban', 'baz') is True
    assert has_any_attrs(obj, 'foo', 'ban', 'raz') is False
    assert has_any_attrs(obj, 'foo', 'ban', 'raz', 'waz') is False



# Generated at 2022-06-25 17:23:07.577240
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserList
    user_list = UserList([1, 2, 3])
    assert has_any_callables(user_list, '__getitem__', '__bool__')
    assert has_any_callables(user_list, '__getitem__')
    assert has_any_callables(user_list, '__bool__')


# Generated at 2022-06-25 17:23:14.185547
# Unit test for function has_any_attrs
def test_has_any_attrs():
    int_0 = -194
    assert has_any_attrs(int_0, 'real', 'conjugate', 'imag', 'item')
    int_1 = -6
    assert not has_any_attrs(int_1, 'to_bytes', 'bit_length', 'denominator')


# Generated at 2022-06-25 17:23:18.411413
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, "keys") is True, "has_callables return False"
    assert has_callables(1, "keys") is False, "has_callables return True"
    assert has_callables([], "keys") is True, "has_callables return False"
    assert has_callables(set(), "keys") is True, "has_callables return False"
    assert has_callables(tuple(), "keys") is True, "has_callables return False"
    assert has_callables(frozenset(), "keys") is True, "has_callables return False"


if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-25 17:23:23.944737
# Unit test for function has_any_callables
def test_has_any_callables():
    # Setup
    class foo(object):
        # Create a method bar
        def bar(self):
            return self

    # Test has_any_callables
    assert has_any_callables(foo(), 'bar')
    assert has_any_callables(foo(), 'baz', 'bar')
    assert not has_any_callables(foo(), 'baz')



# Generated at 2022-06-25 17:23:29.763220
# Unit test for function has_any_callables
def test_has_any_callables():
    # Setup
    obj_0 = {'test1': 'test0', 'test4': 'test4'}

    # Exercise
    bool_0 = has_any_callables(obj_0)

    # Verify
    assert bool_0 == True



# Generated at 2022-06-25 17:23:41.320186
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # object is not a dict
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'get','keys','items','values')
    assert has_any_attrs(dict(),'keys','items','values')
    assert not has_any_attrs(dict(),'keys','items')
    assert has_any_attrs(dict(),'items','values')
    assert not has_any_attrs(dict(),'items')
    assert has_any_attrs(dict(),'values')
    assert not has_any_attrs(dict())

    # object is a dict
    assert not has_any_attrs(dict(foo=1, bar=2))

# Generated at 2022-06-25 17:23:48.482531
# Unit test for function has_any_callables
def test_has_any_callables():
    int_0 = 128
    str_0 = '128'

# Generated at 2022-06-25 17:23:51.732101
# Unit test for function has_any_callables
def test_has_any_callables():
    int_0 = 128
    bool_0 = has_any_callables(int_0)



# Generated at 2022-06-25 17:23:54.934157
# Unit test for function has_any_callables
def test_has_any_callables():
    int_0 = 128
    bool_0 = has_any_callables(int_0)


# Generated at 2022-06-25 17:24:05.150927
# Unit test for function has_callables
def test_has_callables():
    # Test case 0
    try:
        test_case_0()
    except Exception:
        assert False


if __name__ == "__main__":

    # Run unit test for function has_callables
    test_has_callables()

    # Unit test for has_attrs
    result = has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert result is True

    # Unit test for has_any_attrs
    result = has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert result is True

    # Unit test for has_callables
    result = has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert result is True

    # Unit test for has_any_callables

# Generated at 2022-06-25 17:24:08.170320
# Unit test for function has_callables
def test_has_callables():
    test_str = 'test'
    attr_str = 'join'
    assert has_callables(test_str, attr_str)


# Generated at 2022-06-25 17:24:19.897519
# Unit test for function has_any_attrs
def test_has_any_attrs():
   assert has_any_attrs(1)
   assert has_any_attrs(1,'__add__','__sub__','__mul__','__div__')
   assert has_any_attrs(1,'__mul__','__sub__','__add__','__div__')
   assert has_any_attrs(1,'__sub__','__add__','__div__','__mul__')



# Generated at 2022-06-25 17:24:35.442204
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str(), 'startswith', 'endswith', 'find', 'index')
    assert has_callables([], 'append', 'clear', 'count', 'extend')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(tuple(), 'count', 'index')
    assert has_callables(set(), 'add', 'difference', 'symmetric_difference')
    assert has_callables(frozenset(), 'copy')
    assert has_callables(deque(), 'append', 'popleft')
    assert has_callables(Iterator([]), '__next__', '__iter__')
    assert has_callables(KeysView({}), '__contains__', '__iter__')
    assert has_callables

# Generated at 2022-06-25 17:24:44.254765
# Unit test for function has_any_callables
def test_has_any_callables():
    import unittest

    class TestHasAnyCallables(unittest.TestCase):

        # Unit test for has_any_callables() of class TestHasAnyCallables
        def test_has_any_callables(self):
            import types

            def _func(self, x: int) -> int:
                return x * 2

            class _Class(object):

                def __init__(self):
                    self.a = 1
                    self.b = 2

                # noinspection PyShadowingBuiltins
                def _func(self, x: int) -> int:
                    return x * 2

                # noinspection PyShadowingBuiltins
                def _func2(self, x: int) -> int:
                    return x * 2

                def __repr__(self):
                    return 'test._Class'


# Generated at 2022-06-25 17:24:48.002798
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = object()
    a = has_any_attrs(obj, '__doc__', '__module__', '__dict__')
    assert a is True



# Generated at 2022-06-25 17:24:59.897558
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1,2,3],'append','extend','clear','add') is True
    assert has_any_callables([1,2,3],'append','extend','foo') is True
    assert has_any_callables('hello','append','extend','foo') is False
    assert has_any_callables('hello','upper','lower','split') is True
    assert has_any_callables(dict(),'get','keys','items','values') is True
    assert has_any_callables(dict(),'foo','bar','baz') is False



# Generated at 2022-06-25 17:25:03.502941
# Unit test for function has_any_callables
def test_has_any_callables():
    if has_any_callables(dict(),'get','keys','items','values','foo'):
        assert True
    else:
        assert False
        

# Generated at 2022-06-25 17:25:11.702394
# Unit test for function has_any_callables
def test_has_any_callables():
    objs = [
        object(),
        object(),
        object(),
    ]
    for o in objs:
        o.foo = lambda: True
    for o in objs:
        if not has_any_callables(o, 'foo', 'bar'):
            raise AssertionError
    for o in objs:
        del o.foo
    for o in objs:
        if has_any_callables(o, 'foo', 'bar'):
            raise AssertionError


# Generated at 2022-06-25 17:25:13.146205
# Unit test for function has_any_callables
def test_has_any_callables():
    assert True is has_any_callables(dict(), 'get', 'keys', 'values', 'items')
    assert False is has_any_callables(dict(), 'keys', 'values', 'items')



# Generated at 2022-06-25 17:25:23.486085
# Unit test for function has_any_callables
def test_has_any_callables():
    from textwrap import dedent

    from flutils.objutils import has_any_callables

    assert has_any_callables(
        {}, 'get', 'keys', 'items', 'values', 'foo'
    ) is True

    assert has_any_callables(
        {}, 'get', 'keys', 'items', 'values', 'foo', 'bar'
    ) is True

    assert has_any_callables(
        {}, 'get', 'keys', 'items', 'values', 'foo', 'bar1'
    ) is True

    assert has_any_callables(
        {}, 'get', 'keys', 'items', 'values', 'foo', 'bar1', 'bar2'
    ) is True

    assert has_any_callables({}, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-25 17:25:29.286425
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, '__setitem__') is True
    assert has_any_callables(obj, '__getitem__', '__setitem__') is True
    assert has_any_callables(obj, '__getitem__', '__setitem__', '__missing__') is True
    assert has_any_callables(obj, '__getitem__', '__setitem__', '__missing__', '__delitem__') is True
    assert has_any_callables(obj, '__setattr__', '__getattr__', '__delattr__') is True

# Generated at 2022-06-25 17:25:39.124072
# Unit test for function has_any_callables
def test_has_any_callables():

    # Tests for the following:
    #  int, bool, str, UserList, list, set, tuple, dict, None
    assert not has_any_callables(1)
    assert not has_any_callables(True)
    assert not has_any_callables("apple")
    assert has_any_callables(UserList)
    assert has_any_callables(list)
    assert has_any_callables(set)
    assert has_any_callables(tuple)
    assert has_any_callables(dict)
    assert not has_any_callables(None)


test_case_0()
test_has_any_callables()

# Generated at 2022-06-25 17:25:50.912931
# Unit test for function has_any_callables
def test_has_any_callables():

    # Check that it returns the expected result.
    list_0 = list(range(10))
    assert has_any_callables(list_0, 'sort')

    # Check that a string missing all attributes fails as expected.
    str_0 = "hello"
    assert not has_any_callables(str_0, 'sort')

    # Check that a string missing some attributes fails as expected.
    assert not has_any_callables(str_0, 'sort', 'upper')

    # Check that a string with a non-callable attribute fails as expected.
    assert not has_any_callables(str_0, 'upper', 'capitalize')



# Generated at 2022-06-25 17:26:03.894485
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'items', 'values') is True
    assert has_callables({}, 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-25 17:26:09.739210
# Unit test for function has_any_callables
def test_has_any_callables():
    int_0 = 16
    assert has_any_callables(int_0, 'bit_length') is True
    assert has_any_callables(int_0, 'get', 'pop', 'remove') is False


# Generated at 2022-06-25 17:26:18.586294
# Unit test for function has_any_callables
def test_has_any_callables():
    """ Unit tests for function has_any_callables """
    
    # Test with good args
    objs = [dict(), tuple(), set(), frozenset(), list(), deque()]
    attrs = ['__contains__', 
             '__iter__', 
             '__getitem__', 
             '__len__',
             '__reversed__']
    for obj in objs:
        assert has_any_callables(obj, *attrs)
    
    # Test with bad args
    for obj in objs:
        attrs = ['__contains__', 
                 '__iter__', 
                 '__getitem__', 
                 '__len__',
                 '__reversed__',
                 '__add__']
        assert not has_any_callables(obj, *attrs)

# Generated at 2022-06-25 17:26:22.640589
# Unit test for function has_any_callables
def test_has_any_callables():
    class Foo(object):
        pass

    foo = Foo()
    foo.bar = lambda: None
    assert not has_any_callables(Foo, 'bar', 'baz')
    assert has_any_callables(foo, 'bar', 'baz')
    assert not has_any_callables(foo, 'baz', 'qux')



# Generated at 2022-06-25 17:26:27.316930
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'bar')


# Generated at 2022-06-25 17:26:30.792191
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserList
    from flutils.objutils import has_any_callables
    obj = UserList()
    assert has_any_callables(obj, 'append', 'copy') is True


# Generated at 2022-06-25 17:26:32.573576
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-25 17:26:35.133978
# Unit test for function has_callables
def test_has_callables():
    int_0 = 128
    bool_0 = has_callables(int_0, "to_bytes", "bit_length")
    if (bool_0 == 1):
        bool_0 = 1
    else:
        bool_0 = 0
    return (bool_0)


# Generated at 2022-06-25 17:26:44.647497
# Unit test for function has_any_callables
def test_has_any_callables():

    def throw_error(obj: _Any) -> None:
        raise TypeError(
            'The given `obj` is not a list-like object and therefore'
            ' cannot be iterated over.'
        )

    class_0 = _Any
    instance_0 = _Any
    # inst_of_cls_0 = isinstance(instance_0, class_0)
    # if has_any_callables(instance_0, '__iter__', '__len__') is False:
    #     throw_error(instance_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:26:46.378042
# Unit test for function has_any_callables
def test_has_any_callables():
    assert True == has_any_callables(dict(), 'get', 'keys', 'items', 'foo')



# Generated at 2022-06-25 17:26:52.483300
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    from flutils.objutils import has_any_attrs
    from flutils.objutils import has_callables

    int_0 = 128
    assert not has_any_callables(int_0, 'to_bytes')
    assert not has_any_callables(int_0, 'to_bytes', '__bytes__')

    bool_0 = has_any_attrs(int_0)
    assert not has_any_callables(bool_0, '__bool__')
    assert not has_any_callables(bool_0, '__bool__', '__iter__')



# Generated at 2022-06-25 17:27:03.109375
# Unit test for function has_any_callables
def test_has_any_callables():
    int_0 = 128
    assert has_any_callables(int_0) is False

    class A(dict):
        def __init__(self, *args, **kwargs):
            return None

    class B(A):

        def __init__(self, *args, **kwargs):
            A.__init__(self, *args, **kwargs)

        def foo(self):
            pass

    b = B()
    assert has_any_callables(b) is True
    assert has_any_callables(b, 'foo') is True
    assert has_any_callables(b, 'foo', 'bar') is True
    assert has_any_callables(b, 'bar') is False




# Generated at 2022-06-25 17:27:19.639230
# Unit test for function has_callables
def test_has_callables():
    # Void testing
    obj_0 = dict()
    has_callables(obj_0)
    # Positive testing
    obj_0 = dict(a=1, b=2)
    has_callables(obj_0, 'get', 'items', 'keys', 'values')
    # Negative testing
    has_callables(obj_0, 'foo', 'bar', 'baz')
    has_callables(obj_0, 'get', 'foo', 'bar')

# Generated at 2022-06-25 17:27:27.271383
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables

    class TestClass:
        def __init__(self):
            self.a = 0
            self.b = ''
            self.c = []
            self.d = None

        def add_a(self, val):
            self.a += val

        def append_c(self, val):
            self.c.append(val)

    obj = TestClass()
    assert has_callables(obj, 'add_a') is True
    assert has_callables(obj, 'add_a', 'append_c') is True
    assert has_callables(obj, 'add_a', 'append_c', 'd') is True
    assert has_callables(obj, 'add_a', 'append_c', 'd') is True

# Generated at 2022-06-25 17:27:37.006063
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'values') is True
    assert has_any_callables(dict()) is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'bar') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'bar') is False
    assert has_any_callables(dict(), 'get', 'keys', 'bar') is False

# Generated at 2022-06-25 17:27:38.857055
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-25 17:27:41.845574
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is False


# Generated at 2022-06-25 17:27:47.109680
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get')
    assert has_any_callables(dict(), 'keys')
    assert has_any_callables(dict(), 'items')
    assert has_any_callables(dict(), 'values')
    assert has_any_callables(dict(), '__len__')
    #assert has_any_callables(dict(), 'something') is False


# Generated at 2022-06-25 17:27:54.935250
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys')
    assert has_any_callables(dict(), 'get')
    assert has_any_callables(dict(), 'keys', 'get')
    assert has_any_callables(dict(), 'keys', '__contains__', '__iter__')
    assert not has_any_callables(dict(), 'foo')
    assert has_any_callables(dict(), 'foo', 'bar')
    assert not has_any_callables(dict(), 'foo', 'bar', 'baz')
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', '__contains__')
    assert has_any_callables(dict(), 'foo', 'bar', 'baz', '__iter__')

# Generated at 2022-06-25 17:28:05.706168
# Unit test for function has_callables
def test_has_callables():
    """ Test has_callables() """

    class TestClass(object):
        """ Test class for testing has_callables() """

        def __init__(self):
            self.list = []
            self.tuple = ()

    def func(x : int, y : bool=True) -> None:
        """ Test function to use in testing has_callables() """
        pass

    obj = TestClass()

    result = has_callables(obj, '__init__')
    assert result is False

    result = has_callables(obj, 'list')
    assert result is True

    result = has_callables(obj, 'tuple', 'list')
    assert result is True

    result = has_callables(func, '__init__')
    assert result is False


# Generated at 2022-06-25 17:28:16.168216
# Unit test for function has_any_callables
def test_has_any_callables():
    int_0 = 128
    assert has_any_callables(int_0) == False
    dict_0 = dict(zip(range(10), range(10)))
    assert has_any_callables(dict_0, 'get', 'keys', 'items', 'values') == True
    bool_0 = has_any_callables(int_0, 'compute', 'list', 'add', 'subtract')
    assert bool_0 == False
    bool_0 = has_any_callables(dict_0, 'foo', 'bar')
    assert bool_0 == False
    bool_0 = has_any_callables(int_0, 'foo', 'bar')
    assert bool_0 == False


# Generated at 2022-06-25 17:28:19.313088
# Unit test for function has_callables
def test_has_callables():
    # Basic test passed
    num = 'a'
    assert has_callables(num)
    # Basic test failed
    num = 1
    assert not has_callables(num)

