

# Generated at 2022-06-23 18:06:22.252869
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables
    """
    from flutils.objutils import has_callables

    class MyClass(str):
        """Class for testing has_callables
        """

        def upper(self) -> str:
            """Fake upper
            """
            return self

        def lower(self) -> str:
            """Fake lower
            """
            return self

    assert has_callables(MyClass, 'upper', 'lower') is True
    assert has_callables(MyClass, 'upper', 'lower', 'casefold') is False
    assert has_callables(MyClass, 'upper', 'lower', 'casefold', 'upper') is False


# Generated at 2022-06-23 18:06:25.236870
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValueView, UserList
    assert is_subclass_of_any(dict(a=1, b=2).values(), ValueView, UserList)


import unittest

# Generated at 2022-06-23 18:06:28.598107
# Unit test for function has_attrs
def test_has_attrs():
    import collections as cl

    assert has_attrs(cl, 'deque', 'OrderedDict', 'ChainMap') is True
    assert has_attrs(cl, 'deque', 'OrderedDict', 'ChainMap', 'FooBar') is False



# Generated at 2022-06-23 18:06:30.932596
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar','baz','blah','woot') == False


# Generated at 2022-06-23 18:06:35.528951
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:06:38.976519
# Unit test for function has_any_callables
def test_has_any_callables():
    lst = [0, 1, 2, 3]
    assert (has_any_callables(lst,'append','remove','pop') == True)
    assert (has_any_callables(lst,'join','remove','pop') == False)
    assert (has_any_callables(lst, 'join') == False)



# Generated at 2022-06-23 18:06:48.314767
# Unit test for function is_list_like
def test_is_list_like():
    # noinspection PyUnresolvedReferences
    """Unit test for function is_list_like()."""
    from decimal import Decimal
    from collections import (  # noqa: F401
        UserDict,
        UserString,
        ChainMap,
        Counter,
        OrderedDict,
        defaultdict
    )

# Generated at 2022-06-23 18:06:50.709965
# Unit test for function has_callables
def test_has_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'foo') is True
    assert has_any_callables({}, 'foo') is False
    assert has_callables(dict(), 'get', 'keys') is True
    assert has_callables({}, 'foo') is False


# Generated at 2022-06-23 18:06:57.932179
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', '__getitem__') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', '__missing__') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', '__getitem__', '__missing__') is False


# Generated at 2022-06-23 18:07:09.819303
# Unit test for function has_attrs
def test_has_attrs():
    import os
    import shutil
    import sys
    import tempfile
    from contextlib import contextmanager
    from flutils import objutils
    from flutils.objutils import has_attrs

    def get_tempdir():
        """Create a temporary directory for the purpose of unit testing. The
        directory will be deleted upon context exit.

        :return:
            The path to the temporary directory
        :rtype:
            :obj:`str`
        """
        @contextmanager
        def _tempdir():
            tempdir = tempfile.mkdtemp()
            yield tempdir
            shutil.rmtree(tempdir)

        with _tempdir() as d:
            return d


# Generated at 2022-06-23 18:07:13.735961
# Unit test for function has_attrs
def test_has_attrs():
    class SomeClass(object):
        attr1 = 'some_value'
        attr2 = 'another_value'

    obj = SomeClass()
    assert has_attrs(obj, 'attr1', 'attr2') is True
    assert has_attrs(obj, 'attr1', 'attr2', 'attr3') is False
    obj.attr3 = 'a_new_attr'
    assert has_attrs(obj, 'attr1', 'attr2', 'attr3') is True



# Generated at 2022-06-23 18:07:25.981547
# Unit test for function is_list_like
def test_is_list_like():
   assert is_list_like(['a', 'b', 'c']) == True
   assert is_list_like(('a', 'b', 'c')) == True
   assert is_list_like({'a', 'b', 'c'}) == True
   assert is_list_like({'a': 1, 'b': 2, 'c': 3}) == True
   assert is_list_like(sorted('dog')) == True
   assert is_list_like(reversed('dog')) == True
   assert is_list_like(sorted({'a', 'b', 'c'})) == True
   assert is_list_like({'a': 1, 'b': 2, 'c': 3}.keys()) == True

# Generated at 2022-06-23 18:07:29.569661
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True



# Generated at 2022-06-23 18:07:36.403981
# Unit test for function has_attrs
def test_has_attrs():
    import pytest
    from datetime import datetime
    from re import Match
    from collections import ChainMap
    from collections.abc import Sequence

    class A(object):
        def __init__(self):
            self.a = 1
            self.b = 'b'
        @classmethod
        def c(cls, *args, **kwargs):
            pass

    def a(self, *args, **kwargs):
        pass

    class B(A):
        def __init__(self):
            A.__init__(self)
            self.d = 2
        @staticmethod
        def e(self, *args, **kwargs):
            pass
        f = 2

    class C(B):
        def __init__(self):
            B.__init__(self)
            self.g = 3


# Generated at 2022-06-23 18:07:38.988495
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')



# Generated at 2022-06-23 18:07:49.352585
# Unit test for function is_list_like
def test_is_list_like():
    import operator
    import typing

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(dict(a=1, b=2).keys()) is True
    assert is_list_like(dict(a=1, b=2).values()) is True
    assert is_list_like(dict(a=1, b=2).items()) is True

# Generated at 2022-06-23 18:07:57.566196
# Unit test for function has_attrs
def test_has_attrs():
    class Foo():
        def bar(self):
            pass

    class FooBar(Foo):
        def bar(self):
            pass

    assert has_attrs(Foo(), "bar") == True
    assert has_attrs(FooBar(), "bar") == True
    assert has_attrs(Foo(), "bar", "baz") == False
    assert has_attrs(FooBar(), "bar", "baz") == False
    assert has_attrs(FooBar(), "bar", "baz", "baz") == False



# Generated at 2022-06-23 18:08:04.558799
# Unit test for function is_list_like
def test_is_list_like():
    """ Unit test for flutils.objutils.is_list_like """
    # List-like
    assert is_list_like(list())
    assert is_list_like(tuple())
    assert is_list_like(dict())
    assert is_list_like(dict().keys())
    assert is_list_like(dict().values())
    assert is_list_like(dict().items())
    assert is_list_like(reversed(str()))
    assert is_list_like(sorted(str()))
    # ! List-like
    assert not is_list_like(None)
    assert not is_list_like(bool())
    assert not is_list_like(bytes())
    assert not is_list_like(dict().get)
    assert not is_list_like(dict().pop)


# Generated at 2022-06-23 18:08:10.034691
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    from collections import UserDict

    class FooDict(UserDict):
        def get(self, key: Any) -> Any:
            return self.data.get(key)

    assert has_attrs(dict(), 'get') is True
    assert has_attrs(FooDict(), 'get') is True
    assert has_attrs(FooDict(), 'get', 'keys') is True
    assert has_attrs(FooDict(), 'get', 'does_not_exist') is False



# Generated at 2022-06-23 18:08:22.804565
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test to ensure correct return values when using function
    ``has_any_callables``.

    The tests MUST pass.
    """
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') \
        is True
    assert has_any_callables(
        dict(), 'get', 'keys', 'items', 'values', 'something'
    ) is True
    assert has_any_callables({}, 'get', 'keys', 'items', 'values', 'foo') \
        is True
    assert has_any_callables({}, 'get', 'keys', 'items', 'values', 'something') \
        is True
    assert has_any_callables({'a': 1}, 'get', 'keys', 'items', 'values', 'foo') \
        is True

# Generated at 2022-06-23 18:08:28.743120
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like.
    """
    import decimal
    import collections
    from flutils.objutils import is_list_like
    from flutils.objutils import has_callables
    import sys
    # Check several types of objects that should be list-like
    if is_list_like([]) is False:
        sys.stderr.write('Empty list is not list-like\n')
    if is_list_like(['a', 'b', 'c']) is False:
        sys.stderr.write('List is not list-like\n')
    if is_list_like(tuple()) is False:
        sys.stderr.write('Empty tuple is not list-like\n')

# Generated at 2022-06-23 18:08:35.566635
# Unit test for function has_any_callables
def test_has_any_callables():

    from flutils.objutils import (
        has_any_callables,
    )

    assert has_any_callables(dict(),'get','keys','items','values','item') is True
    assert has_any_callables(dict(),'values','item','foo') is True
    assert has_any_callables(dict(),'foo','bar','baz') is False


# Generated at 2022-06-23 18:08:44.537194
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'asd', 'asdf', 'asdfg', 'asdfgh', 'asdfghj') is False
    assert has_any_attrs(int(), 'bit_length', 'conjugate', 'denominator', 'from_bytes', 'imag') is True
    assert has_any_attrs(int(), 'asd', 'asdf', 'asdfg', 'asdfgh', 'asdfghj') is False


# Generated at 2022-06-23 18:08:47.989477
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:08:49.761010
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-23 18:08:57.299037
# Unit test for function has_callables
def test_has_callables():
    import inspect
    from flutils.objutils import has_callables
    assert has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
    )
    assert has_callables(
        inspect.stack(),
        'append',
        'clear',
        'extend',
        'insert',
        'pop',
        'remove',
        'reverse',
        'sort',
    ) is False
    assert has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
    ) is True

# Generated at 2022-06-23 18:09:02.838639
# Unit test for function has_any_callables
def test_has_any_callables():
    # given
    o = dict(a=1, b=2, c=3)
    # when
    result = has_any_callables(o, 'get', 'keys', 'items', 'values', 'foo')
    # then
    assert result is True



# Generated at 2022-06-23 18:09:09.072821
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from pprint import pprint
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.values(), ValuesView)
    assert is_subclass_of_any(obj.keys(), KeysView)
    # pprint(is_subclass_of_any(obj, ValuesView, KeysView))
    # pprint(is_subclass_of_any(obj.items(), ValuesView, KeysView, UserList))



# Generated at 2022-06-23 18:09:17.080940
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from unittest import TestCase
    from flutils.objutils import has_any_attrs

    class MyClass(object):
        def __init__(self):
            self.name = 'foo'

    class MySubClass(MyClass):
        def __init__(self):
            super().__init__()
            self.sub_name = 'bar'

    class MySubClass2(MySubClass):
        def __init__(self):
            super().__init__()
            self.sub_name2 = 'baz'


# Generated at 2022-06-23 18:09:24.004323
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from io import BytesIO

    assert has_any_attrs({}, 'keys', 'items', 'values') is True
    assert has_any_attrs({}, 'keys', 'items', 'values', 'some_other_thing') \
        is True
    assert has_any_attrs({}, 'keys', 'items', 'values', 'read') is False
    assert has_any_attrs(BytesIO(b''), 'keys', 'items', 'values', 'read') \
        is True



# Generated at 2022-06-23 18:09:34.776197
# Unit test for function has_any_callables
def test_has_any_callables():
    u = dict(a=1)
    assert has_any_callables(u, 'get') == True
    assert has_any_callables(u, 'keys', 'get') == True
    assert has_any_callables(u, 'items', 'get') == True
    assert has_any_callables(u, 'values', 'get') == True
    assert has_any_callables(u, 'foo', 'get') == False
    assert has_any_callables(u, 'keys', 'items', 'values') == True
    assert has_any_callables(u, 'keys', 'foo', 'items', 'values') == True
    assert has_any_callables(u, 'keys', 'foo', 'bar') == False


# Generated at 2022-06-23 18:09:36.918482
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert (has_any_attrs(dict(),'get','keys','items','values','something'))


# Generated at 2022-06-23 18:09:39.607706
# Unit test for function has_attrs
def test_has_attrs():
    assert(has_attrs(dict(), 'get', 'keys', 'items', 'values'))


# Generated at 2022-06-23 18:09:47.349921
# Unit test for function has_attrs
def test_has_attrs():
    # Test that returns True when all the given attrs exist on the given obj.
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict([('a', 1), ('b', 2)]), 'get', 'keys', 'items', 'values') is True

    # Test that returns False when not all the given attrs exist
    # on the given obj.
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_attrs(dict([('a', 1), ('b', 2)]), 'get', 'keys', 'items', 'values', 'something') is False



# Generated at 2022-06-23 18:09:51.016365
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test function is_subclass_of_any."""
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    print(is_subclass_of_any(obj, ValuesView, KeysView, UserList))
    print(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList))



# Generated at 2022-06-23 18:09:53.734719
# Unit test for function has_callables
def test_has_callables():
    """Unit test for ``has_callables()``."""
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:09:55.747843
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','keys','items','value') is False
    assert has_attrs(dict(),'get','foo','items','values') is False
    # Unit test for function has_callables

# Generated at 2022-06-23 18:09:59.286738
# Unit test for function has_any_callables
def test_has_any_callables():
    assert not has_any_callables('hello', 'upper', 'lower')
    assert has_any_callables(set(), '__len__', '__iter__')
    assert has_any_callables(dict(), '__len__', 'keys')


# Generated at 2022-06-23 18:10:10.758868
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'items', 'values', 'keys', 'get') is True
    assert has_callables(obj, 'items', 'values', 'keys') is True
    assert has_callables(obj, 'foo', 'bar') is False
    assert has_callables(obj, 'keys', 'items') is True
    assert has_callables(obj, 'values', 'keys') is True
    assert has_callables(obj, 'values', 'keys', 'foo') is False
    assert has_callables(obj, 'values', 'keys', 'foo', 'bar') is False
    assert has_callables(obj, 'values', 'keys', 'get', 'foo', 'bar') is False

# Generated at 2022-06-23 18:10:14.787627
# Unit test for function has_callables
def test_has_callables():
    d = dict()
    b = has_callables(d,'get')
    assert(b==True)
    c = has_callables(d,'goose')
    assert(c==False)


# Generated at 2022-06-23 18:10:25.469792
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar') is False
    assert has_any_callables(set(), 'add', 'clear', 'bar') is True
    assert has_any_callables(set(), 'foo', 'bar') is False
    assert has_any_callables(list(), 'pop', 'remove', 'bar') is True
    assert has_any_callables(list(), 'foo', 'bar') is False
    assert has_any_callables(tuple(), 'foo', 'bar') is False
    assert has_any_callables(UserList(), 'foo', 'bar') is False
    assert has_any_callables(frozenset(), 'foo', 'bar') is False

# Generated at 2022-06-23 18:10:27.421171
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True)

# Generated at 2022-06-23 18:10:38.006160
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(b'this is bytes') is False
    assert is_list_like(1) is False
    assert is_list_like(1.5) is False
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True

# Generated at 2022-06-23 18:10:40.231149
# Unit test for function has_any_attrs
def test_has_any_attrs():
    dct = dict(a=1, b=2)
    assert has_any_attrs(dct, 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-23 18:10:51.607077
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(dict(), object) is False
    assert is_subclass_of_any(dict(), list) is False
    assert is_subclass_of_any(dict(), ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(dict().keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(dict().values(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(UserList(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(KeysView(dict().values()), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:10:53.708776
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-23 18:10:59.404995
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'bar', 'baz', 'qux') is False
    assert has_attrs([1, 2, 3], 'get', 'keys', 'items', 'values') is False
    return True



# Generated at 2022-06-23 18:11:03.379749
# Unit test for function has_attrs
def test_has_attrs():
    """
    >>> from flutils.objutils import has_attrs
    >>> has_attrs(dict(),'get','keys')
    True
    >>> has_attrs(dict(),'get','keys','something')
    False
    """
    pass



# Generated at 2022-06-23 18:11:08.530271
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert is_list_like('hello') is False
    assert is_list_like(('a', 'b', 'c')) is True
    assert is_list_like(range(0, 10, 2)) is True
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(reversed('hello')) is True

# Generated at 2022-06-23 18:11:11.446176
# Unit test for function has_any_attrs
def test_has_any_attrs():
    attrs = ('get', 'items', 'foo', 'bar')
    obj = dict(a=1, b=2)
    result = has_any_attrs(obj, *attrs)
    assert result == True


# Generated at 2022-06-23 18:11:19.513002
# Unit test for function has_callables
def test_has_callables():
    if not has_callables(dict(),'get','keys','items','values'):
        print('dict does not have all 4 callable functions')

    if not has_callables(dict, 'fromkeys'):
        print('dict class does not have fromkeys callable function')

    if has_callables(dict,'makekeys'):
        print('dict class has makekeys callable function')

    if has_callables(dict(),'makekeys'):
        print('dict has makekeys callable function')


# Generated at 2022-06-23 18:11:21.097705
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-23 18:11:21.868258
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_lik

# Generated at 2022-06-23 18:11:28.760403
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items') is False
    assert has_callables(dict(), 'get', 'keys') is False
    assert has_callables(dict(), 'get') is False
    assert has_callables(dict(), 'foo') is False



# Generated at 2022-06-23 18:11:39.880234
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # has_any_attrs will return true if the obj has any of the specified attributes
    # otherwise will return false
    assert has_any_attrs(dict(), 'get', 'keys', 'values') == True
    assert has_any_attrs(dict(), 'get', 'keys', 'values', 'items') == True
    assert has_any_attrs(dict(), 'get', 'keys', 'values', 'pop') == True
    assert has_any_attrs(dict(), '__subclasshook__', 'keys', 'values') == True
    assert has_any_attrs(dict(), '__subclasshook__', 'keys') == True
    assert has_any_attrs(dict(), '__subclasshook__') == True
    assert has_any_attrs(dict(), 'subclasshook__') == False
    assert has_

# Generated at 2022-06-23 18:11:43.790746
# Unit test for function has_attrs
def test_has_attrs():
    class A:
        def __init__(self):
            self.a = None
            self.b = None

    class B(A):
        def __init__(self):
            super().__init__()
            self.c = None

    obj = B()
    print(has_attrs(obj, 'c', 'b', 'a'))


# Generated at 2022-06-23 18:11:52.420471
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # test primitive classes
    assert has_any_attrs(None, '__bool__') is False
    assert has_any_attrs(False, '__bool__') is True
    assert has_any_attrs(True, '__bool__') is True
    assert has_any_attrs(0, '__bool__') is False
    assert has_any_attrs(1, '__bool__') is False
    assert has_any_attrs(0.0, '__bool__') is False
    assert has_any_attrs(1.0, '__bool__') is False
    assert has_any_attrs(0j, '__bool__') is False
    assert has_any_attrs(1j, '__bool__') is False

# Generated at 2022-06-23 18:11:59.573945
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList,
        UserDict,
    )
    class ListFromUserDict(UserDict):
        def __getitem__(self, item):
            return [x for x in super().__getitem__(item)]

    h = ListFromUserDict({"a":1, "b":2, "c":3, "d":4, "e":5})
    assert is_subclass_of_any(["a"], ValuesView, KeysView, UserList) == False
    assert is_subclass_of_any(h.keys(), ValuesView, KeysView, UserList) == True

# Generated at 2022-06-23 18:12:02.916045
# Unit test for function has_callables
def test_has_callables():
    obj = dict(foo='bar')
    assert has_callables(obj, 'get', 'keys') == True
    assert has_callables(obj, 'foo', 'keys') == False


# Generated at 2022-06-23 18:12:14.031235
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(dict()) is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False
    assert is_list_like(UserDict()) is False
    assert is_list_

# Generated at 2022-06-23 18:12:21.002424
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list(range(5))) == True
    assert is_list_like(reversed(list(range(5)))) == True
    assert is_list_like(tuple(range(5))) == True
    assert is_list_like(deque(range(5))) == True
    assert is_list_like(set(range(5))) == True
    assert is_list_like(frozenset(range(5))) == True
    assert is_list_like(dict(range(5))) == False
    assert is_list_like(str()) == False
    assert is_list_like(int()) == False


# Generated at 2022-06-23 18:12:29.796317
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import UserList, UserDict, UserString, ValuesView, KeysView
    assert is_subclass_of_any(UserList, UserList) is True
    assert is_subclass_of_any(UserDict, UserDict) is True
    assert is_subclass_of_any(UserString, UserString) is True
    assert is_subclass_of_any(KeysView, KeysView) is True
    assert is_subclass_of_any(ValuesView, ValuesView) is True
    assert is_subclass_of_any(ValuesView, KeysView) is False
    assert is_subclass_of_any(dict(a=1,b=2).keys(),ValuesView,KeysView,UserList) is True

# Generated at 2022-06-23 18:12:33.285033
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'get','keys','items','values')


# Generated at 2022-06-23 18:12:45.656940
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for the function is_list_like."""
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False
    assert is_list_like(UserDict()) is False
    assert is_list_like(UserString("hello")) is False
    assert is_list_like(defaultdict(lambda: None)) is False
    assert is_list_like(Decimal("1")) is False
    assert is_list_like({}) is False
    assert is_list_like("hello") is False
    assert is_list_like(set("hello")) is True
    assert is_list_like(frozenset("hello")) is True
    assert is_list_like([1, 2, 3]) is True
   

# Generated at 2022-06-23 18:12:49.775791
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'items') is True
    assert has_callables(obj, 'a', 'b') is False



# Generated at 2022-06-23 18:12:54.055162
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys') == True
    assert has_callables(list(),'get','keys') == False
    assert has_callables('', 'get', 'keys') == False
    assert has_callables(0, 'get', 'keys') == False
    assert has_callables(None, 'get', 'keys') == False


# Generated at 2022-06-23 18:12:59.399206
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

is_subclass_of_any.__test__ = False

# Generated at 2022-06-23 18:13:11.534444
# Unit test for function has_callables
def test_has_callables():
    assert not has_callables('', 'isalnum')
    assert has_callables('', 'upper', 'isupper')
    assert not has_callables('', 'upper', 'isalnum')
    assert not has_callables('', 'upper', 'foo')
    assert not has_callables(dict(), 'upper', 'foo')
    assert not has_callables(dict(), 'foo')
    assert has_callables(dict(), 'get', 'foo')
    assert has_callables(dict(), 'get', 'foo', 'keys')
    assert not has_callables(dict(), 'foo', 'keys')
    assert not has_callables(dict(), 'foo', 'keys', 'bar')
    assert has_callables(dict(), 'keys', 'items', 'values', 'bar')

# Generated at 2022-06-23 18:13:13.398040
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True



# Generated at 2022-06-23 18:13:18.209932
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True



# Generated at 2022-06-23 18:13:26.713468
# Unit test for function has_attrs
def test_has_attrs():
    """Test function has_attrs.
    """
    from flutils.objutils import has_attrs

    assert has_attrs({}, 'get') is True
    assert has_attrs({}, 'keys') is True
    assert has_attrs({}, 'items') is True
    assert has_attrs({}, 'values') is True
    assert has_attrs({}, 'foo') is False
    assert has_attrs({}, 'get', 'keys', 'items', 'values') is True
    assert has_attrs({}, 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-23 18:13:39.189802
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert is_list_like([]) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(set()) is True
    assert is_list_like(dict()) is False
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(123) is False
    assert is_list_like(1.23) is False
    assert is_list_like(b'hello') is False
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True

# Generated at 2022-06-23 18:13:41.709127
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    d = dict(a=1)
    assert has_callables(d, 'keys', 'items')



# Generated at 2022-06-23 18:13:45.976893
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:13:47.772597
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')


if __name__ == "__main__":
    print(__doc__)

# Generated at 2022-06-23 18:13:51.674180
# Unit test for function has_callables
def test_has_callables():
    test_cases = [
        {
            'input': (dict(), 'get', 'keys', 'items', 'values'),
            'output': True,
        },
        {
            'input': (dict(), 'get', 'keys', 'items', 'foo'),
            'output': False,
        },
    ]
    for t in test_cases:
        assert has_callables(*t['input']) == t['output']



# Generated at 2022-06-23 18:13:54.940120
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj,'keys','items')


# Generated at 2022-06-23 18:14:03.118339
# Unit test for function is_list_like
def test_is_list_like():
    # Standard use case
    assert is_list_like(['hello']) is True
    # Standard use case (other object)
    assert is_list_like(reversed('hello')) is True
    # Standard use case (False)
    assert is_list_like('hello') is False
    # Standard use case (True)
    assert is_list_like(sorted('hello')) is True
    # Standard use case (True)
    assert is_list_like(['hello', 'there']) is True

# Generated at 2022-06-23 18:14:04.848321
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') == True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') == True



# Generated at 2022-06-23 18:14:07.966719
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    attrs = 'get', 'keys', 'items', 'values'
    assert has_attrs(obj, *attrs) is True


# Generated at 2022-06-23 18:14:13.505584
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values','foo','bar','baz')
    assert has_any_callables(dict(),'foo','bar','baz') is False
    assert has_any_callables(dict(),'get','keys','items','values') is False


# Generated at 2022-06-23 18:14:16.151363
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-23 18:14:26.922805
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo') is False
    assert has_any_attrs('foo', 'upper') is True
    assert has_any_attrs('foo', 'upper', 'lower', 'capitalize') is True
    # test None
    assert has_any_attrs(None, 'foo') is False
    # test bool
    assert has_any_attrs(True, 'foo') is False
    assert has_any_attrs(False, 'foo') is False


# Generated at 2022-06-23 18:14:30.397809
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Unit test for function is_subclass_of_any."""
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList))


# Generated at 2022-06-23 18:14:41.540065
# Unit test for function is_list_like
def test_is_list_like():

    import datetime
    import operator
    import random
    import requests
    import string
    import types

    from collections import (
        ChainMap,
        Counter,
        namedtuple,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import (
        Collection,
    )
    from decimal import (
        Decimal,
    )
    from importlib import resources
    from io import (
        TextIOBase,
    )
    from typing import (
        Mapping,
        Iterable,
        Iterator,
        Generator,
        Sized,
        Sequence,
    )

    from flutils.objutils import (
        is_list_like,
    )
    from pytest import raises


# Generated at 2022-06-23 18:14:45.299127
# Unit test for function has_attrs
def test_has_attrs():
    prop1 = "get"
    prop2 = "something"
    prop3 = "something else"
    mydict = dict(test=1)
    assert has_attrs(mydict,prop1,prop2) == True
    assert has_attrs(mydict,prop1,prop3) == False
    assert has_attrs(mydict,prop2,prop3) == False

# Generated at 2022-06-23 18:14:48.000438
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-23 18:14:50.808078
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(dict(a=1, b=2).keys(), ValuesView, KeysView, UserList) == True



# Generated at 2022-06-23 18:14:55.432101
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2, c=3)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') == True
    assert has_attrs(obj, 'foo', 'bar') == False
    assert has_attrs(obj, 'foo', 'bar', 'get', 'keys', 'items', 'values') == False


# Generated at 2022-06-23 18:14:58.753458
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    obj = dict(a=1)
    for cls in (obj.keys, obj.values, obj.items):
        assert has_callables(obj,cls) is True

# Generated at 2022-06-23 18:15:01.855598
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-23 18:15:04.408131
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-23 18:15:11.908501
# Unit test for function has_callables
def test_has_callables():
    obj = {'get': lambda: 'foo', 'keys': lambda: 'bar'}
    # A lambda function can be called
    assert has_callables(obj, 'get') == True
    # Attribute does not exist
    assert has_callables(obj, 'foo') == False
    # Attribute is not a callable
    obj = {'bar': 'baz'}
    assert has_callables(obj, 'bar') == False

# Generated at 2022-06-23 18:15:15.356912
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-23 18:15:18.014745
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    # GIVEN
    obj = dict(a=1, b=2)

    # WHEN
    result = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

    # THEN
    assert result is True


# Generated at 2022-06-23 18:15:25.129252
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(int,'denominator','imag','numerator','real') == True
    assert has_callables(dict(),'get','keys','items','foo') == False
    assert has_callables(int, 'foo', 'bar') == False
    assert has_callables(list()) == False

if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-23 18:15:32.005667
# Unit test for function is_list_like
def test_is_list_like():
    def test(obj):
        print(obj, is_list_like(obj))

    from collections import ChainMap, Counter, OrderedDict
    from collections.abc import Mapping
    from collections.abc import MutableMapping
    test(['a', 'b'])
    test([1, 2, 3])
    test(deque('hello'))
    test(dict(a=1, b=2))
    test(frozenset('hello'))
    test(reversed([1, 2, 4]))
    test(set((1, 2, 3)))
    test(sorted('hello'))
    test(tuple([1, 2, 3]))

    test(None)
    test(False)
    test(True)
    test(1)
    test(0)
    test('hello')


# Generated at 2022-06-23 18:15:42.373762
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap, Counter, OrderedDict, UserDict, UserString, defaultdict
    from decimal import Decimal
    from flutils.objutils import is_list_like
    import math

    def ex1():
        """List-like objects are instances of:

            - UserList
            - Iterator
            - KeysView
            - ValuesView
            - deque
            - frozenset
            - list
            - set
            - tuple

        List-like objects are **NOT** instances of:

            - None
            - bool
            - bytes
            - ChainMap
            - Counter
            - OrderedDict
            - UserDict
            - UserString
            - defaultdict
            - Decimal
            - dict
            - float
            - int
            - str
            - etc...
        """

# Generated at 2022-06-23 18:15:51.046515
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import ChainMap

    obj = ChainMap()
    for attr in ('__len__', '__bool__', '__contains__', '__iter__', 'get'):
        result = has_any_attrs(obj, attr)
        assert callable(result) is False
        assert result is False

    for attr in ('__len__', '__bool__', '__contains__', '__iter__', 'get'):
        result = has_any_attrs(obj, '__bool__', attr)
        assert callable(result) is False
        assert result is True

    result = has_any_attrs(obj, '__len__', '__bool__', '__contains__',
                           '__iter__', 'get')
    assert callable(result) is False

# Generated at 2022-06-23 18:15:59.927684
# Unit test for function is_list_like
def test_is_list_like():
    obj = dict(a=1, b=2)
    assert is_list_like(obj.values()) is True
    assert is_list_like(obj.keys()) is True
    assert is_list_like(reversed(obj.keys())) is True
    assert is_list_like(reversed(obj)) is True
    assert is_list_like(sorted(obj.values())) is True
    assert is_list_like(sorted(obj.keys())) is True
    assert is_list_like(tuple(obj)) is True
    assert is_list_like(tuple(obj.keys())) is True
    assert is_list_like(tuple(obj.values())) is True
    assert is_list_like(set(obj)) is True

# Generated at 2022-06-23 18:16:04.129497
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_callables(dict(), 'get', 'keys')
    assert has_any_callables(dict(), 'get')
    assert not has_any_callables(dict(), 'foo')
    assert not has_any_callables(dict())



# Generated at 2022-06-23 18:16:15.575795
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like('ab') == True
    assert is_list_like([1,2]) == True
    assert is_list_like({1,2}) == True
    assert is_list_like((1,2)) == True
    assert is_list_like({'a':1}) == True
    assert is_list_like(1) == False
    assert is_list_like(reversed([1,2,3])) == True
    assert is_list_like(None) == False
    assert is_list_like(True) == False
    assert is_list_like(False) == False
    assert is_list_like(1.0) == False
    assert is_list_like(1) == False
    assert is_list_like(sorted([1,2])) == True
    assert is_