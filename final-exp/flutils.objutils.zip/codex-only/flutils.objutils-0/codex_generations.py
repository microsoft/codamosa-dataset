

# Generated at 2022-06-23 18:06:10.977547
# Unit test for function has_any_attrs
def test_has_any_attrs():
    get_list = has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert get_list is True


# Generated at 2022-06-23 18:06:13.073140
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True


# Generated at 2022-06-23 18:06:24.761524
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )

    from typing import (  # noqa: F401
        Any,
    )

    import decimal

    types = [
        None,
        bool,
        bytes,
        ChainMap,
        Counter,
        decimal.Decimal,
        deque,
        dict,
        float,
        frozenset,
        int,
        list,
        object,
        OrderedDict,
        set,
        str,
        tuple,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    ]


# Generated at 2022-06-23 18:06:34.042701
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function ``has_any_callables``."""
    from flutils.objutils import has_any_callables
    from flutils.objutils import has_any_attrs
    assert has_any_attrs(dict(),'get','keys','items','values','foo') is True
    assert has_any_attrs(dict(),'geta','keys','items','values','foo') is False
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert \
        has_any_callables(dict(),'get','keys','items','values','something') is False
    assert has_any_callables(object(),'get','keys','items','values','foo') is False



# Generated at 2022-06-23 18:06:35.579701
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs([], 'sort', 'slice', '__getattribute__')



# Generated at 2022-06-23 18:06:37.930549
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True

# Generated at 2022-06-23 18:06:47.570443
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import (
        UserList,
        UserDict,
        UserString,
    )
    assert has_callables(dict(), 'get', 'values', 'items', 'foo') is True
    assert has_callables({'foo': 'bar'}, 'get', 'values', 'items', 'foo') is True
    assert has_callables({'foo': 'bar'}, 'get', 'values', 'items', 'foo') is True
    assert has_callables(set(), 'add', 'remove', 'foo') is True
    assert has_callables(list(), 'append', 'remove', 'foo') is True
    assert has_callables(tuple(), 'append', 'remove', 'foo') is False

# Generated at 2022-06-23 18:06:53.082402
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list())
    assert is_list_like([])
    assert is_list_like(set())
    assert is_list_like(frozenset())
    assert is_list_like(tuple())
    assert is_list_like(deque())
    assert is_list_like(Iterator)
    assert is_list_like(ValuesView)
    assert is_list_like(KeysView)
    assert is_list_like(UserList)
    assert is_list_like("hello") == False
    assert is_list_like("hello".__iter__())
    assert is_list_like("hello".__reversed__())
    assert is_list_like(reversed("hello"))
    assert is_list_like(dict()) == False

# Generated at 2022-06-23 18:06:59.055162
# Unit test for function has_attrs
def test_has_attrs():
    """Function has_attrs tests to make sure all the attributes are present in the object.

    :rtype:
        :obj:`bool`

        * :obj:`True` if all the given ``*attrs`` exist on the given ``obj``;
        * :obj:`False` otherwise.

        Examples:
        >>> from flutils.objutils import has_attrs
        >>> has_attrs(dict(),'get','keys','items','values')
        True
    """
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:07:04.975939
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables"""
    class TestClass(object):
        """Test Class"""
        def __init__(self):
            """TestClass init"""
            pass

        def foo(self):
            """foo"""
            pass

    tester = TestClass()
    assert has_callables(tester, 'foo') is True
    assert has_callables(tester, 'bar') is False


# Generated at 2022-06-23 18:07:11.327675
# Unit test for function has_any_callables
def test_has_any_callables():
    # The following tests should pass
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'keys')
    # The following tests should not pass
    assert has_any_callables(dict(),'foo') is False


# Generated at 2022-06-23 18:07:13.423376
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView
    assert is_subclass_of_any(dict().values(), ValuesView), 'Instance of ValuesView should return True'

# Generated at 2022-06-23 18:07:17.128106
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','pop')
    assert has_callables((1,2,3,'value'),'index','count')
    assert has_callables(list(),'append','insert')
    assert has_callables(set(),'add','clear')
    assert has_callables({'a':1,'b':2}, 'items','keys','values')
    assert has_callables(list(), 'append', 'insert')
    assert has_callables(int(), 'bit_length')
    assert has_callables(float(), 'is_integer')
    assert has_callables(tuple(), 'count', 'index')
    assert has_callables(str(), 'ljust', 'lstrip')


# Generated at 2022-06-23 18:07:25.929249
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(dict.__class__, dict) is True
    assert is_subclass_of_any(dict, dict.__class__) is False
    assert is_subclass_of_any(set.__class__, dict) is False
    assert is_subclass_of_any(tuple.__class__, dict) is False
    assert is_subclass_of_any(int.__class__, dict) is False
    assert is_subclass_of_any(3, dict) is False

# Generated at 2022-06-23 18:07:29.066795
# Unit test for function has_callables
def test_has_callables():
    test_obj = dict(a=1, b=2)
    if has_callables(test_obj, "values", "items"):
        print("Values and Items are callable")

# Test the above function.
test_has_callables()

# Generated at 2022-06-23 18:07:31.085715
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-23 18:07:34.288250
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView

    obj = dict(a=1, b=2)
    assert isinstance(obj.keys(), ValuesView)
    assert is_subclass_of_any(obj.keys(), ValuesView)



# Generated at 2022-06-23 18:07:39.041375
# Unit test for function has_any_attrs
def test_has_any_attrs():
    try:
        assert has_any_attrs(dict(),'get','keys','items','values','foo') == True
    except AssertionError:
        print("Function has_any_attrs failed")

# Generated at 2022-06-23 18:07:39.926460
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('foo','upper','lower','title','capitalize') is True


# Generated at 2022-06-23 18:07:45.579359
# Unit test for function has_attrs
def test_has_attrs():
    for obj in [dict(), Counter(), OrderedDict(), defaultdict(list), dict]:
        if has_attrs(obj, 'get', 'keys', 'items', 'values') is False:
            raise AssertionError
    if has_attrs(dict(), 'foo', 'bar', 'foobar') is True:
        raise AssertionError



# Generated at 2022-06-23 18:07:50.346775
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'update') is False



# Generated at 2022-06-23 18:07:55.193011
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserDict
    assert has_any_callables(dict(), 'get',
                             'keys', 'items', 'values', 'something') is True
    assert has_any_callables(UserDict(), 'get',
                             'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-23 18:07:59.896809
# Unit test for function has_callables
def test_has_callables():
    dict1 = dict(a=1, b=2)
    dict2 = dict(a=1, b=2, c=3)
    dict1['d'] = dict2
    assert has_callables(dict1, 'get', 'keys', 'items', 'values')
    assert not has_callables(dict2, 'g1et', '1keys', 'items', 'values')



# Generated at 2022-06-23 18:08:11.923965
# Unit test for function has_callables
def test_has_callables():
    """Check that function has_callables() works appropriately.

    Args:
        None

    Returns:
        None

    Function Coverage:
        has_callables

    Examples:
        >>> test_has_callables()
        True
    """
    # Ignore the following pylint warning
    # pylint: disable=no-member
    if has_callables(dict(), 'get', 'keys', 'values', 'items') is False:
        return False
    if has_callables(dict(), 'get', 'keys', 'values', 'items', 'something') is False:
        return False
    if has_callables(int, 'real', 'imag') is False:
        return False
    if has_callables(int, 'real', 'imag', 'something') is False:
        return False

# Generated at 2022-06-23 18:08:24.860277
# Unit test for function has_any_callables
def test_has_any_callables():
    from decimal import Decimal
    from flutils.calcutils import isfloat
    from flutils.objutils import (
        has_any_callables,
        has_callables,
        has_attrs,
    )

    obj = Decimal(0.5)
    assert hasattr(obj, '__call__') is False
    assert has_any_callables(obj, '__call__') is False
    assert has_callables(obj, '__call__') is False
    assert has_attrs(obj, '__call__') is True

    obj = isfloat()
    assert hasattr(obj, '__call__') is True
    assert has_any_callables(obj, '__call__') is True
    assert has_callables(obj, '__call__') is True

# Generated at 2022-06-23 18:08:30.055309
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(1, int, str)
    assert is_subclass_of_any(1, float, type(None))

    assert is_subclass_of_any('1', int, str)
    assert is_subclass_of_any('1', float, type(None))

    assert is_subclass_of_any(dict(), dict)
    assert is_subclass_of_any(dict(), UserList, list)
    assert not is_subclass_of_any(dict(), UserString, list)

# Generated at 2022-06-23 18:08:42.501850
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like"""

    from collections import UserList, UserDict
    from flutils.objutils import is_list_like

    instances_true = [
        list(),
        deque(),
        tuple(),
        frozenset(),
        set(),
        'hello',
        b'bytes',
        reversed('hello'),
        sorted(list()),
        UserList(),
        UserDict(),
    ]

    instances_false = [
        None,
        0,
        1,
        0.0,
        True,
        False,
        float(),
        float('nan'),
        float('inf'),
        float('-inf'),
        dict(),
        set(),
        frozenset(),
        UserDict(),
    ]

    for instance in instances_true:
        assert is_list

# Generated at 2022-06-23 18:08:49.878496
# Unit test for function has_callables
def test_has_callables():
    obj = {}
    assert has_callables(obj, 'get')
    assert has_callables(obj, 'get', 'keys')
    assert has_callables(obj, 'get', 'keys', 'items')
    assert has_callables(obj, 'get', 'keys', 'items', 'values')

    obj = dict()
    assert has_callables(obj, 'get')
    assert has_callables(obj, 'get', 'keys')
    assert has_callables(obj, 'get', 'keys', 'items')
    assert has_callables(obj, 'get', 'keys', 'items', 'values')

    obj = {'a': 1, 'b': 2, 'c': 3}
    assert has_callables(obj, 'get')
    assert has_callables(obj, 'get', 'keys')

# Generated at 2022-06-23 18:08:54.599226
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj1 = dict(a=1, b=2)
    assert is_subclass_of_any(obj1.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-23 18:08:56.703877
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-23 18:09:01.741066
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'keys', 'items', 'values') is True
    assert has_attrs('', 'lower', 'upper') is True
    assert has_attrs(dict(a=1, b=2), 'foo', 'bar', 'baz') is False
    assert has_attrs('', 'lower', 'upper', 'foo') is False
    assert has_attrs(dict(), 'keys', 'values', 'foo') is False



# Generated at 2022-06-23 18:09:06.778109
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'bar', 'baz', 'foo') is False



# Generated at 2022-06-23 18:09:10.063464
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-23 18:09:19.755747
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(reversed('hello')) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    # noinspection PyUnresolvedReferences,PyUnresolvedReferences
    assert is_list_like(dict(a=1, b=2).keys()) is True
    # noinspection PyUnresolvedReferences,PyUnresolvedReferences
    assert is_list_like(dict(a=1, b=2).values()) is True
    # noinspection PyUnresolvedReferences,PyUnresolvedReferences

# Generated at 2022-06-23 18:09:25.977384
# Unit test for function has_any_callables
def test_has_any_callables():
    class SomeObject:
        def foo(self):
            pass

        def bar(self):
            pass

    s = SomeObject()
    assert has_any_callables(s, 'foo') is True
    assert has_any_callables(s, 'foo', 'bar') is True
    assert has_any_callables(s, 'foo', 'baz', 'bar') is True
    assert has_any_callables(s, 'baz', 'bar') is False
    assert has_any_callables(s, 'baz') is False
    assert has_any_callables({}, 'keys') is True
    assert has_any_callables({}, 'keys', 'items') is True
    assert has_any_callables({}, 'keys', 'items', 'get') is True

# Generated at 2022-06-23 18:09:32.322542
# Unit test for function has_attrs
def test_has_attrs():
    """Test ``has_attrs`` with positive results."""
    assert has_attrs(dict(), 'get', 'keys', 'values', 'items')
    assert has_attrs(dict(a='a', b='b'), 'get', 'keys', 'values', 'items')
    assert has_attrs([1, 2, 3], '__getitem__', '__contains__', '__iter__')



# Generated at 2022-06-23 18:09:40.905332
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_callables(dict(), 'get', 'items') is False
    assert (
        has_callables(
            dict(),
            'get',
            'keys',
            'items',
            'values',
            'foo',
            'bar',
            'baz'
        ) is False
    )
    assert has_callables(
        dict(a=1, b=2, c=3, d=4, e=5),
        'get',
        'keys',
        'items',
        'values'
    )

# Generated at 2022-06-23 18:09:48.933984
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for method `flutils.objutils.is_list_like`.
    """
    assert is_list_like(
        dict(a=1, b=2, c=3, d=4, e=5).keys()
    ) is True
    assert is_list_like(
        dict(a=1, b=2, c=3, d=4, e=5).items()
    ) is True
    assert is_list_like(
        dict(a=1, b=2, c=3, d=4, e=5).values()
    ) is True
    assert is_list_like(
        dict(a=1, b=2, c=3, d=4, e=5)
    ) is False

# Generated at 2022-06-23 18:09:52.579631
# Unit test for function has_any_callables
def test_has_any_callables():
    from nose.tools import assert_equal

    dict_attrs = ['get', 'keys', 'values', 'items', 'something']
    obj = dict()
    assert_equal(has_any_callables(obj, *dict_attrs), True)


# Generated at 2022-06-23 18:09:56.807054
# Unit test for function has_attrs
def test_has_attrs():
    # test with attr exist
    obj1 = dict()
    assert has_attrs(obj1, 'get', 'keys', 'items', 'values') is True
    # test with attr does not exist
    obj2 = dict()
    assert has_attrs(obj2, 'get', 'foo', 'items', 'values') is False



# Generated at 2022-06-23 18:10:08.563354
# Unit test for function is_list_like
def test_is_list_like():
    from functools import partial
    from collections import ChainMap, OrderedDict
    from flutils.objutils import is_list_like
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(Iterator(list())) is True
    assert is_list_like(ValuesView(dict())) is True
    assert is_list_like(KeysView(dict())) is True
    assert is_list_like(UserList()) is True
    assert is_list_like(partial(list)) is False
    assert is_list_like(None) is False

# Generated at 2022-06-23 18:10:11.380817
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj,'get','keys','values','items')

# Generated at 2022-06-23 18:10:22.717570
# Unit test for function has_attrs
def test_has_attrs():
    import pytest

    class Foo(object):
        def foo_a(self):
            return 'foo_a'

        def bar_a(self):
            return 'bar_a'

    class Bar(object):
        def foo_b(self):
            return 'foo_b'

        def bar_b(self):
            return 'bar_b'

    foo = Foo()
    bar = Bar()

    # Test has_attrs()
    assert has_attrs(foo, 'foo_a')
    assert not has_attrs(foo, 'foo_b')
    assert not has_attrs(foo, 'foo_a', 'foo_b')
    assert has_attrs(foo, 'foo_a', 'bar_a')

    assert not has_attrs(bar, 'foo_a')
    assert has

# Generated at 2022-06-23 18:10:25.511398
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-23 18:10:36.230936
# Unit test for function is_list_like
def test_is_list_like():
    from operator import itemgetter
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from flutils.objutils import is_list_like

    assert is_list_like([]) is True
    assert is_list_like(()) is True
    assert is_list_like({}) is False
    assert is_list_like(dict()) is False
    assert is_list_like(defaultdict()) is False
    assert is_list_like(set()) is True
    assert is_list_like(OrderedDict()) is False
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like(('a', 'b', 'c')) is True

# Generated at 2022-06-23 18:10:45.964155
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(list(), 'insert', 'append', 'extend')
    assert has_attrs('hello', 'split', 'strip', 'splitlines')
    assert has_attrs(1, 'real', 'imag', 'conjugate')
    assert not has_attrs(list(), 'get', 'keys', 'items', 'values')
    assert not has_attrs(1, 'split', 'strip', 'splitlines')
    assert not has_attrs(dict(), 'insert', 'append', 'extend')
    assert not has_attrs('hello', 'real', 'imag', 'conjugate')


# Generated at 2022-06-23 18:10:55.742820
# Unit test for function has_any_callables
def test_has_any_callables():
    test_passed = True

    d = dict(foo=1, bar=2, baz=3)
    test1_passed = True
    if has_any_callables(d, 'foo', 'bar') is False:
        test1_passed = False
    elif has_any_callables(d, 'foo', 'bar', 'baz') is False:
        test1_passed = False

    if test1_passed is False:
        test_passed = False

    class Foo:
        def foo(self):
            pass

        def bar(self):
            pass

    f = Foo()
    test2_passed = True
    if has_any_callables(f, 'foo', 'bar') is False:
        test2_passed = False

# Generated at 2022-06-23 18:11:02.100388
# Unit test for function has_any_callables
def test_has_any_callables():
    objs = [
        dict(foo=1, bar=2),
        set([(a,b) for a in range(3) for b in range(3)]),
        list(zip(*(range(3), range(3))))
    ]

    for obj in objs:
        assert has_any_callables(obj, 'get', 'keys', 'bar') is True
        assert has_any_callables(obj, 'get', 'keys') is False



# Generated at 2022-06-23 18:11:07.370979
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items') is False
    assert has_callables(dict(),'get','keys','values','foo') is False

# Generated at 2022-06-23 18:11:15.498094
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList, UserDict
    obj = dict(a=1, b=2, c=3)
    assert is_subclass_of_any(obj.keys(),ValuesView)
    assert not is_subclass_of_any(obj,ValuesView)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert not is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserDict, UserList)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList,UserDict)
    assert is_subclass_of_any(obj.keys(),UserList)

# Generated at 2022-06-23 18:11:20.125915
# Unit test for function is_list_like
def test_is_list_like():
    # this is a test function
    assert is_list_like([1,2,3]) is True
    assert is_list_like(reversed([1,2,4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-23 18:11:28.563609
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for the is_list_like function.
    """
    test_list_like_objects = (
        [(1, 2, 3), 1, 2, 3, UserList([1, 2, 3]), 'hello', '', reversed([1, 2, 3]),
         sorted('hello'), dict(a=1, b=2), dict(a=1, b=2).items(), dict(a=1, b=2).keys(),
         dict(a=1, b=2).values(), frozenset([1, 2, 3]), set([1, 2, 3]), tuple([1, 2, 3]),
         deque([1, 2, 3])]
    )

# Generated at 2022-06-23 18:11:39.762498
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for the function is_list_like.
    """
    # pylint: disable=unbalanced-tuple-unpacking


# Generated at 2022-06-23 18:11:44.987468
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert_true(is_subclass_of_any(['a'], list))
    assert_true(is_subclass_of_any(dict(a=1, b=2).values(), ValuesView))
    assert_false(is_subclass_of_any(['a'], ValuesView))

# Generated at 2022-06-23 18:11:52.692762
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True)

# Generated at 2022-06-23 18:12:00.579891
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like"""
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from flutils.primitives import Primitives
    from flutils.objutils import is_list_like
    # the following is list-like
    if is_list_like([1, 2, 3]) is False:
        raise AssertionError
    if is_list_like(reversed([1, 2, 4])) is False:
        raise AssertionError
    if is_list_like(sorted('hello')) is False:
        raise AssertionError
    if is_list_like(iter([1, 2, 4])) is False:
        raise Ass

# Generated at 2022-06-23 18:12:02.673552
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-23 18:12:13.856193
# Unit test for function has_callables
def test_has_callables():
    from collections import ChainMap
    from collections.abc import (
        Mapping,
        MutableMapping,
        MutableSequence,
        MutableSet,
        MappingView,
    )


# Generated at 2022-06-23 18:12:22.000932
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('dict', 'foo', 'upper') is False, "Unable to determine if a string has any callable methods"
    assert has_any_callables([1, 2, 3], 'append', 'foo') is True, "Unable to determine if a dict has any callable methods"
    assert has_any_callables({'a': 1, 'b': 2}, 'keys', 'foo') is True, "Unable to determine if a dict has any callable methods"
    assert has_any_callables(dict(a=1, b=2), 'keys', 'foo') is True, "Unable to determine if a dict has any callable methods"

# Generated at 2022-06-23 18:12:30.220646
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(0) is False
    assert is_list_like(1) is False
    assert is_list_like(2) is False
    assert is_list_like(3) is False
    assert is_list_like(4) is False
    assert is_list_like(5) is False
    assert is_list_like('1') is False


# Generated at 2022-06-23 18:12:33.618644
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','set')
    assert has_any_callables(dict(),'get','keys','items','values','foo') is False


# Generated at 2022-06-23 18:12:38.429180
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList))


# Generated at 2022-06-23 18:12:41.746966
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') == True



# Generated at 2022-06-23 18:12:52.749104
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from decimal import Decimal

    # simple list like objects
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(frozenset({1, 2, 3})) is True
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like({1: 2, 3: 4}) is True
    assert is_list_like(deque([1, 2, 3])) is True
    assert is_list_like(dict(a=1, b=2, c=3)) is True
    assert is_list_like(list([1, 2, 3, 4])) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like

# Generated at 2022-06-23 18:12:57.769462
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(list(),'append','clear','extend','index','insert','pop','remove','reverse','sort') == True


# Generated at 2022-06-23 18:13:03.776868
# Unit test for function is_list_like
def test_is_list_like():
    from doctest import testmod
    from flutils.objutils import is_list_like
    result = testmod(
        verbose=True,
        optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS
    )
    assert result.failed == 0

# Generated at 2022-06-23 18:13:07.769327
# Unit test for function has_attrs
def test_has_attrs():
    """Test has_attrs"""
    assert has_attrs(dict(), 'keys', 'values') is True
    assert has_attrs(dict(), 'keys', 'values', 'something') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False


# Generated at 2022-06-23 18:13:13.309202
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-23 18:13:16.003467
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a = 1, b = 2, c = 3)
    assert has_callables(obj,'keys','values','items')
    assert not has_callables(obj,'keys','values','items','foo')


# Generated at 2022-06-23 18:13:26.675969
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs({}, 'get', 'keys', 'items', 'values', 'something') == True
    assert has_any_attrs(list(),'get','keys','items','values','something') == False
    assert has_any_attrs([], 'get', 'keys', 'items', 'values', 'something') == False
    assert has_any_attrs(set(),'get','keys','items','values','something') == True
    assert has_any_attrs({}, 'get', 'keys', 'items', 'values', 'something') == True
    assert has_any_attrs(frozenset(),'get','keys','items','values','something') == True

# Generated at 2022-06-23 18:13:34.948420
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values','something') == True
    assert has_attrs(dict(),'get','keys','items','values','foo') == False
    assert has_attrs(dict({'a': 1}),'get','keys','items','values','something') == True
    assert has_attrs(dict({'a': 1}),'get','keys','items','values','foo') == False


# Generated at 2022-06-23 18:13:43.378356
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    import decimal

    d = dict(a=1, b=2)
    assert isinstance(d.keys(), ValuesView) is True
    assert is_subclass_of_any(d.keys(), ValuesView) is True
    assert is_subclass_of_any(d.keys(), ValuesView, KeysView) is True
    assert is_subclass_of_any(d.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(d.keys(), ValuesView, KeysView, UserList) is True

    assert is_subclass_of_any(d.keys(), UserList) is True
    assert is_subclass_of_any(d.keys(), float) is False
    assert is_subclass_of_any(d.keys(), bytes) is False

    assert is_subclass

# Generated at 2022-06-23 18:13:47.554094
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True

# Generated at 2022-06-23 18:13:51.054602
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables: is any of the attributes callable"""
    dct = dict(a=1, b=2)
    assert has_any_callables(dct, "get", "keys", "items", "values", "update")
    assert has_any_callables(dct, "get", "foo", "bar")


# Generated at 2022-06-23 18:14:01.715216
# Unit test for function is_list_like
def test_is_list_like():
    list_like = [
        UserList([1, 2, 3]),
        Iterator([]),
        ValuesView(dict(a=1, b=2)),
        deque([1, 2, 3]),
        frozenset([1, 2, 3]),
        [1, 2, 3],
        set([1, 2, 3]),
        tuple([1, 2, 3])
    ]
    not_list_like = ['hello']
    for obj in list_like:
        assert is_list_like(obj)
    for obj in not_list_like:
        assert not is_list_like(obj)



# Generated at 2022-06-23 18:14:12.341676
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(
        [1, 2, 3, 4], 'append', 'clear', 'copy', 'count', 'extend') is False
    assert has_any_attrs(1.0, '__add__', '__abs__', '__bool__', '__class__') is False
    assert has_any_attrs(
        'this is a string', 'capitalize', 'casefold', 'center', 'count')
    assert has_any_attrs(True, 'real', 'imag', 'conjugate', '__complex__') is False
    assert has_any_attrs(
        None, 'real', 'imag', 'conjugate', '__complex__') is False
    assert has

# Generated at 2022-06-23 18:14:16.170560
# Unit test for function has_any_attrs
def test_has_any_attrs():
    ref = dict(a=1)
    assert has_any_attrs(ref, 'a', 'b')
    assert not has_any_attrs(ref, 'b')
    assert has_any_attrs(ref, 'update', 'a')
    assert not has_any_attrs(ref, 'b', 'update')



# Generated at 2022-06-23 18:14:25.636089
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'keys') is True
    assert has_any_callables(dict(a=1, b=2), 'keys') is True
    assert has_any_callables(dict(a=1, b=2), 'foobar') is False
    assert has_any_callables(dict(a=1, b=2), 'foobar', 'keys') is True
    assert has_any_callables(dict(a=1, b=2), 'foobar', 'other') is False


# Generated at 2022-06-23 18:14:27.523285
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(dict(), 'get', 'keys', 'items', 'values') is True)



# Generated at 2022-06-23 18:14:33.425311
# Unit test for function has_attrs
def test_has_attrs():
    from contextlib import suppress
    from collections import UserList

    assert has_attrs({}, 'keys') is True, 'Failed on dictionary'
    assert has_attrs({}.keys(), 'copy') is True, 'Failed on dictionary keys'
    assert has_attrs({}.values(), 'copy') is True, 'Failed on dictionary values'
    assert has_attrs({}.items(), 'copy') is True, 'Failed on dictionary items'
    assert has_attrs([], 'append') is True, 'Failed on list'
    assert has_attrs(set(), 'add') is True, 'Failed on set'
    assert has_attrs(frozenset(), 'copy') is True, 'Failed on frozenset'
    assert has_attrs(tuple(), 'count') is True, 'Failed on tuple'

# Generated at 2022-06-23 18:14:35.789747
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-23 18:14:43.568266
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list()) is True
    assert is_list_like(dict()) is False
    assert is_list_like(reversed(list())) is True
    assert is_list_like(str()) is False
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(Iterator) is True
    assert is_list_like(ValuesView) is True
    assert is_list_like(KeysView) is True
    assert is_list_like(UserList) is True
 
    assert is_list_like(None) is False
    assert is_list_like(bool) is False

# Generated at 2022-06-23 18:14:45.720108
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:14:52.232088
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), *_LIST_LIKE) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, str) is True

# Generated at 2022-06-23 18:15:01.882612
# Unit test for function is_list_like
def test_is_list_like():
    from collections import Counter, ChainMap, OrderedDict, UserDict, UserString, defaultdict
    from decimal import Decimal
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(deque([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(reversed('hello')) is True
    assert is_list_like(sorted([1, 2, 4])) is True
    assert is_list_like(set([1, 2, 4])) is True
    assert is_list_like(frozenset([1, 2, 4])) is True
    assert is_list_like(tuple([1, 2, 4])) is True

# Generated at 2022-06-23 18:15:14.659208
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    from decimal import Decimal
    from flutils.utilities import get_values_to_test

    # Lists of types to check for list-like behaviour
    _BASE = (
        list,
        set,
        frozenset,
        tuple,
        deque,
        Iterator,
        ValuesView,
        KeysView,
        UserList,
    )

    _COLLECTIONS = (
        collections.defaultdict,
        collections.Counter,
        collections.OrderedDict,
        collections.UserDict,
        collections.UserString,
    )

    # Types that are NOT list-like
    _NOT = (
        None,
        bool,
        bytes,
        collections.ChainMap,
        Decimal,
        dict,
        float,
        int,
        str,
    )

# Generated at 2022-06-23 18:15:18.348135
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1,b=2)
    assert(has_callables(obj, 'get','keys','items','values') is True)
    assert(has_callables(obj, 'get','keys','items','values','foo') is False)


# Generated at 2022-06-23 18:15:28.658525
# Unit test for function has_callables
def test_has_callables():
    # Test 1: Template: Test that the correct result is returned given valid params
    # setup test
    class TestClass(object):
        foo = 'bar'

        def do_something(self):
            pass

    expected_result = True
    object_to_check = TestClass()
    # perform test
    actual_result = has_callables(object_to_check, 'do_something')
    # assert expectations
    assert expected_result == actual_result
    # Test 2: Template: Test that the correct result is returned given a subclass
    # setup test
    class TestSubclass(TestClass):
        pass

    expected_result = True
    object_to_check = TestSubclass()
    # perform test
    actual_result = has_callables(object_to_check, 'do_something')
    # assert expectations

# Generated at 2022-06-23 18:15:38.243066
# Unit test for function is_list_like
def test_is_list_like():
    obj1 = UserList()
    obj2 = obj1.copy()
    obj3 = sorted('bca')
    obj4 = 'hello'
    obj5 = None

    output1 = is_list_like(obj1)
    output2 = is_list_like(obj2)
    output3 = is_list_like(obj3)
    output4 = is_list_like(obj4)
    output5 = is_list_like(obj5)

    assert is_list_like(obj1) == True
    assert is_list_like(obj2) == True
    assert is_list_like(obj3) == True
    assert is_list_like(obj4) == False
    assert is_list_like(obj5) == False


# Generated at 2022-06-23 18:15:40.796690
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','values')


if __name__ == '__main__':
    import pytest

    pytest.main(['-xrs', __file__, '-v', '-p', 'no:warnings'])

# Generated at 2022-06-23 18:15:47.542790
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values'
    )
    assert has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'something'
    )
    assert has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'foo'
    )


# Generated at 2022-06-23 18:15:57.623016
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(tuple()) == True
    assert is_list_like(dict()) == False
    assert is_list_like(reversed(tuple())) == True
    assert is_list_like(set()) == True
    assert is_list_like(frozenset()) == True
    assert is_list_like(set(tuple())) == True
    assert is_list_like(dict().keys()) == True
    assert is_list_like(dict().items()) == True
    assert is_list_like(dict().values()) == True
    assert is_list_like(dict(a=1,b=2).items()) == True


# Generated at 2022-06-23 18:16:06.475765
# Unit test for function is_list_like
def test_is_list_like():
    var = ['a', 'b', 'c']
    var_list = is_list_like(var)
    print(var_list)
    var_list = is_list_like(set(var))
    print(var_list)
    var_list = is_list_like(dict(var))
    print(var_list)
    var_list = is_list_like(reversed(var))
    print(var_list)
    var_list = is_list_like('abc')
    print(var_list)
    var_list = is_list_like(sorted(var))
    print(var_list)

if __name__ == '__main__':
    test_is_list_like()

# Generated at 2022-06-23 18:16:11.551405
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'values', 'something')
    obj = ('a', 'b')
    assert has_any_attrs(obj, 'join') == has_any_attrs(obj, 'something')

