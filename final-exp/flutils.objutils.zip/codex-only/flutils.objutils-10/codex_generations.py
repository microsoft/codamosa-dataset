

# Generated at 2022-06-23 18:06:10.414578
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:06:12.126225
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') == True, f"has_attrs(dict(),'get','keys','items','values') == True"

# Generated at 2022-06-23 18:06:24.178991
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import (
        Decimal,
    )
    from flutils.collections import (
        ChainMap,
    )

    from pytest import (
        raises,
    )

    from flutils.objutils import (
        is_subclass_of_any,
    )

    with raises(TypeError):
        is_subclass_of_any()

    assert is_subclass_of_any(None, type(None)) is True
    assert is_subclass_of_any(0, int) is True
    assert is_subclass_of_any(0.0, float) is True
    assert is_subclass_of_any('', str) is True

# Generated at 2022-06-23 18:06:26.546841
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    for attr in ('get', 'keys', 'items', 'values', 'foo'):
        assert has_any_callables(obj, attr) == True

# Generated at 2022-06-23 18:06:31.142236
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    attrs = ('get', 'keys', 'items', 'values')
    assert has_any_attrs(obj, *attrs) is True
    attrs = ('foo', 'bar', 'baz')
    assert has_any_attrs(obj, *attrs) is False


# Generated at 2022-06-23 18:06:32.619149
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:06:37.204475
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    obj = 'string'
    assert not is_subclass_of_any(obj,ValuesView,KeysView,UserList)


# Generated at 2022-06-23 18:06:46.137588
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.items(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(reversed(obj.keys()), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(sorted(obj.keys()), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:06:51.137953
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(dict(), 'something')
    assert has_any_attrs(list(), 'append', 'append', 'sort')
    assert not has_any_attrs(list(), 'something')


# Generated at 2022-06-23 18:07:01.636995
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    import random
    from contextlib import ExitStack as _ExitStack
    from unittest import TestCase as _TestCase
    from unittest import main as _main

    from flutils.objutils import is_subclass_of_any

    # 1. 9 classes that are subclasses of each other and are not subclasses of
    #    any other classes
    # 2. A bunch of classes that are not subclasses of each other

# Generated at 2022-06-23 18:07:03.842047
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:07:14.894162
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False

    obj = list(range(10))
    assert has_callables(obj, 'append', 'extend', 'insert', 'remove', 'pop',
                         'index', 'count', 'sort', 'reverse', 'copy', 'clear') is True
    assert has_callables(obj, 'foo', 'bar') is False

    obj = set('abcd')

# Generated at 2022-06-23 18:07:19.260356
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_any_callables(dict(), 'something', 'else')



# Generated at 2022-06-23 18:07:23.996487
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = {'a': 1, 'b': 2, 'c': 3}
    assert True == has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-23 18:07:29.537359
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'food', 'bar') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'foo', 'food', 'bar', 'get', 'keys', 'items', 'values') is False



# Generated at 2022-06-23 18:07:34.514492
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test to check function is_list_like."""
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like('') is False
    assert is_list_like(int) is False
    assert is_list_like(int()) is False

# Generated at 2022-06-23 18:07:39.803163
# Unit test for function has_any_callables
def test_has_any_callables():
    d = {'get': 'get', 'keys': 'keys', 'values': 'values', 'items': 'items'}
    assert has_any_callables(d, 'get', 'keys', 'values', 'items')



# Generated at 2022-06-23 18:07:49.916099
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict, 'get', 'keys', 'values', 'something'))
    assert(has_any_callables(dict, 'get', 'keys', 'values', 'something'))
    assert(has_any_callables(dict(), 'get', 'keys', 'values', 'something'))
    assert(has_any_callables(list(), 'append', 'clear', 'copy', 'count'))
    assert(has_any_callables(list(), 'append', 'clear', 'copy', 'count'))
    assert(has_any_callables(list, 'append', 'clear', 'copy', 'count'))
    assert(has_any_callables(set(), 'add', 'clear', 'copy', 'difference'))

# Generated at 2022-06-23 18:07:57.225379
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert is_list_like([1,2,3]) is True
    assert is_list_like(reversed([1,2,3])) is True
    assert is_list_like(reversed('hello')) is True
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(123) is False
    assert is_list_like(dict(a=1,b=2,c=3)) is False

# Generated at 2022-06-23 18:08:00.385203
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'items', 'keys')
    assert has_any_attrs(obj, 'get', 'clear', 'something')
    assert not has_any_attrs(obj, 'something', 'something else')



# Generated at 2022-06-23 18:08:04.901973
# Unit test for function has_any_callables
def test_has_any_callables():
    print("test_has_any_callables():")
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-23 18:08:10.579014
# Unit test for function has_callables
def test_has_callables():
    # Test positive result
    actual = has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
    )
    assert actual is True

    # Test negative result
    actual = has_callables(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'foo',
    )
    assert actual is False



# Generated at 2022-06-23 18:08:13.093722
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView) == True


# Generated at 2022-06-23 18:08:21.495699
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """
    >>> from flutils.objutils import is_subclass_of_any
    >>> from collections import ValuesView, KeysView, UserList
    >>> obj = dict(a=1, b=2)
    >>> is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    True
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:08:29.867206
# Unit test for function has_attrs
def test_has_attrs():
    class Foo:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    # noinspection PyPep8Naming,PyUnusedLocal
    class Bar:
        @staticmethod
        def qux(a, b):
            return a, b
        # noinspection PyPep8Naming
        def quux(self):
            print('Bar.quux()')

    # noinspection PyPep8Naming,PyUnusedLocal
    class Baz(Bar):
        # noinspection PyPep8Naming
        def quux(self):
            print('Baz.quux()')

    assert has_attrs(dict(), 'keys', 'values', 'items') is True

# Generated at 2022-06-23 18:08:34.558448
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True


# Generated at 2022-06-23 18:08:41.389488
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'fooz') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is False

# Generated at 2022-06-23 18:08:43.644563
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')


# Generated at 2022-06-23 18:08:45.926365
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    from collections import Counter
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(Counter, 'get','keys','items','values') == False


# Generated at 2022-06-23 18:08:52.584859
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables('hello', 'upper', 'lower', 'something') is True
    assert has_any_callables('hello', 'get', 'foo') is False
    assert has_any_callables(dict(), 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'clear', 'foo') is False
    assert has_any_callables(12345, 'foo') is False


# Generated at 2022-06-23 18:08:57.610703
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter
    from flutils.objutils import has_callables

    obj = Counter(letters='standard')
    assert has_callables(obj, 'most_common')

    obj = 'standard'
    assert not has_callables(obj, 'most_common')


# Generated at 2022-06-23 18:09:01.359162
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'get', 'keys') is True
    assert has_any_callables(obj, 'get', 'keys', 'foo') is True
    assert has_any_callables(obj, 'foo', 'bar', 'baz') is False



# Generated at 2022-06-23 18:09:08.065269
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for function has_callables
    """
    assert has_callables({}, 'get', 'keys', 'items', 'values') == True
    assert has_callables({}, 'get', 'keys', 'list', 'values') == False
    assert has_callables(object(), 'get', 'keys', 'list', 'values') == False
    assert has_callables(object(), 'get', 'keys', 'list', 'values') == False


# Generated at 2022-06-23 18:09:11.201240
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(),'get','keys') is False


# Generated at 2022-06-23 18:09:13.776288
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True

# Generated at 2022-06-23 18:09:24.179576
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs."""
    # Using a dict
    obj = dict(a=1, b=2, c=3)
    assert has_any_attrs(obj, 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(obj, 'keys', 'items', 'values', 'foo') is False
    assert has_any_attrs(obj, 'bar', 'baz', 'qux') is False

    # Using a list
    obj = [1, 2, 3]
    assert has_any_attrs(obj, 'append', 'extend', 'foo') is True
    assert has_any_attrs(obj, 'pop', 'remove', 'something') is False



# Generated at 2022-06-23 18:09:27.033076
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:09:29.338511
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)


# Generated at 2022-06-23 18:09:34.089081
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get','keys','items','values','update')
    assert not has_attrs(dict(), 'bar','foo','baz','foo','baz')


# Generated at 2022-06-23 18:09:38.960999
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj1 = dict(a=1, b=2)
    assert has_any_attrs(obj1, 'keys', 'values', 'items') is True
    assert has_any_attrs(obj1, 'foo') is False
    assert has_any_attrs(obj1) is False
    assert has_any_attrs(dict, 'get') is True



# Generated at 2022-06-23 18:09:46.023689
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """ """
    # Test for given object having at least one of the given attributes.
    obj = dict(a=1, b=2, c=3)
    assert has_any_attrs(obj, 'keys', 'items', 'values', '__iter__') is True
    assert has_any_attrs(obj, 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(obj, 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(obj, 'foo', 'bar', 'baz', 'something') is False


# Generated at 2022-06-23 18:09:54.988320
# Unit test for function is_list_like
def test_is_list_like():
    """Test the function is_list_like"""
    # Test the function with a list
    test_list = [1, 2, 3, 4, 5]
    res = is_list_like(test_list)
    assert res is True

    # Test the function with a frozenset
    test_frozenset = frozenset(test_list)
    res = is_list_like(test_frozenset)
    assert res is True

    # Test the function with a tuple
    test_tuple = tuple(test_list)
    res = is_list_like(test_tuple)
    assert res is True

    # Test the function with a UserList
    from collections import UserList
    test_UserList = UserList(test_list)
    res = is_list_like(test_UserList)
   

# Generated at 2022-06-23 18:09:58.736608
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values',
                         'something') is True
    assert has_any_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'foo',
                         'something') is True
    assert has_any_attrs(dict(a=1), 'get', 'keys', 'foo', 'values',
                         'something') is False


# Generated at 2022-06-23 18:10:10.216463
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo')
    assert has_any_attrs([], '__getitem__','append','extend','insert','pop','remove','index','count','sort','reverse','copy','clear')
    assert not has_any_attrs([], 'get','keys','items','values')
    assert has_any_attrs((), '__getitem__','append','extend','insert','pop','remove','index','count','sort','reverse','copy','clear')
    assert not has_any_attrs((), 'get','keys','items','values')
    assert has_any_attrs(reversed((1,2,3)), '__getitem__','append','extend','insert','pop','remove','index','count','sort','reverse','copy','clear')
    assert not has_

# Generated at 2022-06-23 18:10:16.612257
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test has_any_attrs() function."""
    from flutils import objutils
    assert objutils.has_any_attrs(dict(),'foo','bar') is True
    assert objutils.has_any_attrs(dict(),'get','keys','bar') is True
    assert objutils.has_any_attrs(dict(),'foo','bar','baz') is False


# Generated at 2022-06-23 18:10:24.811674
# Unit test for function is_list_like
def test_is_list_like():
    from decimal import Decimal
    assert is_list_like(Decimal(43)) is False
    assert is_list_like(dict()) is False
    assert is_list_like(float()) is False
    assert is_list_like(43) is False
    assert is_list_like(list()) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(reversed('hello')) is True
    assert is_list_like([1,2,3]) is True
    assert is_list_like(reversed([1,2,4])) is True


# Generated at 2022-06-23 18:10:30.334873
# Unit test for function has_attrs
def test_has_attrs():
    class X(object):
        pass

    x = X()
    x.a = 'a'
    x.b = 'b'

    assert has_attrs(x, 'a', 'b') is True
    assert has_attrs(x, 'a', 'b', 'c') is False
    assert has_attrs(x, 'a', 'x') is False


# Generated at 2022-06-23 18:10:37.918512
# Unit test for function has_attrs
def test_has_attrs():
    # but no callables
    class Ob(object):
        name = 'test'

    # assert has_attrs(Ob(),'name') == True
    assert has_callables(Ob(), 'name') == True
    # assert has_attrs(Ob(),'name','bob') == False
    # assert has_attrs(Ob(),'nam') == False
    # assert has_attrs(Ob(),'name','nam') == False
    assert has_attrs(Ob(), 'name', 'nam') == False



# Generated at 2022-06-23 18:10:42.000042
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter
    dict_obj = dict(a=1, b=2, c=3)
    counter_obj = Counter(a=1, b=2, c=3)
    assert has_callables(dict_obj, 'get', 'keys', 'items') is True
    assert has_callables(dict_obj, 'get', 'keys', 'items', 'something') is False
    assert has_callables(counter_obj, 'get', 'keys', 'items') is True


# Generated at 2022-06-23 18:10:48.997053
# Unit test for function has_attrs
def test_has_attrs():
    import unittest

    class HasAttrsTest(unittest.TestCase):
        def test_true(self):
            self.assertTrue(has_attrs(dict(), 'get', 'keys', 'items', 'values'))

        def test_false(self):
            self.assertFalse(has_attrs(dict(), 'foo', 'bar', 'baz'))

    unittest.main()


# Generated at 2022-06-23 18:10:50.501390
# Unit test for function has_attrs
def test_has_attrs():
    import doctest
    doctest.testmod(verbose=1)


# Generated at 2022-06-23 18:10:53.474454
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) ==  True


# Generated at 2022-06-23 18:10:59.499212
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # Tests that the is_subclass_of_any function works.
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(x=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:11:00.550852
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:11:10.477034
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items') == True
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'something') == True
    assert has_any_callables(dict(), 'get', 'keys', 'foo', 'items') == True
    assert has_any_callables(dict(), 'get', 'keys', 'something', 'values') == True
    assert has_any_callables(dict(), 'get', 'keys', 'foo', 'something') == False
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'items', 'values', 'keys', 'get') == True
    assert has_any_callables(obj, 'items', 'values', 'keys', 'foo') == True
    assert has

# Generated at 2022-06-23 18:11:22.695148
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import ChainMap, OrderedDict, UserDict, UserList, UserString
    from decimal import Decimal
    import datetime
    from flutils.objutils import has_any_callables
    # Test types
    assert has_any_callables(None, 'foo', '__init__') is False
    assert has_any_callables(True, 'foo', '__init__') is False
    assert has_any_callables(2.5, 'foo', '__init__') is False
    assert has_any_callables(5, 'foo', '__init__') is False
    assert has_any_callables('hello world', 'foo', '__init__') is False
    assert has_any_callables(b'hello world', 'foo', '__init__') is False
    # Test dict types
   

# Generated at 2022-06-23 18:11:26.871334
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'foo','bar','baz')


# Generated at 2022-06-23 18:11:30.255081
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any('foo', ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:11:36.304414
# Unit test for function has_any_callables
def test_has_any_callables():
    #Test for dict
    obj = dict(a=1,b=2)
    assert has_any_callables(obj,'get','keys','items','values','bar') == True
    # Test for list
    obj = [1,2,3,4,5]
    assert has_any_callables(obj,'get','keys','items','values','bar') == False
    # Test for tuple
    obj = (1,2,3,4,5)
    assert has_any_callables(obj,'get','keys','items','values','bar') == False
    # Test for class
    class Foo:
        a = 1
        b = 2
        def __init__(self):
            a = 1
            b = 2
            c = 3
            d = 4
        def get(self):
            return self.a
    obj

# Generated at 2022-06-23 18:11:40.362546
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True, "Failure on test_is_subclass_of_any"

# Generated at 2022-06-23 18:11:50.640681
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    from collections.abc import ValuesView, KeysView
    from doctest import testmod
    from flutils.objutils import has_callables

    obj = OrderedDict(a=1, b=2)
    assert has_callables(obj, 'keys', 'values') is True
    assert has_callables(obj.keys(), '__iter__', '__call__') is True
    assert has_callables(obj.values(), '__iter__', '__call__') is True
    assert has_callables(obj.values(), '__call__') is False
    assert has_callables(obj.values(), '__iter__', '__call__', '__str__') is True

# Generated at 2022-06-23 18:11:54.947630
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = {'foo': lambda: True}
    attrs = ('get', 'foo', 'bar')
    assert has_any_callables(obj, *attrs) is True
    assert has_any_callables(obj, *('get', 'bar')) is False


# Generated at 2022-06-23 18:12:01.625167
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    # Initialize variables
    obj = dict(a=1, b=2)
    from collections import ValuesView, KeysView, UserList

    # Check that is_subclass_of_any returns True for any of several classes
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

    # Check that is_subclass_of_any returns True for one of several classes
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView) == True

    # Check that is_subclass_of_any returns False for no classes
    assert is_subclass_of_any(obj.keys()) == False

    # Check that is_subclass_of_any returns False for another class
    assert is_subclass_of_any(obj.keys(), ValuesView, UserList)

# Generated at 2022-06-23 18:12:04.543391
# Unit test for function is_list_like
def test_is_list_like():
    obj_test = dict(a=1,b=2)
    res = is_list_like(obj_test)
    assert res == False

# Generated at 2022-06-23 18:12:15.768563
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        UserDict,
        UserString,
        ChainMap,
    )
    from collections.abc import (
        Iterator,  # noqa: F811
        KeysView,  # noqa: F811
        ValuesView,  # noqa: F811
    )
    from decimal import Decimal
    from operator import (
        itemgetter,
        methodcaller,
    )
    from pprint import pprint
    from random import (
        random,
        shuffle,
    )
    from collections import (
        UserList,  # noqa: F811
        deque,  # noqa: F811
    )

# Generated at 2022-06-23 18:12:24.343408
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs([1, 2, 3], '__ne__', '__len__', '__iter__') == True
    assert has_attrs([1, 2, 3, '4'], '__ne__', '__len__', '__iter__', '__add__') == False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') == False


# Generated at 2022-06-23 18:12:30.935929
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'foo', 'keys', 'items', 'values') == False
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') == False
    assert has_callables(dict(), 'foo', 'keys', 'items', 'foo') == False



# Generated at 2022-06-23 18:12:33.967580
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'items', 'real') is True


# Generated at 2022-06-23 18:12:44.794029
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') \
           is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') \
           is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') \
           is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') \
           is True
    assert has_any_callables(dict(), 'foobar') is False
    assert has_any_callables(dict(), '__contains__') is False


# Generated at 2022-06-23 18:12:50.854279
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_attrs"""
    assert has_any_callables(dict(),'clear','keys','items','values')
    assert has_any_callables(dict(),'clear','keys','items','values') == True
    assert has_any_callables(dict(),'clear','keys','items','values','foo') == True


# Generated at 2022-06-23 18:12:56.284839
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any('a', str, list, tuple)
    assert not is_subclass_of_any('a', list, tuple)
    assert not is_subclass_of_any('a')


# Generated at 2022-06-23 18:13:07.595485
# Unit test for function is_list_like
def test_is_list_like():
    from itertools import chain, count
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict
    )
    from decimal import Decimal
    import string

    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(1) is False
    assert is_list_like(0) is False
    assert is_list_like(-1) is False
    assert is_list_like(-2) is False
    assert is_list_like(1.0) is False
    assert is_list_like(0.0) is False
    assert is_list_like(-1.0)

# Generated at 2022-06-23 18:13:13.830952
# Unit test for function has_any_attrs
def test_has_any_attrs():
    test_obj = dict(a=1, b=2)
    from inspect import signature, _ParameterKind
    required_attrs = set([attr
                          for attr, param in signature(dict).parameters.items()
                          if param.kind == _ParameterKind.POSITIONAL_OR_KEYWORD])
    assert has_any_attrs(test_obj, *required_attrs)



# Generated at 2022-06-23 18:13:23.516977
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'foobar') is False
    assert has_any_attrs(dict(), 'something') is False
    assert has_any_attrs(dict(a=1), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(a=1), 'a') is True
    assert has_any_attrs(dict(a=1), 'b') is False
    assert has_any_attrs(dict(a=1), 'get', 'a') is True
    assert has_any_attrs(dict(a=1), 'foobar', 'a') is True

# Generated at 2022-06-23 18:13:27.938183
# Unit test for function has_attrs
def test_has_attrs():
    # setup
    obj = {'a': 1, 'b': 2}
    test = has_attrs(obj, 'keys', 'values')
    assert test == True, 'has_attrs() should have returned True'

    # teardown
    del obj
    return True



# Generated at 2022-06-23 18:13:32.239030
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'values', 'items') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz', 'something') is False



# Generated at 2022-06-23 18:13:39.355973
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """ Unit test for :func:`is_subclass_of_any` """
    # Setup
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    # Test
    if is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is False:
        raise ValueError("is_subclass_of_any failed")
    # Cleanup - none

# Generated at 2022-06-23 18:13:46.290631
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict
    my_dict = OrderedDict(a=1, b=2)
    assert has_any_callables(my_dict, 'keys', 'values', 'items', 'foo')
    assert has_any_callables(my_dict, 'get', 'keys', 'values', 'items')
    assert not has_any_callables(my_dict, 'foo', 'bar', 'baz')



# Generated at 2022-06-23 18:13:53.002341
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'keys', 'invalid_attr') is True
    obj = 5
    assert has_any_attrs(obj, 'keys', 'invalid_attr') is False


# Generated at 2022-06-23 18:13:55.498024
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(dict(a=1,b=2)) is False



# Generated at 2022-06-23 18:13:59.579400
# Unit test for function has_callables
def test_has_callables():
    list_class = [1, 2, 3, 4, 5]
    assert has_callables(list_class, 'pop')
    assert not has_callables(list_class, 'popopop')


# Generated at 2022-06-23 18:14:04.346560
# Unit test for function has_attrs
def test_has_attrs():
    try:
        assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
        assert not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    except Exception as ex:
        pytest.fail(str(ex))


# Generated at 2022-06-23 18:14:08.174440
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    obj = dict(a=12, b=27)
    assert has_callables(obj, 'keys' 'items') is True
    assert has_callables(obj, 'foo') is False



# Generated at 2022-06-23 18:14:09.922141
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-23 18:14:17.950265
# Unit test for function is_list_like
def test_is_list_like():
    from itertools import cycle#, repeat
    from operator import itemgetter
    from random import random
    
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from functools import partial
    from operator import itemgetter
    
    # Test case: not list-like

# Generated at 2022-06-23 18:14:19.605925
# Unit test for function has_attrs
def test_has_attrs():
    """Tests for function has_attrs."""
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'some', 'thing', 'else') is False



# Generated at 2022-06-23 18:14:22.905998
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-23 18:14:29.930695
# Unit test for function has_attrs
def test_has_attrs():
    # An object that has all the given attrs
    _dict = dict()
    assert has_attrs(_dict, 'get', 'keys', 'items', 'values')

    # An object that does not have all the given attrs
    class _Foo:
        def get(self):
            pass

    assert not has_attrs(_Foo(), 'foo', 'bar')


# Generated at 2022-06-23 18:14:30.877177
# Unit test for function is_list_like
def test_is_list_like():
    pass


# Generated at 2022-06-23 18:14:41.802833
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values') is True
    assert has_callables(dict(), 'foo', 'bar') is False
    assert has_callables(list(), 'append', 'insert') is True
    assert has_callables(list(), 'foo', 'bar') is False
    assert has_callables(set(), 'add', 'remove') is True
    assert has_callables(set(), 'foo', 'bar') is False
    assert has_callables(frozenset(), 'copy', 'difference') is True
    assert has_callables(frozenset(), 'foo', 'bar') is False
    assert has_callables(tuple(), 'count', 'index') is True
    assert has_callables(tuple(), 'foo', 'bar') is False

# Generated at 2022-06-23 18:14:45.265209
# Unit test for function has_attrs
def test_has_attrs():
    import pytest
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'a','b','c') is False
    assert has_attrs(object(),'a') is False
    assert has_attrs((1,2,3,4),'a') is False


# Generated at 2022-06-23 18:14:55.289114
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert not is_list_like('hello')
    assert is_list_like(sorted('hello'))


if __name__ == '__main__':
    from flutils.objutils import (
        has_all_attrs,
        has_all_callables,
        has_any_attrs,
        has_any_callables,
    )
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert has_all_attrs(obj, 'get', 'keys', 'items', 'values')

# Generated at 2022-06-23 18:15:02.658438
# Unit test for function is_list_like
def test_is_list_like():
    test = [
        (1, False),
        (1.0, False),
        (True, False),
        (frozenset([1]), True),
        (set(), True),
        (list(), True),
        (dict(), True),
        (None, False),
        (sorted('hello'), True),
        ('hello', False),
        (reversed([1, 2, 3]), True),
        (iter([]), True),
        (iter(range(4)), True),
    ]
    for obj, result in test:
        assert is_subclass_of_any(obj, *_LIST_LIKE) == result

# Generated at 2022-06-23 18:15:09.899449
# Unit test for function has_any_callables
def test_has_any_callables():
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert  has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'pop')
    assert has_any_callables(set(), 'copy', 'difference', 'discard', 'intersection', 'pop')
    assert has_any_callables(tuple(), 'count', 'index')


# Generated at 2022-06-23 18:15:13.006596
# Unit test for function has_attrs
def test_has_attrs():
    obj = {'a':1, 'b':2}
    assert has_attrs(obj, 'get', 'items', 'keys', 'values') is True



# Generated at 2022-06-23 18:15:22.161215
# Unit test for function has_attrs
def test_has_attrs():
  class A:
    def foo(self):
      pass

  class B:
    def bar(self):
      pass

  a = A()
  b = B()

  assert has_attrs(a, 'foo', 'bar', 'razz') == False
  assert has_attrs(b, 'foo', 'bar', 'razz') == False
  assert has_attrs(a, 'foo') == True
  assert has_attrs(b, 'bar') == True
  assert has_attrs(a, 'foo', 'bar') == False
  assert has_attrs(b, 'foo', 'bar') == False


# Generated at 2022-06-23 18:15:30.415270
# Unit test for function has_attrs
def test_has_attrs():
    from collections import namedtuple
    from collections.abc import Collection

    class Thing(Collection):
        def __init__(self, value):
            self.value = value

        def __iter__(self):
            yield self.value

        def __len__(self):
            return 1

    attrs = ('a', 'b', 'c', 'd')
    assert has_attrs(dict(), *attrs) is True

    attrs = ('a', 'b', 'c', 'd')
    TestNamedTuple = namedtuple('TestNamedTuple', attrs)
    assert has_attrs(TestNamedTuple(*range(len(attrs))), *attrs) is True

    attrs = ('a', 'b', 'c', 'd')
    TestThing = Thing(value=attrs)
   

# Generated at 2022-06-23 18:15:34.622244
# Unit test for function is_list_like
def test_is_list_like():
    obj = 1
    assert is_list_like(obj) == False
    obj = []
    assert is_list_like(obj) == True
    obj = {}
    assert is_list_like(obj) == False

# Generated at 2022-06-23 18:15:37.644530
# Unit test for function has_attrs
def test_has_attrs():
    assert(has_attrs(dict(),'get','keys','items','values'))



# Generated at 2022-06-23 18:15:47.985187
# Unit test for function has_attrs
def test_has_attrs():
    """Test if the given ``obj`` has all of the given ``attrs``.

    Args:
        obj (:obj:`Any <typing.Any>`): The object to check.
        *attrs (:obj:`str`): The names of the attributes to check.

    :rtype:
        :obj:`bool`

        * :obj:`True` if all of the given ``attrs`` exist on the given ``obj``;
        * :obj:`False` otherwise.

    Example:
        >>> from flutils.objutils import has_attrs
        >>> has_attrs(dict(),'get','keys','items','values')
        True
        """
    has_attrs(dict(),'get','keys','items','values')
    return True


# Generated at 2022-06-23 18:15:56.358522
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items','beautifulsoup','something')
    assert not has_any_attrs(dict(),'get','keys','items','beautifulsoup')
    #test to make sure it doesn't return false positives
    assert not has_any_attrs(dict(),'getr','keyz','itemss','beautifulsoup')


# Generated at 2022-06-23 18:16:05.936140
# Unit test for function is_list_like
def test_is_list_like():
    assert(is_list_like([1, 2, 3]))

    assert(is_list_like(reversed((1, 2, 4))))

    assert(not is_list_like('hello'))

    assert(is_list_like(sorted('hello')))

    assert (is_list_like(UserList([1, 2, 3])))

    assert (not is_list_like(UserList(range(0, 12, 2))))

    assert (is_list_like(UserList(range(0, 13, 2))))

    assert (is_list_like(UserList(range(0, 13, 3))))

    assert (not is_list_like(UserList(range(0, 13, 4))))

    assert (is_list_like(UserList(range(0, 14, 2))))


# Generated at 2022-06-23 18:16:15.942252
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like."""
    # Test list
    result = is_list_like([1, 2, 3])
    assert result is True, 'then is_list_like([1, 2, 3]) is True'
    # Test tuple
    result = is_list_like((1, 2, 3))
    assert result is True, 'then is_list_like((1, 2, 3)) is True'
    # Test set
    result = is_list_like({1, 2, 3})
    assert result is True, 'then is_list_like({1, 2, 3}) is True'
    # Test frozenset
    result = is_list_like(frozenset({1, 2, 3}))