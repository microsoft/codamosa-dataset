

# Generated at 2022-06-23 18:06:15.563063
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    class Dict2(dict): pass
    class Dict3(Dict2): pass
    class Dict4(Dict3): pass
    class Dict5(Dict4): pass
    class Dict6(Dict5): pass
    class Dict7(Dict6): pass
    class Dict8(Dict7): pass
    class Dict9(Dict8): pass
    class Dict10(Dict9): pass
    class Dict11(Dict10): pass
    class Dict12(Dict11): pass
    class Dict13(Dict12): pass
    class Dict14(Dict13): pass
    class Dict15(Dict14): pass
    class Dict16(Dict15): pass

# Generated at 2022-06-23 18:06:25.110357
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'values', '__eq__') is False
    assert has_any_callables(dict(), 'get', 'keys', 'values') is True
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False


# Generated at 2022-06-23 18:06:27.486114
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any([1,2,3],list)

# Generated at 2022-06-23 18:06:37.682571
# Unit test for function has_callables
def test_has_callables():
    from collections import ChainMap
    obj = ChainMap()
    assert has_callables(obj, 'get', 'keys') is False
    assert has_callables(obj, 'get', 'keys', 'values') is False
    assert has_callables(obj, 'pop', 'popitem', 'setdefault') is True
    assert has_callables(obj, 'copy', 'get') is False
    assert has_callables(obj, 'copy', 'get', 'keys', 'values') is False
    assert has_callables(obj, 'copy', 'get', 'items', 'values') is False
    assert has_callables(obj, 'copy', 'get', 'keys', 'items') is False
    assert has_callables(obj, 'update', 'new_child') is False

# Generated at 2022-06-23 18:06:39.012314
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','values','foo')



# Generated at 2022-06-23 18:06:43.447752
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True

# Generated at 2022-06-23 18:06:54.348067
# Unit test for function is_list_like
def test_is_list_like():

    # Check that the function returns True on a list-like objects
    type_list = [
        None,
        bool,
        bytes,
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
        Decimal,
        dict,
        float,
        int,
        str,
    ]
    assert is_list_like(type_list) == True

    # Check that the function returns False on a non-list-like objects
    not_list_like = 'hello'
    assert is_list_like(not_list_like) == False

    # Check that the function returns False on a non-list-like objects
    not_list_like = sorted('hello')
    assert is_list_like(not_list_like) == True

# Generated at 2022-06-23 18:07:01.237439
# Unit test for function has_attrs
def test_has_attrs():
    import pytest
    from unittest.mock import Mock
    from operator import itemgetter

    obj = dict(a=2, b=3, c=4)

    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(obj, 'foo', 'bar', 'baz') is False

    obj = Mock()
    assert has_attrs(obj) is False
    obj.foo = 'bar'
    assert has_attrs(obj, 'foo') is True
    obj.bar = 'baz'
    assert has_attrs(obj, 'foo') is True
    assert has_attrs(obj, 'foo', 'bar') is True
    assert has_attrs(obj, 'foo', 'bar', 'baz') is False

    obj = fro

# Generated at 2022-06-23 18:07:09.661152
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import (
        is_subclass_of_any,
    )
    from collections import ValuesView, KeysView, UserList
    mydict = dict(a=1, b=2)
    assert is_subclass_of_any(mydict.values(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(mydict.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(mydict.items(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:07:14.092129
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, str) == False

# Generated at 2022-06-23 18:07:17.440485
# Unit test for function has_attrs
def test_has_attrs():
    """Test :func:`~flutils.objutils.has_attrs`."""
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:07:23.501291
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Check that dict has any of these
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    # Check that dict has none of these
    assert not has_any_attrs(dict(), 'blah', 'blah2')


# Generated at 2022-06-23 18:07:29.819351
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert not is_subclass_of_any(obj.keys(),KeysView,UserList,ValuesView) is True

test_is_subclass_of_any()


# Generated at 2022-06-23 18:07:32.965197
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:07:45.426776
# Unit test for function has_callables
def test_has_callables():
    from types import FunctionType
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    )
    from collections.abc import Mapping

    classes = [
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    ]

    for cls in classes:
        assert has_callables(cls, 'get', 'keys', 'items', 'values') is True

    # ValuesView and KeysView have a diffrent signature than typical mapping
    # objects.
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True

# Generated at 2022-06-23 18:07:48.164228
# Unit test for function has_attrs
def test_has_attrs():
    from logging import Logger

    assert has_attrs(Logger, 'error', 'warning') is True
    assert has_attrs(Logger, 'error', 'warning', 'debug') is False



# Generated at 2022-06-23 18:07:51.123409
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test function has_any_callables"""
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-23 18:08:01.010783
# Unit test for function has_attrs
def test_has_attrs():
    from collections import defaultdict
    from flutils.objutils import (
        has_attrs,
    )
    obj = defaultdict(list)
    assert has_attrs(
        obj,
        'get',
        'keys',
        'items',
        'values'
    ) is True
    assert has_attrs(
        {},
        'get',
        'keys',
        'items',
        'values'
    ) is True
    assert has_attrs(
        {'a': 1},
        'get',
        'keys',
        'items',
        'values'
    ) is True
    assert has_attrs(
        {'a': 1},
        'has_key',
        'keys',
        'items',
        'values'
    ) is False
    assert has_att

# Generated at 2022-06-23 18:08:07.325692
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([], 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables({}, 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-23 18:08:14.255165
# Unit test for function is_list_like
def test_is_list_like():
    """
    .. todo::
        1. Docstring
        2. Copy to test_objutils.py
    """
    import decimal
    import json
    import os
    import sys
    import types
    import unittest
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from collections import (
        deque,
        namedtuple,
    )
    from decimal import Decimal
    from flutils.objutils import is_list_like

    class TestObject(object):
        def __init__(self):
            super().__init__()
            self.name = 'TestObject'



# Generated at 2022-06-23 18:08:24.942146
# Unit test for function has_attrs
def test_has_attrs():
    """
    Test function has_attrs
    :return:
    """
    obj = dict(a=1, b=2, c=3, d=4)

    # Test that has_attrs returns True when all given attrs are on obj
    try:
        assert has_attrs(obj, 'keys', 'values', 'pop') is True
    except AssertionError:
        print('Should return True')

    # Test that has_attrs returns False when one or more given attrs are not on obj
    try:
        assert has_attrs(obj, 'keys', 'values', 'pop', 'foo') is False
    except AssertionError:
        print('Should return False')



# Generated at 2022-06-23 18:08:30.289411
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from unittest import TestCase
    import pytest

    # Make sure that dicts do NOT show up as list-like
    assert is_list_like({}) is False
    assert is_list_like({'a': 1, 'b': 2}) is False

    # Make sure that ints do NOT show up as list-like
    assert is_list_like(14) is False

    # Make sure that strs do NOT show up as list-like
    assert is_list_like('hello') is False

    # Make sure that floats do NOT show up as list-like
    assert is_list_like(1.1) is False



# Generated at 2022-06-23 18:08:37.311090
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView) is False
    assert is_subclass_of_any(obj.keys(), UserList) is False

# Generated at 2022-06-23 18:08:42.198469
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs((1, 2, 3), '__getitem__', '__iter__') is True
    assert has_attrs('hello', 'upper', '__add__', '__iter__') is True



# Generated at 2022-06-23 18:08:44.703883
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')


# Generated at 2022-06-23 18:08:48.959345
# Unit test for function has_any_callables
def test_has_any_callables():
    #create an object
    obj = {
        'get': lambda x: x
    }

    #test the function
    assert has_any_callables(obj,'keys','get') == True


# Generated at 2022-06-23 18:08:51.118827
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-23 18:08:54.645003
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import Counter

    assert is_subclass_of_any(Counter([1, 2, 1]), Counter, str) is True
    assert is_subclass_of_any('', Counter, str) is True
    assert is_subclass_of_any(Counter([1, 2, 1]), str) is False

# Generated at 2022-06-23 18:09:02.723663
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([], 'append', 'extend', 'remove', '__reversed__', '__missing__') == True
    assert has_any_callables([], 'append', 'extend', 'remove', '__reversed__', '__missing__', 'None') == True
    assert has_any_callables('string', 'append') == False
    assert has_any_callables('string', 'append', 'capitalize', 'center', 'casefold') == True
    assert has_any_callables(['string'], 'append', 'capitalize', 'center', 'casefold') == True
    assert has_any_callables(['string'], 'append', 'capitalize') == True

# Generated at 2022-06-23 18:09:08.270997
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.items(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:09:10.105974
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'foo') is True



# Generated at 2022-06-23 18:09:20.175299
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        deque,
        UserDict,
        UserString,
        ValuesView,
        KeysView,
        ChainMap,
        OrderedDict,
    )
    assert is_subclass_of_any(tuple(), UserList) is False
    assert is_subclass_of_any(tuple(), UserList, dict) is False
    assert is_subclass_of_any(dict(), UserList) is False
    assert is_subclass_of_any(list(), UserList) is True
    assert is_subclass_of_any(list(), UserList, dict) is True
    assert is_subclass_of_any(set(), UserList) is False
    assert is_subclass_of_any(frozenset(), UserList) is False
    assert is_sub

# Generated at 2022-06-23 18:09:28.473518
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import Counter

    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'jojo', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(a=1, b=2, c=3), 'get', 'keys',
                             'items', 'values', 'foo')
    assert has_any_callables(Counter(a=1, b=2, c=3), 'get', 'keys',
                             'items', 'values', 'foo')
    assert has_any_callables(Counter(a=1, b=2, c=3), 'get', 'keys', 'items', 'values')

# Generated at 2022-06-23 18:09:36.058963
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'not_a_method', 'nope', 'bad', 'evil') is False
    assert has_any_callables(dict(), 'not_a_method', 'obviously', 'not', 'this') is False
    assert has_any_callables(dict(), 'get') is True
    assert has_any_callables(dict(), 'keys') is True
    assert has_any_callables(dict(), 'items') is True
    assert has_any_callables(dict(), 'values') is True
    assert has_any_callables(dict(), 'something') is False



# Generated at 2022-06-23 18:09:46.422719
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import ChainMap
    from decimal import Decimal
    from collections import (
        OrderedDict,
        UserDict,
        UserString,
        Counter,
        defaultdict,
        deque,
        UserList,
        KeysView,
        ValuesView,
        Iterator,
    )

    assert is_list_like([1, 2, 3]) is False
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(b'\x00\x01\x02') is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter('abc')) is False

# Generated at 2022-06-23 18:09:48.025096
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for the has_any_callables function"""
    return True



# Generated at 2022-06-23 18:09:57.109133
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    # True
    assert is_subclass_of_any(ValuesView, ValuesView, KeysView, UserList)
    assert is_subclass_of_any(KeysView, ValuesView, KeysView, UserList)
    assert is_subclass_of_any(UserList, ValuesView, KeysView, UserList)
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    obj = UserList()
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList)
    # False
    assert is_subclass_of_any(obj, UserList) == False

# Generated at 2022-06-23 18:10:05.525675
# Unit test for function has_attrs
def test_has_attrs():
    def test_has_attrs_1():
        int('2')
        assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
        return

    def test_has_attrs_2():
        int('2')
        assert has_attrs(dict(), 'get', 'keys', 'items', 'foo') is False
        return

    test_has_attrs_1()
    test_has_attrs_2()
    return



# Generated at 2022-06-23 18:10:10.145886
# Unit test for function has_callables
def test_has_callables():
    '''Test function has callables'''

    assert(has_callables(dict(),'get','keys','items','values')==True)
    assert(has_callables(dict(),'get','keys','items','values1')==False)


# Generated at 2022-06-23 18:10:14.688513
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True



# Generated at 2022-06-23 18:10:26.067777
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like"""
    #
    # Test Cases
    #

# Generated at 2022-06-23 18:10:36.798621
# Unit test for function has_any_callables
def test_has_any_callables():
    import datetime

    assert has_any_callables(datetime.datetime, 'now', 'replace',
                             'strftime') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values',
                             'something') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values',
                             'something') is True
    assert has_any_callables(datetime.datetime, 'now', 'replace',
                             'strftime', 'something') is True
    assert has_any_callables(datetime.datetime, 'replace', 'something') is False
    assert has_any_callables(datetime.datetime, 'something') is False
    assert has_any_callables(dict(), 'something') is False
    assert has

# Generated at 2022-06-23 18:10:39.494490
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-23 18:10:51.240696
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        UserDict,
        ChainMap,
        ValuesView,
        KeysView,
    )
    obj1 = {'a':1, 'b':2}
    obj2 = UserDict()
    obj3 = ChainMap()
    obj4 = ValuesView(obj1)
    obj5 = KeysView(obj1)
    obj6 = UserList((1,2,3,4))

    assert is_subclass_of_any(obj1, ValuesView, KeysView) is False
    assert is_subclass_of_any(obj2, ValuesView, KeysView) is False
    assert is_subclass_of_any(obj3, ValuesView, KeysView) is False
    assert is_subclass_of_any(obj4, ValuesView, KeysView) is True
   

# Generated at 2022-06-23 18:11:03.540143
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserList, UserDict, UserString, defaultdict
    from contextlib import contextmanager
    from flutils.objutils import has_any_attrs as haa
    from types import SimpleNamespace as SimpleNS

    int_context_managers = 0
    str_context_managers = 0
    # This is an example of a context manager calculating the # of calls it
    # has been called.
    @contextmanager
    def context_manager(obj):
        nonlocal int_context_managers, str_context_managers
        if isinstance(obj, int):
            int_context_managers += 1
        elif isinstance(obj, str):
            str_context_managers += 1
        yield obj

    assert haa(dict(), 'keys', 'items', 'values') is True

# Generated at 2022-06-23 18:11:07.105834
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-23 18:11:09.920574
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-23 18:11:18.790907
# Unit test for function has_attrs
def test_has_attrs():
    print("Test has_attrs")
    f = dict(a=1, b=2)
    print("\tObject is dictionary")
    print("\tGet attribute key: ", has_attrs(f, "keys"))
    print("\tGet attribute values: ", has_attrs(f, "values"))
    print("\tGet attribute item: ", has_attrs(f, "items"))
    print("\tGet attribute get: ", has_attrs(f, "get"))




# Generated at 2022-06-23 18:11:28.319736
# Unit test for function has_any_callables
def test_has_any_callables():

    obj = dict(a=1, b=2)
    assert has_any_callables(obj.keys(), 'pop', 'add', 'remove')
    assert not has_any_callables(obj.keys(), '__add__', '__div__', '__eq__')
    assert not has_any_callables(obj.keys(), 'a', 'b')
    assert not has_any_callables(obj.keys(), '_KeysView__mapping')


# Generated at 2022-06-23 18:11:39.732505
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    import sys
    from typing import List as TList
    assert is_list_like(1) == False
    assert is_list_like(None) == False
    assert is_list_like(True) == False
    assert is_list_like(False) == False
    assert is_list_like(b'bytes') == False
    assert is_list_like({}) == False
    assert is_list_like(dict(a=1, b=2)) == False
    assert is_list_like(sys.modules) == False
    assert is_list_like(set()) == False

# Generated at 2022-06-23 18:11:46.134240
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    if is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList):
        print("Yes, it is a subclass.")

test_is_subclass_of_any()

# lst = [1, 2, 3]
# lst_reversed = reversed(lst)
# lst_sorted = sorted(lst)
# lst_generator_list = [x for x in lst]
# lst_generator_dict = ({"a": x} for x in lst)
# lst_generator_set = {x for x in lst}
# print(is_list_like(lst))
# print(is_list_like(lst_

# Generated at 2022-06-23 18:11:51.097609
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs({'hello': 'world'}, 'keys','items','values','foo')
    assert not has_any_attrs(set(),'get','keys','items','values','something')
    assert has_any_attrs(set((1,2,3)),'get','keys','items','values','something')


# Generated at 2022-06-23 18:11:56.481580
# Unit test for function has_callables
def test_has_callables():
    """Unit test of has_callables()"""

    lst = [[1, 2, 3], ('a', 'b', 'c'), ('e', 'f', 'g')]

    if has_callables(lst):
        print(lst)
    else:
        raise TypeError

if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-23 18:12:01.763248
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)



# Generated at 2022-06-23 18:12:07.615921
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'something')
    def foo():
        pass
    assert has_any_attrs(foo(),'__module__','__name__','__qualname__','__doc__')
    assert not has_any_attrs(foo(),'something')



# Generated at 2022-06-23 18:12:12.112157
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    print(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList))

# Generated at 2022-06-23 18:12:23.895580
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import namedtuple
    test_obj = namedtuple('TestObj', ['foo', 'bar', 'foobar'])
    test_obj = test_obj(foo='foo', bar='bar', foobar='foobar')
    assert has_any_attrs(test_obj, 'foo', 'bar', 'foobar') is True
    assert has_any_attrs(test_obj, 'foo', 'bar') is True
    assert has_any_attrs(test_obj, 'foo') is True
    assert has_any_attrs(test_obj, 'bar') is True
    assert has_any_attrs(test_obj, 'foobar') is True
    assert has_any_attrs(test_obj, 'baz') is False

# Generated at 2022-06-23 18:12:28.418166
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz', 'qux', 'quux') is False



# Generated at 2022-06-23 18:12:38.027390
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'update') is True
    assert has_any_callables({}, 'add') is False
    assert has_any_callables(set(), 'update') is False
    assert has_any_callables(set(), 'add') is True
    assert has_any_callables({}, 'update', 'add') is True
    assert has_any_callables({}, 'foo', 'bar') is False
    assert has_any_callables(str(), 'count') is True
    assert has_any_callables(str(), 'index') is False
    assert has_any_callables(iter([]), 'next') is True
    assert has_any_callables(iter([]), 'pop') is False
    assert has_any_callables(range(0), 'count') is False
    assert has_

# Generated at 2022-06-23 18:12:48.180724
# Unit test for function has_attrs
def test_has_attrs():
    ''' Check that the has_attrs function works as expected '''
    # Create a simple class used for testing
    class SimpleClass(object):
        def __init__(self, attr1=None, attr2=None):
            self.attr1 = attr1
            self.attr2 = attr2

    # Setup expectation that the has_attrs function returns True
    # when it should
    obj = SimpleClass(attr1='foo', attr2='bar')
    expected_result = True
    # Verify that the has_attrs function returns the expected result
    result = has_attrs(obj, 'attr1', 'attr2')
    assert expected_result == result


# Generated at 2022-06-23 18:12:52.183833
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-23 18:13:03.840141
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any(dict(a=1, b=2).keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(dict(a=1, b=2), ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(list(dict(a=1, b=2).keys()), ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(list(dict(a=1, b=2).keys()), list, ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:13:14.230086
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_list_like([1,2,3]) == True
    assert is_list_like(reversed([1,2,4])) == True
    assert is_list_like('hello') == False
    assert is_list_like(sorted('hello')) == True
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_attrs(dict(),'get','keys','items','values') == True
    assert has_call

# Generated at 2022-06-23 18:13:23.978212
# Unit test for function is_list_like
def test_is_list_like():
    # collection.abc
    #     Iterator
    #     KeysView
    #     ValuesView
    # collections
    #     deque
    #     UserList
    _list_like_collections_abc = (
        Iterator,
        KeysView,
        ValuesView
    )
    _list_like_collections = (
        deque,
        UserList
    )
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(sorted(['a', 'c', 'b'])) is True
    assert is_list_like(sorted({'a', 'c', 'b'})) is True
    assert is_list_like(sorted([], reverse=True)) is True
    assert is_list_like(sorted({}, reverse=True))

# Generated at 2022-06-23 18:13:27.983166
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-23 18:13:31.389203
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like"""
    assert is_list_like([1, 2])
    assert is_list_like(reversed([1, 2, 3]))


# Generated at 2022-06-23 18:13:37.152728
# Unit test for function has_attrs
def test_has_attrs():
    person = {'name': 'John Doe', 'age': 30}
    result = has_attrs(person, 'name', 'age')
    assert result is True
    result = has_attrs(person, 'name', 'phone')
    assert result is False

if __name__ == '__main__':
    test_has_attrs()

# Generated at 2022-06-23 18:13:41.169312
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-23 18:13:44.231954
# Unit test for function has_any_callables
def test_has_any_callables():
    assert (has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'))


# Generated at 2022-06-23 18:13:47.502290
# Unit test for function has_attrs
def test_has_attrs():

    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'values', 'keys') is True



# Generated at 2022-06-23 18:13:57.752473
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    import collections.abc
    import decimal
    import datetime
    import pathlib

    # Test true
    assert is_list_like(list()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(collections.UserList()) is True
    assert is_list_like(collections.deque()) is True
    assert is_list_like(collections.Counter()) is True
    assert is_list_like(collections.OrderedDict()) is True
    assert is_list_like(collections.defaultdict()) is True
    assert is_list_like(iter(list())) is True

# Generated at 2022-06-23 18:14:08.713556
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(obj.keys(),UserList,ValuesView,KeysView) == True
    assert is_subclass_of_any(obj.keys(),UserList,str,int) == False
    obj2 = {'a', 'b', 'c'}
    assert is_subclass_of_any(obj2,UserList,set) == True
    assert is_subclass_of_any(obj2,UserList,int,set) == True



# Generated at 2022-06-23 18:14:10.934613
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj,'get','keys','items','values','something') == True


# Generated at 2022-06-23 18:14:15.790224
# Unit test for function has_attrs
def test_has_attrs():
    o = {}
    assert has_attrs(o, 'clear', 'copy', 'setdefault', 'update') is True
    assert has_attrs(o, 'setdefault', 'update') is True
    assert has_attrs(o, 'setdefault') is True
    assert has_attrs(o, '__doc__') is True
    assert has_attrs(o, 'something') is False



# Generated at 2022-06-23 18:14:28.314365
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)

    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True)
    assert(is_subclass_of_any(obj.keys(), UserList, ValuesView, KeysView) is True)
    assert(is_subclass_of_any(obj.keys(), UserList) is False)
    assert(is_subclass_of_any(obj.keys(), str) is False)
    assert(is_subclass_of_any(obj.keys(), str, int) is False)
    assert(is_subclass_of_any(obj, dict) is True)
    assert(is_subclass_of_any(obj, list) is False)

# Generated at 2022-06-23 18:14:30.324927
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:14:34.303738
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(dict().keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(dict().keys(), str)

# Generated at 2022-06-23 18:14:39.925556
# Unit test for function has_callables
def test_has_callables():
    """ Test that the function has_callables returns the correct values.
    """
    dic1 = dict(a=1,b=2)
    dic2 = dict()

    assert(has_callables(dic1, 'get','keys','items','values') == True)
    assert(has_callables(dic2, 'get','keys','items','values') == False)


# Generated at 2022-06-23 18:14:42.683203
# Unit test for function has_attrs
def test_has_attrs():
    # the getters in object should all exist
    assert has_attrs(object, "__repr__")

    # the getters in str should all exist
    assert has_attrs(str, "__repr__")


# Generated at 2022-06-23 18:14:46.084338
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import KeysView, ValuesView

    assert is_subclass_of_any(dict(a=1).values(), KeysView, ValuesView) is True


# Generated at 2022-06-23 18:14:48.822543
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    obj = dict(a=1, b=2)
    c = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert c == True

# Generated at 2022-06-23 18:14:55.975111
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'something')
    assert has_any_attrs(set(), 'pop', 'add', 'difference', 'symmetric_difference')
    assert has_any_attrs(list(), 'append', 'extend', '__contains__')
    assert has_any_attrs(tuple(), 'count', 'index')
    assert not has_any_attrs(tuple(), 'something', 'something_else')
    assert has_any_attrs(frozenset(), 'copy', 'add', 'clear')



# Generated at 2022-06-23 18:15:04.180369
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(reversed(range(3)), '__iter__', '__next__', '__getitem__')
    assert has_any_callables(None, 'foo', 'bar') is False
    assert has_any_callables(None, 'foo', '__iter__') is False
    assert has_any_callables(None, '__getitem__', '__iter__') is False
    assert has_any_callables(5, '__getitem__', '__iter__') is False
    assert has_any_callables(False, '__getitem__', '__iter__') is False
    assert has_any_callables('foo', '__getitem__', '__iter__') is True

# Generated at 2022-06-23 18:15:10.584077
# Unit test for function has_attrs
def test_has_attrs():
    class Foo:
        def __init__(self):
            pass

        def foo(self):
            pass

        def bar(self):
            pass

    foo = Foo()
    assert has_attrs(foo,'foo','bar')
    assert has_attrs(foo,'foo','hey') is False
    assert has_attrs(foo,'foo','bar','hey') is False



# Generated at 2022-06-23 18:15:12.738412
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_attrs(dict(), "get", "keys", "items", "values", "foo") == True

# Generated at 2022-06-23 18:15:24.079621
# Unit test for function is_list_like
def test_is_list_like():
    from collections import UserList, UserDict
    from types import SimpleNamespace

    assert is_list_like([]) is True
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(UserList()) is True
    assert is_list_like(UserList([1,2,3])) is True
    assert is_list_like(UserDict({'a':1}).keys()) is True
    assert is_list_like(UserDict({'a':1}).values()) is True

# Generated at 2022-06-23 18:15:27.329908
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'something') == False
    assert has_any_attrs(dict(),'none') == False


# Generated at 2022-06-23 18:15:29.743522
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True



# Generated at 2022-06-23 18:15:34.498092
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-23 18:15:38.942748
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    assert(has_any_callables(obj, 'get', 'keys', 'values', 'something') is True)


# Generated at 2022-06-23 18:15:43.343481
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'keys', 'values') is True
    assert has_any_attrs(dict(), 'keys', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo', 'bar') is False


# Generated at 2022-06-23 18:15:51.517160
# Unit test for function has_any_callables
def test_has_any_callables():
    import inspect
    import itertools
    import functools
    
    class MyDict(dict):
        def foo(self):
            pass

    assert has_any_callables(MyDict(), 'foo') is True
    assert has_any_callables(MyDict(), 'keys', 'foo') is True
    assert has_any_callables(MyDict(), 'keys', 'foo', 'bar') is True
    assert has_any_callables(MyDict(), 'something', 'values') is False

    assert has_any_callables(dict(), 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'something', 'values') is False

    assert has_any_callables(itertools.chain, 'from_iterable') is True
    assert has_any_call

# Generated at 2022-06-23 18:15:54.054772
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    cls = type('Foo', (), dict(a=1, b=2, c=3))
    foo = cls()
    assert has_attrs(foo, 'a', 'c') is True
    assert has_attrs(foo, 'a', 'd', 'e') is False
    assert has_attrs(foo, 'a', 'b', 'c') is True



# Generated at 2022-06-23 18:16:00.502763
# Unit test for function is_list_like
def test_is_list_like():
    """

    >>> from flutils.objutils import is_list_like

    >>> is_list_like([1, 2, 3])
    True
    >>> is_list_like(reversed([1, 2, 4]))
    True
    >>> is_list_like('hello')
    False
    >>> is_list_like(sorted('hello'))
    True
    """
    pass

# Generated at 2022-06-23 18:16:02.893140
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    res = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert(res is True)

# Generated at 2022-06-23 18:16:11.668448
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    attrs = ['get', 'keys', 'values', 'items']
    result = has_any_attrs(obj, *attrs)
    assert result == True

    obj = {'a':True}
    attrs = ['get', 'keys', 'values', 'items']
    result = has_any_attrs(obj, *attrs)
    assert result == True

    obj = {'a':True}
    attrs = ['something', 'something else']
    result = has_any_attrs(obj, *attrs)
    assert result == False

