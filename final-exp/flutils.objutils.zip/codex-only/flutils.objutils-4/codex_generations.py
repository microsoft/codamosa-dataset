

# Generated at 2022-06-23 18:06:13.464995
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any('hello',ValuesView,KeysView,UserList) == False

# Generated at 2022-06-23 18:06:24.798991
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(a=1, b=2),'get','keys','items','values')
    assert not has_any_attrs(dict(a=1, b=2),'get','keys','entries')
    assert has_any_attrs(set(),'add','clear','discard','pop','remove','done')
    assert has_any_attrs(set(['a','b','c']),'add','clear','discard','pop','remove')
    assert not has_any_attrs(set(['a','b','c']),'add','clear','discard','reset')

# Generated at 2022-06-23 18:06:28.204036
# Unit test for function has_any_callables
def test_has_any_callables():
    t = has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert t == True


# Generated at 2022-06-23 18:06:38.601594
# Unit test for function has_attrs
def test_has_attrs():
    from collections import OrderedDict
    from collections.abc import MutableSequence

    dct = OrderedDict(a=1, b=2, c=3)
    setobj = set(range(10))
    listobj = list(range(10))
    tupobj = tuple(range(10))
    fzsetobj = frozenset(range(10))
    generatorobj = (i for i in range(10))
    keysviewobj = dct.keys()
    valuesviewobj = dct.values()
    userlistobj = UserList()
    userlistobj.extend(range(10))

    # True
    assert has_attrs(dct, 'keys') is True
    assert has_attrs(setobj, 'difference') is True
    assert has_attrs(listobj, 'insert')

# Generated at 2022-06-23 18:06:42.796658
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Arrange
    test_dict = dict()

    # Act
    result = has_any_attrs(test_dict, 'get', 'keys', 'items', 'values', 'something')

    # Assert
    assert result is True


# Generated at 2022-06-23 18:06:45.249161
# Unit test for function has_any_callables
def test_has_any_callables():
    l = dict(a=1, b=2)
    assert has_any_callables(l,'values','keys','foo')



# Generated at 2022-06-23 18:06:50.921537
# Unit test for function has_any_callables
def test_has_any_callables():
    a = dict(a=1,b=2,c=3,d=4)
    b = dict(a=1,b=2,c=3)
    assert has_any_callables(a, 'keys', 'values', 'items', 'foo')
    assert has_any_callables(b, 'keys', 'values', 'items')


# Generated at 2022-06-23 18:06:55.811290
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:07:01.284185
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    from collections import UserList
    assert (has_attrs(list(),'append','pop','extend')) is True
    assert (has_attrs(UserList(),'append','pop','extend')) is True
    assert (has_attrs([], 'foo', 'bar', 'baz')) is False
    assert (has_attrs(UserList(), 'foo', 'bar', 'baz')) is False


# Generated at 2022-06-23 18:07:09.064799
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Example:
        >>> from flutils.objutils import has_any_callables
        >>> has_any_callables(dict(),'get','keys','items','values','foo')
        True
    """
    print('Test:  has_any_callables')
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    print("End  :  has_any_callables")


# Generated at 2022-06-23 18:07:14.393365
# Unit test for function has_any_callables
def test_has_any_callables():

    # Case: has_any_callables(dict(),'get','keys','items','values','something')
    # Return: True
    assert has_any_callables(dict(),'get','keys','items','values','something')

    # Case: has_any_callables(dict(),'get','something','keys','items','values')
    # Return: True
    assert has_any_callables(dict(),'get','something','keys','items','values')

    # Case: has_any_callables(dict(),'get','something','keys','items')
    # Return: False
    assert not has_any_callables(dict(),'get','something','keys','items')


# Generated at 2022-06-23 18:07:26.632930
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(sorted([1, 2, 3])) is True
    assert is_list_like(sorted(['a', 'z', 'b', 'c'])) is True
    assert is_list_like(sorted('abc')) is True
    assert is_list_like('abc') is False
    assert is_list_like({'a': 1, 'b': 2}) is False
    assert is_list_like(123) is False
    assert is_list_like(123.45) is False
    assert is_list_like({'a', 'b', 'c'}) is True

# Generated at 2022-06-23 18:07:34.786090
# Unit test for function is_list_like
def test_is_list_like():

    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 3, 4]))
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello'))
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(None) is False
    assert is_list_like(42) is False
    assert is_list_like(0) is False
    assert is_list_like(0.42) is False
    assert is_list_like(1.2) is False
    assert is_list_like(-42) is False
    assert is_list_like(-0.42) is False

# Generated at 2022-06-23 18:07:38.210528
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True

# Generated at 2022-06-23 18:07:42.914252
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-23 18:07:49.694363
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(obj,'get','keys','items','values', 'pop') is False
    assert has_any_attrs(None, 'get', 'keys', 'items', 'values', 'something') is False
    assert has_any_attrs(2, 'get', 'keys', 'items', 'values', 'something') is False


# Generated at 2022-06-23 18:08:00.081631
# Unit test for function has_any_attrs
def test_has_any_attrs():
    fooobj_1 = dict(a=1, b=2, c=3)
    fooobj_2 = dict(a=1, b=2, c=3)
    fooobj_3 = dict(a=1, b=2, c=3)
    fooobj_4 = dict(a=1, b=2, c=3)
    fooobj_5 = dict(a=1, b=2, c=3)
    for fooobj in (fooobj_1, fooobj_2, fooobj_3, fooobj_4, fooobj_5):
        assert has_any_attrs(fooobj, 'get', 'keys', 'items', 'values', 'something') is True

# Generated at 2022-06-23 18:08:11.952696
# Unit test for function has_any_callables
def test_has_any_callables():
    """
    Function to test has_any_callables
    """
    # Function to test with
    def foo():
        return ''

    # Dict with an attribute that is callable
    dict_ = {'foo': foo}

    # Dict with an attribute that is not callable
    dict_2 = {'foo': 'bar'}

    # Tuple with an attribute that is callable
    tuple_ = tuple({'foo': foo})

    # Tuple with an attribute that is not callable
    tuple_2 = tuple({'foo': 'bar'})

    # List with an attribute that is callable
    list_ = [{'foo': foo}]

    # List with an attribute that is not callable
    list_2 = [{'foo': 'bar'}]

    # Check function's output
    assert has_any

# Generated at 2022-06-23 18:08:18.394677
# Unit test for function has_attrs
def test_has_attrs():
    key_objs = ['dict', 'json', 'collections.OrderedDict']
    result = []
    for key_obj in key_objs:
        result.append(has_attrs(key_obj, '__len__', '__iter__'))
    assert all(result)


# Generated at 2022-06-23 18:08:23.544639
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like.
    """
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like([1, 2, 3]) is True

# Generated at 2022-06-23 18:08:29.898049
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__missing__') is False
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__getitem__', '__missing__') is True


# Run tests for this module
if __name__ == '__main__':
    test_has_any_callables()

# Generated at 2022-06-23 18:08:33.748883
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

# Generated at 2022-06-23 18:08:38.015740
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-23 18:08:50.244686
# Unit test for function has_attrs
def test_has_attrs():
    print("\n*** has_attrs() ***")
    from collections import UserList
    from collections.abc import Iterator
    data = dict(a=1, b=2)
    obj1 = UserList(data)
    print("has_attrs(obj1, 'append', 'extend')",
          has_attrs(obj1, 'append', 'extend'))
    print("has_attrs(obj1, 'append', 'pop')",
          has_attrs(obj1, 'append', 'pop'))
    obj2 = Iterator(data.items())
    print("has_attrs(obj2, '__next__', '__iter__')",
          has_attrs(obj2, '__next__', '__iter__'))

# Generated at 2022-06-23 18:08:51.901904
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')


# Generated at 2022-06-23 18:09:01.741250
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list()) == True
    assert is_list_like([]) == True
    assert is_list_like([1, 2, 3]) == True
    assert is_list_like(UserList()) == True

    assert is_list_like(Iterator([])) == True
    assert is_list_like(reversed([])) == True
    assert is_list_like(sorted([])) == True

    assert is_list_like(KeysView({})) == True
    assert is_list_like(ValuesView({})) == True

    assert is_list_like(deque()) == True
    assert is_list_like(frozenset()) == True
    assert is_list_like(set()) == True
    assert is_list_like(tuple()) == True
    assert is_list_

# Generated at 2022-06-23 18:09:10.485652
# Unit test for function has_attrs
def test_has_attrs():
    class Foo:
        def __init__(self):
            self.foo = None

    class Bar:
        def __init__(self):
            self.bar = None

    foo = Foo()
    assert has_attrs(foo, 'foo', '__class__') is True
    assert has_attrs(foo, 'foo', '__init__') is False
    assert has_attrs(foo, 'foo', 'bar') is False

    bar = Bar()
    assert has_attrs(bar, 'bar', '__class__') is True
    assert has_attrs(bar, 'bar', '__init__') is False
    assert has_attrs(bar, 'bar', 'foo') is False


# Generated at 2022-06-23 18:09:14.414257
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get', 'keys') == True
    assert has_any_callables({}, 'get', 'keys', 'foo') == True

    # check with non-existing attr
    assert has_any_callables({}, 'get', 'keys', 'foo', 'bar') == True



# Generated at 2022-06-23 18:09:24.793983
# Unit test for function has_attrs
def test_has_attrs():
    def test_validity(obj1, obj2, attr_list):
        if has_attrs(obj1, attr_list):
            if has_attrs(obj2, attr_list):
                print(str(obj1) + " and " + str(obj2) + " have attributes " + str(attr_list))
            else:
                print(str(obj1) + " has attributes " + str(attr_list) + " but " + str(obj2) + " does not")
        else:
            if has_attrs(obj2, attr_list):
                print(str(obj1) + " does not have attributes " + str(attr_list) + " but " + str(obj2) + " does")

# Generated at 2022-06-23 18:09:29.339319
# Unit test for function has_callables
def test_has_callables():
    class A:
        def __init__(self):
            self.a = 5

        def __call__(self):
            return self.a

    d = A()
    assert has_callables(d, '__call__') is True



# Generated at 2022-06-23 18:09:37.656812
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo', 'bar', 'baz') is False
    assert has_any_attrs((1,2,3), 'foo', 'bar', 'baz') is False
    assert has_any_attrs(dict(), '__eq__', '__contains__', '__setitem__') is True


# Generated at 2022-06-23 18:09:41.280742
# Unit test for function has_attrs
def test_has_attrs():
    obj = UserList([1, 2, 3])
    assert has_attrs(obj, 'append', 'index', 'insert') is True
    assert has_attrs(obj, 'something', 'other', 'thing') is False


# Generated at 2022-06-23 18:09:43.361959
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'keys') == True


# Generated at 2022-06-23 18:09:51.954403
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs({}, 'get', 'keys', 'items', 'values') is True
    assert has_attrs({}, 'get', 'keys', 'items') is False
    assert has_attrs(list(), 'append', 'insert', 'remove', 'index', 'count') is True
    assert has_attrs(tuple(), 'append', 'insert', 'remove', 'index', 'count') is False
    assert has_attrs(set(), 'add', 'discard') is True
    assert has_attrs(set(), 'insert') is False
    assert has_attrs(frozenset(), 'add', 'discard') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items') is False


# Generated at 2022-06-23 18:09:54.988318
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )

# Generated at 2022-06-23 18:10:01.274322
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keyz', 'itemz', 'values',
                             'foo') is False
    assert has_any_callables(dict(), 'something', 'something_else',
                             'something_new') is False
    assert has_any_callables(dict(), 'update', 'clear', 'foo') is True


# Generated at 2022-06-23 18:10:04.885556
# Unit test for function has_callables
def test_has_callables():
    return has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-23 18:10:13.411015
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from flutils.objutils import is_list_like
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(sorted([1, 2, 3])) is True
    assert is_list_like(
        reversed(sorted([1, 2, 3]))
    ) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-23 18:10:17.755545
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') == True
    assert has_any_attrs('hello', 'foo', 'bar', 'upper') == True
    assert has_any_attrs('hello', 'foo', 'bar', 'baz') == False


# Generated at 2022-06-23 18:10:29.073025
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    print('Testing function is_subclass_of_any')
    obj = dict(a=1, b=2)
    keys = obj.keys()
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, UserList) is False
    assert is_subclass_of_any(obj.keys()) is False
    assert is_subclass_of_any('hello', ValuesView, UserList) is False
    assert is_subclass_of_any(obj.keys(), KeysView, ValuesView, UserList) is True
    assert is_subclass_of_any(keys, ValuesView, UserList, str) is False
    print('Done')



# Generated at 2022-06-23 18:10:39.361666
# Unit test for function has_callables
def test_has_callables():
    def assert_has_callables(obj, *attrs):
        assert has_callables(obj, *attrs) is True, \
               "has_callables should return true, got %s" % return_value

    return_value = has_callables("abc", len)
    assert return_value is False, \
        "has_callables should return false, got %s" % return_value

    return_value = has_callables("abc", "len", "split")
    assert return_value is False, \
        "has_callables should return false, got %s" % return_value

    return_value = has_callables("abc", "len", "split", "lower")
    assert return_value is True, \
        "has_callables should return true, got %s" % return_value

    return_

# Generated at 2022-06-23 18:10:50.697752
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from typing import Any as _Any

    assert has_any_callables(dict(),'get','keys','items','values','something')
    assert has_any_callables(list(),'append','extend','insert','remove')

    _LIST_LIKE = (
        list,
        set,
        frozenset,
        tuple,
        deque,
        Iterator,
        ValuesView,
        KeysView,
        UserList
    )
    assert has_any_callables(_LIST_LIKE, '__getitem__', '__setitem__', '__delitem__')


# Generated at 2022-06-23 18:10:57.959132
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get')
    assert has_callables(dict(), 'get', 'keys')
    assert has_callables(dict(), 'get', 'keys', 'values')
    assert has_callables(dict(), 'get', 'keys', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'values', 'foo') is False


# Generated at 2022-06-23 18:10:59.736878
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get', 'keys', 'items', 'something')



# Generated at 2022-06-23 18:11:03.849088
# Unit test for function has_attrs
def test_has_attrs():
    """This function tests has_attrs.
    """
    assert has_attrs(dict(),'get','keys','items','values') == True
    assert has_attrs(dict(),'get','keys','items','values', 'foo') == False



# Generated at 2022-06-23 18:11:06.513117
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','foo') is False
    assert has_callables(dict(),'get','keys','items') is True


# Generated at 2022-06-23 18:11:14.885102
# Unit test for function has_callables
def test_has_callables():
    """Test the has_callables function."""
    foo = {
        'get': lambda:None,
        'keys': lambda:None,
        'items': lambda:None,
        'values': lambda:None,
        'foo_bar': lambda:None
    }
    assert has_callables(foo, 'get') is True
    assert has_callables(foo, 'get', 'foo') is True
    assert has_callables(foo, 'foo_bar') is True
    assert has_callables(foo, 'foo_bar', 'foo') is True
    assert has_callables(foo, 'get', 'keys', 'items', 'values') is True
    assert has_callables(foo, 'get', 'foo_bar') is True
    assert has_callables(foo, 'foo_bar', 'foo') is False

# Generated at 2022-06-23 18:11:24.531407
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap, Counter, OrderedDict, UserDict, UserString
    from decimal import Decimal
    fl_obj_classes = [
        ChainMap, Counter, Decimal, OrderedDict, UserDict, UserString,
        classmethod, dict, frozenset, int, property, staticmethod, str, tuple
    ]

    # List-like objects should be considered list-like
    # noinspection PyUnresolvedReferences
    assert is_list_like([]) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like({'a': 1, 'b': 2}) is True
    assert is_list_like({1, 2, 1}) is True
    assert is_list_like(range(3)) is True

    # Non-list-like objects should not

# Generated at 2022-06-23 18:11:33.428487
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    obj = UserDict()
    result = has_callables(obj,"get","copy","clear","keys","values")
    if result == True:
        print(f"has_callables({obj}, 'get','copy','clear','keys','values') is True")
    else:
        print(f"has_callables({obj}, 'get','copy','clear','keys','values') is False")
    obj = list(range(3))
    result = has_callables(obj,"append","extend","index","insert","pop","sort")
    if result == True:
        print(f"has_callables({obj}, 'append','extend','index','insert','pop','sort') is True")

# Generated at 2022-06-23 18:11:43.059742
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from fractions import Fraction
    from itertools import (
        count,
        cycle,
        repeat,
        starmap,
        tee,
    )
    from operator import itemgetter
    from random import (
        choices,
        uniform,
        randint,
        random,
        seed,
        shuffle,
        sample,
    )
    from re import (
        findall,
        search,
    )

# Generated at 2022-06-23 18:11:46.259601
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foobar') == False
    assert has_any_callables(dict(),'__getitem__') == True


# Generated at 2022-06-23 18:11:49.269156
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Returns True if any element of attrs is an attribute of obj
    obj = dict()
    attrs = ['get', 'keys', 'something']
    assert has_any_attrs(obj, *attrs) == True


# Generated at 2022-06-23 18:11:55.688223
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    for klass in (ValuesView, KeysView, UserList):
        obj = dict(a=1, b=2)
        assert is_subclass_of_any(obj.keys(), klass)


# Get the absolute path to the directory containing this file
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-23 18:12:05.951664
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values',
                                 'something') == True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values',
                                 'not_there') == True
    assert has_any_attrs(dict(), 'not_there1', 'not_there2') == False
    assert has_any_attrs('abcd', 'upper', 'lower', 'not_there1') == True
    assert has_any_attrs('abcd', 'upper', 'lower', 'not_there1') == True


# Generated at 2022-06-23 18:12:10.543244
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'foo', 'bar', 'buzz') == False
    assert has_attrs(dict(), 'keys', 'values', 'items') == True


# Generated at 2022-06-23 18:12:20.314757
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Unit test for function is_subclass_of_any
    """

    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )

    def check(true_or_false, obj, *classes):
        """Check if true_or_false is true or false.
        """
        if is_subclass_of_any(obj, *classes) is true_or_false:
            return True
        return False

    assert check(True, dict(a=1, b=2).keys(), ValuesView, KeysView, UserList)
    assert check(False, dict(a=1, b=2).keys(), list, UserList, UserDict)
   

# Generated at 2022-06-23 18:12:29.351548
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(defaultdict(), 'get', 'keys', 'items', 'values')
    assert has_callables(Counter(), 'get', 'keys', 'items', 'values')
    assert has_callables(OrderedDict(), 'get', 'keys', 'items', 'values')
    assert has_callables(ChainMap(), 'get', 'keys', 'items', 'values')
    assert has_callables(UserDict(), 'get', 'keys', 'items', 'values')

    assert not has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_callables(defaultdict(), 'get', 'keys', 'foo', 'values')

# Generated at 2022-06-23 18:12:31.999522
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-23 18:12:39.572584
# Unit test for function has_attrs
def test_has_attrs():
    class TestAttr:
        def __init__(self, iterable, **kwargs):
            self.iterable = iterable
            self.kwargs = kwargs

    x = TestAttr([1,2,3], a=1, b=2)
    assert has_attrs(x, 'iterable', 'kwargs') is True


# Generated at 2022-06-23 18:12:43.775424
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    return True


# Generated at 2022-06-23 18:12:49.828866
# Unit test for function has_any_callables
def test_has_any_callables():
    # Arrange
    obj = dict(a=1, b=2)

    # Act
    result = has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    result2 = has_any_callables(obj, 'foo', 'bar')

    # Assert
    assert result is True
    assert result2 is False


# Generated at 2022-06-23 18:12:57.834634
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from unittest import TestCase, main
    from collections import Counter
    from flutils.objutils import has_any_attrs
    from datetime import date
    l = list()
    d = dict()
    t = tuple()
    c = Counter()
    s = set()
    f = frozenset()
    od = date(2020, 1, 1)
    class Foo(object):
        pass
    class Bar(Foo):
        pass
    f = Foo()
    b = Bar()
    class Test_has_any_attrs(TestCase):
        def test_obj_has_not_any_attrs(self):
            rv = has_any_attrs(
                obj=f,
                *['something', 'nothing', 'foo', 'bar']
            )

# Generated at 2022-06-23 18:13:01.770746
# Unit test for function has_attrs
def test_has_attrs():
    print('Test has_attrs')
    assert has_attrs(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:13:04.963470
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like('hello') is False
    assert is_list_like((1, 2)) is True
    assert is_list_like([1, 2]) is True
    assert is_list_like(range(100)) is True



# Generated at 2022-06-23 18:13:13.216641
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import OrderedDict
    assert has_callables([1, 2, 3, 4], 'append', 'index', 'pop')
    assert has_callables(OrderedDict([('a', 1), ('b', 2), ('c', 3)]),
                         'append', 'index', 'pop')
    assert not has_callables([1, 2, 3, 4], 'append', 'index', 'pop', 'foo')
    assert not has_callables("hello", 'append', 'index', 'pop', 'foo')



# Generated at 2022-06-23 18:13:15.169689
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'clear') == True



# Generated at 2022-06-23 18:13:20.691914
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:13:31.328537
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(Iterator([])) is True
    assert is_list_like(ValuesView({})) is True
    assert is_list_like(KeysView({})) is True
    assert is_list_like(UserList()) is True

    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(True) is False
    assert is_list_like(bytes()) is False
    assert is_list_like(dict()) is False

# Generated at 2022-06-23 18:13:35.956827
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # obj = dict(a=1, b=2)
    obj = [1,2]
    obj_type = is_subclass_of_any(obj,ValuesView,KeysView,UserList)
    assert obj_type is True

# Generated at 2022-06-23 18:13:43.922490
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like.
    """

    # Uncomment the following lines and run the unit test
    # import sys
    # sys.modules.pop('flutils', None)
    # import flutils

    from flutils.objutils import is_list_like
    testlist = ['hello', [1, 2, 3], set('hello'), frozenset({1, 2, 3})]
    for x in testlist:
        print('{}: {}'.format(type(x), is_list_like(x)))
    # <class 'str'>: False
    # <class 'list'>: True
    # <class 'set'>: True
    # <class 'frozenset'>: True


# Run unit tests for this module
if __name__ == '__main__':
    test_is_list_like

# Generated at 2022-06-23 18:13:53.745175
# Unit test for function is_list_like
def test_is_list_like():
    from collections import UserList, ChainMap, Counter, OrderedDict, UserDict
    from collections import defaultdict
    from collections.abc import Iterator, KeysView, ValuesView
    from collections import deque, frozenset
    from decimal import Decimal
    from flutils.objutils import is_list_like
    assert is_list_like([]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(UserList('hello')) is True
    assert is_list_like(Iterator([])) is True
    assert is_list_like(ValuesView({'a': 1, 'b': 2})) is True
    assert is_list_like(KeysView({'a': 1, 'b': 2})) is True

# Generated at 2022-06-23 18:14:05.807970
# Unit test for function is_list_like
def test_is_list_like():
    """Test function is_list_like
    """

    from collections import (
        UserDict,
        UserList,
        UserString,
        chainmap,
        Counter,
        OrderedDict,
    )
    from collections.abc import (
        Iterable,
        Iterator,
        KeysView,
        ValuesView,
    )
    from decimal import Decimal
    from math import (
        degrees,
        radians,
    )
    from typing import (
        Any,
        Callable,
        ChainMap,
        Counter as _Counter,
        Dict,
        List,
        Set,
        Union,
    )

    # Test with None
    assert is_list_like(None) is False # type: ignore

    # Test with a callable

# Generated at 2022-06-23 18:14:09.429950
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True)


# Generated at 2022-06-23 18:14:13.744315
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    # >>> obj.keys()
    # dict_keys(['a', 'b'])
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-23 18:14:24.141900
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict(a=1, b=2),'get','keys','items','values')
    assert has_attrs(dict(a=1, b=2),'get','keys','items','values',
                              '__eq__','__bool__','__add__',
                              '__repr__','__contains__','__mul__')
    assert has_attrs(dict(),'setdefault')
    assert has_attrs(dict(),'get','keys','items','values','__len__')



# Generated at 2022-06-23 18:14:28.535744
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView,KeysView,UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True

# Generated at 2022-06-23 18:14:31.808917
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections.abc import Iterable
    test_list = [
        has_any_callables(dict(),'get','keys','items','values','foo'),
        has_any_callables(dict().__class__.__dict__, 'get', 'keys', 'items', 'values', 'foo')
    ]
    assert all(test_list) is True


# Generated at 2022-06-23 18:14:35.709151
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import Counter
    from flutils.objutils import has_any_attrs
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:14:41.508346
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    assert has_callables(dict, "get", "keys")
    assert not has_callables(dict, "get", "keys", "test")
    assert not has_callables(1, "test1", "test2")
    assert has_callables({}, "values")
    assert has_callables(deque(['A', 'B', 'C']), "append", "popleft")


# Generated at 2022-06-23 18:14:51.303961
# Unit test for function has_callables
def test_has_callables():
    print('Testing has_callables')
    """Check if given ``obj`` has all the given ``attrs`` and are callable."""
    obj = dict()
    assert has_callables(obj,'get','keys','items','values') is True
    assert has_callables(obj,'get','keys','items','something') is False
    assert has_callables(obj,'get','something','items','values') is False
    assert has_callables(obj,'get','keys','something','values') is False
    assert has_callables(obj,'get','something','items','something') is False
    assert has_callables(obj,'something','keys','items','values') is False
    assert has_callables(obj,'something','something','items','values') is False
    assert has_callables(obj,'something','keys','something','values') is False


# Generated at 2022-06-23 18:14:52.939739
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')



# Generated at 2022-06-23 18:14:54.426307
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:14:59.757830
# Unit test for function has_attrs
def test_has_attrs():
    o = dict(key='value')
    print(has_attrs(o, 'pop', 'keys', 'items'))
    print(has_attrs(o, 'pop', 'keys', 'foo'))
    print(has_attrs(1, '__add__', '__int__'))
    print(has_attrs(1, '__add__', '__float__'))


# Generated at 2022-06-23 18:15:01.294963
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:15:14.352048
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.items(), ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, dict) is True
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(obj, list, tuple) is False


# Generated at 2022-06-23 18:15:25.427514
# Unit test for function has_attrs
def test_has_attrs():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from email.message import Message
    from io import (
        BufferedIOBase,
        BytesIO,
        RawIOBase,
        StringIO,
    )

    from flutils.objutils import has_attrs

    assert has_attrs(True, '__bool__') is True
    assert has_attrs(False, '__bool__') is True
    assert has_attrs(None, '__bool__') is False

    assert has_attrs(1, '__add__', '__bool__') is True

# Generated at 2022-06-23 18:15:26.851018
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(list(),'append','insert','extend','pop') == True



# Generated at 2022-06-23 18:15:36.272489
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test with empty attrs
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj,) is False
    # Test with empty dict
    obj = dict()
    assert has_any_attrs(obj,'keys') is True
    # Test with a dict and a list
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj,'keys', 'extend') is True
    # Test two dicts
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj,'keys','items','values','foo') is True

# Generated at 2022-06-23 18:15:39.128215
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'foo','bar','baz','quux','norf') == False


# Generated at 2022-06-23 18:15:44.412907
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test function is_subclass_of_any."""
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:15:47.876250
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    print("Test is_subclass_of_any")
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList))
    print("Done")

if __name__ == "__main__":
    test_is_subclass_of_any()

# Generated at 2022-06-23 18:15:55.087635
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_attrs({'get': 1, 'keys': 2}, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_attrs(dict(), 'foo', 'bar')
    assert not has_any_attrs({}, 'foo', 'bar')


# Generated at 2022-06-23 18:15:58.225454
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj,'get','keys','items','values','something')


# Generated at 2022-06-23 18:16:02.850368
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict({'value':'value'}),'get','keys','items','values','something')
    assert has_any_attrs({'val':'val'},'get','keys','items','values','something')


# Generated at 2022-06-23 18:16:13.924369
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from collections.abc import (
        AsyncGenerator,
        Awaitable,
        ByteString,
        Callable,
        Collection,
        Container,
        Coroutine,
        Hashable,
        Iterable,
        Iterator,
        ItemsView,
        KeysView,
        Mapping,
        MappingView,
        MutableMapping,
        MutableSequence,
        MutableSet,
        MutableSequence,
        Sized,
        Sequence,
        Set,
    )
    from decimal import Decimal
    from numbers import (
        Complex,
        Real
    )