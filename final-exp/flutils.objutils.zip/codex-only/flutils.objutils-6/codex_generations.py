

# Generated at 2022-06-23 18:06:10.059704
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    expected = True
    actual = has_any_callables(obj, 'values', 'keys', 'items')
    assert expected == actual


# Generated at 2022-06-23 18:06:12.008372
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-23 18:06:14.033875
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'keys', 'items', 'values')

# Generated at 2022-06-23 18:06:25.302062
# Unit test for function has_callables
def test_has_callables():
    import collections
    import copy
    import json
    import os
    import re
    import shutil
    import sys
    import yaml

# Generated at 2022-06-23 18:06:28.899287
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), "get", "keys", "items", "values", "something")
    assert has_any_attrs(dict(), "get", "keys", "items", "values", "something")
    assert not has_any_attrs(dict(), "foo", "bar")


# Generated at 2022-06-23 18:06:32.096071
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get') is False
    assert has_callables(dict(), 'foo') is False


# Generated at 2022-06-23 18:06:35.216270
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False


# Generated at 2022-06-23 18:06:41.955688
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    def func(list1, *list2, **list3):
        func.call_count += 1
        for i, j in zip(list1, list2):
            if j is not i:
                raise Exception(f'{i} is not {j}')
        for i, j in list3.items():
            if j is not i:
                raise Exception(f'{i} is not {j}')

    func.call_count = 0

    a = [1, 2, 3]
    b = [1, 2]
    c = [2, 3]

    func.call_count = 0
    func([1, 2, 3], a)
    assert func.call_count == 1
    func(a, a)
    assert func.call_count == 2
    func(a, b, c)

# Generated at 2022-06-23 18:06:49.453928
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any(dict().keys(), ValuesView, KeysView, UserList) is True
    from decimal import Decimal as _Decimal
    assert is_subclass_of_any(
        _Decimal('1.0'),
        ValuesView,
        KeysView,
        UserList,
        float,
        int,
        str
    ) is False



# Generated at 2022-06-23 18:06:52.116920
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserDict
    from flutils.objutils import has_any_callables
    assert has_any_callables(UserDict(), 'clear', 'data', '___getattribute___') is True


# Generated at 2022-06-23 18:07:01.991037
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString
    )
    from decimal import Decimal
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(b'hello') is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(None) is False
    assert is_list_like('hello') is False
    assert is_list_like(1) is False
    assert is_list_like(float) is False
    assert is_list_like

# Generated at 2022-06-23 18:07:08.245742
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert not is_list_like('hello')
    assert is_list_like(sorted('hello'))

# Generated at 2022-06-23 18:07:14.749484
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import MutableMapping, MutableSequence
    from decimal import Decimal
    from flutils.objutils import is_list_like

    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(deque()) is True
    assert is_list_like((x for x in range(0, 10))) is True
    assert is_list_like({}.values()) is True
    assert is_list_like({}.keys()) is True
    assert is_list_like

# Generated at 2022-06-23 18:07:16.744129
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-23 18:07:18.528866
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:07:30.138284
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'keys', 'items', 'values') is True
    assert has_callables(obj, 'get', 'keys', 'items') is True
    assert has_callables(obj, 'keys', 'items') is True
    assert has_callables(obj, 'get', 'values') is True
    assert has_callables(obj, 'values') is True
    assert has_callables(obj, 'get', 'keys') is True
    assert has_callables(obj, 'keys') is True
    assert has_callables(obj, 'get') is True
    assert has_callables(obj, 'foo') is False


# Generated at 2022-06-23 18:07:36.329479
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3]) == True;
    assert is_list_like(reversed([1,2,3])) == True;
    assert is_list_like('hello') == False;
    assert is_list_like(sorted('hello')) == True;

if __name__ == '__main__':
    test_is_list_like();

# Generated at 2022-06-23 18:07:40.601553
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        ValuesView,
        KeysView
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:07:44.754170
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class Foo:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    foo = Foo(1,2)
    assert has_any_attrs(foo,"a")
    assert not has_any_attrs(foo,"c")
    assert not has_any_attrs(foo,"c","d","e")


# Generated at 2022-06-23 18:07:46.939560
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True, \
           'has_callables() failed.'

# Generated at 2022-06-23 18:07:53.732243
# Unit test for function has_callables
def test_has_callables():
    class A:
        def __init__(self, a: bool):
            self.a = a

        def foo(self):
            return True

    assert has_callables(A(True), 'a', 'foo') is True
    assert has_callables(A(True), 'foo') is True
    assert has_callables(A(True), 'foo', 'bar') is False
    assert has_callables(A(True), 'bar') is False

# Generated at 2022-06-23 18:07:58.051414
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import UserList
    lst = [1, 2, 3, 4]
    assert is_subclass_of_any(lst, list, UserList) == True
    assert is_subclass_of_any(UserList(lst), list, UserList) == True


# Generated at 2022-06-23 18:08:00.523749
# Unit test for function has_any_attrs
def test_has_any_attrs():
    os.chdir('../')

    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values','foo') is True
    assert has_any_attrs(dict(), 'foo') is True



# Generated at 2022-06-23 18:08:03.863057
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([], 'append', 'sort', 'foo')

# Generated at 2022-06-23 18:08:12.796615
# Unit test for function has_attrs

# Generated at 2022-06-23 18:08:25.477556
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'__setitem__','__getitem__') == True
    assert has_callables(dict(),'__setitem__','__getitem__','foo') == False
    assert has_callables(dict(),'__setitem__') == True
    assert has_callables(dict(),'foo') == False
    assert has_callables(dict(),'pop') == False
    assert has_callables(dict(),'pop',default=6) == True
    assert has_callables(dict()) == False
    assert has_callables(list(),'append','pop','remove','extend','index','sort','reverse','insert') == True
    assert has_callables(tuple(),'index','count') == True

# Generated at 2022-06-23 18:08:28.701447
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(),'get','keys','items','values','something') is True)
    assert(has_any_attrs(dict(),'foo','bar') is False)
    assert(has_any_attrs('foo','upper','get','bar') is True)


# Generated at 2022-06-23 18:08:32.972963
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(set(),'pop','keys','items','values','something')


# Generated at 2022-06-23 18:08:42.539955
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Check that an object has all the given attrs.
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True,\
        "dict has all the given attrs."
    assert has_any_attrs(dict(),'get','keys','items','values','something','foo') == True,\
        "dict has all the given attrs."
    # Check that an object does NOT have all the given attrs.
    assert has_any_attrs(dict(),'get','keys','items','values','foo') == False,\
        "dict does not have all the given attrs."


# Generated at 2022-06-23 18:08:49.429799
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, 'get') is False
    assert has_any_callables(dict, 'get') is True
    assert has_any_callables(dict, 'get', 'keys') is True
    assert has_any_callables(dict.keys, 'get', 'keys') is True
    assert has_any_callables(dict().keys(), 'get', 'keys') is True


# Generated at 2022-06-23 18:08:51.901539
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','items','keys','values') == True
    assert has_attrs(dict(),'get','items','keys','bar') == False


# Generated at 2022-06-23 18:08:54.426805
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'foo') is False



# Generated at 2022-06-23 18:08:58.839817
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items','values','__repr__') == True


# Generated at 2022-06-23 18:09:06.056649
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo')
    assert has_any_attrs(dict(),'get','keys','items','something')
    assert has_any_attrs(dict(),'get','something','items','values')
    assert has_any_attrs(dict(),'keys','items','something','values')
    assert has_any_attrs(dict(),'something','values')



# Generated at 2022-06-23 18:09:10.787747
# Unit test for function has_any_attrs
def test_has_any_attrs():
    '''Function: test_has_any_attrs'''
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'foo','bar','baz') is False


# Generated at 2022-06-23 18:09:12.891586
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-23 18:09:20.502987
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is not False
    assert not is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is False



# Generated at 2022-06-23 18:09:27.752765
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1)
    failed = [k for k in dir(obj) if has_callables(obj, k) is False]
    assert failed == ['clear', 'copy', 'fromkeys', 'get', 'items',
                      'keys', 'pop', 'popitem', 'setdefault', 'update',
                      'values', '__contains__', '__eq__', '__getitem__',
                      '__ge__', '__gt__', '__iter__', '__len__',
                      '__le__', '__lt__', '__ne__', '__repr__',
                      '__setitem__', '__sizeof__']



# Generated at 2022-06-23 18:09:38.715980
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections.abc import KeysView, ValuesView
    from collections import UserList
    obja = dict(a=1, b=2).values()
    objb = 'hello'
    objc = dict(a=1, b=2).keys()
    objd = dict(a=1, b=2)
    print(is_subclass_of_any(obja, ValuesView, KeysView, UserList))
    print(is_subclass_of_any(objb, ValuesView, KeysView, UserList))
    print(is_subclass_of_any(objc, ValuesView, KeysView, UserList))
    print(is_subclass_of_any(objd, ValuesView, KeysView, UserList))



# Generated at 2022-06-23 18:09:40.205553
# Unit test for function has_callables
def test_has_callables():
    assert(has_callables(dict(),'get','keys','items','values') == True)

# Generated at 2022-06-23 18:09:42.381668
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') == True


# Generated at 2022-06-23 18:09:46.473937
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    from collections import (
        Counter,
        UserList
    )

    assert is_subclass_of_any(Counter(), Counter, UserList) is True
    assert is_subclass_of_any(Counter(), UserList) is False

    assert is_subclass_of_any(dict(), UserList) is False

# Generated at 2022-06-23 18:09:47.513893
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(foo=0),'foo','bar') is True
    assert has_any_attrs(dict(),'foo','bar') is False


# Generated at 2022-06-23 18:09:57.018706
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == True
    assert has_callables(dict(),'something','foo','bar','baz') == False
    assert has_callables('fred','upper','lower','swapcase','join','foo') == True
    assert has_callables('fred','upper','lower','swapcase','join') == True
    assert has_callables('fred','upper','lower','swapcase') == True
    assert has_callables('fred','upper','lower') == True
    assert has_callables('fred','upper') == True
    assert has_callables('fred',) == False
    assert has_callables('fred','something') == False

# Generated at 2022-06-23 18:10:00.333661
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values' 'foo') is True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') is False



# Generated at 2022-06-23 18:10:05.682724
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # we have this assertion
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    # we don't have this assertion
    assert not has_any_attrs(dict(),'bar')


# Generated at 2022-06-23 18:10:08.880232
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello'))

# Generated at 2022-06-23 18:10:11.278841
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')



# Generated at 2022-06-23 18:10:18.879803
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1,2,4]))
    assert is_list_like(set([1,2,3]))
    assert is_list_like(frozenset([1,2,3]))
    assert is_list_like(tuple([1,2,3]))
    assert is_list_like(deque([1,2,3]))
    assert is_list_like(sorted('hello'))

test_is_list_like()


# Generated at 2022-06-23 18:10:24.278897
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'copy') == True


# Generated at 2022-06-23 18:10:35.271736
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for fucntion is_list_like()"""
    from flutils.objutils import is_list_like
    from decimal import Decimal
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from typing import (
        Any,
        AnyStr,
        Iterator,
        Iterable,
        List,
        Union,
    )
    primitive_types = (
        Any,
        AnyStr,
        Iterator,
        Iterable,
        List,
        str,
        Union,
        bool,
        bytes,
        Decimal,
        dict,
        float,
        int,
        set,
        tuple,
    )

# Generated at 2022-06-23 18:10:38.444752
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj, 'get', 'items', 'keys', 'values') is True
    assert has_any_attrs(obj, 'bar', 'baz') is False



# Generated at 2022-06-23 18:10:41.163078
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values',
                             'foo') is True
    assert has_any_callables(dict(), 'foo') is False


# Generated at 2022-06-23 18:10:49.407362
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    import decimal
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any(dict(a=1, b=2).keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(decimal.Decimal(1.5), decimal.Decimal) is True
    assert is_subclass_of_any("Hello", str) is True
    assert is_subclass_of_any("Hello", tuple) is False
    assert is_subclass_of_any("Hello", list) is False

# Generated at 2022-06-23 18:11:00.027156
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        ValuesView,
        KeysView,
        deque,
    )
    obj = 1
    assert is_subclass_of_any(obj,int,str,float) == True
    obj = 'a'
    assert is_subclass_of_any(obj,int,str,float) == True
    obj = 1.1
    assert is_subclass_of_any(obj,int,str,float) == True
    obj = dict(a=1,b=2)
    assert is_subclass_of_any(obj.keys(),KeysView,UserList,deque) == True
    assert is_subclass_of_any(obj.values(),ValuesView,UserList,deque) == True
    obj = UserList(['a','b','c'])

# Generated at 2022-06-23 18:11:04.177648
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, "get", "keys", "items", "values") is True, (
        "has_callables() method is not working correctly")
    assert has_callables(dict, "get", "something") is False, (
        "has_callables() method is not working correctly")
    assert has_callables(dict, "keys", "something") is False, (
        "has_callables() method is not working correctly")
    assert has_callables(dict, "keys", "items", "values", "foo") is False, (
        "has_callables() method is not working correctly")



# Generated at 2022-06-23 18:11:06.807993
# Unit test for function has_attrs
def test_has_attrs():
    obj = {}
    attrs = ('get', 'keys', 'items', 'values')

    assert has_attrs(obj, *attrs) is True



# Generated at 2022-06-23 18:11:10.557862
# Unit test for function has_callables
def test_has_callables():
    # Check that it passes
    obj = dict()
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    # Check that it fails
    obj = object()
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is False


# Generated at 2022-06-23 18:11:16.019415
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({1:'1'}, 'get', 'keys', 'foo', 'values') == True
    assert has_any_callables({1:'1'}, 'get', 'keys', 'foo', 'foo2') == False


# Generated at 2022-06-23 18:11:24.769301
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),
                              ValuesView,
                              KeysView,
                              UserList) is True
    assert is_subclass_of_any(obj.keys(),
                              ValuesView,
                              UserList) is True
    assert is_subclass_of_any(obj.keys(),
                              ValuesView) is True
    assert is_subclass_of_any(obj.keys(),
                              UserList) is False
    assert is_subclass_of_any(obj.keys(),
                              UserList,
                              ValuesView,
                              KeysView) is True



# Generated at 2022-06-23 18:11:33.548310
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo') == True
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(list(),'count','index','foo') == True
    assert has_any_attrs(list(),'count','index','something') == True
    assert has_any_attrs(set(),'add','pop','foo') == True
    assert has_any_attrs(set(),'add','pop','something') == True
    assert has_any_attrs(tuple(),'count','index','foo') == True
    assert has_any_attrs(tuple(),'count','index','something') == True
    assert has_any_attrs('something', 'find', 'rfind', 'foo')

# Generated at 2022-06-23 18:11:36.331958
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get2','keys2','items2','values2','foo2') == False


# Generated at 2022-06-23 18:11:47.535413
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict(),'get',
        'keys',
        'items',
        'values',
    )
    assert has_attrs('foo','count','encode','islower','isupper')
    assert has_attrs('foo',
        'count',
        'encode',
        'islower',
        'isupper',
    )
    assert has_attrs('foo','count')
    assert has_attrs('foo','count',
        'encode',
        'islower',
        'isupper',
    )
    assert not has_attrs('foo','count','encode','islower','isupper','foobar')

# Generated at 2022-06-23 18:11:55.506641
# Unit test for function has_attrs
def test_has_attrs():
    # Test that object contains at least one of the given attributes
    assert has_attrs([], 'append', '__contains__', '__getitem__') == True
    # Test that object contains more than one of the given attributes
    assert has_attrs([], '__contains__', '__getitem__', '__setitem__') == True
    # Test that object contains none of the given attributes
    assert has_attrs([], 'foo', 'bar', 'baz') == False



# Generated at 2022-06-23 18:11:58.854269
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert not is_subclass_of_any(obj,ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:12:03.470094
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(get=1, keys=2, items=3)
    assert has_attrs(obj, 'get', 'keys', 'items') is True
    assert has_attrs(obj, 'get', 'keys', 'something') is False


# Generated at 2022-06-23 18:12:08.252604
# Unit test for function has_attrs
def test_has_attrs():
    obj = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert has_attrs(obj, 'a', 'b') is True
    assert has_attrs(obj, 'a', 'b', 'e') is False
    assert has_attrs(obj, 'a', 'b', 'e', 'f') is False



# Generated at 2022-06-23 18:12:13.866802
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs."""
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'a', 'b', 'c', 'd') is True
    assert has_any_attrs(obj, 'x', 'y', 'z', 'w') is False



# Generated at 2022-06-23 18:12:17.960488
# Unit test for function has_callables
def test_has_callables():
    test_obj = dict()
    test_obj['get'] = lambda: None
    test_obj['keys'] = {}
    test_obj['items'] = {}
    test_obj['values'] = {}
    print(has_callables(test_obj, 'get', 'keys', 'items', 'values'))

# Generated at 2022-06-23 18:12:24.256549
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print('Executing function test_has_any_attrs')
    assert (
        has_any_attrs(dict(), 'get', 'keys', 'items', 'values') 
        is True
    )
    assert (
        has_any_attrs(dict(), 'get', 'keys', 'items', 'foo') 
        is True
    )
    assert (
        has_any_attrs(dict(), 'foo', 'bar') 
        is False
    )
    assert (
        has_any_attrs(dict(),) 
        is False
    )
    assert (
        has_any_attrs(None, 'foo', 'bar') 
        is False
    )
    assert (
        has_any_attrs(None,) 
        is False
    )

# Generated at 2022-06-23 18:12:26.109293
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something') is True

# Generated at 2022-06-23 18:12:37.074415
# Unit test for function has_attrs
def test_has_attrs():
    from datetime import datetime
    from typing import List, Iterable
    from flutils.objutils import has_attrs
    from flutils.objutils import has_callables

    # A list of attribute names to be tested for existence on various objects
    ATTRS = ['__name__', '__getitem__', '__init__',
             'datetime', 'date', 'time', 'timedelta']

    assert has_attrs(datetime, *ATTRS)
    assert has_callables(datetime, *ATTRS)

    assert not has_attrs(datetime, *'__datetime__')
    assert not has_callables(datetime, *'__datetime__')

    assert has_attrs(List, *'__iter__')

# Generated at 2022-06-23 18:12:39.521872
# Unit test for function has_attrs
def test_has_attrs():
    obj=dict()
    assert has_attrs(obj,'get','keys','items','values')

# Generated at 2022-06-23 18:12:51.455826
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    col = collections
    d1 = list(range(0, 5))
    print(d1)

    d2 = col.deque(range(0, 5))
    print(d2)

    d3 = tuple(range(0, 5))
    print(d3)
    d4 = col.defaultdict(lambda: "No Value")
    d4[0] = "Test default dict"
    print(d4)

    d5 = col.UserList([1, 2, 3])
    print(d5)
    d6 = col.UserDict([[0, 1], [2, 3]])
    print(d6)
    d7 = col.UserString("")
    print(d7)
    d8 = col.Counter([1, 2, 3])
    print(d8)

# Generated at 2022-06-23 18:12:56.975879
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(),'get','keys','items','values','something') == True)
    assert(has_any_attrs([1,2,3,4],'get','keys','items','values','something') == False)
    assert(has_any_attrs([1,2,3,4],'append', 'triple', 'double', 'something') == True)
    assert(has_any_attrs('hello', 'append', 'triple', 'double', 'something') == False)


# Generated at 2022-06-23 18:13:03.537963
# Unit test for function is_list_like
def test_is_list_like():
    obj = [1]
    assert is_list_like(obj) == True
    obj = reversed([1])
    assert is_list_like(obj) == True
    obj = 'hello'
    assert is_list_like(obj) == False
    obj = 1
    assert is_list_like(obj) == False
    obj = None
    assert is_list_like(obj) == False
    obj = dict(a=1)
    assert is_list_like(obj) == False



# Generated at 2022-06-23 18:13:07.236279
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True


# Generated at 2022-06-23 18:13:12.684957
# Unit test for function has_callables
def test_has_callables():
    """
    Test for function has_callables
    """
    obj = dict(a = 1)
    attrs = ('get', 'values')
    print(has_callables(obj, *attrs))
    attrs = ('getfoo', 'values')
    print(has_callables(obj, *attrs))



# Generated at 2022-06-23 18:13:15.997655
# Unit test for function is_list_like
def test_is_list_like():
    """Basic tests for proper functionality of is_list_like()."""
    assert is_list_like('Hello') is False
    assert is_list_like(['a', 'b']) is True
    assert is_list_like(reversed(['a', 'b'])) is True


# Generated at 2022-06-23 18:13:26.642181
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import Counter, UserDict, UserList

    obj = dict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'somethingelse') is False

    obj = UserDict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'somethingelse') is False

    obj = Counter()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something') is True

# Generated at 2022-06-23 18:13:30.451388
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert not has_any_callables(dict(),'get','keys','items','values','foo')
    assert not has_any_callables('123', 'do_something')

# Generated at 2022-06-23 18:13:33.692428
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:13:42.774502
# Unit test for function has_callables
def test_has_callables():

    # Arrange
    import inspect
    import functools
    import operator

    result = has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert result, 'Fail 1'

    result = has_callables(dict(), 'foo', 'bar', 'baz', 'quux')
    assert not result, 'Fail 2'

    result = has_callables(inspect, 'getdoc', 'getsource', 'getcomments', 'foo')
    assert result, 'Fail 3'

    result = has_callables(functools, 'partial', 'update_wrapper', 'wraps', 'foo')
    assert result, 'Fail 4'

    result = has_callables(operator, 'add', 'mul', 'sub', 'div', 'mod')
    assert result, 'Fail 5'

    result = has

# Generated at 2022-06-23 18:13:48.698590
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(list(), 'append', 'clear', 'copy', 'extend') == True
    assert has_any_callables('hello', 'center', 'ljust', 'rjust') == True



# Generated at 2022-06-23 18:13:55.503845
# Unit test for function is_list_like
def test_is_list_like():
    #
    # Test list
    #
    assert is_list_like([1, 2, 3]) is True
    #
    # Test set
    #
    assert is_list_like({1, 2, 3}) is True
    #
    # Test frozenset
    #
    assert is_list_like(frozenset([1, 2, 3])) is True
    #
    # Test tuple
    #
    assert is_list_like((1, 2, 3,)) is True
    #
    # Test deque
    #
    assert is_list_like(deque([1, 2, 3])) is True
    #
    # Test Iterator
    #
    assert is_list_like(iter([1, 2, 3])) is True
    #
    # Test ValuesView
    #
   

# Generated at 2022-06-23 18:13:57.640528
# Unit test for function has_any_callables
def test_has_any_callables():
    # Setup
    obj = dict(a=1, b=2)

    # Exercise
    result = has_any_callables(obj, 'get', 'keys', 'something')
    expected = True

    # Verify
    assert result == expected



# Generated at 2022-06-23 18:14:09.019082
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    from collections import ValuesView, KeysView, UserList, OrderedDict

    # dict is not subclass of OrderedDict, but OrderedDict is subclass of dict
    assert is_subclass_of_any(OrderedDict, dict)

    # ValuesView is subclass of UserList
    assert is_subclass_of_any(ValuesView, UserList, dict)
    assert not is_subclass_of_any(KeysView, UserList, dict)

    obj = dict(a=1, b=2)

    # obj.keys() is subclass of ValuesView, KeysView, UserList
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

    # int is not subclass of tuple, list
    assert not is_subclass_of_any(2, tuple, list)

# Generated at 2022-06-23 18:14:17.525826
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import (
        OrderedDict,
        defaultdict,
        Counter,
        ChainMap
    )
    from collections.abc import (
        Mapping,
        MutableMapping,
        Hashable,
        Sequence,
        MutableSequence,
        Set,
        MutableSet,
    )
    from decimal import Decimal
    from flutils.objutils import (
        has_any_attrs,
        has_any_callables,
        has_attrs,
        has_callables,
        is_list_like,
    )
    from flutils.py23 import (
        is_str,
        is_bytes,
        is_unicode,
    )
    from io import StringIO
    from json import loads
    from random import randint

# Generated at 2022-06-23 18:14:19.491552
# Unit test for function has_attrs
def test_has_attrs():
    class Foo:
        def __init__(self, _t):
            self.t = _t

        def get(self):
            return self.t

    f = Foo(1)
    assert has_attrs(f, 't', 'get')



# Generated at 2022-06-23 18:14:23.622902
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'fuzzy_bunny', 'values') is False



# Generated at 2022-06-23 18:14:28.849598
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(a=1,b=2),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(a=1,b=2),'get','keys','items','values','something','fubar') == True
    assert has_any_attrs(dict(a=1,b=2),'get','keys','items','something','fubar') == True
    assert has_any_attrs(dict(a=1,b=2),'get','keys','items','something','fubar','fubar') == True

# Generated at 2022-06-23 18:14:34.110966
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict, 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict, 'get', 'keys', 'items', 'tuple')



# Generated at 2022-06-23 18:14:35.984746
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert not has_any_callables(dict(),'foo','bar','baz','qux','quux')


# Generated at 2022-06-23 18:14:46.086709
# Unit test for function is_list_like
def test_is_list_like():
    list_like_objects = [
        [],
        deque(),
        dict(),
        frozenset(),
        iter([]),
        KeysView(dict()),
        list(),
        set(),
        tuple(),
        UserList()
    ]


# Generated at 2022-06-23 18:14:57.113957
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like({1: 'a', 2: 'b', 3: 'c'}) is False
    assert is_list_like({1, 2, 3}.keys()) is True
    assert is_list_like({1, 2, 3}.values()) is True

# Generated at 2022-06-23 18:15:05.491417
# Unit test for function is_list_like
def test_is_list_like():

    # Define list of test objects
    test_objects = [
        None,
        [],
        [1, 2, 3],
        deque(),
        deque([1, 2, 3]),
        frozenset(),
        frozenset([1, 2, 3]),
        iter([]),
        iter([1, 2, 3]),
        tuple(),
        tuple([1, 2, 3]),
        set(),
        set([1, 2, 3]),
        dict(a=1, b=2).keys(),
        dict(a=1, b=2).values(),
        dict(a=1, b=2).items(),
        UserList()
    ]

    # Define expected results

# Generated at 2022-06-23 18:15:09.994851
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('hello', 'lower') is True
    assert has_callables('hello', 'lower', 'upper') is True
    assert has_callables('hello', 'lower', 'upper', 'foobar') is False


# Generated at 2022-06-23 18:15:13.063253
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'keys','foo','bar') == True
    assert has_any_callables(dict(),'foo','bar') == False


# Generated at 2022-06-23 18:15:18.077880
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'get','keys','items','foo') == True
    assert has_any_callables(dict(),'foo') == False


# Generated at 2022-06-23 18:15:28.445822
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(str,'capitalize','upper','lower','casefold','swapcase','title','translate','encode')
    assert has_callables([1,2,3,'hi there'],'append','insert','extend','remove','reverse', 'copy')
    assert has_callables(1,'bit_length','conjugate','denominator','from_bytes','imag','numerator','real','to_bytes')
    assert has_callables((1,2,3,4),'count','index')
    assert has_callables(set('abcd'),'add','clear','discard','difference','intersection','isdisjoint','issubset','pop','remove','union')

# Generated at 2022-06-23 18:15:30.794870
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-23 18:15:42.317121
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import (
        has_attrs,
        is_list_like
    )
    # Test for class object
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    # Test for instance object
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    # Test for list-like object
    assert has_attrs(list(), 'get', 'keys', 'items', 'values') is False

# Generated at 2022-06-23 18:15:45.119688
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    attrs = ('get', 'clear', 'pop', 'popitem', 'setdefault', 'update', 'copy')
    result = has_any_attrs(obj, *attrs)
    assert result is True



# Generated at 2022-06-23 18:15:49.053599
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True)
    assert(is_subclass_of_any(obj.keys(),str,bool,UserList) == False)

# Generated at 2022-06-23 18:15:59.605695
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'values') is True
    assert has_attrs(dict(), 'keys', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items') is True
    assert has_attrs(dict(), 'get', 'keys') is True
    assert has_attrs(dict(), 'keys') is True
    assert has_attrs(dict(), 'items') is False
    assert has_attrs(dict(), 'values') is False
    assert has_attrs(dict(), 'something') is False

# Generated at 2022-06-23 18:16:02.239813
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs
    """

    assert has_any_attrs(dict(),'get','keys','items','values','something') == True



# Generated at 2022-06-23 18:16:09.885497
# Unit test for function has_callables
def test_has_callables():
    from pprint import pprint as pp

    class Test(object):
        def __init__(self):
            self.set_attrs()
            self.set_methods()

        def set_attrs(self):
            self.foo = 'bar'
            self.far = 'boo'
            self.tacos = 'burritos'

        def set_methods(self):
            self.get_foo = lambda self: self.foo
            self.get_far = lambda self: self.far

    t = Test()
    pp(['foo', callable(t.get_foo)])
    pp(['far', callable(t.get_far)])
    pp(['tacos', callable(t.tacos)])