

# Generated at 2022-06-23 18:06:14.409618
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test with empty attributes
    obj = dict()
    attrs = ()
    exp_result = False
    result = has_any_callables(obj, *attrs)
    assert (result == exp_result)

    # Test with a single attribute
    obj = dict()
    attrs = ('get',)
    exp_result = True
    result = has_any_callables(obj, *attrs)
    assert (result == exp_result)

    # Test with multiple attributes
    obj = dict()
    attrs = ('get', 'keys', 'items', 'values', 'pop')
    exp_result = True
    result = has_any_callables(obj, *attrs)
    assert (result == exp_result)

    # Test with a valid attribute
    obj = dict()
    attrs = ('foo',)

# Generated at 2022-06-23 18:06:20.850979
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') == True
    assert has_attrs(obj, 'get', 'keys', 'values', 'foo') == False
    obj = dict(a='1', b='2')
    assert has_attrs(obj, 'get', 'foo') == False


# Generated at 2022-06-23 18:06:26.059084
# Unit test for function has_callables
def test_has_callables():
    test_obj = {'a':1, 'b':2}
    assert has_callables(test_obj,'get') == True
    assert has_callables(test_obj,'clear') == True
    assert has_callables(test_obj,'foo') == False
    assert has_callables(test_obj,'foo','clear') == True
    assert has_any_callables(test_obj,'foo','clear') == True

# Generated at 2022-06-23 18:06:30.870077
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(str,'split','join','strip'))
    assert(not has_any_attrs(str,'split','join','strip','find'))
    assert(has_any_attrs(dict(),'get','keys','items','values','something'))


# Generated at 2022-06-23 18:06:34.104913
# Unit test for function has_attrs
def test_has_attrs():
    '''Unit test for function has_attrs'''
    assert has_attrs(dict(),'get','keys','items','values')


# Generated at 2022-06-23 18:06:35.646524
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True



# Generated at 2022-06-23 18:06:38.958231
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-23 18:06:42.280763
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'items', 'foo')



# Generated at 2022-06-23 18:06:43.932308
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')


# Generated at 2022-06-23 18:06:50.574284
# Unit test for function has_callables
def test_has_callables():
    #
    # Test has any callables
    #
    testdict = dict()
    assert has_callables(testdict, "get", "values", "foo")
    #
    # Test has all callables
    #
    testdict = dict()
    assert has_callables(testdict, "get", "values")
    #
    # Test has no callables
    #
    assert not has_callables(None, "foo", "bar")

# Generated at 2022-06-23 18:06:55.389410
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2]))
    assert is_list_like('hello')
    assert is_list_like(sorted('hello'))

# Generated at 2022-06-23 18:07:03.751908
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import defaultdict

    dd = defaultdict(int)
    assert has_any_callables(dd, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dd, 'get', 'keys', 'items', 'values', 'items') is True

    dd.foo = 'bar'
    assert has_any_callables(dd, 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_any_callables(dd, 'get', 'keys', 'items', 'values', 'items') is True

    dd.items = 'items'
    assert has_any_callables(dd, 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-23 18:07:10.976079
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items') is False
    assert has_callables(dict(), 'get', 'items') is False
    assert has_callables(dict(), 'keys', 'items', 'values') is False
    assert has_callables(dict(), 'get', 'keys', 'values') is False

# Generated at 2022-06-23 18:07:14.051905
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'something') == False
    assert has_any_attrs(None,'something') == False


# Generated at 2022-06-23 18:07:25.981267
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([])
    assert is_list_like([1,2,3])
    assert is_list_like([1,2,3,4,5,6,7,8,9,0])
    assert is_list_like([1,2,3,4,5,6,7,8,9,0,['a','b','c']])
    assert not is_list_like('hello')
    assert not is_list_like(1)
    assert not is_list_like(True)
    assert not is_list_like(False)
    assert not is_list_like(None)
    assert not is_list_like({})
    assert not is_list_like({1:1,2:2,3:3})

# Generated at 2022-06-23 18:07:32.633060
# Unit test for function has_callables
def test_has_callables():
    import pytest
    from collections import (
        Counter,
        ChainMap,
        OrderedDict,
        UserDict,
        defaultdict,
    )
    from decimal import Decimal
    from flutils.objutils import has_callables

    # noinspection PyTypeChecker
    #: :type: list
    _classes = [  # iterates in the same order
        bool,
        bytes,
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        defaultdict,
        Decimal,
        dict,
        float,
        frozenset,
        int,
        list,
        set,
        str,
        UserList,
        tuple,
    ]
    _class_name_lst = [_c.__name__ for _c in _classes]


# Generated at 2022-06-23 18:07:39.562725
# Unit test for function has_attrs
def test_has_attrs():
    assert hasattr(abs, '__code__') == True
    assert hasattr(abs, '__doc__') == True
    assert hasattr(abs, '__globals__') == True
    assert hasattr(abs, '__name__') == True

    assert has_attrs(abs, '__code__', '__doc__', '__globals__', '__name__') == True



# Generated at 2022-06-23 18:07:49.730987
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like."""

# Generated at 2022-06-23 18:07:55.405083
# Unit test for function has_any_callables
def test_has_any_callables():
    """Check that we correctly identify objects that have any callables.
    """
    assert has_any_callables(dict(),'get','keys','items','values','something') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'foo') == False


# Generated at 2022-06-23 18:08:00.809430
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test utility function is_subclass_of_any.
    """
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    subclasses = is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList)
    assert(subclasses == True)
    subclasses = is_subclass_of_any(obj, ValuesView, KeysView, UserList)
    assert(subclasses == False)

# Generated at 2022-06-23 18:08:12.019712
# Unit test for function has_any_callables

# Generated at 2022-06-23 18:08:24.942165
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(a=1,b=2),'get','keys','items','values','foo')
    assert has_any_callables(dict(a=1,b=2),'get','keys','items','values')
    assert has_any_callables(dict(a=1,b=2),'keys','items','values')
    assert has_any_callables(dict(a=1,b=2),'items','values')
    assert has_any_callables(dict(a=1,b=2),'values')
    assert has_any_callables(dict(a=1,b=2),) is False
    assert has_any_callables(dict(),) is False
    assert has

# Generated at 2022-06-23 18:08:29.180997
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert(has_any_callables(obj,'keys','items','values') == True)
    assert(has_any_callables(obj,'keys','items','values','foo') == True)
    assert(has_any_callables(obj,['keys','items','values']) == True)
    assert(has_any_callables(obj,['get','keys','items','values']) == True)
    assert(has_any_callables(obj,'keys','values') == True)
    assert(has_any_callables(obj,'keys') == True)

# Generated at 2022-06-23 18:08:36.164173
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'items') is True
    obj = namedtuple('Test', 'a, b')
    assert has_callables(obj, '__new__') is True
    assert has_callables(obj, '__class__') is False
    assert has_callables(obj, '__class__', '__new__') is False



# Generated at 2022-06-23 18:08:40.135844
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2, c=3).values()
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:08:51.816727
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(dict, dict) == True
    assert is_subclass_of_any(dict, dict, dict) == True
    assert is_subclass_of_any(dict, dict, dict, dict) == True
    assert is_subclass_of_any(dict, dict, dict, dict, dict) == True
    assert is_subclass_of_any([], list) == True
    assert is_subclass_of_any(list, list) == True
    assert is_subclass_of_any('abc', str) == True
    assert is_subclass_of_any(b'abc', bytes) == True
    assert is_subclass_of_any(1, int) == True
    assert is_subclass_of_any(1.0, float) == True
    assert is_

# Generated at 2022-06-23 18:08:54.350239
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'something') == False

# Generated at 2022-06-23 18:08:56.828111
# Unit test for function has_any_callables
def test_has_any_callables():
    x = {'c': 5, 'd': 6}
    assert has_any_callables(x, 'a', 'b', 'c')


# Generated at 2022-06-23 18:09:08.309170
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test case
    list_like = [1, 2, 3]

    # Test if list_like has any of the attrs
    assert has_any_attrs(list_like, 'index', '__iadd__') == True

    # Test if list_like has any of the attrs
    assert has_any_attrs(
        list_like, '__iadd__', '__itruediv__', '__ifloordiv__', '__imod__'
    ) == True

    # Test if list_like does not have any of the attrs
    assert has_any_attrs(list_like, '__itruediv__', '__imod__', 'foo') == True

    # Test if list_like has any of the attrs

# Generated at 2022-06-23 18:09:12.017962
# Unit test for function has_callables
def test_has_callables():
    obj = dict(get=0)
    obj1 = dict(abc=0)
    print(has_callables(obj, 'get'))
    print(has_callables(obj1, 'get'))



# Generated at 2022-06-23 18:09:20.369601
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables."""
    from flutils.objutils import has_callables
    from collections import UserDict
    from io import BytesIO as ioBytesIO
    
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(UserDict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(ioBytesIO(), 'getvalue', 'seek', 'write', 'close') == True


# Generated at 2022-06-23 18:09:23.934807
# Unit test for function has_attrs
def test_has_attrs():
    # Unit test for has_attrs
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'getter', 'keys', 'items', 'values') is False



# Generated at 2022-06-23 18:09:30.395031
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import pytest

    assert has_any_attrs(dict(), 'keys', 'foo') is True
    assert has_any_attrs('hello', 'foo') is False
    assert has_any_attrs(dict(), 'foo') is False

    with pytest.raises(TypeError):
        assert has_any_attrs(dict())


# Generated at 2022-06-23 18:09:34.083495
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView) is False

# Generated at 2022-06-23 18:09:41.846284
# Unit test for function is_list_like
def test_is_list_like():
    from collections.abc import (
        KeysView,
        ValuesView,
    )
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
        deque,
        frozenset,
        list,
        set,
        tuple,
        Iterator,
    )
    from decimal import (
        Decimal,
    )
    from json import (
        JSONDecoder,
        JSONEncoder,
    )
    from json.decoder import (
        WHITESPACE,
    )
    from json.encoder import (
        INFINITY,
        NAN,
    )
    from json.scanner import (
        NULL_STRING,
    )

# Generated at 2022-06-23 18:09:49.010476
# Unit test for function has_callables
def test_has_callables():
    # Check if a object has callable attributes
    assert has_callables(dict(), 'get', 'keys', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'values', 'foo') == True
    assert has_callables(dict(), 'get', 'keys', 'values', 'foo', 'bar') == False
    assert has_callables(dict(), 'keys', 'bar') == False
    assert has_callables(dict(), 'get', 'bar') == False
    assert has_callables(dict(), 'get', 'keys') == True


# Generated at 2022-06-23 18:09:57.379774
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'values', 'items') is True
    assert has_any_attrs((), '__iter__', '__str__', '__contains__',
                         '__getitem__') is True
    assert has_any_attrs(
        (1, 2, 3),
        '__iter__',
        '__str__',
        '__contains__',
        '__getitem__',
        'index',
        'count'
    ) is True
    assert has_any_attrs(
        'hello',
        '__iter__',
        '__str__',
        '__contains__',
        '__getitem__',
        'index',
        'count'
    ) is True

# Generated at 2022-06-23 18:09:58.939588
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items') is False


# Generated at 2022-06-23 18:10:05.840332
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2, c=3)
    assert has_attrs(obj, 'a', 'b', 'c')
    assert has_attrs(obj, 'a', 'b')
    assert not has_attrs(obj, 'a', 'b', 'c', 'd')
    assert not has_attrs(obj)



# Generated at 2022-06-23 18:10:15.998171
# Unit test for function has_callables
def test_has_callables():
    # Check that all required attributes are callable
    # Create new dict-like class
    class TestDictLike(dict):
        def test(self):
            return 'test'

        def __call__(self):
            return '__call__'

    # Test the class
    assert has_callables(TestDictLike(), 'get', 'keys', 'items', 'values', 'test') is True

    # Check that a non-callable attribute fails
    assert has_callables(TestDictLike(), 'get', 'keys', 'items', 'values', 'test', '__call__') is False


# Generated at 2022-06-23 18:10:20.224850
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Unit test for function is_subclass_of_any"""

    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-23 18:10:25.650537
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(has_any_callables, '__name__')
    assert has_any_callables(has_any_callables, '__something_that__does_not_exist__') is False


# Generated at 2022-06-23 18:10:31.226031
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1,2,3], 'append', 'pop', 'remove') is True
    assert has_any_callables((1,2,3), 'append', 'pop', 'remove') is False
    assert has_any_callables(1, 'append', 'pop', 'remove') is False
    assert has_any_callables({'a':1,'b':2}, 'append', 'pop', 'remove') is False

# Generated at 2022-06-23 18:10:40.877546
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from typing import (
        Any,
        Type,
    )

    ok_types = [
        UserList,
        Iterator,
        ValuesView,
        KeysView,
        deque,
    ]

    not_ok_types = [
        # just to keep these in mind
        None,
        bool,
        bytes,
        int,
        float,
        str,
        Type,
        Any,
    ]

    for t in ok_types:
        obj = t()
        assert is_list_like(obj)

    for t in not_ok_types:
        obj = t()
        assert is_list_

# Generated at 2022-06-23 18:10:45.392853
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(a='a'),'get','keys','items','values','something')
    assert has_any_attrs(dict(a='a'),'get','keys','items','values')



# Generated at 2022-06-23 18:10:55.378643
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(obj.keys(),KeysView,ValuesView,UserList)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView)
    assert is_subclass_of_any(obj.keys(),UserList,ValuesView)
    # False
    assert not is_subclass_of_any(obj.keys(),UserList,ValuesView,dict)
    assert not is_subclass_of_any(obj.keys(),ValuesView,UserList,dict)
    assert not is_subclass_of_any(obj.keys(),ValuesView,KeysView,dict)

# Generated at 2022-06-23 18:11:02.143763
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items','values','')
    assert has_any_attrs(dict(),'','')
    assert has_any_attrs(dict(),'','')
    assert has_any_attrs(dict(),'','') is False
    assert has_any_attrs(dict(),'','','something') is False


# Generated at 2022-06-23 18:11:10.264899
# Unit test for function is_list_like
def test_is_list_like():
    """ Test unit for function is_list_like
    """
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(1) is False
    assert is_list_like(tuple()) is True
    assert is_list_like(dict()) is False
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(reversed(range(1,10))) is True



# Generated at 2022-06-23 18:11:22.639080
# Unit test for function has_any_callables
def test_has_any_callables():
    class Foo(object):
        @staticmethod
        def bar():
            pass

        @classmethod
        def baz(cls):
            pass

        def _bat(self):
            pass
    foo = Foo()
    assert has_any_callables(foo, 'bar', 'baz', 'bat', 'bum') is True

    class Foo(object):
        @property
        def bar(self):
            pass
    foo = Foo()
    assert has_any_callables(foo, 'bar', 'baz', 'bat', 'bum') is True

    class Foo(object):
        @staticmethod
        def bar():
            pass

        class Bar(object):
            @staticmethod
            def baz():
                pass

        def __init__(self):
            self.bar = self.Bar()

    foo = Foo

# Generated at 2022-06-23 18:11:26.829107
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2, c=3)
    assert(has_any_attrs(obj, 'values','keys','items','get','b') == True)



# Generated at 2022-06-23 18:11:28.926137
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'foo','bar') is False


# Generated at 2022-06-23 18:11:34.718633
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert(is_list_like([1,2,3]) is True)
    assert(is_list_like(reversed([1,2,3])) is True)
    assert(is_list_like('hello') is False)
    assert(is_list_like(sorted('hello')) is True)

# Generated at 2022-06-23 18:11:42.896101
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList) == True
    assert has_callables(obj, 'keys', 'values') == True
    assert has_attrs(obj, 'keys', 'values') == True
    assert has_any_attrs(obj, 'keys', 'values') == True
    assert has_any_callables(obj, 'keys', 'values') == True

if __name__ == "__main__":
    test_is_subclass_of_any()

# Generated at 2022-06-23 18:11:45.401623
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:11:56.605899
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import Counter, OrderedDict, defaultdict
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert not has_any_callables(dict(),'get','keys','items','values','fooj')
    assert has_any_callables(Counter(),'get','keys','items','values','foo')
    assert not has_any_callables(defaultdict(int),'get','keys','items','values',
                                 'foo')
    assert has_any_callables(OrderedDict(),'get','keys','items','values','foo')


if __name__ == '__main__':
    import pytest

    pytest.main(args=[__file__])

# Generated at 2022-06-23 18:12:01.749269
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    ok = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert ok == True

# Generated at 2022-06-23 18:12:13.320716
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like."""
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    # These are instances of collections.abc.ValuesView
    # These are NOT instances of collections.abc.KeysView,
    # collections.abc.UserList
    _values = dict(
        a=(1, 2, 3),
        b={'a': 1, 'b': 2, 'c': 3, 'd': 4},
        c=['a', 'b', 'c', 'd'],
    )
    for label, obj in _values.items():
        assert is_list_like(obj) is True
        assert is_list_like(reversed(obj))

# Generated at 2022-06-23 18:12:24.262223
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        ValuesView,
        KeysView,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView) is True
    assert is_subclass_of_any(obj.items(), ValuesView) is False
    assert is_subclass_of_any(obj.values(), KeysView) is False
    assert is_subclass_of_any(obj.keys(), KeysView, ValuesView, UserList)
    assert is_subclass_of_any(obj.values(), KeysView, ValuesView, UserList)
    assert is_subclass_of_any(obj.items(), KeysView, ValuesView, UserList)
    assert is_subclass_of_any(1, ValuesView) is False

# Generated at 2022-06-23 18:12:35.689283
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    assert is_list_like([1, 2]) is True
    assert is_list_like((1, 2)) is True
    assert is_list_like({1, 2}) is True
    assert is_list_like({'a': 1, 'b': 2}) is False
    assert is_list_like(set([1, 2])) is True
    assert is_list_like(frozenset([1, 2])) is True
    assert is_list_like(deque([1, 2])) is True
    assert is_list_like(reversed([1, 2])) is True
    assert is_list_like

# Generated at 2022-06-23 18:12:42.114242
# Unit test for function has_attrs
def test_has_attrs():
    foo = dict(a=1, b=2, c=3, d=4)
    assert has_attrs(foo, '__class__', '__contains__', '__len__')
    assert not has_attrs(foo, '__class__', '__contain__', '__len__')



# Generated at 2022-06-23 18:12:52.430241
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables

    .. note:: This function is not exported from this module.
    """
    from flutils.objutils import has_callables

    # Test has_callables for dict.
    for test_class in (
        dict,
        dict()
    ):
        assert has_callables(test_class, 'get', 'items', 'keys', 'values') is True

    # Test has_callables for list.
    for test_class in (
        list,
        [],
        list.__new__(list)
    ):
        assert has_callables(test_class, 'append', 'copy', 'count') is True

    assert has_callables(list, 'foo') is False



# Generated at 2022-06-23 18:12:56.559825
# Unit test for function has_any_callables
def test_has_any_callables():
    d = {'a':5,'b':5}
    result = has_any_callables(d,'get','items','values')
    assert result == True


# Generated at 2022-06-23 18:12:58.733861
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get','keys','items','values')



# Generated at 2022-06-23 18:13:03.429335
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-23 18:13:07.442310
# Unit test for function has_any_callables
def test_has_any_callables():
    class TestClass:
        def __init__(self, *args):
            for arg in args:
                setattr(self, arg, self.get_attr)

        def get_attr(self):
            pass

    return True


if __name__ == '__main__':
    print(test_has_any_callables())

# Generated at 2022-06-23 18:13:12.083163
# Unit test for function has_attrs
def test_has_attrs():
    assert(has_attrs(dict(),'get','keys','items','values')) == True
    assert(has_attrs(dict(),'foo')) == False
    assert(has_attrs(dict(a=1,b=2),'items')) == True


# Generated at 2022-06-23 18:13:19.121064
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'bar', 'baz', 'qux') is False
    assert has_attrs([1, 2, 3], 'append', 'insert', 'remove', 'pop') is True
    assert has_attrs([1, 2, 3], 'foo', 'bar', 'baz', 'qux') is False
    assert has_attrs(list(), 'append', 'insert', 'remove', 'pop') is True
    assert has_attrs(list(), 'foo', 'bar', 'baz', 'qux') is False
    assert has_attrs('', 'encode', 'format', 'format_map', 'join') is True

# Generated at 2022-06-23 18:13:25.420128
# Unit test for function has_attrs
def test_has_attrs():
    # Test 1: Check all attrs exist
    attrs = ['get', 'keys', 'items', 'values']
    assert has_attrs(dict, *attrs) is True
    # Test 2: Fail on non-existant attribute
    attrs.append('foo')
    assert has_attrs(dict, *attrs) is False
    # Test 3: Fail when some attrs don't exist
    attrs.pop()
    assert has_attrs(dict, *attrs) is False



# Generated at 2022-06-23 18:13:32.637525
# Unit test for function is_list_like
def test_is_list_like():
    import types
    import collections
    import decimal
    import json
    from flutils.objutils import is_list_like

# Generated at 2022-06-23 18:13:42.379768
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(bytes(b'foo')) is False
    assert is_list_like({'foo': 1, 'bar': 2}) is False
    assert is_list_like({'foo', 'bar'}) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-23 18:13:49.240728
# Unit test for function has_attrs
def test_has_attrs():
    assert not has_attrs(str, "__len__")
    assert has_attrs(str, "__len__", "__add__")
    assert not has_attrs(str, "__len__", "__add__", "__doc__")
    assert has_attrs(str, "__len__", "__add__", "__doc__", "__class__")



# Generated at 2022-06-23 18:13:51.852777
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj, 'get', 'items', 'keys', 'pop', 'popitem', 'setdefault', 'update', 'values')



# Generated at 2022-06-23 18:13:53.606281
# Unit test for function has_callables
def test_has_callables():
    pass



# Generated at 2022-06-23 18:14:01.046247
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(str(),'__contains__','__eq__','__len__','__add__')
    assert has_attrs(int(),'bit_length','__add__','__sub__','__mul__')
    assert has_attrs(float(),'is_integer','__add__','__sub__','__mul__')



# Generated at 2022-06-23 18:14:10.934445
# Unit test for function has_callables
def test_has_callables():
    import pytest
    from flutils.objutils import has_callables
    from collections import (
        OrderedDict,
        defaultdict,
    )

    # dict-like
    assert has_callables(dict(), 'get') is True

    # collections.OrderedDict
    assert has_callables(OrderedDict(), 'get') is True

    # collections.defaultdict
    assert has_callables(defaultdict(), 'get') is True

    # dict-like, but missing 'get'
    assert has_callables(dict(), 'get', 'foo') is False

    # dict-like with 'get', but 'foo' doesn't exist
    assert has_callables(dict(), 'get', 'foo') is False



# Generated at 2022-06-23 18:14:14.595868
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something') == True


# Generated at 2022-06-23 18:14:16.280360
# Unit test for function has_attrs
def test_has_attrs():
    print(has_attrs(dict(),'get','keys','items','values'))


# Generated at 2022-06-23 18:14:28.759792
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # Test that an object is confirmed as a subclass of the intended class.
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    # Test that an object is not confirmed as a subclass of the intended class.
    assert not is_subclass_of_any(obj.keys(),int,bool,dict)
    # Test that an object is not confirmed as a subclass of the intended class.
    from decimal import Decimal
    from fractions import Fraction
    class Model(type): pass
    assert not is_subclass_of_any(Decimal,Fraction,Model)
    # Test that an object is confirmed as a subclass of the intended class.
    class Fraction(Fraction,Model): pass

# Generated at 2022-06-23 18:14:40.479685
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Tests for function is_subclass_of_any"""
    # Assert that the following list-like objects are True for is_subclass_of_any
    list_objs = [
        # Regular lists
        [1, 2, 3],
        # UserList
        UserList([1, 2, 3]),
        # Keys/Values Views
        dict(a=1, b=2).keys(),
        dict(a=1, b=2).values(),
        # Iterators
        reversed([1, 2, 3]),
        sorted('abcde')
    ]

    for list_obj in list_objs:
        assert is_subclass_of_any(list_obj, UserList, ValuesView, KeysView, Iterator)

    # Assert that the following list-like objects are NOT True for is_subclass_of_

# Generated at 2022-06-23 18:14:47.112909
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)

    try:
        assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    except AssertionError:
        print('Test is_subclass_of_any failed')
        return 1

    return 0

# Generated at 2022-06-23 18:14:54.739919
# Unit test for function has_any_attrs
def test_has_any_attrs():
    o = {'a':1,'b':2,'c':3}
    assert(has_any_attrs(o,'a','b'))
    assert(has_any_attrs(o,'a','b','c'))
    assert(has_any_attrs(o,'b','c','a'))
    assert(has_any_attrs(o,'c','a','b'))
    assert(has_any_attrs(o,'b','c','d') is False)
    assert(has_any_attrs(o,'d','e','f') is False)


# Generated at 2022-06-23 18:14:59.021637
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(dict(), 'something', 'something_else')
    assert not has_any_attrs(None, 'something', 'something_else')



# Generated at 2022-06-23 18:15:05.564052
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        Counter,
        deque,
        defaultdict,
        UserList,
    )

    assert is_list_like([]) is True
    assert is_list_like(Counter()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(defaultdict()) is True
    assert is_list_like(set()) is True
    assert is_list_like(dict().keys()) is True
    assert is_list_like(dict().values()) is True
    assert is_list_like(dict().items()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(UserList()) is True
    assert is_list_like({}) is False
    assert is_

# Generated at 2022-06-23 18:15:08.300122
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')


# Generated at 2022-06-23 18:15:10.253236
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','values','a','b')



# Generated at 2022-06-23 18:15:13.733448
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo') == True
    assert has_any_attrs(dict(),'foo','bar','baz','qux') == False


# Generated at 2022-06-23 18:15:17.261716
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','values','foo') is True
    assert has_any_callables(dict(a=1,b=2),'get','keys','values','foo') is True


# Generated at 2022-06-23 18:15:23.673620
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test for function has_any_attrs
    """
    assert (has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo'))
    assert (has_any_attrs(dict(), 'get', 'keys', 'items', 'values'))
    assert (has_any_attrs(dict(), 'keys', 'items', 'values'))



# Generated at 2022-06-23 18:15:30.727710
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict
    )
    from decimal import Decimal
    assert is_subclass_of_any(None, ChainMap, OrderedDict)
    assert is_subclass_of_any(True, UserDict, dict)
    assert is_subclass_of_any(b'some bytes', Counter, UserString)
    assert is_subclass_of_any(Decimal('12.0000'), defaultdict, dict)
    assert is_subclass_of_any(1234, ChainMap, dict)
    assert is_subclass_of_any(dict(), ChainMap, dict)

# Generated at 2022-06-23 18:15:35.836686
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'foo')



# Generated at 2022-06-23 18:15:47.543036
# Unit test for function is_list_like
def test_is_list_like():
    # Define the test classes
    class MyList(list):
        pass

    class NotList(str):
        pass

    assert is_list_like(MyList) is False
    assert is_list_like(NotList) is False
    assert is_list_like(MyList()) is True
    assert is_list_like(NotList()) is False
    assert is_list_like([]) is True
    assert is_list_like(None) is False
    assert is_list_like(bool()) is False
    assert is_list_like(bytes()) is False
    assert is_list_like(int()) is False
    assert is_list_like(float()) is False
    assert is_list_like(str()) is False
    assert is_list_like(dict()) is False
    assert is_list_like(set())

# Generated at 2022-06-23 18:15:54.539167
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'items', 'values') is True
    assert has_callables(obj, 'keys', 'a', 'values') is False
    assert has_callables(obj, 'keys', 'items', 'values', 'something') is False
    assert has_callables(obj) is False


# Generated at 2022-06-23 18:16:05.129795
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from nose.tools import assert_true, assert_false, assert_raises

    # Assert that it works
    obj = dict()
    assert_true( has_any_attrs(obj,'get','keys','items','values','something') )
    assert_false( has_any_attrs(obj,'foo','bar','baz') )

    # Assert that it fails if obj is not an object
    assert_raises(AttributeError, has_any_attrs, 1234, 'foo', 'bar')

    # Assert that it fails if passed an incorrect number of arguments
    assert_raises(TypeError, has_any_attrs)
    assert_raises(TypeError, has_any_attrs, obj)
    assert_raises(TypeError, has_any_attrs, obj, '')



# Generated at 2022-06-23 18:16:12.412303
# Unit test for function has_callables
def test_has_callables():
    """
    TODO: test the function has_callables
    """
    obj = dict(a=1, b=2)
    assert has_callables(obj.keys(),'__getitem__') is True
    assert has_callables(obj.values(),'__getitem__') is True
    assert has_callables(obj.items(),'__getitem__') is True
    assert has_callables(obj,'__getitem__') is True
