

# Generated at 2022-06-23 18:06:17.901156
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    if not is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList):
        raise AssertionError("value not equal")

if __name__ == '__main__':
    test_is_subclass_of_any()

# Generated at 2022-06-23 18:06:27.939115
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'items')
    assert has_callables(obj, 'get', 'keys', 'items')
    assert has_callables(obj, ('get', 'keys', 'items'))

    assert has_callables(obj, ('get', 'keys', 'items', 'something'))
    assert has_callables(obj, ('get', 'keys', 'items', 'something'), True)
    assert has_callables(obj, ('get', 'keys', 'items', 'something'), True)

    assert not has_callables(obj, 'something', False, True)
    assert not has_callables(obj, 'something', False, True, False)
    assert not has_callables(obj, 'something', True, False)


# Unit

# Generated at 2022-06-23 18:06:38.240252
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like.
    """
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString
    )
    from decimal import Decimal
    from flutils.objutils import (
        is_list_like,
        is_subclass_of_any
    )

    # Test list-like objects
    assert is_list_like([])
    assert is_list_like(['a'])
    assert is_list_like(frozenset())
    assert is_list_like(frozenset('abc'))
    assert is_list_like(iter([]))
    assert is_list_like(iter(['a']))
    assert is_list_like(iter(frozenset()))

# Generated at 2022-06-23 18:06:41.871722
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:06:44.246551
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3])
    assert is_list_like(reversed([1,2,4]))
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello'))

# Generated at 2022-06-23 18:06:54.904913
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(obj, 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(obj, 'foo') is False
    assert has_attrs(obj, 'foo', 'bar') is False
    # Only the first attr will be a exception
    assert has_attrs(obj, '__all__', '__doc__') is False
    assert has_attrs(obj, '__all__') is False
    assert has_attrs(obj, '__doc__') is False
    assert has_attrs(obj, '__module__') is True
    # Test with a userdefined class

# Generated at 2022-06-23 18:06:56.646856
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), "get", "keys", "items", "values")

# Generated at 2022-06-23 18:06:59.026191
# Unit test for function has_attrs
def test_has_attrs():
    """ Tests the function has_attrs.
        Expects True
    """
    assert has_attrs(dict(),'get','keys','items','values') == True


# Generated at 2022-06-23 18:07:10.793744
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs([1,2,4], 'append', 'insert', 'remove', 'clear', 'pop')
    assert has_any_attrs((1,2,5), 'append', 'insert', 'remove', 'clear', 'pop')
    assert has_any_attrs(frozenset([1,2,6]), 'append', 'insert', 'remove', 'clear', 'pop')
    assert has_any_attrs(set([1,2,6]), 'append', 'insert', 'remove', 'clear', 'pop')
    assert not has_any_attrs(0, 'append', 'insert', 'remove', 'clear', 'pop')

# Generated at 2022-06-23 18:07:22.050651
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from collections import (
        defaultdict,
        deque,
    )
    from decimal import Decimal
    from flutils.objutils import (
        is_list_like,
    )
    import numpy
    import pandas
    from typing import (
        Any,
        Dict,
        Iterable,
        Iterator as Iterator_,
        KeysView as KeysView_,
        List,
        Set,
        Tuple,
        ValuesView as ValuesView_,
    )

# Generated at 2022-06-23 18:07:27.222489
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from nose.tools import assert_true, assert_false

    obj = dict()
    assert_true(has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo'))
    assert_false(has_any_attrs(obj, 'foo', 'bar', 'baz', 'qux'))



# Generated at 2022-06-23 18:07:35.139708
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(a=1, b=2), 'keys', 'items', 'values', 'clear')
    assert has_callables(dict(a=1, b=2), 'keys', 'items', 'values')
    assert has_callables(dict(a=1, b=2), 'clear', 'keys', 'items', 'values')
    assert has_callables(dict(a=1, b=2), 'clear', 'foo', 'keys', 'items', 'values')
    assert has_callables(dict(a=1, b=2), 'clear', 'foo', 'bar', 'keys', 'items', 'values')
    assert not has_callables(dict(a=1, b=2), 'foo', 'bar', 'baz')

# Generated at 2022-06-23 18:07:41.969010
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj,'get','keys','items','values','foo') is True
    assert has_any_callables(obj,'get','foo','items','values','baz') is False
    assert has_any_callables(obj,'foo','bar','baz') is False



# Generated at 2022-06-23 18:07:51.304825
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(tuple(), 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-23 18:07:53.891167
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-23 18:07:58.703607
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables('test', 'find', 'replace', 'format') is True
    assert has_callables('test', 'foo', 'bar') is False

# Generated at 2022-06-23 18:08:00.315329
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(a=1, b=2), 'keys', 'items', 'values')



# Generated at 2022-06-23 18:08:11.952935
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import (
        AsyncIterator,
        Awaitable,
        ByteString,
        Coroutine,
        Generator,
        Callable,
        Set,
        Mapping,
        MappingView,
        Sequence,
        Collection,
        Hashable,
        ItemsView,
        Iterable,
        Iterator,
        KeysView,
        Reversible,
        Sized,
        ValuesView,
    )
    try:
        from collections.abc import View
    except:
        pass

    import decimal
    import functools
    import operator
    import itertools

    # noinspection SpellCheckingInspection

# Generated at 2022-06-23 18:08:24.913187
# Unit test for function has_any_callables
def test_has_any_callables():
    class TestClass(object):

        def __init__(self):
            self.name = 'foo'
            self.age = 21
            self.color = 'red'

        def is_color_red(self):
            return self.color == 'red'

    obj = TestClass()
    assert has_any_callables(obj, 'is_color_red', 'name', 'age') is True
    assert has_any_callables(obj, 'is_color_red', 'name', 'age', 'color') is False
    assert has_any_callables(obj, 'is_color_red', 'color', 'age') is True
    assert has_any_callables(obj, 'is_color_red', 'name', 'color') is False

# Generated at 2022-06-23 18:08:31.948574
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(()) is True
    assert is_list_like(b'') is False
    assert is_list_like(0) is False
    assert is_list_like(0.0) is False
    assert is_list_like([]) is True
    assert is_list_like(dict()) is False
    assert is_list_like('hello') is False
    assert is_list_like(frozenset()) is True
    assert is_list_like(set()) is True
    assert is_list_like(reversed([1, 2, 3])) is True

# Generated at 2022-06-23 18:08:34.865115
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        KeysView,
        ValuesView,
        UserList
    )

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), object) is True
    assert is_subclass_of_any(obj.keys(), UserList) is False



# Generated at 2022-06-23 18:08:46.957980
# Unit test for function has_callables

# Generated at 2022-06-23 18:08:55.260443
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs({}, 'get', 'keys', 'items', 'values')
    assert has_attrs({}, 'get', 'keys', 'foo') is False
    assert has_attrs('', 'join', 'center', 'rjust')
    assert has_attrs('', 'join', 'center', 'rjust', 'foo') is False
    assert has_attrs(int(), 'from_bytes', 'numerator', 'conjugate')
    assert has_attrs(int(), 'from_bytes', 'numerator', 'conjugate', 'foo') is False
    assert has_attrs(float(), 'hex', 'fromhex', 'fromhex', 'fromhex', 'foo') is False



# Generated at 2022-06-23 18:09:03.988399
# Unit test for function has_callables
def test_has_callables():
    # This is example code
    assert has_callables([1, 2, 3], 'append', 'get', 'extend')
    assert has_callables([1, 2, 3], 'append', 'extend')
    assert has_callables([1, 2, 3], 'append')
    assert not has_callables([1, 2, 3], 'append', 'extend', 'foo')
    assert not has_callables([1, 2, 3], 'foo')

if __name__ == "__main__":
    test_has_callables()

# Generated at 2022-06-23 18:09:07.034554
# Unit test for function has_any_callables
def test_has_any_callables():
    assert (has_any_callables(dict(),'get','keys','items','values','foo')) == True
    assert (has_any_callables(dict(),'foo','bar','bob','tom','tim')) == False


# Generated at 2022-06-23 18:09:13.768415
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get')
    assert not has_callables(dict(), 'foo')
    assert not has_callables(dict(), 'setdefault')
    assert not has_callables(dict(), 'get', 'setdefault')
    # noinspection PyTypeChecker
    assert not has_callables('', 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:09:17.544232
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-23 18:09:25.786530
# Unit test for function has_callables
def test_has_callables():
    class TestClass:
        def __init__(self, name):
            self.name = name

        def __call__(self, *args, **kwargs):
            return self.name

        def callable_method(self, *args, **kwargs):
            return self.__call__(*args, **kwargs)

        @classmethod
        def class_method(cls, *args, **kwargs):
            return f'{cls.__name__}.class_method'

        @staticmethod
        def static_method(*args, **kwargs):
            return f'{TestClass.__name__}.static_method'

        @property
        def property(self):
            return self._property

        @property.setter
        def property(self, value):
            self._property = value


# Generated at 2022-06-23 18:09:27.481414
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-23 18:09:31.962167
# Unit test for function has_any_callables
def test_has_any_callables():
    class A:
        def foo(self):
            return 'foo'
        @staticmethod
        def bar():
            return 'bar'
    a = A()
    assert has_any_callables(a,'foo','bar','baz')


# Generated at 2022-06-23 18:09:40.751868
# Unit test for function has_any_callables
def test_has_any_callables():
    #type: () -> None
    """Test for function has_any_callables"""
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__contains__') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'baz') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', '__contains__', 'bar', 'baz') is True

# Generated at 2022-06-23 18:09:44.253445
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'keys', 'values')  # should pass
    assert not has_any_callables(obj, 'foo', 'something', 'bar')  # should fail



# Generated at 2022-06-23 18:09:46.895388
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == False


# Generated at 2022-06-23 18:09:48.444986
# Unit test for function has_attrs
def test_has_attrs():
    r = has_attrs(dict, 'get', 'keys', 'items', 'values')
    assert r is True



# Generated at 2022-06-23 18:09:52.111030
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'something')
    assert not has_any_attrs(dict, 'something')
    assert has_any_attrs(UserList, 'something')


# Generated at 2022-06-23 18:09:54.618927
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-23 18:10:03.995620
# Unit test for function has_callables
def test_has_callables():
    """Unit test for ``has_callables()``
    """
    assert has_callables(set(), 'pop', 'add', 'update') is True

    assert has_callables('hello', 'capitalize', 'title', 'upper') is True

    assert has_callables('hello', 'cap', 'up') is False

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True

    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False

    assert has_callables(dict(), 'get', 'a', 'b', 'values') is False



# Generated at 2022-06-23 18:10:07.161212
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:10:16.836308
# Unit test for function has_callables
def test_has_callables():
    dictinst = dict()
    listinst = list()
    setinst = set()
    tupleinst = tuple()
    dequeinst = deque()
    assert has_callables(dictinst,'get','keys','values','items')
    assert has_callables(listinst,'append','remove','appendleft','extend')
    assert has_callables(setinst,'add','remove','discard','clear')
    assert has_callables(tupleinst,'count','index','__contains__')
    assert has_callables(dequeinst,'append','remove','appendleft','extend')


# Generated at 2022-06-23 18:10:24.517235
# Unit test for function has_callables
def test_has_callables():
    objs = [
        dict(a=1, b=2),
        {'a': 1, 'b': 2},
        list([1, 2, 3]),
        [1, 2, 3],
        set((1, 2, 3)),
        (1, 2, 3),
        tuple((1, 2, 3)),
    ]
    for obj in objs:
        result = has_callables(obj, 'keys', 'items', 'values')
        assert result is True



# Generated at 2022-06-23 18:10:35.524973
# Unit test for function has_callables
def test_has_callables():
    '''Tests the function has_callables.
    '''
    from collections import UserDict
    from collections.abc import Container, Iterable
    from decimal import Decimal
    import pytest
    from flutils.objutils import has_callables

    def fn():
        pass

    class Test:
        def foo(self):
            pass

    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'pop')
    assert not has_callables(UserDict(), 'get', 'keys', 'items', 'values', 'pop')

    assert has_callables(Test(), 'foo')
    assert not has_callables(Test(), 'bar')
    assert not has_callables(Test, 'foo')
    assert not has_callables(Test, 'bar')


# Generated at 2022-06-23 18:10:38.290290
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:10:40.285058
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'foo') == False
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') == True



# Generated at 2022-06-23 18:10:43.053920
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """
    Test for function has_any_attrs
    """
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-23 18:10:44.546403
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import doctest
    doctest.testmod()



# Generated at 2022-06-23 18:10:53.393360
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'fooooo','keys','items','values','foo') is False
    assert has_any_callables(dict(),'keys','items','values') is False
    assert has_any_callables(dict(),'keys','items','values','something') is False
    assert has_any_callables(dict(),'fooooo','keys','items','values','something') is False


# Generated at 2022-06-23 18:11:00.918764
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1,b=2)
    assert has_attrs(obj, 'get') is True
    assert has_attrs(obj, 'get', 'keys') is True
    assert has_attrs(obj, 'get', 'keys', 'items') is True
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(obj, 'get', 'keys', 'items', 'values', 'something') is False


# Generated at 2022-06-23 18:11:11.605402
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list())==True
    assert is_list_like(set())==True
    assert is_list_like(frozenset())==True
    assert is_list_like(tuple())==True
    assert is_list_like(deque())==True
    assert is_list_like(dict().keys())==True
    assert is_list_like(dict().values())==True
    assert is_list_like(dict().items())==True
    assert is_list_like(dict().keys())==True
    assert is_list_like(iter(dict().keys()))==True
    assert is_list_like(iter(dict().values()))==True
    assert is_list_like(iter(dict().items()))==True
    assert is_list_like(UserList())==True

   

# Generated at 2022-06-23 18:11:16.179030
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo_bar')

# Generated at 2022-06-23 18:11:20.289329
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:11:22.403590
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict()
    assert has_any_callables(d, 'get', 'keys', 'items', 'values') is True

# Generated at 2022-06-23 18:11:26.098823
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-23 18:11:30.208691
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables."""
    if has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') != True:
        raise AssertionError("`has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') != True` is not True")



# Generated at 2022-06-23 18:11:40.242691
# Unit test for function is_list_like
def test_is_list_like():
    l = [1, 2, 3, 4]
    r = reversed(l)
    t = (1, 2, 3, 4)
    s = {1, 2, 3, 4}
    assert is_list_like(l) is True
    assert is_list_like(r) is True
    assert is_list_like(t) is True
    assert is_list_like(s) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(sorted(l, reverse=True)) is True
    assert is_list_like(sorted(t, reverse=True)) is True

# Generated at 2022-06-23 18:11:48.357560
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict(),'get','keys','items')
    assert has_attrs(dict(),'get','keys')
    assert has_attrs(dict(),'get')
    assert has_attrs(dict(),'keys')
    assert has_attrs(dict(),'items')
    assert has_attrs(dict(),'values')

    assert not has_attrs(dict(),'something')
    assert not has_attrs(dict(),'get','something')
    assert not has_attrs(dict(),'keys','something')
    assert not has_attrs(dict(),'get','something','keys')
    assert not has_attrs(dict(),'something','keys','items')


# Generated at 2022-06-23 18:11:52.593657
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:12:00.505860
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from typing import Any as _Any
    from unittest import TestCase
    from unittest.mock import MagicMock


# Generated at 2022-06-23 18:12:07.058023
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs('abcde', 'startswith')
    assert not has_attrs(dict(),'foo')
    assert not has_attrs('abcde', 'foo')
    assert not has_attrs(dict(),'foo', 'bar')
    assert not has_attrs('abcde', 'foo', 'bar')


# Generated at 2022-06-23 18:12:10.243244
# Unit test for function has_attrs
def test_has_attrs():
    
    # Execute the function with valid parameters
    assert has_attrs(dict(),'get','keys','items','values')


# Generated at 2022-06-23 18:12:15.855416
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get')
    assert has_callables(dict(), 'keys', 'items', 'values')
    assert not has_callables(dict(), 'foo')
    assert not has_callables(dict(), 'get', 'foo')
    assert not has_callables(dict(), 'foo', 'foo')
    assert not has_callables(dict(), 'items', 'foo')
    assert len(str(has_callables.__doc__)) > 0


# Generated at 2022-06-23 18:12:27.128178
# Unit test for function has_callables
def test_has_callables():
    """Test ``has_callables`` function."""
    from hypothesis import given
    from hypothesis.strategies import one_of, dictionaries, lists, sets, text
    from flutils.objutils import has_callables, has_attrs

    @given(one_of(text(), dictionaries(text(), text()), lists(text()),
                  sets(text())), lists(text()))
    def test_has_callables_not_iter(obj: _Any, attrs: list) -> None:
        """Check that ``has_callables`` does not iterate."""
        assert has_callables(obj, *attrs) is False


# Generated at 2022-06-23 18:12:31.683218
# Unit test for function has_callables
def test_has_callables():
    dict_object = dict(a = 1, b = 2)
    assert(has_callables(dict_object,'get','keys','items','values') == True)
    assert(has_callables(dict_object, 'get', 'keys', 'values', 'something') == False)


# Generated at 2022-06-23 18:12:34.925877
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    assert has_callables(obj, 'get', 'keys', 'items', 'something') == False
    assert has_callables(obj, 'get', 'keys', 'items','values') == True


# Generated at 2022-06-23 18:12:47.229274
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    lst = list(range(1, 10))
    assert is_list_like(lst) is True

    lst = tuple(range(1, 10))
    assert is_list_like(lst) is True

    lst = set(range(1, 10))
    assert is_list_like(lst) is True

    lst = frozenset(range(1, 10))
    assert is_list_like(lst) is True

    lst = deque(range(1, 10))
    assert is_list_like(lst) is True

    lst = reversed(range(1, 10))


# Generated at 2022-06-23 18:12:56.774173
# Unit test for function is_list_like
def test_is_list_like():
    from collections import OrderedDict, defaultdict, ChainMap
    from decimal import Decimal
    from flutils.objutils import is_list_like
    # True
    obj = [1, 2, 3]
    assert is_list_like(obj) is True
    obj = (1, 2, 3)
    assert is_list_like(obj) is True
    obj = {1, 2, 3}
    assert is_list_like(obj) is True
    obj = frozenset({1, 2, 3})
    assert is_list_like(obj) is True
    obj = reversed([1, 2, 3])
    assert is_list_like(obj) is True
    obj = sorted('hello')
    assert is_list_like(obj) is True
    obj = dict(a=1, b=2)


# Generated at 2022-06-23 18:13:01.509750
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == False
    assert has_callables(set(), 'add', 'discard') == True
    assert has_callables((1, 2, 3), 'append') == False

# Generated at 2022-06-23 18:13:05.865884
# Unit test for function is_list_like
def test_is_list_like():
    from unittest import TestCase, main

    class _TestCase(TestCase):
        def test__all(self):
            from collections import (
                ChainMap,
                Counter,
                OrderedDict,
                UserDict,
                UserList,
                UserString,
                defaultdict
            )
            from decimal import Decimal
            import random

            # Decimal instances can be in a list
            self.assertTrue(is_list_like([Decimal('1')]))
            self.assertFalse(is_list_like(Decimal('1')))

            # dict instances can be in a list
            self.assertFalse(is_list_like({1, 2, 3}))

            # int instances can be in a list
            self.assertTrue(is_list_like([1, 2, 3]))

# Generated at 2022-06-23 18:13:16.147473
# Unit test for function is_list_like
def test_is_list_like():
    """Test function is_list_like.
    """
    print('Testing function is_list_like...', end='')
    import sys
    assert is_list_like(sys.modules['flutils.objutils'].__dict__['is_list_like']) is True
    assert is_list_like(None) is False
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like([]) is True
    assert is_list_like('hello') is False
    assert is_list_like(123) is False
    assert is_list_like(123.45) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(tuple()) is True

# Generated at 2022-06-23 18:13:21.348444
# Unit test for function has_any_callables
def test_has_any_callables():
    '''Test function has_any_callables'''
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-23 18:13:30.909348
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'keys','items','values','foo')
    assert has_any_callables(dict(),'keys','items','values')
    assert has_any_callables(dict(),'get','keys','items')
    assert has_any_callables(dict(),'get','keys')
    assert has_any_callables(dict(),'get')
    assert has_any_callables(dict(),'foo') is False
    assert has_any_callables(dict()) is False


# Generated at 2022-06-23 18:13:34.279796
# Unit test for function has_attrs
def test_has_attrs():
    dictionary = dict(a=1, b=2)
    assert has_attrs(dictionary, "get", "keys", "items", "values") == True

# Generated at 2022-06-23 18:13:38.685460
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    obj = dict()
    func_list = ['get', 'keys', 'items', 'values']
    assert has_any_callables(obj,*func_list) == True
    assert has_any_callables(obj,'get','keys','items','values','foo') == True
    assert has_any_callables(obj,'foo') == False

# Unit test function has_attrs

# Generated at 2022-06-23 18:13:45.342451
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import namedtuple
    TestClass = namedtuple('TestClass', ['a', 'b', 'c'])
    obj = TestClass(1, 2, 3)
    for attr in ('a', 'c', '__dict__'):
        assert has_any_attrs(obj, attr) is True
    for attr in ('d', 'e'):
        assert has_any_attrs(obj, attr) is False


# Generated at 2022-06-23 18:13:49.730603
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs({}, 'keys', 'items', 'values', 'get', 'foo') is True
    assert has_any_attrs({}, 'foo', 'bar', 'baz', 'qux') is False



# Generated at 2022-06-23 18:13:53.273861
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables({'bar': 'baz'}, 'foo', 'keys', 'bar') is False
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-23 18:13:56.793101
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True

if __name__ == "__main__":
    test_has_callables()

# Generated at 2022-06-23 18:14:08.317859
# Unit test for function has_attrs
def test_has_attrs():
    from collections.abc import ValuesView, KeysView, UserList
    assert has_attrs(dict(a=1, b=2), 'keys', 'values', 'items') is True
    assert has_attrs(dict(a=1, b=2), 'keys', 'values', 'items', 'foo') is False
    assert has_attrs(dict().keys(), '__contains__') is True
    assert has_attrs(dict().keys(), '__contains__', '__iter__') is True
    assert has_attrs(dict().keys(), '__contains__', '__iter__', '__hash__')
    assert has_attrs(dict(a=1, b=2), 'keys', 'values', 'items', '__add__') is False

# Generated at 2022-06-23 18:14:16.239402
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'somethinghere') is False

    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'somethinghere') is False



# Generated at 2022-06-23 18:14:28.721205
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values')
    assert not has_any_callables(dict(),'get','keys','items','values','foo')
    assert not has_any_callables(dict(),'geta','keys','items','values','foo')
    assert not has_any_callables(dict(),'get','keysa','items','values','foo')
    assert not has_any_callables(dict(),'get','keys','itemsa','values','foo')
    assert not has_any_callables(dict(),'get','keys','items','valuesa','foo')
    assert not has_any_callables(dict(),'get','keys','items','values','fooa')



# Generated at 2022-06-23 18:14:31.924155
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict(),'keys','items') is False


# Generated at 2022-06-23 18:14:35.796948
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:14:38.287144
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo', 'bar') is False


# Generated at 2022-06-23 18:14:47.146055
# Unit test for function has_attrs
def test_has_attrs():
    class TestAttrs:

        def __init__(self, attrs):
            self.attrs = attrs

        def __getattr__(self, item: str):
            if item in self.attrs:
                return item
            raise AttributeError(item)

        def __dir__(self):
            return self.attrs

    # Test to make sure has_attrs works as expected.
    testobj = TestAttrs(('foo', 'bar', 'baz'))
    assert has_attrs(testobj, 'foo', 'bar', 'baz') is True
    assert has_attrs(testobj, 'foo', 'bar', 'baz', 'blah') is False
    assert has_attrs(testobj, 'bar', 'baz') is True

# Generated at 2022-06-23 18:14:54.776948
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import sh
    obj = sh.Command('ls')
    assert has_any_attrs(obj, 'bake', 'bake_me_a_cake') is False
    assert has_any_attrs(obj, 'get_out', 'get_in') is False
    assert has_any_attrs(obj, 'bake', 'want_to_make') is False
    assert has_any_attrs(obj, 'get_out', 'get_in') is False
    assert has_any_attrs(obj, 'get_out', 'get_in') is False


# Generated at 2022-06-23 18:15:03.620722
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import UserList, ValuesView, KeysView, deque

    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like(sorted('hello')) is False
    assert is_list_like('hello') is False
    assert is_list_like({}) is False
    assert is_list_like(None) is False

    # Unit test: UserList
    lst = UserList([1, 2, 3])
    assert is_list_like(lst) is True
    assert is_list_like(lst.data) is True

    # Unit test: ValuesView
    obj = dict(a=1, b=2)
    assert is_list

# Generated at 2022-06-23 18:15:11.955267
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert not is_subclass_of_any(obj, UserList)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(
        obj.items(), ValuesView, KeysView, UserList
    )

# Generated at 2022-06-23 18:15:13.890146
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')


# Generated at 2022-06-23 18:15:20.250989
# Unit test for function has_attrs
def test_has_attrs():
    from collections import (
        UserList,
        deque,
    )

    assert has_attrs('hello', 'isupper') is True
    assert has_attrs(dict(), 'get', 'keys') is True
    assert has_attrs(UserList(), 'append') is True
    assert has_attrs(deque(), 'append') is True
    assert has_attrs(dict(), 'keys', 'append') is False



# Generated at 2022-06-23 18:15:29.526416
# Unit test for function has_callables
def test_has_callables():
    import pytest
    from publicsuffixlist import PublicSuffixList
    from flutils.objutils import has_callables

    class test_obj(object):

        def foo(self):
            return True

        def bar(self):
            return True

        @staticmethod
        def baz():
            return True

        @classmethod
        def qux(cls):
            return True

    tmptest_obj = test_obj()
    assert has_callables(tmptest_obj, 'foo', 'bar', 'baz', 'qux') is True

    tmptest_obj = PublicSuffixList()
    assert has_callables(tmptest_obj, 'get_public_suffix') is True

    assert has_callables(tmptest_obj, 'foo') is False


# Generated at 2022-06-23 18:15:35.102714
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(object, 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-23 18:15:47.200633
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from typing import Mapping, Union, Set
    assert is_list_like(['a', 'b', 'c'])
    assert is_list_like(('a', 'b', 'c'))
    assert is_list_like({'a', 'b', 'c'})
    assert is_list_like({'a':1, 'b':2, 'c':3})
    assert is_list_like(set())
    assert is_list_like(list())
    assert is_list_like(dict())
    assert is_list_like(tuple())
    assert is_list_like(frozenset())
    assert is_list_like(deque())
    assert is_list_like('abc')

# Generated at 2022-06-23 18:15:58.146343
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(),'foo','bar','baz'))
    assert(has_any_attrs(dict(a=1,b=2,c=3),*dict(a=1,b=2,c=3).keys()))
    assert(has_any_attrs(dict(a=1,b=2,c=3),*dict(a=1,b=2,c=3).values()))
    assert(has_any_attrs(dict(a=1,b=2,c=3),*dict(a=1,b=2,c=3).items()))
    assert(not has_any_attrs(dict(a=1,b=2,c=3),'foo','bar','baz'))



# Generated at 2022-06-23 18:16:05.351783
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'valuese') == False
    assert has_attrs('hello', 'get', 'keys', 'items', 'values') == False
    assert has_attrs(None, 'keys', 'items') == False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'foo', 'values') == False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'foo',) == False


# Generated at 2022-06-23 18:16:11.568710
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import UserDict

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(reversed((1, 2, 3))) is True
    assert is_list_like(reversed({1, 2, 3})) is True
    assert is_list_like(reversed({1: 1, 2: 2, 3: 3})) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted(('h', 'e', 'l', 'l', 'o'))) is True
    assert is_list_like(UserDict()) is False