

# Generated at 2022-06-23 18:06:14.125697
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import (
        KeysView,
        ValuesView,
    )
    from collections import (
        UserList,
        deque,
    )
    from decimal import (
        Decimal,
    )
    from typing import (
        Any as _Any,
        Callable as _Callable,
        DefaultDict as _DefaultDict,
        Dict as _Dict,
    )
    import datetime as _dt

    is_fn = is_list_like
    assert is_fn(777) is False, 'Expected False.'
    assert is_fn(b'777') is False, 'Expected False.'

# Generated at 2022-06-23 18:06:21.430976
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs('hello','upper','upper')
    assert has_any_attrs(123,'real','imag','conjugate')
    assert not has_any_attrs(1,'e','pi','nan')
    dct = dict(a=1, b=2)
    assert has_any_attrs(dct,'get','keys','items','values')


# Generated at 2022-06-23 18:06:23.658591
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-23 18:06:29.267273
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','foo') is False
    assert has_attrs(dict(),'foo','bar','baz','quux') is False


# Generated at 2022-06-23 18:06:33.407189
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'items', 'values')
    assert has_callables(obj, 'keys', 'items', 'values', 'foo')
    assert has_callables(obj, 'foo', 'keys', 'items', 'values') is False

# Generated at 2022-06-23 18:06:39.083675
# Unit test for function has_callables
def test_has_callables():

    obj = dict()
    has_callables(obj, 'foo', 'bar')
    has_callables(obj, 'get')
    has_callables(obj, 'keys', 'items')
    has_callables(obj, 'keys', '__contains')

    obj = list()
    has_callables(obj, 'foo', 'bar')
    has_callables(obj, 'pop')
    has_callables(obj, 'count', 'index')
    has_callables(obj, 'sort', '__contains')


# Generated at 2022-06-23 18:06:44.145782
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(), 'keys') is True
    assert has_callables(dict(), 'items') is True
    assert has_callables(dict(), 'values') is True
    assert has_callables(dict(), 'foo') is False



# Generated at 2022-06-23 18:06:54.815598
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3])
    assert is_list_like([1,2,3])
    assert is_list_like((1,2,3))
    assert is_list_like({"a":1,"b":2})
    assert is_list_like({"a"})
    assert is_list_like({1,2,3})
    assert is_list_like(deque([1,2,3]))
    assert is_list_like(iter([1,2,3]))
    assert is_list_like(UserList([1,2,3]))
    assert is_list_like(frozenset({1,2,3}))
    assert is_list_like(sorted({1,2,3,}))
    #assert is_list_like(None)

# Generated at 2022-06-23 18:06:57.813599
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','keys','items','valuesxx') is False


# Generated at 2022-06-23 18:07:04.201539
# Unit test for function has_callables
def test_has_callables():
    # Test valid
    obj1 = dict(a=1, b=2)
    assert has_callables(obj1, 'get', 'keys', 'items', 'values') is True

    # Test invalid
    obj2 = dict(a=1, b=2)
    assert has_callables(obj2, 'num_items', 'num_keys', 'num_values') is False



# Generated at 2022-06-23 18:07:15.274892
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        UserList,
        ValuesView,
        KeysView,
    )
    assert is_subclass_of_any(dict(), dict)
    assert is_subclass_of_any(dict(), dict)
    assert is_subclass_of_any(dict().keys(), ValuesView)
    assert is_subclass_of_any(dict().keys(), KeysView)
    assert is_subclass_of_any(dict().keys(), UserList)
    assert is_subclass_of_any(dict().keys(), ValuesView)
    assert is_subclass_of_any(dict().keys(), KeysView, UserList)
    assert is_subclass_of_any(dict().keys(), UserList, ValuesView)
    assert is_subclass_of_any(UserList, ValuesView)
    assert is_sub

# Generated at 2022-06-23 18:07:18.421799
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False


# Generated at 2022-06-23 18:07:30.012761
# Unit test for function is_list_like
def test_is_list_like():
    # Unit test: test_is_list_like
    assert is_list_like([1, 2]) is True
    assert is_list_like(sorted([1, 2])) is True
    assert is_list_like(set([1, 2])) is True
    assert is_list_like(sorted(set([1, 2]))) is True
    assert is_list_like(tuple([1, 2])) is True
    assert is_list_like(frozenset([1, 2])) is True
    assert is_list_like(deque([1, 2])) is True
    assert is_list_like(values_view_obj) is True
    assert is_list_like(keys_view_obj) is True
    assert is_list_like(UserList([1, 2])) is True
   

# Generated at 2022-06-23 18:07:42.431411
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    lst_like_obj = [1, 2, 3]
    itr_like_obj = sorted('hello')
    # noinspection PyTypeChecker
    not_lst_like_obj = 1
    # noinspection PyTypeChecker
    not_lst_like_obj = True
    # noinspection PyTypeChecker
    not_lst_like_obj = b'hello'
    # noinspection PyTypeChecker
    not_lst_like_obj = ChainMap()
    # noinspection PyTypeChecker
    not_lst_like_obj = Counter()
    # noinspection PyTypeChecker
    not_

# Generated at 2022-06-23 18:07:45.041923
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1,b=2)

    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(obj.keys(),ValuesView,UserList) == False



# Generated at 2022-06-23 18:07:46.848767
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-23 18:07:48.896469
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:07:54.294951
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(),'foo') == False
    assert has_any_callables(dict(),'get') == True
    assert has_any_callables(dict(),'get','foo') == True


# Generated at 2022-06-23 18:07:57.113560
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','values')
    assert not has_any_callables(dict(),'get','keys','values','foo')


# Generated at 2022-06-23 18:07:57.797476
# Unit test for function has_any_callables
def test_has_any_callables():
    pass

# Generated at 2022-06-23 18:07:59.359873
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-23 18:08:01.404512
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:08:11.452306
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(['a', 'b', 'c']) is True
    assert is_list_like(('a', 'b', 'c')) is True
    assert is_list_like('abc') is False
    assert is_list_like(sorted((1, 2, 3))) is True
    assert is_list_like(reversed((1, 2, 3))) is True
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like(frozenset(range(5))) is True
    assert is_list_like(123) is False
    assert is_list_like(['a', 'b', 'c']) is True
    assert is_list_like(('a', 'b', 'c')) is True

# Generated at 2022-06-23 18:08:17.009971
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)

    try:
        assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    except:
        raise


# Generated at 2022-06-23 18:08:19.560182
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')==True


# Generated at 2022-06-23 18:08:23.090816
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.values(), ValuesView)
    assert is_subclass_of_any(obj.keys(), KeysView)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList), obj

# Generated at 2022-06-23 18:08:29.057666
# Unit test for function has_callables
def test_has_callables():
    import pytest
        # Test 1: Test function for valid input
    def test_has_callables_valid():
        obj1 = dict(a=1, b=2)

# Generated at 2022-06-23 18:08:38.117784
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(dict(), 'keys', 'items', 'values') is True
    assert has_any_attrs(dict(), 'items', 'values') is True
    assert has_any_attrs(dict(), 'values') is True
    assert has_any_attrs(dict()) is False
    assert has_any_attrs(dict(), 'foo', 'bar', 'thing') is False



# Generated at 2022-06-23 18:08:43.972300
# Unit test for function has_callables
def test_has_callables():
    d = dict(a=1, b=2)
    assert has_callables(d, 'get', 'keys', 'items', 'values') is True
    assert has_callables(d, 'get', 'keys', 'items', 'val', 'something') is False



# Generated at 2022-06-23 18:08:54.536109
# Unit test for function has_any_callables
def test_has_any_callables():
    test_obj = {}
    assert has_any_callables(test_obj, 'get', 'keys', 'items', 'values')
    test_obj = []
    assert has_any_callables(test_obj, 'append', 'insert', 'extend')
    test_obj = ()
    assert has_any_callables(test_obj, 'count', 'index')
    test_obj = frozenset()
    assert has_any_callables(test_obj, 'difference', 'intersection')
    test_obj = (1, 2, 3)
    assert has_any_callables(test_obj, 'count', 'index')
    test_obj = {'a':1, 'b':2, 'c':3}

# Generated at 2022-06-23 18:09:02.650511
# Unit test for function has_callables
def test_has_callables():
    _1 = dict(a=1, b=2, c=3)
    _2 = dict(d=1, e=2, f=3)
    _3 = {}
    _4 = None
    _5 = (1, 2, 3)
    _6 = [4, 5, 6]
    _7 = (1,)
    _8 = [4]
    _9 = set([4, 5, 6])
    _10 = frozenset((1, 2, 3))
    _11 = [1, 2, 3]
    _11[1] = 23
    _12 = tuple((1, 2, 3))
    _13 = bytes((1))

    assert has_callables(_1, 'clear', 'copy', 'fromkeys') is True

# Generated at 2022-06-23 18:09:11.337179
# Unit test for function is_list_like
def test_is_list_like():

    import collections
    import decimal
    import pprint

    #from flutils.objutils import is_list_like

    NON_LISTS = (
        None, bool, bytes, bool, int, float, str,
    )
    LISTS = (
        list, set, frozenset, tuple,
        collections.UserList,
        collections.Iterator,
        collections.KeysView,
        collections.ValuesView,
        collections.deque,
        decimal.Decimal
    )

    #: :type: collections.UserList
    list_like = collections.UserList()
    #: :type: collections.UserList
    not_list = collections.UserDict()



# Generated at 2022-06-23 18:09:14.502342
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import UserList, UserString
    assert is_subclass_of_any(UserList(), list, UserString) == True


# Generated at 2022-06-23 18:09:22.886352
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables
    """
    import pytest
    from flutils.objutils import has_callables
    obj = dict()
    attrs = tuple()
    res = has_callables(obj, *attrs)
    assert res is True
    with pytest.raises(TypeError):
        has_callables(obj)
    with pytest.raises(TypeError):
        has_callables(obj, 'foo')
    with pytest.raises(TypeError):
        has_callables(obj, 'foo', 'bar')


# Generated at 2022-06-23 18:09:33.538463
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') \
        == True, 'Failed.'
    assert has_callables(dict(), 'get', 'keys', 'items', 'value') \
        == False, 'Failed.'
    assert has_callables(dict(), 'get', 'keys', 'item', 'values') \
        == False, 'Failed.'
    assert has_callables(dict(), 'get', 'keys', 'values') \
        == True, 'Failed.'
    assert has_callables(dict(), 'get', 'key', 'values') \
        == False, 'Failed.'


# Generated at 2022-06-23 18:09:38.786922
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(obj.items(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:09:46.710307
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True
    assert is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList) is True
    assert is_subclass_of_any(obj.items(),ValuesView,KeysView,UserList) is False
    assert is_subclass_of_any(obj.keys(),KeysView) is True
    assert is_subclass_of_any(obj.values(),ValuesView) is True
    assert is_subclass_of_any(obj.items(),KeysView,ValuesView) is False

# Generated at 2022-06-23 18:09:51.559046
# Unit test for function has_attrs
def test_has_attrs():

    class MyClass(object):
        def __init__(self, my_attr_1, my_attr_2):
            self.my_attr_1 = my_attr_1
            self.my_attr_2 = my_attr_2
            self.my_unused_attr = None

    assert has_attrs(MyClass, 'my_attr_1', 'my_attr_2') is True
    assert has_attrs(MyClass, 'my_attr_1', 'my_attr_3') is False
    assert has_attrs(MyClass, 'my_unused_attr', 'foo', 'bar') is False



# Generated at 2022-06-23 18:09:54.549663
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs

    obj = dict()

    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:10:06.183895
# Unit test for function has_callables
def test_has_callables():
    # testing tuple
    obj = (1, 2, 3)
    attrs = [
        'count',
        'index',
    ]
    # testing set
    obj = {1, 2, 3}
    attrs.extend([
        'add',
        'clear',
        'copy',
        'difference',
        'difference_update',
        'intersection',
        'intersection_update',
        'isdisjoint',
        'issubset',
        'issuperset',
        'pop',
        'remove',
        'symmetric_difference',
        'symmetric_difference_update',
        'union',
        'update',
    ])
    # testing dict
    obj = dict(a=1, b=2)

# Generated at 2022-06-23 18:10:09.337271
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True

# Unit test function has_callables

# Generated at 2022-06-23 18:10:20.183575
# Unit test for function has_any_callables
def test_has_any_callables():
    assert (
        has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
        is True
    )
    assert (
        has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar')
        is True
    )
    assert (
        has_any_callables(
            dict(),
            'get',
            'keys',
            'items',
            'values',
            'foo',
            'bar',
            'baz'
        )
        is True
    )
    assert has_any_callables(dict(), 'foo') is False
    assert has_any_callables(dict(), 'get', 'foo') is False

# Generated at 2022-06-23 18:10:27.980385
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """ Run tests for the function is_subclass_of_any

    """
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, list) == True



# Generated at 2022-06-23 18:10:31.844980
# Unit test for function has_callables
def test_has_callables():
    """Test function :func:`flutils.objutils.has_callables`."""
    from flutils.objutils import has_callables
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:10:33.454118
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:10:42.498651
# Unit test for function is_list_like
def test_is_list_like():
    from dataclasses import dataclass
    from collections import ChainMap
    from decimal import Decimal


# Generated at 2022-06-23 18:10:53.434151
# Unit test for function is_list_like
def test_is_list_like():
    """Test the function `is_list_like`"""
    assert is_list_like([]) is True
    assert is_list_like(dict()) is False
    assert is_list_like(reversed(dict())) is True
    assert is_list_like(UserList()) is True
    assert is_list_like(dict().keys()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(None) is False
    assert is_list_like(bool()) is False
    assert is_list_like(int()) is False
    assert is_list_like(float()) is False
    assert is_

# Generated at 2022-06-23 18:11:03.539799
# Unit test for function has_callables
def test_has_callables():
    class A:
        def __init__(self):
            self.foo = 'bar'
        def bar(self):
            return self.foo

    class B:
        def __init__(self):
            self.foo = 'bar'
        def bar(self):
            return self.foo

    def baz():
        return None

    assert has_callables(A(), 'bar') is True
    assert has_callables(B(), 'bar') is True
    assert has_callables(baz) is True
    assert has_callables(A(), 'baz') is False
    assert has_callables(B(), 'baz') is False


# Generated at 2022-06-23 18:11:07.231895
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    from typing import List
    obj = dict(a=1, b=2)
    y = is_subclass_of_any(obj.keys(),List,ValuesView,KeysView,UserList)
    assert y is True

# Generated at 2022-06-23 18:11:15.406627
# Unit test for function is_list_like
def test_is_list_like():

    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)

    obj = [1, 2, 3]
    logger.info(f'is_list_like(obj) == {is_list_like(obj)}')
    assert is_list_like(obj) is True

    obj = (1, 2, 3)
    logger.info(f'is_list_like(obj) == {is_list_like(obj)}')
    assert is_list_like(obj) is True

    obj = reversed([1, 2, 3])
    logger.info(f'is_list_like(obj) == {is_list_like(obj)}')
    assert is_list_like(obj) is True

    obj = list(obj)

# Generated at 2022-06-23 18:11:24.874886
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from sys import getsizeof

    obj = None
    assert is_list_like(obj) == False

    obj = True
    assert is_list_like(obj) == False

    obj = 'foo'
    assert is_list_like(obj) == False

    obj = bytes('foo', 'utf-8')
    assert is_list_like(obj) == False

    obj = defaultdict(int)
    assert is_list_like(obj) == False

    obj = Decimal('3.14')
    assert is_list_like(obj) == False

    obj = dict()

# Generated at 2022-06-23 18:11:29.615140
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'values') is True
    assert has_callables(obj, 'get') is False
    assert has_callables(obj, 'keys', 'values', 'pop') is False
    assert has_callables(obj, 'pop') is False


# Generated at 2022-06-23 18:11:35.683041
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from flutils.objutils import _LIST_LIKE
    a = reversed([1, 2, 3])
    assert a.__class__ in _LIST_LIKE
    assert is_list_like(a)

    a = sorted('hello')
    assert a.__class__ in _LIST_LIKE
    assert is_list_like(a)



# Generated at 2022-06-23 18:11:44.325331
# Unit test for function has_callables
def test_has_callables():
    assert has_callables([], 'index', 'append') == True
    assert has_callables(dict(), 'get', 'keys') == True
    assert has_callables(dict(), 'get', 'keys', 'something') == True
    assert has_callables(dict(), 'get', 'keys', 'append') == False
    assert has_callables(dict(), 'get', 'append') == False
    assert has_callables(dict(), 'index', 'append') == False
    assert has_callables(dict(), 'something', 'append') == False
    assert has_callables(dict(), 'something') == False
    assert has_callables(dict(),) == False
    assert has_callables(None, 'something') == False
    assert has_callables(None) == False



# Generated at 2022-06-23 18:11:46.667003
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-23 18:11:49.156110
# Unit test for function has_callables
def test_has_callables():
    d = dict()
    assert has_callables(d,'keys','get','values') == True
    assert has_callables(d,'keys','get','values','foo') == False


# Generated at 2022-06-23 18:11:59.261756
# Unit test for function is_list_like
def test_is_list_like():
    import pytest
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )

    # List-like objects are instances of:
    obj = [1, 2, 3]
    assert is_list_like(obj) is True

    obj = reversed(obj)
    assert is_list_like(obj) is True

    obj = UserList([1, 2, 3])
    assert is_list_like(obj) is True

    obj = reversed(obj)
    assert is_list_like(obj) is True

    obj = set(obj)
    assert is_list_like(obj) is True

    obj = sorted(obj)
    assert is_list_like(obj) is True


# Generated at 2022-06-23 18:12:03.629157
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(deque([1, 2, 3])) is True
    assert is_list_like(list(reversed([1, 2, 3]))) is True
    assert is_list_like(tuple(reversed([1, 2, 3]))) is True

# Generated at 2022-06-23 18:12:14.090411
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True # noqa: E501
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something') == True # noqa: E501
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values') == True # noqa: E501
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something', 'bar', 'foo') == True # noqa: E501
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something', 'bar', 'foo', 'baz', 'qux') == True # noqa: E501
    assert has_any_call

# Generated at 2022-06-23 18:12:16.686060
# Unit test for function has_any_attrs
def test_has_any_attrs():
    d = dict()
    assert has_any_attrs(d, 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-23 18:12:19.441453
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    return None

# Generated at 2022-06-23 18:12:22.016570
# Unit test for function has_any_callables
def test_has_any_callables():
    print(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo'))



# Generated at 2022-06-23 18:12:27.082667
# Unit test for function has_attrs
def test_has_attrs():
    """Test function has_attrs."""
    # Test the and condition for an empty object
    assert has_attrs(list(),'append','extend','clear','sort') is False
    # Test the or condition for an empty object
    assert has_attrs(list(),'append','extend','clear','sort','foo','bar','baz') is False
    # Test the and condition for a non-empty object
    assert has_attrs(set(),'add','remove','discard','clear') is True
    # Test the or condition for a non-empty object
    assert has_attrs(
        set(),'add','remove','discard','clear','pop','foo','bar','baz'
    ) is True
    # Test the and condition for an empty object
    assert has_attrs(dict(),'get','keys','items','values') is True

# Generated at 2022-06-23 18:12:32.105044
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    attrs = ['get', 'keys', 'items', 'values', 'foo']
    assert has_any_callables(obj, *attrs) is True
    assert has_any_callables(obj, *['foo', 'bar']) is False



# Generated at 2022-06-23 18:12:35.272226
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserDict
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(UserDict({}),'get','keys','items','values','something')


# Generated at 2022-06-23 18:12:38.968060
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('abcd','upper','lower','replace','startswith',
                         'endswith','lstrip','rstrip','strip')


# Generated at 2022-06-23 18:12:50.952586
# Unit test for function is_list_like
def test_is_list_like():
    # noinspection PyUnresolvedReferences
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from decimal import Decimal
    from flutils.objutils import is_list_like

    # List-like objects that should be detected.
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like({'hello': 'world'}.items()) is True
    assert is_list_like({'hello': 'world'}.keys()) is True
    assert is_list_like({'hello': 'world'}.values()) is True
    assert is_list_like('hello') is False
    assert is_list_like

# Generated at 2022-06-23 18:13:03.176855
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap, Counter, OrderedDict, UserDict, UserString
    from collections.abc import Hashable
    from decimal import Decimal
    from flutils.objutils import is_list_like

    assert is_list_like([]) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(iter('abc')) is True
    assert is_list_like(range(4)) is True
    assert is_list_like(deque('d')) is True
    assert is_list_like(KeysView({'a': 1})) is True

# Generated at 2022-06-23 18:13:05.534741
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = ['foo', 'bar']
    assert has_any_callables(obj,'__getitem__','__len__','__add__') is True



# Generated at 2022-06-23 18:13:13.789074
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True)
    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView) is True)
    assert(is_subclass_of_any(obj.keys(), UserList) is False)
    assert(is_subclass_of_any(obj.keys(), UserDict) is False)
    assert(is_subclass_of_any(obj.keys(), dict) is False)

# Generated at 2022-06-23 18:13:16.978441
# Unit test for function has_any_callables
def test_has_any_callables():
    pass
    # TODO
    # assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    # assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-23 18:13:20.638908
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'keys','items','values')


# Generated at 2022-06-23 18:13:28.862050
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import (
        is_subclass_of_any,
        )
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False
    return

# Generated at 2022-06-23 18:13:35.535119
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(bytes()) is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False


# Generated at 2022-06-23 18:13:40.502554
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') != False
    assert has_any_callables(dict(), 'foo') == False


# Generated at 2022-06-23 18:13:52.138161
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Set up
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from typing import Any as _Any

    _dict_ = dict(foo='bar')

    # Test
    assert(has_any_attrs(_dict_, 'get', 'keys', 'items', 'values', 'something'))

    assert(has_any_attrs(_dict_.items(), '__iter__', '__next__'))
    assert(has_any_attrs(_dict_.values(), '__iter__', '__next__'))
    assert(has_any_attrs(_dict_.keys(), '__iter__', '__next__'))


# Generated at 2022-06-23 18:13:56.506116
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'foo', 'values') is False



# Generated at 2022-06-23 18:13:59.212495
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:14:00.918610
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert (
        has_any_attrs(
            dict(),
            'get',
            'keys',
            'items',
            'values',
            'something'
        ) is True
    )



# Generated at 2022-06-23 18:14:04.018239
# Unit test for function has_attrs
def test_has_attrs():
    d = dict(a=1, b=2)
    assert has_attrs(d, 'get', 'keys', 'values', 'items') is True



# Generated at 2022-06-23 18:14:13.427875
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2]) == True
    assert is_list_like((1, 2)) == True
    assert is_list_like(True) == False
    assert is_list_like(False) == False
    assert is_list_like(dict(a=1, b=2)) == False
    assert is_list_like(dict(a=1, b=2).keys()) == True
    assert is_list_like(dict(a=1, b=2).values()) == True
    assert is_list_like(dict(a=1, b=2).items()) == True
    assert is_list_like('hello') == False
    assert is_list_like(list(x**2 for x in range(10))) == True

# Generated at 2022-06-23 18:14:26.391823
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'foo') is False
    assert has_callables(dict(), 'get') is True
    assert has_callables(dict(), 'keys') is True
    assert has_callables(dict(), 'items') is True
    assert has_callables(dict(), 'values') is True
    assert has_callables(dict(), 'pop') is True
    assert has_callables(dict(), 'update') is True
    assert has_callables(dict(), 'clear') is True
    assert has_callables(dict(), 'setdefault') is True

    assert has_callables(dict(), 'get', 'keys') is True
    assert has_callables(dict(), 'get', 'keys', 'foo') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-23 18:14:27.917607
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(obj, 'foo', 'bar') is False



# Generated at 2022-06-23 18:14:34.459261
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    from collections.abc import OrderedDict as ABCOrderedDict
    from collections.abc import UserDict as ABCUserDict
    from collections.abc import UserList as ABCUserList
    from collections.abc import UserString as ABCUserString
    from decimal import Decimal
    from typing import Mapping, MutableMapping
    assert has_callables(dict(a=1, b=2), 'get', 'keys') is True
    assert has_callables(ABCOrderedDict(a=1, b=2), 'get', 'keys') is True
    assert has_callables(defaultdict(list), 'get', 'keys') is True
    assert has_callables(ABCUserDict(a=1, b=2), 'get', 'keys') is True

# Generated at 2022-06-23 18:14:43.334415
# Unit test for function has_any_callables
def test_has_any_callables():
    import collections
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'get','keys','items','values') == True
    assert has_any_callables(dict(),'bar','baz') == False
    assert has_any_callables(None,'bar','baz') == False
    assert has_any_callables(False,'bar','baz') == False
    assert has_any_callables(True,'bar','baz') == False
    assert has_any_callables(collections.ChainMap(),'maps') == True
    assert has_any_callables(collections.Counter(),'keys','items','values') == True

# Generated at 2022-06-23 18:14:51.499301
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import defaultdict
    from itertools import chain

    assert has_any_callables(defaultdict(list, {'a': 1, 'b': 2}), 'keys')
    assert has_any_callables(chain('hello'), 'keys')
    assert has_any_callables(chain('hello'), 'foo', 'bar', 'keys')
    assert not has_any_callables({'a': 1, 'b': 2}, 'keys')

if __name__ == '__main__':
    # Unit test the module.
    test_has_any_callables()

# Generated at 2022-06-23 18:14:53.966585
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test function has_any_attrs."""
    print(has_any_attrs(dict(),'get','keys','items','values','something'))
    # True


# Generated at 2022-06-23 18:14:55.525376
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs({}, 'items') is True


# Generated at 2022-06-23 18:15:01.697962
# Unit test for function has_attrs
def test_has_attrs():
    assert (has_attrs(dict(), 'to_json', 'keys')) == True
    assert (has_attrs(dict(), 'to_json')) == False
    assert (has_attrs(dict(), 'to_json', 'keys', 'items')) == True
    assert (has_attrs(dict(), 'to_json', 'keys', 'items', 'foo')) == False
    assert (has_attrs(list(), 'to_json', 'keys', 'items', 'foo')) == False



# Generated at 2022-06-23 18:15:06.554001
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-23 18:15:17.912997
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'a', 'b', 'c') is False
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    obj = Mock(foo=1, bar=2)
    assert has_any_attrs(obj, 'foo', 'baz', 'bar', 'biz') is True
    assert has_any_attrs(obj, 'baz', 'biz') is False
    assert has_any_attrs(obj, 'foo', 'baz', 'bar', 'biz') is True
    assert has_any_attrs(obj, 'baz', 'biz') is False
    assert has_any_attrs(obj, 'baz', 'biz') is False

# Generated at 2022-06-23 18:15:28.300681
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import deque, KeysView, ValuesView
    assert has_any_callables(
        deque(),
        'append',
        'extend',
        'foo'
    )
    assert has_any_callables(
        KeysView(dict(a=1, b=2)),
        '__iter__',
        'add',
        'foo'
    )
    assert has_any_callables(
        ValuesView(dict(a=1, b=2)),
        '__iter__',
        'add',
        'foo'
    )
    assert has_any_callables(
        ValuesView(dict(a=1, b=2)),
        '__iter__',
        'add'
    ) is False

# Generated at 2022-06-23 18:15:36.530364
# Unit test for function has_attrs
def test_has_attrs():
    """Test for function :func:`has_attrs <flutils.objutils.has_attrs>`
    """
    from collections import deque

    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(deque(), 'append', 'pop', 'clear') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values',
                     'something') is False
    assert has_attrs(deque(), 'append', 'pop', 'foo') is False



# Generated at 2022-06-23 18:15:40.050095
# Unit test for function has_any_callables
def test_has_any_callables():
    _obj = dict()
    assert has_any_callables(_obj, 'get', 'keys', 'values', 'items', 'foo') is True

    # Unit test for function has_any_attrs

# Generated at 2022-06-23 18:15:49.290313
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), "get", "keys", "items", "values") is True
    assert has_callables(dict(), "get", "keys", "items") is False
    assert has_callables(dict(), "foo") is False
    assert has_callables(dict(), "foo", "bar") is False
    assert has_callables(dict(a=1), "get", "keys", "items", "values") is True
    assert has_callables(dict(a=1), "get", "keys", "items") is False
    assert has_callables(dict(a=1), "foo") is False
    assert has_callables(dict(a=1), "foo", "bar") is False



# Generated at 2022-06-23 18:15:52.509663
# Unit test for function has_any_callables
def test_has_any_callables():
    # Test1
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True

    # Test2
    assert has_any_callables(dict(),'keys','items','values','foo') == True

    # Test3
    assert has_any_callables(dict(),'get','foo') == False

    # Test4
    assert has_any_callables(dict(),'get',None) == False



# Generated at 2022-06-23 18:15:56.832115
# Unit test for function has_any_attrs
def test_has_any_attrs():
    key = 'a'
    value = 1
    obj = {key: value}

    assert has_any_attrs(obj, 'keys', 'items', 'values') is True
    assert has_any_attrs(obj, 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-23 18:16:02.320069
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True

    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_list_like(obj.keys()) == False

# Generated at 2022-06-23 18:16:06.665726
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict, "get", "keys", "items") == True
    assert has_callables(dict(), "get", "keys", "items") == True
    assert has_callables(dict, "get", "foo", "bar") == False
    assert has_callables(dict(), "get", "foo", "bar") == False



# Generated at 2022-06-23 18:16:16.440510
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList

    _list = [1, 2, 3]
    assert has_callables(_list, 'append', 'count') is True
    assert has_callables(_list, 'append', 'count', 'something') is False

    _set = set('abc')
    assert has_callables(_set, 'add', 'clear') is True
    assert has_callables(_set, 'add', 'clear', 'something') is False

    _frozenset = frozenset('abc')
    assert has_callables(_frozenset, 'copy', 'difference') is True
    assert has_callables(_frozenset, 'copy', 'difference', 'something') is False

    _tuple = (1, 2, 3)
    assert has_callables(_tuple, 'count', 'index') is True
