

# Generated at 2022-06-23 18:06:16.206218
# Unit test for function has_callables
def test_has_callables():
    class Person:
  
        def __init__(self, name):
            self.__name = name
    
        def get_name(self):
            return self.__name
  
    p = Person('John')
    assert(has_callables(p, 'get_name'))
  
  

# Generated at 2022-06-23 18:06:21.378092
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(obj, 'clear', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-23 18:06:28.038802
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import (
        has_any_callables
    )

    assert has_any_callables(dict(), 'get', 'keys', 'values') is True
    assert has_any_callables('hello', 'upper', 'lower', 'split') is True
    assert has_any_callables('hello', 'split', 'islower') is True
    assert has_any_callables('hello', 'upper', 'islower') is False
    assert has_any_callables('hello', 'split', 'islower()') is False



# Generated at 2022-06-23 18:06:31.716192
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_attrs(dict(), 'get', 'foo', 'bar', 'baz') is False



# Generated at 2022-06-23 18:06:43.379824
# Unit test for function is_list_like
def test_is_list_like():
    # Test for built-in list functions
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(sorted([1, 2, 3])) is True
    assert is_list_like(sorted([1, 2, 3], key=lambda x: x)) is True
    assert is_list_like(sorted([1, 2, 3], key=lambda x: x, reverse=True)) is True
    assert is_list_like(sorted('hello')) is True
    # Test for built-in list classes
    assert is_list_like(tuple()) is True
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_

# Generated at 2022-06-23 18:06:45.314633
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({'a': 1, 'b': 2}, 'items')



# Generated at 2022-06-23 18:06:49.079610
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj,'get','keys','items','values','update')
    # Unit test for function has_attrs

# Generated at 2022-06-23 18:06:54.773749
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs.

    Args:
        None.

    Returns:
        None.

    """
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'foo') is False
    assert has_any_attrs({}) is False


test_has_any_attrs.__test__ = False



# Generated at 2022-06-23 18:07:01.443133
# Unit test for function is_list_like
def test_is_list_like():
    class TestList(list):
        pass

    assert is_list_like(list())
    assert is_list_like(iter(list()))
    assert is_list_like(iter(set()))
    assert is_list_like(iter(tuple()))
    assert is_list_like(iter(deque()))
    assert is_list_like(values(dict()))
    assert is_list_like(keys(dict()))
    assert is_list_like(UserList())
    assert is_list_like(TestList())
    assert not is_list_like(None)
    assert not is_list_like(True)
    assert not is_list_like(b'')
    assert not is_list_like(ChainMap())
    assert not is_list_like(Counter())
    assert not is_

# Generated at 2022-06-23 18:07:13.061072
# Unit test for function is_list_like
def test_is_list_like():
    """ Test function is_list_like.
    """
    assert is_list_like(KeysView({})) is True
    assert is_list_like(ValuesView({})) is True
    assert is_list_like(UserList()) is True
    assert is_list_like(iter([])) is True
    assert is_list_like(deque()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like([]) is True
    assert is_list_like(set()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(bytes(b'')) is False
    assert is_list_like(ChainMap({}))

# Generated at 2022-06-23 18:07:25.138622
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like([1,]) is True
    assert is_list_like({}) is False
    assert is_list_like({1: "a"}) is False
    assert is_list_like("a") is False
    assert is_list_like({"a"}) is False
    assert is_list_like((2,)) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(sorted("hello")) is True
    assert is_list_like(ValuesView([1,2,3])) is True
    assert is_list_like(KeysView({1: "a", 2: "b"})) is True
    assert is_list_like(UserList([1,2,3]))

# Generated at 2022-06-23 18:07:26.959840
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-23 18:07:28.626651
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:07:35.944840
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    obj_classes = set(type(obj).__mro__)
    classes = set((
        ValuesView,
        KeysView,
        UserList
    ))
    assert obj_classes & classes
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert issubclass(obj.keys().__class__, ValuesView)
    assert is_subclass_of_any(obj, dict, UserList)
    assert issubclass(obj.__class__, dict)
    assert issubclass(obj.__class__, UserList)
    assert is_subclass_of_any(obj, UserList, set)

# Generated at 2022-06-23 18:07:39.802353
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1,b=2,c=3,d=4)
    assert True == has_attrs(obj,'get','items','keys','values')


# Generated at 2022-06-23 18:07:45.474231
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True


# Generated at 2022-06-23 18:07:48.423680
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'get','keys','items','values','foo'))



# Generated at 2022-06-23 18:07:55.179759
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(None) is False


# Generated at 2022-06-23 18:08:02.680104
# Unit test for function has_any_callables
def test_has_any_callables():
    from unittest import TestCase
    class Test_has_any_callables(TestCase):
        """ Test flutils.objutils.has_any_callables """
        def test_has_any_callables(self):
            from flutils.objutils import has_any_callables
            attrs = (
                "get",
                "keys",
                "items",
                "values",
                "foo"
            )
            obj = dict(a=1, b=2)
            self.assertEqual(has_any_callables(obj, *attrs), True)
            attrs = (
                "__class__",
                "foo",
                "key"
            )
            self.assertEqual(has_any_callables(obj, *attrs), False)

# Generated at 2022-06-23 18:08:06.474804
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False


# Generated at 2022-06-23 18:08:09.574977
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:08:12.343735
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items') == True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'foo') == False


# Generated at 2022-06-23 18:08:15.633936
# Unit test for function has_any_callables
def test_has_any_callables():  
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-23 18:08:22.339922
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables."""
    # Empty parameters
    assert not has_callables(None)
    assert not has_callables(object())
    assert not has_callables(dict(),'')
    # Wrong parameters
    assert not has_callables(dict(),'foo')
    # Correct parameters
    assert has_callables(dict(),'get','keys','values','items')


# Generated at 2022-06-23 18:08:24.113289
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True


# Generated at 2022-06-23 18:08:28.356293
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )

    obj = dict(a=1, b=2)

    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True



# Generated at 2022-06-23 18:08:41.036056
# Unit test for function has_attrs
def test_has_attrs():
    from collections import OrderedDict
    from flutils.objutils import has_attrs
    
    assert has_attrs(dict(), 'keys') is True
    assert has_attrs(dict(), 'foo') is False
    assert has_attrs(OrderedDict(), 'keys') is True
    assert has_attrs(OrderedDict(), 'foo') is False
    assert has_attrs({}, 'keys') is True
    assert has_attrs({}, 'foo') is False
    assert has_attrs(OrderedDict(), 'keys','foo') is False
    assert has_attrs(OrderedDict(), 'keys','__class__','foo') is False
    assert has_attrs(OrderedDict(), 'keys','__class__','__subclasshook__','foo') is False

# Generated at 2022-06-23 18:08:52.386591
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like"""
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    import decimal
    import itertools as it

    list_like = list, tuple, set, frozenset, deque, ValuesView, KeysView, UserList

    not_list_like = (None, bool, decimal.Decimal, dict, float, int, str,
                     bytes, ChainMap, Counter, OrderedDict, UserDict, UserString, defaultdict)

    for obj in list_like:
        assert is_list_like(obj([1, 2, 3])) is True


# Generated at 2022-06-23 18:08:54.854030
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values')
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-23 18:08:56.443830
# Unit test for function has_any_attrs
def test_has_any_attrs():
    pass
    #obj = dict(a=1,b=2)
    #assert has_any_attrs(obj) == True


# Generated at 2022-06-23 18:09:01.799895
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values')
    assert not has_callables(obj, 'get', 'keys', 'items', 'values', 'foo')
    assert not has_callables(obj, 'get', 'keys', 'items', 'foo')
    assert not has_callables(obj, 'get', 'keys', 'items')
    assert not has_callables(obj, 'get', 'keys')



# Generated at 2022-06-23 18:09:07.764768
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'keys', 'values', 'items') is True
    assert has_any_attrs(obj, 'iterkeys', 'itervalues', 'iteritems') is False
    assert has_any_attrs(obj, 'keys', 'itervalues', 'iteritems') is False



# Generated at 2022-06-23 18:09:09.764378
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs({}, 'keys')
    assert not has_attrs({}, 'key')


# Generated at 2022-06-23 18:09:11.856982
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-23 18:09:14.199458
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs({}, 'get', 'keys', 'items', 'values') 



# Generated at 2022-06-23 18:09:23.896301
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'values', 'something') == True
    assert has_any_attrs(dict(), 'foo', 'bar') == False
    assert has_any_attrs({'a': 1, 'b': 2}, 'keys', 'foo', 'bar') == True
    #
    assert has_any_attrs('hello', 'isalpha', 'format') == True
    assert has_any_attrs('hello', 'isdigit', 'foo') == False
    assert has_any_attrs('hello', 'isdigit', 'isalpha') == True
    assert has_any_attrs('hello', 'bar') == False
#

# Generated at 2022-06-23 18:09:33.593385
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    from collections import Counter
    obj = Counter()
    assert has_any_callables(obj, 'update', 'copy', 'most_common') is True
    assert has_any_callables(obj, 'update', 'copy', 'most_common', 'foo') is True
    assert has_any_callables(obj, 'foo') is False
    with pytest.raises(TypeError, match='foo') as excinfo:
        # noinspection PyTypeChecker
        has_any_callables(obj, None)
    assert str(excinfo.value) == "'NoneType' object is not iterable"


# Generated at 2022-06-23 18:09:37.221836
# Unit test for function has_attrs
def test_has_attrs():
    def run_test(obj, *attrs):
        assert has_attrs(obj, attrs) is True

    run_test(dict(), 'get', 'keys', 'items', 'values')
    run_test(dict(), 'get')


# Generated at 2022-06-23 18:09:49.122642
# Unit test for function is_list_like
def test_is_list_like():
    # Check items in flutils.objutils._LIST_LIKE
    assert is_list_like([]) is True
    assert is_list_like({}) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(reversed([])) is True
    # Check items NOT in flutils._LIST_LIKE
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(b'') is False
    assert is_list_like(float()) is False
    assert is_list_like(int()) is False
    assert is_list_like(str()) is False
    assert is_list

# Generated at 2022-06-23 18:09:57.418308
# Unit test for function has_attrs
def test_has_attrs():
    from collections import OrderedDict, UserDict
    from collections.abc import KeysView
    mydict = OrderedDict(a='felix', b='leonard')
    mylist = ['felix', 'leonard']
    mytuple = ('felix', 'leonard')
    myset = set(['felix', 'leonard'])
    mykeys = mydict.keys()
    myvalues = mydict.values()
    myuserdict = UserDict(mydict)
    mykeysview = KeysView(mydict)
    mykeyslist = list(mykeysview)
    mydictlist = list(mydict)
    myordereddictlist = list(mydict.keys())
    mysetlist = list(myset)
    # Testing all list-like objects (including OrderedDict list objects)

# Generated at 2022-06-23 18:10:09.153768
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from flutils.objutils import has_attrs
    from flutils.objutils import has_any_attrs
    from flutils.objutils import has_any_callables

    # Test cases with no attributes
    assert has_callables(dict()) is False
    assert has_callables(int, 'foo', 'bar') is False

    # Test cases with attributes but not callable
    assert has_callables(dict, 'foo') is False
    assert has_callables(dict, 'foo', 'bar', 'baz') is False
    assert has_callables(dict, 'foo', 'bar', 'baz', 'foo_bar') is False

    # Test cases with attributes but not callable
    assert has_callables(dict, 'get') is True
    assert has_

# Generated at 2022-06-23 18:10:20.029310
# Unit test for function has_attrs
def test_has_attrs():
    # setup
    T = True
    F = False

# Generated at 2022-06-23 18:10:29.349246
# Unit test for function has_attrs
def test_has_attrs():
    import collections.abc
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys') == True
    assert has_attrs(obj, 'get', 'keys', 'foo') == False
    assert has_attrs(obj, 'get', 'keys', 'foo', 'bar', 'baz') == False
    assert has_attrs(collections.abc.Callable, '__call__') == True
    assert has_attrs(collections.abc.Callable, '__call__', 'foo') == False



# Generated at 2022-06-23 18:10:37.356778
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(iter([])) is True
    assert is_list_like(iter(dict().values())) is True
    assert is_list_like(iter(dict().keys())) is True
    assert is_list_like(UserList()) is True


# Generated at 2022-06-23 18:10:49.408292
# Unit test for function has_any_callables
def test_has_any_callables():
    for obj in [dict(), collections.ChainMap(), collections.defaultdict(), collections.OrderedDict()]:
        assert has_any_callables(obj, '__len__', '__contains__', '__iter__', '__getitem__', '__setitem__', '__delitem__') is True
        assert has_any_callables(obj, '__len__', '__contains__', '__iter__', '__getitem__', '__setitem__', '__delitem__', '__foo__') is True
        assert has_any_callables(obj, '__foo__', '__bar__') is False
    assert has_any_callables('hello', '__len__', '__hash__', '__iter__', '__getitem__') is True

# Generated at 2022-06-23 18:10:51.607204
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj,'get','keys','items','values','something')


# Generated at 2022-06-23 18:10:59.919862
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_attrs(dict(), 'foo', 'bar') == False
    assert has_attrs((1, 2, 3), 'get', 'keys', 'items', 'values') == False
    assert has_attrs((1, 2, 3), '__len__', '__getitem__') == True
    assert has_attrs((1, 2, 3), '__len__', '__getitem__', '__mro__') == True


# Generated at 2022-06-23 18:11:01.963835
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True


# Generated at 2022-06-23 18:11:11.843734
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs({}, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(list, 'append', 'clear', 'count', 'extend') is True
    assert has_attrs(str, 'capitalize', 'encode', 'format', 'lower') is True
    assert has_attrs(int, 'bit_length', 'denominator', 'imag', 'real') is True
    assert has_attrs(float, 'hex', 'is_integer', 'real', 'imag') is True
    assert has_attrs('', 'capitalize', 'encode', 'format', 'lower') is True

# Generated at 2022-06-23 18:11:17.347357
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    obj = dict(a=1, b=2)
    assert issubclass(obj.keys().__class__, ValuesView) is True
    assert is_subclass_of_any(obj.keys(), ValuesView) is True
    assert is_subclass_of_any(obj.values(), KeysView) is False

# Generated at 2022-06-23 18:11:18.790379
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')


# Generated at 2022-06-23 18:11:28.601846
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)

    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.items(), ValuesView, KeysView, UserList)


# Generated at 2022-06-23 18:11:38.709476
# Unit test for function has_any_attrs
def test_has_any_attrs():
    print("Testing has_any_attrs...")
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_attrs(dict(), 'get', 'keys', 'values')
    assert has_any_attrs(dict(), 'get', 'items', 'values')
    assert has_any_attrs(dict(), 'get', 'items', 'values', 'clear')
    assert has_any_attrs(dict(), 'get', 'items', 'values') is False
    print("Done testing has_any_attrs.")


# Generated at 2022-06-23 18:11:42.522786
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('hi', 'upper') is True
    assert has_callables('hi', 'upper', 'lower') is True
    assert has_callables('hi', 'uppper', 'lower') is False
    return 1

# Generated at 2022-06-23 18:11:49.617469
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(foo=42),'get','keys','items','values') is True
    assert has_callables(dict(),'clear') is False
    assert has_callables(dict(),'get','keys','items') is False
    assert has_callables(dict(),'get','keys','foo','values') is False
    assert has_callables(dict(),'foo') is False
    assert has_callables(dict(foo=42),'bar') is False



# Generated at 2022-06-23 18:11:59.101644
# Unit test for function has_callables
def test_has_callables():
    # Test for dict.
    dict_obj = dict(a=1, b=2, c=3)
    assert has_callables(dict_obj, 'keys', 'ge') is True
    assert has_callables(dict_obj, 'keys', 'something_else') is False
    assert has_callables(dict_obj, 'keys', 'keys') is True

    # Test for str.
    str_obj = 'hello'
    assert has_callables(str_obj, 'keys', 'items') is False
    assert has_callables(str_obj, 'startswith') is True

    # Test for int.
    int_obj = 1
    assert has_callables(int_obj, 'keys', 'items') is False

# Generated at 2022-06-23 18:12:02.060675
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') == True
    assert has_attrs(dict(),'set','keys','items','values') == False


# Generated at 2022-06-23 18:12:08.538611
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get')
    assert has_any_attrs(['hello'])
    assert has_any_attrs(None) == False
    assert has_any_attrs(1) == False
    assert has_any_attrs(1.23) == False
    assert has_any_attrs(True) == False


# Generated at 2022-06-23 18:12:19.295865
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest

    dict_obj = dict(a=1,b=2)
    dict_obj_false = dict(a=1,b=2,_c=3)
    func_obj = dict_obj.get
    list_obj = dict_obj.keys()
    list_obj_false = list_obj + [1,]

    assert has_any_callables(obj=dict_obj,
                             *dict_obj.keys()) == True
    assert has_any_callables(obj=dict_obj_false,
                             *dict_obj_false.keys()) == True
    assert has_any_callables(obj=list_obj,
                             *list_obj) == True
    assert has_any_callables(obj=list_obj_false,
                             *list_obj_false) == True


# Generated at 2022-06-23 18:12:23.207617
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:12:26.335946
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','keys','items','values','something') is False
    assert has_attrs(dict(),'something',) is False


# Generated at 2022-06-23 18:12:37.108711
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
    )
    from typing import (
        Any,
        ClassVar,
        Deque,
        FrozenSet,
        List,
        Set,
        Tuple,
        Type,
        TypeVar,
        Union,
    )
    from decimal import Decimal
    from dataclasses import dataclass

    # These are list-like objects
    assert is_list_like([]) is True
    assert is_list_like(['hello']) is True
    assert is_list_like(range(0, 10)) is True
    assert is_list_like(reversed(range(0, 10))) is True
    assert is_list_like(1) is False



# Generated at 2022-06-23 18:12:40.663417
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    attrs = ('get','keys','items','values','foo')
    assert has_any_callables(obj,*attrs)

# Generated at 2022-06-23 18:12:44.481212
# Unit test for function has_attrs
def test_has_attrs():
    class Foo:
        def __init__(self):
            self.a = 1
            self.b = 2
    obj = Foo()
    assert has_attrs(obj, 'a', 'b') is True


# Generated at 2022-06-23 18:12:47.383358
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, '__getitem__', '__len__')



# Generated at 2022-06-23 18:12:52.379828
# Unit test for function is_list_like
def test_is_list_like():
    obj_classes = [
        dict,
        int,
        str,
        float,
        list,
        set,
        frozenset,
        tuple,
        deque,
        Iterator,
        ValuesView,
        KeysView,
        UserList,
        None,
        bool,
        bytes,
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
        Decimal
    ]
    list_like_objs = [
        list(),
        set(),
        frozenset(),
        tuple(),
        deque(),
        reversed(list()),
        sorted('hello'),
        dict().keys(),
        dict().values(),
        dict().items(),
        dict().values().keys(),
        dict().items().values()
    ]

# Generated at 2022-06-23 18:13:00.542275
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'get', 'b', 'items', 'values') is True
    assert has_any_callables(obj, 'something', 'b', 'items', 'values') is True
    assert has_any_callables(obj, 'foo', 'b', 'items', 'values') is False
    assert has_any_callables(obj, 'a', 'b', 'foo', 'values') is False


# Generated at 2022-06-23 18:13:03.077984
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-23 18:13:05.404597
# Unit test for function has_any_callables
def test_has_any_callables():
    dct = dict(a=1, b=2)
    assert has_any_callables(dct, 'keys', 'makeupper', 'values') is True



# Generated at 2022-06-23 18:13:11.685075
# Unit test for function has_any_attrs
def test_has_any_attrs():
    d = dict(a=1, b=2)
    assert has_any_attrs(d, 'get', 'keys', 'something')
    assert not has_any_attrs(d, 'foo', 'bar', 'something')
    assert has_any_attrs(d.keys(), '__contains__', 'something')
    assert not has_any_attrs(d.keys(), 'foo', 'bar', 'something')


# Generated at 2022-06-23 18:13:19.718713
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables"""
    import unittest

    class Callables(object):
        def __init__(self):
            self.attr = 'attr'
            self.method = lambda x: x

    class NotCallables(object):
        def __init__(self):
            pass

    class TestCallables(unittest.TestCase):
        def test_has_callables(self):
            self.assertTrue(has_callables(Callables(), 'attr', 'method'))
            self.assertTrue(has_callables(NotCallables(), 'method'))
            self.assertFalse(has_callables(NotCallables(), 'method', 'attr'))

    unittest.main()

# Unit Test for function has_attrs

# Generated at 2022-06-23 18:13:27.196002
# Unit test for function has_any_callables
def test_has_any_callables():
    print("Running test_has_any_callables()")
    assert has_any_callables(float(), 'is_integer', 'as_integer_ratio') is True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'something') is True
    assert has_any_callables(list(), 'append', 'insert', 'something') is True
    assert has_any_callables(set(), 'add', 'discard', 'something') is True
    assert has_any_callables(frozenset(), 'add', 'discard', 'something') is False
    assert has_any_callables(tuple(), 'add', 'discard', 'something') is False


# Generated at 2022-06-23 18:13:39.355521
# Unit test for function is_list_like
def test_is_list_like():
    print('testing is_list_like() with:',None)
    if is_list_like(None) is False:
        print('PASSED')
    else:
        print('FAILED')

    print('testing is_list_like() with:',True)
    if is_list_like(True) is False:
        print('PASSED')
    else:
        print('FAILED')

    print('testing is_list_like() with:',[1, 2, 3])
    if is_list_like([1, 2, 3]) is True:
        print('PASSED')
    else:
        print('FAILED')

    print('testing is_list_like() with:',{'a': 1, 'b': 2})

# Generated at 2022-06-23 18:13:43.467805
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like('hello')
    assert not is_list_like(sorted('hello'))

# Generated at 2022-06-23 18:13:47.652905
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'something') == False

# Generated at 2022-06-23 18:13:57.751998
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(
        dict(a=1, b=2),
        'get',
        'keys',
        'items',
        'values',
        'foo',
        '__add__') is True

# Generated at 2022-06-23 18:14:01.883743
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """
    Unit test for function is_subclass_of_any
    """
    from collections import (
        KeysView,
        ValuesView,
        UserList
    )
    obj = dict(a=1,b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:14:05.393154
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3])
    assert is_list_like(reversed([1,2,3]))
    assert is_list_like(range(1,10))
    assert is_list_like('hello') is False

# Generated at 2022-06-23 18:14:13.123374
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'foo') is False
    assert has_callables([], 'append', 'pop') is True
    assert has_callables(set(), 'add', 'remove') is True
    assert has_callables(tuple(), 'index', 'count') is True
    assert has_callables(str(), 'index', 'count', 'upper') is True
    assert has_callables("abc", 'index', 'count', 'upper') is True


# Generated at 2022-06-23 18:14:18.930619
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
  from collections import ValuesView, KeysView, UserList
  from flutils.objutils import is_subclass_of_any
  obj = dict(a=1, b=2)
  assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True


# Generated at 2022-06-23 18:14:24.839380
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)==True
    assert is_subclass_of_any(g.keys(),ValuesView,KeysView,UserList)==False

# Generated at 2022-06-23 18:14:32.187685
# Unit test for function has_callables
def test_has_callables():
    log.addHandler(logging.NullHandler())
    log.setLevel(logging.DEBUG)
    # noinspection PyUnresolvedReferences
    from collections.abc import MutableMapping
    # noinspection PyUnresolvedReferences
    from collections import UserDict
    log.debug(has_callables(dict(), 'get', 'keys', 'items', 'values'))
    log.debug(has_callables(UserDict(), 'get', 'keys', 'items', 'values'))
    log.debug(has_callables(MutableMapping(), 'get', 'keys', 'items', 'values'))
    log.debug(has_callables(dict, 'get', 'keys', 'items', 'values'))

# Generated at 2022-06-23 18:14:40.071745
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs('abc','get','keys','items','values') == True
    assert has_any_attrs(range(10),'get','keys','items','values') == True
    assert has_any_attrs(True,'get','keys','items','values') == False
    assert has_any_attrs(1,'get','keys','items','values') == False
    assert has_any_attrs(None,'get','keys','items','values') == False


# Generated at 2022-06-23 18:14:49.534737
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test function is_subclass_of_any"""
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, list) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, tuple) is False



# Generated at 2022-06-23 18:14:59.798750
# Unit test for function has_callables
def test_has_callables():
    import csv
    assert has_callables(dict, 'get', 'keys', 'items')
    assert has_callables(csv.writer, 'writerows')
    assert has_callables(csv.reader, 'next')
    assert has_callables(csv.DictWriter, 'writerows')
    assert has_callables(csv.DictReader, 'next')
    assert has_callables(list, 'append')
    assert has_callables(set, 'add')
    assert has_callables(tuple, 'index')
    assert has_callables(deque, 'append')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(list(), 'append', 'clear')
    assert has_callables(set(), 'add', 'clear')
   

# Generated at 2022-06-23 18:15:01.073345
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-23 18:15:03.099959
# Unit test for function has_callables
def test_has_callables():
    pass



# Generated at 2022-06-23 18:15:10.259094
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like('abc') is False
    assert is_list_like(['abc']) is True
    assert is_list_like((x for x in range(0, 10))) is True
    assert is_list_like(reversed('abc')) is True
    assert is_list_like(None) is False
    assert is_list_like(set('abc')) is True
    print("All tests passed")


# Generated at 2022-06-23 18:15:13.733544
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-23 18:15:20.463902
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj1 = dict(a=1, b=2)
    print(is_subclass_of_any(obj1.keys(), ValuesView, KeysView, UserList))
    print(is_subclass_of_any(obj1.values(), ValuesView, KeysView, UserList))
    print(is_subclass_of_any(obj1.keys(), int, float, str, list, ValuesView, KeysView, UserList))

# Generated at 2022-06-23 18:15:24.691718
# Unit test for function has_callables
def test_has_callables():
    print("Testing function has_callables...")
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    print("has_callables passed tests")


# Generated at 2022-06-23 18:15:31.787171
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'bar') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'bar') is True
    assert has_any_attrs(dict(), 'get', 'keys') is True
    assert has_any_attrs

# Generated at 2022-06-23 18:15:36.155217
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'values', 'items', 'foo') is True



# Generated at 2022-06-23 18:15:45.409864
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables

    class Foo:
        attr1 = 'attr1'
        attr2 = 'attr2'

        def method1(self):
            return self.attr1

        def method2(self):
            return self.attr2

    obj = Foo()
    assert has_callables(obj, 'method1', 'method2') is True

    assert has_callables(obj, 'attr1', 'attr2') is False

    assert has_callables(obj, 'attr1', 'method1') is False

    # Unit test for function has_any_callables

# Generated at 2022-06-23 18:15:51.317096
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList)
    assert not is_subclass_of_any(obj.values(),UserList) # NOT instance of UserList

# Generated at 2022-06-23 18:16:00.029078
# Unit test for function has_attrs
def test_has_attrs():
    from collections import deque, UserList
    from setuptools.command.setopt import edit_config, edit_config_2
    from setuptools.command.setopt import _edit_config as edit_config_3

    D = dict(a=1, b=2)
    L = list([1, 2, 4])
    C = Counter(a=1, b=2)
    S = set([1, 2, 3])
    FS = frozenset([1, 2, 3])
    T = tuple([1, 2, 3])
    I = iter([1, 2, 3])
    U = UserList([1, 2, 3])
    DQ = deque([1, 2, 3])
    KV = D.keys()
    VV = D.values()
    EC = edit_config

# Generated at 2022-06-23 18:16:03.527735
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    result = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert result is True

# Generated at 2022-06-23 18:16:08.309099
# Unit test for function has_callables
def test_has_callables():
    def foo():
        pass

    x = {
        'bar': 'baz',
        'foo': foo,
    }

    assert has_callables(x, 'foo') is True
    assert has_callables(x, 'bar') is False



# Generated at 2022-06-23 18:16:12.458687
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(dict(), 'something')
    assert has_any_attrs(dict(), 'items', 'foo')
