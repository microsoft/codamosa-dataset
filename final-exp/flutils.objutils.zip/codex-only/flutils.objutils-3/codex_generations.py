

# Generated at 2022-06-23 18:06:10.710643
# Unit test for function has_callables
def test_has_callables():
    # function exists
    assert hasattr(objutils, 'has_callables')
    # function returns correct results
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'get','keys','items','foo')


# Generated at 2022-06-23 18:06:12.642417
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    assert is_subclass_of_any(dict(), dict) == True
    assert is_subclass_of_any([], []) == True

# Generated at 2022-06-23 18:06:22.100995
# Unit test for function has_any_callables
def test_has_any_callables():

    # Create testing object
    class MyClass(object):
        def __init__(self):
            self.foo = 'bar'

        def bar(self):
            pass

    obj = MyClass()
    assert has_any_callables(obj, 'foo', 'bar') is True
    assert has_any_callables(obj, 'baz', 'qux') is False
    assert has_any_callables(obj, 'foo') is False
    assert has_any_callables(obj, 'bar') is True
    assert has_any_callables(obj) is False


# Generated at 2022-06-23 18:06:24.153906
# Unit test for function is_list_like
def test_is_list_like():
    """Test function
    """
    # pylint: disable=invalid-name
    assert is_list_like([1, 2, 3]) == True
    assert is_list_like(reversed([1, 2, 4])) == True
    assert is_list_like('hello') == False
    assert is_list_like(sorted('hello')) == True
    return 0

# Generated at 2022-06-23 18:06:26.546705
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:06:36.738061
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList,obj.values()) == True
    assert is_subclass_of_any(obj.keys(),UserList,ValuesView,obj.values(),KeysView) == True
    assert is_subclass_of_any(obj.keys(),UserList,tuple,ValuesView,obj.values(),KeysView) == True

# Generated at 2022-06-23 18:06:43.647015
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(
        get=lambda: None,
        keys=lambda: None,
        items='',
        values=123
    )
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') is True
    # Test incorrect return
    assert has_any_callables(obj, 'get', 'keys', 'items', 'values') is not False

# Generated at 2022-06-23 18:06:50.012098
# Unit test for function has_attrs
def test_has_attrs():
    """ Unit test for function has_attrs.
    """
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'bar', 'baz', 'boom') is False
    assert has_attrs([1, 2, 3, 4], 'foo', 'bar', 'baz', 'boom') is False



# Generated at 2022-06-23 18:06:53.871885
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:07:01.765238
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """ Unit test for is_subclass_of_any
    """
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(
        obj.keys(),
        ValuesView,
        KeysView,
        UserList
    ) is True

    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False

    assert is_subclass_of_any('', ValuesView, KeysView, UserList) is False

    assert is_subclass_of_any(1, ValuesView, KeysView, UserList) is False

# Generated at 2022-06-23 18:07:07.101827
# Unit test for function has_attrs
def test_has_attrs():
    # Test a valid obj
    assert has_attrs(dict(),'get','keys','items','values') is True
    # Test an invalid obj
    assert has_attrs(dict(),'only_in_dict') is False


# Generated at 2022-06-23 18:07:13.809707
# Unit test for function has_callables
def test_has_callables():
    obj = dict()
    obj['__call__'] = lambda: 0  # noqa: E731
    obj['caller'] = lambda: 0  # noqa: E731
    obj['exists'] = lambda: 0  # noqa: E731
    obj['func'] = lambda: 0  # noqa: E731
    obj['method'] = lambda: 0  # noqa: E731
    assert has_callables(obj, '__call__', 'callable', 'exists', 'func', 'method') is True


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:07:15.803173
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-23 18:07:27.721262
# Unit test for function is_list_like
def test_is_list_like():
    # List-like objects
    assert(is_list_like(list()) == True)
    assert(is_list_like(set()) == True)
    assert(is_list_like(frozenset()) == True)
    assert(is_list_like(tuple()) == True)
    assert(is_list_like(deque()) == True)
    assert(is_list_like(Iterator([])) == True)
    assert(is_list_like(ValuesView({'a': 1, 'b': 2})) == True)
    assert(is_list_like(KeysView({'a': 1, 'b': 2})) == True)
    assert(is_list_like(UserList([1, 2, 3])) == True)

    # Not list-like objects

# Generated at 2022-06-23 18:07:30.891561
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(
        a=1,
        b=2,
        c=3
    )
    assert has_any_callables(obj, 'get', 'getitem', 'foo') is True



# Generated at 2022-06-23 18:07:36.826193
# Unit test for function has_callables
def test_has_callables():
    assert not has_callables(dict(),'get','keys','items','values','foo')
    assert has_callables(dict(),'get','keys','items','values')
    assert has_callables(dict(),'get','keys','items')
    assert has_callables(dict(),'get','keys')
    assert not has_callables(dict(),'get')


# Generated at 2022-06-23 18:07:39.374545
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')



# Generated at 2022-06-23 18:07:41.477525
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict()
    assert has_attrs(obj, '__iter__', '__len__', '__getitem__') is True



# Generated at 2022-06-23 18:07:43.865996
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'something')


# Generated at 2022-06-23 18:07:47.900993
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict([('a',1),('b',2),('c',3)]),'get','keys','items','values','foo')
    assert not has_any_callables(dict([('a',1),('b',2),('c',3)]),'get','keys','items','values','bar')


# Generated at 2022-06-23 18:07:58.576828
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(),'get','keys','items','values','foo') is True)
    assert(has_any_attrs(dict(),'foo') is False)
    assert(has_any_attrs([], 'pop', 'append') is True)
    assert(has_any_attrs([], 'pop', 'extend') is False)
    assert(has_any_attrs(tuple(), 'index') is True)
    assert(has_any_attrs(tuple(), 'index', 'append') is False)
    assert(has_any_attrs(set(), 'add', 'difference') is True)
    assert(has_any_attrs(set(), 'add', 'union', 'copy') is False)


# Generated at 2022-06-23 18:08:02.044696
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList,set) is False

# Generated at 2022-06-23 18:08:12.170659
# Unit test for function has_any_callables
def test_has_any_callables():
  from flutils.objutils import has_any_callables
  from collections import UserDict
  def hello(): pass
  class Dict(UserDict):
    def __init__(self, *args, **kwargs):
      super(Dict, self).__init__(*args, **kwargs)
    def hello(self): pass
  d = Dict()
  d['a'] = 1
  d['b'] = 2
  assert has_any_callables(d, 'hello') == True
  assert has_any_callables(d, 'keys', 'hello') == True
  assert has_any_callables(d, 'keys', 'items', 'hello') == True
  assert has_any_callables(d, 'keys', 'items', 'values', 'hello') == True

  assert has_any_callables

# Generated at 2022-06-23 18:08:23.172502
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function :func:`~flutils.objutils.has_any_attrs`.

    Tests:
        :func:`~flutils.objutils.has_any_attrs`

        - given an object with any attribute, returns True
        - given an object with no attributes, returns False
    """
    from nose.tools import assert_true, assert_false
    assert_true(has_any_attrs(dict(), 'get'))
    assert_true(has_any_attrs(dict(), 'get', 'keys'))
    assert_false(has_any_attrs(dict(), 'foo'))



# Generated at 2022-06-23 18:08:26.584086
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_attrs(str(), 'lstrip', 'rstrip', 'strip') is True
    assert has_attrs(str(), 'lstrip', 'rstrip', 'strip', 'bogus') is False



# Generated at 2022-06-23 18:08:27.959746
# Unit test for function has_attrs
def test_has_attrs():
    import doctest
    doctest.testmod()
    doctest.run_docstring_examples(has_attrs, globals())


# Generated at 2022-06-23 18:08:33.151917
# Unit test for function has_callables
def test_has_callables():
    # Function has_all_attrs does not exist
    assert has_callables(None, 'foo') is False
    # Function get exists but is not callable
    assert has_callables(dict(get=1), 'get') is False
    # Function get is callable
    assert has_callables(dict(get=lambda x: x), 'get') is True
    # Function get and bar do not exist but foo exists but is not callable
    assert has_callables(dict(foo=1), 'foo', 'get', 'bar') is False
    # Function get, foo and bar do not exist
    assert has_callables(dict(), 'foo', 'get', 'bar') is False
    # Function get does not exist but foo and bar exist and are callable

# Generated at 2022-06-23 18:08:38.208650
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.collections import CircularSet
    from flutils.objutils import (
        has_any_callables,
        has_any_attrs,
        has_attrs,
        has_callables,
        is_list_like,
        is_subclass_of_any,
    )
    assert has_any_callables(CircularSet(set('abc')), 'add', '__le__') is True
    assert has_any_attrs(CircularSet(set('abc')), 'add', '__le__') is True
    assert has_attrs(CircularSet(set('abc')), 'add', '__le__') is True
    assert has_callables(CircularSet(set('abc')), 'add', '__le__') is False

# Generated at 2022-06-23 18:08:47.386517
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like('') is False
    assert is_list_like(()) is True
    assert is_list_like('') is False
    assert is_list_like({}) is False
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(deque()) is True
    for i in range(5):
        assert is_list_like(reversed(list(range(i)))) is True
        assert is_list_like(sorted(list(range(i)))) is True
        assert is_list_like(sorted(list(range(i)), reverse=True)) is True
    from collections import UserList

# Generated at 2022-06-23 18:08:51.209901
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(reversed([1, 2, 4])) is True

# Generated at 2022-06-23 18:08:54.715904
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = (1, 2, 3)
    assert has_any_attrs(obj, 'index', 'count') == True
    assert has_any_attrs(obj, 'index', 'foo') == True
    assert has_any_attrs(obj, 'foo', 'bar') == False


# Generated at 2022-06-23 18:08:57.950173
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    obj = "hello"
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False


if __name__ == "__main__":
    test_is_subclass_of_any()

# Generated at 2022-06-23 18:09:04.984154
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for function has_attrs"""
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values')


# Generated at 2022-06-23 18:09:11.508278
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2, c=3)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList),\
        'Not a subclass of any of the given classes'
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList),\
        'Not a subclass of any of the given classes'
    assert is_subclass_of_any(obj.items(), ValuesView, KeysView, UserList),\
        'Not a subclass of any of the given classes'


# Generated at 2022-06-23 18:09:20.239835
# Unit test for function is_list_like
def test_is_list_like():
    """Test the flutils.objutils.is_list_like function
    """
    from flutils.objutils import is_list_like

    assert(is_list_like([]) is True)
    assert(is_list_like([1, 2, 3]) is True)
    assert(is_list_like(reversed([1, 2, 3])) is True)
    assert(is_list_like('hello') is False)
    assert(is_list_like(sorted('hello')) is True)

# Generated at 2022-06-23 18:09:22.916254
# Unit test for function has_attrs
def test_has_attrs():
    """Test for function: objutils.has_attrs"""
    assert has_attrs({}, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:09:30.152259
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )
    obj = dict(a=1, b=2)
    # obj.keys() is subclass of KeysView
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True


if __name__ == '__main__':
    test_is_subclass_of_any()

# Generated at 2022-06-23 18:09:40.594019
# Unit test for function has_any_callables
def test_has_any_callables():
    def foo():
        pass

    def bar():
        pass

    def baz():
        pass

    obj = dict(foo=foo, baz=baz)

    assert has_any_callables(obj, 'foo', 'bar') is True
    assert has_any_callables(obj, 'bar', 'baz') is True
    assert has_any_callables(obj, 'foo', 'bar', 'baz') is True
    assert has_any_callables(obj, 'bar', 'baz', 'foo') is True
    assert has_any_callables(obj, 'baz', 'foo', 'bar') is True

    assert has_any_callables(obj, 'bar', 'bax') is False
    assert has_any_callables(obj, 'bax', 'baz') is False

# Generated at 2022-06-23 18:09:48.732659
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
     )
    from collections.abc import (
        Iterator,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), KeysView, ValuesView, UserList) is True
    assert is_subclass_of_any(obj.keys(), UserList, ValuesView, KeysView) is True

    assert is_subclass_of_any(obj.keys(), Iterator) is False
    assert is_subclass_of_any(obj.keys(), dict) is False
    assert is_subclass_of_any(obj.keys(), str) is False
    assert is_

# Generated at 2022-06-23 18:09:57.327043
# Unit test for function is_list_like
def test_is_list_like():
    # Test collections classes
    assert is_list_like(UserList())
    assert is_list_like(deque())
    assert is_list_like(Iterator([]))
    assert is_list_like(KeysView({}))
    assert is_list_like(ValuesView({}))
    # Test collections container types
    assert is_list_like([])
    assert is_list_like(frozenset())
    assert is_list_like(set())
    assert is_list_like(tuple())
    # Test built-in types
    assert is_list_like(reversed([]))
    assert is_list_like(sorted([]))
    assert is_list_like(sorted({}))
    # Test str type
    assert not is_list_like('hello')
    assert not is_

# Generated at 2022-06-23 18:09:59.143875
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','something')


# Generated at 2022-06-23 18:10:01.437059
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(
        dict(), 'get', 'keys', 'values', 'foo') is True



# Generated at 2022-06-23 18:10:12.042056
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from string import ascii_uppercase
    from typing import Union
    from collections import KeysView, ValuesView, UserList
    # Test subclasses of built-in types
    assert is_subclass_of_any("a", KeysView, ValuesView, UserList) is True
    assert is_subclass_of_any("a", int, str, KeysView) is True
    assert is_subclass_of_any("a", int, KeysView, UserList) is False
    # Test subclass of user defined type
    class MyClass:
        pass
    class MySubClass(MyClass):
        pass
    assert is_subclass_of_any(MySubClass(),int,str,MyClass) is True

# Generated at 2022-06-23 18:10:17.491099
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # test that issubclass() returns False when checking a class against
    # itself
    assert is_subclass_of_any(dict.__class__, dict.__class__) is False
    assert is_subclass_of_any('ciao', dict.__class__) is False
    assert is_subclass_of_any(dict(ciao=1), list) is False
    assert is_subclass_of_any(list, dict) is False
    assert is_subclass_of_any(list, dict, list) is True
    assert is_subclass_of_any('ciao', str) is True
    assert is_subclass_of_any(dict(ciao=1), dict) is True

# Generated at 2022-06-23 18:10:29.120313
# Unit test for function has_callables
def test_has_callables():
    """
    Unit test for function has_callables
    """
    from unittest import TestCase

    from flutils.objutils import has_callables
    from flutils.objutils import is_list_like

    class Dummy():

        def __init__(self, d):
            self._d = d

        def keys(self):
            return self._d.keys()

        def get(self, k):
            return self._d.get(k)

    class DummyNotList():

        def __init__(self, d):
            self._d = d

        def keys(self):
            return self._d.keys()

        def get(self, k):
            return self._d.get(k)

        def __iter__(self):
            raise AttributeError


# Generated at 2022-06-23 18:10:37.127068
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter
    from decimal import Decimal

    cnt = Counter()

    # noinspection PyUnresolvedReferences
    assert has_callables(cnt, 'most_common') is True

    assert has_callables(Decimal, '__eq__') is True

    b = bytes()
    # noinspection PyUnresolvedReferences
    assert has_callables(b, 'decode') is True

    # noinspection PyUnusedLocal
    def foo():
        pass

    assert has_callables(foo, '__call__') is True



# Generated at 2022-06-23 18:10:49.407783
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'bar') is False
    assert has_attrs(dict(a=1, b=2, c=3), 'get', 'keys', 'items', 'values')
    assert (
        has_attrs(dict(a=1, b=2, c=3), 'get', 'keys', 'items', 'values', 'bar')
        is False
    )
    assert (
        has_attrs(
            dict(a=1, b=2, c=3, get=lambda x: x), 'get', 'keys', 'items',
            'values', 'bar'
        )
        is False
    )



# Generated at 2022-06-23 18:10:56.330100
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs('abc', '__contains__', '__getitem__')
    assert not has_attrs('abc', '__contains__', '__getattr__')
    assert has_attrs(['a', 'b', 'c'], '__contains__', '__getitem__')
    assert has_attrs(dict(a=1, b=2), '__contains__', '__getitem__')
    assert has_attrs(dict, '__contains__', '__getitem__')



# Generated at 2022-06-23 18:11:01.225966
# Unit test for function has_callables
def test_has_callables():
    with pytest.raises(TypeError) as excinfo:
        has_callables(None)
    assert str(excinfo.value) == ('Parameter "obj" must be not None; '
                                  'received None')
    assert has_callables(dict(), 'keys', 'values', 'items', 'get') == True



# Generated at 2022-06-23 18:11:09.726881
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # Test obj is an instance of any of the given classes.
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList))

    # Test obj is NOT an instance of any of the given classes.
    from uuid import UUID
    assert(is_subclass_of_any(UUID, ValuesView, KeysView, UserList) is False)


# Generated at 2022-06-23 18:11:13.256869
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView
    obj = dict()
    assert is_subclass_of_any(obj, ValuesView) is False

# Generated at 2022-06-23 18:11:21.786778
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from decimal import Decimal
    from functools import reduce

    _CLASSES_ = (
        None,
        bool,
        bytes,
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
        Decimal,
        dict,
        float,
        frozenset,
        int,
        list,
        map,
        set,
        str,
        tuple,
    )

# Generated at 2022-06-23 18:11:24.614520
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('hello', 'upper', 'lower') is True


# Generated at 2022-06-23 18:11:31.541301
# Unit test for function is_list_like
def test_is_list_like():

    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(reversed('hello')) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(('a', 'b', 'c')) is True
    assert is_list_like(reversed(('a', 'b', 'c'))) is True

# Generated at 2022-06-23 18:11:33.703272
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'something','keys','items','values','foo') is False

# Generated at 2022-06-23 18:11:43.264889
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    # Classes to check against
    classes = (
        values.__class__ for values in (
            ChainMap, Counter, OrderedDict, UserDict, UserString, defaultdict,
            Decimal, dict, float, int, str, bool, bytes, tuple,
        )
    )

    # Verify that the above classes are NOT instances of the list-like types
    for cls in classes:
        assert is_subclass_of_any(cls, *_LIST_LIKE) is False

    # Verify that the list-like types are instances of the list-like types

# Generated at 2022-06-23 18:11:46.910442
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True



# Generated at 2022-06-23 18:11:53.546229
# Unit test for function has_attrs
def test_has_attrs():
    # Modules with the needed attributes
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(zip(['a', 'b', 'c'], [1, 2, 3])), 'get', 'keys',
                     'items', 'values')
    # Modules without the needed attributes
    assert not has_attrs(dict(zip(['a', 'b', 'c'], [1, 2, 3])), 'keys',
                         'items', 'values', 'something')
    assert not has_attrs(dict(), 'keys', 'items', 'values', 'something')



# Generated at 2022-06-23 18:11:57.463816
# Unit test for function is_list_like
def test_is_list_like():
    pass

# Generated at 2022-06-23 18:12:00.266656
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True


# Generated at 2022-06-23 18:12:02.822747
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'something')


# Generated at 2022-06-23 18:12:14.008580
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(None) == False
    assert is_list_like(False) == False
    assert is_list_like(0) == False
    assert is_list_like(0.0) == False
    assert is_list_like('') == False
    assert is_list_like(()) == True
    assert is_list_like([]) == True
    assert is_list_like({}) == False
    assert is_list_like(dict()) == False
    assert is_list_like('spam') == False
    assert is_list_like({'a':1, 'b':2}) == False
    assert is_list_like({'a':1, 'b':2}.keys()) == True
    assert is_list_like({'a':1, 'b':2}.values()) == True

# Generated at 2022-06-23 18:12:22.080113
# Unit test for function has_attrs
def test_has_attrs():
    from collections import defaultdict
    from itertools import chain, islice
    from operator import itemgetter
    from operator import lt, le, eq, ne, ge, gt
    from operator import add, mul, sub, truediv, floordiv, mod, pow
    from operator import neg, pos, abs, invert, lshift, rshift, and_, or_, xor
    from operator import concat, contains, countOf, indexOf
    from operator import eq, ne, gt, ge, lt, le
    from operator import not_, truth
    from operator import add, sub, mul, truediv, floordiv, mod, pow, lshift, rshift, and_, xor, or_
    import operator

    op = operator  # type: ignore

# Generated at 2022-06-23 18:12:25.126350
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import OrderedDict
    from flutils.objutils import has_any_callables

    tests = {
        dict: True,
        OrderedDict: True,
        bytes: False,
        list: False,
        list: True,
        (1, 2, 3): False
    }

    for t, expected in tests.items():
        assert has_any_callables(t, '__len__', '__iter__') == expected

# Generated at 2022-06-23 18:12:27.621977
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:12:35.143360
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.items(), ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False

# Generated at 2022-06-23 18:12:42.370899
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj.keys(), UserList)
    assert not is_subclass_of_any(obj.keys(), int, float, list)


# Generated at 2022-06-23 18:12:48.817973
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    obj = dict(a=1,b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(None, ValuesView, KeysView, UserList) is False
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False



# Generated at 2022-06-23 18:12:57.513359
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import UserList, UserDict, KeysView, ValuesView
    from flutils.objutils import is_subclass_of_any

    lst = UserList([1,2,3])
    dct = UserDict({'a':1, 'b':2})

    assert is_subclass_of_any(lst, UserList)
    assert is_subclass_of_any(dct, UserDict)
    assert is_subclass_of_any(dct.items(), KeysView, ValuesView)
    assert not is_subclass_of_any(dct.values(), UserList)
    assert not is_subclass_of_any(dct.values(), ValuesView)
    assert not is_subclass_of_any(dct.items(), UserList)
    assert not is_subclass_of

# Generated at 2022-06-23 18:13:01.023816
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for the has_any_callables function.

    >>> from flutils.objutils import has_any_callables
    >>> has_any_callables(dict(),'get','keys','items','values','foo')
    True
    """
    pass



# Generated at 2022-06-23 18:13:06.776437
# Unit test for function has_any_callables
def test_has_any_callables():
    def foo(bar = 1):
        
        return bar
    
    def bar(baz = 1):
        return baz
            
    my_dict = {"foo":foo, "bar":bar}
    
    if has_any_callables(my_dict, 'foo', 'bar', 'baz'):
        return True
    else:
        raise ValueError("has_any_callables() did not return True!")

# Generated at 2022-06-23 18:13:14.345201
# Unit test for function has_callables
def test_has_callables():
    # Create test data
    class Test:
        def __init__(self,foo):
            self.foo = foo
    class Test2:
        def __init__(self,foo):
            self.foo = foo
        def bar(self):
            pass

    # Read in expected results
    expected_results = {'Test':True,'Test2':False}

    for cls in expected_results:
        result = has_callables(eval(cls))
        assert result == expected_results[cls]



# Generated at 2022-06-23 18:13:16.557418
# Unit test for function has_attrs
def test_has_attrs():
    cls = dict(a=1, b=2)
    assert has_attrs(cls, 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:13:26.704828
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo') is True
    assert has_any_attrs({'foo': 'bar'}, 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs({'foo': 'bar'}, 'get', 'keys', 'items', 'something') is True
    assert has_any_attrs({'foo': 'bar'}, 'get', 'keys', 'items', 'values', 'pop') is True
    assert has_any_attrs({'foo': 'bar'}, 'something', 'something_else') is False
    assert has_any_attrs(None, 'something', 'something_else') is False

# Generated at 2022-06-23 18:13:33.937867
# Unit test for function has_callables
def test_has_callables():
    """
    Testing has_callables()

    :return:
    """
    class Foo(object):
        def __getattr__(self,attr):
            pass
        def __setattr__(self,attr,val):
            pass
    f = Foo()
    assert has_callables(f, '__getattr__', '__setattr__') == True



# Generated at 2022-06-23 18:13:42.916436
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView) == True
    assert is_subclass_of_any(obj.keys(), ValuesView) == True
    assert is_subclass_of_any(obj.keys(), KeysView, UserList) == True
    assert is_subclass_of_any(obj.keys(), UserList) == True
    assert is_subclass_of_any(obj.keys(), UserList, ValuesView) == True
    assert is_subclass_of_any(obj.keys(), UserList, ValuesView, KeysView) == True
    assert is_

# Generated at 2022-06-23 18:13:47.501553
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import flutils.objutils as objutils
    obj = {'a':1, 'b':2}
    assert objutils.has_any_attrs(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:13:51.177340
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:14:04.166064
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'keys', 'values', 'items') is True
    assert has_callables(dict(a=1, b=2), 'keys', 'values', 'items') is True
    assert has_callables(int(), 'bit_length', 'to_bytes') is True
    assert has_callables(1, 'bit_length', 'to_bytes') is True
    assert has_callables(float(), 'is_integer', 'hex') is True
    assert has_callables(1.1, 'is_integer', 'hex') is True
    assert has_callables(complex(), 'real', 'imag') is True
    assert has_callables(1 + 1j, 'real', 'imag') is True
    assert has_callables(1 + 1j, 'real', 'imag') is True
    assert has

# Generated at 2022-06-23 18:14:13.428720
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict
    )
    from decimal import Decimal
    from flutils.objutils import (
        is_list_like,
        is_subclass_of_any
    )

    # Test for all types of list-like objects
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(list(reversed([1, 2, 3]))) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(tuple([1, 2, 3])) is True
    assert is_

# Generated at 2022-06-23 18:14:26.394620
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from collections.abc import (
        Iterable,
        Iterator,
    )
    from decimal import Decimal
    import numbers
    import unittest

    from flutils.objutils import is_list_like

    class ListLike(object):
        def __init__(self, x):
            self.x = x

        def __iter__(self):
            return list.__iter__(self.x)

    class NonListLike(object):
        def __init__(self, x):
            self.x = x


# Generated at 2022-06-23 18:14:29.059894
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'gett','keyss','itemss','valuess')


# Generated at 2022-06-23 18:14:33.787256
# Unit test for function has_attrs
def test_has_attrs():
    assert True == has_attrs(dict(),'get','keys','items','values')
    assert True == has_attrs(dict(),'get')
    assert False == has_attrs(dict(),'something')


# Generated at 2022-06-23 18:14:40.714337
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert not has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_callables(dict(), 'foo', 'bar', 'baz') is False
    assert has_callables(dict(), 'foo') is False
    assert has_callables(dict(), 'foo', 'bar') is False
    assert has_callables(dict(), 'foo', 'bar', 'baz', 'foo') is False



# Generated at 2022-06-23 18:14:48.056110
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_callables(OrderedDict(a=1, b=2), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:14:51.910700
# Unit test for function has_callables
def test_has_callables():
    assert (has_callables(dict(),'get','keys','items','values')== True)
    assert (has_callables(dict(),'something') == False)


# Generated at 2022-06-23 18:14:55.501357
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), '__str__', 'get', 'keys') is True, 'has_callables failed to pass'
    assert has_callables(dict(), '__str__', 'get', 'nothere') is False, 'has_callables failed to fail'



# Generated at 2022-06-23 18:15:01.697537
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_attrs(dict(), 'foo', 'bar', 'baz')
    assert has_any_attrs(
        dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_attrs(dict(a=1, b=2), 'foo', 'bar', 'baz')
    return



# Generated at 2022-06-23 18:15:14.504442
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(['a', 'b']) is True
    assert is_list_like(('c', 'd')) is False
    assert is_list_like(({'e': 'e'}, {'f': 'f'})) is False
    assert is_list_like(sorted('g')) is True
    assert is_list_like('g') is False
    assert is_list_like(range(1, 10)) is False
    assert is_list_like('hello') is False
    assert is_list_like(bytes([1, 2, 3])) is False
    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(values('g')) is True


# Generated at 2022-06-23 18:15:16.563860
# Unit test for function has_callables
def test_has_callables():
    # true
    assert has_callables(dict(),'get','keys','items','values') is True
    

# Generated at 2022-06-23 18:15:27.088518
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables.
    """
    # Need a class that has the attrs we want, and is callable
    class TestClass:
        attr1 = attr2 = attr3 = attr4 = attr5 = attr6 = attr7 = attr8 = None

        def attr1(self):
            return 'attr1'

        def attr2(self):
            return 'attr2'

        def attr3(self):
            return 'attr3'

        def attr4(self):
            return 'attr4'

        def attr5(self):
            return 'attr5'

        def attr6(self):
            return 'attr6'

        def attr7(self):
            return 'attr7'


# Generated at 2022-06-23 18:15:34.498580
# Unit test for function has_callables
def test_has_callables():
    ldict = dict(a=1, b=2)
    assert has_callables(ldict, 'get')
    assert has_callables(ldict, 'setdefault')
    assert has_callables(ldict, 'get', 'setdefault')
    assert not has_callables(ldict, 'get', 'setdefault', 'foo')
    assert not has_callables(ldict, 'foo', 'bar')



# Generated at 2022-06-23 18:15:46.709927
# Unit test for function has_callables
def test_has_callables():
    """Unit test for is_subclass_of_any

    Execute as follows:

    .. code-block:: python

        python -m flutils.objutils

    """
    from collections import UserList
    actual = has_callables(dict(), 'get', 'keys', 'items', 'values')
    expected = True
    assert actual == expected, f'actual: {actual} vs expected: {expected}'

    actual = has_callables([], 'append', 'extend', 'reverse', 'sort')
    expected = True
    assert actual == expected, f'actual: {actual} vs expected: {expected}'

    actual = has_callables({}, '__contains__', '__iter__', '__len__')
    expected = True
    assert actual == expected, f'actual: {actual} vs expected: {expected}'



# Generated at 2022-06-23 18:15:52.706211
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like('hello') == False
    assert is_list_like(sorted('hello'))

if __name__ == '__main__':
    test_is_list_like()

# Generated at 2022-06-23 18:15:54.413345
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-23 18:16:04.965065
# Unit test for function is_list_like
def test_is_list_like():

    print('Testing function is_list_like()')

    # Expected True:
    true_list = (
        list([1, 2, 3]),
        frozenset({5, 6, 7}),
        set({'a', 'b', 'c'}),
        tuple((8, 9, 10)),
        deque([11, 12, 13]),
        reversed(list([1, 2, 3])),
        sorted(['a', 'b', 'c', 'd']),
        sorted(list(['a', 'b', 'c']), key=str.lower),
        reversed(tuple((8, 9, 10))),
        reversed(deque([11, 12, 13]))
    )

    # Expected False:

# Generated at 2022-06-23 18:16:11.547490
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        UserDict,
        UserString,
    )

    from decimal import Decimal

    from flutils.objutils import is_list_like

    assert is_list_like(list(range(0, 5)))

    assert is_list_like(range(0, 5))

    assert is_list_like(set())

    assert is_list_like(frozenset())

    assert is_list_like(tuple())

    assert is_list_like(UserList())

    assert is_list_like(deque())

    assert is_list_like(ValuesView())

    assert is_list_like(KeysView())

    assert is_list_like(sorted('Hello World'))

    assert is_list_like(iter('Hello World'))

   