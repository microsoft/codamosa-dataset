

# Generated at 2022-06-23 18:06:12.274693
# Unit test for function has_callables
def test_has_callables():
    """
    Check that has_callables returns expected results.
    """
    # Arrange
    test_obj = dict(a=1, b=2)
    test_attrs = ['get', 'keys', 'foo']

    # Act
    has_callables(test_obj, test_attrs)

    # Assert
    assert has_callables(test_obj, test_attrs) == True

if __name__ == '__main__':
    test_has_callables()

# Generated at 2022-06-23 18:06:18.723657
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(dict(), 'get', 'something') is True
    assert has_any_attrs(dict(), 'something') is False



# Generated at 2022-06-23 18:06:21.794160
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a='1', b='2')
    assert has_attrs(obj, '__getitem__', '__setitem__', '__contains__')



# Generated at 2022-06-23 18:06:30.505262
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for function has_attrs.
    """
    def test_has_attrs_fail(obj, attrs):
        """Test that has_attrs fails.
        """
        assert has_attrs(obj, *attrs) is False

    def test_has_attrs_pass(obj, attrs):
        """Test that has_attrs passes.
        """
        assert has_attrs(obj, *attrs) is True

    d = dict(a=1, b=2)
    class D(dict):
        pass

    test_has_attrs_pass(d, 'keys')
    test_has_attrs_pass(d, 'items')
    test_has_attrs_pass(d, 'get')
    test_has_attrs_fail(D(), 'keys')
    test

# Generated at 2022-06-23 18:06:32.959700
# Unit test for function is_list_like
def test_is_list_like():
    # Define test object
    test_obj = {'1'}

    # Check is_list_like function
    assert is_list_like(test_obj)

    return 0


# Generated at 2022-06-23 18:06:38.871266
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    import random
    import string
    # Test with simple list
    random_cls = random.choice(string.ascii_letters)
    obj = list()
    # Test True
    is_subclass_of_any(obj, list, set)
    # Test False
    is_subclass_of_any(obj, random_cls)
    # Test None
    is_subclass_of_any(None, list, set)
    # Test False
    is_subclass_of_any(None, random_cls)



# Generated at 2022-06-23 18:06:48.242219
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like(frozenset((1, 2, 3))) is True
    assert is_list_like(tuple((1, 2, 3))) is True
    assert is_list_like(deque((1, 2, 3))) is True
    assert is_list_like(sorted(map(abs, [-3, -2, -1, 0, 1, 2, 3]))) is True

# Generated at 2022-06-23 18:06:49.880826
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=2, b=3)
    assert has_callables(obj, 'keys', 'items', 'values', 'something') is True


# Generated at 2022-06-23 18:06:54.475098
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    print(has_any_attrs(obj, 'get', 'keys', 'items', 'values'))

    # Unit test for function has_any_callables

# Generated at 2022-06-23 18:06:57.839093
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    test = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert test == True

# Generated at 2022-06-23 18:07:05.961948
# Unit test for function has_any_callables
def test_has_any_callables():
    str_obj = "hello world"
    list_obj = [1,2,3]
    dict_obj = {"a":1,"b":2,"c":3}
    assert has_any_callables(str_obj,'upper','list','center') == True
    assert has_any_callables(list_obj,'append','insert','sort') == True
    assert has_any_callables(dict_obj,'items','values','keys','get') == True
    assert has_any_callables(str_obj,'upper','list','center','foo') == True
    assert has_any_callables(list_obj,'append','foo','insert','sort') == True
    assert has_any_callables(dict_obj,'foo','items','values','keys','get') == True

# Generated at 2022-06-23 18:07:14.729011
# Unit test for function has_any_callables
def test_has_any_callables():
    # Given
    obj = dict(a=1)

    # When
    attr_exists_key = has_any_callables(obj, 'keys', 'values')
    attr_exists_items = has_any_callables(obj, 'keys', 'items')
    attr_exists_get = has_any_callables(obj, 'get', 'keys')
    attr_does_not_exist_key = has_any_callables(obj, 'keys', 'something')
    attr_does_not_exist_items = has_any_callables(obj, 'items', 'something')
    attr_does_not_exist_get = has_any_callables(obj, 'get', 'something')

    # Then
    assert attr_exists_key is True
    assert attr_ex

# Generated at 2022-06-23 18:07:19.053283
# Unit test for function has_callables
def test_has_callables():
    from collections import defaultdict
    from flutils.objutils import has_callables
    obj = defaultdict(list)
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True
    assert has_callables(obj, 'default_factory') is False



# Generated at 2022-06-23 18:07:25.314196
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(5) is False



# Generated at 2022-06-23 18:07:27.082995
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-23 18:07:29.895143
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get','keys','items','values') == True
    assert has_callables(dict(), 'get','keys','items','values','foo') == False


# Generated at 2022-06-23 18:07:33.584065
# Unit test for function has_any_attrs
def test_has_any_attrs():
    '''
    >>> has_any_attrs(dict(),'get','keys','items','values','something')
    True
    '''
    pass



# Generated at 2022-06-23 18:07:36.764206
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a = 1,b = 2)
    assert has_callables(obj,'keys','items') == True


# Generated at 2022-06-23 18:07:48.082099
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'values')
    assert has_any_attrs([], 'append', 'keys', 'items', 'values') is False
    assert not has_any_attrs([], 'append', 'keys', 'items', 'values')
    assert has_any_attrs([], 'append', 'index', 'items', 'values') is True

# Generated at 2022-06-23 18:07:51.426405
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like((1,2)) is True
    assert is_list_like({'a':'b','c':'d'}) is False


# Generated at 2022-06-23 18:07:59.240921
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict((i, i) for i in range(10)),'get','keys','items','values','foo') is True
    assert has_any_callables(dict((i, i) for i in range(10)),'get','keys','items_not_here','values','foo') is False
    assert has_any_callables([i for i in range(10)],'get','keys','items_not_here','values','foo') is False


# Generated at 2022-06-23 18:08:01.903741
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(True) == False
    assert is_list_like('hello') == False
    assert is_list_like(1) == False
    assert is_list_like([1, 2, 3]) == True


if __name__ == '__main__':
    test_is_list_like()

# Generated at 2022-06-23 18:08:07.796588
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    from collections import (
        ValuesView,
        KeysView,
        UserList
    )

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)



# Generated at 2022-06-23 18:08:11.168549
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'get','foo','items','values') is False
    assert has_attrs(dict(),'foo','bar') is False


# Generated at 2022-06-23 18:08:24.020688
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import Counter
    from functools import partial
    from operator import itemgetter, truth
    from types import FunctionType
    from unittest.mock import MagicMock
    from types import LambdaType

    class Foo(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def bar(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    def baz(*args, **kwargs):
        return args + tuple(kwargs.items())

    # all false
    assert has_any_callables('') is False
    assert has_any_callables(None) is False
    assert has_any_callables(3) is False
    assert has_any

# Generated at 2022-06-23 18:08:27.971726
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables
    """
    if has_callables({}, 'get', 'keys'):
        print('has_callables: PASS')
    else:
        print('has_callables: FAIL')


# Generated at 2022-06-23 18:08:33.640069
# Unit test for function has_callables
def test_has_callables():
    obj = { 1, 2, 3 }
    assert has_callables(obj, 'pop', 'add', 'discard', 'clear') == True, 'Failed example'
    obj = (1, 2, 3)
    assert has_callables(obj, 'pop', 'add', 'discard', 'clear') == False, 'Failed example'

# Generated at 2022-06-23 18:08:38.752354
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = {'a': 1, 'b': 2}
    a1 = has_any_attrs(obj, 'get', 'keys', 'values')
    assert a1 == True
    a2 = has_any_attrs(obj, 'geta', 'getb', 'getc')
    assert a2 == False


# Generated at 2022-06-23 18:08:48.237784
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    from collections.abc import Iterator
    from collections.abc import Mapping
    obj = dict(a=1, b=2)
    
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, Mapping) == True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList, Mapping, Iterator) == True

# Generated at 2022-06-23 18:08:51.119959
# Unit test for function has_attrs
def test_has_attrs():
    assert(has_attrs(dict(), 'get', 'keys')) is True
    assert(has_attrs(dict(), 'get', 'keys', 'items', 'values')) is True



# Generated at 2022-06-23 18:08:54.162353
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')



# Generated at 2022-06-23 18:08:59.256480
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like(
        'hello'
    ) is False, 'Strings are not list-like.  They are str-like.'
    assert is_list_like(
        sorted(
            'hello'
        )
    ) is True

# Generated at 2022-06-23 18:09:05.502253
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from unittest import TestCase
    from unittest.mock import MagicMock
    class Obj:
        pass
    obj = Obj()
    obj.prop1 = MagicMock()

    assert(has_any_attrs(obj,'prop1','prop2') == True)
    assert(has_any_attrs(obj,'prop2') == False)


# Generated at 2022-06-23 18:09:07.778464
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo'
    ) is True
    assert has_any_attrs(dict(), 'foo', 'bar') is False



# Generated at 2022-06-23 18:09:11.078572
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'values') is True
    assert has_any_callables(dict(), 'get', 'keys', 'foo') is False



# Generated at 2022-06-23 18:09:13.725404
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert not has_any_callables(dict(),'get','keys','items','values','foo','bar')


# Generated at 2022-06-23 18:09:24.406990
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True)
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'gett') == True)
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'gett', 'values') == True)
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'gett', 'values','foo') == True)
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'gett', 'values','foo','boo') == False)

# Generated at 2022-06-23 18:09:29.506691
# Unit test for function has_any_callables
def test_has_any_callables():
    """Docstring."""
    from collections import OrderedDict

    od = OrderedDict()

    obj = {'a': 1, 'b': 2}
    result = has_any_callables(obj, 'a', 'b', 'c')
    assert result is False



# Generated at 2022-06-23 18:09:35.296474
# Unit test for function has_any_attrs
def test_has_any_attrs():
    '''Test function for function has_any_attrs'''

    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-23 18:09:40.468254
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True


# Generated at 2022-06-23 18:09:44.665287
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'not_values') is False
    assert has_attrs(dict(), 'not_get', 'not_keys', 'not_items', 'not_values') is False


# Generated at 2022-06-23 18:09:46.202002
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True


# Generated at 2022-06-23 18:09:52.913863
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import defaultdict

    dd = defaultdict(int)
    dd['foo'] = 1
    obj = dd
    assert has_any_callables(obj, 'foo', 'bar') == True
    assert has_any_callables(obj, 'foo', 'bar', 'get') == True
    assert has_any_callables(obj, 'foo', 'bar', 'bar') == True
    assert has_any_callables(obj, 'foo', 'bar', 'update') == False
    assert has_any_callables(obj, 'foo', 'bar', 'asdf') == False


# Generated at 2022-06-23 18:09:56.117800
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs([1, 2, 3],'get','keys','items','values','something') == False



# Generated at 2022-06-23 18:09:57.729910
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')



# Generated at 2022-06-23 18:10:09.436198
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function has_callables
    """
    from collections import OrderedDict
    from string import Template
    from datetime import datetime

    # unit tests for collections.OrderedDict
    obj = OrderedDict()
    assert has_callables(obj, 'keys', 'values', 'items', '__len__', '__contains__') is True
    assert has_callables(obj, 'keys', 'values', 'items', '__len__', '__contains__', '__getitem__') is True
    assert has_callables(obj, 'keys', 'values', 'items', '__len__', '__contains__', 'update') is True
    ma = list(obj)

# Generated at 2022-06-23 18:10:15.182490
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_attrs(dict(), 'foo', 'bar', 'baz') is False


# Generated at 2022-06-23 18:10:21.804152
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj_a = dict(a=1)

    assert has_any_attrs(obj_a, 'get', 'something') is True
    assert has_any_attrs(obj_a, 'get', 'something', 'else') is False


# Generated at 2022-06-23 18:10:27.864750
# Unit test for function has_any_callables
def test_has_any_callables():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.umd = dict(
                a=1,
                b=2,
                c=3,
                d=4,
            )
            self.umd2 = dict(
                a=1,
                b=2,
                c=3,
                d=4,
            )
            self.umd3 = dict(
                a=1,
                b=2,
                c=3,
                d=4,
            )
            self.umd4 = dict(
                a=1,
                b=2,
                c=3,
            )

        def test_1(self):
            self.assertTrue(has_any_callables(self.umd, 'get'))

# Generated at 2022-06-23 18:10:28.812068
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:10:32.961225
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'keys','items','values') is True
    assert has_any_attrs(dict(),'get','foo','bar') is False


# Generated at 2022-06-23 18:10:42.094178
# Unit test for function has_callables
def test_has_callables():
    """Test function ``has_callables``.

    :rtype:
        :obj:`bool`

        * :obj:`True` if the test passes;
        * :obj:`False` otherwise.
    """
    from unittest import TestCase
    from collections import Counter

    tests = {
        'abc': {
            'foo': 1,
            'bar': 2,
            'baz': 3,
        },
        'Counter': Counter(
            zip(['a', 'b', 'c'], [1, 2, 3])
        ),
        'list': [1, 2, 3],
        'tuple': (1, 2, 3),
        'set': {1, 2, 3}
    }

# Generated at 2022-06-23 18:10:47.144201
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    result1 = has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo')
    result2 = has_any_attrs(obj, 'foo', 'bar')

    assert result1 == True
    assert result2 == False


# Generated at 2022-06-23 18:10:52.321734
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    assert has_attrs(dict(),'get','keys','items','values') == True
    assert has_attrs(dict(),'get','keys','items','foobar') == False
    assert has_attrs(dict(),'__init__','foobar','pop') == False




# Generated at 2022-06-23 18:10:54.960601
# Unit test for function has_callables
def test_has_callables():
    from types import FunctionType
    def foo(x):
        return x
    class Example_Class:
        foo = foo

    # Should return True
    assert has_callables(Example_Class, 'foo') is True



# Generated at 2022-06-23 18:10:58.203437
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1,b=2,c=3)
    print(has_any_attrs(obj,'get','keys','items','values','foo'))


# Generated at 2022-06-23 18:11:03.012662
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = {'a': 1, 'b': 2}
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), set, frozenset, deque) is False



# Generated at 2022-06-23 18:11:07.067999
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)



# Generated at 2022-06-23 18:11:15.303351
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    ## List-like objects

    # UserList
    assert is_list_like(list()) is True
    assert is_list_like(UserList()) is True

    # Iterator
    assert is_list_like(iter([1, 2, 3])) is True
    assert is_list_like(reversed([1, 2, 3])) is True

    # KeysView
    assert is_list_like(dict(a=1, b=2).keys()) is True

    # ValuesView

# Generated at 2022-06-23 18:11:22.891971
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True
    assert is_subclass_of_any(obj.keys(),dict,list,UserList) == False
    assert is_subclass_of_any(obj, dict, list, UserList, tuple, set) == True
    assert is_subclass_of_any(obj, list, UserList, tuple, set) == False



# Generated at 2022-06-23 18:11:29.697276
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
        is True)
    assert(has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
        is True)
    # Unit test for function has_any_callables
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
        is True)
    assert(has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'something')
        is True)
    # Unit test for function has_attrs
    assert(has_attrs(dict(), 'get', 'keys', 'items', 'values') is True)
    # Unit test for function has_callables

# Generated at 2022-06-23 18:11:32.302642
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert(has_attrs(obj,"keys","get")) is True


# Generated at 2022-06-23 18:11:37.184980
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(list(),'append','insert','extend','clear','__str__') is True
    assert has_any_callables(list(),'append','insert','extend','clear','__doc__') is False


# Generated at 2022-06-23 18:11:43.841121
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Object that has some attributes
    obj = dict(a=1, b=2, items=None, values=None)
    assert has_any_attrs(obj, 'keys', 'items', 'values') is True
    assert has_any_attrs(obj, 'keys', 'something', 'values') is True
    assert has_any_attrs(obj, 'get', 'something', 'values') is False

    # Object that doesn't have the attributes
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'keys', 'items', 'values') is False



# Generated at 2022-06-23 18:11:52.444125
# Unit test for function is_list_like
def test_is_list_like():
    """Test to ensure that is_list_like is functioning properly
    """
    assert(not is_list_like(None))
    assert(not is_list_like(False))
    assert(not is_list_like(True))
    assert(not is_list_like(0))
    assert(not is_list_like(1))
    assert(not is_list_like(float(0)) )
    assert(not is_list_like(float(1.0)) )
    assert(not is_list_like(3.0))
    assert(not is_list_like(3.14159))

    assert(is_list_like([]))
    assert(is_list_like([1, 2, 3]))
    assert(is_list_like((1, 2, 3)))

# Generated at 2022-06-23 18:11:55.222731
# Unit test for function has_any_attrs
def test_has_any_attrs():
    a = dict(a=1, b=2, c=3)
    assert has_any_attrs(a, 'a', 'keys', 'values') is True



# Generated at 2022-06-23 18:11:57.782657
# Unit test for function is_list_like
def test_is_list_like():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)
    print('Testing Success')

if __name__ == "__main__":
    test_is_list_like()

# Generated at 2022-06-23 18:12:02.115637
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(a=1), 'get', 'keys', 'items', 'values', 'something') == True


# Generated at 2022-06-23 18:12:05.223517
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1)
    retval = has_callables(
        obj=obj,
        attrs='get'
    )
    assert retval is True

    obj = dict(a=1)
    retval = has_callables(
        obj=obj,
        attrs='foo'
    )
    assert retval is False



# Generated at 2022-06-23 18:12:10.241308
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import ValuesView
    from flutils.objutils import has_any_callables
    assert has_any_callables(ValuesView([1, 2, 3]), '__len__') is True
    assert has_any_callables(OrderedDict(), '__len__') is True


# Generated at 2022-06-23 18:12:14.294885
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView) is True
    assert is_subclass_of_any(obj,ValuesView,KeysView) is False


# Generated at 2022-06-23 18:12:16.850896
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    assert has_callables(dict(),'get','keys','items','something') is False


# Generated at 2022-06-23 18:12:20.050204
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """
    Test is_subclass_of_any
    """
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:12:24.262706
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'something')
    assert not has_any_attrs(dict(),None)
    assert not has_any_attrs(dict())

# Generated at 2022-06-23 18:12:27.621926
# Unit test for function has_callables
def test_has_callables():
    # Prints out the results of the test
    assert (has_callables(dict(), 'get', 'keys', 'items', 'values')) == True
    return True


# Generated at 2022-06-23 18:12:37.555909
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """
    Unit test for function has_any_attrs
    """
    import os
    import glob
    test_passed = True
    test_dict = {'a' : 'b', 'c' : 'd'}
    if not has_any_attrs(test_dict, 'get', 'keys', 'items', 'values'):
        test_passed = False
    test_list = os.listdir(os.getcwd())
    if not has_any_attrs(test_list, 'get', 'keys', 'items', 'values'):
        test_passed = False
    test_file = open('has_attrs_test.txt', 'w')

# Generated at 2022-06-23 18:12:49.777589
# Unit test for function is_list_like
def test_is_list_like():
    import unittest

    class Test(unittest.TestCase):
        from collections import (
            UserList,
            deque,
        )

        from collections.abc import (
            Iterator,
            KeysView,
            ValuesView,
        )

        from typing import Any as _Any
        from typing import List as _List
        from typing import Set as _Set
        from typing import Tuple as _Tuple
        from typing import Dict as _Dict
        from decimal import Decimal as _Decimal

        def test_is_list_like(self):
            def assert_false(val: _Any):
                self.assertFalse(is_list_like(val))

            def assert_true(val: _Any):
                self.assertTrue(is_list_like(val))


# Generated at 2022-06-23 18:12:57.810046
# Unit test for function is_list_like
def test_is_list_like():
    """Test is_list_like"""
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    # Test list-like objects
    assert is_list_like(list()) is True
    assert is_list_like(set()) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(tuple()) is True
    assert is_list_like(deque()) is True
    assert is_list_like(reversed(list())) is True
    assert is_list_like(sorted(list())) is True
    assert is_list_like(dict().keys()) is True

# Generated at 2022-06-23 18:13:09.358876
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from flutils.objutils import is_list_like
    from unittest.mock import Mock


    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(b'foo') is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False
    assert is_list_like(UserDict()) is False

# Generated at 2022-06-23 18:13:13.441487
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'keys', 'items') is True
    assert has_attrs(obj, 'keys', 'items', 'foo') is False



# Generated at 2022-06-23 18:13:22.063332
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from numbers import Number
    from numpy import (
        array,
        ndarray,
    )
    from pydantic import BaseModel
    from random import (
        sample,
        shuffle,
    )

    dict_ = dict(a=1, b=2)
    float_ = 1.0
    int_ = 1
    list_ = [1, 2, 3]
    list_str = ['a', 'b', 'c']
    numpy_array = array([1, 2, 3])
    numpy_ndarray = ndarray([1, 2, 3])
    str_ = 'hello'
    tuple

# Generated at 2022-06-23 18:13:25.341607
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:13:30.669527
# Unit test for function is_list_like
def test_is_list_like():
    
    list_like_objects = [
        [1,2,3],
        None,
        True,
        b"string",
        (1,2,3),
        dict(),
        3.5,
        2,
        "string",
    ]

    for i in list_like_objects:
        if is_list_like(i) == True:
            print (i, True)
        else:
            print (i, False)


# Generated at 2022-06-23 18:13:34.182222
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:13:35.465352
# Unit test for function has_attrs
def test_has_attrs():
    from .tests import test_has_attrs as t
    t.test()


# Generated at 2022-06-23 18:13:41.052156
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    from flutils.objutils import is_subclass_of_any
    obj = dict(a=1, b=2)
    cls1 = ValuesView
    cls2 = KeysView
    cls3 = UserList
    classes = [cls1, cls2, cls3]

    result = is_subclass_of_any(obj.keys(), *classes)
    assert(result == True)


# Generated at 2022-06-23 18:13:43.999672
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values')
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(obj, 'something', 'get', 'items')



# Generated at 2022-06-23 18:13:53.360169
# Unit test for function has_any_attrs
def test_has_any_attrs():
    my_dict = dict(a=1, b=2)
    assert has_any_attrs(my_dict, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(my_dict, 'get', 'keys', 'values', 'something') is True
    assert has_any_attrs(my_dict, 'get', 'items', 'values') is True
    assert has_any_attrs(my_dict, 'get', 'values', 'something') is True
    assert has_any_attrs(my_dict, 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(my_dict, 'items', 'values', 'something') is True



# Generated at 2022-06-23 18:14:05.195195
# Unit test for function is_list_like
def test_is_list_like():
    """
    Test if is_list_like function returns true for list-like objects
    and false for non list-like objects

    Returns:
        [bool]: true if test passes, false if test fails.
    """

    result_1 = is_list_like([1,2,3])
    assert result_1 == True

    result_2 = is_list_like(reversed([1,2,4]))
    assert result_2 == True

    result_3 = is_list_like('hello')
    assert result_3 == False

    result_4 = is_list_like(sorted('hello'))
    assert result_4 == True

    return result_1, result_2, result_3, result_4

# Run unit test
test_is_list_like()

# Generated at 2022-06-23 18:14:09.153230
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') is False
    assert has_callables(dict(), 'foo') is False

# Generated at 2022-06-23 18:14:15.925088
# Unit test for function is_list_like
def test_is_list_like():
    # List-like objects are instances of:
    # UserList, Iterator, KeysView, ValuesView, deque, frozenset, list, set,
    # tuple
    assert(is_list_like(UserList([])))
    assert(is_list_like(iterator.from_iterable([])))
    assert(is_list_like(dict(a=1, b=2).values()))
    assert(is_list_like(dict(a=1, b=2).keys()))
    assert(is_list_like(deque([])))
    assert(is_list_like(frozenset([])))
    assert(is_list_like([]))
    assert(is_list_like(set()))
    assert(is_list_like(tuple()))

    # List-like objects are

# Generated at 2022-06-23 18:14:22.025334
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Unit tests for function is_list_like

# Generated at 2022-06-23 18:14:24.788370
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'something')


# Generated at 2022-06-23 18:14:32.168266
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 3]))
    assert is_list_like(UserList([1, 2, 3]))
    assert is_list_like(tuple((1, 2, 3)))
    assert is_list_like(reversed(tuple((1, 2, 3))))
    assert is_list_like(frozenset((1, 2, 3)))
    assert is_list_like(reversed(frozenset((1, 2, 3))))
    assert is_list_like(set((1, 2, 3)))
    assert is_list_like(reversed(set((1, 2, 3))))
    assert is_list_like(deque((1, 2, 3)))
    assert is_list

# Generated at 2022-06-23 18:14:34.830504
# Unit test for function has_any_attrs
def test_has_any_attrs():
  assert has_any_attrs(dict(),'get','keys','items','values','something')


# Generated at 2022-06-23 18:14:43.092785
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get') is True
    assert has_attrs(dict(), 'something') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_attrs(dict(a=1, b=2), 'get', 'keys', 'items', 'values', 'something', '__init__') is False

# Generated at 2022-06-23 18:14:48.774630
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'foo') is True
    assert has_any_callables(dict(), 'get', 'items', 'keys', 'values') is True
    assert has_any_callables(dict(), 'get', 'not_get') is False
    assert has_any_callables(dict(), 'foo') is False


# Generated at 2022-06-23 18:14:57.246974
# Unit test for function has_callables
def test_has_callables():
    def foo1():
        return True

    def foo2():
        return True

    def foo3():
        return True

    def foo4():
        return True

    def bar1():
        return True

    class Foo:
        foo1 = foo1
        foo2 = foo2
        foo3 = foo3

    assert has_callables(Foo, 'foo1', 'foo2', 'foo3') is True
    assert has_callables(Foo, 'foo1', 'foo2', 'foo3', 'bar1') is True
    assert has_callables(Foo, 'foo1', 'foo2', 'foo3', 'bar1', 'foo4') is False
    assert has_callables(Foo, 'bar1') is False



# Generated at 2022-06-23 18:15:05.631347
# Unit test for function is_list_like
def test_is_list_like():

    from sys import modules

    import pytest

    from flutils.objutils import (
        is_list_like,
    )

    dict_class = modules['__main__'].__dict__['dict']
    set_class = modules['__main__'].__dict__['set']
    frozenset_class = modules['__main__'].__dict__['frozenset']
    list_class = modules['__main__'].__dict__['list']
    tuple_class = modules['__main__'].__dict__['tuple']
    deque_class = modules['__main__'].__dict__['deque']
    Iterator_class = modules['__main__'].__dict__['Iterator']
    ValuesView_class = modules['__main__'].__dict__['ValuesView']
    KeysView_

# Generated at 2022-06-23 18:15:17.473571
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test passing a class
    assert (has_any_attrs(dict, 'get', 'keys', 'items', 'values')) is True
    # Test passing an instance
    assert (has_any_attrs(dict(), 'get', 'keys', 'items', 'values')) is True
    # Test passing multiple attrs that don't exist
    assert (has_any_attrs(dict(), 'foo', 'bar', 'baz')) is False
    # Test passing multiple attrs that exist, but not all
    assert (has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')) is True
    # Test passing multiple attrs that exist, but not all
    assert (has_any_attrs(dict(), 'foo', 'bar', 'keys', 'items')) is True


# Unit test

# Generated at 2022-06-23 18:15:22.736590
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    actual = is_subclass_of_any('str', int)
    assert actual is False
    actual = is_subclass_of_any('str', str)
    assert actual is True
    actual = is_subclass_of_any('str', str, int)
    assert actual is True


# Generated at 2022-06-23 18:15:24.427966
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-23 18:15:30.115124
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','values','items') is True
    assert has_callables(dict(),'foo') is False
    assert has_callables(dict(),'keys','values','items') is True
    assert has_callables(dict(),'keys','/') is False
    assert has_callables(dict(),'get','keys','values','items','foo') is True
    assert has_callables(dict(),'get','keys','values','foo') is False
    assert has_callables(dict(),'keys','values') is True


# Generated at 2022-06-23 18:15:37.877041
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(),'get','keys','items','values'))
    assert(has_any_attrs(str(),'split','replace'))
    assert(has_any_attrs('hello','upper','swapcase'))
    assert(has_any_attrs(str(),'upper','swapcase'))
    assert(has_any_attrs(dict(),'get','copy','update','clear'))
    assert(has_any_attrs([1,2,3],'append','remove'))
    assert(has_any_attrs(set(),'add','remove'))


# Generated at 2022-06-23 18:15:42.767299
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs

    assert has_attrs(dict(),'get','keys','items','values') is True
    # noinspection PyTypeChecker
    assert has_attrs(dict(),'get','keys','items','values', 'foo') is False


# Generated at 2022-06-23 18:15:47.328844
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False


# Generated at 2022-06-23 18:15:54.892618
# Unit test for function has_attrs
def test_has_attrs():
    from decimal import Decimal
    d = Decimal()
    assert has_attrs(d, '__class__', 'as_tuple', 'adjusted', 'canonical')
    assert not has_attrs(d, '__class__', 'as_tuple', 'adjusted', 'canonical',
                         'something')
    assert not has_attrs(d, '__class__', 'as_tuple', 'adjusted', 'canonical',
                         'something')


# Generated at 2022-06-23 18:16:04.607909
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserList, deque
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    imports = (
        UserList,
        deque,
        Iterator,
        ValuesView,
        KeysView,
    )
    for obj in imports:
        assert has_any_attrs(obj, 'extend')
        assert has_any_attrs(obj(), 'extend')
        assert has_any_attrs(obj, 'append')
        assert has_any_attrs(obj(), 'append')
        assert has_any_attrs(obj, 'foo') is False
        assert has_any_attrs(obj(), 'foo') is False



# Generated at 2022-06-23 18:16:08.878103
# Unit test for function has_attrs
def test_has_attrs():

    # Get a dict with keys and values
    obj = dict(a=1, b=2)

    # Check that we get True
    assert has_attrs(obj,'a','b') == True
