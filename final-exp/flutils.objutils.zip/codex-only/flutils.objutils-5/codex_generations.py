

# Generated at 2022-06-23 18:06:14.499628
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # noinspection PyUnresolvedReferences
    assert has_any_attrs(set(), 'add', 'pop', 'remove')
    # noinspection PyUnresolvedReferences
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')
    # noinspection PyUnresolvedReferences
    assert has_any_attrs(list(), 'append', 'count')
    # noinspection PyUnresolvedReferences
    assert has_any_attrs(frozenset(), 'difference', 'intersection', 'union')
    # noinspection PyUnresolvedReferences
    assert has_any_attrs({1}, 'difference', 'intersection', 'union')
    # noinspection PyUnresolvedReferences
    assert has_any_attrs(tuple(), 'count', 'index')
    #

# Generated at 2022-06-23 18:06:25.648228
# Unit test for function is_list_like
def test_is_list_like():
    """Test the function is_list_like."""
    # type: () -> None
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True

    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(1) is False
    assert is_list_like(1.0) is False
    assert is_list_like('hello') is False
    assert is_list_like([1, 2, 3][0]) is False
    assert is_list

# Generated at 2022-06-23 18:06:30.170702
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables"""
    from collections import UserDict
    from flutils.objutils import has_any_callables
    obj = UserDict()

    assert has_any_callables(obj, 'keys', 'items') is True



# Generated at 2022-06-23 18:06:33.503489
# Unit test for function has_attrs
def test_has_attrs():
    class X:
        def __init__(self):
            self.a = 1
            self.b = 'two'
            self.c = lambda x: x + 1

    x = X()
    assert has_attrs(x, 'a', 'b', 'c') is True



# Generated at 2022-06-23 18:06:45.109678
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import yaml
    y = yaml.YAML()
    y.preserve_quotes = True
    y.typ = 'rt'

    y.default_flow_style = True
    for data in (
            dict(
                obj=dict(),
                attrs=('get', 'keys', 'items', 'values', 'something'),
                result=True
            ),
            dict(
                obj=dict(),
                attrs=('go', 'keke', 'imim', 'vals', 'some'),
                result=False
            )
    ):
        res = has_any_attrs(data['obj'], *data['attrs'])

# Generated at 2022-06-23 18:06:49.523385
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'foo', 'bar', 'baz') == False


# Generated at 2022-06-23 18:06:51.309773
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'get','keys','items','values','something_else') is False


# Generated at 2022-06-23 18:06:54.644983
# Unit test for function has_attrs
def test_has_attrs():
    from os import environ
    assert has_attrs(environ,'get','keys','items','values') == True


# Generated at 2022-06-23 18:07:03.227101
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    # Test with None
    assert has_any_callables(None, 'foo', 'bar', 'baz') == False
    # Test with list
    assert has_any_callables([6, 8, 10], 'append', 'insert', 'pop', 'extend')
    assert has_any_callables([6, 8, 10], 'keys', 'items', 'values', 'mro') == False
    # Test with dict
    assert has_any_callables(dict(a=1, b=2, c=3), 'keys', 'items', 'values')
    assert has_any_callables(dict(a=1, b=2, c=3), 'append', 'insert', 'pop', 'extend') == False
    # Test with dict-like object
   

# Generated at 2022-06-23 18:07:09.808076
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    import decimal
    import datetime
    # Import collections
    ChainMap = collections.ChainMap
    OrderedDict = collections.OrderedDict
    Counter = collections.Counter
    UserDict = collections.UserDict
    UserString = collections.UserString
    defaultdict = collections.defaultdict
    # Import decimal
    Decimal = decimal.Decimal
    # Import datetime objects
    datetime = datetime.datetime
    timedelta = datetime.timedelta
    tzinfo = datetime.tzinfo
    timezone= datetime.timezone
    # Import other datetime objects
    date = datetime.date
    time = datetime.time
    # Import helper objects
    from collections import (
        UserList,
        deque,
    )

# Generated at 2022-06-23 18:07:20.388541
# Unit test for function has_attrs
def test_has_attrs():
    x = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    y = 'hello'
    z = 1
    a = has_attrs(x, 'items')
    b = has_attrs(x, 'keys')
    c = has_attrs(x, 'values')
    d = has_attrs(x, 'something')
    e = has_attrs(x, 'a', 'b', 'c', 'd', 'e')
    f = has_attrs(y, 'split')
    g = has_attrs(z, 'bit_length')
    h = has_attrs(z, 'bit_lenght')
    i = has_attrs(z, 'something')
    j = has_attrs(None, 'something')

# Generated at 2022-06-23 18:07:24.196801
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(str, "__str__", "__iter__", "__contains__", "__len__")



# Generated at 2022-06-23 18:07:28.525826
# Unit test for function has_attrs
def test_has_attrs():
    class TestObj(object):
        pass
    testObj = TestObj()
    assert has_attrs(testObj, 'foo') == False
    testObj.foo = True
    assert has_attrs(testObj, 'foo') == True
    assert has_attrs(testObj, 'bar') == False


# Generated at 2022-06-23 18:07:34.603207
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserList, UserDict
    assert has_attrs([], 'append', 'remove') is True
    assert has_attrs(set(), 'add', 'remove') is True
    assert has_attrs(frozenset(), 'add', 'remove') is False
    assert has_attrs(tuple(), 'add', 'remove') is False
    assert has_attrs(deque(), 'append', 'remove') is True
    assert has_attrs(UserList(), 'append', 'remove') is True
    assert has_attrs(UserDict(), 'data', 'keys') is True



# Generated at 2022-06-23 18:07:39.474231
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get','keys','items','values','something')
    assert not has_any_attrs(2, 'get','keys','items','values','something')


# Generated at 2022-06-23 18:07:42.015461
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test function has_any_attrs."""
    assert has_any_attrs({}, '__len__', '__missing__', '__getitem__') == True



# Generated at 2022-06-23 18:07:51.333910
# Unit test for function has_attrs
def test_has_attrs():
    assert not has_attrs(dict(), 'foo')  # type: ignore
    assert has_attrs(dict(), 'foo', 'bar') is False
    assert has_attrs(dict(), 'get')  # type: ignore
    assert has_attrs(dict(), 'get', 'items')  # type: ignore
    assert has_attrs(dict(), 'something', 'somethingelse') is False
    assert has_attrs(dict(), 'something', 'somethingelse', 'get') is False
    assert has_attrs(dict(), 'get', 'something', 'somethingelse') is False
    assert has_attrs(dict(), 'something', 'get', 'somethingelse') is False
    assert has_attrs(dict(), 'something', 'somethingelse', 'get') is False

# Generated at 2022-06-23 18:07:55.002892
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(dict(),'foo','bar') is False


# Generated at 2022-06-23 18:08:02.614358
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    obj = dict()
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False
    obj = frozenset()
    assert is_subclass_of_any(obj, deque, frozenset, tuple) is True
    obj = list()
    assert is_subclass_of_any(obj, deque, frozenset, tuple) is False
    obj = reverse(list())
    assert is_subclass_of_any(obj, deque, frozenset, tuple, iter) is True
    obj = set()
    assert is_subclass_of_

# Generated at 2022-06-23 18:08:07.549837
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'foo') is False
    assert has_any_callables('hello','foo') is False


# Generated at 2022-06-23 18:08:09.663559
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'get','keys','items')
    assert not has_attrs(dict(),'foo')


# Generated at 2022-06-23 18:08:17.009798
# Unit test for function has_any_callables
def test_has_any_callables():

    # Test function with optional arguments
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

    # Test function with multiple optional arguments
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

    # Test function with no optional arguments
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')

# Generated at 2022-06-23 18:08:22.182980
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), *(ValuesView, KeysView)) is True
    assert is_subclass_of_any(obj.keys(), *(ValuesView, UserList)) is False

# Generated at 2022-06-23 18:08:25.018801
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items', 'values', 'foo')
    assert not has_any_callables(dict(),'foo','bar','baz')


# Generated at 2022-06-23 18:08:26.813631
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:08:29.308225
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_callables(dict(), '__iter__', '__len__')
    assert not has_any_callables(dict(), '__str__')


# Generated at 2022-06-23 18:08:35.315392
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj.keys(), ValuesView, KeysView, dict)

# Generated at 2022-06-23 18:08:42.372504
# Unit test for function has_attrs
def test_has_attrs():
    class Foo(object):
        def foo1(self):
            return None

        def foo2(self):
            return None

        def foo3(self):
            return None

    assert has_attrs(dict, 'items', 'keys', 'values')
    assert has_attrs(Foo(), 'foo1', 'foo2', 'foo3')
    assert not has_attrs(Foo(), 'foo1', 'foo2', 'foo3', 'foo4')



# Generated at 2022-06-23 18:08:49.006634
# Unit test for function is_list_like
def test_is_list_like():
    """Test function is_list_like

    >>> from flutils.objutils import is_list_like
    >>> is_list_like((1, 'a', 3.0))
    True
    """
    list_like = ((1, 'a', 3.0),)
    for item in list_like:
        assert is_list_like(item) is True



# Generated at 2022-06-23 18:08:50.499615
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(dict(a=1, b=2).keys(),ValuesView,KeysView,UserList)


# Generated at 2022-06-23 18:08:57.732405
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables('hello','get','keys','items','values','foo')
    assert has_any_callables(True,'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-23 18:09:09.342540
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap, Counter, OrderedDict, UserDict, UserString
    from decimal import Decimal
    # List-like
    assert is_list_like([1,2,3]) is True
    assert is_list_like(reversed([1,2,3])) is True
    assert is_list_like(sorted([1,2,3])) is True
    assert is_list_like(reversed(sorted([1,2,3]))) is True
    assert is_list_like(sorted(reversed([1,2,3]))) is True
    # Not list-like
    assert is_list_like(Decimal('1')) is False
    assert is_list_like('hello') is False
    assert is_list_like({}) is False
    assert is_list_

# Generated at 2022-06-23 18:09:17.344952
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        Counter,
        OrderedDict,
        UserDict
    )
    from collections.abc import (
        Hashable,
        Iterable,
        Iterator,
        Mapping,
        MutableMapping,
        MappingView,
        Reversible,
        Sequence,
        Sized,
        Container,
    )
    from flutils.objutils import is_subclass_of_any

    assert is_subclass_of_any(Counter, Counter)
    assert is_subclass_of_any(Counter, Sized, Mapping, Reversible, Iterable)
    assert is_subclass_of_any(
        OrderedDict, MutableMapping, Sized, Iterable, Hashable, Container
    )

# Generated at 2022-06-23 18:09:23.600929
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    def func():
        pass

    class TestClass:
        def __init__(self):
            self.var = 0

        def func(self):
            pass

    obj = TestClass()
    assert has_any_callables(obj, 'var','func') is True
    with pytest.raises(ValueError, match="Must pass at least one attribute"):
        has_any_callables(obj)


# Generated at 2022-06-23 18:09:34.151688
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import (
        is_subclass_of_any,
    )
    from collections import (
        KeysView,
        ValuesView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), KeysView, ValuesView, UserList) is True
    assert is_subclass_of_any(obj.keys(), KeysView, ValuesView) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, UserList) is False
    assert is_subclass_of_any(obj.keys()) is False
# end def test_is_subclass_of_any

# Generated at 2022-06-23 18:09:37.314142
# Unit test for function has_attrs
def test_has_attrs():
    x = {}
    assert has_attrs(x,'get','keys','items','values') == True


if __name__ == '__main__':
    test_has_attrs()

# Generated at 2022-06-23 18:09:42.993390
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'items', 'values')
    assert has_any_attrs(obj, *attrs) is True



# Generated at 2022-06-23 18:09:51.667491
# Unit test for function has_callables
def test_has_callables():
    d = dict(a=1, b=2)
    assert has_callables(d, 'keys', 'items', 'values')
    assert has_callables(d, 'keys', 'items', 'values', 'get')
    assert has_callables(d.keys(), 'get')
    assert has_callables(d.values(), 'get')
    assert has_callables(d.items(), 'get')
    assert has_callables(d.items(), 'get', 'count')
    assert has_callables(d.values(), 'get', 'count', 'index')
    assert has_callables(d.values(), 'count', 'index')
    assert has_callables(d.values(), 'count')
    assert has_callables(d.keys(), 'count')

# Generated at 2022-06-23 18:10:01.438869
# Unit test for function has_callables
def test_has_callables():
    from collections import Counter, ChainMap, UserList, UserDict, UserString
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from collections import (
        deque,
        OrderedDict,
    )
    from typing import Any
    from flutils.objutils import has_callables
    from flutils.objutils import has_any_callables

    # has_callables()
    from collections import defaultdict
    from decimal import Decimal
    from types import ClassType, FunctionType

# Generated at 2022-06-23 18:10:12.042622
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'keys')
    assert has_attrs(dict(), 'keys', 'values')
    assert has_attrs(dict(), 'keys', 'values', 'items')
    assert has_attrs(dict(), 'keys', 'values', 'items', '__repr__')
    assert has_attrs(dict(), '__repr__', '__getitem__')
    assert has_attrs(dict(), '__repr__', '__getitem__', '__setitem__')
    assert has_attrs(dict(), '__repr__', '__getitem__', '__setitem__', 'keys')
    assert has_attrs(dict(), '__repr__', '__getitem__', '__setitem__', 'keys', 'update')

# Generated at 2022-06-23 18:10:17.669559
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(a=1,b=2),'get','keys','items','values')
    assert not has_any_attrs(dict(),'foo','bar')
    assert not has_any_attrs(dict(a=1,b=2),'foo','bar')


# Generated at 2022-06-23 18:10:25.465170
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(1, int, float) == True
    assert is_subclass_of_any('foo', str, int) == True
    assert is_subclass_of_any(1.0, int, float) == True
    assert is_subclass_of_any([1,2,3], list, set, tuple) == True
    assert is_subclass_of_any((1,2,3), list, set, tuple) == True


# Generated at 2022-06-23 18:10:29.167221
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserString)


# Generated at 2022-06-23 18:10:39.503680
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    list_like_list = [
        (list, True),
        (set, True),
        (frozenset, True),
        (tuple, True),
        (deque, True),
        (Iterator, True),
        (ValuesView, True),
        (KeysView, True),
        (UserList, True),
    ]

# Generated at 2022-06-23 18:10:42.009083
# Unit test for function has_callables
def test_has_callables():
    from collections import UserList

    obj = UserList([])
    assert has_callables(obj, 'pop', 'count')



# Generated at 2022-06-23 18:10:44.127931
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:10:54.630245
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert hasattr(dict(),'get') is True
    assert hasattr(dict(),'values') is True
    assert has_attrs(dict(),'get', 'get') is True
    assert has_attrs(dict(),'keys', 'values') is True
    assert has_attrs(dict(),'values', 'keys') is True
    assert hasattr(dict(),'values') is True
    assert hasattr(dict(),'keys') is True
    assert has_attrs({},'values', 'keys') is True
    assert has_attrs(dict(),'XXXXX') is False
    assert has_attrs(dict(),'XXXXX', 'YYYYY') is False

# Generated at 2022-06-23 18:10:58.697792
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_any_attrs(dict(), 'foo', 'keys', 'items', 'values') == False


# Generated at 2022-06-23 18:11:04.383235
# Unit test for function has_attrs
def test_has_attrs():
    """Test the function has_attrs().
    """
    the_obj = dict(a=1, b=2)
    the_classes = (ValuesView, KeysView, UserList)
    assert has_attrs(the_obj, 'keys', 'values') is True
    assert has_attrs(the_obj, 'keys', 'what') is False
    assert has_attrs(the_obj, 'values', 'keys') is True
    assert has_attrs(the_obj, 'keys', 'values', 'items') is True
    assert has_attrs(the_obj, 'keys', 'values', 'something') is False
    assert has_attrs(the_obj, 'values', 'items') is True
    assert has_attrs(the_obj, 'values', 'something') is False

# Generated at 2022-06-23 18:11:09.831727
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView)
    assert is_list_like(obj.keys()) is True
    assert is_list_like(obj.values()) is True

# Generated at 2022-06-23 18:11:14.377742
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """
    >>> from flutils.objutils import has_any_attrs
    >>> has_any_attrs(dict(),'get','keys','items','values','something')
    True
    >>> has_any_attrs(dict(),'get','keys','items','values','mro')
    True
    >>> has_any_attrs(dict(),'get','keys','items','values','__name__')
    False
    """


# Generated at 2022-06-23 18:11:24.244303
# Unit test for function is_list_like
def test_is_list_like():

    from collections import ValuesView, KeysView, UserList
    from decimal import Decimal
    from functools import partial
    from itertools import chain, islice, starmap
    from operator import is_not
    from random import gauss
    from string import ascii_lowercase
    from typing import List

    # Set of valid list-like objects

# Generated at 2022-06-23 18:11:27.991957
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True



# Generated at 2022-06-23 18:11:33.627569
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'items', 'setdefault', 'pop')
    assert has_attrs(dict(), 'get', 'items', 'pop', 'popitem')
    assert not has_attrs(dict(), 'gets', 'item', 'foo', 'bar')


# Generated at 2022-06-23 18:11:36.196474
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:11:47.453445
# Unit test for function has_attrs
def test_has_attrs():
    import random
    import string
    from collections.abc import MutableMapping
    from collections import namedtuple
    from collections import UserList
    from collections import Counter
    from flutils.objutils import has_attrs

    class MyNamedTuple(namedtuple('MyNamedTuple', ['a', 'b', 'c'])):
        def __repr__(self):
            return 'MyNamedTuple {} {} {}'.format(self.a, self.b, self.c)

    class MyList(UserList):
        pass

    class MyCounter:
        def __init__(self):
            self.counter = Counter()

        def inc(self, item):
            self.counter[item] += 1

        def items(self):
            return self.counter.items()


# Generated at 2022-06-23 18:11:58.394292
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    listLike = [1,2,3]
    listLike2 = collections.deque([1,2,3])
    listLike3 = collections.UserList([1,2,3])
    listLike4 = collections.Counter([1,2,3])
    iterLike = reversed([1,2,3])
    notListLike = 'hello'
    notListLike2 = {1,2,3}
    assert is_list_like(listLike) == True
    assert is_list_like(listLike2) == True
    assert is_list_like(listLike3) == True
    assert is_list_like(listLike4) == True
    assert is_list_like(iterLike) == True
    assert is_list_like(notListLike) == False

# Generated at 2022-06-23 18:12:09.931501
# Unit test for function has_any_callables
def test_has_any_callables():
    """Unit test for function has_any_callables
    """
    from collections import (
        UserDict,
    )
    from functools import (
        partial,
    )
    from operator import (
        add,
    )

    class DummyObj(object):
        def __init__(self, a: int = 1, b: int = 2):
            self.a = a
            self.b = b

        def foo(self):
            pass

        def bar(self):
            pass

        @staticmethod
        def baz():
            pass

        @property
        def qux(self):
            pass

        @staticmethod
        def quux(x: int = 3) -> int:
            return x

    # noinspection PyProtectedMember

# Generated at 2022-06-23 18:12:17.272442
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get','keys','items','values') == True
    assert has_any_attrs(dict(),'foo','bar') == False
    assert has_any_attrs(str(),'strip','upper','lower') == True
    assert has_any_attrs(str(),'strip','upper','lower','foo') == True
    assert has_any_attrs(str(),'foo','bar') == False
    assert has_any_attrs(list(),'append','insert','remove','append') == True
    assert has_any_attrs(list(),'append','insert','remove') == True
    assert has_any_attrs(tuple(),'__len__','index') == True
    assert has

# Generated at 2022-06-23 18:12:25.577347
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables({}, *('a', 'b', 'c')) is False
    assert has_any_callables({'a': '1', 'b': '2', 'c': '3'}, *('a', 'b', 'c')) is False
    assert has_any_callables({'a': lambda x: '1'}, *('a', 'b', 'c')) is True
    assert has_any_callables([1, 2, 3], *('a', 'b', 'c')) is False



# Generated at 2022-06-23 18:12:30.071548
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = [1, 2, 3]
    attrs = ['append', 'count', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
    assert has_any_callables(obj, *attrs) == True


# Generated at 2022-06-23 18:12:33.489091
# Unit test for function has_attrs
def test_has_attrs():
    assert (has_attrs(dict(),'get','keys','items','values') == True)
    assert (has_attrs(dict(),'foo','get','keys','items','values') == False)


# Generated at 2022-06-23 18:12:35.619010
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:12:43.259290
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'keys', 'items', 'values') is True
    assert has_any_attrs(obj, 'keys', 'items', 'values', 'something') is True
    assert has_attrs(obj, 'keys', 'items', 'values', 'something') is False
    assert has_any_attrs(obj, 'something', 'anything') is False



# Generated at 2022-06-23 18:12:52.269420
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'bar') is False
    for attr in ('get', 'keys', 'items', 'values'):
        assert obj.__class__.__name__ in repr(getattr(obj, attr))
    assert 'foo' not in repr(obj)


# Generated at 2022-06-23 18:12:59.181081
# Unit test for function has_any_callables
def test_has_any_callables():

    test_obj = { 'key1': 1, 'key2': 2, 'key3': 3 }
    if has_any_callables(test_obj, 'get', 'keys', 'foo'):
        print('Passed test: has_any_attrs')
    else:
        print('Failed test: has_any_callables')



# Generated at 2022-06-23 18:13:04.261997
# Unit test for function has_callables
def test_has_callables():
    import doctest
    from flutils.objutils import has_callables as has_callables
    doctest.run_docstring_examples(
        has_callables,
        globals(),
        verbose=True
    )


# Generated at 2022-06-23 18:13:06.902063
# Unit test for function has_attrs
def test_has_attrs():
    d = dict()
    assert has_attrs(d, 'get', 'keys', 'items', 'values') == True
    assert has_attrs(d, 'hello', 'world') == False



# Generated at 2022-06-23 18:13:09.919757
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert not has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')


# Generated at 2022-06-23 18:13:15.612866
# Unit test for function has_attrs
def test_has_attrs():
    from collections import UserDict
    class TestDict(UserDict):
        pass
    test = TestDict({'key': 1})
    assert has_attrs(test, 'keys', 'get') == True
    assert has_attrs(test, 'keys', 'get', 'items') == True
    assert has_attrs(test, 'keys', 'get', 'foo') == False


# Generated at 2022-06-23 18:13:19.415904
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True)



# Generated at 2022-06-23 18:13:23.816344
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True

if __name__ == '__main__':
    test_is_subclass_of_any()

# Generated at 2022-06-23 18:13:28.825934
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for function has_any_attrs."""

    assert(has_any_attrs(dict(),'get','keys','items','values','something'))
    assert(has_any_attrs(dict(),'keys','items','values'))
    assert(has_any_attrs(dict(),'get','keys','items','values'))


# Generated at 2022-06-23 18:13:30.765022
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values')


# Generated at 2022-06-23 18:13:41.597657
# Unit test for function has_callables
def test_has_callables():
    """Unit tests for function ``has_callables``."""

    from flutils.objutils import has_callables
    from flutils.objutils import has_attrs
    from flutils.objutils import has_any_callables
    import collections

    assert isinstance(has_callables, collections.abstractmethod) is False

    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'foo') is False

    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'foo') is False

    assert has_any_callables(dict(), 'get', 'keys', 'foo') is True

# Generated at 2022-06-23 18:13:52.855673
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    import numpy

    from collections import (
        Counter, 
        OrderedDict,
        UserList,
        UserDict,
        defaultdict,
    )

    obj = {'a': 1, 'b': 2, 'c': 3}
    assert is_subclass_of_any(obj=obj, classes={'a': 1, 'b': 2, 'c': 3})
    assert is_subclass_of_any(obj=obj, classes=dict)

    assert is_subclass_of_any(obj=obj.values(), classes=UserList)
    assert is_subclass_of_any(obj=obj.values(), classes=Counter)
    assert is_subclass_of_any(obj=obj.values(), classes=OrderedDict)

# Generated at 2022-06-23 18:14:05.232444
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any({'a': 1}, ValuesView, KeysView) == True
    assert is_subclass_of_any({'a': 1}.keys(), ValuesView, KeysView) == True
    assert is_subclass_of_any({'a': 1}.values(), ValuesView, KeysView) == True
    assert is_subclass_of_any({'a': 1}.items(), ValuesView, KeysView) == True
    assert is_subclass_of_any(UserList([1, 2, 3]), ValuesView, KeysView) == True
    assert is_subclass_of_any([1, 2, 3], ValuesView, KeysView) == True
    assert is_subclass_of

# Generated at 2022-06-23 18:14:15.291457
# Unit test for function has_callables
def test_has_callables():
    assert has_callables('', 'split', 'lower') == True # Test a string
    assert has_callables(list, 'append', 'sort') == True # Test a class
    assert has_callables(list(), 'append', 'sort') == True # Test an object
    assert has_callables(10, 'bit_length') == True # Test an integer
    assert has_callables({'a': 1, 'b': 2}, 'keys', 'values') == True # Test a dict
    assert has_callables(dict(), 'keys', 'values') == True # Test a type
    assert has_callables(dict, 'update') == True # Test an instance
    assert has_callables(10, 'zfill') == False # Test an integer
    assert has_callables('', 'zfill') == False # Test a string
    assert has

# Generated at 2022-06-23 18:14:16.597820
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')

# Generated at 2022-06-23 18:14:23.572337
# Unit test for function has_attrs
def test_has_attrs():

    class Foo:
        def __init__(self):
            self.foo = 1
            self.bar = 2

    # Test with class Foo
    foo = Foo()
    assert has_attrs(foo, 'foo', 'bar') == True
    assert has_attrs(foo, 'foo', 'bar', 'baz') == False



# Generated at 2022-06-23 18:14:27.879481
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-23 18:14:30.846450
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True



# Generated at 2022-06-23 18:14:41.802739
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    # list
    assert is_subclass_of_any([1, 2, 3], ValuesView, KeysView, UserList) == False
    assert is_subclass_of_any([1, 2, 3], ValuesView, KeysView, UserList, list) == True
    # set
    assert is_subclass_of_any(set([1]), ValuesView, KeysView, UserList) == False
    assert is_subclass_of_any(set([1]), ValuesView, KeysView, UserList, set) == True
    # tuple
    assert is_subclass_of_any((1, 2, 3), ValuesView, KeysView, UserList) == False

# Generated at 2022-06-23 18:14:50.756357
# Unit test for function has_callables
def test_has_callables():
    # Test callable on all objects
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    # Test callable on keys, values, and items
    assert has_callables(dict(), 'keys', 'values', 'items') == True
    # Test only callable on keys
    assert has_callables(dict(), 'keys') == True
    # Test not callable on foo
    assert has_callables(dict(), 'foo') == False
    # Test not callable on keys and foo
    assert has_callables(dict(), 'keys', 'foo') == False


# Generated at 2022-06-23 18:14:54.388193
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)


if __name__ == '__main__':
    print('This module is not meant to be run.')

# Generated at 2022-06-23 18:14:58.477921
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values')

    class Test:
        pass

    assert has_attrs(Test, '__class__')



# Generated at 2022-06-23 18:14:59.716515
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:15:03.666484
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(set(),'intersection','union','discard','symmetric_difference')
    assert not has_attrs(tuple(),'append','remove','index','count')
    assert not has_attrs(frozenset(),'update','difference','add','remove')
    assert not has_attrs(list(),'clear','reverse','append','extend')


# Generated at 2022-06-23 18:15:09.627282
# Unit test for function has_attrs
def test_has_attrs():
    # test that has_attrs returns True if all attrs exist on object
    assert has_attrs(dict(),'get','keys','items','values') == True
    # test that has_attr returns False if all attrs do not exist on object
    assert has_attrs(dict(),'foo','bar','baz','bat') == False



# Generated at 2022-06-23 18:15:11.665040
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True


# Generated at 2022-06-23 18:15:17.239188
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap
    from decimal import Decimal
    # None breaks things
    assert is_list_like(None) == False
    # simple list
    assert is_list_like([]) == True
    assert is_list_like([1]) == True
    assert is_list_like(['a','b','c']) == True
    assert is_list_like([1, 'a', 'hello', 2.0, None, [1,2,3], (1,2,3)]) == True
    # list of list
    assert is_list_like([[1,2,3],[1,2,3]]) == True
    assert is_list_like([[1,2,3]]) == True
    # simple tuple
    assert is_list_like(()) == True

# Generated at 2022-06-23 18:15:19.076574
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    attrs = 'get', 'keys', 'items', 'values', 'something'
    assert has_any_attrs(obj, *attrs) == True


# Generated at 2022-06-23 18:15:23.398609
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True


# Generated at 2022-06-23 18:15:28.788949
# Unit test for function has_attrs
def test_has_attrs():
    from collections import defaultdict
    from flutils.objutils import has_attrs
    obj = defaultdict()
    assert has_attrs(obj, 'get', 'keys', 'items', 'values') is False
    assert has_attrs(obj, '__missing__', 'keys', 'items', 'values') is True
    assert has_attrs(obj, '__missing__', '__missing__', 'items', 'values') is True



# Generated at 2022-06-23 18:15:34.414950
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'something') is False
    assert has_any_attrs(reversed([1, 2, 3]), 'something') is False



# Generated at 2022-06-23 18:15:42.485921
# Unit test for function has_callables
def test_has_callables():
    '''unit test for function has_callables'''
    from collections import Counter
    from flutils.objutils import has_callables
    from unittest import TestCase

    class Test_has_callables(TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_has_callables_01(self):
            '''test has_callables'''
            expected_result = True
            actual_result = has_callables(Counter(), 'most_common', 'update')
            self.assertEqual(expected_result, actual_result)

        def test_has_callables_02(self):
            '''test has_callables'''
            expected_result = False

# Generated at 2022-06-23 18:15:48.948464
# Unit test for function is_list_like
def test_is_list_like():
    import collections
    import decimal
    import types

    assert(is_list_like(None) == False)
    assert(is_list_like(True) == False)
    assert(is_list_like(0) == False)
    assert(is_list_like(0.0) == False)
    assert(is_list_like(0j) == False)
    assert(is_list_like('hello') == False)
    assert(is_list_like(b'hello') == False)
    assert(is_list_like(decimal.Decimal()) == False)
    assert(is_list_like(set()) == True)
    assert(is_list_like((1, 2, 3)) == True)
    assert(is_list_like([1, 2, 3]) == True)

# Generated at 2022-06-23 18:15:54.581836
# Unit test for function has_callables
def test_has_callables():
    test_instance = {'get':'get','keys':'keys','items':'items','values':'values'}
    test_attrs = ['get','keys','items','values']
    assert has_callables(test_instance,*test_attrs)==True, 'has_callables has failed'


# Generated at 2022-06-23 18:16:05.197103
# Unit test for function has_callables
def test_has_callables():
    d = dict()
    assert has_callables(d, 'get', 'items') is True
    assert has_callables(d, 'get', 'items', '__class__') is True
    assert has_callables(d, 'get', 'items', '__class__', '__eq__') is True
    assert has_callables(d, 'get', 'items', '__class__', '__eq__',
                         '__gt__') is True
    assert has_callables(d, 'get', 'items', '__class__', '__eq__', '__hash__') \
        is True
    assert has_callables(d, 'get', 'items', '__class__', '__eq__', '__hash__',
                         '__iter__') is True

# Generated at 2022-06-23 18:16:15.538254
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test function is_list_like
    """
    print('Testing function is_list_like')
    if not is_list_like([1, 2, 3]) :
        raise Exception('Expected is_list_like to return True for [1, 2, 3]')
    if not is_list_like(reversed([1, 2, 4])) :
        raise Exception('Expected is_list_like to return True for reversed([1, 2, 4]')
    if is_list_like('hello') :
        raise Exception('Expected is_list_like to return False for "hello"')
    if not is_list_like(sorted('hello')) :
        raise Exception('Expected is_list_like to return True for sorted(hello)')
