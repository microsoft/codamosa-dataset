

# Generated at 2022-06-23 18:06:14.025109
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'something') is False
    assert has_callables(dict(), 'get', 'keys') is False
    assert has_callables(list(), 'get', 'keys', 'items', 'values') is False
    assert has_callables(list(), 'append', 'clear', 'copy', 'count') is True


# Generated at 2022-06-23 18:06:25.313303
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs({}, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs([], 'append', 'keys', 'items', 'values', 'something') is False
    assert has_any_attrs('', 'append', 'keys', 'items', 'values', 'something') is False
    assert has_any_attrs(set(), 'add', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(frozenset(), 'add', 'keys', 'items', 'values', 'something') is False
    assert has_any_attrs(tuple(), 'add', 'keys', 'items', 'values', 'something') is False

# Generated at 2022-06-23 18:06:29.609675
# Unit test for function has_callables
def test_has_callables():
    '''
    Function test_has_callables is used to test the function has_callables for
    flutils.objutils
    '''
    assert has_callables(dict(),'get','keys','items','values')



# Generated at 2022-06-23 18:06:36.182919
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import UserDict
    from flutils.objutils import has_any_attrs
    obj = UserDict(dict(a=1, b=2))
    assert has_any_attrs(obj, 'get', 'foo', 'bar') is True
    assert has_any_attrs(obj, 'bar', 'blah', 'blee') is False
    assert has_any_attrs(obj, 'bar', 'blah', 'blee', 'get') is True


# Generated at 2022-06-23 18:06:41.211292
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True



# Generated at 2022-06-23 18:06:49.546166
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    from collections import (
        OrderedDict,
        Counter,
        ChainMap,
        UserDict,
        UserList,
        UserString,
        defaultdict
    )

    # Objects
    _objects = (
        None,
        bool,
        bytes,
        type,
        object,
        tuple,
        list,
        dict,
        ChainMap,
        OrderedDict,
        Counter,
        UserDict,
        UserList,
        UserString,
        defaultdict
    )
    # Attributes
    _attrs = (
        'get',
        'keys',
        'items',
        'values',
        'update',
    )

    for obj in _objects:
        assert has_any_callables(obj, *_attrs) is True


# Generated at 2022-06-23 18:06:54.262190
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from operator import itemgetter, attrgetter
    from functools import partial
    from collections import ChainMap
    from decimal import Decimal
    class T:
        def __init__(self, x):
            self.x = x
        def f(self):
            return self.x
    t = T(10)
    t_get = T(10)
    t_get.__getitem__ = t.__getitem__
    assert has_callables(t, 'f') is True
    assert has_callables(t_get, '__getitem__') is True
    assert has_callables(itemgetter(1), '__call__') is True
    assert has_callables(attrgetter('x'), '__call__') is True
    assert has

# Generated at 2022-06-23 18:07:02.606068
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'something'
    ) is True
    assert has_any_attrs(
        dict(),
        'get',
        'keys',
        'items',
        'values'
    ) is True
    assert has_any_attrs(
        dict(),
        'get',
        'keys',
        'items',
        'values',
        'something',
        None,
        False
    ) is True
    assert has_any_attrs(
        dict(),
        None,
        False
    ) is False
    assert has_any_attrs(
        dict(),
        'something'
    ) is False


# Generated at 2022-06-23 18:07:04.975901
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:07:11.149438
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    key = dict(a=1, b=2).keys()
    assert is_subclass_of_any(key, ValuesView, KeysView, UserList) == True
    assert is_subclass_of_any(key, 'a', 'b', 'c') == False
    return True

# Generated at 2022-06-23 18:07:15.665597
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([]) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

# Generated at 2022-06-23 18:07:27.633997
# Unit test for function is_list_like

# Generated at 2022-06-23 18:07:31.137690
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2])
    assert is_list_like(sorted("hello"))
    assert is_list_like(KeysView(dict(a=1)))
    assert not is_list_like("hello")

# Generated at 2022-06-23 18:07:36.984849
# Unit test for function has_attrs
def test_has_attrs():
    obj = {
        'get': lambda x: x,
        'keys': lambda x: x,
        'items': lambda x: x,
        'values': lambda x: x,
    }
    assert has_attrs(obj, 'get', 'keys', 'values') is True
    assert has_attrs(obj, 'get', 'keys', 'something') is False


# Generated at 2022-06-23 18:07:44.137077
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert not is_subclass_of_any(obj.keys(),list,dict)


# Generated at 2022-06-23 18:07:48.964072
# Unit test for function has_attrs
def test_has_attrs():
    """Ensure that function has_attrs returns True when
    all of the given 'attrs' exists on the given object
    """
    obj = 'test'
    attrs = ['isspace', 'isalpha', 'isnumeric']
    assert has_attrs(obj, *attrs), f'{obj} should have {attrs!r}'



# Generated at 2022-06-23 18:07:59.871350
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(reversed('hello')) is True
    assert is_list_like([1,2,3]) is True
    assert is_list_like(set([1,2,3])) is True
    assert is_list_like(frozenset([1,2,3])) is True
    assert is_list_like(tuple([1,2,3])) is True
    assert is_list_like(deque([1,2,3])) is True
    assert is_list_like(Iterable([1,2,3])) is True
    assert is_list_like(dict([1,2,3])) is False

# Generated at 2022-06-23 18:08:01.928936
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:08:04.714973
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """ Unit test for function is_subclass_of_any """
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:08:06.514220
# Unit test for function has_attrs
def test_has_attrs():
    import inspect
    assert has_attrs(dict(),'get','keys','items','values') == True


# Generated at 2022-06-23 18:08:13.980654
# Unit test for function has_any_callables
def test_has_any_callables():
    assert(has_any_callables(dict(),'__getitem__','keys','items','values'))
    assert(has_any_callables(dict(),'__getitem__','keys','items','values','something'))
    assert(has_any_callables(dict(),'__getitem__','keys','items'))
    assert(has_any_callables(dict(),'__getitem__','keys'))
    assert(has_any_callables(dict(),'__getitem__'))
    assert(has_any_callables(dict(),'something'))
    assert(has_any_callables(dict(),'keys','get'))
    assert(has_any_callables(dict(),'keys','get','items'))
    assert(has_any_callables(dict(),'keys','get','items','values'))

# Generated at 2022-06-23 18:08:18.026542
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:08:24.437773
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'keys', 'values') is True
    assert has_any_callables(obj, 'keys', 'values', 'foo') is True
    assert has_any_callables(obj, 'foo') is False
    assert has_any_callables(obj, 'foo', 'bar', 'baz') is False



# Generated at 2022-06-23 18:08:30.316034
# Unit test for function is_list_like
def test_is_list_like():
    # None, bool, bytes
    assert is_list_like(
        'hello world'
    ) is False
    assert is_list_like(
        b'hello world'
    ) is False
    assert is_list_like(
        dict()
    ) is False
    assert is_list_like(
        frozenset((1, 2, 3))
    ) is True
    assert is_list_like(
        keys
    ) is False
    assert is_list_like(
        list(range(5))
    ) is True
    assert is_list_like(
        set([1, 2, 3])
    ) is True
    assert is_list_like(
        sorted('hello', reverse=True)
    ) is True
    assert is_list_like(
        tuple(range(5))
    )

# Generated at 2022-06-23 18:08:35.507319
# Unit test for function has_callables
def test_has_callables():
    # Initialise defaultdict with callable default_factory
    def default_factory(): return 'something'
    test_dict = defaultdict(default_factory)
    
    assert has_callables(test_dict, 'get', 'keys', 'items', 'values')

# Generated at 2022-06-23 18:08:40.485254
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False
    assert has_attrs(dict(a=1, b=2, c=3)) is True



# Generated at 2022-06-23 18:08:46.559327
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(None, 'lower', 'title') is False
    assert has_any_attrs('', 'lower', 'title') is True
    assert has_any_attrs(list(), 'lower', 'title') is False
    assert has_any_attrs(dict(), 'lower', 'title') is False
    assert has_any_attrs({}, 'lower', 'title') is False



# Generated at 2022-06-23 18:08:49.523134
# Unit test for function has_callables
def test_has_callables():
    obj = [1, 2, 3]
    assert has_callables(obj, 'append', 'extend') == True


# Generated at 2022-06-23 18:08:54.608819
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','foo') is True
    assert has_any_attrs('hello','foo','bar','baz','upper','capitalize') is True
    assert has_any_attrs(dict(),'foo','bar','baz','upper','capitalize') is False
    assert has_any_attrs('hello', 'foo', 'bar', 'baz') is False


# Generated at 2022-06-23 18:08:58.580659
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView) is True
    assert is_subclass_of_any(obj.keys(), ValuesView, UserList) is False
    assert is_subclass_of_any(obj.keys(), ValuesView) is False
    assert is_subclass_of_any(obj.keys()) is False

# Generated at 2022-06-23 18:09:09.457645
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class Foo:
        def __init__(self):
            self.bar = None

    assert has_any_attrs(Foo(), 'bar') is True
    assert has_any_attrs(Foo(), 'bar', 'baz') is True
    assert has_any_attrs(Foo(), '__init__', 'baz') is True
    assert has_any_attrs(Foo(), '__init__') is True
    assert has_any_attrs(Foo(), 'baz') is False

    import datetime
    assert has_any_attrs(datetime.datetime.today(), 'year') is True
    assert has_any_attrs(datetime.datetime.today(), 'year', 'month', 'day') is True

# Generated at 2022-06-23 18:09:17.449994
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(dict()), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(a=1, b=2), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict, 'get', 'keys', 'items', 'values') is False
    assert has_callables(dict, 'update', 'keys', 'items', 'values') is False
    assert has_callables(dict, 'update', 'keys', 'items', 'foo') is False
    assert has_callables(str, 'upper', 'lower', 'capitalize') is True
    assert has_callables(str, 'upper', 'lower', 'capitalize', 'foo')

# Generated at 2022-06-23 18:09:26.632938
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like
    """
    from collections import UserList, UserDict
    from flutils.objutils import is_list_like
    assert is_list_like('') is False
    assert is_list_like('a') is False
    assert is_list_like([]) is True
    assert is_list_like([1,2,3]) is True
    assert is_list_like({'a':1, 'b':2}) is False
    assert is_list_like(UserList('a')) is True
    assert is_list_like(UserDict(a=1, b=2)) is False
    assert is_list_like(('a','b','c')) is True
    assert is_list_like(('a',)) is True

# Generated at 2022-06-23 18:09:28.564768
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-23 18:09:33.365824
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like("helloworld") is False
    assert is_list_like(sorted("helloworld")) is True
    assert is_list_like(dict()) is False

# Generated at 2022-06-23 18:09:41.450887
# Unit test for function has_callables
def test_has_callables():
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'get', 'keys', 'values')
    assert has_callables(obj.keys(), 'index')
    assert has_callables(obj.values(), 'index')
    assert has_callables(obj.items(), 'index')
    assert has_callables(sorted(obj), 'index')
    assert not has_callables(obj, 'get', 'keys', 'values', 'foo')
    assert not has_callables(obj, 'foo')
    assert not has_callables(obj.keys(), 'foo')
    assert not has_callables(obj.values(), 'foo')
    assert not has_callables(obj.items(), 'foo')
    assert not has_callables(sorted(obj), 'foo')

# Generated at 2022-06-23 18:09:48.333688
# Unit test for function has_any_attrs
def test_has_any_attrs():
    x = {}
    assert has_any_attrs(x, '__setitem__', '__getitem__') is True
    assert has_any_attrs(x, '__setitem__', '__add__') is False
    assert has_any_attrs(x, 'keys', 'get', 'copy') is True
    assert has_any_attrs(x, '__setitem__', '__add__', 'keys', 'get', 'copy') is True
    assert has_any_attrs(x, 'foo') is False


# Generated at 2022-06-23 18:09:57.459288
# Unit test for function has_callables
def test_has_callables():
    from collections import OrderedDict
    obj = OrderedDict()
    assert has_callables(obj, 'get', 'keys', 'items', 'values') is True, \
        'does not have all callables'
    assert has_callables(obj, 'get', 'keys', 'items', 'values', 'foo') is False, \
        'has non-existent method'
    assert has_callables(obj, 'get', 'keys', 'items', 'values', '__iter__') is True, \
        'does not have all callables'
    assert has_callables(obj, 'get', 'keys', 'items', 'values', '__iter__', '__foo__') is False, \
        'has non-existent method and non-callable method'

# Generated at 2022-06-23 18:10:09.194993
# Unit test for function has_callables
def test_has_callables():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
    )
    from collections.abc import (
        Mapping,
        MutableMapping,
        Sequence,
        MutableSequence,
        Set,
        MutableSet,
    )
    from decimal import Decimal
    from typing import (
        Any,
        Callable,
        ClassVar,
        Generic,
        Protocol,
        TypeVar,
    )
    from types import (
        MappingProxyType,
    )

    # noinspection PyMissingOrEmptyDocstring
    class MyClass(dict):

        # noinspection PyMissingOrEmptyDocstring
        @property
        def my_getitem(self):
            pass

        # noinspection PyMissingOrEmptyDocstring

# Generated at 2022-06-23 18:10:15.322377
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList))
    assert(is_subclass_of_any(obj.keys(), list, tuple)) == False


# Generated at 2022-06-23 18:10:23.832453
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert(
        is_subclass_of_any(
            RegexFlag.IGNORECASE,
            RegexFlag.IGNORECASE,
            RegexFlag.MULTILINE
        )
    )
    assert(
        is_subclass_of_any(
            RegexFlag.IGNORECASE, RegexFlag.MULTILINE
        )
    )
    assert(
        is_subclass_of_any(
            RegexFlag.IGNORECASE,
            RegexFlag.IGNORECASE,
        )
    )



# Generated at 2022-06-23 18:10:35.069656
# Unit test for function has_attrs
def test_has_attrs():
    from collections import defaultdict

    from flutils.objutils import has_attrs

    # Ensure that has_attrs fails if attributes are not present.
    assert has_attrs(defaultdict, 'popitem', 'pop', 'rpop') is False
    assert has_attrs(dict, 'popitem', 'pop', 'rpop') is False
    assert has_attrs(list, 'popitem', 'pop', 'rpop') is False
    assert has_attrs(tuple, 'popitem', 'pop', 'rpop') is False
    assert has_attrs(set, 'popitem', 'pop', 'rpop') is False
    assert has_attrs(frozenset, 'popitem', 'pop', 'rpop') is False

# Generated at 2022-06-23 18:10:45.288956
# Unit test for function has_attrs
def test_has_attrs():
    ''' Tests function has_attrs
    '''
    # typechecked
    assert has_attrs(dict(),'get','keys','items','values') == True
    assert has_attrs(list(),'append','extend','insert') == True
    assert has_attrs(set(),'add','clear','intersection') == True
    assert has_attrs(frozenset(),'copy','difference','intersection') == True
    assert has_attrs(tuple(),'count','index') == True
    assert has_attrs(reversed([1, 2, 3]),'__next__','__iter__') == True
    assert has_attrs(zip([1, 2, 3],('a','b','c')),'__next__','__iter__') == True

# Generated at 2022-06-23 18:10:50.950005
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2, c=3)
    assert has_any_callables(obj, 'get', 'items') is True
    assert has_any_callables(obj, 'get', 'foo') is True
    assert has_any_callables(obj, 'foo', 'bar') is False


# Generated at 2022-06-23 18:10:55.505177
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # Example 1
    obj = dict(a=1, b=2)
    classes = (ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj.keys(), *classes) is True

    # Example 2
    obj = dict(a=1, b=2)
    classes = (ValuesView, UserList)
    assert is_subclass_of_any(obj.keys(), *classes) is False

# Generated at 2022-06-23 18:11:01.904908
# Unit test for function has_attrs
def test_has_attrs():
    class TestClass(object):
        def __init__(self):
            self.foo = 1
            self.bar = 2
        pass
    testobj = TestClass()
    assert has_attrs(testobj, 'foo', 'bar') is True
    assert has_attrs(testobj, 'foo', 'bar', 'baz') is False
    assert has_attrs(testobj, 'foo', 'bar', 'baz') is False


# Generated at 2022-06-23 18:11:06.208261
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like(sorted('hello'))
    assert not is_list_like('hello')


# Generated at 2022-06-23 18:11:11.922252
# Unit test for function is_list_like
def test_is_list_like():
    # Dictionary
    assert(is_list_like({}) == False)
    # List
    assert(is_list_like([]) == True)
    # Float
    assert(is_list_like(1.5) == False)
    # Float
    assert(is_list_like(True) == False)
    # Tuple
    assert(is_list_like(()) == True)

# Execution of unit test for function is_list_like
test_is_list_like()


# Generated at 2022-06-23 18:11:14.309509
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values') == True

# Generated at 2022-06-23 18:11:16.552561
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True



# Generated at 2022-06-23 18:11:20.704964
# Unit test for function has_any_callables
def test_has_any_callables():
    from flutils.objutils import has_any_callables
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')
    assert not has_any_callables(dict(), 'get', 'keys', 'items', 'values')


# Generated at 2022-06-23 18:11:26.482755
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # list has get, append, pop
    obj = list()
    assert has_any_attrs(obj, 'get', 'append', 'pop')

    # dict has get, keys, items, values
    obj = dict()
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values')

    # dict has no foo
    obj = dict()
    assert not has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo')

    # None has no foo
    obj = None
    assert not has_any_attrs(obj, 'foo')



# Generated at 2022-06-23 18:11:29.034580
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items', 'values', 'foo') == True


# Generated at 2022-06-23 18:11:37.587836
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert test_utils.has_any_attrs_is_true_on_dict(
        has_any_attrs,
        ('keys', 'items', 'values', '__repr__')
    )
    assert test_utils.has_any_attrs_is_False_on_dict(
        has_any_attrs,
        ('foobar',)
    )
    assert test_utils.has_any_attrs_is_False_on_dict(
        has_any_attrs,
        'foobar'
    )



# Generated at 2022-06-23 18:11:40.948271
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is not False


# Generated at 2022-06-23 18:11:44.584746
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'clear', '__delitem__', '__setitem__') is True


# Generated at 2022-06-23 18:11:48.405846
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get')
    assert has_callables(dict(),'get','keys')
    assert not has_callables(dict())
    assert not has_callables(dict(),'foo')


# Generated at 2022-06-23 18:11:58.820001
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test :func:`has_any_attrs`.

    :rtype:
        :obj:`None`
    """
    assert has_any_attrs(list(), 'add', 'index', 'something')
    assert not has_any_attrs(list(), 'something')
    assert has_any_attrs(list(), 'add', 'index', 'clear')
    assert not has_any_attrs(list(), 'add', 'something', 'clear')
    assert has_any_attrs(tuple(), 'add', 'index', 'clear')
    assert not has_any_attrs(tuple(), 'add', 'something', 'clear')
    assert has_any_attrs(set(), 'add', 'index', 'clear')
    assert not has_any_attrs(set(), 'add', 'something', 'clear')

# Generated at 2022-06-23 18:12:06.404652
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(set(), 'add', 'clear', 'copy', 'discard', 'pop') is True
    assert has_attrs(frozenset(), 'add', 'clear', 'copy', 'discard', 'pop') is False
    assert has_attrs((1, 2, 3, 4), 'count', 'index', '__getitem__', '__iter__') is True



# Generated at 2022-06-23 18:12:18.430535
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values',
                         'something') is True
    assert has_any_attrs(dict(), 'get', 'k', 'items', 'values',
                         'something') is False
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values',
                         'something') is True
    assert has_any_attrs(dict(), 'foo', 'bar') is False
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'values',
                         'something') is True
    assert has_any_attrs(dict, 'foo', 'bar') is False
    assert has_any_attrs(5, 'real', 'imag', 'conjugate') is False

# Generated at 2022-06-23 18:12:23.102957
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True


# Generated at 2022-06-23 18:12:30.171620
# Unit test for function has_callables
def test_has_callables():
    from collections import deque
    from collections.abc import Iterator, KeysView, ValuesView
    from collections import UserList
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables('hello', 'upper', 'lower') is True
    assert has_callables(list(), 'sort', 'pop') is True
    assert has_callables(deque(), 'sort', 'pop') is True
    assert has_callables(Iterator, 'sort', 'pop') is True
    assert has_callables(KeysView, 'sort', 'pop') is True
    assert has_callables(ValuesView, 'sort', 'pop') is True
    assert has_callables(UserList, 'sort', 'pop') is True

# Generated at 2022-06-23 18:12:37.144194
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like('hello') is False
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like([]) is True
    assert is_list_like([1, 'hello', 2]) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like(iter('hello')) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(sorted([1, 2, 3])) is True



# Generated at 2022-06-23 18:12:49.670269
# Unit test for function is_list_like
def test_is_list_like():
    from collections import namedtuple, UserDict, ChainMap
    from collections.abc import OrderedDict, UserString
    from decimal import Decimal
    from flutils.objutils import is_list_like


# Generated at 2022-06-23 18:12:57.731676
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from typing import (
        Any as _Any,
        Union as _Union
    )

    _LIST_LIKE = (
        list,
        set,
        frozenset,
        tuple,
        deque,
        Iterator,
        ValuesView,
        KeysView,
        UserList
    )

    # Lists, sets, tuples and frozensets should be recognized
    assert is_list_like(['foo', 'bar']) is True, "List not recognized correctly"
    assert is_list_like(set(['foo', 'bar'])) is True, "Set not recognized correctly"
    assert is_list_like

# Generated at 2022-06-23 18:13:04.832255
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.items(), ValuesView, KeysView, UserList) is False



# Generated at 2022-06-23 18:13:15.500624
# Unit test for function has_callables
def test_has_callables():
    """Test the has_callables() function.

    Expected:
        >>> from collections import deque, UserList
        >>> from flutils.objutils import has_callables
        >>> has_callables(deque(), 'append', 'extend')
        True
        >>> has_callables(UserList(), 'append', 'extend')
        True
        >>> has_callables(object(), '__add__', '__eq__', '__le__')
        True
        >>> has_callables('', 'split')
        False
        >>> has_callables(set(), 'append', 'extend')
        False
        >>> has_callables(dict(), 'append', 'extend')
        False
    """
    pass


# Generated at 2022-06-23 18:13:21.934494
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3])
    assert is_list_like(reversed([1,2,4]))
    assert is_list_like('hello')
    assert is_list_like(sorted('hello'))
    assert is_list_like('hello')

# Generated at 2022-06-23 18:13:26.562321
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(),'get','keys','items','values','something') is True)
    assert(has_any_attrs(dict(),'something','something else','something different') is False)



# Generated at 2022-06-23 18:13:28.329648
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert(has_any_attrs(dict(),'get','keys','items','values','something'))


# Generated at 2022-06-23 18:13:34.948244
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) == True


# Backwards compatibility
has_all_attrs = has_attrs
has_all_callables = has_callables

# Generated at 2022-06-23 18:13:44.334714
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Testing has_any_attrs on a dict()
    print('Testing has_any_attrs on a dict().')
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values',
                         'something') is True
    print('has_any_attrs on a dict() passed.')
    # Testing has_any_attrs on a list
    print('Testing has_any_attrs on a list.')
    assert has_any_attrs([1, 2, 3], 'append', 'remove', 'sort', 'foo') is True
    print('has_any_attrs on a list passed.')
    # Testing has_any_attrs on a tuple
    print('Testing has_any_attrs on a tuple.')

# Generated at 2022-06-23 18:13:50.046446
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    if is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList):
        print('Is ValueView, KeysView or UserList.')
    else:
        print('Is not ValueView, KeysView or UserList.')

# Generated at 2022-06-23 18:13:53.376625
# Unit test for function has_any_callables
def test_has_any_callables():
    d = dict(a=1, b=2)
    assert has_any_callables(d, 'get', 'keys', 'items', 'values') is True
    assert has_any_callables(d, 'asdfasdf', 'asdfdfg', 'aaaaaaa', 'bnbbbbb') is False



# Generated at 2022-06-23 18:13:55.033731
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-23 18:13:59.715971
# Unit test for function has_attrs
def test_has_attrs():
    ret = has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert ret is True
    ret = has_attrs(dict(), 'get', 'keys', 'items', 'foo')
    assert ret is False



# Generated at 2022-06-23 18:14:10.318480
# Unit test for function is_list_like
def test_is_list_like():
    import decimal
    import random
    import string
    classes = (
        decimal.Decimal,
        Decimal,
        dict,
        float,
        int,
        None,
        str,
        bool,
        bytes,
        Decimal,
        dict,
        float,
        int,
        None,
        str,
        bool,
        bytes,
    )
    print('is_list_like results for:')
    for cls in classes:
        print(cls, cls())
        assert is_list_like(cls()) is False
    # Generate some random objects
    for _ in range(10):
        obj = ''.join(random.choices(string.ascii_letters, k=random.randint(1, 10)))
        print(obj)
        assert is_list_

# Generated at 2022-06-23 18:14:17.423056
# Unit test for function is_list_like
def test_is_list_like():
    test_ttples = (
        (None, False),
        (bool, False),
        (bytes, False),
        (dict, False),
        (float, False),
        (int, False),
        (str, False),
        (tuple, False),
        ('hello', False),
        (1, False),
        (1.0, False),
        (reversed('hello'), True),
        (sorted('hello'), True),
        (sorted(reversed('hello')), True),
        (set('hello'), True),
    )
    for obj, expected in test_ttples:
        assert is_list_like(obj) is expected

# Generated at 2022-06-23 18:14:29.303340
# Unit test for function has_any_callables
def test_has_any_callables():
    # dictionary
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    # set
    assert has_any_callables(set(),'get','keys','items','values','foo') is False
    # frozenset
    assert has_any_callables(frozenset(),'get','keys','items','values','foo') is False
    # list
    assert has_any_callables(list(),'get','keys','items','values','foo') is False
    # tuple
    assert has_any_callables(tuple(),'get','keys','items','values','foo') is False
    # deque
    assert has_any_callables(deque(),'get','keys','items','values','foo') is False
    # iterator

# Generated at 2022-06-23 18:14:31.882435
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-23 18:14:37.365386
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict, 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict, 'foo', 'bar', 'woof', 'sniff') is False
    assert has_attrs(dict, 'get', 'keys', 'items', 'values', 'foo', 'bar') is False



# Generated at 2022-06-23 18:14:40.707154
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') == True


# Generated at 2022-06-23 18:14:48.824199
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    # Setup test data
    obj = dict(a=1, b=2)
    args_1 = (ValuesView, KeysView, UserList)
    args_2 = (dict, ValuesView, KeysView, UserList)

    # Run tests
    assert is_subclass_of_any(obj.keys(), *args_1)
    assert is_subclass_of_any(obj.keys(), *args_2) is False

# Generated at 2022-06-23 18:14:56.767523
# Unit test for function has_any_attrs
def test_has_any_attrs():
    d = dict(a=1, b=2)
    assert has_any_attrs(d, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(d, 'get', 'keys', 'items', 'values', 'something', 'none') is False
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something', 'none') is False
    assert has_any_attrs(dict, 'get', 'keys', 'items', 'values', 'something', 'none') is False


# Generated at 2022-06-23 18:15:04.589393
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(True) is False
    assert is_list_like(42) is False
    assert is_list_like('hello') is False

    assert is_list_like({} is False)
    assert is_list_like({'a':1,'b':2}) is False

    assert is_list_like([]) is True
    assert is_list_like([1,2,3]) is True
    assert is_list_like((1,2,3)) is True
    assert is_list_like({1,2,3}) is True
    assert is_list_like(set([1,2,3])) is True

# Generated at 2022-06-23 18:15:16.787521
# Unit test for function has_callables
def test_has_callables():
    """Test function has_callables"""
    from flutils.objutils import has_callables
    from unittest import TestCase
    from unittest.mock import patch
    from builtins import (
        list,
        tuple
    )
    class MockObj(object):
        """Mock object for testing has_callables"""
        @staticmethod
        def all_exist():
            """Check if all callables exist"""
            return True
        @staticmethod
        def none_exist():
            """Check if none of the callables exist"""
            return False
        @staticmethod
        def some_exist():
            """Check if some of the callables exist"""
            return True


# Generated at 2022-06-23 18:15:20.146931
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:15:25.513642
# Unit test for function has_callables
def test_has_callables():
    # Given: An object to check and attributes
    obj = dict(a=1, b=2)
    attrs = ('get', 'keys', 'items', 'values')

    # When: Check that all the attrs exist and are callable
    result = has_callables(obj, *attrs)

    # Then: The result should be True
    assert result



# Generated at 2022-06-23 18:15:27.806576
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables

    assert has_callables(dict(), 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:15:32.783134
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs({}, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs({}, 'get', 'keys', 'items', 'values', 'foo') is True



# Generated at 2022-06-23 18:15:39.574685
# Unit test for function is_list_like
def test_is_list_like():
    """Unit test for function is_list_like."""
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from operator import itemgetter
    import json

    # List-like objects

# Generated at 2022-06-23 18:15:49.479957
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(list(),'append','count','extend','index','insert',
                         'something')
    assert has_any_attrs(set(),'add','clear','copy','difference','something')
    assert has_any_attrs(frozenset(),'copy','difference','intersection_update',
                         'issubset','something')
    assert has_any_attrs(tuple(),'count','index','something')
    assert has_any_attrs(deque(),'append','appendleft','clear','copy','something')
    assert has_any_attrs(Iterator(),'__next__','something')

# Generated at 2022-06-23 18:15:50.844594
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:15:52.430623
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs([], '__len__', '__contains__')
    assert not has_attrs([], '__len__', '__contains__', '__iter__')



# Generated at 2022-06-23 18:16:00.426171
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(), '__init__', '__contains__', '__iter__')
    assert has_attrs(OrderedDict(), '__init__', '__contains__', '__iter__')
    assert has_attrs(collections.ChainMap(), 'get', 'parents', 'maps', 'new_child')
    assert has_attrs(collections.Counter(), 'update', 'clear', 'most_common')
    assert has_attrs(next, '__call__', 'send', 'close')
    assert has_attrs(operator.add, '__call__', '__gt__', '__ne__')

# Generated at 2022-06-23 18:16:03.802015
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(), 'get')
    assert not has_attrs(dict(), 'foo')
    assert not has_attrs(123, 'foo', 'bar')


# Generated at 2022-06-23 18:16:10.631822
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'foo') is True
    assert has_any_callables(dict(), 'keys', 'foo', 'bar') is True
    assert has_any_callables(dict(), 'keys', 'foo', 'bar', 'nothing') is False
    assert has_any_callables(dict(), 'get', 'getattr') is False
