

# Generated at 2022-06-23 18:06:14.733899
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class Test1:
        def __init__(self):
            self.foo = 'bar'

    class Test2(Test1):
        def __init__(self):
            super().__init__()
            self.foo2 = 'bar'

    assert has_any_attrs(dict(),'get','keys','items','values','something') is True
    assert has_any_attrs(int,'real','conjugate','__add__','__mul__') is True
    assert has_any_attrs(Test1,'foo','__init__','foo2','__class__') is True
    assert has_any_attrs(Test2,'foo','__init__','foo2','__class__') is True
    assert has_any_attrs(5,'bit_length','conjugate') is True
    assert has_any_att

# Generated at 2022-06-23 18:06:23.659194
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Unit test for ``has_any_attrs``.

    Notes:
        * If a ``TypeError`` is raised, the test will fail.

    Examples:
        >>> from flutils.objutils import has_any_attrs
        >>> has_any_attrs(dict(),'get','keys','items','values','something')
        True
        >>> has_any_attrs(dict(),'get','keys','items','values','something')
        True
    """
    has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')



# Generated at 2022-06-23 18:06:31.280743
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3]) == True
    assert is_list_like(reversed([1,2,3])) == True
    assert is_list_like('hello') == False
    assert is_list_like(sorted('hello')) == True
    assert is_list_like(1) == False
    assert is_list_like(1.0) == False
    assert is_list_like(None) == False



# Generated at 2022-06-23 18:06:35.608047
# Unit test for function has_attrs
def test_has_attrs():
    assert not has_attrs(dict(),'get','keys','items','values','something')
    assert has_attrs(dict(),'get','keys','items','values')
    assert not has_attrs(dict(),'get','keys','items','values','get')


# Generated at 2022-06-23 18:06:42.219726
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    import unittest

    list_like = (
        bool,
        bytes,
        ChainMap,
        Counter,
        float,
        int,
        OrderedDict,
        set,
        str,
        UserDict,
        UserString,
        defaultdict,
        Decimal,
        dict,
        frozenset,
        list,
        tuple,
    )
    non_list_like = (
        None,
    )

    class TestIsListLike(unittest.TestCase):
        """ Testing the function is_list_like. """


# Generated at 2022-06-23 18:06:48.511544
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    # given
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    expected_result=True
    # when
    result = is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    # then
    assert result == expected_result

# Generated at 2022-06-23 18:06:49.622189
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is True

# Generated at 2022-06-23 18:06:52.737568
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(str, 'startswith', 'upper')
    assert has_callables(dict, 'get', 'keys', 'values')
    assert has_callables(tuple, 'index')

    assert not has_callables(str, 'startswith', 'upper', 'foo')
    assert not has_callables(dict, 'get', 'keys', 'values', 'foo')
    assert not has_callables(tuple, 'index', 'foo')


# Generated at 2022-06-23 18:06:56.855602
# Unit test for function has_callables
def test_has_callables():
    """ Test for the ``has_callables`` function.

        Test for the ``has_callables`` function.

    """
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'something', 'else') is False

# Generated at 2022-06-23 18:06:58.945524
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.tests import objutils
    assert objutils.has_attrs(dict(),'get','keys','items','values') is True

# Generated at 2022-06-23 18:07:03.079596
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') == True
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something else') == False



# Generated at 2022-06-23 18:07:14.052341
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Testing the is_subclass_of_any function."""
    from pyutils import FlutilsUnitTester

    tester = FlutilsUnitTester(
        test_module_doc=__doc__,
        module_name=__name__,
        test_class_doc=test_is_subclass_of_any.__doc__,
        test_func_doc=test_is_subclass_of_any.__doc__,
    )
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )

    obj = dict(a=1, b=2)

# Generated at 2022-06-23 18:07:17.751475
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values')
    assert not has_callables(dict(),'to_dict','values')
    assert not has_callables(dict(),'foo','bar','baz')


# Generated at 2022-06-23 18:07:29.574575
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import ChainMap, OrderedDict
    from typing import List
    cm: ChainMap = ChainMap()
    cm.maps = [{'a': 1, 'b': 2, 'c': 3}]
    od: OrderedDict = OrderedDict()
    od.update(a=1, b=2, c=3)
    a: List[int] = [1, 2, 3]
    assert has_any_callables(od, 'get', 'keys', 'values', 'items')
    assert has_any_callables(od, 'keys', 'values', 'items')
    assert has_any_callables(od, 'keys', 'items')
    assert has_any_callables(od, 'items')

# Generated at 2022-06-23 18:07:40.832681
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    class Foo:
        pass

    class Bar(Foo):
        pass

    # Bar is a subclass of Foo
    assert is_subclass_of_any(Bar, Foo)

    # Bar is not a subclass of Bar
    assert not is_subclass_of_any(Bar, Bar)

    # Bar is a subclass of (Foo, Bar)
    assert is_subclass_of_any(Bar, Foo, Bar)

    # Bar is not a subclass of (Bar, Foo)
    assert not is_subclass_of_any(Bar, Bar, Foo)

    # Bar is not a subclass of Foo
    assert not is_subclass_of_any(Bar, Bar, Bar)



# Generated at 2022-06-23 18:07:43.882049
# Unit test for function has_callables
def test_has_callables():
    if has_callables(dict(),'get','keys','items','values') is True:
        print("Test has_callables Passed")
    else:
        print("Test has_callables Failed")

# Generated at 2022-06-23 18:07:51.579058
# Unit test for function is_list_like
def test_is_list_like():
    cases = [
        ([], True),
        (['a', 'b', 'c'], True),
        ('hello', False),
        ('hello', True),
        (dict(a=1, b=2, c=3), False),
        (dict(a=1, b=2, c=3).keys(), True),
        (dict(a=1, b=2, c=3).values(), True),
        (dict(a=1, b=2, c=3).items(), True)
    ]
    for args, expected in cases:
        try:
            obj = is_list_like(*args)
        except TypeError as err:
            obj = err

        assert obj == expected

# Generated at 2022-06-23 18:08:00.868017
# Unit test for function has_callables
def test_has_callables():
    from functools import reduce
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_attrs(reduce, '__call__', '__next__')
    assert has_callables(reduce, '__call__', '__next__')
    assert has_attrs(reduce, '__call__', '__next__')
    assert has_callables(reduce, '__call__', '__next__')

# Generated at 2022-06-23 18:08:11.424780
# Unit test for function has_attrs
def test_has_attrs():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )

    from decimal import Decimal

    class Foo:
        def __init__(self, d: dict = {}) -> None:
            self.d = d

        def __iter__(self):
            return iter(self.d)

        def keys(self):
            return self.d.keys()

        def items(self):
            return self.d.items()

        def values(self):
            return self.d.values()

    # List of the things that are not iterable

# Generated at 2022-06-23 18:08:17.702049
# Unit test for function has_attrs
def test_has_attrs():
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'keys') == True
    assert has_attrs(obj, 'get', 'keys1') == False
    assert has_attrs(obj, 'get11') == False


# Generated at 2022-06-23 18:08:20.070236
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True


# Generated at 2022-06-23 18:08:28.987753
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj1 = dict(a=1)
    assert is_subclass_of_any(obj1.keys(),ValuesView)
    assert is_subclass_of_any(obj1.values(), ValuesView)
    assert is_subclass_of_any(obj1.keys(), ValuesView, KeysView)
    assert is_subclass_of_any(obj1.values(), ValuesView, KeysView)
    assert is_subclass_of_any(obj1.keys(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(obj1.values(), ValuesView, KeysView, UserList)
    assert not is_subclass_of_any(obj1.keys(), UserList)

# Generated at 2022-06-23 18:08:41.850876
# Unit test for function is_list_like
def test_is_list_like():

    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like(bytes(b'hello')) is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False
    assert is_list_like(UserDict()) is False
    assert is_list_like(UserList()) is True
    assert is_list_like(UserString()) is False

# Generated at 2022-06-23 18:08:44.932712
# Unit test for function has_any_callables
def test_has_any_callables():
    # pass
    assert has_any_callables(dict(),'get','keys','items','values','foo')



# Generated at 2022-06-23 18:08:48.288653
# Unit test for function has_attrs
def test_has_attrs():
    """Test for function has_attrs()"""
    assert has_attrs(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:08:50.000833
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True


# Generated at 2022-06-23 18:08:54.211155
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:08:56.928487
# Unit test for function has_attrs
def test_has_attrs():
    """Check that the ``has_attrs`` function works correctly.
    """
    a = dict()
    assert has_attrs(a, 'get', 'keys', 'items', 'values')

    a = dict()
    assert not has_attrs(a, 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-23 18:08:59.474191
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')==True


# Generated at 2022-06-23 18:09:04.897545
# Unit test for function has_callables
def test_has_callables():
    assert (
        has_callables(
            dict(),
            'copy',
            'fromkeys',
            'get',
            'items',
            'keys',
            'pop',
            'popitem',
            'setdefault',
            'update',
            'values'
        )
    ) is True

# Generated at 2022-06-23 18:09:07.178767
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs({}, 'get')
    assert not has_any_attrs({}, 'keys', 'items', 'values', 'something')



# Generated at 2022-06-23 18:09:12.535580
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'foo', 'values') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is False



# Generated at 2022-06-23 18:09:23.933599
# Unit test for function has_attrs
def test_has_attrs():
    """Unit test for function has_attrs."""
    test_obj = dict(a=1, b=2)
    test_obj2 = UserDict(test_obj)
    test_obj3 = OrderedDict(test_obj)
    test_obj4 = object()
    assert has_attrs(test_obj, 'pop', 'keys', 'values', 'items') is True
    assert has_attrs(test_obj, 'pop', 'keys', 'values', 'items', 'foo') is False
    assert has_attrs(test_obj, 'pop', 'keys', 'values', 'items', 'keys') is True
    assert has_attrs(test_obj, 'pop', 'keys', 'values', 'items', 'keys', 'foo') is False

# Generated at 2022-06-23 18:09:34.980460
# Unit test for function has_attrs
def test_has_attrs():
    # dict
    dict_obj = dict()
    assert has_attrs(dict_obj, 'get', 'keys', 'items', 'values')
    assert has_any_attrs(dict_obj, 'get', 'keys', 'items', 'values', 'something')
    # list
    list_obj = list()
    assert has_attrs(list_obj, 'pop', 'count', 'insert', 'clear')
    assert has_any_attrs(list_obj, 'pop', 'count', 'insert', 'clear', 'something')
    #set
    set_obj = set()
    assert has_attrs(set_obj, 'discard', 'union', 'intersection', 'difference')

# Generated at 2022-06-23 18:09:39.870994
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True)

# Generated at 2022-06-23 18:09:47.754596
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values','foo') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values','foo','update') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values','foo','__add__') == False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values','foo','update','__add__') == False


# Generated at 2022-06-23 18:09:50.031312
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:09:52.504867
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test for has_any_callables
    """
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:09:53.717058
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'__str__','__len__','__repr__') is True


# Generated at 2022-06-23 18:10:05.249725
# Unit test for function is_list_like
def test_is_list_like():
    """Test the function :func:`is_list_like` ."""
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(sorted([1, 2, 3])) is True
    assert is_list_like(tuple([1, 2, 3])) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(deque([1, 2, 3])) is True
    assert is_list_like(set([1, 2, 3])) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(dict(a=1, b=2, c=3).keys()) is True

# Generated at 2022-06-23 18:10:09.194634
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert is_subclass_of_any(obj.values(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:10:14.986757
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert has_any_attrs(dict(),'get','keys','something','values','items','something') is False


# Generated at 2022-06-23 18:10:25.711461
# Unit test for function has_attrs
def test_has_attrs():
    # Fixture with class with both attributes
    class TestClass(object):
        def __init__(self, foo):
            self.foo = foo
            self.bar = {'baz': 'bam'}
        def test_method(self):
            return True

    # Fixture with a class with only one attribute
    class TestClass2(object):
        def __init__(self, foo):
            self.foo = foo
        def test_method(self):
            return True

    # Fixture with class that has no attributes
    class TestClass3(object):
        def __init__(self, foo):
            self.test_method(foo)
        def test_method(self, foo):
            return foo

    # Test that it returns True if all attrs exist

# Generated at 2022-06-23 18:10:27.857790
# Unit test for function has_any_attrs
def test_has_any_attrs():
    result = has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'something')
    assert result == True



# Generated at 2022-06-23 18:10:32.068773
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'get','keys','items','values','foo') == True
    assert has_callables(dict(a=1),'get','keys','items','values') == True


# Generated at 2022-06-23 18:10:35.677172
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')
    assert not has_any_attrs(dict(),'get','keys','items','values','something')



# Generated at 2022-06-23 18:10:42.961061
# Unit test for function has_attrs
def test_has_attrs():
    test_obj = dict(a=1, b=2)
    attr_list = ['get', 'keys', 'items', 'values']
    assert has_attrs(test_obj, *attr_list) is True
    assert has_attrs(test_obj, 'get') is True
    assert has_attrs(test_obj, 'keys') is True
    assert has_attrs(test_obj, 'items') is True
    assert has_attrs(test_obj, 'values') is True
    assert has_attrs(test_obj, '__missing__') is False
    assert has_attrs(test_obj, '__missing__', 'get') is False


# Generated at 2022-06-23 18:10:53.791322
# Unit test for function has_attrs
def test_has_attrs():
    from io import StringIO
    from tempfile import NamedTemporaryFile
    # Test Defaults
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'get', 'items', 'keys', 'values') == True
    assert has_attrs(obj, 'foo', 'bar', 'baz', 'qux') == False
    # Test List-like
    assert has_attrs(list(obj.values()), 'get', 'keys', 'values') == True
    assert has_attrs(list(obj.values()), 'foo', 'bar', 'baz', 'qux') == False
    assert has_attrs(sorted(obj.values()), 'get', 'keys', 'values') == True

# Generated at 2022-06-23 18:10:56.281123
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:11:06.974408
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any('hello',str) == True
    assert is_subclass_of_any('hello',str,int) == True
    assert is_subclass_of_any(True,bool,list) == True
    assert is_subclass_of_any([1,2,3],list) == True
    assert is_subclass_of_any(None,UserList,ValuesView,KeysView) == False
    assert is_subclass_of_any(None,UserList,ValuesView,KeysView,type(None)) == True
    assert is_subclass_of_any(dict.fromkeys('abc'),dict) == True
    assert is_subclass_of_any(dict.fromkeys('abc'),dict,UserList) == True

# Generated at 2022-06-23 18:11:12.900270
# Unit test for function has_any_callables
def test_has_any_callables():
    """Test for function ``has_any_callables``
    """
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get1','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get1','keys1','items','values','foo') is True
    assert has_any_callables(dict(),'get1','keys1','items1','values','foo') is True


# Generated at 2022-06-23 18:11:20.947085
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), '__getitem__', 'pop', 'popitem', 'clear') is True
    assert has_callables(dict(), '__getitem__', 'pop', 'clear') is True
    assert has_callables(dict(), '__getitem__', 'pop', 'popitem') is True
    assert has_callables(dict(), '__getitem__', 'pop', 'popitem', 'clear', 'get') is False
    assert has_callables({}, '__getitem__', 'pop', 'popitem', 'clear') is False



# Generated at 2022-06-23 18:11:28.225512
# Unit test for function has_attrs
def test_has_attrs():
    """Test function :func:`has_attrs <flutils.objutils.has_attrs>`."""
    from collections import KeysView, ValuesView, UserList
    obj = dict(a=1, b=2, c=3)
    assert has_attrs(obj, 'keys', 'values', 'items') is True, (
        '`has_attrs` should return True when given an object with the '
        'given attributes.'
    )
    assert has_attrs(obj.keys(),'__iter__','__len__','__contains__','__getitem__','__setitem__','__delitem__','__reversed__','__sizeof__') is True, (
        '`has_attrs` should return True when given an object with the '
        'given attributes.'
    )
    assert has_att

# Generated at 2022-06-23 18:11:39.721126
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables([1, 2, 3], 'append')
    assert has_any_callables([1, 2, 3], 'append', 'sort')
    assert not has_any_callables([1, 2, 3], 'foo')
    assert not has_any_callables([1, 2, 3], 'foo', 'bar')
    assert has_any_callables('hello', 'join')
    assert has_any_callables('hello', 'join', 'lower')
    assert not has_any_callables('hello', 'foo')
    assert not has_any_callables('hello', 'foo', 'bar')
    assert not has_any_callables(9, 'foo', 'bar')
    assert not has_any_callables(9.9, 'foo', 'bar')
    assert not has_any_

# Generated at 2022-06-23 18:11:42.714058
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs('1', 'replace') is True
    assert has_attrs('1', 'barf') is False


# Generated at 2022-06-23 18:11:47.249471
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    try:
        from flutils.objutils import is_subclass_of_any
    except:
        print("Could not import is_subclass_of_any; skipping test.")
        return

    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    print('is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) ==',
          is_subclass_of_any(obj.keys(), ValuesView,KeysView,UserList))
    print('# Expected: True')


# Generated at 2022-06-23 18:11:49.626387
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something')


# Generated at 2022-06-23 18:11:59.372152
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    if not has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something'):
        raise AssertionError
    obj = 'hello'
    if has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something'):
        raise AssertionError
    obj = b'hello'
    if has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something'):
        raise AssertionError
    obj = datetime.datetime(2020, 1, 1, 0, 0, 0)
    if has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'something'):
        raise AssertionError



# Generated at 2022-06-23 18:12:11.739662
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values')
    assert has_attrs(dict(a=1,b=2),'get','keys','items','values')
    assert has_attrs(dict(a=1,b=2),'get','keys')
    assert has_attrs(dict(a=1,b=2),'get')
    assert not has_attrs(dict(),'get','keys','items','values','foo')
    assert not has_attrs(dict(a=1,b=2),'get','keys','items','values','foo')
    assert not has_attrs(dict(a=1,b=2),'keys','items','values','foo')
    assert not has_attrs(dict(a=1,b=2),'keys','items','foo')

# Generated at 2022-06-23 18:12:14.750895
# Unit test for function has_any_callables
def test_has_any_callables():
    print(has_any_callables(dict(),'get','keys','items','values','foo'))
    return 'test_has_any_callables passed'

# Generated at 2022-06-23 18:12:22.026449
# Unit test for function is_list_like
def test_is_list_like():
    thelist = ['the', 'list']
    thestring = 'thestring'
    thedict = {'the': 'dict'}
    thetuple = ('the', 'tuple')

    assert is_list_like(thelist) is True
    assert is_list_like(thestring) is False
    assert is_list_like(thedict) is False
    assert is_list_like(thetuple) is True
    assert is_list_like(('the', 'tuple')) is True
    assert is_list_like(['the', 'list']) is True
    assert is_list_like([x for x in thelist]) is True
    assert is_list_like((x for x in thetuple)) is True



# Generated at 2022-06-23 18:12:25.529673
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values',
                         'something')
    assert not has_any_attrs(dict(), 'foo', 'bar', 'baz')


# Generated at 2022-06-23 18:12:36.646730
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    from datetime import (
        datetime,
        time,
        timezone,
        timedelta,
    )
    list_objs = [
        [1, 2, 3],
        reversed([1, 2, 3]),
        sorted('hello')
    ]

# Generated at 2022-06-23 18:12:42.876204
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values')
    assert has_callables(dict(), 'get', 'keys', 'items') is False
    assert has_callables(dict(), 'get', 'keys') is False
    assert has_callables(dict(), 'get') is False


# Generated at 2022-06-23 18:12:49.828755
# Unit test for function has_attrs
def test_has_attrs():
    print("test: has_attrs")
    assert (has_attrs(dict(), 'get', 'keys', 'items', 'values'))
    assert (has_attrs(dict(), 'get', 'keys', 'items', 'values', 'update'))
    #
    assert (has_attrs(list(), 'append') is False)
    assert (has_attrs(list(), 'foo') is False)


# Generated at 2022-06-23 18:12:51.643246
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:12:56.126969
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True

# Generated at 2022-06-23 18:13:00.741471
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any(UserList(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(KeysView(), ValuesView, KeysView, UserList)
    assert is_subclass_of_any(ValuesView(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:13:08.477551
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    assert is_subclass_of_any(dict(), list, set) is True
    assert is_subclass_of_any(map('some_string', str.split), list, set) is True
    assert is_subclass_of_any(str(), list, set, tuple) is True
    assert is_subclass_of_any(list(), list, set, tuple) is True
    assert is_subclass_of_any(set(), list, set, tuple) is True
    assert is_subclass_of_any(tuple(), list, set, tuple) is True


# Generated at 2022-06-23 18:13:18.345882
# Unit test for function is_subclass_of_any

# Generated at 2022-06-23 18:13:23.457801
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2, c=3)
    ret = is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert (ret is True, f"Expected True. Get {ret}")


# Generated at 2022-06-23 18:13:26.662080
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) is True

# Generated at 2022-06-23 18:13:39.199719
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like({'a': 'b', 'c': 'd'}) is False
    assert is_list_like(sorted({'a': 'b', 'c': 'd'})) is True
    assert is_list_like(sorted({'a': 'b', 'c': 'd'})) is True
    assert is_list_like(sorted(set('hello'))) is True
    assert is_list_like(sorted(set('hello'))) is True
    assert is_list_like(sorted(set('hello'))) is True
    assert is_list_like(sorted(set('hello'))) is True
    assert is_

# Generated at 2022-06-23 18:13:50.309485
# Unit test for function has_any_attrs
def test_has_any_attrs():
    class Foo():
        def foo(self):
            pass

        def bar(self):
            pass

    obj = Foo()
    assert has_any_attrs(obj,'foo', 'bar', 'foobar')
    assert has_any_attrs(obj.foo, '__class__')
    assert has_any_attrs(obj.__class__, '__mro__')
    assert has_any_attrs(obj.foo, '__name__')
    assert has_any_attrs(obj.foo, '__module__')
    assert has_any_attrs(obj.foo, '__qualname__')
    assert has_any_attrs(obj.__class__, '__subclasses__')


# Generated at 2022-06-23 18:14:03.119760
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Arrange: Create a dictionary and a tuple
    d = dict(a=1, b=2)
    t = (1, 2, 3)

    # Act
    # Assert:
    assert has_any_attrs(d, 'a', 'b', 'c', 'd')
    assert has_any_attrs(d, 'a', 'b', 'c')
    assert has_any_attrs(d, 'a', 'b')
    assert has_any_attrs(d, 'c', 'd') is False
    assert has_any_attrs(d, 'c')
    assert has_any_attrs(d, 'd') is False
    assert has_any_attrs(t, 'a', 'b', 'c') is False

# Generated at 2022-06-23 18:14:13.617477
# Unit test for function has_any_attrs
def test_has_any_attrs():
    import pytest
    from typing import Dict

    # Dictionary with all attributes
    attrs_dict: Dict[str, bool] = {
        'get': False,
        'items': False,
        'keys': False,
        'values': False,
    }
    # Dictionary with some attributes
    attrs_dict2: Dict[str, bool] = {
        'get': False,
        'items': False,
        'keys': False,
        'values': False,
        'foo': False,
    }

    # Dictionary with no attributes
    attrs_dict3: Dict[str, bool] = {
        'foo': False,
        'bar': False,
        'baz': False,
    }

    # Check for all attrs
    attrs_dict.update({'get': True})


# Generated at 2022-06-23 18:14:26.745825
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    # list-like
    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(True) is False
    assert is_list_like(b'\xf0\xf1\xf2') is False
    assert is_list_like(ChainMap()) is True
    assert is_list_like(Counter()) is True
    assert is_list_like(OrderedDict()) is True
    assert is_list_like(UserDict()) is True
    assert is_list_like(UserString('foo')) is True

# Generated at 2022-06-23 18:14:29.441163
# Unit test for function has_attrs
def test_has_attrs():
    assert (has_attrs(dict(),'get', 'keys', 'items', 'values') is True)
    assert (has_attrs(list(),'get', 'keys', 'items', 'values') is False)


# Generated at 2022-06-23 18:14:36.952637
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from collections import deque
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(deque(), 'get', 'keys', 'items', 'values',
                         'something') is True
    # noinspection SpellCheckingInspection
    assert has_any_attrs(deque(), 'hell', 'keys', 'items', 'values',
                         'something') is False



# Generated at 2022-06-23 18:14:44.238580
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(object(), '__dict__', '__class__') is True
    assert has_attrs(object(), '__dict__', '__class__', '__module__') is True
    assert has_attrs(object(), '__dict__', '__class__', '__mock__') is False
    assert has_attrs(dict(), 'keys', 'values', 'items', 'get') is True
    assert has_attrs(dict(), 'keys', 'values', 'items', 'foo') is False


# Generated at 2022-06-23 18:14:54.734793
# Unit test for function is_list_like
def test_is_list_like():
    # ListLike
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 3])) is True
    assert is_list_like(sorted([1, 2, 3])) is True
    # Not ListLike
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True
    assert is_list_like(None) is False
    assert is_list_like(False) is False
    assert is_list_like(True) is False
    assert is_list_like(1) is False
    assert is_list_like(1.0) is False
    assert is_list_like(dict(a=1, b=2)) is False
    assert is_list_like(int)

# Generated at 2022-06-23 18:14:57.120227
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():

    # Setup
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)

    # Tests
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList) == True

# Generated at 2022-06-23 18:14:59.918756
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'something') is False

# Generated at 2022-06-23 18:15:03.610034
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Typical usage
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'items', 'foo') is True
    assert has_any_attrs(obj, 'foo', 'bar', 'baz') is False
    # Raise TypeError if non-string value given
    with pytest.raises(TypeError):
        assert has_any_attrs(obj, 3)


# Generated at 2022-06-23 18:15:06.952158
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') is True
    assert has_attrs(dict(),'foo','bar') is False


# Generated at 2022-06-23 18:15:18.169157
# Unit test for function is_list_like
def test_is_list_like():
    # No assertion since this function returns a boolean
    print(is_list_like(list(['a', 'b', 'c'])))
    print(is_list_like(list()))
    print(is_list_like(dict()))
    print(is_list_like(set()))
    print(is_list_like(UserList()))
    print(is_list_like(tuple()))
    print(is_list_like(None))
    print(is_list_like(True))
    print(is_list_like(False))
    print(is_list_like(bool()))
    print(is_list_like(bytes()))
    print(is_list_like(bytearray()))
    print(is_list_like(ChainMap()))

# Generated at 2022-06-23 18:15:22.161430
# Unit test for function has_any_callables
def test_has_any_callables():

    assert has_any_callables(dict(),'get','keys','items','values','something') is True
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True



# Generated at 2022-06-23 18:15:30.154547
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert is_list_like(reversed([1, 2, 4]))
    assert is_list_like('hello')
    assert is_list_like(sorted('hello'))
    assert is_list_like(True)
    assert is_list_like(False)
    assert is_list_like(None)
    assert is_list_like('')
    assert is_list_like('hello')
    assert is_list_like(b'hello')
    assert is_list_like(bytes('hello'))
    assert is_list_like(bytearray('hello'))
    assert is_list_like(1)
    assert is_list_like(100.0)
    assert is_list_like(1.1)
    t

# Generated at 2022-06-23 18:15:35.963157
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict()
    assert has_any_attrs(obj,'get','keys','items','values','something')
    assert not has_any_attrs(obj,'foo','bay','car','door','spam')
    assert has_any_attrs(obj, 'keys','values','items','fromkeys')
    assert not has_any_attrs(obj,'bar','foo')


# Generated at 2022-06-23 18:15:47.540796
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test function is_subclass_of_any()"""
    from collections import UserList, ValuesView, KeysView
    obj = dict(a=1, b=2)
    # obj.items is not a UserList
    assert not is_subclass_of_any(obj.items(), UserList)
    # obj.values is a ValuesView
    assert is_subclass_of_any(obj.values(), ValuesView)
    # obj.keys is a KeysView
    assert is_subclass_of_any(obj.keys(), KeysView)
    # obj.keys is a KeysView and UserList
    assert is_subclass_of_any(obj.keys(), KeysView, UserList)
    # obj.keys is not a ValuesView
    assert not is_subclass_of_any(obj.keys(), ValuesView)
    #

# Generated at 2022-06-23 18:15:54.114636
# Unit test for function has_any_attrs
def test_has_any_attrs():
    d = dict(a=1, b=2)
    assert has_any_attrs(d, 'get', 'keys', 'items', 'values', 'something') is True
    assert has_any_attrs(d, 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(d, 'something') is False



# Generated at 2022-06-23 18:16:00.551772
# Unit test for function has_attrs
def test_has_attrs():
  """
  Unit test for function has_attrs
  """
  # Pass
  obj = dict(a=1, b=2)
  attrs = ('get','keys','items','values')
  assert has_attrs(obj,*attrs)
  # Fail
  attrs = ('get','keys','items','values','bar')
  assert not has_attrs(obj,*attrs)


# Generated at 2022-06-23 18:16:02.687231
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values')
    assert not has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-23 18:16:06.066461
# Unit test for function has_attrs
def test_has_attrs():
    obj = {'get': 1, 'keys': 2, 'items': 3, 'values': 4}
    assert has_attrs(obj, 'get', 'keys', 'items', 'values')



# Generated at 2022-06-23 18:16:07.895524
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values') == True


# Generated at 2022-06-23 18:16:17.198698
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
