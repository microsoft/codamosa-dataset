

# Generated at 2022-06-23 18:06:19.449355
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import UserList

    assert has_any_callables(dict(),'get','keys','items','values','something') is True
    assert has_any_callables(UserList(),'__len__','__iter__','__repr__','__init__','something') is True
    assert has_any_callables(UserList(),'__len__','__iter__','__repr__','__init__') is True
    assert has_any_callables(UserList(),'something') is False



# Generated at 2022-06-23 18:06:29.274406
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        Counter,
        ChainMap,
        UserList,
        UserDict,
        UserString,
        deque,
        Iterator,
        KeysView,
        ValuesView
    )
    from decimal import Decimal
    import warnings
    warnings.filterwarnings('ignore', category=FutureWarning)
    test_types = (
        'None',
        'bool',
        'bytes',
        'ChainMap',
        'Counter',
        'OrderedDict',
        'UserDict',
        'UserString',
        'defaultdict',
        'Decimal',
        'dict',
        'float',
        'int',
        'str',
        'UserList',
        'deque',
        'Iterator',
        'KeysView',
        'ValuesView'
    )

# Generated at 2022-06-23 18:06:32.237999
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_callables(dict(), 'get', 'keys', 'items', 'foo') == False

# Generated at 2022-06-23 18:06:38.064115
# Unit test for function has_attrs
def test_has_attrs():
    """Test the function has_attrs.
    """
    obj = dict(a=1, b=2)
    assert has_attrs(obj, 'keys') is True
    assert has_attrs(obj, 'foo') is False
    assert has_attrs(obj, 'foo', 'bar') is False
    obj = [1, 2, 3]
    assert has_attrs(obj, 'append') is True
    assert has_attrs(obj, 'a') is False



# Generated at 2022-06-23 18:06:42.752437
# Unit test for function has_attrs
def test_has_attrs():
    """Test function has_attrs"""
    assert(has_attrs(dict(),'keys', 'values')==True)
    assert (has_attrs(dict(), 'keys', 'values', 'other') == False)

# Unit test function has_callables

# Generated at 2022-06-23 18:06:53.832100
# Unit test for function has_callables
def test_has_callables():
    class A:
        def do_stuff(self):
            pass

    class B:
        pass

    assert has_callables(A(), 'do_stuff')
    assert not has_callables(B(), 'do_stuff')


if __name__ == '__main__':
    from os.path import (
        abspath,
        dirname,
        join as path_join,
        pardir,
    )
    from sys import path
    from unittest import main as _main

    # noinspection PyUnresolvedReferences
    _RUN_DIR = abspath(dirname(__file__))
    _SRC_DIR = abspath(path_join(_RUN_DIR, pardir, pardir))
    path.insert(0, _SRC_DIR)

    __test__ = {}


# Generated at 2022-06-23 18:06:59.301593
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)
    obj = 'hello'
    assert is_subclass_of_any(obj.__class__, str, KeysView, UserList)
    obj = sorted('hello')
    assert is_subclass_of_any(obj.__class__, list, KeysView, UserList)

# Generated at 2022-06-23 18:07:04.402284
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'get','keys','items','values') == True
    assert has_attrs(dict(),'get','keys','items','values', 'something') == False
    assert has_attrs({1:1,2:2,3:3}, 'get','keys','items','values', 'something') == False



# Generated at 2022-06-23 18:07:15.467132
# Unit test for function has_callables

# Generated at 2022-06-23 18:07:20.799051
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """
    Unit test for function is_subclass_of_any
    """
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)


# Generated at 2022-06-23 18:07:32.090629
# Unit test for function is_list_like
def test_is_list_like():
    from collections import ChainMap, Counter, OrderedDict, UserDict, UserList, UserString
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    from collections import (
        deque,
        defaultdict,
    )
    from decimal import Decimal


# Generated at 2022-06-23 18:07:33.661044
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True



# Generated at 2022-06-23 18:07:45.853558
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') is False
    assert has_callables(dict(), 'get', 'keys', 'items', 'values', 'pop') is True
    assert has_callables(list(), 'append', 'clear', 'copy', 'count', 'extend',
                         'index', 'insert', 'pop', 'remove', 'reverse', 'sort') is True
    assert has_callables(list(), 'append', 'clear', 'copy', 'count', 'extend',
                         'index', 'insert', 'pop', 'remove', 'reverse',
                         'sort', 'foo') is False



# Generated at 2022-06-23 18:07:57.834288
# Unit test for function has_callables
def test_has_callables():
    """Unit test for function ``has_callables``."""
    obj = dict(a=1, b=2)
    assert has_callables(obj, 'keys', 'items', 'values') is True
    assert has_callables(obj, 'bar', 'baz') is False
    assert has_callables(obj, 'bar') is False
    assert has_callables(obj, 'get', 'bar') is False
    assert has_callables(obj, 'get', 'keys', 'bar') is False
    assert has_callables(obj, 'get', 'keys', 'bar', 'items') is False
    assert has_callables(obj, 'get') is True
    assert has_callables(obj, 'get', 'bar', 'items') is False

# Generated at 2022-06-23 18:08:01.542690
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    """Test for function is_subclass_of_any"""
    from flutils.objutils import is_subclass_of_any
    from collections import (
        ValuesView,
        KeysView,
        UserList,
    )
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:08:06.936269
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'values', 'items')
    assert not has_attrs(dict(), 'get', 'foo')



# Generated at 2022-06-23 18:08:09.847433
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values',
                         'something')
    assert not has_any_attrs(dict(), 'something')



# Generated at 2022-06-23 18:08:21.389224
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, UserList, UserDict
    import decimal
    import collections
    assert is_subclass_of_any(1, ValuesView, UserList, UserDict) is False
    assert is_subclass_of_any(ValuesView, ValuesView, UserList, UserDict) is True
    assert is_subclass_of_any(
        decimal.Decimal(1),
        decimal.Decimal,
        collections.UserList,
        collections.UserDict
    ) is True
    assert is_subclass_of_any(
        [1, 2, 3],
        ValuesView,
        collections.UserList,
        collections.UserDict
    ) is True



# Generated at 2022-06-23 18:08:29.835619
# Unit test for function is_list_like
def test_is_list_like():
    import types
    import collections

    assert is_list_like([])
    assert is_list_like([1, 2, 3])
    assert is_list_like([1, 2, 3.1459])
    assert is_list_like([1, 2, 'hello', 'world'])
    assert is_list_like((1, 2, 3))
    assert is_list_like(tuple())
    assert is_list_like(tuple([1, 2]))
    assert is_list_like(tuple([1, 2, 3.4]))
    assert is_list_like(tuple([1, 2, 3, 'hello']))
    assert is_list_like(set())
    assert is_list_like(set([1, 2]))

# Generated at 2022-06-23 18:08:36.378497
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict(a=1, b=2)
    assert has_any_callables(obj, 'keys', 'items', 'values', 'nothing') is True
    assert has_any_callables(obj, 'keys', 'items', 'values') is True
    assert has_any_callables(obj, 'keys', 'items', 'values', 'something') is True



# Generated at 2022-06-23 18:08:38.335364
# Unit test for function has_callables
def test_has_callables():
    assert has_callables({}, *{'keys', 'items', 'values', 'get'}) == True



# Generated at 2022-06-23 18:08:40.515621
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:08:49.712803
# Unit test for function has_any_attrs
def test_has_any_attrs():
    dict_attrs = {'get', 'keys', 'items', 'values', 'something'}
    dict_attrs_subset = {'get', 'keys'}
    dict_attrs_not_subset = {'a', 'b', 'c', 'd', 'e'}

    inst = dict()
    assert has_any_attrs(inst, *dict_attrs) is True
    assert has_any_attrs(inst, *dict_attrs_subset) is True
    assert has_any_attrs(inst, *dict_attrs_not_subset) is False



# Generated at 2022-06-23 18:08:57.264073
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import Mapping
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'biz') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'biz', 'baz') == True
    assert has_any_callables(dict(), 'get', 'keys', 'items', 'values', 'foo', 'bar', 'biz', 'baz', 'foo') == True

# Generated at 2022-06-23 18:09:01.808266
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3])
    assert not is_list_like('hello')
    assert is_list_like(sorted('hello'))
    assert is_list_like(reversed([1, 2, 4]))

# Generated at 2022-06-23 18:09:10.517106
# Unit test for function has_callables
def test_has_callables():
    from collections import UserDict
    class Dummy(UserDict):
        @property
        def get(self): pass
        @property
        def keys(self): pass
        @property
        def items(self): pass
        @property
        def values(self): pass
        def _mutable_items(self): pass
    assert has_callables(Dummy(),'get','keys','items','values') is True
    assert has_callables(Dummy({'a':1,'b':2}),'get','keys','items','values') is True
    d = Dummy(a=1, b=2)
    assert has_callables(d,'get','keys','items','values') is True


# Generated at 2022-06-23 18:09:21.022630
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test with has_any_attrs
    testobj = dict()
    assert has_any_attrs(testobj, 'get', 'keys', 'items', 'values') is True
    assert has_any_attrs(testobj, 'get', 'keys', 'items', 'values', 'foo') is True
    assert has_any_attrs(testobj, 'get', 'keys', 'items', 'values', 'foo', 'bar') is True
    testobj = 'hello'
    assert has_any_attrs(testobj, 'get', 'keys', 'items', 'values') is False
    assert has_any_attrs(testobj, 'get', 'keys', 'items', 'values', 'foo') is False

# Generated at 2022-06-23 18:09:30.441354
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True, 'List should be list-like.'
    assert is_list_like(reversed([1, 2, 4])) is True, 'Reversed list should be list-like.'
    assert is_list_like('hello') is False, 'String should not be list-like.'
    assert is_list_like(sorted('hello')) is True, 'Sorted list should be list-like.'

if __name__ == '__main__':
    test_is_list_like()

# Generated at 2022-06-23 18:09:32.904187
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo')



# Generated at 2022-06-23 18:09:36.299479
# Unit test for function has_any_attrs
def test_has_any_attrs():
    """Test function :func:`has_any_attrs`."""
    assert has_any_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') is True


# Generated at 2022-06-23 18:09:44.460159
# Unit test for function has_attrs
def test_has_attrs():
    class _Test:
        def __init__(self):
            self.get = lambda: None
            self.keys = lambda: None
            self.values = lambda: None
            self.items = lambda: None

    obj = _Test()
    for attrs in (('get', 'values', 'items', 'keys', 'something'),
                  ('get', 'values', 'items', 'keys'),
                  ('get', 'values', 'items'),
                  ('get', 'values'),
                  ('get',),):
        assert has_attrs(obj, *attrs) is True


# Generated at 2022-06-23 18:09:48.025176
# Unit test for function is_list_like
def test_is_list_like():
    assert(is_list_like('hello'))  # False
    assert(is_list_like(sorted('hello')))  # True
    assert(is_list_like([1, 2, 3]))  # True
    assert(is_list_like(reversed([1, 2, 4])))  # True

# Generated at 2022-06-23 18:09:57.245032
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
        deque,
        frozenset,
        list,
        set,
        tuple,
    )
    from decimal import Decimal
    import types

    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True

    assert is_list_like(None) is False
    assert is_list_like(True) is False
    assert is_list_like(False) is False
    assert is_list_like({}) is False

# Generated at 2022-06-23 18:10:00.192721
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:10:11.394477
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(), 'get', 'update', 'set')
    assert has_any_callables([], 'append', 'extend')
    assert has_any_callables(set(), 'add', 'update', 'remove', 'discard')
    assert has_any_callables(tuple(), 'index', 'count')
    assert has_any_callables('', 'join', 'replace', 'strip')
    assert has_any_callables(deque(), 'append', 'extend', 'index', 'remove')
    assert has_any_callables(iter('foo'), '__next__')
    assert has_any_callables(frozenset('foo'), 'add', 'remove', 'update')
    assert has_any_callables(map('', ''), '__next__')
    assert has_any

# Generated at 2022-06-23 18:10:22.716353
# Unit test for function is_list_like
def test_is_list_like():

    # List-like objects are **NOT** instances of:
    assert not is_list_like(None)
    assert not is_list_like(True)
    assert not is_list_like(False)
    assert not is_list_like(bytes())
    assert not is_list_like(ChainMap())
    assert not is_list_like(Counter())
    assert not is_list_like(OrderedDict())
    assert not is_list_like(UserDict())
    assert not is_list_like(UserString())
    assert not is_list_like(defaultdict())
    assert not is_list_like(Decimal(0))
    assert not is_list_like(dict())
    assert not is_list_like(float())
    assert not is_list_like(int())
    assert not is_list

# Generated at 2022-06-23 18:10:30.844748
# Unit test for function is_list_like
def test_is_list_like():
    from flutils.objutils import is_list_like
    assert is_list_like(list())
    assert is_list_like([])
    assert is_list_like(tuple())
    assert is_list_like(())
    assert is_list_like(set())
    assert is_list_like(frozenset())
    assert is_list_like(reversed([]))
    assert is_list_like(sorted([]))
    print('Unit test for function is_list_like: OK!')

test_is_list_like()

# Generated at 2022-06-23 18:10:32.786416
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo')


# Generated at 2022-06-23 18:10:36.081615
# Unit test for function has_any_attrs
def test_has_any_attrs():
    obj = dict(a=1, b=2)
    assert has_any_attrs(obj, 'get', 'keys', 'items', 'values', 'foo')


# Generated at 2022-06-23 18:10:39.909093
# Unit test for function is_list_like
def test_is_list_like():
    assert(is_list_like([1, 2, 3]) is True)
    assert(is_list_like(reversed([1, 2, 4])) is True)
    assert(is_list_like('hello') is False)
    assert(is_list_like(sorted('hello')) is True)


# Generated at 2022-06-23 18:10:43.923902
# Unit test for function has_any_attrs
def test_has_any_attrs():
    x=[1,2,3]
    if has_any_attrs(x,'append','pop'):
        print("The object has an attribute which is append or pop")
    else:
        print("The object does not have an attribute which is append or pop")


# Generated at 2022-06-23 18:10:45.807081
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'__getitem__','keys','items','values','something')


# Generated at 2022-06-23 18:10:55.627189
# Unit test for function is_list_like

# Generated at 2022-06-23 18:11:06.472849
# Unit test for function has_attrs
def test_has_attrs():
    from . import AssertThatMixin
    from .faux import (
        FauxDict,
        FauxDictABC,
    )

    class TestHasAttrs(AssertThatMixin):
        """Test for function has_attrs."""

        def test_has_attrs(self):
            """Test function has_attrs."""
            # Test to ensure that a FauxDict inherits the ABC stuff and
            # has the attrs
            d = FauxDict()
            assertThat(d).has_attrs('clear', 'copy', '__contains__',
                                    '__delitem__', '__eq__', '__getitem__',
                                    '__iter__', '__len__', '__ne__',
                                    '__setitem__')
            assertThat(d).has_attrs

# Generated at 2022-06-23 18:11:10.222009
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(reversed([1, 2, 4])) is True
    assert is_list_like('hello') is False
    assert is_list_like(sorted('hello')) is True



# Generated at 2022-06-23 18:11:22.601234
# Unit test for function has_attrs
def test_has_attrs(): # pragma: no cover
    import collections
    import logging
    import flutils.objutils as objutils
    # Test dict
    mydict = dict(a=1, b=2)
    assert objutils.has_attrs(mydict, 'get', 'keys', 'values', 'items')
    assert objutils.has_attrs(mydict, 'get', 'keys', 'items') is False
    assert objutils.has_attrs(mydict, 'get', 'keys', 'items', 'bar') is False
    # Test list
    mylist = [1, 2]
    assert objutils.has_attrs(mylist, 'append', 'count', 'extend', 'index')
    assert objutils.has_attrs(mylist, 'append', 'count', 'extend') is False
    assert objutils.has_

# Generated at 2022-06-23 18:11:32.709527
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    import decimal
    assert is_subclass_of_any(decimal.Decimal, decimal.Decimal) is True
    assert is_subclass_of_any(decimal.Decimal('1.0'), decimal.Decimal) is True
    assert is_subclass_of_any(ChainMap, dict) is True
    assert is_subclass_of_any(Counter, dict) is True
    assert is_subclass_of_any(OrderedDict, dict) is True
    assert is_subclass_of_any(UserDict, dict) is True
    assert is_subclass_of_any(defaultdict, dict) is True

# Generated at 2022-06-23 18:11:35.986864
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    '''Basic test if function'''
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)

# Generated at 2022-06-23 18:11:43.438664
# Unit test for function has_attrs
def test_has_attrs():
    obj1 = dict(a=1, b=2)
    assert has_attrs(obj1, '__class__', '__str__')
    assert has_attrs(obj1, '__class__', '__str__', 'items')
    assert has_attrs(obj1, 'items', '__class__', '__str__')
    assert has_attrs(obj1, 'items', 'values')
    assert has_attrs(obj1, '__class__', 'keys')
    assert not has_attrs(obj1, '__class__', '__str__', 'something')



# Generated at 2022-06-23 18:11:48.376158
# Unit test for function has_any_attrs
def test_has_any_attrs():
    assert has_any_attrs(dict(),'get','keys','items','values','something') == True
    assert has_any_attrs(dict(),'get','keys','items','values') == True
    assert has_any_attrs(dict(),'foo','bar') == False
    assert has_any_attrs(dict(),'foo') == False


# Generated at 2022-06-23 18:11:58.819016
# Unit test for function is_list_like
def test_is_list_like():
    from random import random
    from pytest import raises
    from flutils.objutils import is_list_like
    from collections import (
        UserList,
        deque,
        Iterator,
        ValuesView,
        KeysView,
        ChainMap,
        OrderedDict,
        UserDict,
        UserString,
        defaultdict,
    )
    from decimal import Decimal

    # Test type(None)
    assert is_list_like(None) is False

    # Test type(bool)
    assert is_list_like(True) is False
    assert is_list_like(False) is False

    # Test type(bytes)
    assert is_list_like(bytes()) is False

    # Test type(ChainMap)
    assert is_list_like(ChainMap()) is False

    # Test type

# Generated at 2022-06-23 18:12:05.340952
# Unit test for function has_any_attrs
def test_has_any_attrs():
    from flutils import objutils
    test_cases = (
        {
            "args": (dict(), 'get', 'keys', 'values', 'items'),
            "out": True,
        }
    )
    for case in test_cases:
        args = case['args']
        out = case['out']
        assert objutils.has_any_attrs(*args) == out



# Generated at 2022-06-23 18:12:12.024082
# Unit test for function has_callables
def test_has_callables():
    from flutils.objutils import has_callables
    from collections import UserList
    assert has_callables(UserList(), 'copy') is True
    assert has_callables(UserList(), 'copy', 'append') is True
    assert has_callables(UserList(), 'copy', 'foo') is False
    assert has_callables(UserList(), 'foo', 'bar') is False



# Generated at 2022-06-23 18:12:18.677866
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj.values(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(obj, ValuesView, KeysView, UserList) is False


# Generated at 2022-06-23 18:12:28.196670
# Unit test for function has_attrs
def test_has_attrs():
    # Create a test object
    class TestObject:

        def __init__(self, a=1, b=2, **kwargs):
            self.a = a
            self.b = b
            for k, v in kwargs.items():
                setattr(self, k, v)

    test_obj = TestObject()
    assert has_attrs(test_obj, 'a') is True
    assert has_attrs(test_obj, 'a', 'b') is True
    assert has_attrs(test_obj, 'a', 'b', 'c') is False
    assert has_attrs(test_obj, 'c') is False
    assert has_attrs(test_obj, 'a', 'b', 'get_dummy_func') is False



# Generated at 2022-06-23 18:12:30.835012
# Unit test for function has_any_callables
def test_has_any_callables():
    obj = dict()
    assert has_any_callables(obj,'get','keys','items','values','foo') == True



# Generated at 2022-06-23 18:12:37.219351
# Unit test for function has_any_callables
def test_has_any_callables():
    import pytest
    assert has_any_callables(dict(),'get','keys','items','values','foo')
    assert has_any_callables(dict(),'foo','bar','baz') is False
    assert has_any_callables(object(),'not_get','keys','items','values','foo') is False

    with pytest.raises(TypeError):
        has_any_callables(None)

    with pytest.raises(TypeError):
        has_any_callables(1)

    with pytest.raises(TypeError):
        has_any_callables(True)

    with pytest.raises(TypeError):
        has_any_callables('hello')

    with pytest.raises(TypeError):
        has_any_callables([1, 2, 3])


# Generated at 2022-06-23 18:12:38.351256
# Unit test for function has_attrs
def test_has_attrs():
    """
    Unit test for function has_attrs
    """
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 18:12:42.114243
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:12:47.347667
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') == True
    assert has_any_callables(dict(),'foo','bar') == False


# Generated at 2022-06-23 18:12:56.841715
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    assert is_list_like(['a']) is True
    assert is_list_like(('a', 'b')) is True
    assert is_list_like({'a', 'b'}) is True
    assert is_list_like(frozenset(('a', 'b'))) is True
    assert is_list_like(deque(('a', 'b'))) is True
    assert is_list_like((x for x in range(1, 10))) is True
    assert is_list_like(iter(('a', 'b'))) is True

# Generated at 2022-06-23 18:13:02.792446
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    a = dict(a=1, b=2)
    assert is_subclass_of_any(a.keys(), ValuesView, KeysView, UserList) is True
    assert is_subclass_of_any(a.keys(), ValuesView, KeysView, dict) is False
    assert is_subclass_of_any(a, ValuesView, KeysView, UserList) is False



# Generated at 2022-06-23 18:13:05.578313
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(),'clear','fromkeys','get','items','keys','pop') is True
    assert has_attrs(dict(),'foo','bar','baz') is False


# Generated at 2022-06-23 18:13:10.056173
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    if is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList):
        print('test passed')


# Generated at 2022-06-23 18:13:14.694277
# Unit test for function has_callables
def test_has_callables():
    assert has_callables([], 'append')
    assert has_callables(dict(), 'keys', 'items', 'values')
    assert has_callables(dict, 'fromkeys')
    assert not has_callables([], 'foobar')
    assert not has_callables(dict(), 'foobar')

# Generated at 2022-06-23 18:13:17.169530
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True
    #assert has_callables(dict(),'get','keys','foo','values') is False


# Generated at 2022-06-23 18:13:26.764767
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(list(), 'append')
    assert has_attrs(dict(), 'keys', 'items')
    assert has_attrs(list, 'append', 'clear')
    assert has_attrs(1+2j, 'conjugate')
    assert has_attrs("hello", 'count', 'capitalize')
    assert has_attrs({}, 'get', 'update')
    assert has_attrs(tuple(), 'count', 'index')
    assert has_attrs(Exception, 'args')
    assert has_attrs(KeyError(), 'args', 'with_traceback')
    assert has_attrs(Exception, 'args')
    assert has_attrs(set(), 'add', 'clear')
    assert has_attrs(frozenset(), 'add', 'clear')
    assert has_attrs

# Generated at 2022-06-23 18:13:39.187629
# Unit test for function has_callables
def test_has_callables():
    class _Cls:
        @staticmethod
        def foo():
            return

        get = foo
        keys = foo
        items = foo
        values = foo

    assert has_callables(_Cls(), 'get') is True
    assert has_callables(_Cls(), 'keys') is True
    assert has_callables(_Cls(), 'items') is True
    assert has_callables(_Cls(), 'values') is True

    class _Cls1:
        @staticmethod
        def foo():
            return

        get = foo
        keys = foo
        values = foo

    assert has_callables(_Cls1(), 'get') is True
    assert has_callables(_Cls1(), 'keys') is True
    assert has_callables(_Cls1(), 'values') is True
    # Keys should be False because there

# Generated at 2022-06-23 18:13:43.212172
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    assert is_subclass_of_any(dict().keys(), ValuesView, KeysView, UserList) is True

# Generated at 2022-06-23 18:13:47.343599
# Unit test for function has_any_callables
def test_has_any_callables():
    assert has_any_callables(dict(),'get','keys','items','values','foo') is True
    assert has_any_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:13:52.673685
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList

    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)

# Generated at 2022-06-23 18:13:57.751490
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from flutils.objutils import is_subclass_of_any
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert(is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList))

# Generated at 2022-06-23 18:14:00.687267
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') == True
    assert has_callables(dict(),'foo','bar') == False


# Generated at 2022-06-23 18:14:07.757486
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    l = list(range(10))
    assert is_subclass_of_any(l, ValuesView, KeysView, UserList) == True
    assert is_subclass_of_any(l, ValuesView, KeysView) == False
    assert is_subclass_of_any(l, ValuesView, UserList) == True
    assert is_subclass_of_any(l, ValuesView) == False


# Generated at 2022-06-23 18:14:16.838165
# Unit test for function has_any_callables
def test_has_any_callables():
    # tabular data container
    obj = {'a':1, 'b':2}
    assert has_any_callables(obj,'get','keys','items','values','foo') == True
    # tabular data container
    import numpy as np
    obj = np.array([1, 2, 3])
    assert has_any_callables(obj,'get','keys','items','values','foo') == True
    # text container
    obj = 'hello'
    assert has_any_callables(obj,'get','keys','items','values','foo') == False
    # binary data container
    obj = b'\xaa\x5f\xcc'
    assert has_any_callables(obj,'get','keys','items','values','foo') == False
    # set
    obj = frozenset('hello')
    assert has_

# Generated at 2022-06-23 18:14:29.170132
# Unit test for function has_attrs
def test_has_attrs():
    # Test has_attrs
    from collections import UserList
    assert has_attrs(list(), 'append', 'clear') is True
    assert has_attrs(list(), 'foo', 'bar') is False
    assert has_attrs(UserList, 'append', 'clear') is True
    assert has_attrs(UserList, 'foo', 'bar') is False
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'bar') is False
    assert has_attrs(str(), '__str__') is True
    assert has_attrs(str(), 'foo') is False
    assert has_attrs(bytes(), '__bytes__') is True
    assert has_attrs(bytes(), 'foo') is False
    assert has_

# Generated at 2022-06-23 18:14:30.876735
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),'get','keys','items','values') is True


# Generated at 2022-06-23 18:14:41.802753
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([1,2,3])
    assert is_list_like(reversed([1,2,4]))
    assert is_list_like([])
    assert is_list_like('')
    assert is_list_like(sorted('hello'))
    assert is_list_like(tuple())
    assert is_list_like(set())
    assert is_list_like(frozenset())
    assert is_list_like({'a': 'a', 'b': 'b'}.items())
    assert is_list_like({'a': 'a', 'b': 'b'}.keys())
    assert is_list_like({'a': 'a', 'b': 'b'}.values())
    assert is_list_like(deque())
    assert is_list_like

# Generated at 2022-06-23 18:14:51.134937
# Unit test for function has_any_attrs
def test_has_any_attrs():
    # Test 1
    d = { }
    assert has_any_attrs(d, 'get', 'keys', 'items', 'values', 'something')
    # Test 2
    s = "hello world"
    assert has_any_attrs(s, 'upper', 'lower', 'remove')
    # Test 3
    assert not has_any_attrs("hello world", 'upper', 'lower', 'remove')
    # Test 4
    assert has_any_attrs(1, 'to_bytes', 'from_bytes')
    # Test 5
    assert not has_any_attrs("something", '__iter__')


# Generated at 2022-06-23 18:15:00.811664
# Unit test for function is_list_like
def test_is_list_like():
    from collections import (
        ChainMap,
        Counter,
        OrderedDict,
        UserDict,
        UserList,
        UserString,
        defaultdict,
    )
    from decimal import Decimal
    assert is_list_like([]) is True
    assert is_list_like({}) is False
    assert is_list_like(set()) is True
    assert is_list_like(reversed([])) is True
    assert is_list_like(None) is False
    assert is_list_like(ChainMap()) is False
    assert is_list_like(Counter()) is False
    assert is_list_like(OrderedDict()) is False
    assert is_list_like(UserDict()) is False
    assert is_list_like(UserList()) is True
    assert is_list_like

# Generated at 2022-06-23 18:15:06.547352
# Unit test for function is_list_like
def test_is_list_like():
    assert is_list_like([0, 0, 1])
    assert is_list_like(reversed([0, 0, 1]))
    assert is_list_like('hello')
    assert is_list_like(sorted('hello'))
    assert not is_list_like(None)
    assert not is_list_like(True)
    assert not is_list_like(False)
    assert not is_list_like(1)
    assert not is_list_like(-1)
    assert not is_list_like(1.1)
    assert not is_list_like(-1.1)
    assert not is_list_like(1+1j)
    assert not is_list_like(-1+1j)
    assert not is_list_like(1-1j)
    assert not is_

# Generated at 2022-06-23 18:15:11.661230
# Unit test for function is_list_like

# Generated at 2022-06-23 18:15:17.694577
# Unit test for function has_attrs
def test_has_attrs():
    from collections import Counter
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(Counter(), 'get', 'keys', 'items', 'values') is True
    assert has_attrs(dict(), 'foo', 'bar', 'baz', 'qux') is False
    assert has_attrs(Counter(), 'foo', 'bar', 'baz', 'qux') is False


# Generated at 2022-06-23 18:15:28.117190
# Unit test for function has_attrs
def test_has_attrs():
    from flutils.objutils import has_attrs
    from collections import (
        UserList,
        deque,
    )
    from collections.abc import (
        Iterator,
        KeysView,
        ValuesView,
    )
    d = dict()
    l = list()
    o = object()

    assert has_attrs(l, '__len__', '__iter__') is True
    assert has_attrs(l, '__len__', '__iter__', '__getitem__') is True
    assert has_attrs(l, 'foo', 'bar') is False
    assert has_attrs(d, '__len__', '__iter__', '__getitem__') is True

# Generated at 2022-06-23 18:15:38.151104
# Unit test for function has_callables
def test_has_callables():
    from collections.abc import Iterator, ValuesView, KeysView
    from collections import deque, UserList
    obj = range(10)
    assert has_callables(obj, '__iter__', '__next__') is True
    obj = reversed(range(10))
    assert has_callables(obj, '__iter__', '__next__') is True
    obj = iter(range(10))
    assert has_callables(obj, '__iter__', '__next__') is True
    obj = ValuesView(dict(a=1, b=2).values())
    assert has_callables(obj, '__iter__', '__next__') is True
    obj = KeysView(dict(a=1, b=2).keys())

# Generated at 2022-06-23 18:15:44.413539
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import (
        ValuesView,
        KeysView,
        UserList
    )
    obj = dict(a=1, b=2, c=3)
    ret = is_subclass_of_any(obj.keys(),ValuesView,KeysView,UserList)
    assert ret is True


if __name__ == '__main__':
    test_is_subclass_of_any()

# Generated at 2022-06-23 18:15:46.186182
# Unit test for function has_callables
def test_has_callables():
    assert has_callables(dict(),
                         'clear', 'keys', 'items','values') == True


# Generated at 2022-06-23 18:15:49.303964
# Unit test for function is_subclass_of_any
def test_is_subclass_of_any():
    from collections import ValuesView, KeysView, UserList
    obj = dict(a=1, b=2)
    assert is_subclass_of_any(obj.keys(), ValuesView, KeysView, UserList)



# Generated at 2022-06-23 18:15:50.612112
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs("hellos", "capitalize", "count", "isdigit", "split")


# Generated at 2022-06-23 18:15:52.071349
# Unit test for function has_any_callables
def test_has_any_callables():
    from collections import defaultdict
    assert has_any_callables(dict(),'get','keys','items','values','value') is True
    d = defaultdict(int)
    assert has_any_callables(d,'get','keys','items','values','value') is True


# Generated at 2022-06-23 18:16:02.635387
# Unit test for function has_attrs
def test_has_attrs():
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values') == True
    assert has_attrs(dict(), 'get', 'keys', 'items', 'values', 'foo') == False
    assert has_attrs(dict(), 'keys', 'items', 'values') == False
    assert has_attrs(dict(), 'get', 'items', 'values') == False
    assert has_attrs(dict(), 'get', 'keys', 'values') == False
    assert has_attrs(dict(), 'get', 'keys', 'items') == False
    assert has_attrs(dict(), 'get') == False
    assert has_attrs(dict(), 'keys') == False
    assert has_attrs(dict(), 'items') == False
    assert has_attrs(dict(), 'values') == False

# Unit test

# Generated at 2022-06-23 18:16:13.600870
# Unit test for function is_list_like
def test_is_list_like():
    # Positive tests
    assert is_list_like([]) is True
    assert is_list_like([1, 2, 3]) is True
    assert is_list_like(()) is True
    assert is_list_like((1, 2, 3)) is True
    assert is_list_like({}) is True
    assert is_list_like({1, 2, 3}) is True
    assert is_list_like(frozenset()) is True
    assert is_list_like(frozenset([1, 2, 3])) is True
    assert is_list_like(deque()) is True
    assert is_list_like(deque([1, 2, 3])) is True
    assert is_list_like(UserList()) is True