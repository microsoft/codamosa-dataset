

# Generated at 2022-06-22 08:49:55.262823
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    instance = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert instance



# Generated at 2022-06-22 08:50:00.959099
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = r'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    if ie.working():
        ie.extract(url)
    else:
        print('UDNEmbedIE: not working')

# Generated at 2022-06-22 08:50:04.042434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()

# Generated at 2022-06-22 08:50:12.732801
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    pattern = re.compile(ie._VALID_URL)
    matched = pattern.match('//video.udn.com/embed/news/300040')
    assert matched
    matched = pattern.match('https://video.udn.com/embed/news/300040')
    assert matched
    matched = pattern.match('http://video.udn.com/embed/news/300040')
    assert matched
    matched = pattern.match('https://video.udn.com/play/news/303776')
    assert matched

# Generated at 2022-06-22 08:50:20.737945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    url = r'http://video.udn.com/embed/news/300040'

    # Check extracting video_id
    match_video_id = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert re.match(match_video_id, url).group('id') == '300040'

    # Check the _VALID_URL
    match_valid_url = UDNEmbedIE._VALID_URL
    assert re.match(match_valid_url, url)

    # Check the constructor
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie

# Generated at 2022-06-22 08:50:24.321750
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    assert udnEmbedIE is not None
    assert udnEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:50:29.727126
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

    ie = UDNEmbedIE(ie)
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:50:31.539266
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-22 08:50:37.715994
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE(downloader=None)
    # test constructor when url is not valid
    assert udn.suitable('https://video.udn.com/invalid_url') == False
    # test constructor when url is valid
    assert udn.suitable('https://video.udn.com/embed/news/300040') == True
    assert udn.suitable('http://video.udn.com/embed/news/300040') == True
    # test constructor when url has wrong protocol
    assert udn.suitable('ftp://video.udn.com/embed/news/300040') == False
    # test constructor when url has wrong domain
    assert udn.suitable('http://video_udn.com/embed/news/300040') == False
    # test constructor when url has wrong subdomain

# Generated at 2022-06-22 08:50:42.901719
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor of class UDNEmbedIE
    # This is the test case for the bug reported in https://github.com/rg3/youtube-dl/pull/13429
    class TestUDNEmbedIE(UDNEmbedIE):
        IE_DESC = 'UDN Videos'
        _VALID_URL = 'http://video.udn.com/news/1'
        _TESTS = [{
            'url': 'http://video.udn.com/news/1',
            'only_matching': True,
        }]

    ie = TestUDNEmbedIE()
    print(ie.IE_DESC)
    for test in ie._TESTS:
        print(ie._real_extract(test['url']))

# Generated at 2022-06-22 08:50:59.588444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:09.418584
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._downloader is not None
    assert ie.ie_key() == 'UDNEmbed'
    assert ie._WORKING is True
    assert ie.get_host() == 'video.udn.com'
    # Test if IE is working
    assert ie.working() == True

    # Test for match function

# Generated at 2022-06-22 08:51:17.140272
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie._generic_extract(None) is None


# Generated at 2022-06-22 08:51:19.124713
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed


# Generated at 2022-06-22 08:51:22.424965
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_html import get_testdata
    UDNEmbedIE.test(
        get_testdata('testing_udn_embed.html'),
        'http://video.udn.com/embed/news/300040'
    )

# Generated at 2022-06-22 08:51:25.891178
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert(IE.ie_key() == 'UDNEmbed')
    assert(IE.ie_desc() == '聯合影音')


# Generated at 2022-06-22 08:51:36.162009
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import ExtractorError
    from .common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor(UDNEmbedIE.ie_key())
    UDNEmbedIE(ie, UDNEmbedIE.ie_key())

    for url, ie_key in [
            ('http://video.udn.com/embed/news/300040', UDNEmbedIE.ie_key()),
            ('https://video.udn.com/play/news/303776', UDNEmbedIE.ie_key()),
            ('https://vimeo.com/ondemand/laravel', 'Vimeo'),
            ('https://youtu.be/xFgIhi--mfo', 'Youtube'),
    ]:
        assert ie.suitable(url) == ie_key

# Generated at 2022-06-22 08:51:48.247432
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Enter function test_UDNEmbedIE()")
    print("")
    print("Now test whether instantiation of class UDNEmbedIE succeeds")
    print("")
    UDNEmbedIE()
    print("Instantiation of class UDNEmbedIE succeeds")
    print("")
    print("Now test for correct operation of class UDNEmbedIE")
    print("")
    input_url = 'http://video.udn.com/embed/news/300040'
    print("")
    print("input_url = %s" % input_url)
    print("")
    my_UDNEmbedIE = UDNEmbedIE()
    my_result = my_UDNEmbedIE.extract(input_url)
    print("")

# Generated at 2022-06-22 08:51:54.915833
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None
    assert type(ie) is UDNEmbedIE
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:51:58.995593
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == r'https?:' + UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE().IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:52:36.042501
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('')

    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('http://video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-22 08:52:41.514346
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert isinstance(ie._TESTS, list)

# Generated at 2022-06-22 08:52:52.627999
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE._TESTS[0]['url'] = url
    UDNEmbedIE._TESTS[0]['expected_warnings'] = []
    UDNEmbedIE._TESTS[1]['url'] = url
    UDNEmbedIE._TESTS[1]['only_matching'] = False
    ie = UDNEmbedIE()
    # Set _real_initialize to cover the initialization of UDNEmbedIE
    ie._real_initialize()
    return ie.suitable(url)

# And this is for class UDNEmbedIE itself
test_UDNEmbedIE()

# Generated at 2022-06-22 08:53:01.016186
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _UDNEmbedIE = UDNEmbedIE(InfoExtractor())
    assert _UDNEmbedIE._VALID_URL == _UDNEmbedIE.UDNEmbedIE._VALID_URL
    assert _UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == _UDNEmbedIE.UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert _UDNEmbedIE._TESTS == _UDNEmbedIE.UDNEmbedIE._TESTS
    assert _UDNEmbedIE.IE_DESC == _UDNEmbedIE.UDNEmbedIE.IE_DESC

# Generated at 2022-06-22 08:53:07.137971
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == '__main__':
        url = 'https://video.udn.com/play/news/303776'
        url = url[0:20] + '//' + url[20:]
        extractor = UDNEmbedIE()
        result = extractor._real_extract(url)
        print(result)

# Generated at 2022-06-22 08:53:09.283371
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert True

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:53:12.879630
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor of class UDNEmbedIE
    ie = UDNEmbedIE()
    # Test if the object is an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)
    return


# Generated at 2022-06-22 08:53:16.193389
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except NameError:
        assert False, "Constructor of class UDNEmbedIE has problem"


# Generated at 2022-06-22 08:53:18.443737
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url=url)

# Generated at 2022-06-22 08:53:28.756875
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Youtube, not extracted
    udn_embed_ie_1=UDNEmbedIE()
    res_1=udn_embed_ie_1._real_extract('http://video.udn.com/embed/news/300040')
    assert (res_1=={
        '_type': 'url',
        'url': 'https://www.youtube.com/watch?v=LyQ2zxfwf-k',
        'ie_key': 'Youtube'
    })

    # MP4, extracted
    udn_embed_ie_2=UDNEmbedIE()
    res_2=udn_embed_ie_2._real_extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:54:12.181907
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert re.compile(ie._PROTOCOL_RELATIVE_VALID_URL).match('//video.udn.com/embed/news/300040') is not None
    assert re.compile(ie._VALID_URL).match('https://video.udn.com/embed/news/300040') is not None
    # If the test fails, please check all the parameters below
    # and fix them if necessary.
    assert len(ie._TESTS) == 3
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:54:18.446489
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-22 08:54:28.221014
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:54:32.999783
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    m_UDNEmbedIE = UDNEmbedIE('UDNEmbedIE')
    assert m_UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:54:35.531203
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    cases = [
        [r'//video\.udn\.com/embed/news/300040', 'UDNEmbedIE'],
        [r'//video\.udn\.com/news/303776', 'UDNEmbedIE'],
    ]
    for case in cases:
        assert case[1] == ie_key_map[re.match(ie_regex, case[0]).group('ie_key')]

# Generated at 2022-06-22 08:54:41.068575
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'


# Test for _real_extract of class UDNEmbedIE

# Generated at 2022-06-22 08:54:50.490044
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbed = UDNEmbedIE()
    print(udnEmbed)
    assert udnEmbed.IE_DESC == '聯合影音'
    assert udnEmbed._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbed._VALID_URL == r'https?:' + udnEmbed._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:54:59.451023
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:55:10.732801
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie=UDNEmbedIE()
    assert ie.IE_NAME == "UDNEmbedIE"
    assert ie.IE_DESC == "聯合影音"
    assert ie._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)"
    assert ie._TESTS[0]["url"] == "http://video.udn.com/embed/news/300040"
    assert ie._TESTS[0]["info_dict"]["id"] == "300040"
    assert ie._TESTS[0]["info_dict"]["title"] == "生物老師男變女 全校挺\"做自己\""
    assert ie

# Generated at 2022-06-22 08:55:16.166947
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    test_class = UDNEmbedIE()
    assert test_class._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_class._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_class._TESTS

# Generated at 2022-06-22 08:56:42.414897
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    InfoExtractor.UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/embed/news/(?P<id>\d+)'
    ie = InfoExtractor.UDNEmbedIE._UDNEmbedIE(InfoExtractor.UDNEmbedIE)
    # Invalid case
    assert ie is None
    InfoExtractor.UDNEmbedIE._VALID_URL = r'https?:' + InfoExtractor.UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    ie = InfoExtractor.UDNEmbedIE._UDNEmbedIE(InfoExtractor.UDNEmbedIE)
    # Valid case
    assert ie != None
    # Test some class functions, just for coverage

# Generated at 2022-06-22 08:56:43.830254
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn != None

# Generated at 2022-06-22 08:56:50.210285
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE.get_info_extractor(url)
    if isinstance(ie, UDNEmbedIE):
        print('[PASS] Constructor of class UDNEmbedIE: get_info_extractor()')
    else:
        print('[FAIL] Constructor of class UDNEmbedIE: get_info_extractor()')


# Generated at 2022-06-22 08:57:00.079738
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:57:04.791152
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = INFO_EXTRACTOR_MAP.get('https://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:57:07.678055
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert_equal(ie._VALID_URL, r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-22 08:57:08.917034
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.IE_NAME == 'udn'

# Generated at 2022-06-22 08:57:16.809047
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    # Test constructor of class UDNEmbedIE
    assert(udne.IE_DESC == '聯合影音')
    assert(udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udne._VALID_URL == r'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL)
    # unit test for _real_extract
    # {
    #   'url': 'http://video.udn.com/embed/news/300040',
    #   'info_dict': {
    #       'id': '300040',
    #       'ext': 'mp4',

# Generated at 2022-06-22 08:57:17.827020
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None)

# Generated at 2022-06-22 08:57:23.202890
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
 
    # Test case_1
    url = 'http://video.udn.com/embed/news/300040'
    info = ie._real_extract(url)
    assert info['id'] == '300040'
    assert info['title'] == '生物老師男變女 全校挺"做自己"'
    assert len(info['formats']) == 4
    assert info['thumbnail'] is not None

    # Test case_2
    url = 'http://video.udn.com/embed/news/id_not_exist'
    info = ie._real_extract(url)
    assert info is None

if __name__ == '__main__':
    test_UDNEmbedIE