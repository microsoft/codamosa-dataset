

# Generated at 2022-06-22 08:49:58.605288
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Simple test for UDNEmbedIE.
    """
    _url = 'http://video.udn.com/embed/news/300040'
    _video_id = dict(UDNEmbedIE._VALID_URL_RE.match(_url).groupdict())['id']
    _info = dict(UDNEmbedIE._TESTS[0]['info_dict'])

    ie = UDNEmbedIE(_url)
    info = ie.extract()

    assert info['id'] == _video_id
    assert info['formats']
    assert info['title'] == _info['title']
    assert info['thumbnail']

# Generated at 2022-06-22 08:50:03.801755
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_template = 'https://video.udn.com/embed/news/%s?autoplay=1'
    video_ids = (
        '300040',
        '300041',
        '300042'
    )
    for video_id in video_ids:
        url = url_template % video_id
        UDNEmbedIE().url_result(url)

# Generated at 2022-06-22 08:50:15.483966
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_youtube_dl import YoutubeDL
    from .test_utils import make_mock_extractor

    UDNEmbedIE.PROTOCOL_RELATIVE_VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    UDNEmbedIE.valid_urls = UDNEmbedIE._valid_urls
    UDNEmbedIE.tests = UDNEmbedIE._tests

    ydl = YoutubeDL(dict(udn_embed=make_mock_extractor()))
    ydl.add_info_extractor(UDNEmbedIE)
    UDNEmbedIE.__dict__['_real_extract'] = UDNEmbedIE._real_extract

    # Test valid_urls

# Generated at 2022-06-22 08:50:24.762649
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(isinstance(ie,UDNEmbedIE))
    assert(isinstance(ie,InfoExtractor))
    assert(ie.IE_DESC == "聯合影音")
    assert(re.match(ie._PROTOCOL_RELATIVE_VALID_URL, "//video.udn.com/embed/news/300040") is not None)
    assert(re.match(ie._VALID_URL, "https://video.udn.com/embed/news/300040") is not None)
    assert(ie._TESTS[0]["url"] == "http://video.udn.com/embed/news/300040")
    assert(ie._TESTS[1]["only_matching"] == True)

# Generated at 2022-06-22 08:50:29.247541
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    ieid = udne.ie_key()
    assert ieid == "UDNEmbed"
    # assert udne.ie_key() == "Youtube"

# Generated at 2022-06-22 08:50:32.238556
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # FIXME test fails with python -m pytest test.py
    import pytest
    u = UDNEmbedIE()
    with pytest.raises(AttributeError):
        u.ie_key()

# Generated at 2022-06-22 08:50:36.169669
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None)._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:50:38.517256
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert(IE.IE_DESC == '聯合影音')

# Generated at 2022-06-22 08:50:43.736200
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS != []


# Generated at 2022-06-22 08:50:47.599721
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ext = UDNEmbedIE(0)
    ext.extract(url, True)

# Generated at 2022-06-22 08:51:06.958374
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_utils import *
    assert isinstance(UDNEmbedIE(), InfoExtractor)
    assert isinstance(UDNEmbedIE(UDNEmbedIE.IE_DESC), InfoExtractor)
    assert isinstance(UDNEmbedIE(UDNEmbedIE.IE_DESC, UDNEmbedIE._VALID_URL), InfoExtractor)


# Generated at 2022-06-22 08:51:13.402758
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    assert inst._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst._VALID_URL == r'https?:' + inst._PROTOCOL_RELATIVE_VALID_URL
    assert inst._TESTS



# Generated at 2022-06-22 08:51:17.658180
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:51:18.738580
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:29.905585
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import sys
    import os
    import re
    from youtube_dl.utils import make_HTTPS_handler
    import urllib.request, urllib.parse, urllib.error
    from bs4 import BeautifulSoup

    class TestUDNEmbedIE(unittest.TestCase):
        def setUp(self):
            self.udn = UDNEmbedIE()

        def test_download_webpage(self):
            class FakeOpener(object):
                def __init__(self, geturl, headers):
                    pass
                def open(self, url, data=None, timeout=None):
                    return self
                # read() will be called

# Generated at 2022-06-22 08:51:33.713303
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test = UDNEmbedIE()
    match_id = unit_test._match_id('//video.udn.com/embed/news/300040')
    assert match_id == '300040'



# Generated at 2022-06-22 08:51:40.802384
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    ret = ie._match_id(url)
    assert ret == '300040'

    url = 'https://video.udn.com/embed/news/300040'
    ret = ie._match_id(url)
    assert ret == '300040'

    url = 'https://video.udn.com/play/news/303776'
    ret = ie._match_id(url)
    assert ret == '303776'

    url = 'http://video.udn.com/play/news/303776'
    ret = ie._match_id(url)
    assert ret == '303776'


if __name__ == '__main__':
    test_UDNE

# Generated at 2022-06-22 08:51:43.201170
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_NAME == 'udn')
    assert(ie.IE_DESC == '聯合影音')


# Generated at 2022-06-22 08:51:54.133445
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # create a instance of class UDNEmbedIE
    udn_embed_ie = UDNEmbedIE()

    assert( isinstance(udn_embed_ie, InfoExtractor) )

    assert(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

    assert(udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL)

    assert(udn_embed_ie.IE_DESC == '聯合影音')


# Generated at 2022-06-22 08:51:55.410519
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    print(IE._PROTOCOL_RELATIVE_VALID_URL)



# Generated at 2022-06-22 08:52:12.823542
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()

    assert( len(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL) == 79 )
    assert( len(udn_embed_ie._VALID_URL) == 83 )
    assert( len(udn_embed_ie._TESTS) == 3 )

# Generated at 2022-06-22 08:52:18.879038
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert('UDNEmbedIE' == UDNEmbedIE.ie_key())
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')

# Generated at 2022-06-22 08:52:25.660603
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn:embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'


test_UDNEmbedIE()

# Generated at 2022-06-22 08:52:28.905343
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_utils import test_constructor_1
    test_constructor_1('UDN', '//video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:52:39.367172
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    assert u.name == "UDNEmbedIE"
    assert u.ie_key() == "UDNEmbed"
    assert u.ie_desc() == "聯合影音"
    assert u.valid_url("http://video.udn.com/embed/news/300040")
    assert u.valid_url("https://video.udn.com/embed/news/300040")
    assert not u.valid_url("http://video.udn.com/play/news/300040")
    assert u.valid_url("https://video.udn.com/play/news/300040",
                           "https://video.udn.com/play/news/303776")

# Generated at 2022-06-22 08:52:44.292564
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'



# Generated at 2022-06-22 08:52:55.585776
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse
    from ..compat import compat_http_client
    import urllib

    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    dict_data = {'test': 'test data'}
    #test _download_webpage
    data = ie.download_webpage(url, 'test_json', data=json.dumps(dict_data), headers={
        'Content-Type': 'application/json'
    })
    assert dict_data == data
    #test _download_json

# Generated at 2022-06-22 08:52:58.548431
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
        url = 'https://video.udn.com/embed/news/300040'
        UDNEmbedIE()._real_initialize()
        UDNEmbedIE().url_result(url, 'UDNEmbed')

# Generated at 2022-06-22 08:53:04.710892
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:53:06.735495
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_scraper = UDNEmbedIE()
    assert(udn_scraper)

# Generated at 2022-06-22 08:53:36.806433
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:53:40.605088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-22 08:53:46.417576
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-22 08:53:50.211584
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['expected_warnings'] == ['Failed to parse JSON Expecting value']

# Generated at 2022-06-22 08:53:51.929469
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj


# Generated at 2022-06-22 08:53:56.382907
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, 'UDNEmbedIE.IE_DESC'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)', 'UDNEmbedIE.IE_DESC'
    #print("UDNEmbedIE Validation success")

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:54:01.073984
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    assert re.search(UDNEmbedIE._VALID_URL, url) is not None
    obj = UDNEmbedIE()
    return obj.extract(url)

# Generated at 2022-06-22 08:54:08.968310
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    newIE = UDNEmbedIE()
    # Testing
    assert newIE.ie_key() == 'UDNEmbed'
    assert newIE.ie_desc() == '聯合影音'
    assert newIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert newIE._VALID_URL == r'https?:' + newIE._PROTOCOL_RELATIVE_VALID_URL
 

# Generated at 2022-06-22 08:54:14.855220
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_NAME == 'UDNEmbed'
    assert udne._VALID_URL ==  r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._TESTS[0]['url'] ==  'http://video.udn.com/embed/news/300040'
    assert udne._TESTS[0]['info_dict']['id'] == '300040'
    assert udne._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-22 08:54:17.820531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	url = "http://video.udn.com/embed/news/300040"
	assert UDNEmbedIE()._match_id(url) == "300040"
	

# Generated at 2022-06-22 08:55:18.238739
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.info_dict == {'id': '300040'}
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

test_UDNEmbedIE()

# Generated at 2022-06-22 08:55:20.314897
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()

# Generated at 2022-06-22 08:55:22.279071
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE()._real_extract(url)
    url = "https://video.udn.com/embed/news/300040"
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-22 08:55:25.054913
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    q = UDNEmbedIE(None)
    assert q.IE_NAME == 'udn'

# Generated at 2022-06-22 08:55:33.505130
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL.match('https://video.udn.com/embed/news/300040')
    assert UDNEmbedIE._VALID_URL.match('http://video.udn.com/embed/news/300040')
    assert UDNEmbedIE._VALID_URL.match('https://video.udn.com/play/news/300040')
    assert UDNEmbedIE._VALID_URL.match('http://video.udn.com/play/news/300040')
    assert not UDNEmbedIE._VALID_URL.match('https://video.udn.com/news/300040')

# Generated at 2022-06-22 08:55:34.424953
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-22 08:55:38.093682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    assert udne._VALID_URL == u'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
# End of unit test

# Generated at 2022-06-22 08:55:39.656959
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    func = globals().get('test_' + UDNEmbedIE.__name__)
    assert func
    func()

# Generated at 2022-06-22 08:55:44.911335
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """test parameter can be 'https://video.udn.com/embed/news/300040' or '//video.udn.com/embed/news/300040'"""
    UDNEmbedIE('https://video.udn.com/embed/news/300040')
    UDNEmbedIE('//video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:55:52.932553
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    global UDNEmbedIE
    UDNEmbedIE.__module__ = 'test_UDNEmbedIE'
    instance = UDNEmbedIE()
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_DESC == '聯合影音'
    assert instance._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:58:31.649520
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:58:33.385259
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:58:37.362132
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from views import UDNEmbedIE
    UDNEmbedIE("https://video.udn.com/embed/news/300040", "udn_video")
    UDNEmbedIE("https://video.udn.com/embed/news/300040", "udn_video")

# Generated at 2022-06-22 08:58:44.063369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._TESTS += [{
        'url': 'https://video.udn.com/embed/news/300040',
        'info_dict': {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }]


# Generated at 2022-06-22 08:58:51.618460
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	import yaml
	with open("test.yaml") as f:
		tests = yaml.load(f)

	for (url, title) in tests:
		print("Testing " + url)
		assert UDNEmbedIE()._extract_title(url) == title



# Generated at 2022-06-22 08:58:57.941807
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # This test is going to construct the URLEmbedIE object,
    # but not going to call the _real_initialize() of that constructed object.
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:59:05.182676
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040').groupdict()['id'] == '300040'
    assert re.match(UDNEmbedIE._VALID_URL, 'https://video.udn.com/embed/news/300040').groupdict()['id'] == '300040'


# Test for method _real_extract() of class UDNEmbedIE

# Generated at 2022-06-22 08:59:08.082726
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_name = 'UDNEmbed'
    ie_class = globals()[ie_name + 'IE']
    ie = ie_class('UDNEmbed')
    if not ie.IE_NAME == ie_name:
        return False
    return True

# Unit test

# Generated at 2022-06-22 08:59:09.769605
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:59:15.127153
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test Protocol-relative URL
    url = '//video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'udn.com:embed'

    # Test invalid URL
    url = 'http://www.udn.com/news/story/6885/1459450'
    ie = UDNEmbedIE()
    assert not ie.suitable(url)