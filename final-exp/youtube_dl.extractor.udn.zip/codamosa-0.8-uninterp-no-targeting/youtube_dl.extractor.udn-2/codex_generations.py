

# Generated at 2022-06-22 08:49:52.107998
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:49:52.708683
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:50:04.365795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _VALID_URL = r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:16.090360
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # Test case 1:
    #   Test with a valid URL
    valid_url = "http://video.udn.com/embed/news/300040"
    ret = ie.suitable(valid_url)
    assert ret == 'SUITABLE'

    # Test case 2:
    #   Test with a non-valid URL
    non_valid_url = "https://video.udn.com/embed/news/300040"
    ret = ie.suitable(non_valid_url)
    assert ret == 'UNSUITABLE'

    # Test case 3:
    #   Test with a valid URL, but not a YouTube video
    valid_url = "https://video.udn.com/play/news/303776"
    ret = ie.suitable(valid_url)

# Generated at 2022-06-22 08:50:21.098483
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert isinstance(test, InfoExtractor)
    assert test.IE_NAME == 'udn'
    assert test.IE_DESC == '聯合影音'
    assert test._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:50:32.488322
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert ie.suitable(url)
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._extract_url(url) == '300040'
    assert ie._real_extract(url)['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie._real_extract(url)['id'] == '300040'

# Generated at 2022-06-22 08:50:34.113840
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:50:39.864090
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    from utils import get_testdata_dir
    from ..utils import compat_urlparse

    class TestUDNEmbedIE(unittest.TestCase):
        def setUp(self):
            test_id = '200089'
            self.URL = 'http://video.udn.com/embed/news/' + test_id
            self.page = self.load_page('page_' + test_id)

        def load_page(self, test_page):
            import os.path
            return compat_urlparse.urljoin(
                'file:',
                compat_urlparse.quote(os.path.join(get_testdata_dir(), test_page + '.html')))

        def test_constructor_1(self):
            ie_1 = UDNEmbedIE()
           

# Generated at 2022-06-22 08:50:41.341069
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    template = UDNEmbedIE(InfoExtractor())
    assert isinstance(template, InfoExtractor), 'Unit test for constructor of class UDNEmbedIE failed.'


# Generated at 2022-06-22 08:50:52.039968
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instanceUDNEmbedIE = UDNEmbedIE()
    assert(instanceUDNEmbedIE.IE_DESC == '聯合影音')
    assert(re.compile(instanceUDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL).match('//video.udn.com/embed/news/300040') is not None)
    assert(re.compile(instanceUDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL).match('//video.udn.com/play/news/300040') is not None)
    assert(re.compile(instanceUDNEmbedIE._VALID_URL).match('http://video.udn.com/embed/news/300040') is not None)

# Generated at 2022-06-22 08:51:05.378947
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 08:51:13.053903
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Set up class for testing
    class TestClass(UDNEmbedIE):
        def _download_webpage(self, url, video_id, note=None, errnote=None, fatal=True):
            webpage = self._webpage_read_content(video_id)
            return webpage

# Generated at 2022-06-22 08:51:18.688096
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_url = 'http://video.udn.com/embed/news/300040'
    udn_embed_id = '300040'
    udn_embed_ie = UDNEmbedIE()
    udn_embed_ie.extractor._match_id(udn_embed_url) == udn_embed_id

# Generated at 2022-06-22 08:51:25.253761
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    test_instance = UDNEmbedIE()
    result = test_instance.suitable(url)
    # print test_instance.suitable(url)
    assert result == False
    # assert test_instance.suitable(url) == False



# Generated at 2022-06-22 08:51:35.234473
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == '__main__':
        test_class = UDNEmbedIE('UDNEmbedIE')
        assert test_class._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
        assert test_class._VALID_URL == r'https?:' + test_class._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:51:46.804333
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    assert i.IE_DESC == '聯合影音'
    assert i._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert i._VALID_URL == r'https?:' + i._PROTOCOL_RELATIVE_VALID_URL
    assert len(i._TESTS) == 3
    assert i._TESTS[0]['url']=='http://video.udn.com/embed/news/300040'
    assert i._TESTS[0]['info_dict']['id']=='300040'

# Generated at 2022-06-22 08:51:56.352178
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie.getUrl() == url
    assert ie.getVideoId() == '300040'
    assert ie.getExtractors() == []

# Generated at 2022-06-22 08:51:58.730602
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE({})


# Generated at 2022-06-22 08:52:01.104108
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(UDNEmbedIE.ie_key())
    assert ie.ie_key() in ie.SUFFIX

# Generated at 2022-06-22 08:52:08.020749
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_dict = UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')

    assert info_dict['id'] == '300040'
    assert info_dict['ext'] == 'mp4'
    assert info_dict['title'] == '生物老師男變女 全校挺"做自己"'
    assert re.search(r'^https?://.*\.jpg$', info_dict['thumbnail'])

# Generated at 2022-06-22 08:52:27.443797
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # download a video from http://video.udn.com/videoplayer/embed/news/300640
    url = "http://video.udn.com/embed/news/300640"
    UDNEmbedIE = UDNEmbedIE()
    UDNEmbedIE.extract(url)
    # the result should be a valid download of the video

# Test the compatibility between the
# [URL] http://video.udn.com/videoplayer/embed/news/300001
# [URL] http://video.udn.com/embed/news/300001

# Generated at 2022-06-22 08:52:30.991727
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_object = UDNEmbedIE()
    test_object = info_object.IE_DESC
    assert(test_object == "聯合影音")


# Generated at 2022-06-22 08:52:36.610469
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    test_input = {"url": "https://video.udn.com/embed/news/300040", "result": "300040"}
    result = udnei._match_id(test_input["url"])
    assert result == test_input["result"]
    print("Test 1 for UDNEmbedIE constructor: Passed\n")



# Generated at 2022-06-22 08:52:40.458834
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:53.022964
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructed with a single url
    url = 'https://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE(url)
    assert udne._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    # Constructed with a single url and embed=True, private fields should change accordingly
    udne = UDNEmbedIE(url, embed=True)
    assert udne._VALID_URL == 'https?://video\.udn\.com/embed/news/(?P<id>\d+)'
    assert udne._TESTS

# Generated at 2022-06-22 08:53:00.634170
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test = UDNEmbedIE()

    # Test case with value of `_PROTOCOL_RELATIVE_VALID_URL`
    match = unit_test._match_id('//video.udn.com/embed/news/300040')
    assert match == '300040'

    # Test case with value of `_VALID_URL`
    match = unit_test._match_id('http://video.udn.com/embed/news/300040')
    assert match == '300040'


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:53:12.015518
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        int_or_none,
        js_to_json,
    )
    from ..compat import compat_urlparse

    video_id = '300040'

# Generated at 2022-06-22 08:53:14.282599
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:53:20.884722
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test _PROTOCOL_RELATIVE_VALID_URL
    ie = UDNEmbedIE(None)
    ie._match_id('//video.udn.com/embed/news/300040')
    # Test _VALID_URL
    ie = UDNEmbedIE(None)
    ie._match_id('http://video.udn.com/embed/news/300040')
    ie._match_id('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:53:26.770002
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    match_obj = re.match(
        UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
        '//video.udn.com/embed/news/300040',
    )
    instance = UDNEmbedIE(match_obj)

    assert instance._match_id('http://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-22 08:53:59.173376
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('udn')  # noqa

# Generated at 2022-06-22 08:54:03.997819
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed.IE_NAME == "UDN.com Embed"
    assert udn_embed.IE_DESC == "聯合影音"


# Generated at 2022-06-22 08:54:05.440085
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(isinstance(UDNEmbedIE, InfoExtractor))

# Generated at 2022-06-22 08:54:09.738738
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the constructor without a parameter
    UDNEmbedIE()

    # Test the constructor with a parameter
    UDNEmbedIE(None)

# Generated at 2022-06-22 08:54:15.574372
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:54:22.071903
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    assert ie._match_id(ie.IE_NAME, 'http://video.udn.com/embed/news/300040') == 'http://video.udn.com/embed/news/300040'
    assert ie._match_id(ie.IE_NAME, 'https://video.udn.com/embed/news/300040') == 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:54:26.808032
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040');
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'http://video.udn.com/embed/news/(?P<id>\\d+)'

test_UDNEmbedIE()

# Generated at 2022-06-22 08:54:32.625904
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:54:40.356043
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.ie_key() == 'UDNEmbed'
    assert u.ie_desc() == '聯合影音'
    assert u.info_dict['id'] == '300040'
    assert u.info_dict['title'] == '生物老師男變女 全校挺"做自己"'
    assert hasattr(u.info_dict, 'thumbnail') is True
    assert u.info_dict['formats'][0]['url'] == 'https://video.udn.com/api/v1/streaming/news/300040?quality=ld'
    assert u.info_dict['formats'][0]['format_id'] == 'http-hls'


# Generated at 2022-06-22 08:54:41.334883
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:55:47.283848
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert (ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')

# Generated at 2022-06-22 08:55:56.163328
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor test
    """
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'embed:udn.com'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:55:58.773361
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    new_UDNEmbedIE = UDNEmbedIE(None)
    assert new_UDNEmbedIE is not None
    assert new_UDNEmbedIE.IE_NAME == 'UDN Video'

# Generated at 2022-06-22 08:56:01.320401
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    temp = UDNEmbedIE()
    assert temp.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:56:04.373785
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('udn', 'https://video.udn.com/embed/news/300040')
    assert isinstance(ie, InfoExtractor)
    assert 'udn' in ie.IE_NAME

# Generated at 2022-06-22 08:56:06.643449
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert ie._PROTOCOL_RELATIVE_VALID_URL;
    assert ie._VALID_URL;
    assert ie._TESTS;

# Generated at 2022-06-22 08:56:08.511982
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-22 08:56:13.283900
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembed_ie = UDNEmbedIE()
    assert (udnembed_ie.IE_NAME == 'UDNEmbed')
    assert (udnembed_ie.IE_DESC == '聯合影音')

# Generated at 2022-06-22 08:56:15.737807
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE._downloader)

# Generated at 2022-06-22 08:56:22.110181
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbedIE'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:58:51.561395
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:58:54.256177
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(context={'cookiejar':{}})

# Generated at 2022-06-22 08:59:04.316027
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

	from .youtube import YoutubeIE
	from .douyutv import DouyuTVIE
	from .iqilu import IQiLuIE


# Generated at 2022-06-22 08:59:06.590166
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == ie.IE_DESC
    ie = UDNEmbedIE("")
    assert ie._VALID_URL == ie.IE_DESC

# Generated at 2022-06-22 08:59:09.047603
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..test import get_testcases
    get_testcases(UDNEmbedIE, [UDNEmbedIE._VALID_URL], [UDNEmbedIE._TESTS])

# Generated at 2022-06-22 08:59:13.280778
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Constructor test
    '''
    ie = UDNEmbedIE()
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-22 08:59:15.019413
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:59:18.804668
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:59:20.230931
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()
    print(x)

# Generated at 2022-06-22 08:59:22.602127
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # type: () -> object
    """Unit test for constructor of class UDNEmbedIE"""
    udn_embed_ie = UDNEmbedIE()
    return udn_embed_ie