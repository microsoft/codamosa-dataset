

# Generated at 2022-06-22 08:49:50.469084
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('@UDN')
    # test whether the url_regex is valid
    m = ie._VALID_URL.match('http://video.udn.com/embed/news/300040')
    m.group('id')

# Generated at 2022-06-22 08:49:52.253175
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE, url

# Generated at 2022-06-22 08:49:55.024637
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:50:01.848962
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # the following returns a 'InfoExtractor' instance which is the top-level class for all info extractors
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:50:06.043009
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == 
        '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-22 08:50:14.337741
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("https://video.udn.com/embed/news/300040")
    UDNEmbedIE("https://video.udn.com/news/300040")
    UDNEmbedIE("http://video.udn.com/embed/news/300040")
    UDNEmbedIE("http://video.udn.com/play/news/300040")
    UDNEmbedIE("//video.udn.com/embed/news/300040")
    UDNEmbedIE("//video.udn.com/play/news/300040")

# Generated at 2022-06-22 08:50:23.772933
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UdnEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:50:26.894032
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("constructor check:")
    assert(UDNEmbedIE)
    print("constructor success")

# Generated at 2022-06-22 08:50:31.438752
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()

    assert udne._VALID_URL == udne.VALID_URL
    assert udne._TESTS == udne.TESTS
    assert udne.IE_NAME == udne.ie_key()


# Generated at 2022-06-22 08:50:37.660849
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..test import get_testcases
    from .. import _html_search_regex
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        js_to_json
    )

    print("Test UDNEmbedIE...")
    testcases = get_testcases(UDNEmbedIE)
    for (test_id, raw_testcase) in enumerate(testcases):
        testcase = raw_testcase.copy()

# Generated at 2022-06-22 08:51:00.430610
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    # test _html_search_regex
    p = 'var options = {"video":{"mp4":"http://video.udn.com/mp4url/300222-1.mp4"}};'

# Generated at 2022-06-22 08:51:07.206741
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embedIE = UDNEmbedIE()
    assert udn_embedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embedIE._VALID_URL == r'https?:' + udn_embedIE._PROTOCOL_RELATIVE_VALID_URL



# Generated at 2022-06-22 08:51:08.760578
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()


# Generated at 2022-06-22 08:51:21.062599
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:30.141921
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test YoutubeIE constructor."""
    def check_valid_url(url, expected_id):
        """Check if the url is parsed correctly."""
        udn_IE = UDNEmbedIE(url)
        assert udn_IE._match_id == expected_id

    check_valid_url(
        'https://video.udn.com/embed/news/300110',
        r'300110')
    check_valid_url(
        'http://video.udn.com/embed/news/300040',
        r'300040')
    check_valid_url(
        'http://video.udn.com/play/news/300040',
        r'300040')

# Generated at 2022-06-22 08:51:37.165232
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-22 08:51:44.352697
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Make sure that class UDNEmbedIE works properly.
    '''
    from ..utils import parse_duration

    udnIE = UDNEmbedIE()

    # Extract duration from a youtube url
    youtubeUrl = '//www.youtube.com/watch?v=L8W7Zu-vU5Q'
    duration = parse_duration(udnIE._download_webpage(
        'http://' + youtubeUrl, None))
    assert duration == 0

# Generated at 2022-06-22 08:51:45.314940
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    print('test = %s' % test)

# Generated at 2022-06-22 08:51:47.415073
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("http://video.udn.com/embed/news/300040")
    UDNEmbedIE("https://video.udn.com/embed/news/300040")

# Generated at 2022-06-22 08:51:48.895224
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:52:18.777471
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test video retrieval with a video URL.
    a_video_url = 'http://video.udn.com/embed/news/300040'
    a_udn_video_retriever = UDNEmbedIE()
    assert a_udn_video_retriever._match_id(a_video_url) == '300040'


# Generated at 2022-06-22 08:52:27.986651
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE()
    r = obj._real_extract(url)
    assert r["id"] == "300040"
    assert r["title"] == '生物老師男變女 全校挺"做自己"'
    assert r["thumbnail"] == 'https://i.ytimg.com/vi/xIwz0rSu3qc/hqdefault.jpg'

# Generated at 2022-06-22 08:52:35.669895
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    expected_result = 'http://video.udn.com/embed/news/300040'
    assert_equal(ie._match_id(expected_result), '300040')

    expected_result = 'http://video.udn.com/play/news/300040'
    assert_equal(ie._match_id(expected_result), '300040')

    assert_equal(re.compile(ie._VALID_URL).match(expected_result).groupdict()['id'], '300040')

# Generated at 2022-06-22 08:52:43.195385
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    test_url1 = 'http://video.udn.com/embed/news/300334'
    test_url2 = 'https://video.udn.com/embed/news/300334'

    # test normal case
    test_case1 = {'url':test_url1,
                  'ie':'UDNEmbed',
                  'video_id':'300334',
                  'skip_download':True}

    # test https case
    test_case2 = {'url':test_url2,
                  'ie':'UDNEmbed',
                  'video_id':'300334',
                  'skip_download':True}

    # test for _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:45.792131
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    embed = UDNEmbedIE()
    embed._match_id('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:52:56.598818
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == '__main__':
        # The test of constructor of class UDNEmbedIE
        ie = UDNEmbedIE()
        assert ie.IE_NAME == 'udn'
        assert ie.IE_DESC == '聯合影音'
        assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
        assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
        assert ie.__name__ == 'UDNEmbedIE'
        # The test of _real_extract
        url = 'https://video.udn.com/play/news/300040'


# Generated at 2022-06-22 08:53:05.032025
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert isinstance(udn_embed_ie, InfoExtractor)
    assert udn_embed_ie.IE_DESC == "聯合影音"
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == "//video.udn.com/(?:embed|play)/news/(?P<id>\d+)"
    assert udn_embed_ie._VALID_URL == "https?://video.udn.com/(?:embed|play)/news/(?P<id>\d+)"


# Generated at 2022-06-22 08:53:15.943142
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test case 1: a valid URL of a video in UDN website
    test_url = "http://video.udn.com/embed/news/300040"
    test_url_parsed = compat_urlparse.urlparse(test_url)
    test_url_query = compat_urlparse.parse_qs(test_url_parsed.query)
    assert test_url_parsed.netloc == 'video.udn.com'
    assert test_url_parsed.path == '/embed/news/300040'
    assert test_url_parsed.query == ''
    assert test_url_parsed.query == ''
    # test case 2: a valid URL of a video in same website with
    #              protocol-relative form

# Generated at 2022-06-22 08:53:25.834816
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    m = re.search(ie._VALID_URL, 'https://video.udn.com/play/news/300040')
    assert m
    assert m.group('id') == '300040'
    m = re.search(ie._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert m
    assert m.group('id') == '300040'

# Generated at 2022-06-22 08:53:31.420241
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:54:33.632080
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie
    assert ie.ie_key() == 'udnembed'
    assert ie.ie_desc() == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-22 08:54:40.308855
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # Test for normal case
    url = 'http://video.udn.com/embed/news/300040'
    page = ie._download_webpage(url, '300040')
    options_str = ie._html_search_regex(r'var\s+options\s*=\s*([^;]+);', page, 'options')
    trans_options_str = js_to_json(options_str)
    # Test for JSON domain
    assert ie._parse_json(trans_options_str, 'options')
    # Test for missing JSON domain
    assert ie._parse_json(trans_options_str, 'options', fatal=False)

# Generated at 2022-06-22 08:54:47.633289
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE.
    """
    url = UDNEmbedIE._VALID_URL
    url_dict = UDNEmbedIE._extract_urls(url)
    assert len(url_dict) == 1
    assert url_dict[0] == url
    url = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    url_dict = UDNEmbedIE._extract_urls(url)
    assert len(url_dict) == 1
    assert url_dict[0] == 'http:' + url

# Generated at 2022-06-22 08:54:57.641051
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:55:05.440457
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert str(type(ie._match_id)) == "<type 'method'>"
    assert str(type(ie._real_extract)) == "<type 'instancemethod'>"
    # assert ie._TESTS
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie.__name__ == 'UDNEmbedIE'
    assert ie.__doc__

# Generated at 2022-06-22 08:55:10.583101
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    unit test for constructor of class UDNEmbedIE
    """
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:55:12.027203
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne != None


# Generated at 2022-06-22 08:55:13.524538
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result = UDNEmbedIE.suitable('', None)
    assert result == (None, None)

# Generated at 2022-06-22 08:55:21.232148
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    IE._PROTOCOL_RELATIVE_VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    IE._VALID_URL = UDNEmbedIE._VALID_URL
    IE.IE_DESC = UDNEmbedIE.IE_DESC
    IE._real_extract = UDNEmbedIE._real_extract
    IE._download_webpage =lambda url : '<script>var options = { "video": { "mp4": "http://www.youtube.com/v/6ZfuNTqbHE8&hl=zh_TW&fs=1&" }, "poster": "/static/images/video/none.jpg", "title": "Youtube Test" };</script>'

# Generated at 2022-06-22 08:55:23.728154
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:56:39.012919
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj2 = UDNEmbedIE()



# Generated at 2022-06-22 08:56:39.993765
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()


# Generated at 2022-06-22 08:56:44.653630
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    assert i
    assert i.IE_DESC == '聯合影音'
    assert i._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert i._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:56:48.048274
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    UDNEmbedIE(InfoExtractor(), u'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:56:50.414900
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_NAME == 'udn'
    assert instance.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:56:51.836078
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE(InfoExtractor())

# Generated at 2022-06-22 08:56:52.753175
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-22 08:56:55.891274
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME in globals()
    assert ie.IE_DESC in globals()
    assert ie._VALID_URL in globals()

# Generated at 2022-06-22 08:56:58.969663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._TESTS == UDNEmbedIE._TESTS

# Generated at 2022-06-22 08:57:05.767462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _udn_embed_ie = UDNEmbedIE()
    _udn_embed_ie.IE_DESC = "test udn_embed_ie"
    _udn_embed_ie.IE_NAME = "udn_embed_ie"
    _udn_embed_ie._VALID_URL = UDNEmbedIE._VALID_URL
    _udn_embed_ie._TESTS = UDNEmbedIE._TESTS
    return _udn_embed_ie

# Tests for match process