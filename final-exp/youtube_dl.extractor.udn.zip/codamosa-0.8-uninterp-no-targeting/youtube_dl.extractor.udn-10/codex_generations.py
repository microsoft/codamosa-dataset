

# Generated at 2022-06-22 08:49:50.707128
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL()
    udn_embed_ie = ydl._ies['udn_embed']
    assert(isinstance(udn_embed_ie, UDNEmbedIE))

# Generated at 2022-06-22 08:49:54.961875
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._TESTS == ie._TESTS

# Generated at 2022-06-22 08:50:00.268907
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
     url = 'http://video.udn.com/embed/news/300040'
     aUDNEmbedIE = UDNEmbedIE()
     assert(aUDNEmbedIE._TESTS[0]['url'] == url)

# Generated at 2022-06-22 08:50:01.233130
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-22 08:50:09.330985
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_local_url = 'http://video.udn.com/embed/news/300040'
    udn_url = 'https://video.udn.com/embed/news/300040'
    udn_local_url_no_protocol = '//video.udn.com/embed/news/300040'
    udn_url_no_protocol = 'https://video.udn.com/embed/news/300040'
    youtube_url = 'http://www.youtube.com/embed/watch?feature=player_embedded&v=XSGBVzeBUbk'
    ie = UDNEmbedIE()

    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    assert ie.ie

# Generated at 2022-06-22 08:50:14.702061
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit = UDNEmbedIE()
    url = UDNEmbedIE._TESTS[0]['url']
    video_id = UDNEmbedIE._TESTS[0]['info_dict']['id']
    assert unit._match_id(url) == video_id

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:50:22.950899
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Given
    url = "http://video.udn.com/embed/news/1000"

    # When
    udn = UDNEmbedIE()

    # Then
    assert(udn.IE_NAME == "udn_embed")
    assert(udn.IE_DESC == "聯合影音")
    assert(udn._VALID_URL == re.compile(r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'))
    assert(udn._TESTS[0]['url'] == url)
    assert(udn._TESTS[0]['info_dict']['id'] == "1000")

# Generated at 2022-06-22 08:50:29.673485
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_info = {'_VALID_URL': 'https://video.udn.com/embed/news/300040'}
    try:
        UDNEmbedIE(test_info)
    except (SystemExit, KeyboardInterrupt):
        raise
    except Exception:
        pass
    else:
        raise RuntimeError('UDNEmbedIE should raise an exception for protocol relative URL')

# Generated at 2022-06-22 08:50:33.414700
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-22 08:50:39.155577
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    try:
        info = ie.extract(url)
        print(info)
    except Exception as e:
        print(str(e))

# Unit test
if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:50:52.467054
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/embed/news/300040')
    UDNEmbedIE('http://video.udn.com/news/300040')
    UDNEmbedIE('https://video.udn.com/news/300040')
    UDNEmbedIE('//video.udn.com/news/300040?fromApp=App')
    UDNEmbedIE('')
    UDNEmbedIE(None)

# Generated at 2022-06-22 08:51:00.559993
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/303991'
    ie = UDNEmbedIE()

    assert ie.IE_NAME == 'udn.com:embed'
    assert ie._VALID_URL == ie.VALID_URL
    assert re.match(ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/303991'), "VALID_URL can't match URL: https://video.udn.com/embed/news/303991"

    m = ie._match_id(url)
    assert m == '303991', 'The id is 303991'


# Generated at 2022-06-22 08:51:06.011371
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME == 'UDNEmbed'
    assert obj.IE_DESC == '聯合影音'
    assert obj._VALID_URL == r'https?:https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:11.832083
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .udn import UDNEmbedIE
    ie = InfoExtractor(UDNEmbedIE.ie_key())
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:13.450436
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE == type(UDNEmbedIE({}))

# Generated at 2022-06-22 08:51:17.173554
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    url = 'http://video.udn.com/embed/news/300040'

    # sample input url
    # url = r'https://video.udn.com/embed/news/300040'

    UDNEmbedIE(url)

# Generated at 2022-06-22 08:51:17.836095
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:20.964797
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.IE_NAME == 'UDNEmbed'
    assert IE.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:51:25.468582
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:35.695466
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_NAME == 'udn'
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udne._TESTS[0]['info_dict']['id'] == '300040'
    assert u

# Generated at 2022-06-22 08:51:49.185462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:52.507515
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    class_ = globals()['UDNEmbedIE']
    # Constructor of class InfoExtractor
    udnEmbedIE = class_(None)
    # Constructor of class UDNEmbedIE
    udnEmbedIE = class_(udnEmbedIE._downloader, udnEmbedIE._match_id(url))
    assert udnEmbedIE._match_id(url) == '300040'

# Generated at 2022-06-22 08:51:55.403461
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:56.606680
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inf_extractor = UDNEmbedIE()
    assert inf_extractor is not None


# Generated at 2022-06-22 08:52:08.070073
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    s = UDNEmbedIE()
    assert s._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert s._VALID_URL == r'https?:' + s._PROTOCOL_RELATIVE_VALID_URL
    assert s._TESTS[0]['info_dict']['id'] == '300040'
    assert s._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert s._TESTS[0]['params']['skip_download']

# Generated at 2022-06-22 08:52:14.943740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # When the url can not be found, raise an error
    url = 'http://video.udn.com/embed/news/1'
    # When the url can be found, return a UDNEmbedIE instance
    url2 = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE(url)
    udn_embed_ie2 = UDNEmbedIE(url2)
    assert udn_embed_ie == udn_embed_ie2
    assert isinstance(udn_embed_ie, InfoExtractor)


# Generated at 2022-06-22 08:52:17.729958
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = UDNEmbedIE._VALID_URL
    ie = UDNEmbedIE(None)
    ie.result = ie._real_extract(url)
    assert ie.result

# Generated at 2022-06-22 08:52:18.314284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-22 08:52:25.615677
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME == 'udn'
    assert obj.IE_DESC == '聯合影音'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:52:36.943010
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    class ConUnitTest(unittest.TestCase):
        def setUp(self):
            self.udn_embed_ie = UDNEmbedIE()
        def test__PROTOCOL_RELATIVE_VALID_URL(self):
            # if do not have prfix, add http:
            url = '//video.udn.com/embed/news/300040'
            self.assertEqual('http:' + url, self.udn_embed_ie._match_id(url))
            # if prfix is https, add https:
            url = 'https://video.udn.com/embed/news/300040'
            self.assertEqual(url, self.udn_embed_ie._match_id(url))
    unittest.main()

# Generated at 2022-06-22 08:53:05.402745
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE.
    """
    assert(UDNEmbedIE().IE_DESC == '聯合影音')

# Generated at 2022-06-22 08:53:16.300559
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        int_or_none,
        js_to_json,
    )
    from ..compat import compat_urlparse

    udne = UDNEmbedIE()
    

# Generated at 2022-06-22 08:53:20.503061
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:53:30.354298
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-22 08:53:35.032412
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor of class UDNEmbedIE will check whether the regex
    # _PROTOCOL_RELATIVE_VALID_URL matches the string _VALID_URL
    # _VALID_URL contains one more '/' than _PROTOCOL_RELATIVE_VALID_URL
    # so the regex _PROTOCOL_RELATIVE_VALID_URL will not match the string _VALID_URL
    assert not re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, UDNEmbedIE._VALID_URL)

# Generated at 2022-06-22 08:53:37.831812
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().url_result(test_url)


# Generated at 2022-06-22 08:53:46.833819
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE('UDNEmbedIE', 'http://www.youtube.com')
    assert inst._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst._VALID_URL == r'https?:' + inst._PROTOCOL_RELATIVE_VALID_URL
    assert inst.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:53:52.126286
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    udne = UDNEmbedIE()
    assert udne.suitable(url) is True
    assert udne._match_id(url) == '303776'

# Generated at 2022-06-22 08:53:55.911744
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor, extractor_for_url
    
    udn_embed_ie = extractor_for_url('https://video.udn.com/embed/news/300040')
    assert isinstance(udn_embed_ie, UDNEmbedIE)

# Generated at 2022-06-22 08:53:57.344519
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tmp = UDNEmbedIE()
    assert tmp is not None

# Generated at 2022-06-22 08:54:27.712910
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE()
    assert tester._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:54:35.905684
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.__name__ == 'UDNEmbed'

# Generated at 2022-06-22 08:54:41.426397
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert u.IE_DESC == '聯合影音'
    assert u._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:54:50.798470
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Assert that udn_embed_ie.UDNEmbedIE.__init__() will work properly
    embedie = UDNEmbedIE()
    # Call udn_embed_ie.UDNEmbedIE.get_url_re() to get URL regex
    emb_re = embedie.get_url_re()

    # Test that some URLs will match the URL regex
    assert(len(emb_re.findall('http://video.udn.com/embed/news/300040')) > 0)
    assert(len(emb_re.findall('https://video.udn.com/embed/news/300040')) > 0)
    assert(len(emb_re.findall('http://video.udn.com/play/news/303776')) > 0)

# Generated at 2022-06-22 08:54:56.386787
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(url='', params=None)
    assert (ie.IE_DESC == '聯合影音')
    assert (ie.IE_NAME == 'udn')
    assert (ie.VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL)
    assert (ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-22 08:54:59.193556
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._match_id("http://video.udn.com/embed/news/300040")
    assert True


# Generated at 2022-06-22 08:55:05.125173
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE('')
    pat_PROTOCOL_RELATIVE_VALID_URL = re.compile(IE._PROTOCOL_RELATIVE_VALID_URL)
    assert pat_PROTOCOL_RELATIVE_VALID_URL.match('//video.udn.com/play/news/303776')

# Generated at 2022-06-22 08:55:09.972910
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Testing constructor")

    assert(UDNEmbedIE("https://video.udn.com/embed/news/300040"))
    assert(UDNEmbedIE("https://video.udn.com/play/news/300040"))
    assert(not UDNEmbedIE("https://video.udn.com/play/news/300040", True))

# Generated at 2022-06-22 08:55:17.791551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE(url)
    assert ie.__class__.__name__ == 'UDNEmbedIE'
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.valid_url == 'http://video.udn.com/embed/news/300040'
    assert ie.info_dict == {'id': '300040', 'ext': 'mp4', 'title': '生物老師男變女 全校挺"做自己"', 'thumbnail': re.compile('^https?://.*\.jpg$')}
    assert ie.params['skip_download'] == True

# Generated at 2022-06-22 08:55:27.157515
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udni = UDNEmbedIE(None)
    assert udni.IE_NAME == 'UDNEmbedIE'
    #assert udni.IE_DESC == '聯合影音'
    assert udni._VALID_URL == 'https?://video.udn.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udni._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)'
    #assert udni._TESTS == [{
    #    'url': 'http://video.udn.com/embed/news/300040',
    #    'info_dict': {
    #        'id': '300040',

# Generated at 2022-06-22 08:56:44.096465
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:56:50.694925
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()
	ie._real_extract('https://video.udn.com/play/news/303776')
	return ie

if __name__ == '__main__':
	ie = test_UDNEmbedIE()
	print(ie.__dict__)
	print(ie.__dict__["_downloader"].__dict__)
	print(ie.__dict__["_downloader"]._default_downloader.__dict__)

# Generated at 2022-06-22 08:56:52.793945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'

    UDNEmbedIE().extract(url)

# Generated at 2022-06-22 08:56:54.643594
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(UDNEmbedIE.ie_key()).suitable(url) and UDNEmbedIE(UDNEmbedIE.ie_key()).extract(url)

# Generated at 2022-06-22 08:56:55.813499
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' == UDNEmbedIE.ie_key()

# Generated at 2022-06-22 08:56:58.512117
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._TESTS == ie._TESTS

# Generated at 2022-06-22 08:57:08.252815
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Proto relative URL
    udn_embed_ie = UDNEmbedIE._registry.instance(
        '//video.udn.com/embed/news/300040')
    assert isinstance(udn_embed_ie, UDNEmbedIE)
    # 'http' prefixed URL
    udn_embed_ie = UDNEmbedIE._registry.instance(
        'http://video.udn.com/embed/news/300040')
    assert isinstance(udn_embed_ie, UDNEmbedIE)
    # Proto relative URL with invalid prefix
    udn_embed_ie = UDNEmbedIE._registry.instance(
        'xxx://video.udn.com/embed/news/300040')
    assert isinstance(udn_embed_ie, UDNEmbedIE)
    #

# Generated at 2022-06-22 08:57:14.335920
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test case 1
    url = 'https://video.udn.com/embed/news/300040'
    url = url
    # Constructor
    assert UDNEmbedIE._match_id(url) == '300040'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._download_webpage == UDNEmbedIE._download_webpage
    assert UDNEmbedIE._match_id == UDNEmbedIE._match_id
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbed

# Generated at 2022-06-22 08:57:22.375256
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    
    # test case 1
    url = 'https://video.udn.com/embed/news/300040'
    expect_id = '300040'
    assert ie.suitable(url) == True, 'not suitable for this url!'  
    assert ie._match_id(url) == expect_id, 'video id not match!'
    
    # test case 2
    url = 'https://video.udn.com/embed/news/300040#udn_zoom=2'
    expect_id = '300040'
    assert ie.suitable(url) == True, 'not suitable for this url!'  
    assert ie._match_id(url) == expect_id, 'video id not match!'
    
    # test case 3

# Generated at 2022-06-22 08:57:27.777216
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

