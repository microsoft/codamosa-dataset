

# Generated at 2022-06-22 08:49:50.756103
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():   
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:49:56.397595
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:49:57.435932
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().name == 'udn'

# Generated at 2022-06-22 08:50:03.087395
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_DESC == '聯合影音'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == 'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:10.587026
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert ie._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-22 08:50:13.358402
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.compile(UDNEmbedIE._VALID_URL).match(
        'http://video.udn.com/embed/news/300040') is not None

# Generated at 2022-06-22 08:50:20.299718
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert info_extractor.IE_DESC == '聯合影音'
    assert info_extractor._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert info_extractor._user_agent == 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0'

# Generated at 2022-06-22 08:50:21.136914
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-22 08:50:24.795388
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        from youtube_dl.extractor.udn import UDNEmbedIE
        assert isinstance(UDNEmbedIE, type)
        assert issubclass(UDNEmbedIE, InfoExtractor)
    except:
        assert False, "Cannot import youtube-dl.extractor.udn.UDNEmbedIE"


# Generated at 2022-06-22 08:50:32.039491
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    extractor = UDNEmbedIE()
    assert extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert extractor._VALID_URL == r'https?:' + extractor._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:44.924597
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None)

# Generated at 2022-06-22 08:50:47.079511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:50:50.710915
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie._VALID_URL)
    print(ie.IE_DESC)
    print(ie.__doc__)


# Generated at 2022-06-22 08:50:51.698836
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(IE_DESC)

# Generated at 2022-06-22 08:50:54.162452
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert isinstance(u, InfoExtractor)
    assert isinstance(u, UDNEmbedIE)

# Generated at 2022-06-22 08:50:55.979752
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u=UDNEmbedIE()
    assert(u.name == 'udn.com')

# Generated at 2022-06-22 08:50:56.734288
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:00.337715
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udney = UDNEmbedIE()
    match = udney._PROTOCOL_RELATIVE_VALID_URL
    udney._test_valid_url(match, r'//video\.udn\.com/play/news/300040')
    assert udney._VALID_URL == r'https?:' + match

# Generated at 2022-06-22 08:51:04.464007
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?:(?:https?:)?//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:16.475382
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO: Move to unit test
    class UDNEmbedIE_Test(UDNEmbedIE):
        def __init__(self):
            UDNEmbedIE.__init__(self)
            self.options = None
            self.title = None
            self.poster = None

        def _real_extract(self, url):
            UDNEmbedIE._real_extract(self, url)
            return {
                'options': self.options,
                'title': self.title,
                'poster': self.poster,
            }
    tester = UDNEmbedIE_Test()
    tester.download('http://video.udn.com/embed/news/300040')
    assert tester.options is not None
    assert len(tester.options) is 3
    assert t

# Generated at 2022-06-22 08:51:42.400409
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    assert i._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:44.782465
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_info_extractor import TestInfoExtractor
    TestInfoExtractor.test_constructor(UDNEmbedIE)

# Generated at 2022-06-22 08:51:51.070307
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    re_obj = re.compile(ie._VALID_URL)
    for test_url in ['http://video.udn.com/embed/news/300040', 'https://video.udn.com/embed/news/300040']:
        assert re_obj.match(test_url) is not None
    re_obj = re.compile(ie.VALID_URL)

# Generated at 2022-06-22 08:51:55.044956
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Test the constructor of class UDNEmbedIE
    '''
    assert eval(repr(UDNEmbedIE())) == UDNEmbedIE()

# Generated at 2022-06-22 08:51:57.654616
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udndetail = UDNEmbedIE()
    udndetail.suitable(url)
    udndetail._real_extract(url)


# Generated at 2022-06-22 08:52:08.249552
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .UDNEmbedIE import UDNEmbedIE
    from . import SearcherIE
    i=UDNEmbedIE()
    assert i.IE_NAME == 'udn'
    assert i.IE_DESC == '聯合影音'
    assert i._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:52:11.231020
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video = UDNEmbedIE()
    video.download('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:52:15.197025
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_url = 'http://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE()
    assert udn_embed.suitable(valid_url) == True

# Generated at 2022-06-22 08:52:16.268679
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()
    return True

# Generated at 2022-06-22 08:52:17.532971
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:53:04.820825
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert('udnEmbed' == UDNEmbedIE.ie_key())

# Generated at 2022-06-22 08:53:11.756714
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    i = UDNEmbedIE(UDNEmbedIE.create_ie())
    assert i._match_id(url) == '300040'

    url = 'https://video.udn.com/embed/news/300040'
    i = UDNEmbedIE(UDNEmbedIE.create_ie())
    assert i._match_id(url) == '300040'


# Generated at 2022-06-22 08:53:23.342539
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbed_ie = UDNEmbedIE()
    assert udnEmbed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbed_ie._VALID_URL == r'https?:' + udnEmbed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:53:26.902899
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE()
    a._download_webpage('http://video.udn.com/embed/news/300040', '300040')
    a.extract('http://video.udn.com/embed/news/300040')
    return


# Generated at 2022-06-22 08:53:27.891495
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Constructor test"""
    UDNEmbedIE()

# Generated at 2022-06-22 08:53:29.999078
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie._DESC

# Generated at 2022-06-22 08:53:37.795631
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..downloader import YoutubeDL
    url = 'http://video.udn.com/embed/news/300040'
    ydl = YoutubeDL({'verbose': True})
    res = ydl.extract_info(url, download=False)
    assert 'entries' in res

    url = 'http://video.udn.com/play/news/300040'
    res = ydl.extract_info(url, download=False)
    assert 'entries' in res

# Generated at 2022-06-22 08:53:46.833176
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'video.udn.com'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:53:58.603073
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._TESTS is not None
    assert UDNEmbedIE._TESTS[0].get('url') == 'http://video.udn.com/embed/news/300040'
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.match(UDNEmbedIE._VALID_URL, 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:54:08.959553
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    # URL for _VALID_URL
    valid_url = 'http://video.udn.com/embed/news/300040'

    # Test _match_id
    assert udnei._match_id(valid_url) == '300040'
    assert udnei._match_id('') == None

    # Test _real_extract
    json_str = '{"url":"http://video.udn.com/new/video/vdo/20170518/300040.mp4-300k.mp4"}'
    assert udnei._real_extract(valid_url)['formats'][0]['url'] == json_str

# Generated at 2022-06-22 08:56:10.988393
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('udn', '聯合影音', 'embed')

# Generated at 2022-06-22 08:56:21.595413
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE('udn', 'http://video.udn.com/embed/news/300040')
    assert tester._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert tester._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert tester._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert tester._TESTS[0]['info_dict']['id'] == '300040'
    assert tester._TESTS[0]['info_dict']['ext'] == 'mp4'
   

# Generated at 2022-06-22 08:56:31.364614
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_UDNEmbedIE = UDNEmbedIE()
    assert ie_UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # assert ie_UDNEmbedIE.IE_DESC == '聯合影音'
    assert ie_UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie_UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert ie_UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie_UDNEmbedIE._

# Generated at 2022-06-22 08:56:37.136581
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    import unittest
    try:
        from urlparse import urlparse
    except ImportError:
        from urllib.parse import urlparse

    if sys.version_info.major >= 3:
        from urllib.parse import parse_qs
    else:
        from urlparse import parse_qs

    from .common import InfoExtractor

    from ..utils import (
        compat_urlparse,
        determine_ext,
        int_or_none,
        js_to_json,
    )
    from ..compat import (
        compat_urllib_error,
        compat_urllib_parse,
        compat_urlparse,
    )
    from ..extractor import (
        Selection,
        YoutubeIE,
    )
    from ..external import (
        _parse_json,
    )

# Generated at 2022-06-22 08:56:42.342891
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-22 08:56:50.615142
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_UDNEmbedIE.UDNEmbedIE_1 = UDNEmbedIE({'username': 'abc', 'password': 'xyz'})
    assert test_UDNEmbedIE.UDNEmbedIE_1.username == 'abc'
    assert test_UDNEmbedIE.UDNEmbedIE_1.password == 'xyz'

    test_UDNEmbedIE.UDNEmbedIE_2 = UDNEmbedIE({})
    assert test_UDNEmbedIE.UDNEmbedIE_2.username == None
    assert test_UDNEmbedIE.UDNEmbedIE_2.password == None

# Generated at 2022-06-22 08:57:00.326169
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .UDNEmbedIE import UDNEmbedIE
    from ..utils import (
        determine_ext,
        int_or_none,
        js_to_json,
    )
    from ..compat import compat_urlparse


# Generated at 2022-06-22 08:57:03.893681
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test class constructor of class UDNEmbedIE"""
    ie = UDNEmbedIE()
    assert ie
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_PROTOCOL_RELATIVE_VALID_URL')

# Generated at 2022-06-22 08:57:12.692585
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'

# Generated at 2022-06-22 08:57:16.564128
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor_test({
        'url': 'http://video.udn.com/embed/news/300040',
        'only_matching': True,
    })