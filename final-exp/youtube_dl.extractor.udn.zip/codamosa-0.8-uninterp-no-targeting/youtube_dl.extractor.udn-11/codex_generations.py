

# Generated at 2022-06-22 08:49:53.894966
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_extractor = UDNEmbedIE()
    assert udn_extractor is not None

# Generated at 2022-06-22 08:49:58.613117
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._html_search_regex(None, None, None) == None
    assert UDNEmbedIE._match_id(None) == None
    assert UDNEmbedIE._real_extract(None) == None

# Generated at 2022-06-22 08:50:03.520265
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE"""
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn_embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:50:11.694481
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test constructor of class UDNEmbedIE."""
    test_object = UDNEmbedIE({})
    assert test_object._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_object._VALID_URL == r'https?:' + test_object._PROTOCOL_RELATIVE_VALID_URL
    assert test_object._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert test_object._TESTS[0]['info_dict']['id'] == '300040'
    assert test_object._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert test_

# Generated at 2022-06-22 08:50:14.503595
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert(udn_embed is not None)

# Test get_url function of UDNEmbedIE

# Generated at 2022-06-22 08:50:23.982875
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # test for methods
    print(ie._match_id("https://video.udn.com/embed/news/300040"))
    assert ie._match_id("http://video.udn.com/embed/news/300040") == "300040"
    assert ie._real_extract("https://video.udn.com/play/news/300040")["id"] == "300040"
    assert ie._real_extract("https://video.udn.com/embed/news/300040")["id"] == "300040"
    # test for test case
    assert "mp4" in ie._real_extract("http://video.udn.com/embed/news/300040")["formats"][0]["ext"]
    assert "title" in ie._real_ext

# Generated at 2022-06-22 08:50:30.644842
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_NAME == 'udn:embed'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:50:38.210434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test 1
    data_url = 'https://video.udn.com/embed/news/300040'
    test_1 = UDNEmbedIE()
    print(test_1._PROTOCOL_RELATIVE_VALID_URL, test_1._VALID_URL)

    # test 2
    test_2 = UDNEmbedIE._VALID_URL
    test_2_result = re.match(test_2, data_url)
    print(test_2_result)


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:50:49.017210
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        int_or_none,
        js_to_json,
    )
    from ..compat import compat_urlparse

    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:51.114212
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert(IE.ie_key() == 'UDNEmbed')

# Generated at 2022-06-22 08:51:12.290980
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_UDNEmbedIE = UDNEmbedIE()
    assert_equal(test_UDNEmbedIE.IE_NAME, 'udn')
    assert_equal(test_UDNEmbedIE.IE_DESC, '聯合影音')
    assert_equal(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert_equal(UDNEmbedIE._VALID_URL, 'https?:' + '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert_false(UDNEmbedIE._TESTS[0].has_key('only_matching'))

# Generated at 2022-06-22 08:51:16.769608
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()

    # Check the constructor
    assert udn_embed_ie

    # Check instance of InfoExtractor
    assert isinstance(udn_embed_ie, InfoExtractor)

# Generated at 2022-06-22 08:51:17.816298
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:22.051426
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Unit Test for _real_extract of class UDNEmbedIE

# Generated at 2022-06-22 08:51:26.705412
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert inst.extract()["title"] == u"生物老師男變女 全校挺\"做自己\""

# Generated at 2022-06-22 08:51:34.129206
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    ie2 = UDNEmbedIE(ie, ie._downloader)
    assert ie2._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie2._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:35.544463
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_class = UDNEmbedIE()
    assert test_class

# Generated at 2022-06-22 08:51:36.669905
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:42.141257
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE.
    """
    url = '//video.udn.com/embed/news/300040'
    expected_dict = {'ie_key': 'UDNEmbed'}

    content = UDNEmbedIE._build_url_result(url)
    assert content == expected_dict

# Generated at 2022-06-22 08:51:53.303582
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("### Test UDNEmbedIE ###")
    UDNEmbedIE.ie = UDNEmbedIE()
    UDNEmbedIE.ie.VERSION = '1'
    UDNEmbedIE.ie._downloader.params.update({'noprogress': True})
    UDNEmbedIE.ie._downloader.params.update({'outtmpl': '%(id)s.%(ext)s'})
    print("# Test url: http://video.udn.com/embed/news/300040")
    UDNEmbedIE.ie.extract('http://video.udn.com/embed/news/300040')
    print("# Test url: https://video.udn.com/embed/news/300040")

# Generated at 2022-06-22 08:52:24.284718
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie.params() == {}
    assert ie.working() is True

# Generated at 2022-06-22 08:52:35.602634
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #test with an url in _PROTOCOL_RELATIVE_VALID_URL
    URL = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE.url_result(URL, 'UDNEmbedIE', video_id='300040')
    URL = '//video.udn.com/embed/news/300040'
    UDNEmbedIE.url_result(URL, 'UDNEmbedIE', video_id='300040')
    URL = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE.url_result(URL, 'UDNEmbedIE', video_id='300040')
    #test with an url not in _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:40.609018
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE({})
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._match_id("http://video.udn.com/embed/news/300040") == "300040"
    assert ie._match_id("http://video.udn.com/play/news/300040") == "300040"

# Generated at 2022-06-22 08:52:53.152956
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-22 08:52:54.935426
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-22 08:52:56.396882
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert issubclass(UDNEmbedIE, InfoExtractor)

# Generated at 2022-06-22 08:52:58.876041
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME is not None
    assert ie.IE_DESC is not None
    assert ie._VALID_URL is not None

# Generated at 2022-06-22 08:53:10.072588
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert test._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:53:21.210272
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print (UDNEmbedIE.IE_NAME)
    print (UDNEmbedIE.IE_DESC)
    print (UDNEmbedIE.IE_DESC)
    print (UDNEmbedIE.WEBPAGE_URL_TEMPLATE)
    print (UDNEmbedIE.VALID_URL)
    print (UDNEmbedIE.IE_NAME)
    print (UDNEmbedIE.ie_key())
    print (UDNEmbedIE.ie_keywords())
    print (UDNEmbedIE.ie_url_re())

    test_obj = UDNEmbedIE()
    print (type(test_obj))
    print (test_obj.IE_NAME)
    print (test_obj.IE_DESC)
    print (test_obj.IE_DESC)

# Generated at 2022-06-22 08:53:27.501600
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:54:35.299540
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_config = {
        'class': 'UDNEmbedIE',
        'url': 'https://video.udn.com/embed/news/300040'
    }
    x = globals()[test_config['class']]
    y = x(test_config)
    assert y.ie_key() == 'UDNEmbed'

# Generated at 2022-06-22 08:54:38.855394
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test the constructor of class UDNEmbedIE
    url = UDNEmbedIE._VALID_URL
    UDNEmbedIE(UDNEmbedIE.ie_key(), url)

# Generated at 2022-06-22 08:54:41.150609
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert tester != None

# Generated at 2022-06-22 08:54:45.926519
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'udn'
    assert ie.ie_desc() == '聯合影音'
    # test for method '_real_extract'
    url = 'http://video.udn.com/embed/news/300040'
    assert ie._real_extract(url)

# Generated at 2022-06-22 08:54:51.322083
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE._html_search_regex('', '', '')
        UDNEmbedIE._html_search_regex('', '', '')
    except:
        pass
    return True

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:54:55.819040
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:54:59.316182
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _UDNEmbedIE = UDNEmbedIE(InfoExtractor())
    assert _UDNEmbedIE._PARSER == 'html5lib'


# Generated at 2022-06-22 08:55:04.538874
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    print (obj)

    url = "https://video.udn.com/embed/news/300040"
    print (obj._match_id(url))


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:55:07.915357
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    object_UDNEmbedIE = UDNEmbedIE()
    object_UDNEmbedIE._match_id(url)

# Generated at 2022-06-22 08:55:10.373207
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..test import get_testcases

    for _, _, url in get_testcases(UDNEmbedIE):
        UDNEmbedIE(url)

# Generated at 2022-06-22 08:57:46.927702
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert ie.IE_NAME in ie.ie_key()
    assert ie.IE_NAME in ie.suitable(url)
    # Currently invalid page source
    page = '''
    var options = {"video":{"mp4":"http://video.udn.com/video/mp4/304396.mp4?type=movie"},
                  "images":{"poster":"http://img.udn.com.tw/video/upload/v3/2015/03/07/image/30905777.jpg"}
                  "title":"隨便看看"}
    '''

# Generated at 2022-06-22 08:57:49.664042
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test constructor of class UDNEmbedIE."""
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-22 08:57:55.984152
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://www.test.com/play/news/303776')
    assert ie._match_id('http://www.test.com/play/news/303776') == '303776'
    assert ie._match_id('http://www.test.com/embed/news/303776') == '303776'
    assert ie._match_id('http://www.test.com/embed/news/303776?a=b') == '303776'

# Generated at 2022-06-22 08:58:03.396284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:58:09.244714
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    udnEmbedIE_TestURL = 'http://video.udn.com/embed/news/300040'
    ie.extract(udnEmbedIE_TestURL)
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:58:18.945054
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # 1. Test invalid url.
    # Invalid url should return `None`.
    assert UDNEmbedIE("http://www.udn.com/news/story/6861/1422819-%E7%8F%BE%E7%A5%9E%E7%95%8C%E7%9A%84%E5%8F%B0%E5%8D%97%E6%96%B0%E6%9D%91%E6%8E%A8%E5%A3%B3")._VALID_URL is None

    # 2. Test protocol-relative url.
    # Protocol-relative url should return the protocol-relative url.
    assert UDNEmbedIE("http://video.udn.com/play/news/300040")._PROTOCOL_RELATIVE_

# Generated at 2022-06-22 08:58:22.876922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_class = UDNEmbedIE()
    assert test_class.IE_DESC == '聯合影音'
    assert test_class._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_class._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:58:25.596206
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Constructor test for class UDNEmbedIE."""
    UDNEmbedIE()

# Generated at 2022-06-22 08:58:31.695741
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('example.com')
    assert ie.IE_NAME =="udn"
    assert ie.IE_DESC == "聯合影音"
    assert ie._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert ie._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-22 08:58:35.746653
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    wanted_url = 'https://video.udn.com/embed/news/300040'
    url_test = 'http:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert wanted_url == ie._real_extract(url_test)