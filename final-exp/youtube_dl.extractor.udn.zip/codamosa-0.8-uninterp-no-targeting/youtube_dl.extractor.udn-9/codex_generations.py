

# Generated at 2022-06-22 08:49:49.211619
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    embed = UDNEmbedIE()
    embed._match_id(None)

# Generated at 2022-06-22 08:49:51.328855
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = '//video.udn.com/embed/news/300040'
    UDNEmbedIE()._match_id(url)

# Generated at 2022-06-22 08:49:53.138026
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = InfoExtractor("Unit test for constructor of class UDNEmbedIE")
    assert obj != None


# Generated at 2022-06-22 08:50:04.641745
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test = UDNEmbedIE('UDNEmbedIE')

    # the first of _TESTS
    url = 'http://video.udn.com/embed/news/300040'
    expected = '300040'
    unit_test.url = url
    video_id = unit_test._match_id(url)
    assert video_id == expected

    # the second of _TESTS
    url = 'http://video.udn.com/embed/news/300040'
    expected = '300040'
    unit_test.url = url
    video_id = unit_test._match_id(url)
    assert video_id == expected

    # the third of _TESTS
    url = 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-22 08:50:07.153051
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udni = UDNEmbedIE('test-ie')
    assert udni is not None

# Generated at 2022-06-22 08:50:09.578146
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:50:10.687328
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:50:17.407734
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS

# Generated at 2022-06-22 08:50:19.212278
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbedIE').to_screen('show case')

# Unit test

# Generated at 2022-06-22 08:50:28.663796
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert ie._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-22 08:50:43.760379
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test constructor of class UDNEmbedIE
    """
    # Constructor of class UDNEmbedIE should not raise any exception
    try:
        UDNEmbedIE()
    except Exception as ex:
        assert False, "Failed due to unexpected exception: " + str(ex)

# Generated at 2022-06-22 08:50:44.780545
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'video.udn.com:embed'

# Generated at 2022-06-22 08:50:47.731089
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/123').to_screen()

# Generated at 2022-06-22 08:50:55.556466
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_NAME == 'video.udn.com'
    assert UDNEmbedIE().IE_DESC == '聯合影音'
    assert UDNEmbedIE()._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:50:57.719745
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj._PROTOCOL_RELATIVE_VALID_URL
    obj._VALID_URL

# Generated at 2022-06-22 08:50:58.576552
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie

# Generated at 2022-06-22 08:51:01.015714
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('udn', 'http://video.udn.com/embed/news/300040')
    UDNEmbedIE('udn', 'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:51:07.781177
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    # the above url is extracted from 'http://video.udn.com/embed/news/300040' which is used to test extractor.
    ie._real_extract('http://video.udn.com/embed/news/300040')
    # the above url is extracted from 'http://video.udn.com/embed/news/300040' which is used to test extractor.

# Generated at 2022-06-22 08:51:20.070831
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert ie.__class__.__name__ == 'UDNEmbedIE', \
        'UDNEmbedIE class is used for this test'
    # example: https://video.udn.com/embed/news/300040
    test_urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        '//video.udn.com/embed/news/300040'
    ]
    for test_url in test_urls:
        print('test URL: ' + test_url)
        result = ie.suitable(test_url)
        assert result, 'suitable failed for test URL: ' + test_url
        result = ie.get_video_info

# Generated at 2022-06-22 08:51:26.529036
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    __name__ = '__main__'
    url = 'https://video.udn.com/play/news/303776'
    print('test_udn_embed_constructor:')
    print(UDNEmbedIE()._match_id(url))
    print(UDNEmbedIE()._real_extract(url))



# Generated at 2022-06-22 08:51:54.746218
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    assert isinstance(udneie, UDNEmbedIE)
    assert isinstance(udneie, InfoExtractor)


# Generated at 2022-06-22 08:52:00.912528
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from security import check_type_test, check_property_test, check_value_test

    # Test 1. basic test
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL
    correct_UDN_ie = UDNEmbedIE(UDNEmbedIE._VALID_URL, UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    check_type_test(UDNEmbedIE, correct_UDN_ie, 'IE_CODE', 'UDNEmbed')

# Generated at 2022-06-22 08:52:04.002269
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:52:08.165391
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    

# test_UDNEmbedIE()

# Generated at 2022-06-22 08:52:16.397089
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class `UDNEmbedIE`"""

    # If not using `media` option,
    # test case with site URL of video segment rather than video URL

    from ..downloader import common
    from ..utils import DEFAULT_HEADERS

    common.HEADERS = DEFAULT_HEADERS
    common.HEADERS.update({'Accept-Language': 'zh-TW'})

    # Constructor of class InfoExtractor

# Generated at 2022-06-22 08:52:19.484533
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    info_dicts = ie._real_extract('http://video.udn.com/embed/news/300040')
    assert info_dicts['id'] == '300040'
    assert info_dicts['ext'] == 'mp4'
    assert info_dicts['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-22 08:52:23.968313
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("UDNEmbedIE", "UDN影音", "聯合影音")

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:52:35.424089
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:52:40.310524
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test case for the UDNEmbedIE constructor.
    # Arguments:
    #     test_info_dict (dict): test case info dictionary
    # Return:
    #     UDNEmbedIE (class): UDNEmbedIE instance

    ie_instance = UDNEmbedIE()
    assert isinstance(ie_instance, InfoExtractor)

# Generated at 2022-06-22 08:52:48.985522
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()

    assert udne._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:53:23.457164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Protocol-relative URL
    match_obj = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match('//video.udn.com/embed/news/300040')
    assert match_obj
    assert match_obj.group('id') == '300040'
    # Valid URL
    match_obj = UDNEmbedIE._VALID_URL.match('http://video.udn.com/embed/news/300040')
    assert match_obj
    assert match_obj.group('id') == '300040'
    # URL contains protocol-relative URL
    match_obj = UDNEmbedIE._VALID_URL.match('http://video.udn.com/embed/news/300040?key=//video.udn.com/embed/news/300040')
    assert match_obj

# Generated at 2022-06-22 08:53:29.359798
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)._valid_url('http://video.udn.com/embed/news/300040', ['info', 'ext']) == True
    UDNEmbedIE(None)._valid_url('http://video.udn.com/play/news/300040', ['info', 'ext']) == True
    UDNEmbedIE(None)._valid_url('http://not_valid.com/not_valid/300040', ['info', 'ext']) == False

# Generated at 2022-06-22 08:53:31.778815
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_str = 'https://video.udn.com/embed/news/300040'
    b = UDNEmbedIE()
    print(b)
    b._real_extract(url_str)

# Generated at 2022-06-22 08:53:37.123208
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    import unittest

    if sys.version_info < (3, 4):
        return

    class UDNEmbedIETest(unittest.TestCase):
        def test_constructor(self):
            UDNEmbedIE()

    unittest.main()

# Generated at 2022-06-22 08:53:46.402604
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test "UdnVideoIE"
    assert UdnVideoIE._VALID_URL == 'https?:\\/\\/video\\.udn\\.com\\/news\\/(?P<id>\\d+)'

# Generated at 2022-06-22 08:53:53.101350
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    u1 = 'http://video.udn.com/embed/news/300040'
    u2 = 'https://video.udn.com/embed/news/300040'
    u3 = 'https://video.udn.com/play/news/303776'
    ie = UDNEmbedIE()
    assert ie._match_id(u1) == '300040'

# Generated at 2022-06-22 08:53:57.763427
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Test UDNEmbedIE")
    print("- Test _real_extract")
    URLS_test_real_extract = [
        "http://video.udn.com/embed/news/300040",
        "http://video.udn.com/embed/news/300040",
        "http://video.udn.com/embed/news/300040",
    ]
    for i, URL in enumerate(URLS_test_real_extract):
        print("Testing URL: " + URL)
        udnerie_test = UDNEmbedIE()
        print(udnerie_test._real_extract(URL))
    print("Test done.")
    print("All test done.")
    print("")

# Run test

# Generated at 2022-06-22 08:54:00.389969
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().suitable(url)
    assert UDNEmbedIE()._match_id(url) == '300040'

# Generated at 2022-06-22 08:54:02.399837
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

# Generated at 2022-06-22 08:54:06.222247
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert test._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:55:04.738751
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check the normal case
    assert(UDNEmbedIE._match_id('http://video.udn.com/embed/news/300040') == '300040')
    # Check the case which begins with https
    assert(UDNEmbedIE._match_id('https://video.udn.com/embed/news/300040') == '300040')
    # Check the case which begins with https and www
    assert(UDNEmbedIE._match_id('https://www.video.udn.com/embed/news/300040') == '300040')
    # Check the case which begins with protocol_relative
    assert(UDNEmbedIE._match_id('//video.udn.com/embed/news/300040') == '300040')
    # Check the case which begins with protocol_relative and https

# Generated at 2022-06-22 08:55:10.688797
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video = UDNEmbedIE()._real_extract(url)

    assert video['id'] == '300040'
    assert video['title'] == '生物老師男變女 全校挺"做自己"'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:55:11.527474
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None);

# Generated at 2022-06-22 08:55:19.417930
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:55:29.657988
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    ie_obj = UDNEmbedIE()
    assert ie_obj.ie_key() == 'udn'
    assert ie_obj.ie_desc() == '聯合影音'
    assert ie_obj._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie_obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:55:33.581196
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    ue = UDNEmbedIE()
    IE_DESC = "聯合影音"
    assert ue.IE_DESC == IE_DESC

# Generated at 2022-06-22 08:55:36.252020
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-22 08:55:38.856889
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    inst.IE_NAME = 'testname'
    assert inst.IE_NAME == 'testname' and inst.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:55:42.118525
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'



# Generated at 2022-06-22 08:55:45.423070
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.get_protocol_relative_url_regex() == obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:58:14.172298
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case = [{
        'url': 'http://video.udn.com/embed/news/300040',
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
    }, {
        'url': 'https://video.udn.com/embed/news/300040',
        'id': '300040',
    }]
    for case in test_case:
        result = UDNEmbedIE()._real_extract(case['url'])
        assert result['id'] == case['id']
        if 'ext' in case:
            assert result['ext'] == case['ext']

# Generated at 2022-06-22 08:58:15.245310
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None) is not None

# Generated at 2022-06-22 08:58:23.993897
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie=UDNEmbedIE()
    #just test assign a string to UDNEmbedIE,no need to download a webpage
    udn_embed_ie._download_webpage=lambda x,y: '<html><head>'
    html_with_options = '<html><head>'

# Generated at 2022-06-22 08:58:28.237773
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-22 08:58:38.990987
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:58:47.812804
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:58:49.073385
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert isinstance(udn_embed_ie, InfoExtractor) == True

# Generated at 2022-06-22 08:58:50.381195
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()
    y = UDNEmbedIE()
    assert x == y
    assert x is y

# Generated at 2022-06-22 08:58:51.200711
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE(None)
    assert udn is not None

# Generated at 2022-06-22 08:58:55.229315
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie)

if __name__ == "__main__":
    test_UDNEmbedIE()