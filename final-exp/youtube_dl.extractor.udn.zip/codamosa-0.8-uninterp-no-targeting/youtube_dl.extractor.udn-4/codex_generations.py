

# Generated at 2022-06-22 08:49:57.903084
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:50:05.958901
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE();
    if udn_embed_ie.IE_NAME != 'udnEmbed':
        print("the 'IE_NAME' property is not equal to 'udnEmbed'.");
    if udn_embed_ie.IE_DESC != '聯合影音':
        print("the 'IE_DESC' property is not equal to '聯合影音'.");

# Generated at 2022-06-22 08:50:17.145134
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Testing UDNEmbedIE.__init__()")
    # from .common import list_ies
    # for ie in list_ies():
    #     if ie.IE_NAME == 'Udn':
    #         print(ie)
    #         break
    # return
    # check if it has the attribute IE_NAME
    assert UDNEmbedIE.IE_NAME == "Udn"
    # check if it has the attribute IE_DESC
    assert UDNEmbedIE.IE_DESC == "聯合影音"
    # check if it has the attribute _VALID_URL
    assert UDNEmbedIE._VALID_URL
    # check if it has the attribute _TESTS
    assert UDNEmbedIE._TESTS
    # check if it has the attribute _PROT

# Generated at 2022-06-22 08:50:25.705131
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()
	assert ie.IE_DESC == '聯合影音'
	assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
	assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
	assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
	assert ie._TESTS[0]['info_dict']['id'] == '300040'
	assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:50:31.288219
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()
    assert class_UDNEmbedIE.name == 'udn'
    assert class_UDNEmbedIE.ie_key() == 'UDNEmbed'
    assert class_UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:50:32.238584
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-22 08:50:37.097007
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:50:43.493492
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    self.assertEqual(ie._VALID_URL, 'https?://video\.udn\.com/(?:embed|play)/news/(\\d+)')
    self.assertEqual(ie._PROTOCOL_RELATIVE_VALID_URL, '//video\.udn\.com/(?:embed|play)/news/(\\d+)')
    self.assertEqual(ie.IE_DESC, '聯合影音')


# Generated at 2022-06-22 08:50:45.156474
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()()
# end of test for constructor of class UDNEmbedIE


# Generated at 2022-06-22 08:50:56.888560
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for protocol relative URL
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Test for valid URLs
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

    # Test for match IDs
    class FakeUDNEmbedIE:
        def _match_id(url):
            mobj = re.match(UDNEmbedIE._VALID_URL, url)
            return '%s' % mobj.group('id')

    # Test for get video IDs

# Generated at 2022-06-22 08:51:05.577210
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == 'https?:' + UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:51:16.820778
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    re_protocol_relative_url = ie._PROTOCOL_RELATIVE_VALID_URL
    re_protocol_relative_url_match = re.match(re_protocol_relative_url, '//video.udn.com/embed/news/300040')
    assert re_protocol_relative_url_match is not None
    assert re_protocol_relative_url_match.groupdict()
    
    valid_url = ie._VALID_URL
    valid_url_match = re.match(valid_url, 'https://video.udn.com/embed/news/300040')
    assert valid_url_match is not None
    assert valid_url_match.groupdict()

# Generated at 2022-06-22 08:51:23.030257
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url in [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        '//video.udn.com/embed/news/300040',
    ]:
        print('===' + url)
        ie = UDNEmbedIE(url)
        IE_DESC = ie.IE_DESC
        print(ie._VALID_URL)


# Generated at 2022-06-22 08:51:25.249118
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    check_unit_test_for_IE(inst)

# Generated at 2022-06-22 08:51:32.697874
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .common import ExtractorError
    from .common import unescapeHTML

    i = InfoExtractor(UDNEmbedIE())

    # Test regular video
    # test_url = 'http://video.udn.com/embed/news/300040'
    # info = i._real_extract(test_url)
    # assert(info['id'] == '300040')
    # assert(info['title'] == u'生物老師男變女 全校挺”做自己”')
    # assert(info['thumbnail'] is not None)

    # Test youtube video
    test_url = 'http://video.udn.com/embed/news/303776'
    info = i._real_ext

# Generated at 2022-06-22 08:51:39.306329
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    # test _PROTOCOL_RELATIVE_VALID_URL with '//'
    print(udneie._PROTOCOL_RELATIVE_VALID_URL)
    print(udneie._VALID_URL)
    print(udneie._TESTS)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:51:50.846190
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://www.udn.com/')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:57.750107
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    from ..utils import extract_attributes

    # Test setting up class instance
    UDNEmbedIE()._build_class_attributes()

    try:
        attributes = extract_attributes(UDNEmbedIE())

        for attr in ('IE_NAME', '_VALID_URL', 'IE_DESC'):
            assert(attributes[attr] is not None)
    except Exception as e:
        raise ValueError("The UDNEmbedIE.__init__() method has an exception.\n", e)

# Generated at 2022-06-22 08:52:00.327706
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE = UDNEmbedIE('test')
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:52:05.403331
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None)._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE(None)._VALID_URL == r'https?:' + UDNEmbedIE(None)._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:19.930288
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-22 08:52:31.416306
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r = UDNEmbedIE()
    assert r.IE_DESC == '聯合影音'
    assert r._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert r._VALID_URL == r'https?:' + r._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:33.890684
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert 'UDNEmbedIE' == u.IE_NAME

# Generated at 2022-06-22 08:52:37.957009
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    regex = re.compile(r'^http(s)?://')

# Generated at 2022-06-22 08:52:40.805740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE"""
    from .youtube import YoutubeIE
    assert UDNEmbedIE.ie_key() == 'udn'
    assert UDNEmbedIE.ie_key() == YoutubeIE.ie_key()

# Generated at 2022-06-22 08:52:53.322219
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    uDNEmbedIE = UDNEmbedIE()
    assert uDNEmbedIE.IE_DESC == '聯合影音'
    assert len(uDNEmbedIE._TESTS) == 3
    assert uDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert uDNEmbedIE._VALID_URL == 'https?:' + uDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert '//video.udn.com/play/news/303776' in uDNEmbedIE._VALID_URL

# Generated at 2022-06-22 08:53:04.227900
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    from .youtube import YoutubeIE
    youtube_ie = YoutubeIE()
    udn_embed_ie.to_screen( 'test can be passed.' )
    assert( udn_embed_ie._match_id('1') == '1' )
    assert( udn_embed_ie._match_id('') is None )
    assert( udn_embed_ie._match_id('http://video.udn.com/embed/news/300040') == '300040')
    assert( udn_embed_ie._match_id('') is None )

# Generated at 2022-06-22 08:53:05.932942
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/play/news/303776')

# Generated at 2022-06-22 08:53:16.780325
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import io
    import json
    import base64

    options_str = ''
    with io.open('test/testdata/udn-options.js', 'r', encoding='utf-8') as options_file:
        options_str = options_file.read()

    trans_options_str = ''
    with io.open('test/testdata/udn-options-trans.js', 'r', encoding='utf-8') as trans_options_file:
        trans_options_str = trans_options_file.read()

    trans_options = json.loads(trans_options_str)

    try:
        # Test the constructor of class UDNEmbedIE
        udne = UDNEmbedIE()
    except:
        assert False

    # Test the _real_extract()

# Generated at 2022-06-22 08:53:22.483457
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udni = UDNEmbedIE()
    print(udni)
    assert udni.IE_NAME == 'udn'
    assert udni.IE_DESC == '聯合影音'
    assert udni._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:53:57.174628
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Purpose: test whether instantiation is successful
    Pre-conditions:
        1. url is a string
        2. ie_key is a string
    Post-conditions:
        1. instantiation is successful
    Return:
        True if  instantiation is successful; False otherwise
    """
    url = 'http://video.udn.com/embed/news/300040'
    ie_key = 'UDNEmbed'

    udn_embed_ie = UDNEmbedIE(url)
    if udn_embed_ie.ie_key == ie_key:
        return True
    return False

# Generated at 2022-06-22 08:54:08.828607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:54:17.107425
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._check_valid_url('http://video.udn.com/embed/news/300040')
    assert ie._check_valid_url('//video.udn.com/embed/news/300040')
    assert ie._check_valid_url('https://video.udn.com/play/news/303776')
    assert ie._check_valid_url('https://video.udn.com/embed/news/300040')
    assert not ie._check_valid_url('https://video.udn.com/embed/news/300040/')
    assert not ie._check_valid_url('https://video.udn.com/embed/abnormal/300040')

# Generated at 2022-06-22 08:54:21.293395
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:54:29.508930
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:54:30.667699
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """test for constructor of class UDNEmbedIE"""
    UDNEmbedIE()


# Generated at 2022-06-22 08:54:32.666356
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for class UDNEmbedIE"""

    # Check for successfully constructed object
    UDNEmbedIE(None)

# Generated at 2022-06-22 08:54:35.086476
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE.construct_ie()
    assert ie.IE_NAME == 'udn'



# Generated at 2022-06-22 08:54:41.814088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	""" test for constructor of class UDNEmbedIE """
	# get/check name
	assert UDNEmbedIE.ie_key() == 'udn_embed'
	assert UDNEmbedIE.ie_name() == '聯合影音'
	assert UDNEmbedIE.ie_desc() == '聯合影音'

# Generated at 2022-06-22 08:54:47.597344
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ('https:'+ UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL) == ie._VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert ie._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-22 08:56:01.769917
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

    valid_urls = (
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/303776',
    )
    i = 0
    for url in valid_urls:
        print('url is %s' % url)
        result = ie.suitable(url)
        assert result is not None, 'url %s is considered not suitable by ie.suitable()' % url

        match_id = ie.match_id(url)

# Generated at 2022-06-22 08:56:09.950919
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()

    assert udne._PROTOCOL_RELATIVE_VALID_URL == u'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == u'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL
    assert udne._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udne._TESTS[0]['info_dict']['id'] == '300040'
    assert udne._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:56:13.816625
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert(udnei.IE_NAME == 'udn')
    assert(udnei.IE_DESC == '聯合影音')

# Generated at 2022-06-22 08:56:17.084754
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:56:21.306607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:56:29.559664
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    expected = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }
    udneie = UDNEmbedIE()
    actual = udneie._real_extract(url)
    for key in expected:
        assert expected[key] == actual[key]

# Generated at 2022-06-22 08:56:39.364410
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    URL = 'https://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == r'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL
    assert udne._match_id(URL) == '300040'
    assert udne._real_extract(URL) is not None
    assert udne._TESTS[0]['url'] == URL

# Generated at 2022-06-22 08:56:40.879526
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        unit = UDNEmbedIE()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-22 08:56:46.119527
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == "UDNEmbedIE"
    assert ie.IE_DESC == "聯合影音"
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:56:54.533841
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        int_or_none,
        js_to_json,
    )
    from ..compat import compat_urlparse


    class UDNEmbedIE(InfoExtractor):
        IE_DESC = '聯合影音'
        _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
        _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:59:29.967338
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    match = udne._VALID_URL.match(url)
    udne._real_extract(url)
    assert (match)

# Generated at 2022-06-22 08:59:36.511913
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # different URL patterns
    url1 = 'http://video.udn.com/embed/news/300040'
    url2 = 'https://video.udn.com/embed/news/300040'
    url3 = 'http://video.udn.com/play/news/300040'
    url4 = 'https://video.udn.com/play/news/300040'
    url5 = 'http://video.udn.com/news/300040'

    assert UDNEmbedIE.suitable(url1)
    assert UDNEmbedIE.suitable(url2)
    assert UDNEmbedIE.suitable(url3)
    assert UDNEmbedIE.suitable(url4)
    assert not UDNEmbedIE.suitable(url5)

    # correct ID extracted

# Generated at 2022-06-22 08:59:43.810231
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_NAME == 'udn'
    assert udn_ie.IE_DESC == '聯合影音'
    assert udn_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

if __name__ == '__main__':
    test_UDNEmbedIE()