

# Generated at 2022-06-22 08:49:58.135614
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    p = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    m = p.match(url)
    expect_id = m.group('id')
    assert expect_id == "300040"

    values = UDNEmbedIE._get_info_dict(url)
    assert values['IE_DESC'] == "聯合影音"
    assert values['_VALID_URL'] == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:00.252967
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-22 08:50:03.333953
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    udn_embed_ie_instance = ie.construct_UDNEmbedIE_instance()
    assert udn_embed_ie_instance is ie

# Generated at 2022-06-22 08:50:14.388913
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:18.280132
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.__name__ = "UDNEmbedIE"
    obj = UDNEmbedIE("https://video.udn.com/embed/news/300040")
    obj._real_extract("https://video.udn.com/embed/news/300040")

# Generated at 2022-06-22 08:50:29.352834
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert list(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL) == ['//video.udn.com/(?:embed|play)/news/(?P<id>\d+)']
    assert udn_embed_ie._VALID_URL == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:30.576766
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:50:33.710776
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    from contextlib import closing

    # Test reading argument from stdin
    with closing(sys.stdin):
        arg = sys.stdin.read()
        print("You typed: ")
        print(arg)

    # Test instantiating
    UdnVideo = UDNEmbedIE('qtcs')

# Generated at 2022-06-22 08:50:34.884087
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL



# Generated at 2022-06-22 08:50:38.519446
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.IE_DESC
    ie._PROTOCOL_RELATIVE_VALID_URL
    ie._VALID_URL
    ie._TESTS
    ie._real_extract

# Generated at 2022-06-22 08:50:53.558970
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.ie_key()).create_ie()

# Generated at 2022-06-22 08:51:00.234398
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    t = re.compile(udne._PROTOCOL_RELATIVE_VALID_URL)
    url = 'http://video.udn.com/embed/news/300040'
    assert t.match(url)
    url1 = 'https://video.udn.com/play/news/300040'
    assert t.match(url1)
    url2 = 'http://video.udn.com/play/news/300040'
    assert t.match(url2)

# Generated at 2022-06-22 08:51:02.150286
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:13.830688
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:51:15.593789
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

# Generated at 2022-06-22 08:51:18.663772
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE('http://video.udn.com/embed/news/300040')
        UDNEmbedIE('https://video.udn.com/play/news/300040')
    except:
        assert False, 'Constructor of class UDNEmbedIE raise error.'
    else:
        assert True


# Generated at 2022-06-22 08:51:21.334675
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test method for constructor of class UDNEmbedIE
    """
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:26.911543
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check A
    obj = UDNEmbedIE()
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == 'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:51:29.333897
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie
    assert udn_embed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:36.888783
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('some_id')
    assert ie.IE_NAME == 'udn_embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:51.207773
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE('udnembed')
    assert x is not None

# Generated at 2022-06-22 08:51:57.027006
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert(udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udn._VALID_URL == r'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-22 08:52:08.166961
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:11.702275
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE."""
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'udn'
    assert ie.ie_desc() == '聯合影音'

# Generated at 2022-06-22 08:52:22.854931
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    temp_IE = UDNEmbedIE()
    # Example 1: test _PROTOCOL_RELATIVE_VALID_URL
    test_url = '//video.udn.com/play/news/300040'
    temp_IE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert temp_IE._match_id(test_url) == '300040'
    # Example 2: test _VALID_URL
    test_url = 'https://video.udn.com/embed/news/300040'
    temp_IE._VALID_URL = r'https?:' + temp_IE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:28.906261
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == "聯合影音"
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:52:39.368055
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    data = {'options':
                {'video':
                     {'mp4': '/news/300040/mp4?ver=5',
                      'm3u8': '/news/300040/m3u8?ver=5',
                      'youtube': 'https://www.youtube.com/watch?v=7VJskXmOhdY'
                      },
                 'title': '生物老師男變女 全校挺"做自己"',
                 'poster': '//v.udn.com.tw/upfiles/news/my_video/pictures/2018/04/18/s_303776_B.jpg'
                 }
            }

# Generated at 2022-06-22 08:52:49.566113
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # Test valid URL
    url = 'http://video.udn.com/embed/news/300040'
    assert ie.suitable(url) is True
    assert ie.IE_NAME in ie.extract_info(url)

    # Test invalid URL
    url = 'http://video.udn.com/play/news/300040'
    assert ie.suitable(url) is False
    assert ie.IE_NAME not in ie.extract_info(url)

    # Test _real_initialize()
    assert ie._real_initialize() is None

# Generated at 2022-06-22 08:52:59.341998
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.get_url()
    # unit test for function get_all_urls()
    assert ie.get_all_urls()
    assert ie.get_num_urls()
    # unit test for functions download, extract and extract_all
    assert ie.download('https://video.udn.com/embed/news/300040')
    assert ie.extract('https://video.udn.com/embed/news/300040')
    assert ie.extract_all('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:53:04.228295
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE(url)
    assert udn_embed_ie.extract() == '300040'

# Generated at 2022-06-22 08:53:33.547671
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-22 08:53:38.321462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    t = UDNEmbedIE()
    assert(t.IE_DESC == '聯合影音')
    assert(t._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')


# Generated at 2022-06-22 08:53:45.158967
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('[unit test] UDNEmbedIE is called')

    from .common import InfoExtractor
    from .common import InfoExtractor
    from ..compat import compat_urllib_request
    import urllib
    import urllib.request
    import json
    import sys
    import os
    try:
        from urllib2 import urlopen
    except ImportError:
        from urllib.request import urlopen
    try:
        from urlparse import urlparse
    except ImportError:
        from urllib.parse import urlparse



# Generated at 2022-06-22 08:53:46.008015
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()

# Generated at 2022-06-22 08:53:49.479018
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL.startswith('https?:')
    assert ie._PROTOCOL_RELATIVE_VALID_URL.startswith('//')
    assert ie._TESTS

# Generated at 2022-06-22 08:53:58.452715
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    test_url = "http://video.udn.com/embed/news/300040"
    assert udn_embed_ie.suitable(test_url)
    (video_id, webpage_url) = udn_embed_ie._get_video_id(test_url)
    assert webpage_url == test_url
    assert video_id == "300040"
    assert udn_embed_ie.IE_NAME == "UDNEmbed"
    assert udn_embed_ie.IE_DESC == "聯合影音"

# Generated at 2022-06-22 08:54:01.769029
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # construct with an invalid format_url
    assert ie._match_id(None) == None

# Generated at 2022-06-22 08:54:02.824530
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-22 08:54:08.081387
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:54:14.330440
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    t = UDNEmbedIE()
    assert t._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert t._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert t.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:55:16.525673
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from unittest import TestCase
    import youtube_dl

    class TestUDNEmbedIE(TestCase):
        def test_language(self):
            self.assertEqual(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

    TestUDNEmbedIE().test_language()


# Generated at 2022-06-22 08:55:26.552525
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._parse_json('{"title":"生物老師男變女 全校挺\"做自己\""}', "title") == '生物老師男變女 全校挺"做自己"'
    assert ie._parse_json('{"title":"生物老師男變女 全校挺\u201c做自己\u201d"}', "title") == '生物老師男變女 全校挺“做自己”'

# Generated at 2022-06-22 08:55:33.216954
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert isinstance(udne, InfoExtractor)
    assert udne.IE_DESC == '聯合影音'
    assert re.match(udne._PROTOCOL_RELATIVE_VALID_URL,
        '//video.udn.com/embed/news/300040')
    assert re.match(udne._VALID_URL,
        'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:55:43.903335
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_cases = (
        {
            'url': 'http://video.udn.com/embed/news/300040',
            'expected': {
                'id': '300040',
                'ext': 'mp4',
                # "英雄" => "英雄鄭南榕被陷害殺害案 立委爭取重新調查"
                'title': '英雄鄭南榕被陷害殺害案 立委爭取重新調查',
                'thumbnail': None,
            },
        },
    )

# Generated at 2022-06-22 08:55:52.174638
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    # Due to _TESTS is empty, we need to provide some extra information
    ie.set_test()
    ie.add_default_info_extractors()
    # Now, we are able to extract video information
    video_information = ie.extract(url)
    assert video_information['url'] == url
    assert video_information['title'] == '生物老師男變女 全校挺"做自己"'
    assert video_information['id'] == '300040'


# Generated at 2022-06-22 08:55:58.617210
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    print('test success')

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:56:02.931303
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    json_str = ie._download_webpage("http://video.udn.com/embed/news/300040", None)
    print(json_str)
#


# Generated at 2022-06-22 08:56:08.182221
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id(r'http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id(r'//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id(r'//video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-22 08:56:18.661806
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test known case
    #assert(UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    #assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

    # test that some elements of _TESTS is correct
    unitTestUDNEmbedIE = UDNEmbedIE(InfoExtractor())
    for test in unitTestUDNEmbedIE._TESTS:

        # For test[url], assert that it matches UDNEmbedIE._VALID_URL
        url = test['url']

# Generated at 2022-06-22 08:56:27.739497
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert (UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL ==
            r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert (UDNEmbedIE._VALID_URL ==
            r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE.__name__ == 'UDNEmbedIE'



# Generated at 2022-06-22 08:59:04.539733
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert re.search(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, ie._VALID_URL)

# Generated at 2022-06-22 08:59:05.650020
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    UDNEmbedIE(sys.argv[1])

# Generated at 2022-06-22 08:59:09.048000
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Matching URL
    UDNEmbedIE(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    # Non-matching URL
    assert not UDNEmbedIE("https://video.udn.com/news/300000")


# Generated at 2022-06-22 08:59:12.973521
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_initialize()
    expected_id = '300040'
    assert UDNEmbedIE()._real_extract(url)['id'] == expected_id

# Generated at 2022-06-22 08:59:14.473180
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:59:25.312912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Unit test for constructor of class UDNEmbedIE

    '''

# Generated at 2022-06-22 08:59:26.469477
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbed = UDNEmbedIE()
    print(UDNEmbed)

# Generated at 2022-06-22 08:59:27.318311
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-22 08:59:28.223523
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	assert(UDNEmbedIE is not None)

# Generated at 2022-06-22 08:59:31.368755
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040?callback=jsonp_11'
    UDNEmbedIE()._real_extract(url)