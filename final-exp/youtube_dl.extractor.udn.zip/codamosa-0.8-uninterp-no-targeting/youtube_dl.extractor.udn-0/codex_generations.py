

# Generated at 2022-06-22 08:49:48.701452
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('https://video.udn.com/play/news/303776')

# Generated at 2022-06-22 08:49:50.994505
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    UDNEmbedIE() constructor should be able to create an object
    """
    instance = UDNEmbedIE()
    assert instance

# Generated at 2022-06-22 08:49:55.620799
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == r'https?:' + UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:49:59.712989
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    print(instance.IE_NAME)
    assert instance.IE_NAME == 'udn'

# Generated at 2022-06-22 08:50:06.191496
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test match_id function
    udn_ie = UDNEmbedIE()
    assert udn_ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert udn_ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    # test extractor
    assert '300040' in udn_ie.extract('https://video.udn.com/embed/news/300040')
    assert '300040' in udn_ie.extract('//video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:50:08.427896
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor) == True


# Generated at 2022-06-22 08:50:19.121524
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test class constructor with valid url
    ie = UDNEmbedIE('http://video.udn.com/embed/news/303776')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test class constructor with valid url
    ie = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test class constructor with invalid url
    ie = UDNEmbedIE('http://video.udn.com/embed/')
    assert ie._VALID_URL is None
    # Test class constructor with invalid url


# Generated at 2022-06-22 08:50:24.678740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:35.801058
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'  # From https://video.udn.com/news/303776
    udne = UDNEmbedIE()
    match = udne._PROTOCOL_RELATIVE_VALID_URL
    # (MatchObject, str, unicode) if it matches, None otherwise.
    mo, scheme, authority = udne._match_host(match, url)
    assert mo is None
    mo, scheme, authority = udne._match_host(match, 'http://video.udn.com/embed/news/300040')
    assert mo.groupdict() == {'id': '300040'}

    udne._match_id(url)
    udne.IE_NAME
    udne.IE_DESC

# Generated at 2022-06-22 08:50:38.246869
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    n = UDNEmbedIE()
    n.to_screen(url='http://video.udn.com/embed/news/300040', verbose=False)
    n.download(url='http://video.udn.com/embed/news/300040', verbose=False)

# Generated at 2022-06-22 08:50:51.453754
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:50:54.738121
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-22 08:51:02.188820
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)' 
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:51:04.761911
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE()
    assert tester.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:08.063610
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('UDN')
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'UDN'
    assert ie.ie_desc() == '聯合影音'

# Generated at 2022-06-22 08:51:12.021897
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    def test_UDNEmbedIE_get_ua():
        result = com.UDNEmbedIE._get_ua()
        if result != "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0;":
            print("result = %s" % result)
            assert False

    test_UDNEmbedIE_get_ua()

# Generated at 2022-06-22 08:51:15.279266
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    video_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    ie.extract(video_url)

# Generated at 2022-06-22 08:51:16.669420
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:21.014888
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert udnie.suitable(url)
    assert udnie._VALID_URL == 'https?:' + udnie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:51:30.470245
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:51:43.029299
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("UDNEmbedIE", "UDNEmbedIE")

# Generated at 2022-06-22 08:51:49.377494
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._VALID_URL == ie._TESTS[0]['url']

# Generated at 2022-06-22 08:51:57.154009
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

    # Test url matching
    url = 'http://video.udn.com/embed/news/300040'
    match = ie._PROTOCOL_RELATIVE_VALID_URL.match(url)
    assert match
    assert match.group('id') == '300040'
    assert match.group('id') == ie._match_id(url)
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert r'https?://video\.udn\.com/(?:embed|play)/news/\d+' == ie._VALID_URL
    assert ie.su

# Generated at 2022-06-22 08:52:00.647605
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # construction:
    ie = UDNEmbedIE()
    # method:
    ie.extract('http://video.udn.com/embed/news/300127')

# Generated at 2022-06-22 08:52:03.309116
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie._match_id(url) == '300040'

# Generated at 2022-06-22 08:52:05.891113
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Check class UDNEmbedIE can be constructed
    """
    assert hasattr(UDNEmbedIE, '_real_extract')

test_UDNEmbedIE()

# Generated at 2022-06-22 08:52:15.037238
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE(): 
    ie = UDNEmbedIE()
    assert ie.IE_DESC == "聯合影音"
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0] == {
        'url': 'https://video.udn.com/embed/news/300040',
        'only_matching': True,
    }

# Generated at 2022-06-22 08:52:16.478778
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:52:17.827131
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:52:19.331680
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO: remove this unit test after #1
    UDNEmbedIE(UDNEmbedIE._VALID_URL, UDNEmbedIE._TESTS[0]['url'])

# Generated at 2022-06-22 08:52:44.819268
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:52:46.006352
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:52:48.508839
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    res = UDNEmbedIE()
    test = res.IE_DESC
    assert(test == '聯合影音')

# Generated at 2022-06-22 08:52:57.286084
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    module = __import__(__name__)
    IE = module.UDNEmbedIE
    ie = IE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(ie._TESTS) > 0
    assert ie.__name__ == 'UDNEmbedIE'

# Generated at 2022-06-22 08:53:00.923464
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .udn import UDNEmbedIE
    ie = InfoExtractor.infoExtractorFactory('http://video.udn.com/embed/news/300040')
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-22 08:53:05.268795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _UDNEmbedIE = UDNEmbedIE()
    _UDNEmbedIE._real_extract("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-22 08:53:08.796704
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    vid = '300040'

    url = 'http://video.udn.com/embed/news/' + vid
    UDNEmbedIE()._real_extract(url)



# Generated at 2022-06-22 08:53:19.525318
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:53:24.579551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _UDNEmbedIE = UDNEmbedIE()
    _UDNEmbedIE._real_extract('http://video.udn.com/embed/news/300040')
    _UDNEmbedIE._real_extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:53:25.794000
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Instance defined using class UDNEmbedIE
    UDNEmbedIE()

# Generated at 2022-06-22 08:54:28.891395
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    webpage = ie._download_webpage(url, '300040')
    options_str = ie._html_search_regex(
            r'var\s+options\s*=\s*([^;]+);', webpage, 'options')
    trans_options_str = js_to_json(options_str)
    options = ie._parse_json(trans_options_str, 'options', fatal=False) or {}
    assert options
    video_urls = ie._parse_json(ie._html_search_regex(
            r'"video"\s*:\s*({.+?})\s*,', trans_options_str, 'video urls'), 'video urls')
    assert video

# Generated at 2022-06-22 08:54:30.562707
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-22 08:54:39.422104
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-22 08:54:40.380780
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    InfoExtractor(UDNEmbedIE)

# Generated at 2022-06-22 08:54:44.163318
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:54:51.106514
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)

    url = "http://video.udn.com/embed/news/300040"
    video_id = ie._match_id(url)
    assert video_id == '300040'

    url = "http://video.udn.com/embed/news/300040"
    video_id = ie._match_id(url)
    assert video_id == '300040'

    url = "https://video.udn.com/play/news/300040"
    video_id = ie._match_id(url)
    assert video_id == '300040'

# Generated at 2022-06-22 08:54:59.860405
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check the instantiation
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_NAME == 'udn'
    assert ie.ie_key() == 'Udn'
    assert ie.IE_DESC == '聯合影音'

    # Check the static method of finding youtube link from options
    options = {}
    the_func = ie._extract_youtube
    # A normal case with youtube
    options['video'] = {'youtube': 'https://www.youtube.com/watch?v=q3nMk-xq1fc'}
    assert the_func(options)
    # A normal case without youtube

# Generated at 2022-06-22 08:55:06.088402
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    ie._VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    ie.match_id('//video.udn.com/embed/news/300040') == '300040'
    ie.match_id('//video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-22 08:55:13.833291
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor of class UDNEmbedIE are tested.
    """
    # dict `_VALID_URL_TEMPLATE` doesn't exist, it should return None
    assert UDNEmbedIE()._VALID_URL_TEMPLATE == None
    # dict `IE_DESC` exists, it should return "聯合影音".
    assert UDNEmbedIE().IE_DESC == "聯合影音"
    # dict `_VALID_URL` exists, it should return "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-22 08:55:24.713090
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert str(ie) == '<UDNEmbedIE https://video.udn.com/embed/news/300040>'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:57:51.514343
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'

# Generated at 2022-06-22 08:58:00.046292
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # This test case was created by extracting the code from 'UDNEmbedIE' directly to here,
    # and then refactoring it to fit the class's API.
    # Both this test case and the code in 'UDNEmbedIE' should be kept in sync.

    # test case 1
    test_url = 'http://video.udn.com/embed/news/300040'


# Generated at 2022-06-22 08:58:03.228826
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert "UDNEmbedIE" == udn.IE_NAME
    assert "聯合影音" == udn.IE_DESC
    assert "http:" + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._VALID_URL



# Generated at 2022-06-22 08:58:11.476399
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_DESC == '聯合影音'
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:58:13.219917
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == "UDNEmbed"



# Generated at 2022-06-22 08:58:20.845648
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    print('Url Type: ' + ie.get_type(url))
    print('Protocol Relative Value: ' + ie.get_proto_relative())
    print('Protocol Relative Value: ' + ie.get_proto_relative_match())
    print('Protocol Relative Value: ' + ie.get_proto_relative_valid_url())
    print('Protocol Relative Value: ' + ie.get_valid_url())
    print('Protocol Relative Value: ' + ie.get_test_list())


# Generated at 2022-06-22 08:58:27.956700
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    # This is a URL
    assert udne.ie_key() == 'UDNEmbed'
    # This is a URL
    test_url = 'http://video.udn.com/embed/news/300040'
    assert udne.suitable(test_url)
    # This is not a URL
    test_url = 'abc'
    assert not udne.suitable(test_url)

# Generated at 2022-06-22 08:58:34.406090
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Unit test for constructor of class UDNEmbedIE.
    '''
    url_input = 'https://video.udn.com/play/news/300040'
    udn_embed_ie = UDNEmbedIE()
    if udn_embed_ie.suitable(url_input):
        return
    else:
        print('Unit test for constructor of class UDNEmbedIE failed.')
        return

# Generated at 2022-06-22 08:58:40.974252
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test_url = 'https://video.udn.com/embed/news/300040'
    test_url = 'http://video.udn.com/embed/news/300040'
    result = UDNEmbedIE()._real_extract(test_url)
    assert result['id'] == '300040'
    assert result['title'] == '生物老師男變女 全校挺"做自己"'
    assert result['thumbnail'] is not None

# Generated at 2022-06-22 08:58:45.825176
# Unit test for constructor of class UDNEmbedIE