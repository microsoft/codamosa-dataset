

# Generated at 2022-06-22 08:49:49.995998
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    test_result = udn_embed.suitable(url)
    assert test_result, 'the Url is not a udn embed link'

# Generated at 2022-06-22 08:50:03.168123
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    us = 'https://video.udn.com/embed/news/300040'
    u = 'http://video.udn.com/embed/news/300040'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == r'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL
    assert udne._match_id(u) == '300040'
    assert udne._match_id(u) != 'abc'
    assert udne._match_id(us) == '300040'
    assert udne._match_id(us)

# Generated at 2022-06-22 08:50:11.227594
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor of class UDNEmbedIE
    udne = UDNEmbedIE()
    # Check the existence of method _real_extract
    assert udne._real_extract is not None
    # Check the existence of method _PROTOCOL_RELATIVE_VALID_URL
    assert udne._PROTOCOL_RELATIVE_VALID_URL is not None
    # Check the existence of method _TESTS
    assert udne._TESTS is not None
    # Check the existence of method _VALID_URL
    assert udne._VALID_URL is not None
    # Check the existence of method IE_DESC
    assert udne.IE_DESC is not None



# Generated at 2022-06-22 08:50:13.149131
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'

# Generated at 2022-06-22 08:50:15.430772
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:50:16.444341
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    return UDNEmbedIE().test()

# Generated at 2022-06-22 08:50:17.435145
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(InfoExtractor())

# Generated at 2022-06-22 08:50:25.899700
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    assert inst._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst._VALID_URL == 'https?:' + inst._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:29.300434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-22 08:50:30.212944
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    dp = UDNEmbedIE()

# Generated at 2022-06-22 08:50:48.731588
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('video.udn.com', 'http://video.udn.com/play/news/300015', {})
    #UDNEmbedIE(_VALID_URL, 'https://video.udn.com/play/news/300040', {})
    return True

# Generated at 2022-06-22 08:50:53.501988
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Verifies the class constructor
    """
    ie = [
        UDNEmbedIE()
    ]

    for i in ie:
        if i.IE_NAME == 'UDNEmbedIE':
            assert i.ie_key() == 'UDNEmbedIE'
            assert i.IE_DESC == '聯合影音'
        else:
            assert False, 'wrong IE name: assert False'

# Generated at 2022-06-22 08:50:56.548823
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    my_date = ""
    my_url = ""

    embed_ie = UDNEmbedIE()

    embed_ie.initialize(my_date, my_url)

    assert embed_ie is not None

# Generated at 2022-06-22 08:50:58.730906
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:01.053468
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == 'udn_embed'
    assert udn_embed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:08.571786
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_list=['http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/303776']
    
    for url in url_list:
        IE = UDNEmbedIE()
        assert IE.suitable(url), 'URL %s must be suitable for %s/%s'%(url,UDNEmbedIE.IE_NAME,UDNEmbedIE.IE_DESC)

# Generated at 2022-06-22 08:51:10.493571
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:19.524516
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn_embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:28.851376
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from unittest import TestCase
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.downloader import HttpFD
    from youtube_dl.extractor import (
        GENERIC_IE_DESC,
        YoutubeIE,
    )
    from youtube_dl.options import OptSingleton
    from youtube_dl.utils import (
        ExtractorError,
        format_bytes,
        get_meta_content,
        orderedSet,
        parse_age_limit,
        url_basename,
    )


# Generated at 2022-06-22 08:51:32.987431
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    # _PROTOCOL_RELATIVE_VALID_URL
    udn_url = udn._match_id('//video.udn.com/embed/news/300040')
    assert udn_url == '300040'

# Generated at 2022-06-22 08:51:48.744395
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE()
    correct_id = '300040'
    assert correct_id == udn_embed._match_id(url)
    assert True == udn_embed._match_id(url)

# Generated at 2022-06-22 08:51:51.770841
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:54.921385
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/play/news/300040')

# Generated at 2022-06-22 08:51:56.163872
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        a = UDNEmbedIE()
        assert False
    except:
        assert True

# Generated at 2022-06-22 08:52:01.865712
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    class_ = ie.ie_key()
    _ = ie.url_result(url, class_)
    assert _.url == url
    assert _.ie_key() == class_

# Generated at 2022-06-22 08:52:06.133830
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_protocol_relative = '//video.udn.com/embed/news/300040'
    url = 'http:' + url_protocol_relative
    ie = UDNEmbedIE(url)
    assert ie.url == url
    assert ie.VIDEO_ID == '300040'

# Generated at 2022-06-22 08:52:06.899105
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    e = UDNEmbedIE()
    assert e

# Generated at 2022-06-22 08:52:09.235958
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:20.887961
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE."""

    # Test case 1: the video of news
    udn_embed_video_news_ie = UDNEmbedIE(compat_urllib_request.Request('http://video.udn.com/embed/news/300040'))
    assert udn_embed_video_news_ie.IE_NAME == 'udn'
    assert udn_embed_video_news_ie.IE_DESC == '聯合影音'

    # Test case 2: the video of show
    #udn_embed_video_show_ie = UDNEmbedIE('http://video.udn.com/embed/show/10130')
    #assert udn_embed_video_show_ie.IE_NAME == 'udn'
    #

# Generated at 2022-06-22 08:52:27.829088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == udn._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL == udn._VALID_URL
    assert UDNEmbedIE.IE_DESC == udn.IE_DESC
    assert UDNEmbedIE._TESTS == udn._TESTS


# Generated at 2022-06-22 08:52:56.737716
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:53:00.920359
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    expected_result = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    actual_result = ie.extract({'url': url})
    assert actual_result['id'] == expected_result['id']

# Generated at 2022-06-22 08:53:07.444664
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj_UDNEmbedIE = UDNEmbedIE()
    _VALID_URL = 'https://video.udn.com/embed/news/300040'
    _MATCH_ID = '300040'
    output = obj_UDNEmbedIE._real_extract(_VALID_URL)
    assert(output['id'] == _MATCH_ID)

# Generated at 2022-06-22 08:53:10.334854
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:53:14.543708
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    url = "https://video.udn.com/embed/news/300040"
    result = UDNEmbedIE()._real_extract(url)
    assert result['id'] == '300040'



# Generated at 2022-06-22 08:53:20.422076
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:53:30.268604
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE(None)
    assert i._VALID_URL == 'https?:' + i._PROTOCOL_RELATIVE_VALID_URL
    assert i._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:53:34.988791
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    infoextractor = UDNEmbedIE()
    assert infoextractor.IE_DESC == '聯合影音'
    assert infoextractor._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert infoextractor._VALID_URL == 'https?:' + infoextractor._PROTOCOL_RELATIVE_VALID_URL
    assert len(infoextractor._TESTS) == 3

# Generated at 2022-06-22 08:53:44.862675
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_KEY == 'UdnEmbed'

# Generated at 2022-06-22 08:53:46.416197
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor_test(UDNEmbedIE, [('https://video.udn.com/embed/news/300040', {})])

# Generated at 2022-06-22 08:54:45.282691
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        u = UDNEmbedIE()
        assert(isinstance(u,UDNEmbedIE))
    except:
        print("Can't initialize the class UDNEmbedIE")

# Generated at 2022-06-22 08:54:49.905219
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udnei = UDNEmbedIE()
    assert udnei._match_id(url) == '300040'

# Generated at 2022-06-22 08:54:52.760520
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor of class UDNEmbedIE should return an instance with non-empty attribute _VALID_URL.
    """
    assert UDNEmbedIE._VALID_URL

# Generated at 2022-06-22 08:54:57.427838
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("========test_UDNEmbedIE=========")
    url = "http://video.udn.com/embed/news/300040"
    udn_embed = UDNEmbedIE()
    print(udn_embed._match_id(url))
    print("========test_UDNEmbedIE=========\n")

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:55:03.779300
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    assert udnEmbedIE.IE_NAME == 'udn'
    assert udnEmbedIE.IE_DESC == '聯合影音'
    assert udnEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:55:05.656456
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-22 08:55:10.774759
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_object = UDNEmbedIE()
    assert test_object._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_object._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:55:18.326013
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    ie.IE_DESC = '聯合影音'
    ie._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    ie._VALID_URL = r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:55:25.483973
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import time
    try:
        # First test only
        UDNEmbedIE(True)
        time.sleep(2) # waiting for next test
    except Exception:
        assert False
    print('The constructor function passes the test')
    time.sleep(2) # waiting for next test

    try:
        # Second test only
        UDNEmbedIE(False)
        time.sleep(2) # waiting for next test
    except Exception:
        assert False
    print('The constructor function passes the test')
    time.sleep(2) # waiting for next test

# Generated at 2022-06-22 08:55:36.586851
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:58:14.282507
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-22 08:58:15.338102
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-22 08:58:24.067477
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udne._TESTS[0]['info_dict']['id'] == '300040'
    assert udne._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert udne._TESTS[0]['params']['skip_download'] == True
    assert udne._T

# Generated at 2022-06-22 08:58:24.987844
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:58:26.016357
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:58:29.174800
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:58:32.873964
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except:
        assert False, 'Can not construct class UDNEmbedIE'

# Generated at 2022-06-22 08:58:33.892172
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:58:36.425354
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    assert obj.ie_key() == 'UDNEmbed'

# Generated at 2022-06-22 08:58:41.667345
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    UDNEmbedIE.ie_keywords[0][1] = UDNEmbedIE._VALID_URL
    UDNEmbedIE.ie_keywords[0][0] = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    udn = UDNEmbedIE('UDNEmbedIE', url)
    udn.test()
    return UDNEmbedIE