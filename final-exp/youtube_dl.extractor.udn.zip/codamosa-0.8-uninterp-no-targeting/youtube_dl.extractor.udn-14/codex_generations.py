

# Generated at 2022-06-22 08:49:50.702317
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:49:55.659609
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_download import TestDownload
    from .test_utils import get_testcases
    TestDownload.__init__(TestDownload, UDNEmbedIE())
    testcases = get_testcases(UDNEmbedIE)
    TestDownload.test_ie(TestDownload, UDNEmbedIE(), testcases)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:50:01.652919
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	url = 'https://video.udn.com/embed/news/300040'
	ex = UDNEmbedIE()
	assert type(ex) == UDNEmbedIE,\
		'UDNEmbedIE constructor failed.'

# Generated at 2022-06-22 08:50:06.835770
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    import pytest
    from ..utils import ExtractorError
    with pytest.raises(ExtractorError):
        # URL not match
        ie.extract('http://video.udn.com/play/news/303776')

# Generated at 2022-06-22 08:50:08.195612
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO
    assert True


# Generated at 2022-06-22 08:50:18.925153
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    for test in ie._TESTS:
        if test.get('url') == 'https://video.udn.com/embed/news/300040':
            assert test == {
                'url': 'https://video.udn.com/embed/news/300040',
                'only_matching': True,
            }

# Generated at 2022-06-22 08:50:26.924708
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tests_run = 0
    exp_results = {
        0: ['300040', 200],
        1: ['303776', 200],
        2: ['300040', 200],
        3: ['303776', 200],
    }
    # Inputs to constructor
    test_inputs = [
        ('https://video.udn.com/embed/news/300040'),
        ('https://video.udn.com/play/news/303776'),
        ('http://video.udn.com/embed/news/300040'),
        ('http://video.udn.com/play/news/303776'),
    ]


# Generated at 2022-06-22 08:50:28.172142
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	UDNEmbedIE()

# Generated at 2022-06-22 08:50:35.800904
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._match_id(test_url) == '300040'


# Generated at 2022-06-22 08:50:46.167308
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Simple unit tests for the constructor of the class UDNEmbedIE"""
    udn_embed_obj = UDNEmbedIE()

    # Check if the instance has been created successfully
    assert isinstance(udn_embed_obj, InfoExtractor)

    # Check the match of embed URL
    embed_urls = [
        '//video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
    ]

    for embed_url in embed_urls:
        assert udn_embed_obj._match_id(embed_url) is not None

    # Check the match of non-embed URL

# Generated at 2022-06-22 08:50:55.585771
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    result = ie._PROTOCOL_RELATIVE_VALID_URL
    if result != '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)':
        raise Exception('Result of constructing protocol_relative_valid_url is not expected: ' + result)

# Generated at 2022-06-22 08:50:57.068858
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:50:59.205256
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:05.105977
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()
    assert UDNEmbedIE().IE_NAME == 'udn_embed'
    assert UDNEmbedIE().IE_DESC in ('聯合影音', 'UDN Embed')
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE()._TESTS == UDNEmbedIE._TESTS

# Generated at 2022-06-22 08:51:10.493544
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembed_ie = UDNEmbedIE()
    assert udnembed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnembed_ie._VALID_URL == r'https?:' + udnembed_ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-22 08:51:17.606286
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    n_instances = UDNEmbedIE._instances
    UDNEmbedIE._instances = 0
    assert UDNEmbedIE._instances == 0
    instance_1 = UDNEmbedIE()
    assert UDNEmbedIE._instances == 1
    instance_2 = UDNEmbedIE()
    assert UDNEmbedIE._instances == 1
    UDNEmbedIE._instances = n_instances

# Generated at 2022-06-22 08:51:18.689104
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:26.327197
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.get_protocol_relative_url('http://video.udn.com/embed/news/300040') == '//video.udn.com/embed/news/300040'
    assert ie.get_protocol_relative_url('https://video.udn.com/embed/news/300040') == '//video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:51:30.568436
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id("http://video.udn.com/embed/news/300040") == '300040'
    assert ie._match_id("https://video.udn.com/embed/news/300040") == '300040'
    assert ie._match_id("//video.udn.com/play/news/300040") == '300040'

# Generated at 2022-06-22 08:51:32.635434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Tests for constructor of class UDNEmbedIE."""
    obj = UDNEmbedIE()
    assert obj

# Generated at 2022-06-22 08:51:45.874587
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:48.416472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Unit test for constructor of class UDNEmbedIE
    '''
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL
    assert UDNEmbedIE._TESTS

# Generated at 2022-06-22 08:51:56.421986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    regex_result_1 = udn_ie._PROTOCOL_RELATIVE_VALID_URL
    regex_result_2 = udn_ie._VALID_URL
    assert regex_result_1 == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert regex_result_2 == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:52:08.021840
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .. import YoutubeIE
    from .. import extractor as ie
    from .test_common import TestCommon
    from .test_youtube import TestYoutube

    class TestUDNEmbedIE(TestCommon, TestYoutube):
        IE_NAME = 'udn-embed'

# Generated at 2022-06-22 08:52:12.989784
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)', \
        'ERROR: Build a string in wrong format, should be "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)".'

# Generated at 2022-06-22 08:52:14.070330
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-22 08:52:20.125898
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-22 08:52:23.795663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a1 = UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL
    a2 = UDNEmbedIE()._VALID_URL
    a3 = UDNEmbedIE().IE_DESC
    a4 = UDNEmbedIE()._TESTS
    return a1, a2, a3, a4


# Generated at 2022-06-22 08:52:35.223528
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    val = udnei._real_extract(
        "https://video.udn.com/embed/news/300040",
        {'skip_download': True})

# Generated at 2022-06-22 08:52:40.420720
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor

    class TestUDNEmbedIE(object):

        def test_udn_video(self):
            UDNEmbedIE()._real_extract("http://video.udn.com/embed/news/300040")
            UDNEmbedIE()._real_extract("http://video.udn.com/play/news/300040")

# Generated at 2022-06-22 08:53:16.124931
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_ie = UDNEmbedIE()
    assert 'udne' in udn_ie.compat_str_to_bytes(udn_ie.IE_NAME)
    assert 'udne' in udn_ie.compat_str_to_bytes(udn_ie.ie_key())
    assert 'udne' in udn_ie.compat_str_to_bytes(udn_ie.ie_key())
    assert url == udn_ie.url_result({'url': url}, 'UDNEmbed')
    assert url == udn_ie.ie_key()
    assert url == udn_ie.working_link(url)

# Generated at 2022-06-22 08:53:26.013311
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    check the class constructor of
    class UDNEmbedIE
    """
    # initialize class
    infoExtractor = UDNEmbedIE()

    # is it initialized?
    assert infoExtractor.IE_NAME == 'UDNEmbedIE', \
        "UDNEmbedIE.IE_NAME is 'UDNEmbedIE'"
    assert infoExtractor.IE_DESC == '聯合影音', \
        "UDNEmbedIE.IE_DESC is '聯合影音'"

    # do we have test cases?
    assert len(infoExtractor._TESTS) == 3, \
        "len(UDNEmbedIE._TESTS) should be 3"

    # test we can set parameters
    # test we can call the method
    video

# Generated at 2022-06-22 08:53:34.497389
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE
    """


# Generated at 2022-06-22 08:53:44.597235
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.IE_NAME == 'udn'
    assert u.IE_DESC == '聯合影音'
    assert u._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(u._TESTS) == 3
    for index, test in enumerate(u._TESTS):
        assert test.get('url') == u._TESTS[index].get('url')

# Generated at 2022-06-22 08:53:49.679290
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for http://video.udn.com/embed/news/300040
    url = 'http://video.udn.com/embed/news/300040'
    builder = UDNEmbedIE().get_info(url)
    assert builder.url == 'http://video.udn.com/embed/news/300040'
    assert builder.id == '300040'
    assert 'mp4' in builder.ext
    assert builder.title == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-22 08:53:55.935677
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_data = UDNEmbedIE._TESTS[0]
    url = test_data['url']
    result = UDNEmbedIE()._real_extract(url)
    assert result['id'] == '300040'
    assert result['title'] == '生物老師男變女 全校挺"做自己"'
    assert result['thumbnail'] == 'http://img.video.udn.com.tw/cd/video/news303900/300040_m.jpg'
    assert len(result['formats']) == 3
    assert result['formats'][0]['url'] == 'http://video.udn.com.tw/video_download/300040_hls.m3u8'

# Generated at 2022-06-22 08:54:05.174045
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert '聯合影音' == ie.IE_DESC

    # Unit test for _real_extract function
    # Non-empty case
    real_extract = ie._real_extract
    url = 'http://video.udn.com/embed/news/300040'
    video_id = ie._match_id(url)
    video_urls = real_extract(url)
    assert video_id in video_urls
    assert 'mp4' == video_urls[video_id]
    assert '生物老師男變女 全校挺"做自己"' == video_urls['title']

# Generated at 2022-06-22 08:54:08.233624
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('udn')

# Generated at 2022-06-22 08:54:11.096913
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    udn = UDNEmbedIE()
    udn.download(url)

# Generated at 2022-06-22 08:54:16.938288
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_utils import make_test_url_extractor
    udn_embed = make_test_url_extractor('UDNEmbedIE')
    test_urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        '//video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/303776',
    ]
    for url in test_urls:
        assert udn_embed(url) is not None

# Generated at 2022-06-22 08:55:17.271192
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None);
    # test __init__ method
    assert ie._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-22 08:55:26.720253
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie.IE_NAME == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:55:31.232802
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == r'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:55:35.739498
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_url = 'http://video.udn.com/embed/news/300040'
    test_video_id = '300040'
    assert ie._match_id(test_url) == test_video_id
    assert ie.ie_key() in ie.gen_extractors()


# Generated at 2022-06-22 08:55:41.698476
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_class = UDNEmbedIE()
    assert test_class.IE_DESC == '聯合影音'
    assert test_class._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_class._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:55:46.761095
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

    ie.IE_DESC = ie.IE_DESC
    ie._PROTOCOL_RELATIVE_VALID_URL = ie._PROTOCOL_RELATIVE_VALID_URL
    ie._VALID_URL = ie._VALID_URL
    ie._TESTS = ie._TESTS

# Generated at 2022-06-22 08:55:48.953236
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unittest.main()

# Generated at 2022-06-22 08:55:51.567182
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:55:55.924962
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE(None, None)
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL is not None
    assert udn_embed_ie._VALID_URL is not None
    assert udn_embed_ie._TESTS is not None

# Generated at 2022-06-22 08:55:57.764740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(None)

# Generated at 2022-06-22 08:58:38.892224
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UdnEmbed'
    assert udn_embed_ie.ie_desc() == '聯合影音'
    assert udn_embed_ie._VALID_URL is not None
    assert udn_embed_ie._TESTS is not None


# Generated at 2022-06-22 08:58:41.893270
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert isinstance(udne.IE_NAME, str)
    assert udne.IE_DESC is not None
    assert isinstance(udne.IE_DESC, str)
    assert udne.ie_key() in ['UDNEmbed']
    return

# Generated at 2022-06-22 08:58:48.821364
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE(None)
    assert test_obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:58:53.354501
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert ie._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-22 08:58:55.559629
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    print("yamlTest_UDNEmbedIE()")

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:58:58.588935
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert instance.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:59:07.934359
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-22 08:59:09.575929
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	assert UDNEmbedIE(UDNEmbedIE.ie_key())

# Generated at 2022-06-22 08:59:18.120866
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:59:21.456914
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_UDNEmbedIE = UDNEmbedIE()
    test_UDNEmbedIE._match_id(r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    test_UDNEmbedIE._valid_url(r'https?:' + test_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)