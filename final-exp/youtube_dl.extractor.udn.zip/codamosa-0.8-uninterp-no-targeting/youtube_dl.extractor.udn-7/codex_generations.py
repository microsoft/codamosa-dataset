

# Generated at 2022-06-22 08:49:49.613188
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    for url in ie._TESTS:
        print(ie.suitable(url['url']))

# Generated at 2022-06-22 08:49:50.612069
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()

# Generated at 2022-06-22 08:49:54.414152
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie.ie_key())
    assert ie.ie_key() == 'UDNEmbed'


# Generated at 2022-06-22 08:50:05.388834
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:50:16.697540
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .base import _download_json
    url = 'https://video.udn.com/embed/news/300040'
    webpage = _download_json(url)
    info_dict = {}
    if webpage:
        options_str = re.search(r'var\s+options\s*=\s*([^;]+);', webpage).group(1)
        trans_options_str = js_to_json(options_str)
        options = re.search(r'"video"\s*:\s*({.+?})\s*,', trans_options_str).group(1)
        video_urls = json.loads(options)
        title = re.search(r"title\s*:\s*'(.+?)'\s*,", options_str).group(1)

# Generated at 2022-06-22 08:50:18.502280
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Initial test to see if class UDNEmbedIE can be instantiated
    """
    UDNEmbedIE()

# Generated at 2022-06-22 08:50:22.708433
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)' 
    assert obj._VALID_URL == r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:33.719164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print('test: UDNEmbedIE _PROTOCOL_RELATIVE_VALID_URL is %s' % ie._PROTOCOL_RELATIVE_VALID_URL)
    print('test: Valid URL is %s' % ie._valid_url('http://video.udn.com/embed/news/300040', 'UDNEmbed'))
    print('test: Valid URL is %s' % ie._valid_url('http://video.udn.com/play/news/300040', 'UDNEmbed'))
    print('test: Valid URL is %s' % ie._valid_url('https://video.udn.com/embed/news/300040', 'UDNEmbed'))

# Generated at 2022-06-22 08:50:37.974844
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    embed_ie = UDNEmbedIE()
    assert embed_ie.IE_DESC == '聯合影音'
    assert embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(embed_ie._TESTS) == 3


# Generated at 2022-06-22 08:50:45.880445
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('abc','abc','abc','abc','abc','abc','abc')

    # __init__(self, _type, ie_key, name, description)
    assert ie._type == 'abc'
    assert ie.ie_key == 'abc'
    assert ie.name == 'abc'
    assert ie.description == 'abc'

    # _extract_video_url(self, video_id, webpage)
    video_urls = {'youtube':'https://www.youtube.com/watch?v=cxIGQekc9yI'}
    webpage = 'abc'
    video_id = 'cxIGQekc9yI'

# Generated at 2022-06-22 08:51:01.646601
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + _PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:13.196793
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE(None)
    assert udn.ie_key() == 'UDNEmbed'
    assert udn.ie_desc() == '聯合影音'
    assert udn.test_test() == {'url': 'http://video.udn.com/embed/news/300040', 'info_dict': {'id': '300040', 'ext': 'mp4', 'thumbnail': 're:^https?://.*\\.jpg$', 'title': '生物老師男變女 全校挺"做自己"'}, 'params': {'skip_download': True}, 'expected_warnings': ['Failed to parse JSON Expecting value']}

# Generated at 2022-06-22 08:51:16.229496
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().suitable(url)



# Generated at 2022-06-22 08:51:22.145302
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Construct a UDNEmbbedIE object for testing
    UDNEmbedIE = type(str('UDNEmbedIE'),
                      (UDNEmbedIE,),
                      dict(UDNEmbedIE._TESTS[0]))
    # Test extract()
    UDNEmbedIE._real_extract(UDNEmbedIE(),
                             UDNEmbedIE._TESTS[0]['url'])

# Generated at 2022-06-22 08:51:27.064446
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert(udn_ie.IE_DESC == '聯合影音')
    assert(udn_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-22 08:51:32.223262
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #if __test_UDNEmbed__:
    url = u'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_initialize()
    UDNEmbedIE().extract(url)
    
__test_UDNEmbed__ = False

# Generated at 2022-06-22 08:51:35.693929
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE().IE_NAME == IE_NAME
    assert UDNEmbedIE().IE_DESC == IE_DESC

# Generated at 2022-06-22 08:51:38.122221
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('300040')
    assert type(ie) is UDNEmbedIE


# Generated at 2022-06-22 08:51:49.268323
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE"""
    query_obj = {
        'ie_key': 'UDNEmbed',
        'video_id': '300040',
        'display_id': '300040',
        'url': 'http://video.udn.com/embed/news/300040',
    }
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.suitable(query_obj) == True
    assert ie.working() == True
    assert ie.max_age() is None
    assert ie._LANG == 'zh-TW'
    assert ie.IE_NAME == 'udn'
    assert ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-22 08:51:55.281352
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._TESTS == UDNEmbedIE._TESTS
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:10.870783
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:52:17.938509
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url, re_str, ie_desc = ie._PROTOCOL_RELATIVE_VALID_URL, ie._VALID_URL, ie.IE_DESC
    valid_url = 'http://video.udn.com/embed/news/300040'
    assert (ie_desc + ' (' + re_str + ')') == ie._real_extract(valid_url).get('id')

# Generated at 2022-06-22 08:52:22.478968
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('constructing an instance of UDNEmbedIE...')
    a = UDNEmbedIE()
    print('done')

# Generated at 2022-06-22 08:52:24.870132
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:52:27.039550
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class test_UDNEmbedIE(UDNEmbedIE):
        def __init__(self):
            pass
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:52:31.390907
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDNEmbed'
    assert udn_embed_ie.ie_desc() == '聯合影音'

# Generated at 2022-06-22 08:52:36.941831
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:52:38.646840
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.ie_key(), UDNEmbedIE.ie_key())

# Generated at 2022-06-22 08:52:48.106023
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..unit.test_IE import TEST_CASES
    from ..unit import run_tests
    from ..compat import parse_qsl
    from urllib.parse import urlparse, urlunparse

    class UDNEmbedUnitTestIE(UDNEmbedIE):
        """Overwrite `_download_webpage` for unit test."""
        def _download_webpage(self, *args, **kwargs):
            """Overwrite `_download_webpage` for unit test."""
            del args, kwargs

# Generated at 2022-06-22 08:52:49.527133
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE('http://www.udn.com')

# Generated at 2022-06-22 08:53:17.526900
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO(yumu): Find a real video url, replace the fake values
    UDNEmbedIE('https://video.udn.com/embed/news/300040')._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:53:27.454852
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    s = UDNEmbedIE()
    assert isinstance(s, InfoExtractor)
    assert s.IE_NAME == 'udn'
    assert s.IE_DESC == '聯合影音'
    assert s._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert s._VALID_URL == r'https?:' + s._PROTOCOL_RELATIVE_VALID_URL
    assert hasattr(s, '_TESTS')
    assert hasattr(s, '_real_extract')


# Generated at 2022-06-22 08:53:29.579577
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_udnembedie = UDNEmbedIE()
    assert class_udnembedie is not None


# Generated at 2022-06-22 08:53:30.352766
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check to see that an object can be created by the constructor
    UDNEmbedIE()

# Generated at 2022-06-22 08:53:32.894079
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)

    assert(
        pattern.match(
            '//video.udn.com/embed/news/300040'
        )
    )

# Generated at 2022-06-22 08:53:35.198859
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:53:39.580455
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:53:43.571201
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test basic functions of class UDNEmbedIE.
    """
    from .test_utils import find_testcases
    for url, _, _ in find_testcases(UDNEmbedIE).values():
        _ = UDNEmbedIE._real_extract(UDNEmbedIE(), url)

# Generated at 2022-06-22 08:53:45.764582
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:53:49.273479
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    target = UDNEmbedIE()
    assert target._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert target._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:54:44.071708
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-22 08:54:47.144360
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	udn_video = UDNEmbedIE()
	udn_video.extract("https://video.udn.com/embed/news/300040")

if __name__ == '__main__':
	test_UDNEmbedIE()

# Generated at 2022-06-22 08:54:54.867765
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..test import get_testcases
    testcases = get_testcases(UDNEmbedIE)
    instance = UDNEmbedIE()
    # 'assert' is not a function, so...
    def _assert(cond, msg=None):
        if not cond:
            raise AssertionError(msg)
    for testcase in testcases:
        _assert(instance._match_id(testcase['url']) is not None, testcase['url'])
        _assert(instance._match_id(testcase['url']) == testcase['expected'], testcase['url'])

# Generated at 2022-06-22 08:55:04.449160
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assertUDNEmbedIE = UDNEmbedIE(UDNEmbedIE.ie_key())
    assertUDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assertUDNEmbedIE._VALID_URL == r'https?:' + assertUDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assertUDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:55:06.257373
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME != ''
    assert ie.IE_DESC != ''

# Generated at 2022-06-22 08:55:13.833262
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_utils import ipes

    this = ipes.UDNEmbedIE

    assert(this._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(this._VALID_URL == 'https?:' + this._PROTOCOL_RELATIVE_VALID_URL)

    assert(isinstance(this._TESTS[0], dict))
    assert(isinstance(this._TESTS[1], dict))
    assert(isinstance(this._TESTS[2], dict))

    assert(this._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:55:19.978286
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_video = 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE.suitable(url_video.encode('utf-8'))
    t = UDNEmbedIE()
    assert t.IE_NAME == 'UDNEmbed'
    assert t._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert t._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert t.IE_DESC == '聯合影音'
    assert t._TESTS[0]['url'] == url_video

# Generated at 2022-06-22 08:55:21.564677
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()
test_UDNEmbedIE()

# Generated at 2022-06-22 08:55:26.105978
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:55:37.389721
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for Youtube video
    assert UDNEmbedIE('http://video.udn.com/embed/news/9991')._match_id('http://video.udn.com/embed/news/9991') is '9991'
    assert UDNEmbedIE('http://video.udn.com/embed/news/300040')._match_id('http://video.udn.com/embed/news/300040') is '300040'
    assert UDNEmbedIE('https://video.udn.com/embed/news/300040')._match_id('https://video.udn.com/embed/news/300040') is '300040'

# Generated at 2022-06-22 08:58:04.993961
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    embed = UDNEmbedIE()
    assert embed._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert embed._VALID_URL == r'https?:' + embed._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-22 08:58:11.987508
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.IE_NAME = "udnembed"
    test_video_url = "https://video.udn.com/play/news/303776"
    # Check the url is matched or not
    assert ie.suitable(test_video_url)
    # Check the IE_DESC
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:58:21.773854
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    testcases = [
        ('http://video.udn.com/embed/news/300040', {'IE_NAME': 'YouTube'}),
        ('https://video.udn.com/embed/news/300040', {'IE_NAME': 'YouTube'}),
        ('https://video.udn.com/play/news/303776', {'IE_NAME': 'UDNEmbed'}),
        ('http://video.udn.com/play/news/303776', {'IE_NAME': None}),
    ]
    for url, expected_result in testcases:
        result = UDNEmbedIE._match_ie_key(url)
        assert result == expected_result, '%s != %s for %s' % (result, expected_result, url)

# Generated at 2022-06-22 08:58:32.048255
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE()
    obj.IE_DESC = '聯合影音'
    obj._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    obj._VALID_URL = r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:58:36.072387
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_name = UDNEmbedIE.__name__
    instance = eval(class_name + '()')
    assert(isinstance(instance, InfoExtractor))
    print('Pass: ' + class_name)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:58:42.953193
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    # test if video_id is extracted correctly
    video_id = IE._match_id("https://video.udn.com/embed/news/300040")
    assert(int(video_id) == 300040)
    video_id = IE._match_id("//video.udn.com/embed/news/300040")
    assert(int(video_id) == 300040)
    video_id = IE._match_id("//video.udn.com/play/news/303776")
    assert(int(video_id) == 303776)


# Generated at 2022-06-22 08:58:51.237263
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert test._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test._VALID_URL == 'https?:' + test._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:58:56.849319
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    'constructor for UDNEmbedIE'
    ubnb = UDNEmbedIE()
    assert ubnb.RE == UDNEmbedIE._RE
    assert ubnb.IE_NAME == UDNEmbedIE.IE_NAME
    assert ubnb.IE_DESC == UDNEmbedIE.IE_DESC

# Generated at 2022-06-22 08:59:05.012975
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #pylint: disable=W0212
    assert UDNEmbedIE._match_id(
        'https://video.udn.com/play/news/300040') == '300040'
    assert UDNEmbedIE._match_id(
        'https://video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE._match_id(
        'http://video.udn.com/play/news/300040') == '300040'
    assert UDNEmbedIE._match_id(
        'http://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-22 08:59:05.782629
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()