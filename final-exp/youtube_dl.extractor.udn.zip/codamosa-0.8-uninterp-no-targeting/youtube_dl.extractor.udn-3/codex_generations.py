

# Generated at 2022-06-22 08:49:49.615189
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:49:51.468692
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:49:53.144233
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('', '1.0')

# Generated at 2022-06-22 08:49:58.134927
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_NAME == '聯合影音'
    assert ie.IE_DESC == '聯合影音'



# Generated at 2022-06-22 08:50:01.381840
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:50:09.438827
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040')
    assert UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040/')
    assert UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040/index.shtml')
    assert UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040/index')
    assert UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040/index.html')
    assert UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040/')

# Generated at 2022-06-22 08:50:11.005201
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    print(udn_embed_ie)

# Generated at 2022-06-22 08:50:12.944918
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor test
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'

# Generated at 2022-06-22 08:50:15.643477
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert UDNEmbedIE._VALID_URL == udn_embed_ie.VALID_URL

# Generated at 2022-06-22 08:50:24.861016
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    assert i.IE_DESC == '聯合影音'
    assert i._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert i._VALID_URL == r'https?:' + i._PROTOCOL_RELATIVE_VALID_URL
    assert len(i._TESTS) == 3
    test = i._TESTS[0]
    assert test['url'] == 'http://video.udn.com/embed/news/300040'
    assert test['info_dict']['id'] == '300040'
    assert test['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:50:42.064579
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDNEmbed'
    assert udn_embed_ie.ie_desc() == '聯合影音'

# Generated at 2022-06-22 08:50:51.768839
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    output = str(extractor)
    assert extractor.IE_DESC == '聯合影音'
    assert extractor._VALID_URL == r'https?:(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'
    assert extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert output.find('UDNEmbedIE') > 0

# Generated at 2022-06-22 08:50:58.109471
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE.IE_DESC == '聯合影音')
    assert(UDNEmbedIE._VALID_URL == 'https?:(?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))')

if __name__ == '__main__':
    # Test for constructor of class you-get.extractors.udn.UDNEmbedIE
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:50:59.056540
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:51:00.981991
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert type(UDNEmbedIE()) is UDNEmbedIE

# Generated at 2022-06-22 08:51:04.610796
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:07.048241
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UdnVideo'
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:51:08.019843
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(get_info=None)

# Generated at 2022-06-22 08:51:11.886894
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    embeded = UDNEmbedIE()._match_id(url)
    assert embeded == '300040'



# Generated at 2022-06-22 08:51:13.083201
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()

# Generated at 2022-06-22 08:51:27.854101
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.IE_DESC

# Generated at 2022-06-22 08:51:29.493755
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test if can be constructor
    UDNEmbedIE()


# Generated at 2022-06-22 08:51:33.329621
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test create_ie method return
    ie = UDNEmbedIE.create_ie('https://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:51:44.726591
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:51:53.009810
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE('http://video.udn.com/embed/news/300040').IE_NAME == 'udn_embed'
    assert UDNEmbedIE('https://video.udn.com/embed/news/300040').IE_NAME == 'udn_embed'
    assert UDNEmbedIE('http://video.udn.com/play/news/300040').IE_NAME == 'udn_embed'
    assert UDNEmbedIE('https://video.udn.com/play/news/300040').IE_NAME == 'udn_embed'

# Generated at 2022-06-22 08:52:02.032892
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-22 08:52:04.393752
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Test constructing an instance of class UDNEmbedIE
    '''
    UDNEmbedIE(None)


# Generated at 2022-06-22 08:52:05.197992
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:52:11.181621
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    ie = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:52:18.091586
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    for url in ie._TESTS[0]['url']:
        assert ie._match_id(url) == ie._TESTS[0]['info_dict']['id']
    url = 'https://video.udn.com/embed/news/300040'
    assert ie._match_id(url) == ie._TESTS[0]['info_dict']['id']

# Generated at 2022-06-22 08:52:52.091010
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """ Test cases for UDNEmbedIE """
    # TODO: Add more test cases

    # Construct an instance of UDNEmbedIE
    udn_embed_ie = UDNEmbedIE()

    # Make sure that the constructor works fine
    assert udn_embed_ie is not None

    # Check the regex for valid URL
    part_valid_url = '//video.udn.com/embed/news/300040'
    assert udn_embed_ie._is_valid_url(part_valid_url, udn_embed_ie.IE_NAME)


# Generated at 2022-06-22 08:52:55.076579
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    e = UDNEmbedIE()
    assert e._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:52:59.532149
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'
    assert ie.IE_NAME == ie.__class__.__name__

# Generated at 2022-06-22 08:53:10.219505
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # test for _PROTOCOL_RELATIVE_VALID_URL
    assert_equal(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL, r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    # test for _VALID_URL
    assert_equal(udn_embed_ie._VALID_URL, r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL)

    # test for _TESTS

# Generated at 2022-06-22 08:53:11.705228
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('test')
    assert ie is not None

# Generated at 2022-06-22 08:53:15.897767
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    p = UDNEmbedIE()
    assert p.IE_DESC == '聯合影音'
    assert p.has_key('title') == False
    assert p.has_key('is_live') == False
    assert p.has_key('http_chunk_size') == False

# Generated at 2022-06-22 08:53:18.139903
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:53:29.091107
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:53:30.196283
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test whether constructor will cause any error."""
    UDNEmbedIE()

# Generated at 2022-06-22 08:53:31.742204
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:54:36.327631
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    assert i._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:54:41.919469
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test to check if constructor of class UDNEmbedIE is able to handle a valid url
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.suitable('https://video.udn.com/embed/news/300040')


# Generated at 2022-06-22 08:54:47.998020
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE()
    result = udn_embed.extract('http://video.udn.com/embed/news/300040')
    assert result['id'] == '300040'
    assert result['ext'] == 'mp4'
    assert result['title'] == '生物老師男變女 全校挺"做自己"'
    assert result['thumbnail'] == 're:^https?://.*\.jpg$'


# Generated at 2022-06-22 08:54:57.895466
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for URL validation
    for url in ['',
                'http://video.udn.com/play/news/303776',
                'https://video.udn.com/embed/news/300040',
                'https://video.udn.com/play/news/303776',
                'http://video.udn.com/embed/news/12345678',
                'http://video.udn.com/embed/news/123abc',
                '//video.udn.com/embed/news/300040',
                '//video.udn.com/play/news/303776']:
        ie = UDNEmbedIE()
        if url:
            assert ie.suitable(url) == (url != '')
            assert ie.IE_NAME == 'udn.com:embed'

# Generated at 2022-06-22 08:54:58.856609
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:55:02.575595
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test for constructor of class UDNEmbedIE
    """
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-22 08:55:05.828400
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    Udn_embed = UDNEmbedIE()
    Udn_embed.IE_DESC
    Udn_embed._VALID_URL
    Udn_embed._PROTOCOL_RELATIVE_VALID_URL
    Udn_embed.extract('https://video.udn.com/play/news/303776')


# Generated at 2022-06-22 08:55:07.639556
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.ie_key() == 'UDNEmbed'

# Generated at 2022-06-22 08:55:08.659517
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(InfoExtractor)

# Generated at 2022-06-22 08:55:11.644765
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:57:55.184038
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import urllib
    url = 'http://video.udn.com/embed/news/300040'
    url_ = urllib.parse.urlparse(url)
    assert url_ is not None
    assert url_.scheme == 'http'
    assert url_.netloc == 'video.udn.com'
    assert url_.path == '/embed/news/300040'
    assert url_.query == ''
    assert url_.fragment == ''

# Generated at 2022-06-22 08:57:57.593162
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:57:59.244444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._match_id(url)

# Generated at 2022-06-22 08:58:05.274253
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict'] == {'id': '300040', 'ext': 'mp4', 'title': '生物老師男變女 全校挺"做自己"', 'thumbnail': 're:^https?://.*\\.jpg$'}

# Generated at 2022-06-22 08:58:10.245528
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_DESC == '聯合影音'
    assert instance._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:58:11.193718
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed

# Generated at 2022-06-22 08:58:17.134364
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst =  UDNEmbedIE()
    assert inst.IE_DESC == '聯合影音'
    assert inst._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:58:22.123242
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pylint: disable=attribute-defined-outside-init
    test_class = UDNEmbedIE
    instance = test_class(None)
    assert instance._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == 'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:58:25.645013
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.test()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:58:28.110102
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)
