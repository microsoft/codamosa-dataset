

# Generated at 2022-06-22 08:50:01.740174
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    video_id = '300040'
    # num. 1
    video_url = 'http://video.udn.com/embed/news/%s' % video_id
    res = ie.url_result(video_url, 'UDNEmbed')
    assert res['_type'] == 'url_transparent', res['_type']
    # num. 2
    video_url = 'https://video.udn.com/embed/news/%s' % video_id
    res = ie.url_result(video_url, 'UDNEmbed')
    assert res['_type'] == 'url_transparent', res['_type']

# Generated at 2022-06-22 08:50:08.912297
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    title = '生物老師男變女 全校挺"做自己"'
    thumbnail = 'http://video.udn.com/img/news/300040/cover.jpg'
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE.__new__(UDNEmbedIE)
    ie.extract(url)

# Generated at 2022-06-22 08:50:19.529832
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    extractor = UDNEmbedIE()
    assert extractor.suitable(url)
    assert extractor.IE_DESC == '聯合影音'
    assert extractor._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert extractor._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert extractor._TESTS[0]['info_dict']['id'] == '300040'
    assert extractor._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:50:28.690851
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # show the list of variables defined in class UDNEmbedIE

# Generated at 2022-06-22 08:50:34.523372
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    _VALID_URL = r'http://video\.udn\.com/embed/news/(?P<id>\d+)'
    assert _VALID_URL == inst._VALID_URL
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/embed/news/(?P<id>\d+)'
    assert _PROTOCOL_RELATIVE_VALID_URL == inst._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-22 08:50:38.160499
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert str(UDNEmbedIE()) == '<class \'youtube_dl.extractor.udn.UDNEmbedIE\'>'

# Generated at 2022-06-22 08:50:40.888927
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _UDNEmbedIE = UDNEmbedIE(None)
    print(_UDNEmbedIE.IE_DESC)

# Generated at 2022-06-22 08:50:41.742781
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Basic test:
    >>> test_UDNEmbedIE()
    True
    """
    assert True

# Generated at 2022-06-22 08:50:43.625346
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:50:51.491681
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url ='https://video.udn.com/embed/news/300040'
    udn_class = UDNEmbedIE()
    assert udn_class._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_class.IE_DESC == '聯合影音'
    assert udn_class._VALID_URL == r'https?:' + udn_class._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:50:59.735292
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Run the actual unit test
    UDNEmbedIE()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:51:04.024858
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._EXTENSIONS == ['mp4']
    assert UDNEmbedIE._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-22 08:51:08.204833
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # _VALID_URL can't be found error, but the subclass can be instantiated
    assert UDNEmbedIE._VALID_URL
    ie = UDNEmbedIE(UDNEmbedIE._VALID_URL)
    assert ie.IE_NAME == 'udn'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:17.606125
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # http://video.udn.com/embed/news/300040
    test_url ='http://video.udn.com/embed/news/300040'
    assert re.match(ie._PROTOCOL_RELATIVE_VALID_URL, test_url)
    # https://video.udn.com/embed/news/300040
    test_url ='https://video.udn.com/embed/news/300040'
    assert re.match(ie._VALID_URL, test_url)

# Generated at 2022-06-22 08:51:25.890517
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:51:33.663416
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:51:43.824077
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test validation(case 1)
    url_1 = r'https://video.udn.com/embed/news/300040'
    assert re.match(UDNEmbedIE._VALID_URL, url_1)
    # test validation(case 2)
    url_2 = r'//video.udn.com/embed/news/300040'
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, url_2)
    # test validation(case 3)
    url_3 = r'https://video.udn.com/play/news/300040'
    assert re.match(UDNEmbedIE._VALID_URL, url_3)



# Generated at 2022-06-22 08:51:49.268719
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for test_url in [
        "http://video.udn.com/embed/news/300040"
    ]:
        extractor = UDNEmbedIE()
        assert extractor.suitable(test_url) is True, "%s is a valid url for %s" % (test_url, extractor.IE_NAME)


# Generated at 2022-06-22 08:51:51.500208
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE(url)._real_extract(url)

# Generated at 2022-06-22 08:51:54.787899
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-22 08:52:11.340401
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._real_extract('http://video.udn.com/embed/news/300040')
    assert ie._real_extract('https://video.udn.com/embed/news/300040') == \
        ie._real_extract('http://video.udn.com/embed/news/300040')
    assert ie._real_extract('https://video.udn.com/play/news/303776') == \
        ie._real_extract('https://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:52:14.852400
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    ie = InfoExtractor.for_module(UDNEmbedIE)
    assert ie is not None
    return i

# Generated at 2022-06-22 08:52:17.355295
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    new_udn_embed_ie = UDNEmbedIE()
    assert new_udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-22 08:52:20.423752
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_test = UDNEmbedIE()
    assert udn_test._VALID_URL == 'https?:' + udn_test._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-22 08:52:31.945712
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_cases = [
        # Valid case
        {
            'url': 'https://video.udn.com/embed/news/300040',
            'should_return': True,
            'expected': {
                'id': '300040'
            },
        },
        # Invalid case
        {
            'url': 'https://video.udn.com/embed/news/30004a0',
            'should_return': False,
            'expected': {
                'id': ''
            },
        }
    ]
    for test_case in test_cases:
        id = ie._match_id(test_case['url'])
        result = True if test_case['should_return'] and id == test_case['expected']['id'] else False
        assert result

# Generated at 2022-06-22 08:52:35.013693
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-22 08:52:36.984290
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE().extract()

# Generated at 2022-06-22 08:52:39.579105
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE(None)
    assert udnEmbedIE is not None

# Unit tests for method _real_extract of class UDNEmbedIE

# Generated at 2022-06-22 08:52:43.030448
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie
    assert_eq_()

# Generated at 2022-06-22 08:52:49.466434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..extractor import gen_extractors
    module = '__main__'
    extractors = gen_extractors(modules=[__import__(module, fromlist=[''])])
    url = 'http://video.udn.com/embed/news/300040'
    ie = extractors[0].gen_extractor(url)(url)
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-22 08:53:04.922307
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """test for initial constructor of class UDNEmbedIE"""
    # url = 'http://video.udn.com/embed/news/300040'
    url = 'https://video.udn.com/play/news/303776'
    udn_vid = UDNEmbedIE()
    info = udn_vid._real_extract(url)
    print(info)


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:53:11.858567
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:53:14.870780
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert udne.ie_key() == 'udn'

# Generated at 2022-06-22 08:53:17.519675
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:53:19.253255
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()

# Generated at 2022-06-22 08:53:28.086910
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    testobj = UDNEmbedIE(None)
    assert testobj._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert testobj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert testobj._VALID_URL == 'https?:' + testobj._PROTOCOL_RELATIVE_VALID_URL
    assert testobj._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-22 08:53:28.942901
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()

# Generated at 2022-06-22 08:53:34.148937
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    url2 = 'https://video.udn.com/embed/news/300040'
    udn = UDNEmbedIE(url, {})
    assert udn.params == {}, 'params should be empty'
    udn.params['key1'] = 'val1'
    udn2 = UDNEmbedIE(url2, {})
    assert udn2.params['key1'] == 'val1', 'params should be the same'

# Generated at 2022-06-22 08:53:35.458782
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None)



# Generated at 2022-06-22 08:53:36.655226
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:54:13.744498
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-22 08:54:18.921930
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._match_id('http://video.udn.com/embed/news/300000') == '300000'
    assert obj._match_id('https://video.udn.com/embed/news/300000') == '300000'
    assert obj._match_id('video.udn.com/embed/news/300000') == '300000'

# Generated at 2022-06-22 08:54:19.770363
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:54:23.924164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.IE_NAME == 'udn'
    assert IE.IE_DESC == '聯合影音'
    assert re.match(r'.*%s' % IE._VALID_URL, IE._VALID_URL)
    assert IE._TESTS

# Generated at 2022-06-22 08:54:26.129252
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._downloader.params['username']
    assert ie._downloader.params['password']

# Generated at 2022-06-22 08:54:29.103803
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    pattern = re.compile(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL)
    assert pattern.match('//video.udn.com/embed/news/300040')


# Generated at 2022-06-22 08:54:34.378859
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    print(ie._download_webpage('http://video.udn.com/embed/news/300040', '300040'))
    # _VALID_URL = '^https\://video\.udn\.com/embed/news/\d+$'


# //video.udn.com/embed/news/300040

# //video.udn.com/play/news/300040

# Test:
# $ python -m youtube_dl.extractor.udn --debug --verbose --extractor=udn --format='bestvideo/best' 'http://video.udn.com/embed/news/300040'

# ^
# $ python -m youtube_dl.extractor.udn --debug --

# Generated at 2022-06-22 08:54:37.009136
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE



# Generated at 2022-06-22 08:54:43.361047
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE_NAME = 'udn'
    EXPECTED_URL = 'http://video.udn.com/embed/news/300040'
    EXPECTED_RESULT = '300040'
    ie = UDNEmbedIE()
    result = ie._match_id(EXPECTED_URL)
    if result != EXPECTED_RESULT:
        raise Exception('The input {} is not equal to expected {}'.format(result, EXPECTED_RESULT))

# Generated at 2022-06-22 08:54:49.366023
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import youtube_dl as ytdl
    class UDNEmbedIETest(unittest.TestCase):
        def test_constructor(self):
            result = ytdl.YoutubeDL({
                'username': 'nctuiot',
                'password': 'nctuiot',
                'usenetrc': False,
                'verbose': True,
                'simulate': False,
                'skip_download': True
            }).extract_info(
                'http://video.udn.com/embed/news/300040',
                download=False
            )
            self.assertEqual(result['ext'], 'mp4')
    return UDNEmbedIETest()
# test_UDNEmbedIE()

# Generated at 2022-06-22 08:56:02.748022
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result_print('test', 'UDNEmbedIE')
    ie = UDNEmbedIE()

    test_url = 'http://video.udn.com/embed/news/300040'
    result_print('test', test_url)
    
    test_filename = ie._real_extract(test_url)
    result_print('filename', test_filename['id'])
    result_print('filename', test_filename['title'])

# Generated at 2022-06-22 08:56:05.225791
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test_UDNEmbedIE = UDNEmbedIE()
    print (unit_test_UDNEmbedIE)


# Generated at 2022-06-22 08:56:07.487444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    downloader = UDNEmbedIE()
    result = downloader._real_extract(url)

# Generated at 2022-06-22 08:56:13.166371
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.UDNEmbedIE('UDNEmbedIE', 'https://video.udn.com/embed/news/300040', 'https://video.udn.com/embed/news/300040', '300040')

# Generated at 2022-06-22 08:56:18.257634
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(UDNEmbedIE.ie_key())
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_NAME == 'udn'
    assert ie.ie_desc() == '聯合影音'



# Generated at 2022-06-22 08:56:19.595391
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne is not None

# Generated at 2022-06-22 08:56:20.538720
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:56:21.374723
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:56:27.812195
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE(UDNEmbedIE.ie_key(), 'http://video.udn.com/embed/news/333455')
    assert IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._PROTOCOL_RELATIVE_VALID_URL == IE._VALID_URL[9:]

# Generated at 2022-06-22 08:56:37.226595
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    _TESTS = [{
        'url': 'http://video.udn.com/embed/news/300040',
        'info_dict': {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        },
        'expected_warnings': ['Failed to parse JSON Expecting value'],
    }]
    for t in _TESTS:
        ie.extract(t['url'])

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-22 08:59:09.221074
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UDNEmbed'

# Generated at 2022-06-22 08:59:15.228383
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040',{'test':'test'})
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._download_webpage.__name__ == '_download_webpage'

# Generated at 2022-06-22 08:59:18.954516
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
  # pylint: disable=E1101
  UDNEmbedIE.test()

if __name__ == "__main__":
  test_UDNEmbedIE()

# Generated at 2022-06-22 08:59:19.962765
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-22 08:59:24.642383
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(UDNEmbedIE._VALID_URL, UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-22 08:59:26.427471
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-22 08:59:30.516798
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(re.match(ie._PROTOCOL_RELATIVE_VALID_URL,
            '//video.udn.com/embed/news/300040') is not None)
    assert(re.match(ie._VALID_URL, 'http://video.udn.com/embed/news/300040') is
            not None)

# Generated at 2022-06-22 08:59:37.332650
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # For more detail, please see:
    # https://github.com/rg3/youtube-dl/pull/2583#issuecomment-52356150
    if not hasattr(compat_urlparse, 'parse_qs'):
        return

    assert 'UDNEmbedIE' == UDNEmbedIE._WORKER_CLASS
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

    o = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert o._WORKER_CLASS == 'UDNEmbedIE'
    assert o._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

    # Check normal URL cases

# Generated at 2022-06-22 08:59:47.765717
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_instance = UDNEmbedIE()
    assert udn_instance.IE_NAME == "UDNEmbed"
    assert udn_instance.IE_DESC == '聯合影音'
    assert udn_instance._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_instance._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'