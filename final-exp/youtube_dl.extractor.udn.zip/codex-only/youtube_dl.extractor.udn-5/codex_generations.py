

# Generated at 2022-06-24 13:39:33.510847
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    The constructor of class UDNEmbedIE.
    '''
    UDNEmbedIE()


# Generated at 2022-06-24 13:39:42.085933
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Constructor test for class UDNEmbedIE without optional parameters")
    udn = UDNEmbedIE()
    print("Object : " + str(udn))
    print("url : " + str(udn.url))
    print("ie : " + str(udn.ie))
    print("video_id : " + str(udn.video_id))
    print("video_url : " + str(udn.video_url))
    print("ext : " + str(udn.ext))
    print("\nConstructor test for class UDNEmbedIE with optional parameters")
    udn = UDNEmbedIE("https://video.udn.com/embed/news/300040", "udn")
    print("Object : " + str(udn))

# Generated at 2022-06-24 13:39:43.083336
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:39:50.586540
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test the constructor of class UDNEmbedIE
    """
    splash_url = "http://video.udn.com/embed/news/300040"
    tester = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    tester.to_screen("Testing constructor of class UDNEmbedIE")
    assert tester._match_id("https://video.udn.com/embed/news/300040") == "300040", "Return result should be 300040"

# Generated at 2022-06-24 13:39:59.019826
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the normal case
    UDNEmbedIE()._real_extract(('https://video.udn.com/embed/news/'
                                '300040'))

    # Test the case without video options
    UDNEmbedIE()._real_extract(('https://video.udn.com/embed/news/'
                                '790453'))

    # Test the case with YouTube video
    UDNEmbedIE()._real_extract(('https://video.udn.com/embed/news/'
                                '311383'))

# Generated at 2022-06-24 13:40:00.993658
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE(1000, 1000, 'http://video.udn.com/embed/news/300040', 1000)
    udne.extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:40:03.249786
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC
    assert ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-24 13:40:07.921271
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    result = UDNEmbedIE()._real_extract(url)
    assert result["id"] == "300040"
    assert result["title"] == "生物老師男變女 全校挺\"做自己\""
    assert "youtube_url" not in result
    assert "thumbnail" in result
    # The number of formats may be different from run to run
    # Here we just check the length of the list
    assert len(result["formats"]) > 0

# Generated at 2022-06-24 13:40:10.765565
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:40:20.970196
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Simple test for class UDNEmbedIE
    """
    url = 'http://video.udn.com/embed/news/300040'
    url_ytdl = 'https://video.udn.com/play/news/303776'
    assert UDNEmbedIE.suitable(url)
    assert not UDNEmbedIE.suitable(url_ytdl)
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.suitable(url)
    assert udn_embed_ie.suitable(url_ytdl)
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmb

# Generated at 2022-06-24 13:40:25.833284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._match_id(url) == '300040'
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._TESTS

# Generated at 2022-06-24 13:40:29.897837
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    web_url = UDNEmbedIE._VALID_URL
    if not web_url.startswith('http'):
        web_url = 'http' + web_url
    assert web_url == 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:40:37.736210
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDNEmbed'
    assert udn_embed_ie.ie_desc() == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:40:42.501716
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert 'UDN' in ie.IE_DESC
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:49.840381
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.match(UDNEmbedIE._VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert re.match(UDNEmbedIE._VALID_URL, 'http://video.udn.com/play/news/300040')
    assert re.match(UDNEmbedIE._VALID_URL, 'https://video.udn.com/play/news/300040')
    assert not re.match(UDNEmbedIE._VALID_URL, 'http://video.udn.com/news/300040')

# Generated at 2022-06-24 13:40:57.719865
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()

    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._TESTS

    assert udn_embed_ie._match_id('https://video.udn.com/embed/news/300040').group('id') == '300040'

# Generated at 2022-06-24 13:41:00.108411
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url in UDNEmbedIE._TESTS:
        if url['only_matching'] == True:
            continue

        return

# Generated at 2022-06-24 13:41:06.074779
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    udnvideo = UDNEmbedIE()
    assert udnvideo._match_id(url) == "300040"
    assert udnvideo._VALID_URL == r'https?:' + udnvideo._PROTOCOL_RELATIVE_VALID_URL
    assert udnvideo._TESTS[0]['url'] == url

# Generated at 2022-06-24 13:41:09.095383
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_download import get_testcases

    testcases = get_testcases(UDNEmbedIE)
    UDNEmbedIE(testcases[0][0])

# Generated at 2022-06-24 13:41:10.644001
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.IE_DESC)

# Generated at 2022-06-24 13:41:13.465313
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE."""
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'udn'

# Generated at 2022-06-24 13:41:20.370659
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Please don't change "class UDNEmbedIE" to "class UDNEmbedIE,".
    assert UDNEmbedIE.IE_NAME == 'udn'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:23.010371
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.search(UDNEmbedIE._VALID_URL, UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL) != None

# Generated at 2022-06-24 13:41:28.018534
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Test

# Generated at 2022-06-24 13:41:32.503179
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test that subclass UDNEmbedIE could be built from VideoIE
    from ..extractor import VideoIE
    assert type(VideoIE.ie_keywords['udn']) == type
    assert issubclass(VideoIE.ie_keywords['udn'], (UDNEmbedIE, ))
    assert issubclass(UDNEmbedIE, InfoExtractor)

# Generated at 2022-06-24 13:41:33.313447
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE();

# Generated at 2022-06-24 13:41:42.636806
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None).IE_DESC == '聯合影音'
    assert UDNEmbedIE(None)._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE(None)._VALID_URL == '(?i)https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE(None)._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE(None)._TESTS[0]['info_dict']['id'] == '300040'
    assert UD

# Generated at 2022-06-24 13:41:44.180112
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:41:50.385537
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/300040'
    info_dict = ie._real_extract(url)
    assert info_dict['id'] == '300040'
    assert info_dict['title'] == '生物老師男變女 全校挺"做自己"'
    assert info_dict['formats'][0]['url'] == 'https://moas.udn.com/vod/udn/2000/35/300040.mp4/300040_hd_1_0.mp4'

# Generated at 2022-06-24 13:41:53.535252
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE().IE_DESC == UDNEmbedIE.IE_DESC

# Generated at 2022-06-24 13:41:57.004878
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:07.640118
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert re.match(udne._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.match(udne._VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert not re.match(udne._VALID_URL, 'http://video.udn.com')
    assert not re.match(udne._VALID_URL, 'http://video.udn.com/play')
    assert not re.match(udne._VALID_URL, 'http://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:42:12.053753
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'].startswith('http://')
    assert ie._TESTS[1]['url'].startswith('https://')

# Generated at 2022-06-24 13:42:21.337538
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_cases = [
        # protocol relative url
        '//video.udn.com/embed/news/300040',
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        # full url
        'http://video.udn.com/play/news/300040',
        'https://video.udn.com/play/news/300040'
    ]

    for url in test_cases:
        test_UDNEmbedIE = UDNEmbedIE(url)
        assert test_UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:42:28.666993
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(udn._TESTS) == 3


# Generated at 2022-06-24 13:42:30.098143
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test random urls
    UDNEmbedIE()._match_id('http://video.udn.com/embed/news/300040')

    # test of __init__ function
    UDNEmbedIE()

# Generated at 2022-06-24 13:42:36.303072
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ieObj = UDNEmbedIE()

    # Unit test for _match_id(url)
    assert ieObj._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ieObj._match_id('//video.udn.com/embed/news/300040') == '300040'

if __name__ == '__main__':
    test_UDNEmbedIE()
    print('Successfully passed all tests')

# Generated at 2022-06-24 13:42:37.274879
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:42:41.199247
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_video = UDNEmbedIE()
    test_urls = ['//video.udn.com/embed/news/300040']

    for test_url in test_urls:
        # print('test_url: %s' % test_url)
        udn_video.extract(test_url)

# Generated at 2022-06-24 13:42:49.906816
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:42:51.869159
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:42:58.590135
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert issubclass(UDNEmbedIE, InfoExtractor)
    assert UDNEmbedIE.IE_DESC == '聯合影音'

    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:04.919271
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:05.924660
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie)

# Generated at 2022-06-24 13:43:07.600246
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert isinstance(ie, UDNEmbedIE), 'UDNEmbedIE is the constructor of class UDNEmbedIE'

# Generated at 2022-06-24 13:43:18.640666
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from unittest import TestCase
    from .test_utils import make_test_cases

    class UDNEmbedIETestCase(TestCase):
        def check_url(self, url, expected_id, expected_protocol, expected_domain):
            udn_ie = UDNEmbedIE()
            url_info = compat_urlparse.urlparse(url)
            self.assertEqual(
                udn_ie._match_id(url), expected_id,
                'id in URL {} should be {} but is {}'.format(
                    url, expected_id, udn_ie._match_id(url)))

# Generated at 2022-06-24 13:43:23.921946
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    host = 'http://video.udn.com/'
    video_page_links = [
        '//video.udn.com/embed/news/300040',
        '//video.udn.com/play/news/303776',
        ]
    for video_page_link in video_page_links:
        test_url = host + video_page_link
        res = re.search(UDNEmbedIE._VALID_URL, test_url)
        if not res:
            print('the url \'' + test_url + '\' is a invalid')



# Generated at 2022-06-24 13:43:32.543621
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Give real url
    url = 'http://video.udn.com/embed/news/300040'
    theclass = UDNEmbedIE()
    assert theclass._set_video_id(url) == '300040'

    # Give real url and a fake one
    url = 'http://video.udn.com/embed/news/300040'
    fake_url = 'https://video.udn.com/embed/news/300040'
    theclass = UDNEmbedIE()
    assert theclass._set_video_id(url) == '300040'
    assert theclass._set_video_id(fake_url) == '300040'

    # Give fake url
    url = 'http://video.udn.com/fake/news/300040'
    theclass = UDNEmbedIE()

# Generated at 2022-06-24 13:43:41.665642
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed', 'ie_key() returns invalid value'
    assert ie.ie_desc() == '聯合影音', 'ie_desc() returns invalid value'

    # example from the original test cases
    ie = UDNEmbedIE()
    info = ie.extract('http://video.udn.com/embed/news/300040')
    assert info['id'] == '300040', 'extract() returns invalid id'
    assert info['ext'] == 'mp4', 'extract() returns invalid extension'
    assert 'title' in info, 'extract() returns no title'
    assert 'thumbnail' in info, 'extract() returns no thumbnail'

# Generated at 2022-06-24 13:43:52.023747
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:53.772047
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed


# Generated at 2022-06-24 13:43:56.160351
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    instance.suitable(None)


# Generated at 2022-06-24 13:44:00.379259
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ud = UDNEmbedIE()
    assert ud.IE_DESC == '聯合影音'
    assert ud._VALID_URL == 'https?:' + ud._PROTOCOL_RELATIVE_VALID_URL
    return ud

# Generated at 2022-06-24 13:44:03.439449
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_NAME == 'udn'
    assert udn_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:44:04.306196
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result = UDNEmbedIE()

# Generated at 2022-06-24 13:44:07.684684
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        ie = UDNEmbedIE()
        assert isinstance(ie, InfoExtractor)
        print('Unit test passed!')
        print('Class name: ' + ie.__class__.__name__)
    except AssertionError as e:
        print('Unit test failed!')
      

# Generated at 2022-06-24 13:44:08.331225
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)

# Generated at 2022-06-24 13:44:13.106555
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE:
    """

    # Function '_real_extract' of UDNEmbedIE
    def test_UDNEmbedIE__real_extract(self):
        """
        Test if the method '_real_extract' works.
        """

        # Test cases:
        # Test case 1:
        # Test if the method works without error (no error raise) when the options
        # in the webpage is parsed successfully.
        # Function '_real_extract' should be called.
        #
        # Input:
        # url: url to be extracted
        # webpage: webpage contains information of the video
        # video_id: id of the video
        # video_urls: urls of the video
        #
        # Output:
        # info_dict: a

# Generated at 2022-06-24 13:44:21.193325
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040') is not None
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/play/news/300040') is not None
    assert re.match(UDNEmbedIE._VALID_URL, 'http://video.udn.com/embed/news/300040') is not None
    assert re.match(UDNEmbedIE._VALID_URL, 'https://video.udn.com/embed/news/300040') is not None

# Generated at 2022-06-24 13:44:31.852815
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-24 13:44:43.481444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test that the regular expression for protocol relative URLS matches the correct URL.
    url = '//video.udn.com/embed/news/300040'
    proto_relative_match = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match(url)
    assert proto_relative_match
    assert proto_relative_match.group('id') == '300040'

    # Test that the regular expression for regular URLS matches the correct URL.
    url = 'https://video.udn.com/embed/news/300040'
    regex_match = UDNEmbedIE._VALID_URL.match(url)
    assert regex_match
    assert regex_match.group('id') == '300040'
    assert regex_match.group(0) == url

    # Test that the regular expression for regular UR

# Generated at 2022-06-24 13:44:48.476077
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import URLSies
    from .common import TESTS
    from .common import playlist_result

    urlsies = URLSies(TESTS)
    urlsies.populate_ie_key_map({'UDNEmbed': UDNEmbedIE})

    for (url, ie_key) in urlsies.iteritems():
        yield playlist_result, URLSies(TESTS, ie_key), ie_key, url

# Generated at 2022-06-24 13:44:51.617662
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    test_url = 'http://video.udn.com/embed/news/300040'
    test_ie = UDNEmbedIE()
    assert test_ie.suitable(test_url)

# Generated at 2022-06-24 13:44:55.092283
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:56.194754
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _ = UDNEmbedIE()
    print('Done')

# Generated at 2022-06-24 13:44:59.976821
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE = UDNEmbedIE()
    UDNEmbedIE._downloader.urlopen = lambda: None
    UDNEmbedIE._downloader.cache = lambda: None
    UDNEmbedIE._real_extract(url)

# Generated at 2022-06-24 13:45:02.598427
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
    UDNEmbedIE()._real_extract('http://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:45:07.755278
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    ie._VALID_URL = r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:45:15.608974
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test protocol relative URL
    udn_url = '//video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.suitable(udn_url) is True
    assert ie._VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert ie._VALID_URL.startswith('https?:') is True
    assert ie._PROTOCOL_RELATIVE_VALID_URL.startswith('//') is True
    assert ie._match_id(udn_url) == '300040'

    # Test valid URL
    udn_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.suitable(udn_url)

# Generated at 2022-06-24 13:45:20.109078
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:45:23.155218
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except:
        assert False, 'init UDNEmbedIE failed'

# Generated at 2022-06-24 13:45:24.583427
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie)

# Generated at 2022-06-24 13:45:26.347631
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040',None)

# Generated at 2022-06-24 13:45:33.007757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040', '', '')
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'(?:https?:)?//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:(?:https?:)?//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:35.614270
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    ie = UDNEmbedIE(url)
    assert ie.extract_info(url) == {}


# Generated at 2022-06-24 13:45:38.888318
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    from .common import BaseTest

    class UDNEmbedIETest(BaseTest):
        extractor = UDNEmbedIE

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-24 13:45:48.849320
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # Unit tests for _PROTOCOL_RELATIVE_VALID_URL
    url = '//video.udn.com/embed/news/300040'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._match_id(url) == '300040'

    # Unit tests for _VALID_URL
    url = 'https://video.udn.com/embed/news/300040'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._match_id(url) == '300040'

# Generated at 2022-06-24 13:45:50.230359
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

# Generated at 2022-06-24 13:45:51.985828
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """This module implements the test for constructor of 'UDNEmbedIE'."""
    UDNEmbedIE()

# Generated at 2022-06-24 13:45:53.645646
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:45:59.166687
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Make sure _PROTOCOL_RELATIVE_VALID_URL can be used as an argument of constructor
    UDNEmbedIE._VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    test_url = 'http:%s' % UDNEmbedIE._VALID_URL
    try:
        UDNEmbedIE(compat_urlparse.urlparse(test_url))
    except:
        raise AssertionError('Constructor does not work, with url %s' % test_url)

# Generated at 2022-06-24 13:46:00.959337
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    print(udn)

# Generated at 2022-06-24 13:46:08.433356
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Arrange
    url = 'https://video.udn.com/embed/news/300040'
    # Act
    udn_embed_ie = UDNEmbedIE()
    # Assert
    assert udn_embed_ie._match_id(url) is not None
    assert udn_embed_ie.IE_NAME == 'udn:embed'
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie.test


# Generated at 2022-06-24 13:46:11.839193
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(test_url)
    print("ID: " + ie._match_id(test_url))
    assert ie._match_id(test_url) == '300040'

# Generated at 2022-06-24 13:46:12.881302
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """ Test function for constructor of class UDNEmbedIE"""
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:16.576491
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	# url = "http://video.udn.com/embed/news/300040"
	# url = "http://video.udn.com/embed/news/303776"
	url = "http://video.udn.com/embed/news/303776"
	ie = UDNEmbedIE()
	# ie.download(url)
	# ie.download(url)
	ie.extract(url)

test_UDNEmbedIE()

# Generated at 2022-06-24 13:46:24.883984
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import TestIE
    test = TestIE(UDNEmbedIE)

# Generated at 2022-06-24 13:46:26.468300
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result = UDNEmbedIE()
    print("test_UDNEmbedIE: %s" % result)

# Generated at 2022-06-24 13:46:34.632896
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040?autostart=true"
    ie = UDNEmbedIE()
    video_id = "300040"
    page = ie._download_webpage(url, video_id)
    assert page
    options_str = ie._html_search_regex(r'var\s+options\s*=\s*([^;]+);',
        page, "options")
    trans_options_str = js_to_json(options_str)
    options = ie._parse_json(trans_options_str, 'options', fatal=False) or {}
    assert options
    video_urls = options['video']
    assert video_urls
    title = options['title']
    assert title
    poster = options.get('poster')
   

# Generated at 2022-06-24 13:46:39.595755
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:41.577456
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Testing to construct the class UDNEmbedIE")
    cls = UDNEmbedIE()
    cls.ie_key()

# Generated at 2022-06-24 13:46:48.216989
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:46:50.633286
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE = UDNEmbedIE()
    # Test whether object of class UDNEmbedIE has been successfully created
    assert(UDNEmbedIE is not None)



# Generated at 2022-06-24 13:47:01.150722
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE(None)
    assert IE.IE_DESC == '聯合影音'
    assert IE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:05.186276
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from youtube_dl.downloader import _extract_info

    udn_video_info = _extract_info(InfoExtractor(), 'https://video.udn.com/embed/news/300040', {})
    assert udn_video_info['id'] == '300040'
    assert udn_video_info['ext'] == 'mp4'

# Generated at 2022-06-24 13:47:06.269986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie

# Generated at 2022-06-24 13:47:07.237260
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:47:08.081112
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:47:13.358315
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(UDNEmbedIE._downloader)._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE(UDNEmbedIE._downloader).IE_NAME == 'udnembed'
    assert UDNEmbedIE(UDNEmbedIE._downloader).IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:47:22.038099
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL  == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:26.054571
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.ie_key() == 'UDNEmbed'
    pattern = ie._VALID_URL
    ie = UDNEmbedIE('http://video.udn.com/play/news/300040')
    assert ie.ie_key() == 'UDNEmbed'
    pattern = ie._VALID_URL

# Generated at 2022-06-24 13:47:33.307361
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:47:37.590218
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'http://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

test_UDNEmbedIE()

# Generated at 2022-06-24 13:47:39.289971
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert(udne is not None)

# Should be successful

# Generated at 2022-06-24 13:47:43.571948
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test_meta = UDNEmbedIE._TESTS[0]
    v_url = unit_test_meta['url']
    udn_embed = UDNEmbedIE()

    assert udn_embed.suitable(v_url) is True
    assert udn_embed._match_id(v_url) == '300040'


# Generated at 2022-06-24 13:47:44.929165
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()



# Generated at 2022-06-24 13:47:53.803519
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    udn_embed_ie = UDNEmbedIE()
    # check if extractor is initialized
    assert udn_embed_ie is not None
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL \
        == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie.IE_NAME == 'udn'

# Generated at 2022-06-24 13:47:57.241952
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # test all the supported URLs
    for test_case in ie._TESTS:
        if test_case.get('only_matching', False):
            continue
        ie.url_result(test_case['url'])

# Generated at 2022-06-24 13:47:59.714521
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE('UDNEmbedIE')



# Generated at 2022-06-24 13:48:05.254030
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj._VALID_URL == r'https?:' + test_obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:48:06.162276
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:48:08.525806
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Default
    UDNEmbedIE()

    # Explicit
    UDNEmbedIE(UDNEmbedIE.ie_key())

# Generated at 2022-06-24 13:48:09.662314
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')


# Generated at 2022-06-24 13:48:21.313561
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _VALID_URL = 'https://video.udn.com/embed/news/300040'
    _INVALID_VALID_URL = 'https://video.udn.com/embed/news/3000'
    _PROTOCOL_RELATIVE_VALID_URL = '//video.udn.com/embed/news/300040'
    _TEST = [{
        'url': _VALID_URL,
        'only_matching': True,
    }, {
        'url': _INVALID_VALID_URL,
        'only_matching': False,
    }, {
        'url': _PROTOCOL_RELATIVE_VALID_URL,
        'only_matching': True,
    }]
    ie = UDNEmbedIE

# Generated at 2022-06-24 13:48:23.183590
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj.suite()

# Generated at 2022-06-24 13:48:25.210963
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

# Generated at 2022-06-24 13:48:33.968494
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    e = UDNEmbedIE()
    e.IE_DESC = '聯合影音'
    e._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    e._VALID_URL = r'https?:' + e._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:48:44.009474
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:48:46.474615
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'



# Generated at 2022-06-24 13:48:52.805975
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:49:03.460005
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    import os
    sys.path.append('..')
    # Test before modifying sys.path
    with open(os.path.join(__file__, '../.gitignore'), 'r') as f:
        assert f.readline() == '!test_UDNEmbedIE.py\n'

    from .test_downloads import _TEST_FILES
    from .downloadermock import DownloaderMock
    from .common import InfoExtractor

    # Test for making sure _VALID_URL, _TESTS and IE_DESC work properly
    # Refer to: https://github.com/rg3/youtube-dl/blob/3d9cb8c/youtube_dl/extractor/common.py#L113-L115
    udne = UDNEmbedIE()
    assert udne

# Generated at 2022-06-24 13:49:04.666834
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/embed/news/100059')

# Generated at 2022-06-24 13:49:07.084960
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:49:12.278234
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r_UDNEmbedIE = UDNEmbedIE()
    assert r_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert r_UDNEmbedIE._VALID_URL == r'https?:' + r_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL + r'$'

# Generated at 2022-06-24 13:49:20.436729
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._TESTS[0]['url'] == "http://video.udn.com/embed/news/300040"
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:49:30.477132
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_DESC == '聯合影音'
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == 'https?:' + UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL
    assert 'http://video.udn.com/embed/news/300040' in list(map(lambda test: test['url'], UDNEmbedIE()._TESTS))

# Generated at 2022-06-24 13:49:33.485732
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'udn'