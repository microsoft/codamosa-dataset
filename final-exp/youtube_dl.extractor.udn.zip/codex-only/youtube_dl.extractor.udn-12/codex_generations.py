

# Generated at 2022-06-24 13:39:41.027251
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:39:47.478312
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    pattern = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert re.match(pattern, '//video.udn.com/embed/news/300040') is not None
    assert re.match(pattern, '//video.udn.com/play/news/300040') is not None
    assert re.match(pattern, '//video.udn.com/foo/bar/300040') is None
    assert re.match(pattern, 'https://video.udn.com/embed/news/300040') is None
    assert re.match(pattern, 'http://video.udn.com/embed/news/300040') is None

    # test UDNEmbedIE._VALID_URL
    pattern

# Generated at 2022-06-24 13:39:55.312153
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_1 = 'http://video.udn.com/embed/news/300040'
    url_2 = 'https://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._match_id(url_1) == '300040'
    assert UDNEmbedIE._match_id(url_2) == '300040'
    assert UDNEmbedIE._match_id('http://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-24 13:40:00.429607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.extractor.udn import UDNEmbedIE
    from youtube_dl.utils import FakeYDL
    ie = UDNEmbedIE(FakeYDL())
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:40:02.447786
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    v = UDNEmbedIE()
    v.suitable(url)
    v.extract(url)

# Generated at 2022-06-24 13:40:03.629654
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
   url = 'https://video.udn.com/embed/news/300040'
   UDNEmbedIE(url)

# Generated at 2022-06-24 13:40:09.599741
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_url = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert re.search(valid_url, 'http://video.udn.com/embed/news/300040')
    assert re.search(valid_url, 'https://video.udn.com/embed/news/300040')
    assert re.search(valid_url, '//video.udn.com/embed/news/300040')
    assert re.search(valid_url, '//video.udn.com/play/news/300040')
    assert re.search(valid_url, 'http://video.udn.com/embed/news/300040')
    assert not re.search(valid_url, 'http://video.udn.com/embed/news/300040/')

# Generated at 2022-06-24 13:40:13.113900
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:22.683348
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    from .common import FakeYDL
    from .common import test_expected_warnings

    test_youtube_video = 'https://www.youtube.com/watch?v=Bg_Q7KYWG1g'
    test_video = 'http://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE(FakeYDL())

    test_expected_warnings(
        lambda: udn_embed._extract_urls(test_video, None, re.compile('video.*?{(.*?)}', re.DOTALL), 'video'),
        ['Failed to parse JSON Expecting value'])

    assert(udn_embed._match_id(test_video) == '300040')


# Generated at 2022-06-24 13:40:24.041492
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE())

# Generated at 2022-06-24 13:40:24.943624
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:40:27.224794
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj != None, "Failed to construct an object of class UDNEmbedIE"

# Generated at 2022-06-24 13:40:27.849430
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-24 13:40:32.302515
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?:(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'

# Generated at 2022-06-24 13:40:37.736433
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-24 13:40:46.806570
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._match_id('https:http://video.udn.com/embed/news/300040/') == '300040'
    assert ie._match_id('http:http://video.udn.com/embed/news/300040/') == '300040'
    assert ie._match_id('http://video.udn.com/embed/news/300040/') == '300040'
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('http://video.udn.com/embed/news/300040?abc') == '300040'

# Generated at 2022-06-24 13:40:50.192986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/300040'
    video_id = udne._match_id(url)
    assert video_id == '300040'

# Generated at 2022-06-24 13:40:52.585011
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:03.342776
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:41:10.922690
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert 'IE_DESC' in UDNEmbedIE.__dict__
    assert '_TESTS' in UDNEmbedIE.__dict__


# Generated at 2022-06-24 13:41:14.068806
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embedIE = UDNEmbedIE()
    url = "http://video.udn.com/embed/news/300040"
    assert udn_embedIE._match_id(url) == "300040"

# Generated at 2022-06-24 13:41:15.862959
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:41:18.769301
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
        assert True
        print ('\033[1;32m[+]Constructor test success!\033[0m')
    except:
        assert False
        print ('\033[1;31m[-]Constructor test fail!\033[0m')


# Generated at 2022-06-24 13:41:22.829221
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    trueValue = (
        UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
        UDNEmbedIE._VALID_URL)

    falseValue = (
        UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
        UDNEmbedIE._VALID_URL,
        )

    for true in trueValue:
        assert UDNEmbedIE._match_id(true)
    for false in falseValue:
        assert not UDNEmbedIE._match_id(false)

# Generated at 2022-06-24 13:41:29.405136
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    # Test if class is constructed successfully
    ie = UDNEmbedIE()
    assert (ie.IE_NAME == 'udnembed')
    assert (ie.IE_DESC == '聯合影音')
    assert (ie._VALID_URL == 'http://video.udn.com/embed/news/(?P<id>\\d+)')

# Generated at 2022-06-24 13:41:34.864574
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:41:43.948943
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'

    assert ie._match_id('http://video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-24 13:41:46.074265
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('Udn')
    assert ie.ie_key() == 'Udn'
    assert ie.ie_desc() == '聯合影音'



# Generated at 2022-06-24 13:41:52.961698
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie._download_webpage.__self__ == ie
    assert ie._match_id(ie._TESTS[0]['url']).isdigit()

# Generated at 2022-06-24 13:41:59.609029
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.IE_NAME == 'udn'
    assert IE.IE_DESC == '聯合影音'
    assert IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert IE._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:42:04.756174
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie == type(ie)
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[1].get('only_matching') == True
    assert ie._TESTS[2].get('only_matching') == True


# Generated at 2022-06-24 13:42:16.439281
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    # The default value for 'url'
    assert ie.IE_DESC == '聯合影音'
    # The default value for 'IE_DESC'
    assert ie._VALID_URL == 'https?://video.udn.com/(?:embed|play)/news/(?P<id>\\d+)'
    # The default value for '_VALID_URL'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\\d+)'
    # The default value for '_PROTOCOL_RELATIVE_VALID_URL'
    assert ie._match_id

# Generated at 2022-06-24 13:42:18.287164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE('udn')
    assert u.IE_NAME == 'udn'

# Generated at 2022-06-24 13:42:25.094582
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # Test case: _PROTOCOL_RELATIVE_VALID_URL
    # input - URL: '//video\.udn\.com/embed/news/300040',
    # expected output - regex group 'id' is '300040'
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'

    # input - URL: '//video.udn.com/play/news/303776',
    # expected output - regex group 'id' is '303776'
    assert ie._match_id('//video.udn.com/play/news/303776') == '303776'

    # Test case: _VALID_URL
    # input - URL: 'https://video.udn.com/embed/news

# Generated at 2022-06-24 13:42:30.874459
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '1'
    url = 'https://video.udn.com/embed/news/' + video_id
    prot_rel_url = '//video.udn.com/embed/news/' + video_id
    se = UDNEmbedIE()
    for a_url in [url, prot_rel_url]:
        assert se._match_id(a_url) == video_id

# Generated at 2022-06-24 13:42:34.069123
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()._real_extract(
        'http://video.udn.com/embed/news/300040')
    print('udnEmbedIE: ', udnEmbedIE)

# Generated at 2022-06-24 13:42:38.854245
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/play/news/300040')


# Generated at 2022-06-24 13:42:40.780613
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

# Generated at 2022-06-24 13:42:49.734074
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:56.473247
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE();

    assert(udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udne._VALID_URL == r'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL)
    assert(udne.IE_DESC == '聯合影音')
    

# Generated at 2022-06-24 13:43:00.310837
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test normal constructor
    UDNEmbedIE("http://video.udn.com/embed/news/300040")
    UDNEmbedIE("https://video.udn.com/embed/news/300040")
    # Test constructor for protocol-relative URL
    UDNEmbedIE("//video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:43:02.200096
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE(UDNEmbedIE._VALID_URL)
	assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:04.052942
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from . import UDNEmbedIE
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:07.762761
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/news/300040')
    UDNEmbedIE('https://video.udn.com/embed/news/300040')
    # or it should return an error?
    #UDNEmbedIE('https://video.udn.com/news/300040')
    UDNEmbedIE('https://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:43:17.081429
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url1 = "http://video.udn.com/embed/news/300040"
    udne = UDNEmbedIE()._match_id(url1)
    assert '300040' == udne

    url2 = "https://video.udn.com/embed/news/300040"
    udne = UDNEmbedIE()._match_id(url2)
    assert '300040' == udne

    url3 = 'https://video.udn.com/play/news/303776'
    udne = UDNEmbedIE()._match_id(url3)
    assert '303776' == udne

# Generated at 2022-06-24 13:43:19.712828
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._match_id(url)
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:43:21.054640
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None, None)


# Generated at 2022-06-24 13:43:29.968871
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test = UDNEmbedIE()
    assert unit_test.IE_DESC == '聯合影音'
    assert unit_test._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert unit_test._VALID_URL == r'https?:' + unit_test._PROTOCOL_RELATIVE_VALID_URL
    # Test _TESTS
    assert unit_test._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert unit_test._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert unit_test._T

# Generated at 2022-06-24 13:43:40.013996
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:40.749088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()

# Generated at 2022-06-24 13:43:50.975590
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_utils import make_absolute_url
    from ..compat import compat_urlparse
    
    print(UDNEmbedIE._VALID_URL)
    print(UDNEmbedIE._TESTS[1]['url'])
    
    # Check the case that the URL is not valid
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert make_absolute_url(UDNEmbedIE._TESTS[1]['url']) == 'https://video.udn.com/embed/news/300040'
    assert not UDNEmbedIE._VALID_URL_RE.match('http://www.udn.com/news/story/7/2278663')

# Generated at 2022-06-24 13:43:53.423346
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('test for UDNEmbedIE constructor')
    UDNEmbedIE('https://video.udn.com/embed/news/302148')


# Generated at 2022-06-24 13:43:58.638238
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test for constructor of class UDNEmbedIE
    """
    input_url = 'http://video.udn.com/embed/news/300040'
    try:
        IE = UDNEmbedIE(input_url)
    except:
        assert False



# Generated at 2022-06-24 13:44:03.684309
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:12.159191
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:13.772450
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:44:15.581763
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(UDNEmbedIE._downloader, None, None)._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-24 13:44:23.347981
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test_url --> http://video.udn.com/embed/news/300040
    url_test = 'http://video.udn.com/embed/news/300040'
    ydl_opts = {'skip_download': True}
    ie = UDNEmbedIE()
    result = ie.extract(url_test)
    print('video id : ', result['id'])
    print('title : ', result['title'])
    for f in result['formats']:
        print('format : ', f['format_id'], ' --- ', f['url'])
    print('thumbnail : ', result['thumbnail'])
# End test

# Generated at 2022-06-24 13:44:28.933591
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # assert that when the url is valid, the constructor of class UDNEmbedIE return a UDNEmbedIE object
    # the return value of type() is <class '__main__.UDNEmbedIE'>
    assert type(UDNEmbedIE(UDNEmbedIE.ie_key())) == type(UDNEmbedIE('test'))


# Generated at 2022-06-24 13:44:36.865706
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:38.516486
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie)



# Generated at 2022-06-24 13:44:40.279617
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    infoExtractor = UDNEmbedIE()
    assert infoExtractor.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:44:49.045512
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    UDNEmbedIE._VALID_URL = r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:44:58.115744
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # Matched 'https'
    assert(len(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL) == len('http') + len('://video.udn.com/(?:embed|play)/news/(?P<id>\d+)'))
    # The url must match http(s)://video.udn.com/(?:embed|play)/news/(?P<id>\d+)
    assert(re.match('http[s]?://video.udn.com/(?:embed|play)/news/(?P<id>\d+)', 'https://video.udn.com/play/news/303776'))
    # The url must not match http(s)://video.udn.com/(?:embed|play)/news/(?

# Generated at 2022-06-24 13:45:04.277509
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    assert(udne.IE_DESC == '聯合影音')
    assert(udne.ie._VALID_URL == 'https?:(?:embed|play)')
    assert(udne.ie._PROTOCOL_RELATIVE_VALID_URL == '//(?:embed|play)')
    assert(udne.ie._VALID_URL == 'https?://(?:embed|play)')
    assert(udne.ie_key() == 'UDNEmbed')

# Generated at 2022-06-24 13:45:13.484530
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'

# Generated at 2022-06-24 13:45:21.022205
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie._match_id(url) == '300040'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-24 13:45:32.296849
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..compat import unittest, yaml
    from ..utils import xpath_text
    from . import _FAKE_HTML

    class XmlExtractorTestCase(unittest.TestCase):
        def setUp(self):
            self.ie = UDNEmbedIE()
            self.html = _FAKE_HTML

    def _get_tests(filename):
        tests = []
        for test_spec in yaml.load(open(filename)):
            if not 'url' in test_spec:
                continue
            if test_spec.get('playlist', False):
                continue
            if not test_spec.get('info_dict'):
                test_spec['info_dict'] = {}
            # TODO: extract mgid and calculate upload date

# Generated at 2022-06-24 13:45:41.971091
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert re.match(ie._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert re.match(ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')


#

# Generated at 2022-06-24 13:45:45.156583
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL



# Generated at 2022-06-24 13:45:52.468691
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    parser = UDNEmbedIE()
    parser._html_search_regex(
        r'(?:var|const)\s+options\s*=\s*',
        'const options = {};',
        'options',
        default='Dummy'
    )
    parser._html_search_regex(
        r'(?:var|const)\s+options\s*=\s*',
        'var options = {};',
        'options',
        default='Dummy'
    )
    parser._parse_json(
        '{}',
        'options',
        fatal=True
    )

# Generated at 2022-06-24 13:45:54.829994
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE()
    assert a._VALID_URL == a.VALID_URL
    assert a._TESTS == a.TESTS

# Generated at 2022-06-24 13:46:01.383401
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE()._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE()._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE()._match_id('http://video.udn.com/play/news/300040') == '300040'
    assert UDNEmbedIE()._match_id('https://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-24 13:46:12.027831
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	# Test for extracting info from http://video.udn.com/embed/news/300040
	udn_embed_ie = UDNEmbedIE()
	url = 'http://video.udn.com/embed/news/300040'

	info = udn_embed_ie._real_extract(url)
	assert video_id == info['id']
	assert title == info['title']
	assert thumbnail == info['thumbnail']
	#m3u8_formats = info['formats']
	assert len(m3u8_formats) == 3

	# Test for extracting info from https://video.udn.com/embed/news/300040
	https_udn_embed_ie = UDNEmbedIE()

# Generated at 2022-06-24 13:46:18.007085
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    video_url = 'http://video.udn.com/embed/news/' + video_id
    video_info_dict = {
        'id': video_id,
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }
    video_params = {
        # m3u8 download
        'skip_download': True,
    }
    video_expected_warnings = ['Failed to parse JSON Expecting value']
    assert UDNEmbedIE(video_url, video_info_dict, video_params, video_expected_warnings)

# Generated at 2022-06-24 13:46:19.859971
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url ='https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._match_id(url)

# Generated at 2022-06-24 13:46:26.918676
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie(url='http://video.udn.com/embed/news/300040')
    assert ie(url='https://video.udn.com/embed/news/300040')
    assert ie(url='//video.udn.com/embed/news/300040')
    assert ie(url='https://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:46:28.849654
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = u'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().url_result(url, u'UDNEmbed')

# Generated at 2022-06-24 13:46:35.982368
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url1 = 'http://video.udn.com/embed/news/300040'
    url2 = 'https://video.udn.com/embed/news/300040'
    url3 = 'https://video.udn.com/play/news/303776'
    ie = UDNEmbedIE()

    print("The URL of the media is " + url1)
    extract_info1 = ie.extract(url1)
    print("The title of the media is " + extract_info1['title'])
    print("The ID of the media is " + extract_info1['id'])
    print("The thumbnail image of the media is " + extract_info1['thumbnail'])

    print("The URL of the media is " + url2)
    extract_info2 = ie.extract(url2)


# Generated at 2022-06-24 13:46:37.022398
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _udneie = UDNEmbedIE()

# Generated at 2022-06-24 13:46:38.537336
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:46:41.577980
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE(None)
    except TypeError:
        print("UDNEmbedIE(None) TypeError occurred")


# Generated at 2022-06-24 13:46:44.658663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    udn_embed = UDNEmbedIE('http://www.udn.com/video/')
    assert udn_embed.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:46:46.148757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    testObj = UDNEmbedIE()
    assert testObj.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:46:53.843992
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import make_extractor
    test_IE_DESC = 'TEST'
    test_VALID_URL = 'https://google.com.tw'
    test_IE = make_extractor(test_IE_DESC, test_VALID_URL)
    assert test_IE.IE_DESC == test_IE_DESC
    assert len(test_IE._VALID_URL) == 0
    assert len(test_IE._PROTOCOL_RELATIVE_VALID_URL) == 0
    assert len(test_IE._TESTS) == 0
    test_IE_DESC = 'TEST2'
    test_VALID_URL = 'https://www.google.com.tw'
    test_PROTOCOL_RELATIVE_VALID_URL = '//www.google.com.tw'

# Generated at 2022-06-24 13:47:00.794302
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udneie = UDNEmbedIE()
    assert udneie._VALID_URL == udneie.ie._VALID_URL
    assert udneie._PROTOCOL_RELATIVE_VALID_URL == udneie.ie._PROTOCOL_RELATIVE_VALID_URL
    result = udneie.ie._match_id(url)
    assert result == '300040'

# Generated at 2022-06-24 13:47:04.420487
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == UDNEmbedIE.IE_DESC

# Generated at 2022-06-24 13:47:05.306316
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()

# Generated at 2022-06-24 13:47:06.709300
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE.UDNEmbedIE({})

# Generated at 2022-06-24 13:47:13.719315
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	test_str = "https://video.udn.com/embed/news/300040"
	IE_test = UDNEmbedIE(test_str)
	assert IE_test.IE_DESC == "聯合影音"
	assert IE_test._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
	assert IE_test._VALID_URL == "https?:" + IE_test._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:47:15.018044
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test Constructor"""
    UDNEmbedIE()


# Generated at 2022-06-24 13:47:19.753850
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Arrange
    url = "http://video.udn.com/embed/news/300040"

    # Act
    UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040')
    ie = UDNEmbedIE(url)

    # Assert
    # TODO: determine how to test the extraction
    #assert ie.extract() == None

# Generated at 2022-06-24 13:47:21.812584
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()
    UDNEmbedIE().extract(url)

# Generated at 2022-06-24 13:47:24.824409
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:47:29.953057
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie_obj = UDNEmbedIE()
    print (dir(udn_embed_ie_obj))
    print (type(udn_embed_ie_obj))
    print (udn_embed_ie_obj.IE_NAME)
    print (udn_embed_ie_obj.IE_DESC)
    print (udn_embed_ie_obj._VALID_URL)
    print (udn_embed_ie_obj._TESTS)
    print ('*********************')

# Generated at 2022-06-24 13:47:40.417276
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE({})
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:47:51.479090
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = IEDownloader()
    if ie._downloader is None:
        ie._downloader = YoutubeDL()
    ie.url = 'https://video.udn.com/embed/news/300040'
    assert ie.extract()['_type'] == 'url', 'udn embed extract type error'
    assert ie.extract()['url'] == 'https://www.youtube.com/watch?v=Iy0G0P-IwYw', 'udn embed extract value error'

    ie.url = 'https://video.udn.com/play/news/303776'
    assert ie.extract()['_type'] == 'url', 'udn play extract type error'

# Generated at 2022-06-24 13:47:57.764957
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test _PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE._match_id('//video.udn.com/play/news/300040') == '300040'

    # test _VALID_URL
    assert UDNEmbedIE._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE._match_id('https://video.udn.com/play/news/300040') == '300040'
    assert UDNEmb

# Generated at 2022-06-24 13:48:04.288279
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    print(udn_embed_ie.IE_DESC)
    print(udn_embed_ie._VALID_URL)
    print(udn_embed_ie._NETRC_MACHINE)
    print(udn_embed_ie._TEST)


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:48:12.973455
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE(UDNEmbedIE._VALID_URL, downloader=None)
    assert i.IE_NAME == 'udn'
    assert i.IE_DESC == '聯合影音'
    assert i._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-24 13:48:23.375205
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor of class UDNEmbedIE must accept this format of URL
    assert UDNEmbedIE.suitable('https://video.udn.com/embed/news/300040')
    assert UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040')

    # Constructor of class UDNEmbedIE must not accept this format of URL
    assert not UDNEmbedIE.suitable('https://video.udn.com/news/300040')
    assert not UDNEmbedIE.suitable('http://video.udn.com/news/300040')

# Generated at 2022-06-24 13:48:26.991630
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test empty constructor
    ie = UDNEmbedIE()
    assert ie.IE_NAME == "udn"

    # Test constructor with given parameter
    ie = UDNEmbedIE(ie)
    assert ie.IE_NAME == "udn"

# Generated at 2022-06-24 13:48:28.597919
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UdnEmbedIE = UDNEmbedIE(None)
    assert isinstance(UdnEmbedIE, InfoExtractor)
    assert hasattr(UdnEmbedIE, 'extract')

# Generated at 2022-06-24 13:48:34.189311
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # Test for _PROTOCOL_RELATIVE_VALID_URL
    udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/embed/news/(?P<id>\d+)'
    url = 'http://video.udn.com/embed/news/300040'
    video_id = udn_embed_ie._match_id(url)
    assert video_id == '300040'

# Generated at 2022-06-24 13:48:40.586925
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:42.312956
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:48:46.409448
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    cls = globals()['UDNEmbedIE']
    ie = cls()
    check_dict = {'_VALID_URL': r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'}

    for key in check_dict:
        assert ie.__dict__[key] == check_dict[key]


# Generated at 2022-06-24 13:48:54.940483
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_NAME == 'udneembed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._WORKING == True

# Generated at 2022-06-24 13:48:55.729022
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    print(udn_embed)

# Generated at 2022-06-24 13:49:06.593986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # If any one of the following assertion fails, it may be caused by the
    # changes of web page's HTML.
    udne_ie = UDNEmbedIE()

# Generated at 2022-06-24 13:49:12.725861
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:49:16.323302
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._TESTS[0]["info_dict"]["title"] = (
        "生物老師男變女 全校挺做自己")
    UDNEmbedIE._TESTS[0]["info_dict"]["thumbnail"] = (
        r"re:^https?://.*\.jpg$")



# Generated at 2022-06-24 13:49:18.557902
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)

# Generated at 2022-06-24 13:49:20.538426
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-24 13:49:27.596581
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # isinstance
    assert isinstance(UDNEmbedIE(), InfoExtractor)
    # check type of properties
    assert isinstance(UDNEmbedIE.IE_NAME, str)
    assert isinstance(UDNEmbedIE._VALID_URL, str)
    assert isinstance(UDNEmbedIE.IE_DESC, str)
    assert isinstance(UDNEmbedIE._TESTS, list)



# Generated at 2022-06-24 13:49:38.498396
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL