

# Generated at 2022-06-24 13:39:43.751474
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:39:45.675488
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' != None
    assert 'UDNEmbedIE' != ''



# Generated at 2022-06-24 13:39:57.573638
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Verify function _match_id of class UDNEmbedIE
    udne_obj = UDNEmbedIE()
    url_list = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
    ]
    for url in url_list:
        assert udne_obj._match_id(url) == '300040'

    # Verify function _real_extract of class UDNEmbedIE

# Generated at 2022-06-24 13:39:58.228218
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()



# Generated at 2022-06-24 13:39:59.129548
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pylint: disable=unused-variable
    inst = UDNEmbedIE()

# Generated at 2022-06-24 13:40:01.910475
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:40:08.009987
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert u.suitable(url)
    # for avoid to error,
    assert u.IE_NAME == 'udn'
    assert u.IE_DESC == '聯合影音'
    assert u.VALID_URL == u'https?://video.udn.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u.get_url_re().match(url)
    assert u.IE_NAME in urllib.request.urlopen(url).info().get(u'content-type')
    assert u.IE_NAME in u.working

# Generated at 2022-06-24 13:40:11.681752
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()

    # test match
    x.match('http://video.udn.com/embed/news/300040')
    x.match('https://video.udn.com/embed/news/300040')

    # test no match
    x.match('http://video.udn.com/embed/news/300040/')
    x.match('https://video.udn.com/embed/news/300040/')
    x.match('https://video.udn.com/play/news/300040/')

# Generated at 2022-06-24 13:40:19.178328
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

    url = 'http://video.udn.com/embed/news/300040'
    m = re.match(UDNEmbedIE._VALID_URL, url)
    assert m.groupdict()['id'] == '300040'

# Generated at 2022-06-24 13:40:20.120128
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor
    UDNEmbedIE()

# Generated at 2022-06-24 13:40:27.673001
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .youtube import YoutubeIE
    from .udn import UDNIE
    from .utils import match_filter_func
    from .compat import compat_urlparse
    from .extractors.generic import GenericIE
    from .extractors.video_duration import VideoDurationIE

    url = 'http://video.udn.com/embed/news/300040'
    ie = InfoExtractor.for_url(url)
    assert isinstance(ie, UDNEmbedIE)
    ie = InfoExtractor.for_url('http://video.udn.com/embed/news/300040?youtube=123')
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-24 13:40:34.113284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()
	assert ie.IE_NAME == 'udn'
	assert ie.IE_DESC == '聯合影音'
	assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
	assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:40:37.169059
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the unit test
    try:
        UDNEmbedIE()._match_id('https://video.udn.com/embed/news/300040')
    except:
        assert False
    return

# Generated at 2022-06-24 13:40:38.707537
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE = UDNEmbedIE(url)
    assert UDNEmbedIE.url == url

# Generated at 2022-06-24 13:40:43.485455
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE('UDN','https://video.udn.com/play/news/303776')
    assert udne._VALID_URL == UDNEmbedIE._VALID_URL
    assert udne._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:40:45.891755
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    k = UDNEmbedIE.__init__(UDNEmbedIE)

# Generated at 2022-06-24 13:40:46.393143
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None) is not None

# Generated at 2022-06-24 13:40:56.513490
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == 'udn'
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-24 13:41:02.975480
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == ie._UNESCAPED_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == ie._UNESCAPED_PROTOCOL_RELATIVE_URL

# Unit test to cover the execution path of the code in section "if options:"
#   of method _real_extract(self, url) of class UDNEmbedIE

# Generated at 2022-06-24 13:41:14.253526
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_IE = UDNEmbedIE()
    assert udn_embed_IE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_IE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn_embed_IE._TESTS[0]['info_dict']['id'] == '300040'
    assert udn_embed_IE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:41:15.833799
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')



# Generated at 2022-06-24 13:41:16.741007
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == '__main__':
        print(UDNEmbedIE())

# Generated at 2022-06-24 13:41:22.323547
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert re.search(IE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert not re.search(IE._VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.search(IE._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert re.search(IE._VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert re.search(IE._VALID_URL, 'http://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:41:24.515169
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE(None)
    assert udnEmbedIE.IE_NAME == 'udn'

# Generated at 2022-06-24 13:41:33.794953
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = "http://video.udn.com/embed/news/300040"
    url_ie = UDNEmbedIE()
    try:
        # First check if the url can be recognized
        assert url_ie.suitable(test_url)
    except Exception as e:
        # If not, raise an exception and stop the test
        raise e
    # Else, get only the video
    test_result = url_ie.extract(test_url)
    # And print it
    print('id: %s' % test_result['id'])
    print('title: %s' % test_result['title'])
    print('formats: %s' % test_result['formats'])
    print('thumbnail: %s' % test_result['thumbnail'])


# Generated at 2022-06-24 13:41:36.575841
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:37.172801
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:41:39.605209
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    testcase = UDNEmbedIE('UDNEmbedIE','http://video.udn.com/embed/news/300040')
    return testcase


# Generated at 2022-06-24 13:41:41.531330
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().get_info(url)

# Generated at 2022-06-24 13:41:50.567333
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern_m3u8_download = re.compile(r'https?://.*m3u8')
    pattern_f4m_download = re.compile(r'https?://.*f4m')
    for test_data in UDNEmbedIE._TESTS:
        test_data = test_data.copy()
        if 'expected_warnings' in test_data:
            continue

        if 'params' in test_data:
            if test_data.get('params', {}).get('skip_download'):
                continue

        info = UDNEmbedIE()._real_extract(test_data['url'])

        downloaded_formats = info.get('formats', [])

# Generated at 2022-06-24 13:41:51.245090
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:41:55.598015
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.video_id == '300040'
    assert ie.url == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:42:07.535682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_object = UDNEmbedIE()
    assert test_object.IE_NAME == 'udn'
    assert test_object.IE_DESC == '聯合影音'
    assert test_object._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_object._TESTS[0]['info_dict']['id'] == '300040'
    assert test_object._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert test_object._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-24 13:42:09.876411
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert hasattr(UDNEmbedIE, 'ie_key')
    assert hasattr(UDNEmbedIE, 'ie_desc')


# Generated at 2022-06-24 13:42:11.727005
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    _ie = UDNEmbedIE()
    _ie._real_extract(url)

# Generated at 2022-06-24 13:42:16.333410
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/303776'
    ie = UDNEmbedIE(url, UDNEmbedIE.IE_DESC)
    assert ie.ie_key() == 'UDNEmbed'



# Generated at 2022-06-24 13:42:19.105299
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    if ie is not None:
        print("UDNEmbedIE constructor works properly")
    else:
        print("UDNEmbedIE constructor failed")

# Test for real_extract method of class UDNEmbedIE

# Generated at 2022-06-24 13:42:26.353558
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    test_url1 = 'http://video.udn.com/embed/news/300040'
    test_result1 = udn_embed_ie._match_id(test_url1)
    assert test_result1 == '300040', 'Unit test for id extraction of class UDNEmbedIE failed.'

    test_url2 = 'https://video.udn.com/embed/news/300040'
    test_result2 = udn_embed_ie._match_id(test_url2)
    assert test_result2 == '300040', 'Unit test for https url of class UDNEmbedIE failed.'

# Generated at 2022-06-24 13:42:32.930866
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj.IE_DESC == '聯合影音'
    assert test_obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj._VALID_URL == r'https?:' + test_obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:39.845814
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:41.624533
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']

# Generated at 2022-06-24 13:42:46.888232
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    c = UDNEmbedIE()
    assert c.IE_DESC == '聯合影音'
    assert c._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert c._VALID_URL == r'https?:' + c._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:53.374589
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:55.285094
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()


# Generated at 2022-06-24 13:43:01.120092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert ie.suitable(url)
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS == UDNEmbedIE._TESTS
    assert ie._match_id(url) == '300040'

# Generated at 2022-06-24 13:43:08.349905
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    with open('test/test_data/udn_video.html', 'r') as f:
        webpage = f.read()
    article = webpage.split('<div class="content">')[1]
    udn = UDNEmbedIE()
    options_str = udn._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', article, 'options')
    trans_options_str = js_to_json(options_str)
    options = udn._parse_json(trans_options_str, 'options', fatal=False) or {}
    assert options
    video_urls = options['video']
    title = options['title']
    poster = options.get('poster')

# Generated at 2022-06-24 13:43:14.419830
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    if udne.suitable(url):
        info = udne.extract(url)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:43:18.629980
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    # test a valid URL
    assert inst.suitable(inst._VALID_URL)
    assert inst.extract('https://video.udn.com/embed/news/300042')
    # test a valid URL
    assert inst.suitable('https://video.udn.com/play/news/300042')

# Generated at 2022-06-24 13:43:22.368182
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result_a = UDNEmbedIE()._match_id('http://video.udn.com/embed/news/300040')
    result_b = UDNEmbedIE()._match_id('http://video.udn.com/play/news/300040')
    assert result_a == '300040'
    assert result_b == '300040'

# Generated at 2022-06-24 13:43:24.289596
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC

# Generated at 2022-06-24 13:43:25.341462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)
    assert True

# Generated at 2022-06-24 13:43:29.508809
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:38.467812
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.suitable('https://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:43:41.251174
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor test
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'



# Generated at 2022-06-24 13:43:46.243150
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    self.assertEqual(
        UDNEmbedIE._build_url_result(url),
        {
            'url': url,
            'ie_key': UDNEmbedIE.ie_key(),
        }
    )

# Generated at 2022-06-24 13:43:52.811195
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_unit_test_instance = UDNEmbedIE()
    assert udn_embed_unit_test_instance._match_id(
        'https://video.udn.com/embed/news/300040') == '300040'
    assert udn_embed_unit_test_instance._match_id(
        '//video.udn.com/play/news/300040') == '300040'
    assert udn_embed_unit_test_instance._match_id(
        'http://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-24 13:44:01.563768
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('http://video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-24 13:44:11.233919
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import json
    import re

    # Page content from https://video.udn.com/embed/news/300040

# Generated at 2022-06-24 13:44:19.184768
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)

# Generated at 2022-06-24 13:44:27.232714
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Initialize an instance of class UDNEmbedIE
    ie = UDNEmbedIE()
    # Test _PROTOCOL_RELATIVE_VALID_URL class attribute
    assert(ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    # Test _VALID_URL class attribute
    assert(ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-24 13:44:29.938049
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:44:32.488115
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音', udn.IE_DESC
    return

test_UDNEmbedIE()

# Generated at 2022-06-24 13:44:37.686352
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    parser = UDNEmbedIE()
    assert parser._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert parser._match_id('https://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-24 13:44:39.284253
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('udn.com')
    return True

# Generated at 2022-06-24 13:44:40.280074
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbed = UDNEmbedIE()

# Generated at 2022-06-24 13:44:42.938171
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_key()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == ie.ie_key()
    assert ie._VALID_URL == ie.ie_key()

# Generated at 2022-06-24 13:44:48.686081
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test protocol-relative URL
    IE = UDNEmbedIE('http:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    _, url, _ = IE._extract_url_info(
        'http:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)

    assert url == 'https:%s' % UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:44:53.646840
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-24 13:44:55.966558
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Extractor test
    """
    try:
        UDNEmbedIE()
    except Exception:
        raise AssertionError("UDNEmbedIE constructor test failed")


# Generated at 2022-06-24 13:44:58.804789
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert (UDNEmbedIE('test', 'http://embed.system/test')._PROTOCOL_RELATIVE_VALID_URL ==
            UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:45:00.907789
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE("http://video.udn.com/embed/news/300040")
    except:
        assert False
    assert True

# Generated at 2022-06-24 13:45:02.315021
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:45:04.220243
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'udn_embed'
    assert UDNEmbedIE.ie_key() != 'UDNEmbed'

# Generated at 2022-06-24 13:45:08.174131
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pass
    url = 'http://video.udn.com/embed/news/300040'
    url2 = 'https://video.udn.com/embed/news/300040'
    url3 = 'https://video.udn.com/play/news/303776'
    ie = UDNEmbedIE()
    ie.extract(url)
    ie.extract(url2)
    ie.extract(url3)

# Generated at 2022-06-24 13:45:10.224820
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test_result = UDNEmbedIE()
    assert unit_test_result.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:45:11.015546
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)

# Generated at 2022-06-24 13:45:14.919785
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_cases = [{
        'test_url': 'http://video.udn.com/embed/news/300040'
    }, {
        'test_url': 'http://video.udn.com/play/news/303776'
    }]

    for test_case in test_cases:
        url = test_case['test_url']
        instance = UDNEmbedIE()
        instance._match_id(url)
        instance._real_extract(url)

# Generated at 2022-06-24 13:45:24.967884
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # for py3 compatibility
    if hasattr(compat_urlparse.urlsplit, 'hostname'):
        hostname_func = lambda url: compat_urlparse.urlsplit(url).hostname
    else:
        hostname_func = lambda url: compat_urlparse.urlsplit(url).netloc.split(':')[0]

    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:45:34.948428
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:45:45.046375
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert(u != None)
    assert(isinstance(u,InfoExtractor))
    assert(u._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(u._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(u._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040')
    assert(u._TESTS[0]['info_dict']['id'] == '300040')
    assert(u._TESTS[0]['info_dict']['ext'] == 'mp4')
   

# Generated at 2022-06-24 13:45:48.190735
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        udn = UDNEmbedIE()
        print(udn)
    except Exception as ex:
        print(ex)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:45:49.948462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:45:50.984080
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('test')

# Generated at 2022-06-24 13:45:56.873888
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Simple test for constructor of class UDNEmbedIE
    """
    udn_embed_ie = UDNEmbedIE()
    assert_equal(udn_embed_ie.age_limit, 0)
    assert_true(udn_embed_ie.suitable('http://video.udn.com/embed/news/300040'))
    assert_false(udn_embed_ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc'))

# Generated at 2022-06-24 13:45:58.080374
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040', {})

# Generated at 2022-06-24 13:46:09.016310
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    find = re.findall
    obj = UDNEmbedIE()
    assert obj.IE_DESC == '聯合影音'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:10.753652
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE().suitable(url)


# Generated at 2022-06-24 13:46:16.057519
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()

    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn_embed_ie._TESTS[0]['info_dict']['id'] == '300040'
   

# Generated at 2022-06-24 13:46:24.533164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:26.186148
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert str(ie) == ie.IE_DESC

# Generated at 2022-06-24 13:46:29.230709
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:30.778398
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbed', False)
    UDNEmbedIE('UDNEmbed', True)

# Generated at 2022-06-24 13:46:38.824187
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	url = "https://video.udn.com/embed/news/300040"
	udn_embed = UDNEmbedIE()
	test = udn_embed._real_extract(url)
	print(test)
	assert test["id"] == "300040"

# Generated at 2022-06-24 13:46:42.204995
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    udn_embed_ie = ie.extract('http://video.udn.com/embed/news/300040')
    print(udn_embed_ie)

# Generated at 2022-06-24 13:46:43.247098
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE())

# Generated at 2022-06-24 13:46:46.954106
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_error
    from ..compat import compat_urllib_parse
    url = "https://video.udn.com/play/news/300040"
    try:
        compat_urllib_request.urlopen(url)
    except compat_urllib_error.URLError as e:
        e.reason

# Generated at 2022-06-24 13:46:52.738677
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:02.693858
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Unit test for constructor of class UDNEmbedIE
    ie = UDNEmbedIE()
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL ==
           'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')
    assert(ie._PROTOCOL_RELATIVE_VALID_URL ==
           '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')
    assert(ie._TESTS[0]['url'] ==
           'http://video.udn.com/embed/news/300040')
    assert(ie._TESTS[0]['info_dict']['id'] == '300040')

# Generated at 2022-06-24 13:47:07.277208
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    A test case for UDNEmbedIE
    """
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().suitable(url)
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:47:13.194954
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:18.760088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check the expected class constructor
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:26.216194
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembedIE = UDNEmbedIE()
    # Url is like http://video.udn.com/embed/news/300040
    url = 'http://video.udn.com/embed/news/300040'
    url_result = udnembedIE.url_result(url)
    assert 'udn.com' in url_result.host
    assert 'embed/news/300040' in url_result.path

    # Url is like https://video.udn.com/embed/news/300040
    url = 'https://video.udn.com/embed/news/300040'
    url_result = udnembedIE.url_result(url)
    assert 'udn.com' in url_result.host
    assert 'embed/news/300040' in url_result.path

    #

# Generated at 2022-06-24 13:47:29.107756
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:32.605438
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert not(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.startswith('https://'))
    assert UDNEmbedIE._VALID_URL.startswith('https://')

# Generated at 2022-06-24 13:47:36.166227
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == '__main__':
        url = 'http://video.udn.com/embed/news/300040'
        ie = UDNEmbedIE()
        result = ie.extract(url)
        print(result)

# Generated at 2022-06-24 13:47:39.812645
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbed = UDNEmbedIE(UDNEmbedIE._downloader)
    test_UDNEmbed = UDNEmbed._real_extract(url)
    assert test_UDNEmbed['id'] == '300040'
    assert test_UDNEmbed['title'] == '生物老師男變女 全校挺"做自己"'
    assert test_UDNEmbed['thumbnail'] != None
    assert test_UDNEmbed['formats'][0]['format_id'] == 'hls'

# Generated at 2022-06-24 13:47:43.360704
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    result = ie.suitable(url)
    assert result == True


# Generated at 2022-06-24 13:47:45.516061
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:47:46.413503
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    t = UDNEmbedIE()

# Generated at 2022-06-24 13:47:52.562404
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test constructor of UDNEmbedIE class
    UDNEmbed_ins = UDNEmbedIE()
    assert UDNEmbed_ins._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbed_ins._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:53.988308
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except:
        return False
    return True

# Generated at 2022-06-24 13:47:58.137676
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    UDNEmbedIE.__init__()
    UDNEmbedIE._VALID_URL = r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    UDNEmbedIE.__init__()

# Generated at 2022-06-24 13:48:00.181727
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern = re.compile(UDNEmbedIE._VALID_URL)
    match = pattern.match('http://video.udn.com/embed/news/300040')
    assert match is not None


# Generated at 2022-06-24 13:48:01.816591
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:48:03.990881
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert_equal(udn.ie_key(), 'UDNEmbed')
    assert_equal(udn.ie_desc(), '聯合影音')


if __name__ == '__main__':
    from .test_suite import run_test
    run_test()

# Generated at 2022-06-24 13:48:08.478432
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'
    # Video does not exist
    assert not UDNEmbedIE()._real_extract(url)
    # Video exists
    assert video_id == UDNEmbedIE()._real_extract(url)['id']

# Generated at 2022-06-24 13:48:17.066660
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test the constructor of class UDNEmbedIE whether match right.
    """
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert re.match(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL, r'//video\.udn\.com/(?:embed|play)/news/\d+') is not None
    assert re.match(udn_embed_ie._VALID_URL, r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL) is not None

# Generated at 2022-06-24 13:48:18.765747
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Simple test of constructor
    assert(UDNEmbedIE().extract)

# Generated at 2022-06-24 13:48:24.094313
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test UDNEmbedIE constructor
    """
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-24 13:48:30.612882
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:48:36.329736
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # set up arguments
    url = 'https://video.udn.com/embed/news/300040'

    # create udnEmbedIE object
    udnEmbedIE_obj = UDNEmbedIE(downloader=None)

    # call the _real_extract function of the udnEmbedIE
    udnEmbedIE_obj._real_extract(url)

# Generated at 2022-06-24 13:48:41.405225
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:48:45.489550
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    import platform
    if sys.version_info.major == 2 and platform.system() == 'Windows':
        return
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:48:51.037673
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    udn = UDNEmbedIE()
    assert(udn.IE_DESC == "聯合影音")
    assert(udn.ie_key() == "Udn")
    assert(udn._VALID_URL == udn._build_regex(udn._PROTOCOL_RELATIVE_VALID_URL))


# Generated at 2022-06-24 13:48:53.293524
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('embed')
    assert ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:48:59.234284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("https://video.udn.com/embed/news/300040")
    # Check that the constructor of class InfoExtractor has been called
    assert ie.ie_key().lower() == 'udn'
    assert ie.url.lower() == 'https://video.udn.com/embed/news/300040'
    assert ie.count == 0
    assert ie.is_debug == False


# Generated at 2022-06-24 13:49:04.164775
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:49:13.096871
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE("1")
    assert udne.IE_DESC == '聯合影音'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == r'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:49:16.468338
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    dict_test = {'test':'test'}
    info_extractor_dict = info_extractor.extract(dict_test)
    return info_extractor_dict

# Generated at 2022-06-24 13:49:20.404601
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE()._VALID_URL)
    print(UDNEmbedIE._VALID_URL)
    # print(UDNEmbedIE._TESTS)
    # print(UDNEmbedIE.WORKING)
    # print(UDNEmbedIE.IE_NAME)
    # print(UDNEmbedIE.IE_DESC)
    # print(UDNEmbedIE.EMBED_URL_TEMPLATE)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:49:26.734095
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:49:28.274382
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-24 13:49:36.367324
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'https://video.udn.com/play/news/303776'
    udne = UDNEmbedIE()
    assert(udne.suitable(test_url) == True)
    assert(udne._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')