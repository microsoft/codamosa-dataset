

# Generated at 2022-06-24 13:39:34.996929
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:39:35.989667
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
  u = UDNEmbedIE()


# Generated at 2022-06-24 13:39:43.928663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    webpage = UDNEmbedIE()._download_json(url, '300040')
    options_str = UDNEmbedIE()._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', webpage, 'options')
    trans_options_str = js_to_json(options_str)
    options = UDNEmbedIE()._parse_json(trans_options_str, 'options', fatal=False)
    # print(options['video'])
    # json.dumps(options, sort_keys=True, indent=4)

# Generated at 2022-06-24 13:39:45.027308
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:39:47.499540
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == "聯合影音"

# Generated at 2022-06-24 13:39:50.249707
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("UDNEmbedIE","UDN",'udn')

# Generated at 2022-06-24 13:39:55.983793
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = UDNEmbedIE
    assert class_.IE_NAME == 'udn'
    assert class_.IE_DESC == '聯合影音'
    assert class_._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert class_._TESTS != []

# Generated at 2022-06-24 13:40:04.679456
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("https://video.udn.com/embed/news/300040")
    assert ie.IE_DESC == "聯合影音"
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == "http://video.udn.com/embed/news/300040"

# Generated at 2022-06-24 13:40:05.796639
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();

# Generated at 2022-06-24 13:40:06.806892
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()


# Generated at 2022-06-24 13:40:09.550709
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:40:14.078093
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Case 1
    UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')

    # Case 2
    UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:40:23.576459
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_name = r'UDNEmbedIE'
    # test for regex of url
    url_regex = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # test for protocal_relative_url
    protocal_relative_url = r'//video\.udn\.com/embed/news/300040'
    # test for valid url
    valid_url = r'https://video\.udn\.com/embed/news/300040'
    # test for invalid url
    invalid_url = r'https://video\.udn\.com/play/news/300040'
    # test for invalid info dict

# Generated at 2022-06-24 13:40:32.344912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.match(
        r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
        'http://video.udn.com/embed/news/300040',
    )

    assert re.match(
        r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
        '//video.udn.com/embed/news/300040',
    )

    assert re.match(
        r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
        'https://video.udn.com/embed/news/300040',
    )

# Generated at 2022-06-24 13:40:38.525476
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(UDNEmbedIE.create_ie())._real_initialize()
    UDNEmbedIE(UDNEmbedIE.create_ie())._real_extract(url)
    #UDNEmbedIE(UDNEmbedIE.create_ie())._real_extract('http://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:40:40.260601
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    assert isinstance(inst, UDNEmbedIE)

# Generated at 2022-06-24 13:40:48.564796
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:56.361136
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import extract_attributes
    udne_ie = UDNEmbedIE()

# Generated at 2022-06-24 13:41:00.655122
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)._real_extract('http://video.udn.com/embed/news/300040')
    UDNEmbedIE(None)._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:41:05.327788
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import youtube_dl
    ie = youtube_dl.YoutubeDL({'default_search': 'udn', 'logger': youtube_dl.utils.null_print}).extract_info(
        'http://video.udn.com/embed/news/300040', False)
    assert ie['id'] == '300040'
    assert ie['title'] == '生物老師男變女 全校挺"做自己"'



# Generated at 2022-06-24 13:41:06.663511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    return UDNEmbedIE

# Generated at 2022-06-24 13:41:17.043904
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, UDNEmbedIE)
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:41:20.405183
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # for test_UDNEmbedIE, the url argument can be either
    # a valid url or whole code of this website
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    assert(udne.suitable(url))

# Generated at 2022-06-24 13:41:25.287167
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import json
    import requests
    import unittest
    import xml.etree.ElementTree
    from xml.etree.ElementTree import ParseError
    class TestUDNEmbedIE(unittest.TestCase):
        def test_init_UDNEmbedIE(self):
            url = 'https://video.udn.com/embed/news/300040'
            url_match = True if re.match(UDNEmbedIE._VALID_URL, url) else False
            udn_embed_ie = UDNEmbedIE(url = url)
            if url_match:
                self.assertEqual( udn_embed_ie.url, url)
                self.assertEqual( udn_embed_ie.url_id, '300040')

# Generated at 2022-06-24 13:41:28.263726
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie)
    assert ie.IE_NAME == 'udn.com'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:41:36.023170
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create an instance of class UDNEmbedIE
    # so that we can call its internal methods
    udn_embed_ie = UDNEmbedIE()

    assert udn_embed_ie._match_id('http://video.udn.com/embed/news/300040') == '300040'

    # Check whether function _real_extract() can extract a valid video
    assert 'video' in udn_embed_ie._real_extract('http://video.udn.com/embed/news/300040').keys()

    # Check whether function _real_extract() can extract a valid playlist
    assert 'playlist' in udn_embed_ie._real_extract('http://video.udn.com/embed/news/300040').keys()

    # Check whether function _real_extract() can extract a valid Youtube

# Generated at 2022-06-24 13:41:45.122774
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..compat import compat_urlparse
    from ..html import get_element_by_id


# Generated at 2022-06-24 13:41:47.746341
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:41:54.682401
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    assert re.match(UDNEmbedIE._VALID_URL, url)
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL in url
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Extractor test

# Generated at 2022-06-24 13:41:58.912089
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn:embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:08.430293
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import pdb
    pdb.set_trace()
    # Test 1
    video_url = 'http://video.udn.com/embed/news/300040'
    test_url = UDNEmbedIE._VALID_URL.match(video_url)
    assert(test_url.group('id') == '300040')

    # Test 2
    url = 'http://video.udn.com/play/news/303776'
    m = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match(url)
    assert(m.group('id') == '303776')

# Generated at 2022-06-24 13:42:11.376800
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/402713'
    udne = UDNEmbedIE(url)
    return udne

# Generated at 2022-06-24 13:42:14.577737
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except Exception:
        raise AssertionError('Unable to run constructor of class UDNEmbedIE')


# Generated at 2022-06-24 13:42:16.054111
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:42:20.167883
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_ua = 'Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3'
    unit_test_case = UDNEmbedIE(test_ua)
    assert unit_test_case.ua == test_ua, 'User-Agent was incorrectly set'
    return unit_test_case

# Generated at 2022-06-24 13:42:26.455524
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-24 13:42:29.623451
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url) == '300040'


# Generated at 2022-06-24 13:42:32.507425
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test for constructor of class UDNEmbedIE
    """
    try:
        UDNEmbedIE('udn')
    except TypeError:
        print("constructor of class UDNEmbedIE works well")

# Generated at 2022-06-24 13:42:42.766500
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    result = ie._real_extract(url)

# Generated at 2022-06-24 13:42:48.551555
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Precondition
    assert issubclass(UDNEmbedIE, InfoExtractor)
    # Instantiation
    u = UDNEmbedIE(InfoExtractor.create_ie())
    # Test
    assert u._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u._VALID_URL == r'https?:' + u._PROTOCOL_RELATIVE_VALID_URL



# Generated at 2022-06-24 13:42:53.245667
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = "https://video.udn.com/embed/news/300040"
    assert ie._match_id(url) == "300040"
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._download_webpage(url, None) != None


# Generated at 2022-06-24 13:42:56.163018
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:43:01.575320
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().suitable(url)
    instance = UDNEmbedIE()
    assert instance._match_id(url) == '300040'
    response = instance._download_webpage(url, '300040')
    assert response is not None
    assert instance._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', response, 'options') is not None

# Generated at 2022-06-24 13:43:04.119406
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_object = UDNEmbedIE()
    assert test_object._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:05.957104
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    u = UDNEmbedIE()
    assert u.suitable(url) == True

# Generated at 2022-06-24 13:43:12.425223
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    _UDNEmbedIE = UDNEmbedIE()
    _UDNEmbedIE.IE_DESC

    assert _UDNEmbedIE.IE_DESC == '聯合影音'
    assert _UDNEmbedIE._VALID_URL
    assert _UDNEmbedIE._TESTS


# Generated at 2022-06-24 13:43:14.822811
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()  # noqa: N806
    assert class_UDNEmbedIE is not None



# Generated at 2022-06-24 13:43:19.908881
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	udn_embed_ie = UDNEmbedIE()
	assert(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
	assert(udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:43:25.140362
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Test case for _extract_url in UDNEmbedIE

# Generated at 2022-06-24 13:43:29.458589
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:31.362568
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    IE.download('https://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:43:38.264731
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_NAME == 'udn')
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:43:42.804227
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == UDNEmbedIE.IE_DESC
    assert ie._TESTS == UDNEmbedIE._TESTS

# Generated at 2022-06-24 13:43:52.282125
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:59.139779
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_NAME == 'udn'
    assert udn_ie.IE_DESC == '聯合影音'
    assert udn_ie._VALID_URL == \
        'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert udn_ie._TESTS

# Generated at 2022-06-24 13:44:07.747272
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:44:08.912558
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne


# Generated at 2022-06-24 13:44:11.282035
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_utils import MockIE

    ie = MockIE('udn', UDNEmbedIE())
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-24 13:44:18.179270
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie._match_id(url) == '300040'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._downloader is None
    assert ie.IE_DESC == '聯合影音'
    assert ie._WORKING == True

# Generated at 2022-06-24 13:44:23.336318
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test _PROTOCOL_RELATIVE_VALID_URL
    url = 'https://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    match = udn_embed_ie._VALID_URL.match(url)
    assert match
    assert udn_embed_ie._match_id(url) == '300040'



# Generated at 2022-06-24 13:44:33.549343
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_info_extractor = UDNEmbedIE()
    assert udn_embed_info_extractor.ie_key() == 'udn'
    assert udn_embed_info_extractor.IE_DESC == '聯合影音'
    assert udn_embed_info_extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_info_extractor._VALID_URL == r'https?:' + udn_embed_info_extractor._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:44:44.714359
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    ie_UDNEmbed = UDNEmbedIE()


# Generated at 2022-06-24 13:44:51.663307
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
  udne_ie = UDNEmbedIE()
  print("UDNEmbedIE:")
  print("_PROTOCOL_RELATIVE_VALID_URL:", udne_ie._PROTOCOL_RELATIVE_VALID_URL)
  print("_VALID_URL:", udne_ie._VALID_URL)
  print("IE_DESC:", udne_ie.IE_DESC)
  print("_API_URL:", udne_ie._API_URL)


# Generated at 2022-06-24 13:44:54.863266
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert re.match(ie._PROTOCOL_RELATIVE_VALID_URL, ie._VALID_URL)

# Generated at 2022-06-24 13:44:55.653046
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:45:01.024117
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    'Unit test class'
    # UDNEmbedIE.__init__(embed_url, video_id)
    vid = UDNEmbedIE(url='https://video.udn.com/embed/news/300040',
                     video_id='300040')

    # UDNEmbedIE._real_extract(self, url)
    print('test_UDNEmbedIE function: ')
    print(vid._real_extract(vid.url))

test_UDNEmbedIE()

# Generated at 2022-06-24 13:45:06.363144
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """ Test the constructors of UDNEmbedIE """
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    UDNEmbedIE._VALID_URL
    UDNEmbedIE._TESTS
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = '//video.udn.com/embed/news/(?P<id>\d+)'
    UDNEmbedIE._VALID_URL = 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    # Test UDNEmbedIE.ie_key()
    ie = InfoExtractor.ie_key('UDNEmbed')
    assert ie == UDNEmbedIE, 'UDNEmbed not matched'

# Generated at 2022-06-24 13:45:10.452590
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    print('Protocol relative valid URL: %s' % udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL)
    print('Valid URL: %s' % udn_embed_ie._VALID_URL)
    return

# Generated at 2022-06-24 13:45:14.817762
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE('http://udn.com/')
    assert test.IE_NAME == 'udn'
    assert test.IE_DESC == '聯合影音'
    # TODO: Fix this?
    # assert test.VALID_URL == 'http://video\.udn\.com/embed/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:15.805661
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-24 13:45:18.891886
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Smoke test of constructor of UDNEmbedIE
    UDNEmbedIE(object)

# Generated at 2022-06-24 13:45:21.385145
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # test constructor
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:32.343422
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == (
        r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert UDNEmbedIE._VALID_URL == (
        r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:45:37.093325
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    c = UDNEmbedIE()
    assert re.search(c._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert re.search(c._VALID_URL, 'https://video.udn.com/play/news/300040')
    assert re.search(c._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:45:45.087552
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    def _test_parse_func(list):
        for item in list:
            url = item['url']
            if url:
                network_location = compat_urlparse.urlparse(url)
                network_location = network_location._replace(scheme='')
                if network_location.netloc == 'video.udn.com':
                    continue
                else:
                    raise Exception('It need to parse by another method.')
            else:
                raise Exception('This url is empty.')
    _test_parse_func(UDNEmbedIE._TESTS)

# Generated at 2022-06-24 13:45:47.196968
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert test.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:45:51.596927
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for the construct of YoutubeIE class.
    """
    # constructor alone
    ie = UDNEmbedIE()
    # check if it's working
    test_urls = ['http://video.udn.com/embed/news/300040']
    for url in test_urls:
        ie.extract(url)

# Generated at 2022-06-24 13:45:52.922020
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:45:54.915717
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create an instance of UDNEmbedIE, then check whether constructor is successful
    assert UDNEmbedIE(UDNEmbedIE._downloader)

# Generated at 2022-06-24 13:45:55.771396
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.IE_DESC
    ie._VALID_URL

# Generated at 2022-06-24 13:46:01.208120
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    rel_url = r'//video\.udn\.com/(?:embed|play)/news/300040'
    url = 'https:' + rel_url
    video_id = ie._match_id(url)
    assert video_id == '300040'

# Generated at 2022-06-24 13:46:11.879100
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:46:12.667274
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()
	print(ie)

# Generated at 2022-06-24 13:46:18.692574
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE.IE_DESC == '聯合影音')
    assert(UDNEmbedIE.IE_NAME == 'udn.com')
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:46:26.859255
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    for url in ['http://video.udn.com/embed/news/300040',
                'https://video.udn.com/embed/news/300040',
                'https://video.udn.com/play/news/303776']:
        assert ie._match_id(url) == '300040'
        assert ie.suitable(url)
        assert ie._real_extract(url)

# Generated at 2022-06-24 13:46:34.874604
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:46:42.115187
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    assert udnEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbedIE._VALID_URL == 'https?:' + udnEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert udnEmbedIE.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:46:43.070080
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:44.184110
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ins = UDNEmbedIE()
    print(str(ins))

# Generated at 2022-06-24 13:46:52.415663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor

    # test protocol relative url
    _VALID_URL = r'//video\.udn\.com/embed/news/300040'
    url_list = ['http:%s' % _VALID_URL,
                'https:%s' % _VALID_URL,
                'http://%s' % _VALID_URL]

    for url in url_list:
        print("Testing %s\n" % url)
        ie = InfoExtractor.for_working_url(url)

        assert(ie.working_url == 'http:%s' % _VALID_URL)
        assert(ie.IE_NAME == 'UDNEmbed')
    print("All %d tests passed" % len(url_list))

if __name__ == '__main__':
    test_

# Generated at 2022-06-24 13:47:01.409662
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    print()
    print('[Test] Instantiate UDNEmbedIE object')
    print(i)
    print()

    url = 'http://video.udn.com/embed/news/300040'
    print('[Test] Extract url: %s' % url)
    print(i._real_extract(url))
    print()

    url = 'https://video.udn.com/play/news/303776'
    print('[Test] Extract url: %s' % url)
    print(i._real_extract(url))
    print()


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:47:02.091471
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:47:10.326337
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL is not None
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL is not None

    url = 'https://video.udn.com/embed/news/300040'
    IE = UDNEmbedIE(url)
    assert IE.suitable(url.encode('utf-8')) == True
    assert IE._match_id(url.encode('utf-8')) == '300040'
    assert IE.IE_DESC is not None


test_UDNEmbedIE()

# Generated at 2022-06-24 13:47:14.144191
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'udn:embed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:47:16.718891
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test singleton demo
    singletonTest = UDNEmbedIE()
    singletonTest2 = UDNEmbedIE()
    assert singletonTest == singletonTest2

# Generated at 2022-06-24 13:47:17.760790
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE

# Generated at 2022-06-24 13:47:23.155777
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert 'udn' in udn_embed_ie.ie_key()
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-24 13:47:24.109402
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/play/news/303776', None)

# Generated at 2022-06-24 13:47:28.169001
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.ie_key() == 'UDNEmbed'
    assert obj.ie_desc() == '聯合影音'
    assert obj.ie_info()['id'].lower() == 'udnembed'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:47:29.465483
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	youtube_IE = UDNEmbedIE()

# Generated at 2022-06-24 13:47:40.102307
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()

    print("Downloading page: %s" % url)
    page = ie.download_page(url)
    
    assert page
    print("Parsing options: %s" % page)
    options = ie.extract_options(page)
    assert options

    print("Parsing title: %s" % options)
    title = ie.extract_title(options)
    assert title

    print("Parsing poster: %s" % options)
    poster = ie.extract_poster(options)
    print("Poster: %s" % poster)

    print("Parsing video urls: %s" % options)
    video_urls = ie.extract_video_

# Generated at 2022-06-24 13:47:45.696652
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\\d+)')
    assert(ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:47:51.956174
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:47:58.038561
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ue = UDNEmbedIE()
    assert (ue.IE_NAME == 'udn.com')
    assert (ue.IE_DESC == '聯合影音')
    assert (ue._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')
    assert (ue._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040')
    assert (ue._TESTS[0]['info_dict']['id'] == '300040')
    assert (ue._TESTS[0]['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-24 13:48:09.241228
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test the class UDNEmbedIE"""
    video_id = '300040'
    url = 'http://video.udn.com/embed/news/' + video_id
    url_m3u8 = 'http://video.udn.com/api/getSource/%s?type=m3u8hd' % video_id
    url_hds = 'http://video.udn.com/api/getSource/%s?type=f4m' % video_id
    url_mp4 = 'http://video.udn.com/api/getSource/%s?type=mp4hd' % video_id
    expected_mp4 = 'http://video.udn.com/api/getSource/%s?type=mp4hd' % video_id

    udn_embed_ie = UDNE

# Generated at 2022-06-24 13:48:11.875083
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    a_match = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert re.match(a_match, url) is not None

# Generated at 2022-06-24 13:48:21.743688
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check whether object is initialized successfully
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-24 13:48:28.135993
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test constructor of class UDNEmbedIE"""
    print('Testing constructor...')
    print('Create extractor for http://video.udn.com/embed/news/300040')
    udne = UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
    print('extractor: %s' % udne)
    print('Done.')



# Generated at 2022-06-24 13:48:32.476820
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_obj = UDNEmbedIE()
    # Test pattern of the class
    assert ie_obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test properties of the class
    assert ie_obj.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:48:36.482487
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
        assert True, 'Unit test for UDNEmbedIE() passed'
    except Exception as e:
        print('Unit test for UDNEmbedIE() failed')
        print(e)
        assert False

# Generated at 2022-06-24 13:48:42.319352
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:48:45.766757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.extract_info(url) is not None

# Generated at 2022-06-24 13:48:55.784607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_NAME == 'udn'
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert udne._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert udne._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'



# Generated at 2022-06-24 13:48:59.385592
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        ie = UDNEmbedIE()
    except:
        assert False, 'UDNEmbedIE constructor failed.'


# Generated at 2022-06-24 13:49:00.540796
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE(0)



# Generated at 2022-06-24 13:49:04.071183
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:49:06.124810
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    for test in udnei._TESTS:
        print(test['url'])

# Generated at 2022-06-24 13:49:09.144136
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result = re.search(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/play/news/303776')
    assert result

# Generated at 2022-06-24 13:49:10.484632
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE().working = False
    UDNEmbedIE().extract(url)

# Generated at 2022-06-24 13:49:13.057451
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:49:16.467060
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    assert url == UDNEmbedIE._build_url(
        UDNEmbedIE._match_id(url),
        ie=UDNEmbedIE
    )

# Generated at 2022-06-24 13:49:23.584387
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ieTest = UDNEmbedIE(None)
    # _PROTOCOL_RELATIVE_VALID_URL
    assert ieTest._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # _VALID_URL
    assert ieTest._VALID_URL == r'https?:' + ieTest._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-24 13:49:31.818739
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_urls = (
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        '//video.udn.com/embed/news/300040',
        'http://video.udn.com/play/news/303776',
        'https://video.udn.com/play/news/303776',
        '//video.udn.com/play/news/303776',
    )
    for test_url in test_urls:
        res = ie.suitable(test_url)
        assert res is not None
