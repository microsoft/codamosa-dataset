

# Generated at 2022-06-24 13:39:33.678757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE('www.udn.com')
    assert udne.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:39:35.073781
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj


# Generated at 2022-06-24 13:39:36.790106
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # pass

# Generated at 2022-06-24 13:39:42.380414
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    print(ie.IE_DESC);
    print(ie._VALID_URL);
    print(ie._PROTOCOL_RELATIVE_VALID_URL);
    print(ie._TESTS);
    print(ie._VALID_URL.find(r'//'));
    print(ie._VALID_URL.find(r'http:'));
    print(ie._VALID_URL.find(r'https:'));

# Generated at 2022-06-24 13:39:43.383224
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:39:45.245585
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL is not None

# Generated at 2022-06-24 13:39:49.785741
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME == 'udn'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._VALID_URL.startswith('https?:')


# Generated at 2022-06-24 13:39:58.246915
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_url = 'http://video.udn.com/embed/news/300040'
    test_url2 = 'https://video.udn.com/embed/news/300040'
    test_url3 = 'https://video.udn.com/play/news/303776'
    assert ie._match_id(test_url) == '300040'
    assert ie._match_id(test_url2) == '300040'
    assert ie._match_id(test_url3) == '303776'

# Generated at 2022-06-24 13:40:00.306192
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDNEmbed'
    assert udn_embed_ie.ie_desc() == '聯合影音'

# Generated at 2022-06-24 13:40:03.321853
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Unit test for constructor of class UDNEmbedIE
    '''
    UDNEmbed = UDNEmbedIE()
    assert UDNEmbed.IE_NAME == 'udn'
    assert UDNEmbed.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:40:05.097033
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try: 
        UDNEmbedIE()
    except Exception as e:
        print("error: %s" % (e))
        return False

    return True



# Generated at 2022-06-24 13:40:06.139178
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    print(udn)

# Generated at 2022-06-24 13:40:10.357995
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_DESC == '聯合影音'
    assert instance._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == 'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    # Test base url
    url = 'http://video.udn.com/embed/news/300040'
    assert instance._match_id(url) == '300040'
    url = 'https://video.udn.com/embed/news/300040'
    assert instance._match_id(url) == '300040'

# Generated at 2022-06-24 13:40:16.206610
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn:embed'
    assert ie._VALID_URL == 'https?://video.udn.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:25.240420
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    youtube_re_pattern = r'^https?://(?:www\.)?youtube.com/watch\?v=.+$'
    m3u8_re_pattern = r'^https?://video\.udn\.com/api/get/video/m3u8/v2/\?.+$'
    f4m_re_pattern = r'^https?://video\.udn\.com/api/get/video/f4m/v2/\?.+$'
    http_mp4_re_pattern = r'^https?://video\.udn\.com/api/get/video/mp4/v2/\?.+$'


# Generated at 2022-06-24 13:40:27.892990
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:40:29.608021
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:35.055512
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    c = UDNEmbedIE()
    url = c._VALID_URL.replace('https:', '')
    c._match_id(url)
    c._download_webpage(url, '300040')
    c._html_search_regex(r'var\s+options\s*=\s*([^;]+);', 'hello world', 'options')
    c._real_extract(url)

# Generated at 2022-06-24 13:40:40.732462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL
    assert obj.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:40:42.977423
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = "http://video.udn.com/embed/news/300040"
    assert ie.suitable(url) is True, 'url:' + url
    url = "https://video.udn.com/embed/news/300040"
    assert ie.suitable(url) is True, 'url:' + url



# Generated at 2022-06-24 13:40:48.962211
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..test import get_testcases
    from .test_udn import test_udn_article_content
    for case in get_testcases(
        'https://video.udn.com/news/303776',
        'https://video.udn.com/embed/news/303776'
    ):
        url = case['url']
        udn_embed_ie = UDNEmbedIE()
        parsed_url = compat_urlparse.urlparse(url)
        match_obj = udn_embed_ie._VALID_URL_RE.match(url)
        article_url = url[:parsed_url.path.rfind('/')]
        match_obj_article = test_udn_article_content._VALID_URL_RE.match(article_url)

# Generated at 2022-06-24 13:40:50.289396
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(UDNEmbedIE._create_get_info())
    return

# Generated at 2022-06-24 13:40:53.350930
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create instance of class UDNEmbedIE
    UDNEmbedIE_instance = UDNEmbedIE()
    assert(UDNEmbedIE_instance is not None)
    # Return true if successful
    return True

test_UDNEmbedIE()

# Generated at 2022-06-24 13:41:01.348754
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # url in format "//video\.udn\.com/embed/news/300040"
    test_url = {
        'url': '//video.udn.com/embed/news/300040',
        'info_dict': {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
        'expected_warnings': ['Failed to parse JSON Expecting value'],
    }
    ie = UDNEmbedIE()
    assert ie.suitable

# Generated at 2022-06-24 13:41:03.364441
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME == 'udn'
    assert obj.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:41:06.217742
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:41:09.258027
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # The following is a unit test case for UDNEmbedIE constructor
    UDNEmbedIE("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:41:10.807741
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for i in range(10):
        UDNEmbedIE()

# Generated at 2022-06-24 13:41:13.224974
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._match_id("http://video.udn.com/embed/news/300040") == "300040"

# Generated at 2022-06-24 13:41:14.208446
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:41:16.528914
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-24 13:41:17.415589
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()


# Generated at 2022-06-24 13:41:22.469719
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        from .test_downloader import TestDownloader
        from .test_utils import TestUtils
        from .test_youtube_dl import TestYoutubeDL
    except ImportError:
        TestDownloader = type('TestDownloader', (object,), dict())
        TestUtils = type('TestUtils', (object,), dict())
        TestYoutubeDL = type('TestYoutubeDL', (object,), dict())
    TestDownloader._TEST_INSTANCE = True
    TestUtils._TEST_INSTANCE = True
    TestYoutubeDL._TEST_INSTANCE = True
    return UDNEmbedIE(TestDownloader())

# Generated at 2022-06-24 13:41:25.811540
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_test = 'http://video.udn.com/embed/news/300040'
    expected_url = 'http://video.udn.com/news/300040'
    assert UDNEmbedIE._VALID_URL == expected_url

# Generated at 2022-06-24 13:41:29.264362
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    from .common import InfoExtractor

    url = 'http://video.udn.com/embed/news/300040'

    ie = InfoExtractor()
    ie.add_ie(UDNEmbedIE)
    ie.extract(url)

# Generated at 2022-06-24 13:41:31.144570
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:41:40.439762
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL
    IE_DESC = '聯合影音'


# Generated at 2022-06-24 13:41:41.969267
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE('')
    assert udne.IE_NAME == 'udn'

# Generated at 2022-06-24 13:41:44.467854
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'


# Generated at 2022-06-24 13:41:46.039009
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:41:50.016564
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of UDNEmbedIE"""

    UDNEmbedIE.can_handle_url(None)
    UDNEmbedIE._VALID_URL

# Generated at 2022-06-24 13:42:00.892937
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO: Add a test with a youtube link
    # TODO: Add a test with a fail to parse JSON Expecting value
    # TODO: Add a test with a fail to parse with message
    # TODO: Add a test with a fail to parse with message and note
    expected_regex = re.compile(r'poster\s*:\s*\'(.+?)\'\s*,')
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    webpage = ie._download_webpage(url, '300040')
    options_str = ie._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', webpage, 'options')
    trans_options_str = js_to_

# Generated at 2022-06-24 13:42:03.197503
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei != None

# Generated at 2022-06-24 13:42:14.803363
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # test to see if the video links were properly scraped
    expected_video_links = {'youtube': 'https://www.youtube.com/watch?v=Rt8MzlVu4eI',
                            'hls': 'https://video.udn.com.tw/api/getFile/hls_vid/300040/300040.m3u8'}

    udn_embed_ie = UDNEmbedIE()
    test_url = 'http://video.udn.com/embed/news/300040'

    result = udn_embed_ie._real_extract(test_url)

    assert result['id'] == '300040'

# Generated at 2022-06-24 13:42:18.789807
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:27.314621
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME.find('UDNEmbed') != -1
    assert obj.IE_DESC.find('聯合影音') != -1
    assert obj._VALID_URL.find('video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)') != -1
    assert obj._TESTS[0]['url'].find('http://video.udn.com/embed/news/300040') != -1
    assert obj._TESTS[0]['info_dict']['id'].find('300040') != -1
    assert obj._TESTS[0]['info_dict']['ext'].find('mp4') != -1


# Generated at 2022-06-24 13:42:37.833188
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    import os.path
    input_file = os.path.join(os.path.dirname(__file__), 'test_data', 'udn_embed.html')
    sys.argv = ['udn_embed.py', input_file]
    udn_embed = UDNEmbedIE()
    assert udn_embed.name == 'udn_embed'
    assert udn_embed.IE_DESC == '聯合影音'
    assert udn_embed._VALID_URL == '(https?:)?//video\.udn\.com/embed/news/\d+'

# Generated at 2022-06-24 13:42:39.880157
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE('http://video.udn.com/embed/news/300040')
    except Exception as e:
        raise e

# Generated at 2022-06-24 13:42:48.895248
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE.suitable(url)
    assert UDNEmbedIE.IE_NAME == 'udn.com:embed'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE.WEBPAGE_URL_TEMPLATE == 'https://video.udn.com/embed/news/%s'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/embed/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:50.622273
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._VALID_URL

# Generated at 2022-06-24 13:43:00.027828
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # normal case
    class_name = 'UDNEmbedIE'
    udn_embed_IE = globals()[class_name]()
    assert isinstance(udn_embed_IE, InfoExtractor)

    # test protocal relative url
    assert re.match(udn_embed_IE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.match(udn_embed_IE._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert re.match(udn_embed_IE._VALID_URL, 'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:43:07.589858
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Example: https://video.udn.com/embed/news/300040
    url = 'https://video.udn.com/embed/news/300040'

    from youtube_dl.utils import parse_qs

    assert parse_qs(compat_urlparse.urlparse(url).query)['id'][0] == '300040'

    assert re.match(UDNEmbedIE._VALID_URL, url)
    assert re.match(UDNEmbedIE._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert re.match(UDNEmbedIE._VALID_URL, 'https://video.udn.com/embed/news/300040')


# Generated at 2022-06-24 13:43:08.496324
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:43:12.640402
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    ie.extract(url)

# Generated at 2022-06-24 13:43:15.381385
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:25.806193
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_list = ['http://video.udn.com/embed/news/300040',
                'https://video.udn.com/embed/news/300040',
                '//video.udn.com/embed/news/300040']
    for url in url_list:
        url_split = url.split('/')[2:]
        video_id = url_split[-1]

        html = open('./test/html/udn.html', 'r').read()
        options_str = re.search(r'var\s+options\s*=\s*([^;]+);', html).group(1)
        trans_options_str = js_to_json(options_str)
        options = UDNEmbedIE._parse_json(trans_options_str, 'options', fatal=False)

# Generated at 2022-06-24 13:43:26.634971
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-24 13:43:29.161271
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ins = UDNEmbedIE()
    ins.extract(url)

# Generated at 2022-06-24 13:43:32.157092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE() 
    assert x._VALID_URL == 'https?:(\/\/video\.udn\.com\/(?:embed|play)\/news\/(?P<id>\d+))'

# Generated at 2022-06-24 13:43:34.667613
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	url = 'http://video.udn.com/embed/news/300040'
	UDNEmbedIE().extract(url)

# Generated at 2022-06-24 13:43:43.289013
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    assert inst.IE_DESC == '聯合影音'
    assert inst._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert inst._TESTS[0]['info_dict']['id'] == '300040'
    assert inst._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert inst

# Generated at 2022-06-24 13:43:46.855589
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    ie = UDNEmbedIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == 'udn.com:embed'



# Generated at 2022-06-24 13:43:47.586051
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:43:51.205180
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE._VALID_URL == IE._VALID_URL
    assert IE._TESTS == IE._TESTS
    assert IE._PROTOCOL_RELATIVE_VALID_URL == IE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:58.996230
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Case 1: Build a UDNEmbedIE instance with valid url
    print('Case 1: Build a UDNEmbedIE instance with valid url')
    UDNEmbedIE(url='//video.udn.com/embed/news/300040')

    # Case 2: Build a UDNEmbedIE instance with invalid url
    print('Case 2: Build a UDNEmbedIE instance with invalid url')
    try:
        UDNEmbedIE(url='http://google.com')
    except Exception as e:
        print(e)

# Generated at 2022-06-24 13:44:07.695455
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Let us test the constructor of the YouTubeIE class
    # 1. Create an instance of the class with only mandatory parameters
    UDNEmbedIE_obj_1 = UDNEmbedIE()
    # 2. Check the created object is instance of the class
    assert isinstance(UDNEmbedIE_obj_1, UDNEmbedIE) == True
    # 3. Check the constants and class variables of the class
    assert UDNEmbedIE_obj_1.IE_DESC == '聯合影音'
    assert UDNEmbedIE_obj_1._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:08.551600
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.ie_key())

# Generated at 2022-06-24 13:44:12.592649
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('Test constructor of class UDNEmbedIE')

    video_url = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie_obj = UDNEmbedIE()
    print('video_id:', udn_embed_ie_obj._match_id(video_url))

# Generated at 2022-06-24 13:44:16.957997
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:23.470899
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_example = 'http://video.udn.com/embed/news/300040'
    ie_obj = UDNEmbedIE()
    if ie_obj is None:
        raise AssertionError('Cannot initialize the class UDNEmbedIE')
    if ie_obj.IE_NAME is not 'udn':
        raise AssertionError('Cannot initialize the class UDNEmbedIE')
    if ie_obj.IE_DESC is not UDNEmbedIE.IE_DESC:
        raise AssertionError('Cannot initialize the class UDNEmbedIE')
    if ie_obj.IE_VERSION is not '0.0.1':
        raise AssertionError('Cannot initialize the class UDNEmbedIE')

# Generated at 2022-06-24 13:44:32.457807
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor

    ie = InfoExtractor()

    assert ie.suitable('http://video.udn.com/embed/news/300040')
    assert ie.suitable('https://video.udn.com/embed/news/300040')
    assert ie.suitable('//video.udn.com/embed/news/300040')

    assert not ie.suitable('https://video.udn.com/news/303776')
    assert not ie.suitable('http://video.udn.com/play/news/303776')
    assert not ie.suitable('https://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:44:36.976121
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'(?i)https?:(?-i)//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Integration test for analyze url for url "https://video.udn.com/embed/news/300040"

# Generated at 2022-06-24 13:44:45.561466
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor._match_id('300040') == '300040'
    assert extractor._match_id('300040/') == '300040'
    assert extractor._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert extractor._match_id('https://video.udn.com/play/news/300040') == '300040'
    assert extractor._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert extractor._match_id('//video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-24 13:44:49.692010
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.ie_keywords = ['udn', 'udnvideo']
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_name() == '聯合影音'



# Generated at 2022-06-24 13:44:52.469348
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        udneie = UDNEmbedIE()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-24 13:44:53.431153
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:44:54.613374
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # UDNEmbedIE(None, None)
    pass

# Generated at 2022-06-24 13:44:56.351533
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Arrange
    obj = UDNEmbedIE()
    # Act
    # Assert
    assert(obj != None)


# Generated at 2022-06-24 13:45:01.672453
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    IE._search_regex = classmethod(lambda cls, pattern, string, name=None, default=None: 'pass')
    IE._download_webpage = lambda self, url, video_id, note=None, errnote=None, fatal=True: url
    url = 'http://video.udn.com/embed/news/300040'
    IE.url = url
    items = IE.extract({'url': url})
    assert(len(items['formats']))

# Generated at 2022-06-24 13:45:03.688463
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'

# Generated at 2022-06-24 13:45:05.012511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj._match_id(obj._TESTS[0]['url'])

# Generated at 2022-06-24 13:45:09.457766
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    for test in instance._TESTS:
        if test['only_matching']:
            pass
        else:
            assert 'entries' in instance._real_extract(test['url'])

# Generated at 2022-06-24 13:45:12.217191
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor_test_result = UDNEmbedIE()
    assert constructor_test_result.IE_NAME == 'udn'
    assert constructor_test_result.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:45:21.567654
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class TestUDNEmbedIE(UDNEmbedIE):

        def _download_webpage(self, url, video_id, note=None, errnote=None, fatal=False, encoding='utf-8', data=None):
            assert '*' not in url, 'Invalid URL: %r' % url
            assert re.match(self._VALID_URL, url)
            return '''[{"youtube":"","webm":"*","mp4":"*"}]'''
    ie = TestUDNEmbedIE()
    video_urls = ie._real_extract('http://video.udn.com/embed/news/300040')['formats']
    assert len(video_urls) == 1

# Generated at 2022-06-24 13:45:25.946710
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Unit test for constructor of class UDNEmbedIE begins")
    unittest_IE = InfoExtractor()
    udn_embed_ie = unittest_IE.gen_extractor("https://video.udn.com/play/news/300040")
    assert isinstance(udn_embed_ie, UDNEmbedIE)
    print("Unit test for constructor of class UDNEmbedIE ends")


# Generated at 2022-06-24 13:45:28.576161
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/300040'
    udn.match(url)

# Generated at 2022-06-24 13:45:31.053564
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # just a simple test of the constructor
    UDN = UDNEmbedIE()
    UDN._downloader = object()



# Generated at 2022-06-24 13:45:33.095872
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(object, 'http://www.udn.com/news/story/1/1149912')


# Generated at 2022-06-24 13:45:38.151964
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    fetch = UDNEmbedIE()._real_extract(url)
    assert fetch.get('title') == '生物老師男變女 全校挺"做自己"'
    assert fetch.get('id') == '300040'
    assert fetch.get('thumbnail')

# Generated at 2022-06-24 13:45:44.984920
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembedie = UDNEmbedIE()
    assert udnembedie.IE_NAME == "udn"
    assert udnembedie.IE_DESC == "聯合影音"
    assert udnembedie._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert udnembedie._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-24 13:45:46.765098
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE._downloader, UDNEmbedIE._VALID_URL)

# Generated at 2022-06-24 13:45:50.764046
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        from youtube_dl.YoutubeDL import YoutubeDL
        from youtube_dl.extractor.udn import UDNIE
    except:
        print('Didn\'t import')
        return

    print('Test __init__() of class UDNEmbedIE')
    list_YoutubeDL_IEs = YoutubeDL.get_info_extractors()
    list_IEs = []
    new_IEs = []
    # Fix the order of list_IEs
    for IE in list_YoutubeDL_IEs:
        if IE.IE_NAME == 'funshion':
            list_IEs.append(IE)
    for IE in list_YoutubeDL_IEs:
        if IE.IE_NAME == 'UDN':
            list_IEs.append(IE)


# Generated at 2022-06-24 13:45:53.911819
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("UDNEmbed")

# Generated at 2022-06-24 13:45:55.173938
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:46:01.551634
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:46:12.142396
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # Constructor for class UDNEmbedIE
    udnEmbedIE = UDNEmbedIE()

    # A typical valid request url (from https://video.udn.com/news/300040?r=video)
    url = 'http://video.udn.com/embed/news/300040'

    # A typical url that is not valid (from https://video.udn.com/news/300040?r=video)
    url = 'http://google.com'

    # Do request on the valid url
    test = udnEmbedIE._real_extract(url=url)

    print(test['id'])
    print(test['title'])
    print(test['thumbnail'])
    

# Test the constructor of class UDNEmbedIE
test_UDNEmbedIE()

# Generated at 2022-06-24 13:46:12.713905
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:14.666297
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE("https://video.udn.com/embed/news/300040")
    assert obj is not None

# Display all methods in class UDNEmbedIE

# Generated at 2022-06-24 13:46:16.689795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    UDNEmbedIE(url)

# Generated at 2022-06-24 13:46:21.518557
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    This is a unit test for constructor of class UDNEmbedIE
    """
    from ..extractor import ie_gen
    ie = ie_gen['UDNEmbed']()
    # UDNEmbedIE is only for extract video urls of embeded video in udn.com
    assert ie.IE_NAME == 'udn.com:embed'
    # test a protocol-relative url
    _VALID_URL_UDN_EMBED = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + _VALID_URL_UDN_EMBED
    # test a normal url

# Generated at 2022-06-24 13:46:24.955386
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._extract_url

# Generated at 2022-06-24 13:46:31.699324
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)', ie._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # test extract info extraction
    url = 'http://video.udn.com/embed/news/300040'
    result = ie.extract(url)
    assert result['id'] == '300040'

# Generated at 2022-06-24 13:46:36.198613
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:39.235352
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_NAME == '聯合影音'

# Generated at 2022-06-24 13:46:40.452934
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:46.024946
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_youtube_dl.test_utils import PyObject

    test_urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040'
    ]
    for url in test_urls:
        ie = UDNEmbedIE(PyObject)
        assert ie._match_id(url) == '300040'
        assert ie._real_extract(url)

# Generated at 2022-06-24 13:46:53.770217
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == 'udn.com:embed'
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:56.325178
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE('ytsearch', {})
    assert udnIE.IE_NAME == 'udn.com:embed'

# Generated at 2022-06-24 13:46:59.962196
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url).extract()
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(url).extract()

# Generated at 2022-06-24 13:47:04.882077
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor

    cls = type('UDNEmbedIE', (InfoExtractor, ), {'_PROTOCOL_RELATIVE_VALID_URL': r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'})
    ie = cls()

    url = 'https://video.udn.com/embed/news/300040'
    result = ie.extract(url)
    assert(result['id'] == '300040')

# Generated at 2022-06-24 13:47:10.452423
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    InfoExtractor.uninitialize()
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie.ie_key() in ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.ie_key() in ie._VALID_URL

# Generated at 2022-06-24 13:47:19.366291
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_NAME == 'udn')
    assert('udn.com' in ie.IE_DESC)
    assert(ie.BROWSER_DESC == 'embed')
    assert(ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL)
    assert(ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040')
    assert(ie._TESTS[0]['info_dict']['id'] == '300040')
    assert(ie._TESTS[0]['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-24 13:47:25.652211
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # assert the attributes of class UDNEmbedIE
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:28.926258
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS

# Generated at 2022-06-24 13:47:39.515257
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'

    # test matching urls
    assert UDNEmbedIE._valid_url(url, UDNEmbedIE._VALID_URL)

    # checking whether _VALID_URL is a regular expression
    assert UDNEmbedIE._VALID_URL == re.compile(UDNEmbedIE._VALID_URL).pattern

    # test extracting video id from url
    assert UDNEmbedIE._match_id(url) == '300040'
    # test extracting url from url
    assert UDNEmbedIE._extract_url(url) == url

    # test check if url is valid
    assert UDNEmbedIE._is_valid_url(url)

    # test check if url is invalid

# Generated at 2022-06-24 13:47:50.416641
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    t_instance = UDNEmbedIE()
    # t_instance = UDNEmbedIE(params={'webpage_url': 'http://video.udn.com/embed/news/300040'})
    # print(t_instance.__dict__)
    # print(t_instance.__class__.__name__)
    # print(t_instance.__class__.__bases__)
    # print(UDNEmbedIE.__bases__)
    # print(UDNEmbedIE.__dict__)
    # print(UDNEmbedIE.__module__)
    # print(UDNEmbedIE.__name__)
    # print(dir(UDNEmbedIE))
    # print(dir(t_instance))
    # print(t_instance.IE_DESC)   #

# Generated at 2022-06-24 13:47:57.151097
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # create a subclass
    class TestIE(UDNEmbedIE):
        IE_DESC = 'Test IE'
    ie = TestIE(UDNEmbedIE.create_ie_instance())


# Generated at 2022-06-24 13:47:59.341822
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	assert UDNEmbedIE is not None
	UDNEmbedIE()

# Generated at 2022-06-24 13:48:06.285304
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert isinstance(UDNEmbedIE({})._VALID_URL, type(UDNEmbedIE({})._PROTOCOL_RELATIVE_VALID_URL))
    assert re.match(UDNEmbedIE({})._VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert re.match(UDNEmbedIE({})._VALID_URL, 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:48:11.566333
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:48:16.761528
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()
    assert(class_UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert(class_UDNEmbedIE.ie_desc() == '聯合影音')

# Generated at 2022-06-24 13:48:18.959984
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:48:22.992864
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    if udne.IE_DESC != "聯合影音":
        raise AssertionError("class constructor of class UDNEmbedIE may have changed")

# Generated at 2022-06-24 13:48:32.592757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    obj = UDNEmbedIE()
    obj.url = url
    assert obj.IE_NAME == 'udn'
    assert obj.IE_DESC == '聯合影音'
    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:48:35.312902
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.IE_NAME, UDNEmbedIE.IE_DESC)



# Generated at 2022-06-24 13:48:36.809109
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:48:42.615983
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:48:48.148521
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == 'UDN'
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:59.197015
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('Test UDNEmbedIE:')
    from .common import TEST_OUTPUT_1
    from .common import TEST_OUTPUT_2
    from .common import TEST_OUTPUT_3
    from .common import TEST_OUTPUT_4
    from .common import TEST_OUTPUT_5
    from .common import TEST_OUTPUT_6
    from .common import TEST_OUTPUT_7

    url_1 = 'http://video.udn.com/embed/news/300040'
    url_2 = 'https://video.udn.com/embed/news/300040'
    url_3 = 'https://video.udn.com/play/news/303776'
    udne = UDNEmbedIE()

# Generated at 2022-06-24 13:49:02.607421
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_ie = UDNEmbedIE()
    assert test_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    return True

# Generated at 2022-06-24 13:49:11.784182
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor of class UDNEmbedIE with common parameters
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Test constructor of class UDNEmbedIE with specific parameters
    ie = UDNEmbedIE()
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS

# Generated at 2022-06-24 13:49:15.815878
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie

# Generated at 2022-06-24 13:49:19.738970
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    e = UDNEmbedIE('www.youtube.com')
    assert e.ie_key() == 'Youtube'



# Generated at 2022-06-24 13:49:21.647548
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE()
    tester._match_id('//video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:49:27.554473
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:49:31.693575
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'

    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.suitable(url)
    assert udn_embed_ie.IE_NAME == 'udn-embed'

# Generated at 2022-06-24 13:49:35.260097
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME
    assert UDNEmbedIE.IE_DESC
    assert UDNEmbedIE._VALID_URL
    assert UDNEmbedIE._TESTS
