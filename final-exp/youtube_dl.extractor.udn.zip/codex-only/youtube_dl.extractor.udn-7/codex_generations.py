

# Generated at 2022-06-24 13:39:43.776997
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:39:49.116965
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    # The following test is just for the constructor
    assert udn.IE_DESC == '聯合影音'
    assert udn._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:39:59.782674
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL==r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(UDNEmbedIE._VALID_URL==r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(re.match(UDNEmbedIE._VALID_URL, "https://video.udn.com/embed/news/300040")!=None)
    assert(re.match(UDNEmbedIE._VALID_URL, "http://video.udn.com/embed/news/300040")!=None)
    

# Generated at 2022-06-24 13:40:00.522833
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:40:03.289407
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE._TESTS[0]['url'] = url
    print
    UDNEmbedIE.suite()


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:40:05.300156
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _tester = InfoExtractor(match='re:%s' % UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert _tester.ie_key() == 'udn_embed'

# Generated at 2022-06-24 13:40:07.860771
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    UDNEmbedIE._TESTS[1]['only_matching'] = True
    ie._TESTS = UDNEmbedIE._TESTS

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:40:09.082874
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = globals()['UDNEmbedIE']
    udne = class_()
    assert udne


# Generated at 2022-06-24 13:40:10.872074
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.startswith('//')
    assert UDNEmbedIE._VALID_URL.replace('embed', 'play') in UDNEmbedIE._TESTS[2]['url']

# Generated at 2022-06-24 13:40:13.757934
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE()
    UDNEmbedIE().extract(url)

# Generated at 2022-06-24 13:40:17.995487
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert info_extractor.IE_DESC == '聯合影音'
    assert info_extractor._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:26.342886
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udnIE = UDNEmbedIE()

    assert udnIE._match_id(url)

    assert udnIE.IE_NAME == 'UDN'
    assert udnIE.IE_DESC == '聯合影音'
    assert udnIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:31.529945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    loader = lambda url: UDNEmbedIE(url)
    url = 'http://video.udn.com/embed/news/300040'
    ie = loader(url)
    expected = 'UDNEmbedIE'
    actual = ie.__class__.__name__
    print(expected)
    print(actual)
    assert expected == actual


# Generated at 2022-06-24 13:40:38.480394
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor with one url of UDNEmbedIE._VALID_URL
    # http://video.udn.com/embed/news/300040
    udn_video = 'http://video.udn.com/embed/news/300040'
    valid_urls = [udn_video]
    tester = InfoExtractor.for_website(
        'udn', valid_urls[0], valid_urls, None, None)
    assert type(tester) is UDNEmbedIE


# Generated at 2022-06-24 13:40:46.227860
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('Test function for constructor of class UDNEmbedIE')
    print('loading module...')
    # Load the module
    from ..YoutubeDL import YoutubeDL
    print('done')
    # Create the instance
    ydl = YoutubeDL()
    # Set options for testing
    options = {'quiet': True, 'no_warnings': True}
    ydl.params.update(options)
    # Test
    url = 'http://video.udn.com/embed/news/300040'
    print('testing URL: ', url)
    info = ydl.extract_info(url, download=False)
    assert info['id'] == '300040'

# Generated at 2022-06-24 13:40:54.397822
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for protocol_relative_url
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # test for valid_url
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    # test for entry_protocol
    UDNEmbedIE._VALID_URL = re.sub(r'https?:', 'http:', UDNEmbedIE._VALID_URL)

# Generated at 2022-06-24 13:40:55.403108
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-24 13:41:06.829141
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == "UdnVideoEmbed"
    assert ie.IE_DESC == "聯合影音"
    # Test _VALID_URL
    assert ie._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    # Test _PROTOCOL_RELATIVE_VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    # Test _TESTS
    # Test_0

# Generated at 2022-06-24 13:41:11.094969
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:14.015200
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)
    # skip download unit test
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:41:22.029649
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # Test case: url contains protocol(https://) and port(:80)
    url = "https://video.udn.com:80/embed/news/300040"
    assert(ie.suitable(url) == True)
    assert(ie._match_id(url) == "300040")

    # Test case: url contains protocol(http://) only
    url = "http://video.udn.com/embed/news/300040"
    assert(ie.suitable(url) == True)
    assert(ie._match_id(url) == "300040")

    # Test case: url contains path(/embed/news/300040) only
    url = "/embed/news/300040"
    assert(ie.suitable(url) == True)

# Generated at 2022-06-24 13:41:25.344896
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    embed_ie = UDNEmbedIE()
    assert embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:34.403928
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:39.069896
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:46.898662
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check the constructor of class UDNEmbedIE
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:41:57.976449
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test class UDNEmbedIE
    """
    # A video URL
    video_url = 'http://video.udn.com/embed/news/300040'
    # Create an instance of class InfoExtractor
    ie = InfoExtractor()
    # Create an instance of class UDNEmbedIE
    udn_ie = UDNEmbedIE()
    # The test of function _real_extract
    result = udn_ie._real_extract(video_url)
    assert result['id'] == '300040'
    assert result['formats'] != []
    assert result['title'] == '生物老師男變女 全校挺"做自己"'
    assert result['thumbnail'] != ''

    # The test of function _PR

# Generated at 2022-06-24 13:42:05.169172
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # A test for the constructor of class UDNEmbedIE in file udnie.py
    instance = UDNEmbedIE()
    assert(instance.IE_DESC == '聯合影音')
    assert(instance._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-24 13:42:09.503921
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:10.241397
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:42:21.247282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)._match_id(None)
    UDNEmbedIE(None)._real_extract(None)
    UDNEmbedIE(None)._search_regex(None, None, None)
    UDNEmbedIE(None)._extract_m3u8_formats(*(None,) * 3)
    UDNEmbedIE(None)._extract_f4m_formats(*(None,) * 3)
    UDNEmbedIE(None)._download_json(*(None,) * 3)
    UDNEmbedIE(None)._download_webpage(*(None,) * 3)
    UDNEmbedIE(None)._sort_formats(*(None,) * 2)

# Generated at 2022-06-24 13:42:30.392476
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_cases = [{
        'url': 'http://video.udn.com/embed/news/300040',
        'result': 'http://video.udn.com/embed/news/300040',
    }, {
        'url': '//video.udn.com/embed/news/300040',
        'result': 'http://video.udn.com/embed/news/300040',
    }]
    for test in test_cases:
        url = test['url']
        udn_embed_ie = UDNEmbedIE()
        assert udn_embed_ie._match_id(url) == udn_embed_ie._match_id(test['result'])

# Generated at 2022-06-24 13:42:33.208107
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:37.185358
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE('UDNEmbed', True)
    assert class_UDNEmbedIE.IE_NAME == 'UDNEmbed'
    assert class_UDNEmbedIE._downloader is True

test_UDNEmbedIE()

# Generated at 2022-06-24 13:42:46.654698
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test for constructor of class UDNEmbedIE
    """
    url='http://video.udn.com/embed/news/300040'
    extractor = UDNEmbedIE(url)

    assert extractor.IE_DESC == '聯合影音'
    assert extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert extractor._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:48.725166
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == udn_embed_ie._TESTS[0]['url']

# Generated at 2022-06-24 13:42:58.139136
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # with URL arguments
    assert(UDNEmbedIE._match_id("//video.udn.com/embed/news/300040") == "300040")
    assert(UDNEmbedIE._match_id("//video.udn.com/play/news/300040") == "300040")
    assert(UDNEmbedIE._match_id("http://video.udn.com/embed/news/300040") == "300040")
    assert(UDNEmbedIE._match_id("https://video.udn.com/embed/news/300040") == "300040")

    assert(UDNEmbedIE._match_id("https://video.udn.com/play/news/300040") is None)

    # without URL arguments

# Generated at 2022-06-24 13:43:00.233326
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:03.808746
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(ie._TESTS) == 3

# Generated at 2022-06-24 13:43:05.624391
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnie = UDNEmbedIE()
    assert udnie.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:43:07.836057
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    obj=UDNEmbedIE()
    obj._real_extract(url)
    print(obj.result)

# Generated at 2022-06-24 13:43:18.746198
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn = UDNEmbedIE(url)
    video_id = udn._match_id(url)
    page = udn._download_webpage(url, video_id)
    options_str = udn._html_search_regex(r'var\s+options\s*=\s*([^;]+);', page, 'options')
    print(options_str)

    trans_options_str = js_to_json(options_str)
    options = udn._parse_json(trans_options_str, 'options', fatal=False) or {}
    if options:
        video_urls = options['video']
        title = options['title']
        poster = options.get('poster')

# Generated at 2022-06-24 13:43:20.958144
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test compatibility with protocol relative urls.
    instance = UDNEmbedIE(None)
    instance.url_result('//video.udn.com/embed/news/300040', 'UDNEmbed')

# Generated at 2022-06-24 13:43:26.795532
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE('UDNEmbedIE', 'http://video.udn.com/embed/news/300040')
    assert udn_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:43:37.058128
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test of constructor of class UDNEmbedIE"""
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:43:38.416445
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	info_extractor = UDNEmbedIE()

# Generated at 2022-06-24 13:43:41.819017
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    cls = InfoExtractor.get_info_extractor(UDNEmbedIE.IE_NAME)
    cls.ie_key()
    cls.working()
    cls.get_host_and_id('https://video.udn.com/embed/news/300040')


# Generated at 2022-06-24 13:43:43.991297
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:43:52.782322
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.ie_key() == 'udn'
    assert obj.ie_desc() == '聯合影音'
    assert obj.IE_DESC
    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:55.176538
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:43:59.338894
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Download in https://video.udn.com/news/303776
    ie = UDNEmbedIE('https://video.udn.com/embed/news/303776')
    assert ie.IE_NAME == 'UDN'

# Generated at 2022-06-24 13:44:01.919264
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None)._match_id(
        'https://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-24 13:44:09.468309
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('unit test')
    udne = UDNEmbedIE()
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne.IE_DESC == '聯合影音'

# unit test for function _real_extract

# Generated at 2022-06-24 13:44:10.173518
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)



# Generated at 2022-06-24 13:44:18.530056
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    assert i.IE_DESC == '聯合影音'
    assert i._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert i._VALID_URL == r'https?:' + i._PROTOCOL_RELATIVE_VALID_URL
    assert i._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert i._TESTS[0]['info_dict']['id'] == '300040'
    assert i._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:44:23.903894
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    res = UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')
    assert res['id'] == '300040'
    assert res['title'] == '生物老師男變女 全校挺"做自己"'
    assert re.match(r'https?://.*\.jpg$', res['thumbnail'])

# Generated at 2022-06-24 13:44:29.148912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS == UDNEmbedIE._TESTS

# Generated at 2022-06-24 13:44:33.924795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    pattern = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    protocol_relative_url = '//video.udn.com/embed/news/300040'
    pattern = re.compile(pattern)
    mobj = pattern.match(protocol_relative_url)
    assert mobj.group('id') == '300040'

# Generated at 2022-06-24 13:44:44.751455
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = '//video.udn.com/embed/news/300040'
    url_real = 'http:' + url
    udneie = UDNEmbedIE()

    assert udneie._match_id(url) == '300040'
    assert udneie._match_id(url_real) == '300040'
    assert udneie._PROTOCOL_RELATIVE_VALID_URL == url
    assert udneie._VALID_URL == url_real
    assert udneie.suitable(url_real)

    # check the result of _real_extract()
    assert isinstance(udneie._real_extract(url_real), dict)


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:44:45.667403
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:44:55.327721
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert u._TEMPLATE_URL == 'http://video.udn.com/embed/news/%s'
    assert u._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u._VALID_URL == 'https?:' + u._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:44:56.131801
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Initialize class
    UDNEmbedIE()

# Generated at 2022-06-24 13:45:00.869970
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie.IE_NAME == 'UDNEmbed'
    assert udn_embed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:45:02.841528
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:05.363159
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    class_name = 'UDNEmbedIE'
    ie = globals()[class_name]()
    ie.extract(url)
# Unit test end

# Generated at 2022-06-24 13:45:07.704546
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:45:10.682028
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie.IE_NAME, str)
    assert re.match(ie._VALID_URL, ie.IE_NAME) is not None
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:45:20.987129
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # code in this function will not be run in normal test,
    # but will be run only when `ytdl_test_UDNEmbedIE` is called
    # (see unit_tests.py)

    ie = UDNEmbedIE()

    assert ie.IE_DESC == '聯合影音'

    assert ie._VALID_URL == 'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:45:27.694871
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    unit test for constructor of class UDNEmbedIE
    """
    import unittest
    class TestUDNEmbedIE(unittest.TestCase):
        """
        unit test for constructor of class UDNEmbedIE
        """
        def test_constructor(self):
            """
            test the constructor of class UDNEmbedIE
            """
            UDNEmbedIE()

    unittest.main()

# Generated at 2022-06-24 13:45:37.321679
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    test_str = 'var options = {video: {"mp4_video_url": "http://cloud.video.taobao.com/play/u/349236941/p/1/e/6/t/1/30278303.mp4", "mp4_video_url": "http://cloud.video.taobao.com/play/u/349236941/p/1/e/6/t/1/30278303.mp4", "m3_video_url": "http://video.udn.com/vod/1/30/11161730.m3u8"}}'

# Generated at 2022-06-24 13:45:47.936434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test normal cases
    ie = UDNEmbedIE(None)

    # Test URL matches
    match = ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._matches_url(match)
    assert ie._matches_url('http:' + match)
    assert ie._matches_url('https:' + match)
    assert ie._matches_url('abc://' + match) == False
    assert ie._matches_url('://' + match) == False

    # Test _real_extract()
    # Case 1: load options, get video urls and test type of url
    url = 'http://video.udn.com/embed/news/300040'
    a_page = ie._download_webpage(url, '300040')
    a_options_str = ie._html_search

# Generated at 2022-06-24 13:45:49.277478
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None).to_screen(None)


# Generated at 2022-06-24 13:45:54.698534
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #test if the id of UDNEmbedIE is same with that passed in

    # Create an UDNEmbedIE instance with a fake url
    instance = UDNEmbedIE(False)
    url = 'http://fake.url/300040'
    instance._match_id(url)
    id = instance._match_id(url)
    assert id == '300040', 'The id you retrieved is not equal to the id you got from URL'

# Generated at 2022-06-24 13:45:56.961762
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # instanciate a test case for class UDNEmbedIE
    testCase = UDNEmbedIE()
    # test constructor is working
    assert testCase



# Generated at 2022-06-24 13:46:07.603725
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE
    assert IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:12.915927
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert UDNEmbedIE('//video.udn.com/embed/news/300040')
    assert UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert UDNEmbedIE('//video.udn.com/play/news/303776')


# Generated at 2022-06-24 13:46:18.637452
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[2]['url']

# Generated at 2022-06-24 13:46:27.785927
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert hasattr(UDNEmbedIE, 'ie_key')
    assert isinstance(UDNEmbedIE.IE_DESC, basestring)
    assert hasattr(UDNEmbedIE, '_VALID_URL')
    assert hasattr(UDNEmbedIE, '_TESTS')
    assert hasattr(UDNEmbedIE, '_download_webpage')
    assert hasattr(UDNEmbedIE, '_search_regex')
    assert hasattr(UDNEmbedIE, '_match_id')
    assert hasattr(UDNEmbedIE, '_real_extract')
    return

# Generated at 2022-06-24 13:46:35.316084
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE('UDNEmbedIE', video_id='300040')
    assert udnEmbedIE.IE_NAME == 'UDNEmbedIE' and udnEmbedIE.IE_DESC == '聯合影音'
    assert udnEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbedIE._VALID_URL == 'https?:' + udnEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:37.429724
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    if (ie is None):
        raise Exception('UDNEmbedIE() failed')

# Generated at 2022-06-24 13:46:41.488551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("test_UDNEmbedIE.py: start running unit test for constructor of class UDNEmbedIE")
    IE = UDNEmbedIE()
    print("test_UDNEmbedIE.py: finish running unit test for testing constructor of class UDNEmbedIE")

# Generated at 2022-06-24 13:46:50.578881
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie1 = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie1.IE_DESC == '聯合影音'
    assert ie1._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie1._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

    ie2 = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie2.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:46:53.023586
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_info_extractor = UDNEmbedIE()
    assert udn_embed_info_extractor is not None

# Generated at 2022-06-24 13:46:53.884881
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:56.424152
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # isinstance() only works for classes, use type() for other types
    assert type(UDNEmbedIE()) == type(InfoExtractor())

# Generated at 2022-06-24 13:47:03.888235
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    with open(r'test/test_data/UTDEmbedIE.json', 'r', encoding='utf-8') as myfile:
        page = myfile.read()
        extractor = UDNEmbedIE()
        extractor._download_webpage = lambda url, video_id: page
        extractor.url = "http://video.udn.com/embed/news/300040"
        extractor._download_webpage("http://video.udn.com/embed/news/300040", "300040")
        extractor._real_extract("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:47:05.101883
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    s = UDNEmbedIE()
    assert s is not None

# Generated at 2022-06-24 13:47:06.508114
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE is not None


# Generated at 2022-06-24 13:47:16.015551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj.test(test_obj._TESTS[0].get('url'))

    # test _download_webpage
    webpage_2 = test_obj._download_webpage(test_obj._TESTS[0].get('url'), '')
    webpage_str = webpage_2.decode('utf-8')
    assert len(webpage_str) > 100

    # test _extract_urls
    urls = test_obj._extract_urls(test_obj._TESTS[0].get('url'), webpage_str)
    assert len(urls) == 1

    # test _real_extract
    video_id = test_obj._match_id(urls[0])

# Generated at 2022-06-24 13:47:24.365993
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # determine_ext
    assert(determine_ext('http://video.udn.com/api/getMp4/video/1175359.mp4') == 'mp4')

    # int_or_none
    assert(int_or_none('123') == 123)
    assert(int_or_none('abc') is None)

    # js_to_json
    assert(js_to_json('var options = [1, 2, 3];') == '[1, 2, 3];')

    # regex for 'options_str'

# Generated at 2022-06-24 13:47:31.472463
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class MockUDNEmbedIE(UDNEmbedIE):
        def _real_extract(self, url):
            return self._real_extract(url)
    def test_embed_constructor(url, match=False):
        # First check if the constructor of class MockUDNEmbedIE could
        # successfully create an instance for the given URL.
        # If match is set to True, the return value should be a match object.
        # If match is set to False, the return value should be None.
        ie = MockUDNEmbedIE(None)
        result = ie._match_vsrs4_url(url)
        if match == True:
            assert result
            assert isinstance(result, MatchObject)
        else:
            assert result == None
    # Test valid URL

# Generated at 2022-06-24 13:47:38.734663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    o = UDNEmbedIE()
    assert o._match_id(url) == '300040'
    assert o._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert o._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:41.804639
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UDNEmbed'
    assert UDNEmbedIE()._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:45.338318
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    udne = UDNEmbedIE()
    assert udne.suitable(url)
    assert udne.IE_NAME == 'udn'

# Generated at 2022-06-24 13:47:51.054387
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    m = udn._PROTOCOL_RELATIVE_VALID_URL
    assert re.search(m, '//video.udn.com/embed/news/300040')
    assert re.search(m, '//video.udn.com/play/news/300040')
    assert re.search(m, '//video.udn.com/play/news/300040') is None

# Generated at 2022-06-24 13:48:00.903809
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class TestUDNEmbedIE(UDNEmbedIE):
        # Turn off download
        def _check_download(self, *args, **kwargs):
            return False

    udn_ie = TestUDNEmbedIE()

    # Test of protocol-relative url, aka. url starts with "//"
    url = '//video.udn.com/embed/news/300040'
    actual_id = udn_ie._match_id(url)
    actual_url = udn_ie._proto_relative_url(url)
    expected_id = '300040'
    expected_url = 'https:' + url
    assert actual_id == expected_id
    assert actual_url == expected_url

    # Test of normal url, aka. url starts with "http:" or "https:"

# Generated at 2022-06-24 13:48:01.549329
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()

# Generated at 2022-06-24 13:48:05.266796
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(AVDummyIE(), test_url)
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:06.163467
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:48:08.525527
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()
    

# Generated at 2022-06-24 13:48:19.265539
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(UDNEmbedIE._TESTS[0].get('url') == 'http://video.udn.com/embed/news/300040')
    assert(UDNEmbedIE._TESTS[0].get('params').get('skip_download') == True)
    assert(UDNEmbedIE._TESTS[1].get('url') == 'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:48:24.378168
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_common import url_for_test
    url = url_for_test(UDNEmbedIE)
    ie = UDNEmbedIE(url)
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'



# Generated at 2022-06-24 13:48:27.226556
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == 'https?:(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'

# Generated at 2022-06-24 13:48:35.455437
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == 'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:48:44.766282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import re
    import json
    url = 'http://video.udn.com/embed/news/300040'
    udnEmbed = UDNEmbedIE()
    webpage = udnEmbed._download_webpage(url, '300040')
    options_str = re.search(r'var\s+options\s*=\s*([^;]+);', webpage).group(1)
    options_json = json.loads(options_str)
    video_urls = options_json['video']
    assert video_urls['mp4'] == '/api/video/300040.mp4'
    assert video_urls['mp4small'] == '/api/video/300040_small.mp4'

# Generated at 2022-06-24 13:48:55.125055
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor
    ie = UDNEmbedIE()
    # unit test for _PROTOCOL_RELATIVE_VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # unit test for _VALID_URL
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    # unit test for IE_DESC
    assert ie.IE_DESC == '聯合影音'
    # unit test for _TESTS
    assert len(ie._TESTS) == 3

# Generated at 2022-06-24 13:48:58.374964
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('')
    print(ie.IE_NAME)
    print(ie.IE_DESC)

# Generated at 2022-06-24 13:49:07.641770
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(lambda  :None).suitable(url)
    UDNEmbedIE(lambda  :None)._real_extract(url)
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(lambda  :None).suitable(url)
    UDNEmbedIE(lambda  :None)._real_extract(url)
    url = 'https://video.udn.com/play/news/303776'
    UDNEmbedIE(lambda  :None).suitable(url)
    UDNEmbedIE(lambda  :None)._real_extract(url)
    return True

# Generated at 2022-06-24 13:49:09.205780
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from . import UDNEmbedIE
    assert UDNEmbedIE("").__class__ == UDNEmbedIE

# Generated at 2022-06-24 13:49:12.737348
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:49:18.546740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    info = UDNEmbedIE()._real_extract(url)
    assert info[0]['url'] == 'https://video.udn.com/embed/news/300040'
    assert info[0]['id'] == '300040'
    assert info[0]['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-24 13:49:19.574397
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()

# Generated at 2022-06-24 13:49:21.087160
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:49:30.253244
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # URLS are set with // at 99% case.
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/embed/news/300040'
    valid_url = 'http://video.udn.com/embed/news/300040'
    _match_id = UDNEmbedIE._match_id(valid_url)
    assert _match_id == '300040'

    # URLS with valid protocol
    valid_url = 'https://video.udn.com/embed/news/300040'
    _match_id = UDNEmbedIE._match_id(valid_url)
    assert _match_id == '300040'

# Generated at 2022-06-24 13:49:36.972224
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME == 'udn'
    assert obj.IE_DESC == '聯合影音'

    # Test the constructor of the class UDNEmbedIE
    assert 'http-mp4' == obj.extract_format_id( \
        {'format_id': 'http-mp4', 'url': 'http://video.udn.com/news/303776'})
