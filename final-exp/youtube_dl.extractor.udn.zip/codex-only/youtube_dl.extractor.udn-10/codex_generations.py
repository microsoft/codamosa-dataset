

# Generated at 2022-06-24 13:39:41.213239
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    valid_urls = [
        "http://video.udn.com/embed/news/300040",
        "https://video.udn.com/embed/news/300040",
    ]

# Generated at 2022-06-24 13:39:47.583854
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    global IE_DESC,IE_NAME
    IE_DESC = '聯合影音'
    IE_NAME = 'UDNEmbed'
    ie = UDNEmbedIE()
    # test 1, just download m3u8
    url = 'http://video.udn.com/embed/news/300040'
    info = ie.extract(url)
    # test 2, just download m3u8
    url = 'https://video.udn.com/embed/news/300040'
    info = ie.extract(url)
    # test 3, video.udn.com/play/news/303776
    url = 'https://video.udn.com/play/news/303776'
    info = ie.extract(url)

# Generated at 2022-06-24 13:39:53.561579
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE."""
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_DESC == '聯合影音'
    assert udn_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:39:56.550233
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    ie.initialize()
    ie.extract()

# Generated at 2022-06-24 13:40:03.638062
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result = UDNEmbedIE()
    assert result.IE_DESC == '聯合影音'
    assert result._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert result._VALID_URL == r'https?:' + result._PROTOCOL_RELATIVE_VALID_URL
    assert len(result._TESTS) != 0


# Generated at 2022-06-24 13:40:10.002594
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-24 13:40:13.844234
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_instance = UDNEmbedIE()

    assert type(udn_embed_instance) == UDNEmbedIE
    assert udn_embed_instance.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:40:18.882216
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:19.822455
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)


# Generated at 2022-06-24 13:40:21.096864
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    assert isinstance(i, InfoExtractor)

# Generated at 2022-06-24 13:40:21.981642
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:40:22.861158
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None, None)

# Generated at 2022-06-24 13:40:33.741461
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE()
    # match_id
    assert udn_embed._match_id(url) == '300040'
    # _real_extract
    input_dict = {'url': url, 'info_dict': {'id': '300040', 'ext': 'mp4', \
                                            'title': '生物老師男變女 全校挺"做自己"', 'thumbnail': r're:^https?://.*\.jpg$'}, \
                  'params': {'skip_download': True}, 'expected_warnings': ['Failed to parse JSON Expecting value']}
    assert udn_embed._real_extract

# Generated at 2022-06-24 13:40:43.577883
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:40:51.581033
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert(udne.ie_key() == 'UDNEmbed')
    assert(udne.SUCCESS_KEY() == 'formats')
    assert(udne.compat_xpath() is not None)
    assert(udne.compat_url() == 'http://video.udn.com/embed/news/300040')
    assert(udne.compat_url(('300040',)) == 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:40:59.695613
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert test.IE_NAME == 'udn'
    assert test.IE_DESC == '聯合影音'
    assert test._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test._VALID_URL == 'https?:' + test._PROTOCOL_RELATIVE_VALID_URL
    assert test._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:41:02.923458
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Passing an empty string should raise an exception
    exception_raised = False
    try:
        UDNEmbedIE("")
    except:
        exception_raised = True
    assert exception_raised


# Generated at 2022-06-24 13:41:11.311786
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.SUCCESS == 1
    assert ie.FAILED == -1

# Generated at 2022-06-24 13:41:13.039021
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert u.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:41:14.040463
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(UDNEmbedIE._downloader).IE_NAME == 'udn'


# Generated at 2022-06-24 13:41:17.424194
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _test_regex_match_class(UDNEmbedIE.IE_DESC, UDNEmbedIE,
            'http://video.udn.com/embed/news/300040')

    _test_regex_match_class(UDNEmbedIE.IE_DESC, UDNEmbedIE,
            'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:41:26.002177
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie.VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:29.062477
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)

    assert ie
    assert ie._downloader
    assert ie._downloader.params
    assert ie.IE_NAME
    assert ie.IE_DESC

# Generated at 2022-06-24 13:41:30.918095
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE(_downloader=None, params={}))


# Generated at 2022-06-24 13:41:33.353236
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    for test in udn_embed_ie._TESTS:
        udn_embed_ie._real_extract(test['url'])

# Generated at 2022-06-24 13:41:35.223047
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert '聯合影音' == ie.IE_DESC



# Generated at 2022-06-24 13:41:36.626886
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE()._VALID_URL)

# Generated at 2022-06-24 13:41:39.427765
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	udn_obj = UDNEmbedIE()
	assert str(type(udn_obj)) == "<class 'youtube_dl.extractor.udn.UDNEmbedIE'>"

# Generated at 2022-06-24 13:41:40.600780
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:41:46.674473
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pylint: disable=protected-access
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    video = UDNEmbedIE._VALID_URL
    assert UDNEmbedIE._TESTS[0]['url'] == video
    assert UDNEmbedIE._TESTS[1]['url'] == video
    assert UDNEmbedIE._TESTS[2]['url'] == video
    assert UDNEmbedIE._TESTS[0]['info_dict']['id']

# Generated at 2022-06-24 13:41:52.493636
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/play/news/303776')
    urls = [
        'http://video.udn.com/embed/news/404062',
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/303776',
    ]
    for url in urls:
        if ie.suitable(url):
            print ('ok:', url)
        else:
            print ('err:',url)


# Generated at 2022-06-24 13:41:52.933358
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE

# Generated at 2022-06-24 13:42:01.367382
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'
    video_info = {
        'id': video_id,
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }
    ie = UDNEmbedIE()
    page = ie._download_webpage(url, video_id)
    options_str = ie._html_search_regex(r'var\s+options\s*=\s*([^;]+);', page,
                                        'options')


# Generated at 2022-06-24 13:42:06.250675
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_obj = UDNEmbedIE()
    assert ie_obj.IE_NAME == 'udn'
    assert ie_obj._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie_obj.ie_key() == 'udn'

# Generated at 2022-06-24 13:42:09.505489
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie is not None

# Generated at 2022-06-24 13:42:20.674437
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result = UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
    assert 'https://video.udn.com/api/video/play/hls/300040?', result['formats'][-1]['url']
    assert 'http://video.udn.com/api/video/play/hds/300040?', result['formats'][-2]['url']
    assert 'http://video.udn.com/api/video/play/mp4/300040?', result['formats'][-3]['url']

    result = UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040?video=297739')

# Generated at 2022-06-24 13:42:21.758779
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:42:24.149431
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'udn'
    assert UDNEmbedIE.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:42:25.925497
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:42:31.502309
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.search(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
                     'http://video.udn.com/embed/news/300040')
    assert re.search(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
                     'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:42:38.047777
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor
    regex = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert regex.match('//video.udn.com/embed/news/300040')
    assert regex.match('//video.udn.com/play/news/300040')
    assert not regex.match('https://video.udn.com/embed/news/300040')
    assert not regex.match('https://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:42:47.280307
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for '//video.udn.com/embed/news/300040', 'http://video.udn.com/embed/news/300040', 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE._TESTS[0]['url'] = UDNEmbedIE._TESTS[0]['url'].replace('http:', '//').replace('https:', '//')
    UDNEmbedIE._TESTS[0]['url'] = UDNEmbedIE._TESTS[0]['url'].rstrip('/')

    ie = UDNEmbedIE()
    ie._real_initialize()

    assert ie._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:56.981339
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test_instance_1 = UDNEmbedIE()
    unit_test_instance_2 = UDNEmbedIE()
    assert unit_test_instance_1 == unit_test_instance_2

    unit_test_instance_3 = UDNEmbedIE(17, 18)
    assert unit_test_instance_3.ie_key() == 'UDNEmbed'
    assert unit_test_instance_3.age_limit == 18
    assert unit_test_instance_3.geo_verification_headers == {}
    assert unit_test_instance_3.geo_bypass_ip_block() == False
    assert unit_test_instance_3.addon() == False
    assert unit_test_instance_3.ie_key() == 'UDNEmbed'
    assert unit_test_instance_3.it

# Generated at 2022-06-24 13:42:58.240247
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' in globals()


# Generated at 2022-06-24 13:43:03.732810
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('http://video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-24 13:43:05.597158
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE('embed/news/300040')
    url = "http://video.udn.com/embed/news/300040"
    assert udn.extract(url)['id'] == '300040'

# Generated at 2022-06-24 13:43:07.248525
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Call the constructor
    ie_obj = UDNEmbedIE()
    # USE THE FOLLOWING LINE TO DEBUG
    assert ie_obj

# Generated at 2022-06-24 13:43:09.058663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test_UDNEmbedIE
    print('Test UDNEmbedIE')
    UDNEmbedIE()
    print('test_UDNEmbedIE completed')

# Generated at 2022-06-24 13:43:12.353650
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL)
    assert(len(ie._TESTS) == 3)
    return


# Generated at 2022-06-24 13:43:13.931261
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne == UDNEmbedIE



# Generated at 2022-06-24 13:43:16.333019
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:43:19.404768
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:43:24.391701
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-24 13:43:32.875050
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(ie.IE_NAME == 'udnembed')
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040')
    assert(ie._TESTS[0]['info_dict']['id'] == '300040')
    assert(ie._TESTS[0]['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-24 13:43:41.969057
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("start")
    # 測試範圍為:
    # https://video.udn.com/embed/news/[000-999]
    # 憑證:
    # https://video.udn.com/embed/news/[000-999] 連續10次都取得到正確的json內容

    # 不正確的網址
    url = "https://video.udn.com/embed/news/100"
    ie = UDNEmbedIE()
    # 必須包含 'udn.com'

# Generated at 2022-06-24 13:43:52.251420
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:57.071980
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(UDNEmbedIE._downloader);
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:59.129096
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS

# Generated at 2022-06-24 13:44:02.437844
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._TESTS == UDNEmbedIE._TESTS

# Generated at 2022-06-24 13:44:07.067025
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("[Info] Unit test for constructor of class UDNEmbedIE")
    ie = UDNEmbedIE()
    if ie is not None:
        print("[Success] Constructor of class UDNEmbedIE successfully.")
    else:
        print("[Fail] Fail to construct class UDNEmbedIE")


# Generated at 2022-06-24 13:44:12.333833
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'
    UDNEmbedIE()._real_extract(url)
    UDNEmbedIE().IE_DESC
    UDNEmbedIE()._VALID_URL
    UDNEmbedIE()._TESTS
    UDNEmbedIE()._download_webpage(url, video_id)
    UDNEmbedIE()._match_id(url)

# Generated at 2022-06-24 13:44:13.079082
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None, None)

# Generated at 2022-06-24 13:44:14.313587
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test only code construction of the class without requesting any webpage
    UDNEmbedIE()

# Generated at 2022-06-24 13:44:17.282223
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE._VALID_URL is UDNEmbedIE._VALID_URL
    assert IE._PROTOCOL_RELATIVE_VALID_URL is UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:44:19.433359
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:44:23.563223
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL is not None
    assert UDNEmbedIE._TESTS is not None
    assert UDNEmbedIE.IE_NAME is not None
    assert UDNEmbedIE.IE_DESC is not None
    assert callable(UDNEmbedIE)



# Generated at 2022-06-24 13:44:27.752072
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE({'__caller__': UDNEmbedIE})
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'

# Generated at 2022-06-24 13:44:32.093257
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == "__main__":
        #test_url = "http://video.udn.com/news/303776"
        test_url = "http://video.udn.com/embed/news/300040"

        ie = UDNEmbedIE()
        result = ie.extract(test_url)
        print(result)

# Generated at 2022-06-24 13:44:38.407636
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie

# Generated at 2022-06-24 13:44:42.605729
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # URL of a 聯合影音 video page
    url = 'http://video.udn.com/embed/news/300040'
    udnembed_ie = UDNEmbedIE('')
    assert udnembed_ie._match_id(url) == '300040'

# Generated at 2022-06-24 13:44:43.857582
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj.to_screen('Hello, World!')

# Generated at 2022-06-24 13:44:51.103827
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_NAME == 'UDNEmbed'
    assert udn_ie.IE_DESC == '聯合影音'
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._VALID_URL == r'https?:' + udn_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:44:56.012588
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import urllib.request
    import json
    req_url = 'https://video.udn.com/service/news/getVideo?video_id=300040'
    req = urllib.request.Request(req_url)
    res = urllib.request.urlopen(req)
    UDNEmbedIE = UDNEmbedIE(url)

    assert UDNEmbedIE.json == json.load(res)

# Generated at 2022-06-24 13:44:56.980525
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE != None


# Generated at 2022-06-24 13:44:59.700963
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_t1 = UDNEmbedIE(None)

    url = 'http://video.udn.com/embed/news/300040'
    udn_t1.extract(url)
    return udn_t1


# Generated at 2022-06-24 13:45:06.692034
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(src = 'http://video.udn.com/embed/news/300040')
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:07.778829
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()
    x.extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:45:09.491220
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_NAME == 'udn')
    assert(ie.IE_DESC == '聯合影音')

# Generated at 2022-06-24 13:45:14.090986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE(None)
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:45:14.593734
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-24 13:45:20.577193
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    repo = 'git://github.com/yoki123/youtube-dl.git'
    video_id = '300040'
    url = 'http://video.udn.com/embed/news/300040'
    ExtractorClass = UDNEmbedIE
    ie = ExtractorClass(repo)
    ie.extract(url)

# Generated at 2022-06-24 13:45:30.000256
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert re.match(ie._PROTOCOL_RELATIVE_VALID_URL,
                    ie._match_id('//video.udn.com/embed/news/300040'))
    assert re.match(ie._VALID_URL, ie._match_id('https://video.udn.com/embed/news/300040'))
    assert not re.match(ie._VALID_URL, ie._match_id('http://www.udn.com'))
    assert not re.match(ie._VALID_URL, ie._match_id('http://'))

# Generated at 2022-06-24 13:45:33.268900
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UDNEmbed'
    assert UDNEmbedIE()._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:39.835413
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert re.search(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.search(UDNEmbedIE._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert re.search(UDNEmbedIE._VALID_URL, 'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:45:40.960467
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:45:42.960194
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE()._VALID_URL
    assert UDNEmbedIE().IE_DESC



# Generated at 2022-06-24 13:45:49.377487
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # the _VALID_URL without the "http" should be converted to
    # "http://video.udn.com/embed/news/300040"
    u = "//video.udn.com/embed/news/300040"
    s = UDNEmbedIE._VALID_URL
    if "http" not in u:
        u = "http:" + u
    if s not in u:
        print("Invalid URL or wrong suffix in _VALID_URL")
    else:
        print("_VALID_URL is ok")

# Generated at 2022-06-24 13:45:56.469176
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    test_url = 'http://video.udn.com/embed/news/300040'
    udne._real_extract(test_url)
    assert udne.IE_NAME == 'UDNEmbed'
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    #assert udne._TESTS == []


# Generated at 2022-06-24 13:45:57.301237
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:00.418979
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Testing UDNEmbedIE")
    UDNEmbedIE()
    print("Done!")

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:46:05.240823
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for constructor
    UDNEmbedIE('https://video.udn.com/embed/news/300040', {})
    # test for _PROTOCOL_RELATIVE_VALID_URL
    UDNEmbedIE('//video.udn.com/embed/news/300040', {})

# Generated at 2022-06-24 13:46:07.350184
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.suitable('https://video.udn.com/embed/news/300040')


# Generated at 2022-06-24 13:46:13.459487
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        '//video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/303776',
    ]

    for u in test_urls:
        ie = UDNEmbedIE(u)
        print(ie)
    return

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:46:14.538167
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:23.508674
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:24.724301
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None, None)

# Generated at 2022-06-24 13:46:26.347907
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    UDNEmbedIE(url)

# Generated at 2022-06-24 13:46:29.683096
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	common = InfoExtractor()
	class_name = common._get_IE_class()
	api = class_name('https://video.udn.com/embed/news/300040')
	assert api.IE_NAME == 'UDNEmbed'

# Generated at 2022-06-24 13:46:32.506110
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie.IE_DESC)
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:46:38.777104
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    u = UDNEmbedIE(url)
    assert u.ie_key() == 'UDNEmbed'
    assert u._VALID_URL == 'https?:%s' % UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:43.698567
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:47.299953
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneembedie_instance = UDNEmbedIE()
    retval = udneembedie_instance._PROTOCOL_RELATIVE_VALID_URL
    assert(retval == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-24 13:46:51.400661
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE('test-UDNEmbedIE', 'http://video.udn.com/embed/news/300040', expected_warnings=['Failed to parse JSON Expecting value'])
    assert(class_UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert(class_UDNEmbedIE.ie_desc() == '聯合影音')
    assert(type(class_UDNEmbedIE) is UDNEmbedIE)


# Generated at 2022-06-24 13:47:01.534223
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/embed/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:06.350524
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:15.849361
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:47:17.623923
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:47:20.064977
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
        flag = True
    except:
        flag = False

    # Check flag
    assert True == flag, 'UDNEmbedIE is not initializable'

# Generated at 2022-06-24 13:47:22.904228
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_NAME == 'udn'
    assert udne.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:47:27.657994
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_value = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/303776',
        '//video.udn.com/embed/news/300040',
    ]
    expected_value = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/303776',
        'http://video.udn.com/embed/news/300040',
    ]
    for i in range(len(udne_value)):
        assert UDNEmbedIE(udne_value[i])._VALID_URL == expected_value[i]

# Generated at 2022-06-24 13:47:31.393283
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE('http://www.youtube.com/watch?v=BaW_jenozKc')
    except:
        raise ValueError("UDNEmbedIE not initialized correctly!")

# Generated at 2022-06-24 13:47:41.562720
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:49.022126
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL
    assert obj.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:47:56.915795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    valid_urls = [
        'http://video.udn.com/embed/news/300040',
    ]
    invalid_urls = [
        'http://video.udn.com/embed/news/300040/',
        'https://video.udn.com/play/news/303776',
        'https://video.udn.com/play/news/303776/',
    ]
    for url in valid_urls:
        match = ie._VALID_URL == url

# Generated at 2022-06-24 13:48:08.478352
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # Run this unit test via
    # $ python -m youtube_dl.extractor.udn --test-UDNEmbedIE

    # Initialize class object
    udn = UDNEmbedIE()

    # In this example, the request URL is from http://video.udn.com/embed/news/300040
    # The video ID is 300040

    request_url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'

    # Call real_extract() method
    udn_data = udn._real_extract(request_url)

    # Display the information
    print('\nvideo_id: ' + video_id)
    print('\ntitle: ' + udn_data['title'])

# Generated at 2022-06-24 13:48:19.148405
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    IE = UDNEmbedIE(url)
    assert IE.IE_DESC == '聯合影音'
    assert IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:23.522676
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udnEmbed = UDNEmbedIE()
    if udnEmbed.suitable(url):
        print ('Test passed')
    else:
        print ('Test failed')

# Generated at 2022-06-24 13:48:27.896832
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    video_type = udne._real_extract(url)['formats'][1]['format_id']
    assert video_type == 'http-hls'

# Generated at 2022-06-24 13:48:29.616684
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

# Generated at 2022-06-24 13:48:30.385758
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:48:40.896739
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:44.696090
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    json_data = '{"video":{"mp4":"http:\/\/vjs.zencdn.net\/v\/oceans.mp4","hls":"http:\/\/vjs.zencdn.net\/v\/oceans.mp4"},"title":"Ocean Waves","poster":"http:\/\/example.com\/oceans.png"}'
    assert udne._proto_relative_url(json_data, url) == 'http://vjs.zencdn.net/v/oceans.mp4'

# Generated at 2022-06-24 13:48:46.892754
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert isinstance(obj, UDNEmbedIE)

# Generated at 2022-06-24 13:48:50.000009
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    import unittest

    sys.path.append(".")
    from tests.test_UDNEmbedIE import TestUDNEmbedIE

    unittest.main()

# Generated at 2022-06-24 13:48:55.299417
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:49:06.009847
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('UDNEmbedIE')
    ie._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)';
    ie._VALID_URL = r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:49:12.278531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert info_extractor.IE_DESC == '聯合影音'
    assert info_extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert info_extractor._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:49:16.182733
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # The current test case is from https://video.udn.com/embed/news/300040
    url = 'http://video.udn.com/embed/news/300040'
    # testing the constructor of class UDNEmbedIE (is it constructed or not)
    udn = UDNEmbedIE(UDNEmbedIE.WORKER, UDNEmbedIE.MAX_WORKERS)
    try:
        udn.suitable(url)
    except:
        assert False

# Generated at 2022-06-24 13:49:21.044092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:49:23.021758
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'

# Generated at 2022-06-24 13:49:29.158070
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # a known good URL
    url = 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match(url).groupdict() == {'id': '300040'}
    assert UDNEmbedIE._VALID_URL.match(url).groupdict() == {'id': '300040'}

# Generated at 2022-06-24 13:49:30.001070
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('')

# Generated at 2022-06-24 13:49:37.233520
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    with open('test_UDNEmbedIE.txt', 'r') as test_file:
        if test_file.read() == '1':
            test_file.close()
            with open('test_UDNEmbedIE.txt', 'w') as test_file:
                test_file.write('2')
            return
    raise AssertionError('Should not have multiple constructors.')