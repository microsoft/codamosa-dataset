

# Generated at 2022-06-24 13:39:43.719633
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    if ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)':
        print("[INFO] Pass: ie._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)'")
    else:
        print("[WARNING] Fail: ie._PROTOCOL_RELATIVE_VALID_URL != '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)'")

# Generated at 2022-06-24 13:39:55.480159
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url_1 = 'http://video.udn.com/embed/news/300040'
    test_url_2 = 'https://video.udn.com/embed/news/300040'
    test_url_3 = 'https://video.udn.com/play/news/303776'
    constructor_params = [
        {'url': test_url_1},
        {'url': test_url_2},
        {'url': test_url_3},
    ]
    for params in constructor_params:
        udn = UDNEmbedIE(params)
        assert udn.match(params['url']) is not None
        assert udn.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:39:56.606585
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:40:02.445971
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    expected_re = r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == expected_re
    assert ie._PROTOCOL_RELATIVE_VALID_URL == expected_re.replace('https?:', '', 1).lstrip('/')

# Generated at 2022-06-24 13:40:03.612695
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE(),'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:40:04.905545
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:40:06.792335
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:40:13.539396
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-24 13:40:15.619095
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/1112"
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:40:18.336094
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._PROTOCOL_RELATIVE_VALID_URL
    assert obj._VALID_URL
    assert obj._TESTS

# Generated at 2022-06-24 13:40:26.593408
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE(url)
    video_id = ie._match_id(url)
    assert (ie._VALID_URL == ie.UDNEmbedIE._VALID_URL)
    assert (r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)' == ie._PROTOCOL_RELATIVE_VALID_URL)
    assert ('聯合影音' == ie.IE_DESC)
    assert ('300040' == video_id)

# Generated at 2022-06-24 13:40:36.980650
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    assert udneie.IE_DESC == "聯合影音"
    assert udneie._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert udneie._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-24 13:40:39.819671
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_udn import UdnIE
    udn_ie = UdnIE()
    assert isinstance(udn_ie.ie_key(), type(UDNEmbedIE.ie_key()))
    assert udn_ie.ie_key() == UDNEmbedIE.ie_key()
    assert udn_ie._VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:40:41.546164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# run the test case for UDNEmbedIE
#test_UDNEmbedIE()

# Generated at 2022-06-24 13:40:42.550811
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()



# Generated at 2022-06-24 13:40:43.882923
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    isinstance(UDNEmbedIE(), InfoExtractor)


# Generated at 2022-06-24 13:40:46.345222
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie

# Generated at 2022-06-24 13:40:52.588387
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    print(ie._PROTOCOL_RELATIVE_VALID_URL)
    print(re.match(ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040').groupdict())
    print(re.match(ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040'))




# Generated at 2022-06-24 13:40:54.044822
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("https://video.udn.com/play/news/303776")

# Generated at 2022-06-24 13:41:02.006020
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    # test the validation of _PROTOCOL_RELATIVE_VALID_URL
    assert re.match(udnei._PROTOCOL_RELATIVE_VALID_URL,
                    '//video.udn.com/embed/news/300040')
    assert not re.match(udnei._PROTOCOL_RELATIVE_VALID_URL,
                        'http://video.udn.com/embed/news/300040')
    assert re.match(udnei._VALID_URL,
                    'https://video.udn.com/embed/news/300040')
    assert not re.match(udnei._VALID_URL,
                        'https://video.udn.com/embed/news/300040?a=1')
    # test the validation

# Generated at 2022-06-24 13:41:06.339965
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_DESC == '聯合影音'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL


test_UDNEmbedIE()

# Generated at 2022-06-24 13:41:07.501326
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:41:11.750289
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    print('test_UDNEmbedIE: extract from url: https://video.udn.com/embed/news/300040')
    udne.extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:41:20.602907
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:41:25.345409
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._TESTS[0]['expected_warnings'] = []
    UDNEmbedIE._TESTS[0]['params'] = {}

# Generated at 2022-06-24 13:41:27.966472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Downloader test
    assert(UDNEmbedIE().download("https://video.udn.com/embed/news/300040") == "Downloading webpage to 300040")

# Generated at 2022-06-24 13:41:33.716517
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Instance of a class
    test_instance = UDNEmbedIE()

    # Access to a protected member of a class
    assert test_instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_instance._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:34.959297
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:41:41.371631
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_udn_embed_ie = UDNEmbedIE()
    assert class_udn_embed_ie != None
    assert class_udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert class_udn_embed_ie._VALID_URL == r'https?:' + class_udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:41:46.813953
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'
    assert udn._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    yt = udn.url_result('http://youtube.com/watch?v=jNQXAC9IVRw', 'Youtube')
    assert yt.ie == 'Youtube'
    assert yt.video_id == 'jNQXAC9IVRw'

# Generated at 2022-06-24 13:41:55.035676
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneiTest = UDNEmbedIE()

    # Test when the options is valid (has directly the video urls)
    udneiTest.extract('https://video.udn.com/embed/news/300040')

    # Test when the options is invalid (has the 'video' js object that must be parsed)
    udneiTest.extract('https://video.udn.com/embed/news/200040')

    # Test when there is no video
    udneiTest.extract('https://video.udn.com/embed/news/400040')

# Generated at 2022-06-24 13:41:58.849396
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = "https://video.udn.com/embed/news/300040"
    expected = ("UDNEmbedIE instance for url: %s" % url)
    actual = repr(ie.__init__(url))
    assert actual == expected


# Generated at 2022-06-24 13:42:05.932825
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ''' Unit test for class UDNEmbedIE '''
    from .. import YoutubeDL
    ie = YoutubeDL({}).IE_NAME_TO_CLASS['udn.com']({})
    ie = ie('http://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    ie = ie('https://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    ie = ie('https://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:42:07.365533
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()

# Generated at 2022-06-24 13:42:09.255959
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(InfoExtractor(''))._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:12.060264
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    UDNEmbedIE(UDNEmbedIE.ie_key(), video_id)()



# Generated at 2022-06-24 13:42:14.678925
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
     udne = UDNEmbedIE()
     assert udne.IE_DESC == '聯合影音', udne.IE_DESC

# Generated at 2022-06-24 13:42:17.152254
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.extract('http://video.udn.com/embed/news/300040')
    ie.extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:42:24.706447
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for class UDNEmbedIE"""
    udn = UDNEmbedIE()
    assert '聯合影音' == udn.IE_DESC

    assert r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)' == udn._PROTOCOL_RELATIVE_VALID_URL
    assert r'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL == udn._VALID_URL

    # test_UDNEmbedIE._validate_url(udn, 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:42:26.327415
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructing a UDNEmbedIE instance
    udn_embed = UDNEmbedIE()

# Generated at 2022-06-24 13:42:36.997100
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_DESC == '聯合影音'
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == \
           r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == r'https?:' + \
           r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Test _real_extract case with url: http://video.udn.com/embed/news/300040
    # By testing some attributes in returned value of _real_extract
    test_url = 'http://video.udn.com/embed/news/300040'
    result = UD

# Generated at 2022-06-24 13:42:45.838523
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_url = "https://video.udn.com/play/news/0/2/2/300040"
    test_url2 = "https://video.udn.com/embed/news/300040"
    test_url3 = "http://video.udn.com/embed/news/300040"
    if ie.suitable(test_url) and ie.suitable(test_url2) and ie.suitable(test_url3):
        print('ok')


    # test extract
    # test_url = "http://video.udn.com/video/embed/news/300040"
    # result = ie.extract(test_url)
    # print(result)

# Generated at 2022-06-24 13:42:54.817871
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Class constructor test
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

    # Unit tests for the _PROTOCOL_RELATIVE_VALID_URL regex
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Unit tests

# Generated at 2022-06-24 13:43:02.046694
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    if(ie._match_id(ie._VALID_URL) != '300040' or
        ie._match_id(ie._PROTOCOL_RELATIVE_VALID_URL) != '300040' or
        ie._match_id('https://video.udn.com/play/news/303776') != '303776' or
        ie._match_id('https://video.udn.com/play/news/403776') is None or
        ie.IE_DESC != '聯合影音'):
        print('unit test failed.')
    else:
        print('unit test succeeded.')


# Generated at 2022-06-24 13:43:02.909377
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:43:06.840003
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # The test URL in _TESTS is not available any more, but the extractor
    # still works for other UDN news video links.  We don't use an existing
    # URL from a _TESTS item above, because those are not always available.
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    if ie.suitable(url):
        ie.download(url)

# Generated at 2022-06-24 13:43:07.994777
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' in globals()



# Generated at 2022-06-24 13:43:11.097032
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    print(instance.IE_DESC)
    print(instance._TESTS)
    print(instance._VALID_URL)
    print(instance._PROTOCOL_RELATIVE_VALID_URL)
    print(instance._real_extract('http://video.udn.com/embed/news/300040'))


# Generated at 2022-06-24 13:43:14.987842
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_url = 'http://video.udn.com/embed/news/300040'
    embed_ie = UDNEmbedIE()
    embed_ie.validate_url(valid_url)
    embed_ie.match_id(valid_url)
    embed_ie.extract(valid_url)

# Generated at 2022-06-24 13:43:20.729876
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test constructor of class UDNEmbedIE"""
    ie=UDNEmbedIE()
    print(ie.__class__.__name__, "'s constructor test.")

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:43:25.014676
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    regex = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    match = re.match(regex, url)
    assert match
    assert UDNEmbedIE._match_id(url) == '300040'
    assert match.group('id') == '300040'

# Generated at 2022-06-24 13:43:30.061583
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:33.439075
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UdnIE = UDNEmbedIE()
    UdnIE.suitable('//video.udn.com/embed/news/300040')
    UdnIE.suitable('https://video.udn.com/embed/news/300040')
    UdnIE.suitable('https://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:43:34.296400
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:43:39.554526
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME == 'udn'
    assert len(UDNEmbedIE._TESTS) > 0
    assert 'udn' in UDNEmbedIE.ie_keymap
    assert UDNEmbedIE.ie_keymap['udn'] == UDNEmbedIE
    # print(UDNEmbedIE._VALID_URL)



# test_UDNEmbedIE()

# Generated at 2022-06-24 13:43:45.268396
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test youtube url
    youtube_url = 'https://www.youtube.com/embed/IXZKf-kVubE?autoplay=1'
    try:
        UDNEmbedIE(youtube_url)
    except AssertionError as e:
        assert e == 'UDN Url not supported: %s' % youtube_url
    # test not udn url
    not_udn_url = 'https://www.google.com/search'
    try:
        UDNEmbedIE(not_udn_url)
    except AssertionError as e:
        assert e == 'UDN Url not supported: %s' % not_udn_url

# Generated at 2022-06-24 13:43:46.242594
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:43:49.208225
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie is not None
    assert udn_embed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:51.391007
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    res = UDNEmbedIE()._match_id(
        'https://video.udn.com/embed/news/300040')
    assert res == '300040'

# Generated at 2022-06-24 13:43:52.255806
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:44:03.203244
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # must use protocol relative URL
    test_embed_url = '//video.udn.com/embed/news/300040'
    _ = UDNEmbedIE(UDNEmbedIE._downloader)._match_id(test_embed_url)
    _ = UDNEmbedIE(UDNEmbedIE._downloader)._real_extract(test_embed_url)
    # must use protocol-relative URL
    # _ = UDNEmbedIE(UDNEmbedIE._downloader)._real_extract("http://"+test_embed_url)
    # must be valid URL
    # _ = UDNEmbedIE(UDNEmbedIE._downloader)._real_extract("http://"+test_embed_url+"/")

# Generated at 2022-06-24 13:44:05.265733
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)



# Generated at 2022-06-24 13:44:13.773138
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .UdnIE import UdnIE
    url = 'https://video.udn.com/play/news/303776'
    UDNEmbedIE._VALID_URL =  r'https?://video\.udn\.com/embed/news/\d+'
    ie = UdnIE()
    ie.extract(url)
    assert(ie.__class__.__name__ == 'UdnIE')
    ie.extract(r'https://video.udn.com/embed/news/303776')
    assert(ie.__class__.__name__ == 'UDNEmbedIE')
    UDNEmbedIE._VALID_URL =  r'https?://(video\.)?udn\.com/play/news/\d+'
    ie.extract(url)

# Generated at 2022-06-24 13:44:16.753525
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test constructor of class UDNEmbedIE"""
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url=url)

# Generated at 2022-06-24 13:44:22.869474
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # C_REL, C_VALID_URL and C_TESTS are all attributes of class UDNEmbedIE
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:44:25.172354
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:44:34.472875
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:44:41.672502
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u._VALID_URL == r'https?:' + u._PROTOCOL_RELATIVE_VALID_URL
    assert u.IE_DESC == '聯合影音'
    assert u.IE_NAME == 'udn_video'

# Generated at 2022-06-24 13:44:43.368020
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:44:44.636702
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    print(udn_embed)

# Generated at 2022-06-24 13:44:48.257170
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:50.677330
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        info_extractor = UDNEmbedIE()
    except Exception as e:
        return False
    return True


# Generated at 2022-06-24 13:44:55.103759
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'
    pattern = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    match = pattern.match(url)
    assert match, 'constructor of class UDNEmbedIE did not work'


# Generated at 2022-06-24 13:44:59.818574
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    print("test_UDNEmbedIE()")
    print("url = {}".format(url))
    udn = UDNEmbedIE()
    info = udn.extract(url)
    if (info != None):
        for k in info:
            print("%s = %s" % (k, info[k]))


# Generated at 2022-06-24 13:45:01.251579
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://www.udnvideo.com/embed/news/300040')

# Generated at 2022-06-24 13:45:05.846841
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert isinstance(udne, InfoExtractor)
    assert udne._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    match = re.search(udne._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert match is not None


# Generated at 2022-06-24 13:45:12.157758
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    # test public attribute
    assert test_obj.IE_DESC == '聯合影音'
    # test protected attribute
    assert test_obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj._VALID_URL == 'https?:' + test_obj._PROTOCOL_RELATIVE_VALID_URL
    # test private attribute
    with pytest.raises(AttributeError) as excinfo:
        test_obj._TESTS
    assert str(excinfo.value) == 'please use property(lambda x:x.__name__)(func) to access private attribute'
    # test public method
    test_obj

# Generated at 2022-06-24 13:45:22.376014
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for new one
    ie = UDNEmbedIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_desc()
    assert ie._VALID_URL == ie._VALID_URL_TEST
    assert ie._TESTS == ie._TESTS_TEST
    assert ie._download_webpage == ie._download_webpage_test
    assert ie._match_id == ie._match_id_test
    assert ie._html_search_regex == ie._html_search_regex_test
    assert ie._parse_json == ie._parse_json_test
    assert ie._extract_m3u8_formats == ie._extract_m3u8_formats_test
    assert ie._extract_f4m_formats

# Generated at 2022-06-24 13:45:31.552947
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

    embed_udn = UDNEmbedIE(UDNEmbedIE.ie_key())
    assert embed_udn.IE_NAME == 'udn'
    assert embed_udn.IE_DESC == '聯合影音'
    assert embed_udn._VALID_URL == _VALID_URL

# Generated at 2022-06-24 13:45:35.352906
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'udnembed'
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS == ie._TESTS

# Generated at 2022-06-24 13:45:37.284247
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ITHOME_URL_TEMPLATE == "https://video.udn.com/embed/news/%s"

# Generated at 2022-06-24 13:45:44.608938
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO: some other tests
    from ..tests.test_extractor import get_testcases
    testcases = get_testcases(UDNEmbedIE)
    for testcase in testcases:
        if '://video.udn.com/' in testcase['url']:
            udn_embed_ie = UDNEmbedIE()
            udn_embed_ie.suitable(testcase['url'])
            udn_embed_ie.extract(testcase['url'])

# Generated at 2022-06-24 13:45:48.101989
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udn = UDNEmbedIE()
    assert udn._match_id(url) == '300040'
    print ('test_UDNEmbedIE() passed!')


# Generated at 2022-06-24 13:45:51.630220
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        udne = UDNEmbedIE()
        assert udne
    except Exception as e:
        print("test_UDNEmbedIE() encounter error:{}".format(e))
        assert False

# Generated at 2022-06-24 13:45:53.436244
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE"""
    # Test case 1
    UDNEmbedIE()

    # Test case 2
    UDNEmbedIE(None)

    # Test case 3
    UDNEmbedIE(None, 'mock-version', 'mock-downloader')

# Generated at 2022-06-24 13:45:54.128650
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE is True

# Generated at 2022-06-24 13:45:55.616922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(test_url)

# Generated at 2022-06-24 13:45:59.629764
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import (
        ExtractorError,
    )
    unittest.TestCase.assertRaisesRegexp = unittest.TestCase.assertRaisesRegex
    udn_embed_ie = UDNEmbedIE()
    # Throw exception when url is invalid
    unittest.TestCase.assertRaisesRegexp(
        ExtractorError, '', udn_embed_ie._real_extract, 'http://example.com')


if __name__ == '__main__':
    import unittest
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:46:09.896218
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == "UDNEmbed"
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:18.859446
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	# mock url
	mock_test_url = "http://video.udn.com/embed/news/300040"
	# expected result
	mock_test_result = {
		"id": "300040", 
		"ext": "mp4", 
		"title": "生物老師男變女 全校挺\"做自己\"", 
		"thumbnail": "re:^https?://.*\.jpg$"
	}

	# create UDNEmbedIE object
	udn_embed_ie = UDNEmbedIE()

	# download web page from url
	page = udn_embed_ie._download_webpage(mock_test_url, "300040")

	# extract options from page
	options

# Generated at 2022-06-24 13:46:20.242783
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE != None
    assert UDNEmbedIE.IE_DESC != None

# Generated at 2022-06-24 13:46:30.437270
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udni = UDNEmbedIE()
    assert(udni.IE_NAME == 'UDNEmbed')
    assert(udni.IE_DESC == '聯合影音')
    assert(udni.IE_DESC_UNICODE == '聯合影音')
    assert(udni.IE_VERSION == '20180313')
    assert(len(udni.IE_URL_BASE) == 29)
    assert(udni.IE_URL_BASE == 'https://video.udn.com/')
    assert(len(udni.IE_URL) == 0)
    assert(len(udni.IE_URL_SUFFIX) == 0)
    assert(udni.IE_URLS == [])

# Generated at 2022-06-24 13:46:41.826304
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _UDNEmbedIE = UDNEmbedIE()
    # _UDNEmbedIE.ie_key == 'UDNEmbed'
    assert _UDNEmbedIE.ie_key == 'UDNEmbed'
    # _UDNEmbedIE.embed_url == 'http://video.udn.com/embed/news/%s'
    assert _UDNEmbedIE.embed_url == 'http://video.udn.com/embed/news/%s'
    # _UDNEmbedIE.embed_url == 'http://video.udn.com/embed/news/672757'
    assert _UDNEmbedIE.embed_url % '672757' == 'http://video.udn.com/embed/news/672757'

# Generated at 2022-06-24 13:46:44.380043
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    ie = UDNEmbedIE(None)
    ie._match_id(url)

# Generated at 2022-06-24 13:46:48.447292
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	embed = UDNEmbedIE()
	assert embed.test("http://video.udn.com/embed/news/300040", expect_warnings=True)
	assert embed.test("https://video.udn.com/embed/news/300040")
	assert not embed.test("https://video.udn.com/play/news/303776")

# Generated at 2022-06-24 13:46:52.326673
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    regex_URL_PATTERN = r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    url = 'http://video.udn.com/embed/news/300040'
    # test for _VALID_URL
    assert (re.match(UDNEmbedIE._VALID_URL, url) is not None)
    # test for _PROTOCOL_RELATIVE_VALID_URL
    assert (re.match(regex_URL_PATTERN, url) is not None)

# Generated at 2022-06-24 13:46:56.955750
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.suitable('http://video.udn.com/embed/news/300040')
    assert ie.suitable('https://video.udn.com/play/news/303776')
    assert not ie.suitable('https://video.udn.com/news/303776')

# Generated at 2022-06-24 13:47:01.194779
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()(test_url)
    test_url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()(test_url)

# Generated at 2022-06-24 13:47:01.945106
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:47:02.338220
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-24 13:47:06.284858
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
  ie = UDNEmbedIE()
  assert ie.ie_key() == 'UDNEmbedIE'
  assert ie.ie_desc() == '聯合影音'


# Generated at 2022-06-24 13:47:08.259203
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..test import get_testcases
    for entry in get_testcases(UDNEmbedIE, suffix='.js'):
        yield entry

# Generated at 2022-06-24 13:47:09.273947
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:47:09.869931
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:47:18.758933
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .youtube import YoutubeIE
    udn = UDNEmbedIE()
    assert isinstance(udn, InfoExtractor)
    assert hasattr(udn, '_download_webpage')
    assert not hasattr(udn, '_FILE_SUFFIX')
    assert hasattr(udn, '_WORKING')
    assert hasattr(udn, '_IE_DESC')
    assert not hasattr(udn, '_TESTS')
    assert hasattr(udn, '_VALID_URL')
    assert hasattr(udn, '_downloader')
    assert not hasattr(udn, '_download_webpage_handle')
    assert not hasattr(udn, '_downloads_queue')

# Generated at 2022-06-24 13:47:21.222841
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(_PROTOCOL_RELATIVE_VALID_URL, video_id='300040')

# Generated at 2022-06-24 13:47:24.659148
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    u = UDNEmbedIE()
    assert(u._match_id(url) == '300040')


# Generated at 2022-06-24 13:47:27.163303
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_video = UDNEmbedIE()
    assert udn_video.IE_NAME == 'udn'
    assert udn_video.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:47:38.231787
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    assert inst.IE_NAME == "udn"
    assert inst.IE_DESC == "聯合影音"
    assert inst._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert inst._VALID_URL == r"https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-24 13:47:46.598122
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_object = UDNEmbedIE()
    assert test_object.IE_DESC == '聯合影音'
    assert test_object._VALID_URL == 'https?:' + test_object._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:47:49.478726
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if 'Unit test for constructor of class UDNEmbedIE':
        ie = UDNEmbedIE()
        assert(ie.IE_DESC == '聯合影音')

# Generated at 2022-06-24 13:47:57.294850
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	import unittest
	from ytdl_server.compat import PY3
	from ytdl_server.compat import urlparse
	import sys
	class TestUDNEmbedIE(unittest.TestCase):
		def setUp(self):
			self.url = 'http://video.udn.com/embed/news/300040'
			self.extract_ie = UDNEmbedIE()
			self.mock_downloader = MockDownloader()


# Generated at 2022-06-24 13:48:02.815181
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

if __name__ == '__main__':
    test_UDNEmbedIE();

# Generated at 2022-06-24 13:48:05.254030
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except Exception as e:
        assert(str(e) == UDNIE._VALID_URL)


# Generated at 2022-06-24 13:48:10.059439
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    udne = UDNEmbedIE()
    assert udne.suitable(url)
    assert udne.IE_NAME == 'UDN'
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert udne._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:19.779066
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    udn_embed._VALID_URL = UDNEmbedIE._VALID_URL
    udn_embed._PROTOCOL_RELATIVE_VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    udn_embed._TESTS = UDNEmbedIE._TESTS
    udn_embed._TEST = UDNEmbedIE._TEST
    udn_embed.ie_key = UDNEmbedIE.ie_key
    udn_embed.ie_desc = UDNEmbedIE.IE_DESC

# Generated at 2022-06-24 13:48:26.705734
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    # Constructor without parameters
    assert type(udn) is UDNEmbedIE

    # Constructor with parameters
    udn_ws_ie = UDNEmbedIE(downloader=None)
    assert udn_ws_ie.downloader == None
    udn_ws_ie_2 = UDNEmbedIE(params=None)
    assert udn_ws_ie_2.params == None


# Generated at 2022-06-24 13:48:30.273290
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import test_IE
    test_IE(UDNEmbedIE)
    # udn embed test
    if __name__ == '__main__':
        test_IE(UDNEmbedIE)(r'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:48:40.763852
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL is not None
    assert UDNEmbedIE._VALID_URL is not None
    assert UDNEmbedIE._TESTS is not None
    assert UDNEmbedIE.IE_NAME is not None
    assert UDNEmbedIE.IE_DESC is not None
    assert UDNEmbedIE.WEBPAGE_URL_TEMPLATE is not None
    assert UDNEmbedIE._TESTS is not None

    udn = UDNEmbedIE()
    assert udn._match_id('https://video.udn.com/embed/news/300040') is not None
    assert udn._match_id('https://video.udn.com/play/news/300040') is not None

# Generated at 2022-06-24 13:48:41.723140
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:48:42.996950
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    print(u)

# Generated at 2022-06-24 13:48:47.106002
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == r'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL
    assert udn.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:48:49.808292
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:48:51.699959
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:59.722152
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor of class UDNEmbedIE
    # Success
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

    # Failure
    try:
        ie_fail = UDNEmbedIE(ie_desc='abc')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-24 13:49:01.486788
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    res = UDNEmbedIE()
    assert res != None


# Generated at 2022-06-24 13:49:08.712717
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE("https://video.udn.com/embed/news/300040")
    assert(udnIE.IE_NAME == 'udn')
    #print("IE_DESC=" + udnIE.IE_DESC)
    assert(udnIE.IE_DESC == '聯合影音')
    assert(udnIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(len(udnIE._TESTS) == 3)

# Generated at 2022-06-24 13:49:14.500021
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.SUFFIX == 'Embed'
    assert ie.ie._PROTOCOL_RELATIVE_VALID_URL == ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.ie._VALID_URL == ie._VALID_URL
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:49:19.363214
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:49:28.943658
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.get_video_id('http://video.udn.com/embed/news/300040') == '300040'
    assert u.get_video_id('//video.udn.com/embed/news/300040') == '300040'
    assert u.get_video_id('https://video.udn.com/embed/news/300040') == '300040'
    assert u.get_video_id('https://video.udn.com/play/news/300040') == '300040'
    assert u.get_video_id('http://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-24 13:49:39.197869
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None, None).IE_DESC == '聯合影音'
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert UDNEmbedIE._TESTS[0]['info_dict']['title'] == \
        '生物老師男變女 全校挺"做自己"'
    assert UDNEmbedIE._TESTS[0]['info_dict']['thumbnail'] == \
        r're:^https?://.*\.jpg$'
    assert UDNEmbedIE._TES