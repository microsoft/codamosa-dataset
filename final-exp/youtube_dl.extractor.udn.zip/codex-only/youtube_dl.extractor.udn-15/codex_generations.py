

# Generated at 2022-06-24 13:39:32.498515
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._match_id('http://video.udn.com/embed/news/300040')



# Generated at 2022-06-24 13:39:38.371927
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,'https://video.udn.com/', '300040')
    #print(test)
    assert test.ie_key() == "UDNEmbed"
    assert test.video_id == 300040
    assert test.url == 'https://video.udn.com/embed/news/300040'
    assert test.extractor_key == 'UDNEmbed'

# Generated at 2022-06-24 13:39:39.205635
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:39:43.873955
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

    assert len(ie._TESTS) == 3

# Generated at 2022-06-24 13:39:51.065654
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040';
    UDNEmbedIE()._VALID_URL = UDNEmbedIE._VALID_URL
    UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    UDNEmbedIE()._match_id(url)
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:39:52.195379
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()

# Generated at 2022-06-24 13:40:03.432776
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_cases = [
        # test empty url
        {
            "url":'',
            "result":(False,None)
        },
        # test protocol relative url
        {
            "url":'//video.udn.com/embed/news/300040',
            "result":(True,'300040')
        },
        # test full url
        {
            "url":'https://video.udn.com/embed/news/300040',
            "result":(True,'300040')
        },
        # test unsupport url
        {
            "url":'http://tw.beauty.yahoo.com/',
            "result":(False,None)
        }
    ]

# Generated at 2022-06-24 13:40:09.342615
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    assert ie.ie_key() == "UdnEmbed"
    assert ie.IE_NAME == "聯合影音"
    assert ie.IE_DESC == "聯合影音"
    assert ie.can_handle_url(url) == True
    ie.extract(url)



# Generated at 2022-06-24 13:40:10.920980
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL is not None


# Generated at 2022-06-24 13:40:19.775962
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test if subclass of InfoExtractor is properly set
    ie = UDNEmbedIE('http://example.com')
    assert ie.__class__.__name__ == 'UDNEmbedIE'
    assert ie.__class__.__bases__[0].__name__ == 'InfoExtractor'
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

    # Test if string representation of instance is properly set
    ie = UDNEmbedIE('http://example.com')
    assert ie.__str__() == '<UDNEmbedIE http://example.com>'

# Generated at 2022-06-24 13:40:21.393226
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-24 13:40:31.577152
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import youtube_dl.extractor.udn as udn
    udn_embed_ie = udn.UDNEmbedIE()
    unittest.assertEqual(udn_embed_ie.IE_DESC, '聯合影音')
    unittest.assertEqual(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL, r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    unittest.assertEqual(udn_embed_ie._VALID_URL, r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    #assertEqual(udn_embed_ie._TESTS

# Generated at 2022-06-24 13:40:34.581892
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert(UDNEmbedIE._VALID_URL)
    assert(UDNEmbedIE._TESTS)

# Generated at 2022-06-24 13:40:44.431001
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    TEST_STRING = 'test string'
    # Initialize class
    ie = UDNEmbedIE()
    assert ie._downloader == None
    assert ie._WORKING_URL_TEMPLATE == None
    assert ie._download_webpage == None
    assert ie._search_regex == None
    assert ie._html_search_regex == None
    assert ie._og_search_title == None
    assert ie._og_search_description == None
    assert ie._og_search_thumbnail == None
    assert ie._html_search_meta == None
    assert ie._xpath_text == None
    assert ie._type == None
    assert ie._ie_key == None
    assert ie._NETRC_MACHINE == None
    assert ie._password_management_enabled == None

# Generated at 2022-06-24 13:40:52.035362
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:40:54.538942
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE._VALID_URL)
    UDNEmbedIE(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:40:55.165635
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert True

# Generated at 2022-06-24 13:41:04.132223
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE(None)
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == r'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL
    assert udn._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:41:15.225577
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import re

    test_valid_URLs = [
        'https://video.udn.com/play/news/300040',
        'https://video.udn.com/play/news/300040/',
        'http://video.udn.com/play/news/300040',
        'http://video.udn.com/play/news/300040/',
    ]

    test_invalid_URLs = [
        'https://video.udn.com/play/news/300040_1',
        'http://video.udn.com/play/news/300040_1',
    ]


# Generated at 2022-06-24 13:41:20.037615
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'https://video.udn.com/play/news/303776'
    obj = UDNEmbedIE()
    assert obj.match(test_url)
    assert obj.IE_DESC == obj.ie._ies[obj.ie.default_extractor_index].IE_DESC
    assert obj.ie.default_extractor_index == obj.ie.index_of_ie('UDNEmbedIE')

# Generated at 2022-06-24 13:41:21.565677
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()

# Generated at 2022-06-24 13:41:22.828736
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert isinstance(UDNEmbedIE(), UDNEmbedIE)


# Generated at 2022-06-24 13:41:25.068186
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:41:33.639112
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create a valid url.
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    id = ie._match_id(url)
    assert id == '300040'
    # Create a valid url of m3u8.
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    id = ie._match_id(url)
    assert id == '300040'
    # Create an invalid url.
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    id = ie._match_id(url)
    assert id is None

# Generated at 2022-06-24 13:41:40.047190
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test with empty url string
    url=''
    udn = UDNEmbedIE(url)
    # Test with url has wrong domain
    url='http://abc.abc'
    udn = UDNEmbedIE(url)
    # Test with url has right domain and right pattern
    url='https://video.udn.com/play/news/300040'
    udn = UDNEmbedIE(url)
    assert udn.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:41:40.723967
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:41:46.776510
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    # Test for production constructor
    IE_test = IE._real_extract('http://video.udn.com/embed/news/300040')
    assert IE_test['id'] == '300040'
    assert IE_test['title'] == '生物老師男變女 全校挺"做自己"'
    assert IE_test['thumbnail'] == 'https://i.vimeocdn.com/video/527332592_1280x720.jpg'
    # Test for production constructor when there is no poster
    IE_test = IE._real_extract('http://video.udn.com/embed/news/300814')
    assert IE_test['thumbnail'] == None

# Generated at 2022-06-24 13:41:48.815561
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbedIE', 'test cases')

# Generated at 2022-06-24 13:41:59.288513
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

    assert ie._VALID_URL == 'https?://video\.udn\.com/embed/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-24 13:42:00.999531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert type(UDNEmbedIE('http://video.udn.com/embed/news/300040')) == UDNEmbedIE

# Generated at 2022-06-24 13:42:13.139726
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:14.533857
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	print("constructor test")
	g = UDNEmbedIE()
	print("constructor test OK")


# Generated at 2022-06-24 13:42:15.780009
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE.ie_key()

# Generated at 2022-06-24 13:42:17.702280
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE().suitable(url)
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:42:21.241486
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for youtube video
    UDNEmbedIE()._real_extract('https://video.udn.com/news/303776')

    # Test for udn video
    UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')

    # Test if the constructor failed
    test_func = lambda: UDNEmbedIE()
    assert_raises(AttributeError, test_func)

# Generated at 2022-06-24 13:42:22.399015
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:42:25.848974
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, {})._real_extract('http://video.udn.com/embed/news/296582')
    UDNEmbedIE(None, {})._real_extract('https://video.udn.com/embed/news/296582')
    UDNEmbedIE(None, {})._real_extract('https://video.udn.com/play/news/296582')

# Generated at 2022-06-24 13:42:36.624239
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the regular URL
    udn1 = UDNEmbedIE()
    assert udn1._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn1._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn1._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn1._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:42:38.813934
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:42:44.639517
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-24 13:42:45.221434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-24 13:42:52.819177
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL) == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert(UDNEmbedIE._VALID_URL) == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert(UDNEmbedIE._TESTS[0]['url']) == 'http://video.udn.com/embed/news/300040'
    assert(UDNEmbedIE._TESTS[0]["info_dict"]["id"]) == '300040'
    assert(UDNEmbedIE._TESTS[0]["info_dict"]["ext"]) == 'mp4'

# Generated at 2022-06-24 13:42:58.163815
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None)._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE(None)._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:02.821792
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _valid_url = 'https://video.udn.com/embed/news/300040'
    _instance = UDNEmbedIE()
    assert _instance.ie_key() == 'UDNEmbed'
    assert _instance.ie_name() == '聯合影音'
    assert _instance.description() == '聯合影音'
    assert _instance._VALID_URL == _valid_url
    assert _instance._TESTS[0]['url'] == _valid_url

# Generated at 2022-06-24 13:43:12.205793
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    # Test 1 - function _real_extract()
    # Vars: url
    url = 'http://video.udn.com/embed/news/300040'
    # Vars: video_id
    video_id = '300040'
    # Vars: page
    page = '<html><title>聯合影音</title></html>'
    # Vars: options_str

# Generated at 2022-06-24 13:43:20.927656
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE()
    assert tester.IE_DESC == '聯合影音'
    assert tester._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert tester._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert tester._TESTS[0]['info_dict']['id'] == '300040'
    assert tester._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:43:25.694805
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_class = UDNEmbedIE(None)
    assert udn_class._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_class._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:32.889456
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    def test_UDNEmbedIE():
        # test if a wrong URL will not raise error
        udn = UDNEmbedIE()
        udn._match_id('http://video.udn.com/')
        udn._match_id('http://video.udn.com/embed/news/')
        udn._match_id('//video.udn.com/embed/news/')

    # test if constructor will raise error by a bad URL
    try:
        test_UDNEmbedIE()
    except ValueError:
        pass

# Generated at 2022-06-24 13:43:34.885385
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)


# Generated at 2022-06-24 13:43:37.349687
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    IE._match_id('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:43:40.714062
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # print ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:46.682516
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test _VALID_URL
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    ie._download_webpage = lambda url, video_id, note: 'page'
    ie._parse_json = lambda page, video_id, fatal: 'options'
    ie._html_search_regex = lambda regex, page, name, default: 'options'
    ie._extract_m3u8_formats = lambda m3u8_url, video_id, ext, m3u8_id: 'hls'
    ie._extract_f4m_formats = lambda f4m_url, video_id, f4m_id: 'hds'
    ie._sort_formats = lambda formats: 'formats'
    ie

# Generated at 2022-06-24 13:43:48.684522
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE({})
    # test whether the instance of class InfoExtractor is created.
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:43:56.077877
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import fake_HTTPretty_http_response
    from ..downloader.http import FakeHttpyResponse
    from ..compat import BytesIO

    url = "https://video.udn.com/embed/news/300040"
    mp4_src = 'http://mp4.udn.com.edgesuite.net/upf/newmedia/2017_1/170330_TAIGEI_3_1000/170330_TAIGEI_3_1000.mp4'
    m3u8_src = 'http://newmedia.udn.com.edgesuite.net/upf/newmedia/2017_1/170330_TAIGEI_3_1000/m3u8/170330_TAIGEI_3_1000.m3u8'

# Generated at 2022-06-24 13:43:58.693756
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = UDNEmbedIE._VALID_URL
    assert url == UDNEmbedIE(url)._VALID_URL

# Generated at 2022-06-24 13:44:07.528987
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == ie._PROTOCOL_RELATIVE_VALID_URL.replace('//', 'https://')

# Generated at 2022-06-24 13:44:16.107501
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    obj._VALID_URL = r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL
    url = 'https://video.udn.com/embed/news/300040'
    expected_id = '300040'
    obj._real_extract(url)
    assert obj.IE_NAME == 'udn'
    assert obj.IE_DESC == '聯合影音'
    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:18.044387
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ied = UDNEmbedIE()
    url = 'http://udn.com/video/embed/news/100045'
    ret = ied._real_extract(url)

# Generated at 2022-06-24 13:44:26.057949
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbed = UDNEmbedIE()
    assert udnEmbed.IE_NAME == 'udn'
    assert udnEmbed.IE_DESC == '聯合影音'
    assert udnEmbed._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbed._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:28.193293
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    assert inst._match_id(inst._PROTOCOL_RELATIVE_VALID_URL) == '300040'

# Generated at 2022-06-24 13:44:31.852415
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == udn_embed_ie.VALID_URL
    assert udn_embed_ie.IE_DESC == udn_embed_ie.ie_key()

# Generated at 2022-06-24 13:44:34.949654
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._VALID_URL == r'https?:' + udn_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:44:38.516163
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert ('video.udn.com', '300040') == UDNEmbedIE._extract_video_id({
        'url': 'http://video.udn.com/embed/news/300040'
    })

# Generated at 2022-06-24 13:44:44.788882
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    # Test that instantiation works in case of a valid URL
    UDNEmbedIE(url)
    # Test that instantiation raises an exception in case of an invalid URL
    invalid_url = 'http://video.udn.com/embed/news/30'
    try:
        UDNEmbedIE(invalid_url)
        assert False, 'Expected exception was not thrown'
    except :
        pass

# Generated at 2022-06-24 13:44:54.577432
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040', 'id', 'title')
    assert ie._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:57.057808
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie._VALID_URL == 'https?:' + udn_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:45:02.528618
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test _PROTOCOL_RELATIVE_VALID_URL and _VALID_URL
    t_udn_embed_ie = UDNEmbedIE()
    assert t_udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert t_udn_embed_ie._VALID_URL == r'https?:' + t_udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:45:04.345260
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbed', 'http://api1.video.udn.com/video/video_play.jsp?id=300040')

# Generated at 2022-06-24 13:45:08.025207
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:10.073534
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result = UDNEmbedIE()
    assert result._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:45:19.861876
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _VALID_URL = 'https://video.udn.com/embed/news/300040'
    _VIDEO_ID = '300040'

    def do_test(self, url, video_id, expected_type):
        if expected_type is None:
            with self.assertRaises(RegexNotFoundError):
                self._real_extract(url)
        else:
            info = self._real_extract(url)
            self.assertEqual(info['id'], video_id)
            self.assertEqual(type(info), expected_type)

    Instance = UDNEmbedIE()
    do_test(Instance, _VALID_URL, _VIDEO_ID, UDNEmbedIE)


# Generated at 2022-06-24 13:45:22.971534
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for k,v in vars(UDNEmbedIE).items():
        if k.startswith('_') and not k.startswith('__'):
            print(k, ':', v)
        else:
            print(k)

# Check the regular expression of class fields

# Generated at 2022-06-24 13:45:24.441878
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:45:34.487914
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:45:36.820105
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:45.087360
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.IE_DESC = 'Test'
    ie._VALID_URL = r'https?://(?:www\.)?example\.com/.+'
    ie._TESTS = [{
        'url': 'fake url',
        'only_matching': True,
    }]
    assert (ie._VALID_URL == r'https?://(?:www\.)?example\.com/.+')
    assert (ie.IE_DESC == 'Test')

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:45:46.303025
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    valid_url = UDNEmbedIE._VALID_URL
    assert re.compile(valid_url).match(url)

# Generated at 2022-06-24 13:45:48.276966
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    # To run the unit test, define the constants below
    # obj.download(url)

# Generated at 2022-06-24 13:45:57.486014
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    URL = "https://video.udn.com/embed/news/300040"
    UDNEmbedIE = UDNEmbedIE()
    UDNEmbedIE._download_webpage = lambda url: ("<script>var options = {'video':{'mp4':'http://www.test.com/test.mp4', 'm3u8':'http://www.test.com/test.m3u8'}}</script>")
    UDNEmbedIE._download_webpage = lambda url: ("<script>var options = {'title':'title_test'}</script>")

# Generated at 2022-06-24 13:46:05.365419
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_instance = UDNEmbedIE()
    assert test_instance.IE_NAME == "udn"
    assert test_instance._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_instance._TESTS != []

# Generated at 2022-06-24 13:46:14.166855
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    sample_url1 = 'http://video.udn.com/embed/news/300040'
    ie1 = UDNEmbedIE(sample_url1)
    assert ie1.IE_NAME == 'udn'
    assert ie1.IE_DESC == '聯合影音'
    assert ie1._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie1._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:17.529927
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor_test(UDNEmbedIE, [], [{
        'url': 'http://video.udn.com/embed/news/300040',
        'only_matching': True,
    }])


# Generated at 2022-06-24 13:46:19.102193
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:46:19.990551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:24.288331
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the availability of method _real_extract()
    ie = UDNEmbedIE()
    assert(ie._real_extract)

# Generated at 2022-06-24 13:46:29.687290
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:41.229585
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import load_json

    # Test constructor of class UDNEmbedIE
    # Success: no exception
    UDNEmbedIE()

    # Test function _real_extract() of class UDNEmbedIE
    # Success: no exception
    __test_UDNEmbedIE_real_extract('http://video.udn.com/embed/news/300040')

    # Test function _real_extract() of class UDNEmbedIE
    # Success: no exception
    __test_UDNEmbedIE_real_extract('https://video.udn.com/embed/news/300040')

    # Test function _real_extract() of class UDNEmbedIE
    # Success: no exception

# Generated at 2022-06-24 13:46:44.263071
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE([])
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:52.486406
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:57.897207
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # Assert URL of _VALID_URL is correct
    valid_url = udn_embed_ie._VALID_URL
    expected_url = r'https?:(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'
    assert valid_url == expected_url


# Generated at 2022-06-24 13:47:00.653015
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('udn', {'youtube': 'https://www.youtube.com/watch?v=EOwGnHgD-_E'})

# Generated at 2022-06-24 13:47:01.924306
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None, None)



# Generated at 2022-06-24 13:47:08.240354
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert len(udn_embed_ie._TESTS) == 3
    # Unit test for method _real_extract in UDNEmbedIE
    test_tuple = udn_embed_ie._TESTS[1]
    url = test_tuple.get("url")
   

# Generated at 2022-06-24 13:47:12.934703
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	from ..utils import (
	    determine_ext,
	    int_or_none,
	    js_to_json,
	)
	from ..compat import compat_urlparse
	video_id = 300040
	url = 'https://video.udn.com/embed/news/' + video_id
	page = 'wget -O - ' + url

# Generated at 2022-06-24 13:47:17.206448
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    result = ie.extract('https://video.udn.com/embed/news/300040')
    assert result['id'] == '300040'
    assert result['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-24 13:47:27.124972
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:47:27.978227
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:47:31.296198
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor test
    """
    _ = UDNEmbedIE('foo', {})
    # Constructor without protocol
    UDNEmbedIE('foo', {})

# Generated at 2022-06-24 13:47:36.758090
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-24 13:47:43.916947
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Match, extract and check for protocol relative url
    url = '//video.udn.com/embed/news/300040'
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    ie = UDNEmbedIE(url)
    ie._match_id(url) == '300040'

    # Not match for https url
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    ie._match_id(url) is None

# Generated at 2022-06-24 13:47:53.613754
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:48:04.828546
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'

    page = 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:48:13.305538
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()

    assert(udn_embed_ie.IE_DESC == '聯合影音')
    assert(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udn_embed_ie._VALID_URL == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:48:26.327982
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:27.755805
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:48:34.857121
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from . import t
    from .mock import MockIE
    from inspect import isclass

    ie = t.get_extractor(UDNEmbedIE.ie_key())
    assert isclass(ie)
    assert issubclass(ie, MockIE)
    assert UDNEmbedIE == ie
    assert ie != MockIE
    assert ie.ie_key() == UDNEmbedIE.ie_key()

    tester = t.get_tester()
    tester.test('https://video.udn.com/embed/news/300040',
                ie)

    tester.test('https://video.udn.com/play/news/300040',
                ie)

# Generated at 2022-06-24 13:48:37.320815
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')


# Generated at 2022-06-24 13:48:40.538331
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE()
    match = obj._match_id(url)
    assert match == '300040'

# Generated at 2022-06-24 13:48:42.268607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # init a UDNEmbedIE instance
    UDNEmbedIE()


# Generated at 2022-06-24 13:48:47.735921
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    print('------------------------------------------------------------------------------------------------------------------')
    print( 'extract_info_dict: {}'.format(udn_embed_ie.extract(url) ) )
    print('------------------------------------------------------------------------------------------------------------------')

# Generated at 2022-06-24 13:48:55.390544
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    regex_url = r'https?://video\.udn\.com/embed/news/300040'
    assert re.search(regex_url, ie.construct_download_url('http://video.udn.com/embed/news/300040')) is not None
    assert ie.construct_download_url('http://video.udn.com/embed/news/300040') == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:49:06.124953
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:49:07.606569
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test URL in _VALID_URL
    UDNEmbedIE('UDNEmbed', False)


# Generated at 2022-06-24 13:49:08.987439
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(UDNEmbedIE.create_ie_instance())
    assert ie
    assert ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:49:10.228715
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except Exception:
        assert False

# Generated at 2022-06-24 13:49:14.032872
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None).extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:49:21.217445
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..compat import unittest
    import sys

    class TestUDNEmbedIE(unittest.TestCase):
        def test_url_protocol_relative(self):
            url = '//video.udn.com/embed/news/300040'
            ie = UDNEmbedIE()
            self.assertEqual(
                'http:' + url,
                ie._match_id(url, '%s://%s' % (sys.platform, url))
            )
        def test_url_http(self):
            url = 'http://video.udn.com/embed/news/300040'
            ie = UDNEmbedIE()

# Generated at 2022-06-24 13:49:28.503421
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:49:38.956656
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None
    assert ie.name == "UDNEmbedIE"
    assert ie.IE_DESC == "聯合影音"
    assert ie._VALID_URL == r"https?://video\.udn\.com/(?:embed|play)/news/(\d+)"