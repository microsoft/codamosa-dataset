

# Generated at 2022-06-24 13:39:38.206922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'



# Generated at 2022-06-24 13:39:45.502293
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:39:48.267092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Unit test for constructor of class UDNEmbedIE
    '''
    UDNEmbedIE()


# Generated at 2022-06-24 13:39:49.393342
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:39:51.009242
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Tested by youtube_dl/extractor/udn.py
    pass

# Generated at 2022-06-24 13:39:53.954074
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u._PROTOCOL_RELATIVE_VALID_URL
    assert u._VALID_URL
    assert u._TESTS

# Generated at 2022-06-24 13:39:55.137053
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:39:56.721766
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert len(UDNEmbedIE._TESTS) >= 1

# Generated at 2022-06-24 13:40:07.354048
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    my = UDNEmbedIE()
    assert my.IE_NAME == 'udn'
    assert my.IE_DESC == '聯合影音'
    assert my._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert my._VALID_URL == r'https?:' + my._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:40:09.683973
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:40:16.885867
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test for class UDNEmbedIE."""
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:40:22.642105
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print("test UDNEmbedIE")
    print("protocol relative url %s" % ie.suitable("//video.udn.com/embed/news/200040"))
    print("absolute url %s" % ie.suitable("https://video.udn.com/embed/news/200040"))
    print("not a video %s" % ie.suitable("https://video.udn.com/news/200040"))

# Generated at 2022-06-24 13:40:29.321369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert 'UDNEmbedIE' == obj.IE_NAME
    assert '聯合影音' == obj.IE_DESC
    assert 'http://video.udn.com/embed/news/300040' == obj.IE_URL
    assert 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)' == obj._PROTOCOL_RELATIVE_VALID_URL
    assert 'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL == obj._VALID_URL
    obj2 = UDNEmbedIE(url='http://video.udn.com/embed/news/300040')
    assert 'http://video.udn.com/embed/news/300040' == obj2

# Generated at 2022-06-24 13:40:39.453057
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, 'http://video.udn.com/embed/news/300040') == {
    'extractors': [],
    'id': '300040',
    'ext': 'mp4',
    'title': '生物老師男變女 全校挺"做自己"',
    'thumbnail': r're:^https?://.*\.jpg$'}

# Generated at 2022-06-24 13:40:48.044737
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie.ie_key() == 'UDNEmbed'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:52.412833
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # 1. no need to write again for the following code
    '''
    udn = UDNEmbedIE()
    udn_url = 'http://video.udn.com/embed/news/300040'
    udn_id = '300040'
    assert udn.match_url(udn_url) == udn_id
    assert udn_id == udn.match_id(udn_url)
    
    udn_url = 'https://video.udn.com/embed/news/300040'
    assert udn.match_url(udn_url) == udn_id
    assert udn_id == udn.match_id(udn_url)
    '''
    # 2. need to write again for the following code

# Generated at 2022-06-24 13:40:54.824932
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        # non-existing url
        UDNEmbedIE('http://video.udn.com/embed/news/300040')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 13:40:57.500348
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    e = UDNEmbedIE()
    assert e.IE_NAME == 'udn'
    assert e.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:41:00.928423
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor of class UDNEmbedIE
    ie = UDNEmbedIE()
    # Extract infomation of Youtube video
    ie.extract('https://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:41:02.872506
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE._downloader, UDNEmbedIE._VALID_URL)

# Generated at 2022-06-24 13:41:03.928999
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj


# Generated at 2022-06-24 13:41:10.323446
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test if class UDNEmbedIE is created.
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(ie._TESTS) == 3

    # Test if js_to_json works.

# Generated at 2022-06-24 13:41:19.664053
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    urls = [
        'http://video.udn.com/embed/news/300040',
        'http://video.udn.com/news/300040',
        'https://video.udn.com/embed/news/300040',
        'https://video.udn.com/news/300040',
    ]
    for url in urls:
        assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.replace('video.udn.com/', r'video\.(?:udn\.com|mtv\.com\.tw)/'), url
        assert UDNEmbedIE._VALID_URL.replace('video.udn.com/', r'video\.(?:udn\.com|mtv\.com\.tw)/'), url


# Generated at 2022-06-24 13:41:23.907979
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert (udn_embed_ie.IE_NAME == 'udn_embed')
    assert (udn_embed_ie.IE_DESC == '聯合影音')

# Generated at 2022-06-24 13:41:33.300422
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:41:35.532842
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'udn'
    assert UDNEmbedIE.ie_key() in IE_KEY_MAP_DICT

# Generated at 2022-06-24 13:41:44.804599
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE_DESC = '聯合影音'
    udn_embed_instance_1 = UDNEmbedIE()
    assert udn_embed_instance_1.IE_NAME == 'udn.com:embed'
    assert udn_embed_instance_1.IE_DESC == IE_DESC
    assert udn_embed_instance_1._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:45.961498
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor
    UDNEmbedIE('www')


# Generated at 2022-06-24 13:41:57.880438
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Get info from url
    url = 'https://video.udn.com/embed/news/300040'
    a = UDNEmbedIE()
    info_dict = a._real_extract(url)
    assert info_dict
    assert info_dict['id'] == '300040'
    assert info_dict['title'] == '生物老師男變女 全校挺"做自己"'
    assert info_dict['ext'] == 'mp4'
    assert info_dict['thumbnail'] == 're:^https?://.*\.jpg$'

    formats = info_dict['formats']
    assert formats
    assert len(formats) == 3
    assert formats[0]['format_id'] == 'http-m3u8'
   

# Generated at 2022-06-24 13:42:03.817222
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert repr(ie).split(' ')[0] == 'UDNEmbedIE'
    assert repr(ie).split(' ')[1] == ie.IE_NAME
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:42:10.035054
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:11.161460
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()

# Generated at 2022-06-24 13:42:13.567545
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    return UDNEmbedIE()._real_extract("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:42:14.636530
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None, None)

# Generated at 2022-06-24 13:42:21.726854
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Try to construct an instance of class UDNEmbedIE.
    """
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:32.143675
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    url1 = 'http://video.udn.com/embed/news/300040'
    url2 = 'https://video.udn.com/play/news/303776'

    ie1 = UDNEmbedIE()
    ie2 = UDNEmbedIE()

    assert ie1._match_id(url1) == '300040'
    assert ie2._match_id(url2) == '303776'
    assert ie1._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie2._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:42.389662
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert isinstance(udn, InfoExtractor)
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == r'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL
    assert udn.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:42:43.984433
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except Exception as e:
        assert False, e

if __name__ == '__main__':
    # Unit test for constructor of class UDNEmbedIE
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:42:45.542451
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:42:46.588482
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie._real_initialize()
    ie.ie_key

# Generated at 2022-06-24 13:42:48.967920
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import expected_warnings
    with expected_warnings(['Failed to parse JSON Expecting value']):
        IE = UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:42:51.329767
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	from pprint import pprint as pp
	ie = UDNEmbedIE()
	pp(ie)

if __name__ == '__main__':
	test_UDNEmbedIE()

# Generated at 2022-06-24 13:43:00.562905
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Test case for constructor of class UDNEmbedIE
    '''

    # Test case 1
    url = 'http://video.udn.com/embed/news/300040'

    UDNEmbedIE(UDNEmbedIE.ie_key())._real_initialize(url)
    # expected output: {}

    # Test case 2
    url = 'https://video.udn.com/embed/news/300040'

    UDNEmbedIE(UDNEmbedIE.ie_key())._real_initialize(url)
    # expected output: {}

    # Test case 3
    url = 'https://video.udn.com/play/news/303776'

    UDNEmbedIE(UDNEmbedIE.ie_key())._real_initialize(url)
   

# Generated at 2022-06-24 13:43:03.768110
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test normal case
    UDNEmbedIE(UDNEmbedIE.ie_key())._real_extract(
        'http://video.udn.com/embed/news/300040')
    # Test error case of invalid json
    UDNEmbedIE(UDNEmbedIE.ie_key())._real_extract(
        'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:43:07.730168
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # URL for udn video without "embed"
    url = ie._match_id(r'//video\.udn\.com/play/news/300040')
    assert url == '300040'
    # URL for udn video with "embed"
    url = ie._match_id(r'//video\.udn\.com/embed/news/300040')
    assert url == '300040'

# Generated at 2022-06-24 13:43:16.123448
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert re.match(ie._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert re.match(ie._VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert not re.match(ie._VALID_URL, 'http://video.udn.com/play/news/300040')
    assert not re.match(ie._VALID_URL, 'https://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:43:21.006322
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('example', {'hello': 'world'})

if __name__ == '__main__':
	test_UDNEmbedIE()

# Generated at 2022-06-24 13:43:29.898005
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:33.555920
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._VALID_URL
    assert ie._TESTS
    assert ie.IE_DESC


# Generated at 2022-06-24 13:43:42.545982
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # Initialize a new object
    obj = UDNEmbedIE()

    # Check if properties were initialized correctly

    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj.IE_DESC == '聯合影音'

    # Check if methods are executed correctly

    # If a URL (string) is given as an argument to match(), a match object is returned if the URL matches the pattern. Otherwise, None is returned.
    assert obj._match_id('http://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:43:44.537913
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print (UDNEmbedIE._TESTS[0]['url'])

# Generated at 2022-06-24 13:43:46.197947
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Make sure that constructor of class UDNEmbedIE works well
    return UDNEmbedIE()

# Generated at 2022-06-24 13:43:52.311010
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_names = [
        'UDNEmbedIE',
    ]
    global_page = 'https://embed.udn.com/udnplayer/js/embed.min.js'
    for class_name in class_names:
        ie = eval(class_name)
        instance = ie()
        js = instance._download_webpage(global_page, None)
        assert instance._search_regex(
            r'var\s+options\s*=\s*\{', js, 'options')


# Generated at 2022-06-24 13:43:55.274601
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:57.031300
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    s = UDNEmbedIE()
    print(s.IE_DESC)

# Generated at 2022-06-24 13:44:01.654802
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    youTube_pattern = re.compile(r'^(https?:)?//www\.youtube\.com/')
    assert youTube_pattern.match(
        '//www.youtube.com/watch?v=HU6ljU4-Z4I') is not None

# Generated at 2022-06-24 13:44:07.881846
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # No error will be raised if the regex doesn't match
    browser = UDNEmbedIE('udn', 'http://example.com')
    assert browser._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert browser._VALID_URL == r'https?:' + browser._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-24 13:44:13.223992
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for _PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.startswith('//')

    # Test for _VALID_URL
    assert UDNEmbedIE._VALID_URL.startswith('https?')
    assert UDNEmbedIE._VALID_URL.find(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL[2:]) >= 0

# Generated at 2022-06-24 13:44:21.303113
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()

    # Test protocol relative
    assert udn_ie._is_valid_url(
        udn_ie._PROTOCOL_RELATIVE_VALID_URL,
        {'id': '123'}
    )
    assert udn_ie._is_valid_url_old_api(
        udn_ie._PROTOCOL_RELATIVE_VALID_URL,
        {'id': '123'}
    )

    # Test normal
    assert udn_ie._is_valid_url(
        udn_ie._VALID_URL,
        {'id': '123'}
    )

# Generated at 2022-06-24 13:44:27.041720
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO: more robust test?
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    if ie.url_result:
        assert ie.url_result.url == 'https://www.youtube.com/embed/RX9DDE7v8Yg'
    else:
        assert ie.video_id == '300040'

# Generated at 2022-06-24 13:44:28.378226
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert str(UDNEmbedIE) == "UDNEmbedIE"

# Generated at 2022-06-24 13:44:30.337044
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE([]).extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:44:36.864934
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-24 13:44:42.182983
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for class UDNEmbedIE
    udneie = UDNEmbedIE()
    assert udneie.IE_DESC == '聯合影音'
    assert udneie._PROTOCOL_RELATIVE_VALID_URL
    assert udneie._VALID_URL
    assert udneie._TESTS

# Generated at 2022-06-24 13:44:52.279813
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #  print "in test_UDNEmbedIE()"
    VERBOSE = False

    # Example of 'Embed' page of UDN.com
    #  url= 'http://video.udn.com/embed/news/300040'
    url='https://video.udn.com/embed/news/300040'
    print("Testing UDNEmbedIE() constructor with url = '{}'".format(url))
    udnEmbedIE = UDNEmbedIE()
    if VERBOSE:
        print("\nudnEmbedIE = '{}'".format(udnEmbedIE))
        print("\ndir(udnEmbedIE) = {}".format(dir(udnEmbedIE)))
    #  print("\nudnEmbedIE.__dict__ = {}".format(

# Generated at 2022-06-24 13:44:58.358130
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    video_id = ie._match_id(url)
    result = ie._real_extract(url)
    assert result == {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }

# Generated at 2022-06-24 13:45:02.316926
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-24 13:45:04.661966
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Basic test for constructor of class UDNEmbedIE"""
    ud = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    ud.extract(url)

# Generated at 2022-06-24 13:45:10.572170
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .utils import TestIE
    assert_raises(AssertionError, TestIE, 'UDNEmbedIE')
    # UDNEmbedIE is a subclass of InfoExtractor.
    # Therefore, class variables are shared among its subclasses,
    # and it is impossible to test each class individually.
    assert_raises(AssertionError, TestIE, 'UDNEmbedIE', module='udn')

# Generated at 2022-06-24 13:45:15.776338
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME in [ie.IE_NAME for ie in InfoExtractor.get_ies()]
    assert not any(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == ie._VALID_URL 
                   for ie in InfoExtractor.get_ies())
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL in UDNEmbedIE._VALID_URL


# Generated at 2022-06-24 13:45:21.505599
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Base class of IE, InfoExtractor
    from ..utils import InfoExtractor
    from .common import InfoExtractor
    from .generic import GenericIE
    from .youtube import YoutubeIE
    i = UDNEmbedIE()
    assert(isinstance(i,InfoExtractor))
    assert(isinstance(i,GenericIE))

# Generated at 2022-06-24 13:45:27.348898
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test case for constructor of class UDNEmbedIE"""
    # Constructor of class UDNEmbedIE
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == "UDN (UDNEmbed)"
    assert udn_embed_ie.IE_DESC == "聯合影音"


# Generated at 2022-06-24 13:45:37.306053
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:47.892935
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .youtube import YoutubeIE
    from .generic import GenericIE
    from .naver import NaverIE
    from .brightcove import BrightcoveIE
    udne_ie_0001 = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    udne_ie_0002 = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    udne_ie_0003 = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert isinstance(udne_ie_0001, InfoExtractor)
    assert isinstance(udne_ie_0002, InfoExtractor)
    assert isinstance(udne_ie_0003, InfoExtractor)

# Generated at 2022-06-24 13:45:52.285022
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-24 13:45:58.982197
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test cases of the constructor
    url='http://video.udn.com/embed/news/300040'
    test_UDNIE=UDNEmbedIE()
    # test for _VALID_URL
    valid_url=re.match(test_UDNIE._VALID_URL,url)
    print(valid_url.group('id'))
    # test for _PROTOCOL_RELATIVE_VALID_URL
    valid_url=re.match(test_UDNIE._PROTOCOL_RELATIVE_VALID_URL,url)
    print(valid_url.group('id'))


# Generated at 2022-06-24 13:46:03.259780
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert not UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL.startswith('http')
    assert UDNEmbedIE()._VALID_URL.startswith('http')

# Generated at 2022-06-24 13:46:04.635338
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()

# Generated at 2022-06-24 13:46:13.763805
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_1 = 'http://video.udn.com/embed/news/300040'
    url_2 = 'https://video.udn.com/embed/news/300040'

    # Validate for http scheme
    ie_1 = UDNEmbedIE(url_1)
    assert isinstance(ie_1._VALID_URL, str)
    assert url_1.startswith('http://')
    assert ie_1._VALID_URL == 'http:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

    # Validate for https scheme
    ie_2 = UDNEmbedIE(url_2)
    assert isinstance(ie_2._VALID_URL, str)
    assert url_2.startswith('https://')
    assert ie_2._VALID_

# Generated at 2022-06-24 13:46:15.709319
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:46:16.595052
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r = UDNEmbedIE()


# Generated at 2022-06-24 13:46:21.288755
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME == 'udn'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    UDNEmbedIE._TESTS += [
        {
            'url': '//video.udn.com/embed/news/300040',
            'only_matching': True,
        },
    ]

# Generated at 2022-06-24 13:46:31.040898
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..jsinterp import exec_js

    # test the regex
    page = """
    var options = {
        id: '260000',
        title: '北大聲訴案 獨家視頻曝光警方遮蔽事實',
        poster: 'http://static.udn.com.tw/video/2015/01/aluminium.jpg',
        video: {
            mp4: 'http://video.udn.com/video/mp4/201501/vdo_aluminium_r.mp4',
            hls: 'http://video.udn.com/video/mp4/201501/vdo_aluminium_r.m3u8'
        }
    }
    """


# Generated at 2022-06-24 13:46:41.007148
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-24 13:46:49.746092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()

    assert obj.IE_NAME == 'udn'
    assert obj.IE_DESC == '聯合影音'
    assert obj._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-24 13:46:54.351953
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)' == test._PROTOCOL_RELATIVE_VALID_URL
    assert r'https?:' + test._PROTOCOL_RELATIVE_VALID_URL == test._VALID_URL
    assert test._TESTS
    assert test.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:46:57.704438
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[1]['only_matching'] == True
    assert ie._TESTS[0]['params'] == {'skip_download': True}

# Generated at 2022-06-24 13:47:03.671834
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-24 13:47:13.360405
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:47:15.724372
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:47:17.830407
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor

    UDNEmbedIE().download('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:47:27.861795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert info_extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert info_extractor._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert info_extractor._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert info_extractor._TESTS[0]['info_dict']['id'] == '300040'
    assert info_extractor._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert info

# Generated at 2022-06-24 13:47:31.639730
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE.UDNEmbedIE()
    ie.url = "http://video.udn.com/embed/news/300040"
    ie.video_id = "300040"

# Generated at 2022-06-24 13:47:37.450129
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE('UDNEmbedIE')
    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:41.658593
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Simple unit test for class UDNEmbedIE constructor.
    """
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(UDNEmbedIE.create_ie()).suitable(url) # Shouldn't raise an exception
    #assert False


# Generated at 2022-06-24 13:47:51.695608
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    page = open ("./test/test_UDNEmbedIE_page.html", 'r').read()
    assert page != ''
    udnTest = UDNEmbedIE()
    options_str = udnTest._html_search_regex(r'var\s+options\s*=\s*([^;]+);', page, 'options')
    trans_options_str = udnTest._download_webpage('http://www.udn.com/static/libs/js/cookies.js', '123')
    assert trans_options_str != ''
    trans_options_str = udnTest._download_webpage('https://www.udn.com/static/libs/js/cookies.js', '123')
    assert trans_options_str != ''
    options = udnTest._parse_json

# Generated at 2022-06-24 13:47:58.040726
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._match_id(
        'http://video.udn.com/embed/news/300040') == '300040'
    assert obj._match_id(
        'https://video.udn.com/embed/news/300040') == '300040'
    assert obj._match_id(
        '//video.udn.com/embed/news/300040') == '300040'
    assert obj._match_id(
        'https://video.tw.news.yahoo.com/uniq/298d3b8cb1cff9e9d694cfc3a430a824') == None

# Generated at 2022-06-24 13:48:00.430205
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._TESTS[0]['info_dict']
#test_UDNEmbedIE()

# Generated at 2022-06-24 13:48:10.748946
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for unsupport URLs.
    #
    # Don't do the real download.
    def dummy_download_webpage(*args, **kwargs):
        return ''

    # Don't print messages while fetching data
    class NullLogger(object):
        def debug(self, *args):
            pass

    import unittest
    import sys

    class UDNEmbedIETestCase(unittest.TestCase):
        def setUp(self):
            self._old_download_webpage = UDNEmbedIE._download_webpage
            self._old_logger = UDNEmbedIE._logger
            UDNEmbedIE._download_webpage = dummy_download_webpage
            UDNEmbedIE._logger = NullLogger()

        def tearDown(self):
            UDNEmbedIE._

# Generated at 2022-06-24 13:48:21.932621
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    url = 'http://video.udn.com/embed/news/' + video_id

    udn_embed = UDNEmbedIE()

    # Test _valid_url
    assert udn_embed._valid_url(url, video_id)

    # Test _real_extract
    info = udn_embed._real_extract(url)
    assert info
    assert info['id'] == video_id
    assert info['title']
    assert info['thumbnail']
    formats = info['formats']
    assert formats[0]
    assert formats[0]['url']
    for video_type, api_url in info['formats'][0].items():
        assert api_url

# Generated at 2022-06-24 13:48:23.762459
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:48:28.880683
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit = UDNEmbedIE()
    assert unit._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert unit._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:35.103283
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructing a UDNEmbedIE instance and check that it downloads the video correctly
    """
    # 1. Check if the UDNEmbedIE can be constructed.
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE(url)
    # 2. Try extracting the URL, and check that its the expected one.
    video_url = udn_embed_ie.extract_video_url()
    assert(video_url.startswith("http://vid.udn.com.edgesuite.net"))

# Generated at 2022-06-24 13:48:41.774881
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_ie = UDNEmbedIE()
    assert udne_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne_ie.IE_DESC == '聯合影音'
    assert udne_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:48.718868
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn_embed_ie._TESTS[0]['info_dict']['id'] == '300040'
    assert u

# Generated at 2022-06-24 13:48:59.802337
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .compat import compat_urlparse
    from .udn import UDNEmbedIE
    from .youtube import YoutubeIE
    from ..utils import (
        determine_ext,
        int_or_none,
        js_to_json,
    )
    from ..compat import compat_urllib_parse

    # test youtube video
    youtube_url = 'http://video.udn.com/embed/news/300040'
    ie = InfoExtractor.for_url(youtube_url)
    assert isinstance(ie, UDNEmbedIE)
    # TODO use mock, youtube already set skip_download = True

# Generated at 2022-06-24 13:49:04.468491
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udnembed = UDNEmbedIE()
    assert(udnembed.suitable(url))
    assert(udnembed._match_id(url) == '300040')
    assert(udnembed.IE_DESC == '聯合影音')

# Generated at 2022-06-24 13:49:07.245614
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()
	#print ie.IE_DESC
	#print ie.__class__.__name__

test_UDNEmbedIE()

# Generated at 2022-06-24 13:49:08.884920
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:49:09.448152
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    UDNEmbedIE()

# Generated at 2022-06-24 13:49:11.075890
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDNEmbed'
    assert udn_embed_ie.ie_desc() == '聯合影音'

# Generated at 2022-06-24 13:49:20.358659
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_ie = UDNEmbedIE()
    assert test_ie.IE_DESC == '聯合影音'
    assert test_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_ie._VALID_URL == r'https?:' + test_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:49:30.427888
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:49:32.403053
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

# Generated at 2022-06-24 13:49:41.832967
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    # check whether the URL can be extracted
    assert ie.can_extract(url)
    # check whether the URL cannot be extracted
    assert not ie.can_extract('http://video.udn.com/12345')
    # check whether the URL can be extracted by regex
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == ie._PROTOCOL_RELATIVE_VALID_URL
    assert re.match(UDNEmbedIE._VALID_URL, url)
    assert not re.match(UDNEmbedIE._VALID_URL, 'http://video.udn.com/12345')