

# Generated at 2022-06-24 13:39:34.250110
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UdnEmbed'



# Generated at 2022-06-24 13:39:36.943411
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        assert 1 == 1
    except AssertionError as e:
        raise Exception(e.message + ": test constructing class UDNEmbedIE")



# Generated at 2022-06-24 13:39:44.597286
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert 'info_dict' in u._TESTS[0]
    assert 'params' in u._TESTS[0]
    assert 'expected_warnings' in u._TESTS[0]
    assert 'only_matching' in u._TESTS[2]
    # The object constructor of class InfoExtractor
    # returns an object of class YoutubeIE.
    assert repr(u) == repr(InfoExtractor())
    assert str(u) == str(InfoExtractor())
    assert u.IE_NAME == 'udn'
    assert u.IE_DESC == '聯合影音'
    assert u._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:39:49.117130
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    # See: https://github.com/rg3/youtube-dl/issues/7927
    UDNEmbedIE()._download_webpage(url, '300040')


# Generated at 2022-06-24 13:40:00.640992
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnvideo = UDNEmbedIE()
    assert udnvideo.IE_NAME == "UDNEmbed"
    assert udnvideo.IE_DESC == "聯合影音"
    assert udnvideo._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:09.427171
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnUrl = 'http://video.udn.com/embed/news/300040'
    test_UDNEmbedIE = UDNEmbedIE()
    
    # test the definition of IE_DESC, _VALID_URL, _TESTS
    print(test_UDNEmbedIE.IE_DESC)
    print(test_UDNEmbedIE._VALID_URL)
    print(test_UDNEmbedIE._TESTS)
    
    # test the function _match_id in the class InfoExtractor of parent class
    print(test_UDNEmbedIE._match_id(udnUrl))
    print(test_UDNEmbedIE._real_extract(udnUrl))

# Generated at 2022-06-24 13:40:10.062921
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-24 13:40:16.933949
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:23.958011
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for valid input,
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.VALID_URL == 'http://video.udn.com/embed/news/(?P<id>\\d+)'
    # test for invalid input,
    ie = UDNEmbedIE('http://video.udn.com/sdafsdfs/sdfsdfsdf')
    assert ie.VALID_URL == 'http://video.udn.com/embed/news/(?P<id>\\d+)'

test_UDNEmbedIE()

# Generated at 2022-06-24 13:40:34.393570
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = IE_TESTS['udn'](
        {
            'extractor': 'udn',
            'ie_key': 'UdnEmbed',
            'video_id': '300040',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        })
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:43.114351
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test a valid url
    assert UDNEmbedIE()._match_id(
        'http://video.udn.com/embed/news/300040') is not None
    # Test a valid protocol-relative url
    assert UDNEmbedIE()._match_id(
        '//video.udn.com/embed/news/300040') is not None
    # Test a invalid url
    assert UDNEmbedIE()._match_id(
        'http://video.udn.com/embed/news/') is None
    # Test a valid url (play)
    assert UDNEmbedIE()._match_id(
        'https://video.udn.com/play/news/303776') is not None

# Generated at 2022-06-24 13:40:49.009282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('UDNEmbedIE', 'https://video.udn.com/embed/news/300040')
    assert ie._match_id(ie._VALID_URL) == '300040'
    assert ie._match_id(ie._PROTOCOL_RELATIVE_VALID_URL) == '300040'

# Generated at 2022-06-24 13:40:51.634807
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_url = "https://video.udn.com/embed/news/300040"
    udn_embed_ie = UDNEmbedIE()
    assert isinstance(udn_embed_ie, InfoExtractor)


# Generated at 2022-06-24 13:40:59.184187
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor
    ie = UDNEmbedIE()
    # Properties
    (input_url, output_json) = ie._VALID_URL, {'id': '300040', 'ext': 'mp4', 'title': '生物老師男變女 全校挺"做自己"', 'thumbnail': r're:^https?://.*\.jpg$'}
    # Methods
    assert ie.suitable(input_url) == 'This video is only available in Taiwan.'
    info_dict = ie._real_extract(input_url)
    for key in output_json:
        assert info_dict[key] == output_json[key]
    return

# Generated at 2022-06-24 13:41:02.871552
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    video_id = ie._match_id(url)
    assert video_id == '300040'
    pass

# Generated at 2022-06-24 13:41:14.160842
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:41:18.388657
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:41:24.900389
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # valid URL
    assert ie._match_id(
        'http://video.udn.com/embed/news/300040'
    ) == '300040'
    # with path
    assert ie._match_id(
        'https://video.udn.com/play/news/303776'
    ) == '303776'
    # protocol relative URL
    assert ie._match_id(
        '//video.udn.com/embed/news/300040'
    ) == '300040'

# Generated at 2022-06-24 13:41:34.076585
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .udn import UDNEmbedIE


    Udneie = UDNEmbedIE(InfoExtractor())
    assert Udneie.IE_DESC == '聯合影音'
    assert Udneie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert Udneie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:37.998939
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_key()
    assert ie._VALID_URL == ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:41:39.269103
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)


# Generated at 2022-06-24 13:41:41.206801
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:41:44.132766
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extraction_test(UDNEmbedIE, [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/303776'
    ])

# For testing purpose

# Generated at 2022-06-24 13:41:46.709105
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE(UDNEmbedIE.suitable(test_url))


# Generated at 2022-06-24 13:41:53.023943
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:41:59.691559
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    temp_instance = UDNEmbedIE()
    assert temp_instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert temp_instance._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert temp_instance.IE_NAME == 'udn'

# Generated at 2022-06-24 13:42:05.290153
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    # Make assertTrue, assertEqual, assertIsInstance and etc. can be used
    # in this test case
    assert 'assert' in globals(), 'There is no "assert" keyword in this ' \
                                  'Python version'
    # Make 'assertRaisesRegexp' can be used in this test case.
    # Because there is no 'assertRaisesRegex' in Python 2.6
    assert 'assertRaisesRegexp' in globals(), 'There is no "assertRaisesRegexp" keyword in ' \
                                              'this Python version'
    assert 'assertRegexpMatches' in globals(), 'There is no "assertRegexpMatches" keyword in ' \
                                              'this Python version'
    assertRa

# Generated at 2022-06-24 13:42:06.579369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:42:07.326944
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

# Generated at 2022-06-24 13:42:09.728766
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    repr_of_UDNEmbed = repr(UDNEmbedIE)
    # just to pass flake8
    assert repr_of_UDNEmbed
    assert str(UDNEmbedIE)

# Generated at 2022-06-24 13:42:11.431913
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
  ie = UDNEmbedIE()
  assert ie is not None


# Generated at 2022-06-24 13:42:18.514076
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'



# Generated at 2022-06-24 13:42:25.282576
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'UDNEmbed'
    assert UDNEmbedIE.ie_key() == 'UDNEmbed'
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')
    assert('UDNEmbed' == UDNEmbedIE.ie_key() )
    assert('UDNEmbed' == UDNEmbedIE.ie_key() )
    assert(UDNEmbedIE.ie_key() != 'A')
    assert(UDNEmbedIE.ie_key() != 'A')
    assert('A' != UDNEmbedIE.ie_key() )
    assert('A' != UDNEmbedIE.ie_key() )
    assert(UDNEmbedIE.ie_key() == 'UDNEmbed')

# Generated at 2022-06-24 13:42:31.502956
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:42:34.844165
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
        print('Unit test for constructor of class UDNEmbedIE ... OK')
    except:
        print('Unit test for constructor of class UDNEmbedIE ... FAIL')


# Generated at 2022-06-24 13:42:44.788161
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    index = 0
    assert ie._TESTS[index]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[index]['info_dict']['id'] == '300040'
    assert ie._TESTS[index]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:42:45.938150
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().suitable(url)

# Generated at 2022-06-24 13:42:49.512550
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    fct = UDNEmbedIE()._real_extract
    def is_valid(dic):
        dic = dic.values()
        return (dic is not None\
            and "" in dic\
            and isinstance(dic, dict))
    assert is_valid(fct('https://video.udn.com/embed/news/300040'))

# Generated at 2022-06-24 13:42:51.771514
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if 'UDNEmbedIE' in globals():
        udn = UDNEmbedIE()
        print(udn.__class__.__name__)


# Generated at 2022-06-24 13:43:00.816531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """this test case tests the constructor of class UDNEmbedIE"""
    # assert that the super class is correctly initialized
    udn = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert udn is not None
    assert udn.IE_DESC == '聯合影音'
    assert udn._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:03.760605
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_NAME == 'UDN')
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-24 13:43:13.412343
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    temp_instance2 = UDNEmbedIE()
    # Test whether the url pattern is in PROPERTY_NAME
    assert temp_instance2._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test whether the url pattern is in VALID_URL
    assert temp_instance2._VALID_URL == r'https?:' + temp_instance2._PROTOCOL_RELATIVE_VALID_URL
    # Test whether the url pattern is in _TESTS
    assert temp_instance2._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:43:15.814208
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie._match_id(url) == '300040'

# Generated at 2022-06-24 13:43:23.609450
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:43:27.820183
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:30.070773
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_NAME == 'udn'
    assert udn_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:32.156942
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()
	assert(ie.IE_NAME in __name__)


# Generated at 2022-06-24 13:43:37.642034
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	# Constructor of class UDNEmbedIE
	# Args:
	#	url(string): The url.
	#	ie(string, optional): The ie to use.
	url = 'https://video.udn.com/embed/news/300040'
	udn_embed_ie = UDNEmbedIE(url)
	url2 = 'https://video.udn.com/play/news/303776'
	udn_embed_ie2 = UDNEmbedIE(url2)
	url3 = 'https://video.udn.com/play/news/300040'
	udn_embed_ie3 = UDNEmbedIE(url3)


# Generated at 2022-06-24 13:43:47.224349
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:'+UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:48.123191
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbedIE')

# Generated at 2022-06-24 13:43:51.937722
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_test = 'http://video.udn.com/embed/news/300040'
    id_test = '300040'
    UDNEmbedIE()._match_id(url_test)
    UDNEmbedIE()._match_id(url_test) == id_test

test_UDNEmbedIE()

# Generated at 2022-06-24 13:44:03.213639
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    url = "https://video.udn.com/embed/news/300040"
    webpage = udneie._download_webpage(url, "300040")
    options_str = udneie._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', webpage, 'options')
    trans_options_str = js_to_json(options_str)
    print("options_str =", options_str)
    print("trans_options_str =", trans_options_str)
    options = udneie._parse_json(trans_options_str, 'options', fatal=False)
    print("options = ", options)
    print("options['video'] = ", options['video'])
    video

# Generated at 2022-06-24 13:44:04.139033
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:44:12.634553
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import requests
    from .constants import _UPLOAD_TEST
    udne = UDNEmbedIE()
    # check valid url
    url = 'https://video.udn.com/embed/news/300040'
    assert udne._VALID_URL == udne._VALID_URL_TEMPLATE.format('')
    valid_url_match = udne._VALID_URL_TEMPLATE.format('(?P<id>[0-9]+)').format(id='300040')
    assert re.match(valid_url_match, url) is not None

    # check download_webpage
    response = udne._download_webpage(url, '300040')
    assert isinstance(response, requests.models.Response)
    json_content_match = re.comp

# Generated at 2022-06-24 13:44:16.994578
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie     = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    url    = 'https://video.udn.com/embed/news/300040'
    video_id = ie._match_id(url)
    assert video_id == r'300040'


# Generated at 2022-06-24 13:44:17.787299
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None, None)

# Generated at 2022-06-24 13:44:28.631371
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test constructor of class UDNEmbedIE
    """

    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:32.869305
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE()._real_initialize()
    assert UDNEmbedIE().suitable(url)
    assert (UDNEmbedIE()._real_extract(url)['formats'][0]['url'])

# Generated at 2022-06-24 13:44:35.201872
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-24 13:44:36.218438
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_constructor(UDNEmbedIE)

# Generated at 2022-06-24 13:44:38.565609
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test with a real url
    UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:44:44.826944
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.SITE_NAME == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-24 13:44:46.407841
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE([])._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:44:55.066052
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    # Unit test for constructor of class InfoExtractor
    assert udne.params == {}
    assert udne._downloader is None
    assert udne._WORKING_WINDOW is None
    assert udne._download_retry == 3
    assert udne._max_errors == 10
    assert udne._geo_verification_headers is None
    assert udne._sleep_interval is None
    assert udne._last_download_stats is None
    assert udne._progress_hooks == []
    assert udne._ies is None
    assert udne._pps is None
    assert udne._progress_ctx is None

# Generated at 2022-06-24 13:44:57.245593
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test case 1:
    # This is the way to test constructor
    instance = UDNEmbedIE()
    assert isinstance(instance, InfoExtractor) == True



# Generated at 2022-06-24 13:45:04.159480
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:45:10.361222
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    video_url = 'http://video.udn.com/embed/news/' + video_id
    video_title = '生物老師男變女 全校挺"做自己"'

    udn_embed_ie = UDNEmbedIE()
    udn_embed_ie._download_webpage = lambda url: '<video id="' + video_id + '" title="' + video_title + '" poster="' + url + '"></video>'
    udn_embed_ie._download_webpage = lambda url, video_id, note: url

    video = udn_embed_ie.extract(video_url)


# Generated at 2022-06-24 13:45:16.726060
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_common import YouTubeTestFunc
    from .test_embeds import TestEmbedBase
    from .test_youtube_dl import YoutubeDL

    class TestUDNEmbedIE(TestEmbedBase):
        IE_DESC = '聯合影音'
        _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
        _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL
        _TESTS = []


# Generated at 2022-06-24 13:45:22.001478
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    # Test URL without https://
    udn_embed_ie = UDNEmbedIE(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL + video_id, video_id)
    # Test video_id
    assert video_id == udn_embed_ie._match_id(udn_embed_ie.url)

# Generated at 2022-06-24 13:45:25.836266
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:26.923732
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:45:33.939901
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    IE = UDNEmbedIE()
    IE = UDNEmbedIE(url)
    assert IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:37.197511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.__init__(
        UDNEmbedIE(),
        UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
        'video.udn.com/embed/news/300040',
        '300040'
    )

# Generated at 2022-06-24 13:45:44.827147
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test of function UDNEmbedIE().

    Test whether UDNEmbedIE class is constructed successfully
    """
    udn_instrument = UDNEmbedIE()
    # Specify url and video id
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'
    # Extract info
    info = udn_instrument._real_extract(url)
    # If video id is retrieved, assert it is equal to specifying video id
    assert info['id'] == video_id

# Generated at 2022-06-24 13:45:54.306109
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    youtube_url = 'https://www.youtube.com/watch?v=WyH8_vS50IU'
    url = 'http://video.udn.com/embed/news/300040'
    options = {
        'video': {'youtube': youtube_url},
        'title': 'test',
        'poster': 'http://g.img.com.tw/10/99/2/pic1.jpg'
    }
    m = UDNEmbedIE()
    result = m._real_extract(url, options)
    assert result['id'] == '300040'
    assert result['formats'] == []
    assert result['title'] == 'test'
    assert result['thumbnail'] == 'http://g.img.com.tw/10/99/2/pic1.jpg'
    assert result

# Generated at 2022-06-24 13:45:59.438033
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_params = {}
    test_params['url'] = 'http://video.udn.com/embed/news/300040'
    test_params['info_dict'] = {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        }
    test = UDNEmbedIE(test_params)
    assert hasattr(test, 'url')
    assert hasattr(test, '_match_id')
    assert hasattr(test, '_real_extract')

# Generated at 2022-06-24 13:46:09.858765
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import NS_MAP

    TEST_SET = [
        '//video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
    ]

    for url in TEST_SET:
        ie = UDNEmbedIE()
        # result = ie.extract(url)
        result = ie.extract(url)

        assert result['id'] == '300040'
        assert result['title'] == '生物老師男變女 全校挺"做自己"'
        assert result['thumbnail'][0:30] == 'https://static.udn.com.tw/'

        assert 'mp4' in [x['ext'] for x in result['formats']]

# Generated at 2022-06-24 13:46:11.101125
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('udn.com', 'test_UDNEmbedIE')

# Generated at 2022-06-24 13:46:12.403292
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_ie = UDNEmbedIE()
    assert udne_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:46:14.720002
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    assert class_UDNEmbedIE._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-24 13:46:17.660618
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = "http://video.udn.com/embed/news/300040"
    assert ie._match_id(url) == "300040"



# Generated at 2022-06-24 13:46:21.687299
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneI = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert udneI.IE_DESC == '聯合影音'
    assert udneI._VALID_URL==r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:25.685158
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:46:33.923946
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    video = ie.extract(url)
    assert video['id'] == '300040'
    assert video['ext'] == 'mp4'
    assert video['title'] == '生物老師男變女 全校挺"做自己"'
    assert re.match(r'https?://.*\.jpg$', video['thumbnail'])
    options_str = ie._download_webpage(url, video_id=video['id'])
    options = ie._parse_json(options_str, 'options', fatal=False) or {}
    if options:
        video_urls = options['video']

# Generated at 2022-06-24 13:46:39.910808
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    t = UDNEmbedIE()
    t = UDNEmbedIE._VALID_URL
    t = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    t = UDNEmbedIE.IE_DESC
    t = UDNEmbedIE._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:46:41.992003
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # It should work even with a URL of a webpage
    UDNEmbedIE().suitable('https://video.udn.com/news/303776')

# Generated at 2022-06-24 13:46:47.461233
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE()
    assert udnIE.IE_DESC == '聯合影音'
    assert udnIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnIE._VALID_URL == r'https?:' + udnIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:48.293632
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # To be implemented if needed.
    assert(True)

# Generated at 2022-06-24 13:46:53.652562
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_udn import test_udn_test_download
    assert UDNEmbedIE.__name__ == 'UDNEmbedIE'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._VALID_URL == r'https?:(?i)//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:56.381757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._match_id(test_url)
    # test_url = 'https://video.udn.com/play/news/300040'
    # print(UDNEmbedIE()._match_id(test_url))


# Generated at 2022-06-24 13:47:01.701816
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    UDNEmbedIE._VALID_URL = r'https?://www.test.com.tw/test/(?P<id>\d+)/'

    url = 'https://www.test.com.tw/test/123456789/'
    video_id = '123456789'
    assert ie._match_id(url) == video_id

# Generated at 2022-06-24 13:47:07.497063
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'

    udn_embed_instance = UDNEmbedIE()
    assert udn_embed_instance._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    match = udn_embed_instance._VALID_URL_RE.match(url)
    assert match
    assert match.groupdict()['id'] == '300040'


# Generated at 2022-06-24 13:47:12.796349
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Make sure that regular expression can match url above
    url = 'https://video.udn.com/embed/news/300040'
    match = re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, url)
    assert match, 'Regular expression cannot match url'
    assert match.group(1) == '300040'
    print ('Regular expression can match url')

# Generated at 2022-06-24 13:47:17.374989
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    embedInfo = UDNEmbedIE(url)
    assert (embedInfo.IE_NAME == 'UDNEmbed')
    assert (embedInfo._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-24 13:47:25.225339
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test invalid URLs
    assert not UDNEmbedIE.suitable('http://video.udn.com/news/300040')
    assert not UDNEmbedIE.suitable('https://video.udn.com/new/300040')
    assert not UDNEmbedIE.suitable('http://video.udn.com/embed/ne/300040')
    assert not UDNEmbedIE.suitable('https://video.udn.com/play/ne/300040')
    assert not UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040/')
    assert not UDNEmbedIE.suitable('https://video.udn.com/play/news/300040/')

# Generated at 2022-06-24 13:47:31.154184
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    # Test URL with https scheme
    ie = UDNEmbedIE()
    assert ie.suitable(url)

    url = 'http://video.udn.com/play/news/303776'
    # Test URL with http scheme
    ie = UDNEmbedIE()
    assert ie.suitable(url)

    url = '//video.udn.com/play/news/303776'
    # Test URL with no scheme
    # TODO: Add this type of URL support in suitable()
    ie = UDNEmbedIE()
    assert not ie.suitable(url)

# Generated at 2022-06-24 13:47:35.415850
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('UDNEmbed')
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert len(ie._TESTS) == 3

# Generated at 2022-06-24 13:47:40.111492
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie._VALID_URL == ie._TEST.get('valid_url')
    assert ie._PROTOCOL_RELATIVE_VALID_URL == ie._TEST.get('protocol_relative_valid_url')
    assert ie._TESTS == ie._TEST.get('tests', [])
    assert ie._WORKING == ie._TEST.get('working', True)
    assert ie.IE_DESC == ie._TEST.get('ie_desc', '聯合影音')

# Generated at 2022-06-24 13:47:44.880910
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor

    ie = InfoExtractor('UDNEmbedIE', "UDNEmbedIE")
    assert ie.ie_key() == 'UDNEmbedIE'

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:47:45.857819
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:47:48.310570
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:47:50.748522
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert True


if __name__ == "__main__":
    test_UDNEmbedIE()

# Definition of class UDNEmbedIE
UDNEmbedIE = test_UDNEmbedIE

# Generated at 2022-06-24 13:48:00.813394
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    from .common import fake_httpd
    from .common import base_url

    server = None

# Generated at 2022-06-24 13:48:01.956747
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.create_ie())._test_id('300040')

# Generated at 2022-06-24 13:48:02.736404
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.ie_key())

# Generated at 2022-06-24 13:48:06.208805
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # To test whether post request works once we have a valid id
    ie = UDNEmbedIE()
    ie_info = ie.extract('http://video.udn.com/embed/news/300040')
    assert ie_info['id'] == '300040'

# Generated at 2022-06-24 13:48:08.951410
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test class UDNEmbedIE
    """
    ie = UDNEmbedIE()
    print("Extractor is "+ ie.IE_NAME)



# Generated at 2022-06-24 13:48:16.269780
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()

    # Test URL that should match
    url_1 = 'https://video.udn.com/embed/news/300040'
    url_2 = '//video.udn.com/embed/news/300040'
    assert udne.suitable(url_1)
    assert udne.suitable(url_2)

    # Test URL that shouldn't match
    url_3 = 'https://www.udn.com/news/story/7240/3319228'
    assert not udne.suitable(url_3)

    # Test _real_extract()
    info = udne._real_extract(url_1)
    assert info['id'] == '300040'

# Generated at 2022-06-24 13:48:20.417852
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie._url == url
    assert ie._video_id == '300040'


# Generated at 2022-06-24 13:48:25.679905
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    assert udnEmbedIE._VALID_URL == udnEmbedIE._PROTOCOL_RELATIVE_VALID_URL.replace("//","https://")
    assert udnEmbedIE._VALID_URL in 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:48:27.039925
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne is not None

# Generated at 2022-06-24 13:48:29.157478
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()    
    ie.extract(UDNEmbedIE._TESTS[0]['url'])

# Generated at 2022-06-24 13:48:31.771085
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test if the constructor and the toString methods of
    class UDNEmbedIE could be pass without any exception thrown.
    """
    instance = UDNEmbedIE()
    print(instance)

# Generated at 2022-06-24 13:48:32.962369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:48:39.204568
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pylint:disable=protected-access
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    # pylint:enable=protected-access

# Generated at 2022-06-24 13:48:42.745408
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE()

    # Test for method '_real_extract' in class UDNEmbedIE
    result = obj._real_extract(url)
    assert result is not False

# Generated at 2022-06-24 13:48:47.384806
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert len(ie._TESTS) == 3


# Generated at 2022-06-24 13:48:57.916851
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor with valid URL, which should return valid IE
    assert UDNEmbedIE._VALID_URL == 'https?:(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'
    # Test for correct match with valid URL
    assert re.search(UDNEmbedIE._VALID_URL, 'https://video.udn.com/play/news/249826', re.IGNORECASE) is not None
    # Test for incorrect match with invalid URL
    assert re.search(UDNEmbedIE._VALID_URL, 'https://videot.udn.com/play/news/249826', re.IGNORECASE) is None

# Generated at 2022-06-24 13:48:59.793514
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # This test is for catching bug #1188
    # At the time of writing, the error only happened with this _VALID_URL
    # It might be necessary to update the test when the error occurs again
    url = 'https://video.udn.com/embed/news/309382'
    UDNEmbedIE()._match_id(url)

# Generated at 2022-06-24 13:49:04.128033
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	url = 'http://video.udn.com/embed/news/300040'
	assert UDNEmbedIE._match_id(url) == '300040'
	url = 'https://video.udn.com/embed/news/300040'
	assert UDNEmbedIE._match_id(url) == '300040'

# Generated at 2022-06-24 13:49:13.064598
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test of constructor of class UDNEmbedIE.

    A constructor of class should take a url and extract a video information
    from the url.
    """
    # Given a video url and a video information,
    url = 'http://video.udn.com/embed/news/300040'
    IE_DESC = '聯合影音'
    expected_video_info = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }

    # When we construct an instance with the video url,
    udnEmbed = UDNEmbed

# Generated at 2022-06-24 13:49:18.513752
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:49:19.899019
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None, None)



# Generated at 2022-06-24 13:49:21.980663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:49:27.125040
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS
test_UDNEmbedIE.func_annotations = {}

# Generated at 2022-06-24 13:49:28.907281
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie


# Generated at 2022-06-24 13:49:35.259916
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, 'IE_DESC')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_real_extract')
# Test for _real_extract()