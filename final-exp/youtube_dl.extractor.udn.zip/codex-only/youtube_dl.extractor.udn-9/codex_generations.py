

# Generated at 2022-06-24 13:39:44.776238
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # test __init__
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._downloader == None
    assert ie._working_dir == None
    assert ie.to_screen == None
    assert ie._ies == []
    assert ie.params == {}
    assert ie._progress_hooks == []
    assert ie.cache == None
    assert ie._download_retry == {}
    assert ie._unit_test == False
    assert ie._num_downloads == 0
    assert ie._error_counts == {}
    assert ie._download_counts == {}
    assert ie._do_download_archive_index == True
    assert ie._download_archive == {}
    assert ie

# Generated at 2022-06-24 13:39:47.275956
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    from ytdl_server.server.extractors.youtube import YoutubeIE
    assert instance.constructor == YoutubeIE

# Generated at 2022-06-24 13:39:59.130541
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:40:01.491565
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	test_instance = UDNEmbedIE()
	test_instance._real_extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:40:03.092011
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert (UDNEmbedIE.__name__ == 'UDNEmbedIE')
    assert issubclass(UDNEmbedIE, InfoExtractor)


# Generated at 2022-06-24 13:40:09.550795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("====test_UDNEmbedIE====")
    url = 'http://video.udn.com/embed/news/300040'
    extractor = UDNEmbedIE.ie_key()(url)
    info_dict = extractor.extract(url)

    print("  id=" + info_dict['id'])
    print("  title=" + info_dict['title'])
    print("  thumbnail=" + info_dict['thumbnail'])
    print("  formats=")
    for format in info_dict['formats']:
        print("    format_id=" + format['format_id'])
        print("    tbr=" + str(format.get('tbr', None)))
        print("    height=" + str(format.get('height', None)))

# Generated at 2022-06-24 13:40:15.182658
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url='http://udn.com/video/embed/news/300040'
    udn = UDNEmbedIE()
    assert udn.ie_key() == 'UDNEmbed'
    #webpage_info=[]
    webpage_info = udn._real_extract(url)
    assert webpage_info['id'] == '300040'

# Generated at 2022-06-24 13:40:24.483135
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern = r'^https?://.*\.jpg$'
    protocol_relative_valid_url = '//video.udn.com/embed/news/300040'
    valid_url = 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:40:26.897035
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    _ = UDNEmbedIE(InfoExtractor())

# Generated at 2022-06-24 13:40:37.315912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj_dict = obj.__dict__
    assert obj_dict.get('_PROTOCOL_RELATIVE_VALID_URL') == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj_dict.get('_VALID_URL') == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj_dict.get('IE_DESC') == '聯合影音'
    assert obj_dict.get('_TESTS')[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:40:42.090468
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Unit test for constructor
    if __name__ == '__main__':
        # Load webpage from local file
        from .test_downloads import TEST_PAGE
        webpage = open(TEST_PAGE, 'r').read()
        # Load class
        from .common import InfoExtractor
        from ..utils import (
            determine_ext,
            int_or_none,
            js_to_json,
        )
        from ..compat import compat_urlparse
        # Convert JS code to JSON object
        options_str = re.search(r'var\s+options\s*=\s*([^;]+);', webpage).group(1)
        trans_options_str = js_to_json(options_str)
        # Create InfoExtractor object
        udne_ie = InfoExtractor()
        #

# Generated at 2022-06-24 13:40:48.072322
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test when video_urls contain youtube
    udn_embed_ie = UDNEmbedIE()
    invalid_url = 'https://video.udn.com/embed/news/1000'
    invalid_options = {'video': {'youtube': 'https://www.youtube.com/watch/v=dQw4w9WgXcQ'}, }
    assert udn_embed_ie._real_extract(invalid_url) == udn_embed_ie.url_result(
        invalid_options['video']['youtube'], 'Youtube')

    # test when video_urls contain dk
    valid_url = 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:40:50.109255
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert udnie._match_id(url) == '300040'

# Generated at 2022-06-24 13:40:53.936306
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    regexMatch = udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert regexMatch == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:56.877978
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:58.239321
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()

# Generated at 2022-06-24 13:41:09.589388
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_variable = UDNEmbedIE()
    assert test_variable._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_variable._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert test_variable._TESTS[0]['info_dict']['id'] == '300040'
    assert test_variable._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert test_variable._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert test_variable

# Generated at 2022-06-24 13:41:14.785598
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == "UDNEmbedIE"
    assert ie.ie_desc() == "聯合影音"
    assert ie.extract("http://video.udn.com/embed/news/300040")

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:41:17.801561
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._TESTS == ie._TESTS



# Generated at 2022-06-24 13:41:26.819991
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[1]['only_matching']
    assert UDNEmbedIE._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-24 13:41:31.553329
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL[2:]
    UDNEmbedIE(UDNEmbedIE.IE_NAME, False)._download_webpage(
        'https://video.udn.com/embed/news/300040', '300040')


# Generated at 2022-06-24 13:41:38.483303
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert len(UDNEmbedIE._TESTS) == 3

test_UDNEmbedIE()

# Generated at 2022-06-24 13:41:44.651151
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	test_url = 'http://video.udn.com/embed/news/300040'
	infoExtractor = UDNEmbedIE(downloader=None)

# Generated at 2022-06-24 13:41:47.012350
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    UDNEmbedIE('http://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:41:53.586084
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert ie.IE_DESC == "聯合影音"
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:41:57.057507
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert test._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:42:00.739511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert_equal(ie.IE_DESC, '聯合影音')
    assert_equal(ie._VALID_URL, r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')


# Generated at 2022-06-24 13:42:03.470144
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Basic test
    UDNEmbedIE(None)._real_initialize()
# test_UDNEmbedIE()

# Generated at 2022-06-24 13:42:08.840239
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:12.840975
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Simple unit test for constructor of class UDNEmbedIE
    """
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert type(UDNEmbedIE._TESTS) == list
    assert len(UDNEmbedIE._TESTS) > 0
    

# Generated at 2022-06-24 13:42:15.603044
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    udnInstance = UDNEmbedIE()


# Generated at 2022-06-24 13:42:18.223807
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:20.186388
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    _ = UDNEmbedIE()._real_extract(url)

# Testing member function _real_extract()

# Generated at 2022-06-24 13:42:23.600558
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import _TEST_HTTP_HEADERS
    from .common import _TEST_UUID
    ie = UDNEmbedIE(None)
    ie.http._http_headers = _TEST_HTTP_HEADERS
    ie.http._http_headers.update({
        'X-Requested-With': _TEST_UUID,
    })



# Generated at 2022-06-24 13:42:24.474815
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:42:25.286644
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()


# Generated at 2022-06-24 13:42:32.232981
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:42:35.796912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'https://video.udn.com/play/news/303776'
    # Only check if URL match, not construct IE (for there is no extract method)
    UDNEmbedIE()._match_id(test_url)

# Generated at 2022-06-24 13:42:41.718670
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor = globals()['UDNEmbedIE']
    instance = constructor(None)
    assert isinstance(instance, InfoExtractor)
    assert hasattr(instance, '_WORKING')
    assert hasattr(instance, '_downloader')
    assert hasattr(instance, 'ie_key')
    assert hasattr(instance, '_ies')
    assert hasattr(instance, '_downloader')
    assert hasattr(instance, '_WORKING')


# Generated at 2022-06-24 13:42:50.265417
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_CODE == 'udn'
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:57.307444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert len(UDNEmbedIE._TESTS) == 3



# Generated at 2022-06-24 13:43:05.132643
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:43:09.394661
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == 'https?:' + UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE().IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:19.948076
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    # Protocol-relative URL for constructor of class InfoExtractor
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Validate URL for constructor of class InfoExtractor
    assert udne._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Video ID for constructor of class InfoExtractor
    assert udne._match_id('http://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-24 13:43:24.946993
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from . import UDNEmbedIE
    e = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert e.IE_NAME == 'udn'
    assert e.IE_DESC == '聯合影音'
    assert e._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(e._TESTS) == 1


# Generated at 2022-06-24 13:43:26.232692
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie


# Generated at 2022-06-24 13:43:27.820299
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

# Generated at 2022-06-24 13:43:30.893052
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE(UDNEmbedIE.IE_NAME, UDNEmbedIE.IE_DESC)
    assert obj.ie_key() == UDNEmbedIE.IE_KEY
    assert obj.ie_desc() == UDNEmbedIE.IE_DESC
    assert obj.ie_name() == UDNEmbedIE.IE_NAME
    assert obj.extract('https://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:43:40.716513
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:43:45.009314
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    details = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }
    url = 'https://video.udn.com/embed/news/300040'
    assert UDNEmbedIE(url)._extract_info_dict(url) == details

# Generated at 2022-06-24 13:43:48.721988
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE().IE_NAME == UDNEmbedIE.IE_NAME
    assert UDNEmbedIE().IE_DESC == UDNEmbedIE.IE_DESC

# Generated at 2022-06-24 13:43:56.101373
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    # Test for the _TESTS property
    seg = ie._TESTS[0]
    assert seg['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:44:02.864766
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None, 'http://video.udn.com/embed/news/300040')
    UDNEmbedIE(None, None, 'https://video.udn.com/embed/news/300040')
    UDNEmbedIE(None, None, 'http://video.udn.com/play/news/300040')
    UDNEmbedIE(None, None, 'https://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:44:09.454882
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # From https://video.udn.com/news/303776
    url = 'https://video.udn.com/play/news/303776'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._match_id(url) == '303776'

# Generated at 2022-06-24 13:44:10.172716
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:44:12.289346
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed is not None, "Failed to initialize udn_embed"

# Generated at 2022-06-24 13:44:14.529934
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    result = UDNEmbedIE()._match_id(url)
    assert result == '300040'

# Generated at 2022-06-24 13:44:16.294110
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    udn.extract("https://video.udn.com/play/news/303776")

# Generated at 2022-06-24 13:44:20.660618
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE().IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:44:31.397035
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:42.841196
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Testing UDNEmbedIE (a subclass of InfoExtractor)
    info_extractor = UDNEmbedIE()
    assert info_extractor.IE_DESC == '聯合影音'

    # Testing proper initialization
    UDNEmbedIE._DOWNLOADER_FACTORY = 'test'
    UDNEmbedIE._AVAILABLE_FORMATS = 'test'
    UDNEmbedIE._QUALITIES = 'test'
    UDNEmbedIE._VIDEO_INFO_TEMPLATE = 'test'
    info_extractor = UDNEmbedIE()
    assert info_extractor._downloader is 'test'
    assert info_extractor._available_formats is 'test'
    assert info_extractor._qualities is 'test'
    assert info_extractor._video

# Generated at 2022-06-24 13:44:52.654229
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    instance = UDNEmbedIE("udn")
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_NAME == "udn"
    assert instance._VALID_URL == "https?://video\\.udn\\.com/(?:embed|play)/news/(?P<id>\\d+)"
    assert instance._download_webpage("https://video.udn.com/embed/news/300040" , "someid")
    # check get_id
    assert instance._match_id(url) == "300040"
    # check get_title

# Generated at 2022-06-24 13:44:55.348850
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:44:59.436945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = globals()['UDNEmbedIE']
    obj = class_()
    assert hasattr(obj, '_PROTOCOL_RELATIVE_VALID_URL')
    assert hasattr(obj, '_VALID_URL')
    assert hasattr(obj, '_TESTS')
    assert hasattr(obj, 'IE_DESC')


# Generated at 2022-06-24 13:45:00.302146
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()

# Generated at 2022-06-24 13:45:03.182231
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:07.581520
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-24 13:45:15.294237
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'
    video_title = '生物老師男變女 全校挺"做自己"'
    video_thumbnail = 'https://s.yimg.com/ea/img/-/180828/poster_default_300040_180828152053_news_3_0.jpg'

    udn_embed = UDNEmbedIE()
    # Test url parsing
    assert udn_embed._match_id(url) == video_id
    assert udn_embed._VALID_URL == (
        r'https?:' + udn_embed._PROTOCOL_RELATIVE_VALID_URL)

    # Test _

# Generated at 2022-06-24 13:45:20.107421
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # test #1
    url = 'http://video.udn.com/embed/news/300040'
    _ = ie.match_id(url)
    assert _ == '300040'

# Generated at 2022-06-24 13:45:26.296357
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:28.223856
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'



# Generated at 2022-06-24 13:45:35.398797
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test constructor of class UDNEmbedIE
    """
    embedIE = UDNEmbedIE()
    assert embedIE.IE_DESC == '聯合影音'
    assert embedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert embedIE._VALID_URL == r'https?:' + embedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:45:41.996003
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Make sure unit test detects problem when re.match can't match
    # real url
    ie = UDNEmbedIE()
    unit_test_url = 'http://video.udn.com/embed/news/123'
    assert ie.suitable(unit_test_url)
    unit_test_url = 'http://video.udn.com/embed/news/321'
    assert not ie.suitable(unit_test_url)
    unit_test_url = '/embed/news/123'
    assert ie.suitable(unit_test_url)
    unit_test_url = '/embed/news/321'
    assert not ie.suitable(unit_test_url)

# Generated at 2022-06-24 13:45:48.138816
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_1 = 'http://video.udn.com/embed/news/300040'
    url_2 = '//video.udn.com/embed/news/300040'
    url_3 = 'https://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE()
    assert isinstance(udn_embed, InfoExtractor)
    assert udn_embed.IE_NAME == 'udn'
    assert udn_embed.IE_DESC
    assert udn_embed._VALID_URL == udn_embed._TESTS[0]['url']
    assert udn_embed._match_id(url_1) == udn_embed._match_id(url_2) == udn_embed._match_id(url_3)

# Generated at 2022-06-24 13:45:49.134556
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-24 13:45:58.102110
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == r'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL
    # Only test default values

# Generated at 2022-06-24 13:46:09.014463
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:09.821393
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE())

# Generated at 2022-06-24 13:46:11.657270
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """ can construct UDNEmbedIE object

    """
    ie = UDNEmbedIE()
    assert ie is not None
    return



# Generated at 2022-06-24 13:46:18.652660
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    assert(udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udn_embed_ie._match_id(url) == '300040')

# Generated at 2022-06-24 13:46:29.133174
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:36.920517
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.IE_NAME == 'udn'
    assert u.IE_DESC == '聯合影音'
    assert u._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:44.885677
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = ie._PROTOCOL_RELATIVE_VALID_URL
    match = ie._VALID_URL_RE.match(url)
    assert match is not None
    video_id = ie._match_id(url)
    assert video_id == '300040'
    assert ie._VALID_URL == r'https?:' + url
    assert ie._TESTS[0]['url'] == 'http:' + url
    assert ie._TESTS[1]['url'] == 'https:' + url
    assert ie._match_id(ie._TESTS[1]['url']) == '300040'

# Generated at 2022-06-24 13:46:51.051359
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Unit tests for _real_extract
# For testing _real_extract, we pass in test_dict which is one of the test cases in the variable TESTS in the
# variable UDNEmbedIE._TESTS

# Generated at 2022-06-24 13:47:01.238822
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    def check(url, embed_url, embed_title):
        embed_ie = UDNEmbedIE(url)
        assert embed_ie.name == '聯合影音'
        assert embed_ie.ie_key() == 'UDNEmbed'
        assert embed_ie._VALID_URL == r'https?:(?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'
        assert embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
        assert embed_ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
        assert embed_ie._TES

# Generated at 2022-06-24 13:47:06.379461
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	from . import UDNEmbedIE
	ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
	print(ie.IE_DESC)
	print(ie.__is_valid_url)
	assert ie.IE_DESC == '聯合影音'
	assert ie.__is_valid_url('http://video.udn.com/embed/news/300040') is True
	print(ie._real_extract('http://video.udn.com/embed/news/300040'))

# Generated at 2022-06-24 13:47:13.719213
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    IE_DESC = '聯合影音'
    url = 'http://video.udn.com/embed/news/300040'
    # Testing constructor
    obj = UDNEmbedIE(url)
    # Testing attributes
    assert obj._VALID_URL == 'https?:' + _PROTOCOL_RELATIVE_VALID_URL
    assert obj.IE_DESC == IE_DESC

# Generated at 2022-06-24 13:47:14.596952
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	assert UDNEmbedIE != None

# Generated at 2022-06-24 13:47:15.638882
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE([])

# Generated at 2022-06-24 13:47:24.064367
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert re.search(r'stripslashes\(unescape\(', ie._html_search_regex(None, None, 'parse_json'))
    assert re.search(r'var\s+options\s*=\s*([^;]+);', ie._html_search_regex(None, None, 'options'))
    assert re.search(r'"video"\s*:\s*({.+?})\s*,', ie._html_search_regex(None, None, 'video_urls'))
    assert re.search(r"title\s*:\s*'(.+?)'\s*,", ie._html_search_regex(None, None, 'title'))

# Generated at 2022-06-24 13:47:26.597330
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL
    ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:47:27.978336
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:47:39.112962
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # Do not use assertIsInstance
    assert ie.__class__.__name__ == 'UDNEmbedIE'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:47.229596
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == 'udn'
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert re.search(r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert re.search(r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL, 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:47:48.267302
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, {})

# Generated at 2022-06-24 13:47:51.335660
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:01.962560
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:48:02.551333
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()



# Generated at 2022-06-24 13:48:09.334465
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE.suitable(url)
    # Should called twice and extract
    IE = UDNEmbedIE()
    IE.suitable(url)
    IE.extract('http://video.udn.com/embed/news/300040')
    IE.suitable('https://video.udn.com/embed/news/300040')
    IE.extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:48:16.946234
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_url = 'https://video.udn.com/embed/news/300040'
    invalid_url = 'https://video.udn.com/news/300040'
    valid_ie = UDNEmbedIE()
    invalid_ie = InfoExtractor()
    ie = valid_ie.suitable(valid_url)
    assert ie, True
    ie = valid_ie.suitable(invalid_url)
    assert ie, False
    ie = invalid_ie.suitable(valid_url)
    assert ie, False

# Generated at 2022-06-24 13:48:19.259442
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 13:48:23.999194
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # The first argument of the constructor can be a string or a regex object
    UDNEmbedIE('http://video\.udn\.com/test/', 'test_url')
    UDNEmbedIE(re.compile(r'http://video\.udn\.com/test/'), 'test_url_regex')

# Generated at 2022-06-24 13:48:27.990950
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for success case
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

    # test for fail case
    # UDNEmbedIE('http://video.udn.com/embed/news/300040', fail=True)

# Generated at 2022-06-24 13:48:32.161711
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    expected_prefix = 'https://video.udn.com'
    assert udne._VALID_URL == expected_prefix + '/embed/news/300040'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == '/video.udn.com/embed/news/300040'
    assert udne._TESTS[0]['url'] == expected_prefix + '/embed/news/300040'

# Generated at 2022-06-24 13:48:37.748794
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    r = UDNEmbedIE()._real_extract(url)
    assert r['id'] == '300040'
    assert r['title'] == u'生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-24 13:48:38.591076
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie.IE_DESC)

# Generated at 2022-06-24 13:48:45.975255
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_data = [
        ('//video.udn.com/embed/news/300040', '300040'),
        ('https://video.udn.com/embed/news/300040', '300040'),
    ]

    for url, video_id in valid_data:
        assert UDNEmbedIE._match_id(url) == video_id

    invalid_data = [
        '//video.udn.com/embed/news/a300040',
        'https://video.udn.com/embed/news/a300040',
    ]

    for url in invalid_data:
        assert not UDNEmbedIE._match_id(url)

# Generated at 2022-06-24 13:48:47.478719
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)._test_extract()

# Generated at 2022-06-24 13:48:49.805979
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == '__main__':
        import sys
        sys.exit(UDNEmbedIE()._run())

# Generated at 2022-06-24 13:48:57.766635
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    assert UDNEmbedIE()._match_id(url) == '300040'
    # Check that the expected failure case works
    assert UDNEmbedIE()._match_id('https://video.udn.com/play/news/300040') is None
    # Check that the protocol-relative URL works
    assert UDNEmbedIE()._match_id('//video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-24 13:49:01.645220
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    o = UDNEmbedIE()
    assert o.IE_DESC == '聯合影音'
    assert o._VALID_URL == 'https?://video.udn.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-24 13:49:02.554918
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie

# Generated at 2022-06-24 13:49:10.767551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE.suitable("https://video.udn.com/play/news/303776"))
    assert(UDNEmbedIE.suitable("https://video.udn.com/embed/news/300040"))
    assert(UDNEmbedIE.suitable("//video.udn.com/embed/news/300040"))
    assert(UDNEmbedIE.suitable("http://video.udn.com/embed/news/300040"))
    assert(UDNEmbedIE.suitable("http://video.udn.com/play/news/300040"))
    assert(UDNEmbedIE.suitable("http://video.udn.com/play/news/300040"))

# Generated at 2022-06-24 13:49:16.308454
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE("UDNEmbed", url)
    assert_equal("UDNEmbed", ie._VALID_URL)
    assert_equal("UDNEmbedIE", ie.IE_DESC)

# Generated at 2022-06-24 13:49:28.539975
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    v_url = 'http://video.udn.com/video/api/get_video/300040'
    t_url = 'http://video.udn.com/video/api/get_title/300040'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == url
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
   

# Generated at 2022-06-24 13:49:36.421834
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert len(UDNEmbedIE._TESTS) == 3
    assert UDNEmbedIE._TESTS[0]['expected_warnings'] == ['Failed to parse JSON Expecting value']
