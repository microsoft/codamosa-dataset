

# Generated at 2022-06-24 13:39:44.722955
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:39:49.727932
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    match = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert match == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + match

# Generated at 2022-06-24 13:39:53.616734
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    m = UDNEmbedIE()
    m.extract('http://video.udn.com/embed/news/300040')
    m.extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:39:58.582499
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Note: __init__ function call is being skipped
    #       Instance of InfoExtractor is just being created
    instance_of_IE = UDNEmbedIE()
    for url in UDNEmbedIE._TESTS:
        instance_of_IE._match_id(url['url'])

# Generated at 2022-06-24 13:40:02.195369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie._downloader.tests


# Generated at 2022-06-24 13:40:11.717418
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test url which is not start with protocol
    url = '//video.udn.com/embed/news/300040'
    # Test url which is start with protocol
    url2 = 'http://video.udn.com/embed/news/300040'
    # Test url which is not part of class
    url3 = 'http://example.com'

    ie = UDNEmbedIE(None)

    # Test _PROTOCOL_RELATIVE_VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test _VALID_URL

# Generated at 2022-06-24 13:40:21.352434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    item = UDNEmbedIE()
    assert item.IE_DESC == '聯合影音'
    assert item._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert item._VALID_URL == r'https?:' + item._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:40:25.589226
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj.IE_DESC == '聯合影音'
    assert test_obj._VALID_URL == 'https?:' + test_obj._PROTOCOL_RELATIVE_VALID_URL
    assert test_obj._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:40:28.412059
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r = UDNEmbedIE()
    for t in r._TESTS:
        assert t['url'] == r._TESTS[0]['url']



# Generated at 2022-06-24 13:40:38.661843
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # test _real_extract()
    response = ie._real_extract('https://video.udn.com/embed/news/303776')
    # video id
    video_id = response['id']
    assert video_id == "303776"
    # video thumb
    thumb = response['thumbnail']
    # thubm should be a non-empty string
    assert (isinstance(thumb, str) and thumb != '')
    # video title
    title = response['title']
    # title should be a non-empty string
    assert (isinstance(title, str) and title != '')
    # formats
    formats = response['formats']
    # formats should be a list
    assert isinstance(formats, list)
    # at least one format entry


# Generated at 2022-06-24 13:40:39.638284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' in globals()

# Generated at 2022-06-24 13:40:42.925776
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_initialize()
    UDNEmbedIE._real_extract(UDNEmbedIE(), url)

# Generated at 2022-06-24 13:40:48.930643
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert re.search(udn_ie._PROTOCOL_RELATIVE_VALID_URL,
                     '//video.udn.com/embed/news/300040') is not None
    assert re.search(udn_ie._PROTOCOL_RELATIVE_VALID_URL,
                     'https://video.udn.com/embed/news/300040') is not None
    assert re.search(udn_ie._PROTOCOL_RELATIVE_VALID_URL,
                     'http://video.udn.com/embed/news/300040') is not None

# Generated at 2022-06-24 13:40:52.738813
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # Assert that pattern is correct
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:40:57.825430
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')


# Generated at 2022-06-24 13:41:09.202181
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.get_info_url('300040') == 'https://video.udn.com/embed/news/300040'
    assert IE.get_info_url('http://video.udn.com/embed/news/300040') == 'https://video.udn.com/embed/news/300040'
    assert IE.get_info_url('https://video.udn.com/embed/news/300040') == 'https://video.udn.com/embed/news/300040'
    assert IE.get_info_url('//video.udn.com/embed/news/300040') == 'https://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:41:18.877075
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        from . import yt_search_api
    except ImportError:
        # utils.py is not included in the extracted archive.
        yt_search_api = None

    _VALID_URL = 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:41:20.530004
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:41:26.000951
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("https://video.udn.com/embed/news/300040")
    UDNEmbedIE("https://video.udn.com/play/news/300040")
    UDNEmbedIE("//video.udn.com/embed/news/300040")
    UDNEmbedIE("//video.udn.com/play/news/300040")

# Generated at 2022-06-24 13:41:31.553511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne_ie = UDNEmbedIE()
    if udne_ie._VALID_URL == udne_ie._PROTOCOL_RELATIVE_VALID_URL:
        raise ValueError('Test case not ready!')

    udne_ie = UDNEmbedIE()
    udne_ie._valid_url()

# Generated at 2022-06-24 13:41:34.390691
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test __init__
    udn_embed = UDNEmbedIE()
    assert udn_embed.IE_NAME == 'udn'
    assert udn_embed.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:41:35.667221
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' != None


# Generated at 2022-06-24 13:41:41.000156
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:44.481576
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE().IE_NAME is not None)
    assert(UDNEmbedIE().IE_DESC is not None)
    assert(UDNEmbedIE()._VALID_URL is not None)
    assert(UDNEmbedIE()._TESTS is not None)
    assert(UDNEmbedIE()._downloader is not None)
    assert(UDNEmbedIE()._WORKING is not None)



# Generated at 2022-06-24 13:41:46.631623
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:41:48.822741
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # given
    url = 'https://video.udn.com/embed/news/300040'
    # when
    udi = UDNEmbedIE()
    # then
    assert(udi is not None)

# Generated at 2022-06-24 13:41:55.702627
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE({})
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:42:06.733926
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    extracted_urls = []
    def extract_url_by_udnembedIE(url):
        #
        # Callback function for extract_urls_by_ie()
        #
        ie = UDNEmbedIE()
        result = ie.extract(url)
        extracted_urls.append(result)

    import urlutil
    urlutil.extract_urls_by_ie(extract_url_by_udnembedIE)

    print("The following urls are extracted by IE 'UDNEmbedIE':")
    for extracted_url in extracted_urls:
        print("%s" % extracted_url)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:42:17.976476
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # Test Case 1: test the initialization of UDNIE
    UDNEmbed_ie_test1 = UDNEmbedIE()
    print ("The name of IE is %s" % UDNEmbed_ie_test1.IE_NAME)
    print ("The description of IE is %s" % UDNEmbed_ie_test1.IE_DESC)
    print ("The ie_key of IE is %s" % UDNEmbed_ie_test1.ie_key())

    # Test Case 2: test the extractor of UDNIE
    UDNEmbed_ie_test2 = UDNEmbedIE()
    UDNEmbed_ie_test2.extract("http://video.udn.com/embed/news/300040")


# Generated at 2022-06-24 13:42:24.815991
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert info_extractor.IE_DESC == '聯合影音'
    assert info_extractor._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert info_extractor._VALID_URL == 'https?:' + info_extractor._PROTOCOL_RELATIVE_VALID_URL
    assert info_extractor._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert info_extractor._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-24 13:42:25.645130
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _ = UDNEmbedIE()

# Generated at 2022-06-24 13:42:28.593690
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    description = UDNEmbedIE.IE_DESC
    constructor_result = UDNEmbedIE()
    assert constructor_result.IE_DESC == description


# Generated at 2022-06-24 13:42:29.824989
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE is not None

# Generated at 2022-06-24 13:42:35.059109
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test URL in _PROTOCOL_RELATIVE_VALID_URL and VALID_URL
    udne_ie = UDNEmbedIE()
    udne_ie.suitable('//video.udn.com/play/news/300040')
    udne_ie.suitable('https://video.udn.com/play/news/300040')


# Generated at 2022-06-24 13:42:43.281755
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_url = 'https://video.udn.com/play/news/300040'
    obj = UDNEmbedIE()
    # Matching no-scheme URL
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Matching scheme URL
    assert obj._VALID_URL == 'https?:' + '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Matching some actual URL
    assert re.search(obj._VALID_URL, valid_url)

# Generated at 2022-06-24 13:42:45.435620
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == ie.PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:47.389968
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert test._match_id(test._VALID_URL) == '300040'
    assert test._match_id(test._PROTOCOL_RELATIVE_VALID_URL) == '300040'

# Generated at 2022-06-24 13:42:57.088459
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_DESC == '聯合影音'
    assert obj.IE_NAME == 'udn'
    assert obj._VALID_URL == 'https??://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert obj._TESTS[0]['info_dict']['id'] == '300040'
    assert obj._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:43:01.485687
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create an instance of the class
    ie = UDNEmbedIE()
    
    # Assert class variables
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    
    

# Generated at 2022-06-24 13:43:02.312893
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(0, 0)

# Generated at 2022-06-24 13:43:09.456683
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test case 1
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    UDNEmbedIE._VALID_URL = r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    result = UDNEmbedIE._VALID_URL
    expected = r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert result == expected
    result = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:12.596895
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor of class InfoExtractor shouldn't raise any exception.
    UDNEmbedIE()

# Generated at 2022-06-24 13:43:13.550403
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UdnEmbed'


# Generated at 2022-06-24 13:43:16.924388
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE()
    tester.urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
    ]
    return tester

# Generated at 2022-06-24 13:43:21.491261
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO: Updating _TESTS would be preferable, but in that case extractors/test.py
    # would need to be modified as well
    udne = UDNEmbedIE()
    assert udne.ie_key() == 'udn'
    assert udne.IE_NAME == '聯合影音'
    assert udne.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:23.023924
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:43:25.478058
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()
    UDNEmbedIE('udn')
    UDNEmbedIE('udn', 'udn embed')


# Generated at 2022-06-24 13:43:30.746364
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/news/303776'
    udn = UDNEmbedIE()
    assert udn._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._TESTS != None
    assert udn._html_search_regex("(?<=http://)","http://google.com",None) == "google.com"

# Generated at 2022-06-24 13:43:37.263850
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    info = ie._real_extract(
        'https://video.udn.com/embed/news/300040')
    assert info['id'] == '300040'
    assert info['title'] == '生物老師男變女 全校挺"做自己"'
    assert info['thumbnail'] is not None
    assert info['formats'] is not None

# Generated at 2022-06-24 13:43:38.835694
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        a = UDNEmbedIE()
        assert(a)
    except Exception:
        assert(False)

# Generated at 2022-06-24 13:43:40.356154
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r"""
    Unit test for constructor of class UDNEmbedIE
    """
    UDNEmbedIE()

# Generated at 2022-06-24 13:43:42.078699
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_obj = UDNEmbedIE()
    assert ie_obj.ie_key() == 'UDNEmbed', ie_obj.ie_key()

# Generated at 2022-06-24 13:43:52.250746
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie._TESTS

# Generated at 2022-06-24 13:43:55.704632
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'
    UDNEmbedIE()._match_id(url) == video_id

# Generated at 2022-06-24 13:43:57.644390
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    print(ie)

# Generated at 2022-06-24 13:44:00.292439
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE()
    # AssertionError: This class does not have _TEST
    assert a._TESTS == []



# Generated at 2022-06-24 13:44:02.994532
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:44:07.374497
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == "UDN-UDNEmbedIE"
    assert udn_embed_ie.IE_DESC == "聯合影音"
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:10.942408
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match('//video.udn.com/embed/news/300040')
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match('//video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:44:18.973035
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #test case 1: normal youtube link
    youtube_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie._match_id(youtube_url) == '300040'
    assert list(ie.suitable(youtube_url))
    #test case 2: none youtube

# Generated at 2022-06-24 13:44:29.803813
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # The following code is used to construct an instance of class UDNEmbedIE
    udn = UDNEmbedIE()

# Generated at 2022-06-24 13:44:37.191827
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:44:41.391191
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """ Unit test for constructor of class UDNEmbedIE"""
    udn_embed_ie = UDNEmbedIE()
    print (udn_embed_ie)
    
if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:44:52.144276
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import fake_urlopen
    from .common import mocked_urlopen
    from .common import FakeYDL
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.udn
    url = 'http://video.udn.com/embed/news/300040'
    with fake_urlopen() as mock_urlopen:
        with mocked_urlopen(mock_urlopen):
            fakeydl = FakeYDL()
            with youtube_dl.YoutubeDL(fakeydl) as ydl:
                UDNEmbedIE.url_result(url)
                info = UDNEmbedIE._real_extract(url)
                assert info['id'] == '300040'

# Generated at 2022-06-24 13:45:00.250416
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    video_url = 'http//video.udn.com/embed/news/' + video_id
    video_url_2 = 'https//video.udn.com/embed/news/' + video_id
    udn_ie = UDNEmbedIE()

    assert udn_ie._match_id(video_url) == video_id
    assert udn_ie._match_id(video_url_2) == video_id
    # the result of URL (http://video.udn.com/play/news/303776) should be
    # the same
    assert udn_ie._match_id(video_url_2) == udn_ie._match_id(
        'http//video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:45:02.562935
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert ('UDNEmbedIE', {'UDNVideo'} == {UDNEmbedIE(UDNEmbedIE()).ie_key(), InfoExtractor.ie_key()})


# Generated at 2022-06-24 13:45:04.651037
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert len(ie._TESTS) == 2

# Generated at 2022-06-24 13:45:13.838496
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()

    assert test_obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # test for _GEO_BYPASS
    assert test_obj._GEO_BYPASS == False
    assert test_obj._GEO_COUNTRIES == ['TW']

    # test for IE_NAME
    assert test_obj.IE_NAME == 'udn'

    #  test for _NETRC_MACHINE
    assert test_obj._NETRC_MACHINE == 'udn'



# Generated at 2022-06-24 13:45:19.817941
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import os, sys
    import unittest
    import nose


# Generated at 2022-06-24 13:45:27.065858
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:45:36.777071
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from . import YoutubeIE
    from . import YoutubeDL
    file1 = open("../test-data/test_UDNEmbedIE/test_UDNEmbedIE_1.txt", "r")
    file2 = open("../test-data/test_UDNEmbedIE/test_UDNEmbedIE_2.txt", "r")
    source_code = file1.read()
    source_code = source_code + file2.read()
    url = "http://video.udn.com/embed/news/300040"
    options = {
               'format': 'best',
               'fatal_warnings': True,
               }
    a = YoutubeIE._extract_video_info(YoutubeDL(options), url, source_code)
    file1.close()
    file2.close()
   

# Generated at 2022-06-24 13:45:37.639510
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE)

# Generated at 2022-06-24 13:45:45.217613
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    regex_str = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

    # Test with a valid URL.
    mobj = re.match(regex_str, '//video.udn.com/embed/news/300040')
    assert mobj.group('id') == '300040'

    # Test with an invalid URL (i.e. bad format).
    mobj = re.match(regex_str, 'http://video.udn.com/embed/news/300040')
    assert mobj is None

# Generated at 2022-06-24 13:45:46.185203
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert isinstance(UDNEmbedIE, type)

# Generated at 2022-06-24 13:45:47.857846
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert isinstance(obj, UDNEmbedIE)

# Generated at 2022-06-24 13:45:51.128901
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    p = UDNEmbedIE(None)
    url = 'http://video.udn.com/embed/news/300040'
    re_match = p._match_id(url)
    assert re_match == '300040'

# Generated at 2022-06-24 13:45:59.437077
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for _PROTOCOL_RELATIVE_VALID_URL
    try:
        UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    except AttributeError:
        assert False, '_PROTOCOL_RELATIVE_VALID_URL was not defined in UDNEmbedIE'
    # Test for _VALID_URL
    try:
        UDNEmbedIE._VALID_URL
    except AttributeError:
        assert False, '_VALID_URL was not defined in UDNEmbedIE'
    # Test for IE_DESC
    try:
        UDNEmbedIE.IE_DESC
    except AttributeError:
        assert False, 'IE_DESC was not defined in UDNEmbedIE'
    # Test for _TESTS

# Generated at 2022-06-24 13:46:09.858558
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _PROTOCOL_RELATIVE_VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    _VALID_URL = UDNEmbedIE._VALID_URL
    IE_DESC = UDNEmbedIE.IE_DESC
    assert UDNEmbedIE.ie_key() == 'UdnEmbed'


# Generated at 2022-06-24 13:46:17.066914
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:46:25.042635
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url1 = 'http://video.udn.com/embed/news/300040'
    url2 = 'https://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == r'http?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:31.737078
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    # download web page
    webpage = InfoExtractor._download_webpage(url, '300040', None)
    # match regex "var\s+options\s*=\s*([^;]+);" and get result
    options_str = InfoExtractor._html_search_regex(r'var\s+options\s*=\s*([^;]+);', webpage, 'options')
    # js to json
    trans_options_str = js_to_json(options_str)
    # parse json part of "options", and convert it to dict
    options = InfoExtractor._parse_json(trans_options_str, 'options', fatal=False) or {}
    if options:
        video_urls = options['video']


# Generated at 2022-06-24 13:46:37.816067
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/embed/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:46:48.332235
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'

# Generated at 2022-06-24 13:46:53.692144
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	# Arrange
    url = 'http://video.udn.com/embed/news/300040'
    regex = r'var\s+options\s*=\s*([^;]+);'

# Generated at 2022-06-24 13:46:58.778877
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_embed import _test_embed
    from .test_country_restricted import _test_country_restricted
    from .test_download_webpage import _test_download_webpage
    from .test_extractor_error import _test_extractor_error
    from .test_extractor_sort_formats import _test_extractor_sort_formats

    udn_embed_ie = UDNEmbedIE()

    _test_embed(udn_embed_ie, '300040')
    _test_country_restricted(udn_embed_ie, '300040')
    _test_download_webpage(udn_embed_ie, '300040')
    _test_extractor_error(udn_embed_ie, '300040')

# Generated at 2022-06-24 13:46:59.783695
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:47:00.973822
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()

# Generated at 2022-06-24 13:47:03.746254
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_NAME == 'udn'
    assert instance.IE_DESC == '聯合影音'
    assert instance.returns_m3u8

# Generated at 2022-06-24 13:47:07.380072
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert (UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL) and (UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-24 13:47:09.257894
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    assert udnEmbedIE

# Generated at 2022-06-24 13:47:18.237461
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test normal
    normal_dict = {u'udn_video_options': [u'UDN.video.options', u'300040',
                                          u'1', u'', u'', u'0']}

# Generated at 2022-06-24 13:47:20.025471
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:47:20.841188
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None)

# Generated at 2022-06-24 13:47:29.653381
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    from os import path
    from urllib import urlretrieve
    from urlparse import urlparse
    from fixture import UDNEmbedIE_fixture as fixture
    from ydl.YDL import YoutubeDL
    from ydl.extractor import gen_extractors

    # Fetch fixture data with YoutubeDL
    fixture_url = 'http://video.udn.com/embed/news/%s' % fixture.video_id
    UID = sys.modules[__name__] # Unit test module

# Generated at 2022-06-24 13:47:40.278470
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict'] == {'id': '300040', 'ext': 'mp4', 'title': '生物老師男變女 全校挺"做自己"', 'thumbnail': 're:^https?://.*\.jpg$'}

# Generated at 2022-06-24 13:47:41.232444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:47:48.740224
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/300040'
    parsed_url = compat_urlparse.urlparse(url)
    assert ie._match_url(url).group('id') == '300040'
    assert ie._match_url(url) == re.match(UDNEmbedIE._VALID_URL, url, re.VERBOSE)
    assert parsed_url.netloc == 'video.udn.com'
    assert parsed_url.scheme == 'https'

# Generated at 2022-06-24 13:47:52.499348
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:58.318701
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:47:58.795977
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # No exception

# Generated at 2022-06-24 13:48:05.433667
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/300040'
    assert ie._match_id(url) == '300040'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == ie._VALID_URL.replace('https?:', '')

# Generated at 2022-06-24 13:48:13.706492
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    this_module = globals()["test_UDNEmbedIE"]
    ie_class = this_module.__dict__["UDNEmbedIE"]

    if not hasattr(ie_class, 'ie_key'): # _VALID_URL to be changed
        return False
    # _VALID_URL is used to determine whether a URL is a valid URL
    # of this IE.
    if not re.match(ie_class._VALID_URL, 'https://video.udn.com/play/news/303776'):
        return False
    # _VALID_URL is not compatible with _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:48:21.697207
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._VALID_URL == r'https?:' + IE._PROTOCOL_RELATIVE_VALID_URL
    assert "聯合影音" == IE.IE_DESC

# Generated at 2022-06-24 13:48:26.945363
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor of class UDNEmbedIE
    # Input:
    #   - url: URL to webpage which embeds the video, whose id is "300040"
    # Return:
    #   - An instance of InfoExtractor
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    return



# Generated at 2022-06-24 13:48:28.597990
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 13:48:38.155161
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert re.match(ie._VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert re.match(ie._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert re.match(ie._VALID_URL, 'https://video.udn.com/play/news/300040')
    assert re.match(ie._VALID_URL, 'http://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:48:40.885563
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    # Test for the class constructor
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 13:48:42.268669
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(isinstance(UDNEmbedIE({}), InfoExtractor))

# Generated at 2022-06-24 13:48:46.617475
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()
    assert(class_UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-24 13:48:58.238892
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test 1
    UnitTestIE = UDNEmbedIE()
    # Test 1-1
    assert UnitTestIE.IE_DESC == '聯合影音'
    # Test 1-2
    assert UnitTestIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test 1-3
    assert UnitTestIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test 1-4
    assert len(UnitTestIE._TESTS) == 3
    # Test 1-4.1
    assert UnitTestIE._TESTS[0].get('url')

# Generated at 2022-06-24 13:49:06.195949
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie._

# Generated at 2022-06-24 13:49:09.895548
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    construct_ie = lambda: UDNEmbedIE() # pylint: disable=W0622
    assert construct_ie()
    assert construct_ie() == construct_ie()
    assert construct_ie() is construct_ie()
    assert construct_ie() != object()

# Generated at 2022-06-24 13:49:18.061418
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_ = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    try:
        assert(ie._match_id(url_) == '300040')
        assert(ie.IE_NAME == '聯合影音')
        assert(ie.IE_DESC == '聯合影音')
    except AssertionError:
        raise Exception('Failed to Test class UDNEmbedIE')

# Generated at 2022-06-24 13:49:22.471128
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.name == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._TESTS == UDNEmbedIE._TESTS

# Generated at 2022-06-24 13:49:25.608586
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:49:29.754951
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_NAME == 'udn'
    assert udn_ie.IE_DESC == '聯合影音'
    assert udn_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:49:32.030694
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.test()


if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:49:41.862021
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn_embed_ie._TESTS[0]['info_dict']['id'] == '300040'
   