

# Generated at 2022-06-24 13:39:41.764998
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    instance = UDNEmbedIE(url)
    assert instance._match_id(url) == '300040'
    assert instance._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:39:42.727522
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.suite()

# Generated at 2022-06-24 13:39:51.595740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

if __name__ == '__main__':
    import sys
    if len(sys.argv) >= 2:
        test_UDNEmbedIE()
    else:
        print('Please provide a test url.')

# Generated at 2022-06-24 13:39:53.223541
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj.to_screen('Hello World')

# Generated at 2022-06-24 13:40:04.301224
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert UDNEmbedIE._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-24 13:40:04.937639
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-24 13:40:07.041544
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        ui = UDNEmbedIE()
    except Exception as e:
        print("Constructor of class UDNEmbedIE failed with Exception %s" % str(e))



# Generated at 2022-06-24 13:40:12.405593
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/embed/news/300040'
    UDNEmbedIE._VALID_URL = r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    # Constructor
    udn_embed = UDNEmbedIE('test')
    # Test if _PROTOCOL_RELATIVE_VALID_URL is updated correctly
    assert udn_embed._VALID_URL == r'https?://video\.udn\.com/embed/news/300040'
    # Test if get_valid_url() returns the original url

# Generated at 2022-06-24 13:40:21.684853
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_queue = [
        {"url": "http://video.udn.com/embed/news/300040",
         "only_matching": True,
         "url_regex": r'^https?:\/\/video\.udn\.com\/(?:embed|play)\/news\/300040$'},
        {"url": "https://video.udn.com/embed/news/300040",
         "only_matching": True,
         "url_regex": r'^https?:\/\/video\.udn\.com\/(?:embed|play)\/news\/300040$'}
    ]
    for expected_result in url_queue:
        # print(expected_result)
        yield UDNTest.get_info_extractor, expected_result



# Generated at 2022-06-24 13:40:28.311793
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_udn = UDNEmbedIE()
    assert class_udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert class_udn._VALID_URL == r'https?:' + class_udn._PROTOCOL_RELATIVE_VALID_URL
    assert class_udn.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:40:32.248483
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(
        list(UDNEmbedIE._build_video_regex(UDNEmbedIE._VALID_URL))
        ==
        list(UDNEmbedIE._build_video_regex(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)))

# Generated at 2022-06-24 13:40:33.347811
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(InfoExtractor())

# Generated at 2022-06-24 13:40:34.675016
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    InfoExtractor( -1 ).register_ie( UDNEmbedIE( -1 ) )

# Generated at 2022-06-24 13:40:35.684445
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:40:45.256528
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.IE_DESC = "test"
    ie._TESTS = [{
        'url': 'test',
        'info_dict': {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
        'expected_warnings': ['Failed to parse JSON Expecting value'],
    }]
    ie._VALID_URL = UDNEmbedIE._VALID_URL
    ie._PROTOC

# Generated at 2022-06-24 13:40:51.581669
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    s = UDNEmbedIE()
    assert s._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert s._VALID_URL == r'https?|http://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert s.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:40:54.278200
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        udnEmbedIE = UDNEmbedIE()
        print('[OK] UDNEmbedIE instance created')
    except:
        print('[ERROR] Fail to create UDNEmbedIE instance')
        

# Generated at 2022-06-24 13:41:02.163550
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    try:
        from urllib.parse import urlparse
    except ImportError:
        from urlparse import urlparse

    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:41:10.533577
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(ie._TESTS[0]['url'] == url)
    assert(ie._TESTS[0]['info_dict']['id'] == '300040')

# Generated at 2022-06-24 13:41:11.639198
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:41:14.296017
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import test_extractor
    tc = test_extractor(UDNEmbedIE)
    # Test UDNEmbedIE constructor
    assert tc # Placeholder

# Generated at 2022-06-24 13:41:16.378356
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    assert ie._match_id(url) == "300040"
    assert ie._real_extract(url)

# Generated at 2022-06-24 13:41:18.250703
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert 'http-mp4' == ie._search_regex(r'http-(.+)', 'http-mp4', 'id')

# Generated at 2022-06-24 13:41:19.514127
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # Constructor
    assert isinstance(UDNEmbedIE(), InfoExtractor)



# Generated at 2022-06-24 13:41:20.646485
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:41:22.257303
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:41:26.722162
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test1: with protocol relative URL
    UDNEmbedIE(None)._real_extract('//video.udn.com/embed/news/300040')
    # test2: with absolute URL
    UDNEmbedIE(None)._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:41:35.273012
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..compat import StringIO
    from ..extractor import DummyExtractor
    from ..downloader import FakeDownloader
    from ..formatter import DummyFormatter
    from ..downloader.http import HttpRequest

    # Test that correct URL is returned
    udn_extractor = UDNEmbedIE(DummyExtractor())
    test_url = 'http://video.udn.com/embed/news/300040'
    print('test_url: ', test_url)
    assert(udn_extractor._match_id(test_url) == '300040')
    assert(udn_extractor._real_extract(test_url))

    # Test that correct download url is returned with m3u8
    downloader = FakeDownloader()

# Generated at 2022-06-24 13:41:41.653660
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.IE_DESC == '聯合影音'
    assert IE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._VALID_URL == r'https?:' + IE._PROTOCOL_RELATIVE_VALID_URL
    assert isinstance(IE._TESTS, list) == True

# Generated at 2022-06-24 13:41:45.139415
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)
    return

# Generated at 2022-06-24 13:41:54.470128
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert(ie.IE_NAME == 'udnembed')
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')
    assert(ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')



# Generated at 2022-06-24 13:41:56.255053
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie is not None

# Generated at 2022-06-24 13:41:57.313255
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()


# Generated at 2022-06-24 13:41:58.273993
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:42:03.206411
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE()
    tester._match_id(
        'http://video.udn.com/embed/news/300040') == '300040'
    tester.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:42:05.607740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test class constructor of class UDNEmbedIE."""
    UDNEmbedIE(InfoExtractor())



# Generated at 2022-06-24 13:42:07.957154
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url="https://video.udn.com/embed/news/300040"
    UDNEmbedIE(url)


# Generated at 2022-06-24 13:42:17.863818
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    for url in (
            'http://video.udn.com/embed/news/300040',
            'https://video.udn.com/embed/news/300040',
            '//video.udn.com/embed/news/300040'
    ):
        assert ie.suitable(url)
        assert ie.IE_NAME == ie.determine_ie(url).IE_NAME, url
    assert not ie.suitable('http://example.com')
    assert not ie.suitable('https://example.com')
    assert not ie.suitable('http://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:42:24.756161
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test that invalid URL raise exception
    # InvalidURL
    try:
        UDNEmbedIE()._match_id('http://invalidUrl/')
        assert False
    except:
        assert True

    # ValidURL
    url = 'http://xxx.xxx.xxx.xxx/'
    assert UDNEmbedIE()._match_id(url) == ''

    # test that invalid video_type raise exception
    # InvalidURL
    try:
        UDNEmbedIE()._real_extract('http://invalidUrl/')
        assert False
    except:
        assert True

    # InvalidVideoType
    try:
        UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
        assert False
    except:
        assert True

    # ValidURL


# Generated at 2022-06-24 13:42:28.109522
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._REGEX == r'https?:(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'



# Generated at 2022-06-24 13:42:33.692294
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, '_REAL_EXTENSION') == False
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:39.840788
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_youtube import assertRegex
    from .test_youtube import YoutubeBaseInfoExtractor
    udn_embed_ie = UDNEmbedIE()
    assert isinstance(udn_embed_ie, YoutubeBaseInfoExtractor)
    # Check if function _match_id() from YoutubeBaseInfoExtractor is used correctly
    assertRegex(udn_embed_ie, udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL, r'id')

# Generated at 2022-06-24 13:42:40.682579
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:42:42.852964
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnVid = UDNEmbedIE()
    assert udnVid


# Generated at 2022-06-24 13:42:43.365307
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert type(UDNEmbedIE) == type

# Generated at 2022-06-24 13:42:44.269999
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:42:51.783968
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:53.466724
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _ = UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:43:01.904851
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:03.412975
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(type(ie))
    assert(type(ie) != None)

# Generated at 2022-06-24 13:43:05.325032
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    url = 'http://video.udn.com/embed/news/' + video_id
    UDNEmbedIE()._real_initialize()
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:43:10.998520
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    with open("test_data/test_udn_embed_ie.html", encoding='utf-8') as f:
        page = f.read()
    options_str = re.search(r'var\s+options\s*=\s*([^;]+);', page).group(1)
    trans_options_str = js_to_json(options_str)
    options = json.loads(trans_options_str)
    assert 'video' in options
    assert 'title' in options
    assert 'poster' in options
    assert options['poster'] == '//i.imgur.com/OZq3qZa.jpg'


# Generated at 2022-06-24 13:43:20.096591
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == '(?:http:|https:)' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:28.813190
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedInstance = UDNEmbedIE()
    assert udnEmbedInstance.IE_DESC == '聯合影音'
    assert udnEmbedInstance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbedInstance._VALID_URL == r'https?:' + udnEmbedInstance._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:32.448878
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_test = UDNEmbedIE()
    assert udn_embed_test._VALID_URL == UDNEmbedIE._VALID_URL
    assert udn_embed_test._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:34.008979
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE.
    """
    UDNEmbedIE()

# Generated at 2022-06-24 13:43:41.174884
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_str = 'http://video.udn.com/embed/news/300040'
    url = url_str
    assert url.encode('utf8') == url
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDNEmbed'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie._match_id(url_str) == '300040'

# Generated at 2022-06-24 13:43:46.855588
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:48.635982
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:43:56.054086
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    if not ie.suitable('https://video.udn.com/embed/news/300040'):
        print('Warning: UDNEmbedIE does not support https://video.udn.com/embed/news/300040')
    if not ie.suitable('http://video.udn.com/embed/news/300040'):
        print('Warning: UDNEmbedIE does not support http://video.udn.com/embed/news/300040')
    if not ie.suitable('https://video.udn.com/play/news/300040'):
        print('Warning: UDNEmbedIE does not support https://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:43:57.840162
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_NAME == 'udn'



# Generated at 2022-06-24 13:44:04.306327
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        # Test valid URL
        UDNEmbedIE(UDNEmbedIE._VALID_URL, 'video.udn.com')
    except:
        raise AssertionError('Test valid URL failed')

    try:
        # Test invalid URL
        UDNEmbedIE("Invalid URL", 'video.udn.com')
    except AssertionError:
        return
    except:
        raise AssertionError('Test valid URL failed')
    raise AssertionError('Test valid URL failed')

# Generated at 2022-06-24 13:44:08.499014
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    # Test case #1
    try:
        ie = UDNEmbedIE()
        print(ie.IE_DESC)
        # Test case #2
        ie = UDNEmbedIE(test=True)
        print(ie.IE_DESC)
    except Exception as e:
        print('test_UDNEmbedIE: ' + str(e))


# Generated at 2022-06-24 13:44:17.031737
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:44:19.713621
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from you_get.extractors.udn_embed import UDNEmbedIE

if __name__=='__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:44:21.606824
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:44:24.122270
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test whether UDNEmbedIE constructor works.
    """
    instance = UDNEmbedIE()
    assert isinstance(instance, InfoExtractor)



# Generated at 2022-06-24 13:44:25.945869
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _ = UDNEmbedIE

# Generated at 2022-06-24 13:44:34.820912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    # Check _VALID_URL and _PROTOCOL_RELATIVE_VALID_URL
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Check regex
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-24 13:44:36.309158
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'UDNEmbed'

# Generated at 2022-06-24 13:44:40.788386
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:43.159321
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE(None)
    print ('udn_embed_ie:', udn_embed_ie)


# Generated at 2022-06-24 13:44:45.788316
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:55.433848
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest

    class TestUDNEmbedIE(unittest.TestCase):
        def setUp(self):
            self.udn_embed_ie = UDNEmbedIE({'downloader': None})

        def test_1(self):
            self.udn_embed_ie.url = 'http://video.udn.com/embed/news/300040'
            self.assertEqual(self.udn_embed_ie.match_id, '300040')

        def test_2(self):
            self.udn_embed_ie.url = 'http://video.udn.com/play/news/300040'
            self.assertEqual(self.udn_embed_ie.match_id, '300040')

        def test_3(self):
            self.udn_embed_

# Generated at 2022-06-24 13:44:57.626018
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:44:59.081062
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udni = UDNEmbedIE()
    assert isinstance(udni, InfoExtractor)

# Generated at 2022-06-24 13:45:03.222566
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # This can be a resolver test, but the video with id "300040" is not available any more.
    # So we can just test the constructor of class UDNEmbedIE.
    from youtube_dl.extractor.udn import UDNEmbedIE
    url = 'https://video.udn.com/news/300040'
    assert re.match(UDNEmbedIE._VALID_URL, url)

# Generated at 2022-06-24 13:45:05.699691
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._TESTS == UDNEmbedIE._TESTS

# Generated at 2022-06-24 13:45:08.976137
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:45:11.313716
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructing a UDNEmbedIE object with a correct pattern URL should not raise any error.
    """
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:45:12.109237
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:45:14.438567
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    instance = UDNEmbedIE()
    instance.suitable(url)
    instance.extract(url)

# Generated at 2022-06-24 13:45:19.030424
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'



# Generated at 2022-06-24 13:45:20.310394
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Nothing to test, the class constructor is trivial
    UDNEmbedIE(None)

# Generated at 2022-06-24 13:45:31.882972
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	from __main__ import UDNEmbedIE
	info_extractor = UDNEmbedIE('test_UDNEmbedIE')
	assert info_extractor.IE_DESC == '聯合影音'
	assert re.match(info_extractor._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040') is not None
	assert re.match(info_extractor._PROTOCOL_RELATIVE_VALID_URL, 'https://video.udn.com/play/news/300040') is not None
	assert re.match(info_extractor._VALID_URL, 'http://video.udn.com/embed/news/300040') is not None

# Generated at 2022-06-24 13:45:38.559130
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    url = 'https://video.udn.com/play/news/303776'
    # Note: the video_id is not set in this test

    ie = UDNEmbedIE()
    video_id = ie._match_id(url)
    assert video_id is not None, "The video id should not be None"

    # A basic test to verify if the web page can be downloaded
    # is_success == 0 means success, otherwise failure.
    is_success = ie._download_webpage(url, video_id)
    assert is_success == 0

# Generated at 2022-06-24 13:45:41.671898
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for test in UDNEmbedIE._TESTS:
        url = test['url']
        assert UDNEmbedIE._is_valid_url(url), '%s is invalid url' % url


# Generated at 2022-06-24 13:45:51.630247
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert len(ie._TESTS) == 3
    test = ie._TESTS[0]
    assert test['url'] == 'http://video.udn.com/embed/news/300040'
    info_dict = test['info_dict']
    assert info_dict['id'] == '300040'
    assert info_dict['ext'] == 'mp4'
    assert info

# Generated at 2022-06-24 13:45:52.236569
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie

# Generated at 2022-06-24 13:45:58.440238
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info = UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
    assert info['id'] == '300040'
    assert len(info['formats']) > 0
    assert info['title'] == '生物老師男變女 全校挺"做自己"'
    assert re.match(r'https?://.*\.jpg$', info['thumbnail']) != None
    assert info['thumbnail'].startswith('http://')

# Generated at 2022-06-24 13:46:09.326285
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url in ('http://video.udn.com/embed/news/300040',
                'https://video.udn.com/embed/news/300040',):
        u = UDNEmbedIE()
        assert isinstance(u, InfoExtractor)
        assert u.IE_NAME == 'video.udn.com'
        assert u.IE_DESC == '聯合影音'
        assert u._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
        assert u._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:18.245160
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.IE_NAME == 'udn'
    assert u.IE_DESC == '聯合影音'
    assert u._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:25.969098
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert i.IE_DESC == '聯合影音'
    assert i._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:46:30.555924
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040' # Protocol relative URL
    valid_url = UDNEmbedIE._VALID_URL
    match_url_object = re.match( valid_url, url )
    print( match_url_object.group(0) )

# Unit test the constructor of class RegexNotFoundError

# Generated at 2022-06-24 13:46:42.236971
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert determine_ext(ie._VALID_URL) is None
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:46:44.918390
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    udn._real_extract(url)
    assert(udn.query.id == '300040')

# Generated at 2022-06-24 13:46:45.776682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:53.613680
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for _VALID_URL
    valid_url = 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE.suitable(valid_url), 'suitable() returns False'
    assert UDNEmbedIE.IE_NAME == 'udn', '_VALID_URL matches the wrong IE'

    # test for _PROTOCOL_RELATIVE_VALID_URL
    protocol_relative_valid_url = '//video.udn.com/embed/news/300040'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, 'protocol_relative_valid_url is empty'

# Generated at 2022-06-24 13:47:03.526439
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:47:07.317315
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udn_ie = UDNEmbedIE()
    try:
        assert udn_ie._match_id(url) == '300040'
    except AssertionError as e:
        raise e

# Generated at 2022-06-24 13:47:12.595036
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test class constructor"""
    import youtube_dl.extractor.udn

    udn = youtube_dl.extractor.udn.UDNEmbedIE()
    assert udn is not None, "UDNEmbedIE should not be None"
    assert isinstance(udn, youtube_dl.extractor.udn.UDNEmbedIE), "UDNEmbedIE should be instance of UDNEmbedIE"

# Generated at 2022-06-24 13:47:13.694044
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE._TESTS)



# Generated at 2022-06-24 13:47:14.224400
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE

# Generated at 2022-06-24 13:47:17.498777
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # Check that the regular expression from class is used
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:21.605153
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == '(?i)https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:30.159178
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    # TODO: the test data is fake, and the content of returned dict is not same as the expected dict
    # assert ie._TESTS[0] == {
    #     'url': 'http://video.udn.com/embed/news/300040',
    #     'info_dict': {
    #         'id': '300040',
    #         'ext': 'mp4',


# Generated at 2022-06-24 13:47:40.580411
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'
    assert ie.IE_NAME is None

# Generated at 2022-06-24 13:47:45.690139
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert udn is not None
    assert udn._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:51.056934
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import test_protocol_relative_urls
    import sys

    if sys.version_info >= (3, 6):
        # UDNEmbedIE is a subclass of InfoExtractor
        UDNEmbedIE()
        # test_protocol_relative_urls is a function which is declared after UDNEmbedIE.
        test_protocol_relative_urls(UDNEmbedIE)

# Generated at 2022-06-24 13:47:58.515684
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # The test code calculates the SHA-1 hash of a URL and compare with pre-computed hash
    # On the one hand, it verifies that hash algorithm works; on the other hand, it helps
    # to ensure that there is no change in the URL.
    #
    # This is just a temporary solution, because it is better to check if the URL is available
    # rather than using hash. The test code will be updated later.
    import hashlib
    ie = UDNEmbedIE({})
    # this URL should be in the 'udn_videos' table
    url = 'https://video.udn.com/embed/news/300040'
    page = ie._download_webpage(url, 300040)
    print(page)

# Generated at 2022-06-24 13:48:04.647102
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from . import UDNEmbedIE
    udne = UDNEmbedIE('http://www.udn.com/video/play/2221', 'http://video.udn.com/services/player/bins/')
    assert udne.__class__ == UDNEmbedIE
    assert udne.url == 'http://video.udn.com/services/player/bins/'

# Generated at 2022-06-24 13:48:05.609872
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()

# Generated at 2022-06-24 13:48:10.397724
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:17.298514
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # Note that this URL is from _TESTS,
    # which is because it doesn't require network connection to get the result.
    assert ie.suitable('http://video.udn.com/embed/news/300040')
    # This class is abstract, so it shouldn't be used by YouTubeDL directly.
    assert not ie.suitable('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:48:24.096748
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # init pattern validator
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    UDNEmbedIE._VALID_URL = r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    
    # init class
    UDNEmbedIE()

# Generated at 2022-06-24 13:48:30.271835
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:48:35.037609
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE(None)
    assert(udn_embed.IE_NAME == 'udn')
    assert(udn_embed._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-24 13:48:36.897612
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:48:45.776983
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert type(UDNEmbedIE._TESTS) == list
    t = UDNEmbedIE._TESTS[0]
    assert 'url' in t
    assert 'info_dict' in t
    assert 'params' in t
    assert 'expected_warnings' in t
    assert type(UDNEmbedIE._TESTS[1]) == dict
    assert 'url' in UDNEmbedIE._TESTS[1]

# Generated at 2022-06-24 13:48:57.562027
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    constructor_args_num = len(ie.__init__.__code__.co_varnames) - 1
    assert constructor_args_num == 0, 'Number of arguments except self should be 0'

    test_urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040'
    ]
    for url in test_urls:
        valid, reason = ie._match_id(url)
        assert valid is True, reason

    invalid_urls = [
        'http://video.udn.com/play/news/300040'
    ]
    for url in invalid_urls:
        valid, reason = ie._match_id(url)
        assert valid is False

# Generated at 2022-06-24 13:49:05.776610
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    IE_DESC = '聯合影音'
    UDNEmbedIE_PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    UDNEmbedIE_VALID_URL = r'https?:' + UDNEmbedIE_PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:49:08.137796
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'udn_embed'
    assert ie.ie_desc() == '聯合影音'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS

# Generated at 2022-06-24 13:49:09.729334
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert isinstance(UDNEmbedIE(UDNEmbedIE),UDNEmbedIE)

# Generated at 2022-06-24 13:49:10.602524
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:49:17.199791
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_out = UDNEmbedIE()
    # assertEqual
    assert(udn_out.IE_DESC == '聯合影音')
    # assertRaises
    # assertIsNone
    # assertIsNotNone
    # assertTrue
    # assertFalse
    # assertIsInstance
    # assertIn
    # assertNotIn
    # assertIs

# Generated at 2022-06-24 13:49:23.264961
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE().IE_NAME == 'udn'
    assert UDNEmbedIE().IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:49:29.330663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.match(_PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.match(_VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert re.match(_VALID_URL, 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:49:32.867742
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test constructor
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
