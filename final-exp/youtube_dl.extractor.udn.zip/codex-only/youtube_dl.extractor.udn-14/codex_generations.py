

# Generated at 2022-06-24 13:39:41.716306
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_inst = UDNEmbedIE()
    assert test_inst._match_id(
        'http://video.udn.com/embed/news/300040') == '300040'
    assert test_inst._match_id(
        'https://video.udn.com/embed/news/300040') == '300040'
    assert not test_inst._match_id(
        'http://video.udn.com/play/news/300040')
    assert test_inst._match_id(
        'https://video.udn.com/play/news/300040') == '300040'
    assert not test_inst._match_id(
        'http://video.udn.com/play/news/300040/')

# Generated at 2022-06-24 13:39:43.875351
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_test = UDNEmbedIE()
    ie_test._match_id('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:39:55.649282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:40:05.271064
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()._real_initialize(url)
    print(ie.IE_DESC)
    print(ie._VALID_URL)
    video_id = ie._match_id(url)
    print(video_id)
    page = ie._download_webpage(url, video_id)
    print(page)
    options_str = ie._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', page, 'options')
    print(options_str)

# Test method extract of class UDNEmbedIE

# Generated at 2022-06-24 13:40:06.036783
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    global UDNEmbedIE
    UDNEmbedIE

# Generated at 2022-06-24 13:40:08.469559
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(str(ie) == '聯合影音')
    assert(ie._real_initialize() == None)
    assert(ie._real_extract == UDNEmbedIE._real_extract)

# Generated at 2022-06-24 13:40:14.002389
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url =  "//video.udn.com/embed/news/300040"
    u = UDNEmbedIE()
    assert u.IE_NAME == 'UDNEmbedIE'
    assert u.IE_DESC == '聯合影音'
    assert u._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u._VALID_URL == 'https?:' + u._PROTOCOL_RELATIVE_VALID_URL
    assert u._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert u._TESTS[0]['info_dict']['id'] == '300040'
   

# Generated at 2022-06-24 13:40:18.631225
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    UDNEmbedIE._TESTS[0].update({'expected_warnings': []})
    UDNEmbedIE._TESTS[0]["info_dict"]["title"] = '生物老師男變女：全校挺「做自己」'

# Generated at 2022-06-24 13:40:21.394251
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)

    assert ie._match_id(url) == '300040'

# Generated at 2022-06-24 13:40:22.686088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn_embed'

# Generated at 2022-06-24 13:40:33.494547
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:40:39.170435
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/300040'
    assert ie._match_id(url) == '300040'
    assert ie._match_id('//video.udn.com/play/news/123456') == '123456'
    assert ie._match_id('https://video.udn.com/embed/news/1234567') == '1234567'

# Generated at 2022-06-24 13:40:42.454043
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    print(('UDNEmbedIE instace created: %s' % instance))
    # print(('UDNEmbedIE instace created: %s' % dir(instance)))



# Generated at 2022-06-24 13:40:43.438851
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:40:46.706477
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    my_UDNEmbedIE = UDNEmbedIE();
    print(my_UDNEmbedIE)

test_UDNEmbedIE()

# Generated at 2022-06-24 13:40:48.861406
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbed', 'https://video.udn.com/play/news/303776')


# Generated at 2022-06-24 13:40:50.218371
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    global UDNEmbedIE
    UDNEmbedIE('test', True)


# Generated at 2022-06-24 13:40:51.062612
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:40:57.170687
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # _PROTOCOL_RELATIVE_VALID_URL is a class variable,
    # so we need to access it by using the class name.
    test_url = '//video.udn.com/embed/news/300040'
    match = re.match(ie._PROTOCOL_RELATIVE_VALID_URL, test_url)
    assert(match)
    assert(match.group('id') == '300040')

# Generated at 2022-06-24 13:41:01.532589
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert all(UDNEmbedIE.suitable(url) for url in [
        # Protocol relative URLs
        'http://video.udn.com/embed/news/123',
        'https://video.udn.com/embed/news/123',
    ])

# Generated at 2022-06-24 13:41:06.919674
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    construct test
    """
    ie = UDNEmbedIE()
    # check format_id
    assert ie._format_id('UDNEmbed', 'mp4') == 'UDNEmbed-http-mp4', 'format_id incorrect'
    assert ie._format_id('UDNEmbed', 'm3u8') == 'UDNEmbed-http-m3u8', 'format_id incorrect'
    assert ie._format_id('UDNEmbed', 'f4m') == 'UDNEmbed-http-f4m', 'format_id incorrect'


# Generated at 2022-06-24 13:41:11.197933
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    my_UDNEmbedIE = UDNEmbedIE()
    my_UDNEmbedIE._real_extract("https://video.udn.com/embed/news/300040")

#unit test for _match_id method in class InfoExtractor

# Generated at 2022-06-24 13:41:13.174223
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_udn_embed_ie = UDNEmbedIE()
    assert class_udn_embed_ie != None

# Generated at 2022-06-24 13:41:15.182119
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._match_id('https://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-24 13:41:20.297026
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie._match_id('https:' + ie._PROTOCOL_RELATIVE_VALID_URL) == ie._match_id('http:' + ie._PROTOCOL_RELATIVE_VALID_URL)
    assert ie._match_id('https:' + ie._PROTOCOL_RELATIVE_VALID_URL) == ie._match_id(url)

# Generated at 2022-06-24 13:41:26.177212
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    uIE = UDNEmbedIE();

# Generated at 2022-06-24 13:41:27.159509
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:41:29.403093
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    # Test whether the constructor of the class is working.
    assert(udnEmbedIE)

# Generated at 2022-06-24 13:41:31.998890
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Neither the class constructor nor its __init__() take arguments
    udne = UDNEmbedIE()
    assert udne is not None


# Generated at 2022-06-24 13:41:37.707260
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'udn_embed', "ie_key is wrong"
    assert ie.ie_desc() == '聯合影音', "ie_desc is wrong"
    assert ie.webpage_url_re() == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)', "webpage_url_re is wrong"

# Generated at 2022-06-24 13:41:43.791742
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result = UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
    assert result['id'] == '300040'
    assert result['formats'][0]['format_id'] == 'http-hls'
    assert result['formats'][0]['url'] == 'http://vod.udn.com/udnnews/300040/300040_1920p_4000.m3u8'

    result = UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')
    assert result['id'] == '300040'
    assert result['formats'][0]['format_id'] == 'http-hls'

# Generated at 2022-06-24 13:41:45.191166
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert isinstance(obj, UDNEmbedIE)


# Generated at 2022-06-24 13:41:48.661245
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()
# End of test

# Generated at 2022-06-24 13:41:53.066581
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # go to the test case
    IE = UDNEmbedIE()
    # call _real_extract
    IE._real_extract('http://video.udn.com/embed/news/300040')

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:41:55.974164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert len(UDNEmbedIE._TESTS) == 3
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE(UDNEmbedIE._downloader)._real_extract(url)

# Generated at 2022-06-24 13:41:59.440873
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:42:01.858337
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._real_extract('http://video.udn.com/embed/news/300040', '300040')

# Generated at 2022-06-24 13:42:05.724245
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:09.224876
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')



# Generated at 2022-06-24 13:42:12.046037
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:19.085276
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = 'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:42:21.059239
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() in [
        'UDNEmbed'
    ]


# Generated at 2022-06-24 13:42:21.852384
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor
    UDNEmbedIE()

# Generated at 2022-06-24 13:42:30.300178
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for normal case
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'^https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert not ie._GEO_COUNTRIES

    # Test for static method
    ie = InfoExtractor.for_site('udn')
    assert isinstance(ie, UDNEmbedIE)
    assert ie._VALID_URL == r'^https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert not ie._GEO_COUNTRIES

# Generated at 2022-06-24 13:42:33.522735
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:34.454644
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit = UDNEmbedIE(None)

# Generated at 2022-06-24 13:42:36.174525
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    print(udn)

# Generated at 2022-06-24 13:42:40.402895
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # This URL i copied from _TESTS
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE(url)
    info_dict = udn_embed_ie._info_dict
    assert info_dict["id"] == '300040'

# Generated at 2022-06-24 13:42:49.385063
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert len(ie._TESTS) == 3

# Generated at 2022-06-24 13:42:50.194962
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.test()

# Generated at 2022-06-24 13:42:54.619709
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnURL = 'https://video.udn.com/news/303776'
    result = UDNEmbedIE()._extract_video_url_info(udnURL)
    print(result)
    assert result['ext'] == 'mp4'

# Generated at 2022-06-24 13:43:01.733346
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed.ie_key() == 'udnembed'
    assert udn_embed.ie_desc() == '聯合影音'
    assert udn_embed.suitable('http://video.udn.com/embed/news/300040')
    assert udn_embed.suitable('https://video.udn.com/embed/news/300040')
    assert not udn_embed.suitable('http://video.udn.com/play/news/300040')
    assert not udn_embed.suitable('https://video.udn.com/play/news/300040')

# Generated at 2022-06-24 13:43:06.738632
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    target = UDNEmbedIE()
    assert target.IE_DESC == '聯合影音'
    assert target._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert target._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(target._TESTS) == 3


# Generated at 2022-06-24 13:43:14.947941
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    info = UDNEmbedIE()._real_extract(url)
    assert info['title'] == '生物老師男變女 全校挺"做自己"'
    assert info["thumbnail"] == "http://v.img.udn.com.tw/v2/img/udn/udn_logo.png"
    assert len(info['formats']) == 3


# Generated at 2022-06-24 13:43:17.658502
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    url_protocol_relative = '//video.udn.com/embed/news/300040'
    url_absolute = 'http:' + url_protocol_relative
    assert udn_ie.suitable(url_protocol_relative) == True
    assert udn_ie.suitable(url_absolute) == True
    assert udn_ie._real_extract(url_absolute)

# Generated at 2022-06-24 13:43:19.363269
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE"""
    unit_test = UDNEmbedIE()

# Generated at 2022-06-24 13:43:20.961977
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(_PROTOCOL_RELATIVE_VALID_URL)._VALID_URL == _VALID_URL

# Generated at 2022-06-24 13:43:24.915900
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    udnei = UDNEmbedIE('https://video.udn.com/play/news/300040')
    assert udnei.SUFFIX == 'Embed'
    assert udnei.IE_NAME == 'UDNEmbed'

# Generated at 2022-06-24 13:43:33.265156
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import json
    import BASE.UnitTest

    # Python 2

# Generated at 2022-06-24 13:43:38.180662
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'
    udne = UDNEmbedIE()
    assert udne._match_id(url) == video_id
    assert udne._match_id(url) == udne._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:43:44.819345
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.get_protocol_relative_url().search(r'^//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)$', re.I)
    assert udn.get_protocol_relative_url().search(r'^//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)$', re.I).group('id') == '300040'
    assert udn.get_protocol_relative_url().search(r'^//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)$', re.I).group('id') != '3000401'

# Generated at 2022-06-24 13:43:49.562549
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
  print("Testing class UDNEmbedIE")
  ie = UDNEmbedIE()
  url = 'https://video.udn.com/embed/news/300040'
  assert ie._match_id(url) == '300040'
  assert ie._VALID_URL == ie.IE_DESC + url[str(url).rfind(':')+1:]

# Generated at 2022-06-24 13:43:52.047859
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("https://video.udn.com/embed/news/300040")._real_extract("https://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:43:58.438906
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	try:
		ie = UDNEmbedIE()
		assert ie
		assert ie._PROTOCOL_RELATIVE_VALID_URL
		assert ie._VALID_URL
		assert ie._TESTS
		assert ie._real_extract
		assert ie.IE_DESC
	except (AssertionError, NameError):
		return
	return ie



# Generated at 2022-06-24 13:44:04.193621
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._TESTS[0]['url'] = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE._TESTS[1]['url'] = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE._TESTS[2]['url'] = 'http://video.udn.com/play/news/303776'


# Generated at 2022-06-24 13:44:10.496434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbed_test = UDNEmbedIE()

    assert UDNEmbed_test._PROTOCOL_RELATIVE_VALID_URL == \
        r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbed_test._VALID_URL == \
        r'https?:' + UDNEmbed_test._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbed_test.IE_DESC == '聯合影音'
    for TESTS in UDNEmbed_test._TESTS:
        assert 'url' in TESTS
        assert 'info_dict' in TESTS

# Generated at 2022-06-24 13:44:12.333746
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    assert udneie.IE_NAME == 'udn'

# Generated at 2022-06-24 13:44:15.196710
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test udnebedie.UDNEmbedIE."""
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udnvideo'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:44:16.266222
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ydl = UDNEmbedIE()
    assert ydl is not None

# Generated at 2022-06-24 13:44:17.615256
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-24 13:44:19.263192
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

test_UDNEmbedIE()

# Generated at 2022-06-24 13:44:22.636198
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._TESTS[0]['expected_warnings'] == [u'Failed to parse JSON Expecting value']

# Generated at 2022-06-24 13:44:32.985118
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        import json
    except ImportError:
        import simplejson as json
    URL = 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:44:37.972431
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    udn_embed_ie = UDNEmbedIE()
    unittest.TestCase().assertEqual(udn_embed_ie.IE_DESC, '聯合影音')

# Generated at 2022-06-24 13:44:45.268358
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/play/news/303776'
    inst = UDNEmbedIE()
    assert(inst._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(inst._VALID_URL == 'https?:' + inst._PROTOCOL_RELATIVE_VALID_URL)
    assert(inst.IE_DESC == '聯合影音')
    assert(inst._match_id(url) == '303776')

# Generated at 2022-06-24 13:44:54.064951
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert udn.IE_DESC == '聯合影音'
    assert udn._TESTS[0].get('url') == 'http://video.udn.com/embed/news/300040'
    assert udn._TESTS[1].get('url') == 'https://video.udn.com/embed/news/300040'
    assert udn._TESTS[2].get('url') == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-24 13:44:55.642520
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test
    ie = UDNEmbedIE()
    # print ie.get_url()


# Generated at 2022-06-24 13:44:56.466725
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:44:57.241551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('udn')

# Generated at 2022-06-24 13:44:59.662033
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import doctest
    udn = UDNEmbedIE()
    doctest.testmod(udn)


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:45:04.729196
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test_obj = UDNEmbedIE()
    assert unit_test_obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert unit_test_obj._VALID_URL == r'https?:' + unit_test_obj._PROTOCOL_RELATIVE_VALID_URL
    assert unit_test_obj.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:45:13.894144
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn_embed_ie._TESTS[0]['info_dict']['id'] == '300040'


# Generated at 2022-06-24 13:45:20.190346
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url in [
            "http://video.udn.com/embed/news/300040",
            "https://video.udn.com/embed/news/300040"]:
        assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
        assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, url)

# Generated at 2022-06-24 13:45:23.728901
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test: __init__ of class UDNEmbedIE
    """
    UDNEmbedIE()


# Generated at 2022-06-24 13:45:33.850743
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Parse argv options
    from argparse import ArgumentParser
    parser = ArgumentParser(description='Test for constructor of class UDNEmbedIE')
    parser.add_argument(dest='url', nargs='?', type=str,
                        help='URL of video webpage to be tested')
    args = parser.parse_args()

    # Begin to extract video URL
    print("Checking video webpage '%s'" % args.url)
    info_extractor = UDNEmbedIE()
    video_info = info_extractor.extract(args.url)
    print("\nVideo information:")
    print(video_info)

    print("\nVideo format list:")
    for a_format in video_info['formats']:
        print(a_format)


# Generated at 2022-06-24 13:45:36.787630
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # url = 'http://video.udn.com/embed/news/300040'
    url = 'a'
    pp = ie.extract(url)
    print (pp)

# Generated at 2022-06-24 13:45:41.542986
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-24 13:45:46.040668
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _VALID_URL = r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    ie = UDNEmbedIE()
    m = ie._VALID_URL_RE.match(_VALID_URL)
    assert m
    assert ie._match_id(m) == '300040'

# Generated at 2022-06-24 13:45:52.238254
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('a', 'b', 'c')
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie.suitable('unit_test_dummy_url') == False
    assert ie.suitable('http://video.udn.com/embed/news/300040') == True
    assert ie.suitable('http://video.udn.com/play/news/300040') == True

# Generated at 2022-06-24 13:45:55.710049
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-24 13:45:58.918695
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ins = UDNEmbedIE()
    assert ins._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ins._VALID_URL == r'https?:' + ins._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:00.549375
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    return ie

# Generated at 2022-06-24 13:46:01.531282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    raise NotImplementedError('TODO')

# Generated at 2022-06-24 13:46:12.142783
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for valid URL
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie.match(url)
    assert '300040' in ie.match(url)
    assert ie.IE_NAME in ie.match(url)
    assert ie.IE_DESC in ie.match(url)
    assert ie._VALID_URL in ie.match(url)
    # Test for valid URL with protocol-relative prefix
    url = '//video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie.match(url)
    assert '300040' in ie.match(url)
    assert ie.IE_NAME in ie.match(url)
    assert ie.IE_DES

# Generated at 2022-06-24 13:46:14.021871
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(
        UDNEmbedIE.ie_key(),
        'http://video.udn.com/embed/news/300040',
        {
            'skip_download': True,
        }
    )

# Generated at 2022-06-24 13:46:17.100073
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.IE_NAME == 'udn'
    assert IE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:46:27.442993
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Test: UDNEmbedIE")
    UDNEmbedIE.IE_DESC = '聯合影音'

    test_url_1 = 'http://video.udn.com/embed/news/300040'
    test_url_2 = 'http://video.udn.com/embed/news/300040'
    test_url_3 = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE.IE_DESC = '聯合影音'

    assert UDNEmbedIE._match_id(test_url_1) == '300040'
    assert UDNEmbedIE._match_id(test_url_2) == '300040'

# Generated at 2022-06-24 13:46:28.726291
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert False

# Generated at 2022-06-24 13:46:35.902111
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._VALID_URL == r'https?:' + IE._PROTOCOL_RELATIVE_VALID_URL
    assert IE.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:46:41.229877
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE('http://video.udn.com/news/300040')
    assert udn.ie_key() == 'Udn'
    assert udn.ie_key() == 'Udn:embed'
    assert udn.ie_key() == 'Udn:play'
    assert udn.ie_key() == 'Udn'

# Generated at 2022-06-24 13:46:47.218311
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .. import UDNEmbedIE_instance
    assert UDNEmbedIE_instance is not None
    assert UDNEmbedIE_instance.IE_NAME == 'udn'
    assert UDNEmbedIE_instance.IE_DESC == UDNEmbedIE.IE_DESC
    assert UDNEmbedIE_instance._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE_instance._TESTS == UDNEmbedIE._TESTS

# Generated at 2022-06-24 13:46:52.518359
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_info_IE = UDNEmbedIE()
    video_info_IE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/embed/news/300040'
    video_info_IE._VALID_URL = r'https?:' + video_info_IE._PROTOCOL_RELATIVE_VALID_URL
    assert video_info_IE._VALID_URL == r'https?://video\.udn\.com/embed/news/300040'



# Generated at 2022-06-24 13:46:53.392992
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:47:02.065548
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    youtube_url = 'https://www.youtube.com/watch?v=nfWlot6h_JM'
    yt_ie = YoutubeIE()
    yt_info = yt_ie.extract(youtube_url)
    assert isinstance(yt_info, dict) == True

    udn_embed_url = 'https://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    udn_embed_info = udn_embed_ie.extract(udn_embed_url)
    assert isinstance(udn_embed_info, dict) == True


# Generated at 2022-06-24 13:47:09.576948
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    # Ensure that the regex would match desired URL
    assert re.match(r'https?:.*?\.udn\.com/embed/news/\d+', 'https://video.udn.com/embed/news/300040')
    # Make sure the class can be instantiated
    _ = IE(extractor_type='UDNEmbedIE',
           test=True)

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:47:10.118267
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-24 13:47:18.265703
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor

    ie = InfoExtractor.test_video_result (
        'http://video.udn.com/embed/news/300040', '300040', 'mp4', '生物老師男變女 全校挺"做自己"'
    )

    ie = InfoExtractor.test_video_result (
        'http://video.udn.com/embed/news/300040'
    )

    ie = InfoExtractor.test_video_result (
        'http://video.udn.com/embed/news/300040', '300040', 'mp4', '生物老師男變女 全校挺"做自己"'
    )

    ie

# Generated at 2022-06-24 13:47:21.623046
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_class = UDNEmbedIE()
    assert test_class.IE_DESC == '聯合影音'
    assert test_class._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:28.695693
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == "UDNEmbed", "UDNEmbedIE.ie_key should return 'UDNEmbed'"
    assert ie.ie_desc() == "聯合影音", "UDNEmbedIE.ie_desc should return '聯合影音'"
    assert ie.suitable("http://video.udn.com/embed/news/300040"), "UDNEmbedIE.suitable should return True for URLs start with https://video.udn.com/embed"



# Generated at 2022-06-24 13:47:36.319732
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert(info_extractor.IE_DESC == '聯合影音')
    assert(info_extractor._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(info_extractor._VALID_URL == 'https?:' + info_extractor._PROTOCOL_RELATIVE_VALID_URL)


# Generated at 2022-06-24 13:47:38.732982
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    udn_real_extract = udn._real_extract
    assert udn_real_extract is not None


# Generated at 2022-06-24 13:47:47.826289
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor

    # Test the ability of class UDNEmbedIE to recognize a valid url
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL is not None

    assert UDNEmbedIE.suitable('https://video.udn.com/embed/news/300040')
    assert UDNEmbedIE.suitable('//video.udn.com/embed/news/300040')

    assert not UDNEmbedIE.suitable(
        'http://www.youtube.com/watch?v=BaW_jenozKc')


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:47:51.760531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    url = 'http://video.udn.com/embed/news/300040'
    url2 = 'https://video.udn.com/play/news/300040'
    UDNEmbedIE()._match_id(url) == video_id
    UDNEmbedIE()._match_id(url2) == video_id

# Generated at 2022-06-24 13:47:55.608534
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert IE_DESC in ie.IE_DESC
    assert _PROTOCOL_RELATIVE_VALID_URL in ie._PROTOCOL_RELATIVE_VALID_URL
    assert _VALID_URL in ie._VALID_URL
    assert '_TESTS' in globals()



# Generated at 2022-06-24 13:48:00.716788
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE({})
    assert ie.suitable(url)
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_NAME.lower() == ie.ie_key().lower()

# Generated at 2022-06-24 13:48:02.279563
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:48:03.907430
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn is not None

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:48:05.916929
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie is not None


# Generated at 2022-06-24 13:48:11.530588
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .. import YoutubeDL
    from .embed import EmbedIE
    import copy

    ydl = YoutubeDL(dict(_debug_print=False))
    embed_ie = EmbedIE(ydl)
    embed_ie._ies.clear()

    UDNEmbedIE._build_ie(ydl, embed_ie)

    assert embed_ie._ies['https?' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL] == UDNEmbedIE

# Generated at 2022-06-24 13:48:21.408255
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

    assert not ie._PROTOCOL_RELATIVE_VALID_URL.startswith('//')
    assert ie._PROTOCOL_RELATIVE_VALID_URL.startswith('/')
    assert ie._VALID_URL.startswith('https?:')
    assert ie._VALID_URL.startswith('http') or ie._VALID_URL.startswith('https')
    assert not ie._VALID_URL.startswith('http:') or ie._VALID_URL.startswith('https:')

# Generated at 2022-06-24 13:48:31.692084
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    IE_UDNEmbed = UDNEmbedIE()
    IE_UDNEmbed._html_search_regex = lambda *a: None
    IE_UDNEmbed._download_webpage = lambda *a: None
    IE_UDNEmbed._match_id = lambda *a: None
    IE_UDNEmbed._parse_json = lambda *a: None
    IE_UDNEmbed._extract_m3u8_formats = lambda *a: None
    IE_UDNEmbed._extract_f4m_formats = lambda *a: None
    IE_UDNEmbed._sort_formats = lambda *a: None
    IE_UDNEmbed._real_extract(url)
    pass

# Generated at 2022-06-24 13:48:35.727997
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    try:
        ie._real_extract(url)
    except:
        pass
    finally:
        pass

# Generated at 2022-06-24 13:48:36.329827
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:48:45.315735
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    s = UDNEmbedIE()
    assert s.IE_DESC == '聯合影音'
    assert s._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert s._VALID_URL == 'https?:' + s._PROTOCOL_RELATIVE_VALID_URL
    assert s._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert s._TESTS[0]['info_dict']['id'] == '300040'
    assert s._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 13:48:48.429323
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'



# Generated at 2022-06-24 13:48:59.495070
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from ..utils import js_to_json

    url = 'http://video.udn.com/embed/news/300040'
    # Static reference

# Generated at 2022-06-24 13:49:07.038633
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    main_class = UDNEmbedIE()
    main_class.IE_DESC = 'UDN video site'
    main_class._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    main_class._VALID_URL = r'https?:' + main_class._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:49:12.240209
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udneie = UDNEmbedIE()
    info_dict = udneie._real_extract(url)
    assert info_dict['title'] == '生物老師男變女 全校挺"做自己"'
    assert info_dict['id'] == '300040'


# Generated at 2022-06-24 13:49:13.731410
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert UDNEmbedIE._TESTS == udn_embed_ie._TESTS

# Generated at 2022-06-24 13:49:16.126849
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	from nose.tools import assert_raises
	assert_raises(TypeError, UDNEmbedIE, None)
	assert_raises(TypeError, UDNEmbedIE, [])
	assert_raises(TypeError, UDNEmbedIE, '', '')

# Generated at 2022-06-24 13:49:19.739452
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Testing constructor ...
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'



# Generated at 2022-06-24 13:49:30.010252
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = globals()['UDNEmbedIE']
    udn_embed_IE = class_()

    assert udn_embed_IE.IE_DESC == '聯合影音'
    assert udn_embed_IE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Test for non-unicode string input
    udn_embed_IE._download_webpage(
        'http://video.udn.com/embed/news/300040', '300040')
    udn_embed_IE._download_webpage(
        b'http://video.udn.com/embed/news/300040', '300040')

# Generated at 2022-06-24 13:49:40.190445
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # When: Download video from URL
    udn_embed_ie = UDNEmbedIE()
    udn_embed_ie._download_webpage = lambda *args, **kwargs: ''
    udn_embed_ie._extract_m3u8_formats = lambda *args, **kwargs: []
    udn_embed_ie._extract_f4m_formats = lambda *args, **kwargs: []
    udn_embed_ie._parse_json = lambda *args, **kwargs: {}
    
    # Then: Downloaded video information must be correct
    udn_embed_ie._download_webpage('http://video.udn.com/embed/news/300040', '300040')