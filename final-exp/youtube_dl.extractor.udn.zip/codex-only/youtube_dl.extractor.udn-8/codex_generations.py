

# Generated at 2022-06-24 13:39:38.092460
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # test if URLs can be extracted 
    assert ie.extract_info('http://video.udn.com/embed/news/300040')
    assert ie.extract_info('https://video.udn.com/embed/news/300040')
    assert ie.extract_info('http://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:39:42.191126
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?:(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:39:48.268144
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_ie = UDNEmbedIE()
    result = udn_ie.extract(url)
    assert result['id'] == '300040'
    assert result['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-24 13:39:57.175994
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()

    assert(i.IE_DESC == '聯合影音')

    assert(i._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

    assert(i._VALID_URL == r'https?:' + i._PROTOCOL_RELATIVE_VALID_URL)

    assert(i._TESTS[0].get('url') == 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:40:01.336625
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    m_obj = re.match(udnEmbedIE._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert m_obj.group('id') == '300040'

# Generated at 2022-06-24 13:40:03.586570
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie is not None


# Generated at 2022-06-24 13:40:09.574331
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r = UDNEmbedIE()
    assert r.ie_key() == 'UDNEmbed'
    assert r.IE_DESC == '聯合影音'
    assert r._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert r._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert r._TESTS[0]['info_dict']['id'] == '300040'
    assert r._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert r._TESTS[0].get('skip_download')

# Generated at 2022-06-24 13:40:19.687107
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Download a dictionary of all the variables.
    url = "https://video.udn.com/embed/news/300040"
    udn = UDNEmbedIE()
    info = udn._download_webpage(url, 300000, 'retrieve url')

    # Find the variable which we need
    jstr = udn._html_search_regex(r'var\s+options\s*=\s*([^;]+);', info, 'options')
    js_to_json(jstr)

    # Test the constructor
    udn._parse_json(js_to_json(jstr), 'options', fatal=False)

    # Test _real_extract
    assert udn._real_extract(url)

# Generated at 2022-06-24 13:40:27.406996
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import youtube_dl
    import re
    import sys
    import os
    if sys.version_info < (3,):
        reload(sys)
        sys.setdefaultencoding('utf8')
    url = 'http://video.udn.com/embed/news/300040'
    video = youtube_dl.YoutubeDL().extract_info(url=url, download=False)
    f_w = open('video_info.json', 'w')
    f_w.write(re.sub(r'"url": "(.*?)"', r'"url": "URL"', json.dumps(video, ensure_ascii=False, indent=4)))
    f_w.close()
    os.system('diff -u --ignore-all-space video_info.json_youtube-dl video_info.json')
   

# Generated at 2022-06-24 13:40:29.741258
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:40:34.393370
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')

    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:36.674965
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE('https://video.udn.com/embed/news/300040')
    except:
        assert False

# Generated at 2022-06-24 13:40:38.016356
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj.get_url()

# Generated at 2022-06-24 13:40:43.882955
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'
    assert udn._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:40:54.681800
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    test_cases = [(
        'http://video.udn.com/embed/news/300040', '300040'), (
        'https://video.udn.com/embed/news/300040', '300040'), (
        'http://video.udn.com/play/news/300040', '300040'), (
        'https://video.udn.com/play/news/300040', '300040'), (
        'https://video.udn.com/play/news/300002', '300002'), (
        'https://video.udn.com/play/news/300215', '300215')]
    for tc in test_cases:
        m = udn_ie._VALID_URL_RE.match(tc[0])

# Generated at 2022-06-24 13:40:55.520092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie

# Generated at 2022-06-24 13:40:56.323351
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-24 13:40:59.367391
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert ie.urls[0] == ie._VALID_URL

# Generated at 2022-06-24 13:41:00.410812
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL != None

# Generated at 2022-06-24 13:41:07.841716
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Init
    ie = UDNEmbedIE()
    # Test regular case
    test_url = 'http://video.udn.com/embed/news/300040'
    # Test regular case
    assert(ie._match_id(test_url) == '300040')
    # Test protocol relative case
    test_url = '//video.udn.com/embed/news/300040'
    # Test regular case
    assert(ie._match_id(test_url) == '300040')

# Generated at 2022-06-24 13:41:09.425624
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne



# Generated at 2022-06-24 13:41:19.036777
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    A unit test to check the constructor of class UDNEmbedIE
    """
    try:
        from ytdl.extractor import gen_extractors
        from ytdl.compat import compat_str
    except:
        raise ValueError("Make sure that you have downloaded the"
                         " required dependency, pytube.")
    _VALID_URL = 'http://video.udn.com/embed/news/300040'

    # Construct an object with the _VALID_URL
    try:
        UDNEmbedIE(_VALID_URL)
    except:
        raise AssertionError("An object cannot be constructed!")

    # Check if the IE key is present in gen_extractors()
    if compat_str(UDNEmbedIE.ie_key()) not in gen_extractors():
        raise

# Generated at 2022-06-24 13:41:22.605745
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(hasattr(UDNEmbedIE, 'IE_DESC'))
    assert(hasattr(UDNEmbedIE, '_VALID_URL'))
    assert(hasattr(UDNEmbedIE, '_TESTS'))

# Generated at 2022-06-24 13:41:28.761443
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    test_urls = [
        # http link
        'http://video.udn.com/embed/news/300040',
        # https link
        'https://video.udn.com/embed/news/300040'
    ]
    for url in test_urls:
        assert re.match(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL, url)

# Generated at 2022-06-24 13:41:32.133231
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor of InfoExtractor should be tested first
    ie = InfoExtractor()

    # Constructor of InfoExtractor sub class UDNEmbedIE should be tested now
    udn_ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:41:36.039151
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    print(IE._PROTOCOL_RELATIVE_VALID_URL)
    print(IE._VALID_URL)
    print(IE._TESTS)
    print(IE.IE_DESC)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:41:45.166715
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert ie._TESTS[1]['only_matching'] == True

# Generated at 2022-06-24 13:41:51.179692
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_ie = UDNEmbedIE()._real_initialize(url)
    assert udn_ie.SUCCESS == udn_ie.extract(url)

# Generated at 2022-06-24 13:41:59.142442
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei.IE_NAME == 'udn'
    assert udnei.IE_DESC == '聯合影音'
    assert udnei._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnei._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:42:01.455527
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    # TODO: can write the test for this?
    print(udn_embed)

# Generated at 2022-06-24 13:42:04.966697
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie_obj = UDNEmbedIE()
    assert udn_embed_ie_obj.ie_key() == 'udn'

# Generated at 2022-06-24 13:42:11.775510
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    # test whether "UDNEmbedIE" is in the description
    assert ie.IE_DESC in ie.IE_NAME
    # test whether "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)" pattern is in the _VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL in ie._VALID_URL


# Generated at 2022-06-24 13:42:18.889645
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_ext_testcase = InfoExtractor()
    infos_testcase = {
        'url': 'https://video.udn.com/embed/news/300040',
        'info_dict': {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
        'expected_warnings': ['Failed to parse JSON Expecting value'],
    }

    assert infos_testcase['url'] == info_ext_testcase.UDNEmbed

# Generated at 2022-06-24 13:42:20.800637
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # IE_NAME is not defined in UDNEmbedIE
    assert ie.IE_NAME == 'udn_embed'

# Generated at 2022-06-24 13:42:22.395572
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert test.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:42:23.423505
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None)

# Generated at 2022-06-24 13:42:25.524757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u._VALID_URL is not None
    assert u._NETRC_MACHINE is not None
    assert u._downloader is not None

# Generated at 2022-06-24 13:42:36.262425
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	assert(UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
	assert(UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040')
	assert(UDNEmbedIE._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"')
	assert(UDNEmbedIE._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:42:41.767050
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()
    assert x._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert x._VALID_URL == r'https?:' + x._PROTOCOL_RELATIVE_VALID_URL
    assert x.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:42:50.295909
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
   """
    from ..aies import _get_supported_ie
    from ..aies import my_extractor
    from . import UDNIE  # from .common import InfoExtractor

    my_exp = my_extractor(UDNEmbedIE)
    assert isinstance(my_exp, UDNIE)

    # assert 'UDNEmbedIE' in _get_supported_ie()
    assert my_exp.IE_DESC == '聯合影音'
    my_ie = UDNEmbedIE(_print_debug=True)
    assert my_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
   

# Generated at 2022-06-24 13:42:52.342765
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Make sure url parameter doesn't crash constructor
    UDNEmbedIE('https://video.udn.com/play/news/303776')

# Generated at 2022-06-24 13:42:54.972430
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

# Generated at 2022-06-24 13:42:57.017446
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE(_print_debug=True)
    except Exception as e:
        print("Real: %s" % e)

# Generated at 2022-06-24 13:43:04.965100
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_dict = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }
    url = 'http://video.udn.com/embed/news/300040'
    udnembed_info_extractor = UDNEmbedIE()
    assert isinstance(udnembed_info_extractor, InfoExtractor)
    udnembed_info = udnembed_info_extractor._real_extract(url)
    assert isinstance(udnembed_info, dict)

# Generated at 2022-06-24 13:43:06.275243
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie is not None

# Generated at 2022-06-24 13:43:08.288955
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._WEBPAGE_URL % '300040' == obj._TESTS[0]['url']


# Generated at 2022-06-24 13:43:09.511998
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	# execute constructor
	ie = UDNEmbedIE()

# Generated at 2022-06-24 13:43:14.230932
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Note that this is only a very simple test,
    # and many detailed tests are done in test_extractor.py
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:43:17.916382
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.IE_DESC == '\u9023\u5408\u5f71\u97f3'

# Generated at 2022-06-24 13:43:21.081427
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert_equal(udn_ie.IE_DESC, '聯合影音')



# Generated at 2022-06-24 13:43:25.518315
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert hasattr(UDNEmbedIE, 'IE_NAME')
    assert hasattr(UDNEmbedIE, '_VALID_URL')
    assert hasattr(UDNEmbedIE, 'IE_DESC')
    assert hasattr(UDNEmbedIE, '_TESTS')

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:43:33.348683
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == r'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    assert instance._test_suites()[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert instance._test_suites()[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert instance._test_suites()[2]['url'] == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-24 13:43:34.218295
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:43:35.884422
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()

# Generated at 2022-06-24 13:43:38.349889
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    UDNEmbedIE(url=url)
    assert True

# Generated at 2022-06-24 13:43:40.822613
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:43:45.483837
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url1 = 'http://video.udn.com/embed/news/300040'
    url2 = '//video.udn.com/embed/news/300040'
    url3 = 'http://video.udn.com/play/news/303776'

    my_test = UDNEmbedIE()
    assert my_test._match_id(url1) == '300040'
    assert my_test._match_id(url2) == '300040'
    assert my_test._match_id(url3) == '303776'

# Generated at 2022-06-24 13:43:50.548862
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._TESTS[0].get('url') == UDNEmbedIE._build_url('200')
    assert UDNEmbedIE._TESTS[1].get('url') == UDNEmbedIE._build_url('200')
    assert UDNEmbedIE._TESTS[0].get('url') != UDNEmbedIE._build_url('100')

# Generated at 2022-06-24 13:43:59.783861
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.IE_DESC == '聯合影音'
    assert u._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u._VALID_URL == r'https?:' + u._PROTOCOL_RELATIVE_VALID_URL
    assert len(u._TESTS) == 3
    assert u._TESTS[1] == {
        'url': 'https://video.udn.com/embed/news/300040',
        'only_matching': True,
    }

# Generated at 2022-06-24 13:44:02.308428
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    result = UDNEmbedIE()._real_extract(url)
    print(result)

# Generated at 2022-06-24 13:44:08.321180
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL 
    udne_rv = UDNEmbedIE._VALID_URL
    assert(re.match(_VALID_URL, udne_rv) != None)

# Generated at 2022-06-24 13:44:13.968823
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert info_extractor.IE_NAME == 'video.udn.com'
    assert info_extractor.IE_DESC == '聯合影音'
    assert info_extractor._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert info_extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:44:19.252442
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    new_ie = UDNEmbedIE()
    assert new_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert new_ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-24 13:44:28.026351
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #constructor: UDNEmbedIE(self, ie_key, host, ie)
    from .udn import UDNIE
    udn_ie = UDNIE()
    UDNEmbedIE.udn_ie = udn_ie 
    udn_embed_ie = UDNEmbedIE(ie_key='udn', host='video.udn.com', ie=udn_ie)
    print(str(udn_embed_ie))
    print(str(udn_embed_ie._extract_video_info_from_url))


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:44:32.330682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed is not None
    # This test should raise an exception
    try:
        udn_embed.download_webpage(url='http://www.baidu.com', video_id='10001')
    except RegexNotFoundError:
        print('RegexNotFoundError raised')

# Generated at 2022-06-24 13:44:36.501893
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.extractor_key == 'UDNEmbed'

# Generated at 2022-06-24 13:44:39.614970
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(UDNEmbedIE.ie_key())._real_extract(url) # No Error



# Generated at 2022-06-24 13:44:43.360523
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test URL: http://video.udn.com/embed/news/300040
    from .. import UDNIE
    udn_ie = UDNIE()
    udn_ie.ie_key = "UDNEmbed"
    print(udn_ie)

# Generated at 2022-06-24 13:44:53.210722
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    url = 'https://video.udn.com/embed/news/' + video_id

# Generated at 2022-06-24 13:45:02.202499
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    # Test get_url()
    assert re.match(test_obj._PROTOCOL_RELATIVE_VALID_URL, test_obj.get_url('http://video.udn.com/embed/news/300040'))
    assert re.match(test_obj._PROTOCOL_RELATIVE_VALID_URL, test_obj.get_url('https://video.udn.com/embed/news/300040'))
    assert re.match(test_obj._PROTOCOL_RELATIVE_VALID_URL, test_obj.get_url('//video.udn.com/embed/news/300040'))

# Generated at 2022-06-24 13:45:04.480976
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test for constructor of class UDNEmbedIE
    """
    udni = UDNEmbedIE()
    assert udni
    assert udni.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:45:09.767568
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert hasattr(UDNEmbedIE, 'IE_DESC')
    assert hasattr(UDNEmbedIE, '_PROTOCOL_RELATIVE_VALID_URL')
    assert hasattr(UDNEmbedIE, '_VALID_URL')
    assert hasattr(UDNEmbedIE, '_TESTS')

# Generated at 2022-06-24 13:45:20.190152
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:45:23.313234
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert type(UDNEmbedIE('UDNEmbedIE', True)) == UDNEmbedIE

# Generated at 2022-06-24 13:45:27.398164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        x = UDNEmbedIE()
        print(x)
        (os.remove(x.info_dict['id']))
    except:
        print('Error for extraction')

# Test for download and convert url of class UDNEmbedIE
test_UDNEmbedIE()

# Generated at 2022-06-24 13:45:29.204857
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:45:31.353178
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test
    x = UDNEmbedIE()
    # assert
    assert x is not None


# Generated at 2022-06-24 13:45:33.708423
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    youtube_url = 'https://youtu.be/FbH2nf-E5gw'

    UDNEmbedIE(youtube_url)

    assert True == True

# Generated at 2022-06-24 13:45:40.975940
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    assert udne.suitable(url) == True
    assert udne.IE_NAME == 'udn'
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:45:44.985452
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie._VALID_URL == ie._VALID_URL

# Generated at 2022-06-24 13:45:48.146584
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:45:51.072496
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    c = UDNEmbedIE()
    assert c.ie_key() == 'UDNEmbed'
    assert c.IE_DESC == '聯合影音'


# Generated at 2022-06-24 13:45:53.144390
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-24 13:45:56.137830
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie._real_extract('http://video.udn.com/embed/news/300040')
    assert(ie.IE_DESC == '聯合影音')

# Generated at 2022-06-24 13:45:56.985266
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:45:59.905401
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor test
    """
    assert UDNEmbedIE.ie_key() == 'UDNEmbed'
    assert UDNEmbedIE.ie_key() in InfoExtractor._downloaders

# Generated at 2022-06-24 13:46:08.212034
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url, expected_class in [
        ('//video.udn.com/embed/news/300040', 'UDNEmbedIE'),
        ('https://video.udn.com/embed/news/300040', 'UDNEmbedIE'),
    ]:
        print('Testing URL %s' % url)
        ie = InfoExtractor.for_url(url)
        ie_class = ie.__class__.__name__
        if ie_class != expected_class:
            print('Failed! It is not %s! It is %s.' % (expected_class, ie_class))
            exit(1)

# Generated at 2022-06-24 13:46:10.308742
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None, None)._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-24 13:46:12.417416
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id(
        'https://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-24 13:46:13.033012
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()


# Generated at 2022-06-24 13:46:15.543091
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Start test constructor of class UDNEmbedIE")
    udn_embed_ie = UDNEmbedIE()
    print("Finish test")

# Generated at 2022-06-24 13:46:17.401279
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE('youtube')
    assert instance

    instance = UDNEmbedIE()
    assert instance

# Generated at 2022-06-24 13:46:18.324778
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:46:22.243566
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE()
    a._real_extract('https://video.udn.com/embed/news/300040')
    a._real_extract('https://video.udn.com/play/news/303776')
    a._html_search_regex
    a._parse_json
    a._match_id
    a._download_webpage

# Generated at 2022-06-24 13:46:24.632636
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()


# Generated at 2022-06-24 13:46:27.595922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE(url)
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'UDNEmbed'

# Generated at 2022-06-24 13:46:37.429795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Check whether the constructor of UDNEmbedIE works well
    '''

    # Arrange
    UDNEmbedIE.ie_key = 'UDNEmbed'
    UDNEmbedIE.ie_desc = 'UDNEmbed_description'
    UDNEmbedIE.ie_short_desc = 'UDNEmbed_short_description'
    UDNEmbedIE._TESTS = []
    UDNEmbedIE._TESTS_RETRY = []
    UDNEmbedIE.http_headers = {}
    UDNEmbedIE.geo_verification_headers = {}
    UDNEmbedIE.http_proxy = None
    UDNEmbedIE.http_connection = None
    UDNEmbedIE.retries = 10
    UDNEmbedIE.age_limit = 0


# Generated at 2022-06-24 13:46:39.955333
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:46:41.699844
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(0)
    ie.extract()


# Generated at 2022-06-24 13:46:43.202681
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 13:46:44.855891
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    return UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:46:49.786949
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    pattern = ie._VALID_URL
    assert pattern == ie._PROTOCOL_RELATIVE_VALID_URL
    ie._PROTOCOL_RELATIVE_VALID_URL = '//.*'
    pattern = ie._VALID_URL
    assert pattern == 'https?://.*'
    assert type(ie.IE_DESC) == str
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-24 13:46:52.906920
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE"""
    udne = UDNEmbedIE()
    print(udne.url)
    print(udne.ie_key())
    print(udne._extract_url())
    print(udne._download_webpage)

# Generated at 2022-06-24 13:46:54.611474
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-24 13:46:59.785792
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    # Following URL only works in China.
    assert udne._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:47:01.323202
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #TODO: Add your codes here
    assert(True)

# Generated at 2022-06-24 13:47:06.435438
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    e = UDNEmbedIE()
    # assert e._PROTOCOL_RELATIVE_VALID_URL
    # assert e._VALID_URL
    # assert e._TESTS
    # assert e._download_webpage
    # assert e._match_id
    # assert e._html_search_regex
    # assert e._parse_json
    # assert e._extract_m3u8_formats
    # assert e._extract_f4m_formats
    # assert e._sort_formats
    # assert e._real_extract


# Generated at 2022-06-24 13:47:11.467406
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UnitTestUDNEmbedIE = UDNEmbedIE()
    assert(UnitTestUDNEmbedIE.ext == ['mp4'])
    assert(UnitTestUDNEmbedIE.IE_DESC == '聯合影音')
    assert(len(UnitTestUDNEmbedIE._VALID_URL) == 34)


# Generated at 2022-06-24 13:47:13.357724
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(url).extract()

# Generated at 2022-06-24 13:47:15.412680
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract("http://video.udn.com/embed/news/300040")
    assert True

# Generated at 2022-06-24 13:47:23.894625
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040'))
    assert(re.match(UDNEmbedIE._VALID_URL, 'https://video.udn.com/embed/news/300040'))

# Generated at 2022-06-24 13:47:27.399923
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert('300040' == IE._match_id('http://video.udn.com/embed/news/300040'))
    assert('300040' == IE._match_id('https://video.udn.com/embed/news/300040'))

# Generated at 2022-06-24 13:47:34.513477
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    assert udne._match_id(url) == '300040'
    assert udne._match_id(url, fatal=False) == '300040'
    assert udne._match_id('http://video.udn.com/play/news/300040', fatal=False) == '300040'



# Generated at 2022-06-24 13:47:39.469862
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udney = UDNEmbedIE()
    assert (udney.IE_DESC == '聯合影音')
    url = 'https://video.udn.com/embed/news/300040'
    match_url = udney._match_id(url)
    assert (match_url == '300040')


# Generated at 2022-06-24 13:47:47.485097
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie

# Generated at 2022-06-24 13:47:51.326945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie_obj =  UDNEmbedIE()
    result = ie_obj.extract(url)

    assert result is not None
    assert result['id'] == '300040'
    assert result['title'] is not None

# Generated at 2022-06-24 13:47:51.987438
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-24 13:47:55.326248
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
        ie.extract('http://video.udn.com/embed/news/300040')
    except Exception as e:
        print("Test Fail!")
        print("Exception:", str(e))

# Generated at 2022-06-24 13:47:59.214282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # case 1
    url = 'http://video.udn.com/embed/news/300040'
    id_ = '300040'
    assert ie._match_id(url) == id_
    # case 2
    url = 'https://video.udn.com/embed/news/300040'
    id_ = '300040'
    assert ie._match_id(url) == id_

# Generated at 2022-06-24 13:48:00.992335
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE._download_webpage)


# Generated at 2022-06-24 13:48:01.562516
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-24 13:48:06.504259
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

	original_UDNEmbedIE = UDNEmbedIE
	UDNEmbedIE = partialclass(UDNEmbedIE, host='example.com')
	class TestUDNEmbedIE(UDNEmbedIE):
		"""Test class only used for constructor of class UDNEmbedIE"""
		IE_DESC = 'Test class only used for constructor of class UDNEmbedIE'
		_VALID_URL = r'^https?://example\.com/\d+$'
		_TESTS = [{
			'url': 'http://example.com/1234',
			'info_dict': {
				'id': '1234',
			},
		}]

	TestUDNEmbedIE('')
	UDNEmbedIE = original_UD

# Generated at 2022-06-24 13:48:08.152437
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'

# Generated at 2022-06-24 13:48:09.883077
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a_UDNEmbedIE = UDNEmbedIE()
    return a_UDNEmbedIE

# Generated at 2022-06-24 13:48:11.321999
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL
    assert UDNEmbedIE._TESTS



# Generated at 2022-06-24 13:48:23.954089
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE

    This unit test mainly focus on the constructor of class UDNEmbedIE.
    Besides, it also constructs a simple instance of class InfoExtractor
    for the further unit test of method _real_extract of class UDNEmbedIE.
    """
    # Test the constructor of class UDNEmbedIE
    # The IE_DESC is the only field that not declared in class InfoExtractor
    assert UDNEmbedIE.IE_DESC == '聯合影音'

    # Construct a simple instance of class InfoExtractor
    udn_ie = InfoExtractor(UDNEmbedIE.IE_NAME, UDNEmbedIE.IE_DESC)

# Generated at 2022-06-24 13:48:33.302997
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-24 13:48:38.419334
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udnembed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-24 13:48:42.444360
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie.http_headers() == {'User-Agent': 'Mozilla/5.0'}


# Generated at 2022-06-24 13:48:43.687497
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

# Generated at 2022-06-24 13:48:48.148332
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie._real_extract('http://video.udn.com/embed/news/300040')
    assert ie._real_extract('https://video.udn.com/embed/news/300040')



# Generated at 2022-06-24 13:48:50.195448
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.extractor == UDNEmbedIE



# Generated at 2022-06-24 13:48:56.285587
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # Test url with http scheme
    url = ie._PROTOCOL_RELATIVE_VALID_URL.replace(r'//', 'http://')
    assert ie._VALID_URL == url
    # Test url with https scheme
    url = ie._PROTOCOL_RELATIVE_VALID_URL.replace(r'//', 'https://')
    assert ie._VALID_URL == url

# Generated at 2022-06-24 13:49:03.493879
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_constructor = [
        lambda: UDNEmbedIE(UDNEmbedIE.ie_key(), UDNEmbedIE._VALID_URL),
        lambda: UDNEmbedIE(UDNEmbedIE.ie_key())
        ]
    for constructor in class_constructor:
        try:
            constructor()
        except Exception as e:
            assert False, 'UDNEmbedIE failed to initialize. ' + str(e)
        else:
            assert True

# Generated at 2022-06-24 13:49:04.449666
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-24 13:49:06.124704
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-24 13:49:10.234356
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnie = UDNEmbedIE()
    assert udnie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnie._VALID_URL == r'https?:' + udnie._PROTOCOL_RELATIVE_VALID_URL
    assert udnie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-24 13:49:16.270770
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udns = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    udns.url_result(url)
    url = 'https://video.udn.com/embed/news/300040'
    udns.url_result(url)

# Generated at 2022-06-24 13:49:19.425317
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE().extract(url='http://video.udn.com/embed/news/300040')

# Generated at 2022-06-24 13:49:21.282225
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except Exception as e:
        print(e)
        return False

    return True


# Generated at 2022-06-24 13:49:30.906277
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    # The following line will throw error if the constructor of class UDNEmbedIE
    # doesn't take exactly one argument
    IE = UDNEmbedIE(url)
    assert(IE.IE_NAME == "udn_embed")
    assert(IE.IE_DESC == "聯合影音")
    assert("_VALID_URL" in IE._TESTS[0])
    assert("_PROTOCOL_RELATIVE_VALID_URL" in IE._TESTS[2])
    assert(IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-24 13:49:39.129625
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE(None)
    test_url = '//video.udn.com/embed/news/300040'
    assert udne._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert udne._match_id(test_url) == '300040'
    assert udne._match_id('www.udn.com/embed/news/300040') == '300040'
    assert udne._match_id('https://udn.com/embed/news/300040') == '300040'