

# Generated at 2022-06-26 13:12:48.739075
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()

# Generated at 2022-06-26 13:12:51.229494
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:12:53.038028
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert callable(UDNEmbedIE)


# Generated at 2022-06-26 13:12:55.950238
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:12:57.900765
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:13:06.255199
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for the correct name of the class
    assert UDNEmbedIE.IE_NAME == 'udn'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:13:08.150998
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()
    assert u_d_n_embed_i_e_0.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:13:13.339832
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:13:14.563482
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()


# Generated at 2022-06-26 13:13:25.050327
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # _VALID_URL = 'https?:' + _PROTOCOL_RELATIVE_VALID_URL

    # def _real_extract(self, url):
    if 'https://video.udn.com/embed/news/300040':
        u_d_n_embed_i_e_0_real_extract = UDNEmbedIE._real_extract(self='http://video.udn.com/embed/news/300040', url='https?:' + _PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-26 13:13:38.083877
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Example of this class are in tests/test_udn.py
    """
    video_id = '1337'
    web_page_content = '<video></video>'
    ie = UDNEmbedIE({}, UDNEmbedIE._download_webpage,
                    UDNEmbedIE._match_id, web_page_content, video_id)
    assert isinstance(ie, UDNEmbedIE)

    another_web_page_content = '<div></div>'
    ie = UDNEmbedIE({}, UDNEmbedIE._download_webpage,
                    UDNEmbedIE._match_id, another_web_page_content, video_id)
    assert not ie


# Generated at 2022-06-26 13:13:42.447227
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructs_success = True
    try:
        UDNEmbedIE()
    except:
        constructs_success = False

    if not constructs_success:
        raise AssertionError('Constructing UDNEmbedIE() raises exception.')

# Generated at 2022-06-26 13:13:47.606912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """ Basic test for constructor of class UDNEmbedIE """
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(0)
    ie.extract(url)

# Generated at 2022-06-26 13:13:54.661114
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()
    match = re.match(class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert match
    assert match.group('id') == '300040'
    assert class_UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:14:00.757453
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    class UDNEmbedIETest(unittest.TestCase):
        def test_non_matching(self):
            UDNEmbedIE('https://www.udn.com/')

    unittest.main()

# Generated at 2022-06-26 13:14:08.366025
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # test method

# Generated at 2022-06-26 13:14:13.591952
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne_ie = UDNEmbedIE(url)

    tester_1 = udne_ie._match_id(url)
    assert tester_1 == '300040'

# Generated at 2022-06-26 13:14:18.861080
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_common import TestIE
    ie = TestIE([UDNEmbedIE.ie_key()])
    assert ie.ie is UDNEmbedIE
    assert ie.test()

# Generated at 2022-06-26 13:14:21.933429
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-26 13:14:29.403980
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .embed import EmbedIE
    from .udn import UDNEmbedIE
    from .youtube import YoutubeIE
    from ..utils import to_native_str

    class TestInfoExtractor(InfoExtractor):
        def _download_webpage(self, *args):
            body = '''
                <script>
                    var options = {
                        "video": {
                            "mp4": "api_url_mp4",
                            "3gp": "api_url_3gp",
                            "youtube": "http://www.youtube.com/watch?v=1234567",
                        },
                        "title": "title"
                    };
                </script>
                '''
            return body if len(args) == 1 else (None, body)

    ie_list = list(EmbedIE._ies)
    ie_

# Generated at 2022-06-26 13:14:45.817812
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, UDNEmbedIE)


if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:14:51.975344
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ins = UDNEmbedIE()
    assert ins._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ins._download_webpage == InfoExtractor._download_webpage

# Generated at 2022-06-26 13:14:59.845436
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test constructor of class UDNEmbedIE
    global udn
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == r'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL
    assert udn._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:15:06.962230
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040'
    ]
    for url in test_urls:
        print(UDNEmbedIE()._real_extract(url))

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:15:14.964006
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:19.807225
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'UDNEmbed'
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert UDNEmbedIE._TESTS[2]['url'] == \
           'https://video.udn.com/play/news/303776'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:15:21.098377
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()
    assert x

# Generated at 2022-06-26 13:15:26.424472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    IE.IE_DESC = 'Description'

    def test_ie_desc(self):
        return self.IE_DESC
    IE._real_extract = test_ie_desc

    print(IE._real_extract('https://video.udn.com/embed/news/300040'))

# Generated at 2022-06-26 13:15:37.145978
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    assert ie.IE_DESC == "聯合影音"
    assert ie._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+).*"

# Generated at 2022-06-26 13:15:41.833218
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()
    assert x._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:14.898207
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    url = "http://video.udn.com/embed/news/300040"
    re_url = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert re.search(re_url, url) is not None

    udne = UDNEmbedIE(url)
    assert udne._PROTOCOL_RELATIVE_VALID_URL == re_url

# Run tests
test_UDNEmbedIE()

# Run unit tests if executed from command line
if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-26 13:16:24.275106
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().suitable('http://video.udn.com/embed/news/300040') == True
    assert UDNEmbedIE().suitable('https://video.udn.com/embed/news/300040') == True
    assert UDNEmbedIE().suitable('//video.udn.com/embed/news/300040') == True
    assert UDNEmbedIE().suitable('https://video.udn.com/play/news/303776') == True

# Generated at 2022-06-26 13:16:26.917707
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, 'https://video.udn.com/play/news/303776', 'None')

# Generated at 2022-06-26 13:16:30.461040
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Construct UDNEmbedIE
    ie = UDNEmbedIE()

    # TODO: implement this unit test
    # Test that the following URL is matched by the regex
    url = '//video.udn.com/embed/news/300040'
    assert ie._match_id(url) == '300040'

    # Test if the class could be initialized
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:16:38.986256
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
    ]
    invalid_urls = [
        'http://video.udn.com/embed/news/300040?a=b',
        'https://video.udn.com/embed/news/300040?a=b',
        'hhttp://video.udn.com/embed/news/300040',
        'http://video.udn.com/play/news/300040',
    ]
    assert_true(all(re.match(UDNEmbedIE._VALID_URL, u) for u in valid_urls))

# Generated at 2022-06-26 13:16:47.127757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedExtractor = UDNEmbedIE()
    assert udnEmbedExtractor
    assert udnEmbedExtractor.IE_NAME == 'udn'
    assert udnEmbedExtractor.IE_DESC == '聯合影音'
    assert udnEmbedExtractor._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbedExtractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:58.394481
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:17:07.978703
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # first parameter must be string of class 'str'
    try:
        a = UDNEmbedIE(1, 2)
    except TypeError:
        pass
    a = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert(a._match_id(a._VALID_URL) == '300040')
    assert(a._match_id('https://video.udn.com/embed/news/300040') == '300040')
    assert(a._match_id('http://video.udn.com/play/news/300040') == '300040')
    assert(a._match_id('https://video.udn.com/play/news/300040') == '300040')

# Generated at 2022-06-26 13:17:09.711680
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    print('title:', info_extractor.IE_DESC)
    
test_UDNEmbedIE()
# Example of unit test

# Generated at 2022-06-26 13:17:12.256555
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbed = UDNEmbedIE(url)
    assert UDNEmbed._VALID_URL == 'https?:' + UDNEmbed._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbed._TESTS[0]['url'] == url

# Generated at 2022-06-26 13:18:17.881174
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    def f(url):
        return obj._real_extract(url)
    assert f('http://video.udn.com/embed/news/300040')
    assert f('https://video.udn.com/embed/news/300040')
    assert f('//video.udn.com/embed/news/300040')
    assert f('http://video.udn.com/play/news/303776')

# Generated at 2022-06-26 13:18:26.682135
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test import get_testcases
    from .common import list_extractors
    from .extractor import gen_extractors_test

    ie = UDNEmbedIE()
    testcases = get_testcases(ie, ie.IE_NAME, ie.IE_DESC)
    gen_extractors_test(list_extractors(ie.IE_NAME), testcases, ie.IE_NAME, ie.IE_DESC)

# Generated at 2022-06-26 13:18:34.306093
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor of class UDNEmbedIE.
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.suitable(ie._match_id(url))
    assert ie.suitable(url)

# Generated at 2022-06-26 13:18:35.856506
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:18:42.441433
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE('')
    assert class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert class_UDNEmbedIE._VALID_URL == r'https?:' + class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:18:47.379448
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('测试', 'http://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:18:58.125042
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        # step 1. Construct an instance of class InfoExtractor
        infoExtractor = InfoExtractor()
        # step 2. Construct an instance of class UDNEmbedIE
        myIE = infoExtractor.constructor(
            'UDNEmbedIE',
            [],
            default_downloader=True
        )()
        # step 3. test instance
        assert isinstance(myIE, UDNEmbedIE)
    except:
        print("Error when test construct instance of class UDNEmbedIE")

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:19:09.076979
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    test_case_1 = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

    # test case for match id
    assert re.match(test_case_1, '//video\.udn\.com/embed/news/300040')

    # test case for unmatch id
    assert not re.match(test_case_1, '//video.udn.com/embed/news/3000404')

    # test case for unmatch url
    assert not re.match(test_case_1, '//video.udn.com/fake/news/3000404')


# Generated at 2022-06-26 13:19:13.158982
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-26 13:19:19.736632
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:21:42.338085
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    info_dict = udne._real_extract(url)
    assert info_dict['id'] == '300040'
    assert info_dict['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-26 13:21:52.841163
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE("fake_value", "fake_value")
    assert inst.IE_DESC == "聯合影音"
    assert inst._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:21:56.153951
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()
    assert x._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:22:00.401994
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:22:06.004909
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    result = ie.suitable(url)
    assert result == True

# Generated at 2022-06-26 13:22:14.618827
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor, url_basename
    from .youtube import _parse_duration

    # 1st, test the extractor constructor
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == 'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL
    
    # 2nd, test method '_real_extract'
    # Extractor.real_extract usually returns a dictionary containing 
    # [1] 'id' : the video id (extracted from the target URL)
    # [2] 'title' : the video title (also extracted from the video page)
    # [3] 'formats' : the list of formats (m3u8,

# Generated at 2022-06-26 13:22:20.982353
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE"""
    url = 'https://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE(url)
    assert udn_embed_ie is not None

# Generated at 2022-06-26 13:22:23.956070
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert_equal(u._VALID_URL, 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')


# Generated at 2022-06-26 13:22:25.861173
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE({})
    assert ie.IE_NAME == 'udn'

# Generated at 2022-06-26 13:22:29.360931
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE(IE_DESC)
