

# Generated at 2022-06-26 13:12:51.548449
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-26 13:12:55.600404
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:12:56.993717
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert not test_case_0()

# Generated at 2022-06-26 13:12:58.478236
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:13:00.278986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()

# Generated at 2022-06-26 13:13:02.565416
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:13:03.224042
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()

# End of test_UDNEmbedIE

# Generated at 2022-06-26 13:13:05.787122
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:13:12.172441
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    match_id = UDNEmbedIE()._match_id
    _PROTOCOL_RELATIVE_VALID_URL = UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL
    url = 'https://video.udn.com/embed/news/300040'
    video_id = match_id(url)

# Generated at 2022-06-26 13:13:24.310365
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert_raises(AttributeError, UDNEmbedIE, None)
    assert_raises(AttributeError, UDNEmbedIE, None, None)
    assert_raises(AttributeError, UDNEmbedIE, None, None, None)
    assert_raises(AttributeError, UDNEmbedIE, None, None, None, None)
    assert_raises(AttributeError, UDNEmbedIE, None, None, None, None, None)
    assert_raises(AttributeError, UDNEmbedIE, None, None, None, None, None, None)
    assert_raises(AttributeError, UDNEmbedIE, None, None, None, None, None, None, None)
    assert_raises(AttributeError, UDNEmbedIE, None, None, None, None, None, None, None, None)

# Generated at 2022-06-26 13:13:46.346514
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert_equals(UDNEmbedIE().IE_DESC, '聯合影音')
    assert_equals(UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL, r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert_equals(UDNEmbedIE()._VALID_URL, r'https?:' + UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL)
    assert_equals(UDNEmbedIE()._TESTS[0]['url'], 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:13:49.031369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_ = UDNEmbedIE()


# Generated at 2022-06-26 13:13:50.685394
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-26 13:13:56.708110
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e.IE_DESC == '聯合影音'
    assert u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u_d_n_embed_i_e._VALID_URL == 'https?:' + u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-26 13:14:02.554325
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e is not None, 'Unit test for constructor of class UDNEmbedIE failed.'


# Generated at 2022-06-26 13:14:03.855816
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:14:16.053083
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-26 13:14:19.821152
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

    # Test case for instantiating an object of class UDNEmbedIE
    test_case_0()
# Test cases for class UDNEmbedIE

# Generated at 2022-06-26 13:14:27.055290
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    version(u_d_n_embed_i_e)
    assert_equal(u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL, r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert_equal(u_d_n_embed_i_e._VALID_URL, r'https?:' + u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL)
    # assert_equal(u_d_n_embed_i_e.IE_DESC, '聯合影音')


# Generated at 2022-06-26 13:14:30.104897
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:15:08.601295
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    result_object_list = UDNEmbedIE().extract(url)
    assert result_object_list['id'] == '300040'
    assert result_object_list['ext'] == 'mp4'
    assert result_object_list['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-26 13:15:14.738200
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME == 'udn'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE.IE_KEY == 'udn'


# Generated at 2022-06-26 13:15:18.189445
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        u_d_n_embed_i_e_0_test_case_0()
    except AssertionError as a_e_var:
        print('test_UDNEmbedIE(): AssertionError = "' + str(a_e_var) + '"')
        raise


# Generated at 2022-06-26 13:15:20.240838
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert test_case_0()

# Generated at 2022-06-26 13:15:29.727787
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance_ = UDNEmbedIE()
    assert instance_.IE_DESC == '聯合影音'
    assert instance_._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert instance_._VALID_URL == 'https?:' + instance_._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:15:36.241769
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    match_id_0 = u_d_n_embed_i_e_0._match_id('https://video.udn.com/play/news/303776')
    match_id_1 = u_d_n_embed_i_e_0._match_id('https://video.udn.com/play/news/303776')
    match_id_2 = u_d_n_embed_i_e_0._match_id('http://video.udn.com/play/news/303776')
    match_id_3 = u_d_n_embed_i_e_0._match_id('https://video.udn.com/embed/news/303776')
    assert(match_id_1 == match_id_2)

# Generated at 2022-06-26 13:15:48.100375
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test with OK values
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?://video.udn.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:50.273316
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_id = 0
    video_id = 0
    page = u_d_n_embed_i_e_0._download_webpage(url_id, video_id)


# Generated at 2022-06-26 13:15:52.533445
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_1 = UDNEmbedIE()
# unit test for function _match_id

# Generated at 2022-06-26 13:15:54.411435
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:16:26.862668
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)


# Generated at 2022-06-26 13:16:35.656321
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert ie._PROTOCOL_RELATIVE_VALID_URL  == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._match_id(url) == '300040'

# Generated at 2022-06-26 13:16:40.679609
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    # "https://video.udn.com/play/news/303776"
    udne.extract('https://video.udn.com/play/news/303776')

# Generated at 2022-06-26 13:16:43.679595
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UdnEmbedIe = UDNEmbedIE()
    UdnEmbedIe._match_id(UdnEmbedIe._VALID_URL)

# Generated at 2022-06-26 13:16:54.065734
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class UDNEmbedIE(InfoExtractor):
        IE_DESC = '聯合影音'
        _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
        #_VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL
        _TESTS = []

    u = UDNEmbedIE()

# Generated at 2022-06-26 13:17:00.942371
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test build_regex
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL != UDNEmbedIE._VALID_URL
    assert len(UDNEmbedIE._VALID_URL) == len(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL) + 8

# Generated at 2022-06-26 13:17:04.127808
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Preparing the environment to run test
    """
    instance = UDNEmbedIE()
    test_instance = UDNEmbedIE()
    assert instance is not test_instance

# Generated at 2022-06-26 13:17:12.143908
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj.IE_DESC == '聯合影音'
    assert test_obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(test_obj._TESTS) == 3

# Generated at 2022-06-26 13:17:16.500163
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Arrange
    url = "https://video.udn.com/play/news/303776"
    
    # Act
    udnIE = UDNEmbedIE()
    isValid = udnIE._VALID_URL

    # Assert
    assert isValid == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnIE.IE_DESC == '聯合影音'
    assert udnIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-26 13:17:19.431740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(None)._real_initialize(url)

# Generated at 2022-06-26 13:18:41.248633
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)

    # Unit test for _PROTOCOL_RELATIVE_VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Unit test for _VALID_URL
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

    # Unit test for _TESTS

# Generated at 2022-06-26 13:18:46.302957
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_UDNEmbed = UDNEmbedIE()
    print(ie_UDNEmbed.IE_DESC)
    print(ie_UDNEmbed._VALID_URL)
    print(ie_UDNEmbed._TESTS)


# Generated at 2022-06-26 13:18:53.759143
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # Check if all member variables are initialized correctly
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:18:56.653514
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('constructor of class UDNEmbedIE')
    UDNEmbedIE()


# Generated at 2022-06-26 13:19:01.831235
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.ie_key() == 'udn'
    assert instance.IE_NAME == 'udn'
    assert instance.IE_DESC == '聯合影音'
    assert instance.VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance.embed_webpage(
        'http://video.udn.com/embed/news/300040', '300040')
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:19:09.339736
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:19:18.907150
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie.suitable(['https://video.udn.com/embed/news/300040'])
    assert not ie.suitable(['https://www.udn.com/news/story/6702/2297409'])

# Generated at 2022-06-26 13:19:26.042444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.title == '生物老師男變女 全校挺"做自己"'
    assert ie.video_id == '300040'

# Generated at 2022-06-26 13:19:28.921861
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert drmmodule.MPD


# Generated at 2022-06-26 13:19:31.604877
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    assert ie.SUFFIX == "/embed/news"

# Generated at 2022-06-26 13:22:11.811496
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # See https://github.com/rg3/youtube-dl/issues/8441
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/play/news/300040')

# Generated at 2022-06-26 13:22:14.243267
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == '聯合影音'

# Generated at 2022-06-26 13:22:25.560360
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    # Test _PROTOCOL_RELATIVE_VALID_URL
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test _VALID_URL
    assert udn_ie._VALID_URL == r'https?:' + udn_ie._PROTOCOL_RELATIVE_VALID_URL
    # Test _TESTS
    assert len(udn_ie._TESTS) == 3
    assert udn_ie._TESTS[0]['expected_warnings'] == ['Failed to parse JSON Expecting value']
    assert udn_ie._TESTS[1]['only_matching'] == True


# Generated at 2022-06-26 13:22:29.564938
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:22:37.129905
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check if the _VALID_URL is correct
    valid_url = 'https://video.udn.com/embed/news/300040'
    assert re.match(UDNEmbedIE._VALID_URL, valid_url)
    # Check if the _PROTOCOL_RELATIVE_VALID_URL is correct
    protocol_relative_valid_url = '//video.udn.com/embed/news/300040'
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, protocol_relative_valid_url)

# Generated at 2022-06-26 13:22:45.887313
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('test_UDNEmbedIE ...')
    ie = UDNEmbedIE()
    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = 'https?:' + _PROTOCOL_RELATIVE_VALID_URL