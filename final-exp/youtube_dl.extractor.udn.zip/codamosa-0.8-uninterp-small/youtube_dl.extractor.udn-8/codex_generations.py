

# Generated at 2022-06-26 13:12:48.973002
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()


# Generated at 2022-06-26 13:12:50.067141
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()

# Generated at 2022-06-26 13:12:58.501959
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create a VideoInfoExtractor object
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:12:59.397344
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-26 13:13:00.412014
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert test_case_0() == None


# Generated at 2022-06-26 13:13:05.995986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    # test the function _real_extract
    u_d_n_embed_i_e._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:13:08.196359
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # video_id =
    # assert_equal(u_d_n_embed_i_e_0._real_extract(video_id), {'url': 'http://video.udn.com/embed/news/300040'})
    pass


# Generated at 2022-06-26 13:13:19.182931
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()
    print(u_d_n_embed_i_e_0)
    # 此测试用例说明UDN页面整体框架，网页分为头部，body，底部，body（内容部分）其实是指两个标签之间的内容，如：
    # <body onload="window.scroll(0,0);" class="body">
    #  <div id="main">
    #   <div class="video_player" data

# Generated at 2022-06-26 13:13:21.513509
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:13:34.650088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME == 'udn'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-26 13:13:45.176493
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    url = 'https://video.udn.com/embed/news/%s' % video_id
    udne = UDNEmbedIE()
    assert udne._match_id(url) == video_id
    assert re.match(udne._PROTOCOL_RELATIVE_VALID_URL, url)
    assert re.match(udne._VALID_URL, url)

# Generated at 2022-06-26 13:13:52.640974
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert udnEmbedIE._match_id(url) == '300040'
    assert udnEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:13:56.089310
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = UDNEmbedIE._VALID_URL
    assert url == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:14:07.273208
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(embed|play)/news/(?P<id>\\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-26 13:14:17.060465
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.search(r'{"video"', js_to_json(r"options={video:'http://v.udn.com.tw/upf/newmedia/2016_data/20160427_taipei_video/json/taipei_video_091.json'}", True)) == None
    assert re.search(r'{"video"', js_to_json(r"options={video:'http://v.udn.com.tw/upf/newmedia/2016_data/20160427_taipei_video/json/taipei_video_091.json'}", False)) != None

# Generated at 2022-06-26 13:14:21.752943
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video = UDNEmbedIE().suitable(url)
    assert(video != None)
    assert(video.download(url))

# Generated at 2022-06-26 13:14:27.696358
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME == 'UDNEmbed'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE.IE_CAN_EXTRACT_URL == True
    assert UDNEmbedIE.IE_CAN_EMBED_URL == False
    assert UDNEmbedIE.IE_CAN_BE_EMBEDDED == False
    assert UDNEmbedIE.IE_CAN_BE_SELFHOSTED == False
    assert UDNEmbedIE.PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.VALID_URL == r'https?:' + UDNEmb

# Generated at 2022-06-26 13:14:34.549640
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _loading = UDNEmbedIE(None)
    assert all(re.match(pattern, _loading._VALID_URL) for pattern in _loading._TESTS)
    _loading = UDNEmbedIE(None)
    assert re.match(_loading._VALID_URL, _loading._TESTS[0]['url'])

# Generated at 2022-06-26 13:14:47.814980
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?:(?:/{2}|\*\.)video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 13:14:48.489485
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UDNEmbed'

# Generated at 2022-06-26 13:15:02.562704
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-26 13:15:05.350143
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')


# Generated at 2022-06-26 13:15:07.703274
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')


# Generated at 2022-06-26 13:15:09.927896
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    Instance = UDNEmbedIE()
    print (Instance)


# Generated at 2022-06-26 13:15:20.175417
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """ Test case for default constructor of class UDNEmbedIE """

    ie = UDNEmbedIE()

    assert ie.ie_key() == 'UdnEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 13:15:27.949745
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    case_of_valid_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie._match_id(case_of_valid_url) == '300040'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-26 13:15:37.702336
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.suitable('http://video.udn.com/embed/news/300040')
    assert UDNEmbedIE.suitable('http://video.udn.com/play/news/300040')
    assert UDNEmbedIE.suitable('//video.udn.com/play/news/300040')
    assert UDNEmbedIE.suitable('//video.udn.com/embed/news/300040')

    assert not UDNEmbedIE.suitable('http://video.udn.com/news/300040')
    assert not UDNEmbedIE.suitable('http://video.udn.com/video/300040')
    assert not UDNEmbedIE.suitable('http://video.udn.com/video/300040/')
    assert not UDNEmbed

# Generated at 2022-06-26 13:15:46.090686
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # a sample URL to be parsed by UDNEmbedIE
    udn_url = 'http://video.udn.com/embed/news/300040'
    video_id = udn_embed_ie._match_id(udn_url)
    assert video_id == '300040'
    assert udn_embed_ie._VALID_URL == udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:15:50.385800
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:15:53.756992
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # check whether the constructor of class UDNEmbedIE raise error
    # when given an incorrect input
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDNEmbed'
    assert udn_embed_ie.ie_desc() == '聯合影音'

# Generated at 2022-06-26 13:16:26.605402
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_NAME == 'udn'
    assert udn.IE_DESC == '聯合影音'
    assert udn._VALID_URL == 'http://video.udn.com/embed/news/300040'
    assert udn._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-26 13:16:28.398743
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie
    assert isinstance(udn_embed_ie, InfoExtractor)



# Generated at 2022-06-26 13:16:38.350368
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    infoExtractor = InfoExtractor()
    UDNEmbedIE.ie_key = 'UDNEmbed'
    infoExtractor.add_ie(UDNEmbedIE)
    # http://video.udn.com/embed/news/300040
    infoExtractor._ies = dict()  # reset
    result = infoExtractor.extract("http://video.udn.com/embed/news/300040")
    assert result['url'] == 'http://video.udn.com/embed/news/300040'
    print(result)
    # https://video.udn.com/embed/news/300040
    result = infoExtractor.extract("https://video.udn.com/embed/news/300040")

# Generated at 2022-06-26 13:16:44.791608
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
     u = UDNEmbedIE('')
     assert_equal('聯合影音', u.IE_DESC)
     assert_equal(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, u._PROTOCOL_RELATIVE_VALID_URL)
     assert_equal(UDNEmbedIE._VALID_URL, u._VALID_URL)
     assert_equal(UDNEmbedIE._TESTS, u._TESTS)

# Generated at 2022-06-26 13:16:57.450398
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    sql_content = 'INSERT INTO `video_site_link` (`id`, `site`, `link`) VALUES ("300040", "udn", "http://video.udn.com/embed/news/300040");'

# Generated at 2022-06-26 13:17:00.039525
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Without validating URL
    UDNEmbedIE(None, None, None)

# Generated at 2022-06-26 13:17:06.868900
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test with a valid url
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().match(url)

    # Test with a non-UDNEmbedIE url
    url = 'http://google.com/'
    obj = UDNEmbedIE()
    assert obj.match(url) is None

    # Test with a non-existed-scheme URL
    url = 'udn://video.udn.com/embed/news/300040'
    assert obj.match(url) is None

    return 'Test passed.'

# Generated at 2022-06-26 13:17:11.356716
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    udn_embed_ie.extract(url)

# Generated at 2022-06-26 13:17:16.311004
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('udn', 'http://video.udn.com/embed/news/300040', '300040')
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 13:17:18.852977
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_interfaces import _test
    udn = UDNEmbedIE()
    _test(udn)

# Generated at 2022-06-26 13:18:21.567588
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:18:25.355253
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040'))

# Generated at 2022-06-26 13:18:31.267236
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert (isinstance(IE, InfoExtractor))
    assert (IE.IE_NAME == 'udn')
    assert (IE.IE_DESC == '聯合影音')
    assert (IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-26 13:18:33.326802
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, {})

# Generated at 2022-06-26 13:18:39.521549
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.suitable('https://video.udn.com/play/news/303776')
    # Make sure the regular expression for _PROTOCOL_RELATIVE_VALID_URL works
    assert ie.suitable('//video.udn.com/play/news/303776')
    assert ie.suitable('//video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:18:46.569623
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:18:59.166736
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

  from unittest import TestCase
  from copy import copy
  exp_params_1 = {
    'skip_download': True,
  }
  exp_warnings_1 = ['Failed to parse JSON Expecting value']
  url_1 = 'http://video.udn.com/embed/news/300040'
  test_case = TestCase()
  udn_embed = UDNEmbedIE()
  test_case.assertEqual(udn_embed._match_id(url_1), '300040')
  test_case.assertEqual(udn_embed._TESTS[0]['url'], url_1)
  test_case.assertEqual(udn_embed._TESTS[0]['expected_warnings'], exp_warnings_1)
  test_case.assertEqual

# Generated at 2022-06-26 13:19:00.120529
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-26 13:19:10.719117
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_UDNEmbedIE.UDNEmbedIE = UDNEmbedIE

    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:19:12.103171
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pass
    UDNEmbedIE()

# Generated at 2022-06-26 13:21:18.940195
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()

# Generated at 2022-06-26 13:21:21.394561
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except Exception:
        assert False


# Generated at 2022-06-26 13:21:30.348839
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    url = 'http://video.udn.com/embed/news/' + video_id
    # test constructor
    ie = UDNEmbedIE()
    # test when URL is valid
    assert ie._match_id(url) == video_id
    # test when URL is protocol relative
    assert ie._match_id('//video.udn.com/embed/news/300040') == video_id
    # test when URL is invalid
    assert ie._match_id('http://video.udn.com/embed/news/invalid_video_id') is None

# Generated at 2022-06-26 13:21:31.760281
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-26 13:21:38.977587
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert pattern.match('//video.udn.com/embed/news/300040')
    assert not pattern.match('//video.udn.com/play/news/300040')

# Generated at 2022-06-26 13:21:51.477023
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_DESC == '聯合影音'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == 'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:21:52.758353
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:21:54.863752
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:21:56.300200
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()


# Generated at 2022-06-26 13:22:00.703599
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """ Test the UDNEmbedIE constructor """
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'