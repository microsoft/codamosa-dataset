

# Generated at 2022-06-26 13:12:54.828115
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()
    assert isinstance(u_d_n_embed_i_e_0, InfoExtractor)
    assert u_d_n_embed_i_e_0._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'


# Generated at 2022-06-26 13:12:56.229498
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Dummy
    pass


# Generated at 2022-06-26 13:13:05.238156
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    assert hasattr(u_d_n_embed_i_e_0, 'ie_keywords')
    assert u_d_n_embed_i_e_0.ie_keywords == ('udn',)

    assert hasattr(u_d_n_embed_i_e_0, '_VALID_URL')
    assert u_d_n_embed_i_e_0._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    assert hasattr(u_d_n_embed_i_e_0, '_PROTOCOL_RELATIVE_VALID_URL')

# Generated at 2022-06-26 13:13:16.955477
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()
    assert u_d_n_embed_i_e_0._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u_d_n_embed_i_e_0._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:13:25.711507
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:13:32.160724
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert_raises(RegexNotFoundError, u_d_n_embed_i_e_0._real_extract, "")
    assert_raises(RegexNotFoundError, u_d_n_embed_i_e_0._real_extract, "")


# Generated at 2022-06-26 13:13:34.634074
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:36.511632
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()

# Unit test checker

# Generated at 2022-06-26 13:13:41.762765
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *')
    print('*                                                    Unit Testing for class UDNEmbedIE                                                                  *')
    print('* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *')

    # Test 1: Instantiation of class UDNE

# Generated at 2022-06-26 13:13:47.966417
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL
    assert UDNEmbedIE._TESTS
    assert UDNEmbedIE.IE_DESC


# Generated at 2022-06-26 13:13:56.021470
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()


# Generated at 2022-06-26 13:14:07.244159
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # constructor of class UDNEmbedIE(InfoExtractor)
    instance = UDNEmbedIE()
    #
    # property of class UDNEmbedIE
    # instance.ie_key()
    # instance.ie_desc()
    # instance.ie_key() == 'UDNEmbed'
    # instance.ie_desc() == '聯合影音'
    # instance.EGOTISTICAL_GIRL == 'http://www.youtube.com/watch?v=9ZiYnGQE7eI'
    # instance.SUIT_MAN == 'http://www.youtube.com/watch?v=F8T7f2DG6l0'
    #
    # method of class UDNEmbedIE
    instance.workingDir()
    instance.cacheDir()
   

# Generated at 2022-06-26 13:14:08.859344
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("http://some.url")
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:14:16.188872
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL   \
        == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL \
        == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._TESTS[0]['url'] \
        == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:14:26.927234
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'


# Generated at 2022-06-26 13:14:36.708217
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test to see if regex can parse the video page correctly"""
    udn_embed = UDNEmbedIE()
    assert udn_embed.IE_NAME == 'udn'

    # Normal test
    udn_embed_url = 'https://video.udn.com/embed/news/300040'
    # Protocol relative test
    udn_embed_url_2 = '//video.udn.com/embed/news/300040'

    assert udn_embed._match_id(udn_embed_url) == '300040'
    assert udn_embed._match_id(udn_embed_url_2) == '300040'

# Generated at 2022-06-26 13:14:43.843537
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for _key, _value in UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.items():
        # test '_PROTOCOL_RELATIVE_VALID_URL'
        _test_url = 'http:' + _value
        assert _test_url == UDNEmbedIE._VALID_URL

# Generated at 2022-06-26 13:14:48.130442
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # Test with a valid url
    url = 'http://video.udn.com/embed/news/300040'
    url_valid = UDNEmbedIE._VALID_URL
    url_valid_compiled = re.compile(url_valid)
    match = url_valid_compiled.search(url)
    assert(match)


# Generated at 2022-06-26 13:14:51.714787
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(UDNEmbedIE._downloader, test_url)

# Generated at 2022-06-26 13:14:58.401338
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # http://tools.ietf.org/html/rfc3986#section-1.1.2
    # http://tools.ietf.org/html/rfc3986#section-3.3
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:15:20.792563
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_downloader import _test_generic_info_extractor

# Generated at 2022-06-26 13:15:22.115827
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:15:27.844648
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, 'https://video.udn.com/embed/news/300040')
    UDNEmbedIE(None, 'http://video.udn.com/embed/news/300040')
    UDNEmbedIE(None, 'http://video.udn.com/play/news/300040')
    UDNEmbedIE(None, '//video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:15:37.652016
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class TempUDNEmbedIE(UDNEmbedIE):
        def __init__(self):
            super(TempUDNEmbedIE, self).__init__()
            self.info_dict_list = []
            self.url_list = []
            self.next_page_req_list = []
    temp_udn_embed_ie = TempUDNEmbedIE()
    test_urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040'
    ]
    for url in test_urls:
        temp_udn_embed_ie._extract_info(url)
    assert len(temp_udn_embed_ie.info_dict_list) == len(test_urls)
   

# Generated at 2022-06-26 13:15:41.244395
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE is not InfoExtractor

# Test for method _real_extract of class UDNEmbedIE

# Generated at 2022-06-26 13:15:44.470170
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        IE = UDNEmbedIE()
    except Exception as e:
        print('UDNEmbedIE exception:', IE, e)
    else:
        assert(IE != None)
        assert(isinstance(IE, InfoExtractor))
        assert(IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
        assert(IE.IE_DESC == '聯合影音')


# Test download video

# Generated at 2022-06-26 13:15:46.215957
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    Udnie = UDNEmbedIE()

# Generated at 2022-06-26 13:15:48.831490
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE('http://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-26 13:15:53.977369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 13:16:06.126531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    valid_urls = [u'http://video.udn.com/embed/news/300040', u'https://video.udn.com/embed/news/300040']
    invalid_urls = [
        u'http://video.udn.com/embed/live/300040',
        u'http://video.udn.com/embed/live/300040',
        u'http://video.udn.com/embed/live/news/300040',
        u'http://video.udn.com/news/300040',
        u'http://video.udn.com/news/index/300040',
        u'http://video.udn.com/news/index/300040/1',
    ]

    # Check single good URLs

# Generated at 2022-06-26 13:16:42.722253
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    # test._match_id
    assert test._match_id('http://video.udn.com/embed/news/300040') == '300040'
    # test._match_id for protocol-relative URL
    assert test._match_id('//video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-26 13:16:44.993482
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:50.426798
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    assert udnEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:59.164540
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE("https://video.udn.com/embed/news/300040")
    assert a._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert a._VALID_URL == r'https?:' + a._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:17:06.264483
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('www-udn-com')
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._WORKING == True

# Generated at 2022-06-26 13:17:16.732957
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_list = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        '//video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/303776'
    ]
    for url in url_list:
        inst = UDNEmbedIE()
        if isinstance(inst, InfoExtractor) is False:
            raise AssertionError('UDNEmbedIE() is not an instance of InfoExtractor')
        if inst.IE_DESC != '聯合影音':
            raise AssertionError('IE_DESC is not "聯合影音"')

# Generated at 2022-06-26 13:17:23.157212
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_youtube import ie_tests
    for t in ie_tests:
        t['url'] = t['url'].replace('youtube.com/', 'video.udn.com/embed/')
        t['info_dict']['id'] = "300040"
    UDNEmbedIE()._run_test(ie_tests)

# Generated at 2022-06-26 13:17:25.232104
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	assert UDNEmbedIE("https://")._match_id("https://video.udn.com/embed/news/300040")

# Generated at 2022-06-26 13:17:27.475539
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie != None

# Generated at 2022-06-26 13:17:37.284084
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbed_test = UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
    assert "http://video.udn.com/embed/news/300040" == UDNEmbed_test['id']
    assert "mp4" == UDNEmbed_test['formats'][0]['ext']

# Generated at 2022-06-26 13:18:51.697436
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE

# Generated at 2022-06-26 13:18:55.085841
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Test generic extraction using constructor of class UDNEmbedIE

# Generated at 2022-06-26 13:18:58.997664
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == 'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:19:01.247504
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 13:19:07.877783
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'udn'
    assert ie.domain() == 'video.udn.com'
    assert ie.url_re() == re.compile(r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-26 13:19:20.933090
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import get_testdata_file

    # URL with all info
    video_url = 'http://video.udn.com/embed/news/300040'
    test_video = UDNEmbedIE()._real_extract(video_url)
    # Only need to test if the info is correct based on test_video_url
    assert test_video['id'] == '300040'
    assert test_video['title'] == '生物老師男變女 全校挺"做自己"'

    # URL without any info
    video_url = 'https://video.udn.com/news/303776'
    test_video = UDNEmbedIE()._real_extract(video_url)
    # Only need to test if the info

# Generated at 2022-06-26 13:19:30.125566
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('300040')
    assert ie.IE_NAME == 'embed.udn.com'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-26 13:19:41.421161
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    assert UDNEmbedIE._match_id(url) == '303776'
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    matches = re.search(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, url)
    groups = matches.groupdict()
    assert groups['id'] == '303776'


# Generated at 2022-06-26 13:19:50.903355
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'

    video_id = UDNEmbedIE._match_id(url)
    try:
        UDNEmbedIE._real_extract(
            UDNEmbedIE(),
            url,
            video_id)

    except Exception as e:
        print('exception in ' + video_id + '\n' + str(e))

# Generated at 2022-06-26 13:19:52.227503
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test that the initializer works
    udn = UDNEmbedIE()

# Generated at 2022-06-26 13:22:39.561641
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        ie = UDNEmbedIE()
        assert(ie._PROTOCOL_RELATIVE_VALID_URL)
    except AssertionError:
        print('AssertionError: Fail to test constructor of class UDNEmbedIE')
    else:
        print('Pass to test constructor of class UDNEmbedIE')


# Generated at 2022-06-26 13:22:45.708433
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test the constructor of class UDNEmbedIE.
    """
    instance = UDNEmbedIE()
    assert instance.IE_NAME == ('udn:embed', 'udn')
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == r'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    assert instance.IE_DESC == '聯合影音'
    return