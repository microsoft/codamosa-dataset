

# Generated at 2022-06-26 13:12:51.791851
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    return u_d_n_embed_i_e


# Generated at 2022-06-26 13:13:01.831539
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert hasattr(UDNEmbedIE, '_PROTOCOL_RELATIVE_VALID_URL'), '_PROTOCOL_RELATIVE_VALID_URL is not attribute'
    assert hasattr(UDNEmbedIE, '_VALID_URL'), '_VALID_URL is not attribute'
    assert hasattr(UDNEmbedIE, '_TESTS'), '_TESTS is not attribute'
    assert hasattr(UDNEmbedIE, 'IE_DESC'), 'IE_DESC is not attribute'



# Generated at 2022-06-26 13:13:11.201127
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()

# Generated at 2022-06-26 13:13:14.981534
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL() == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL()

# Generated at 2022-06-26 13:13:16.359785
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()

# Generated at 2022-06-26 13:13:19.904002
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:23.985486
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert_equal(u_d_n_embed_i_e_0.IE_DESC, '聯合影音')
    assert_equal(u_d_n_embed_i_e_0._VALID_URL, r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')


# Generated at 2022-06-26 13:13:25.099591
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-26 13:13:35.398170
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC
    assert UDNEmbedIE._VALID_URL
    assert UDNEmbedIE.__name__
    assert UDNEmbedIE._TESTS
    assert UDNEmbedIE._download_webpage
    assert UDNEmbedIE._html_search_regex
    assert UDNEmbedIE._match_id
    assert UDNEmbedIE._parse_json
    assert UDNEmbedIE._real_extract
    assert UDNEmbedIE._sort_formats
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Unit Test for method _real_extract of class UDNEmbedIE

# Generated at 2022-06-26 13:13:41.796833
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e._match_id(url) == '300040', 'test_UDNEmbedIE: Failed to match id.'


# Generated at 2022-06-26 13:13:53.739502
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    expected_result = {
        'id': '300040',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
        'ext': 'mp4',
        'skip_download': True
    }
    result = UDNEmbedIE()._real_extract(url)
    assert(result == expected_result)

# Generated at 2022-06-26 13:14:02.019995
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    print (ie.extract(url))
    assert ie.extract(url)
    # assert ie.extract(url)['title'] == '2015 數位浪人假日 張震嶽'

# Generated at 2022-06-26 13:14:05.480620
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE.suitable(url)
    u = UDNEmbedIE()
    u._match_id(url)
    u._extract_urls(url)

# Generated at 2022-06-26 13:14:08.667103
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Instance of UDNEmbedIE()
    UDNEmbedIE_instance = UDNEmbedIE()

# Generated at 2022-06-26 13:14:13.038080
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_obj = InfoExtractor()
    UDNEmbedIE._build_url_result(ie_obj, "http://video.udn.com/embed/news/300040", "Youtube")

# Generated at 2022-06-26 13:14:13.788641
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE is not None

# Generated at 2022-06-26 13:14:18.995937
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:14:26.975904
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert_equals(
        udn_embed_ie.IE_DESC,
        '聯合影音'
    )
    assert_equals(
        udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL,
        r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    )
    assert_equals(
        udn_embed_ie._VALID_URL,
        r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    )

# Generated at 2022-06-26 13:14:30.042282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-26 13:14:31.485179
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:14:49.840823
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert(instance.IE_NAME == 'udn')
    assert(instance.IE_DESC == '聯合影音')
    assert(instance.IE_VERSION == '20171218')
    assert(instance.VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')
    assert(instance.ie._WORKING == True)


# Generated at 2022-06-26 13:14:50.591539
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #constructor should not return None when initialized
    assert UDNEmbedIE() != None

# Generated at 2022-06-26 13:14:52.467123
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert(ie.ie_key() == 'UDNEmbed')
    assert(ie.IE_DESC == '聯合影音')
    assert(ie.suitable('https://video.udn.com/embed/news/300040') == True)

# Generated at 2022-06-26 13:14:59.070566
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei is not None
    assert udnei._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnei.name == '聯合影音'
    assert udnei.IE_DESC == '聯合影音'
    assert udnei._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:00.615692
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-26 13:15:03.253252
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Test if the constructor can be called
    '''
    UDNEmbedIE()

# Generated at 2022-06-26 13:15:06.578805
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import FakeYDL
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, FakeYDL)

# Generated at 2022-06-26 13:15:16.209582
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # URL for testing
    url = 'http://video.udn.com/embed/news/300040'
    # Create a UDNEmbedIE instance
    instance = UDNEmbedIE(url)
    # Get the data from UDNEmbedIE with the URL
    data = instance._real_extract(url)
    # Print the title of the URL
    print(data['title'])
    # Print the formats of the URL
    print(data['formats'])


# Generated at 2022-06-26 13:15:23.569370
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(expect_warning=True)
    ie.extract('http://video.udn.com/embed/news/300040')
    ie.extract('https://video.udn.com/embed/news/300040')
    ie.extract('http://video.udn.com/play/news/300040')

# Generated at 2022-06-26 13:15:25.363193
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Make sure we can construct a UDNEmbedIE object
    UDNEmbedIE()

# Generated at 2022-06-26 13:15:58.738749
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 13:16:04.312855
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for the constructor of class UDNEmbedIE
    # it tests if the instance of the class UDNEmbedIE is created
    mgr = InfoExtractor._create_ie_for_url('http://video.udn.com/embed/news/300040').__class__.__name__
    assert(mgr == 'UDNEmbedIE')

# Generated at 2022-06-26 13:16:14.246270
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/play/news/303776')
    assert ie._match_id('http://video.udn.com/play/news/303776') == '303776'
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/play/news/303776') == '303776'
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-26 13:16:20.734034
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    t = UDNEmbedIE()
    assert len(t._TESTS) > 0


# TODO: Add test cases for method _real_extract of class UDNEmbedIE
# def test_UDNEmbedIE__real_extract():
#     pass

# Generated at 2022-06-26 13:16:23.467085
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembedie = UDNEmbedIE()
    assert udnembedie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:16:30.116578
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import os.path

    def test_file(name):
        return os.path.join(os.path.dirname(__file__), 'test_data', name)

    def test_url(input, expect):
        output = UDNEmbedIE._match_id(input)
        assert output == expect, 'input={}, output={}, expect={}'.format(input,
                                                                         output,
                                                                         expect)
    
    test_url('//video.udn.com/embed/news/300040', '300040')
    test_url('https://video.udn.com/embed/news/300040', '300040')
    test_url('https://video.udn.com/play/news/300040', '300040')
    

# Generated at 2022-06-26 13:16:38.858186
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.f4m import F4MFD
    from youtube_dl.downloader.m3u8 import M3U8FD

    ie = UDNEmbedIE()

    assert ie.IE_DESC == '聯合影音'

    # test _PROTOCOL_RELATIVE_VALID_URL
    assert ie._match_id(
        '//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id(
        '//video.udn.com/play/news/300040') == '300040'

    # test _VALID_URL

# Generated at 2022-06-26 13:16:40.621474
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    global UDNEmbedIE
    UDNEmbedIE()

# Generated at 2022-06-26 13:16:45.778506
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_DESC == '聯合影音'
    assert instance._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == 'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    assert len(instance._TESTS) == 3



# Generated at 2022-06-26 13:16:48.167620
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._download_webpage('asdfasdf')

# Generated at 2022-06-26 13:17:47.041106
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # regex test
    regex = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    m = regex.match("//video.udn.com/embed/news/300040")
    assert("300040" == m.group('id'))

    # TODO: unit test for _real_extract

# Generated at 2022-06-26 13:17:49.985910
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-26 13:17:56.463243
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL.startswith('//')
    assert ie._VALID_URL.startswith('http')
    assert ie._VALID_URL.find(ie._PROTOCOL_RELATIVE_VALID_URL) > 0

# Generated at 2022-06-26 13:18:08.673499
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == ie._PROTOCOL_RELATIVE_VALID_URL.replace('//', '')
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:18:15.348125
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    c = UDNEmbedIE()
    assert c._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert c._VALID_URL == r'https?:' + c._PROTOCOL_RELATIVE_VALID_URL



# Generated at 2022-06-26 13:18:19.669272
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_class = UDNEmbedIE()
    print(test_class._match_id('https://video.udn.com/embed/news/300040'))

# Generated at 2022-06-26 13:18:29.157413
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Create instance of UDNEmbedIE
    """
    test_url = 'https://video.udn.com//embed/news/300040'
    ie = UDNEmbedIE()
    # See https://github.com/rg3/youtube-dl/issues/9416#issuecomment-149973530
    info = ie._info_dict_for_url(test_url)
    assert info['url'] == test_url
    assert info['id'] == '300040'
    assert info['title'] == '生物老師男變女 全校挺"做自己"'
    assert info['thumbnail']

# Generated at 2022-06-26 13:18:30.396384
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:18:35.511158
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = globals()['UDNEmbedIE']
    obj = class_('http://video.udn.com/embed/news/300040')
    assert class_ == obj.__class__

# Generated at 2022-06-26 13:18:37.543355
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None


# Generated at 2022-06-26 13:20:59.701851
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    assert udneie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:21:04.829959
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_test = UDNEmbedIE()
    ie_test.suitable('https://video.udn.com/embed/news/300040')
    ie_test.suitable('http://video.udn.com/play/news/300040')

# Generated at 2022-06-26 13:21:07.606057
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_initialize(url)

# Generated at 2022-06-26 13:21:11.542569
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    The test case checks if the class UDNEmbedIE is successfully built.
    """
    _ = UDNEmbedIE()



# Generated at 2022-06-26 13:21:14.262273
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        c = UDNEmbedIE()
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-26 13:21:22.122670
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)

# Generated at 2022-06-26 13:21:26.117812
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None)

# Testing whether do_download() method of class UDNEmbedIE works properly

# Generated at 2022-06-26 13:21:32.621737
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.SUFFIX == '^[A-Z0-9]+$'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>[A-Z0-9]+)'

# Generated at 2022-06-26 13:21:39.653949
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE().url_result(url, 'UDNEmbed')

    url = 'https://video.udn.com/play/news/303776'
    UDNEmbedIE().url_result(url, 'UDNEmbed')

# Generated at 2022-06-26 13:21:46.566309
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL