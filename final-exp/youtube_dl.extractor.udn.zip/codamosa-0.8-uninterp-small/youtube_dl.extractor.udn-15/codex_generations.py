

# Generated at 2022-06-26 13:12:49.800552
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:12:58.420029
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("\nCalling u_d_n_embed_i_e = UDNEmbedIE()")
    u_d_n_embed_i_e = UDNEmbedIE()
    if u_d_n_embed_i_e is None:
        print("Failed to create u_d_n_embed_i_e!")
        assert False
    else:
        print("Successfully created u_d_n_embed_i_e!")
        assert True
    print("\nu_d_n_embed_i_e.IE_DESC = %s" % u_d_n_embed_i_e.IE_DESC)
    assert u_d_n_embed_i_e.IE_DESC == "聯合影音"

# Generated at 2022-06-26 13:12:59.709530
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-26 13:13:12.616369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()
    assert u'download' in dir(u_d_n_embed_i_e_0)
    assert u'compat_urlparse' in dir(u_d_n_embed_i_e_0)
    assert u'urlopen' in dir(u_d_n_embed_i_e_0)
    assert u'url_result' in dir(u_d_n_embed_i_e_0)
    assert u'url_basename' in dir(u_d_n_embed_i_e_0)
    assert u'_match_id' in dir(u_d_n_embed_i_e_0)

# Generated at 2022-06-26 13:13:19.735515
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert m_UDNEmbedIE.IE_DESC == "聯合影音"
    assert m_UDNEmbedIE._VALID_URL == re.compile(r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert m_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:13:21.523932
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 13:13:27.712065
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert_equal(u_d_n_embed_i_e_0.ie_key(), 'UDNEmbed')
    assert_equal(u_d_n_embed_i_e_0.ie_desc(), '聯合影音')


# Generated at 2022-06-26 13:13:29.541018
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:13:34.791304
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e
    assert u_d_n_embed_i_e.ie_key() == 'UDNEmbed'
    assert u_d_n_embed_i_e.ie_desc() == '聯合影音'


test_case_0()

# Generated at 2022-06-26 13:13:37.201564
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()



# Generated at 2022-06-26 13:13:56.452924
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Testing tuple assignment
    options = {}

# Generated at 2022-06-26 13:13:59.849695
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:14:01.940990
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    t_c_0 = test_case_0()


# Generated at 2022-06-26 13:14:03.358436
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'coding' == u_d_n_embed_i_e_0._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:14:07.356431
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    # Member variable _VALID_URL of class UDNEmbedIE
    u_d_n_embed_i_e._VALID_URL
    # Member variable _PROTOCOL_RELATIVE_VALID_URL of class UDNEmbedIE
    u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-26 13:14:08.169820
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-26 13:14:09.761040
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()
    assert u_d_n_embed_i_e_0 is not None


# Generated at 2022-06-26 13:14:11.091798
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:14:15.411657
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i_e = UDNEmbedIE()
    i_e.extract('http://video.udn.com/embed/news/300040')
    i_e.extract('http://video.udn.com/embed/news/300040')
    i_e.extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:14:16.790441
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-26 13:14:34.377843
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:14:47.779116
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor.IE_NAME == 'udn'
    assert extractor.IE_DESC == '聯合影音'
    assert extractor._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert extractor._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert extractor._TESTS[0]['info_dict']['id'] == '300040'
    assert extractor._TESTS

# Generated at 2022-06-26 13:14:50.380517
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Basic test case for testing construction of class UDNEmbedIE
    """
    UDNEmbedIE()

# Generated at 2022-06-26 13:14:56.844005
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_test = UDNEmbedIE(None) 
    resp = url_test._real_extract('http://video.udn.com/embed/news/300040')
    
    assert resp['id'] == '300040'
    assert resp['ext'] == 'mp4'
    assert resp['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-26 13:15:08.876025
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class Test1(UDNEmbedIE):
        pass

    assert Test1._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert Test1._VALID_URL == 'https?:' + Test1._PROTOCOL_RELATIVE_VALID_URL
    assert Test1.IE_DESC == '聯合影音'

    class Test2(UDNEmbedIE):
        _PROTOCOL_RELATIVE_VALID_URL = '//test\.test\.test/(?P<id>\d+)'

    assert Test2._PROTOCOL_RELATIVE_VALID_URL == '//test\.test\.test/(?P<id>\d+)'
    assert Test2._

# Generated at 2022-06-26 13:15:19.748089
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:26.284175
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE().working_instance()
    info = ie.extract(url)
    assert info['id'] == '300040'
    assert info['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-26 13:15:36.598945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case = {
        'url' : 'http://video.udn.com/embed/news/300040',
        'info_dict' : {
            'id' : '300040',
            'ext' : 'mp4',
            'title' : '生物老師男變女 全校挺"做自己"',
            'thumbnail' : r're:^https?://.*\.jpg$'
        },
        'skip' : 'You need to install ffmpeg and avconv to run this unit test'
    }
    udn_embed_ie = UDNEmbedIE()
    udn_embed_ie.extract(test_case['url'])

# Generated at 2022-06-26 13:15:42.441314
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.ie_key() == 'UDNEmbed'
    assert IE.IE_NAME == '聯合影音'
    assert IE.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:15:48.101750
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # neither http:// nor https:// prefix
    assert re.match(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040') is not None
    assert re.match(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/play/news/300040') is not None

# Generated at 2022-06-26 13:16:18.585734
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
  UDNEmbedIE('http://video.udn.com/embed/news/297790', {'skip_download': True}, 'youtube')

# Generated at 2022-06-26 13:16:28.411311
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE()
    assert udnIE.IE_NAME == 'udn'
    assert udnIE.IE_DESC == '聯合影音'
    assert udnIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:32.072388
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:16:35.956922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert hasattr(UDNEmbedIE, '_VALID_URL')
    assert hasattr(UDNEmbedIE, '_PROTOCOL_RELATIVE_VALID_URL')
    assert hasattr(UDNEmbedIE, '_TESTS')

# Generated at 2022-06-26 13:16:45.948403
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inputs = {
        '//video.udn.com/embed/news/300040':
            {'url': 'http://video.udn.com/embed/news/300040'},
        '//video.udn.com/embed/news/300040':
            {'url': 'https://video.udn.com/embed/news/300040'},
        '//video.udn.com/play/news/303776':
            {'url': 'https://video.udn.com/play/news/303776'},
    }

# Generated at 2022-06-26 13:16:51.258538
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.ie._TESTS

# Generated at 2022-06-26 13:16:54.275428
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_test = UDNEmbedIE(None)
    print('test_UDNEmbedIE:', udne_test)

# Generated at 2022-06-26 13:17:06.324974
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._T

# Generated at 2022-06-26 13:17:10.184440
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE().suitable(test_url) == True, 'Given URL: ' + test_url +\
        'is not valid. Expects True.'
    assert UDNEmbedIE().IE_NAME == 'udn.com:video'
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:17:12.873865
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()
    assert class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:18:21.920121
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test for UDNEmbedIE constructor"""
    UDNEmbedIE.get_info = lambda s, url: url
    url = 'http://video.udn.com/embed/news/300040'
    expected = 'http://video.udn.com/embed/news/300040'
    actual = UDNEmbedIE()._real_extract(url)
    assert expected == actual
    url = 'https://video.udn.com/embed/news/300040'
    expected = 'https://video.udn.com/embed/news/300040'
    actual = UDNEmbedIE()._real_extract(url)
    assert expected == actual
    url = '//video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:18:30.525653
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/303776'
    udne = UDNEmbedIE()
    # Get 'IE_DESC' of class UDNEmbedIE
    #assert udne.IE_DESC == '聯合影音'
    # Get '_VALID_URL' of class UDNEmbedIE
    #assert udne._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Get URL id
    #assert udne._match_id(url) == '303776'
    # Download webpage
    webpage = udne._download_webpage(url, '303776')
    # Search dictionary of options from webpage
    options_str

# Generated at 2022-06-26 13:18:38.030181
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("https://video.udn.com/embed/news/300040")
    assert ie.REQUEST(ie.VIDEO_URLS_TEMPLATE % "300040")
    # will be None, since "options" is not found in the page and no options
    # will be injected into it
    assert ie.video_urls is None


# Generated at 2022-06-26 13:18:43.185993
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    print('udn_embed_ie', udn_embed_ie)

if __name__ == "__main__":
    # test_UDNEmbedIE()
    pass

# Generated at 2022-06-26 13:18:52.144829
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    with open('nadolib/test/test_data/test_udn.html') as file:
        udn._download_webpage = lambda url, video_id: file
        assert udn._match_id('http://video.udn.com/embed/news/300040') == '300040'
        assert udn._match_id('http://video.udn.com/embed/news/300040')
        assert udn._match_id('https://video.udn.com/embed/news/300040')
        assert not udn._match_id('https://video.udn.com/embed/news/foo')
        assert not udn._match_id('https://video.udn.com/embed/news/300040/')
        assert not udn._match

# Generated at 2022-06-26 13:18:57.333301
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/news/303776'
    UDNEmbedIE()._match_id(url)
    UDNEmbedIE().suitable(url)
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-26 13:19:00.242196
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:19:10.759434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:19:14.919235
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE().IE_NAME == 'udn'

# Generated at 2022-06-26 13:19:19.015800
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed.ie_key() == 'udn'
    assert udn_embed.ie_desc() == '聯合影音'

# Generated at 2022-06-26 13:21:47.579308
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL
    assert UDNEmbedIE._TESTS

# Generated at 2022-06-26 13:21:54.216771
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	"""
	Unit test to test constructor of class UDNEmbedIE that initializes
	various properties of the class
	"""
	# initialize the class
	obj = UDNEmbedIE()

	# check whether the IE_DESC is initialized
	if obj.IE_DESC != '聯合影音':
		print(obj.IE_DESC)
		assert False

	# check whether the _VALID_URL is initialized
	if obj._VALID_URL != r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)':
		print(obj._VALID_URL)
		assert False

	# check whether the _TESTS is initialized
	if not obj._TESTS:
		print(obj._TESTS)


# Generated at 2022-06-26 13:22:00.180173
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbedIE', 'udn.com', '聯合影音')
    UDNEmbedIE('UDNEmbedIE', 'udn.com', '聯合影音', 'udn_com')

# Generated at 2022-06-26 13:22:13.227952
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    # test match function
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, 
                    '//video.udn.com/play/news/303776')
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, 
                    '//video.udn.com/embed/news/300040')
    assert not re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, 
                        'https://google.com')
    assert re.match(UDNEmbedIE._VALID_URL, 
                    'https://video.udn.com/play/news/303776')

# Generated at 2022-06-26 13:22:17.210396
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed.IE_DESC == "聯合影音"



# Generated at 2022-06-26 13:22:24.567798
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    entry1 = UDNEmbedIE()
    assert entry1._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    entry2 = UDNEmbedIE(IE_NAME='UDNEmbedIE')
    assert entry2._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-26 13:22:35.058763
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'UDNEmbed'
    assert UDNEmbedIE.ie_desc() == '聯合影音'
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.match(UDNEmbedIE._VALID_URL,
        'http://video.udn.com/embed/news/300040')
    assert re.match(UDNEmbedIE._VALID_URL,
        'https://video.udn.com/embed/news/300040')


# Generated at 2022-06-26 13:22:39.498777
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("http://video.udn.com/embed/news/300040")
    UDNEmbedIE("https://video.udn.com/embed/news/300040")
    UDNEmbedIE("https://video.udn.com/play/news/300040")