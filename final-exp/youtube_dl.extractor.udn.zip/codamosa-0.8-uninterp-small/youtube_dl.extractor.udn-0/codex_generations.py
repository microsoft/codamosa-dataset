

# Generated at 2022-06-26 13:12:49.665327
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:12:51.915106
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:12:56.366476
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    i = UDNEmbedIE()


# Generated at 2022-06-26 13:13:01.774872
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e.ie_key() == 'udn'
    assert u_d_n_embed_i_e.ie_desc() == '聯合影音'


# Generated at 2022-06-26 13:13:10.121985
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    p = u_d_n_embed_i_e_0._PROTOCOL_RELATIVE_VALID_URL
    assert p == r'//video[.]udn[.]com/(?:embed|play)/news/(?P<id>\d+)'
    u_d_n_embed_i_e_0.IE_DESC = 'B'
    p = u_d_n_embed_i_e_0._PROTOCOL_RELATIVE_VALID_URL
    assert p == r'//video[.]udn[.]com/(?:embed|play)/news/(?P<id>\d+)'
    assert u_d_n_embed_i_e_0.IE_DESC == 'B'


# Generated at 2022-06-26 13:13:19.617929
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = "300040"

    url = "http://video.udn.com/embed/news/300040"


# Generated at 2022-06-26 13:13:31.299405
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert_equal(u_d_n_embed_i_e_0.IE_DESC, '聯合影音')
    assert_equal(u_d_n_embed_i_e_0._PROTOCOL_RELATIVE_VALID_URL, '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')
    assert_equal(u_d_n_embed_i_e_0._VALID_URL, 'https?:' + u_d_n_embed_i_e_0._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-26 13:13:32.611200
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()

# Generated at 2022-06-26 13:13:35.028784
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_1 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:45.506420
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_1 = UDNEmbedIE()
    assert(u_d_n_embed_i_e_1.IE_DESC == '聯合影音')
    assert(u_d_n_embed_i_e_1._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/\d+')

# Generated at 2022-06-26 13:14:01.240037
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-26 13:14:02.707332
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()


# Generated at 2022-06-26 13:14:03.699300
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE


# Generated at 2022-06-26 13:14:06.557333
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:14:08.808799
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE();

# Generated at 2022-06-26 13:14:10.256762
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert isinstance(UDNEmbedIE(), object)

# Generated at 2022-06-26 13:14:12.896044
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:14:14.646524
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e is not None


# Generated at 2022-06-26 13:14:24.769473
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:14:27.008282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()



# Generated at 2022-06-26 13:14:46.669137
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert pattern == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert re.match(pattern, 'http://video.udn.com/play/news/300040')
    assert re.match(pattern, 'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:14:58.262881
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # be sure you are network connected
    # and udn video server is available
    url = 'https://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    webpage = udn_embed_ie._download_webpage(url, '300040')
    options_str = udn_embed_ie._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', webpage, 'options')
    trans_options_str = js_to_json(options_str)
    options = udn_embed_ie._parse_json(trans_options_str, 'options')
    assert options != None
    assert options['video']['mp4'] != None
    assert options['title'] != None

# Generated at 2022-06-26 13:15:06.733627
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url='https://video.udn.com/embed/news/300040'
    udneie = UDNEmbedIE()
    #udneie._real_extract(url='http://video.udn.com/embed/news/300040')
    udneie._real_extract(url)
    print(UDNEmbedIE._TESTS)
    

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:15:15.332027
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS == UDNEmbedIE._TESTS

# Generated at 2022-06-26 13:15:21.733466
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_DESC == '聯合影音'
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._VALID_URL == r'https?:' + udn_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn_ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-26 13:15:28.190040
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    assert ie.V3_ENDPOINT == 'https://video.udn.com/api/v3'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:37.774348
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    result = test_obj._TESTS[0]
    expected_result = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': 're:^https?://.*\\.jpg$',
        'params': {
            # m3u8 download
            'skip_download': True,
        },
    }

    # example of test case:
    # {
    #     'url': 'http://video.udn.com/embed/news/300040',
    #     'info_dict': {
    #         'id': '300040',
    #         'ext

# Generated at 2022-06-26 13:15:39.205100
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _ = UDNEmbedIE()

# Generated at 2022-06-26 13:15:49.596501
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    with open('test.html', 'rb') as f:
        web_page = f.read()
    ie = UDNEmbedIE()
    input = ie._PROTOCOL_RELATIVE_VALID_URL
    output = ie._VALID_URL
    assert re.sub(input, output, web_page).find('//video.udn.com/embed/news/300040') != -1
    assert re.sub(input, output, web_page).find('//video.udn.com/embed/news/300040') != -1
    ie = UDNEmbedIE({'_download_webpage': lambda url, name, note: web_page})
    info_dict = ie._real_extract('//video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:15:51.013854
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnClass = UDNEmbedIE()
    assert udnClass
    #assert isinstance(udnClass, InfoExtractor)

# Generated at 2022-06-26 13:16:20.385983
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:16:23.000781
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'udnembed'


# Generated at 2022-06-26 13:16:32.072542
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS[0] == ie.WORKING_TESTS[0]

# Generated at 2022-06-26 13:16:35.655876
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    test for constructor of class UDNEmbedIE
    """
    UDNEmbedIE(IE_DESC, _PROTOCOL_RELATIVE_VALID_URL, _VALID_URL, _TESTS)

# Generated at 2022-06-26 13:16:42.314872
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:16:46.642238
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?:(?:www\.)?video\.udn\.com/(?:embed|play)/news/(\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:16:51.399686
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_url = 'https://video.udn.com/embed/news/300040'
    ie.extract(test_url)

# Generated at 2022-06-26 13:16:58.935637
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # URL: http://video.udn.com/embed/news/300040
    url = "http://video.udn.com/embed/news/300040"
    obj = UDNEmbedIE()
    obj.initialize()
    obj._match_id(url)

    # URL: https://video.udn.com/embed/news/300040
    url = "https://video.udn.com/embed/news/300040"
    obj._match_id(url)

    # URL: https://video.udn.com/play/news/303776
    url = "https://video.udn.com/play/news/303776"
    obj._match_id(url)

# Generated at 2022-06-26 13:16:59.614164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbedIE', True, {})

# Generated at 2022-06-26 13:17:04.873054
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    instance = UDNEmbedIE()
    re = instance.suitable(url)
    assert re, "url: %s" % url

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:18:05.562159
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie.IE_NAME == "UDNEmbed"

# Generated at 2022-06-26 13:18:09.153240
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-26 13:18:11.511574
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    w = UDNEmbedIE()
    assert(w._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-26 13:18:13.149554
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:18:16.830186
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.__class__.__name__ == 'UDNEmbedIE'
    # Test for static  class variable
    assert ie._VALID_URL == ie.IE_NAME + ':' + ie._VALID_URL

# Generated at 2022-06-26 13:18:19.668425
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(UDNEmbedIE.create_ie())._VALID_URL

# Generated at 2022-06-26 13:18:28.271702
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('testing')
    assert ie.IE_DESC == '聯合影音'
    assert re.compile(ie._PROTOCOL_RELATIVE_VALID_URL).pattern == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert re.compile(ie._VALID_URL).pattern == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:18:31.366794
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-26 13:18:33.467811
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE

# Generated at 2022-06-26 13:18:35.084153
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:20:51.154771
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    parser = UDNEmbedIE()
    M = parser.IE_DESC
    inst = parser.__class__
    assert inst.IE_DESC == M
    assert inst._VALID_URL == inst._PROTOCOL_RELATIVE_VALID_URL.replace('//', 'https://')

# Generated at 2022-06-26 13:20:51.859515
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE != None


# Generated at 2022-06-26 13:20:57.603120
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Call the constructor of class UDNEmbedIE for testing.
    obj = UDNEmbedIE()
    # Test whether the URL match the rules defined in _VALID_URL and _PROTOCOL_RELATIVE_VALID_URL.
    # These two rules are used to judge whether the URL matches this IE.
    # For example: This URL (http://video.udn.com/embed/news/300040) matched this IE.
    #              This URL (https://video.udn.com/embed/news/300040) matched this IE too.
    #              This URL (http://video.udn.com/play/news/300040) not matched.
    #              This URL (//video.udn.com/embed/news/300040) matched this IE too.
    #              This URL (//video.udn.com/

# Generated at 2022-06-26 13:21:09.427913
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    proto_relative_url = '//video.udn.com/embed/news/300040'
    # check protocol relative is valid
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL is not None
    # check valid_url is generated correctly
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    # check valid_url can match the protocol relative URL
    match = re.match(UDNEmbedIE._VALID_URL, proto_relative_url)
    assert match is not None
    if match is not None:
        assert match.group('id') == '300040'

# Generated at 2022-06-26 13:21:18.877092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-26 13:21:21.233097
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:21:28.055572
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.suitable(url) == True
    assert ie.IE_DESC == '聯合影音'
    assert ie.IE_NAME == 'UDN'

# Generated at 2022-06-26 13:21:29.117454
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Throws an exception if not succeed
    u = UDNEmbedIE()

# Generated at 2022-06-26 13:21:38.449981
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    assert udneie.IE_NAME == 'udn_embed'
    assert udneie.IE_DESC == '聯合影音'
    assert udneie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    return udneie


# Generated at 2022-06-26 13:21:41.458162
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE('udn')
    assert a.IE_NAME == 'udn'
    assert a.IE_DESC == '聯合影音'
    assert a._VALID_URL == a._VALID_URL