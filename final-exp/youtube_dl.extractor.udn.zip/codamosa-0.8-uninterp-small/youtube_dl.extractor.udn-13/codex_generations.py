

# Generated at 2022-06-26 13:12:58.429600
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ytdl.YoutubeDL import YoutubeDL
    import re
    import sys
    u_d_n_embed_i_e_0 = UDNEmbedIE()
    def t_e_s_t__download_webpage_0(u_r_l, video_id, note, errnote, fatal, data, headers, query, expected_warnings):
        u_d_n_embed_i_e_0._downloader = YoutubeDL({})
        actual_t_e_s_t__download_webpage_0 = u_d_n_embed_i_e_0._download_webpage(u_r_l, video_id, note, errnote, fatal, data, headers, query)
        assert actual_t_e_s_t__download_webpage_0 == None
    # 5000ms


# Generated at 2022-06-26 13:13:12.006835
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:13:14.844196
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:25.140894
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert_equals(UDNEmbedIE.IE_DESC, '聯合影音')
    assert_equals(UDNEmbedIE._VALID_URL, r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert_equals(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert_equals(UDNEmbedIE._TESTS[0]['url'], 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:13:36.166023
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    u_d_n_embed_i_e = UDNEmbedIE()

    assert u_d_n_embed_i_e.IE_DESC == '聯合影音'
    assert u_d_n_embed_i_e._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:13:38.801522
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_info = test_case_0()
    assert ('id' in video_info)


# Generated at 2022-06-26 13:13:46.985517
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case = {
        'url': 'http://video.udn.com/embed/news/300040',
        'info_dict': {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        },
        'params': {
            # m3u8 download
            'skip_download': True,
        },
        'expected_warnings': ['Failed to parse JSON Expecting value'],
    }
    u_d_n_embed_i_e_0 = UDNEmbedIE()

# Generated at 2022-06-26 13:13:51.496181
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE(UDNEmbedIE.__bases__[0](UDNEmbedIE.IE_NAME))



# Generated at 2022-06-26 13:13:53.958509
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE("UDNEmbedIE")
    assert u_d_n_embed_i_e._downloader is None


# Generated at 2022-06-26 13:13:55.461080
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert test_case_0() is None

# Generated at 2022-06-26 13:14:04.076473
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:14:06.486260
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:14:09.341619
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:14:13.117869
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert_equal(u_d_n_embed_i_e_0.ie_desc, '聯合影音')



# Generated at 2022-06-26 13:14:16.632728
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    import ydl
    ydl.extractor.UDNEmbedIE()

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        test_UDNEmbedIE()
    else:
        test_case_0()

# Generated at 2022-06-26 13:14:18.064835
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:14:18.871091
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-26 13:14:21.933402
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE().IE_DESC == '聯合影音')


# Generated at 2022-06-26 13:14:23.291848
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()


# Generated at 2022-06-26 13:14:25.348129
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE(None)


# Generated at 2022-06-26 13:14:34.464726
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "embed/news/300040"
    UDNEmbedIE()._match_id(url)

# Generated at 2022-06-26 13:14:45.047496
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udn = UDNEmbedIE()._real_extract(url)
    assert udn.get('id') == '300040'
    assert udn.get('formats')
    assert udn.get('title') == '生物老師男變女 全校挺"做自己"'
    assert udn.get('thumbnail')

# Generated at 2022-06-26 13:14:51.704786
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:14:53.060464
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:14:55.425908
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pylint: disable=no-value-for-parameter
    assert UDNEmbedIE is not None

# Generated at 2022-06-26 13:14:57.450315
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'udn' in dir(UDNEmbedIE())

# Generated at 2022-06-26 13:14:58.844529
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:15:04.822885
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE()

    # call function
    m = udn_embed._match_id(url)

    # check result
    assert(m == '300040')

# Generated at 2022-06-26 13:15:11.264068
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    with open('test/test_data/udn/json_options.txt') as json_file:
        options_str = json_file.read()
    assert 'video":["' in options_str

    dummy_url = 'https://video.udn.com/play/news/300395'
    options = js_to_json(options_str)
    test_ie = UDNEmbedIE(dummy_url, UDNEmbedIE._VALID_URL)
    assert test_ie.get_protocol_relative_url(dummy_url) == '//video.udn.com/play/news/300395'
    test_ie._parse_json(options, 'options', fatal=False)

# Generated at 2022-06-26 13:15:17.489671
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor = UDNEmbedIE
    instance = constructor(None)
    assert constructor.__name__ == 'UDNEmbedIE'
    assert constructor.IE_NAME == 'video.udn.com'
    assert instance.IE_NAME == 'video.udn.com'
    assert instance.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:15:31.866702
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' == UDNEmbedIE.ie_key()

# Generated at 2022-06-26 13:15:36.111619
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    val = UDNEmbedIE()
    # Assert _VALID_URL starts with http, https and //video.udn.com/embed/news/
    assert val._VALID_URL.startswith('http')
    assert val._VALID_URL.startswith('http')
    assert val._VALID_URL.startswith('//video.udn.com/embed/news/')
    # Assert IE_DESC is 聯合影音
    assert val.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:15:48.114455
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300033')

# Generated at 2022-06-26 13:15:48.593117
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()

# Generated at 2022-06-26 13:15:49.917774
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:15:53.432662
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_udn_embed import UDNEmbedTestCase
    UDNEmbedTestCase.test_udn_embed_constructor(UDNEmbedIE)

# Generated at 2022-06-26 13:15:55.215672
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('url', 'info_dict')

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:16:01.716533
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert '300040' == ie._match_id('http://video.udn.com/embed/news/300040')
    assert '300040' == ie._match_id('https://video.udn.com/play/news/300040')

# Generated at 2022-06-26 13:16:03.742042
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert isinstance(udne, UDNEmbedIE)

# Generated at 2022-06-26 13:16:13.520625
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert_equal(udn._PROTOCOL_RELATIVE_VALID_URL, r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert_equal(udn._VALID_URL, r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert_equal(udn.IE_DESC, '聯合影音')

# Generated at 2022-06-26 13:16:47.261073
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test with no url passed
    udn_ie = UDNEmbedIE()
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL is not None and udn_ie._VALID_URL is not None

    # Test with URL passed
    url = 'http://video.udn.com/embed/news/300040'
    udn_ie = UDNEmbedIE(url=url)
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL is not None and udn_ie._VALID_URL is not None

# Generated at 2022-06-26 13:16:58.463383
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._is_valid_url('http://video.udn.com/embed/news/300040')
    assert UDNEmbedIE()._is_valid_url('https://video.udn.com/embed/news/300040')
    assert not UDNEmbedIE()._is_valid_url('http://video.udn.com/embed/news/300040/')
    assert not UDNEmbedIE()._is_valid_url('https://video.udn.com/embed/news/300040/')
    assert UDNEmbedIE()._is_valid_url(
        'https://video.udn.com/embed/news/300040/1')

# Generated at 2022-06-26 13:17:01.929558
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE()
    assert obj.suitable(url)
    assert obj.IE_NAME == 'udn'
    assert obj.IE_DESC == '聯合影音'

    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == 'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-26 13:17:04.661912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    assert test._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:17:16.358855
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE.IE_DESC == '聯合影音')
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert(len(UDNEmbedIE._TESTS) == 3)
    assert(UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:17:21.723365
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r = UDNEmbedIE()
    assert r.ie_key() == 'UDNEmbed'
    assert r.ie_desc() == '聯合影音'
    assert r._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:17:24.487941
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r = UDNEmbedIE()
    assert r.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:17:36.879209
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()

    # The following URL is the Embed URL of https://video.udn.com/news/300040
    assert udn_ie.ie_key() == 'UDNEmbed'
    assert udn_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    url = 'http://video.udn.com/embed/news/300040'
    m = re.match(udn_ie._VALID_URL, url)
    assert m.group('id') == '300040'

# Generated at 2022-06-26 13:17:47.604405
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:17:56.710657
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:19:18.221476
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
        run unit test
    '''
    # Arrange
    video_url = 'http://video.udn.com/embed/news/300040'
    UDNEmbed = UDNEmbedIE()
    expected = 'UDNEmbed'
    # Action
    result = UDNEmbed.IE_NAME
    # Assert
    assert result == expected

# Generated at 2022-06-26 13:19:19.456664
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:19:30.298790
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Simple unit test for UDNEmbedIE
    """
    from ..extractor import GenIE

    ie = GenIE[UDNEmbedIE.ie_key()]()
    # When testing, use the following HTTPretty registration
    # HTTPretty.register_uri(HTTPretty.GET, re.compile(r'https?://video\.udn\.com/.*'),
    #                        body=download_xml, content_type='text/html')

    assert ie.working == True

# Generated at 2022-06-26 13:19:42.959621
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:19:44.511473
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:19:49.090939
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except TypeError:
        print('Unit test for constructor of class UDNEmbedIE failed')
        return False
    return True



# Generated at 2022-06-26 13:19:52.545839
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    UDNEmbedIE._VALID_URL
    UDNEmbedIE._TESTS
    UDNEmbedIE._real_extract

# Generated at 2022-06-26 13:19:55.496263
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE()
    assert a._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:19:59.576398
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.ie_key() == 'UDNEmbed'
    assert instance.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:20:00.394496
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert True