

# Generated at 2022-06-26 13:12:56.811545
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e.IE_DESC == '聯合影音'
    assert u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u_d_n_embed_i_e._VALID_URL == 'https?:' + u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:13:08.474796
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE() # We have failed to parse JSON at times, you can set fatal to false in the _parse_json function and handle the error appropriately
    # Default arguments
    # kwargs for class InfoExtractor:
    #     downloader=None
    #     downloader_options={}
    #     ie_key=None
    #     num_cache_entries=None
    #     params=None
    #     playliststart=1
    #     playlistend=None
    #     playlist_title=None
    #     _downloader=<youtube_dl.YoutubeDL object>
    #     _type=None


# Generated at 2022-06-26 13:13:11.242096
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:21.023094
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    # url = 'https://video.udn.com/embed/news/300040'
    # url = 'https://video.udn.com/news/303776'
    url_result = u_d_n_embed_i_e_0._real_extract(url)
    for result in url_result:
        print(result,':',url_result[result])

# Generated at 2022-06-26 13:13:22.527225
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:26.677285
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test case #0
    test_case_0()

if __name__ == '__main__':
    # test_UDNEmbedIE()
    pass

# Generated at 2022-06-26 13:13:29.448117
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i_e_desc = u_d_n_embed_i_e_0.IE_DESC


# Generated at 2022-06-26 13:13:37.801580
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-26 13:13:40.444523
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:13:43.031502
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-26 13:13:51.128164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(0)

# Generated at 2022-06-26 13:13:57.630693
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import sys
    import six
    import json
    import os

    #
    # python3 compatibility
    #
    if six.PY3:
        unicode = str

    class TestUDNEmbedIE(unittest.TestCase):
        def setUp(self):
            self.ie = UDNEmbedIE()

        #
        # test _is_valid_url()
        #
        def test_is_valid_url_protocol_relative_url(self):
            #
            # protocol-relative URL
            #
            self.assertTrue(self.ie._is_valid_url(r'//video.udn.com/embed/news/300040'))


# Generated at 2022-06-26 13:14:07.618409
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import unescapeHTML
    from ..configuration import Configuration
    from ..extractor import gen_extractors
    from ..utils import ExtractorError
    from ..compat import compat_urlparse

    config = Configuration()
    gen_extractors(config)

    def test_download_url(url, expected_status=200, expected_content=None,
                          expected_headers=None,
                          return_data=None, data_file=None, expected_content_type=None,
                          expected_error=None,
                          return_expected_error=False,
                          extractor_type=None, **kwargs):
        """
        Simple test for download_url that asserts the expected values
        """
        if extractor_type is None and expected_content is not None:
            extractor_type = test_download

# Generated at 2022-06-26 13:14:14.818511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['params']['skip_download'] == True
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert ie._T

# Generated at 2022-06-26 13:14:16.902069
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test UDNEmbedIE"""
    UDNEmbedIE_instance = UDNEmbedIE()
    print('UDNEmbedIE_instance = %s' % UDNEmbedIE_instance)


# Generated at 2022-06-26 13:14:27.296538
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    ie_test_0 = ie._TESTS[0]
    ie_test_0_info_origin = ie_test_0['info_dict']
    ie_test_0_info_dict_origin = ie_test_0_info_origin['info_dict']
    ie_test_0_id_origin = ie_test_0_info_dict_origin['id']
   

# Generated at 2022-06-26 13:14:37.724233
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    assert(udnEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udnEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-26 13:14:41.918629
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for constructor of class UDNEmbedIE
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.extract()

# Generated at 2022-06-26 13:14:43.308835
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:14:51.576282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import sys
    try:
        UDNEmbedIE
    except NameError:
        import youtube_dl
        if sys.version_info.major == 2:
            class UDNEmbedIE(youtube_dl.YoutubeIE):
                pass
        else:
            @classmethod
            def __modify_schema(cls, ie_key, ie_dict, ie_module_name, ie_entry_point_name):
                ie_object = ie_dict[ie_key]

# Generated at 2022-06-26 13:15:07.521689
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:10.273517
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_ie = UDNEmbedIE()
    assert_equal(type(test_ie), UDNEmbedIE)

# Generated at 2022-06-26 13:15:13.535218
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
        UDNEmbedIE('test')
    except TypeError:
        assert False


# Generated at 2022-06-26 13:15:15.869535
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:15:17.185240
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(lambda x: 1)

# Generated at 2022-06-26 13:15:28.806816
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    web_url = 'https://video.udn.com/embed/news/300040'
    page = ie._download_webpage(web_url, '300040')
    options_str = ie._html_search_regex(r'var\s+options\s*=\s*([^;]+);', page, 'options')
    trans_options_str = js_to_json(options_str)
    options = ie._parse_json(trans_options_str, 'options', fatal=False)
    if options:
        video_urls = options['video']
        title = options['title']

# Generated at 2022-06-26 13:15:33.146144
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn = UDNEmbedIE()
    assert udn._match_id(url) == '300040'

# Generated at 2022-06-26 13:15:39.182695
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:15:40.945349
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:15:46.053932
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_DESC == "聯合影音"
    assert ie._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"


# Generated at 2022-06-26 13:16:25.931677
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	t=UDNEmbedIE()
	assert t.IE_DESC != None

if __name__ == "__main__":
	import sys
	import argparse
	from pprint import pprint
	from youtube_dl.utils import *
 
	parser = argparse.ArgumentParser(prog='UDNEmbedIE')
	parser.add_argument('url', nargs='*', default=None)
	parser.add_argument('-f','--format', dest='fmt', default=None)
	parser.add_argument('-t','--test', dest='test', action='store_true', default=False)
	parser.add_argument('-T','--testall', dest='testall', action='store_true', default=False)

# Generated at 2022-06-26 13:16:30.497113
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    exp_obj = UDNEmbedIE(UDNEmbedIE._downloader)
    assert exp_obj.suitable('http://video.udn.com/embed/news/300040')
    assert exp_obj.IE_NAME == 'UDNEmbed'

    exp_obj = UDNEmbedIE(UDNEmbedIE._downloader)
    assert exp_obj.suitable('https://video.udn.com/embed/news/300040')
    assert exp_obj.IE_NAME == 'UDNEmbed'

# Test for methods

# Generated at 2022-06-26 13:16:34.417495
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie._download_test

# Generated at 2022-06-26 13:16:38.624394
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:40.816627
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();

# Unit test execution
if __name__ == "__main__":
    test_UDNEmbedIE();

# Generated at 2022-06-26 13:16:46.072359
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.FILE_EXTENSIONS == ("mp4", "f4m", "m3u8")
    assert udn.IE_NAME == "UDNEmbed"
    assert udn.IE_DESC == "聯合影音"
    assert udn._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:50.843958
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert re.match(ie._PROTOCOL_RELATIVE_VALID_URL, ie._VALID_URL)


# Generated at 2022-06-26 13:16:57.352710
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    my_object = UDNEmbedIE()
    assert my_object.IE_DESC == ("聯合影音")
    assert my_object._PROTOCOL_RELATIVE_VALID_URL == (
        r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert my_object._VALID_URL == (
        r'https?:' + my_object._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-26 13:17:02.271628
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("https://video.udn.com/embed/news/300040")
    UDNEmbedIE("https://video.udn.com/play/news/303776")

# Generated at 2022-06-26 13:17:09.068696
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from youtube_dl.downloader import HttpFD
    from youtube_dl.downloader.http import HttpDownloader

    UDNEmbedIE_example = UDNEmbedIE()
    UDNEmbedIE_example._download = lambda *args, **kargs: 'example_result'
    UDNEmbedIE_example._download_webpage = lambda *args, **kargs: 'example_resul2'
    UDNEmbedIE_example.http_downloader = HttpDownloader(HttpFD())

    assert UDNEmbedIE_example.ie_key() == 'UDNEmbed'
    assert UDNEmbedIE_example._real_extract('http://video.udn.com/embed/news/300040')['id']=='300040'

# Generated at 2022-06-26 13:18:15.025391
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor_test_helper(UDNEmbedIE)

# Generated at 2022-06-26 13:18:20.783586
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_object = UDNEmbedIE()
    assert test_object._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:18:22.216952
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:18:27.205110
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE._VALID_URL == UDNEmbedIE._VALID_URL
    assert IE._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:18:36.732101
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    result = UDNEmbedIE()._real_extract(url)
    assert result['id'] == '303776'
    assert result['title'] == r'陳韋宗：期待蔡政府接受高智晟的訪問'

# Generated at 2022-06-26 13:18:42.588681
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	print('Unit test for constructor of class UDNEmbedIE')
	udn_ie = UDNEmbedIE()
	udn_ie.IE_DESC = '聯合影音'
	udn_ie._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
	udn_ie._VALID_URL = r'https?:' + udn_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:18:46.514894
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-26 13:18:59.115980
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url='http://video.udn.com/embed/news/300040'
    video_id=300040
    print(UDNEmbedIE.suitable(url))
    ue=UDNEmbedIE(url)
    assert(ue.IE_NAME=='udn')
    assert(ue.IE_DESC=='聯合影音')
    assert(ue.VALID_URL==r'https?://video\.udn\.com/embed/news/(?P<id>\d+)')
    assert(ue._real_extract(url)['id']==video_id)
    assert(ue.url_result(url)['id']==video_id)
    assert(ue.url_result(url,ie='UDNEmbed')['id']==video_id)

# Generated at 2022-06-26 13:19:01.387694
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne

# Generated at 2022-06-26 13:19:10.366504
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_cases = [
        {"url": "http://video.udn.com/embed/news/300040", "id": "300040"},
        {"url": "https://video.udn.com/embed/news/300040", "id": "300040"},
        {"url": "http://video.udn.com/embed/news/300040", "only_matching": True},
        {"url": "https://video.udn.com/embed/news/300040", "only_matching": True},
    ]
    for test_case in test_cases:
        assert UDNEmbedIE._match_id(test_case['url']) == test_case['id']

# Generated at 2022-06-26 13:21:49.444173
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test case for constructor of class UDNEmbedIE
    """
    info_extractor = UDNEmbedIE()
    assert info_extractor.IE_NAME == 'udn'
    assert info_extractor.IE_DESC == '聯合影音'
    assert 'UDNEmbedIE' == info_extractor.__class__.__name__

# Generated at 2022-06-26 13:22:01.977262
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test that a class is constructed with no error
    ie = UDNEmbedIE()
    # Test that a class do not have the method '_real_initialize'
    try:
        ie._real_initialize()
    except AttributeError:
        pass
    else:
        raise AssertionError('An instance of class %s has '
            'attribute "_real_initialize", which is unexpected.' 
            % ie.__class__.__name__)
    # Test that a class do not have the method '_real_extract'
    try:
        ie._real_extract()
    except AttributeError:
        pass

# Generated at 2022-06-26 13:22:13.752654
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import fake_http_response_with_json

    # test _real_extract()
    # 1. empty options

# Generated at 2022-06-26 13:22:25.408885
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if not hasattr(InfoExtractor, '_download_webpage'):
        raise unittest.SkipTest('InfoExtractor._download_webpage not available')

    url = 'https://video.udn.com/embed/news/300040'

    ie = UDNEmbedIE()
    webpage = ie._download_webpage(url, '300040')

    # Verify webpage is downloaded
    assert webpage

    # Verify video urls are extracted
    options_str = ie._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', webpage, 'options')
    trans_options_str = js_to_json(options_str)
    options = ie._parse_json(trans_options_str, 'options', fatal=False) or {}

    assert options

# Generated at 2022-06-26 13:22:32.291955
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-26 13:22:34.528506
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    result = IE.IE_NAME
    assert result == 'udn'

# Generated at 2022-06-26 13:22:35.373448
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:22:35.993520
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL