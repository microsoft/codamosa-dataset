

# Generated at 2022-06-26 13:12:56.472693
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
        UDNEmbedIE('TheNewYorkTimes')
        UDNEmbedIE('TheNewYorkTimes', 'TheNewYorkTimes')
        UDNEmbedIE('TheNewYorkTimes', 'TheNewYorkTimes', 'TheNewYorkTimes')
        UDNEmbedIE('TheNewYorkTimes', 'TheNewYorkTimes', 'TheNewYorkTimes', 'TheNewYorkTimes')
        UDNEmbedIE('TheNewYorkTimes', 'TheNewYorkTimes', 'TheNewYorkTimes', 'TheNewYorkTimes', 'TheNewYorkTimes')
    except TypeError:
        assert False
    else:
        assert True


# Generated at 2022-06-26 13:13:05.347568
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:13:06.255602
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass


# Generated at 2022-06-26 13:13:07.185014
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    udn_embed_IE_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:09.624060
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_1 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:19.422166
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    video_id = u_d_n_embed_i_e._match_id(url)
    options_str = u_d_n_embed_i_e._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', video_id, 'options')
    trans_options_str = js_to_json(options_str)
    options = u_d_n_embed_i_e._parse_json(trans_options_str, 'options', fatal=False) or {}
    assert options
    video_urls = options['video']
    title = options['title']
    poster = options

# Generated at 2022-06-26 13:13:26.146386
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()
    # https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/extractor/udn.py
    input_str = 'http://video.udn.com/embed/news/300040'
    match_obj = re.match(r'http://video\.udn\.com/embed/news/(\d+)', input_str, re.I|re.M)
    str_0 = match_obj.group()
    str_1 = match_obj.group(0)
    str_2 = match_obj.group(1)
    assert str_0 == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:13:35.906983
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:13:37.269982
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()

# Generated at 2022-06-26 13:13:42.290009
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _expected_str = '<UDNEmbedIE>'
    _actual_str = str(UDNEmbedIE())
    assert _expected_str == _actual_str, 'Expected : {}, Actual : {}'.format(_expected_str, _actual_str)


# Generated at 2022-06-26 13:13:56.920471
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'udn'
    assert ie.IE_NAME == 'udn'
    #assert ie.IE_DESC == '\u8d85\u904e200\u842c\u5f71\u7247\u5305\u542b\u91dd\u5c0d\u5716\uFF0C\u5f71\u7247\u6a94\u6848\u5176\u5be6\u662f\u8de8\u5e73\u53f0\u5f71\u7247\u5206\u4eab\uff0c\u660e\u5e74\u958b\u59cb\u505a\u5f71\u7

# Generated at 2022-06-26 13:14:07.552914
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    test_url = 'https://video.udn.com/play/news/303776'
    test_video_id = '303776'
    test_webpage = udn_embed_ie._download_webpage(test_url, test_video_id)
    test_video_urls = udn_embed_ie._html_search_regex(
        r'"video"\s*:\s*({.+?})\s*,', test_webpage, 'video urls')
    # Test if it get the video urls of the corresponding video

# Generated at 2022-06-26 13:14:14.116238
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Tests for UDNEmbedIE"""

    from .common import InfoExtractor

    test_url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE_object = UDNEmbedIE()
    UDNEmbedIE_result = UDNEmbedIE._real_extract(UDNEmbedIE_object, test_url)

    # Test whether the class call is successful
    assert (UDNEmbedIE_result['id'] == '300040'), 'UDNEmbedIE unit test failed'

    # Test whether the return type is a dictionary
    assert (isinstance(UDNEmbedIE_result, dict)), 'UDNEmbedIE unit test failed'



# Generated at 2022-06-26 13:14:16.825332
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:14:18.725089
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj is not None


# Generated at 2022-06-26 13:14:21.173366
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id(ie._VALID_URL)

# Generated at 2022-06-26 13:14:23.161376
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-26 13:14:25.219449
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    dl = UDNEmbedIE()
    print(dl.IE_DESC + ' initialized.')

# Generated at 2022-06-26 13:14:31.905167
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.extract('http://video.udn.com/embed/news/300040')
    ie.extract('https://video.udn.com/embed/news/300040')
    ie.extract('//video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:14:35.131082
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE('https://video.udn.com/embed/news/300040')
    except:
        return False
    return True

# Generated at 2022-06-26 13:14:50.648640
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # construct a UDNEmbedIE instance
    assert UDNEmbedIE(UDNEmbedIE.ie_key()) is not None

# Generated at 2022-06-26 13:14:57.497214
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    from .test_utils import SITE_UDN
    test = unittest.TestCase()
    ie = UDNEmbedIE()
    test.assertEqual(ie.ie_key(), 'UDNEmbed')
    test.assertEqual(ie.ie_desc(), '聯合影音')
    test.assertEqual(ie.site_name(), 'UDN')
    test.assertEqual(ie.site_key(), SITE_UDN)

# Generated at 2022-06-26 13:15:04.539434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'udn.com: embed'
    assert ie.IE_DESC == '聯合影音'


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:15:11.736332
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-26 13:15:16.870272
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:27.011080
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == "UDNEmbed"
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:15:31.277477
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    print(instance.IE_DESC)
    assert instance.IE_DESC == '聯合影音'


# Generated at 2022-06-26 13:15:35.663145
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert pattern.match('//video.udn.com/embed/news/300040') is not None
    assert pattern.match('//video.udn.com/play/news/300040') is not None

# Generated at 2022-06-26 13:15:47.825082
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.ie_key() is 'udn'
    assert IE.ie_desc() is '聯合影音'
    assert IE._VALID_URL is 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._PROTOCOL_RELATIVE_VALID_URL is '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:53.498883
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._VALID_URL == 'https?:' + udn_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:16:28.612074
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_to_test = UDNEmbedIE
    url_test = 'http://video.udn.com/embed/news/300040'
    assert class_to_test._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert class_to_test._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert class_to_test._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:16:35.199197
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._match_id('/embed/news/300040') == '300040'
    assert UDNEmbedIE._match_id('/play/news/300040') == '300040'
    assert UDNEmbedIE._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE._match_id('//video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-26 13:16:45.379951
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = globals()['UDNEmbedIE']
    instance = class_()
    assert instance.IE_DESC == '聯合影音'
    assert re.match(instance._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/12345') != None
    assert re.match(instance._VALID_URL, 'http://video.udn.com/embed/news/12345') != None
    assert re.match(instance._VALID_URL, 'https://video.udn.com/embed/news/12345') != None
    assert re.match(instance._VALID_URL, 'https://video.udn.com/play/news/12345') == None

# Generated at 2022-06-26 13:16:47.392223
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()
	print(ie)

# Generated at 2022-06-26 13:16:54.359488
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class UDNEmbedIE():
        IE_NAME='udnembed'
        _VALID_URL='https?://video\.udn\.com/embed/news/\d+'

    from .common import InfoExtractor

    assert 'UDNEmbedIE' in InfoExtractor.__module__

# Generated at 2022-06-26 13:17:05.048466
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    extractor = UDNEmbedIE()
    exc = extractor._extract_video_info(url)
    assert exc['id'] == '300040'
    assert exc['title'] == '生物老師男變女 全校挺"做自己"'
    assert exc['thumbnail'] == ('https://i.ytimg.com/vi/VuDk-jy7XuU/'
                                'maxresdefault.jpg')

test_UDNEmbedIE()

# Generated at 2022-06-26 13:17:10.929931
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    download_url = "https://video.udn.com/news/303776"
    UDNEmbedIE()._real_extract(download_url)

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:17:17.967064
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei.IE_DESC == '聯合影音'

    test_url = 'http://video.udn.com/embed/news/300040'
    udnei._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnei._VALID_URL == r'https?:' + udnei._PROTOCOL_RELATIVE_VALID_URL
    
    assert udnei._match_id(test_url) == '300040'

    assert udnei.suitable(test_url)

    assert udnei.IE_NAME == 'udn'

# Generated at 2022-06-26 13:17:19.932267
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE() # pylint: disable=W0104

# Generated at 2022-06-26 13:17:25.298806
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    ie._match_id('https://video.udn.com/embed/news/300040')
    ie._match_id('http://video.udn.com/embed/news/300040')
    ie._match_id('http://video.udn.com/play/news/300040')

# Generated at 2022-06-26 13:18:40.950325
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test None input
    udnie = UDNEmbedIE()
    assert udnie.ie_key() == 'UDNEmbed'
    assert udnie.ie_desc() == '聯合影音'
    assert udnie.ie_name() == 'UDNEmbed'
    assert udnie.ie_version() == '20180803.07.01'
    assert udnie.extractor_key() == 'UDNEmbed'
    assert udnie.extractor_desc() == '聯合影音'
    assert udnie.extractor_name() == 'UDNEmbed'
    assert udnie.extractor_version() == '20180803.07.01'

# Generated at 2022-06-26 13:18:48.009518
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert test.ext_list == ['mp4']
    assert test.embed_info_url == 'http://video.udn.com/api/getEmbedHTMLAPI?videoId=300040'
    assert test.embed_video_url == 'http://video.udn.com/api/video/getEmbedPath?videoId=300040'



# Generated at 2022-06-26 13:18:48.767313
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE

# Generated at 2022-06-26 13:18:50.368287
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:18:53.390213
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 13:19:01.079073
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:'+r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    udn = UDNEmbedIE()
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == r'https?:'+r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn.IE

# Generated at 2022-06-26 13:19:08.590211
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url in ['http://video.udn.com/embed/news/300040',
                'https://video.udn.com/embed/news/300040']:
        i = UDNEmbedIE()
        i.initialize()
        assert i.IE_NAME == i.extract_info(url)['extractor'], \
            "Test for constructor of class UDNEmbedIE failed for %s" % url

# Generated at 2022-06-26 13:19:19.391972
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:19:23.897682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    UDNEmbedIE(UDNEmbedIE.ie_key(), url)

# Generated at 2022-06-26 13:19:26.861489
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, UDNEmbedIE)


# Generated at 2022-06-26 13:21:47.165377
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _ = UDNEmbedIE({})


# Generated at 2022-06-26 13:21:54.092091
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """test constructor of class UDNEmbedIE"""
    obj = UDNEmbedIE()
    obj._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    obj._VALID_URL = r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:21:59.255383
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    if udn_embed_ie == None:
        assert 0
    if udn_embed_ie.IE_DESC == None:
        assert 0

# Generated at 2022-06-26 13:22:03.175888
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS

# Generated at 2022-06-26 13:22:14.039915
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'
    udn.IE_DESC = '聯合影音'
    assert udn.IE_NAME == 'udn'
    assert udn.IE_DESC == '聯合影音'
    assert udn._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
   

# Generated at 2022-06-26 13:22:22.785621
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """First test to ensure the class is correctly constructed."""
    udn = UDNEmbedIE()
    assert udn.ie_key() == 'UDNEmbed'
    assert udn.ie_desc == '聯合影音'
    assert udn._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-26 13:22:30.120562
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    assert(udneie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udneie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    

# Generated at 2022-06-26 13:22:39.109500
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    assert ie.ie_key() is 'UDNEmbed'
    assert ie.extract(url)['id'] == '300040'
    assert ie.extract(url)['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie.extract(url)['thumbnail'] == 'https://v.udn.com.tw/upimages/v3/news/300040/300040_1_168x94.jpg'

# Generated at 2022-06-26 13:22:47.220145
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'