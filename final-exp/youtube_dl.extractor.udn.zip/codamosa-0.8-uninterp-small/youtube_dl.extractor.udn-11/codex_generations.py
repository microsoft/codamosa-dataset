

# Generated at 2022-06-26 13:12:51.409453
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert isinstance(u_d_n_embed_i_e, UDNEmbedIE)

# Generated at 2022-06-26 13:12:56.022087
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # u_d_n_embed_i_e_1 = UDNEmbedIE()
    assert True


# Generated at 2022-06-26 13:12:58.518531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:13:12.075185
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert u_d_n_embed_i_e._VALID_URL == r'https?:' + u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL
    assert u_d_n_embed_i_e.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:13:14.038433
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:13:16.290276
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test_case_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:19.834324
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:13:26.246339
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e.IE_DESC == '聯合影音'
    assert u_d_n_embed_i_e._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert u_d_n_embed_i_e._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert u_d

# Generated at 2022-06-26 13:13:36.236793
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-26 13:13:37.473518
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:55.429714
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:14:03.787088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE('http://video.udn.com/embed/news/300040')
        UDNEmbedIE('https://video.udn.com/embed/news/300040')
        UDNEmbedIE('https://video.udn.com/play/news/303776')
    except ValueError:
        assert False, "Constructor of Unit test fail"

# Generated at 2022-06-26 13:14:06.701056
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

# Generated at 2022-06-26 13:14:11.871637
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE()._match_id(url) == '300040'
    assert UDNEmbedIE().suitable(url)

# Generated at 2022-06-26 13:14:21.031312
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Confirm that _match_id is working properly
    assert UDNEmbedIE()._match_id("http://video.udn.com/embed/news/300040") == "300040"
    assert UDNEmbedIE()._match_id("//video.udn.com/embed/news/300040") == "300040"

    # Confirm that _PROTOCOL_RELATIVE_VALID_URL is working properly
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match("//video.udn.com/embed/news/300040")
    assert not UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match("http://video.udn.com/embed/news/300040")
    assert not UDNEmbedIE._PROTOCOL_REL

# Generated at 2022-06-26 13:14:22.460176
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:14:25.856882
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE('http://video.udn.com/embed/news/300040')
    except Exception as e:
        print(e)
        return -1
    return 0

# Generated at 2022-06-26 13:14:36.159189
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie.IE_NAME == 'UDNEmbed'


# Generated at 2022-06-26 13:14:48.343201
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_common import TestCommon
    from .generic import GenericIE

    test = TestCommon()

    Instance = UDNEmbedIE(test.IE_LastURL, test.IE_LastVideoID, test.IE_LastVideoTitle,
                      test.IE_LastVideoFormats, test.IE_LastVideoThumbnail,
                      test.IE_LastVideoDescription, test.IE_LastVideoDuration,
                      test.IE_LastVideoViewCount, test.IE_LastVideoAgeLimit,
                      test.IE_LastVideoLikeCount, test.IE_LastVideoDislikeCount,
                      test.IE_LastVideoUploader, test.IE_LastVideoUploadDate,
                      test.IE_LastVideoTimestamp)

    assert(Instance.ie_key() == 'UDNEmbed')

# Generated at 2022-06-26 13:14:51.838081
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS

# Generated at 2022-06-26 13:15:11.289961
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # match
    m = udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    re.match(m, '//video.udn.com/embed/news/300040')
    re.match(m, '//video.udn.com/play/news/300040')
    re.match(m, '//video.udn.com/embed/news/300040/12345')
    # not match
    re.match(m, 'video.udn.com/embed/news/300040')
    re.match(m, 'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:15:17.490668
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video = UDNEmbedIE()._real_extract(url)
    assert video.get('id') == '300040'
    assert video.get('title') == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-26 13:15:23.219897
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/303776'
    result = udn_ie._match_id(url)
    assert result == '303776'

# Generated at 2022-06-26 13:15:31.642820
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    video_id = "300040"
    title = "生物老師男變女 全校挺\"做自己\""
    thumbnail = "https://video.udn.com/uploads/news/2017/02/15/29731331_10.jpg"
    ext = "mp4"
    expect_result = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': 're:^https?://.*\.jpg$',
    }
    result = UDNEmb

# Generated at 2022-06-26 13:15:38.846998
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 13:15:43.030912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    instance = UDNEmbedIE()
    result = instance.suitable(url)
    assert result

# Generated at 2022-06-26 13:15:51.070500
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME == 'udn.com'
    assert obj.IE_DESC == '聯合影音'
    assert obj.__class__.__name__ == 'UDNEmbedIE'
    assert obj._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:15:51.971304
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()

# Generated at 2022-06-26 13:15:59.555325
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/embed/news/300040?whatever=1') == '300040'
    assert ie._match_id('//video.udn.com/embed/news/300040.whatever?whatever=1') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'
    assert ie

# Generated at 2022-06-26 13:16:08.035066
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    with open('./test/test_data/test_UDNEmbedIE.json', 'r') as f:
        testdata = json.load(f)

    udn_dir = os.path.dirname(os.path.realpath(__file__))
    video_path = os.path.join(udn_dir, 'test', 'test_data', 'test_video.json')
    with open(video_path, 'r') as f:
        video = json.load(f)
        video['returnData']['video'] = json.dumps(video['returnData']['video'])
        with patch('youtube_dl.extractor.udn.UdnIE._download_json') as mock_method:
            mock_method.return_value = video
            obj = UDNEmbedIE()
           

# Generated at 2022-06-26 13:16:45.799386
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._formats == ['mp4', 'm3u8', 'f4m']
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:54.717209
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = "https://video.udn.com/embed/news/300040"
    udn_embed_ie = UDNEmbedIE()
    match = udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL.match(test_url)
    if match != None:
        print("match: %s" % (match.groups()[0]))
    else:
        print("match == None")


# Generated at 2022-06-26 13:17:03.391709
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor_test_fixture(UDNEmbedIE, [
        # Valid URL,
        "http://video.udn.com/embed/news/300040",
        "https://video.udn.com/embed/news/300040",
        # Valid URL, protocol relative
        "//video.udn.com/embed/news/300040",
        "//video.udn.com/play/news/300040",
    ])

# Generated at 2022-06-26 13:17:09.687403
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    tr_url = "https://video.udn.com/embed/news/300040"
    udne = UDNEmbedIE()
    assert udne.IE_NAME == 'udn'
    assert udne._VALID_URL == url, "The url is " + url

# Generated at 2022-06-26 13:17:14.199165
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..compat import urlparse
    assert urlparse.urlparse(UDNEmbedIE._VALID_URL).scheme == 'https'

# Unit tests for _real_extract() of class UDNEmbedIE

# Generated at 2022-06-26 13:17:17.239653
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .core import BaseIE
    d = UDNEmbedIE()
    assert isinstance(d, BaseIE)

# Generated at 2022-06-26 13:17:27.317905
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert (udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-26 13:17:34.013340
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie.match(url)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:17:37.666240
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    class_udnembedIE = UDNEmbedIE()
    match = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    match_obj = re.match(match, url)
    id = match_obj.group('id')
    class_udnembedIE._real_extract(url, id)
    print("test_UDNEmbedIE() successfully")

# Generated at 2022-06-26 13:17:44.232957
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:19:00.833340
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-26 13:19:04.121688
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == "聯合影音"

# Generated at 2022-06-26 13:19:07.775351
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._match_id(url)

# Generated at 2022-06-26 13:19:17.454752
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_NAME == 'udn.com:embed'
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:19:20.349204
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    data = UDNEmbedIE.IE_DESC
    url = UDNEmbedIE._VALID_URL
    reslut = UDNEmbedIE.suitable(data, url)
    assert(reslut == "True")

# Generated at 2022-06-26 13:19:33.168555
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == ie.PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS == ie.TESTS
    url_str = "http://video.udn.com/embed/news/300040"
    url_str1 = "https://video.udn.com/embed/news/300040"
    url_str2 = "http://video.udn.com/play/news/300040"
    assert ie.suitable(url_str)

# Generated at 2022-06-26 13:19:41.292946
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    embed_obj = UDNEmbedIE()
    test_obj = InfoExtractor()
    assert embed_obj._VALID_URL == test_obj._VALID_URL
    assert embed_obj._PROTOCOL_RELATIVE_VALID_URL == test_obj._PROTOCOL_RELATIVE_VALID_URL
    assert embed_obj._TESTS == test_obj._TESTS

# Generated at 2022-06-26 13:19:51.689556
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == _PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL == _VALID_URL

# Generated at 2022-06-26 13:20:03.461587
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import TestIE
    from .common import InfoExtractor

    with TestIE.copy_or_skip_current_test_if(
        lambda: not InfoExtractor.is_suitable(UDNEmbedIE.IE_NAME)
    ):
        ie = InfoExtractor()
        ie_result = ie.extract_info(UDNEmbedIE.IE_NAME, UDNEmbedIE._TESTS[0]['url'], download=False)
        assert ie_result['id'] == UDNEmbedIE._TESTS[0]['info_dict']['id']
        assert ie_result['title'] == UDNEmbedIE._TESTS[0]['info_dict']['title']

# Generated at 2022-06-26 13:20:13.844421
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_DESC == '聯合影音'
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == r'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL