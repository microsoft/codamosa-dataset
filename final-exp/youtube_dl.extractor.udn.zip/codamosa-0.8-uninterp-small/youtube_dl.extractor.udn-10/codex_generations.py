

# Generated at 2022-06-26 13:12:56.697742
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC # check IE_DESC property exists
    assert UDNEmbedIE._VALID_URL # check _VALID_URL property exists
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL # check _PROTOCOL_RELATIVE_VALID_URL property exists
    assert UDNEmbedIE._download_webpage # check _download_webpage method exists
    assert UDNEmbedIE._match_id # check _match_id method exists
    assert UDNEmbedIE._real_extract # check _real_extract method exists
    assert UDNEmbedIE._sort_formats # check _sort_formats method exists
    assert UDNEmbedIE._html_search_regex # check _html_search_regex method exists
    assert UDNEmbed

# Generated at 2022-06-26 13:12:57.697116
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:12:58.518643
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(test_case_0())

test_UDNEmbedIE()

# Generated at 2022-06-26 13:12:59.399071
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-26 13:13:00.684439
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Test UDNEmbedIE")
    assert test_case_0()

# Generated at 2022-06-26 13:13:03.581133
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert isinstance(u_d_n_embed_i_e_0, UDNEmbedIE)


# Generated at 2022-06-26 13:13:08.946006
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_1 = UDNEmbedIE()

# Test cases for functions of class UDNEmbedIE

# Function: _real_extract
# Input: self, url
# Output: self._real_extract(url)

# Generated at 2022-06-26 13:13:17.275398
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case1 = UDNEmbedIE.UDNEmbedIE()
    l = test_case1._TESTS
    l1 = test_case1.IE_DESC
    l2 = test_case1._PROTOCOL_RELATIVE_VALID_URL
    l3 = test_case1._VALID_URL
    l4 = test_case1.test_UDNEmbedIE(test_case1)
    return l, l1, l2, l3, l4


# Generated at 2022-06-26 13:13:20.329990
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:13:22.167263
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_1 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:36.626109
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE('UDNEmbedIE')
    assert udn_embed_ie._VALID_URL.pattern == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)', \
        udn_embed_ie._VALID_URL.pattern
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)', \
        udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie.IE_NAME == 'UDNEmbedIE'

# Generated at 2022-06-26 13:13:37.958574
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:13:46.746737
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_content = 'http://video.udn.com/embed/news/300040'
    extractor = UDNEmbedIE()
    assert extractor.IE_DESC == '聯合影音'
    assert extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert extractor._VALID_URL == r'https?:' + extractor._PROTOCOL_RELATIVE_VALID_URL
    assert extractor._match_id(url_content) == '300040'


# Generated at 2022-06-26 13:13:55.314492
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # The URL is from a real page, and has been tested with _real_extract()
    url = 'http://video.udn.com/embed/news/300040'
    udn_ie = UDNEmbedIE()
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._VALID_URL == 'https?:' + udn_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_ie._match_id(url) == '300040'

# Generated at 2022-06-26 13:14:00.003309
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    ie._real_extract('http://video.udn.com/embed/news/300040')


# Generated at 2022-06-26 13:14:02.783565
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        ie = UDNEmbedIE()
    except Exception as e:
        pass

# Generated at 2022-06-26 13:14:06.771462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_instance = UDNEmbedIE()
    print('%s created!' % (str(udn_instance)))

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:14:14.148025
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor.IE_DESC == '聯合影音'
    assert extractor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert extractor._VALID_URL == r'https?:' + extractor._PROTOCOL_RELATIVE_VALID_URL
    assert extractor._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert extractor._TESTS[0]['info_dict']['id'] == '300040'
    assert extractor._TESTS[0]['info_dict']['ext'] == 'mp4'

# Unit

# Generated at 2022-06-26 13:14:18.588128
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbed = UDNEmbedIE()
    print(udnEmbed._TESTS)
    


# Generated at 2022-06-26 13:14:21.047740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    UDNEmbedIE()

# Generated at 2022-06-26 13:14:37.148625
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractorClass = UDNEmbedIE
    extractorInstance = extractorClass("http://video.udn.com/embed/news/300040")

    assert extractorInstance._VALID_URL == extractorInstance._VALID_URL
    assert extractorInstance._TESTS == extractorInstance._TESTS
    assert extractorInstance.IE_DESC == extractorInstance.IE_DESC

# Generated at 2022-06-26 13:14:41.411912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # this check is to verify the constructor in class InfoExtractor of youtube_dl works well
    assert ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-26 13:14:45.095492
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-26 13:14:50.713903
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    udne = UDNEmbedIE()
    assert(udne._match_id(url) == '300040')



# Generated at 2022-06-26 13:14:53.423682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	print(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
	print(UDNEmbedIE._VALID_URL)
	print(UDNEmbedIE._TESTS)


# Generated at 2022-06-26 13:14:57.149773
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class TestUDNEmbedIE:

        def __init__(self):
            self.downloader = None
            self.to_screen = None
            self.params = None

    TestUDNEmbedIE = TestUDNEmbedIE()
    TestUDNEmbedIE.params = {'skip_download': True}

    sample_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()

    try:
        info = ie.extract(sample_url)
    except Exception as e:
        print(e)

    print(info)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:15:05.272331
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    test_urls = [
        'https://video.udn.com/embed/news/300040',
        'http://video.udn.com/embed/news/300040',
    ]
    for url in test_urls:
        result = udn_embed_ie.suitable(url)
        assert result == True

# Generated at 2022-06-26 13:15:11.985369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    reg = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # test get_video_id()
    video_id = UDNEmbedIE._match_id(url)
    assert video_id == '300040'
    # test urls should be accepted
    valid_urls = [
        '//video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        'http://video.udn.com/play/news/300040',
    ]
    for url in valid_urls:
        assert re.match(reg, url) is not None
    # test urls should not be accepted

# Generated at 2022-06-26 13:15:20.937639
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:15:26.310878
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    i = IE._match_id('http://video.udn.com/embed/news/300040')
    assert i == '300040'
    i = IE._match_id('https://video.udn.com/embed/news/300040')
    assert i == '300040'

# Generated at 2022-06-26 13:15:54.017438
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'

    # Setup
    udn_embed_ie = UDNEmbedIE()

    # Test
    assert udn_embed_ie.IE_NAME == 'UDNEmbed'


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:15:55.797674
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:16:04.488444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnec = UDNEmbedIE()

    # Test URL which contains https
    url = "https://video.udn.com/embed/news/300040"
    exp_video_id = "300040"
    assert (udnec._match_id(url) == exp_video_id)

    # Test URL which contains http
    url = "http://video.udn.com/embed/news/300040"
    exp_video_id = "300040"
    assert (udnec._match_id(url) == exp_video_id)

# Generated at 2022-06-26 13:16:10.442481
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor test
    instance = UDNEmbedIE()
    assert instance.ie_key() == 'UDNEmbed'
    # Unit test for _real_extract
    instance._real_extract("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-26 13:16:10.993181
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.__bases__

# Generated at 2022-06-26 13:16:16.198938
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie.IE_DESC == "聯合影音"
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-26 13:16:21.296893
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import re
    assert UDNEmbedIE._VALID_URL == re.compile(r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
test_UDNEmbedIE()

# Generated at 2022-06-26 13:16:29.322388
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    # test _PROTOCOL_RELATIVE_VALID_URL
    for url1 in [
            '//video.udn.com/embed/news/300040',
            'http://video.udn.com/embed/news/300040',
            'https://video.udn.com/embed/news/300040']:
        m = IE._PROTOCOL_RELATIVE_VALID_URL_RE.match(url1)
        assert m.group('id') == '300040'

    # test _VALID_URL

# Generated at 2022-06-26 13:16:38.618914
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:41.560717
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test case 1: check the instance of UDNEmbedIE
    assert isinstance(UDNEmbedIE(), InfoExtractor)

# Generated at 2022-06-26 13:17:34.580197
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie.IE_DESC)
    print(ie._VALID_URL)
    print(ie._TESTS)

# Generated at 2022-06-26 13:17:44.698475
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video = UDNEmbedIE()
    assert video.IE_DESC == '聯合影音'
    assert video._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert video._VALID_URL == r'https?:' + _PROTOCOL_RELATIVE_VALID_URL
    assert 'video_id' in video._VALID_URL

# Generated at 2022-06-26 13:17:46.094735
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        udn = UDNEmbedIE()
    except:
        assert False, "Fail to initialize UDNEmbedIE"

# Generated at 2022-06-26 13:17:53.222143
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    video_id = (udne._match_id(url))
    assert video_id == '300040', 'UDNEmbedIE fails to extract video id'

# Generated at 2022-06-26 13:17:58.567919
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Initialize an object of class UDNEmbedIE
    ie = UDNEmbedIE('UDNEmbedIE', 'http://video.udn.com/embed/news/300040', {}, 'a')
    # Check for match_id() method
    match_id = ie.match_id('//video.udn.com/embed/news/300040')
    assert match_id == '300040'

# Generated at 2022-06-26 13:18:03.655788
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:18:07.434176
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    module = __import__('utils.py')
    class_name = module.__dict__['UDNEmbedIE']
    instance = class_name()
    assert instance.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:18:16.699335
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert re.match(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL,
        '//video.udn.com/embed/news/300040',
    )
    assert re.match(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL,
        'http://video.udn.com/embed/news/300040',
    )
    assert re.match(udn_embed_ie._VALID_URL,
        'https://video.udn.com/embed/news/300040',
    )

# Generated at 2022-06-26 13:18:25.045868
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:18:28.056410
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    e = UDNEmbedIE('UDN')
    assert e.IE_NAME == 'UDNEmbed'
    assert e.IE_DESC == '聯合影音'
    assert e._VALID_URL is not None

# Generated at 2022-06-26 13:20:38.409664
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(test=True)

# Generated at 2022-06-26 13:20:42.207413
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Basic test for the constructor of class UDNEmbedIE
    """
    IE = UDNEmbedIE()
    assert IE._VALID_URL == 'https?:' + IE._PROTOCOL_RELATIVE_VALID_URL
    assert IE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert IE._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert IE._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'


# Generated at 2022-06-26 13:20:49.496220
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('test')
    print(ie.IE_DESC)
    print(ie._PROTOCOL_RELATIVE_VALID_URL)
    print(ie._VALID_URL)
    print(ie._TESTS)
    print(ie._download_webpage)


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:20:51.024424
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:20:54.210959
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE(url)
    assert ie
    assert not ie is None

# Generated at 2022-06-26 13:20:57.826963
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _URL = 'http://video.udn.com/embed/news/300040'
    _UF = UDNEmbedIE(_URL)
    assert _UF._VALID_URL == 'https?:' + _UF._PROTOCOL_RELATIVE_VALID_URL
    assert _UF._match_id(_URL) == '300040'

# Generated at 2022-06-26 13:21:08.271188
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert(udne.ie_key() == 'udnembed')
    assert(udne.IE_DESC == '聯合影音')
    assert(udne.can_extract_format('http://video.udn.com/embed/news/300040'))
    assert(udne.can_extract_format('https://video.udn.com/play/news/303776'))
    assert(udne.can_extract_format('https://video.udn.com/embed/news/300040'))

# Generated at 2022-06-26 13:21:19.590451
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert re.match(pattern, '//video.udn.com/embed/news/300040')
    assert re.match(pattern, '//video.udn.com/play/news/300040')
    assert re.match(pattern, '//video.udn.com/play/news/300040?')
    assert re.match(pattern, '//video.udn.com/play/news/300040?foo=bar')

    assert UDNEmbedIE._VALID_URL.startswith('https?:')

# Generated at 2022-06-26 13:21:20.859333
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:21:31.317591
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME == 'udn'
    assert obj.IE_DESC == '聯合影音'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == 'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL