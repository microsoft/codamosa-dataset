

# Generated at 2022-06-26 13:13:01.626237
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_NAME == UDNEmbedIE.IE_NAME
    assert UDNEmbedIE().IE_DESC == UDNEmbedIE.IE_DESC
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL
    assert UDNEmbedIE()._TESTS == UDNEmbedIE._TESTS
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-26 13:13:10.432393
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert (UDNEmbedIE()._downloader == None)
    assert (UDNEmbedIE()._downloader_is_external == False)
    assert (UDNEmbedIE().IE_DESC == '聯合影音')
    assert (UDNEmbedIE()._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')
    assert (UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)')

# Generated at 2022-06-26 13:13:11.205651
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:12.392538
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE)


# Generated at 2022-06-26 13:13:24.413410
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert (u_d_n_embed_i_e.IE_DESC == '聯合影音')
    assert (_VALID_URL == 'https?:' + u_d_n_embed_i_e._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-26 13:13:31.157682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    options = {'title': '生物老師男變女 全校挺"做自己"', 'id': '300040'}
    u_d_n_embed_i_e = UDNEmbedIE(options)



# Generated at 2022-06-26 13:13:38.413063
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-26 13:13:43.225229
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_NAME == 'udn'
    assert UDNEmbedIE().IE_DESC == '聯合影音'
    assert UDNEmbedIE()._VALID_URL.startswith('https?:\\/\\/video\\.udn\\.com\\/')

# Generated at 2022-06-26 13:13:45.235795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()

# Generated at 2022-06-26 13:13:52.369121
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_1 = UDNEmbedIE()
    assert u_d_n_embed_i_e_1.ie_key() == 'UDNEmbed'
    assert u_d_n_embed_i_e_1.ie_desc() == '聯合影音'


# Generated at 2022-06-26 13:14:05.468473
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check if can be constructed without exception
    try:
        UDNEmbedIE()
        # If code got here, then the above did not raise an exception
        print('Successfully constructed!')
    except Exception as e:
        print('Failed to construct!')
        raise e

if __name__ == '__main__':
    test_UDNEmbedIE()

# vim: ts=4 sw=4 sts=4 et

# Generated at 2022-06-26 13:14:09.248837
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Test for _real_extract()

# Generated at 2022-06-26 13:14:11.002495
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert (UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-26 13:14:13.277692
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.ie_key() == 'udn'



# Generated at 2022-06-26 13:14:16.828285
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:14:24.380974
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    if not udne.IE_DESC:
        raise Exception('IE_DESC is empty!')
    if type(udne.IE_NAME) is not str:
        raise Exception('IE_NAME is not a str!')
    if type(udne.IE_DESC) is not str:
        raise Exception('IE_DESC is not a str!')
    if not udne.WORKING:
        raise Exception('WORKING should be true!')

# Generated at 2022-06-26 13:14:26.423035
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

# Generated at 2022-06-26 13:14:28.184781
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE)

# Generated at 2022-06-26 13:14:35.095092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS

# Generated at 2022-06-26 13:14:37.522397
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert isinstance(UDNEmbedIE(None), InfoExtractor)

# Generated at 2022-06-26 13:14:54.536343
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from urllib.parse import parse_qs
    from urllib.parse import urlsplit
    # Parse arguments
    arg_str = "https://video.udn.com/embed/news/300040"
    arguments = parse_qs(urlsplit(arg_str).query)
    arguments.get('url')[0]
    arguments.get('ie')
    arguments.get('video_id')
    assert arguments.get('url')[0] == 'https://video.udn.com/embed/news/300040'
    assert arguments.get('video_id') is None
    assert arguments.get('ie') == UDNEmbedIE

    # Parse query
    arg_str = "https://video.udn.com/embed/news/300040"
    udn_embed_ie = UDNEmbed

# Generated at 2022-06-26 13:15:01.269842
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    # Check _VALID_URL
    assert(udn_ie._VALID_URL ==
           'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    # Validate URL
    # sample URL: http://video.udn.com/embed/news/300040
    assert(udn_ie._is_valid_url(r'//video.udn.com/embed/news/300040') ==
           True)
    # sample URL: https://video.udn.com/play/news/303776
    assert(udn_ie._is_valid_url(r'//video.udn.com/play/news/303776') == True)
    # sample URL: https://video.udn.

# Generated at 2022-06-26 13:15:10.780579
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._match_id(url) == '300040'
    # Test _TESTS['url']

# Generated at 2022-06-26 13:15:12.129603
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tmp = UDNEmbedIE()
    assert tmp

# Generated at 2022-06-26 13:15:15.056157
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = utils.TestCase()
    a.test_UDNEmbedIE()

# Generated at 2022-06-26 13:15:21.645550
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    if udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL.rstrip('$') == '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)':
        print('_PROTOCOL_RELATIVE_VALID_URL variable defined successfully')
    else:
        print('_PROTOCOL_RELATIVE_VALID_URL variable defined failed')

    if udn_embed_ie._VALID_URL.rstrip('$') == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL:
        print('_VALID_URL variable defined successfully')
 
    # Successful case of the unit test for _match_id(self, url)

# Generated at 2022-06-26 13:15:30.728896
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    assert UDNEmbedIE.IE_DESC == '聯合影音'

    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert UDNEmbedIE._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"' 
    assert UDNEmbedIE._TESTS[0]['info_dict']['thumbnail'] == r're:^https?://.*\.jpg$'

# Generated at 2022-06-26 13:15:37.821611
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_test_urls = [
        'https://video.udn.com/embed/news/300040',
        'http://video.udn.com/embed/news/300040',
        'http://video.udn.com/play/news/300040',
        'https://video.udn.com/play/news/300040',
    ]
    UDNEmbedIE(udne_test_urls[0])
    UDNEmbedIE(udne_test_urls[1])
    UDNEmbedIE(udne_test_urls[2])
    UDNEmbedIE(udne_test_urls[3])

# Generated at 2022-06-26 13:15:48.977675
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn_embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie.VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-26 13:15:54.229371
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/play/news/303776')


# Generated at 2022-06-26 13:16:24.454438
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:25.260324
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-26 13:16:37.142226
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:39.106684
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_ie = UDNEmbedIE()
    url = 'https://video.udn.com/news/303776'
    udne_ie._real_extract(url)

test_UDNEmbedIE()

# Generated at 2022-06-26 13:16:42.949704
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
      udn = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    except:
      assert False, "test_UDNEmbedIE Failed"


# Generated at 2022-06-26 13:16:48.392460
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.ie_keywords['embed'] = [UDNEmbedIE, 'UDNEmbed']

    info_extractor = UDNEmbedIE()
    assert isinstance(info_extractor, UDNEmbedIE), info_extractor

    info_extractor = InfoExtractor.get_info_extractor(UDNEmbedIE._VALID_URL)
    assert isinstance(info_extractor, UDNEmbedIE), info_extractor

    with_scheme_info_extractor = InfoExtractor.get_info_extractor(
        'https:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert isinstance(with_scheme_info_extractor, UDNEmbedIE), with_scheme_info_extractor

    without_scheme_info

# Generated at 2022-06-26 13:16:49.448864
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:16:53.007457
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if r'http://video\.udn\.com/embed/news/300040' not in UDNEmbedIE._TESTS[0]['url']:
        raise ValueError()

# Generated at 2022-06-26 13:16:59.843135
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test the constructor of class UDNEmbedIE"""
    video_id = '300040'
    expected_object_type = 'udn'
    
    # Create a UDNEmbedIE object to test
    udn_embed_ie = UDNEmbedIE()
    
    # Test if the created object is an instance of class InfoExtractor
    assert isinstance(udn_embed_ie, InfoExtractor) == True
    
    # Test if the created object is an instance of class UDNEmbedIE
    assert isinstance(udn_embed_ie, UDNEmbedIE) == True
    
    # Test if the property _VALID_URL is the same as the regex pattern in _VALID_URL
    assert udn_embed_ie._VALID_URL == UDNEmbedIE._VALID_URL
    
   

# Generated at 2022-06-26 13:17:05.829457
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    ie = UDNEmbedIE(None)

    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:18:10.887796
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class UDNEmbedIE_Test(UDNEmbedIE):
        def _real_extract(self, url):
            return super(UDNEmbedIE_Test, self)._real_extract(url)

    test = UDNEmbedIE_Test()
    result = test.extract('http://video.udn.com/embed/news/300040')
    assert result['id'] == '300040'

    test = UDNEmbedIE_Test()
    result = test.extract('https://video.udn.com/embed/news/300040')
    assert result['id'] == '300040'

# Generated at 2022-06-26 13:18:16.208991
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/300040'
    ie = UDNEmbedIE(downloader=None)
    assert ie.suitable(url) == True
    #assert ie._VALID_URL == 'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:18:28.929108
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-26 13:18:31.304092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.ie_key() == 'udn'


# Generated at 2022-06-26 13:18:38.136157
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    def test_UDNEmbedIE(self, url, expected_video_id, expected_url):
        ie = UDNEmbedIE(url)
        self.assertEqual(ie.url, url)
        self.assertEqual(ie.video_id, expected_video_id)
        self.assertEqual(ie.url, expected_url)

# Generated at 2022-06-26 13:18:49.718215
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = "http://video.udn.com/embed/news/300040"
    print("Testing UDNEmbedIE")
    assert UDNEmbedIE().suitable(test_url)

    valid_urls = [
        "http://video.udn.com/embed/news/300040",
        "http://video.udn.com/play/news/300040",
        "https://video.udn.com/embed/news/300040",
        "https://video.udn.com/play/news/300040",
    ]
    for valid_url in valid_urls:
        print("Testing %s" % valid_url)
        assert UDNEmbedIE().suitable(valid_url)


# Generated at 2022-06-26 13:18:52.048682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()

# Generated at 2022-06-26 13:18:57.824997
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udNEmbedIE = UDNEmbedIE()
    assert udNEmbedIE.IE_DESC == '聯合影音'
    assert udNEmbedIE._VALID_URL == r'https?:' + udNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:19:06.954523
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Arrange
    url = 'http://video.udn.com/embed/news/300040'

    # Act
    ie = UDNEmbedIE()

    # Assert
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:19:15.550566
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:21:41.353373
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == r'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    assert instance.IE_DESC == '聯合影音'
    assert instance._TESTS[1]['only_matching'] == True

# Generated at 2022-06-26 13:21:52.508542
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert type(udn_embed_ie) == UDNEmbedIE
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:22:02.948633
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    assert udnEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbedIE._VALID_URL == r'https?:' + udnEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:22:05.737646
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UDNEmbed'

# Generated at 2022-06-26 13:22:10.633241
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # This URL works now. If it ever stops, feel free to remove it.
    ie.extract("https://video.udn.com/embed/news/300040")

# Generated at 2022-06-26 13:22:22.149916
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie.IE_NAME == 'video.udn.com:embed'
    assert ie.ie_key() == 'video.udn.com:embed'


# Generated at 2022-06-26 13:22:23.965426
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-26 13:22:25.861295
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnie = UDNEmbedIE()
    assert udnie.IE_NAME == "udn"

# Generated at 2022-06-26 13:22:29.817459
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(None)._match_id(url)

# Generated at 2022-06-26 13:22:30.926463
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDN')