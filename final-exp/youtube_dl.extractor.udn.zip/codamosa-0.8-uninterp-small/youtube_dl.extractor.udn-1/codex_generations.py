

# Generated at 2022-06-26 13:12:51.183922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert test_case_0() is None

# Generated at 2022-06-26 13:12:55.118892
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()



# Generated at 2022-06-26 13:12:56.508299
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(test_case_0() == None)

# Generated at 2022-06-26 13:12:58.718340
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test with the real url
    url = 'http://video.udn.com/embed/news/300040'
    # Get the test case
    test_case = test_case_0()
    # Test with the real url
    u_d_n_embed_i_e_0 = UDNEmbedIE()

# Generated at 2022-06-26 13:13:00.901837
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e is not None

# Generated at 2022-06-26 13:13:01.781555
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-26 13:13:07.617182
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .extractor.common import SearchInfoExtractor
    assert_true(issubclass(UDNEmbedIE, InfoExtractor))
    assert_true(issubclass(UDNEmbedIE, SearchInfoExtractor))

# Generated at 2022-06-26 13:13:15.298707
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    # Matching 'https://video.udn.com/embed/news/300040'
    # Matching 'http://video.udn.com/embed/news/300040'
    u_d_n_embed_i_e.match('')
    # Calling _real_extract on 'https://video.udn.com/embed/news/300040'
    # Calling _real_extract on 'http://video.udn.com/embed/news/300040'
    u_d_n_embed_i_e.real_extract('')
    u_d_n_embed_i_e.get_real_extract('')


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 13:13:25.273936
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    assert u_d_n_embed_i_e_0.suitable(url)
    assert u_d_n_embed_i_e_0.IE_NAME == 'Food Network'
    assert u_d_n_embed_i_e_0._VALID_URL == 'http://video\\.udn\\.com/embed/news/(?P<id>.+)'
    assert u_d_n_embed_i_e_0._NETRC_MACHINE == 'foodnetwork'
    assert u_d_n_embed_i_e_0._GEO_COUNTRIES == ['US']

# Generated at 2022-06-26 13:13:29.520367
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 13:13:36.562970
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('test')

# Generated at 2022-06-26 13:13:38.422477
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-26 13:13:43.816146
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL ==\
           r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == \
           r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:13:50.618638
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udnTest = UDNEmbedIE()
    video_id = udnTest._match_id(url)
    assert video_id == '300040'
    assert udnTest._real_extract(url)['id'] == '300040'

# Generated at 2022-06-26 13:13:56.842303
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_name = "UDNEmbedIE"
    url = "http://video.udn.com/embed/news/300040";
    uie = UDNEmbedIE()
    uie.ie_key = class_name;
    uie.webpage_url = url;
    uie._webpage_read_content_url = url;
    uie._match_id(url)
    uie.http_headers = {}
    uie.http_headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0'
    uie._downloader = None
    uie._download_webpage(url, "300040")
    uie._real_extract(url)

# Unit

# Generated at 2022-06-26 13:14:05.411301
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-26 13:14:16.676995
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Unit test for constructor of class UDNEmbedIE
    # 'url': 'http://video.udn.com/embed/news/300040',
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    info_dict = udn_embed_ie._real_extract(url)
    assert info_dict['id'] == '300040'
    assert info_dict['title'] == '生物老師男變女 全校挺"做自己"'

    # Unit test for constructor of class UDNEmbedIE
    # 'url': 'https://video.udn.com/embed/news/300040',

# Generated at 2022-06-26 13:14:21.099439
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:14:27.561922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    if not (IE._TESTS[0]['params']['skip_download']):
        assert False, 'UDNEmbedIE skip_download should be True'
    if IE._VALID_URL == r'https?://video\.udn\.com/embed/news/(?P<id>\d+)':
        assert True
    else:
        assert False, 'UDNEmbedIE _VALID_URL regex error'
    if IE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)':
        assert True
    else:
        assert False, 'UDNEmbedIE _PROTOCOL_RELATIVE_VALID_URL regex error'

# Generated at 2022-06-26 13:14:35.420455
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test case 1:
    test_url = 'http://video.udn.com/embed/news/300040'
    reg_exp = r'<div class="video_p">.*<iframe src="(?:https?:)?//video\.udn\.com/embed/news/300040.*?</div>'
    assert(re.search(reg_exp, test_url)) is not None
    return None


# Generated at 2022-06-26 13:14:57.082096
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_NAME == 'udn'
    assert ie._TESTS[0]['url'] == url
    assert ie._TESTS[0]['info_dict']['id'] == '300040'


# Generated at 2022-06-26 13:15:03.826233
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    test class UDNEmbedIE
    """
    url = 'https://video.udn.com/embed/news/300040'
    url_for_test = 'https://video.udn.com/embed/news/300040'
    assert url == url_for_test
    print("test_UDNEmbedIE() is finished.")

# Generated at 2022-06-26 13:15:11.579540
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie.IE_DESC)
    ie_version = ie.get_version()
    print('The version of IE is ' + str(ie_version))
    print(ie.WORKING)
    return ie

if __name__ == '__main__':
    import sys
    
    # Sample usage
    # python2.7 udne.py http://video.udn.com/embed/news/300040
    # python2.7 udne.py "https://video.udn.com/embed/news/300040"
    # python2.7 udne.py "https://video.udn.com/play/news/303776"
    # Please make sure the return URL is valid

# Generated at 2022-06-26 13:15:15.906908
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE._downloader, InfoExtractor(UDNEmbedIE._downloader), "http://video.udn.com/embed/news/300040")

# Generated at 2022-06-26 13:15:28.223142
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert _PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert _VALID_URL == 'https?:' + _PROTOCOL_RELATIVE_VALID_URL
    assert IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:15:31.954578
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    ie.extract(url)

# Generated at 2022-06-26 13:15:34.876356
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembed_ie = UDNEmbedIE()
    assert udnembed_ie._VALID_URL == 'https?:' + udnembed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:15:47.385443
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Testing constructors of class UDNEmbedIE")
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:48.894135
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie

# Generated at 2022-06-26 13:15:55.120050
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url="http://video.udn.com/embed/news/300040"
    udn_ie = UDNEmbedIE()
    udn_ie._match_id('http://video.udn.com/embed/news/300040') == '300040'

    udn_ie._match_id('http://video.udn.com/play/news/300040') == '300040'


# Generated at 2022-06-26 13:16:34.752171
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert isinstance(instance, UDNEmbedIE)
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == r'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    assert instance.IE_DESC == '聯合影音'
    assert isinstance(instance.IE_DESC, str)
    assert isinstance(instance.i, InfoExtractor)

# Generated at 2022-06-26 13:16:41.018411
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test case 1
    test_class = UDNEmbedIE(None)
    assert test_class.IE_DESC == '聯合影音'
    # test case 2
    test_class.IE_DESC = 'test'
    assert test_class.IE_DESC == 'test'

# Generated at 2022-06-26 13:16:44.851052
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    video_id = ie._match_id('http://video.udn.com/embed/news/300040')
    assert video_id == '300040'

# Generated at 2022-06-26 13:16:50.291614
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test = UDNEmbedIE()
    assert unit_test._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:57.081618
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Simple unit test for UDNEmbedIE
    """
    from ..utils import SearchInfoExtractor
    ie = SearchInfoExtractor()
    ie.add_info_extractor(UDNEmbedIE.ie_key())
    ret_val = ie.extract('https://video.udn.com/embed/news/300040')
    assert len(ret_val['entries']) == 1
    assert ret_val['entries'][0]['id'] == '300040'

# Generated at 2022-06-26 13:17:05.462319
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # An object under testing is created by the class constructor
    video_url = 'http://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE(0)
    assert video_url == udn_embed_ie._VALID_URL
    assert None == udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert None == udn_embed_ie.IE_DESC
    assert None == udn_embed_ie._TESTS

# Generated at 2022-06-26 13:17:14.307353
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # test valid URL
    valid_url = 'https://video.udn.com/embed/news/300040'
    url = ie._match_id(valid_url)
    assert url == '300040'

    # test invalid URL
    invalid_url = 'https://video.udn.com/play/news/invalid_id'
    url = ie._match_id(invalid_url)
    assert url == False

# Generated at 2022-06-26 13:17:20.123333
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    g = r.search('//video.udn.com/embed/news/300040')
    assert g.group('id') == '300040'


# Generated at 2022-06-26 13:17:28.075784
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    handler = UDNEmbedIE()
    handler.url = url
    handler._match_id(url)

# Generated at 2022-06-26 13:17:36.057265
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'



# Generated at 2022-06-26 13:18:49.919375
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Running test for constructor of class UDNEmbedIE")
    object_UDNEmbedIE = UDNEmbedIE("url_UDNEmbedIE",'IE_NAME_UDNEmbedIE')
    assert (object_UDNEmbedIE.url == "url_UDNEmbedIE")
    assert (object_UDNEmbedIE.ie_key() == 'IE_NAME_UDNEmbedIE')


# Generated at 2022-06-26 13:18:56.496544
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:18:59.057294
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    global InfoExtractor
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:19:01.801671
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Constructor of a UDNEmbedIE object
    """
    UDNEmbedIE()

# Generated at 2022-06-26 13:19:06.869266
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:19:07.537133
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(None)

# Generated at 2022-06-26 13:19:14.429392
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test the constructor of UDNEmbedIE
    """
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert len(ie._TESTS) == 3

# Generated at 2022-06-26 13:19:21.440619
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-26 13:19:32.907531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for UDNEmbedIE"""
    tester = UDNEmbedIE()
    tester.extract({ # pylint: disable=no-member
        'url': 'https://video.udn.com/embed/news/300040',
        'only_matching': True
    })

    assert type(tester.extract({ # pylint: disable=no-member
        'url': 'https://video.udn.com/play/news/303776',
        'only_matching': True
    })) == dict # pylint: disable=unidiomatic-typecheck

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:19:43.590502
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the case where the url matches the regex, and the page has options
    url = "http://video.udn.com/embed/news/300040"
    video_id = "300040"
    extractor = UDNEmbedIE()
    true_video_id = extractor._match_id(url)
    assert true_video_id == video_id
    true_url = extractor._real_extract(url)
    assert true_url["id"] == video_id

    # Test the case where the url matches the regex, and the page does not have options
    url2 = "http://video.udn.com/embed/news/262790"
    video_id2 = "262790"
    true_video_id2 = extractor._match_id(url2)
    assert true_video_id

# Generated at 2022-06-26 13:22:21.108569
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert "UDNEmbedIE" in globals()

if __name__ == '__main__':
    # Unit test for constructor
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:22:22.557067
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-26 13:22:34.528240
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_real_UDNEmbed = UDNEmbedIE()
    assert ie_real_UDNEmbed._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie_real_UDNEmbed._VALID_URL == r'https?:' + ie_real_UDNEmbed._PROTOCOL_RELATIVE_VALID_URL
    assert ie_real_UDNEmbed.IE_DESC == '聯合影音'
    assert ie_real_UDNEmbed._TESTS[0]["url"] == "http://video.udn.com/embed/news/300040"

# Generated at 2022-06-26 13:22:43.379318
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor_test_cases = {
        'UDNEmbedIE':
        {
            # From https://video.udn.com/news/303776
            'url': 'https://video.udn.com/play/news/303776',
            'only_matching': True,
        },
    }

    for (obj, cases) in constructor_test_cases.items():
        ie = globals()[obj](downloader=None)

        def _test_class(case):
            print("Test case: ", case)
            result = ie.suitable(case['url']) and ie._real_extract(case['url'])
            print("Actual: ", result)
            print("Expect: ", case['info_dict'])
            assert result == case['info_dict']
            print("Pass")

