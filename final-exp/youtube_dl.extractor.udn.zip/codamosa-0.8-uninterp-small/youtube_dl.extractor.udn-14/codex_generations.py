

# Generated at 2022-06-26 13:12:58.478041
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert UDNEmbedIE.IE_DESC == '聯合影音', 'UDNEmbedIE.IE_DESC not initialized properly'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)', 'UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL not initialized properly'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, 'UDNEmbedIE._VALID_URL not initialized properly'

# Generated at 2022-06-26 13:13:00.546560
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:13:03.441534
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:04.863428
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()

# Generated at 2022-06-26 13:13:07.336553
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()


# Generated at 2022-06-26 13:13:11.239220
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert "UDNEmbedIE" in globals()


if __name__ == '__main__':
    test_case_0()
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:13:14.112430
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(u_d_n_embed_i_e_0.IE_DESC == '聯合影音')

# Generated at 2022-06-26 13:13:20.188567
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_1 = UDNEmbedIE()
    assert u_d_n_embed_i_e_1.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:13:21.485751
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()


# Generated at 2022-06-26 13:13:34.613380
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-26 13:13:43.849755
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:13:55.074306
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test the following case for each subclasses:
        - case 1: Init instance with valid url
        - case 2: Init instance with invalid url
    """
    valid_url = "https://video.udn.com/embed/news/300040"
    valied_url_procol_relative = '//video.udn.com/embed/news/300040'
    invalid_url = "https://video.udn.com/community/video/300040"

    # Case 1: Init instance with valid url
    ie = UDNEmbedIE()
    assert ie.suitable(valid_url)
    assert ie.suitable(valied_url_procol_relative)
    # Case 2: Init instance with invalid url
    assert not ie.suitable(invalid_url)

# Generated at 2022-06-26 13:14:06.662951
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_common import TestCommon
    from .test_youtube import test_youtube_urls
    valid = r'https?://video\.udn\.com(?::\d+)?/(?:embed|play)/news/\d+'
    valid_url = 'http://video.udn.com/embed/news/300040'
    invalid_url = 'http://video.udn.com/play/news/300040'
    t = TestCommon.test_Factory(UDNEmbedIE,
        valid=[valid_url],
        invalid=[invalid_url],
        require_title=[valid_url],
        require_thumbnail=[valid_url],
    )
    test_youtube_urls(t, valid_url, valid)
    return t.run()

# Generated at 2022-06-26 13:14:11.195774
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-26 13:14:18.237632
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    embed_ie = UDNEmbedIE()
    # Check attribute of class
    assert embed_ie.IE_DESC == '聯合影音'
    assert embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert embed_ie._VALID_URL == 'https?:' + embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:14:23.422825
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test the constructor of class UDNEmbedIE.
    """
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:14:25.821316
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie.IE_NAME)
    print(ie.IE_DESC)


# Generated at 2022-06-26 13:14:30.835109
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:14:32.266922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-26 13:14:37.679219
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	test_cases = ['https://video.udn.com/video/news/303776', 'http://video.udn.com/embed/news/300040', 'https://video.udn.com/play/news/303776', 'https://video.udn.com/embed/news/300040']
	for case in test_cases:
		print(type(case))
		result = UDNEmbedIE.suitable(case)
		print(result)
		print('-------------------------')
		#assert result == True

# Generated at 2022-06-26 13:14:55.620733
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_NAME == 'UDNEmbed'

# Generated at 2022-06-26 13:15:00.092622
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_NAME == 'udn')
    assert(ie.IE_DESC == '聯合影音')


# Generated at 2022-06-26 13:15:10.305483
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:20.311933
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_youtube import _TEST_CASES
    import unittest

    cls = type('UDNEmbedIETestCase', (unittest.TestCase, ), {})


# Generated at 2022-06-26 13:15:29.748282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert (UDNEmbedIE._VALID_URL ==
            "https?:(//video\.udn\.com/(?:embed|play)/news/)(\d+)")
    assert (UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL ==
            "(//video\.udn\.com/(?:embed|play)/news/)(\d+)")

# Generated at 2022-06-26 13:15:36.242203
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE("")
    assert udne.IE_DESC == '聯合影音'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == r'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL
    assert udne._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udne._TESTS[0]['info_dict']['id'] == '300040'
    assert udne._TESTS[0]['info_dict']['ext']

# Generated at 2022-06-26 13:15:42.144917
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie.url == url
    assert ie.ie_key() == ie.ie_desc() == ie.IE_DESC


# Generated at 2022-06-26 13:15:47.905938
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE('UDNEmbed','http://www.udn.com.tw')
    if udn._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)':
        assert udn._VALID_URL, 'UDN Video failed'
        return True
    else:
        assert 1, 'UDN Video failed'
        return False
assert test_UDNEmbedIE()

# Generated at 2022-06-26 13:15:52.199310
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Instance
    youtube_embed_ie = UDNEmbedIE()
    assert youtube_embed_ie.IE_DESC == '聯合影音'
    assert youtube_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert youtube_embed_ie._VALID_URL == 'https?:' + youtube_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:15:55.940653
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    assert udneie.IE_DESC == '聯合影音'
    assert udneie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:26.691252
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_common import _test_generic_info_extractor
    return _test_generic_info_extractor('UDNEmbed', '300040')

# Generated at 2022-06-26 13:16:28.491113
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    udn = UDNEmbedIE()
    assert isinstance(udn, InfoExtractor)

# Generated at 2022-06-26 13:16:34.776173
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-26 13:16:36.085412
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-26 13:16:40.479461
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:16:43.783066
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # An instance of class UDNEmbedIE
    test_instance = UDNEmbedIE()
    # Check if the constructor works properly
    assert(test_instance)


# Generated at 2022-06-26 13:16:54.107237
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._TESTS[0]['params']['skip_download'] = False
    UDNEmbedIE._TESTS[0]['expected_warnings'] = []
    UDNEmbedIE._TESTS[0]['skip'] = 'Only works from Taiwan'
    UDNEmbedIE._TESTS[0]['params'] = {}
    UDNEmbedIE._TEST = UDNEmbedIE._TESTS[0:1]
    UDNEmbedIE._test()

# Generated at 2022-06-26 13:17:06.235290
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .universal import _download_webpage
    udn_embed = UDNEmbedIE(None)
    webpage = _download_webpage('https://video.udn.com/embed/news/300040', '300040')
    title = udn_embed._html_search_regex(r"title\s*:\s*'(.+?)'\s*,", webpage, 'title')
    assert title == '生物老師男變女 全校挺"做自己"'
    poster = udn_embed._html_search_regex(
        r"poster\s*:\s*'(.+?)'\s*,", webpage, 'poster', default=None)

# Generated at 2022-06-26 13:17:12.493226
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ieobj = UDNEmbedIE(0)
    assert ieobj.IE_DESC == '聯合影音'
    assert ieobj._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:17:13.267570
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert "YouTube" == ie.IE_DESC

# Generated at 2022-06-26 13:18:27.691627
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # This constructor returns a non-None object
    obj = UDNEmbedIE()
    # Test if IE_DESC of class object is not empty
    assert obj.IE_DESC != ''
    # Test if VALID_URL of class object is not empty
    assert obj.VALID_URL != ''
    # Test if TESTS of class object is not empty
    assert len(obj.TESTS) > 0

# Generated at 2022-06-26 13:18:40.025923
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/play/news/300040') == '300040'
    assert ie._match_id(
        'http://video.udn.com/embed/news/300040/does-not-matter') == '300040'

# Generated at 2022-06-26 13:18:46.852464
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-26 13:18:56.724500
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor test for UDN embeded video.
    """
    ie = UDNEmbedIE(None, 'http://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:19:01.847137
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE._TESTS[0]['url'] = UDNEmbedIE._TESTS[0]['info_dict']['id'] = url
    UDNEmbedIE._TESTS[2]['url'] = UDNEmbedIE._TESTS[2]['only_matching'] = url
    assert UDNEmbedIE._VALID_URL == (url.split('://')[1] if url.startswith('http:') else url)
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == url.split('://')[1]
    assert len(UDNEmbedIE._TESTS) == 3

# Generated at 2022-06-26 13:19:06.869431
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-26 13:19:09.248458
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = InfoExtractor({}, UDNEmbedIE, '', '')
    obj = ie._instantiate_extractor('', '', '', '', '')
    assert isinstance(obj, UDNEmbedIE)

# Generated at 2022-06-26 13:19:21.418522
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import sys
    sys.modules['__main__'] = __import__('__main__')
    from . import UDNIE
    from . import YoutubeIE
    from . import YoutubeDL
    from . import extractor
    class FakeOptions(object):
        def __init__(self, info_dicts):
            self.info_dicts = info_dicts
        def __getattr__(self, name):
            if name.startswith('add_info_dict'):
                key = name[len('add_info_dict_'):]
                return lambda value: self.info_dicts.update({key: value})
            return None
        def __setattr__(self, name, value):
            self.__dict__[name] = value

# Generated at 2022-06-26 13:19:33.468480
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_DESC == '聯合影音'
    assert instance._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == 'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    assert len(instance._TESTS) == 3

# Generated at 2022-06-26 13:19:39.742356
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-26 13:22:10.847076
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, None)

# Generated at 2022-06-26 13:22:24.187945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    c = UDNEmbedIE()
    assert c.IE_DESC == '聯合影音'
    assert c._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert c._VALID_URL == r'https?:' + c._PROTOCOL_RELATIVE_VALID_URL

    assert c._html_search_regex(
            r'var\s+options\s*=\s*([^;]+);', "var options = {};", 'options') == '{};'

# Generated at 2022-06-26 13:22:29.202098
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test = ie.suitable('http://video.udn.com/embed/news/300040') # return True
    assert test == True

# Unit test:
#     Download the mp4 format file

# Generated at 2022-06-26 13:22:40.022050
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert(udn_embed_ie.IE_NAME == 'udn')
    assert(udn_embed_ie.IE_DESC == '聯合影音')

    # test _real_extract function
    test_urls = ['http://video.udn.com/embed/news/300040', 'https://video.udn.com/play/news/303776', 'https://video.udn.com/embed/news/300040']
    ids = ['300040', '303776', '300040']
    for test_url, id in zip(test_urls, ids):
        assert(udn_embed_ie._match_id(test_url) == id)