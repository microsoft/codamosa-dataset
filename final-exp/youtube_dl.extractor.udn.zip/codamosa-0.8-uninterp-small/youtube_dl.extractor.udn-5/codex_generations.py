

# Generated at 2022-06-26 13:12:52.593798
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    b_a_c_k_u_p___globals_0 = globals()
    setattr(globals(), 'UDNEmbedIE', UDNEmbedIE)
    test_case_0()
    globals().clear()
    globals().update(b_a_c_k_u_p___globals_0)

# Generated at 2022-06-26 13:13:04.067663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert u_d_n_embed_i_e_0.IE_DESC == '聯合影音'
    assert u_d_n_embed_i_e_0._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:13:13.030114
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # There are the following arguments
    # https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/common.py
    # init(self, ie_key, ie_desc, ie_urls)

    u_d_n_embed_i_e_0 = UDNEmbedIE(
        'UDN',
        '聯合影音',
        [
            r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
        ]
    )


# Generated at 2022-06-26 13:13:21.407163
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert_equals(u_d_n_embed_i_e_0.IE_DESC, '聯合影音')
    assert_equals(u_d_n_embed_i_e_0._VALID_URL, r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-26 13:13:28.084774
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e = UDNEmbedIE()
    assert u_d_n_embed_i_e.IE_NAME == 'udn'
    assert u_d_n_embed_i_e.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:13:35.724363
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    var_1 = UDNEmbedIE.IE_DESC
    print(var_1)
    var_2 = UDNEmbedIE._VALID_URL
    print(var_2)
    var_3 = UDNEmbedIE._TESTS
    print(var_3)
    return

if __name__ == '__main__':
    test_case_0()
    #test_UDNEmbedIE()

# Generated at 2022-06-26 13:13:37.182308
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert isinstance(udn_embed_ie, UDNEmbedIE)

# Generated at 2022-06-26 13:13:39.789891
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u_d_n_embed_i_e_0 = UDNEmbedIE()


# Generated at 2022-06-26 13:13:47.333179
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == "聯合影音"
    assert UDNEmbedIE._VALID_URL == r"https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r"//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"

# Generated at 2022-06-26 13:13:50.684472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_case_0()
    test_UDNEmbedIE()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 13:14:07.506349
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:14:08.464774
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.IE_NAME

# Generated at 2022-06-26 13:14:12.825934
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udnembed_ie = UDNEmbedIE()
    assert udnembed_ie.suitable(url)

# Generated at 2022-06-26 13:14:14.616138
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._match_id(url)
    UDNEmbedIE().working

# Generated at 2022-06-26 13:14:18.725474
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE().suitable(url) == True

# Generated at 2022-06-26 13:14:22.655481
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test instance by passing url to the class constructor
    url = u"https://video.udn.com/play/news/300040"

    test_instance = UDNEmbedIE(url)
    test_instance.extract_info()

# Generated at 2022-06-26 13:14:27.584494
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Can be useful to set timeout to a higher value
    # timeout = 3.0
    # Can be useful to set verbose to True
    # verbose = True
    regex_test = r'var\s+options\s*=\s*([^;]+);'
    url_test = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(regex_test, url_test)


# Generated at 2022-06-26 13:14:30.982345
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor of class UDNEmbedIE.
    """

    ie = UDNEmbedIE()

# Extract info from the test case

# Generated at 2022-06-26 13:14:34.945100
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    match = udnei._VALID_URL.split('?')[0]
    assert udnei._match_id(match) == '300040'

# Generated at 2022-06-26 13:14:40.155068
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    test_UDNEmbedIE = UDNEmbedIE()
    test_UDNEmbedIE.download(url)

# Generated at 2022-06-26 13:14:56.878363
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #if udn.com is blocked, the following URL can be used for test
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie._match_id(url) is not None
    assert ie._match_id(url) == '300040'

# Generated at 2022-06-26 13:15:02.429640
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:09.801117
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnVideoUrl = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert udnVideoUrl.IE_DESC == '聯合影音'
    assert udnVideoUrl._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnVideoUrl._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:18.393343
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert len(ie._TESTS) == 3


# Generated at 2022-06-26 13:15:20.241247
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()

# Generated at 2022-06-26 13:15:29.724038
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:15:36.243903
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    print("[test_UDNEmbedIE(): Constructor of class UDNEmbedIE]")
    assert inst._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst._VALID_URL == r'https?:' + inst._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-26 13:15:42.144492
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    ie._real_extract(url)
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:15:46.481268
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_ie = UDNEmbedIE()
    assert udne_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne_ie.IE_NAME == 'udn'
    assert udne_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:15:54.777314
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_name = UDNEmbedIE.__name__
    if class_name == 'UDNEmbedIE':
        class_name = 'UdnIE'
    obj = globals()[class_name + '_test']()
    # assert(obj.ie_key() == 'UDNEmbed')
    assert(obj.IE_NAME == 'Udn')
    assert(obj.IE_DESC == obj.ie_key())
    assert(obj.ie_code() == "UDNEmbed")


# Generated at 2022-06-26 13:16:25.769859
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn = UDNEmbedIE()
    print(udn.IE_DESC)
    result = udn.extract(url)
    for key, value in result.items():
        print(key, ':', value)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:16:27.818904
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._downloader.params['http_chunk_size'] == 10485760

# Generated at 2022-06-26 13:16:34.453975
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_url = 'http://video.udn.com/embed/news/300040'
    expected_video_id = '300040'
    video_id = ie._match_id(test_url)
    return video_id == expected_video_id

# Generated at 2022-06-26 13:16:36.792715
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # assert IE is singleton
    assert ie is UDNEmbedIE()
    # assert ie is instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 13:16:38.293013
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'UDNEmbed'
    assert UDNEmbedIE.ie_key() in InfoExtractor._ALL_IES

# Generated at 2022-06-26 13:16:43.481301
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_ok = True
    try:
        inst = UDNEmbedIE()
    except TypeError as e:
        print(e)
        test_ok = False
    if test_ok:
        print('ok')
    else:
        print('fail')

# Main function for testing
if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-26 13:16:48.675496
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    demo = UDNEmbedIE()
    assert demo.IE_NAME == 'udn'
    assert demo._VALID_URL == 'https?://video.udn.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-26 13:16:57.741284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj1 = UDNEmbedIE()
    assert test_obj1._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj1.__class__.__name__ == 'UDNEmbedIE'
    assert test_obj1.ie_key() == 'UDNEmbed'
    assert test_obj1.IE_DESC == '聯合影音'
    assert re.search(test_obj1._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')


# Generated at 2022-06-26 13:17:07.768612
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    info_dict = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$'
    }
    params = {
        # m3u8 download
        'skip_download': True
    }
    expected_warnings = [
        'Failed to parse JSON Expecting value'
    ]

# Generated at 2022-06-26 13:17:09.096862
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj.IE_DESC == '聯合影音'

# Generated at 2022-06-26 13:18:15.219017
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    regex = r'^https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)$'
    result = re.match(regex, url)

    assert(result.group('id') == '300040')

# Generated at 2022-06-26 13:18:25.719954
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_downloads import fake_process

    url = 'http://video.udn.com/embed/news/300040'

    with fake_process('', 'Hello, World!') as proc:
        ie = UDNEmbedIE(proc)
        ie.url = url
        ie.extract()

    expected = 'http://video.udn.com/api/get_video/news/300040'

    assert proc.spy_fetches[expected]

# Generated at 2022-06-26 13:18:28.524221
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:18:37.888910
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    

# Generated at 2022-06-26 13:18:41.926650
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-26 13:18:51.458413
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert ie._TESTS[1]['only_matching'] == True

# Generated at 2022-06-26 13:18:53.390564
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'

# Generated at 2022-06-26 13:18:55.767236
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    return UDNEmbedIE('UDNEmbedIE')


# Generated at 2022-06-26 13:18:57.781900
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'udn'

# Generated at 2022-06-26 13:19:10.118968
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import mock
    import inspect

    class TestUDNEmbedIE(unittest.TestCase):
        def setUp(self):
            mock_download_webpage = mock.MagicMock()
            mock_download_webpage.side_effect = [
                'var options = {"title": "title", "poster": "poster_url", "video": {"mp4": "mp4_video_url"}}',
                'videourl1',
            ]
            mock_extract_m3u8_formats = mock.MagicMock()
            mock_extract_f4m_formats = mock.MagicMock()

# Generated at 2022-06-26 13:21:32.227366
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_DESC == '聯合影音'
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == r'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    assert instance._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert instance._TESTS[0]['info_dict']['id'] == '300040'
    assert instance._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 13:21:36.150531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    reference_url = ''
    extractor = UDNEmbedIE()._real_extract(reference_url)
    assert extractor is not None

# Generated at 2022-06-26 13:21:37.739199
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('') # should not raise exception

# Generated at 2022-06-26 13:21:40.285790
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert (udn_ie.IE_DESC == '聯合影音')


# Generated at 2022-06-26 13:21:44.940809
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-26 13:21:52.350099
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')

    # test _PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # test _VALID_URL
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-26 13:22:02.881558
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == r'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL
    assert len(udn._TESTS) == 3
    # first test case
    test_case = udn._TESTS[0]
    assert test_case['url'] == 'http://video.udn.com/embed/news/300040'
    assert test_case['info_dict']['id'] == '300040'

# Generated at 2022-06-26 13:22:06.470576
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE().extract("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-26 13:22:09.370744
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'Unified'


# Generated at 2022-06-26 13:22:10.900419
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("test")