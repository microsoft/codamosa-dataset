

# Generated at 2022-06-12 18:38:34.872077
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a_test_object = UDNEmbedIE()
    # Test helper functions of class UDNEmbedIE
    a_test_object._extract_f4m_formats = None
    a_test_object._extract_m3u8_formats = None
    a_test_object._html_search_regex = None
    a_test_object._match_id = None
    a_test_object._parse_json = None
    a_test_object._sort_formats = None
    a_test_object.url_result = None
    # Test constructor of class UDNEmbedIE
    a_test_object = UDNEmbedIE()
    print(a_test_object)
    assert a_test_object

# Generated at 2022-06-12 18:38:37.294077
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test no parameter given
    UDNEmbedIE()
    # Test parameter given
    UDNEmbedIE(None, None)
    UDNEmbedIE(info_extractor=InfoExtractor())

# Generated at 2022-06-12 18:38:40.412596
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:38:51.429885
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert (ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:38:55.769776
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor of class UDNEmbedIE
    UDNEmbedIE()


# Generated at 2022-06-12 18:39:05.914272
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/play/news/303776')
    UDNEmbedIE('https://video.udn.com/play/news/303776?type=embed')
    UDNEmbedIE('https://video.udn.com/play/news/303776?type=embed&ad=0')

# Generated at 2022-06-12 18:39:16.509524
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/news/303776'
    udn_video = UDNEmbedIE()
    udn_video._download_webpage('https://video.udn.com/news/303776', '303776')
    udn_video._match_id('https://video.udn.com/news/303776')
    #udn_video._real_extract('https://video.udn.com/news/303776')

    # Check url is correct
    assert url == 'https://video.udn.com/news/303776'


# Generated at 2022-06-12 18:39:26.842348
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._match_id('http://video.udn.com/embed/news/300040') # Should be OK
    UDNEmbedIE()._match_id('http://video.udn.com/play/news/300040') # Should be OK
    UDNEmbedIE()._match_id('http://video.udn.com/random/news/300040') # Should be not match
    UDNEmbedIE()._match_id('http://video.udn.com/embed/news/300040/') # Should be not match
    UDNEmbedIE()._match_id('http://video.udn.com/embed/news/300040/random') # Should be not match

# Generated at 2022-06-12 18:39:27.671554
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:39:34.240344
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_video = UDNEmbedIE()._real_extract(url)
    assert udn_video['id'] == '300040'
    assert udn_video['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-12 18:39:49.040842
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('example')
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:39:53.250622
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    udnembed_ie = UDNEmbedIE()
    print (udnembed_ie)

# Generated at 2022-06-12 18:40:01.704170
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnie = UDNEmbedIE()
    assert udnie.IE_DESC == '聯合影音'

    assert udnie.suitable('http://video.udn.com/embed/news/300040')
    assert udnie.suitable('https://video.udn.com/embed/news/300040')
    assert udnie.suitable('https://video.udn.com/play/news/303776')

    assert not udnie.suitable('https://video.udn.com/')
    assert not udnie.suitable(
        'https://video.udn.com/news/story/1/300003')

# Generated at 2022-06-12 18:40:02.628553
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    isinstance(UDNEmbedIE(), InfoExtractor)

# Generated at 2022-06-12 18:40:06.576185
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL



# Generated at 2022-06-12 18:40:14.029791
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Basic constructor test
    assert UDNEmbedIE is not None

    # Check the type of IE_DESC
    assert UDNEmbedIE.IE_DESC is not None
    assert isinstance(UDNEmbedIE.IE_DESC, str)

    # Check the type of _VALID_URL
    assert UDNEmbedIE._VALID_URL is not None
    assert isinstance(UDNEmbedIE._VALID_URL, str)

    # Check the type of _TESTS
    assert UDNEmbedIE._TESTS is not None
    assert isinstance(UDNEmbedIE._TESTS, list)
    assert len(UDNEmbedIE._TESTS) > 0

    # Check the type of _PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._

# Generated at 2022-06-12 18:40:19.404119
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    result = UDNEmbedIE()._real_extract(url)
    assert result['id'] == '303776'
    assert result['title'] == '法正大學校董胡詩晴被捕'

# Generated at 2022-06-12 18:40:26.441308
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._VALID_URL == 'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL
    assert udn.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:40:27.777959
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # todo: implement unit test
    assert False

# Generated at 2022-06-12 18:40:31.799258
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:40:44.386121
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:40:47.173763
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' in globals()
    try:
        UDNEmbedIE()
    except:
        assert False
    assert True


# Generated at 2022-06-12 18:40:50.123388
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE()
    assert udnIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:41:01.830956
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test constructor of class UDNEmbedIE"""

    url = "http://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?:(?:https?:)?//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)' 
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'(?:https?:)?//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._match_id(url) == '300040'
    assert ie._download_webpage != None


# Generated at 2022-06-12 18:41:12.211323
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE() 
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:41:22.403935
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'
    page = '<script src="http://video.udn.com/embed/news/300040"></script><script>if (b){var c="300040";b.send(c)}</script>'
    # the tranformed options_str is valid JSON format

# Generated at 2022-06-12 18:41:33.910045
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print('1')
    ie._download_webpage()
    print('2')
    ie._extract_m3u8_formats()
    print('3')
    ie._extract_f4m_formats()
    print('4')
    ie._html_search_regex()
    print('5')
    ie.UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    print('6')
    ie.UDNEmbedIE._VALID_URL
    print('7')
    ie.UDNEmbedIE._TESTS
    print('8')
    ie.UDNEmbedIE._real_extract
if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:41:45.086945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern = r'http://video.udn.com/embed/news/([\d]+)'
    match = re.match(pattern, 'http://video.udn.com/embed/news/300040')
    if match is not None:
        video_id = match.group(1)
        print(video_id)

    # pattern = r"var\s+options\s*=\s*([^;]+);"
    # match = re.search(pattern, "var options = $.parseJSON('{\"video\":{\"sd\":\"https://v.udn.com.tw/wp-content/uploads/2019/03/vgt_190322_lg_intl_hk_protest_b.mp4\",\"sd_hls\":\"https://vs.udn.com.tw:1935/

# Generated at 2022-06-12 18:41:50.632432
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.regexs == [{'regex': re.compile(r'//video\.udn\.com/(?:embed|play)/news/(\d+)'), 'class': ['UDNEmbedIE']}]
    assert ie.url_patterns == [r'(?:https?:)?//video\.udn\.com/(?:embed|play)/news/(\d+)']

# Generated at 2022-06-12 18:41:54.376643
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' in globals()
    global UDNEmbedIE
    UDNEmbedIE = type(globals()['UDNEmbedIE'].__name__,
                      globals()['UDNEmbedIE'].__bases__,
                      dict(globals()['UDNEmbedIE'].__dict__))

# Generated at 2022-06-12 18:42:23.957484
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie.__name__ == 'UDNEmbed'

# Generated at 2022-06-12 18:42:29.458291
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbed = UDNEmbedIE()
    assert(udnEmbed._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udnEmbed._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:42:34.496099
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_test = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url_test).ie._download_webpage(url_test, '300040')

# Generated at 2022-06-12 18:42:39.204225
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-12 18:42:49.623689
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    assert inst._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert inst.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:42:52.702658
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # Should not raise any exception
    udn_embed_ie.ie_key()
    udn_embed_ie.suitable(None)
    udn_embed_ie.suitable(VERSION)

# Generated at 2022-06-12 18:42:55.153687
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test UDNEmbedIE.__init__() constructor."""
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:42:59.741116
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://www.youtube.com/watch?v=BaW_jenozKc')
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/play/news/300040')

# Generated at 2022-06-12 18:43:02.667284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(type(UDNEmbedIE))
    udn_ie = UDNEmbedIE()
    print(type(udn_ie))
    assert type(udn_ie) is UDNEmbedIE

# Generated at 2022-06-12 18:43:09.498929
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from inspect import getargspec

    ieu = UDNEmbedIE()
    assert(ieu.ie_key() == 'udnembed')
    assert(ieu.ie_desc() == '聯合影音')
    assert(ieu.ie_name() == 'UDNES')
    assert(ieu.ie_module() == __name__.split('.')[-1])

    assert(len(getargspec(ieu.__init__).args) == 1)
    assert(ieu._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(ieu._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:44:19.216845
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:24.039677
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()
    assert x._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert x._VALID_URL == 'https?:' + x._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-12 18:44:26.175994
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    cUDNEmbedIE = UDNEmbedIE(None)
    assert cUDNEmbedIE

# Generated at 2022-06-12 18:44:30.711328
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Tests for class UDNEmbedIE.
    """
    # Test constructor
    obj = UDNEmbedIE()
    assert obj.ie_key() == 'UDNEmbed'
    assert obj.ie_desc() == '聯合影音'

# Generated at 2022-06-12 18:44:42.387387
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Init UDNEmbedIE
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == ie.PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS == ie.TESTS
    # Test if the regex of _VALID_URL matches the url
    assert ie._match_id(ie._VALID_URL) == '300040'
    assert ie._match_id(ie._PROTOCOL_RELATIVE_VALID_URL) == '300040'

# Generated at 2022-06-12 18:44:49.996137
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:44:58.427585
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    # print(instance._match_id('1'))
    # print(instance._match_id('http://video.udn.com/embed/news/300040'))
    # print(instance._match_id('https://video.udn.com/embed/news/300040'))
    # print(instance.IE_DESC)
    # print(instance._real_extract('https://video.udn.com/embed/news/300040'))
    # print(instance._real_extract('https://video.udn.com/play/news/303776'))
    print(instance)

# Generated at 2022-06-12 18:45:05.266144
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040'))
    assert(re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/play/news/300040'))
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:45:06.527995
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE() != None)

# Generated at 2022-06-12 18:45:10.135995
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    data = ie._real_extract(url)

    assert data.get('id') == '300040'


test_UDNEmbedIE()

# Generated at 2022-06-12 18:47:50.030197
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import os
    import pytest
    from .common import SOURCE_TMPDIR
    from ..compat import compat_urlretrieve
    import requests
    if not os.path.isdir(SOURCE_TMPDIR):
        os.makedirs(SOURCE_TMPDIR)
    for test_url in UDNEmbedIE._TESTS:
        if 'id' in test_url:
            _id = test_url['id']
        else:
            _id = '300040'
        url = 'https://video.udn.com/embed/news/' + _id
        page = requests.get(url).text
        file_name = os.path.join(SOURCE_TMPDIR, _id + '.html')

# Generated at 2022-06-12 18:47:55.759938
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:48:00.986367
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-12 18:48:07.174076
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """

    expected_results = {'id': '300040', 'ext': 'mp4', 'title': '生物老師男變女 全校挺"做自己"', 'thumbnail': r're:^https?://.*\.jpg$'}
    actual_results = UDNEmbedIE()._real_extract({'url': 'http://video.udn.com/embed/news/300040'})

    assert actual_results['id'] == expected_results['id']
    assert actual_results['ext'] == expected_results['ext']
    assert actual_results['title'] == expected_results['title']

# Generated at 2022-06-12 18:48:17.785578
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .. import construct_format
    testcase = UDNEmbedIE(None)
    assert testcase.IE_DESC == '聯合影音'
    assert testcase._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert testcase._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040', \
        "Testcase of 'http://video.udn.com/embed/news/300040' should be right!"

    format = construct_format(
        'http://blahblah', 'http-mp4', 'http-mp4', 'mp4', 1024, 640)
    assert format.url == 'http://blahblah'