

# Generated at 2022-06-12 18:38:33.851587
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE.IE_NAME == "udn")
    assert(UDNEmbedIE.IE_DESC == "聯合影音")
    assert(UDNEmbedIE.FILE_SUFFIX == "mp4")

# Generated at 2022-06-12 18:38:44.611781
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    m_UDNEmbedIE = UDNEmbedIE()
    
    # Unit test for _PROTOCOL_RELATIVE_VALID_URL
    m_PROTOCOL_RELATIVE_VALID_URL = m_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert m_PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Unit test for _VALID_URL
    m_VALID_URL = m_UDNEmbedIE._VALID_URL
    assert m_VALID_URL == r'https?:' + m_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

    # Unit test for _TESTS
    m_

# Generated at 2022-06-12 18:38:48.560370
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:38:53.047791
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-12 18:38:56.019895
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = UDNEmbedIE
    # constructor of class_
    instance = class_('Arg')


# Generated at 2022-06-12 18:39:01.240244
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' in globals()
    x = UDNEmbedIE()
    assert isinstance(x, InfoExtractor)
    assert isinstance(x, UDNEmbedIE)

# Test for extract, returns default_info for given URL

# Generated at 2022-06-12 18:39:04.723885
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:39:06.682489
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/300040'
    assert ie._match_id(url) == '300040'

# Generated at 2022-06-12 18:39:11.593147
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # The constructor of class IEmbedIE should
    # 1) inherit from class InfoExtractor
    # 2) have the class attributes defined in `_TESTS`.
    # Here we use these assertions to make sure the constructor works as intended.

    # Check 1)
    def is_instance_of_info_extractor(obj):
        return isinstance(obj, InfoExtractor)
    assert is_instance_of_info_extractor(UDNEmbedIE())

    # Check 2)
    attr = UDNEmbedIE.IE_DESC
    assert attr is not None

    attr = UDNEmbedIE._TESTS
    assert isinstance(attr, (list, tuple)) and len(attr) > 0

    # Check attribute `_VALID_URL`
    attr = UDNEmbedIE._VALID_

# Generated at 2022-06-12 18:39:21.583425
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    info_dict = {
        'url': url,
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }

    ie = UDNEmbedIE()
    ie_result = ie.extract(url)
    assert ie_result['id'] == info_dict['id']
    assert ie_result['ext'] == info_dict['ext']
    assert ie_result['title'] == info_dict['title']

# Generated at 2022-06-12 18:39:40.558942
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:50.033592
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-12 18:39:57.769184
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udnEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:06.976991
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE();

    url = 'http://video.udn.com/embed/news/300040'
    udn._real_extract(url)

    url = 'https://video.udn.com/embed/news/300040'
    udn._real_extract(url)

    # test of protocol relative URL
    url = '//video.udn.com/embed/news/300040'
    udn._real_extract(url)

    url = 'http://udn.com/video.udn.com/embed/news/300040'
    udn._real_extract(url)

    # test of non-URL
    url = 'http://video.udn.com/embed/news/300040'
    udn._real_extract('hi')
    udn

# Generated at 2022-06-12 18:40:11.769586
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor_name = 'udn'
    udnIE = InfoExtractor.by_name(info_extractor_name)()
    assert info_extractor_name == udnIE.IE_NAME, "the IE_NAME of "\
            + "InfoExtractor.by_name(" + info_extractor_name + ")() "\
            + "and InfoExtractor('" + info_extractor_name + "') are "\
            + "not match!"

# Generated at 2022-06-12 18:40:16.181578
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:21.269029
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert info_extractor.ie_key() == 'UDNEmbed'
    assert info_extractor._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:29.290462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembedIE = UDNEmbedIE()
    assert udnembedIE.IE_DESC == '聯合影音'
    assert udnembedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnembedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:40:32.296256
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Test for _real_extract() of class UDNEmbedIE

# Generated at 2022-06-12 18:40:35.017575
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = globals()['UDNEmbedIE']
    assert class_ is not None

# Generated at 2022-06-12 18:40:55.464022
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnei._VALID_URL == r'https?:' + udnei._PROTOCOL_RELATIVE_VALID_URL
    assert udnei._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udnei._TESTS[0]['info_dict']['id'] == '300040'
    assert udnei._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:41:00.631665
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == 'https?:' + UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE().IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:41:07.857304
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbed = UDNEmbedIE()
    assert udnEmbed.IE_DESC == '聯合影音'
    assert udnEmbed._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnEmbed._VALID_URL == r'https?:' + udnEmbed._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:41:17.245004
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE.
    """
    # Check valid URL
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Check invalid URL
    udn_embed_ie = UDNEmbedIE(UDNEmbedIE._VALID_URL + '1')
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:41:17.864952
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:41:20.773862
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        'https://video.udn.com/play/news/300040',
    ]
    for url in urls:
        assert UDNEmbedIE.suitable(url)

    assert not UDNEmbedIE.suitable('http://video.udn.com/play/news/300040')

# Generated at 2022-06-12 18:41:22.133433
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Construct an instance of class UDNEmbedIE to test it
    """
    UDNEmbedIE()

# Generated at 2022-06-12 18:41:24.476366
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO: We can not test IE which requires website.
    pass

# Generated at 2022-06-12 18:41:29.589248
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test 1: An embedded video
    url = 'https://video.udn.com/embed/news/300040'
    UDN = UDNEmbedIE()
    assert UDN._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDN._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDN._match_id(url) == '300040'

    # Test 2: A normal video
    url = 'https://video.udn.com/play/news/303776'
    assert UDN._match_id(url) == '303776'


# Generated at 2022-06-12 18:41:34.406851
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:42:05.922526
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL
    obj = UDNEmbedIE('', '')
    assert obj._PROTOCOL_RELATIVE_VALID_URL == _PROTOCOL_RELATIVE_VALID_URL
    assert obj._VALID_URL == _VALID_URL

# Generated at 2022-06-12 18:42:09.362483
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor test
    """
    ie = UDNEmbedIE()
    # test protocol-relative URL
    match = ie._PROTOCOL_RELATIVE_VALID_URL_RE.search('//video.udn.com/embed/news/300040')
    assert match is not None, 'Failed to parse protocol-relative URL'
    assert match.group('id') == '300040', 'Failed to parse protocol-relative URL'
    # test valid URL
    match = ie._VALID_URL_RE.search('https://video.udn.com/embed/news/300040')
    assert match is not None, 'Failed to parse valid URL'
    assert match.group('id') == '300040', 'Failed to parse valid URL'

# Generated at 2022-06-12 18:42:19.834394
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE(True)
    assert obj.IE_NAME == 'udn'
    assert obj.IE_DESC == '聯合影音'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL
    assert obj._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert obj._TESTS[0]['info_dict']['id'] == '300040'
    assert obj._TESTS[0]['params']['skip_download'] == True

# Generated at 2022-06-12 18:42:27.891798
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UdnEmbedIE = UDNEmbedIE()
    assert UdnEmbedIE.IE_NAME == 'udn'
    assert UdnEmbedIE.IE_DESC == '聯合影音'
    assert UdnEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:32.892129
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test case for class UDNEmbedIE
    test_case = UDNEmbedIE()

    # - Test
    assert test_case._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:42.226532
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_string = r'''
        var options = { "video":{ "mp4":"foo", "youtube":"bar" }, "poster":"posterUrl", "title":"video title" };
    '''
    test_json = js_to_json(test_string)
    test_obj = UDNEmbedIE()
    assert test_obj._parse_json(test_json, 'options') == {
        'video': {
            'mp4': 'foo',
            'youtube': 'bar',
        },
        'poster': 'posterUrl',
        'title': 'video title',
    }

# Generated at 2022-06-12 18:42:45.991241
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor = globals()['UDNEmbedIE']
    ie = constructor(compat_urllib_request.Request('https://video.udn.com/embed/news/300040'))
    assert ie.ie_key() == 'Udn'

# Generated at 2022-06-12 18:42:51.393555
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(\d+)'
    assert UDNEmbedIE.IE_DESC == '聯合影音'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:43:01.991860
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    import os
    import tempfile

    curr_dir = os.path.dirname(os.path.realpath(__file__))
    temp_file_path = tempfile.mktemp() + ".html"

    # Copy test page to a temporary file
    with open(os.path.join(curr_dir, "test_page_udn.html")) as fr:
        with open(temp_file_path, "w") as fw:
            fw.write(fr.read())


# Generated at 2022-06-12 18:43:04.552937
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert (UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:44:18.437214
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # get the instance of class
    tester = UDNEmbedIE()

    # test _valid_url
    assert tester._valid_url('https://video.udn.com/embed/news/300040')
    assert not tester._valid_url('https://video.udn.com/play/news/300040')
    assert tester._valid_url('http://video.udn.com/embed/news/300040')
    assert not tester._valid_url('http://video.udn.com/play/news/300040')
    assert not tester._valid_url('http://video.udn.com/play/news/300040_test')
    assert not tester._valid_url('http://video.udn.com/play/news/300040_test')
    assert not tester._valid_

# Generated at 2022-06-12 18:44:24.038993
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for url 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(
        'https://video.udn.com/embed/news/300040')


# Test for URL 'https://video.udn.com/play/news/303776'
# Tested video not available anymore, test only that the URL matches

# Generated at 2022-06-12 18:44:25.332394
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

test_UDNEmbedIE()

# Generated at 2022-06-12 18:44:26.254293
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:44:29.244393
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    udn._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:44:33.497109
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.compile(r'^https?://video\.udn\.com/(?:embed|play)/news/\d+$').match('http://video.udn.com/embed/news/300040')



# Generated at 2022-06-12 18:44:36.592198
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnie = UDNEmbedIE()
    assert str(udnie) == '<UDNEmbedIE>'
    assert udnie.SUCCEEDED == True
    assert udnie.FAILED == False
    assert udnie.IE_NAME == 'UDNEmbed'
    assert udnie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:44:45.997239
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    assert udn_embed._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed._VALID_URL == r'https?:' + udn_embed._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:44:52.267197
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()
    assert class_UDNEmbedIE
    assert class_UDNEmbedIE.IE_DESC == '聯合影音'
    assert class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Class constructor has no 'return' statement
    assert class_UDNEmbedIE

# Generated at 2022-06-12 18:44:54.811472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'

    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-12 18:47:37.658895
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:47:38.345058
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _ = UDNEmbedIE(None)

# Generated at 2022-06-12 18:47:40.354244
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    DEFAULT_URL = 'https://video.udn.com/embed/news/300040'
    DEFAULT_ID = '300040'
    DEFAULT_VIDEO_URL

# Generated at 2022-06-12 18:47:46.324296
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    info = ie._real_extract(url);
    assert info['title'] == '生物老師男變女 全校挺"做自己"'
    assert info['thumbnail'] == 'http://www.udn.com/news/storyimg/media/300040/300040-1052.jpg'

# Generated at 2022-06-12 18:47:48.792918
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert 'app.udn.com' in ie._VALID_URL
    ie = UDNEmbedIE('video.udn.com')
    assert 'video.udn.com' in ie._VALID_URL

# Generated at 2022-06-12 18:47:49.803557
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create a UDNEmbedIE object
    UDNEmbedIE()

# Generated at 2022-06-12 18:47:50.894696
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._extract_urls('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:47:56.070748
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL



# Generated at 2022-06-12 18:48:04.079388
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'

    video = UDNEmbedIE(url)

    assert video.IE_DESC == '聯合影音'
    assert video._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert video._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    assert video._match_id(url) == video_id



# Generated at 2022-06-12 18:48:13.613558
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL
    udne = UDNEmbedIE(downloader=None)
    assert isinstance(udne, InfoExtractor)
    assert udne.IE_DESC == IE_DESC
    assert udne._PROTOCOL_RELATIVE_VALID_URL == _PROTOCOL_RELATIVE_VALID_URL
    assert udne._VALID_URL == _VALID_URL