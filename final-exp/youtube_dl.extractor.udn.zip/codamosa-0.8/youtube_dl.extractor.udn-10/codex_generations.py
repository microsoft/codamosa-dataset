

# Generated at 2022-06-12 18:38:31.817644
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:38:36.546800
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InstaIE
    udne_ie = UDNEmbedIE(InstaIE(), 'https://a.b/embed/news/12345')
    udne_ie.IE_NAME = 'udn.com'
    # Test for valid url
    assert udne_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test for invalid url
    assert udne_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:38:48.405329
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()
    assert class_UDNEmbedIE.IE_DESC == '聯合影音'
    assert class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert class_UDNEmbedIE._VALID_URL == r'https?:' + class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert class_UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert class_UDNEmbedIE._TESTS[0]['info_dict']['id']

# Generated at 2022-06-12 18:38:52.491510
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test 1
    UDNEmbedIE.supertv = lambda self, user=2: 'supertv'
    assert UDNEmbedIE.supertv(1) == 'supertv'

    # Test 2
    assert UDNEmbedIE.get_instance(1) == 'supertv'

# Generated at 2022-06-12 18:39:03.983601
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_IE = UDNEmbedIE()

    assert udn_embed_IE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_IE._VALID_URL == r'https?:' + udn_embed_IE._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_IE.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:39:08.129607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:20.671156
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_play = UDNEmbedIE()
    # match test
    print('Match test:')
    print(udn_play._match_id('http://video.udn.com/embed/news/300040'))
    print(udn_play._match_id('https://video.udn.com/embed/news/300040'))
    print(udn_play._match_id('http://video.udn.com/play/news/303776'))
    print(udn_play._match_id('https://video.udn.com/play/news/303776'))
    # download test
    print('Download test:')
    print(udn_play.download('http://video.udn.com/embed/news/300040'))

# Generated at 2022-06-12 18:39:29.396802
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Mock urlopen().read()
    def mock_urlopen_read(*args, **kwargs):
        if 'play/news/303776' in args[0].get_full_url():
            return '''
                var options = {"video": {"mp4": null, "youtube": "https://www.youtube.com/embed/Zjm_B39_xJw", "hls": null, "hds": null}, "title": "父女被入境處塞鴉片書 拒關機關警告", "poster": "http://img.youtube.com/vi/Zjm_B39_xJw/0.jpg", "channel": "udnnews"};
            '''

# Generated at 2022-06-12 18:39:38.152275
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:47.418705
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # protocol-relative URL
    UDNEmbedIE._VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    UDNEmbedIE.IE_DESC = 'UDN'
    ie = UDNEmbedIE('http://video.udn.com/play/news/303776')
    assert ie.IE_NAME == 'UDN'
    assert ie.IE_DESC == 'UDN'
    assert ie._VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'


# Generated at 2022-06-12 18:40:00.411173
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn.IE_NAME == "udn"
    assert udn.IE_DESC == "聯合影音"
    assert udn.IE_CERT == "http://video.udn.com/certificate.html"
    assert udn._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:06.541053
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE"""

    # Get object of class UDNEmbedIE
    udnEmbedIE = UDNEmbedIE()

    # Get object of class RegexNotFoundError
    from ..extractor import RegexNotFoundError

    # Test for the error case
    with pytest.raises(RegexNotFoundError):
        # 'options_str' not found in webpage
        udnEmbedIE._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:40:07.969340
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except Exception as e:
        raise e


# Generated at 2022-06-12 18:40:15.036558
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.IE_NAME == 'udn'
    assert IE.IE_DESC == '聯合影音'
    assert IE._VALID_URL == 'https?://video.udn.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-12 18:40:24.973564
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    __location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
    test_web_page = os.path.join(__location__, "test_UDNEmbedIE_web_page.txt")
    test_web_page_content = open(test_web_page, "r").read()
    assert test_web_page_content is not None
    mock_downloader = Mock()
    mock_downloader.download.return_value = test_web_page_content
    udne = UDNEmbedIE(mock_downloader)

# Generated at 2022-06-12 18:40:34.581953
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    #
    #

# Generated at 2022-06-12 18:40:39.772278
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:46.229620
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:40:49.912787
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    e = UDNEmbedIE()
    e.IE_DESC
    e._PROTOCOL_RELATIVE_VALID_URL
    e._VALID_URL
    e.extract('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:40:52.564657
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    assert(ie.IE_DESC == '聯合影音')

# Generated at 2022-06-12 18:41:09.961039
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test with a valid url
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE.test(url)

    # Test with an invalid url
    url = 'https://video.udn.com/embed/news/'
    UDNEmbedIE.test(url)

# Generated at 2022-06-12 18:41:13.425670
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test constructing an object of class UDNEmbedIE"""
    video_crawler = UDNEmbedIE()
    assert isinstance(video_crawler, InfoExtractor)

# Generated at 2022-06-12 18:41:14.267053
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE.ie_key()

# Generated at 2022-06-12 18:41:23.257515
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    Udn = UDNEmbedIE()
    # For example, this function will return 'protocol relative'
    # for both http://video.udn.com/embed/news/300040 and https://video.udn.com/embed/news/300040
    Udn.IE_NAME = 'protocol relative'
    Udn.IE_DESC = 'protocol relative'
    Udn._VALID_URL = '//video.udn.com/embed/news/300040'
    assert Udn.suitable('http://video.udn.com/embed/news/300040')
    assert Udn.suitable('https://video.udn.com/embed/news/300040')
    assert not Udn.suitable('http://video.udn.com/embed/news/300040?foo=')

# Generated at 2022-06-12 18:41:34.585790
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # Constructor of class UDNEmbedIE
    udn_embed_ie = UDNEmbedIE()

    # Unit test for method _real_extract
    real_extract_result = udn_embed_ie._real_extract('http://video.udn.com/embed/news/300040')
    
    # Set test data.
    test_real_extract_result = {}
    test_real_extract_result['id'] = '300040'
    test_real_extract_result['title'] = '生物老師男變女 全校挺"做自己"'

    # Unit test for id.
    assert real_extract_result['id'] == test_real_extract_result['id'], 'Download id is error!'

# Generated at 2022-06-12 18:41:38.985231
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE()
    assert type(a) == UDNEmbedIE
    assert a.ie_key() == 'UDNEmbed'
    assert a.ie_desc() == '聯合影音'

# Generated at 2022-06-12 18:41:44.280306
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-12 18:41:49.582780
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:41:50.467242
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-12 18:41:55.377895
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    if sys.version_info.major == 2:
        url = 'https://video.udn.com/play/news/303776'
        ie = UDNEmbedIE()

# Generated at 2022-06-12 18:42:25.551668
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Constructor of class class UDNEmbedIE
    u = UDNEmbedIE()
    # Try to extract media ID from URL
    assert(u.media_id('https://video.udn.com/embed/news/300040') == '300040')

test_UDNEmbedIE()

# Generated at 2022-06-12 18:42:28.289221
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import make_extractor
    UDNEmbedIE.__name__ = 'UDNEmbedIE'
    ie = make_extractor(UDNEmbedIE)()
    # An assert that just check the constructor of class UDNEmbedIE not raise any error
    assert ie

# Generated at 2022-06-12 18:42:29.444366
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # TODO
    pass

# Generated at 2022-06-12 18:42:39.029623
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == ie._PROTOCOL_RELATIVE_VALID_URL if ie.IE_DESC == '聯合影音' else 'https:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音' or ie.IE_DESC == '聯合新聞網影音'

# Generated at 2022-06-12 18:42:40.089551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print(ie)

# Generated at 2022-06-12 18:42:49.986593
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    exp_output = '正義聯盟和石像鬼遭“行動”\u3000製作商暫時停止《英雄聯盟》亞洲區伺服器維護',
    URL = 'https://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE()
    output = obj._real_extract(URL)
    print(output)
    assert output['title'] == exp_output, 'Expected "%s" as title, but got "%s"' % (exp_output, output['title'])


# Generated at 2022-06-12 18:42:53.965786
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-12 18:42:59.095548
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    # testing the protocal relative url and valid url
    assert re.search(udne._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.search(udne._VALID_URL, '//video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:43:03.721920
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert(IE.IE_NAME == 'udn')
    assert(IE.IE_DESC == '聯合影音')
    assert(IE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')


# Generated at 2022-06-12 18:43:08.498566
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(ie._TESTS) == 3

# Generated at 2022-06-12 18:44:21.643351
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:23.612663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

# Generated at 2022-06-12 18:44:33.497384
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('===== test_UDNEmbedIE =====')
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:44:40.394290
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        test = UDNEmbedIE("http://video.udn.com/embed/news/300040");
        assert test.IE_DESC == '聯合影音'
        assert test._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
        return True;
    except IOError:
        print("Error: cannot perform assert.")
        return False


# Generated at 2022-06-12 18:44:44.973180
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.name == 'UDNEmbed'
    assert u.IE_DESC == '聯合影音'
    assert u._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:51.902239
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    def test_match():
        match_tests = [
            ('http://video.udn.com/embed/news/300040', '300040'),
            ('http://video.udn.com/play/news/300040', '300040'),
            ('https://video.udn.com/embed/news/300040', '300040'),
            ('https://video.udn.com/play/news/300040', '300040'),
            ('//video.udn.com/embed/news/300040', '300040'),
            ('//video.udn.com/play/news/300040', '300040'),
        ]
        for url, video_id in match_tests:
            if UDNEmbedIE._match_id(url) != video_id:
                print('URL: %s' % url)
               

# Generated at 2022-06-12 18:44:53.628412
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:44:56.997542
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    url = 'http://video.udn.com/embed/news/300040'

    UDNEmbedIE(
        UDNEmbedIE.ie_key(),
        url
    )

# Generated at 2022-06-12 18:44:59.501134
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE()
    print(udnIE)
    print(udnIE.IE_DESC)



# Generated at 2022-06-12 18:45:00.413711
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor_test(UDNEmbedIE)

# Generated at 2022-06-12 18:47:36.979716
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    then = UDNEmbedIE()
    assert then is not None


# Generated at 2022-06-12 18:47:38.492619
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor of class UDNEmbedIE
    #     Test __init__ and _real_extract
    UDNEmbedIE(None)

# Generated at 2022-06-12 18:47:41.726100
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = '//video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE(url)
    print(udn_embed._VALID_URL)
    print(udn_embed._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-12 18:47:46.075776
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnie = UDNEmbedIE()
    assert udnie is not None
    assert udnie._VALID_URL == u'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnie._TESTS is not None
    assert len(udnie._TESTS) == 3

# Generated at 2022-06-12 18:47:50.591332
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_download import options
    ie = UDNEmbedIE(options)
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:47:51.432832
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne is not None

# Generated at 2022-06-12 18:47:52.195463
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE())

test_UDNEmbedIE()

# Generated at 2022-06-12 18:47:57.559622
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor

    ie = InfoExtractor()
    ie = InfoExtractor.youtube_pl_ie(ie)
    ie = InfoExtractor.YoutubeIE(ie)
    ie = InfoExtractor.UDNEmbedIE(ie)
    assert ie.__class__.__name__ == 'UDNEmbedIE'

# Generated at 2022-06-12 18:48:05.520679
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    e = UDNEmbedIE()
    assert 'UDNEmbedIE' == e.IE_DESC
    assert 'http://video.udn.com/embed/news/300040' == e._PROTOCOL_RELATIVE_VALID_URL
    assert 'https?://video.udn.com/embed/news/300040' == e._VALID_URL
    assert '生物老師男變女 全校挺"做自己"' == e._TESTS[0].get('info_dict').get('title')
    assert '300040' == e._TESTS[0].get('info_dict').get('id')
    assert 'mp4' == e._TESTS[0].get('info_dict').get('ext')

# Generated at 2022-06-12 18:48:08.700630
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #Given
    udn_ie = UDNEmbedIE()
    #Then
    assert udn_ie.ie_key() == 'UDNEmbed'