

# Generated at 2022-06-12 18:38:31.722237
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Not a valid URL to test
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:38:32.931245
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(UDNEmbedIE.ie_key()) is not None


# Generated at 2022-06-12 18:38:34.102921
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-12 18:38:42.574963
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembedie = UDNEmbedIE(None)
    assert udnembedie is not None
    assert udnembedie._PROTOCOL_RELATIVE_VALID_URL == \
        r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnembedie._VALID_URL == \
        r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnembedie.IE_DESC == '聯合影音'



# Generated at 2022-06-12 18:38:44.919347
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE.IE_DESC == '聯合影音')

# Generated at 2022-06-12 18:38:45.925924
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:38:52.503352
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u._extract_url('http://video.udn.com/embed/news/300040') == '300040'
    assert u._extract_url('https://video.udn.com/embed/news/300040') == '300040'
    assert u._extract_url('//video.udn.com/play/news/300040') == '300040'
    assert not u._extract_url('http://video.udn.com/news/300040')

# Generated at 2022-06-12 18:39:03.986573
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-12 18:39:07.410638
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:12.401938
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL is not None)
    assert(UDNEmbedIE._VALID_URL is not None)
    assert(UDNEmbedIE._TESTS is not None)

# Generated at 2022-06-12 18:39:22.145629
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE(url)
    assert obj.IE_NAME == 'udn_embed'
    assert obj.url == url

# Generated at 2022-06-12 18:39:24.699723
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    start = UDNEmbedIE()
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.startswith('//')
    UDNEmbedIE._VALID_URL.startswith('https?:')

# Generated at 2022-06-12 18:39:27.592638
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert list(ie._PROTOCOL_RELATIVE_VALID_URL) == '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:39:30.586413
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert '聯合影音' == ie.IE_DESC

# Generated at 2022-06-12 18:39:42.892676
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnei._VALID_URL == r'https?:' + udnei._PROTOCOL_RELATIVE_VALID_URL
    assert udnei._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udnei._TESTS[0]['info_dict']['id'] == '300040'
    assert udnei._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:39:49.611859
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Construct an instance of UDNEmbedIE and test the constructor
    udn = UDNEmbedIE()
    assert(udn.IE_NAME == 'UDNEmbed')
    assert(udn.IE_DESC == '聯合影音')
    assert(udn._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udn._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?P<id>\d+)')
    assert(udn._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    # Construct an instance of InfoExtractor
    ie = InfoExt

# Generated at 2022-06-12 18:39:55.506886
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_instance = UDNEmbedIE()
    assert test_instance._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_instance._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_instance.IE_NAME == 'udn.embed'
    assert test_instance.IE_DESC == '聯合影音'
    assert test_instance._TESTS[0].get('url') == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:40:05.197884
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    def test_constructor(url):
        class Test(UDNEmbedIE):
            IE_NAME = 'udn'
            IE_DESC = 'Dummy'
            _VALID_URL = r'.*'
        t = Test()
        assert t._match_id(url) == '300040'
    yield test_constructor, 'http://video.udn.com/embed/news/300040'
    yield test_constructor, 'https://video.udn.com/embed/news/300040'
    yield test_constructor, 'http://video.udn.com/play/news/300040'

# Generated at 2022-06-12 18:40:07.341688
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_obj = UDNEmbedIE()
    video_id = ie_obj._match_id('http://video.udn.com/embed/news/300040')
    assert video_id == '300040'

# Generated at 2022-06-12 18:40:08.278156
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(InfoExtractor())


# Generated at 2022-06-12 18:40:31.517779
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_test = UDNEmbedIE()
    url_test = 'http://video.udn.com/embed/news/300040'
    video_id_test = ie_test._match_id(url_test)
    page_test = ie_test._download_webpage(url_test, video_id_test)
    options_str_test = ie_test._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', page_test, 'options')
    trans_options_str_test = js_to_json(options_str_test)
    options_test = ie_test._parse_json(trans_options_str_test, 'options', fatal=False) or {}
    video_urls_test = options_test['video']
    title_

# Generated at 2022-06-12 18:40:44.143164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_video = UDNEmbedIE(None)
    assert udn_video._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_video._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_video._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn_video._TESTS[0]['info_dict']['id'] == '300040'
    assert udn_video._TESTS[0]['info_dict']['ext'] == 'mp4'
   

# Generated at 2022-06-12 18:40:49.327058
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for constructor of class UDNEmbedIE."""
    tester = UDNEmbedIE()
    assert tester.IE_DESC.find('聯合影音') != -1, 'IE_DESC is not correct.'
    assert tester.__name__.find('UDNEmbed') != -1, '__name__ is not correct.'

# Generated at 2022-06-12 18:40:51.524020
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Unit test for constructor of class UDNEmbedIE
    q = UDNEmbedIE(None)

# Generated at 2022-06-12 18:40:57.636332
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    obj = UDNEmbedIE()
    assert (obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert (obj._VALID_URL == r'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-12 18:40:58.946711
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()



# Generated at 2022-06-12 18:41:05.240097
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    theUDNEmbedIE = UDNEmbedIE()
    theUDNEmbedIE.match = lambda x: UDNEmbedIE._VALID_URL, None
    result = theUDNEmbedIE._real_extract(url)
    assert result['id'] == '300040'
    assert result['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-12 18:41:07.795518
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.ie_key())

# Generated at 2022-06-12 18:41:10.005966
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.create_ie(UDNEmbedIE.ie_key()))

# Generated at 2022-06-12 18:41:17.924400
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        int_or_none,
        js_to_json,
    )
    from ..compat import compat_urlparse
    assert InfoExtractor.ie_key('UdnEmbed') == 'UdnEmbed'
    # assert InfoExtractor.ie_key(UdnEmbedIE) == 'UdnEmbed'

    page = '''
    var options = {
        poster: 'poster.jpg',
        title: 'title',
        video: {
            m3u8: 'm3u8/url.m3u8',
            mp4: 'mp4/url.mp4'
        }
    };
    '''

# Generated at 2022-06-12 18:41:43.275315
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:41:47.234618
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    try:
        obj.udn
    except:
        return 'Fail'
    else:
        return 'Pass'

# Generated at 2022-06-12 18:41:53.707472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()

    # Check the protocol relative URL
    proto_relative_url_pattern = re.compile(udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL)
    assert proto_relative_url_pattern.match('//video.udn.com/embed/news/300040') is not None

    # Check the URL
    valid_url_pattern = re.compile(udn_embed_ie._VALID_URL)
    assert valid_url_pattern.match('https://video.udn.com/embed/news/300040') is not None

# Generated at 2022-06-12 18:41:56.529291
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Check if the class constructor works.
    """
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'

# Generated at 2022-06-12 18:42:06.018848
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE(CompatRegexpPattern, InfoExtractor, SearchInfoExtractor, SearchInfoExtractor.extract)(
        compat_urllib_parse_urlparse, compat_urllib_request_Request, compat_urllib_request_urlopen, downloader_http,
        InfoExtractor, SearchInfoExtractor, compat_urllib_parse_urlencode, 'http://udn.com/')
    assert class_UDNEmbedIE == UDNEmbedIE, 'When initializing class UDNEmbedIE, unexpected result occurs'

# Generated at 2022-06-12 18:42:12.297663
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_ie = UDNEmbedIE()
    assert(udn_ie._match_id(url) == '300040')
    udn_ie = UDNEmbedIE({})
    assert(udn_ie._match_id(url) == '300040')

# Generated at 2022-06-12 18:42:26.293550
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    result = UDNEmbedIE()
    assert result.ie_key() == 'UDNEmbed'
    assert result.ie_desc() == '聯合影音'
    assert result.valid_url == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:30.068626
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    _PROTOCOL_RELATIVE_VALID_URL = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert re.match(_PROTOCOL_RELATIVE_VALID_URL, url)
    _VALID_URL = UDNEmbedIE._VALID_URL
    assert not re.match(_VALID_URL, url)

# Generated at 2022-06-12 18:42:43.311427
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:49.624338
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE._VALID_URL == IE.VALID_URL
    assert IE._PROTOCOL_RELATIVE_VALID_URL == IE.PROTOCOL_RELATIVE_VALID_URL
    assert IE._TESTS == IE.TESTS
    assert IE._IE_DESC == IE.IE_DESC
    assert IE._NETRC_MACHINE == IE.NETRC_MACHINE
    assert IE._GEO_COUNTRIES == IE.GEO_COUNTRIES


# Generated at 2022-06-12 18:43:54.877979
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()

    assert '300040' == udn._match_id('http://video.udn.com/embed/news/300040')
    assert '300040' == udn._match_id('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:43:56.069226
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:43:56.879242
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:43:59.763612
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE(None)
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL
    assert udn_embed_ie._VALID_URL
    assert udn_embed_ie._TESTS

# Generated at 2022-06-12 18:44:00.520757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)


# Generated at 2022-06-12 18:44:04.743512
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    expected_pattern = r'http://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == expected_pattern
    expected_pattern = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == expected_pattern



# Generated at 2022-06-12 18:44:18.434209
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    # Test for instance attributes
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:44:24.038568
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    # for each test
    for test in UDNEmbedIE._TESTS:
        url = test['url']
        expected_id = test.get('info_dict', {}).get('id')
        assert(expected_id==instance._match_id(url))

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:44:26.705752
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    m = re.compile(udne._PROTOCOL_RELATIVE_VALID_URL).search('//video.udn.com/embed/news/300040')
    print (m.groupdict()['id'])

# Generated at 2022-06-12 18:44:27.849806
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:46:57.576922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_url = 'http://video.udn.com/embed/news/300040'
    ie._match_id(test_url)
    ie._download_webpage(test_url, '300040')
    ie._real_extract(test_url)

# Generated at 2022-06-12 18:47:11.672279
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ''' Test constructor of class UDNEmbedIE
    '''
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:47:17.411313
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei._PROTOCOL_RELATIVE_VALID_URL.split('://')[0] == '', 'test the protocol relative valid url'
    assert udnei._VALID_URL == udnei._VALID_URL.split(':')[0] + ':' + udnei._PROTOCOL_RELATIVE_VALID_URL, 'test the valid url'

# Generated at 2022-06-12 18:47:20.538780
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    __import__('sys').modules['urllib2'] = __import__('urllib3')
    __import__('sys').modules['urlparse'] = __import__('urllib3')
    import pytest
    with pytest.raises(AttributeError):
        UDNEmbedIE()

# Generated at 2022-06-12 18:47:23.679297
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie_udn = UDNEmbedIE(url)
    assert ie_udn.ie_key() == 'UDNEmbed'
    assert ie_udn.url  == url
    assert ie_udn.video_id == '300040'

# Generated at 2022-06-12 18:47:27.307939
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:47:32.776029
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS

# Generated at 2022-06-12 18:47:36.527138
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.ie_key() == 'UDNEmbed'
    assert udn_ie.ie_desc() == '聯合影音'
    for url in udn_ie._TESTS:
        assert udn_ie.suitable(url['url'])

# Generated at 2022-06-12 18:47:42.113735
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_NAME == 'video.udn.com'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    udn_embed_ie = UDNEmbedIE(UDNEmbedIE.ie_key())
    assert udn_embed_ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-12 18:47:47.601407
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    regex = '%s' % ie._PROTOCOL_RELATIVE_VALID_URL
    assert re.search(regex, '//video.udn.com/embed/news/300040')
    assert re.search(regex, '//video.udn.com/play/news/300040')
    assert re.search(regex, 'https://video.udn.com/embed/news/300040')
    assert re.search(regex, 'http://video.udn.com/play/news/300040')
    assert re.search(regex, '//www.youtube.com/embed/C0DPdy98e4c')
    assert not re.search(regex, '//video.udn.com/embed/news/')