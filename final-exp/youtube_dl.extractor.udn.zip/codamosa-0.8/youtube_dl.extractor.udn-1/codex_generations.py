

# Generated at 2022-06-12 18:38:33.628592
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    config = {
        'videourl': 'https://video.udn.com/embed/news/300040',
        'url': 'https://video.udn.com/embed/news/300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
        'id': '300040',
        '_type': 'url',
    }
    ie_result = UDNEmbedIE().extract(config)
    assert ie_result['id'] == config['id']

# Generated at 2022-06-12 18:38:40.685134
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # if in current file, dirname == __name__, else dirname == parent dir
    assert(udn_embed_ie.dirname == __name__)
    # if in current file, filename == __file__, else filename == filename
    assert(udn_embed_ie.filename == __file__)
    assert(udn_embed_ie.ie_key == 'UDNEmbed')
    assert(udn_embed_ie.ie_desc == u'聯合影音')

# Generated at 2022-06-12 18:38:47.043340
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._VALID_URL == r'https?:' + IE._PROTOCOL_RELATIVE_VALID_URL
    assert IE.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:38:51.892648
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("test_UDNEmbedIE")
    url = 'http://video.udn.com/embed/news/300040'
    u = UDNEmbedIE()
    u.IE_NAME = 'UDNEmbedIE'
    ie = u.suitable(url)
    assert ie is not None
    print(ie)



# Generated at 2022-06-12 18:38:58.348849
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    class UnitTesting(unittest.TestCase):
        def test_constructor(self):
            self.assertTrue(UDNEmbedIE())
    unittest.main()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:38:59.783913
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass



# Generated at 2022-06-12 18:39:14.629867
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for UDNEmbedIE constructor"""
    url = 'http://video.udn.com/embed/news/300040'
    try:
        UDNEmbedIE(UDNEmbedIE.ie_key())
        assert True
    except AssertionError:
        assert False

    obj = InfoExtractor.gen_extractor(url)()
    assert obj.ie_key() == 'UDNEmbed'
    assert obj.suitable(url)
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == 'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:39:15.496447
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    return UDNEmbedIE()

# Generated at 2022-06-12 18:39:19.863162
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed = UDNEmbedIE()
    re_match = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert re_match.match(udn_embed._PROTOCOL_RELATIVE_VALID_URL)
    assert not re_match.match(UDNEmbedIE._VALID_URL)

# Generated at 2022-06-12 18:39:24.735134
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie.ie_key() == 'UDNVideo'

# Generated at 2022-06-12 18:39:35.607798
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:39:45.176274
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    url = 'https://video.udn.com/embed/news/' + video_id
    info_dict = {
        'id': video_id,
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }
    params = {
        'skip_download': True,
    }
    expected_warnings = ['Failed to parse JSON Expecting value']
    assert UDNEmbedIE()._real_extract(url, info_dict, params, expected_warnings) == info_dict

# Generated at 2022-06-12 18:39:46.413709
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-12 18:39:55.498427
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_DESC == '聯合影音'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:40:00.409914
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:40:03.925472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_IE = UDNEmbedIE()
    test_url = 'https://video.udn.com/embed/news/300040'
    assert udn_embed_IE._match_id(test_url) == '300040'

# Generated at 2022-06-12 18:40:09.928985
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    cls = UDNEmbedIE
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL
    assert UDNEmbedIE._TESTS
    assert cls._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert cls._VALID_URL == r'https?:' + cls._PROTOCOL_RELATIVE_VALID_URL
    assert cls._TESTS
    assert type(cls._TESTS) == list

# Generated at 2022-06-12 18:40:15.049714
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040', {})
    assert ie.IE_NAME == 'video.udn.com'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-12 18:40:19.124570
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    module = __import__('youtube_dl.extractor.udn', fromlist=['UDNEmbedIE'])
    assert module.UDNEmbedIE('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:40:21.003472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie != None

# Generated at 2022-06-12 18:40:45.041320
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-12 18:40:54.262372
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert (ie.IE_NAME == 'UDNEmbed')
    assert (ie.IE_DESC == '聯合影音')
    assert (ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert (ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    info_dict = ie.extract(url)
    assert(info_dict['id'] == '300040')

# Generated at 2022-06-12 18:40:59.786087
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test URL
    url = 'https://video.udn.com/embed/news/300040'
    # Instantiate an instance of class InfoExtractor
    ie = InfoExtractor()
    # Get an instance of class IE by passing 'url' to method suitable
    ie_instance = ie.suitable(url)
    # Instantiate an instance of class UDNEmbedIE
    # by using constructor of class IE
    udn_embed_ie_instance = ie_instance(url)
    # Check type of 'udn_embed_ie_instance'
    assert isinstance(udn_embed_ie_instance, UDNEmbedIE)


# Generated at 2022-06-12 18:41:05.263234
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._TESTS[0]['info_dict']['title']

# Generated at 2022-06-12 18:41:11.223749
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    val = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL == 'https?:' + val
    assert val == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:41:22.116992
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class TestUDNEmbedIE(UDNEmbedIE):
        url = 'http://video.udn.com/embed/news/300040'

    # Constructor of class InfoExtractor
    obj_udnvideo = TestUDNEmbedIE()
    assert obj_udnvideo.ie_key() == 'UDNEmbed'
    assert obj_udnvideo.ie_desc() == '聯合影音'
    assert obj_udnvideo._VALID_URL == r'https?:' + obj_udnvideo._PROTOCOL_RELATIVE_VALID_URL
    assert obj_udnvideo._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:41:24.477754
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test UDNEmbedIE constructor
    UDNEmbedIE('udn_embed')

# Generated at 2022-06-12 18:41:25.506143
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('extractor')

# Generated at 2022-06-12 18:41:31.857511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_NAME == 'udn'
    assert ie.NAME == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:41:40.352760
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    match = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match('//video.udn.com/embed/news/300040')
    url = '//video.udn.com/embed/news/300040'
    m_dict = {'id': '300040'}
    assert match.groupdict() == m_dict, "Groupdict is not match {}".format(m_dict)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:42:10.683140
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    assert udne._match_id(url) == '300040'
    udne._real_extract(url)

# Generated at 2022-06-12 18:42:20.165719
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest

    class UDNEmbedIETest(unittest.TestCase):
        def test_get_url_re(self):
            self.assertRegex(UDNEmbedIE._VALID_URL, '^http')
            self.assertEqual(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL[:2], '//')

    unittest.main()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:42:25.901215
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('https://video.udn.com/play/news/300040') == '300040'
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('http://video.udn.com/play/news/300040') == '300040'


# Generated at 2022-06-12 18:42:29.105430
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == r'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:42:36.618443
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	assert UdnEmbedIE.ie_key() == 'UdnEmbed'
	assert UDNEmbedIE.ie_key() == 'UdnEmbed'

	ie = UdnEmbedIE('')
	assert ie.ie_key() == 'UdnEmbed'
	assert ie.ie_key() == 'UdnEmbed'

# Generated at 2022-06-12 18:42:43.024724
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.url == ('http://video.udn.com/embed/news/300040')
    assert ie.video_id == '300040'
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-12 18:42:51.177601
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # First, create an object of class UDNEmbedIE
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE(url)

    # Test the attribute '_VALID_URL' of class UDNEmbedIE
    assert 'http://video.udn.com/embed/news/300040' in UDNEmbedIE._VALID_URL
    assert 'https://video.udn.com/embed/news/300040' in UDNEmbedIE._VALID_URL
    assert 'http://video.udn.com/play/news/300040' in UDNEmbedIE._VALID_URL
    assert 'https://video.udn.com/play/news/300040' in UDNEmbedIE._VALID_URL

    # Test the

# Generated at 2022-06-12 18:42:55.194866
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == '__main__':
        url = 'http://video.udn.com/embed/news/300040'
        ie = UDNEmbedIE()
        ie.extract(url)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:42:58.356379
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('UDNEmbed',
                    'http://video.udn.com/embed/news/300040',
                    '300040')
    # Test method _real_extract()
    print(ie.extract())

# Generated at 2022-06-12 18:43:00.753983
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    m = re.match(r'^(https?://)?(video\.udn\.com/(?:embed|play)/news/(\d+))$', 'https://video.udn.com/embed/news/300040')
    assert m is not None

# Generated at 2022-06-12 18:44:17.450328
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..compat import unittest

    class TestUDNEmbedIE(unittest.TestCase):
        def test_UDNEmbedIE(self):
            UDNEmbedIE()._real_extract("http://video.udn.com/embed/news/300040")
            UDNEmbedIE()._real_extract("https://video.udn.com/embed/news/300040")
            UDNEmbedIE()._real_extract("https://video.udn.com/play/news/303776")
    unittest.main()



# Generated at 2022-06-12 18:44:20.404362
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'

    # If error occurs, the test will fail
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-12 18:44:24.367859
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = url = 'http://video.udn.com/embed/news/300040'
    list = UDNEmbedIE.suitable(url)
    print(list)



if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:44:28.355905
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    udn_embed_inst = ie
    assert isinstance(udn_embed_inst.ie_key(), str)


# Generated at 2022-06-12 18:44:40.216098
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._T

# Generated at 2022-06-12 18:44:44.526171
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_url = 'http://video.udn.com/embed/news/300040'
    regex_result = re.search(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, video_url)
    print (regex_result.group('id'))

test_UDNEmbedIE()

# Generated at 2022-06-12 18:44:46.286350
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE().to_screen(r'https://video.udn.com/embed/news/300040')


# Generated at 2022-06-12 18:44:52.306014
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.IE_DESC == '聯合影音'
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == r'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    assert len(instance._TESTS) == 3

# Generated at 2022-06-12 18:44:55.274588
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(UDNEmbedIE.ie_key())._real_extract(url)

# Generated at 2022-06-12 18:45:04.940155
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:47:59.124690
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == "聯合影音"
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'



# Generated at 2022-06-12 18:48:06.124586
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # 1. Call without parameters
    if (UDNEmbedIE() == None):
        assert(False)

    # 2. Call with parameters
    url = "https://video.udn.com/embed/news/300040"
    info_dict = {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        }
    params = {
        'skip_download': True,
    }
    expected_warnings = ['Failed to parse JSON Expecting value']
    IE = UDNEmbedIE()
    IE.url = url
    IE.info_dict = info

# Generated at 2022-06-12 18:48:17.436812
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'