

# Generated at 2022-06-12 18:38:34.901068
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    udn_embed_ie = UDNEmbedIE()
    test_url = 'https://video.udn.com/embed/news/300040'

    assert udn_embed_ie._match_id(test_url) == '300040'

    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert udn_embed_ie._VALID_URL == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:38:38.068129
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:38:40.467937
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a_UDNEmbedIE = UDNEmbedIE()
    assert a_UDNEmbedIE != None

# Generated at 2022-06-12 18:38:46.431004
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:38:53.047187
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei.IE_DESC == '聯合影音'
    assert udnei._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnei._VALID_URL == r'https?:' + udnei._PROTOCOL_RELATIVE_VALID_URL
    assert udnei._TESTS

# Generated at 2022-06-12 18:39:00.814125
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_NAME == 'udn-embed'

# Generated at 2022-06-12 18:39:02.345141
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:39:13.589233
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    # test _PROTOCOL_RELATIVE_VALID_URL class attribute
    match = udne._match_id(
        r'//video\.udn\.com/play/news/300040')
    assert match == '300040'
    match = udne._match_id(
        r'video\.udn\.com/play/news/300040')
    assert match is None
    match = udne._match_id(
        r'http://video\.udn\.com/play/news/300040')
    assert match == '300040'

# Generated at 2022-06-12 18:39:20.698378
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # This test is now meaningless since the website has been changed and won't return JSON format.
    # In particular, the website won't return poster, which may not always be correct.
    from ytdl_udn_tv.UDNEmbed import UDNEmbedIE
    udne_ie_factory = UDNEmbedIE()
    udne_ie = udne_ie_factory.ie_key()
    udne_ie_factory.ie_key(udne_ie)
    udne_ie_factory.ie_key()

# Generated at 2022-06-12 18:39:28.500891
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/300040'
    video_info = ie.extract(url)
    assert video_info['id'] == '300040'
    assert video_info['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-12 18:39:44.553026
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # if raise error, the test case will fail
    try:
        ie.get_urls()
    except Exception:
        print("Got an error: can't instantiate UDNEmbedIE")

# Generated at 2022-06-12 18:39:56.577727
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()


# The following tests are commented out, because they take too long
# and add no value to unit testing. Also, muting them is a bit of a pain
# because of the use of class variable _PROTOCOL_RELATIVE_VALID_URL.

# Test for embedded youtube video
# TESTS.append(({
#     'url': 'http://video.udn.com/embed/news/300040',
#     'md5': 'e8f0738a0ea9df912b9f1f2310a86f66',
#     'info_dict': {
#         'id': '9Y4y-4Uxg70',
#         'ext': 'mp4',
#         'title': '生物老師男變女

# Generated at 2022-06-12 18:40:06.905633
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE()
    # UDNEmbedIE.__init__
    assert udnIE.IE_NAME == 'Udn'
    assert udnIE.IE_DESC == '聯合影音'
    assert udnIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnIE.IE_NAME.lower() == udnIE.ie_key()

# Generated at 2022-06-12 18:40:14.286910
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Testing class UDNEmbedIE")

    test_obj = UDNEmbedIE()

    assert test_obj.IE_DESC == '聯合影音'
    assert test_obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj._VALID_URL == r'https?:' + test_obj._PROTOCOL_RELATIVE_VALID_URL
    assert test_obj._TESTS[0].get('url') == 'http://video.udn.com/embed/news/300040'
    assert test_obj._TESTS[0].get('info_dict').get('id') == '300040'
    assert test_obj._TES

# Generated at 2022-06-12 18:40:19.732567
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UDNEmbed'
    assert UDNEmbedIE().match()
    assert UDNEmbedIE()._VALID_URL
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE().IE_DESC
    assert UDNEmbedIE()._TESTS

# Generated at 2022-06-12 18:40:24.748002
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    aIE = UDNEmbedIE()
    assert aIE.IE_NAME == 'udn'
    assert aIE.IE_DESC == '聯合影音'
    assert isinstance(aIE._VALID_URL, str)

# Generated at 2022-06-12 18:40:30.621937
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:40:38.041838
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE()
    assert udnIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnIE._VALID_URL == 'https?:' + udnIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:40:48.111554
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembed_ie = UDNEmbedIE()
    assert re.match(udnembed_ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.match(udnembed_ie._VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert re.match(udnembed_ie._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert re.match(udnembed_ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/play/news/300040')

# Generated at 2022-06-12 18:40:50.763613
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)
    assert True

# Generated at 2022-06-12 18:41:20.171198
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:41:21.196923
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test if the constructor works
    UDNEmbedIE()

# Generated at 2022-06-12 18:41:25.047853
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert info_extractor.IE_DESC == '聯合影音'


# Generated at 2022-06-12 18:41:35.498682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.ie_key() == 'udn'
    assert udne.ie_desc() == '聯合影音'
    assert udne.ie_info_dict() == None
    url_info = udne.url_result(video_url='ter', video_id='ter', video_title='ter')
    assert url_info.video_url() == 'ter'
    assert url_info.video_id() == 'ter'
    assert url_info.video_title() == 'ter'
    assert url_info.video_description() == None
    assert url_info.video_thumbnail() == None
    assert url_info.video_duration() == None
    assert url_info.video_webpage_url() == None

# Generated at 2022-06-12 18:41:37.622583
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()
    UDNEmbedIE()._real_extract(Url)

# Generated at 2022-06-12 18:41:45.393305
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    pattern = ie._VALID_URL
    # Valid URL:
    assert re.match(pattern, 'http://video.udn.com/embed/news/300040')
    assert re.match(pattern, 'https://video.udn.com/embed/news/300040')
    # Invalid URL:
    assert not re.match(pattern, 'http://video.udn.com/news/300040')
    assert not re.match(pattern, 'http://video.udn.com/embed/news/300040/')
    assert not re.match(pattern, 'http://video.udn.com/embed/news/300040#x')

# Generated at 2022-06-12 18:41:54.529408
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE()
    assert a._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert a._VALID_URL == r'https?:' + a._PROTOCOL_RELATIVE_VALID_URL
    assert a._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert a._TESTS[0]['info_dict']['id'] == '300040'
    assert a._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:41:57.844141
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    out = UDNEmbedIE()
    out.url = "http://video.udn.com/embed/news/300040"
    out._real_extract()

# Generated at 2022-06-12 18:41:58.407912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    assert inst

# Generated at 2022-06-12 18:42:00.715262
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(UDNEmbedIE.ie_key())._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-12 18:43:03.049778
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:43:03.933192
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-12 18:43:10.179884
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_UDNEmbedIE = UDNEmbedIE()
    url_UDNEmbedIE.IE_DESC = '聯合影音'
    url_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    url_UDNEmbedIE._VALID_URL = r'https?:' + url_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:43:17.354905
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #url = "https://video.udn.com/embed/news/300040"
    #url = "https://video.udn.com/play/news/303776"
    url = "https://video.udn.com/play/news/304038"
    UDNEmbedIE._match_id = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.match
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-12 18:43:22.513345
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:43:30.197270
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    r = UDNEmbedIE(None)
    r._match_id(url)
    r._real_extract(url)
    r._real_initialize()
    options = {
        "video": {"hls": "", "hds": "", "mp4": "http://video.udn.com/api/vod/get/video_id/303776/video_url/320/index.m3u8", "youtube": ""},
        "poster": "",
        "title": "拆遷族山海關賣房資格曝光"
    }

# Generated at 2022-06-12 18:43:34.839664
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for _, test_strings in UDNEmbedIE._TESTS:
        url = ''
        for test_string in test_strings:
            if 'http' == test_string[:4]:
                url = test_string
                break
        if url:
            break
    if url:
        IE = UDNEmbedIE()
        IE.extract(url)

# Generated at 2022-06-12 18:43:35.880426
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:43:40.926612
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test protocol-relative
    assert(re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')) is not None
    assert(re.match(UDNEmbedIE._VALID_URL, 'http://video.udn.com/embed/news/300040')) is not None
    assert(re.match(UDNEmbedIE._VALID_URL, 'https://video.udn.com/embed/news/300040')) is not None

# Generated at 2022-06-12 18:43:47.252053
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME == 'udn'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:54.180772
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test for creating instance of class UDNEmbedIE
    test_instance = UDNEmbedIE()
    assert isinstance(test_instance, UDNEmbedIE)

# Generated at 2022-06-12 18:44:59.411781
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE()._VALID_URL == r'https?:' + UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL



# Generated at 2022-06-12 18:45:06.895310
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    expected = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': 're:^https?://.*\.jpg$'
    }
    # run test
    result = ie._real_extract(url)
    print("result = ===> \n", result)
    print("expected ====> \n", expected)
    assert result['id'] == expected['id']

# Generated at 2022-06-12 18:45:14.371115
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    
    ydl = YoutubeDL({"verbose": True, "forceurl": True, "forcetitle": True, "simulate": True})
    
    # For unit test, simulate the download of https://video.udn.com/play/news/303776
    result = ydl.extract_info("https://video.udn.com/play/news/303776", download = False)

    assert result['id'] == '303776'
    assert result['title'] == '美聯儲主席：美國經濟仍須小心'
    assert result['ext'] == 'mp4'

    # m3u8 download

# Generated at 2022-06-12 18:45:15.805701
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbed' == UDNEmbedIE().IE_NAME


# Generated at 2022-06-12 18:45:18.023426
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    ie.extract('http://video.udn.com/embed/news/300040')



# Generated at 2022-06-12 18:45:21.139866
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE('https://video.udn.com/embed/news/300040')
        UDNEmbedIE('https://video.udn.com/play/news/300040')
    except TypeError:
        assert False

# Generated at 2022-06-12 18:45:21.781271
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:45:27.103563
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	test_obj = UDNEmbedIE()
	str_url = "http://video.udn.com/embed/news/300040"
	assert str_url == test_obj._real_extract("http://video.udn.com/embed/news/300040")[0]["url"]
	assert "http://video.udn.com/embed/news/300040" == test_obj._real_extract("http://video.udn.com/embed/news/300040")[0]["thumbnail"]
	assert "聯合影音" == test_obj._real_extract("http://video.udn.com/embed/news/300040")[0]["ext"]

# Generated at 2022-06-12 18:45:28.823249
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-12 18:48:17.325884
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()
    UDNEmbedIE('UDNEmbed', True)

# Generated at 2022-06-12 18:48:25.755057
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL