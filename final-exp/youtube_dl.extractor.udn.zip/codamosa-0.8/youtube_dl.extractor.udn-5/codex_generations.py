

# Generated at 2022-06-12 18:38:36.645872
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(UDNEmbedIE._downloader)._real_initialize()
    info = UDNEmbedIE(UDNEmbedIE._downloader)._real_extract(url)
    assert info['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-12 18:38:48.188607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    '''
    Test UDNEmbedIE construct method
    '''
    test_cases = [
        {
            "url": 'https://video.udn.com/embed/news/300040',
            "expected_id": '300040',
        },
        {
            # From https://video.udn.com/news/303776
            "url": 'https://video.udn.com/play/news/303776',
            "expected_id": '303776',
        }
    ]
    for test_case in test_cases:
        udnEmbed = UDNEmbedIE(test_case["url"])
        assert test_case["expected_id"] == udnEmbed._match_id(test_case["url"])

# Generated at 2022-06-12 18:38:52.844657
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("http://video.udn.com/embed/news/300040")
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:38:58.914818
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    _match_id_result_1 = udnei._match_id('//video.udn.com/embed/news/300040')
    print('_match_id_result_1 = ' + _match_id_result_1)

test_UDNEmbedIE()

# Generated at 2022-06-12 18:39:00.465207
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-12 18:39:04.098912
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    UDNEmbedIE(url)

# Generated at 2022-06-12 18:39:04.890659
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:39:05.373511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	pass

# Generated at 2022-06-12 18:39:18.010616
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_udn_embed = UDNEmbedIE()
    assert ie_udn_embed.ie_key() == 'UDNEmbed'
    assert ie_udn_embed.ie_desc() == '聯合影音'
    assert ie_udn_embed.IE_DESC == '聯合影音'
    assert ie_udn_embed._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:28.114856
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    START_URL = 'https://video.udn.com/embed/news/300040'
    VIDEO_ID = '300040'
    CHECK_VIDEO_ID = '300040'

    def _test_constructor(assert_equal, url, expected_class, target_id=None, expected_id=None, expected_video=None):
        target_obj = expected_class.suitable(url)
        assert_equal(target_obj is not None, True)
        assert_equal(target_obj.ie_key(), expected_class.ie_key())
        if target_id is not None:
            assert_equal(target_obj._match_id(url), target_id)

# Generated at 2022-06-12 18:39:45.307325
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    ie._extract_m3u8_formats = lambda url, video_id: [{'url': url, 'ext': 'mp4', 'm3u8_id': 'hls'}]
    ie._extract_f4m_formats = lambda url, video_id: [{'url': url, 'ext': 'mp4', 'f4m_id': 'hds'}]
    ie._download_webpage = lambda url, video_id, note: url

    # Test https://www.udn.com/news/story/6309/2280693 https://video.udn.com/embed/news/2280693

# Generated at 2022-06-12 18:39:48.026890
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_utils import create_test_instance
    create_test_instance(UDNEmbedIE)

# Generated at 2022-06-12 18:39:48.707024
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:39:52.820541
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'



# Generated at 2022-06-12 18:39:58.870057
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ins = UDNEmbedIE('UDNEmbedIE', 'https://video.udn.com/play/news/303776', {}, 'default')
    assert ins.name == 'UDNEmbedIE'
    assert ins.suitable('https://video.udn.com/play/news/303776')
    assert ins.IE_NAME == 'udn'

# Generated at 2022-06-12 18:40:00.431522
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	udn_embed_ie = UDNEmbedIE()
	assert isinstance(udn_embed_ie, InfoExtractor)
	

# Generated at 2022-06-12 18:40:02.321278
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_DESC == "聯合影音"

# Generated at 2022-06-12 18:40:06.043595
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the URL that has only one video
    UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
    # Test the URL that has multiple videos
    UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/303776')

# Generated at 2022-06-12 18:40:12.115536
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # For testing on a local environment, fill in these URL
    udn_url = 'https://video.udn.com/play/news/300040'
    # That's the output:
    udn_expected = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }
    print('Checking UDNEmbedIE.')
    ie = UDNEmbedIE()
    udn_actual = ie.extract(udn_url)
    print('extract: %s' % udn_actual)

# Generated at 2022-06-12 18:40:13.269224
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert issubclass(UDNEmbedIE, InfoExtractor)

# Generated at 2022-06-12 18:40:27.125062
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(InfoExtractor())

# Generated at 2022-06-12 18:40:34.258822
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'

    # Test constructor
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.ie_desc() == '聯合影音'
    assert ie.suitable(url)
    assert ie.extract_id(url) == '300040'
    assert ie.working() is True
    assert ie.get_url_regex() == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:36.856757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:40:37.977737
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:40:48.111731
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from .common import FakeYDL
    from .common import ParseError

    assert InfoExtractor.get_info_extractor.__doc__ == '''
        Returns the info extractor class for the given ie_key or None.

        :param ie_key: ie_key of the extractor to return
        :type ie_key: str
        :returns: An info extractor class or None
        :rtype: type
    '''
    assert InfoExtractor.get_info_extractor('youtube') == YoutubeIE
    assert InfoExtractor.get_info_extractor('youtube:channel') == YoutubeIE
    assert InfoExtractor.get_info_extractor('youtube:video:id1 id2 id3') == YoutubeIE
    assert InfoExtractor.get_info_extractor('youtube:video')

# Generated at 2022-06-12 18:40:57.085501
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:58.368771
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)

# Generated at 2022-06-12 18:41:08.258891
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    url = 'http://video.udn.com/embed/news/' + video_id
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.format(id=video_id) == url
    assert UDNEmbedIE._VALID_URL.format(id=video_id) == url
    assert UDNEmbedIE._TESTS[0]['url'] == url
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == video_id
    assert UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:41:13.345857
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert UDNEmbedIE('//video.udn.com/embed/news/300040')
    assert not UDNEmbedIE('https://video.udn.com/news/303776')

# Generated at 2022-06-12 18:41:22.933222
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test when http is used
    initial_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(initial_url, '.')
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._initial_url == initial_url
    assert ie._initial_protocol == 'http'

    # Test when https is used
    initial_url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(initial_url, '.')
    assert ie._initial_url == initial_url
    assert ie._initial_protocol == 'https'

# Generated at 2022-06-12 18:41:53.207724
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE()
    match = udnIE._PROTOCOL_RELATIVE_VALID_URL
    pattern = re.compile(match)
    url = 'http://video.udn.com/embed/news/300040'
    assert pattern.match(url).groupdict()['id'] == '300040'
    url = 'https://video.udn.com/embed/news/300040'
    assert pattern.match(url).groupdict()['id'] == '300040'

# Generated at 2022-06-12 18:42:06.520130
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Given
    url = 'http://video.udn.com/embed/news/300040'
    # When
    udn_embed_ie = UDNEmbedIE()
    # Then
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._match_id(url) == '300040'
    assert udn_embed_ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
   

# Generated at 2022-06-12 18:42:13.421398
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url in ('http://video.udn.com/embed/news/300040',
                'https://video.udn.com/embed/news/300040',
                
                ):
        if url:
            ie = UDNEmbedIE(url)
            assert ie.get_info(url)

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:42:23.866740
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Unit test for constructor of class UDNEmbedIE")
    obj = UDNEmbedIE()
    print("Test _VALID_URL", obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    print("Test _PROTOCOL_RELATIVE_VALID_URL", obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')


# Generated at 2022-06-12 18:42:28.714863
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    info = ie._real_extract('http://video.udn.com/embed/news/300040');
    assert info['id'] == '300040'
    assert info['title'] == '生物老師男變女 全校挺"做自己"'
    assert len(info['formats']) > 0
    assert 'hls' in info['formats'][0]

# Generated at 2022-06-12 18:42:41.469062
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test case 1
    udne = UDNEmbedIE()
    assert udne.IE_NAME == 'udn'
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == r'https?:(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'
    assert udne._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udne._TESTS[0]['info_dict']['id'] == '300040'
    assert udne._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:42:43.609995
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys

# Generated at 2022-06-12 18:42:47.843238
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    def test1():
        test_url = 'http://video.udn.com/embed/news/300040'
        ie = UDNEmbedIE(test_url)
        return ie

    pass_result = True
    try:
        test1()
    except Exception:
        pass_result = False
    assert pass_result

# Generated at 2022-06-12 18:42:58.546953
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._make_valid_url(r'//video.udn.com/embed/news/300040')
    UDNEmbedIE._make_valid_url(r'http://video.udn.com/embed/news/20170301/3993781')
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL
    assert re.search(UDNEmbedIE._VALID_URL, "http://video.udn.com/embed/news/300040")
    assert re.search(UDNEmbedIE._VALID_URL, "http://video.udn.com/embed/news/20170301/3993781")

# Generated at 2022-06-12 18:42:59.754462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 18:44:11.911776
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:44:16.244807
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    regex_id = re.compile(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert regex_id.match(url)

    id_of_url = regex_id.match(url).groupdict()['id']
    assert id_of_url == '300040'

# Generated at 2022-06-12 18:44:22.577876
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()

    assert udneie.IE_DESC == '聯合影音'
    assert udneie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udneie._VALID_URL == r'https?:' + udneie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:44:35.237299
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-12 18:44:42.584444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    url = 'http://video.udn.com/embed/news/300040'
    try:
        UDNEmbedIE(url)
    except Exception as e:
        return False
    return True

# Testing two classes above
if __name__ == "__main__":
    print(test_UDNEmbedIE())

# Generated at 2022-06-12 18:44:45.010941
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = globals()['UDNEmbedIE']

    # check protocol_relative_url
    assert class_._VALID_URL == 'https?:' + class_._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:44:45.809684
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    initialize_class(UDNEmbedIE)

# Generated at 2022-06-12 18:44:52.369185
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:56.251414
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    _ = UDNEmbedIE(url)
    return True

# Unit test
if __name__ == '__main__':
    print(test_UDNEmbedIE())

# Generated at 2022-06-12 18:44:57.582552
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # No exception should be raised
    UDNEmbedIE()

# Generated at 2022-06-12 18:47:39.516462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        udn = UDNEmbedIE()
        print(udn)
    except:
        print('cannot initialize UDNEmbedIE')

# Generated at 2022-06-12 18:47:43.679334
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = r'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    match = ie._PROTOCOL_RELATIVE_VALID_URL_RE.match(url)
    assert match.groupdict()['id'], '300040'

# Generated at 2022-06-12 18:47:50.868137
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    test_reg_url = '//video.udn.com/embed/news/300040'

    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == \
        '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._TESTS
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[2]['url']

# Generated at 2022-06-12 18:47:51.888321
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("http://video.udn.com/embed/news/300040")


# Generated at 2022-06-12 18:48:02.304198
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:48:04.443179
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL is not None)

# Generated at 2022-06-12 18:48:16.879915
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_utils import download_webpage
    from .common import InfoExtractor
    from .compat import compat_urlparse

    page = download_webpage('https://video.udn.com/embed/news/300040',
                            'embed test page')
    video_id = '300040'

# Generated at 2022-06-12 18:48:19.148389
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    assert i._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'