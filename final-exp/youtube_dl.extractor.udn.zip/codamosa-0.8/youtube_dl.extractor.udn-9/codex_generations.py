

# Generated at 2022-06-12 18:38:29.208646
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print('Begin')
    print(ie)
    print('End')


# Generated at 2022-06-12 18:38:33.916600
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj.SUCCESS == True

# Generated at 2022-06-12 18:38:44.663306
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .. import UDNEmbedIE
    class_UDNEmbedIE = UDNEmbedIE()
    assert class_UDNEmbedIE.IE_DESC == '聯合影音'
    assert class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert class_UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:38:45.675284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie

# Generated at 2022-06-12 18:38:51.325056
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    try:
        udne = UDNEmbedIE()
        udne._real_extract(url)
    except:
        # print("UDNEmbedIE failed in its constructor")
        raise
    else:
        # print("UDNEmbedIE suceeded in its constructor")
        pass

# Generated at 2022-06-12 18:38:59.930575
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    video_id = '300040'

    opts = ie._get_options(url)
    assert opts.get('video').get('mp4') == 'http://video.udn.com/video/api/play/%s' % video_id
    assert opts.get('video').get('rtmp') == 'http://video.udn.com/video/api/play/%s' % video_id
    assert opts.get('title') == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-12 18:39:03.693127
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-12 18:39:05.069521
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    return UDNEmbedIE()

# Generated at 2022-06-12 18:39:17.880758
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    url = 'https://video.udn.com/embed/news/300040'
    video_id = udn_embed_ie._match_id(url)
    page = udn_embed_ie._download_webpage(url, video_id)
    options_str = udn_embed_ie._html_search_regex(
            r'var\s+options\s*=\s*([^;]+);', page, 'options')
    trans_options_str = js_to_json(options_str)
    options = udn_embed_ie._parse_json(trans_options_str, 'options', fatal=False) or {}
    video_urls = options['video']
    title = options['title']

# Generated at 2022-06-12 18:39:27.966561
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Test parsing arguments for constructor of class UDNEmbedIE."""
    from ..utils import parse_download_webpage
    from ..compat import compat_urllib_parse_urlparse

    def get_matching_class(url):
        parsed_url = compat_urllib_parse_urlparse(url)
        for ie in parse_download_webpage(url).values():
            if ie.suitable(parsed_url) and ie is not InfoExtractor:
                return ie

    ie = get_matching_class( 'http://video.udn.com/embed/news/300040')
    assert isinstance(ie, UDNEmbedIE)

    ie = get_matching_class('https://video.udn.com/play/news/303776')

# Generated at 2022-06-12 18:39:44.872091
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import ExtractorError
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    if not ie.match(url):
        raise ExtractorError(ie.IE_NAME)
    return ie


# Generated at 2022-06-12 18:39:50.815003
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-12 18:39:59.663317
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS

# Generated at 2022-06-12 18:40:07.978002
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    error_msg = "UDNEmbedIE should be valid from 'http://video.udn.com/embed/news/300040'"
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)', error_msg
    error_msg = "UDNEmbedIE should be valid from 'https://video.udn.com/embed/news/300040'"
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)', error_msg
    error_msg = "UDNEmbedIE should be valid from 'http://video.udn.com/embed/news/300040'"

# Generated at 2022-06-12 18:40:12.278486
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_NAME == 'udn'
    # Test the constructor of class UDNEmbedIE
    ie = UDNEmbedIE(UDNEmbedIE.ie_key())
    # Test the result of calling _real_extract(http://video.udn.com/embed/news/300040)
    assert ie._real_extract('http://video.udn.com/embed/news/300040')['id'] == '300040'

# Generated at 2022-06-12 18:40:15.205432
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    extractor = UDNEmbedIE()
    print("extractor: " + str(extractor))
    print("url: " + str(url))

# Generated at 2022-06-12 18:40:18.004521
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:40:19.498037
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for class UDNEmbedIE"""
    assert True

# Generated at 2022-06-12 18:40:31.275805
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    info_dict = ie._real_extract('https://video.udn.com/play/news/300040')
    assert info_dict['title'] == '生物老師男變女 全校挺"做自己"'
    assert info_dict['id'] == '300040'
    assert len(info_dict['formats']) == 2
    m3u8_url = info_dict['formats'][0]['url']
    assert m3u8_url.startswith('http://media.udn.com.edgesuite.net/udn/video/2017/08/02/')
    assert m3u8_url.endswith('.m3u8')
    assert info_dict

# Generated at 2022-06-12 18:40:38.140878
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    ie.extract(url)

    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    ie.extract(url)

# Generated at 2022-06-12 18:40:56.066873
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor test
    """
    from ..youtube_dl import YoutubeDL
    _ = YoutubeDL()
    assert _.get_info_extractor(url='https://video.udn.com/play/news/303776') is not None



# Generated at 2022-06-12 18:41:06.997415
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .. import YoutubeIE
    from ..post_processor.xattrs import XAttrsAdder
    from ..compat import compat_str, compat_urlparse

    ie_obj = UDNEmbedIE()

    # Test whether function _match_id returns the correct result
    assert ie_obj._match_id('http://video.udn.com/embed/news/300040') == '300040'

    # Test whether function _real_extract returns the information of a Youtube video
    url = 'http://video.udn.com/embed/news/300040'
    webpage = ie_obj._download_webpage(url, '300040')

# Generated at 2022-06-12 18:41:19.749889
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    assert udne._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert udne._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert udne._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert udne._match_id('http://video.udn.com/play/news/300040') == '300040'
    assert udne._match_id('https://video.udn.com/play/news/300040') == '300040'
    assert udne._match

# Generated at 2022-06-12 18:41:33.069347
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_url_match = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    valid_url = r'http:' + valid_url_match
    valid_url_with_http = r'http:' + valid_url_match
    non_valid_url = r'https://www.udn.com/'

    assert UDNEmbedIE._VALID_URL == valid_url
    assert UDNEmbedIE._MIN_AGE == 172800
    assert UDNEmbedIE._TESTS[0]['url'] == valid_url_with_http
    assert UDNEmbedIE._TESTS[1]['url'] == valid_url_with_http
    assert UDNEmbedIE._TESTS[2]['url'] == valid_url

    assert UDNEmbedIE.suitable

# Generated at 2022-06-12 18:41:36.363943
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

# Generated at 2022-06-12 18:41:41.409995
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from contextlib import contextmanager
    from sys import version_info
    @contextmanager
    def mock_sys():
        old_version_info = version_info
        version_info = old_version_info._replace(major=2)
        yield
        version_info = old_version_info
    with mock_sys():
        UDNEmbedIE()

# Generated at 2022-06-12 18:41:49.421068
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbed = UDNEmbedIE()
    assert udnEmbed._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert udnEmbed._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert udnEmbed.IE_DESC == "聯合影音"

# Generated at 2022-06-12 18:41:52.643410
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    IE_test = UDNEmbedIE()
    IE_test._match_id(test_url)
    IE_test._real_extract(test_url)

# Generated at 2022-06-12 18:41:55.157200
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u is not None

# Generated at 2022-06-12 18:42:08.169840
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    print(ie)
    print(ie.IE_NAME)
    print(ie.IE_DESC)
    print(ie.info_dict)
    print(ie._VALID_URL)
    print(ie._PROTOCOL_RELATIVE_VALID_URL)
    print(ie._download_webpage('https://video.udn.com/embed/news/300040','300040'))
    print(ie._match_id('https://video.udn.com/embed/news/300040'))
    print(ie._real_extract('https://video.udn.com/embed/news/300040'))

# Generated at 2022-06-12 18:42:45.111444
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url in [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
    ]:
        extractor = UDNEmbedIE()
        assert extractor.suitable(url)
        assert extractor.IE_NAME == "udn"
        assert extractor._VALID_URL == extractor._PROTOCOL_RELATIVE_VALID_URL
        assert "UDNEmbed" in extractor.IE_DESC
        assert extractor._TESTS
        assert extractor._match_id("http://video.udn.com/embed/news/300040") == "300040"
        assert extractor._match_id("https://video.udn.com/embed/news/300040") == "300040"

# Generated at 2022-06-12 18:42:53.442837
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pattern = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert re.match(pattern, '//video.udn.com/embed/news/300040')
    assert re.match(pattern, '//video.udn.com/play/news/300040')
    assert re.match(pattern, '//video.udn.com/0ffff/play/news/300040') is None
    assert re.match(pattern, 'https://video.udn.com/embed/news/300040')
    assert re.match(pattern, 'https://video.udn.com/play/news/300040')
    assert re.match(pattern, 'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:42:56.597159
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    u = UDNEmbedIE()
    assert u.suitable('https://video.udn.com/embed/news/300040')



# Generated at 2022-06-12 18:43:00.808682
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Url is build with _PROTOCOL_RELATIVE_VALID_URL, here we generate a valid url
    url = 'http://' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.split('//')[1]
    UDNEmbedIE(UDNEmbedIE.ie_key())._download_webpage(url, '300040', 'Unit test for constructor of class UDNEmbedIE')

# Generated at 2022-06-12 18:43:02.794266
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udneie = UDNEmbedIE()
    assert udneie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:43:09.568971
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # url = "http://video.udn.com/embed/news/300040"
    url = "https://video.udn.com/embed/news/300040"
    result = UDNEmbedIE()._real_extract(url)
    assert result['id'] == "300040"
    assert result['formats'][0]['url'] == "http://plurimedia.udn.com.tw/video/300040/300040_512.mp4"
    assert result['formats'][0]['format_id'] == "http-mp4"
    assert result['formats'][1]['url'] == "http://plurimedia.udn.com.tw/video/300040/300040_360.mp4"

# Generated at 2022-06-12 18:43:18.545986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    urls = [
        '//video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040'
    ]
    id_head = 'https://video.udn.com/embed/news/'
    for url in urls:
        id = udne._match_id(url)
        assert(id_head + id in url)

    # invalid input
    id = udne._match_id('http://www.g0v.tw/')
    assert(id is None)

# Generated at 2022-06-12 18:43:24.409921
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	test = UDNEmbedIE()
	str = '//video.udn.com/embed/news/300040'
	print(test._PROTOCOL_RELATIVE_VALID_URL)
	print(re.search(test._PROTOCOL_RELATIVE_VALID_URL, str))
	print(test._VALID_URL)
	print(re.search(test._VALID_URL, str))

# Generated at 2022-06-12 18:43:32.584828
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert type(UDNEmbedIE()._VALID_URL) is str
    assert type(UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL) is str
    assert type(UDNEmbedIE()._TESTS) is list
    assert type(UDNEmbedIE().IE_NAME) is str
    assert type(UDNEmbedIE().IE_DESC) is str

# Generated at 2022-06-12 18:43:36.181590
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udni = UDNEmbedIE()
    assert udni._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udni._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udni._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:44:50.029593
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE()
    assert(udnIE.IE_DESC == '聯合影音')
    assert(re.match(udnIE._VALID_URL, 'https://video.udn.com/embed/news/300040'))
    assert(re.match(udnIE._VALID_URL, 'http://video.udn.com/embed/news/300040'))
    assert(not re.match(udnIE._VALID_URL, 'https://video.udn.com/play/news/300040'))
    assert(re.match(udnIE._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040'))

# Generated at 2022-06-12 18:45:00.620211
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == 'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:45:01.837086
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie == type(ie)

# Generated at 2022-06-12 18:45:03.393343
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ins = UDNEmbedIE()
    assert ins._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:45:10.247158
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test constructor of class UDNEmbedIE
    # and all of the attributes would be initialized.
    x = UDNEmbedIE()
    assert x.IE_NAME == 'UDNEmbedIE'
    # assert x.IE_DESC == '聯合影音'
    # assert x.ie_key() == 'UDNEmbed'
    # assert x.ie_key() == 'UDNEmbedIE'
    assert x._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:45:10.663597
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-12 18:45:11.540800
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'udn'

# Generated at 2022-06-12 18:45:20.713002
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert ie._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'


# Generated at 2022-06-12 18:45:27.027579
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:45:28.548744
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://www.udn.com/news/story/7328/3240940')

# Generated at 2022-06-12 18:48:20.988846
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_ie = UDNEmbedIE()
    # Success case
    assert(udne_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    # Fail case
    assert(udne_ie._VALID_URL != r'http://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

