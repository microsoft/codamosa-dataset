

# Generated at 2022-06-12 18:38:36.893309
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # test instance
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # test parse_url_result
    assert ie._extract_url(url=ie._VALID_URL, webpage_url=None, video_id=None, ie=None) == "300040"

# Generated at 2022-06-12 18:38:40.950215
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = globals()['UDNEmbedIE']
    assert class_ is not None
    instance = class_()
    assert instance is not None
    assert hasattr(instance, '_download_webpage')

# Generated at 2022-06-12 18:38:42.382675
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie is not None

# Generated at 2022-06-12 18:38:52.875567
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._VALID_URL == 'https?:' + instance._PROTOCOL_RELATIVE_VALID_URL
    assert instance._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:38:55.214325
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    obj = UDNEmbedIE()
    obj.suitable(url)
    res = obj._real_extract(url)
    print (res)
    assert len(res['formats']) > 0


# Generated at 2022-06-12 18:39:06.064423
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    # Call _real_extract to make sure class is instantiated.
    instance._real_extract('http://video.udn.com/embed/news/300040')
    assert instance._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert instance._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:39:07.919608
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    dummy = UDNEmbedIE(InfoExtractor())

# Generated at 2022-06-12 18:39:20.520935
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    import os
    import urllib.request
    import pycurl
    import io # python2:StringIO python3:io
    import json
    import unittest
    import re

    # add parent directory to sys.path
    sys.path.append(os.path.join('..', '..', '..'))
    
    from youtube_dl.extractor.udn import UDNEmbedIE
    from youtube_dl.utils import fake_http_headers, unescapeHTML
    from youtube_dl.compat import compat_urlparse

    class TestUDNEmbedIE(unittest.TestCase):
        def setUp(self):
            self.udn_embed_ie = UDNEmbedIE({'http_headers': fake_http_headers})
        

# Generated at 2022-06-12 18:39:27.755297
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r = UdnEmbedIE()
    assert r.IE_DESC == '聯合影音'
    assert r._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert r._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert r._TESTS[0]['info_dict'] == {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
    }
    assert r

# Generated at 2022-06-12 18:39:32.063452
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    aUDNEmbedIE = UDNEmbedIE('UDNEmbedIE')
    print(aUDNEmbedIE._VALID_URL)
    print(aUDNEmbedIE._TESTS)


# Generated at 2022-06-12 18:39:44.553010
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[1]['only_matching']
    assert ie._TESTS[2]['only_matching']

# Generated at 2022-06-12 18:39:56.578171
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _CLASS_NAME = 'UDNEmbedIE'
    _CLASS_NAME_SELF = '%s(%s)' % (_CLASS_NAME, 'self')
    _CLASS_IE_DESC = '聯合影音'
    _CLASS_PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:02.503770
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    constructor = globals()['UDNEmbedIE']
    ie = constructor()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:07.017708
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)' and \
    ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL and \
    ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:40:08.466118
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

# Generated at 2022-06-12 18:40:09.147456
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-12 18:40:09.790414
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE({}) is not None

# Generated at 2022-06-12 18:40:14.940053
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE(_download_webpage=None, _parse_json=None)
    assert(a.IE_DESC == '聯合影音')
    assert(a._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(a._VALID_URL == r'https?:' + a._PROTOCOL_RELATIVE_VALID_URL)

    a = UDNEmbedIE(_download_webpage=None, _parse_json=None)
    assert(a._real_extract(_TESTS[0]['url']) == _TESTS[0]['info_dict'])

    # a = UDNEmbedIE(_download_webpage=None

# Generated at 2022-06-12 18:40:27.018241
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-12 18:40:33.004957
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert(udn.IE_DESC == '聯合影音')
    assert(udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(udn._VALID_URL == r'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL)

# Generated at 2022-06-12 18:40:42.748227
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test constructor of UDNEmbedIE
    UDNEmbedIE('http://video.udn.com/embed/news/300040',
               'http://video.udn.com/embed/news/300040')


# Generated at 2022-06-12 18:40:47.747671
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    testURL = 'http://video.udn.com/embed/news/300040'
    print("Testing %s" % testURL)
    videoList = UDNEmbedIE()._real_extract(testURL)
    for video in videoList:
        fullURL = video['url']
        print("Video: %s URL: %s" % (video['id'], fullURL))

# Generated at 2022-06-12 18:40:54.682592
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_obj = UDNEmbedIE()
    assert ie_obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie_obj._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:41:05.365442
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pylint: disable=line-too-long
    constructor_urls = [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        '//video.udn.com/embed/news/300040',
        'http://video.udn.com/play/news/300040',
        'https://video.udn.com/play/news/300040',
        '//video.udn.com/play/news/300040'
    ]
    ie = UDNEmbedIE()
    for url in constructor_urls:
        ie.suitable(url)
        ie.extract(url)

# Generated at 2022-06-12 18:41:13.708041
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == "聯合影音"
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == r'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:41:16.767092
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert isinstance(udn, InfoExtractor) and isinstance(udn, InfoExtractor)

# Generated at 2022-06-12 18:41:24.606154
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import tempfile
    import os
    import subprocess
    path = os.path.dirname(os.path.abspath(__file__))
    fd, out_file = tempfile.mkstemp()
    os.close(fd)
    try:
        command = ['python', '-u', os.path.join(path, 'youtube_dl/__main__.py'),
            '--dump-intermediate-pages', '--verbose', '--write-pages',
            '--write-info-json', '--ignore-errors',
            'http://video.udn.com/embed/news/300040',
            '--output', os.path.join(out_file, '%(id)s.%(ext)s')]
        subprocess.call(command)
    finally:
        import shutil

# Generated at 2022-06-12 18:41:26.369472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'

# Generated at 2022-06-12 18:41:30.083607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url='http://video.udn.com/embed/news/300040'
    info=UDNEmbedIE()._real_extract(url)
    print(info)

# Generated at 2022-06-12 18:41:33.559422
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-12 18:41:49.832124
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert re.match(IE._PROTOCOL_RELATIVE_VALID_URL, "//video.udn.com/embed/news/300040")

# Generated at 2022-06-12 18:41:57.431626
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_NAME == 'udn')
    assert(ie.IE_DESC == '聯合影音')
    assert(ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:42:07.669464
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #url = 'https://video.udn.com/embed/news/300040' # 生物老師男變女 全校挺"做自己"
    url = 'https://video.udn.com/play/news/303776' # 臉書搞笑笑笑！六福村莎士比亞好萊塢故事

# Generated at 2022-06-12 18:42:08.355007
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:42:09.245914
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE == type(UDNEmbedIE()))


# Generated at 2022-06-12 18:42:10.324214
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(dict(_downloader=object(), params=dict(format=''))) is not None

# Generated at 2022-06-12 18:42:11.480387
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()

# Generated at 2022-06-12 18:42:16.179556
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test URL: http://video.udn.com/embed/news/300040
    # Regression test for https://github.com/rg3/youtube-dl/issues/5587
    UDNEmbedIE()._real_extract(
        'http://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:42:19.075819
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Success
    try:
        UDNEmbedIE()
    except:
        assert False
    assert True


# Generated at 2022-06-12 18:42:27.380293
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._valid_url(
        'https://video.udn.com/embed/news/300040')
    assert ie._valid_url(
        'https://video.udn.com/play/news/300040')
    assert ie._valid_url(
        '//video.udn.com/embed/news/300040')
    assert ie._valid_url(
        '//video.udn.com/embed/news/300040/')
    assert ie._valid_url(
        'https://video.udn.com/embed/news/300040/')

# Generated at 2022-06-12 18:42:40.467492
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:42:46.784368
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie.IE_DESC == '聯合影音'


# Generated at 2022-06-12 18:42:48.272223
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj._real_extract("")
    assert(obj)

# Generated at 2022-06-12 18:42:51.352035
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()
    assert class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:59.542713
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?:(?i)//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '(?i)//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0].get('url') == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0].get('info_dict').get('id') == '300040'
    assert ie._T

# Generated at 2022-06-12 18:43:02.310734
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/play/news/300040') == '300040'



# Generated at 2022-06-12 18:43:09.299373
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie.IE_NAME == 'udn'
    assert udn_ie._VALID_URL == 'https?:(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == '(//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+))'
    assert udn_ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert udn_ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-12 18:43:11.215683
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()

# Generated at 2022-06-12 18:43:21.761257
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert UDNEmbedIE._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert UDNEmbed

# Generated at 2022-06-12 18:43:29.592453
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video.udn.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:43:48.555927
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

# Generated at 2022-06-12 18:43:55.842973
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE();
    assert udn.IE_NAME == 'udn_embed'
    assert udn.IE_DESC == '聯合影音'
    assert udn._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert len(udn._TESTS) == 3


# Generated at 2022-06-12 18:43:58.162751
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-12 18:43:59.585554
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()
    assert x.IE_NAME == 'udn.com'

# Generated at 2022-06-12 18:44:00.354840
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():        
    UDNEmbedIE()

# Generated at 2022-06-12 18:44:01.089639
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:44:02.712564
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:44:04.457017
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_ie = UDNEmbedIE()
    assert udne_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:44:07.030877
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("http://video.udn.com/embed/news/300040")
    UDNEmbedIE("//video.udn.com/embed/news/300040")
    UDNEmbedIE("https://video.udn.com/embed/news/300040")

# Generated at 2022-06-12 18:44:11.974081
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:50.811537
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:44:53.812925
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE('UDNEmbedIE', url, None, None)

# Generated at 2022-06-12 18:44:56.829126
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL.startswith('//')
    assert not UDNEmbedIE._VALID_URL.startswith('//')

# Generated at 2022-06-12 18:44:58.560406
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Should not raise an exception
    udn = UDNEmbedIE()


# Generated at 2022-06-12 18:45:01.590470
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:45:02.446856
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:45:03.635909
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Just to test the class constructor
    udn = UDNEmbedIE()

# Generated at 2022-06-12 18:45:12.014480
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import re
    from collections import OrderedDict
    from .common import InfoExtractor

    class UDNEmbedIETest(unittest.TestCase):

        def setUp(self):
            self.ie = UDNEmbedIE()

        def test_UDNEmbedIE_init_common_attributes(self):
            self.assertTrue(hasattr(self.ie, '_VALID_URL'))
            self.assertEqual(self.ie._VALID_URL, r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
            self.assertTrue(hasattr(self.ie, 'IE_NAME'))
            self.assertEqual(self.ie.IE_NAME, 'udn')

# Generated at 2022-06-12 18:45:16.609842
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'

    test_url = 'https://video.udn.com/embed/news/300040'
    video_id = udne._match_id(test_url)
    assert video_id == '300040'

# Generated at 2022-06-12 18:45:17.629018
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-12 18:46:44.695582
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbedIE', 'UDN', '聯合影音')

# Generated at 2022-06-12 18:46:46.141796
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:46:57.291049
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE.UDNEmbedIE()
    assert IE.IE_DESC == '聯合影音'
    assert IE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._VALID_URL == 'https?:' + IE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:46:58.992772
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_obj = UDNEmbedIE()

# Generated at 2022-06-12 18:47:05.542250
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
    UDNEmbedIE()._real_extract('https://video.udn.com/embed/news/300040')
    UDNEmbedIE()._real_extract('https://video.udn.com/play/news/300040')

# Generated at 2022-06-12 18:47:06.347267
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-12 18:47:09.495608
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        udne = UDNEmbedIE()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-12 18:47:15.090764
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None, "", "", "", "")
    print("\n[  OK  ] Done initializing UDNEmbedIE.")
    assert ie._match_id(None) == None, "Fail to match valid url."
    print("[  OK  ] Done matching valid url.")
    assert ie._match_id("") == None, "Fail to match invalid url."
    print("[  OK  ] Done matching invalid url.")
    return 1


# Generated at 2022-06-12 18:47:16.357264
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-12 18:47:19.142553
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('http://video.udn.com/embed/news/300040', {'skip_download':True})