

# Generated at 2022-06-12 18:38:36.790336
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == 'udn'
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._TESTS[0].get('url') == 'http://video.udn.com/embed/news/300040'
    assert udn_embed_ie._TES

# Generated at 2022-06-12 18:38:39.564546
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_test = UDNEmbedIE()
    assert udn_test



# Generated at 2022-06-12 18:38:50.649881
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:39:02.081085
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:02.993052
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:39:07.926082
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        temp = UDNEmbedIE(None)
        print('Successfully instantiated')
    except:
        print('Failed to instantiate')

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:39:20.522134
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-12 18:39:29.281271
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_NAME == 'udn'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:36.647825
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:37.501402
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _udnembed = UDNEmbedIE();
    assert(_udnembed.name == 'udn-embed');

# Generated at 2022-06-12 18:39:49.696379
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj._VALID_URL == 'https?:' + test_obj._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:39:53.997452
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    youtube_url = 'http://video.udn.com/embed/news/300040'
    y = UDNEmbedIE(youtube_url)
    assert y != None

# Generated at 2022-06-12 18:39:56.616714
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Basic test for constructor of class UDNEmbedIE.
    """
    UDNEmbedIE(None, False)

# Generated at 2022-06-12 18:40:06.904429
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_udnembed = UDNEmbedIE()
    re_udnembed = ie_udnembed._PROTOCOL_RELATIVE_VALID_URL
    valid_url = 'http://video.udn.com/embed/news/300040'
    match_id = ie_udnembed._match_id(valid_url)
    assert match_id == '300040'
    valid_url = 'https://video.udn.com/play/news/300040'
    match_id = ie_udnembed._match_id(valid_url)
    assert match_id == '300040'
    assert re.search(re_udnembed, valid_url)
    assert not re.search(re_udnembed, 'http://video.udn.com/play/news/300040')

# Generated at 2022-06-12 18:40:07.597064
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_ie = UDNEmbedIE()

# Generated at 2022-06-12 18:40:10.379882
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE() 
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:40:12.033656
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._VALID_URL == 'http://video.udn.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:16.671897
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()

    assert udn_embed_ie.ie_key() == 'UDNEmbed'
    assert udn_embed_ie.ie_desc() == '聯合影音'
    assert udn_embed_ie._VALID_URL == r'https?:http://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:21.839176
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME == 'udn:embed'
    assert obj.IE_DESC == '聯合影音'
    assert obj._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:24.606150
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-12 18:40:42.048017
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # check value of attribute _VALID_URL
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    # check value of attribute _PROTOCOL_RELATIVE_VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:40:44.593646
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ret = UDNEmbedIE().suitable(url)
    assert ret, 'Unit test for class UDNEmbedIE failed!'

# Generated at 2022-06-12 18:40:53.936707
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_urls = [
            "https://video.udn.com/embed/news/300040",
            "https://video.udn.com/play/news/300040"
        ]
    dummy_video = {
        'id': '300040',
        'ext': 'mp4',
        'title': '生物老師男變女 全校挺"做自己"',
        'thumbnail': r're:^https?://.*\.jpg$',
        'params': {
            # m3u8 download
            'skip_download': True,
        }
    }
    IE = UDNEmbedIE()
    for url in valid_urls:
        video = IE.extract(url)
        assert video['id'] == dummy_

# Generated at 2022-06-12 18:41:05.809617
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..compat import parse_qsl
    from ..utils import ExtractorError
    ie = UDNEmbedIE()

    video_id = '300040'
    video_url = 'https://video.udn.com/embed/news/300040'

    # Test for _match_id.
    assert ie._match_id(video_url) == video_id
    assert ie._match_id is not None

    # Test for _real_extract
    webpage = ie._download_webpage(video_url, video_id)
    options_str = ie._html_search_regex(r'var\s+options\s*=\s*([^;]+);', webpage, 'options')
    trans_options_str = js_to_json(options_str)

    # Test for _download_webpage
   

# Generated at 2022-06-12 18:41:17.069968
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/play/news/303776"
    result = UDNEmbedIE()._real_extract(url)
    assert result['id'] == '303776'
    assert result['title'] == '遠雄／綠島原住民再爭命 阻擋遠雄股東購買樂齡休閒社區'
    assert len(result['formats']) >= 1
    first_video = result['formats'][0]
    assert 'url' in first_video

# Generated at 2022-06-12 18:41:19.263995
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    class_ie = UDNEmbedIE(url)
    # assert value of required member variables
    assert class_ie._VALID_URL == class_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:41:26.193842
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://embed-ssl.udn.com.tw/embed/news/300040"
    pattern = re.compile(r'.*video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    match = pattern.match(url).groupdict()
    assert match['id'] == "300040"

# Generated at 2022-06-12 18:41:36.425394
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'
    assert len(ie._TESTS) == 3
    for test in ie._TESTS:
        url = test['url']
        res = ie.suitable(url)
        if 'only_matching' in test:
            assert res == (test['only_matching'] == True)
        else:
            assert res == True

# Generated at 2022-06-12 18:41:44.791149
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert type(ie._TESTS) == list and len(ie._TESTS) == 3
    assert ie._TESTS[1]['only_matching']
    assert re.search(ie._VALID_URL, ie._TESTS[0]['url'])
    assert ie._TESTS[2]['only_matching']

# Generated at 2022-06-12 18:41:54.373899
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor.IE_NAME == 'udn'
    assert extractor.IE_TYPE == 'video'
    assert extractor.IE_DESC == '聯合影音'
    assert extractor._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:20.601139
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_udn_embed = UDNEmbedIE()
    assert ie_udn_embed.name == 'UDNEmbed'

# Generated at 2022-06-12 18:42:24.486175
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:30.207428
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Use this function as a unit test for constructor of class UDNEmbedIE
    """
    from ..downloader import get_info_extractor
    from ..utils import ExtractorError
    try:
        ie = get_info_extractor("UDNEmbedIE")
        # If no exception is thrown, ie is successfully constructed
        assert(True)
    except ExtractorError:
        # Fail
        assert(False)


# Generated at 2022-06-12 18:42:39.145864
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:41.071147
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = UDNEmbedIE._VALID_URL
    UDNEmbedIE(url)._real_extract(url)

# Generated at 2022-06-12 18:42:47.765070
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE()._PROTOCOL_RELATIVE_VALID_URL ==\
            r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
    assert(UDNEmbedIE()._VALID_URL ==\
            r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:42:55.634496
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE_test= UDNEmbedIE()
    assert UDNEmbedIE_test.extractor == 'UDNEmbed'
    assert UDNEmbedIE_test.page_url == 'http://video.udn.com'
    assert UDNEmbedIE_test.title == '聯合影音'
    assert UDNEmbedIE_test.url_pattern == 'https?:\\\\/\\\\/video\.udn\.com\\\\/(?:embed|play)\\\\/news\\\\/(?P<id>\\\\d+)'

# Generated at 2022-06-12 18:43:01.316540
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_common import CommonTest, DummyIE
    CommonTest(UDNEmbedIE, 
        [('https://video.udn.com/embed/news/300040', {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
            }, DummyIE)
        ]
    )

# Generated at 2022-06-12 18:43:06.122642
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    # Input URL is correct format
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

    # Input URL is wrong format
    url = 'http://video.udn.com/news/300040'
    try:
        UDNEmbedIE(url)
        assert False
    except ValueError as e:
        assert str(e) == 'Invalid URL: ' + url

# Generated at 2022-06-12 18:43:08.726857
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:44:24.973066
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:44:26.603403
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract(UDNEmbedIE._TESTS[0]['url'])

# Generated at 2022-06-12 18:44:38.793441
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    print('------Test constructor of class UDNEmbedIE')
    assert ie.ie_key() == 'udn'
    assert ie.ie_desc() == '聯合影音'
    assert ie.url_regex() == r'https?:(//video\.udn\.com/(?:embed|play)/news/(?:\d+))'
    assert ie.valid_url('http://video.udn.com/embed/news/300040')
    assert ie.valid_url('https://video.udn.com/embed/news/300040')
    assert ie.valid_url('https://video.udn.com/play/news/303776')

# Generated at 2022-06-12 18:44:44.526041
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    ie = UDNEmbedIE().working_class(UDNEmbedIE, url)
    assert ie.IE_NAME == 'udn.com:embed'
    assert ie._VALID_URL == ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_DESC == '聯合影音'
    assert ie._TESTS

# Generated at 2022-06-12 18:44:45.921688
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    assert ie.ie_key() == 'UDNEmbed'

# Generated at 2022-06-12 18:44:50.153585
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:53.188768
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    embed = UDNEmbedIE()
    embed.download_webpage_handle = None

# Generated at 2022-06-12 18:44:55.261224
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:45:04.940502
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnIE = UDNEmbedIE()

    assert udnIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udnIE._TESTS[0]['info_dict']['id'] == '300040'
    assert udnIE._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert udnIE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert udnIE._TESTS[0]['info_dict']['thumbnail'] == r're:^https?://.*\.jpg$'


# Generated at 2022-06-12 18:45:07.519828
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # UDNEmbedIE(None, {})
    None

if __name__ == '__main__':
    # test_UDNEmbedIE()
    None

# Generated at 2022-06-12 18:47:39.933354
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UDNEmbed'
    assert UDNEmbedIE()._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-12 18:47:48.422582
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_url = "https://video.udn.com/embed/news/300040"
    video_id = "300040"
    result = ie._match_id(test_url)
    assert(result == video_id)

    page = ie._download_webpage(test_url, video_id)
    assert(page)

    options_str = ie._html_search_regex(r'var\s+options\s*=\s*([^;]+);', page, 'options')
    trans_options_str = js_to_json(options_str)
    assert(trans_options_str)
    options_json = ie._parse_json(trans_options_str, 'options', fatal=False) or {}
    assert(options_json)

    trans_json

# Generated at 2022-06-12 18:47:49.993949
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    inst = UDNEmbedIE(url)
    print(inst._match_id(url))
    print(inst._real_extract(url))

# Generated at 2022-06-12 18:48:00.419382
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    udnVideo=UDNEmbedIE()
    assert udnVideo.IE_NAME == 'Udn'
    assert udnVideo.IE_DESC == '聯合影音'
    assert udnVideo._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:48:02.878462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)._match_id('//video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:48:10.160601
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:48:13.095203
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-12 18:48:22.540369
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
  from nose.tools import assert_equal
  from nose.tools import assert_true

  udnIE = UDNEmbedIE()
  assert_true(udnIE)
  assert_true(udnIE._VALID_URL)
  assert_equal(udnIE._VALID_URL, r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
  assert_equal(udnIE._PROTOCOL_RELATIVE_VALID_URL, r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
