

# Generated at 2022-06-12 18:38:30.301534
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE('https://video.udn.com/embed/news/300040')
        UDNEmbedIE('https://video.udn.com/play/news/300040')
    except:
        assert False

# Generated at 2022-06-12 18:38:36.547714
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('UDNEmbedIE')
    assert ie.ie_key() == 'UDNEmbedIE'
    ie = UDNEmbedIE(UDNEmbedIE.ie_key())
    assert ie.ie_key() == 'UDNEmbedIE'
    ie = UDNEmbedIE('UDNEmbedIE', 'foobie')
    assert ie.ie_key() == 'UDNEmbedIE'
    ie = UDNEmbedIE('UDNEmbedIE', ie=UDNEmbedIE('foobie'))
    assert ie.ie_key() == 'UDNEmbedIE'
    ie = UDNEmbedIE(udn_embed=UDNEmbedIE('foobie'))
    assert ie.ie_key() == 'UDNEmbedIE'
    ie

# Generated at 2022-06-12 18:38:45.172936
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test if regex can catch a normal url
    regex_url = 'http://video.udn.com/embed/news/300040'
    video_id = UDNEmbedIE._match_id(regex_url)
    assert video_id == '300040'

    # test if regex can catch a url that starts with //
    regex_url = '//video.udn.com/embed/news/300040'
    video_id = UDNEmbedIE._match_id(regex_url)
    assert video_id == '300040'

# Generated at 2022-06-12 18:38:46.991592
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:38:52.904781
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE(): 
    from pprint import pprint
    data = UDNEmbedIE._download_json('https://video.udn.com/api/getVideo/300040', display_id='300040')
    pprint(data)
    format = data['source']
    if format.startswith('http'):
        m = UDNEmbedIE(format)
    else:
        m = UDNEmbedIE.get_instance(format)
    pprint(m.extract())

# Generated at 2022-06-12 18:39:01.920607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == 'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:39:15.370337
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url in ('https://video.udn.com/embed/news/300040',
                'http://video.udn.com/embed/news/300040',
                '//video.udn.com/embed/news/300040'):
        result = UDNEmbedIE().suitable(url)
        assert result is True, '%s should be a suitable url for UDNEmbedIE' % url

    for url in ('http://video.udn.com/play/news/303776', 'https://video.udn.com/play/news/303776'):
        result = UDNEmbedIE().suitable(url)
        assert result is False, '%s should not be a suitable url for UDNEmbedIE' % url

# Generated at 2022-06-12 18:39:17.443222
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:39:24.966078
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._valid_url('http://video.udn.com/embed/news/300040')
    assert ie._valid_url('https://video.udn.com/play/news/300040')

# Generated at 2022-06-12 18:39:25.800060
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)


# Generated at 2022-06-12 18:39:40.804837
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    embed = UDNEmbedIE({})
    embed._downloader = None
    embed.extractor = None
    embed._match_id('') # Confirm no error occurs

# Generated at 2022-06-12 18:39:42.127501
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except Exception:
        raise

# Generated at 2022-06-12 18:39:44.735290
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE()
    assert tester._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:50.230838
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn_embed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:51.654945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:40:01.516180
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    ie.IE_NAME = "UDNEmbedIE"
    ie.IE_DESC = "聯合影音"
    ie._VALID_URL = ie._PROTOCOL_RELATIVE_VALID_URL =\
        r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    print(ie.valid_url("http://video.udn.com/embed/news/300040", True))
    print(ie.valid_url("https://video.udn.com/embed/news/300040", True))
    print(ie.valid_url("http://video.udn.com/play/news/300040", True))

# Generated at 2022-06-12 18:40:05.396774
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    c = UDNEmbedIE()
    assert c.IE_NAME == 'UDNEmbed'
    assert c.IE_DESC == '聯合影音'
    assert c.VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:07.758362
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    if __name__ == '__main__':
        url = 'http://video.udn.com/embed/news/300040'
        inst = UDNEmbedIE()
        print(inst._real_extract(url))

# Generated at 2022-06-12 18:40:13.253492
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == \
        r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # test constructors of video:
    test_video = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert test_video.IE_DESC == '聯合影音'
    assert test_video._PROTOCOL_RELATIVE_VALID_URL == \
        r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:23.498203
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
  test_cases = [
    {'url': 'https://video.udn.com/embed/news/300040', 'match': True},
    {'url': 'https://video.udn.com/play/news/300040', 'match': True},
    {'url': 'https://video.udn.com/embed/news', 'match': False},
  ]
  for test_case in test_cases:
    url = test_case['url']
    match = test_case['match']
    udn_embed_ie = UDNEmbedIE()
    assert (udn_embed_ie._match_id(url) is not None) == match

# Generated at 2022-06-12 18:41:01.703777
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Case 1
    url = 'https://video.udn.com/play/news/303776'
    IE = UDNEmbedIE()
    assert IE._VALID_URL is not None, 'IE._VALID_URL is None'
    assert re.search(IE._VALID_URL, url).group('id') == '303776'
    assert IE._PROTOCOL_RELATIVE_VALID_URL is not None, 'IE._PROTOCOL_RELATIVE_VALID_URL is None'
    assert re.search(IE._PROTOCOL_RELATIVE_VALID_URL, url).group('id') == '303776'
    assert IE.IE_DESC is not None, 'IE.IE_DESC is None'

    # Case 2

# Generated at 2022-06-12 18:41:08.920088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_test = UDNEmbedIE('test_UDNEmbedIE')
    assert url_test.IE_DESC == '聯合影音'
    assert url_test._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert url_test._VALID_URL == 'https?:' + url_test._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:41:19.701691
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.ie_key() == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 18:41:24.724873
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor.IE_NAME == 'udn'
    assert extractor.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:41:29.523807
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == UDNEmbedIE._VALID_URL
    assert ie._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:41:32.448320
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():

    UDNEmbedIE()
    UDNEmbedIE._VALID_URL = "http://video.udn.com/play/news/300040"



# Generated at 2022-06-12 18:41:36.769139
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-12 18:41:45.758472
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:41:49.444088
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # check class UDNEmbedIE can be instantiated
    ie = UDNEmbedIE()
    assert ie is not None
    assert type(ie) == UDNEmbedIE


# Generated at 2022-06-12 18:41:56.681253
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME == 'video.udn.com:embed'
    assert obj.IE_DESC == '聯合影音'
    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:23.773361
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbed')._real_extract(
        'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:42:26.783944
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'https://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE()
    assert udn_embed._match_id(test_url) == '300040'

# Generated at 2022-06-12 18:42:31.454406
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/embed/news/300040')
    assert ie._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:42:34.264140
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_test = UDNEmbedIE()
    # Test constructor of class UDNEmbedIE is completed
    assert udn_test

# Generated at 2022-06-12 18:42:40.371971
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE(None)
    assert re.match(udn_ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert re.match(udn_ie._VALID_URL, 'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:42:46.044592
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #Construct object of class UDNEmbed
    udn = UDNEmbedIE()
    # Check whether url of object is equal to expected url
    assert udn._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:47.531493
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/embed/news/12345')

# Generated at 2022-06-12 18:42:55.467377
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnEmbedIE = UDNEmbedIE()
    assert udnEmbedIE.IE_NAME == 'udn-embed'
    assert udnEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:59.542106
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    uri1 = "https://video.udn.com/embed/news/300040" # Valid URL
    uri2 = "http://v.udn.com/video/news/300040" # Invalid URL
    ie = UDNEmbedIE()
    ie.extract(uri1)
    ie.extract(uri2)

# Generated at 2022-06-12 18:43:07.598719
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from pytest import raises
    from .._testutil import UNKNOWN_ERRORS

    with raises(ValueError):
        UDNEmbedIE('http://video.udn.com/api/news/v3/embed/300040')

    with raises(ValueError):
        UDNEmbedIE('http://video.udn.com/news/300040')

    with raises(ValueError):
        UDNEmbedIE('http://video.udn.com/')

    with raises(ValueError):
        UDNEmbedIE('http://video.udn.com/embed/news/300040/fake')

    with raises(ValueError):
        UDNEmbedIE('http://video.udn.com/embed/news/300040.html')


# Generated at 2022-06-12 18:44:16.389533
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:44:19.053506
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-12 18:44:20.279904
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert isinstance(UDNEmbedIE, object)

# Generated at 2022-06-12 18:44:23.233309
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:26.355454
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test with empty url
    UDNEmbedIE(None, None)

    # Test with invalid url
    UDNEmbedIE(None, 'unknown_url')

# Generated at 2022-06-12 18:44:33.096688
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create an object of class UDNEmbedIE for testing purpose.
    UDNEmbedIE_test = UDNEmbedIE()
    # Get the video_id from a valid video link
    video_id = UDNEmbedIE_test._match_id(
        'http://video.udn.com/embed/news/300040')
    # Assert to check whether the video_id is a string
    assert isinstance(video_id, str)

# Generated at 2022-06-12 18:44:43.910911
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the constructor of class UDNEmbedIE
    url_result_obj = UDNEmbedIE().url_result('http://video.udn.com/embed/news/300040')
    assert url_result_obj.get('ie_key') == 'UDNEmbed'
    assert url_result_obj.get('url') == 'http://video.udn.com/embed/news/300040'
    assert url_result_obj.get('ie') == 'UDNEmbed'

    # Test the private function _PROTOCOL_RELATIVE_VALID_URL of class UDNEmbedIE
    valid_url = '//video.udn.com/embed/news/300040'
    assert re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, valid_url)



# Generated at 2022-06-12 18:44:44.551284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert True

# Generated at 2022-06-12 18:44:49.119280
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    testUrl = "https://video.udn.com/embed/news/300040"
    testUrl2 = "http://video.udn.com/embed/news/300040"
    assert ie._match_id(testUrl) == '300040'
    assert ie._match_id(testUrl2) == '300040'
    assert ie._match_id(testUrl + "?a=b") == '300040'

# Generated at 2022-06-12 18:44:52.263167
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pylint: disable=no-value-for-parameter
    UDNEmbedIE(UDNEmbedIE.ie_key())
    # pylint: enable=no-value-for-parameter

# Generated at 2022-06-12 18:47:32.690760
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie


# Generated at 2022-06-12 18:47:34.690307
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Constructor test
    """
    obj_udn_embed = UDNEmbedIE()
    assert obj_udn_embed is not None

# Generated at 2022-06-12 18:47:37.251341
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_construction = UDNEmbedIE('abc')
    assert test_construction.IE_NAME == 'udnembed'
    assert test_construction.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:47:42.554738
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE(url='http://video.udn.com/embed/news/300040')
    assert udne._VALID_URL == UDNEmbedIE._VALID_URL
    assert udne._TESTS == UDNEmbedIE._TESTS
    assert udne._PROTOCOL_RELATIVE_VALID_URL == UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-12 18:47:45.250168
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"
    video = UDNEmbedIE()._real_extract(url)
    print("video formates: ", video['formats'])
    assert video

# Generated at 2022-06-12 18:47:46.358667
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().ie_key() == 'UDNEmbed'

# Generated at 2022-06-12 18:47:47.141986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:47:49.838307
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # for udn_embed_url in ['http://video.udn.com/embed/news/300040']:
    #     print(ie.url_result(ie._match_id(udn_embed_url)))

# Generated at 2022-06-12 18:47:52.154635
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert(ie.IE_NAME == 'udn')
    assert(ie.IE_DESC == '聯合影音')

# Generated at 2022-06-12 18:47:53.628557
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()