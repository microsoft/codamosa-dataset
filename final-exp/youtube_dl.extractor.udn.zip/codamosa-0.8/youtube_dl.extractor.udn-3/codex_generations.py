

# Generated at 2022-06-12 18:38:35.676354
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Instantiating an instance of the class UDNEmbedIE
    ie = UDNEmbedIE()
    # Testing the method extract_info()
    assert ie.extract('http://video.udn.com/embed/news/300040')['id'] == '300040'
    assert ie.extract('https://video.udn.com/embed/news/300040')['id'] == '300040'

# Generated at 2022-06-12 18:38:36.524730
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie

# Generated at 2022-06-12 18:38:40.524515
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE("https://video.udn.com/play/news/303776", {})._real_extract("https://video.udn.com/play/news/303776")

# Generated at 2022-06-12 18:38:41.579802
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print (UDNEmbedIE)


# Generated at 2022-06-12 18:38:45.874968
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	url = '//video.udn.com/embed/news/300040'
	ie = UDNEmbedIE()

# Generated at 2022-06-12 18:38:54.538392
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import json
    embed_instance = UDNEmbedIE()
    test_url = 'https://video.udn.com/play/news/303776'
    test_url_search = re.search(embed_instance._VALID_URL, test_url)
    assert test_url_search.group('id') == '303776'

    # Testing the _download_webpage function
    videoid = '303776'
    embed_instance.to_screen('[youtube] %s: Downloading webpage' % videoid)
    embed_instance.report_download_webpage(videoid)
    test_args = (test_url, videoid, None)

# Generated at 2022-06-12 18:39:00.539283
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()

    assert test._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test._TESTS is not None

# Generated at 2022-06-12 18:39:15.292012
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_instance = UDNEmbedIE()
    print("\n==== get_info_extractor() ====")
    print(type(ie_instance.get_info_extractor()))
    print("==== _WORKING ====")
    print(type(ie_instance._WORKING))
    print("==== _downloader ====")
    print(type(ie_instance._downloader))
    print("==== _ies ====")
    print(type(ie_instance._ies))
    print("==== _downloader_classes ====")
    print(type(ie_instance._downloader_classes))
    print("==== ie_key() ====")
    print(type(ie_instance.ie_key()))
    print("==== get_info_extractors() ====")

# Generated at 2022-06-12 18:39:23.338164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "https://video.udn.com/embed/news/300040"
    ie = UDNEmbedIE()
    print (ie.IE_DESC) # 聯合影音
    print (ie._VALID_URL) # https?:\/\/video\.udn\.com\/(?:embed|play)\/news\/(?P<id>\d+)
    print (ie._extract_url(url)) # https://video.udn.com/embed/news/300040

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:39:25.774664
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL, ie._TESTS

# Generated at 2022-06-12 18:39:43.613048
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('UDNEmbedIE', None)
    print(ie._PROTOCOL_RELATIVE_VALID_URL)
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:39:46.816690
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check URL format
    assert_equal(UDNEmbedIE()._VALID_URL, UDNEmbedIE._VALID_URL)


# Generated at 2022-06-12 18:39:49.501873
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert hasattr(ie, '_PROTOCOL_RELATIVE_VALID_URL')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-12 18:39:53.634590
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:02.249423
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    tester = UDNEmbedIE()
    match = tester._PROTOCOL_RELATIVE_VALID_URL
    assert(re.match(match, '//video.udn.com/embed/news/300040') != None)
    assert(re.match(match, '//video.udn.com/play/news/300040') != None)
    assert(re.match(match, '//video.udn.com/embed/news/300040') != None)
    assert(re.match(match, 'https://video.udn.com/embed/news/300040') != None)
    assert(re.match(match, 'https://video.udn.com/play/news/300040') != None)


# Generated at 2022-06-12 18:40:09.590997
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    print(UDNEmbedIE()._make_valid_url(url))
    print(UDNEmbedIE()._make_valid_url(url, test=True))
    print(UDNEmbedIE()._make_valid_url(url, test=True, downloader=None))
    print(UDNEmbedIE()._make_valid_url(url, test=True, downloader=None, extra_param={'format': 'bestvideo+bestaudio/best'}))
    print(UDNEmbedIE()._make_valid_url(url, test=True, downloader=None, extra_param={'format': 'bestvideo+bestaudio/best', 'merge_output_format': 'mp4'}))

# Generated at 2022-06-12 18:40:20.813618
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    dl=UDNEmbedIE()
    dl.IE_DESC = '聯合影音'
    dl._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    dl._VALID_URL = r'https?:' + dl._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:40:26.646498
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = ie._real_extract('http://video.udn.com/embed/news/300040')
    assert url['id'] == 'news/300040'
    assert url['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-12 18:40:29.187588
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    match = ie._PROTOCOL_RELATIVE_VALID_URL
    assert re.compile(match)

# Generated at 2022-06-12 18:40:31.639107
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test the constructor
    try:
        UDNEmbedIE()
    except Exception as e:
        logging.info(str(e))
        pass


# Generated at 2022-06-12 18:41:01.192982
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    assert udn._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert udn._VALID_URL == 'https?:' + udn._PROTOCOL_RELATIVE_VALID_URL
    assert udn._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:41:03.776521
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE().extract(
        'https://video.udn.com/embed/news/300040'
    )

# Generated at 2022-06-12 18:41:05.063982
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'UDNEmbed'

# Generated at 2022-06-12 18:41:10.719530
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print('Unit test for constructor of class UDNEmbedIE')
    url = 'http://video.udn.com/embed/news/300040'
    unit = UDNEmbedIE()
    print('URL = %s' % url)
    print('Unit ID = %s' % unit._match_id(url))
    print('Unit Name = %s' % unit._match_name(url))


# Generated at 2022-06-12 18:41:17.192638
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.url_result('http://www.youtube.com/watch?v=9bZkp7q19f0', 'Youtube') == {'url': 'http://www.youtube.com/watch?v=9bZkp7q19f0', 'ie_key': 'Youtube'}

# Generated at 2022-06-12 18:41:21.952242
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a = UDNEmbedIE()
    a.IE_DESC = 'test'
    a._VALID_URL = 'http://testurl'
    a.IE_NAME = 'videoudn:embed'
    a._download_webpage = lambda url, video_id: '{"title":"test","video":{"youtube":"youtubeurl","mp4":"mp4url","hls":"http://hlsurl"}}'
    assert a.ie_key() == 'videoudn:embed'

# Generated at 2022-06-12 18:41:34.068192
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    ie_desc = obj.IE_DESC
    ie_desc_expected = '聯合影音'
    assert ie_desc == ie_desc_expected
    protocol_valid_url = obj._PROTOCOL_RELATIVE_VALID_URL
    protocol_valid_url_expected = '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert protocol_valid_url == protocol_valid_url_expected
    valid_url = obj._VALID_URL
    valid_url_expected = 'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL
    assert valid_url == valid_url_expected
    tests = obj._TESTS

# Generated at 2022-06-12 18:41:36.678811
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()



# Generated at 2022-06-12 18:41:41.366317
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    # Test URL:
    # http://video.udn.com/embed/news/300040
    print(udn_embed_ie.working())

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:41:49.420795
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040', None)
    assert ie.IE_NAME == 'video.udn.com'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie.ie_key() == 'video.udn.com'

# Generated at 2022-06-12 18:42:43.342246
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-12 18:42:47.261356
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    embed_ie = UDNEmbedIE()
    embed_ie.extract(url)
    embed_ie.IE_DESC

# Generated at 2022-06-12 18:42:48.815531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie_udn = UDNEmbedIE('udn')
    ie_udn.work()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:42:54.077886
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    expected = '聯合影音'
    obj = UDNEmbedIE()
    assert obj.IE_NAME == expected, 'UDNEmbedIE IE_NAME should be "%s", but got "%s"' % (expected, obj.IE_NAME)
    expected = '聯合影音'
    assert obj.IE_DESC == expected, 'UDNEmbedIE IE_DESC should be "%s", but got "%s"' % (expected, obj.IE_DESC)

# Generated at 2022-06-12 18:42:57.306838
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..sites import udn

    ie = udn.UDNIE({}, {})
    assert isinstance(ie, UDNEmbedIE)

# Generated at 2022-06-12 18:42:58.736415
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:42:59.586867
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(InfoExtractor)

# Generated at 2022-06-12 18:43:05.504450
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj.IE_NAME == 'video.udn.com:embed'
    assert test_obj.IE_DESC == '聯合影音'
    assert test_obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert test_obj._TESTS[0]['expected_warnings'] == ['Failed to parse JSON Expecting value']

# Generated at 2022-06-12 18:43:06.818536
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert(udne)
    

# Generated at 2022-06-12 18:43:12.503735
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE();
    print("%s" % ie.IE_DESC);
    assert ie.IE_DESC == '聯合影音'

if __name__ == '__main__':
    test_UDNEmbedIE();

# Generated at 2022-06-12 18:45:13.283858
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()

# Generated at 2022-06-12 18:45:16.171393
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/play/news/303776'
    ie = UDNEmbedIE(url)
    assert ie.test_video_url(url)

# Generated at 2022-06-12 18:45:20.210614
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udn = UDNEmbedIE(url)
    assert None != re.search(
        r'[\w.]+\s+[(].+[)]',
        repr(UDNEmbedIE), re.UNICODE)

# Generated at 2022-06-12 18:45:21.891859
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE = UDNEmbedIE()
    print(UDNEmbedIE)
    UDNEmbedIE.get_url_info()

# Generated at 2022-06-12 18:45:25.518825
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    URL = 'http://video.udn.com/embed/news/300040'
    info_extractor = UDNEmbedIE()
    # Regular expression to match the video id
    video_id_re = re.compile(r'(?P<id>\d+)')
    assert video_id_re.match(info_extractor._match_id(URL)).group('id'), "video id not matched"

# Generated at 2022-06-12 18:45:30.946482
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print("Test for constructor of class UDNEmbedIE")
    url = input("Input url:")
    params = input("Input parameters:")
    print("Test code of extractor will be executed.")
    instance = UDNEmbedIE()
    print("The IE class ID is")
    print(instance.IE_NAME)
    print("Result:")
    print(instance.extract(url, params))

# Generated at 2022-06-12 18:45:33.763707
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    t = ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._match_id(t) == '300040'



# Generated at 2022-06-12 18:45:35.402888
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert isinstance(instance, UDNEmbedIE)


# Generated at 2022-06-12 18:45:40.723707
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert ie._match_id(url) is not None, 'The url is valid so it should return an id'
    url = 'http://video.udn.com/embed/news/'
    assert ie._match_id(url) is None, 'The url is invalid so it should return None'

# Generated at 2022-06-12 18:45:46.855941
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ''' UDNEmbedIE.__init__() '''
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.extractor import YoutubePlaylistIE
    from youtube_dl.extractor import YoutubeChannelIE
    from youtube_dl.extractor import GenericIE

    # test REGULAR
    ue = UDNEmbedIE()
    assert (type(ue) == UDNEmbedIE)
    # test DASH
    ue = UDNEmbedIE(dash=True)
    assert (ue.dash == True)
    # test PARENT
    ue = UDNEmbedIE(parent=YoutubeIE())
    assert (type(ue.parent) == YoutubeIE)
    ue = UDNEmbedIE(parent=YoutubeIE())
    assert (type(ue.parent) == YoutubeIE)
   