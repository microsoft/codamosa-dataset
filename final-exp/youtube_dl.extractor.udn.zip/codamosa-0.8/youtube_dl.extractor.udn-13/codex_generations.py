

# Generated at 2022-06-12 18:38:27.938608
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert 'UDNEmbedIE' in globals()

# Generated at 2022-06-12 18:38:30.028961
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # To check if all the given parameters are valid
    # To check if all the given parameters can pass the unittest
    UDNEmbedIE()


# Generated at 2022-06-12 18:38:35.762721
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE()
    if not obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)':
        raise ValueError('setup protocol relative valid url error')
    if not obj._VALID_URL == 'https?:' + obj._PROTOCOL_RELATIVE_VALID_URL:
        raise ValueError('setup valid url error')
    match_result = obj._match_id(url)
    if not match_result == '300040':
        raise ValueError('setup valid url match error')

# Generated at 2022-06-12 18:38:41.160698
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info = UDNEmbedIE().extract('http://video.udn.com/embed/news/300040')
    assert info['id'] == '300040'
    assert info['title'] == '生物老師男變女 全校挺"做自己"'

# Generated at 2022-06-12 18:38:47.094520
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    # Constructor should detect the correct url
    ie.suitable(test_url)
    # ie.IE_DESC should be '聯合影音'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:38:55.142215
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()

    # test a valid url and test the value of the instance's only_IE property
    assert ie.suitable(ie.IE_NAME, 'http://video.udn.com/embed/news/300040')
    assert ie.only_IE(ie.IE_NAME, 'http://video.udn.com/embed/news/300040') == True

    # test a valid url with protocol-relative form
    assert ie.suitable(ie.IE_NAME, '//video.udn.com/embed/news/300040')

    # test the value of the instance's only_IE property if the url is valid
    assert ie.only_IE(ie.IE_NAME, '//video.udn.com/embed/news/300040') == True

    # test a valid url with the form of //

# Generated at 2022-06-12 18:38:59.069871
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None, 'http://video.udn.com/embed/news/300040')
    UDNEmbedIE(None, '//video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:39:07.851242
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:39:14.672057
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = '300040'
    video_url = 'http://video.udn.com/embed/news/300040'
    # get the class object
    UDNEmbedIE_obj = UDNEmbedIE()
    # extract the url
    UDNEmbedIE_obj._real_extract(video_url)

# Generated at 2022-06-12 18:39:18.836404
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check behavior when protocol relative URL is given
    udn_embed_ie = UDNEmbedIE('http:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert udn_embed_ie._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-12 18:39:36.542913
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    IE._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    url = 'http://video.udn.com/embed/news/300040'

    video_id = IE._match_id(url)
    page = IE._download_webpage(url, video_id)

    options_str = IE._html_search_regex(
        r'var\s+options\s*=\s*([^;]+);', page, 'options')
    trans_options_str = js_to_json(options_str)
    options = IE._parse_json(trans_options_str, 'options', fatal=False) or {}

# Generated at 2022-06-12 18:39:47.291497
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:39:48.014892
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbed = UDNEmbedIE()

# Generated at 2022-06-12 18:39:52.264242
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .test_common import all_IEs_tests
    all_IEs_tests(UDNEmbedIE)

# Main for testing
if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:39:56.904382
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:40:03.842513
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    udn_embed_url = '//video.udn.com/embed/news/12345'
    not_udn_embed_url = '//video.udn.com/news/12345'
    assert ie.suitable(udn_embed_url) is True
    assert ie.suitable(not_udn_embed_url) is False

# Generated at 2022-06-12 18:40:04.723124
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    video_id = 300040

    UDNEmbedIE()



# Generated at 2022-06-12 18:40:07.182490
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    match = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    url = '//video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    assert ie is not None

# Generated at 2022-06-12 18:40:10.017120
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    
    if ie._match_id(url) == '300040':
        print('UDNEmbedIE get id successfully')
    else:
        print('UDNEmbedIE get id failed')

    return

# Generated at 2022-06-12 18:40:13.871733
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:40:35.346284
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = '//video.udn.com/embed/news/300040'
    UDNEmbedIE._VALID_URL = 'https:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:40:45.996786
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:51.408739
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    embed_req_url = 'http://video.udn.com/embed/news/300040?wmode=transparent&autoplay=true'
    embed_test_url = 'https://video.udn.com/embed/news/300040?wmode=transparent&autoplay=true'
    assert obj._construct_embed_url(embed_req_url) == embed_test_url

# Generated at 2022-06-12 18:40:53.263355
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_NAME == 'udn'

# Generated at 2022-06-12 18:41:05.517976
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.IE_DESC == '聯合影音'
    assert IE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert IE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:41:18.997643
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import unittest
    import json
    from .common import FakeYDL

    class FakeUDNEmbedIE(UDNEmbedIE, unittest.TestCase):
        def _download_webpage(self, url, video_id, note=None, errnote=None, fatal=True):
            #return FakeUDNEmbedIE._download_webpage(self, url, video_id, note, errnote, fatal)
            try:
                data = json.loads(url)
                return data["data"]
            except json.JSONDecodeError:
                data = url.split('?', 1)[0]
                data = data.split('/')[-1]
                return data

    tester = FakeUDNEmbedIE()

    # Test #1: testing normal flow
    # Let's give data to extractor and see

# Generated at 2022-06-12 18:41:20.740807
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie is not None

# Generated at 2022-06-12 18:41:26.941829
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    test_url = 'http://video.udn.com/embed/news/300040'
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:41:36.817706
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:41:42.807040
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_ie = UDNEmbedIE()
    assert udn_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_ie._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:07.334896
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_UDNEmbedIE = UDNEmbedIE()

    assert class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert class_UDNEmbedIE._VALID_URL == r'https?:' + class_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert class_UDNEmbedIE.IE_DESC == '聯合影音'

    test_url = 'http://video.udn.com/embed/news/300040'
    assert class_UDNEmbedIE._match_id(test_url) == '300040'


# Generated at 2022-06-12 18:42:14.336601
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:17.725293
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor.IE_NAME == 'UDNEmbed'
    assert extractor.IE_DESC == '聯合影音'
    assert extractor._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:30.098503
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for url in [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
        '//video.udn.com/embed/news/300040',
    ]:
        ie = UDNEmbedIE(url)
        assert(str(ie) == '聯合影音')
        assert(dict(ie) == {
            'url': url,
            'info_dict': {
                'ie_key': 'UDNEmbed',
                'url': url,
                'id': '300040',
            },
            'ie_key': 'UDNEmbed',
        })


# Generated at 2022-06-12 18:42:42.067199
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.IE_DESC == '聯合影音'

if __name__ == '__main__':
    # Unit test for constructor of class UDNEmbedIE
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:42:48.220727
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert re.match(
        r'.*' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
        '//video.udn.com/embed/news/300040')
    assert re.match(
        r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL,
        'https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:42:55.732276
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.ie_key() == 'udn_embed'
    assert UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['title'] == '生物老師男變女 全校挺"做自己"'
    assert UDNEmbedIE._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-12 18:42:59.268350
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:43:03.212228
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:43:04.433729
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test for constructing and extracting info
    UDNEmbedIE()

# Generated at 2022-06-12 18:43:38.484680
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert ie._match_id('//video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-12 18:43:41.945026
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_name = 'UDNEmbedIE'
    obj = eval(class_name + '(InfoExtractor)')
    assert obj._VALID_URL == class_name._VALID_URL
    assert obj._TESTS == class_name._TESTS
    assert obj.__name__ == class_name
    assert obj.IE_DESC == class_name.IE_DESC

# Generated at 2022-06-12 18:43:46.912578
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    a_url = 'https://video.udn.com/embed/news/300040'
    udn_embed_ie = UDNEmbedIE()
    parsed_url = compat_urlparse.urlparse(a_url)
    assert udn_embed_ie._match_id(parsed_url) == '300040'


# Generated at 2022-06-12 18:43:50.119216
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # Some test assertions
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL.startswith('https?:')
    assert ie._TESTS[0].get('skip_download')

# Generated at 2022-06-12 18:43:57.177109
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    extractor = UDNEmbedIE()
    assert extractor.IE_DESC == '聯合影音'
    pattern = extractor._PROTOCOL_RELATIVE_VALID_URL
    result = re.search(pattern, '//video.udn.com/embed/news/300040')
    assert result.group('id') == '300040'
    url = 'https://video.udn.com/embed/news/300040'
    assert extractor._VALID_URL == 'https?:' + extractor._PROTOCOL_RELATIVE_VALID_URL
    assert extractor._match_id(url) == '300040'

# Generated at 2022-06-12 18:44:02.820552
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == 'https?:' + '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:11.401218
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pylint: disable=invalid-name
    import unittest
    import os
    import sys

    # UDN's JavaScrtipt code is obfuscated and newline is removed
    # To pass the test, we restore the original code by replacing
    # the newlines and indentation
    # For some cases, remove the content tab after the `function` keyword
    # For example, transform `function(a){a*a}` to `function (a){a*a}`
    def restore_original_js(html_file_path, css_file_path):
        with open(html_file_path, 'rb') as fin:
            data = fin.read().decode('utf-8')
        js_code = data.split('<script language="javascript">')[-1].split('</script>')[0]


# Generated at 2022-06-12 18:44:18.560964
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    unit_test_UDNEmbedIE = UDNEmbedIE()
    assert unit_test_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert unit_test_UDNEmbedIE._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert unit_test_UDNEmbedIE.IE_DESC == '聯合影音'
    assert unit_test_UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert unit_test_UDNEmbedIE._TESTS

# Generated at 2022-06-12 18:44:29.430182
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video.udn.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert UDNEmbedIE._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[1]['url'] == 'https://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[2]['url'] == 'https://video.udn.com/play/news/303776'

# Generated at 2022-06-12 18:44:33.122219
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:45:04.939428
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for constructor of class UDNEmbedIE
    """
    try:
        UDNEmbedIE()
    except Exception as e:
        assert False, e  # no error must be raise
    else:
        assert True  # when no error occur, this line should be executed


# Generated at 2022-06-12 18:45:07.294265
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = UDNEmbedIE
    # We expect the constructor can be initialized without error
    assert(class_ is not None)


# Generated at 2022-06-12 18:45:09.042790
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE == InfoExtractor._make_IE_from_embed_url('video.udn.com/embed/news/300040'))

# Generated at 2022-06-12 18:45:13.276434
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # No assertion, only for constructor
    UDNEmbedIE('http://video.udn.com/embed/news/300040')
    UDNEmbedIE('https://video.udn.com/embed/news/300040')
    UDNEmbedIE('http://video.udn.com/play/news/300040')
    UDNEmbedIE('https://video.udn.com/play/news/300040')

# Generated at 2022-06-12 18:45:16.789476
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    inst = UDNEmbedIE()
    def get_text_value(dict_object, key):
        return dict_object[key]
    assert get_text_value(inst.ie_key2id, 'udn') == 'udnembed'

# Generated at 2022-06-12 18:45:24.831054
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # to test this class, you can use the following command: python -m youtube_dl.extractor.udn all
    # following command has been used as unit test
    testArgs = ['-v','-c','--no-playlist','--yes-playlist','--match-title','--download-archive','download_archive','--age-limit','18','--download-archive','download_archive','--no-download','--format','all','--get-title','--get-id','--getthumbnail','--get-description','--get-duration','--get-filename','--get-format','--default-search','ytsearch','--autonumber-size','5','--autonumber-start','0','--dump-intermediate-pages', '--ignore-config']

# Generated at 2022-06-12 18:45:25.934708
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..debug import test_extractors
    test_extractors(UDNEmbedIE)

# Generated at 2022-06-12 18:45:27.945809
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(None)._real_extract("http://video.udn.com/embed/news/300040")

# Generated at 2022-06-12 18:45:33.883273
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    dl = UDNEmbedIE(UDNEmbedIE.create_ie())
    assert dl._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert dl._VALID_URL == r'https?:' + dl._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:45:42.681893
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    #test the constructor of class UDNEmbedIE
    #it's better that we can get more info from test_UDNEmbedIE of youtube_dl
    assert UDNEmbedIE('http://video.udn.com/embed/news/300040')=={'ie_key': 'UDNEmbed',
                                                                  'url': 'http://video.udn.com/embed/news/300040'}
    #test the constructor of class InfoExtractor

# Generated at 2022-06-12 18:47:10.044864
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()

# Generated at 2022-06-12 18:47:12.968696
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-12 18:47:19.840673
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udney = UDNEmbedIE()
    assert udney._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udney._VALID_URL == r'https?:' + udney._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-12 18:47:22.681054
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Check exception when url is None
    assert_raises(AssertionError, UDNEmbedIE, None, True)


# Generated at 2022-06-12 18:47:27.307878
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    video_id = '300040'
    UDNEmbedIE()._match_id(url)
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-12 18:47:36.906096
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = UDNEmbedIE._VALID_URL
    ie = UDNEmbedIE(url)
    # test _VALID_URL
    assert(ie._match_id(url) == '300040')
    url = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert(ie._match_id(url) == '300040')
    assert(ie.IE_NAME == 'udn' or ie.IE_NAME == 'udn-v2')
    # test _TESTS
    #assert(ie._TESTS[0]['info_dict'] == {
    #    'id': '300040',
    #    'ext': 'mp4',
    #    'title': '生物老師男變女 全校挺"

# Generated at 2022-06-12 18:47:37.625196
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE)

# Generated at 2022-06-12 18:47:39.853138
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    value = 'http://video.udn.com/embed/news/300040'
    id = udne._match_id(value)
    assert id == '300040'

# Generated at 2022-06-12 18:47:40.293945
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-12 18:47:41.725508
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
