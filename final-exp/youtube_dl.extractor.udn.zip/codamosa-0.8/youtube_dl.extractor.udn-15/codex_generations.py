

# Generated at 2022-06-12 18:38:32.467296
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance

# Generated at 2022-06-12 18:38:33.995624
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    r = UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')
    assert r['id'] == '300040'


# Generated at 2022-06-12 18:38:38.067276
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    UnitTest for class UDNEmbedIE
    """
    udn = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert udn.ie_key() == 'UdnEmbed'
    assert udn.ie_desc() == '聯合影音'
    assert udn.suitable(u'http://video.udn.com/embed/news/300040')
    assert udn.suitable(u'https://video.udn.com/embed/news/300040')
    assert udn.suitable(u'https://video.udn.com/play/news/300040')

# Generated at 2022-06-12 18:38:45.427460
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDN'
    assert udn_embed_ie.ie_desc() == '聯合影音'
    assert udn_embed_ie.ie_app_version() is None
    assert udn_embed_ie.ie_app_name() is None
    assert udn_embed_ie.ie_app() is None


# Generated at 2022-06-12 18:38:54.294074
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # valid url
    assert UDNEmbedIE._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    # valid url with "www"
    assert UDNEmbedIE._VALID_URL == "https?://www\.video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    # valid url with protocol-relative pattern
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    # valid url with "www" and protocol-relative pattern

# Generated at 2022-06-12 18:38:55.562504
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:39:07.304289
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import ExtractorError
    # test valid_url
    valid_url = 'http://video.udn.com/embed/news/300040'
    try:
        UDNEmbedIE()._real_extract(valid_url)
    except ExtractorError as e:
        assert True

    # test invalid_url
    invalid_url = 'http://video.udn.com/embed/news/300040/'
    try:
        UDNEmbedIE()._real_extract(invalid_url)
    except ExtractorError as e:
        assert True

# test_UDNEmbedIE()

# Generated at 2022-06-12 18:39:11.124618
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE("https://video.udn.com/embed/news/1234")
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-12 18:39:13.626530
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne_ie = UDNEmbedIE()
    assert isinstance(udne_ie, InfoExtractor)


# Generated at 2022-06-12 18:39:16.752252
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from youtube_dl.utils import SearchInfoExtractor
    from .common import InfoExtractor
    from .common import _test_playlist_result
    from .common import _test_video_result
    from .common import playlist_result
    from .common import video_result

    class _ReportIE(InfoExtractor):

        def report_video_info_webpage_download(self, *args, **kwargs):
            pass

    ie = _ReportIE("youtube", {})

    _test_video_result(UDNEmbedIE("youtube", {}), ie, "https://video.udn.com/embed/news/300040")

# Generated at 2022-06-12 18:39:30.880605
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert ie._downloader is None
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert ie.REQUIRE_MOB_UA is False
    assert ie.IE_KEY == 'UDNEmbed'

# Generated at 2022-06-12 18:39:33.333671
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()._real_extract('http://video.udn.com/embed/news/300040')



# Generated at 2022-06-12 18:39:40.422942
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """test for constructor of class UDNEmbedIE"""
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:39:45.985435
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    parsed = urlparse('http://video.udn.com/embed/news/300040')
    ie = UDNEmbedIE()
    # We expect that there are two groups
    ie._PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?P<first>embed|play)/news/(?P<second>\d+)'
    result = ie._match_id(parsed)
    # The second group converted to int
    assert result == 300040


# Generated at 2022-06-12 18:39:47.741549
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _ = UDNEmbedIE()

# Generated at 2022-06-12 18:39:54.122735
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.suitable("https://video.udn.com/embed/news/300040")
    assert ie.suitable("https://video.udn.com/play/news/300040")
    assert not ie.suitable("https://video.udn.com")
    assert not ie.suitable("https://video.udn.com/news/300040")



# Generated at 2022-06-12 18:39:55.934771
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('testid')
    assert ie._match_id('testid') is not None

# Generated at 2022-06-12 18:40:00.779533
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE('UDNEmbed', '聯合影音')

# Generated at 2022-06-12 18:40:02.000503
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE)

# Generated at 2022-06-12 18:40:09.446786
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the constructor of UDNEmbedIE
    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:40:24.422604
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    x = UDNEmbedIE()

# unit test for the regex of video urls

# Generated at 2022-06-12 18:40:27.884058
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        ie = UDNEmbedIE({})
    except:
        assert False
    else:
        assert ie.IE_DESC == '聯合影音'


# Generated at 2022-06-12 18:40:30.855998
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    UDNEmbedIE()._real_initialize()
    UDNEmbedIE()._real_extract(url)

# Generated at 2022-06-12 18:40:36.127511
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    obj = ie.ie_key()
    obj.update({'ie_key': 'UDNEmbed'})
    assert ie.ie_key() == obj


# Generated at 2022-06-12 18:40:45.085838
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    udne_ie = UDNEmbedIE()
    ie_result = udne_ie._real_extract(url)
    print(ie_result)
    assert ie_result['id'] == '300040'
    assert ie_result['title'] == '生物老師男變女 全校挺"做自己"'
    assert ie_result['thumbnail'] == 'http://video.udn.com/news/300040/1/storyboard5_5.jpg'

test_UDNEmbedIE()

# Generated at 2022-06-12 18:40:52.239133
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import re

    url = 'https://video.udn.com/embed/news/300040'
    url_re = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    valid_url = r'https?:' + url_re

    r = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert re.match(r, url).group('id') == '300040'
    assert r == url_re

    r = UDNEmbedIE._VALID_URL
    assert re.match(r, url).group('id') == '300040'
    assert r == valid_url

# Generated at 2022-06-12 18:40:59.966589
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE(url)
    ie.IE_DESC = '聯合影音'
    assert ie.IE_NAME == 'udn_embed'
    web = ie.extract()
    assert web.get('id') == '300040'
    assert web.get('formats')[0].get('height') >= 360

# Generated at 2022-06-12 18:41:03.356678
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnembed_ie = UDNEmbedIE()
    assert udnembed_ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:41:06.291004
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:41:19.233159
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	info_extractor_class_constructor = InfoExtractor.__new__(UDNEmbedIE)
	assert(info_extractor_class_constructor.IE_NAME == "udn")
	assert(info_extractor_class_constructor.IE_DESC == "聯合影音")
	assert(info_extractor_class_constructor._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')
	assert(info_extractor_class_constructor._VALID_URL == r'https?:' + info_extractor_class_constructor._PROTOCOL_RELATIVE_VALID_URL)

	# Test _real_extract function with url: http://video.udn.

# Generated at 2022-06-12 18:41:48.642881
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('UDNEmbedIE')
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:41:54.079125
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    result = obj._real_extract(obj._TESTS[0]['url'])
    #print(result['formats'][0]['url'])
    assert result['id'] == obj._TESTS[0]['info_dict']['id']
    assert result['thumbnail'] == obj._TESTS[0]['info_dict']['thumbnail']
    assert result['title'] == obj._TESTS[0]['info_dict']['title']

# Generated at 2022-06-12 18:41:55.376432
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    c = UDNEmbedIE()
    assert c is not None

# Generated at 2022-06-12 18:41:56.653304
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:42:04.015281
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    info = ie.extract(url)
    assert info['id'] == '300040'
    assert len(info['formats']) > 0
    assert info['title'] is not None
    assert info['thumbnail'] is not None

# Unit Test for _real_extract of class UDNEmbedIE

# Generated at 2022-06-12 18:42:07.011721
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE().working_instances()[0]
    assert ie._match_id(test_url) == '300040'

# Generated at 2022-06-12 18:42:12.740227
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	# Test 1
	url = 'http://video.udn.com/embed/news/300040'
	udn = UDNEmbedIE()
	assert udn.suitable(url) == True
	assert udn.IE_NAME == 'udn'
	assert udn.IE_DESC == '聯合影音'
	
	# Test 2
	url = 'https://video.udn.com/embed/news/300040'
	udn = UDNEmbedIE()
	assert udn._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
	assert udn._VALID_URL == r'https?:' + udn._PROTOCOL_RELATIVE_VAL

# Generated at 2022-06-12 18:42:26.783248
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        int_or_none,
        js_to_json,
    )
    from ..compat import compat_urlparse

    test_instance = UDNEmbedIE()

    assert(test_instance.IE_DESC == '聯合影音')
    assert(test_instance._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)")

    test_url = 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:42:29.687736
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        temp_udn_embed = UDNEmbedIE()
    except:
        print("Error during initialization of class UDNEmbedIE")
        assert False


# Generated at 2022-06-12 18:42:35.365287
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    assert udne._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:43:39.649306
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create an instance of UDNEmbedIE
    udnVideo = UDNEmbedIE()
    # Create a fake url
    url = 'http://video.udn.com/embed/news/300040'
    # Test the function _match_id
    assert(udnVideo._match_id(url) == '300040')
    # Test the function _real_extract
    assert(udnVideo._real_extract(url)['title'] == '生物老師男變女 全校挺"做自己"')
    # Test an exception in _html_search_regex
    # A fake webpage
    webpage = 'Fake webpage'
    # The exception raised should be "RegexNotFoundError"

# Generated at 2022-06-12 18:43:42.827988
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    unit_test = UDNEmbedIE()._real_extract(url)
    assert unit_test['id'] == '300040'
    assert unit_test['title'] == '生物老師男變女 全校挺"做自己"'
    assert unit_test['thumbnail'] == 'https://i.imgur.com/N4p4w4J.jpg'

# Generated at 2022-06-12 18:43:46.839332
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    # valid URL
    assert ie._match_id(ie._VALID_URL) == '300040'
    # valid URL but with different protocol
    assert ie._match_id(ie._VALID_URL.replace('https:', 'http:')) == '300040'

# Generated at 2022-06-12 18:43:53.123371
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:43:55.304377
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    try:
        UDNEmbedIE()
    except Exception as e:
        print("Exception: %s" % e)
        assert False
    assert True


# Generated at 2022-06-12 18:43:57.547160
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = 'http://video.udn.com/embed/news/300040'
    assert ie.suitable(url) == True
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'



# Generated at 2022-06-12 18:43:59.138512
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    data = UDNEmbedIE()._download_json(
        'https://video.udn.com/videoapi/getscript/{',
        'video source')
    assert data is not None
    assert len(data) > 0

# Generated at 2022-06-12 18:43:59.891537
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert(UDNEmbedIE.IE_NAME == 'UDNEmbedIE')

# Generated at 2022-06-12 18:44:09.246717
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Create a new instance of class UDNEmbedIE
    udne = UDNEmbedIE()
    # Test the _match_id function in class UDNEmbedIE
    assert udne._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert udne._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert udne._match_id('https://video.udn.com/embed/news/300040') == '300040'
    assert udne._match_id('http://video.udn.com/play/news/300040') == '300040'

# Generated at 2022-06-12 18:44:13.164377
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # test inherited abstract class,
    # just not to throw exception
    try:
        (UDNEmbedIE())
    except Exception as e:
        print (e)
        assert True
    else:
        assert True

# Generated at 2022-06-12 18:46:39.735036
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert re.match(ie._VALID_URL, 'http://video.udn.com/embed/news/300040') is not None
    assert re.match(ie._VALID_URL, 'https://video.udn.com/embed/news/300040') is not None
    assert re.match(ie._VALID_URL, 'https://video.udn.com/play/news/300040') is not None
    assert re.match(ie._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/play/news/300040') is not None

# Generated at 2022-06-12 18:46:41.038499
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:46:46.867417
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_udnyt_ie = UDNEmbedIE('udn')
    print('test_udnyt_ie.IE_NAME = %s' % test_udnyt_ie.IE_NAME)
    print('test_udnyt_ie.IE_DESC = %s' % test_udnyt_ie.IE_DESC)
    print('test_udnyt_ie._VALID_URL = %s' % test_udnyt_ie._VALID_URL)

# Generated at 2022-06-12 18:46:57.944910
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert isinstance(UDNEmbedIE._TESTS, list)
    assert UDNEmbedIE._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._TESTS[0]['info_dict']['id'] == '300040'
    assert UDNE

# Generated at 2022-06-12 18:47:03.708864
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # testing if an error raises when an invalid URL is given
    test_valid_url = 'https://video.udn.com/embed/news/300040'
    test_invalid_url = 'https://video.udn.com/embed/news/'
    assert(UDNEmbedIE().suitable(test_valid_url) is True)
    assert(UDNEmbedIE().suitable(test_invalid_url) is False)

# Generated at 2022-06-12 18:47:04.826317
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test constructor of UDNEmbedIE class
    UDNEmbedIE(None)

# Generated at 2022-06-12 18:47:06.209551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:47:09.910778
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    obj.IE_NAME
    obj.IE_DESC
    obj._VALID_URL
    obj.IE_DESC


# Generated at 2022-06-12 18:47:19.055907
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    udn_embed = UDNEmbedIE()
    assert(udn_embed.IE_DESC.encode('utf-8') == b'\xe8\x81\xaf\xe5\x90\x88\xe5\xbd\xb1\xe9\x9f\xb3')
    info_dict = udn_embed._real_extract(url)
    assert(info_dict['id'] == '300040')
    assert(info_dict['ext'] == 'mp4')
    assert(info_dict['title'] == u'生物老師男變女 全校挺"做自己"')

# Generated at 2022-06-12 18:47:19.813441
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE