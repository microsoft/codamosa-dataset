

# Generated at 2022-06-12 18:38:39.351164
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    cases = [
        ('//video.udn.com/embed/news/300040', '300040'),
        ('http://video.udn.com/embed/news/300040', '300040'),
        ('https://video.udn.com/embed/news/300040', '300040'),
        ('http://video.udn.com/play/news/300040', '300040'),
        ('https://video.udn.com/play/news/300040', '300040'),
        ('https://video.udn.com/news/300040', None),
    ]

    ie = UDNEmbedIE()
    for url, expected_video_id in cases:
        assert ie.suitable(url)
        match = ie._VALID_URL_RE.search(url)
        assert match.group('id')

# Generated at 2022-06-12 18:38:40.468381
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()

# Generated at 2022-06-12 18:38:46.141998
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    import sys
    import os

    if sys.version_info >= (3, 0):
        assert not os.system('python3 -m unittest -q test.test_UDNEmbedIE')
    else:
        raise NotImplementedError('Unit test deprecated in python2')

# Generated at 2022-06-12 18:38:54.692282
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:38:58.562730
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	assert "udn" in UDNEmbedIE.ie_keywords()
	assert "UDNEmbedIE" in InfoExtractor._available_ies
	assert UDNEmbedIE.ie_keywords() == ()

# Generated at 2022-06-12 18:39:10.071552
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    test constructor of class UDNEmbedIE
    """
    # test protocol relative URL
    udn_embed_ie = UDNEmbedIE(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL)
    assert udn_embed_ie._VALID_URL == UDNEmbedIE._VALID_URL

    # test http URL
    udn_embed_ie = UDNEmbedIE(UDNEmbedIE._VALID_URL)
    assert udn_embed_ie._VALID_URL == UDNEmbedIE._VALID_URL

# Generated at 2022-06-12 18:39:13.502460
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:39:24.572760
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.IE_NAME == 'udn_embed'
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-12 18:39:36.164603
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # This is a test for constructor of class UDNEmbedIE
    # Input:
    #   - none
    # Expectation:
    #   1. Create an instance of UDNEmbedIE
    #   2. The IE_DESC should be "聯合影音"
    #   3. _VALID_URL should match the pattern of valid URL
    ie_inst = UDNEmbedIE()
    assert ie_inst.IE_DESC == '聯合影音'
    assert re.compile(ie_inst._VALID_URL).match('https://video.udn.com/embed/news/300040') == None

# Generated at 2022-06-12 18:39:38.628043
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    print(UDNEmbedIE("http://video.udn.com/embed/news/300040"))



# Generated at 2022-06-12 18:39:54.524024
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_url = 'https://video.udn.com/embed/news/300040'
    udnEmbed = UDNEmbedIE().working_class(test_url)
    assert isinstance(udnEmbed, UDNEmbedIE)

# Generated at 2022-06-12 18:40:00.658942
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test UDN video from https://video.udn.com/news/303776
    udn_video_url = 'https://video.udn.com/play/news/303776'
    video_id = UDNEmbedIE._match_id(udn_video_url)
    ie = UDNEmbedIE(udn_video_url)
    assert ie._real_extract(udn_video_url) == \
        ie._real_extract(ie._VALID_URL % {'id': video_id})

# Generated at 2022-06-12 18:40:06.503525
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE("http://video.udn.com/udnplayer/iframe/news/300040")
    assert ie.IE_DESC == "聯合影音"
    query = (ie.IE_NAME, ie.IE_DESC, ie.VALID_URL)
    assert query == ("UDNEmbed", "聯合影音", "http://video.udn.com/udnplayer/iframe/news/300040")

# Generated at 2022-06-12 18:40:06.955040
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    pass

# Generated at 2022-06-12 18:40:10.878557
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    class_ = globals()['UDNEmbedIE']
    instance = class_()
    # class_name
    assert instance.IE_DESC == '聯合影音'
    # valid_url
    assert instance._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:40:13.018263
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnei = UDNEmbedIE()
    assert udnei.IE_NAME == 'udn'
    assert udnei.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:40:13.971834
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert type(UDNEmbedIE()) is UDNEmbedIE


# Generated at 2022-06-12 18:40:21.934356
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn.com:video'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-12 18:40:32.694327
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    with open('test_data/test_udn_video.html','r') as f:
        result = udn._real_extract(url=None, webpage=f.read())

# Generated at 2022-06-12 18:40:43.107577
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(UDNEmbedIE.create_ie())
    for url in [
        'http://video.udn.com/embed/news/300040',
        'https://video.udn.com/embed/news/300040',
    ]:
        assert ie.suitable(url)
        assert ie.IE_NAME == 'udn'
        assert ie._WORKING == True
        assert ie._VALID_URL == ie._VALID_URL

    ie = UDNEmbedIE._build_ie(UDNEmbedIE.ie_key())
    assert ie.suitable('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:40:58.936151
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'



# Generated at 2022-06-12 18:41:02.340970
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    assert IE.ie_key() == 'udn'
    assert IE.ie_desc() == '聯合影音'

# Generated at 2022-06-12 18:41:12.997144
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    testTarget = UDNEmbedIE()
    assert testTarget.IE_DESC == '聯合影音'
    assert testTarget._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert testTarget._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert testTarget._TESTS[0]['info_dict'] == {'id': '300040', 'ext': 'mp4', 'title': '生物老師男變女 全校挺"做自己"', 'thumbnail': 're:^https?://.*\\.jpg$'}
    assert testTarget._TES

# Generated at 2022-06-12 18:41:18.193449
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from .common import InfoExtractor


# Generated at 2022-06-12 18:41:25.435717
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """Unit test for class UDNEmbedIE"""

    import os
    import json
    import tempfile
    import unittest
    import sys
    import youtube_dl
    import youtube_dl.utils

    test_cases = [(
        'https://video.udn.com/embed/news/300040',
        {
            'id': '300040',
            'ext': 'mp4',
            'title': '生物老師男變女 全校挺"做自己"',
            'thumbnail': r're:^https?://.*\.jpg$',
        },
    )]
    if sys.version_info >= (3, 0):
        for test_case in test_cases:
            test_case[0] = test_case[0].en

# Generated at 2022-06-12 18:41:34.403187
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE()
    assert obj._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._match_id(url) == '300040'
    assert obj._real_extract(url)['id'] == '300040'



# Generated at 2022-06-12 18:41:45.149853
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    i = UDNEmbedIE()
    # Test for _PROTOCOL_RELATIVE_VALID_URL
    assert i._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Test for _VALID_URL
    assert i._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

    # Test for _TESTS
    assert i._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert i._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-12 18:41:51.608986
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Given
    url = 'http://video.udn.com/embed/news/300040'
    # When
    udn_embed_ie = UDNEmbedIE()
    # Then
    assert udn_embed_ie.IE_DESC == '聯合影音'
    assert udn_embed_ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'


# Generated at 2022-06-12 18:41:54.078739
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:07.154009
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # 1: Test url_result method
    url = 'https://video.udn.com/embed/news/300040'
    url_id = UDNEmbedIE._match_id(url)
    assert url_id == '300040', 'Unit test failed!'
    # 2: Test _real_extract method
    url = 'http://video.udn.com/embed/news/300040'
    url_id = UDNEmbedIE._match_id(url)
    webpage = UDNEmbedIE._download_webpage(url, url_id)
    options_str = UDNEmbedIE._html_search_regex(
            r'var\s+options\s*=\s*([^;]+);', webpage, 'options')

# Generated at 2022-06-12 18:42:40.845788
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    fakeurl = 'http://video.udn.com/embed/news/300040'
    match = re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, fakeurl)
    video_id = match.group('id')
    fakeIE = UDNEmbedIE({})
    assert(fakeIE.IE_NAME == 'udn')
    assert(match.group('id') == video_id)
    match = re.match(UDNEmbedIE._VALID_URL, fakeurl)
    assert(match)

# Generated at 2022-06-12 18:42:45.302048
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_DESC == '聯合影音'


if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:42:47.842717
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import structured_dict
    try:
        UDNEmbedIE(None)
    except Exception as e:
        pass
    else:
        assert False, 'Expecting Exceptino'

# Generated at 2022-06-12 18:42:54.077330
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(None)
    udn_embed_match_protocol_relative_url = re.compile(ie._PROTOCOL_RELATIVE_VALID_URL)
    udn_embed_match_absolute_url = re.compile(ie._VALID_URL)
    assert udn_embed_match_absolute_url.search('https://video.udn.com/embed/news/300040') is not None
    assert udn_embed_match_protocol_relative_url.search('//video.udn.com/embed/news/300040') is not None

# Generated at 2022-06-12 18:43:04.513664
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:43:06.508922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE()._download_webpage(url, '300040')

# Generated at 2022-06-12 18:43:11.541942
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE_DESC = '聯合影音'
    _PROTOCOL_RELATIVE_VALID_URL = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    _VALID_URL = r'https?:' + _PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:43:18.910704
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # pylint: disable=line-too-long,redefined-outer-name
    from .common import InfoExtractor
    from .youtube import YoutubeIE
    from .brightcove import BrightcoveLegacyIE
    from .theplatform import ThePlatformIE

    assert(issubclass(UDNEmbedIE, InfoExtractor))
    assert(issubclass(UDNEmbedIE, YoutubeIE))
    assert(issubclass(UDNEmbedIE, BrightcoveLegacyIE))
    assert(issubclass(UDNEmbedIE, ThePlatformIE))

# Generated at 2022-06-12 18:43:28.718680
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'
    assert ie._TESTS[0]['info_dict']['id'] == '300040'

# Generated at 2022-06-12 18:43:36.890933
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\\d+)'
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:44:45.195948
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test_obj = UDNEmbedIE()
    assert test_obj.ie_key() == 'UDNEmbed'
    assert test_obj.ie_desc() == '聯合影音'

# Generated at 2022-06-12 18:44:52.057064
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    ie = UDNEmbedIE()
    assert ie._match_id(url) == '300040'

# Generated at 2022-06-12 18:44:54.586082
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    IE = UDNEmbedIE()
    IE._real_extract(url)

# Generated at 2022-06-12 18:45:02.163396
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..utils import ExtractorError
    from nose.tools import assert_raises
    from nose.tools import assert_equal

    UDNEmbedIE = UDNEmbedIE()

    # test valid url
    assert_equal(UDNEmbedIE._match_id(compat_urlparse.urlparse('http://video.udn.com/embed/news/300040')),'300040')

    # test invalid url
    assert_raises(ExtractorError,UDNEmbedIE._match_id,compat_urlparse.urlparse('http://video.udn.com/embed/news'))

# Generated at 2022-06-12 18:45:05.490700
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert ie.search_regex == re.compile(r'var\s+options\s*=\s*([^;]+);')

# Generated at 2022-06-12 18:45:06.833325
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    instance = UDNEmbedIE()
    assert instance.ie_key() == 'UDNEmbed'

# Generated at 2022-06-12 18:45:14.371087
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    cases = [{
        'url': 'http://video.udn.com/embed/news/300040',
        'id': '300040',
        'title': '生物老師男變女 全校挺"做自己"',
    }, {
        'url': 'https://video.udn.com/embed/news/300040',
        'id': '300040',
        'title': '生物老師男變女 全校挺"做自己"',
    }]
    c = UDNEmbedIE()
    for case in cases:
        r = c.url_result(case['url'])
        assert r.ie_key() == c.ie_key()

# Generated at 2022-06-12 18:45:19.753056
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()
    ie = udne._get_info_extractor()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == udne._VALID_URL
    assert ie._TESTS == udne._TESTS
    assert ie._download_webpage == udne._download_webpage

# Generated at 2022-06-12 18:45:24.469365
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE(None)
    assert udne.IE_DESC == '聯合影音'

    # test valid url
    url = 'http://video.udn.com/embed/news/300040'
    assert udne._VALID_URL == 'https?:' + udne._PROTOCOL_RELATIVE_VALID_URL
    assert udne.suitable(url) == True
    assert udne.IE_NAME == 'udn'

# Generated at 2022-06-12 18:45:26.878386
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_set = ['http://video.udn.com/embed/news/300040', '//video.udn.com/embed/news/300040', 'https://video.udn.com/embed/news/300040']
    for url in url_set:
        assert UDNEmbedIE._match_id(url) == '300040'

# Generated at 2022-06-12 18:48:12.047876
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._VALID_URL == 'https?://video.udn.com/(?:embed|play)/news/(?P<id>\\d+)'

# Generated at 2022-06-12 18:48:15.812374
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE(GetTitleIE, {})
    assert ie.name == 'GetTitle'


# Generated at 2022-06-12 18:48:23.127004
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn_embed_ie = UDNEmbedIE()
    assert udn_embed_ie.ie_key() == 'UDNEmbed'
    assert udn_embed_ie.ie_desc() == '聯合影音'
    assert udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert udn_embed_ie._VALID_URL == r'https?:' + udn_embed_ie._PROTOCOL_RELATIVE_VALID_URL