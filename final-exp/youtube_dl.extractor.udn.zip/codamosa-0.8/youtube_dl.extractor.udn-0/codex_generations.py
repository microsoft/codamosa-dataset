

# Generated at 2022-06-12 18:38:34.188110
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD, IsolatedFD
    fd = FileDownloader()
    udne = fd.udne_ie
    # Test protocol-relative url, should be accepted
    assert udne.suitable('//video.udn.com/embed/news/300040')
    # Test HTTPS url, should be accepted
    assert udne.suitable(
        'https://video.udn.com/embed/news/300040')
    # Test HTTP url, should be accepted
    assert udne.suitable(
        'http://video.udn.com/embed/news/300040')
    # Test non-accepted protocol-relative url, should be rejected

# Generated at 2022-06-12 18:38:40.686270
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udne = UDNEmbedIE()

    assert(udne.IE_NAME == 'udn')
    assert(udne.IE_DESC == '聯合影音')

    assert(udne._VALID_URL.startswith('https?:'))
    assert(udne._VALID_URL.endswith(udne._PROTOCOL_RELATIVE_VALID_URL))
    assert(len(udne._TESTS) == 3)

# Generated at 2022-06-12 18:38:45.723735
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    if (ie.IE_DESC is None):
        print("Invalid value of the IE_DESC")
        return False;
    if (ie._VALID_URL is None):
        print("Invalid value of the _VALID_URL")
        return False;
    if (ie._TESTS is None):
        print("Invalid value of the _TESTS")
        return False;
    return True;


# Generated at 2022-06-12 18:38:54.458373
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    base_url = "http://tw.udn.com/news/story/6974/303776"

# Generated at 2022-06-12 18:38:56.072867
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert obj.IE_NAME == 'udn'

# Generated at 2022-06-12 18:39:04.670223
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test valid url
    url = 'https://video.udn.com/embed/news/300040'
    assert UDNEmbedIE().suitable(url)
    assert UDNEmbedIE().IE_NAME == 'udn.com:embed'
    assert UDNEmbedIE().IE_DESC == '聯合影音'

    # Test invalid url
    url = 'https://video.udn.com/p/300040'
    assert not UDNEmbedIE().suitable(url)


if __name__ == '__main__':
    # Unit test
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:39:17.624808
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    default_config = "{'youtube_include_dash_manifest': True, 'hls_prefer_native': True, 'hds_prefer_native': True, 'f4m_prefer_native': True, 'prefer_free_formats': True}"
    udnembedie = UDNEmbedIE()
    assert(type(udnembedie) == UDNEmbedIE)
    assert(udnembedie.IE_NAME == 'udn')
    assert(udnembedie.IE_DESC == '聯合影音')
    assert(udnembedie.ie_key() == 'UDNEmbed')

# Generated at 2022-06-12 18:39:19.376915
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    obj = UDNEmbedIE()
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-12 18:39:20.809399
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:39:26.680432
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:39:44.477970
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL = p = r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    UDNEmbedIE._VALID_URL = v = r'https?:' + p

# Generated at 2022-06-12 18:39:47.114021
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    test = UDNEmbedIE()
    test._real_extract('https://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:39:50.027531
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIEClass = UDNEmbedIE
    UDNEmbedIEClass('http://video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:39:58.237389
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    obj = UDNEmbedIE()
    assert obj._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._PROTOCOL_RELATIVE_VALID_URL == '//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert obj._match_id(url) == '300040'

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:40:02.985032
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Test constructor of class UDNEmbedIE
    """
    url = 'http://video.udn.com/embed/news/300040'
    return [UDNEmbedIE()._match_id(url)]

if __name__ == '__main__':
    print(test_UDNEmbedIE())

# Generated at 2022-06-12 18:40:05.471063
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE({})
    assert ie is not None
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:40:11.284902
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    """
    Unit test for class UDNEmbedIE
    """
    assert(UDNEmbedIE().suitable('https://video.udn.com/play/news/300040'))
    assert(UDNEmbedIE().suitable('https://video.udn.com/embed/news/300040'))
    assert(UDNEmbedIE().suitable('//video.udn.com/embed/news/300040'))
    assert(not UDNEmbedIE().suitable('https://video.udn.com/news/300040'))
    assert(not UDNEmbedIE().suitable('https://video.udn.com/play/news/300040/playlist/news'))


# Generated at 2022-06-12 18:40:13.831757
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'UDNEmbed'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:40:17.166000
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE(UDNEmbedIE.IE_NAME, UDNEmbedIE.IE_DESC)

if __name__ == "__main__":
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:40:21.594922
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, '_VALID_URL')
    assert isinstance(ie._VALID_URL, str)
    assert ie._VALID_URL.startswith('https?://')

# Generated at 2022-06-12 18:40:44.995432
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:40:54.263167
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    info_extractor = UDNEmbedIE()
    assert info_extractor._VALID_URL == "https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert info_extractor._PROTOCOL_RELATIVE_VALID_URL == "//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)"
    assert info_extractor.IE_DESC == "聯合影音"

# Generated at 2022-06-12 18:40:57.793988
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
	ie = UDNEmbedIE()
	assert (ie._VALID_URL == 'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)')

# Generated at 2022-06-12 18:41:05.101200
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    url = "http://video.udn.com/embed/news/300040"
    # Must raise error
    with pytest.raises(RegexNotFoundError):
        ie._match_id("gibberish")
    with pytest.raises(RegexNotFoundError):
        ie._real_extract("gibberish")
    # Should return expected result
    assert ie._match_id(url) == "300040"

# Generated at 2022-06-12 18:41:12.166366
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    try:
        assert ie.IE_DESC == '聯合影音'
        assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
        assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
        assert len(ie._TESTS) == 3
    finally:
        ie = None

# Generated at 2022-06-12 18:41:18.037610
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Just test whether the constructor of class UDNEmbedIE would raise an exception or not
    # because the extract method of class UDNEmbedIE is not an unit test and the behavior of
    # the extract method is not guaranteed.
    ie = UDNEmbedIE()

if __name__ == '__main__':
    test_UDNEmbedIE()

# Generated at 2022-06-12 18:41:19.287577
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test the basic feature of constructor
    UDNEmbedIE()

# Generated at 2022-06-12 18:41:23.407368
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(UDNEmbedIE.create_ie('UDNEmbedIE')).ie_key() == 'UDNEmbed'

# Generated at 2022-06-12 18:41:34.620653
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    for item in UDNEmbedIE._TESTS:
        udn_ie = UDNEmbedIE()
        if item.get('only_matching', False):
            from ..compat import (
                compat_urllib_parse_urlparse,
            )
            url = re.match(UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL, item['url']).group('url')
            res = udn_ie._VALID_URL(compat_urllib_parse_urlparse(url))
            assert res == True
        else:
            url = item['url']
            video_id = udn_ie._match_id(url)
            page = udn_ie._download_webpage(url, video_id)
            options_str = udn_ie._html_search_

# Generated at 2022-06-12 18:41:38.606074
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = "http://video.udn.com/embed/news/300040"

    rtnObj = UDNEmbedIE()._real_extract(url)
    assert rtnObj['id'] == '300040'
    assert rtnObj['thumbnail']
    assert rtnObj['title']
    assert rtnObj['formats']

    assert rtnObj['formats'][0]['url']
    assert rtnObj['formats'][0]['format_id']

    assert rtnObj['formats'][2]['height']
    assert rtnObj['formats'][2]['tbr']

# Generated at 2022-06-12 18:42:09.104310
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url_pattern = UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    url_prefix = 'https://'

    assert re.match(url_pattern, '//video.udn.com/embed/news/300040') is not None
    assert re.match(url_pattern, '//video.udn.com/play/news/300040') is not None
    assert re.match(url_pattern, 'https://video.udn.com/embed/news/300040') is not None
    assert re.match(url_pattern, 'https://video.udn.com/play/news/300040') is not None

# Generated at 2022-06-12 18:42:12.326377
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE("https://video.udn.com/play/news/300303")
    assert (udn is not None)


# Generated at 2022-06-12 18:42:26.352061
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:42:28.166466
# Unit test for constructor of class UDNEmbedIE

# Generated at 2022-06-12 18:42:40.952865
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    valid_url = UDNEmbedIE._VALID_URL
    assert UDNEmbedIE._VALID_URL == 'https?:(?://video\.udn\.com/embed/news/|//video\.udn\.com/play/news/)(?P<id>\d+)'
    assert re.match(valid_url, 'http://video.udn.com/embed/news/300040')
    assert re.match(valid_url, 'https://video.udn.com/embed/news/300040')
    assert re.match(valid_url, 'https://video.udn.com/play/news/300040')
    assert re.match(valid_url, '//video.udn.com/embed/news/300040')

# Generated at 2022-06-12 18:42:46.742091
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:42:54.803957
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    ie = UDNEmbedIE()
    ie.get_entry(url)
    assert ie.extractor_key() == 'UdnEmbedIE'
    assert ie.extractor_key(url) == 'UdnEmbedIE'
    assert ie.extractor_key(url, True) == 'UdnEmbedIE'

    # From https://video.udn.com/news/303776
    url = 'https://video.udn.com/play/news/303776'
    ie = UDNEmbedIE()
    ie.get_entry(url)
    assert ie.extractor_key() == 'UdnEmbedIE'
    assert ie.extractor_key(url) == 'UdnEmbedIE'


# Generated at 2022-06-12 18:42:57.934013
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_NAME == 'udn'
    assert ie.IE_DESC == '聯合影音'

# Generated at 2022-06-12 18:43:06.789106
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    __import__('sys').modules['src.scrape.compat.compat_urllib_parse_urlparse'] = compat_urlparse
    __import__('sys').modules['src.scrape.compat.compat_urllib_parse_urljoin'] = compat_urlparse.urljoin
    __import__('sys').modules['src.scrape.compat.compat_urllib_request_Request'] = compat_request
    __import__('sys').modules['src.scrape.compat.compat_urlib_error_HTTPError'] = compat_request.HTTPError
    __import__('sys').modules['src.scrape.compat.compat_urllib_error_URLError'] = compat_request.URLError

# Generated at 2022-06-12 18:43:14.587377
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE()._match_id('http://video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE()._match_id('//video.udn.com/embed/news/300040') == '300040'
    assert UDNEmbedIE()._match_id('https://video.udn.com/embed/news/300040') == '300040'

# Generated at 2022-06-12 18:44:21.288393
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE().IE_NAME == 'udn'

# Generated at 2022-06-12 18:44:26.996406
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL

# Generated at 2022-06-12 18:44:31.944435
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Test when url is 'http://video.udn.com/embed/news/300040',
    # if return a object whose type is a UDNEmbedIE
    obj = UDNEmbedIE('http://video.udn.com/embed/news/300040')
    assert (isinstance(obj, UDNEmbedIE))


# Generated at 2022-06-12 18:44:43.147482
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udn = UDNEmbedIE()
    video_id = '300040'

    mo = re.match(udn._VALID_URL, 'https://video.udn.com/embed/news/300040')
    assert mo != None
    assert udn._match_id(mo) == video_id

    mo = re.match(udn._VALID_URL, 'http://video.udn.com/embed/news/300040')
    assert mo != None
    assert udn._match_id(mo) == video_id

    mo = re.match(udn._PROTOCOL_RELATIVE_VALID_URL, '//video.udn.com/embed/news/300040')
    assert mo != None
    assert udn._match_id(mo) == video_id

# Generated at 2022-06-12 18:44:47.308462
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'

# Generated at 2022-06-12 18:44:56.998358
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    _test_UDNEmbedIE = UDNEmbedIE()
    # Test _PROTOCOL_RELATIVE_VALID_URL: http:http://video.udn.com/embed/news/300040
    assert _test_UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test _VALID_URL: https://video.udn.com/embed/news/300040
    assert _test_UDNEmbedIE._VALID_URL == r'https?:' + r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # Test _TESTS: [{'url': 'http://video.udn.com

# Generated at 2022-06-12 18:45:06.190941
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie.IE_DESC == '聯合影音'
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL
    assert ie._TESTS[0]['url'] == 'http://video.udn.com/embed/news/300040'

# Generated at 2022-06-12 18:45:08.275551
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnExtractor = UDNEmbedIE('https://video.udn.com/play/news/303776')
    assert(udnExtractor)

# Generated at 2022-06-12 18:45:09.113853
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    UDNEmbedIE()


# Generated at 2022-06-12 18:45:18.027827
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    # _VALID_URL != _PROTOCOL_RELATIVE_VALID_URL because of the prefix https?
    assert UDNEmbedIE._VALID_URL != UDNEmbedIE._PROTOCOL_RELATIVE_VALID_URL
    assert url == 'http://video.udn.com/embed/news/300040'
    assert UDNEmbedIE._VALID_URL == r'https?://video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert UDNEmbed

# Generated at 2022-06-12 18:47:53.075607
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    IE = UDNEmbedIE()
    return IE

# Generated at 2022-06-12 18:47:54.980918
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    assert UDNEmbedIE(UDNEmbedIE._downloader).IE_NAME == 'udn'

# Generated at 2022-06-12 18:47:57.052654
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    ie = UDNEmbedIE()
    assert ie._PROTOCOL_RELATIVE_VALID_URL == r'//video\.udn\.com/(?:embed|play)/news/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?:' + ie._PROTOCOL_RELATIVE_VALID_URL


# Generated at 2022-06-12 18:48:05.178313
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    # Correct url
    url = 'http://video.udn.com/embed/news/300040'
    udne = UDNEmbedIE()
    assert udne.suitable(url)
    assert udne.IE_NAME == 'UDNEmbed'
    assert udne.IE_DESC == '聯合影音'
    assert udne._VALID_URL.startswith('https?:')
    assert udne._VALID_URL.endswith('/\d+')
    assert udne._TESTS
    assert udne._TESTS[0]
    assert udne._TESTS[0]['url']
    assert udne._TESTS[0]['info_dict']

# Generated at 2022-06-12 18:48:07.716411
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    url = 'https://video.udn.com/embed/news/300040'
    UDNEmbedIE(url)

# Generated at 2022-06-12 18:48:17.975672
# Unit test for constructor of class UDNEmbedIE
def test_UDNEmbedIE():
    udnVideo = UDNEmbedIE()
    page = udnVideo._download_webpage("http://video.udn.com/embed/news/300040", "300040")
    options_str = udnVideo._html_search_regex(r'var\s+options\s*=\s*([^;]+);', page, 'options')
    trans_options_str = js_to_json(options_str)
    video_urls = udnVideo._parse_json(udnVideo._html_search_regex(r'"video"\s*:\s*({.+?})\s*,', trans_options_str, 'video urls'), 'video urls')