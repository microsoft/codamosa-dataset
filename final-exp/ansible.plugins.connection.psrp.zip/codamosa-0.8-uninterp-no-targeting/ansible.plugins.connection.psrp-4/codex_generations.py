

# Generated at 2022-06-21 04:20:21.682051
# Unit test for method put_file of class Connection
def test_Connection_put_file():
  c = Connection()
  ret = c.put_file(
    b_in_path = None,
    out_path = None,
    in_path = None,
    create_remote_dir = False,
    use_atomic_move = True,
    encoding = None,
    errors = None,
    follow = False,
    handle_unsuccessful_transfer = None,
    mode = None,
    owner = None,
  )
  assert ret == None


# Generated at 2022-06-21 04:20:28.728774
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    input_file = file_input('fetch_file_input')
    expected_output_file = file_output('fetch_file_expected_output')
    expected_output = expected_output_file.read()
    conn = Connection(**input_file['kwargs'])
    conn.runspace = conn._get_runspace()
    conn.fetch_file(**input_file['params'])
    out_file = open(input_file['params']['out_path'], 'r')
    output = out_file.read()
    out_file.close()
    assert output == expected_output
    os.remove(input_file['params']['out_path'])
    os.remove(input_file['params']['in_path'])
    
    

# Generated at 2022-06-21 04:20:41.775917
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create mock for Connection
    Connection = create_autospec(psrp.Connection, spec_set=True, instance=True)
    Connection._exec_psrp_script = Mock()

    # Create return values for Connection._exec_psrp_script
    rc = 0
    stdout = None
    stderr = None
    Connection._exec_psrp_script.return_value = (rc, stdout, stderr)

    # Create return values for Connection._build_exe_command
    exe_cmd = 'cmd'

    # Create return values for Connection.runspace_id
    runspace_id = 'tbd_runspace_id'

    # Create mock for ansible.module_utils.connection._exec_psrp_script
    _exec_psrp_script = Mock()

    # Create mock

# Generated at 2022-06-21 04:20:47.958266
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # This is a very simple test for method exec_command of class Connection,
    # we will compare the function output with the expected output

    result = Connection(play_context=PlayContext()).exec_command("echo 1")[0]
    assert result == 0



# Generated at 2022-06-21 04:20:49.226599
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()

# Generated at 2022-06-21 04:20:54.702875
# Unit test for constructor of class Connection
def test_Connection():

    psrp_connection = Connection(ConnectionInfo({'remote_addr': 'test_addr'}))

    assert psrp_connection._psrp_host == 'test_addr'
    assert psrp_connection._psrp_user == 'root'
    assert psrp_connection._psrp_pass == ''
    assert psrp_connection._psrp_protocol == 'https'
    assert psrp_connection._psrp_port == 5986
    assert psrp_connection._psrp_path == '/wsman'
    assert psrp_connection._psrp_auth == 'plaintext'
    assert psrp_connection._psrp_connection_timeout == 30
    assert psrp_connection._psrp_cert_validation is True
    assert psrp_connection._ps

# Generated at 2022-06-21 04:21:04.123176
# Unit test for method reset of class Connection
def test_Connection_reset():
    def get_transport_name_mock(self):
        raise RuntimeError
    def close_mock(self):
        pass
    def get_connection_mock(self):
        pass
    def get_psrp_version_mock(self):
        return "0.5.0"
    def get_module_path_mock(self):
        raise RuntimeError
    def get_module_version_string_mock(self):
        raise RuntimeError

    # Mock
    class MockConnection(Connection):
        get_transport_name = get_transport_name_mock
        close = close_mock
        get_connection = get_connection_mock
        get_psrp_version = get_psrp_version_mock
        get_module_path = get_module_path_mock

# Generated at 2022-06-21 04:21:16.188460
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    host = 'localhost'
    port = 5986
    use_ssl = True
    user = 'vagrant'
    password = 'vagrant'
    path = '/wsman'
    server_cert_validation = 'ignore'
    remote_addr = '192.168.56.101'
    port = 5986
    read_timeout = 30
    connection_timeout = 30
    message_encryption = 'always'
    max_envelope_size = 153600
    operation_timeout = 600

# Generated at 2022-06-21 04:21:18.651628
# Unit test for method close of class Connection
def test_Connection_close():
    _test_Connection = Connection()
    _test_Connection.runspace = None
    _test_Connection._connected = False
    _test_Connection._last_pipeline = None
    _test_Connection.close()

# Generated at 2022-06-21 04:21:24.016495
# Unit test for constructor of class Connection
def test_Connection():
    ansible_vars = AnsibleVars()
    psrp_conn = Connection(ansible_vars, 'psrp')
    # Test if create() of the base class is called
    assert(psrp_conn._connected is False)


# Generated at 2022-06-21 04:21:49.442115
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    con = Connection()

    # No error test
    try:
        con.put_file()
    except Exception as e:
        print("Error in put_file: %s" % e)
        assert False

    # Error test
    try:
        con.put_file('foo')
    except Exception as e:
        print("Error in put_file: %s" % e)
        assert False


# Generated at 2022-06-21 04:21:51.638057
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    assert connection.reset() is None



# Generated at 2022-06-21 04:21:55.065297
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection()
    assert conn is not None, "No Connection found"

# Generated at 2022-06-21 04:22:01.972426
# Unit test for constructor of class Connection
def test_Connection():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext

    host = Host(name="localhost")
    play_context = PlayContext()

    plugin = Connection('localhost', play_context, new_stdin=None)
    assert plugin._play_context == play_context
    assert plugin._connected == False
    assert plugin._psrp_host == 'localhost'
    assert plugin._psrp_protocol == 'https'
    assert plugin._psrp_port == 5986
    assert plugin._psrp_user == 'ansible'
    assert plugin._psrp_pass == ''
    assert plugin._psrp_auth == 'plaintext'
    assert plugin._psrp_path == 'wsman'
    assert plugin._psrp_read_timeout == None

# Generated at 2022-06-21 04:22:02.998355
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    c = Connection()
    print(c)

# Generated at 2022-06-21 04:22:06.198989
# Unit test for constructor of class Connection
def test_Connection():
    '''
    Unit test function to test the constructor

    :return:
    '''
    c = Connection(None)
    assert c is not None


# Generated at 2022-06-21 04:22:10.017145
# Unit test for method close of class Connection
def test_Connection_close():
    # Test the close method of class Connection
    # Unit test for method close of class Connection
    conn = Connection(None)
    conn.runspace = RunspacePool(None)
    conn.close()
    pass # left empty as exit in psrp class

# Generated at 2022-06-21 04:22:12.569878
# Unit test for method close of class Connection
def test_Connection_close():
    hostname = '127.0.0.1'
    connection = Connection(play_context=PlayContext(remote_addr=hostname))

    connection.close()

# Generated at 2022-06-21 04:22:22.349768
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()

# Generated at 2022-06-21 04:22:23.103221
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection()
    conn.reset('all')

# Generated at 2022-06-21 04:22:44.106557
# Unit test for method close of class Connection
def test_Connection_close():
    # Create an instance of Connection
    connection = Connection(play_context=play_context, new_stdin=None)
    # Attempt to close the Connection instance
    connection.close()



# Generated at 2022-06-21 04:22:51.392586
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup the mocks
    test_conn = "MOCK_CONNECTION"
    test_tmp = "MOCK_TMP"
    test_sudo_user = "MOCK_SUDO_USER"
    test_module_name = "MOCK_MODULE_NAME"
    test_module_args = "MOCK_MODULE_ARGS"
    test_task_vars = {}
    test_bash_wrapper = "MOCK_BASH_WRAPPER"
    test_tmp_path = "MOCK_TMP_PATH"
    test_encrypt = "MOCK_ENCRYPT"
    test_executable = None
    test_in_data = None

    # Construct the object that we want to test
    object_to_test = Connection(test_conn, test_task_vars)

   

# Generated at 2022-06-21 04:23:07.252203
# Unit test for method put_file of class Connection

# Generated at 2022-06-21 04:23:16.391574
# Unit test for constructor of class Connection
def test_Connection():
    from ansible.module_utils.psrp import Connection

# Generated at 2022-06-21 04:23:18.646789
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection()
    assert conn.reset() is None

# Generated at 2022-06-21 04:23:33.367834
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import pytest
    from unittest.mock import MagicMock, PropertyMock
    from ansible import context
    import ansible.module_utils.psrp

    def mock_open(data, encoding=None):
        return data

    def fake_get_option(option, *args, **kwargs):
        if option in AUTH_KWARGS['Negotiate']:
            return None
        if option.startswith('ansible_psrp_'):
            return option.replace('ansible_psrp_', '')
        return option


# Generated at 2022-06-21 04:23:34.743957
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection()


# Generated at 2022-06-21 04:23:46.597785
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    this_connection = Connection()
    this_connection.runspace = None
    this_connection._connected = False
    this_connection._last_pipeline = None
    this_connection.host = None
    this_connection._play_context = None

    this_connection.runspace = RunspacePool(hostname='127.0.0.1', username='username',
                                            password='password', port=5986, ssl=True,
                                            authentication='basic', connection_timeout=30,
                                            read_timeout=None, max_envelope_size=153600,
                                            operation_timeout=600, no_proxy=False,
                                            proxy=None)
    this_connection._connected = True
    this_connection.host = Host(this_connection.runspace)

    this_connection._play_

# Generated at 2022-06-21 04:23:47.965974
# Unit test for constructor of class Connection
def test_Connection():
    Connection('winrm://localhost:5985', 'changeme', 'ansible')

# Generated at 2022-06-21 04:23:55.911227
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    """
    fetch_file() with invalid parameters
    """

    params = dict()
    params['connection'] = dict(protocol='http', remote_addr='host.local', transport='psrp', port=5986, ssl=None, _extras=dict(), _ansible_verbosity=0, _ansible_debug=False, _ansible_socket_path=None, ca_cert='certificate')
    params['task_uuid'] = 'f4d4bc79-8480-4e06-a1a1-4988e9c3ee7b'
    params['task_vars'] = dict()
    params['task_vars']['ansible_connection'] = 'psrp'
    params['task_vars']['ansible_network_os'] = ''

# Generated at 2022-06-21 04:24:23.492634
# Unit test for method put_file of class Connection
def test_Connection_put_file():

    # Unit test for PSRP connection
    conn = Connection(
        'https://Test',
        30741,
        'Test',
        'Test')
    # Data from CreateFile.Modules.PSRP.test_Connection_put_file
    path = "Test"
    data = b"Test"
    try:
        conn.put_file(path, data)
    except AnsibleConnectionFailure as e:
        print(e)
        raise

# Generated at 2022-06-21 04:24:33.286154
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    path = u'/etc/ansible/hosts'
    with open(path, 'r') as in_file:
        with open('/tmp/ansible-tmp-test-file', 'w') as out_file:
            try:
                connection.put_file(
                    in_file, u'/tmp/ansible-tmp-test-file')
            finally:
                os.remove('/tmp/ansible-tmp-test-file')



# Generated at 2022-06-21 04:24:42.485122
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    test_connection = ConnectionClass()
    test_command = 'cmd'
    test_in_data = 'hello'
    test_binary = False
    ps = PowerShell(test_connection.runspace)
    ps.add_script(test_command)
    ps.invoke(input=test_in_data)
    test_connection._parse_pipeline_result(ps)
    test_connection.host.rc = 0
    test_connection.host.ui.stdout = []
    test_connection.host.ui.stderr = []
    return test_connection.exec_command(test_command, test_in_data, test_binary)

# Generated at 2022-06-21 04:24:46.588080
# Unit test for method reset of class Connection
def test_Connection_reset():
    host_name = 'localhost'
    protocol = 'http'
    port = 5985
    default_timeout = 30
    connection = Connection(host=host_name, port=port, protocol=protocol,
                            default_timeout=default_timeout)
    connection.set_options(timeout=60)
    assert connection.get_option('timeout') == 60
    connection.reset()
    assert connection.get_option('timeout') == default_timeout




# Generated at 2022-06-21 04:24:58.861058
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    """
    Verify that the fetch_file method of the Connection class works correctly
    """
    # arranges
    connection = Connection()
    in_path = 'some_in_path'
    out_path = 'some_out_path'
    buffer_size = 1024
    script_dir = 'some_script_dir'
    read_script = 'some_read_script'
    in_path_b64 = 'c29tZV9pbl9wYXRo'
    b_out_path = "b'c29tZV9vdXRfcGF0aA=='"
    read_script_exec = 'some_read_script_exec'
    data = 'some_data'
    data_b64 = 'c29tZV9kYXRh'
    stdout = 'some_stdout'
   

# Generated at 2022-06-21 04:24:59.848140
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()


# Generated at 2022-06-21 04:25:08.151763
# Unit test for constructor of class Connection
def test_Connection():
    psrp_conn = Connection(dict(remote_addr='127.0.0.1',
                                remote_user='ansible',
                                remote_password='ansible',
                                port=5986,
                                protocol='http',
                                path='/wsman',
                                auth='credssp',
                                cert_validation=False,
                                connection_timeout=30,
                                read_timeout=5,
                                message_encryption=True,
                                proxy=None,
                                ignore_proxy=True,
                                operation_timeout=3600,
                                max_envelope_size=153600,
                                reconnection_retries=3,
                                reconnection_backoff=3.0))

# Generated at 2022-06-21 04:25:16.869404
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conn = Connection_psrp()
    config = ConfigParser()
    config.read('ansible.cfg')
    in_path = config.get('defaults', 'remote_tmp') + '\\test1.txt'
    out_path = config.get('defaults', 'remote_tmp') + '\\test1.txt'
    conn.put_file(in_path, out_path)


# Generated at 2022-06-21 04:25:20.340842
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.put_file('./test/test_data/test_file.txt', './test/test_file.txt')
    assert os.path.exists(path='./test/test_file.txt')

# Generated at 2022-06-21 04:25:23.267857
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    '''
    AnsibleConnection.Connection fetch_file() method unit tests.
    '''
    # TODO: Need to add some unit tests for the fetch_file() method.


# Generated at 2022-06-21 04:26:24.508281
# Unit test for method put_file of class Connection
def test_Connection_put_file():
  class AnsibleModule(object):
      def __init__(self, args=None):
          self.params = args

  import stat
  # Test with non-exists src
  # Test with dir as path
  src = "non-exists-file"
  dest = "non-exists-file-dest"
  dest_tmp = dest + ".ansible-tmp"
  follow = True

# Generated at 2022-06-21 04:26:35.953219
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # unit test requires a live connection, so this will be a localhost test
    conn = Connection(play_context=play_context)
    conn._build_kwargs()
    rc, stdout, stderr = conn._exec_psrp_script("Get-Process")
    assert(rc == 0)
    assert(stdout is not None)
    assert(stderr is not None)

    rc, stdout, stderr = conn._exec_psrp_script("Get-Process -WTF")
    assert(rc == 1)
    assert(stdout is not None)
    assert(stderr is not None)

    conn = Connection(play_context=dict(verbosity=4))
    rc, stdout, stderr = conn._exec_psrp_script("Get-Process")

# Generated at 2022-06-21 04:26:40.273575
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conn = Connection(play_context=None, new_stdin=None)
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    plugin_loader = C.PluginLoader(
        '', '', C.DEFAULT_INVENTORY_PLUGINS_PATH, '', '', None
    )
    inventory = InventoryManager(loader=plugin_loader, sources=['localhost'])
    variable_manager = VariableManager(loader=plugin_loader, inventory=inventory)
    loader = DataLoader()

# Generated at 2022-06-21 04:26:46.369754
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Make a mock to test Connection.exec_command
    conn = Connection()
    from ansible.module_utils.powershell.psrp import PSRP
    conn.psrp = PSRP()
    conn.psrp._connected = True
    conn.psrp.runspace = RunspacePool()
    conn.psrp.runspace.state = RunspacePoolState.OPENED
    conn.psrp.runspace.id = 42

    # Test that the code runs without errors
    conn.exec_command('something')


# Generated at 2022-06-21 04:27:02.941169
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Initialize/setup parameters
    host = 'ansible_psrp'
    port = 5986
    user = 'ansible_user'
    password = 'ansible_pass'
    protocol = 'http'
    path = 'wsman'
    connection_timeout = 30
    read_timeout = 30
    message_encryption = False
    proxy = None
    ignore_proxy = False
    operation_timeout = 30
    connection_retries = None
    connection_retries_delay = 1
    max_envelope_size = 153600
    ca_cert = 'test/ansible_cert.pem'
    remote_addr = 'remote_addr'
    remote_user = 'remote_user'
    remote_password = 'remote_password'
    transport = 'http'

    # Mock input/returned value


# Generated at 2022-06-21 04:27:09.226909
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    in_path = "c:\\temp\\in.txt"
    out_path = "c:\\temp\\out.txt"
    buffer_size = 3
    write_script = "$stream = $fs.openWrite(\"%s\")\r\n" \
                   "$temp = $session.PSRP.Streams.CreateRamStream()\r\n" \
                   "$temp.Write([Convert]::FromBase64String(\"%s\"))\r\n" \
                   "while($temp.Length -gt 0){$stream.Write($temp.Read(%d))}\r\n" \
                   "$temp.Close()\r\n" \
                   "$stream.Close()"
    
    connection = Connection()
    connection.runspace = RunspacePool()

# Generated at 2022-06-21 04:27:14.671732
# Unit test for method reset of class Connection
def test_Connection_reset():
  connection = psrp_connection.Connection(play_context={})
  connection.play_context._play_context = {'become_method': 'sudo', 'become_user': 'root'}

  expected_output = connection.play_context
  expected_output._become_method = 'sudo'
  expected_output._become_user = 'root'
  actual_output = connection.reset()

  assert actual_output == expected_output



# Generated at 2022-06-21 04:27:26.886232
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    import mock
    import os.path

    test_dir = 'test'
    conn = Connection(None)
    conn.get_option = mock.Mock()
    conn.get_option.return_value = test_dir


    AnsibleModule = mock.Mock()
    module_args = dict(
        src=os.path.join(test_dir, 'a.txt'),
        dest='/tmp/a.txt'
    )
    AnsibleModule.params = mock.Mock()
    AnsibleModule.params.return_value = module_args
    myansible_module_get_connection = AnsibleModule()

    conn.put_file(
        module_args['src'],
        module_args['dest']
    )

# Generated at 2022-06-21 04:27:27.870810
# Unit test for method close of class Connection
def test_Connection_close():
    pass

# Generated at 2022-06-21 04:27:29.361419
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(None)

# Generated at 2022-06-21 04:29:06.640685
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection('host', 'user', 'password', 'psrp', 'port')

    connection._build_kwargs = MagicMock(return_value=None)
    connection.psrp_client = MagicMock(return_value=None)
    connection.psrp_client.connect.return_value = False

    connection._exec_psrp_script = MagicMock(return_value=(1, None, None))

    in_path = 'in_path'
    out_path = 'out_path'
    in_data = ''
    out_data = ''

    with pytest.raises(AnsibleError):
        connection.put_file(in_path, out_path)



# Generated at 2022-06-21 04:29:08.410167
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    conn = Connection()
    assert_equal(conn.fetch_file(), None)


# Generated at 2022-06-21 04:29:20.930324
# Unit test for method reset of class Connection
def test_Connection_reset():
    cmds = (
        'Import-Module ServerManager\n'
        'Get-WindowsFeature SNMP-Service\n'
    )
    conn = PSRPConnection(dict(
        remote_addr='127.0.0.1',
        remote_user='user',
        password='pass',
        port=5986,
        protocol='https',
        path='/wsman',
        auth='ntlm',
        connection_timeout=5,
        read_timeout=5,
    ))

    # Filter out the newline character at the end of the WinRM command.
    def filter_newline(s):
        return s.replace('\n', '')

    # Put the above WinRM command into a single line
    cmds = ' '.join(map(filter_newline, cmds.splitlines()))


# Generated at 2022-06-21 04:29:23.880713
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create the object of class Connection
    connection = Connection()
    # TODO: add test case here


# Generated at 2022-06-21 04:29:28.611225
# Unit test for method reset of class Connection
def test_Connection_reset():
  # BEGIN TESTS
  c = Connection()
  assert c.runspace is None
  assert c._connected == False
  assert c._last_pipeline is None
  # END TESTS
