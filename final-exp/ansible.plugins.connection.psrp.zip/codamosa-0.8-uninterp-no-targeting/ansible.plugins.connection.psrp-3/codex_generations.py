

# Generated at 2022-06-21 04:20:11.665460
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    r_in, r_out, r_err = None, None, None
    conn = Connection('', r_in, r_out, r_err)
    conn._exec_command('')

# Generated at 2022-06-21 04:20:16.950138
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    remote_addr = None  # type: Optional[str]
    runas_user = None  # type: Optional[str]
    become_password = None  # type: Optional[str]
    port = 5985
    private_key_file = None  # type: Optional[str]
    connection = Connection(remote_addr=remote_addr, runas_user=runas_user, become_password=become_password, port=port, private_key_file=private_key_file)

# Generated at 2022-06-21 04:20:17.979792
# Unit test for method reset of class Connection
def test_Connection_reset():
    assert True

# Generated at 2022-06-21 04:20:21.492462
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    command = "Get-Process"
    result = connection.exec_command(command=command)
    assert result["rc"] == 0
    assert result["stdout"]
    assert not result["stderr"]


# Generated at 2022-06-21 04:20:24.289181
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = ConnectionPSRP()
    rc, stdout, stderr = connection.exec_command('')
    assert (rc, stdout, stderr) == (0, '', '')


# Generated at 2022-06-21 04:20:35.895830
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    parameters = dict(
        in_path='/home/user/hello.txt',
        out_path='hello.txt',
        buffer_size=10,
        convert_newlines=True,
        show_content=True,
        tmp_path='/home/user/tmp',
        encoding='utf-8',
        errors='strict',
        newline_sequence='\n',
        cat_cmd='cat',
        tmpfile=None,
    )

    # Create instance of connection
    conn = Connection(**parameters)

    # Run method with all parameters
    conn.put_file(**parameters)


# Generated at 2022-06-21 04:20:46.860274
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    remote_addr = "test_remote_addr"
    remote_user = "test_remote_user"
    remote_password = "test_remote_password"
    port = "test_port"
    path = "test_path"
    auth = "test_auth"
    cert_validation = "test_cert_validation"
    connection_timeout = "test_connection_timeout"
    read_timeout = "test_read_timeout"
    message_encryption = "test_message_encryption"
    proxy = "test_proxy"
    ignore_proxy = "test_ignore_proxy"
    operation_timeout = "test_operation_timeout"
    max_envelope_size = "test_max_envelope_size"
    configuration_name = "test_configuration_name"

# Generated at 2022-06-21 04:20:59.082118
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    hostname = 'appserver'
    username = 'domain\\username'
    password = ''
    psrp_transport = Transport.PSRP()
    psrp_transport.set_options(direct={'remote_addr': hostname, 'remote_user': username, 'remote_password': password})

    psrp_connection = Connection(psrp_transport)
    psrp_connection.set_options(direct={'extras': {'ansible_psrp_connect_timeout': 5}})
    psrp_connection.exec_command = MagicMock()

    psrp_connection.fetch_file('/source', './destination')


# Generated at 2022-06-21 04:21:06.116656
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    psrp_connection = Connection(play_context=play_context, new_stdin=None)
    psrp_connection._build_kwargs()
    psrp_connection._connected = True
    psrp_connection._psrp_connection_timeout = None
    psrp_connection._psrp_read_timeout = None
    psrp_connection._psrp_message_encryption = None
    psrp_connection._psrp_proxy = None
    psrp_connection._psrp_ignore_proxy = None
    psrp_connection._psrp_operation_timeout = None
    psrp_connection._psrp_max_envelope_size = None
    psrp_connection._psrp_configuration_name = None
    psrp_connection._psrp

# Generated at 2022-06-21 04:21:22.652879
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the PSRP Connection object
    connection = Mock(spec=Connection)

    # Create test values for the method.
    in_path = 'test_in_path'
    out_path = 'test_out_path'
    flt = None
    follow = None
    _ = None
    tmp = None

    # Call the method with the mock
    Connection.put_file(connection, in_path, out_path, flt, follow, _, tmp)

    # Validate the method was called correctly.
    assert connection.transfer_file.call_count == 1
    assert connection.transfer_file.call_args[0] == (in_path, out_path)

# Generated at 2022-06-21 04:21:45.969843
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection('https://localhost:5986', '/wsman', 'Administrator', '!Password!^')
    connection.connect()
    command_rc, command_stdout, command_stderr = connection.exec_command('echo $env:TEMP')
    assert command_rc == 0
    assert len(command_stdout) > 0
    connection.close()


# Generated at 2022-06-21 04:22:01.658217
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.runspace = RunspacePoolState.OPENED

# Generated at 2022-06-21 04:22:10.514310
# Unit test for method reset of class Connection
def test_Connection_reset():
    # We need to initialize the Display object in order to raise a warning.
    display.Display.__init__(True)

    # We need to create the connection object used in the method we want to test
    psrp_conn = Connection()

    # We need a mock object for PluginLoader to avoid class instantiation errors
    mock_plugin = Mock()
    mock_plugin_loader = Mock(return_value=mock_plugin)

# Generated at 2022-06-21 04:22:27.445371
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from units.mock.procenv import swap_stdin_and_argv
    import py_compile
    _connection = Connection('operation_timeout=3', host='localhost')
    with swap_stdin_and_argv():
        _connection.put_file(in_path=None, out_path=None, arguments=None)

    _connection = Connection('operation_timeout=3', host='localhost')
    with swap_stdin_and_argv():
        _connection.put_file(in_path=None, out_path=None)

    _connection = Connection('operation_timeout=3', host='localhost')
    with swap_stdin_and_argv():
        _connection.put_file(in_path=None, out_path='/tmp/test_file1')


# Generated at 2022-06-21 04:22:38.076044
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Mock(spec=Connection)
    spec_dir = 'test/units/modules/external_plugins/test_connection_reset/'
    assert os.path.isfile(spec_dir + 'test_connection_reset.py')
    spec = importlib.util.spec_from_file_location("test_connection_reset", spec_dir + 'test_connection_reset.py')
    test_connection_reset = importlib.util.module_from_spec(spec)
    
    spec.loader.exec_module(test_connection_reset)

    # These are the args we expect to get called with
    class ConnectionArgs(NamedTuple):
        play_context : None
        new_stdin : io.StringIO
        connection_info : _AnsiblePSRPConnectionInfo

# Generated at 2022-06-21 04:22:46.104744
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection(
        host='localhost',
        port=5986,
        username='user',
        password='pass',
        )

    # Initialize the ScriptHost and RunspacePool for our tests
    script_host = PSGeneratedSkeletonHost(connection)
    connection.runspace = RunspacePool(script_host, runspace_state_callback=script_host.on_runspace_state_change)
    connection.runspace.open()

    # For test #1/2,3/4/5/6,7/8,9/10/11/12,13/14/15/16,17/18,19/20/21/22,23/24/25/26,27/28,29/30/31/32,33/34/35/36,37/38,39/40/41/42,43/

# Generated at 2022-06-21 04:22:47.030566
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()



# Generated at 2022-06-21 04:22:59.201511
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    args = {
        '_ansible_socket': None,
        'ansible_host': '127.0.0.1',
        'ansible_port': 5986,
        'ansible_user': 'vagrant',
        'ansible_password': 'vagrant',
        'ansible_connection': 'psrp',
        'ansible_psrp_server_cert_validation': 'ignore'
    }
    pc = PlayContext()
    conn = Connection(pc, **args)
    conn._connected = True
    conn._build_kwargs()
    conn.runspace = RunspacePool(conn._psrp_host, **conn._psrp_conn_kwargs)
    conn.host = Localhost(conn.runspace)
    conn.runspace.open()

# Generated at 2022-06-21 04:23:01.398281
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(None, None, None)
    assert connection is not None


# Generated at 2022-06-21 04:23:14.159780
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
   connection = Connection()

   # Setup psrp_read_script
   psrp_read_script = "read_script"
   connection.psrp_read_script = psrp_read_script

   # Setup buffer_size
   buffer_size = 5
   connection.buffer_size = buffer_size

   # Create a mock object
   psrp_pipeline = Mock()
   psrp_pipeline.output = [b"data"]

   # Create a mock object
   psrp_client = Mock()
   psrp_client.execute_cmd.return_value = (0, psrp_pipeline, "")

   # Set connection properties
   connection.psrp_client = psrp_client

   # Test for fetch_file
   in_path = "test_in_path"

# Generated at 2022-06-21 04:23:37.035250
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(
        module_name='psrp',
        inventory=InventoryManager(host_list=['host_with_psrp']))
    assert isinstance(connection, Connection)



# Generated at 2022-06-21 04:23:44.009029
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Test with required args only
    host = "foo"
    in_path = "bar"
    out_path = "baz"
    runspace = "elmo"

    connection = ansible.plugins.connection.psrp.Connection(play_context=None)
    connection.put_file(in_path, out_path)

# Generated at 2022-06-21 04:23:58.399021
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
	remote_addr = "192.168.0.10"
	remote_user = "ansible"
	remote_password = "ansible"
	protocol = "http"
	port = 5985
	# path = "http://192.168.0.10/wsman"
	path = None
	auth = "ntlm"
	message_encryption = False
	proxy = None
	ignore_proxy = False
	configuration_name = "Microsoft.PowerShell"
	credssp_auth_mechanism = None
	credssp_disable_tlsv1_2 = False
	credssp_minimum_version = None
	negotiate_send_cbt = False
	negotiate_delegate = False
	negotiate_hostname_override = None
	negotiate_service

# Generated at 2022-06-21 04:24:07.161431
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    return_value = None
    a = AnsibleHost()
    b = Connection(a)
    c = {'msg': 'hello'}

    try:

        with patch('ansible.plugins.connection.psrp.Connection._parse_pipeline_result', return_value=(0, '', '')):
            return_value = b.exec_command(c, {}, '/usr/bin/echo')

    except Exception as e:
        return_value = str(e)

    return return_value


# Generated at 2022-06-21 04:24:11.204385
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    result = connection.exec_command('echo hello')
    assert result.rc == 0
    assert result.stdout == 'hello\r\n'
    assert result.stderr == ''



# Generated at 2022-06-21 04:24:20.307206
# Unit test for method reset of class Connection

# Generated at 2022-06-21 04:24:26.140421
# Unit test for method close of class Connection
def test_Connection_close():
    _module_psrp_runspace = ModuleStub({'runspace': PSRP_RUNSPACE})
    self = mock.MagicMock()
    self.runspace = PSRP_RUNSPACE
    
    with patch.multiple(
        "ansible.plugins.connection.psrp",
        ModuleStub=mock.DEFAULT,
        display=mock.DEFAULT,
        to_native=mock.DEFAULT,
        sys=mock.DEFAULT
    ) as mocks:
        mocks['ModuleStub'].return_value = _module_psrp_runspace
        mocks['display'].vvvvv = mock_display_vvvvv
        mocks['to_native'].side_effect = to_native_side_effect

# Generated at 2022-06-21 04:24:27.946129
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    pytest.skip('TODO')



# Generated at 2022-06-21 04:24:38.366817
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print("-------------------test_Connection_put_file-------------------")
    # host = "192.168.7.13"
    # username = "root"
    # password = "root"

    # host = "192.168.29.4"
    # username = "root"
    # password = "esx"

    host = "192.168.29.20"
    username = "root"
    password = "esx"

    # host = "192.168.29.20"
    # username = "root"
    # password = "ca$hc0w"
    # in_path = "D:\\AnsibleZoo\\"
    # out_path = "/root/AnsibleZoo"
    # module_setup(in_path=in_path, out_path=out_path, host=host

# Generated at 2022-06-21 04:24:54.145753
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from __main__ import *
    from ansible.module_utils.six import b
    from ansible.module_utils.urls import open_url
    from ansible.playbook.play_context import PlayContext
    original_open_url = open_url
    original_context = connection.PlayContext

# Generated at 2022-06-21 04:25:33.818241
# Unit test for method reset of class Connection
def test_Connection_reset():
    v = psrp.connection.Connection()
    assert v is not None
    assert v.runspace is None
    try:
        v.reset()
    except Exception as e:
        assert False, str(e)
    assert v.runspace is None

# Generated at 2022-06-21 04:25:43.834886
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    arguments = mock.Mock()
    psrp_runspace_pool = mock.Mock()
    psrp_runspace_pool.state = RunspacePoolState.OPENED
    psrp_runspace_pool.id = 1
    psrp_runspace_pool.runspace = mock.Mock()
    psrp_paramiko_transport = mock.Mock()
    psrp_paramiko_transport.channel = mock.Mock()
    psrp_paramiko_transport.channel.settimeout = mock.Mock()
    psrp_host = mock.Mock()
    psrp_host.rc = 0
    psrp_host.ui = mock.Mock()
    psrp_host.ui.stdout = []

# Generated at 2022-06-21 04:25:59.681994
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # setup
    ansible_connection = Connection(play_context=MagicMock(), new_stdin=MagicMock())
    ansible_connection.runspace = MagicMock()
    script = "script"
    use_local_scope = True
    arguments=["arg1", "arg2"]
    ansible_connection.runspace.invoke_command = MagicMock(return_value=(0, "stdout", "stderr"))
    expected_result = (0, "stdout".encode('utf-8'), "stderr".encode('utf-8'))

    # test call
    result = ansible_connection._exec_psrp_script(script, use_local_scope=True, arguments=["arg1", "arg2"])

    # validate results

# Generated at 2022-06-21 04:26:01.353617
# Unit test for constructor of class Connection
def test_Connection():
    '''connection = Connection(play_context=play_context, new_stdin=None)'''
    display.display("test_Connection")



# Generated at 2022-06-21 04:26:08.115800
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Note: If you want to change the values for this test, don't just do it here.
    # You'll also need to change it in test_Connection__parse_pipeline_result
    hostname = 'testhost'
    username = 'testuser'
    password = 'testpass'
    psrp_host = 'testhost'
    psrp_user = 'testuser'
    psrp_pass = 'testpass'
    psrp_port = 8080
    psrp_protocol = 'https'
    psrp_path = 'testpath'
    psrp_auth = 'testauth'
    psrp_cert_validation = 'ignore'
    psrp_connection_timeout = 30
    psrp_read_timeout = 60

# Generated at 2022-06-21 04:26:22.818937
# Unit test for method close of class Connection
def test_Connection_close():
    host = dict(
        name='test1',
        ansible_host='test2',
        ansible_ssh_host='test3',
        ansible_shell_type='test4',
        ansible_python_interpreter='test5',
    )
    inventory = MagicMock()
    loader = MagicMock()
    variable_manager = MagicMock()
    options = MagicMock()
    options.connection = 'local'
    options.remote_user = 'test6'
    options.private_key_file = 'test7'
    options.verbosity = 5
    play_context = MagicMock()

    test1 = Connection(
        host,
        inventory,
        loader,
        variable_manager,
        options,
        play_context
    )

# Generated at 2022-06-21 04:26:25.650203
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    #ToDo: mock get_winrm_type return value
    #assert connection.put_file('src', 'dest') == None, 'Return value does not match'
    pass

# Generated at 2022-06-21 04:26:31.898441
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    conn = Connection()
    params = dict()
    params['in_path'] = "File path to copy from on the container"
    params['out_path'] = "File path to copy to on the host"
    params['buffer_size'] = 10
    params['timestamp'] = "timestamp"
    params['remote_file'] = "RemoteFile"
    conn.fetch_file(**params)


# Generated at 2022-06-21 04:26:37.460488
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Arrange
    conn = Connection()
    command = ""
    in_data = ""

    # Act
    try:
        # Act
        return_value = conn.exec_command(command, in_data)

        # Assert
        assert return_value is None
    except Exception as err:
        # Assert
        assert isinstance(err, NotImplementedError)

# Generated at 2022-06-21 04:26:42.253253
# Unit test for constructor of class Connection
def test_Connection():
    """Ensure test helper can be instantiated.

    Test helper docs:
    https://docs.ansible.com/ansible/latest/dev_guide/testing_helpers.html
    """
    module = MockModule()
    connection = Connection(module._socket_path)
    assert connection.get_option('remote_addr') == '127.0.0.1'

# Generated at 2022-06-21 04:28:05.130210
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    m = PsrpConnection()
    m.put_file(test_file,test_file)
    return True

# Generated at 2022-06-21 04:28:06.425953
# Unit test for method reset of class Connection
def test_Connection_reset():
  connection = Connection()
  connection.reset(None)


# Generated at 2022-06-21 04:28:08.406347
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    host = 'psrp'
    connection = Connection(host)
    rc = connection.exec_command('$t = Test-Path HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server')
    print(rc)
    rc = connection.exec_command('$t')
    print(rc)

# Generated at 2022-06-21 04:28:14.538985
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conn = Connection(None, None)
    assert conn is not None

    src_file = 'my_source_file'
    dest_file = 'my_dest_file'
    raw_connection = None
    follow = True
    print("put_file...")
    conn.put_file(src_file, dest_file, raw_connection, follow)


# Generated at 2022-06-21 04:28:20.723564
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    runner = Runner(connection=Connection(), host=Host(), module=None)
    ansible_vars = {'ansible_connection': 'psrp'}

    runner.connection.put_file('c:\\test.txt', '/tmp/test.txt', ansible_vars)
    assert runner.connection.connected is True
    runner.connection.close()
    assert runner.connection.connected is False
    # end unit test for Connection.put_file

# Generated at 2022-06-21 04:28:22.127148
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    x = Connection()
    x.fetch_file()


# Generated at 2022-06-21 04:28:29.085151
# Unit test for method close of class Connection
def test_Connection_close():
    connection = mock.MagicMock(spec=_Connection)
    connection._debug = False
    connection._keep_alive = False
    connection._connected = False
    connection.runspace = mock.MagicMock(spec=RunspacePool)
    connection.runspace.state = RunspacePoolState.OPENED
    connection._exec_psrp_script = mock.MagicMock(return_value=(0,'',''))
    # Test
    connection.close()
    # Assertions
    assert connection.runspace.close.call_count is 1

# Generated at 2022-06-21 04:28:35.944295
# Unit test for method reset of class Connection
def test_Connection_reset():
    base_dir = os.getcwd()
    print(base_dir)
    print('**************Test Connection.reset()**********')
    host = 'winc7-ent'
    user = 'winadmin'
    password = '1qaz@WSX'
    print(host)
    print(user)
    print(password)
    transport = 'psrp'
    context = dict()
    agt_conn = Connection(play_context=context)
    agt_conn.set_options({'connection': transport, 'ansible_host': host, 'ansible_user': user, 'ansible_password': password, 'ansible_port': 5986, 'ansible_connection_timeout': 30})
    agt_conn.connect()

    print(dir(agt_conn))

# Generated at 2022-06-21 04:28:50.843435
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    # Initialize objects for unit testing
    _s = SocketServer.TCPServer(("127.0.0.1", 5985), MyTCPHandler)

    thread = Thread(target=_s.serve_forever)
    thread.start()

    # Initialize the connection
    c = Connection(ansible_connection='psrp')
    c._psrp_host = '127.0.0.1'
    c._psrp_protocol = 'http'
    c._psrp_port = 5985
    c._psrp_user = 'dummy'
    c._psrp_pass = 'dummy'
    c.connect()

    # Initialize the command to send
    cmd = 'echo "hello world"'

    (rc, out, err) = c.exec_command(cmd)

# Generated at 2022-06-21 04:29:06.532493
# Unit test for method reset of class Connection
def test_Connection_reset():

    # Create a mock of the PSRP connection class
    mock_psrp_connection = Mock()
    mock_psrp_connection.close.return_value = None

    # Create a mock of the PSRP pool class
    mock_psrp_pool = Mock()
    mock_psrp_pool.get_connection.return_value = mock_psrp_connection
    mock_psrp_pool.runspace = None

    # Create a mock of the PSRP host class
    mock_psrp_host = Mock()

    # Create a mock of the PSRP runspace pool class
    mock_psrp_runspacepool = Mock()
    mock_psrp_runspacepool.create.return_value = mock_psrp_pool

    # Create a mock of the PSRP runspace pool state class