

# Generated at 2022-06-21 04:20:10.339837
# Unit test for method reset of class Connection
def test_Connection_reset():
    with pytest.raises(AnsibleError) as e:
        test_connection = Connection()
        test_connection.reset()

# Generated at 2022-06-21 04:20:21.352610
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    """
    Description
    -----------
    Unit test for fetch_file of class Connection

    Parameters
    ----------
        

    Returns 
    -------

    Raises
    ------
    Exception
    """
    def setup_module(self):
        self.psrp_protocol = 'https'
        self.psrp_user = 'vagrant'
        self.psrp_pass = 'vagrant'
        self.psrp_host = 'localhost'
        self.psrp_port = 5986
        self.psrp_path = '/wsman'
        self.psrp_auth = 'basic'

# Generated at 2022-06-21 04:20:25.719917
# Unit test for method reset of class Connection
def test_Connection_reset():
    runner = unittest.TextTestRunner()
    runner.run(unittest.makeSuite(ConnectionTestCase))


if __name__ == '__main__':
    # Unit test
    args = ['-v']
    args.extend(sys.argv[1:])
    unittest.main(argv=args)
    sys.exit(0)

# Generated at 2022-06-21 04:20:39.416944
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection(
        module=AnsibleModule(
            argument_spec=dict(
                check_mode=dict(default=False, type='bool'),
                remote_addr=dict(required=True),
            )
        ),
        winrm_transport='credssp'
    )
    connection._build_kwargs()
    connection._connect()
    rc='0'
    stdout='base64 encoded test file'
    connection._exec_psrp_script=MagicMock(name='_exec_psrp_script')
    connection._exec_psrp_script.return_value=(rc,stdout,None)
    in_path='/test/test.txt'
    out_path='test/test.txt'
    connection.fetch_file(in_path,out_path)
    connection

# Generated at 2022-06-21 04:20:41.726961
# Unit test for method put_file of class Connection
def test_Connection_put_file():
  pytest.skip("skipped test_Connection_put_file")


# Generated at 2022-06-21 04:20:45.347632
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(37, 'localhost', 'bob', 'pw')
    assert connection is not None
    assert connection.transport == 37
    assert connection.host == 'localhost'
    assert connection.username == 'bob'
    assert connection.password == 'pw'



# Generated at 2022-06-21 04:20:52.575819
# Unit test for method reset of class Connection
def test_Connection_reset():
    dep_1 = Dependency(None)
    dep_2 = Dependency(None)
    dep_3 = Dependency(None)
    dep_4 = Dependency(None)
    dep_5 = Dependency(None)

    conn = Connection(
        module_name='test',
        module_args={},
        _connection_info={}
    )
    conn.set_options(
        direct={'foo': 'bar'},
        vars={'bar': 'baz'},
        become_method=dep_1,
        become_user=dep_2,
        become_pass=dep_3,
        become_exe=dep_4,
        become_flags=dep_5,
        become=True
    )

    assert conn.become_method is dep_1

# Generated at 2022-06-21 04:20:55.156624
# Unit test for method close of class Connection
def test_Connection_close():
    args = dict()
    obj = Connection(args)
    assert obj.close() is None


# Generated at 2022-06-21 04:20:59.647181
# Unit test for constructor of class Connection
def test_Connection():
    class TestConnection(Connection):
        pass

    conn = TestConnection(None)
    assert conn.runspace is None
    assert conn._last_pipeline is None
    assert conn._connected is False
    assert conn.host is None

# Generated at 2022-06-21 04:21:00.542308
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    pass



# Generated at 2022-06-21 04:21:22.918983
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection()
    assert conn is not None



# Generated at 2022-06-21 04:21:23.505852
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection()

# Generated at 2022-06-21 04:21:24.816396
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    assert False==connection.reset()

# Generated at 2022-06-21 04:21:40.880882
# Unit test for constructor of class Connection
def test_Connection():
    '''
    Unit test for constructor of class Connection
    '''
    connection = Connection(play_context=PlayContext())
    assert connection._psrp_host is None
    assert connection._psrp_port is None
    assert connection._psrp_user is None
    assert connection._psrp_pass is None
    assert connection._psrp_protocol == 'https'
    assert connection._psrp_path is None
    assert connection._psrp_auth is None
    assert connection._psrp_cert_validation is True
    assert connection._psrp_connection_timeout is None
    assert connection._psrp_read_timeout is None
    assert connection._psrp_message_encryption is False
    assert connection._psrp_proxy is None

# Generated at 2022-06-21 04:21:53.557794
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection()
    # Set some test settings
    connection._psrp_host = 'test'
    connection._psrp_port = 5985
    connection._psrp_protocol = 'http'
    connection._psrp_path = '/wsman'
    connection._psrp_auth = 'basic'
    connection._psrp_user = 'test'
    connection._psrp_pass = 'test'
    connection._psrp_cert_validation = 'ignore'
    connection._psrp_connection_timeout = None
    connection._psrp_read_timeout = None
    connection._psrp_message_encryption = False
    connection._psrp_proxy = None
    connection._psrp_ignore_proxy = False
    connection._psrp_operation_timeout = 60
   

# Generated at 2022-06-21 04:21:55.509101
# Unit test for constructor of class Connection
def test_Connection():
    # first test without optional parameters
    c = Connection(remote_addr='1.2.3.4')
    assert '1.2.3.4' == c._psrp_host

# Generated at 2022-06-21 04:22:02.310326
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    psrp_connection = Connection(display, variable_manager, 'localhost')
    psrp_connection.connect()
    ansible_psrp_protocol = psrp_connection.get_option('protocol')
    ansible_psrp_port = psrp_connection.get_option('port')

# Generated at 2022-06-21 04:22:05.218491
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection()
    assert connection.has_pipelining
    assert connection.module_implementation_preferences == ["psrp", "winrm"]

# Generated at 2022-06-21 04:22:06.502469
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection()
    assert isinstance(c, Connection)

# Generated at 2022-06-21 04:22:08.414213
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection(None, 'psrp', None)
    assert(conn is not None)

# Generated at 2022-06-21 04:23:00.060873
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection('localhost', port=5986)
    assert conn is not None
    assert conn.remote_addr == 'localhost'
    assert conn.remote_user == 'Administrator'
    assert conn.remote_password == 'password%$'
    assert conn.protocol == 'https'
    assert conn.port == 5986
    assert conn.path == '/wsman'
    assert conn.auth == 'credssp'
    assert conn.cert_validation is True
    assert conn.connection_timeout is None
    assert conn.read_timeout is None
    assert conn.message_encryption == 'auto'
    assert conn.proxy is None
    assert conn.ignore_proxy is False
    assert conn.operation_timeout == 30
    assert conn.max_envelope_size == 153600
    assert conn.configuration_name

# Generated at 2022-06-21 04:23:13.656721
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    this_module = sys.modules[__name__]
    setattr(this_module, 'test_connection', Connection())
    test_connection_instance = sys.modules[__name__].test_connection
    test_connection_instance._connected = True
    # Test with default values for args
    try:
        test_connection_instance.put_file(in_path='/home/zetta/code/ansible/test/integration/targets/psrp/hello.ps1', out_path='/home/zetta/hello.txt')
        print('put_file success')
    except Exception:
        print('put_file failed')
    # Test with default values for args

# Generated at 2022-06-21 04:23:20.742844
# Unit test for constructor of class Connection
def test_Connection():
    # test case 1
    ansible_options = AnsibleOptions(connection='psrp',
                                     remote_addr='localhost',
                                     remote_user='Administrator',
                                     remote_password='P@ssw0rd!')
    conn = Connection(ansible_options)
    assert conn is not None



# Generated at 2022-06-21 04:23:34.911334
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    args = dict(in_path='in_path', out_path='out_path', buffer_size='buffer_size', tmp_path='tmp_path',
                executable=None, follow=False, _psrp_encoding='utf-8')

    conn = Connection()


# Generated at 2022-06-21 04:23:37.590808
# Unit test for constructor of class Connection
def test_Connection():
    m = Connection(module_name='', play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert m is not None

# Generated at 2022-06-21 04:23:54.034946
# Unit test for method reset of class Connection
def test_Connection_reset():
    host_name = 'host_name'
    port = 5986
    path = 'path'
    protocol = 'protocol'
    connection_timeout = 60
    read_timeout = 60
    message_encryption = 'message_encryption'
    proxy = 'proxy'
    ignore_proxy = 'ignore_proxy'
    operation_timeout = 60
    max_envelope_size = 60
    configuration_name = 'configuration_name'
    reconnection_retries = 60
    reconnection_backoff = 60.0
    certificate_key_pem = 'certificate_key_pem'
    certificate_pem = 'certificate_pem'
    credssp_auth_mechanism = 'credssp_auth_mechanism'

# Generated at 2022-06-21 04:24:06.334628
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # setup
    in_path = 'C:\\Users\\vagrant\\test.txt'
    out_path = 'C:\\Users\\vagrant\\test.txt'
    b_in_path = b'C:\\Users\\vagrant\\test.txt'
    b_out_path = b'C:\\Users\\vagrant\\test.txt'
    buffer_size = 65535
    offset = 0
    local_host = MagicMock()
    connection = Connection(local_host)
    connection.runspace = MagicMock()

    # expect
    local_host.get_option.side_effect = [in_path, out_path, buffer_size]

# Generated at 2022-06-21 04:24:16.660466
# Unit test for constructor of class Connection
def test_Connection():
    '''
    Unit test for constructor of class Connection
    '''
    display.verbosity = 4
    # test when we have a host:port combination
    transport = 'psrp'
    remote_addr = '1.1.1.1:9999'
    port = 9999
    connection_timeout = 10
    operation_timeout = 30
    read_timeout = 20
    max_envelope_size = 32000
    server_cert_validation = "ignore"
    auth = 'credssp'
    credssp_disable_tlsv1_2 = True
    credssp_auth_mechanism = "negotiate"
    credssp_minimum_version = "1.0"
    negotiate_send_cbt = True
    negotiate_delegate = True

# Generated at 2022-06-21 04:24:32.255073
# Unit test for method reset of class Connection
def test_Connection_reset():
    _play_context = MagicMock()
    _new_stdout = MagicMock()
    _transfer_files = False
    runspace_pool = MagicMock()
    runspace = MagicMock()
    runspace.state = MagicMock(return_value='OPENED')
    runspace.close = MagicMock(return_value=None)
    runspace_pool.get_runspace = MagicMock(return_value=runspace)
    runspace_pool.is_local = MagicMock(return_value=False)
    _connected = False
    _last_pipeline = None
    _get_conn_kwargs = MagicMock()
    _psrp_host = MagicMock()
    _psrp_user = MagicMock()
    _psrp_pass = MagicMock()

# Generated at 2022-06-21 04:24:42.858942
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.runspace = 'runspace'
    source_path, destination_path, buffer_size = 'test_data/test_psrp.yml', 'c:/temp/test_psrp.yml', 'buffer_size'
    in_path, out_path = 'test_data/test_psrp.yml', 'c:/temp/test_psrp.yml'
    rc, stdout, stderr = 0, 'stdout', 'stderr'

# Generated at 2022-06-21 04:26:10.387960
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()

# Generated at 2022-06-21 04:26:15.721902
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = new_connection(module_class = WindowsConnection)
    result = connection.exec_command('Get-Date', transport='psrp')
    assert result['rc'] == 0

# Generated at 2022-06-21 04:26:21.876763
# Unit test for constructor of class Connection
def test_Connection():
    '''test the constructor of class Connection'''
    module = MockModule()
    conn = Connection(module._play_context, module._new_stdin)
    assert conn._module == module
    assert conn._shell is None
    assert conn._connected == False
    assert conn._shell_type == 'powershell'
    assert conn.has_pipelining is None
    assert conn.runspace is None
    assert conn.host is None
    assert conn._last_pipeline is None
    assert conn._manager is None



# Generated at 2022-06-21 04:26:32.647802
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Note that this method is heavily dependent on the module being imported
    # as a global in the module.
    # This means that the connection object that's created also has a _global_module
    # attribute attached.
    # This is used by the PowerShellHost to attach the connection to the global
    # PSRPHost object

    module = Mock()
    socket = Mock()
    socket.close = Mock()
    module.get_option = Mock(return_value=socket)
    module.runspace = Mock()
    module.runspace.state = RunspacePoolState.OPENED
    module.runspace.close = Mock()
    module.runspace.id = 'a096d61b-0a82-4a0c-bfab-65b07d416300'
    module.host = Mock()
    module.host.ui = Mock

# Generated at 2022-06-21 04:26:41.341672
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Looks like we are testing a method
    conn = Connection({})
    conn._create_runspace()

    # We have to create some variables here
    test_out_path = None
    temp_out_path = None
    test_in_path = None
    temp_in_path = None

    # Do the actual call
    result = conn.exec_command('echo Hello World!', tmpdir='/tmp', in_data='Hello World!', codepage=65001,
                               console_mode_record=False)

    # Check if we got the expected result
    assert result == (0, b'Hello World!', b'')
    return


# Generated at 2022-06-21 04:26:49.138428
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    import requests
    
    cred = { "ansible_user": "test", "ansible_password": "test"}
    host = "localhost"
    src = "test_put_file.txt"
    dest = "test_put_file.txt"
    connection = Connection(play_context=play_context, new_stdin=None,
                            *None, **cred)

    # As of now, the source and dest are the same, because the original code
    # overwrites the dest if it exists
    connection.put_file(src,dest)
    dest_path = connection._shell._exec_psrp_script("(Resolve-Path %s).Path | Write-Host" % dest)

# Generated at 2022-06-21 04:26:54.105872
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    
    # Create a new Connection.
    x = Connection()
    # Create an object to represent command parameters.
    cmd = x.cmd_template_class(command='testcommand', in_data=None, become_user=None, become_method=None, become_exe=None, executable=None)

    # Return a tuple of command return data.
    rc, stdout, stderr = x.exec_command(cmd=cmd)
    
    # Return the function's return value.
    return rc, stdout, stderr


# Generated at 2022-06-21 04:27:06.089335
# Unit test for method exec_command of class Connection

# Generated at 2022-06-21 04:27:06.857214
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(None)
    assert connection is not None

# Generated at 2022-06-21 04:27:12.214145
# Unit test for constructor of class Connection
def test_Connection():
    """
    This unit test will create a connection for localhost with all default
    parameters, and then will set/get each of the options.
    """
    connection = Connection(module_name='test_module', playbook_path='test_playbook.yml')
    connection.set_options(remote_addr='localhost')
    assert connection.get_option('remote_addr') == 'localhost'
    assert connection.get_option('protocol') == 'https'
    assert connection.get_option('port') == 5986
    assert connection.get_option('path') == '/wsman'
    assert connection.get_option('auth') == 'ntlm'
    assert connection.get_option('cert_validation') is True
    assert connection.get_option('ca_cert') is None
    assert connection.get_option('connection_timeout')