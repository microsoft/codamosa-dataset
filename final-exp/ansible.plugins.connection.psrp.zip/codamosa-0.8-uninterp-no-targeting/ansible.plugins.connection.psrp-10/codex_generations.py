

# Generated at 2022-06-21 04:20:08.027531
# Unit test for constructor of class Connection
def test_Connection():
    from ansible.compat.tests.mock import patch, Mock

    # mock_connection_info is a dict which should contain all the properties that
    # need to be mocked for the constructor.

# Generated at 2022-06-21 04:20:11.716509
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    dest = ""
    conn = Connection()
    res = conn.put_file(dest)
    assert res == "", "If the method put_file of class Connection is working properly then it should return empty string"

# Generated at 2022-06-21 04:20:15.858228
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # We cannot unit test this using pytest since this is using pypsrp's
    # RunspacePoolState.OPENED which is not exposed correctly to other
    # functions outside a pypsrp RunspacePool object (unless you use a mock)
    pass


# Generated at 2022-06-21 04:20:21.645044
# Unit test for method close of class Connection
def test_Connection_close():
    fake_self = create_autospec(Connection)
    fake_self.runspace = create_autospec(RunspacePool)
    fake_self.runspace.state = RunspacePoolState.OPENED
    fake_self._connected = False
    fake_self._last_pipeline = None

    # Unit test for method close of class Connection
    fake_self.close()
    assert fake_self.runspace is None



# Generated at 2022-06-21 04:20:22.654786
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    pass



# Generated at 2022-06-21 04:20:29.634307
# Unit test for constructor of class Connection
def test_Connection():
    host = '1.1.1.1'
    user = 'azureuser'
    password = 'SuperSecretPassword!'
    connection = Connection(host, user, password)
    assert connection is not None
    assert connection.host == host
    assert connection.user == user
    assert connection.password == password

# Generated at 2022-06-21 04:20:41.674020
# Unit test for constructor of class Connection
def test_Connection():
    '''
    Constructor for class Connection
    '''

    # create Connection object
    connection = Connection(None)

    # assert that all instance variables are None
    assert connection._connection_info is None
    assert connection._psrp_host is None
    assert connection._psrp_user is None
    assert connection._psrp_pass is None
    assert connection._psrp_path is None
    assert connection._psrp_port is None
    assert connection._psrp_protocol is None
    assert connection._psrp_proxy is None
    assert connection._psrp_auth is None
    assert connection._psrp_message_encryption is None
    assert connection._psrp_cert_validation is None
    assert connection._psrp_ignore_proxy is None
    assert connection._psrp_operation

# Generated at 2022-06-21 04:20:49.576546
# Unit test for method close of class Connection
def test_Connection_close():
  connection = Connection()
  # Test with runspace not null, state not equal to RunspacePoolState.OPENED
  connection.runspace = "string"
  connection.runspace.state = "string"

  expected = None
  actual = connection.close()
  assert expected == actual

  # Test with runspace not null, state equal to RunspacePoolState.OPENED
  connection.runspace = "string"
  connection.runspace.state = RunspacePoolState.OPENED

  expected = None
  actual = connection.close()
  assert expected == actual

  # Test with runspace null
  connection.runspace = None

  expected = None
  actual = connection.close()
  assert expected == actual


# Generated at 2022-06-21 04:21:01.136243
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    # try with this combination 
    protocol = None
    port = None
    credssp_auth_mechanism = None
    host = 'localhost'
    username = 'test'
    password = 'test'
    rc, stdout ,stderr = fetch_file_test_helper( host,username,password,protocol,port,credssp_auth_mechanism)
    print("Output",stdout)
    print("Error",stderr)
    print("RC",rc)
    # Another test combination
    protocol = 'https'
    port = 5986
    credssp_auth_mechanism = None
    host = 'localhost'
    username = 'test'
    password = 'test'

# Generated at 2022-06-21 04:21:09.744570
# Unit test for method reset of class Connection
def test_Connection_reset():
    mock_play_context = MagicMock(**{'is_check_mode.return_value': False})
    mock_host, mock_host_vars, mock_options = test_connection_get_connection_data()
    mock_ansible_vars = {}

    # Initialize and run a test of the Connection.reset() method
    test_conn = connection_psrp.Connection(mock_play_context, mock_host, mock_host_vars, mock_options, mock_ansible_vars)
    test_conn.reset()
    # Make sure that the Connection did not connect to the remote host
    assert test_conn._connected is False
    

# Generated at 2022-06-21 04:21:35.781447
# Unit test for method close of class Connection
def test_Connection_close():

    # Patch remote_addr
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    mock_remote_addr = "8.8.8.8"
    basic._ANSIBLE_ARGS = None
    am = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
        check_invalid_arguments=False,
        bypass_checks=False
    )

    pc = PlayContext()
    pc.remote_addr = mock_remote_addr

    # Test instance creation
    connection = Connection(am, pc)
    assert connection._play_context == pc
    assert connection._connected == False
    assert connection._last_pipeline == None
    assert connection.runspace == None


# Generated at 2022-06-21 04:21:47.927703
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    unitsupport.patch(globals(), modules=modules)
    mock_fetch_file()

    c = Connection(None)
    c.runspace = mock_runspace()
    c._build_kwargs = Mock()
    c.host = Mock()
    c.host.ui = Mock()
    c.host.ui.stdout = Mock()
    c.host.ui.stderr = Mock()
    c.get_option = lambda x, default=None: x
    c.protocol = 'psrp'
    c._exec_psrp_script = Mock()
    c._parse_pipeline_result = Mock()
    c._parse_pipeline_result.return_value = 0, "stdout", "stderr"
    c.display = Mock()

# Generated at 2022-06-21 04:21:55.065373
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Build the connection
    conn = Connection()
    # Build the command
    cmd = 'echo "Hello world"'
    # Build the options
    opts = dict()
    # Call the method
    res = conn.exec_command(cmd, opts)
    # Print the results
    print(res)

# Generated at 2022-06-21 04:22:01.573974
# Unit test for method close of class Connection
def test_Connection_close():
    import pytest
    import ansible_psrp.connection
    conn = ansible_psrp.connection.Connection(play_context=None)
    try:
        with pytest.raises(AnsibleConnectionFailure):
            conn.close()
    except SystemExit:
        pass

# Generated at 2022-06-21 04:22:02.456296
# Unit test for constructor of class Connection
def test_Connection():
    PSRPConnection(None, None, None)

# Generated at 2022-06-21 04:22:09.442330
# Unit test for constructor of class Connection
def test_Connection():
    factory = ConnectionFactory()
    factory.psrp_connection_class = Connection
    connection = factory.create(constants.DEFAULT_TRANSPORT, '='.join(psrp_conn_cmd), psrp_connection_args)
    assert connection._psrp_auth == 'basic'
    assert connection._psrp_negotiate_send_cbt is True
    assert (connection._psrp_conn_kwargs['negotiate_delegate'] is
            connection._psrp_negotiate_delegate)
    assert (connection._psrp_conn_kwargs['negotiate_service'] ==
            connection._psrp_negotiate_service)


# Generated at 2022-06-21 04:22:18.798987
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    hostname = "localhost"
    username = "root"
    password = "passwd"
    service = 0

    ssh = Connection(hostname, username, password, service)

    source = "/Users/twhipple/Desktop/digital_ocean_1_4.txt"
    destination = "/home/twhipple/ Desktop/digital_ocean_1_4.txt"
    ssh.put_file(source, destination)


# Generated at 2022-06-21 04:22:21.456727
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    _test_Connection_fetch_file(MockConnection)


# Generated at 2022-06-21 04:22:31.194471
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    # Arrange
    psrp_connection = Connection()
    psrp_connection.runspace = pythoncom.CoCreateInstance(
        DYNAMIC_RUNSPACE_GUID,
        None,
        pythoncom.CLSCTX_INPROC,
        pythoncom.IID_IDispatch)
    psrp_connection.runspace.Connect(psrp_connection._psrp_host, psrp_connection._psrp_user, psrp_connection._psrp_pass, 'http',
                                 psrp_connection._psrp_port, psrp_connection._psrp_auth, 'en-US')

    psrp_connection.host = Host(psrp_connection.runspace)
    psrp_connection.host.ui = HostUIImpl

# Generated at 2022-06-21 04:22:32.616653
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()



# Generated at 2022-06-21 04:23:01.191110
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
  # Runspace from pypsrp.powershell
  runspace = RunspaceFactory.create_runspace_pool(1, 1, host=None, runspace_attributes=None)
  runspace.open()
  # PowerShell from pypsrp.powershell
  powerShell = PowerShell(runspace)
  powerShell.add_script(script=u'Get-Process | Select-Object -Property Name')
  powerShell.invoke()
  # class PSRPConnection from connection_plugin.py
  # psrpconnection = PSRPConnection()

# Test Connection class

# Generated at 2022-06-21 04:23:02.675365
# Unit test for method close of class Connection
def test_Connection_close():
    args = {}
    connection = Connection(args)
    rc = connection.close()
    assert rc is not None



# Generated at 2022-06-21 04:23:08.109723
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # stubbed method fetch_file
    in_path = ""
    out_path = ""
    file_args = dict()
    file_args['follow'] = False
    file_args['checksum'] = 'sha1'
    file_args['path'] = '/path/to/dest'


    # XXX need a better way of stubbing more complex types
    class RunspacePoolState(object):
        OPENED = 0


    class RunspacePool(object):
        def __init__(self):
            self.id = None
            self.state = RunspacePoolState.OPENED


        def close(self):
            pass


    class GenericComplexObject(object):
        def __init__(self):
            self.to_string = None


    class PSInvocationState(object):
        RUNNING = 0



# Generated at 2022-06-21 04:23:16.670805
# Unit test for method reset of class Connection
def test_Connection_reset():
    host = 'testhost'
    protocol = 'testprotocol'
    port = 12345
    user = 'testuser'
    password = 'testpassword'
    cert_validation = 'testvalidation'
    connection_timeout = 'testtimeout'
    read_timeout = 'testtimeout'
    message_encryption = 'testencryption'
    proxy = 'testproxy'
    ignore_proxy = 'testignoreproxy'
    operation_timeout = 'testoperationtimeout'
    max_envelope_size = 'testmaxenvelopesize'
    configuration_name = 'testconfigurationname'
    reconnection_retries = 'testreconnectionretries'
    reconnection_backoff = 'testreconnectionbackoff'
    certificate_key_pem = 'testcertificatekeypem'

# Generated at 2022-06-21 04:23:23.317619
# Unit test for method close of class Connection
def test_Connection_close():
    conn = Connection(None)
    conn.runspace = MagicMock()
    conn.runspace.state = RunspacePoolState.OPENED
    conn.runspace.close_mock = MagicMock()
    conn.close()
    assert isinstance(conn, Connection)

# Generated at 2022-06-21 04:23:28.061841
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection()
    conn.reset()
    assert(conn.connected == False)
    assert(conn.runspace is None)
    assert(conn._last_pipeline is None)


# Generated at 2022-06-21 04:23:31.270749
# Unit test for method reset of class Connection
def test_Connection_reset():
    handler = psrp.Connection(play_context=play_context)
    handler.reset()

# Generated at 2022-06-21 04:23:41.997339
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    print("\nIn test_Connection_exec_command")
    # Case 1: Input AnsibleConnection type object
    c = Connection()
    print("\n***Case 1: Input AnsibleConnection type object***")
    c.exec_command("Get-Date", stdin=None, in_data=None, sudoable=False)
    print("\n***Case 1: Input AnsibleConnection type object end***")

    # Case 2: Invalid input for Method exec_command
    print("\n***Case 2: Invalid input for Method exec_command***")
    my_conn = Connection()
    my_conn.exec_command(None, None, None, None)
    print("\n***Case 2: Invalid input for Method exec_command end***")


# Generated at 2022-06-21 04:23:45.499333
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    connection.host = Host()
    # TODO: Add tests
    raise NotImplementedError()

# Generated at 2022-06-21 04:23:52.538540
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Initialize the class
    connection = Connection()
    # Get the value of variable runspace
    runspace = connection.runspace
    # Set the value of variable runspace
    connection.runspace = runspace
    # Get the value of variable _connected
    _connected = connection._connected
    # Set the value of variable _connected
    connection._connected = _connected
    # Get the value of variable _last_pipeline
    _last_pipeline = connection._last_pipeline
    # Set the value of variable _last_pipeline
    connection._last_pipeline = _last_pipeline
    # Get the value of variable _psrp_host
    _psrp_host = connection._psrp_host
    # Set the value of variable _psrp_host
    connection._psrp_host

# Generated at 2022-06-21 04:24:41.414282
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-21 04:24:43.611980
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conn = PSRPHost(None)
    conn.put_file('C:\\Users\\Public\\foo.txt', '/tmp/foo.txt')
    conn.close()

# Generated at 2022-06-21 04:24:49.042950
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    test_host = 'localhost'
    test_timeout = 1

    test_conn = Connection(host=test_host, timeout=test_timeout)
    default_result = test_conn.exec_command('dir')
    assert default_result[0] == 0
    assert default_result[1] != ''
    assert default_result[2] == ''

    default_result = test_conn.exec_command('dir', in_data='test_data')
    assert default_result[0] == 0
    assert default_result[1] != ''
    assert default_result[2] == ''

    assert test_conn.exec_command('exit 8') == (8, '', '')


# Generated at 2022-06-21 04:24:55.043093
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(None)
    assert connection._psrp_host is None
    assert connection._psrp_user is None
    assert connection._psrp_pass is None
    assert connection._psrp_protocol == 'https'
    assert connection._psrp_port == 5986
    assert connection._psrp_path is None
    assert connection._psrp_auth is None
    assert connection._psrp_cert_validation is True
    assert connection._psrp_connection_timeout is None
    assert connection._psrp_read_timeout is None
    assert connection._psrp_message_encryption is None
    assert connection._psrp_proxy is None
    assert connection._psrp_ignore_proxy is False
    assert connection._psrp_operation_timeout is None
    assert connection._ps

# Generated at 2022-06-21 04:24:58.866347
# Unit test for method close of class Connection
def test_Connection_close():
    conn = Connection(None)
    conn.rfile = io.BytesIO()
    conn.wfile = io.BytesIO()
    conn.runspace = mock.MagicMock()
    conn.runspace.state = cur_state = mock.MagicMock()
    conn._connected = True
    conn._last_pipeline = (cur_state, mock.MagicMock())
    conn.close()
    assert conn._connected == False
    assert conn.runspace.close.call_count == 1
    assert conn.runspace is None
    assert conn._last_pipeline is None


# Generated at 2022-06-21 04:24:59.847881
# Unit test for method close of class Connection
def test_Connection_close():
    print("test_Connection_close: Executed")

# Generated at 2022-06-21 04:25:03.830241
# Unit test for constructor of class Connection
def test_Connection():
    connection_psrp = Connection(None, run_once=True)
    assert connection_psrp is not None, "Failed to create Connection object"

# Generated at 2022-06-21 04:25:17.900234
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    args = {
        'ansible_host': 'localhost',
        'ansible_password': 'userpass',
        'ansible_port': 5986,
        'ansible_psrp_server_cert_validation': 'ignore',
        'ansible_connection': 'psrp',
        'ansible_user': 'user',
        'ansible_winrm_server_cert_validation': 'ignore'
    }
    # Attempting to call fetch_file with a non-existing file should raise an
    # exception of type AnsibleFileNotFound
    with pytest.raises(AnsibleFileNotFound):
        connection = Connection(play_context=PlayContext(), new_stdin=None,
                                runner=None)
        input_data = None
        connection.set_options(direct=args)

# Generated at 2022-06-21 04:25:21.463629
# Unit test for method close of class Connection
def test_Connection_close():
    fd, tmp = tempfile.mkstemp()
    with os.fdopen(fd, 'r') as f:
        pass
    t = Connection()
    t.close()
    os.remove(tmp)


# Generated at 2022-06-21 04:25:27.709615
# Unit test for constructor of class Connection
def test_Connection():
    # Argument module_name is required
    with pytest.raises(AnsibleError) as excinfo:
        Connection()
    assert str(excinfo.value) == "connection plugin is missing the required argument 'module_name'"

    # Should raise exception for missing argument load_powershell_lib
    with pytest.raises(AnsibleError) as excinfo:
        Connection(module_name='test_module_name')
    assert str(excinfo.value) == 'connection plugin is missing the required argument load_powershell_lib'
    
    # Should raise exception for missing argument host
    with pytest.raises(AnsibleError) as excinfo:
        Connection(module_name='test_module_name', load_powershell_lib=lambda x: None)

# Generated at 2022-06-21 04:27:11.747694
# Unit test for method close of class Connection
def test_Connection_close():
    print("Test close")
    # Test setting up a basic connection with only required args
    host = 'localhost'
    username = 'vagrant'
    password = 'vagrant'
    protocol = None
    port = None
    path = None
    auth = None
    cert_validation = None
    connection_timeout = None
    read_timeout = None
    message_encryption = None
    proxy = None
    ignore_proxy = None
    operation_timeout = None
    max_envelope_size = None
    configuration_name = None
    reconnection_retries = None
    reconnection_backoff = None
    certificate_key_pem = None
    certificate_pem = None
    credssp_auth_mechanism = None
    credssp_disable_tlsv1_2 = None
    credssp

# Generated at 2022-06-21 04:27:13.352007
# Unit test for method close of class Connection
def test_Connection_close():
    Connection._close(self)

# Generated at 2022-06-21 04:27:26.328673
# Unit test for method reset of class Connection
def test_Connection_reset():
    '''
    Unit test for method reset of class Connection.
    '''

    # Define a dict for the parameter 'kwargs'
    base_kwargs = dict()
    # Define a dict for the return value.
    base_return_value = dict()
    # Create the object
    connection_obj = Connection(**base_kwargs)
    # Test the state of the object before the method call
    assert connection_obj._connected == False
    assert connection_obj._last_pipeline == None
    # Perform the method call
    return_value = connection_obj.reset()
    # Test the state of the object after the method call.
    assert connection_obj._connected == False
    assert connection_obj._last_pipeline == None
    # Test the return value
    assert return_value == base_return_value

#

# Generated at 2022-06-21 04:27:30.401349
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # FIXME: properly test this
    # FIXME: Import module and instantiate Connection here
    # FIXME: Call put_file()
    assert False


# Generated at 2022-06-21 04:27:37.081733
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    # Implementation of the Unit test
    conn = Connection(None)
    cmd = 'echo 127.0.0.1'
    rc, stdout, stderr = conn.exec_command(cmd)
    assert '127.0.0.1' == stdout.strip()



# Generated at 2022-06-21 04:27:50.608810
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    host = 'host'
    user = 'user'
    passwd = 'pass'
    port = 5986
    protocol = 'https'
    proxy_host = 'proxy_host'
    proxy_port = 8080
    proxy_user = 'proxy_user'
    proxy_pass = 'proxy_pass'
    encoding = 'utf-8'
    extra_args = dict()

    # Test get_option()
    extra_args['ansible_psrp_proxy_host'] = proxy_host
    c = Connection(host, user, passwd, port, protocol, extra_args, encoding,
                   proxy_host=proxy_host, proxy_port=proxy_port,
                   proxy_user=proxy_user, proxy_pass=proxy_pass)
    assert c.get_option('proxy_host') == proxy_host
   

# Generated at 2022-06-21 04:28:07.295580
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    host = "127.0.0.1"
    port = 5986
    user = "vagrant"
    password = "vagrant"
    
    psrp_options = {
        'protocol':'http',
        'port': port,
        'path': '/wsman',
        'auth': 'plaintext',
        'operation_timeout': 30,
        'max_envelope_size': 153600,
        'message_encryption': 'auto'
    }
    psrp_connection = Connection(psrp_options)
    

# Generated at 2022-06-21 04:28:09.994620
# Unit test for constructor of class Connection
def test_Connection():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    connection = Connection(module._socket_path)
    connection.close()



# Generated at 2022-06-21 04:28:11.518134
# Unit test for method reset of class Connection
def test_Connection_reset():
  assert True


# Generated at 2022-06-21 04:28:13.460785
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    assert connection.close() == None
