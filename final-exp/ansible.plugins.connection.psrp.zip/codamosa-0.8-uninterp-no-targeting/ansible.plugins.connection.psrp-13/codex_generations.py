

# Generated at 2022-06-21 04:20:18.238697
# Unit test for constructor of class Connection
def test_Connection():
    psrp_conn = Connection(
        ssh_connection=None,
        psrp_connection=None,
        new_stdin=None,
        terminal_stdin_prompt='$ '
    )

    assert isinstance(psrp_conn, Connection)

# Generated at 2022-06-21 04:20:24.250057
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
        module = importlib.import_module('ansible.plugins.connection.psrp')
        ins = module.Connection()
        ins.exec_command("ls -al > /tmp/output_test")
        assert os.path.exists("/tmp/output_test")
        if os.path.exists("/tmp/output_test"):
            os.rename("/tmp/output_test", "/tmp/output")
            os.remove("/tmp/output")


# Generated at 2022-06-21 04:20:35.457925
# Unit test for method close of class Connection
def test_Connection_close():
    u = Connection(play_context=play_context)
    u._connected = True
    u.runspace = RunspacePool(connection=u)
    # test_runspace to avoid NameError if there are no more attributes called runspace
    test_runspace = RunspacePool(connection=u)
    setattr(u, "runspace", test_runspace)
    u.close()
    assert u._connected == False
    assert u.runspace == None
    assert u._last_pipeline == None
    

# Generated at 2022-06-21 04:20:37.060646
# Unit test for method close of class Connection
def test_Connection_close():
    # TODO: FIXME
    pass



# Generated at 2022-06-21 04:20:39.895929
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    _test_Connection_exec_command(
        charset='utf-8',
        stdout=b"test stdout\n"
    )


# Generated at 2022-06-21 04:20:43.101534
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection(play_context = None)
    assert isinstance(connection, Connection)
    assert connection.close() == None

# Generated at 2022-06-21 04:20:45.030015
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    assert connection



# Generated at 2022-06-21 04:20:46.167127
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    pass

# Generated at 2022-06-21 04:20:58.384626
# Unit test for constructor of class Connection
def test_Connection():
    display.debug("test_Connection() called")
    # use default protocol, user and host
    conn = Connection(play_context=PlayContext(), new_stdin=None, *ConnectionArgs('', 'winrm', '', '', ''))
    # check the parameters of psrp_kwargs
    psrp_kwargs = conn._psrp_conn_kwargs
    assert psrp_kwargs['port'] == 5986, "Unexpected connection port: %s. Expected: 5986" % psrp_kwargs['port']
    assert psrp_kwargs['ssl'] is True, "Unexpected SSL setting: %s. Expected: True" % psrp_kwargs['ssl']
    assert psrp_kwargs['username'] == '', "Unexpected connection username: %s. Expected: ''" % ps

# Generated at 2022-06-21 04:21:01.890993
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = ConnectionPSRP(play_context=PlayContext())
    source="test"
    content=b"test_Connection_put_file"
    remote_path="/test_Connection_put_file"
    result=connection.put_file(b_source=source, b_content=content, b_remote_path=remote_path)
    assert result == None
    

# Generated at 2022-06-21 04:21:26.721526
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    local_path = None
    remote_path = None
    file_args = dict()
    use_priorities = dict()
    try:
        connection.fetch_file(local_path, remote_path, file_args, use_priorities)
    except Exception as e:
        print(str(e))

# Generated at 2022-06-21 04:21:29.366467
# Unit test for constructor of class Connection
def test_Connection():
    mock_winrm_conn = MockWinRMConnection()
    assert mock_winrm_conn is not None

# Generated at 2022-06-21 04:21:30.956877
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
	pass


# Generated at 2022-06-21 04:21:45.030617
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Set up mock
    url = 'http://github.com/ansible/ansible'
    mock_psrp_host = 'mock psrp_host'
    mock_psrp_user = 'mock psrp_user'
    mock_psrp_pass = 'mock psrp_pass'
    mock_psrp_protocol = 'mock psrp_protocol'
    mock_psrp_port = 'mock psrp_port'
    mock_psrp_path = 'mock psrp_path'
    mock_psrp_auth = 'mock psrp_auth'
    mock_psrp_cert_validation = 'mock psrp_cert_validation'

# Generated at 2022-06-21 04:21:55.010170
# Unit test for constructor of class Connection
def test_Connection():
    display.verbosity = 0
    psrp_connection = Connection(module_name='test_connection')
    assert psrp_connection._psrp_host == 'localhost'
    assert psrp_connection._psrp_user == 'admin'
    assert psrp_connection._psrp_pass == 'password'
    assert psrp_connection._psrp_protocol == 'https'
    assert psrp_connection._psrp_port == 5986
    assert psrp_connection._psrp_auth == 'basic'
    assert psrp_connection._psrp_path == 'wsman'
    assert psrp_connection._psrp_cert_validation == True
    assert psrp_connection._psrp_connection_timeout is None
    assert psrp_connection._ps

# Generated at 2022-06-21 04:22:01.909213
# Unit test for method exec_command of class Connection

# Generated at 2022-06-21 04:22:10.657499
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    mock_psrp_host = 'test_host'
    mock_psrp_user = 'test_user'
    mock_psrp_password = 'test_password'
    mock_psrp_protocol = 'http'
    mock_psrp_path = '/wsman'
    mock_psrp_auth = 'basic'
    mock_psrp_cert_validation = False


# Generated at 2022-06-21 04:22:27.604699
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    try:
        from __main__ import *
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

# Generated at 2022-06-21 04:22:30.274574
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection(None)
    assert conn is not None, "Failed to create Connection object for testing"


if __name__ == '__main__':
    # Run unit tests
    test_Connection()

# Generated at 2022-06-21 04:22:34.760215
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
   psrp_conn = Connection()
   assert psrp_conn.exec_command('dir',True) == 0, "exec_command should return 0"


# Generated at 2022-06-21 04:23:09.290751
# Unit test for constructor of class Connection
def test_Connection():
    # Mutually exclusive protocol/port args
    conn = Connection()
    conn.set_options(direct={'protocol': 'http', 'port': 5986})
    conn._build_kwargs()
    assert conn._psrp_protocol == 'http'
    assert conn._psrp_port == 5986
    conn = Connection()
    conn.set_options(direct={'protocol': 'https', 'port': 5985})
    conn._build_kwargs()
    assert conn._psrp_protocol == 'https'
    assert conn._psrp_port == 5985
    # Missing protocol/port args
    conn = Connection()
    conn.set_options(direct={'protocol': 'http', 'port': None})
    conn._build_kwargs()

# Generated at 2022-06-21 04:23:17.066513
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()

    command = "mycommand"
    in_data = "my stdin data"
    stdout = "my stdout data"
    stderr = "my stderr data"
    rc = 0

    # Test create_pipeline called with 1 command
    with patch('ansible.plugins.connection.psrp._exec_psrp_script') as mock_exec:
        mock_exec.return_value = (rc, stdout, stderr)
        (return_rc, return_stdout, return_stderr) = connection.exec_command(command, in_data, sudoable=False)
        assert mock_exec.called
        assert len(mock_exec.call_args_list) == 1, "Only a single call to create_pipeline should have been made"
        assert mock

# Generated at 2022-06-21 04:23:28.063227
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection()
    fake_inject = {'ansible_connection': 'winrm',
                   'ansible_winrm_server_cert_validation': 'ignore',
                   'ansible_winrm_path': '/wsman',
                   'ansible_winrm_transport': ['ntlm', 'kerberos']}
    conn.set_options(direct={'connection': 'psrp', '_extras': fake_inject})
    conn.exec_command('dir', sudoable=True)

# Generated at 2022-06-21 04:23:34.815580
# Unit test for method close of class Connection
def test_Connection_close():
    mocker.patch('ansible.module_utils.basic._load_params', return_value={})
    mocker.patch('ansible.modules.windows.psrp.Connection._build_kwargs')
    mocker.patch('ansible.modules.windows.psrp.Connection.__init__')
    mocker.patch('ansible.modules.windows.psrp.Connection._connect')
    mocker.patch('ansible.modules.windows.psrp.Connection._exec_psrp_script')
    m = ansible.modules.windows.psrp.Connection()
    m.runspace = Mock()
    m.runspace.state = 'OPENED'
    mocker.patch.object(m.runspace, 'close')
    m.close()
    assert m.runspace.close.call_count

# Generated at 2022-06-21 04:23:46.680912
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    import mock
    import tempfile
    import os
    import shutil
    from ansible.errors import AnsibleError
    from ansible.module_utils.powershell.converter import to_bytes
    from ansible.module_utils.powershell.common import RunspacePoolState
    from ansible.module_utils.powershell.shell import PowerShell
    from ansible.module_utils.powershell.common import PSInvocationState
    from ansible.module_utils.powershell.native_types import GenericComplexObject
    from ansible.module_utils.six.moves import StringIO

    # create a test files
    (fd, test_file) = tempfile.mkstemp()
    os.close(fd)
    test_data = 'test file'

# Generated at 2022-06-21 04:23:48.896004
# Unit test for method exec_command of class Connection

# Generated at 2022-06-21 04:24:01.775557
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conn=Connection(remote_addr='192.168.1.2', remote_user='Administrator', remote_password='Passw0rd!', protocol='http', port=5985, path='wsman', auth='basic', cert_validation=False, connection_timeout=60, read_timeout=None, message_encryption=False, proxy=None, ignore_proxy=False, operation_timeout=30, max_envelope_size=153600)
    out_path='c:\\Users\\Administrator\\test.txt'
    in_path='C:\\Users\\Administrator\\test.txt'
    conn.put_file(in_path=in_path, out_path=out_path)
    # Check that put_file is called with the right paramaters

# Generated at 2022-06-21 04:24:09.427781
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    #create an instance of class Connection
    connection_instance = Connection()
    
    #create dummy input args
    script = "dir c:\\"
    
    #construct method object
    Connection_exec_command_method = Connection.exec_command.__func__
    
    #run method
    Output = Connection_exec_command_method(connection_instance, script)
    print(Output)
    #assert results
    assert Output == (0, '', '')
    
    

# Generated at 2022-06-21 04:24:13.591158
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection()
    assert connection is not None

#
# The following code is stolen from paramiko/__init__.py, as we need to
# validate that the installed pypsrp is new enough to work before we actually
# use it
#


# Generated at 2022-06-21 04:24:16.253051
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection('x', 'y')
    result = connection.put_file('/a', '/b')
    assert result is None

# Generated at 2022-06-21 04:24:44.490899
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
        cmd_exec   = 'hostname'
        cmd_args   = None
        in_data    = None
        sudoable   = False
        check_rc   = True
        exec_rc    = 0
        stdout     = 'a.domain.com'
        stderr     = ''
        #data_stdout = self.power_shell.make_data(stdout.encode('utf-8'))
        #data_stderr = self.power_shell.make_data(stderr.encode('utf-8'))
        # Run test
        x = Connection()
        x._build_kwargs()
        x._set_power_shell()
        result = x._run_psrp_command(cmd_exec, cmd_args, in_data, sudoable, check_rc)

# Generated at 2022-06-21 04:24:58.056319
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection()
    # Reset _psrp_auth
    _psrp_auth = 'Basic'
    conn._psrp_auth = 'Basic'
    conn.reset()
    assert conn._psrp_auth is None
    # Reset _psrp_protocol
    conn._psrp_protocol = 'Basic'
    conn.reset()
    assert conn._psrp_protocol is None
    # Reset _psrp_port
    _psrp_port = 123
    conn._psrp_port = 123
    conn.reset()
    assert conn._psrp_port is None
    # Reset _psrp_cert_validation
    _psrp_cert_validation = False
    conn._psrp_cert_validation = False
    conn.reset()
   

# Generated at 2022-06-21 04:25:06.886798
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Setup test
    conn = Connection(None, None, None)
    conn._build_kwargs = MagicMock()
    conn.close = MagicMock()
    conn.open = MagicMock()

    # Test
    conn.reset()

    # Asserts
    assert conn.close.call_count == 1
    assert conn.open.call_count == 1
    assert conn._build_kwargs.call_count == 1


# Generated at 2022-06-21 04:25:18.845531
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    psrp_conn = Connection('psrp')
    psrp_conn._build_kwargs()
    psrp_conn._connected = True
    psrp_conn.psrp_host = 'localhost'
    psrp_conn.runspace = RunspacePool()
    psrp_conn.psrp_path = '/wsman'
    
    from ansible.utils.path import unfrackpath
    in_path = '../../../../test/integration/targets/win_files/src/a.txt'
    out_path = 'c:/temp/a.txt'
    in_path = unfrackpath(in_path)
    b_in_path = to_bytes(in_path, errors='surrogate_or_strict')
    b_out_path = to_bytes

# Generated at 2022-06-21 04:25:21.319920
# Unit test for method close of class Connection
def test_Connection_close():
    print("Testing Connection.close")
    connection = psrp.Connection()
    connection.close()
    assert(1 == 1)
    return True

# Generated at 2022-06-21 04:25:22.560409
# Unit test for constructor of class Connection
def test_Connection():
    pytest.skip('test_Connection not implemented yet')


# Generated at 2022-06-21 04:25:25.516257
# Unit test for constructor of class Connection
def test_Connection():
    pass


# Generated at 2022-06-21 04:25:29.054758
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup the test
    connection = Connection()
    
    # Exercise the method
    result = connection.exec_command("test")
    
    # Verify the result
    assert result == None, 'Method returned unexpected result.'


# Generated at 2022-06-21 04:25:38.821113
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    command = "hello_world"
    rc = 5
    stdout = "something"
    stderr = "some error"
    ps = PipelineState()
    ps.state = PipelineState.RUNNING
    ps.results.append("hello_world")
    ps.results.append("something")
    ps.results.append("some error")
    ps.return_code = 5

    host = Host(None, None)

    psrp_conn = PSRPConnection()
    psrp_conn._host = host
    psrp_conn._connected = True
    psrp_conn._last_pipeline = ps
    psrp_conn._last_pipeline.state = PSInvocationState.RUNNING

    rc, stdout, stderr = psrp_conn._parse_pipeline_result

# Generated at 2022-06-21 04:25:40.201816
# Unit test for method close of class Connection
def test_Connection_close():
    connection_close_obj = Connection()
    connection_close_obj.close()

# Generated at 2022-06-21 04:26:38.076559
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    m_runspace_pool = MagicMock()
    m_runspace_pool.acquireRunspace.return_value.invoke.return_value = {'stdout': 'value1',
                                                                        'stderr': 'value2',
                                                                        'rc': 0
                                                                        }
    m_psrp_protocol = 'http'

    m_transport = MagicMock
    m_transport.psrp_protocol = m_psrp_protocol
    m_play_context = MagicMock

    m_play_context.verbosity = 0

    cmd = 'test'

    connection = Connection(m_play_context)
    connection.runspace = m_runspace_pool

    out = connection.exec_command(cmd)


# Generated at 2022-06-21 04:26:45.807254
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    host = '172.17.0.2'
    user = 'Administrator'
    password = 'vagrant'
    port = 5985
    connection = Connection(host, user, password, port)
    in_path = 'C:\\Test\\test.txt'
    out_path = 'C:\\Temp\\test.txt'
    connection.put_file(in_path, out_path)
    #print (str(str(response.message)).split("\r\n"))
    #print (response.status_code)
    #print (response.text)
    assert True

test_Connection_put_file()


# Generated at 2022-06-21 04:26:58.409882
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    hostname = 'localhost'
    username = 'vagrant'
    password = 'vagrant'
    port = 5986
    remote_path = 'C:\\Users\\vagrant\\Desktop\\test.txt'
    local_path = 'test.txt'

    # First declare the context object for the connection
    context = Connection(host=hostname,
                         user=username,
                         port=port,
                         password=password).runspace_pool

    # Second, use the context object to do something
    Connection(runspace_pool=context).put_file(remote_path, local_path)


# Generated at 2022-06-21 04:27:00.661454
# Unit test for method close of class Connection
def test_Connection_close():
    my_connect = Connection()
    my_connect.close()



# Generated at 2022-06-21 04:27:06.481258
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Initialize object
    connection = Connection(None, None)
    args = ()
    # Pass the actual function to be tested
    kwargs = {'in_path': 'GET_PATH', 'out_path': 'POST_PATH', 'use_ntlm': True}
    actual_return = connection._put_file(*args, **kwargs)
    # Return value should be NoneType
    assert actual_return is None, "Connection._put_file() returns %s, not NoneType" % type(actual_return)


# Generated at 2022-06-21 04:27:22.190046
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    c = Connection(play_context=PlayContext())
    c.runspace = RunspacePool(None, None, None)

    file_content = "This is a test text"
    file_path = 'C:\\temp\\test.txt'
    temp_fh, temp_path = tempfile.mkstemp()
    os.close(temp_fh)


# Generated at 2022-06-21 04:27:30.611541
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    conn = Connection('', '')
    in_path = "100k.txt"
    out_path = "/var/tmp/ansible/100k.txt"
    b_out_path = to_bytes(out_path)
    setattr(conn, '_last_pipeline', None)
    setattr(conn, 'runspace', None)
    setattr(conn, '_psrp_host', 'localhost')
    setattr(conn, '_psrp_path', '')
    setattr(conn, '_psrp_user', 'Administrator')
    setattr(conn, '_psrp_pass', 'TestPassword123')
    setattr(conn, '_psrp_protocol', 'http')
    setattr(conn, '_psrp_port', 5985)
    set

# Generated at 2022-06-21 04:27:35.475695
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import logging
    import sys
    import pytest

    logger = logging.getLogger()
    logger.level = logging.DEBUG
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)

    testobj = Connection()

    psrp_host = '10.114.31.1'
    plain_text = 'test plain text'

    testobj.get_option = mock.MagicMock()
    testobj.get_option.side_effect = [
        psrp_host, 'Administrator', 'Password01!', 'http', 5985,
        'virtual_environment_name', False, None, None, False,
        None, None, None, None, None, True, None, None,
        None, None, None, None, None, None, None, None, None]
    test

# Generated at 2022-06-21 04:27:37.131190
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Arrange
    reset = Connection._reset
    # Act
    reset()
    # Assert

# Generated at 2022-06-21 04:27:39.495985
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    my_object = Connection(None, None, None, None)
    my_object.inject = {'psrp': None}

    assert my_object.fetch_file == my_object.inject['psrp'].fetch_file

# Generated at 2022-06-21 04:29:31.751153
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Setup
    from ansible.module_utils.psrp import PsrpSession

    p = patch.object(PsrpSession, '_exec_psrp_script')
    mock_exec = p.start()

    # Test
    with Connection() as conn:
        conn.put_file = put_file_psrp  # Only in playbooks
        conn.put_file(u'in_path', u'out_path')
        assert mock_exec.called  # The connection should execute a PS script to copy a file

    # Cleanup
    p.stop()
