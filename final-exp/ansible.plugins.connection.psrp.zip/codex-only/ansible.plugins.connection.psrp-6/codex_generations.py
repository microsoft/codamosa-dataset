

# Generated at 2022-06-23 09:55:00.913921
# Unit test for method close of class Connection
def test_Connection_close():
    print('Unit test for method close of class Connection')
    test_connection = Connection()
    test_connection.close()
    

# Generated at 2022-06-23 09:55:11.498977
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = _construct_object(Connection)
    command = utils.random_string()
    stdin = utils.random_string()
    persistent_connection_id = utils.random_string()
    display.vvvvv = Mock(return_value=None)
    display.vvvvvv = Mock(return_value=None)
    result = connection.exec_command(command, stdin, persistent_connection_id)
    assert result == (0, '', ''), result
    display.vvvvv.assert_called_with("PSRP EXEC '%s'" % (command), host=None)
    display.vvvvvv.assert_called_with("PSRP EXEC PERSIST_ID: %s" % (persistent_connection_id), host=None)




# Generated at 2022-06-23 09:55:12.768734
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection._reset_connection()

# Generated at 2022-06-23 09:55:23.934457
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    mock_module_helper = MagicMock()
    mock_module_helper.params = dict()
    expected_result = dict()

    mock_file = MagicMock()

    mock_open = MagicMock(return_value=mock_file)
    b64_encode = MagicMock(return_value="ThisIsSomeBase64")
    mock_module_helper.b_path = MagicMock(side_effect=lambda x: "/b" + x)


# Generated at 2022-06-23 09:55:25.680472
# Unit test for method close of class Connection
def test_Connection_close():
    connection = psrp_connection.Connection()
    connection.close()


# Generated at 2022-06-23 09:55:29.637916
# Unit test for method close of class Connection
def test_Connection_close():
    psrp = psrp = PypsrpConnection(dict(ansible_user='vagrant', ansible_password='vagrant', ansible_connection='psrp'))
    psrp.close()
    pass


# Generated at 2022-06-23 09:55:32.561564
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    assert hasattr(connection, 'close')
    assert callable(getattr(connection, 'close'))


# Generated at 2022-06-23 09:55:41.837871
# Unit test for method close of class Connection
def test_Connection_close():
    # remove any previous devops.cfg
    if os.path.isfile("devops.cfg"):
        run("rm devops.cfg")
    # make sure we have a fresh devops.cfg. 
    initialize_devops()
    # Connection()
    a_obj=Connection()
    #  we need to connect before we close()
    a_obj.connect()
    # call close()
    a_obj.close()
    # make sure that self.runspace is None
    assert a_obj.runspace == None, 'test_Connection_close assertion failed.'


# Generated at 2022-06-23 09:55:50.645062
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    if os.path.isfile("C:\\temp\\test_get_put_file.txt"): 
        # file exists
        os.remove("C:\\temp\\test_get_put_file.txt")

    runspacePool = None
    

# Generated at 2022-06-23 09:56:03.350120
# Unit test for constructor of class Connection
def test_Connection():
    # Verify localhost can be used with psrp
    try:
        c = Connection(remote_addr='localhost')
    except:
        raise Exception('localhost cannot be used with psrp')
    else:
        del c

    # Verify a wrong port cannot be used with psrp
    try:
        c = Connection(remote_addr='127.0.0.1:22')
    except:
        pass
    else:
        raise Exception('an incorrect port should not work with psrp')

    # verify a wrong protocol cannot be used with psrp
    try:
        c = Connection(remote_addr='http://127.0.0.1')
    except:
        pass
    else:
        raise Exception('an incorrect protocol should not work with psrp')

    # verify that we can use a username without a password
   

# Generated at 2022-06-23 09:56:15.884536
# Unit test for method close of class Connection
def test_Connection_close():
    mock_psrp_host = '127.0.0.1'

    with patch('ansible.plugins.connection.psrp.DictConnection._build_kwargs', return_value=None) as mock_build:
        with patch('ansible.plugins.connection.psrp.pypsrp.client.Client', return_value=None) as mock_client:
            with patch('ansible.plugins.connection.psrp.DictConnection.get_option', return_value=mock_psrp_host) as mock_option:
                c = DictConnection(mock_play_context, new_stdin=None)
                c.close()

    mock_build.assert_called_once()
    mock_client.assert_not_called()

# Generated at 2022-06-23 09:56:29.773254
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection('http', 'server', 'user', 'pass')
    assert conn.protocol == 'http'
    assert conn.host == 'server'
    assert conn.user == 'user'
    assert conn.password == 'pass'
    assert conn.port == 5985
    assert conn.psrp_conn_kwargs['port'] == conn.port
    assert conn.psrp_conn_kwargs['username'] == 'user'
    assert conn.psrp_conn_kwargs['password'] == 'pass'
    assert conn.psrp_conn_kwargs['ssl'] == False
    assert conn.psrp_conn_kwargs['auth'] == 'basic'
    assert conn.psrp_conn_kwargs['server'] == 'server'

# Generated at 2022-06-23 09:56:33.026161
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection._last_pipeline is None
    assert connection.runspace is None
    assert connection.host is None



# Generated at 2022-06-23 09:56:41.667204
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
	f = open(r'test_data/psrp.json', mode='r')
	options = json.load(f)
	print(options)
	f.close()
	
	mock_inventory = ansible.parsing.dataloader.DataLoader()
	mock_loader = ansible.parsing.dataloader.DataLoader()
	mock_variable_manager = ansible.vars.manager.VariableManager()
	mock_playbook = ansible.playbook.Playbook.load(
		playbook_path='test_data/test_playbook.yml',
		variable_manager=mock_variable_manager,
		loader=mock_loader,
	)

# Generated at 2022-06-23 09:56:44.576091
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection()
    conn.reset()
    assert conn._connected is False
    assert conn.runspace is None
    assert conn._last_pipeline is None

# Generated at 2022-06-23 09:56:46.362688
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection('./test_raw.yml')
    conn.exec_command('dir')


# Generated at 2022-06-23 09:56:50.947496
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup
    from ansible.plugins.connection.winrm import Connection, winrm_get_shell_id
    from ansible.plugins.loader import integrated_docstring

    def get_docstring():
        docstring = "%s" % Connection.exec_command
        docstring = integrated_docstring(docstring, Connection)
        return docstring

    fake_winrm = FakeWinRM()
    fake_winrm.runspace = FakeRunspace()
    fake_winrm.host = FakeHost()
    fake_winrm.protocol = FakeProtocol()
    fake_winrm.shell_id = winrm_get_shell_id(fake_winrm)

    # Test 1
    # cmd is not a string
    cmd = [1,2,3]

# Generated at 2022-06-23 09:56:54.325423
# Unit test for method close of class Connection
def test_Connection_close():
    from ansible.plugins.connection.winrm import Connection
    # initialize a test plugin
    connection_plugin = Connection(None)
    # set the associated fake object attributes
    connection_plugin.runspace = None
    connection_plugin._connected = False
    # run the method to test
    connection_plugin.close()

# Generated at 2022-06-23 09:56:57.032330
# Unit test for constructor of class Connection
def test_Connection():
    class TestConnection(Connection):
        def __init__(self):
            pass

    c = TestConnection()

    assert c is not None, "Failed to create instance of Connection"


# Generated at 2022-06-23 09:57:10.880115
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import pytest
    import sys
    import os
    import tempfile
    import base64
    import json
    import random
    import string
    import collections

    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    from ansible.plugins.connection.psrp import Connection as C
    from ansible.plugins.connection.psrp.psrp_client import PSRPClient
    from ansible.plugins.connection.psrp.wmiexec import WMIClient
    from ansible.plugins.connection.psrp import _

# Generated at 2022-06-23 09:57:20.902135
# Unit test for method reset of class Connection
def test_Connection_reset():
    """Unit tests for the Connection._reset() method"""
    # Runspace failed to open, close the runspace and reset the connection
    # state

    class TestRunspacePool(pypsrp.powershell.RunspacePool):
        def __init__(self):
            super(TestRunspacePool, self).__init__(None, None, None)
            self._state = RunspacePoolState.OPENED

        @property
        def state(self):
            return self._state

        @state.setter
        def state(self, value):
            self._state = value

    connection = Connection(None)
    connection.runspace = TestRunspacePool()
    connection.runspace.state = RunspacePoolState.ORPHANED
    connection._reset()
    assert connection.runspace is None
    assert connection._connected is False



# Generated at 2022-06-23 09:57:34.426032
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-23 09:57:45.026219
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a connection to execute the command
    conn = Connection(None, None)

    # Execute simple command
    rc, out, err = conn.exec_command("echo Hello")
    assert rc == 0
    assert out == "Hello"

    # Execute command with error return code
    rc, out, err = conn.exec_command("cmd /c dir C:\DirectoryThatDoesNotExist")
    assert rc == 1
    assert err != ""

    # Execute command and get stdout and stderr
    rc, out, err = conn.exec_command("cmd /c dir")
    assert rc == 0
    assert out != ""
    assert err != ""

    # Execute command with stderr and stdout
    rc, out, err = conn.exec_command("echo Hello & >&2 echo Error")
    assert rc == 0

# Generated at 2022-06-23 09:57:57.802329
# Unit test for constructor of class Connection
def test_Connection():
    """
    Unit test for constructor of class Connection
    :return:
    """

# Generated at 2022-06-23 09:57:58.677990
# Unit test for constructor of class Connection
def test_Connection():
    Connection(None)

# Generated at 2022-06-23 09:58:11.536511
# Unit test for method close of class Connection
def test_Connection_close():
    host = 'test'
    remote_user = 'test'
    remote_pass = 'test'
    port = 5985
    connection_timeout = 30
    read_timeout = 30
    become = False
    become_method = None
    become_user = None
    become_pass = None
    become_exe = '/usr/bin/sudo'
    become_flags = '-H'
    encoding = None
    passwords = {}
    transport = 'winrm'
    tty = False
    module_implementation_order = ['psrp']
    ansible_connection = None
    ansible_shell_type = None
    ansible_shell_executable = None
    ansible_python_interpreter = None
    data = 'data'
    check = 'check'
    debug = 'debug'

# Generated at 2022-06-23 09:58:22.450328
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    p = mock.patch(
        'psrpclient.client._PSRPClient.run_command',
        create=True,
    )
    remote_path = "/remote/path/to/file"
    local_path = "/local/path/to/file"
    arguments = [remote_path, local_path]
    psrp_client = Connection()

    with p as mock_run_command:
        psrp_client._fetch_file(remote_path, local_path)

        mock_run_command.assert_called_once_with(
            'Get-Content', arguments, as_list=True, as_json=True,
        )


# Generated at 2022-06-23 09:58:30.488266
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # The source code snippet to test
    inv = dict(
        connection='psrp',
        protocol='https',
        remote_addr='localhost',
        remote_user='vagrant',
        remote_password='vagrant',
        port=5986,
        max_envelope_size=4194304,
        operation_timeout=300,
        connection_timeout=300,
    )
    conn = Connection(play_context=PlayContext(), new_stdin=None, local_port=None,
            local_host='127.0.0.1')

    conn.set_options(var_options=inv)
    conn.exec_command('')
    assert conn._exec_psrp_script('') == (0, '', '')
    #assert conn._exec_psrp_script('') == (

# Generated at 2022-06-23 09:58:40.766742
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Create a copy of original Connection to preserve class for other tests
    Connection_test = copy.deepcopy(Connection)

    # Create necessary mock objects
    psrp_host = 'localhost'
    psrp_protocol = 'https'
    psrp_port = 5986
    psrp_path = None
    psrp_proxy = None
    psrp_ignore_proxy = False
    psrp_configuration_name = None
    psrp_operation_timeout = 30

    mock_play_context = create_autospec(PlayContext)
    mock_loader = create_autospec(DataLoader)
    mock_templar = create_autospec(Templar)

    mock_play_context.verbosity = 4
    mock_play_context.timeout = 5

    mock_psrp

# Generated at 2022-06-23 09:58:51.026182
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    
    # create an instance of the class to be tested
    test_conn = Connection(None)

    # TODO: Create mock poweshell object

    # create a mock variable for the created poweshell object
    mock_ps = PowerShell()

    # create fake output for the stream of the mock object
    mock_ps.output = ["test_1", "test_2", "test_3"]

    # create fake output for the error stream of the mock object
    mock_ps.streams.error = ["test_1", "test_2", "test_3"]

    # create fake output for the stdout of the mock host
    mock_ps.host.ui.stdout = ["test_1", "test_2", "test_3"]

    # create fake output for the stderr of the mock host
    mock_ps.host.ui

# Generated at 2022-06-23 09:58:57.328902
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test case for the exec_command method of SSH connection
    class Test1:
        def __init__(self, port=None, connection_timeout=None, read_timeout=None, message_encryption=None, ssl=None, proxy=None, no_proxy=False, max_envelope_size=None, operation_timeout=None, certificate_key_pem=None, certificate_pem=None, credssp_auth_mechanism=None, credssp_disable_tlsv1_2=False, credssp_minimum_version=None, negotiate_send_cbt=False, negotiate_delegate=False, negotiate_hostname_override=None, negotiate_service=None):
            pass
        def open_runspace_pool(self, runspace_pool_config=None):
            pass

# Generated at 2022-06-23 09:59:07.515267
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # SUT and Mock Objects
    connection = Connection()
    connection.become = False
    connection.become_user = "become_user"
    connection.become_method = "become_method"
    connection.no_log = False
    connection.host = "host"
    connection._play_context = "play_context"
    connection.connected = False
    connection.runspace = "runspace"
    connection._last_pipeline = "last_pipeline"
    connection._psrp_host = "psrp_host"
    mock_ps = Mock()
    mock_ps.invoke = Mock(return_value = (0, "", ""))
    mock_ps.had_errors = False
    mock_ps.state = "state"

# Generated at 2022-06-23 09:59:17.546898
# Unit test for method close of class Connection
def test_Connection_close():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('ansible.plugins.connection.psrp.Connection._exec_psrp_script') as exec_psrp_script:
        # Parameters
        connection = Connection()

        # Invoke method
        connection.close()

        # Assertions
        assert exec_psrp_script.call_count == 1
        assert exec_psrp_script.call_args_list[0][0] == ('$fs.Close()',)



# Generated at 2022-06-23 09:59:27.580452
# Unit test for method close of class Connection
def test_Connection_close():
    connection=Connection(param={'ansible_network_os': 'ios'})
    runspace = RunspacePool()
    rs = RunspacePool()
    connection.runspace = rs
    connection.close()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None



# Generated at 2022-06-23 09:59:30.246632
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    ret_val = connection.exec_command(command)
    assert ret_val != None


# Generated at 2022-06-23 09:59:36.264145
# Unit test for method close of class Connection
def test_Connection_close():
    '''
    Unit test for method close of class Connection
    '''
    connection = Connection()

    # Test with a positive input
    # Test when no exception is thrown
    assert True == connection.close()

    # Test with a negative input
    # Test when exception is thrown
    try:
        connection.close()
        assert False, "Expected exception"
    except Exception as e:
        assert True



# Generated at 2022-06-23 09:59:37.967223
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # TODO: implement
    pass



# Generated at 2022-06-23 09:59:48.038433
# Unit test for constructor of class Connection
def test_Connection():
    # Test is done by invoking constructor of class Connection
    # so there is no explicit test function
    test = Connection('localhost')
    test = Connection('localhost', port=5985)
    test = Connection('localhost', port=5986, protocol='https')
    test = Connection('localhost', port=5985, protocol='http')
    test = Connection('localhost', port=5985, protocol='http', path='wsman')
    test = Connection('localhost', port=5985, protocol='http', path='wsman',
                      username='username', password='password')
    test = Connection('localhost', port=5985, protocol='http', path='wsman',
                      username='username', password='password',
                      connection_timeout=30)

# Generated at 2022-06-23 10:00:00.954008
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """
    Test if we can successfully execute a simple command
    
    """
    from ansible.module_utils.psrp import Connection
    connection = Connection(dict(ansible_port=8085, ansible_user='ansible', ansible_password='pass', ansible_server='localhost'))
    connection.connect()
    resp = connection._exec_psrp_script('hostname')
    assert resp == (0, '127.0.0.1', '')
    resp = connection._exec_psrp_script('powershell -command "&{write-output \'Hello world!\'}')
    assert resp == (0, 'Hello world!', '')
    resp = connection._exec_psrp_script('powershell -command "&{write-error \'Hello error!\'}')

# Generated at 2022-06-23 10:00:14.001073
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup and initialize the plugin, this will register the plugin
    # and set the correct paths for ansible.cfg, inventory, hosts, etc.
    context = setup_psrp_plugin()

    # Create a connection to test against.
    connection = Connection(context.cls._play_context, context.cls._new_stdin)

    # Test cases.

# Generated at 2022-06-23 10:00:15.695312
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # TODO: add tests
    pass

# Generated at 2022-06-23 10:00:20.890867
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection(play_context=play_context)
    assert os.getpid() == conn.get_option('persistent_command_pid')
    conn.reset()
    assert 0 == conn.get_option('persistent_command_pid')
    assert conn.runspace is None
    assert not conn._connected
    assert conn._last_pipeline is None



# Generated at 2022-06-23 10:00:31.382813
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = psrp_exec.Connection(Inventory())
    out_path = ""
    in_path = ""
    in_data = ""
    with mock.patch('ansible.plugins.connection.psrp_exec.base64.b64encode') as b64encodemock:
        with mock.patch('ansible.plugins.connection.psrp_exec.connection.Connection.exec_command') as execcommandmock:
            connection.put_file(out_path, in_path, in_data)

# Generated at 2022-06-23 10:00:37.923840
# Unit test for method close of class Connection
def test_Connection_close():
    from ansible.module_utils import psrp
    import mock
    # remove invocation of object destroy method
    runspace_pool_destroy_fqn = 'ansible.module_utils.psrp.RunspacePool.destroy'
    with mock.patch(runspace_pool_destroy_fqn):
        psrp_connection = psrp.Connection(dict(ansible_connection='psrp'))
        psrp_connection.close()

# Generated at 2022-06-23 10:00:42.164187
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection(None)
    with pytest.raises(AnsibleError) as exc_info:
        connection.fetch_file("", "/")
    assert "fetch_file could not be used" in str(exc_info.value)


# Generated at 2022-06-23 10:00:49.493536
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # initialize
    conn = Connection()
    command_executed = 0
    try:
        conn.exec_command()
        command_executed += 1
    except Exception as e:
        assert(str(e) == "Not implemented")
    # test command exec
    conn = Connection()
    command_executed = 0
    try:
        conn.exec_command("Get-Process")
    except Exception as e:
        command_executed += 1
    assert(command_executed == 1)

# Generated at 2022-06-23 10:01:02.222609
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Assign
    source = 'test source'
    dest = 'test dest'
    host = 'test host'
    remote_user = 'test user'
    remote_pass = 'test pass'
    port = 5985
    connection = Connection(self._play_context, self._new_stdin)
    self.connection._psrp_protocol = 'http'
    self.connection._psrp_port = 5985
    self.connection._psrp_host = host
    self.connection._psrp_user = remote_user
    self.connection._psrp_pass = remote_pass
    write_script = """$stream = [System.IO.StreamWriter]::"new"("%s")
$stream.WriteLine("foo")
$stream.Close()"""

# Generated at 2022-06-23 10:01:16.615945
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-23 10:01:26.606547
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()

    connection.close()

    # Assert that all properties have default values.
    assert connection._psrp_host == ""
    assert connection._psrp_user == ""
    assert connection._psrp_pass == ""
    assert connection._psrp_protocol == ""
    assert connection._psrp_port == 0
    assert connection._psrp_path == ""
    assert connection._psrp_auth == ""
    assert connection._psrp_cert_validation == ""
    assert connection._psrp_connection_timeout == ""
    assert connection._psrp_read_timeout == ""
    assert connection._psrp_message_encryption == ""
    assert connection._psrp_proxy == ""
    assert connection._psrp_ignore_proxy == ""
    assert connection._psr

# Generated at 2022-06-23 10:01:32.510787
# Unit test for method close of class Connection
def test_Connection_close():
    """
    Test close
    """
    runspace = Mock()
    runspace.state = RunspacePoolState.OPENED
    conn = Connection(runspace, settings=Mock())
    conn.close()
    assert runspace.close.call_count == 1
    assert conn.runspace is None
    assert not conn._connected
    assert conn._last_pipeline is None

# Generated at 2022-06-23 10:01:47.950278
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    host = 'host'
    user = 'username'
    password = 'password'
    

# Generated at 2022-06-23 10:01:56.406888
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    # Test when the command was not given
    connection = psrp.Connection()
    try:
        connection.exec_command('')
        assert False, 'AnsibleConnectionFailure not thrown'
    except AnsibleConnectionFailure:
        pass

    # Test when the command was given
    connection = psrp.Connection()
    rc, stdout, stderr = connection.exec_command('Write-Host "Test"')
    assert rc == 0
    assert stdout == b'Test\r\n'
    assert stderr == b''


# Generated at 2022-06-23 10:01:58.662941
# Unit test for method reset of class Connection
def test_Connection_reset():
  connection = Connection()
  connection.reset()


# Generated at 2022-06-23 10:02:09.590807
# Unit test for method reset of class Connection
def test_Connection_reset():

    mock_self = create_autospec(Connection)
    mock_self.runspace = create_autospec(RunspacePool)
    mock_self._connected = create_autospec(bool)
    mock_self._last_pipeline = create_autospec(PowerShell)
    mock_self.runspace.state = create_autospec(RunspacePoolState)

    with patch.object(mock_self.runspace.state, 'OPENED', autospec=True) as mock_state_OPENED:
        mock_self.runspace.state.OPENED = create_autospec(RunspacePoolState)
        mock_self.runspace.state.OPENED = RunspacePoolState.OPENED


# Generated at 2022-06-23 10:02:21.926592
# Unit test for method reset of class Connection
def test_Connection_reset():
    con = Connection()
    
    class DummyHost:
        pass
    
    class DummyTask:
        def __init__(self):
            self.args = dict()
            self.args['connection'] = 'winrm'
            self.args['host_info'] = dict()
            self.args['host_info']['host'] = '192.168.1.1'
            self.args['host_info']['port'] = 5986
            self.args['host_info']['username'] = 'Administrator'
            self.args['host_info']['password'] = 'password'
            self.args['host_info']['transport'] = 'ssl'
            self.args['host_info']['uri'] = 'https://192.168.1.1:5986/wsman'


# Generated at 2022-06-23 10:02:29.049112
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible import errors
    from ansible.plugins.connection.psrp import Connection
    from ansible.module_utils.powershell import PSRPShell

    # Create a temporary file for testing
    tf = tempfile.NamedTemporaryFile()
    # Get the name of the file
    fname = os.path.basename(tf.name)
    # Add some text to the file
    tf.write(b'Hello World!')
    tf.flush()

    mock_psrp_endpoint = Mock()
    mock_psrp_client = Mock()
    mock_psrp_client.get_shell.return_value = mock_psrp_endpoint

# Generated at 2022-06-23 10:02:30.947400
# Unit test for method reset of class Connection
def test_Connection_reset():
    # psrp_connection = Connection()
    # psrp_connection.reset()
    pass

# Generated at 2022-06-23 10:02:43.324233
# Unit test for constructor of class Connection
def test_Connection():
    import pytest

    class PsHost:
        def __init__(self):
            self.rc = 0
            self.ui = PsHostUI()

        def create_runspace_pool(self, **kwargs):
            return PsRunspacePool(host=self, **kwargs)

    class PsHostUI:
        def __init__(self):
            self.stdout = []
            self.stderr = []

    class PsRunspacePool:
        def __init__(self, host, **kwargs):
            self.host = host
            self.kwargs = kwargs

        def open(self):
            self.state = 'opened'


# Generated at 2022-06-23 10:02:46.033151
# Unit test for method close of class Connection
def test_Connection_close():
    conn = Connection()
    # ToDo:  Add test code here
    assert conn != None


# Generated at 2022-06-23 10:02:57.091713
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    from ansible_collections.jctanner.psrp_winrm.plugins.connection.psrp import PSRPConnection
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts.system.appveyor import Appveyor
    from ansible.module_utils.facts.system.mikrotik import Mikrotik
    from ansible.module_utils.facts.system.netapp import NetApp
    from ansible.module_utils.facts.system.pfsense import PfSense
    from ansible.module_utils.facts.system.solaris import Solaris
    from ansible.module_utils.facts.system.pfsense import PfSense
    from ansible.module_utils.facts.system.vsphere import VmwareSystemInfo

# Generated at 2022-06-23 10:02:57.579558
# Unit test for method close of class Connection
def test_Connection_close():
    pass

# Generated at 2022-06-23 10:03:09.235750
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    psrp_host = 'psrp.host'
    psrp_port = 9999
    psrp_path = ''
    psrp_user = 'psrp.user'
    psrp_pass = 'psrp.password'
    psrp_protocol = 'psrp.protocol'
    psrp_auth = 'psrp.auth'
    proxy_host = ''
    proxy_port = 9999
    proxy_user = ''
    proxy_pass = ''
    psrp_timeout = 9999
    psrp_operation_timeout = 9999

# Generated at 2022-06-23 10:03:18.160763
# Unit test for method close of class Connection
def test_Connection_close():
    args = {}
    curdir = os.path.dirname(__file__)
    args['playbook_path'] = os.path.join(curdir, 'single_host.yml')
    if not os.path.exists(args['playbook_path']):
        os.chdir(curdir)

    pb = PlaybookExecutor(playbooks=[args['playbook_path']], inventory=inventory, variable_manager=variable_manager, loader=loader)
    results = pb.run()
    assert results == 0
    assert os.path.exists(os.path.join(curdir, 'single_host_output.log'))


# Generated at 2022-06-23 10:03:19.677679
# Unit test for method close of class Connection
def test_Connection_close():
    conn_obj = Connection(None)
    conn_obj.close()

# Generated at 2022-06-23 10:03:23.363269
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    result = connection.put_file('/test/test_file', 'test/test_file')
    assert result == None

# Generated at 2022-06-23 10:03:35.185802
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """
    Connection.exec_command()
    """
    # FIXME: constructor tests
    with pytest.raises(NotImplementedError):
        task_vars = dict()
        tmp_path = "/tmp"
        inject = dict()
        runner_connection = Connection('psrp', 'acitestuser', 'acitestpass', port=5985, protocol='http',
                                       hostname='10.193.93.60', local_tmp_path=tmp_path, task_uuid=None, task_vars=task_vars,
                                       inject=inject, config=None, connection_info=dict())
    with pytest.raises(NotImplementedError):
        task_vars = dict()
        tmp_path = "/tmp"
        inject = dict()

# Generated at 2022-06-23 10:03:36.281868
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Requires open connection
    pass


# Generated at 2022-06-23 10:03:48.425213
# Unit test for method reset of class Connection
def test_Connection_reset():
    from ansible import context
    from ansible.plugins.connection.psrp import Connection
    from ansible.plugins.loader import connection_loader
    from ansible.template import Templar

    # Hack to get around Ansibles inventory parsing
    context.CLIARGS = lambda: None
    context.CLIARGS.connection = 'psrp'

    # Mock the connection_loader imports
    connection_loader.get('winrm', class_only=True)
    connection = Connection()
    connection._build_kwargs = lambda: None
    connection._exec_psrp_script = lambda script, input_data=None, use_local_scope=True, arguments=None: (0, '', '')
    connection._parse_pipeline_result = lambda pipeline: (0, '', '')

    # Mock the templating
    tem

# Generated at 2022-06-23 10:03:55.348181
# Unit test for method reset of class Connection
def test_Connection_reset():
    '''test_Connection_reset'''
    psrp_patcher = mock.patch('ansible.plugins.connection.psrp.Connection._connect')
    with psrp_patcher as mock_connect:
        mock_connect.side_effect = Exception('fake')
        psrp_connection = Connection(mock.MagicMock())
        try:
            psrp_connection.reset()
        except Exception:
            pass
    assert not psrp_connection._connected
    assert psrp_connection.runspace is None
    assert psrp_connection._last_pipeline is None

# Generated at 2022-06-23 10:04:08.343776
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    host = "localhost"
    connection_class = PSRPAuth
    psrp_obj = connection_class()
    psrp_obj._psrp_host = host
    psrp_obj.host = None
    inventory_manager = None
    loader = None
    variable_manager = None
    psrp_obj._play_context = PlayContext()
    psrp_obj._connected = True
    psrp_obj._connection = None
    psrp_obj.runspace = None
    psrp_obj._psrp_path = None
    psrp_obj.BASE_CMD = b'/usr/bin/python'
    psrp_obj._build_kwargs = Mock(return_value={})

# Generated at 2022-06-23 10:04:20.345452
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.tranport.psrp import Connection
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create data loader
    loader = DataLoader()

    # Create inventory and pass to var manager
    inventory = InventoryManager(loader=loader, sources=[])
    var_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a host
    host = Host(name="test")

    # Set connection variables
    host.set_variable('ansible_psrp_connection', 'winrm')
    host.set_variable('ansible_psrp_server', 'TEST_PSRP_SERVER')

# Generated at 2022-06-23 10:04:25.870885
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    b_runspace_id = b"$runspace_id"
    instance = Connection()
    in_path = "in_path"
    out_path = "out_path"
    file_size = 100
    file_attributes = 10
    # TODO: Add test once implemented


# Generated at 2022-06-23 10:04:35.355311
# Unit test for method close of class Connection
def test_Connection_close():
    # Test case
    # setup the protocol_impl so we can test it
    protocol_impl._psrp_protocol = 'http'
    protocol_impl._psrp_host = 'test_host'
    protocol_impl._psrp_port = 5986
    protocol_impl._psrp_user = 'test_user'
    protocol_impl._psrp_pass = 'test_pass'
    protocol_impl._psrp_cert_validation = True
    protocol_impl._psrp_connection_timeout = 60
    protocol_impl._psrp_read_timeout = 60
    protocol_impl._psrp_message_encryption = True
    protocol_impl._psrp_proxy = None
    protocol_impl._psrp_ignore_proxy = False
    protocol_impl._psrp_operation

# Generated at 2022-06-23 10:04:38.329801
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection()
    assert isinstance(c, Connection)

# Generated at 2022-06-23 10:04:46.181938
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
        with patch('psrp.client.WSMan.reconnect') as mock_reconnect:
            with patch('ansible.plugins.connection.psrp.Connection.reconnect', new=mock_meth(mock_reconnect)):
                conn = Connection()
                conn.reset()
                assert mock_reconnect.call_count == 1
    except ImportError:
        pass


# Generated at 2022-06-23 10:04:54.498145
# Unit test for constructor of class Connection
def test_Connection():
    '''
    Unit test for constructor of AnsiblePSRPConnection class
    '''
    # Test no options supplied, no need to test options as they are tested individually
    options = {}
    conn = AnsiblePSRPConnection(play_context=PlayContext(), new_stdin=None, **options)

    # Test psrp_path not supplied
    options = {
        'ansible_user': 'test_user',
        'ansible_password': 'test_password',
        'ansible_port': 5985
    }
    conn = AnsiblePSRPConnection(play_context=PlayContext(), new_stdin=None, **options)
    assert conn._psrp_path == u'/wsman'
    assert conn._psrp_port == 5985

    # Test psrp_path supplied

# Generated at 2022-06-23 10:04:59.764823
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create connection instance
    conn = Connection()
    # Create function arguments
    script = "ls"
    # Execute exec_command method
    rc, stdout, stderr = conn.exec_command(script)