

# Generated at 2022-06-23 09:55:06.455440
# Unit test for method reset of class Connection
def test_Connection_reset():

    mock_self = Mock()
    mock_self.runspace = Mock()
    mock_self._connected = Mock()
    mock_self._last_pipeline = Mock()

    # Invoke method
    ansible_psrp._connection.Connection.reset(mock_self)

    # Assert return values
    assert mock_self.runspace.state.called
    assert mock_self.runspace.close.called
    assert mock_self.runspace.called
    assert mock_self._connected.called
    assert mock_self._last_pipeline.called
    assert mock_self._last_pipeline.called


# Generated at 2022-06-23 09:55:17.228169
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    my_module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='path', required=True),
            dest=dict(type='path'),
            validate_certs=dict(type='bool', required=False),
            follow=dict(type='bool', required=False),
        )
    )

    # Test invalid dest path
    file_path = os.path.split(__file__)[0]
    sub_dir = file_path + os.sep + 'test_dir' + os.sep + 'my_module.py'
    sub_dir_file = 'test_dir' + os.sep + 'my_module.py'

# Generated at 2022-06-23 09:55:22.284040
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.last_pipeline = None
    connection.runspace = RunspacePool()
    connection.runspace.state = RunspacePoolState.OPENED
    connection.close()
    assert connection.runspace == None
    assert connection._connected == False
    assert connection._last_pipeline == None


# Generated at 2022-06-23 09:55:25.109656
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection(play_context=play_context)
    assert connection.close() == None

# Generated at 2022-06-23 09:55:26.532309
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    assert not connection.connected




# Generated at 2022-06-23 09:55:39.403480
# Unit test for method exec_command of class Connection

# Generated at 2022-06-23 09:55:42.719132
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    p = psrp.PSRPConnection()
    assert p.put_file == Connection.put_file
    assert callable(p.put_file)

# Generated at 2022-06-23 09:55:46.679483
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.put_file(in_path, out_path)
    assert out_path.exists()
    assert out_path.read_text('utf-8') == in_path.read_text('utf-8')
    out_path.unlink()


# Generated at 2022-06-23 09:55:53.003488
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    import json
    import pytest
    import sys
    import shutil
    import tempfile
    import os
    import base64
    pytest.main([__file__])
    local_path = os.path.join(tempfile.gettempdir(), to_text(uuid.uuid4()))
    b_local_path = to_bytes(local_path, errors='surrogate_or_strict')
    remote_path = os.path.join(tempfile.gettempdir(), to_text(uuid.uuid4()))
    b_remote_path = to_bytes(remote_path, errors='surrogate_or_strict')

# Generated at 2022-06-23 09:56:03.256081
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    import tempfile
    local_file = tempfile.NamedTemporaryFile(mode='w')
    local_file.write("foo")
    local_file.flush()
    local_file.seek(0)

    conn = Connection(dict())

    remote_file = tempfile.NamedTemporaryFile(mode='w')
    try:
        conn.put_file(local_file.name, remote_file.name)

        remote_file.seek(0)
        contents = remote_file.read()
        print(contents)
        assert contents == "foo"
    finally:
        remote_file.close()

    local_file.close()



# Generated at 2022-06-23 09:56:05.443510
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    assert connection.close() is None


# Generated at 2022-06-23 09:56:07.196415
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()

# Generated at 2022-06-23 09:56:14.303795
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    # Arrange
    connection = Connection('192.168.1.1', '22', 'powershell', 'bob')
    filename = 'file.txt'
    out_path = '/tmp/'
    file_bytes = '123'
    display = Display()

    # Act
    connection.fetch_file(filename, out_path)

    # Assert
    assert(file_bytes == out_path)


# Generated at 2022-06-23 09:56:21.021407
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # from ansible.plugins.connection.psrp import Connection
    connection = Connection(None)
    mocker.patch.object(connection, 'runspace')
    runspace = connection.runspace
    mocker.patch.object(runspace, 'state', RunspacePoolState.OPENED)
    mocker.patch.object(connection, '_exec_psrp_script')
    connection._exec_psrp_script.side_effect = ([0, "", ""])
    # Test with args and kwargs
    # test = connection.put_file('/path/to/file', '/path/to/file')
    # assert test == None

# Generated at 2022-06-23 09:56:34.965690
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    """
    This unit test is testing the fetch_file method of class Connection
    """
    from ansible.inventory.host import Host
    host = create_host_mock(
        {
            "ansible_psrp_server": "mytarget",
            "ansible_psrp_port": 5986
        },
        "my_psrp"
    )
    psrp_mock = Mock(spec=Connection)
    psrp_mock._psrp_host = "my_psrp"
    psrp_mock._psrp_user = "my_user"
    psrp_mock._psrp_pass = "my_pass"
    psrp_mock._psrp_protocol = "http"
    psrp_mock._psrp_

# Generated at 2022-06-23 09:56:42.613445
# Unit test for constructor of class Connection

# Generated at 2022-06-23 09:56:52.683095
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    print('Start Test')
    # Allows to test the module without the risk of altering your system

# Generated at 2022-06-23 09:57:05.604190
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    in_file_path = 'dummy_in_file'
    out_file_path = 'dummy_out_file'
    buffer_size = 'dummy_buffer_size'
    transfer_data = 'dummy_transfer_data'
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    from ansible.plugins.connection.psrp import AUTH_KWARGS
    from ansible.plugins.connection.psrp import PSRP_CONN_COMMON_ARGS
    from mock import Mock, patch
    mock_module = Mock()
    mock_module.params = dict()
    for arg in PSRP_CONN_COMMON_ARGS:
        mock_module.params[arg] = 'dummy_arg'
    mock_base64 = Mock()


# Generated at 2022-06-23 09:57:08.947997
# Unit test for method close of class Connection
def test_Connection_close():
  connection = psrp_Connection()
  connection.close()



# Generated at 2022-06-23 09:57:10.200718
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    assert connection.fetch_file() == None

# Generated at 2022-06-23 09:57:20.302771
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from tempfile import TemporaryFile
    from ansible_collections.notstdlib.moveitallout.plugins.connection.psrp import Connection

    fp = TemporaryFile()
    fp.write(b'testing')
    fp.seek(0)

    conn = Connection(dict(ansible_user='test_user', ansible_password='test_password',
                           ansible_port=5986, ansible_host='localhost'))
    conn._build_kwargs()
    conn.host = FakePsrpHost(FakePsrpResponses())

    conn._exec_psrp_script("New-Item -ItemType file -Force -Path '%s'" % 'C:/Temp/test')
    conn.put_file(None, 'C:/Temp/test', fp)



# Generated at 2022-06-23 09:57:25.370689
# Unit test for method close of class Connection
def test_Connection_close():
    p = PluginLoader('./', 'Connection')
    plugin_obj = p.load_plugin('Connection', 'psrp', C.config, C, C.connection_loader)
    plugin_obj.set_options()
    plugin_obj.close()


# Generated at 2022-06-23 09:57:27.861583
# Unit test for method close of class Connection
def test_Connection_close():
    pass


# Generated at 2022-06-23 09:57:33.330152
# Unit test for method close of class Connection
def test_Connection_close():
    mock_self = _setup_mock_self()
    mock_self.runspace = mock.Mock()
    mock_self.runspace.state = RunspacePoolState.OPENED
    return_value = Connection.close(mock_self)
    assert return_value is None


# Generated at 2022-06-23 09:57:39.031211
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection(play_context=play_context)
    p = Mock(**{'read.side_effect': ['foo', 'bar', 'baz', '']})
    connection.put_file(in_path='/tmp/in_path', out_path='/tmp/out_path', in_data=p)
    connection.close()


# Generated at 2022-06-23 09:57:48.751568
# Unit test for constructor of class Connection
def test_Connection():
    from ansible.plugins.connection.psrp import Connection

    def get_psrp_conn():
        return Connection(
            play_context=None,
            new_stdin=None,
            remote_addr='foo',
            remote_user='bar',
            password='test',
            port=5985,
            connection_timeout=10,
            args=['test'],
            private_key_file='test',
        )

    # Test with Kerberos authentication disabled, should throw an exception
    try:
        get_psrp_conn()
        assert False
    except SystemExit:
        assert True

    # Test with Kerberos authentication enabled and no kerberos module
    os.environ['ANSIBLE_PSRP_USE_KERBEROS'] = '1'

# Generated at 2022-06-23 09:57:49.657005
# Unit test for method reset of class Connection
def test_Connection_reset():
    pass


# Generated at 2022-06-23 09:57:51.116079
# Unit test for constructor of class Connection
def test_Connection():
    c = Connection(None)
    c.exec_command("dir")



# Generated at 2022-06-23 09:58:01.727763
# Unit test for method put_file of class Connection
def test_Connection_put_file():
  con = Connection()
  con._psrp_protocol = None
  con._psrp_port = None
  con._psrp_path = None
  con._psrp_auth = None
  con._psrp_cert_validation = True
  con._psrp_connection_timeout = None
  con._psrp_read_timeout = None
  con._psrp_message_encryption = False
  con._psrp_proxy = None
  con._psrp_ignore_proxy = None
  con._psrp_operation_timeout = None
  con._psrp_max_envelope_size = None
  con._psrp_configuration_name = None
  con._psrp_reconnection_retries = None
  con._psrp_reconnection_back

# Generated at 2022-06-23 09:58:13.243122
# Unit test for method put_file of class Connection
def test_Connection_put_file():

    # Testing that put_file writes the contents of the buffer to the remote file
    class MockFile(object):
        def __init__(self, name, mode):
            self.name = name
            self.mode = mode

    class MockConnection(Connection):
        def __init__(self):
            super(MockConnection, self).__init__(None)
            self._put_file_obj = {}

        def put_file_in_buffer(self, in_path, out_path, args=None, buffer_size=65536):
            self._put_file_obj[out_path] = open(in_path, 'rb')

        def _exec_psrp_script(self, script, input_data=None, use_local_scope=True, arguments=None):
            out_path = arguments[0]
            new

# Generated at 2022-06-23 09:58:14.660551
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
	pass


# Generated at 2022-06-23 09:58:26.356481
# Unit test for constructor of class Connection
def test_Connection():  # pylint: disable=unused-variable
    inventory = ansible.parsing.dataloader.DataLoader()
    display = ansible.utils.display.Display()

# Generated at 2022-06-23 09:58:28.417349
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(None, None)

    assert connection is not None

# Generated at 2022-06-23 09:58:34.429220
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    """
    fetch_file unit test stub.
    """
    # unit test for Connection.fetch_file
    if not is_pypsrp_installed():
        pytest.skip('pypsrp not installed')
    pytest.skip('Test not implemented')


# Generated at 2022-06-23 09:58:35.649516
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()

# Generated at 2022-06-23 09:58:47.877189
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import mock
    try:
        from unit.ansible_module import AnsibleModule
    except:
        from ansible.module_utils.ansible_module import AnsibleModule


# Generated at 2022-06-23 09:59:04.010901
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import mock
    import os
    import tempfile
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import BytesIO
    from units.mock.procenv import swap_stdin_and_argv

    # Create a dummy connection class that can be used for testing.
    class DummyConnection:
        _connected = False
        runspace = None
        _last_pipeline = None
        host = None
        _psrp_host = None

    # Test using a real runspace.
    conn = DummyConnection()
    conn.host = WSManHost(encoding='utf-8', no_ssl=True)
    conn.runspace = RunspacePool(conn.host)
    conn.runspace.open()
    conn.runspace.load_assembly('System.IO')
   

# Generated at 2022-06-23 09:59:07.071390
# Unit test for method close of class Connection
def test_Connection_close():
    '''
    Unit test for method close of class Connection.
    '''
    # Initialization
    obj = Connection(play_context=play_context, new_stdin=new_stdin)
    # Execution
    obj.close()

# Generated at 2022-06-23 09:59:14.774762
# Unit test for constructor of class Connection
def test_Connection():
    '''
    Unit test for constructor of class Connection
    '''
    runner = Connection('localhost')

    assert runner.protocol == 'psrp'
    assert runner.port == 5985
    assert runner.has_pipelining is True
    assert runner.become is None
    assert runner.become_method is None
    assert runner.become_user is None

# Generated at 2022-06-23 09:59:16.287504
# Unit test for method close of class Connection
def test_Connection_close():
    bc = Connection()
    bc.close()


# Generated at 2022-06-23 09:59:21.995428
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection()
    assert connection.host is None
    assert connection.port is None
    assert connection.user is None
    assert connection.password is None
    assert connection.private_key_file is None
    assert connection.timeout is 10
    assert connection._connected is False
    assert connection.shell is None
    assert connection._shell_type == 'powershell'
    assert connection._last_pipeline is None
    assert connection._play_context is None
    assert connection._shell_id is None


# Generated at 2022-06-23 09:59:31.456644
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection(play_context=PlayContext(), new_stdin=None)
    connection = Connection(play_context=PlayContext(), new_stdin=None)
    connection = Connection(play_context=PlayContext(), new_stdin=None)
    connection = Connection(play_context=PlayContext(), new_stdin=None)
    connection.close()

# Generated at 2022-06-23 09:59:38.723475
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    class MockHost:
        name = None
        shell = None
        port = 65535
        def __init__(self, name, shell):
            self.name = name
            self.shell = shell
    
    class MockConnectionInfo:
        def __init__(self, uuid, host, connection):
            self.uuid = uuid
            self.host = host
            self.connection = connection
            self.protocol = 'https'
        def run_ps(self, *args, **kwargs):
            return '', '', 0
        def run_cmd(self, *args, **kwargs):
            return '', '', 0
        def __str__(self):
            return 'ConnectionInfo: ' + self.uuid
        

# Generated at 2022-06-23 09:59:43.586121
# Unit test for constructor of class Connection
def test_Connection():
    module = mock.MagicMock()
    conn = Connection(module._socket_path)
    assert isinstance(conn, Connection)
    module.fail_json.assert_called_with(
        msg='to use the "psrp" connection type, pypsrp must be installed on the local Ansible control host and on '
            'the remote host being managed via PSRP',
        exception=None)

# Generated at 2022-06-23 09:59:53.625750
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    ansible = Ansible(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'myhost', None, None, None)
    my_connection = Connection(ansible)

# Generated at 2022-06-23 10:00:04.339569
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    cmd_connection = PSRPConnection()
    output_dir = 'test_dir'
    src = 'test_src'
    b_dest = 'dest/test_dest'
    local_checksum = 'checksum'
    dest_checksum = 'none'
    follow = True
    inject = {'test_dict': 'test_value'}


# Generated at 2022-06-23 10:00:10.793697
# Unit test for method reset of class Connection
def test_Connection_reset():
    '''
    Unit test for method reset on class Connection
    '''

    # Initialize a test object
    conn = Connection()

    # Set some test variables
    var__psrp_auth = 'Credssp'

    # Invoke method
    conn.reset(
        _psrp_auth=var__psrp_auth,
    )

# Generated at 2022-06-23 10:00:11.411843
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
	pass

# Generated at 2022-06-23 10:00:19.352817
# Unit test for method close of class Connection
def test_Connection_close():
	mock_self = mock.Mock()
	mock_self.runspace = mock.Mock()
	mock_self.runspace.state = mock.Mock()
	mock_self.runspace.state.OPENED = mock.Mock()
	mock_self._psrp_host = mock.Mock()
	mock_self._connected = mock.Mock()
	mock_self._last_pipeline = mock.Mock()

	expected_result = None
	actual_result = Connection.close(mock_self)

	assert expected_result == actual_result

# Generated at 2022-06-23 10:00:25.053858
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    
    if len(sys.argv) < 2:
        print("You must supply a Connection object!")
        sys.exit(1)
        
    # Use the get_connection module to instantiate a Connection object
    # You need to first modify the module to set your THOR_CONNECTION
    # environment variable and change the code to import this module.
    connection_obj = get_connection(sys.argv[1])
    
    # Create an invalid Connection object (no remote_addr)
    if connection_obj.remote_addr == '':
        connection_obj.remote_addr = 'bogus'
        local_addr = connection_obj.remote_addr
        connection_obj.remote_addr = ''
    
    # Create a temp file
    tmpfile = tempfile.NamedTemporaryFile(mode="w")
    


# Generated at 2022-06-23 10:00:37.605376
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    src_path = 'C:\\temp\\test.txt'
    dest_path = 'C:\\temp\\test_copy.txt'
    host = 'fake_host'
    user = 'fake_user'
    password = 'fake_password'
    protocol = 'fake_protocol'
    port = 5986
    opt = Options()
    opt.become = False
    opt.become_method = 'fake_become_method'
    opt.become_user = 'fake_become_user'
    opt.verbosity = 4
    opt.connection = 'psrp'
    opt.remote_addr = host
    opt.remote_user = user
    opt.remote_password = password
    opt.protocol = protocol
    opt.port = port
    

# Generated at 2022-06-23 10:00:47.500642
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import tempfile
    import pypsrp
    from ansible.errors import AnsibleError
    from psrp.test import utils
    from psrp.exceptions import PyPsrpError
    # Remote filename that should exists
    in_path = "test_Data.txt"
    # Read range size
    buffer_size = 1024
    # Length of file
    file_length = 10240
    # Expected file length
    length = 1024
    # Connection instance
    connection = Connection(play_context=PlayContext())
    # Set the connection parameters
    connection._psrp_host = "localhost"
    connection._psrp_port = 5986
    connection._psrp_user = "vagrant"
    connection._psrp_pass = "vagrant"

# Generated at 2022-06-23 10:00:56.085344
# Unit test for constructor of class Connection
def test_Connection():
    '''
    Ensure that Connection class successfully creates a psrp connection
    '''
    display.vvvvv = Mock()
    psrp_connection = Connection(
        host="127.0.0.1",
        port=5985,
        user="user",
        password="password",
        protocol="http",
        proxy=None,
        ignore_proxy=True,
        server_cert_validation="ignore"
    )

    assert isinstance(psrp_connection.session, pypsrp.client.Client)

# Generated at 2022-06-23 10:00:57.564993
# Unit test for method reset of class Connection
def test_Connection_reset():
	connection = Connection()
	connection.reset()

# Generated at 2022-06-23 10:01:07.932692
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conf = dict(
        protocol='http',
        port=5985,
        remote_addr='127.0.0.1',
        remote_user='vagrant',
        remote_password='vagrant',
        connection='psrp',
        module_path=['/to/mymodules'],
        become=True,
        become_method='runas',
        become_user='administrator',
        become_password='Passw0rd!'
    )
    pc = TaskExecutor(conf)._play_context
    connection = Connection(pc._play_context, pc)
    # Setup test data
    # in_path = 'C:\\Users\\vagrant\\AppData\\Local\\Temp\\test_psrp_file.cfg'
    # out_path = 'c:\\ansible_test\\test.cfg'
    #

# Generated at 2022-06-23 10:01:09.179289
# Unit test for method close of class Connection
def test_Connection_close():
    connection_psrp = Connection('psrp')
    connection_psrp.close()

# Generated at 2022-06-23 10:01:20.493793
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible_collections.ansible.builtin.plugins.module_utils import psrp
    import pypsrp
    from ansible.config.manager import ConfigManager
    import ansible_collections.ansible.builtin.plugins.module_utils.basic
    import ansible_collections.ansible.builtin.plugins.module_utils.connection
    import ansible_collections.ansible.builtin.plugins.module_utils.network
    import os
    import tempfile
    from mock import Mock

    filename = 'test_file'
    connection = Connection(ConfigManager(os.path.dirname(ansible_collections.ansible.builtin.plugins.module_utils.__file__)).get_module_config(psrp))

    # Ensure the module does not except

# Generated at 2022-06-23 10:01:28.814891
# Unit test for method put_file of class Connection
def test_Connection_put_file():

# Check if the module can connect to host
    con = Connection()
    if(con.host != 'localhost'):
        print("connection.host != 'localhost'")
    if(con.port != 5986):
        print("connection.port != 5986")
    if(con.path != 'wsman'):
        print("connection.path != 'wsman'")
    if(con.protocol != 'https'):
        print("connection.protocol != 'https'")
    

# Generated at 2022-06-23 10:01:33.178908
# Unit test for constructor of class Connection
def test_Connection():
    unittest.main()

if __name__ == "__main__":
    # TODO: take in environment variables to set the connection
    # options as an alternative
    unittest.main()

# Generated at 2022-06-23 10:01:42.574462
# Unit test for method close of class Connection
def test_Connection_close():
    psrp = mock.Mock()
    rs = mock.Mock()
    psrp.protocol = 'https'
    psrp.port = 5986
    psrp.server = '127.0.0.1'
    psrp.username = 'foo'
    psrp.password = 'bar'
    
    rs.state = RunspacePoolState.OPENED
    rs.id = 1
    
    conn = Connection(psrp, rs)
    conn.close()
    assert conn._connected is False
    assert conn.runspace is None
    assert conn._last_pipeline is None
    

# Generated at 2022-06-23 10:01:47.717885
# Unit test for method reset of class Connection
def test_Connection_reset():
    from ansible.module_utils.psrp import Connection
    from psrp.exceptions import RunspacePoolState

    connection = Connection('localhost')
    connection.runspace = 'mock.runspace'
    connection.runspace.state = 'MOCK_STATE'
    connection.reset()
    assert 'mock.runspace' != connection.runspace
    assert connection.runspace.state == RunspacePoolState.CLOSED



# Generated at 2022-06-23 10:01:52.380394
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    from ansible.module_utils.powershell import PSRPConnection
    ansible_connection = PSRPConnection('/tmp/ansible_pypsrp/test_pypsrp_exec_powershell_1')
    ansible_connection._build_kwargs()


# Generated at 2022-06-23 10:02:01.288871
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    host = Host(name='test.example.org')
    variable_manager = VariableManager()
    connection = Connection(host, variable_manager)
    in_file = 'test_file'
    out_file = 'out_file'

    connection.put_file(in_file, out_file)
    # TODO: assert something?
    connection.close()


# Generated at 2022-06-23 10:02:04.822918
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection(None)
    assert conn is not None, "Failed to create Connection object"
#
# Run unit tests
#
import unittest
if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-23 10:02:18.004496
# Unit test for constructor of class Connection
def test_Connection():
    psrp_connection = Connection(dict(
        remote_addr='foo',
        remote_user='bar',
        remote_password='baz',
        protocol='http',
        port=1234,
        path='foobar',
        auth='kerberos',
        cert_validation=False,
        connection_timeout=1,
        read_timeout=2,
        message_encryption='always',
        proxy='foobar',
        proxy_auth='kerberos',
        ignore_proxy=True,
        operation_timeout=3,
        max_envelope_size=10,
        configuration_name='foobar'
    ))
    assert psrp_connection._psrp_host == 'foo'
    assert psrp_connection._psrp_user == 'bar'
    assert psrp_connection

# Generated at 2022-06-23 10:02:29.898947
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    set_module_args(dict(
        host='psrp.example.com',
        port=5986,
        username='testuser',
        password='testpass',
        local_file='C:\\temp\\test.txt',
        remote_path='C:\\temp\\test.txt'
    ))

# Generated at 2022-06-23 10:02:33.410573
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    in_path = "/tmp/file"
    out_path = "/tmp/remote_file"
    try:
        print("Testing fetch_file")
        result = Connection.fetch_file(in_path,out_path)
        assert True == result
    except Exception:
        assert False

# Generated at 2022-06-23 10:02:44.629223
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    mock_display = MagicMock()
    mock_host = MagicMock()
    mock_host.ui = MagicMock()
    mock_host.rc = 0
    mock_host.ui.stderr = []
    mock_read_script = u'$stream = $in | ForEach-Object {' \
                       '$bytes = [System.Text.Encoding]::UTF8.GetBytes($_)' \
                       '$stream.Write($bytes, 0, $bytes.Length)}' \
                       '$bytes = $stream.ToArray();' \
                       '$encoded = [System.Convert]::ToBase64String($bytes);' \
                       '$encoded;' \
                       '$stream.Close()'

# Generated at 2022-06-23 10:02:46.549922
# Unit test for method close of class Connection
def test_Connection_close():
  # TODO: write unit test
  pass

# Generated at 2022-06-23 10:02:51.679335
# Unit test for method reset of class Connection
def test_Connection_reset():
    host_mock = HostStub()
    connection = Connection(None)
    connection._set_host_overrides(host_mock)
    connection.close()

    connection.reset(None)
    assert connection._connected is False
    assert connection.runspace is None

# Generated at 2022-06-23 10:02:53.001848
# Unit test for method close of class Connection
def test_Connection_close():
    # Arguments
    assert True


# Generated at 2022-06-23 10:02:54.393889
# Unit test for constructor of class Connection
def test_Connection():
    connection = create_connection()
    assert(connection)



# Generated at 2022-06-23 10:02:59.955610
# Unit test for method reset of class Connection
def test_Connection_reset():
    #set up
    args = {}
    psrp_host = "psrp_host"
    psrp_user = "psrp_user"
    psrp_pass = "psrp_pass"
   
    #testing
    test = Connection(psrp_host, psrp_user, psrp_pass)
    assert test.runspace
    assert isinstance(test.runspace, RunspacePool)
    test.reset()
    assert not test.runspace
    # teardown


# Generated at 2022-06-23 10:03:12.944462
# Unit test for method reset of class Connection
def test_Connection_reset():
    hostname = 'computer01'
    psrp_pass = 'pass'
    psrp_protocol = 'https'
    psrp_port = 5986
    psrp_path = 'wsman'
    psrp_auth = 'basic'
    psrp_cert_validation = True
    psrp_connection_timeout = None
    psrp_read_timeout = None
    psrp_message_encryption = False
    psrp_proxy = None
    psrp_ignore_proxy = False
    psrp_operation_timeout = 60
    psrp_max_envelope_size = 153600
    psrp_configuration_name = None
    psrp_reconnection_retries = 100
    psrp_reconnection_backoff = 1.0


# Generated at 2022-06-23 10:03:21.655569
# Unit test for method close of class Connection
def test_Connection_close():
    class_type = psrp_connection.Connection
    test_instance = class_type(play_context=MagicMock())

    # test with required args
    args = (MagicMock(), )

    setattr(test_instance, '_connected', True)
    setattr(test_instance, '_psrp_host', 'fake_host')
    setattr(test_instance, 'runspace', MagicMock())
    setattr(test_instance.runspace, 'state', RunspacePoolState.OPENED)
    setattr(test_instance, '_last_pipeline', 'fake_last_pipeline')

    expected_result = None
    expected_stderr = ''


# Generated at 2022-06-23 10:03:24.070780
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    out = connection.close()
    assert out == None, "close must return None"

# Generated at 2022-06-23 10:03:34.718611
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Do an initial test to ensure we can create a connection object
    conn = PSRPConnection('example.com', 'Administrator', 'adminpassword')
    # Need to create a PSRPClient to satisfy the __init__ call of PSRPConnection
    class PSRPClientStub():
        def __init__(self):
            self.host = 'example.com'
            self.username = 'Administrator'
            self.password = 'adminpassword'
    psrp_client = PSRPClientStub()
    conn.set_client(psrp_client)
    # Call exec_command with a PS script that will succeed
    conn.exec_command('''Write-Output "Hello World"''')

# Generated at 2022-06-23 10:03:36.381947
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection()

    assert isinstance(conn, Connection), 'Could not instantiate Connection'

# Generated at 2022-06-23 10:03:48.520863
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    '''Connection.put_file'''
    try:
        from psrp_client.session import Session
    except ImportError:
        Session = None
        pass

    connection = Connection(dict())

# Generated at 2022-06-23 10:03:54.835605
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_class = Connection
    connections = {'default': Connection(play_context=None)}

    runner = Runner(
        connections=connections,
        module_name=None,
    )

    runner.connection = connections['default']
    runner.connection._connected = True
    runner._terminated = False
    runner.host_result = None

    runner.reset()

    assert runner.host_result is None
    assert runner.connection._connected
    assert runner._terminated
    assert runner.connection._last_pipeline is None




# Generated at 2022-06-23 10:03:57.631295
# Unit test for method reset of class Connection
def test_Connection_reset():
    under_test = Connection()
    under_test._connected = True
    test_result = under_test.reset()
    assert test_result == None, "Test result must be type None."


# Generated at 2022-06-23 10:04:10.329332
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Initialize Connection object
    module = 'test_module'
    inventory = 'test_inventory'
    loader = 'test_loader'
    variable_manager = 'test_variable_manager'
    host = 'test_host'
    task_uuid = 'test_task_uuid'
    connection_info = {
        'host': 'test_connection_info_host',
        'port': 123,
        'username': 'test_username',
        'password': 'test_password',
        'private_key_file': 'test_private_key_file',
        'private_key_pass': 'test_private_key_pass',
        'timeout': 123
    }
    
    obj = Connection(module, inventory, loader, variable_manager, host, task_uuid, connection_info)

    # Test properties
   

# Generated at 2022-06-23 10:04:17.322223
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection()
    module_class = connection
    assert module_class.__module__ == 'ansible.plugins.connection.psrp'
    assert module_class.__name__ == 'Connection'
    assert isinstance(module_class.__doc__, str)
    assert module_class.__dict__ == module_class.__slots__ == {}

# Generated at 2022-06-23 10:04:24.254271
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
        work_dir = u"/tmp"
        temp_dir = u"/tmp/tmp_dir"
        command = u"ls"
        module_name = u"shell"
        args = u""
        in_data = u""
        result_queue = Queue()

        # Test with non-existant working directory
        connection = Connection(in_path=work_dir, result_queue=result_queue)
        response = connection.exec_command(module_name=module_name, module_args=args, in_data=in_data)
        assert response == (257, b'', b"Could not find or access '/tmp/tmp_dir'\r\n")
        connection.close()

        # Create working directory
        mkdir(temp_dir)

        # Test with empty directory, should return 0 and ls command output
       

# Generated at 2022-06-23 10:04:32.401027
# Unit test for method reset of class Connection
def test_Connection_reset():
    module = mock.MagicMock()
    module.connection = 'psrp'
    remote_addr = 'L1'
    remote_user = 'L2'
    port = 'L3'
    remote_password = ''
    connection = Connection(module._socket_path, remote_addr, remote_user, port, remote_password)

    original_runspace_state = connection.runspace.state
    connection.reset()
    assert connection.runspace == None
    assert connection.runspace.state == original_runspace_state


# Generated at 2022-06-23 10:04:37.757451
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # If we want to test code that uses PSRP, we need to mock out most of
    # our dependencies, so we only test validating the args
    import ansible.plugins.connection
    # Pull in a copy of Connection's exec_command method...
    exec_command = ansible.plugins.connection.Connection.exec_command
    # ... then replace it with a method that just validates the args.
    ansible.plugins.connection.Connection.exec_command = exec_command
    Connection()
    ansible.plugins.connection.Connection.exec_command = exec_command

# Generated at 2022-06-23 10:04:38.984231
# Unit test for constructor of class Connection
def test_Connection():
    Connection()


# Generated at 2022-06-23 10:04:50.974839
# Unit test for method reset of class Connection
def test_Connection_reset():
    reset_connection = Connection(None)

    reset_connection.host = Connection._host
    reset_connection.runspace = Connection._runspace
    reset_connection.protocol = Connection._protocol
    reset_connection._connected = Connection._connected
    reset_connection._psrp_host = Connection._psrp_host
    reset_connection._psrp_user = Connection._psrp_user
    reset_connection._psrp_pass = Connection._psrp_pass
    reset_connection._psrp_protocol = Connection._psrp_protocol
    reset_connection._psrp_port = Connection._psrp_port
    reset_connection._psrp_path = Connection._psrp_path
    reset_connection._psrp_auth = Connection._psrp_auth
    reset_connection._ps

# Generated at 2022-06-23 10:05:00.477986
# Unit test for method close of class Connection
def test_Connection_close():
    '''
    Connection.close
    '''

    # Test with invalid runspace
    conn = psrp.Connection(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    conn.runspace = None
    conn.close()

    # Test with valid runspace
    conn = psrp.Connection(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    conn._connected = True
    conn._last_pipeline = 5
    conn.runspace = RunspacePool(None, None, None, None, None, None, None)
    conn.runspace.state = RunspacePoolState.OPENED
    object_type