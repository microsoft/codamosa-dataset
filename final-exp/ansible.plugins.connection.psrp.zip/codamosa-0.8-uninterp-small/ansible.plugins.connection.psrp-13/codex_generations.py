

# Generated at 2022-06-25 08:59:50.544398
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path_0 = str()
    out_path_0 = str()
    use_sudo_0 = bool()
    use_su_0 = bool()
    remote_src_0 = bool()
    set_remote_user_0 = bool()
    set_owner_0 = bool()
    set_group_0 = bool()
    create_remote_path_0 = bool()
    delete_remote_path_0 = bool()
    tmp_path_0 = str()
    tmp_path_1 = str()

# Generated at 2022-06-25 08:59:52.474198
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection()
    var_1 = connection_1.exec_command('echo', 'Hello World!')


# Generated at 2022-06-25 08:59:55.418411
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Testing with inputs
    # 1. test_case_0
    connection_0 = Connection()
    in_path_0 = 'test_path'
    out_path_0 = 'test_out_path'
    var_0 = connection_0.put_file(in_path=in_path_0, out_path=out_path_0)


# Generated at 2022-06-25 08:59:59.706462
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print('Testing Connection.put_file()')
    connection_0 = Connection()
    connection_0.host = None
    var_0 = connection_0.put_file(None, None)
    print(var_0)
    print('Done.')


# Generated at 2022-06-25 09:00:01.402629
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:00:08.795114
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path_1 = 'dist/ansible/module_utils/connection/acitoolkit/tests/'
    out_path_1 = '/etc/hosts'
    var_2 = connection_0.put_file(in_path_1, out_path_1)


# Generated at 2022-06-25 09:00:12.504499
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
        test_case_0()
    except Exception as var_1:
        print('Exception message: {}'.format(var_1))
        assert False
    else:
        assert True

# Generated at 2022-06-25 09:00:15.344635
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Test if file is fetched from remote location
    connection_0 = Connection()
    connection_0.connect()
    result = connection_0.fetch_file("D:/test_file.txt", "D:/test_file_copy.txt")
    assert result != -1


# Generated at 2022-06-25 09:00:21.603299
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    args_0 = dict()
    args_0['cmd'] = 'dir'
    connection_0 = Connection()
    var_0 = connection_0.exec_command(**args_0)
    """
    check if the return code is 0.
    """
    assert var_0[0] == 0


# Generated at 2022-06-25 09:00:22.349691
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()


# Generated at 2022-06-25 09:00:43.549497
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    var_1 = connection_0.exec_command('ls')
    assert var_1 is not None, "Null value returned for exec_command"
    assert var_1 == (0, b'', b''), "Unexpected tuple return value"


# Generated at 2022-06-25 09:00:46.858108
# Unit test for method close of class Connection
def test_Connection_close():
    connection_1 = Connection()
    var_0 = connection_1.close()


# Generated at 2022-06-25 09:00:50.178480
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    var_0 = connection_0.exec_command()


# Generated at 2022-06-25 09:00:51.012821
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    test_case_0()

# Generated at 2022-06-25 09:00:55.289259
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import os
    ansible_connection = Connection()
    ansible_in_path = os.path.join('/etc', 'passwd')
    ansible_out_path = os.path.join('/tmp')
    ansible_connection.fetch_file(ansible_in_path, ansible_out_path)


# Generated at 2022-06-25 09:00:56.926016
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 09:01:01.314998
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    var_0 = connection_0.fetch_file(in_path='E:/Src/PsrpPlayground/Ansible-PSRP/tests/unit/files/files_to_fetch/1KB_random.txt', out_path='E:/Src/PsrpPlayground/Ansible-PSRP/tests/unit/files/files_fetched/1KB_random.txt')



# Generated at 2022-06-25 09:01:06.563332
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.remote_management.winrm import Connection
    assert True


# Generated at 2022-06-25 09:01:11.331252
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    command_1 = 'string_0'
    args_0 = (command_1,)
    var_0 = connection_0.exec_command(*args_0)


# Generated at 2022-06-25 09:01:20.282930
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    # test default value of cmd, if not specified
    cmd = "/bin/echo"
    var_1 = connection_0.exec_command(cmd=cmd)
    if ( not (var_1 == (0, b'/bin/echo', b'')) ):
        raise Exception('Failed test')
    # test value of cmd with single argument
    cmd = "/bin/echo foo"
    var_2 = connection_0.exec_command(cmd=cmd)
    if ( not (var_2 == (0, b'/bin/echo foo', b'')) ):
        raise Exception('Failed test')
    # test value of cmd with multiple arguments
    cmd = "/bin/echo foo bar"

# Generated at 2022-06-25 09:01:41.493944
# Unit test for method reset of class Connection
def test_Connection_reset():
    print("test_Connection_reset:")
    test_case_0()
    print("Done")


# Generated at 2022-06-25 09:01:53.211591
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    connection._exec_psrp_script = PSRP._exec_psrp_script
    connection._exec_psrp_script = PSRP._exec_psrp_script
    connection._exec_psrp_script = PSRP._exec_psrp_script
    connection._exec_psrp_script = PSRP._exec_psrp_script
    connection._exec_psrp_script = PSRP._exec_psrp_script
    connection._exec_psrp_script = PSRP._exec_psrp_script
    connection._parse_pipeline_result = PSRP._parse_pipeline_result
    connection._parse_pipeline_result = PSRP._parse_pipeline_result

# Generated at 2022-06-25 09:01:55.658599
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()


# Generated at 2022-06-25 09:02:04.104518
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    # From test/integration/targets/psrp/inventory
    host = '52.172.30.195'

    # From setup module
    source = '$env:temp\\test_connection.txt'

    # From file module
    dest = '~/test.txt'

    # Create a temporary file, otherwise the test will try to fetch a file that doesn't exist
    tmp_file_path = os.path.join(tempfile.gettempdir(), 'test_connection.txt')
    with open(tmp_file_path, 'w') as tmp_file:
        tmp_file.write('Test!')

    connection_0 = Connection()

    var_0 = connection_0.set_host_overrides(host)

    var_0 = connection_0.set_options(connection='psrp')

    var

# Generated at 2022-06-25 09:02:05.021319
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create the test instance
    connection_0 = Connection()
    var_0 = connection_0.reset()



# Generated at 2022-06-25 09:02:11.519514
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    path1 = u'test_value_3'
    path2 = u'test_value_4'
    tmpfile = None # TODO: implement the test for this value
    module_kwargs = None # TODO: implement the test for this value
    connection_0.fetch_file(path1, path2, tmpfile, module_kwargs)


# Generated at 2022-06-25 09:02:17.941827
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Run the test for each value in the list
    for arg_0 in [True, False]:
        for arg_1 in [True, False]:
            for arg_2 in [True, False]:
                test_case_0(arg_0, arg_1, arg_2)


# Generated at 2022-06-25 09:02:23.526731
# Unit test for method reset of class Connection
def test_Connection_reset():
    print("Test reset")

    if test_Connection_reset.passed == 0:
        test_case_0()

    test_Connection_reset.passed = 1


# Generated at 2022-06-25 09:02:26.969838
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path_0 = str()
    out_path_0 = str()
    connection_0.put_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:02:33.113720
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    in_path = "~/dir1/dir2/dir3/file.exe"
    out_path = "~/dir1/dir2/dir3/file.exe"
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()
    file_name = os.path.basename(tmp_file.name)
    file_path = tmp_file.name
    cmd = "Copy-Item '%s' -Destination '%s'" % (in_path, file_path)
    var_0 = Connection()
    var_0.reset()
    var_1 = var_0.fetch_file(in_path, out_path)
    assert os.path.exists(file_path) is True


# Generated at 2022-06-25 09:03:15.871039
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = str()
    out_path = str()
    var_0 = connection_0.reset()
    var_1 = connection_0.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:03:17.208593
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
      test_case_0()
      print("Test Case 0 Passed")
    except:
      print("Test Case 0 Failed")


# Generated at 2022-06-25 09:03:20.363192
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()



# Generated at 2022-06-25 09:03:29.414580
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = '.\\in_path'
    out_path_0 = '.\\out_path'
    file_size_0 = 0
    var_0 = connection_0.fetch_file(in_path_0, out_path_0, file_size_0)

    connection_1 = Connection()
    in_path_1 = '.\\in_path'
    out_path_1 = '.\\out_path'
    file_size_1 = 1
    var_1 = connection_1.fetch_file(in_path_1, out_path_1, file_size_1)

    connection_2 = Connection()
    in_path_2 = '.\\in_path'
    out_path_2 = '.\\out_path'

# Generated at 2022-06-25 09:03:32.592363
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = "0123456789"
    out_path_0 = "0123456789"
    use_sudo_0 = True
    use_cache_0 = True
    connection_0.fetch_file(in_path_0, out_path_0, use_sudo_0, use_cache_0)

# Generated at 2022-06-25 09:03:37.953966
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = "Z!#\u0015_\u0015\u0018\u000bX\u001f\u0018\u0019\u001d\u001c\u0017U\u0017\u001b\"\u0078\u000f\u000b\u0015\u001d\u0000\u001d"
    out_path_0 = "\u0005\u0005\u0019\u0014\u000f\u000e\u0015\u0019\u0005\u000f\"\u0078\u000f\u000b\u0015\u001d\u0000\u001d"

# Generated at 2022-06-25 09:03:40.850922
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # var init
    connection_0 = Connection()
    var_0 = b_('~/test.py')
    var_1 = b_('/tmp/test.py')
    # all arguments i.e. connection_0, var_0, var_1 are tested
    connection_0.fetch_file(in_path=var_0, out_path=var_1)



# Generated at 2022-06-25 09:03:42.783526
# Unit test for method put_file of class Connection
def test_Connection_put_file():

    connection_0 = Connection()
    in_path_0 = 'in/path'
    out_path_0 = 'out/path'
    var_0 = connection_0.put_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:03:44.382281
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()

# Generated at 2022-06-25 09:03:46.305372
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    assert var_0 == None, "%s" % var_0


# Generated at 2022-06-25 09:05:30.616808
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    var_1 = connection_0.exec_command('test')
    var_2 = connection_0.exec_command('test')
    var_3 = connection_0.exec_command('test')
    var_4 = connection_0.exec_command('test')
    var_5 = connection_0.exec_command('test')
    var_6 = connection_0.exec_command('test')
    var_7 = connection_0.exec_command('test')
    var_8 = connection_0.exec_command('test')
    var_9 = connection_0.exec_command('test')
    var_10 = connection_0.exec_command('test')
    var_11 = connection_0.exec_command('test')
    var_

# Generated at 2022-06-25 09:05:37.462252
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    connection_0.reset()
    in_path_0 = None
    out_path_0 = None
    use_sudo_0 = None
    use_su_0 = None
    mode_0 = None
    connection_0.put_file(in_path_0, out_path_0, use_sudo_0, use_su_0, mode_0)


# Generated at 2022-06-25 09:05:48.288780
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    var_0 = connection_0.exec_command(b'\t')
    assert var_0 == (1, b'', b'parameter "command" must be a string\r\n', b'')
    var_1 = connection_0.exec_command('\t')
    assert var_1 == (
    1, '', 'parameter "command" must be a binary string\r\n', '')
    var_2 = connection_0.exec_command(b'\x00')
    assert var_2 == (
    1, b'', b'parameter "command" must not contain null bytes\r\n', b'')
    var_3 = connection_0.exec_command('\x00')

# Generated at 2022-06-25 09:05:51.206997
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    var_0 = connection_0.exec_command('!#/bin/sh -c "uname -a"')



# Generated at 2022-06-25 09:06:00.272766
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_1 = Connection()
    in_file_name = 'IN_FILE_NAME'
    out_file_name = 'OUT_FILE_NAME'
    var_1 = connection_1.fetch_file(in_file_name, out_file_name)


# Generated at 2022-06-25 09:06:06.741228
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = 'C:\\Users\\C005560\\Documents\\ansible_test\\test'
    out_path_0 = 'C:\\Users\\C005560\\Documents\\ansible_test\\test\\test'
    var_0 = connection_0.fetch_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:06:08.773224
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()

if __name__ == '__main__':
    test_Connection_reset()

# Generated at 2022-06-25 09:06:13.265985
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()


# Generated at 2022-06-25 09:06:15.613756
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path_0 = None
    out_path_0 = None
    tmp_0 = None
    var_0 = connection_0.put_file(in_path_0, out_path_0, tmp_0)



# Generated at 2022-06-25 09:06:17.754526
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    var_1 = connection_0.fetch_file('ansible_psrp_test', '/tmp/ansible_psrp_test')
    assert var_1.rc == 0
