

# Generated at 2022-06-25 08:59:44.503236
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    print("Test the method fetch_file")
    connection_1 = Connection()
    var_1 = connection_1.reset()
    return


# Generated at 2022-06-25 08:59:47.690693
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    if not connection_0.connected:
        connection_0.connect()
    var_0 = connection_0.reset()
    connection_0.fetch_file(None, None)


# Generated at 2022-06-25 08:59:52.333274
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    connection_0.reset()
    var_0 = connection_0.exec_command('ls')
    assert var_0==0


# Generated at 2022-06-25 08:59:53.235567
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()

# Generated at 2022-06-25 09:00:04.707341
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    # Start
    import os
    import tempfile
    in_path = tempfile.mktemp()
    with open(in_path, 'wb') as f:
        f.write("hello world".encode("utf-16-le"))
    out_path = tempfile.mktemp()
    connection_0.fetch_file(in_path, out_path)
    assert(os.path.isfile(out_path))
    os.remove(in_path)
    os.remove(out_path)

    # End
    # Assertion error
    with pytest.raises(AssertionError):
        connection_0.fetch_file(in_path, out_path)
    # Assertion error

# Generated at 2022-06-25 09:00:11.427193
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    buf_0 = BytesIO()
    buf_1 = buf_0.read()
    connection_0 = Connection(buf_0)
    connection_1 = connection_0.reset()
    protocol_1 = connection_1.get_option('protocol')
    port_0 = connection_1.get_option('port')
    if protocol_1 is None and port_0 is None:
        var_0 = 'https'
        protocol_1 = var_0
  

# Generated at 2022-06-25 09:00:13.548109
# Unit test for method reset of class Connection

# Generated at 2022-06-25 09:00:22.943721
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Get connection object
    connection_0 = Connection()
    # Test exec_command() method
    var_0 = connection_0.exec_command('echo $env:computername')
    # Check type of var_0
    if (type(var_0[0]) == int):
        var_0 = True
        # Check if the test case was successful
        assert var_0, "connection.py - exec_command() method test has FAILED!"
    print("connection.py - exec_command() method test has PASSED!")


# Generated at 2022-06-25 09:00:25.252433
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    command = PSRPConnection()

    command.exec_command("print 'hello'")
    command.exec_command("echo 'hello'")


# Generated at 2022-06-25 09:00:28.120564
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path = 'in_path'
    out_path = 'out_path'
    var_0 = connection_0.put_file(in_path, out_path)


# Generated at 2022-06-25 09:00:51.077155
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection()
    var_1 = connection_1.exec_command("cmd.exe", "", "", "", "", "")


# Generated at 2022-06-25 09:00:54.255692
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    try:
        var_0 = connection_0.fetch_file(None, None)
    except Exception:
        import traceback
        exceptionType, exceptionValue, exceptionTraceback = sys.exc_info()
        traceback.print_exception(exceptionType, exceptionValue, exceptionTraceback, None, sys.stderr)
        del traceback



# Generated at 2022-06-25 09:01:00.797356
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    # Commands will be the same as that of the PSRP Test_Psrp_Execute.ps1 script
    var_0 = connection_0.exec_command('Write-Output "one"', sudoable=False)
    var_1 = connection_0.exec_command('Write-Output "two"; Write-Error "three"', sudoable=False)
    var_2 = connection_0.exec_command('$host.SetShouldExit(55)', sudoable=False)
    var_3 = connection_0.exec_command('$host.SetShouldExit(56); Write-Output "four"', sudoable=False)


# Generated at 2022-06-25 09:01:06.968656
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Testing the arguments of the inner function
    connection_0 = Connection()
    var_0 = connection_0.connect()
    # Testing the return value of the inner function
    var_1 = connection_0.put_file()


# Generated at 2022-06-25 09:01:11.374871
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Setup test case
    connection_0 = Connection()

    # Test fetch_file method
    var_0 = connection_0.fetch_file(arg_0, arg_1, arg_2)


# Generated at 2022-06-25 09:01:14.439488
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = str()
    out_path = str()
    var_0 = connection_0.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:01:18.623212
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    var_1 = connection_0.exec_command('ls')
    assert var_1 == 0


# Generated at 2022-06-25 09:01:23.459408
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()


# Generated at 2022-06-25 09:01:25.463523
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 09:01:28.815067
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 09:01:49.799493
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()


# Generated at 2022-06-25 09:01:51.365424
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:01:53.168108
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_3 = Connection()
    connection_3.exec_command('test')


# Generated at 2022-06-25 09:02:03.484287
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common._collections_compat import Mapping, MutableSequence

    with pytest.raises(AnsibleError) as excinfo:
        connection_0 = Connection()
        connection_0.exec_command(cmd=None)
    assert 'cmd is required' in to_native(excinfo.value)

    with pytest.raises(AnsibleError) in excinfo:
        connection_0 = Connection()
        connection_0.exec_command(cmd='')
    assert 'cmd is required' in to_native(excinfo.value)

    with pytest.raises(AnsibleError) as excinfo:
        connection_0 = Connection()
        connection_0.exec_command(cmd=False)
    assert 'cmd is required'

# Generated at 2022-06-25 09:02:04.395180
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    assert callable(getattr(Connection, 'exec_command', None))


# Generated at 2022-06-25 09:02:05.882381
# Unit test for method close of class Connection

# Generated at 2022-06-25 09:02:09.581584
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    global connection_0
    global temp_dir_0
    global temp_file_0
    with tempfile.NamedTemporaryFile('w+b', delete=False, prefix='test_Connection_put_file_') as temp_file_0:
        temp_file_0.write(b'testing put_file')
        temp_file_0.close()
        connection_0.put_file(temp_file_0.name, 'test_dir/test_put_file')
        os.remove(temp_file_0.name)


# Generated at 2022-06-25 09:02:17.005222
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cmd = 'echo "test"'
    # Execute command and return psrp object (with rc, stdout, stderr)
    result = connection_0.exec_command(cmd)
    print (result)

if __name__ == '__main__':
    test_Connection_exec_command()

#pylint: enable=C0103
#pylint: enable=consider-using-with

# Generated at 2022-06-25 09:02:23.317750
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    file_in = "/in.txt"
    file_out = "out.txt"
    connection.fetch_file(file_in, file_out)


# Generated at 2022-06-25 09:02:26.435630
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cmd_0 = "dir \\temp"
    (rc_exec_command, out_exec_command, err_exec_command) = connection_0.exec_command(cmd_0)
    print ("rc_exec_command=", rc_exec_command, "out_exec_command=", out_exec_command, "err_exec_command=", err_exec_command)


# Generated at 2022-06-25 09:03:15.741305
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cmd_0 = "dir"
    stdin_0 = None
    in_data_0 = None
    sudo_0 = False
    sudo_user_0 = None
    check_rc_0 = True
    executable_0 = None
    encoding_0 = "utf-8"
    errors_0 = "surrogate_then_replace"
    no_log_0 = False
    input_data_0 = None

# Generated at 2022-06-25 09:03:18.526829
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    print("test_Connection_fetch_file")
    connection_0 = Connection()
    in_path = 'test_file'
    out_path = 'test_file'
    file_size = 0
    connection_0.fetch_file(in_path, out_path, file_size)


# Generated at 2022-06-25 09:03:24.271140
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = None
    out_path = None
    file_args = None
    use_powershell = None
    connection_0.fetch_file(in_path, out_path, file_args, use_powershell)


# Generated at 2022-06-25 09:03:25.451310
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()


# Generated at 2022-06-25 09:03:26.521915
# Unit test for method reset of class Connection
def test_Connection_reset():
    pass


# Generated at 2022-06-25 09:03:27.659332
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:03:30.977361
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    local_path_0 = "C:\\Git\\AzureStack-Tools\\Test\\ConnectionTest.py"
    remote_path_0 = "c:\\test.txt"
    result_0 = connection_0.put_file(local_path_0, remote_path_0)
    assert result_0 is None


# Generated at 2022-06-25 09:03:34.380000
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    assert callable(getattr(connection_0, "close", None))
    # No exception if run without arguments
    connection_0.close()

# Generated at 2022-06-25 09:03:39.617637
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    ret = connection_0.put_file(local_path="test_value_3", remote_path="test_value_4", module_args="test_value_5", use_priviledged_mode=False)
    assert ret is None, "Return value should be None"


# Generated at 2022-06-25 09:03:40.498677
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:04:29.364028
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:04:30.197748
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:04:36.281139
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    src = u'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    dest = u'A'
    param = 0

# Generated at 2022-06-25 09:04:41.367991
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    connection_0._exec_psrp_script(script=None, input_data=None, use_local_scope=True, arguments=None)


# Generated at 2022-06-25 09:04:45.697655
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection() 
    result_0 = connection_1.exec_command("dir \"C:\Program Files\"")
    print('\n'.join(result_0[1].splitlines()[:10]))

    result_1 = connection_1.exec_command("dir \"C:\\Program Files\"")
    print('\n'.join(result_1[1].splitlines()[:10]))



# Generated at 2022-06-25 09:04:49.766748
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    host = 'localhost'
    path = '"' + os.path.join(getcwd(),"test_fetch") + '"'

    # Call the fetch_file method of class Connection

    # Unit test for fetch_file method - case where the return value is None
    connection_1 = Connection()

    # Unit test for fetch_file method - case where the return value is not None
    connection_2 = Connection()


if __name__ == '__main__':
    test_case_0()
    test_Connection_fetch_file()

# Generated at 2022-06-25 09:04:53.552872
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    filename_0 = "./test_data/test_file.txt"
    filename_1 = "./test_data/test_file.txt"
    connection_0 = Connection()
    connection_0.connected = Mock(return_value=True)
    connection_0._build_kwargs = Mock(return_value=None)
    connection_0._exec_psrp_script = Mock(return_value=(0, "", ""))
    connection_0.put_file(filename_0, filename_1)


# Generated at 2022-06-25 09:04:54.566609
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    try:
        connection_0 = Connection()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 09:04:56.721978
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    result = connection.put_file(
        content = b'"A"',
        dest = '/Users/leidong/Documents/repos/ansible_source_code/ansible-test/test_test_module.py'
    )
    print(result)


# Generated at 2022-06-25 09:04:59.952940
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:06:36.861135
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_1 = Connection()
    in_path_1 = None
    out_path_1 = None
    parameters_1 = dict()

# Generated at 2022-06-25 09:06:38.363586
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cmd = 'echo 1'
    connection_0.exec_command(cmd)


# Generated at 2022-06-25 09:06:41.086068
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:06:46.277830
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    # TODO: implement test for Connection.fetch_file
    assert False


# Generated at 2022-06-25 09:06:48.297797
# Unit test for method reset of class Connection
def test_Connection_reset():
    print("Testing reset")

    # Define object connection_0 of class Connection
    connection_0 = Connection()

    # Call method reset of connection_0
    connection_0.reset()


# Generated at 2022-06-25 09:06:52.684806
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection()
    connection_1.exec_command("$var = $null; $var")
    connection_1.exec_command("(Get-ChildItem $env:Temp -Path:$false).Name")
    connection_1.exec_command("''")


# Generated at 2022-06-25 09:06:58.068722
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    try:
        connection_0.reset()
    except Exception as e:
        print("Failed to call reset")


# Generated at 2022-06-25 09:07:05.683802
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    script_0 = 'Write-Host "Hello World!"'
    arguments_0 = None
    result_0 = connection_0.exec_command(script_0, arguments_0)
    print('result_0:')
    for key in result_0:
        print(f'{key}: {result_0[key]}')



# Generated at 2022-06-25 09:07:09.068134
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()
    print('Test passed')


# Generated at 2022-06-25 09:07:13.521764
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()
