

# Generated at 2022-06-25 08:59:41.422912
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 08:59:48.980471
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    test_kwargs = {'host': '192.168.56.104', 'port': 5985, 'username': 'Administrator', 'password': 'Password123!'}
    connection_0 = Connection(**test_kwargs)
    test_args = ('lambda',)
    test_xxkwargs = {}
    test_rc = 0
    test_stdout = 'c:\\'
    test_stderr = ''
    rc, stdout, stderr = connection_0.exec_command(*test_args, **test_xxkwargs)

    assert rc == test_rc
    assert stdout == test_stdout
    assert stderr == test_stderr


# Generated at 2022-06-25 08:59:50.358614
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    test_case_0()

if __name__ == '__main__':
    test_Connection_exec_command()

# Generated at 2022-06-25 08:59:53.284873
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = '' 
    out_path = ''
    file_system = ''
    local_follow = connection_0.get_option('ansible_winrm_follow_symlinks')
    # Call method Connection.fetch_file on connection_0
    connection_0.fetch_file(in_path, out_path, file_system, local_follow)


# Generated at 2022-06-25 08:59:54.636001
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.fetch_file('in_path', 'out_path', 'buffer_size')


# Generated at 2022-06-25 08:59:58.928421
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    remote_path_0 = 'test'
    file_path_0 = 'test'
    connection_0.fetch_file(remote_path_0, file_path_0)


# Generated at 2022-06-25 09:00:05.056170
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print("[+] Testing Connection.put_file")
    connection_0 = Connection()
    in_path_0 = "./test/ansible_connection.py"
    out_path_0 = "C:/Users/Sudhakar/Desktop/new_folder/ansible_connection.py"
    try:
        connection_0.put_file(in_path_0,out_path_0)
    except AnsibleError as err:
        print("[-] AnsibleError exception : " + err.message)


# Generated at 2022-06-25 09:00:16.193998
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Test of the function fails if remote_addr is not set
    connection_0 = Connection()
    connection_0._psrp_host = None
    in_path = "/windows/system32/WindowsPowerShell/v1.0/Modules/PSReadline/1.1"
    out_path = "test"
    try:
        connection_0.fetch_file(in_path, out_path)
    except AnsibleError as e:
        assert "Invalid/missing remote_addr" in e.message
    connection_0._psrp_host = "test_host_0"
    in_path = "/windows/system32/WindowsPowerShell/v1.0/Modules/PSReadline/1.1"
    out_path = "test"
    # Test of the function fails if runspace was not created
   

# Generated at 2022-06-25 09:00:28.153163
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print("\n*** test_Connection_put_file ***")

    # Test case setup
    config.CONNECTION_TIMEOUT = 30
    config.CLI_MESSAGE_FORMAT = 'json'
    config.GATHERING = 'explicit'
    config.HOST_KEY_CHECKING = False
    config.LOG_PATH = './ansible.log'
    config.LOG_CURSOR = True
    config.LOG_AGENT = True
    test_case_0()
    test_connection_0 = connection_0
    inventory_0 = InventoryManager(loader=None, sources=None)
    variable_manager_0 = VariableManager(loader=None, inventory=None)
    test_playbook_path_0 = 'test/put_file.yml'

# Generated at 2022-06-25 09:00:33.417267
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    src_0 = 'data/test_put_file'
    dst_0 = 'test_put_file'
    connection_0.put_file(src_0, dst_0)
    return


# Generated at 2022-06-25 09:01:20.544968
# Unit test for method put_file of class Connection
def test_Connection_put_file():
	connection_0 = Connection()
	file_name = ''
	dest_file_path = ''
	flatten = None
	try:
		connection_0.put_file(file_name, dest_file_path, flatten)
		# Unit test passed
	except Exception as e:
		# Unit test failed
		print('put_file: unit test failed.')


# Generated at 2022-06-25 09:01:22.777402
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
  connection_ = Connection()
  in_path = 'in_path_value'
  out_path = 'out_path_value'
  connection_.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:01:27.698717
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    command_0 = ''
    stdin_0 = None
    stdout_0 = None
    stderr_0 = None
    checkrc_0 = False
    close_fds_0 = False
    executable_0 = None
    cwd_0 = None
    env_0 = None
    data_0 = None
    binary_data_0 = True
    path_0 = None
    prompt_0 = None
    newline_0 = True
    unexpected_0 = None
    allow_prompt_0 = False
    answer_0 = None
    sendonly_0 = False
    input_data_0 = None
    args_0 = None
    return_connection_0 = False
    return_stdout_0 = False
    return_stderr_0 = False
    expand_

# Generated at 2022-06-25 09:01:33.153048
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    test_var_0 = 'foo'
    test_cmd = '$var0:::'.format(test_var_0)

    test_case_0()
    Connection.exec_command(test_cmd)


# Generated at 2022-06-25 09:01:34.525447
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:01:36.141115
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    assert connection_0.protocol == 'psrp'


# Generated at 2022-06-25 09:01:40.288788
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    psrp_path_0 = '/tmp/test'
    ansible_path_0 = '/tmp/test'
    connection_0.fetch_file(psrp_path_0, ansible_path_0)


# Generated at 2022-06-25 09:01:52.011380
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create an instance of class Connection
    connection_0 = Connection()
    # Retrieve the parameters
    b_in_path = "test_data/test_put.txt"
    b_out_path = "test_data/test_put.txt"
    input_data = "PSRP test_Connection_put_file\n"
    # Call the method under test
    connection_0.put_file(b_in_path, b_out_path, input_data)
    in_path = "test_data/test_put.txt"
    with open(in_path, 'rb') as in_file:
        data = in_file.read()
    # Check the results
    assert(data == input_data)




# Generated at 2022-06-25 09:01:53.123743
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()



# Generated at 2022-06-25 09:01:58.474099
# Unit test for method close of class Connection
def test_Connection_close():
    with pytest.raises(NotImplementedError) as excinfo:
        connection_1 = Connection()
        connection_1.close()


# Generated at 2022-06-25 09:03:22.851759
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    put_file_0 = 'b'
    put_file_1 = 'b'
    connection_0.put_file(put_file_0, put_file_1)


# Generated at 2022-06-25 09:03:27.480176
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    # Test arguments
    module_0=module

    # Invoke method
    rc_0, stdout_0, stderr_0 =Connection.exec_command(module_0,  )

    # Test for correct result
    assert rc_0 == 0
    assert stdout_0 == "\r\n\r\nHello World\r\n"
    assert stderr_0 == ""


# Generated at 2022-06-25 09:03:31.444970
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = 'test'
    out_path = 'test'
    result = connection_0.fetch_file(in_path, out_path)
    assert result == None


# Generated at 2022-06-25 09:03:36.698982
# Unit test for method reset of class Connection
def test_Connection_reset():
    display.vvv(HostVars.items())

HostVars = {'ansible_psrp_auth': 'basic',
            'ansible_psrp_cert_validation': 'ignore',
            'ansible_psrp_connection_timeout': 30,
            'ansible_psrp_encryption': 'auto',
            'ansible_psrp_host': '192.168.0.0',
            'ansible_psrp_port': 5986,
            'ansible_psrp_username': 'Administrator',
            'ansible_psrp_password': '12345678'
            }

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 09:03:40.329385
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = None
    out_path = None
    flat = None
    connection_0.fetch_file(in_path, out_path, flat)


# Generated at 2022-06-25 09:03:49.118546
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0._psrp_host = "hostname"
    connection_0._psrp_user = "username"
    connection_0._psrp_pass = "password"
    connection_0._psrp_protocol = "https"
    connection_0._psrp_port = 5986
    connection_0._psrp_path = ""
    connection_0._psrp_auth = "CredSSP"
    connection_0._psrp_cert_validation = True
    connection_0._psrp_connection_timeout = 10
    connection_0._psrp_read_timeout = 3600
    connection_0._psrp_message_encryption = "Always"
    connection_0._psrp_proxy = "PROXY"
    connection_

# Generated at 2022-06-25 09:04:00.184056
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = 'test_value'
    out_path_0 = 'test_value'
    file_args_0 = dict(
        remote=False,
        fail_on_missing=True,
        other=None,
    )
    display_0 = 'test_value'
    src_0 = 'test_value'
    key_0 = 'test_value'
    mode_0 = 'test_value'
    params_0 = dict(
        become_user=None,
        become_method=None,
        become_info=None,
        verbosity=None,
        check=False,
        diff=False,
    )

# Generated at 2022-06-25 09:04:02.057374
# Unit test for method close of class Connection
def test_Connection_close():
    new_connection = Connection
    new_connection.close()


# Generated at 2022-06-25 09:04:08.736225
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = None
    out_path = None
    connection_0.fetch_file(in_path, out_path)
    in_path = b'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\Modules\\PSReadLine\\en-US\\Microsoft.PowerShell.ConsoleHost.psd1'
    out_path = 'c:\\Users\\Administrator\\.ansible\\tmp\\ansible-tmp-1561256334.91-86925202242760\\tmpdIH0OA'
    connection_0.fetch_file(in_path, out_path)
    connection_0.connected = True
    connection_0.runspace = RunspacePool()
    connection_0.runspace.state = RunspacePoolState.OPENED
    connection

# Generated at 2022-06-25 09:04:18.102026
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.module_utils.psrp.common import PSRPException
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.psrp.connection_loader import connection_loaders

    construct_loader_mock = Mock()
    connection_loaders['psrp'] = construct_loader_mock

    try:
        connection_0 = Connection()
        connection_0.connected = True
        connection_0.put_file()
    except PSRPException as e:
        if str(e) == 'A destination path must be specified on the destination host.':
            pass
        else:
            raise Exception('Unexpected exception raised: %s' % e)
    else:
        raise Exception('ExpectedException not raised')


# Generated at 2022-06-25 09:08:13.567623
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()

    arguments = []
    if len(arguments) == 1 and isinstance(arguments[0], Connection):
        # State 0
        return

    # State 1
    # Function return value test
    assert True == connection_0.fetch_file('', '')

# Generated at 2022-06-25 09:08:15.077208
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset(
        connection='connection_0'
    )
    return connection_0


# Generated at 2022-06-25 09:08:22.903080
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    connection_0.put_file("connection_0.py", "C:/Users/Admin/Desktop/Ansible/Library/psrp_connection/connection_0.py")


# Generated at 2022-06-25 09:08:25.150791
# Unit test for method reset of class Connection
def test_Connection_reset():
    with patch.object(Connection, 'connect') as mock_connect:
        with patch.object(Connection, 'close') as mock_close:
            connection_1 = Connection()
            connection_1.reset()
            mock_close.assert_called_once()
            mock_connect.assert_called_once()


# Generated at 2022-06-25 09:08:36.189456
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    import inspect
    import types

    # We need to mock the real exec_command
    original_exec_command = connection_plugin_class.exec_command

    # Let's grab the real signature so we can call the original method
    # properly inside our mock
    original_exec_command_argspec = inspect.getargspec(original_exec_command)

    # Execute our mocked exec_command method
    def mocked_exec_command(self, cmd, in_data, sudoable=True):
        # Call our original exec_command method with the right
        # arguments given
        original_exec_command_argspec.args.append(cmd)
        original_exec_command_argspec.args.append(in_data)
        original_exec_command_argspec.args.append(sudoable)


# Generated at 2022-06-25 09:08:41.068713
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    connection_0.connect()
    
    # Open file to copy
    f = open(r'C:\\Users\\jzeisler\\Desktop\\PSRP_TEST.txt', 'r')
    file_contents = f.read()
    
    # Copy file
    assert connection_0.put_file(remote=r'C:\\PSRP_TEST.txt', local=r'C:\\Users\\jzeisler\\Desktop\\PSRP_TEST.txt') != 100

    # Verify
    f = open(r'C:\\Users\\jzeisler\\Desktop\\PSRP_TEST.txt', 'r')
    assert f.read() == file_contents
    
    # Clean up

# Generated at 2022-06-25 09:08:45.049072
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_2 = Connection()
    in_path = 'test_val_7'
    out_path = 'test_val_8'
    connection_2.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:08:46.338881
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_case_0()


# Generated at 2022-06-25 09:08:57.227604
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    path_0 = 'C:\\Users\\Alex\\Ansible\\psrp\\tests\\put_file_test\\test_put_file_1.txt'
    out_path_0 = 'C:\\Users\\Alex\\Ansible\\psrp\\tests\\put_file_test\\test_put_file_2.txt'