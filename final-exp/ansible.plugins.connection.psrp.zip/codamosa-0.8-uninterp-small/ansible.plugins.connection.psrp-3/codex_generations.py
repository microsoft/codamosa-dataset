

# Generated at 2022-06-25 08:59:34.105766
# Unit test for method close of class Connection
def test_Connection_close():
    global connection_0
    connection_0.close()


# Generated at 2022-06-25 08:59:35.814939
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    str_0 = ''
    str_1 = ''
    connection_0.fetch_file(str_0, str_1)


# Generated at 2022-06-25 08:59:38.759921
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    connection_0.exec_command('touch /home/ching/Desktop/test.txt')


# Generated at 2022-06-25 08:59:49.194006
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    file_0 = 'a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/t/u/v/w/x/y/z/A/B/C/D/E/F/G/H/I/J/K/L/M/N/O/P/Q/R/S/T/U/V/W/X/Y/Z/0/1/2/3/4/5/6/7/8/9'

# Generated at 2022-06-25 08:59:51.087793
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection(**{})
    current_user_0 = connection_0.get_user()
    print(current_user_0)


# Generated at 2022-06-25 08:59:52.599068
# Unit test for method close of class Connection
def test_Connection_close():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    connection_0.close()
    print("------------------Test Connection.close-------------------")


# Generated at 2022-06-25 09:00:04.687785
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    result_0 = connection_0.put_file(src_0, dst_0)
    # AssertionError: expected {'_ansible_no_log': True, '_ansible_verbose_always': True, '_ansible_verbosity': 3, '_ansible_debug': False, '_ansible_listtags': False, '_ansible_listtasks': False, '_ansible_syntax': False, '_ansible_diff': False, '_ansible_module_name': 'copy', '_ansible_module_name': 'copy', '_ansible_module_name': 'copy', '_ansible_module_name': 'copy', '_ansible_module_name': 'copy', '_ansible_module

# Generated at 2022-06-25 09:00:15.597473
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # test case 1:
    cmd = 'dir'
    connection_1 = Connection()
    rc, stdout, stderr = Connection.exec_command(connection_1, cmd, environ_update=None, check_rc=True, close_fds=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, combine_stderr=True, encoding=None, errors=None)
    assert rc == 0
    assert stderr == ''
    assert stdout != ''

    # test case 2:
    cmd = 'dir'
    connection_2 = Connection()

# Generated at 2022-06-25 09:00:19.314091
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    command_0 = 'echo "Hello world!"'
    returned_value_0 = connection_0.exec_command(command_0)
    assert returned_value_0 is None


# Generated at 2022-06-25 09:00:23.858358
# Unit test for method close of class Connection
def test_Connection_close():
    kwargs_0 = {}
    connection_0 = Connection(**kwargs_0)
    connection_0.close()


# Generated at 2022-06-25 09:00:52.792040
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    cmd = 'echo "Hello"'

    print(cmd)
    display_width = 80

    display.display(cmd, color=C.COLOR_VERBOSE, stderr=True)
    cli = PSRPConnection()
    rc, out, err = cli.exec_command(cmd, in_data=None, sudoable=False)
    print(out)
    print(err)
    print(rc)
    if out:
        display.display(out, color=C.COLOR_VERBOSE, screen_only=True,
                        log_only=True)
    if err:
        display.display(err, color=C.COLOR_ERROR, screen_only=True,
                        log_only=True)

# Generated at 2022-06-25 09:00:54.680469
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection()
    expected = (0, b'', b'')
    returned = conn.exec_command('command')
    assert returned == expected


# Generated at 2022-06-25 09:01:02.322193
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    in_path = '/tmp/testfile'
    out_path = '/tmp/testfile'
    buf_size = 65535
    conn = Connection()
    # First try when the parameter in_path is neither a file nor a directory

# Generated at 2022-06-25 09:01:12.129175
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    path = 'a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/t/u/v/w/x/y/z/A/B/C/D/E/F/G/H/I/J/K/L/M/N/O/P/Q/R/S/T/U/V/W/X/Y/Z/0/1/2/3/4/5/6/7/8/9'

# Generated at 2022-06-25 09:01:20.603039
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    obj = Connection(module_name=module_name, connection=connection)
    obj.fetch_file(in_path=in_path, out_path=out_path, file_size=file_size)
    assert obj._connected == True
    assert obj._psrp_host == 'myhost'
    assert obj._psrp_user == 'myuser'
    assert obj._psrp_pass == 'mypass'
    assert obj._psrp_protocol == 'https'
    assert obj._psrp_port == 5986
    assert obj._psrp_path == '/wsman'
    assert obj._psrp_auth == None
    assert obj._psrp_cert_validation == True
    assert obj._psrp_connection_timeout == None
    assert obj._psrp_read_timeout

# Generated at 2022-06-25 09:01:30.117022
# Unit test for method close of class Connection

# Generated at 2022-06-25 09:01:42.159109
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    obj_Connection = Connection()
    # input params
    pb_sudo = False
    pb_sudo_user = None
    pb_module_name = None
    pb_module_args = None
    pb_in_data = None
    pb_executable = None
    pb_in_priority = None
    pb_in_path = None
    # exec_command()
    func_return = obj_Connection.exec_command(pb_sudo, pb_sudo_user, pb_module_name, pb_module_args, pb_in_data, pb_executable, pb_in_priority, pb_in_path)
    print("[{}] Execute func_return: ".format(str(os.getpid())) + str(func_return))
    # check results

# Generated at 2022-06-25 09:01:54.801609
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Test of correct implementation of return value data type
    print("\n---test_Connection_fetch_file")
    print("\n---test_Connection_fetch_file")
    print("\nTest of correct implementation of return value data type")

    conn = Connection()
    buffer_size = 1024
    in_path = 'in_path'
    out_path = 'out_path'
    tmp_path = 'tmp_path'

    global fetch_file_bytes
    fetch_file_bytes = 0

    out_file = open(out_path, 'wb')
    conn.fetch_file(in_path=in_path, out_path=out_file, buffer_size=buffer_size)
    out_file.close()
    assert os.path.exists(out_path)

    out_file = open

# Generated at 2022-06-25 09:02:03.392940
# Unit test for method reset of class Connection
def test_Connection_reset():
    def num_of_records_in_dict_7(d):
        num = 0
        for val in d.values():
            num += len(val)
        return num

    ansible_conn = Connection(play_context=None, new_stdin=None)
    assert Connection.__doc__ is not None

    assert ansible_conn.close() is None


# Generated at 2022-06-25 09:02:04.470855
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection(None, None)
    connection_0.reset()


# Generated at 2022-06-25 09:02:27.739752
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    password = 'Ansible'
    host = '192.168.56.101'
    psrp_port = 5986
    psrp_pass = password
    psrp_user = 'Administrator'
    psrp_protocol = 'https'
    psrp_path = '/wsman'
    psrp_auth = 'plaintext'

    psrp_conn_kwargs = dict(
        server=host, port=psrp_port, username=psrp_user, password=psrp_pass, ssl=psrp_protocol == 'https',
        path=psrp_path, auth=psrp_auth, cert_validation=True, connection_timeout=60)


# Generated at 2022-06-25 09:02:32.937622
# Unit test for method reset of class Connection
def test_Connection_reset():
    a = Connection("psrp")
    str_0 = 'a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/t/u/v/w/x/y/z/A/B/C/D/E/F/G/H/I/J/K/L/M/N/O/P/Q/R/S/T/U/V/W/X/Y/Z/0/1/2/3/4/5/6/7/8/9'
    a.reset(host=str_0)



# Generated at 2022-06-25 09:02:34.531270
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection()
    conn.reset()


# Generated at 2022-06-25 09:02:38.358213
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Run command reset on a Connection.
    #
    # This method executes on the ansible controller and is used to reset a
    # transport connection if the connection becomes unusable.  The default
    # implementation does nothing.
    #
    # By default, this method does nothing
    pass


# Generated at 2022-06-25 09:02:45.798526
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conn_psrp = Connection(None)
    data_0 = 'a/b/c/d/e/f/g/h/i/j/k/l/m/n/o/p/q/r/s/t/u/v/w/x/y/z/A/B/C/D/E/F/G/H/I/J/K/L/M/N/O/P/Q/R/S/T/U/V/W/X/Y/Z/0/1/2/3/4/5/6/7/8/9'
    put_0 = 'abc'
    out_0 = 'abc'
    conn_psrp.put_file(put_0, out_0)


# Generated at 2022-06-25 09:02:49.094724
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    """
    fetch_file
    """
    # Invalid number of arguments
    with pytest.raises(TypeError):
        Connection.fetch_file()




# Generated at 2022-06-25 09:02:53.106500
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Create a mock object - we don't care about it's contents
    mock_Connection_object = Connection()
    # Run the method under test
    result = mock_Connection_object.reset()
    # Check the results
    # Make sure the reset method doesn't return anything
    assert result is None


# Generated at 2022-06-25 09:03:01.368612
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.plugins.connection.psrp import Connection
    from ansible.parsing.utils.addresses import parse_address
    from ansible.errors import AnsibleError
    from ansible.release import __version__

    connection = Connection(None, parse_address('127.0.0.1', restrict_to_hosts=False, allow_ranges=False, allow_bare=False), False, False)
    connection.host = '127.0.0.1'
    connection.psrp_user = 'remote_user'
    connection.psrp_password = 'remote_password'
    connection.psrp_port = 8080
    connection.psrp_protocol = 'test_value'
    connection.psrp_auth = 'test_value'
    connection.psrp_cert_valid

# Generated at 2022-06-25 09:03:03.089655
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Test with connections resetting
    mc = MockConnection()
    mc.reset()


# Generated at 2022-06-25 09:03:14.214750
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    with mock.patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.powershell._winrm_exec', mock.Mock(return_value=('test', None, None))):
        with pytest.raises(AnsibleError) as excinfo:
            test_case_0()
        assert excinfo.value.args[0] == "unable to open shell. Please see: https://docs.ansible.com/ansible/network_debug_troubleshooting.html#unable-to-open-shell"
        assert excinfo.value.args[1] == '/home/project/ansible/500.txt'
        assert excinfo.value.args[2] == '1'
        assert excinfo.value.args[3] == 'path does not exist'


# Generated at 2022-06-25 09:03:37.870568
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    in_path_0 = 'd:\\dev\\ansible'
    out_path_0 = 'd:\\dev\\ansible\\credentials.yml'
    connection_0.fetch_file(in_path_0, out_path_0)
    in_path_0 = 'd:\\dev\\ansible'
    out_path_0 = 'd:\\dev\\ansible\\credentials.yml'
    connection_0.fetch_file(in_path_0, out_path_0)
    in_path_0 = 'd:\\dev\\ansible'
    out_path_0 = 'd:\\dev\\ansible\\credentials.yml'

# Generated at 2022-06-25 09:03:40.499660
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    command_0 = "uname"
    res = connection_0.exec_command(command_0)
    res = connection_0.exec_command(command_0, use_persistent_connection=False)
    res = connection_0.exec_command(command_0, use_persistent_connection=True)


# Generated at 2022-06-25 09:03:42.639488
# Unit test for method close of class Connection
def test_Connection_close():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    connection_0.close()


# Generated at 2022-06-25 09:03:46.346121
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    args_0 = ['echo', 'foo']
    args_1 = ['echo', 'bar']
    args_2 = ['echo', 'foobar']
    args_3 = []
    _validate_case((), {'args': args_0}, (0, b'foo', b''))
    _validate_case((), {'args': args_1}, (0, b'bar', b''))
    _validate_case((), {'args': args_2}, (0, b'foobar', b''))


# Generated at 2022-06-25 09:03:49.404806
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()

    # test for valid parameters
    rc, output, err = connection_0.put_file('testfile.txt', 'testfile.txt')

    assert rc == 0, 'Valid parameters must return 0'
    assert len(err) == 0, 'There should be no errors'


# Generated at 2022-06-25 09:03:50.279491
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_case_0()


# Generated at 2022-06-25 09:03:52.897660
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_case_0()

if __name__ == '__main__':
    test_Connection_put_file()

# Generated at 2022-06-25 09:03:55.717016
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Parameters and expected results.
    test_case_0()

    # Parsing output, checking results.
    pass

if __name__ == "__main__":
    test_Connection_exec_command()

# Generated at 2022-06-25 09:04:05.548305
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection()
    assert connection_1.exec_command('powershell') == 0
    assert connection_1.exec_command('powershell -command') == 0
    # assert connection_1.exec_command('powershell -command', input='123') == 0
    # (psrp_host, psrp_port, psrp_user, psrp_pass, psrp_protocol, psrp_path, psrp_auth, psrp_cert_validation, psrp_connection_timeout, psrp_read_timeout, psrp_message_encryption, psrp_proxy, psrp_operation_timeout, psrp_max_envelope_size, psrp_configuration_name) = (u'10.0.0.67', 5985, 'NetworkAutomation

# Generated at 2022-06-25 09:04:09.748920
# Unit test for method reset of class Connection
def test_Connection_reset():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    connection_0.reset()


# Generated at 2022-06-25 09:05:01.018948
# Unit test for method reset of class Connection
def test_Connection_reset():
    dict_0 = {}
    connection_0 = Connection(**dict_0)

    connection_0.reset()


# Generated at 2022-06-25 09:05:05.293909
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    in_path_0 = "0"
    out_path_0 = "1"
    connection_0.fetch_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:05:12.799991
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    in_path = 'abc.txt'
    out_path = 'xyz.txt'
    makedirs_1 = makedirs
    def makedirs_0(name, mode=511):
        return 1
    makedirs_1 = makedirs_0
    with open(u'abc.txt', 'w') as out_file:
        out_file.write(u'a\n')
    connection_0.put_file(in_path, out_path)
    with open(u'xyz.txt', 'r') as in_file:
        lines = in_file.readlines()
        assert(len(lines) == 1)
        assert(lines[0] == u'a\n')


# Generated at 2022-06-25 09:05:16.778939
# Unit test for method reset of class Connection
def test_Connection_reset():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    connection_0.reset()


# Generated at 2022-06-25 09:05:22.432807
# Unit test for method reset of class Connection
def test_Connection_reset():
    ARGUMENTS = {}
    # initialize the object
    connection_0 = Connection(**ARGUMENTS)

    # apply the method to the object
    connection_0.reset()


# Generated at 2022-06-25 09:05:29.284646
# Unit test for method close of class Connection
def test_Connection_close():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    class_attr_0 = connection_0.__class__
    attr_1 = class_attr_0.runspace
    value_0 = None
    assert_not_equals(attr_1, value_0)
    connection_0.close()
    attr_2 = class_attr_0.runspace
    value_1 = connection_0._connected
    assert_equals(attr_2, value_1)


if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-25 09:05:34.824004
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    dict_0 = {}
    connection_0 = Connection(**dict_0)

    # Test with literal args
    command = ['/bin/true']
    rc, stdout, stderr = connection_0.exec_command(command)
    assert rc == 0


# Generated at 2022-06-25 09:05:41.527950
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    command_0 = "Command1"
    # Execute method with argument command_0 and store the result in a local variable.
    result_0 = connection_0.exec_command(command_0)
    # Check the value of result_0 with an expected value.
    assert result_0 == None


# Generated at 2022-06-25 09:05:45.620003
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_handle = Connection()
    in_path = 'abc'
    out_path = 'abc'
    print(connection_handle.put_file(in_path, out_path))


# Generated at 2022-06-25 09:05:48.396206
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    dict_0 = {}
    connection_0 = Connection(**dict_0)

    # dict_1 = dict(src=str, dest=str)
    # connection_0.fetch_file(**dict_1)



# Generated at 2022-06-25 09:07:29.274937
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    in_path_0 = 'test_in_path_0'
    out_path_0 = 'test_out_path_0'
    follow_0 = True
    try:
        connection_0.put_file(in_path_0, out_path_0, follow_0)
    except AnsibleError as e:
        print("failed to put file %s" % (e))
    else:
        print("successfully put file to %s" % (out_path_0))


# Generated at 2022-06-25 09:07:33.211375
# Unit test for method reset of class Connection
def test_Connection_reset():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    # SOURCE LINE 5

    if TESTING_PSRP:
        from psrptools.testing import mocked_session_factory
        mocked_session_factory(connection_0)

    # SOURCE LINE 8
    connection_0._reset()


# Generated at 2022-06-25 09:07:38.685510
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        f.write("Hello, World!")
    connection_0 = Connection(**{})
    filepath_0 = f.name
    dest_0 = "/tmp/dest"
    connection_0.fetch_file(filepath_0, dest_0)


# Generated at 2022-06-25 09:07:45.980059
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    in_path_0 = 'in_file_0'
    out_path_0 = 'out_file_0'
    force_0 = True
    
    # Test with a non-existing out file
    try:
        os.remove(out_path_0)
    except OSError:
        pass
    connection_0.fetch_file(in_path_0, out_path_0)
    with open(out_path_0, 'r') as f:
        assert f.read() == 'Hello World'
    
    # Test with an existing out file
    with open(out_path_0, 'w') as f:
        f.write('Bye')

# Generated at 2022-06-25 09:07:47.666863
# Unit test for constructor of class Connection
def test_Connection():
    test_case_0()



# Generated at 2022-06-25 09:07:49.161876
# Unit test for method close of class Connection
def test_Connection_close():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    connection_0.close()


# Generated at 2022-06-25 09:07:59.135815
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-25 09:08:03.941884
# Unit test for method close of class Connection
def test_Connection_close():
    dict_0 = {}
    connection_0 = Connection(**dict_0)
    e__str__ = connection_0.close()
    assert(e__str__ == None)


# Generated at 2022-06-25 09:08:08.433269
# Unit test for method put_file of class Connection
def test_Connection_put_file():
        # Setup
        source_0 = 'test'
        destination_0 = 'test'
        dict_0 = {}
        connection_0 = Connection(**dict_0)
        # Invoke method
        connection_0.put_file(source=source_0, destination=destination_0)


# Generated at 2022-06-25 09:08:17.429042
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    dict_0 = {'host': 'localhost', 'port': '5986', 'username': 'paul', 'password': 'password', 'protocol': 'http'}
    connection_0 = Connection(**dict_0)
    args_0 = ['ipconfig']
    kwargs_0 = {'use_local_scope': 'True', 'input_data': None, 'arguments': None}
    rc_0, stdout_0, stderr_0 = connection_0.exec_command(args_0, **kwargs_0)
    assert rc_0 == 0
    assert stdout_0
    assert stderr_0 == b''
