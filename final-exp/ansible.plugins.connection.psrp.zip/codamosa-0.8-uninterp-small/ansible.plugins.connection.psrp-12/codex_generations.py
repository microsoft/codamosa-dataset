

# Generated at 2022-06-25 08:59:49.677742
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    connection.connection = PSSession(None, None, None, None)
    ansible_shell_executable = None
    cmd = "if ($PSVersionTable.PSVersion.Major -lt 3) {$Command = {& $($_ -join ' ')}; } else {$Command = {& $args }}; $Command | Out-String -Stream | Write-Output -Encoding oem"
    in_data = None
    sudoable = None
    executable = None
    executable_argv = None
    binary_as_stdin = None
    in_data = None
    stdin = None
    stdout = None
    stderr = None
    call = None

# Generated at 2022-06-25 08:59:55.006568
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # First execute test_case_0 to create some test data
    test_case_0()
    connection_0 = Connection()
    connection_0.reset()

# Generated at 2022-06-25 09:00:01.482320
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    uri = "dummy_uri"
    in_path = "dummy_in_path"
    out_path = "dummy_out_path"
    use_powershell = "dummy_use_powershell"
    # Call method
    from ansible.plugins.connection.psrp import Connection
    con = Connection()
    con.put_file(in_path, out_path, use_powershell)



# Generated at 2022-06-25 09:00:04.609493
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()



# Generated at 2022-06-25 09:00:12.398734
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    file_path = "/tmp/file_path"
    remote_path = "/tmp/remote_path"
    tmp_file = "/tmp/tmp_file"
    tmp_dir = "/tmp/tmp_dir"
    open_kwargs = {"encoding": "utf-8"}
    set_remote_date = False
    connection_0 = Connection()
    connection_0.put_file(file_path,remote_path,tmp_file,tmp_dir,open_kwargs,set_remote_date)


# Generated at 2022-06-25 09:00:15.079188
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = 'in_path_0'
    out_path_0 = 'out_path_0'
    var_0 = connection_0.fetch_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:00:25.253600
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_1 = Connection()
    var_1 = connection_1.reset()

    # Assign test values to method parameters
    in_path = os.path.join('/', 'tmp', 'ansible-file-to-download')
    out_path = os.path.join('/', 'tmp', 'ansible-file-downloaded')
    file_args = {}
    file_args['mode'] = '0600'
    file_args['owner'] = ''
    file_args['group'] = ''
    file_args['selevel'] = ''
    file_args['serole'] = ''
    file_args['setype'] = ''
    file_args['seuser'] = ''

    # Call method
    rc_0 = connection_1.fetch_file(in_path, out_path, **file_args)

# Generated at 2022-06-25 09:00:35.905056
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create an instance of the Connection class
    connection_0 = Connection()
    # Configure the instance of the Connection class
    connection_0.configure()
    # Test the fetch_file() method of the connection object
    connection_0.fetch_file('an-remote-file', 'an-local-file', 'a-remote-path', 'a-local-path', 1024, True)
    # Test the case where the remote_file is None. A TypeError should be raised in this case
    try:
        connection_0.fetch_file(None, 'an-local-file', 'a-remote-path', 'a-local-path', 1024, True)
    except TypeError:
        pass
    except Exception as e:
        raise Exception(str(e))
    # Test the case where the local_file is None. A Type

# Generated at 2022-06-25 09:00:41.116047
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 09:00:46.038210
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()



# Generated at 2022-06-25 09:01:12.754620
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    display.debug("Unit test for function exec_command in class Connection:")
    # Test case 0
    # No exception caught
    try:
        display.info("Test case 0: no exception caught.")
        connection_0 = Connection()
        # assert os.path.exists(connection_0.get_option('remote_addr')) == True
    except Exception as e:
        display.display("Exception caught. " + str(type(e)) + str(e))
        display.display(traceback.format_exc())
        assert False
    else:
        display.display("exec_command in class Connection: no exception caught")
        assert True


# Generated at 2022-06-25 09:01:21.031109
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    # Test with valid inputs
    # Test with filesize as 1KB
    connection_0.fetch_file('C:/Users/vaishakh/Downloads/test_file.txt','C:/Users/vaishakh/Desktop/test_file.txt')
    # Test with filesize as 100KB
    connection_0.fetch_file('C:/Users/vaishakh/Downloads/test_file_100KB.txt', 'C:/Users/vaishakh/Desktop/test_file_100KB.txt')
    # Test with filesize as 1GB
    connection_0.fetch_file('C:/Users/vaishakh/Downloads/test_file_1GB.txt', 'C:/Users/vaishakh/Desktop/test_file_1GB.txt')

    # Test with Invalid inputs
   

# Generated at 2022-06-25 09:01:25.033117
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection()
    commands = 'dir'
    stdout = connection_1.exec_command(commands)
    assert(stdout)


# Generated at 2022-06-25 09:01:28.772621
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    # TODO Add implementation or remove method
    raise NotImplementedError()


# Generated at 2022-06-25 09:01:36.764137
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    print("\ntest_Connection_fetch_file")
    connection_0 = Connection()
    dir_path = u"C:\\Users\\konstantin.sorokin\\Downloads\\psrp-master\\test"
    file_name = u"test.txt"
    file_path = os.path.join(dir_path, file_name)
    connection_0.fetch_file(file_path, dir_path)
    assert os.path.exists(file_path)
    print("Test passed")


# Generated at 2022-06-25 09:01:44.473150
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cache_0 = CredentialCache()
    test_string_0 = 'test_value'
    test_string_1 = 'test_value'
    test_string_2 = 'test_value'
    test_string_3 = 'test_value'
    test_string_4 = 'test_value'
    test_string_5 = 'test_value'
    test_string_6 = 'test_value'
    test_string_7 = 'test_value'
    test_string_8 = 'test_value'
    test_string_9 = 'test_value'
    test_string_10 = 'test_value'
    test_string_11 = 'test_value'
    test_string_12 = 'test_value'

# Generated at 2022-06-25 09:01:45.548032
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_case_0()
    assert True


# Generated at 2022-06-25 09:01:48.551583
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    assert connection_0.put_file("./test.txt", "/path/to/remote") is None


# Generated at 2022-06-25 09:01:59.549788
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_file_name_0 = 'temp_data/temp_file_0.txt'
    test_file_name_1 = 'temp_data/temp_file_1.txt'
    test_file_name_2 = 'temp_data/temp_file_2.txt'
    test_file_name_3 = 'temp_data/temp_file_3.txt'
    test_file_name_4 = 'temp_data/temp_file_4.txt'
    test_file_name_5 = 'temp_data/temp_file_5.txt'
    test_file_name_6 = 'temp_data/temp_file_6.txt'
    text_file_name_1 = 'test_file_text_1.txt'

# Generated at 2022-06-25 09:02:05.966283
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    test_file_content = "test"
    test_file = NamedTemporaryFile(mode="w+")
    test_file.write(test_file_content)

    remote_path = "$env:TEMP\\test.txt"
    connection.put_file(test_file.name, remote_path)

    cmd = 'powershell -command "Get-Content -Path \'%s\' -Raw | Out-String"' % remote_path
    stdout, stderr, rc, _ = connection.conn.exec_command(cmd)
    stdout = stdout.readlines()

    assert rc == 0
    assert stdout[0].strip() == test_file_content


# Generated at 2022-06-25 09:02:44.567068
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    file_path_0 = create_temp_file()
    dest_path_0 = create_temp_file()
    connection_0.fetch_file(file_path_0 , dest_path_0 )


# Generated at 2022-06-25 09:02:48.920488
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cmd = 'ipconfig'
    rc, stdout, stderr = connection_0.exec_command(cmd)
    assert rc == 0
    assert stdout.find(b'Windows IP Configuration') > -1


# Generated at 2022-06-25 09:02:54.029038
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    b_in_path = b''
    in_path = ''
    b_out_path = b''
    out_path = ''

    try:
        connection_0.fetch_file(b_in_path, in_path, b_out_path, out_path)
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 09:02:56.542414
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    shell_0 = connection_0.exec_command('$true')
    assert shell_0.rc == 0


# Generated at 2022-06-25 09:03:03.101310
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    cmd_0 = "dir"
    expected_stdout_0 = b"displays a list of files and subdirectories in a directory"
    expected_stderr_0 = b""
    expected_rc_0 = 0

    # Create a new Connection object
    connection_0 = Connection()

    # Execute the command on the remote Windows host and get the stdout, stderr and rc
    rc_0, stdout_0, stderr_0 = connection_0.exec_command(cmd_0)

    assert(rc_0 == expected_rc_0)
    assert(stdout_0 == expected_stdout_0)
    assert(stderr_0 == expected_stderr_0)

    conection_0 = Connection()


# Generated at 2022-06-25 09:03:07.644661
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    try:
        connection_0.fetch_file(in_path=None, out_path=None)
    except NotImplementedError:
        print("NotImplementedError")
        pass


# Generated at 2022-06-25 09:03:09.060525
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:03:13.788840
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    remote_file_0 = "/var/log/syslog"
    local_file_0 = "/Users/miq/Documents/git_repos/ansible-psrp/lib/ansible/plugins/connection/psrp/test.tmp"
    result_0 = connection_0.fetch_file(remote_file_0, local_file_0)
    assert "file" in result_0 or "inode/" in result_0
    #assert result_0 == 0
    #assert result_0 == True


# Generated at 2022-06-25 09:03:26.469862
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    command = "ls -l"  # <type 'str'> (line number = 44)
    in_data = None  # <type 'NoneType'> (line number = 45)
    sudoable = False  # <type 'bool'> (line number = 46)
    check_rc = None  # <type 'NoneType'> (line number = 47)
    tmp_path = None  # <type 'NoneType'> (line number = 48)
    executable = None  # <type 'NoneType'> (line number = 49)
    binary_data = False  # <type 'bool'> (line number = 50)
    connection_0.exec_command(command, in_data, sudoable, check_rc, tmp_path, executable, binary_data)

# Generated at 2022-06-25 09:03:29.018930
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_0 = 'in0'
    out_0 = 'out0'
    b_0 = True
    connection_0.put_file(in_0, out_0, b_0)


# Generated at 2022-06-25 09:05:08.202447
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    assert not connection_0.resolve_auto_power_path
    assert not connection_0._loader_backup_dir
    assert not connection_0._shell
    assert not connection_0._matched_prompt
    assert connection_0._matched_pattern is None
    assert not connection_0._matched_hostname
    assert not connection_0._matched_username
    assert not connection_0._matched_device_path
    assert not connection_0._matched_device_prompt
    assert not connection_0._matched_command
    assert not connection_0._shell_type
    assert not connection_0._prompt_change_re
    assert not connection_0._shell_plugin
    assert not connection_0._connected
    assert not connection_0._become_method_supported
    assert not connection_0._bec

# Generated at 2022-06-25 09:05:15.013771
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-25 09:05:17.722152
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_1 = Connection()
    in_path_2 = './tst.txt'
    out_path_3 = './tstOut.txt'
    connection_1.put_file(in_path_2, out_path_3)


# Generated at 2022-06-25 09:05:29.708113
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    # Create connection arguments

# Generated at 2022-06-25 09:05:33.004766
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    command_0 = '/bin/ls -al'
    rc_0, stdout_0, stderr_0 = connection_0.exec_command(command_0)
    assert rc_0 == 0
    assert stdout_0 is None
    assert stderr_0 is None
    connection_0.close()


# Generated at 2022-06-25 09:05:41.614044
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    fq_file_path_0 = "put_file"
    in_path_0 = "in_path_0"
    out_path_0 = "out_path_0"
    follow_0 = False
    use_sudo_0 = False
    use_sudo_1 = False
    connection_0.put_file(fq_file_path_0, in_path_0, out_path_0, follow_0, use_sudo_0, use_sudo_1)


# Generated at 2022-06-25 09:05:49.332881
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print('\n' + "===== test_Connection_put_file =====")
    connection_0 = Connection()
    in_path_1 = tempfile.mktemp() 
    out_path_2 = '/Users/vagrant/git/ansible/test_put_out'
    ansible_module_runner_3 = get_runner(connection_0, play_context=dict(connection='local'))
    display.deprecated('use put_file() instead of push_file()', version='2.13')
    connection_0.put_file(in_path_1, out_path_2)


# Generated at 2022-06-25 09:05:56.457590
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Test with the following inputs
    in_path = "Path"
    out_path = "Path"
    # Optional input arguments
    buffer_size = None
    # Test the method
    x_0 = Connection()
    x_0.fetch_file("Path","Path")


# Generated at 2022-06-25 09:06:05.116380
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    b_in_path_0 = b'/home/hongbin/work/ansible/python/pypsrp/test/testdata/test.txt'  # An example of type: bytes
    b_in_path_1 = b'C:\\Users\\Administrator\\Desktop\\test.txt'  # An example of type: bytes
    b_out_path_0 = b'C:\\Users\\Administrator\\Desktop\\test.txt'  # An example of type: bytes
    in_path_0 = b_in_path_0.decode('utf-8')  # An example of type: str
    in_path_1 = b_in_path_1.decode('utf-8')  # An example of type: str
    out_path_0 = b_out_path_0

# Generated at 2022-06-25 09:06:11.808513
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    # Test for command with 1 arg
    with pytest.raises(AnsibleConnectionFailure):
        connection_0.fetch_file('b_in_path')
    # Test for command with 2 args
    with pytest.raises(AnsibleConnectionFailure):
        connection_0.fetch_file('b_in_path', 'b_out_path')
    # Test for command with too many args
    with pytest.raises(AnsibleConnectionFailure):
        connection_0.fetch_file('b_in_path', 'b_out_path', 'buffer_size')
