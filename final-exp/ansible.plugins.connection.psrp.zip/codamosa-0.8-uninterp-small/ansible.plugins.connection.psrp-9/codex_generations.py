

# Generated at 2022-06-25 08:59:41.460943
# Unit test for constructor of class Connection
def test_Connection():
    var_0 = Connection()
    assert var_0 is not None


# Generated at 2022-06-25 08:59:44.566281
# Unit test for method close of class Connection
def test_Connection_close():
    connection_1 = Connection()
    var_1 = connection_1.close()


# Generated at 2022-06-25 08:59:46.793676
# Unit test for method reset of class Connection
def test_Connection_reset():
    print("test_Connection_reset")

    connection_0 = Connection()
    var_0 = connection_0.reset()


# Generated at 2022-06-25 08:59:49.413911
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    var_1 = connection_0.put_file('test/resources/test_file.txt', 'test/resources/test_file.txt')


# Generated at 2022-06-25 08:59:51.260431
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()


# Generated at 2022-06-25 08:59:52.589516
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    assert var_0 is None


# Generated at 2022-06-25 08:59:56.112326
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()


# Generated at 2022-06-25 08:59:58.973211
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    var_0 = connection_0.exec_command('cmd.exe /c echo The command worked!')


# Generated at 2022-06-25 09:00:03.594503
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    src_0 = 'this'
    dest_0 = ansible_winrm_0 = ansible_winrm_1 = local_url_0 = local_url_1 = 'winrm:///Users/jerry/Desktop/code/ansible/lib/ansible/plugins/connection/psrp.py'
    force_0 = 3
    validate_src_0 = True
    checksum_0 = True
    connection_0 = Connection()
    var_0 = connection_0.put_file(src_0, dest_0, force_0, validate_src_0, checksum_0)


if __name__ == '__main__':
    test_case_0()
    test_Connection_put_file()

# Generated at 2022-06-25 09:00:06.306851
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    print("In test_Connection_fetch_file()")

    connection_0 = Connection()
    in_path = "/etc/passwd"
    out_path = "ansible_file"
    var_0 = connection_0.fetch_file(in_path=in_path, out_path=out_path)

    print("In test_Connection_fetch_file()")

# Generated at 2022-06-25 09:00:25.255065
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    assert True


# Generated at 2022-06-25 09:00:26.382211
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:00:29.080172
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    assert connection_0.exec_command("foo", False) == "foo\r\n"


# Generated at 2022-06-25 09:00:35.167853
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Unit test stub for method put_file of class Connection
    ansible_module = AnsibleModule(argument_spec={})
    connection_0 = Connection()
    in_path = connection_0.put_file()
    if in_path == None:
        ansible_module.exit_json(changed=False)



# Generated at 2022-06-25 09:00:43.811043
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    try:
        connection_0 = Connection()
        if isinstance(connection_0, Connection):
            put_file_return_value_0 = connection_0.put_file(None, None)
            assert put_file_return_value_0 is None
        else:
            raise TypeError("Cannot test the return type of a method that is not a class")
    except TypeError as err:
        print("TypeError in method 'test_Connection_put_file': {}".format(err))


# Generated at 2022-06-25 09:00:46.638624
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:00:54.778717
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_directory = "C:\\ansible_test_dir\\"

    # create a test file for the put_file function
    test_file = open(test_directory + "unit_test_file.txt", "w+")
    test_file.close()
    os.chmod(test_directory + "unit_test_file.txt", 0o555)

    # Create a connection object
    connection_1 = Connection()

    #Test put_file with null args
    result_1 = connection_1.put_file(test_directory + "unit_test_file.txt", "")
    assert result_1 == False

    #Test put_file with null file
    result_2 = connection_1.put_file("", "./test_directory/test_file.txt")
    assert result_2 == False

    #Test put

# Generated at 2022-06-25 09:01:02.382025
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Setup
    connection_0 = Connection()
    connection_0._psrp_user = 'fake'
    connection_0._psrp_pass = 'fake'
    connection_0._psrp_cert_validation = False
    connection_0._psrp_conn_kwargs = {
        'server': 'localhost',
        'port': 5986,
        'username': 'fake',
        'password': 'fake',
        'ssl': False
    }
    connection_0.runspace = None
    connection_0._connected = True
    connection_0._last_pipeline = None
    in_path = '/tmp/fake'
    out_path = '/tmp/fake'

    # Act

# Generated at 2022-06-25 09:01:03.140639
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:01:05.824783
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    connection_0.put_file()



# Generated at 2022-06-25 09:01:29.849844
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection()
    command_1 = "ipconfig"
    exit_code_1, stdout_1, stderr_1 = connection_1.exec_command(command_1)
    print("Exit Code: %s" % exit_code_1)
    if len(stdout_1) > 0:
        print("stdout: ")
        print(stdout_1.decode('utf-8'))
    if len(stderr_1) > 0:
        print("stderr: ")
        print(stderr_1.decode('utf-8'))


# Generated at 2022-06-25 09:01:40.066344
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Test 0: Fetch remote file
    test_file = u'Test file \u65e5\u672c\u8a9e.txt'


# Generated at 2022-06-25 09:01:51.315967
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_1 = Connection()
    try:
        connection_1.put_file(
            in_path=None,
            out_path=None,
            use_winrm=False,
            set_remote_user=True,
            use_ntlm=False,
            use_ssl=True,
            force_basic_auth=False,
            docker_extra_vars=None,
            options=None,
            index_of_first_non_dash_argument=0
        )
    except Exception:
        # caught an exception that we didn't expect
        return False
    else:
        # didn't catch an exception as expected
        return True


# Generated at 2022-06-25 09:01:55.018273
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    print("Test fetch_file of class Connection")
    connection_0 = Connection()
    connection_0.fetch_file("in_path", "out_path")


# Generated at 2022-06-25 09:01:57.083898
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    print('------> Executing test_Connection_exec_command ')
    connection_0 = Connection()
    assert connection_0.exec_command(command='') == (0, None, None)
    print('------> Executed!')


# Generated at 2022-06-25 09:02:02.137025
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    # Initialize connection instance
    connection_0 = Connection()

    # Inputs for command execution
    inputs = {'command': 'Import-Module ServerManager \n Add-WindowsFeature AS-NET-Framework', 'sudoable': False}

    # Action on connection to test method
    response = connection_0.exec_command(**inputs)

    # Print the output of the command
    print("\nResponse: %s" % response)


# Generated at 2022-06-25 09:02:08.086595
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    connection_0.protocol = 'protocol_0'

    # Test method with option remote_addr
    connection_0.remote_addr = 'remote_addr_0'
    in_path = 'in_path_0'
    out_path = 'out_path_0'
    try:
        connection_0.fetch_file(in_path, out_path)
    except:
        pass

    # Test method with options remote_user and remote_password
    connection_0.remote_user = 'remote_user_0'
    connection_0.remote_password = 'remote_password_0'
    try:
        connection_0.fetch_file(in_path, out_path)
    except:
        pass

if __name__ == "__main__":
    test_

# Generated at 2022-06-25 09:02:09.799332
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    result_0 = connection_0.reset()
    assert(result_0 == None)


# Generated at 2022-06-25 09:02:15.810614
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    connection_0.open()
    cmd = "echo 'HelloWorld'"
    rc, stdout, stderr = connection_0.exec_command(cmd)
    assert stdout == "HelloWorld\r\n"
    assert rc == 0
    assert stderr == ""
    connection_0.close()


# Generated at 2022-06-25 09:02:18.443632
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    try:
        connection_1 = Connection()
        connection_1.fetch_file('arg1', 'arg2')
    except RuntimeError:
        pass


# Generated at 2022-06-25 09:02:56.813308
# Unit test for method reset of class Connection
def test_Connection_reset():
    child = Connection()
    child.reset()

if __name__ == '__main__':
    test_case_0()
    test_Connection_reset()

# Generated at 2022-06-25 09:03:03.053207
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a new instance of Connection
    connection_0 = Connection()
    # Create a new instance of TemporaryDirectory
    temporary_directory_0 = TemporaryDirectory()

    # Call method put_file of Connection
    try:
        connection_0.put_file(b'/tmp/test_file', temporary_directory_0.name)
    # Check if an exception of type IOError was raised
    except IOError as exception_0:
        print(exception_0)
    
    # Call method put_file of Connection
    connection_0.put_file(b'test_file', temporary_directory_0.name)


# Generated at 2022-06-25 09:03:08.736143
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Setup test input
    self_0 = Connection()
    in_path_1 = None
    out_path_1 = None

    # Invoke method
    try:
        result_1 = self_0.put_file(in_path_1, out_path_1)

    except Exception as exception:
        print(exception)


# Generated at 2022-06-25 09:03:14.741561
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    f = open("../test_cases/test_case_0.txt", "r")
    lines = f.readlines()
    test_case_0_connection = ansible.plugins.connection.psrp.Connection()
    test_case_0_result = test_case_0_connection.exec_command(lines[0])
    # We need to check if the result is what we expected.
    assert test_case_0_result == "0"


# Generated at 2022-06-25 09:03:19.308748
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    connection_0.put_file(file_path=None, out_path=None)


# Generated at 2022-06-25 09:03:21.797000
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    assert connection_0.reset() == None
    return


# Generated at 2022-06-25 09:03:25.413896
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    try:
        rc, stdout, stderr = connection_0.exec_command('ping google.com')
    except:
        rc = -1
    assert rc != -1


# Generated at 2022-06-25 09:03:31.300523
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = 'test-in-path'
    out_path = 'test-out-path'
    # Call method
    connection_0.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:03:32.594799
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    file = None
    connection_0.fetch_file(file)


# Generated at 2022-06-25 09:03:34.345977
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:05:14.727513
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    print(os.path.basename(__file__) + ": Connection.exec_command()")
    connection_0 = Connection()
    command_0 = 'cmd.exe'
    stdin_0 = None
    check = connection_0.exec_command(command_0, in_data=stdin_0)
    if (check['stdout'] == 'Microsoft Windows [Version 10.0.10240]\r\n(c) 2015 Microsoft Corporation. All rights reserved.\r\n\r\nC:\\Users\\Natasha>' and
            check['stdout_lines'] == ['Microsoft Windows [Version 10.0.10240]', '(c) 2015 Microsoft Corporation. All rights reserved.', '', 'C:\\Users\\Natasha>']) and check['rc'] == 0 and check['stderr'] == '':
        print

# Generated at 2022-06-25 09:05:16.413280
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    try:
        connection_0.exec_command('ls')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 09:05:17.761726
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # TODO: write test for connection._put_file
    assert False


# Generated at 2022-06-25 09:05:22.579661
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    pytest.skip('Not implemented yet.')


# Generated at 2022-06-25 09:05:25.580987
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()
    # The connection is reset to the default state


# Generated at 2022-06-25 09:05:30.939237
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_case_0()
    print("Unit Test for method put_file of class Connection")
    path = "vartest123"
    tmpdir = "C:\\Temp"
    path = os.path.join(tmpdir, path)
    print("path: {}".format(path))
    contents = "Contents: Test Content"
    f = open(path, "w")
    f.write(contents)
    connection_0.put_file(path, path)
    print("Successfully put file")
    f.close()
    os.remove(path)


# Generated at 2022-06-25 09:05:32.195219
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:05:43.516566
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()

# Generated at 2022-06-25 09:05:51.718793
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    assert connection_0.exec_command('Test-NetConnection -ComputerName 192.168.0.1') == (0, b'ComputerName     : 192.168.0.1\r\nRemoteAddress    : 192.168.0.1\r\nInterfaceAlias   : Wi-Fi\r\nSourceAddress    : 192.168.0.5\r\nPingSucceeded    : True\r\nPingReplyDetails (RTT) : 0 ms', b'')


# Generated at 2022-06-25 09:05:56.177487
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
        # self.connection.socket.close()
        try:
            # connection_0 = Connection(self._play_context, new_stdin=StdinStringIO())
            connection_0 = Connection()
            result = connection_0.reset(_server_capabilities=None,
                in_data=None, task_uuid=None)
            print('Result:', str(result))
            #
            print()
            print('Test reset(): OK')
        finally:
            connection_0.close()
    except Exception as exc:
        print('Test reset(): FAILED')
        raise
