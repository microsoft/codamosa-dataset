

# Generated at 2022-06-25 08:59:46.536922
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_1 = Connection()
    in_path = 'in_path' # Default value
    out_path = 'out_path' # Default value
    use_cont_rq = True # Default value
    var_1 = connection_1.fetch_file(in_path, out_path, use_cont_rq)


# Generated at 2022-06-25 08:59:54.264866
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    kwargs = dict(
        in_path="/path/byte/file",
        out_path="/remote/path",
        use_winrm_temp=None,
        winrm_file_transfer=None,
        winrm_temp_dir=None,
    )
    connection_0 = Connection()
    var_0 = connection_0.put_file(**kwargs)


# Generated at 2022-06-25 08:59:59.918544
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    fetch_file_0 = Connection()
    in_path_0 = '.\\in_path'
    out_file_0 = '.\\out_file'
    display_0 = Display()
    var_0 = fetch_file_0.fetch_file(in_path_0, out_file_0, display_0)


# Generated at 2022-06-25 09:00:07.536622
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    with pytest.raises(AnsibleConnectionFailure, match=r"PSRP is not supported for windows_local"):
        connection_0 = Connection()
        result_0 = connection_0.exec_command("dir")


# Generated at 2022-06-25 09:00:10.750281
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    connection_0.exec_command("", "")


# Generated at 2022-06-25 09:00:15.597138
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    script_0 = '''
        function foo{

        }

        foo
    '''
    json_0 = '''{ "test" : "test_val"}'''
    var_0 = connection_0.exec_command(script_0, json_0)


# Generated at 2022-06-25 09:00:22.186884
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    if 'ansible_shell_type' in connection.get_shell_type().keys():
        pass
    output = connection.exec_command(command='dir', tmp_path='dir')
    assert output['rc'] == 0
    assert output['stdout'] is not None


# Generated at 2022-06-25 09:00:27.145084
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path_0 = 'test_in_path'
    out_path_0 = 'test_out_path'
    use_winrm_path_conversion_0 = True
    var_0 = connection_0.put_file(in_path_0, out_path_0, use_winrm_path_conversion_0)

# Generated at 2022-06-25 09:00:28.367143
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    test_case_0()
    print("PSRP fetch_file complete")


# Generated at 2022-06-25 09:00:31.842271
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()


# Generated at 2022-06-25 09:00:55.289921
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()

    try:
        connection_0.close()
    except Exception:
        # We ignore any exception that may be thrown here, we just want to know
        # if code crashes.
        pass
    else:
        var_0 = True
        assert var_0


# Generated at 2022-06-25 09:01:02.865320
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    from ansible.module_utils.common._collections_compat import Mapping
    import json

    # Since these are unit tests and we are testing the returned results based on the provided inputs, we will be making
    # use of FakeAnsibleModule functionality.
    module_name = 'test_' + uuid.uuid4().hex
    fake_module = FakeAnsibleModule(module_name)

    # input params that are to be used by the fake_module

# Generated at 2022-06-25 09:01:04.663556
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    assert_raises(TypeError, connection_0.close)


# Generated at 2022-06-25 09:01:12.318226
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    a_out_path = os.path.join(os.getcwd(), "test_ansible_temp_file.out")
    b_out_path = os.path.join(os.getcwd(), "test_ansible_temp_file.err")
    print("a_out_path=", a_out_path)
    print("b_out_path=", b_out_path)
    # Test case 0
    connection_0 = Connection()
    connection_0.establish()
    var_0 = connection_0.exec_command("powershell.exe -Command Get-EventLog")
    connection_0.put_file("test_put_file_0.ps1", "test_put_file_1.ps1")

# Generated at 2022-06-25 09:01:20.726867
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    mock_tmpdir = None
    connection_0 = Connection()
    mock_cmd = None
    mock_daemonize = None
    mock_executable = None
    mock_in_data = None
    mock_sudoable = None
    mock_unpack = None
    mock_init = None
    mock_stdin = None
    mock_bin_data = None
    mock_stderr = None
    mock_stdout_lines = None
    mock_stdout = None
    mock_bin_data = None
    mock_env = None
    mock_stdout_lines = None
    mock_stdout = None
    mock_bin_data = None
    mock_stdout_lines = None
    mock_stdout = None
    mock_bin_data = None
    mock_stderr = None
    mock_bin

# Generated at 2022-06-25 09:01:30.769281
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test 1: Input is a string
    connection_1 = Connection()
    arguments_1 = 'Get-Process'
    rc_1, stdout_1, stderr_1 = connection_1.exec_command(arguments_1)
    assert rc_1 == 0
    assert stdout_1 is not None
    assert stderr_1 is not None
    connection_1.close()

    # Test 2: Input has carriage return and line feed
    connection_2 = Connection()
    arguments_2 = 'Get-Process\r\n'
    rc_2, stdout_2, stderr_2 = connection_2.exec_command(arguments_2)
    assert rc_2 == 0
    assert stdout_2 is not None
    assert stderr_2 is not None
    connection_2.close()



# Generated at 2022-06-25 09:01:40.301982
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Test template for the method put_file of class Connection.
    # Test the basic functionality of the method
    connection_0 = Connection()
    connection_0.set_options({'protocol': 'http', 'remote_addr': '127.0.0.1', 'remote_user': 'Administrator', 'remote_password': 'pass', 'port': 5985, 'ca_cert': 'ca.pem', 'remote_port': 5985, 'private_key_file': 'private.key', 'cert_validation': True, 'connection_timeout': 5})
    connection_0.connection
    connection_0.cert_validation = False
    in_path_0 = ''
    out_path_0 = ''
    buf_0 = ''

# Generated at 2022-06-25 09:01:41.628100
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()


# Generated at 2022-06-25 09:01:43.505556
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 09:01:47.258548
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    filename_0 = 'abc'
    path_0 = '/abc/abc'
    var_0 = connection_0.put_file(filename_0, path_0)



# Generated at 2022-06-25 09:02:15.191957
# Unit test for method reset of class Connection
def test_Connection_reset():
    str_0 = 'test_'
    str_1 = 'test_'
    dict_2 = {str_0:str_1}
    str_3 = 'test_'
    dict_4 = {str_0:str_1}
    str_5 = 'test_'
    str_6 = 'test_'
    dict_7 = {str_0:str_1}
    str_8 = 'test_'
    dict_9 = {str_0:str_1}
    str_10 = 'test_'
    str_11 = 'test_'
    dict_12 = {str_0:str_1}
    str_13 = 'test_'
    dict_14 = {str_0:str_1}
    str_15 = 'test_'
    str_16 = 'test_'

# Generated at 2022-06-25 09:02:21.731553
# Unit test for method put_file of class Connection
def test_Connection_put_file():
  data = list(range(0,10))
  size = random.randint(1,10)
  remote_path = 'test_file_put_file.txt'
  local_path = 'test_file_put_file.txt'
  module = 'test_module'
  callbacks = ''
  try:
     tmp_0 = Connection(str_0,data)
     tmp_0.put_file(local_path,remote_path,module,callbacks)
  except Exception as e:
    print(e)


# Generated at 2022-06-25 09:02:30.268617
# Unit test for method reset of class Connection
def test_Connection_reset():
    hostname = '127.0.0.1'
    str_0 = 'test_'
    str_1 = 'test_'
    str_2 = 'test_'
    str_3 = 'test_'
    str_4 = 'test_'
    str_5 = 'test_'
    str_6 = 'test_'
    str_7 = 'test_'
    str_8 = 'test_'
    str_9 = 'test_'
    str_10 = 'test_'
    str_11 = 'test_'
    str_12 = 'test_'
    str_13 = 'test_'
    str_14 = 'test_'
    str_15 = 'test_'
    str_16 = 'test_'
    str_17 = 'test_'

# Generated at 2022-06-25 09:02:31.032370
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()


# Generated at 2022-06-25 09:02:40.178380
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    fmtstr = '%s'
    str_0 = 'test_0'
    str_1 = '@'
    str_2 = 'test_4'
    str_3 = 'test_2'
    str_4 = 'test_3'
    str_5 = 'test_1'
    str_6 = 'test_5'
    str_7 = 'test_6'
    str_8 = '%s'

    # Set up mock

# Generated at 2022-06-25 09:02:44.680602
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    host = _PSRPConnection()
    in_path = 'test'
    out_path = 'test'
    buffer_size = 8192
    host.fetch_file(in_path, out_path, buffer_size)


# Generated at 2022-06-25 09:02:49.387212
# Unit test for method close of class Connection
def test_Connection_close():
    try:
        str_0 = 'test_'
        str_1 = ConnectionPlugins.PSRP.get_connection_info()
        str_1 = ConnectionPlugins.PSRP.close()
    except:
        print('Exception')
        # TODO: put a real assertion and exception here
        return


# Generated at 2022-06-25 09:02:52.179347
# Unit test for method reset of class Connection
def test_Connection_reset():
    print('test_Connection_reset')
    # ------ Arrange ------
    connection = Connection()

    # ------ Act ------
    connection.reset()

    # ------ Assert ------
    assert True


# Generated at 2022-06-25 09:02:55.302209
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection(str_0, str_0)
    connection_0.reset(str_0)
    connection_0.reset(str_0)


# Generated at 2022-06-25 09:02:57.783211
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
        psrp_0 = Connection()
        psrp_0.reset()
    except Exception as e_0:
        print(e_0)
        test_case_0()


# Generated at 2022-06-25 09:03:17.655397
# Unit test for method close of class Connection
def test_Connection_close():
    test_case_0()
    connection = Connection()
    connection.close()


# Generated at 2022-06-25 09:03:20.365092
# Unit test for method close of class Connection
def test_Connection_close():
    str_1 = 'test_'


# Generated at 2022-06-25 09:03:21.636019
# Unit test for method close of class Connection
def test_Connection_close():
    assert "close" == True

# Generated at 2022-06-25 09:03:26.899834
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    in_path = os.path.expanduser('~/rawdata/yiluo/test_data/test_file.txt')
    out_path = os.path.expanduser('~/rawdata/yiluo/exchange_test/test_file_put.txt')
    copy_file(in_path, out_path)
    get_file(in_path, out_path)


# Generated at 2022-06-25 09:03:33.516528
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
        var_a = Connection()
    except:
        import traceback,sys
        exc_type, exc_value, exc_traceback = sys.exc_info()
        stacktrace = traceback.format_exception(exc_type, exc_value, exc_traceback)
        print(''.join(stacktrace))
        sys.exit(1)

    var_a.conn_id='test_'
    var_a.port=int(980)
    var_a.host=None
    var_a.username=None
    var_a._socket_path=None
    var_a.ipv6=None
    var_a.password=None
    var_a.host_hash=None
    var_a.private_key_file=None
    var_a.private_key_pass=None


# Generated at 2022-06-25 09:03:44.438087
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    host = None
    in_data = None
    tmp_path = None
    tmp_path_1 = None
    max_size = -1
    tmp_path_2 = None
    tmp_path_3 = None
    str_0 = 'test_'
    tmp_path_4 = None
    test_path_0 = None
    test_path_1 = None
    tmp_path_5 = None
    test_path_2 = None
    tmp_path_6 = None
    test_path_3 = None
    test_path_4 = None
    tmp_path_7 = None
    test_path_5 = None
    tmp_path_8 = None
    test_path_6 = None
    test_path_7 = None
    test_path_8 = None
    test_path_9 = None


# Generated at 2022-06-25 09:03:54.396603
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    remote_file = 'test_file'
    put_file_script = '''
        param($content)
        $Value = [System.Convert]::FromBase64String($content)
        $FilePath = "%s"
        Set-Content -Encoding Byte -Path $FilePath -Value $Value
    ''' % remote_file

# Generated at 2022-06-25 09:03:55.372690
# Unit test for method close of class Connection
def test_Connection_close():
  test_case_0()



# Generated at 2022-06-25 09:04:05.295777
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection(1, 2)
    command = str(3)
    args = str(4)
    in_data = str(5)
    sudoable = False
    executable = lambda: None
    stdin = lambda: None
    stdin_add_newline = False
    become_method = 'test_'
    become_user = 'test_'

    # Pass number 1 (cover branch 1)
    # Pass number 2 (cover branch 2)
    # Pass number 3 (cover branch 3)
    # Pass number 4 (cover branch 3)
    # Pass number 5 (cover branch 4)
    # Pass number 6 (cover branch 5)
    # Pass number 7 (cover branch 5)

# Generated at 2022-06-25 09:04:06.729266
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_Connection_reset_0()


# Generated at 2022-06-25 09:04:42.401362
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = '<VALUE>'
    out_path_0 = '<VALUE>'
    result = connection_0.fetch_file(in_path_0, out_path_0)
    assert result is None


# Generated at 2022-06-25 09:04:46.282027
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Setup
    connection_0 = Connection()
    connection_0.params = dict()
    connection_0.params["ansible_connection"] = "psrp"

    # Test
    # connection_0.fetch_file(result, in_path, out_path,)
    try:
        connection_0.fetch_file()
    except Exception as e:
        assert e


# Generated at 2022-06-25 09:04:48.386341
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()

    # Following line should raise an exception since no runspace exists yet
    #connection_0.put_file('./test_files/test_put_file', 'c:\\test_files\\test_put_file')

# Generated at 2022-06-25 09:04:51.343418
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conneciton_0 = Connection()

# Generated at 2022-06-25 09:04:56.292372
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # unit tests for exec_command
    connection_0 = Connection()
    cmd_0 = 'ipconfig'
    args_0 = ['/all']
    raise Exception('Failed unit test for Connection.exec_command')


# Generated at 2022-06-25 09:04:59.679411
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()


# Generated at 2022-06-25 09:05:04.136962
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = ""
    out_path = ""
    try:
        connection_0.fetch_file(in_path, out_path)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 09:05:05.917232
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    with pytest.raises(Exception):
        connection_0.reset()


# Generated at 2022-06-25 09:05:11.806369
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    if connection_0.runspace.state == RunspacePoolState.Opened:
        connection_0.close()
    connection_0.close()
    runspace_1 = RunspacePool(connection_0._connection_0)
    connection_0.runspace = runspace_1
    connection_0.connect()
    in_path_2 = 'test_in_path'
    out_path_3 = 'test_out_path'
    connection_0.fetch_file(in_path_2, out_path_3)
    runspace_1.close()
    connection_0.close()


# Generated at 2022-06-25 09:05:19.189385
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = "Path to input file"
    out_path = "Path to output file"
    with mock.patch('ansible.plugins.connection.psrp.to_bytes') as mock_to_bytes:
        connection_0.fetch_file(in_path,out_path)
        mock_to_bytes.assert_called_once_with(out_path, encoding='utf-8')


# Generated at 2022-06-25 09:05:49.833406
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    # Make sure the required attributes are set
    display.vvvv(connection_0.runspace)
    display.vvvv(connection_0._last_pipeline)
    display.vvvv(connection_0.host)
    display.vvvv(connection_0._psrp_host)
    display.vvvv(connection_0._psrp_user)
    display.vvvv(connection_0._psrp_pass)
    display.vvvv(connection_0._psrp_protocol)
    display.vvvv(connection_0._psrp_port)
    display.vvvv(connection_0._psrp_path)
    display.vvvv(connection_0._psrp_auth)

# Generated at 2022-06-25 09:05:52.206728
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    assert connection_0.connected() == False
    connection_0._connected = True
    connection_0.reset()
    assert connection_0.connected() == False
    assert connection_0.runspace == None


# Generated at 2022-06-25 09:05:54.522481
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    local_file_path = os.path.join(os.path.dirname(__file__), "asm/start_server.py")
    connection_0 = Connection()
    connection_0.put_file(local_file_path, "/tmp/test")


# Generated at 2022-06-25 09:05:55.867375
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    assert connection_0 != None
    connection_0.reset()
    assert connection_0 != None


# Generated at 2022-06-25 09:06:00.075367
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = ''
    out_path_0 = ''
    file_args_0 = {}
    result_0 = connection_0._fetch_file(in_path_0, out_path_0, file_args_0)
    assert result_0 is None


# Generated at 2022-06-25 09:06:05.651950
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()

    file_0 = File()
    temp_file_0 = tmp_path()
    in_path_0 = "../usr/bin/python"
    out_path_0 = "/tmp/home/b7h8yso4F4"
    validate_certs_0 = True

    # Call method
    connection_0.fetch_file(in_path_0, out_path_0, temp_file_0, file_0, validate_certs_0)


# Generated at 2022-06-25 09:06:13.614778
# Unit test for constructor of class Connection
def test_Connection():
    connection_0 = Connection()
    assert getattr(connection_0, "DEFAULT_SUDO_EXE") == 'sudo'
    assert getattr(connection_0, "DEFAULT_SUDO_FLAGS") == ('-H',)
    assert getattr(connection_0, "DEFAULT_SU_EXE") == 'su'
    assert getattr(connection_0, "DEFAULT_SU_FLAGS") == ('-c',)
    assert getattr(connection_0, "DEFAULT_BECOME_EXE") == SU_PROMPT_LOCALE.split()[0]
    assert getattr(connection_0, "DEFAULT_BECOME_FLAGS") == SU_PROMPT_LOCALE.split()[1:]
    assert getattr(connection_0, "DEFAULT_BECOME_METHOD")

# Generated at 2022-06-25 09:06:15.927223
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection()
    # Execute command
    cmd = "Get-ChildItem"
    arg = None
    in_data = None
    stdout = connection_1._exec_psrp_script(cmd, in_data, True, arg)
    #print(stdout)


# Generated at 2022-06-25 09:06:21.276882
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = "/opt/ansible/ansible/test/integration/targets/psrp/iaas_psrp_win"
    out_path_0 = "/home/ansible/ansible/test/integration/targets/psrp/iaas_psrp_win/hello"
    connection_0.fetch_file(in_path_0, out_path_0)

    # Exception: Path to remote file must be absolute.
    in_path_1 = "hello"
    out_path_1 = "/home/ansible/ansible/test/integration/targets/psrp/iaas_psrp_win/hello"

# Generated at 2022-06-25 09:06:23.184151
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection()
    assert connection_1.exec_command("") == (0, "", "")


# Generated at 2022-06-25 09:07:20.781212
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    src = ''
    dst = ''
    result = connection_0.fetch_file(src, dst)


# Generated at 2022-06-25 09:07:30.080532
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    class Connection:
        def __init__(self):
            self.play_context = dict()


    def get_option(key):
        return None

    def get_file_attributes(self, path):
        return {}

    def get_folder_attributes(self, path):
        return {}

    def get_file_attributes_if_exists(self, path):
        return {}

    def get_folder_attributes_if_exists(self, path):
        return {}

    def run(self, cmd, in_data, sudoable=True):
        return 0, None, None

    Connection.get_option = get_option
    Connection.get_file_attributes = get_file_attributes
    Connection.get_folder_attributes = get_folder_attributes
    Connection.get_file_att

# Generated at 2022-06-25 09:07:30.878863
# Unit test for constructor of class Connection
def test_Connection():
    connection_0 = Connection()
    return



# Generated at 2022-06-25 09:07:33.355169
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    assert connection_0 is not None
    connection_0.fetch_file()


# Generated at 2022-06-25 09:07:36.761510
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    print("PSRP Connection exec_command test")
    connection_0 = Connection()
    stdout = connection_0.exec_command("Get-Date")
    print(stdout)


# Generated at 2022-06-25 09:07:44.860982
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()

# Generated at 2022-06-25 09:07:49.260351
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = "in_path_0"
    out_path_0 = "out_path_0"
    connection_0.fetch_file(in_path_0,out_path_0)


# Generated at 2022-06-25 09:07:52.360551
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:07:56.728383
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:08:03.154859
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()

    path_1 = './just_a_file.txt'
    remote_path_1 = 'C:/Temp/just_a_file.txt'
    path_2 = './file_with_encoding.txt'
    remote_path_2 = 'C:/Temp/file_with_encoding.txt'

    # Create a file locally so it can be uploaded to remote server.
    if not os.path.exists(path_1):
        f = open(path_1, 'w')
        f.close()
    if not os.path.exists(path_2):
        f = open(path_2, 'w')
        f.close()

    connection.host = ''
    connection.protocol = 'http'
    connection.port = 5985
    connection.path = None
   