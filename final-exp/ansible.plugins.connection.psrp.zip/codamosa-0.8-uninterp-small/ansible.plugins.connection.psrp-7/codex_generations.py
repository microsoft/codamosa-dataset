

# Generated at 2022-06-25 08:59:47.942958
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # --> Constructor test
    connection_0 = Connection()
    # --> Execution test
    ret_0 = connection_0.exec_command('command_0')
    assert(ret_0 == (0, '', ''))


# Generated at 2022-06-25 08:59:49.306284
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_1 = Connection()
    var_1 = connection_1.fetch_file()


# Generated at 2022-06-25 08:59:50.485142
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 08:59:55.160076
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # TODO: This test is a placeholder currently, needs to be implemented
    pass


# Generated at 2022-06-25 09:00:04.950475
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    test_connection = Connection()

# Generated at 2022-06-25 09:00:07.202487
# Unit test for method close of class Connection
def test_Connection_close():
    conn = Connection()
    conn.close()


# Generated at 2022-06-25 09:00:17.558628
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path_0 = str()
    out_path_0 = str()
    f_0 = Mock()
    data_0 = to_bytes('')
    f_0.read.return_value = data_0
    f_0.tell.return_value = 58
    display_0 = Mock()
    display_0.display.return_value = None
    connection_0.display = display_0
    input_data_0 = str()
    arguments_0 = str()
    var_0 = connection_0._exec_psrp_script(in_path_0, input_data=input_data_0, arguments=arguments_0)
    _connection_put_file(connection_0, in_path_0, out_path_0, f_0)


# Generated at 2022-06-25 09:00:19.417424
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()



# Generated at 2022-06-25 09:00:23.582888
# Unit test for method reset of class Connection
def test_Connection_reset():
    var_0 = test_case_0()
    assert var_0 is None, "return of type None"


# Generated at 2022-06-25 09:00:29.141938
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()

# Method to enable testing of the execute method of class Connection

# Generated at 2022-06-25 09:00:49.992739
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 09:00:51.107921
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()


# Generated at 2022-06-25 09:00:55.559425
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    connection_0 = Connection()
    in_path_0 = "test_file"
    out_path_0 = "test_file"
    if out_path_0=="":
        raise ValueError("out_path must be set")
    var_0 = connection_0.fetch_file(in_path_0,out_path_0)


# Generated at 2022-06-25 09:00:56.655973
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()



# Generated at 2022-06-25 09:00:58.168082
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 09:01:01.609549
# Unit test for method reset of class Connection
def test_Connection_reset():
    if connection_0.connected:
        var_0 = connection_0.close()
    connection_0.clear()
    var_0 = connection_0.reset()
    var_1 = connection_0.connected
    var_2 = var_1
    var_3 = (var_2 is False)
    assert var_3


# Generated at 2022-06-25 09:01:09.078651
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print("Testing put_file ...")
    connection_0 = Connection()
    in_path_0 = None
    out_path_0 = None
    try:
        # Passed parameters
        connection_0.put_file(in_path_0, out_path_0)
        print("... No exception raised!")
    except Exception as e:
        print("... Exception raised:", e)
    print("Done!")


# Generated at 2022-06-25 09:01:13.965504
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
        test_case_0()
    except Exception as exp:
        print("Exception raised in test_case_0: %s" % str(exp))
        raise exp
    else:
        print("No exception raised in test_case_0")
    finally:
        pass



# Generated at 2022-06-25 09:01:18.002853
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    command = "Get-Process"
    connection_0 = Connection()
    var_0 = connection_0.exec_command(command)


# Generated at 2022-06-25 09:01:21.473492
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    connection_0.reset()
    in_path_0 = 'C:\\TEMP\\Test.txt'
    out_path_0 = 'C:\\ansible_test\\Test.txt'
    var_0 = connection_0.fetch_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:01:52.683711
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    buf_0 = create_string_buffer('cmd')
    buf_array_0 = Array(POINTER(c_char), [buf_0])
    var_0 = connection_0.exec_command(buf_array_0)
    var_1 = connection_0.exec_command(buf_array_0)
    var_2 = connection_0.exec_command(buf_array_0)
    var_3 = connection_0.exec_command(buf_array_0)
    var_4 = connection_0.exec_command(buf_array_0)
    var_5 = connection_0.exec_command(buf_array_0)
    var_6 = connection_0.exec_command(buf_array_0)

# Generated at 2022-06-25 09:01:55.019101
# Unit test for method close of class Connection
def test_Connection_close():
    print("test_Connection_close")


# Generated at 2022-06-25 09:02:00.871004
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Initial input parameters
    connection_0 = Connection()
    command_0 = u'ls'
    stdin_0 = None
    run_as_0 = None
    # Setup args
    args = command_0, stdin_0, run_as_0
    # Expected result
    result = 2, u'ls', u''
    # Real result
    real_result = connection_0.exec_command(*args)
    # Compare result
    # assert real_result == result


# Generated at 2022-06-25 09:02:02.713346
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
        test_case_0()
    except Exception as exception:
        raise AssertionError(exception)


# Generated at 2022-06-25 09:02:04.324228
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    del(connection_0)


# Generated at 2022-06-25 09:02:18.200573
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    cmd = "dir"
    expected_rc = 0
    expected_stdout = (b"\r\n"
        b"    Directory: C:\\TEST\r\n"
        b"\r\n"
        b"\r\n"
        b"Mode                LastWriteTime         Length Name\r\n"
        b"----                -------------         ------ ----\r\n"
        b"-a----        18/01/2017     10:57             0 test.txt\r\n")
    expected_stderr = b""

    rc, stdout, stderr = connection_0.exec_command(cmd)
    assert rc == expected_rc
    assert stdout == expected_stdout
    assert stderr == expected

# Generated at 2022-06-25 09:02:22.973082
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
        test_case_0()
    except Exception as err:
        print(err)


# Generated at 2022-06-25 09:02:26.968886
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    path_0 = ''
    file_0 = ''
    file_1 = ''
    connection_0.fetch_file(path_0, file_0, file_1)


# Generated at 2022-06-25 09:02:28.754920
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    with pytest.raises(NotImplementedError):
        connection.fetch_file(in_path=None, out_path=None)


# Generated at 2022-06-25 09:02:31.992983
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    var_0 = connection_0.reset()


# Generated at 2022-06-25 09:03:08.518509
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()


# Generated at 2022-06-25 09:03:11.354578
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    connection_0.reset()
    in_path_0 = 'in_path_0'
    out_path_0 = 'out_path_0'
    var_0 = connection_0.fetch_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:03:13.260418
# Unit test for method close of class Connection
def test_Connection_close():
    from ansible.plugins.connection.psrp import Connection
    connection_0 = Connection()
    var_0 = connection_0.reset()
    connection_0.close()


# Generated at 2022-06-25 09:03:15.831697
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    var_0 = connection_0.reset()
    var_1 = connection_0.exec_command('pwd')
    print(var_1)
    var_2 = connection_0.exec_command('echo abc')
    print(var_2)


# Generated at 2022-06-25 09:03:16.932006
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test for python 2.7 and after
    test_case_0()

# Generated at 2022-06-25 09:03:18.863264
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = ''
    out_path = ''
    var_0 = connection_0.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:03:25.524751
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()

    var_0 = connection_0.put_file('ansible_psrp_fs_case_sensitive', 'file:///C:/Windows/System32/WindowsPowerShell/v1.0/Modules/PSDesiredStateConfiguration/DSCResources/MSFT_xArchiveResource/archive.psm1', 'C:\\Windows\\Temp\\archive.psm1')


# Generated at 2022-06-25 09:03:29.114368
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Init class
    connection_0 = Connection()
    # Init #0
    var_1 = "C:\\Windows\\Temp\\file_9.txt"
    var_2 = "C:\\Windows\\Temp\\file_10.txt"
    # Call function
    connection_0.put_file(var_1, var_2)


# Generated at 2022-06-25 09:03:31.268429
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path = ''  # Put an appropriate value here
    out_path = ''  # Put an appropriate value here
    var_0 = connection_0.put_file(in_path, out_path)


# Generated at 2022-06-25 09:03:35.726852
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    connection_0 = Connection()
    in_path_0 = b'/tmp/ansible_psrp_payload_fCwGip'
    out_path_0 = u'/home/vagrant/ansible-module-psrp/test/test_cases/test_Connection/test_Case_0/home/vagrant/ansible-module-psrp/test/test_cases/test_Connection/test_Case_0'
    var_0 = connection_0.fetch_file(in_path_0, out_path_0)



# Generated at 2022-06-25 09:05:21.195995
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from ansible.errors import AnsibleError
    connection_0 = Connection()
    in_path_0 = "in_path_0"
    out_path_0 = "out_path_0"
    # convert in_path and out_path to respective Windows paths if necessary.
    if ':' not in in_path_0:
        in_path_0 = 'C:\\WINDOWS\\Temp\\ansible_file_transfer_payload_' + in_path_0
    if ':' not in out_path_0:
        out_path_0 = 'C:\\WINDOWS\\Temp\\ansible_file_transfer_payload_' + out_path_0
    remote_0 = True

# Generated at 2022-06-25 09:05:25.537927
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()

    assert(isinstance(connection_0, Connection))

    assert_raises(AnsibleConnectionFailure, connection_0.connect)

    connection_0._build_kwargs()
    connection_0.reset()

# Generated at 2022-06-25 09:05:27.313054
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    path_0 = 'abc'
    file_0 = connection_0.fetch_file(path_0)


# Generated at 2022-06-25 09:05:32.804041
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.reset()
    var_1 = connection_0.close()


# Generated at 2022-06-25 09:05:38.071430
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    with mock.patch('ansible_collections.ansible.community.plugins.module_utils.common.winrm.pypsrp.client.Client.open') as mocked_open, \
            mock.patch('ansible_collections.ansible.community.plugins.module_utils.common.winrm.pypsrp.client.Client.invoke_command') as mocked_invoke_command, \
            mock.patch('ansible_collections.ansible.community.plugins.module_utils.common.winrm.pypsrp.client.WSManClient.disconnect') as mocked_disconnect:
        # setup the mock
        connection_0 = Connection()
        connection_0.orig_conn = MagicMock()
        connection_0.reset()
        mocked_open.side_effect = [True, True, True]
        mocked_

# Generated at 2022-06-25 09:05:40.716871
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    var_0 = connection_0.fetch_file('dir_0', 'file_0')


# Generated at 2022-06-25 09:05:41.698727
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()


# Generated at 2022-06-25 09:05:45.784271
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_1 = Connection()
    in_path = "foobar"
    out_path = "foobar"
    var_1 = connection_1.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:05:52.195395
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Ensure that the put_file method does nothing if the file was not changed
    connection = Connection()
    result = connection.put_file("foo", "file", False, False)
    if result:
        raise ValueError("Result should be false")

    # Ensure that the put_file method fails if the file cannot be read
    result = connection.put_file("foo", "file", True, False)
    if result:
        raise ValueError("Result should be false")

    # Ensure that the put_file method succeeds if the file can be read
    result = connection.put_file("foo", "file", True, True)
    if not result:
        raise ValueError("Result should be true")


# Generated at 2022-06-25 09:05:56.328445
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = 'in/path'
    out_path = 'out/path'
    var_0 = connection_0.fetch_file(in_path, out_path)
