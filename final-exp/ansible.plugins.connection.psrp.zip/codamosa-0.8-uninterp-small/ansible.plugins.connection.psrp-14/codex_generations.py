

# Generated at 2022-06-25 08:59:47.175952
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 08:59:48.666809
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 08:59:50.052121
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 08:59:51.517627
# Unit test for method reset of class Connection
def test_Connection_reset():
    test_case_0()


# Generated at 2022-06-25 08:59:56.516698
# Unit test for method close of class Connection
def test_Connection_close():
    # Basic test with all required parameters
    connection_0 = Connection()
    var_0 = connection_0.close()


# Generated at 2022-06-25 08:59:59.194578
# Unit test for constructor of class Connection
def test_Connection():
    display.info("Function: " + __name__)
    test_case_0()
    display.info("SUCCESS\n")

# Generated at 2022-06-25 09:00:01.564754
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    assert connection_0.exec_command('whoami') is None
    assert connection_0.connected is True


# Generated at 2022-06-25 09:00:02.625838
# Unit test for method reset of class Connection
def test_Connection_reset():
    # expected: "return None"
    assert test_case_0() == None, 'Expected None'


# Generated at 2022-06-25 09:00:14.778959
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test template from:
    # https://github.com/pytest-dev/pytest/blob/master/lib/python3.5/_pytest/python.py#L534
    # See also:
    # https://docs.pytest.org/en/latest/example/simple.html#writing-well-integrated-assertion-helpers
    # https://docs.pytest.org/en/latest/assert.html
    #
    # Test case 0
    #
    test_file = '<INSERT_TEST_FILE_PATH>'
    test_data = '<INSERT_TEST_DATA>'
    test_mode = '<INSERT_TEST_MODE_AS_STRING>'
    test_cwd = '<INSERT_TEST_CWD>'

# Generated at 2022-06-25 09:00:27.342368
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    var_0 = to_text(path.join(core.ANSIBLE_TEST_DATA_ROOT, 'test_copy_fetch_success'))
    connection_0.set_options(direct={'remote_addr': 'localhost', 'remote_user': 'vagrant', 'remote_port': 5986, 'protocol': 'https', 'operation_timeout': 45})
    connection_0.set_task_uuid('a2f93ffe-9f8f-4e3f-bfc5-ac2a0aefa063')
    connection_0.set_loader('8c8bf33174a6a99a0ddb14e843f1d0a7')

# Generated at 2022-06-25 09:00:53.038434
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:01:00.665679
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    def enable_debug_logging():
        display.verbosity = 5
        display.columns = 80
        display.debug = True
        display.deprecate_warnings = False
    
    display.verbosity = 5
    display.columns = 80
    display.debug = True
    display.deprecate_warnings = False
    
    conn_0 = Connection()
    # Test with values for local_path as String
    local_path_0 = 'mydir/myfile.txt'
    # Test with values for remote_path as String
    remote_path_0 = 'mydir/myfile.txt'
    # Test with values for set_remote_mod as String
    set_remote_mod_0 = 'no'
    # Test with values for module_implementation as String

# Generated at 2022-06-25 09:01:07.321719
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    args = ["$env:APPDATA\\Temp\\ansible-test-file", "C:\\test.txt"]
    if connection_0.check_mode:
        return
    connection_0.fetch_file(args[0], args[1])


# Generated at 2022-06-25 09:01:11.067914
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()

    # act
    connection_0.fetch_file("c:\\temp\\report.txt", "c:\\temp\\result.txt")


# Generated at 2022-06-25 09:01:15.977269
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Define paths for source and destination of file
    in_path = "C:\\Users\\Public\\Documents\\in.txt"
    out_path = "/home/ansible/in.txt"

    connection_0 = Connection()
    connection_0.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:01:17.259467
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:01:19.358564
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    output_0 = connection_0.fetch_file('file_path', 'local_path')
    assert output_0 == None


# Generated at 2022-06-25 09:01:23.823551
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:01:25.565893
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:01:37.215760
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    connection_0.runspace = RunspacePool(RunspacePoolState.OPENED)
    destination = '/home/michael/microcloud/ansible/test/integration/targets/psrp/test_file'
    b_destination = to_bytes(destination, errors='surrogate_or_strict')
    remote_path = '/home/michael/microcloud/ansible/test/integration/targets/psrp/test_file'
    b_remote_path = to_bytes(remote_path, errors='surrogate_or_strict')
    # test fetch_file method of class Connection
    connection_0.fetch_file(destination, remote_path)


# Generated at 2022-06-25 09:02:17.570427
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_Connection_put_file_0()


# Generated at 2022-06-25 09:02:22.570571
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()


# Generated at 2022-06-25 09:02:24.283570
# Unit test for constructor of class Connection
def test_Connection():
    connection_0 = Connection()
    try:
        connection_0
    except NameError as ne:
        print(ne)


# Generated at 2022-06-25 09:02:27.274652
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()

    args = []
    result = connection.exec_command(args)
    assert result == (None, None, None)


# Generated at 2022-06-25 09:02:38.790887
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_1 = Connection()
    in_path_1 = 'C:\\Users\\agduncan\\Documents\\Automation\\ansible\\test\\test_psrp\\test_in_0.txt'
    out_path_1 = 'C:\\Users\\agduncan\\Documents\\Automation\\ansible\\test\\test_psrp\\test_out_0.txt'
    display.vvvvv("host=%s in_path=%s out_path=%s" % (connection_1._psrp_host, in_path_1, out_path_1), host=connection_1._psrp_host)
    connection_1.fetch_file(in_path_1, out_path_1)


# Generated at 2022-06-25 09:02:41.485467
# Unit test for method reset of class Connection
def test_Connection_reset():
    # No parameters specified
    display.vvvvv("*** START test_Connection_reset ***")
    connection_0 = Connection()
    connection_0.reset()
    display.vvvvv("*** FINISH test_Connection_reset ***")


# Generated at 2022-06-25 09:02:45.524633
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    c = Connection()
    c.runspace = psrp_runspace.runspace_pool()
    fetch_file(c, 'dummy_in_path', 'dummy_out_path', 100)


# Generated at 2022-06-25 09:02:50.530902
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = ''
    out_path = ''
    fail_on_missing = False
    use_ntlm = False
    connection = connection_0
    result = connection.fetch_file(in_path, out_path, fail_on_missing, use_ntlm)
    assert result is None


# Generated at 2022-06-25 09:02:55.591092
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    assert (connection_0.runspace is None), "connection_0.runspace"
    assert (connection_0._connected == False), "connection_0._connected"
    assert (connection_0._last_pipeline is None), "connection_0._last_pipeline"
    connection_0.close()


# Generated at 2022-06-25 09:02:59.097168
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = "C:\Windows\notepad.exe"
    out_path = "notepad.exe"
    connection_0.fetch_file(in_path, out_path)
    print("Successfully fetched file from remote host...Please verify file",out_path)


# Generated at 2022-06-25 09:04:25.627254
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = ""
    out_path = ""
    connection_0.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:04:29.727391
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:04:36.893623
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    # Setup test case
    connection_0 = Connection()

    # Setup parameters
    in_path = "C:\\Users\\alice.johnson\\Documents\\test.ps1"
    out_path = "C:\\Users\\alice.johnson\\Documents\\test.ps1"
    file_size = "55"

    # Invoke method
    connection_0.fetch_file(in_path, out_path, file_size)


# Generated at 2022-06-25 09:04:45.550880
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    connection_0 = Connection()
    in_path_0 = b'/tmp/data.txt'
    out_path_0 = b'/tmp/data.txt'
    file_args_0 = dict(false='false', false='false', false='false')
    file_kwargs_0 = dict(md5sum='md5sum', sha1sum='sha1sum', checksum='checksum', content='content', decode='decode', validate_certs='validate_certs', follow='follow')

    connection_0.fetch_file(in_path_0, out_path_0, **file_kwargs_0)


# Generated at 2022-06-25 09:04:53.045656
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict

    loader_0 = DataLoader()
    inventory_0 = InventoryManager(loader=loader_0, sources=['/etc/ansible/hosts'])
    variable_manager_0 = VariableManager(loader=loader_0, inventory=inventory_0)

# Generated at 2022-06-25 09:05:00.861384
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    connection_0._build_kwargs()
    connection_0.connect()
    connection_0._exec_psrp_script("New-Item -ItemType directory -Path $env:TEMP -Name psrp -ea 0")
    connection_0._exec_psrp_script("$txt = 'This is the test file content.'")
    connection_0._exec_psrp_script("$env:TEMP\\psrp\\test.txt | Out-File -Encoding Ascii -Force -ea 0")
    connection_0._exec_psrp_script("Out-File -Encoding Ascii -InputObject $txt -FilePath $env:TEMP\\psrp\\test.txt")
    in_path='$env:TEMP\\psrp\\test.txt'
   

# Generated at 2022-06-25 09:05:07.096352
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    print("Testing exec_command")
    connection_0 = Connection()
    # self.pod_1.unschedule_pod_events(events)
    assert connection_0.exec_command("ls -a") == (0, "\n".join([".", "..", "afile.txt", "bfile.txt", "dfile.txt"]), "")
    assert connection_0.exec_command("ls /tmp/")[0] == 0


# Generated at 2022-06-25 09:05:08.227794
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:05:13.809402
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    type_file_content = "read_bytes"
    encode_to_base64 = False
    b_file_content = b"read_bytes"
    if encode_to_base64:
        b_file_content = encode_text(b_file_content, 'base64').encode('utf-8')
    result = connection_0.put_file(local_path="temp_file_name", remote_path="temp_file_name", mode="w",
                                   type_file_content=type_file_content, encode_to_base64=encode_to_base64,
                                   b_file_content=b_file_content)
    assert result == None


# Generated at 2022-06-25 09:05:21.466560
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    psrp_host = 'hostname'
    psrp_user = 'domain\\username'
    psrp_pass = 'password'
    psrp_port = 5985
    psrp_protocol = 'http'
    psrp_path = '/wsman'
    psrp_connection_timeout = None
    psrp_read_timeout = None
    psrp_message_encryption = 0
    psrp_proxy = None
    psrp_ignore_proxy = False
    psrp_max_envelope_size = 153600
    psrp_operation_timeout = None

    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote_addr = psrp_host
    play_context.port = psrp