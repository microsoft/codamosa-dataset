

# Generated at 2022-06-25 08:59:45.639009
# Unit test for method reset of class Connection
def test_Connection_reset():
    con = Connection()
    con.reset()
    return 0


# Generated at 2022-06-25 08:59:53.261667
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    def mock_exec_psrp_script(script, input_data=None, use_local_scope=True, arguments=None):
        return 0, '', ''

    # Create a new connection object
    connection_0 = Connection()
    # Set the in_path variable to the given test value
    in_path = '/home/pypsrp/test.txt'
    # Set the out_path variable to the given test value
    out_path = '/home/pypsrp/test.txt'
    # Set the buffer_size variable to the given test value
    buffer_size = 0
    # Set the runspace variable to the given test value
    runspace = RunspacePool()
    # Set the runspace_pool variable to the given test value
    runspace_pool = RunspacePool()
    # Set the host variable to the given

# Generated at 2022-06-25 08:59:54.172722
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()


# Generated at 2022-06-25 08:59:58.175804
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path = ''
    out_path = ''
    connection_0.put_file(in_path, out_path)


# Generated at 2022-06-25 09:00:02.562591
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    script = 'echo "hello"'
    input_data = None
    arguments = None
    actual = connection_0._exec_psrp_script(script, input_data, True, arguments)
    expected = (0, b'hello\r\n', b'')
    assert actual == expected


# Generated at 2022-06-25 09:00:10.224939
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    try:
        if os.path.exists("setup.pyx"):
            os.remove("setup.pyx")
    except:
        print("Can't delete file setup.pyx")

    connection_0 = Connection()
    connection_0.put_file("setup.py", "setup.pyx")
    if not os.path.exists("setup.pyx"):
        print("put_file failed: output file does not exist")


# Generated at 2022-06-25 09:00:14.376762
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = 'in_path'
    out_path = 'out_path'
    use_controldirs = False
    test_case_0(connection_0, in_path, out_path, use_controldirs)


# Generated at 2022-06-25 09:00:20.630468
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    actual = connection_0.exec_command("pwd")
    actual_x = connection_0.exec_command("pwd", use_local_scope=True)


# Generated at 2022-06-25 09:00:23.107004
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Set up test environment
    connection_0 = Connection()
    cmd_0 = None

    # Call class method being tested
    stdout, stderr, rc = connection_0.exec_command(cmd_0)

    # Test execution of method
    assert(True)


# Generated at 2022-06-25 09:00:24.968708
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_1 = Connection()
    connection_1.put_file(None, None)



# Generated at 2022-06-25 09:01:11.458019
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    try:
        connection_0.fetch_file()
    except NotImplementedError:
        return
    assert False


# Generated at 2022-06-25 09:01:15.098984
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = "in_path_0"
    out_path_0 = "out_path_0"
    connection_0.fetch_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:01:19.837700
# Unit test for constructor of class Connection
def test_Connection():
    connection_0 = Connection()
    connection_1 = Connection()
    assert connection_0.protocol == 'psrp'
    assert connection_1.protocol == 'psrp'
    assert connection_0.shell is None
    assert connection_1.shell is None
    assert connection_0.delegate is None
    assert connection_1.delegate is None
    assert connection_0.closed is False
    assert connection_1.closed is False
    assert connection_0.always_pipeline_modules == False
    assert connection_1.always_pipeline_modules == False
    assert connection_0.connected is False
    assert connection_1.connected is False
    assert connection_0.allow_executable_pipeline is True
    assert connection_1.allow_executable_pipeline is True
    assert connection_0

# Generated at 2022-06-25 09:01:25.491668
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    # session_0 should be a pypsrp.client.Client object
    session_0 = mock.Mock(pypsrp.client.Client)
    # runspace_0 should be a pypsrp.powershell.Runspace object
    runspace_0 = mock.Mock(pypsrp.powershell.Runspace)
    # runspace_pool_0 should be a pypsrp.powershell.RunspacePool object
    runspace_pool_0 = mock.Mock(pypsrp.powershell.RunspacePool)
    # powershell_0 should be a pypsrp.powershell.PowerShell object
    powershell_0 = mock.Mock(pypsrp.powershell.PowerShell)
    # pipeline_0 should be a pypsrp.powershell

# Generated at 2022-06-25 09:01:29.152133
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    command_0 = 'dir'
    connection_0.exec_command(command_0)


# Generated at 2022-06-25 09:01:39.564094
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    # Testing with a non-existing file
    test_file_name = "/tmp/asdf13456789asdf.txt"
    connection_0 = Connection()
    connection_0.psrp_client = MagicMock()
    connection_0.psrp_client.get.return_value = False

    with pytest.raises(AnsibleError, match=r".*does not exist on the remote server.*"):
        connection_0.fetch_file(test_file_name)

    # Testing with an empty file
    connection_0.psrp_client.get.return_value = True
    connection_0.psrp_client.read_file.return_value = b''


# Generated at 2022-06-25 09:01:52.640490
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = './ansicolor.py'
    out_path = '/home/work/'
    buffer_size = 1024
    connection_0.runspace = pypsrp.runspace.RunspacePool(connection_0._psrp_host,
                                                         connection_0._psrp_user,
                                                         connection_0._psrp_pass,
                                                         ssl=connection_0._psrp_protocol == 'https',
                                                         port=connection_0._psrp_port,
                                                         cert_validation=connection_0._psrp_cert_validation)
    connection_0.runspace.connection_info.protocol_version = connection_0._psrp_configuration_name
    connection_0.runspace.open()

# Generated at 2022-06-25 09:02:02.781639
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # initialize the class and test attributes
    psrp_host = "ansible_test_host"
    psrp_port = 5986
    psrp_user = "ansible_test_user"
    psrp_pass = "ansible_test_pass"
    psrp_protocol = "https"
    psrp_read_timeout = None
    psrp_path = None
    psrp_auth = "basic"
    psrp_cert_validation = True
    psrp_connection_timeout = 30
    psrp_message_encryption = None
    psrp_proxy = None
    psrp_ignore_proxy = False
    psrp_operation_timeout = 30
    psrp_max_envelope_size = 153600
    psrp_config

# Generated at 2022-06-25 09:02:08.192357
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import io
    import os
    import sys
    print("Running fetch_file test case")
    # Test case variables
    task_vars = dict()
    # Create an instance of class Connection
    connection_0 = Connection()
    # Set instance variables
    display.verbosity = 2
    connection_0._connected = True
    connection_0._play_context = dict(remote_addr="10.10.10.10", port=5986, password="test",
                                      connection_user="test", remote_user="test", remote_password="test",
                                      transport="psrp", become_method=None,
                                      become_user=None, become_password=None, become_exe=None,
                                      sudo_flags=None, sudoable=False, connection="local",
                                      no_log=False, verbosity=2)

# Generated at 2022-06-25 09:02:15.155941
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cmd = 'cmd'
    in_data = None
    sudoable = None
    executable = None
    stdin = None
    stdout = None
    stderr = None
    start_time = None
    use_unsafe_shell = None
    no_log = None
    encoding = None

    # Call method
    rc, out, err = connection_0.exec_command(cmd, in_data, sudoable, executable, stdin, stdout, stderr, start_time, use_unsafe_shell, no_log, encoding)


# Generated at 2022-06-25 09:03:41.338429
# Unit test for method close of class Connection
def test_Connection_close():
    connection_1 = Connection()
    try:
        connection_1.close()
    except Exception as e:
        print("It's failed to close connection! The exception is: " + repr(e))
    else:
        print("It's successful to close connection!")


# Generated at 2022-06-25 09:03:42.918172
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    c = Connection()
    command = c.exec_command('"hello world"')
    assert command == (0, 'hello world')


test_case_0()
test_Connection_exec_command()

# Generated at 2022-06-25 09:03:45.027233
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Test with basic arguments
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:03:47.630172
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    # NOTE: file_transfer.chunk_size can not be None
    connection_0.put_file(b'/tmp/to/path', b'/tmp/from/path', file_transfer.chunk_size, None)


# Generated at 2022-06-25 09:03:49.625659
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()

    source = "source"
    destination = "destination"
    connection_0.put_file(source, destination)


# Generated at 2022-06-25 09:03:55.716952
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    command = "ls"
    executable = None
    stdin = None
    in_data = None
    sudoable = True
    suppress_warning = True
    # Call Connection.exec_command with correct arguments
    try:
        result = connection.exec_command(command, executable, stdin, in_data, sudoable, suppress_warning)
    except Exception as err:
        display.error("Testcase 0 failed")


# Generated at 2022-06-25 09:04:05.577801
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    if not bool(os.getenv('UNITTEST_VERBOSE')):
        return
    connection_0 = Connection()
    connection_0.host = 'host_0'
    connection_0.runspace = 'runspace_0'
    connection_0._psrp_host = 'localhost'
    connection_0._psrp_user = 'test'
    connection_0._psrp_pass = 'testpassword'
    connection_0._psrp_protocol = 'http'
    connection_0._psrp_port = 5985
    connection_0._psrp_path = '/wsman'
    connection_0._psrp_auth = 'basic'
    connection_0._psrp_cert_validation = True
    connection_0._psrp_connection_timeout = 30
    connection

# Generated at 2022-06-25 09:04:11.035804
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    connection_0._build_kwargs = MagicMock()
    connection_0._connect = MagicMock()
    connection_0._exec_psrp_script = MagicMock()
    connection_0._parse_pipeline_result = MagicMock()
    connection_0.close = MagicMock()
    connection_0.host = MagicMock()
    connection_0.host.get_tmp_path = MagicMock()
    connection_0.runspace = MagicMock()
    connection_0.runspace.id = 0
    connection_0.runspace.state = RunspacePoolState.OPENED
    connection_0._psrp_host = '192.168.1.1'
    connection_0._psrp_port = 5986
    connection_0._psr

# Generated at 2022-06-25 09:04:12.809460
# Unit test for method close of class Connection
def test_Connection_close():
    c = Connection()
    c.close()


# Generated at 2022-06-25 09:04:20.126579
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    ansible_host_0 = 'ansible.host.0'
    ansible_host_1 = 'ansible.host.1'
    chunk_size = 65536
    remote_file = 'remote/file'
    local_file = 'local/file'
    b_remote_file = to_bytes(remote_file, encoding='utf-8')
    b_remote_path = to_bytes(os.path.dirname(remote_file), encoding='utf-8')
    b_local_file = to_bytes(local_file, encoding='utf-8')
    b_chunk_size = chunk_size

# Generated at 2022-06-25 09:08:31.608967
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    assert(isinstance(connection_0.close(), bool))


# Generated at 2022-06-25 09:08:37.757532
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_1 = Connection()
    file_name_1 = "test_put_file.txt"
    file_content_1 = "Test content for put_file"
    file_1 = open(file_name_1, 'w')
    file_1.write(file_content_1)
    file_1.close()
    file_name_2 = "test_put_file_2.txt"
    file_content_2 = "Additional content for put_file"
    file_2 = open(file_name_2, 'w')
    file_2.write(file_content_2)
    file_2.close()
    in_path_1 = os.path.dirname(os.path.realpath(__file__)) + "\\" + file_name_1

# Generated at 2022-06-25 09:08:41.231419
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()

# Generated at 2022-06-25 09:08:47.598179
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = 'C:\\Users\\Wei\\Desktop\\ansible'
    out_path = 'C:\\Users\\Wei\\Desktop\\ansible'
    connection_0.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:08:52.135219
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = 'setup'
    out_path_0 = 'setup'
    file_args_0 = dict()
    file_args_0['src'] = in_path_0
    file_args_0['dest'] = out_path_0
    file_args_0['mimetype'] = None
    file_args_0['remote_src'] = True
    file_args_0['follow'] = False
    file_args_0['path_encoding'] = None
    file_args_0['method'] = 'get'
    connection_0.fetch_file(**file_args_0)


# Generated at 2022-06-25 09:09:03.994594
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_1 = Connection()
    in_path_2 = 'test'
    out_path_3 = 'test'
    file_args_4 = None
    file_args_4 = dict()
    file_args_4['src'] = out_path_3
    file_args_4['contents'] = ''
    connection_1.module_implementation_pre = MagicMock()
    connection_1.module_implementation_pre.return_value = True
    connection_1.get_option = MagicMock()
    connection_1.get_option.return_value = True
    connection_1.fetch_file(in_path_2, out_path_3, file_args_4)
