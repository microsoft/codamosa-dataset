

# Generated at 2022-06-25 08:59:44.086425
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()
    assert(True)



# Generated at 2022-06-25 08:59:45.722979
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 08:59:47.305825
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    Connection.put_file(connection=None, in_path=None, out_path=None, chunk_size=None, timeout=None)


# Generated at 2022-06-25 08:59:48.494642
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()



# Generated at 2022-06-25 08:59:52.286439
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path = u'file_name'
    out_path = u'file_name'
    tmp_path = u'file_name'
    try:
        connection_0.put_file(in_path, out_path, tmp_path)
    except Exception as error:
        print("Test case 0: Failed: " + str(error.args))
        raise


# Generated at 2022-06-25 08:59:53.325505
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 08:59:58.160156
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    mock_self = MagicMock(spec=Connection)
    mock_in_path = MagicMock(spec=str)
    mock_out_path = MagicMock(spec=str)
    mock_tmp = MagicMock(spec=str)
    mock_in_path.replace = MagicMock(return_value=mock_tmp)
    mock_tmp = MagicMock(spec=str)
    mock_out_path.encode = MagicMock(return_value=mock_tmp)
    mock_tmp = MagicMock(spec=str)
    mock_tmp.replace = MagicMock(return_value=mock_tmp)
    mock_tmp.strip = MagicMock(return_value=mock_tmp)
    mock_b_out_path = MagicMock(spec=str)
    mock_b

# Generated at 2022-06-25 08:59:59.835089
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # connection_0 = Connection()
    # assert isinstance(connection_0, Connection)
    assert True


# Generated at 2022-06-25 09:00:05.171162
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    reset_0 = connection_0.reset()


# Generated at 2022-06-25 09:00:10.704645
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    t = Connection()
    t.exec_command('dir')

if __name__ == '__main__':
    test_Connection_exec_command()

# Generated at 2022-06-25 09:00:33.319242
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:00:40.886096
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_1 = Connection()
    command_0 = "/bin/echo"

    if DEBUG:
        command_0 = "/bin/echo"
    else:
        command_0 = "/bin/echo"

    connection_1.exec_command(command_0)


# Generated at 2022-06-25 09:00:43.878142
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:00:45.453427
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset(None)


# Generated at 2022-06-25 09:00:51.831303
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    empty_file_path = os.path.abspath('psrp/tests/fixture/empty')
    nonempty_file_path = os.path.abspath('psrp/tests/fixture/nonempty')
    invalid_path = os.path.abspath('psrp/tests/fixture/invalid_path')
    connection_0 = Connection()


# Generated at 2022-06-25 09:00:52.895544
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()


# Generated at 2022-06-25 09:00:55.886204
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    input_0 = 'TEST'
    input_1 = None
    input_2 = None
    input_3 = None
    # print(connection_0.exec_command(input_0, input_1, input_2, input_3))


# Generated at 2022-06-25 09:00:57.406618
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    connection_0.put_file("a", "b")


# Generated at 2022-06-25 09:00:59.570154
# Unit test for method reset of class Connection
def test_Connection_reset():
    try:
        reactor_0 = Reactor()
        connection_0 = Connection()
        connection_0.reset()
    except:
        assert False
    return



# Generated at 2022-06-25 09:01:08.927671
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_1 = 'test_in_path'
    out_path = 'test_out_path'
    tmp_path_4 = 'test_tmp_path'
    local_follow = True
    use_tmout = True
    ref_5 = 'test_ref'
    test_0_1 = connection_0._fetch_file(in_path_1, out_path, tmp_path_4, local_follow, use_tmout, ref_5)
    # Check if fetch_file returns bytes
    assert type(test_0_1) is bytes


# Generated at 2022-06-25 09:01:55.497143
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print("\n>>> put_file <<<")
    connection_0 = Connection()
    in_path = u"C:\Temp"
    in_data = "abcdefgh"
    out_path = u"C:\Temp"
    connection_0.put_file(in_path, in_data, out_path)


# Generated at 2022-06-25 09:02:01.344604
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()

    # This test requires arguments.
    b_in_path = b'in_path'
    b_out_path = b'out_path'

    with patch.object(pypsrp, 'get_file') as patched_get_file:
        connection_0.fetch_file(b_in_path, b_out_path)
        patched_get_file.assert_called_once_with(b'in_path', b'out_path')


# Generated at 2022-06-25 09:02:05.651605
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    parameter_0 = "C:\\Anaconda3\\powershell.exe"
    parameter_1 = 'wWLvV8'
    parameter_2 = "C:\\Users\\ymy\\powershell.exe"
    parameter_3 = False
    try:
        connection_0.put_file(parameter_0, parameter_1, parameter_2, parameter_3)
    except Exception as e:
        pass


# Generated at 2022-06-25 09:02:08.627738
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()


# Generated at 2022-06-25 09:02:11.760587
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Initialize a variable that will hold the return value of method
    # under test
    method_under_test_ret_val = None

    # Instantiate a Connection object
    connection_0 = Connection()

    # Call the method under test
    method_under_test_ret_val = connection_0.put_file(in_path='in/path', out_path='out/path')

    # Assert return value type
    assert(isinstance(method_under_test_ret_val, bool))



# Generated at 2022-06-25 09:02:14.560088
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Initialization
    b_in_path = ''
    b_out_path = ''
    connection_0 = Connection()
    # Invocation
    connection_0.put_file(b_in_path, b_out_path)


# Generated at 2022-06-25 09:02:17.370500
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    stdout_0 = connection_0.exec_command('echo abc')
    if stdout_0 != 'abc\n':
        print("ERROR: stdout doesn't match expected string: 'abc\\n', actual string is '%s'" % (stdout_0))


# Generated at 2022-06-25 09:02:26.928401
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """
    If the user does not pass in a command but instead just a list that contains the command and its arguments then PSRP
    will merge the elements of the list into a string and pass that as the command to PowerShell.
    """
    connection_1 = Connection()
    connection_1._exec_psrp_script(script="Get-Process")
    connection_1._exec_psrp_script(script=["Get-Process"])


# Generated at 2022-06-25 09:02:31.509614
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:02:32.665738
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:03:55.716844
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    result = connection_0.put_file(b"", b"", None)
    assert result is None


# Generated at 2022-06-25 09:04:00.551233
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = 'C:\\tmp'
    out_path = 'C:\\tmp'
    test_case_0()
    try:
        connection_0.fetch_file(in_path, out_path)
    except Exception as error:
        print(error)


# Generated at 2022-06-25 09:04:05.002472
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    rc, stdout, stderr = connection_0.exec_psrp_script("hostname", use_local_scope=True)
    print("Test Result: %d" % rc)
    print("Test Result: %s" % stdout)
    print("Test Result: %s" % stderr)


# Generated at 2022-06-25 09:04:11.181121
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path = "in_path"
    out_path = "out_path"
    out_path = connection_0.put_file(in_path,out_path)
    print(out_path)


# Generated at 2022-06-25 09:04:16.861185
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_1 = Connection()
    f = tempfile.NamedTemporaryFile(delete=False)
    f.write(b"This is a temporary test file for testing put_file.")
    f.close()
    try:
        connection_1.put_file(f.name, f.name)
    except:
        os.unlink(f.name)
        raise
    os.unlink(f.name)


# Generated at 2022-06-25 09:04:25.382385
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    # command_0 = unicode()
    # sudoable_0 = bool()
    # in_data_0 = unicode()
    # stdin_1 = int()
    # stdout_1 = int()
    # stderr_1 = int()
    # start_1 = int()
    # exec_command(command_0, in_data_0, sudoable_0, stdin_1, stdout_1, stderr_1, start_1)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 09:04:30.587449
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from ansible.errors import AnsibleError

    if not pypsrp.FEATURES.winrm_configuration_name:
        return

    connect_host = '172.19.103.65'
    connect_user = 'vagrant'
    connect_pass = 'vagrant'
    connect_config_name = 'vagrant_winrm'
    certificate_key_pem = None
    certificate_pem = None


# Generated at 2022-06-25 09:04:35.255746
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Test using a mock Connection to test with
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:04:42.061014
# Unit test for constructor of class Connection
def test_Connection():
    try:
        connection_0 = Connection()
    except Exception as e:
        print(e)
        # print(e)
        # result = None
        # print(result)


if __name__ == '__main__':
    # test_case_0()
    test_Connection()

# Generated at 2022-06-25 09:04:45.309709
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path = None
    out_path = None
    file_args = None
    file_common_args = None
    connection_0.fetch_file(in_path, out_path, file_args, file_common_args)


# Generated at 2022-06-25 09:08:38.487436
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = 'test/fetch/source_file'
    out_path_0 = 'test/fetch/destination_file'
    try:
        connection_0.fetch_file(in_path_0, out_path_0)
    except Exception:
        pass


# Generated at 2022-06-25 09:08:40.128889
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:08:43.415027
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0=Connection()
    test_file_in_path = 'C:\\Users\\Public\\Documents\\test_file.txt'
    test_file_out_path = 'C:\\Users\\Public\\Documents\\test_file_out.txt'
    connection_0.fetch_file(test_file_in_path, test_file_out_path)


# Generated at 2022-06-25 09:08:44.911602
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:08:47.042813
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()


# Generated at 2022-06-25 09:08:52.977752
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    in_path = ''
    out_path = ''
    try:
        connection_0 = Connection()
        connection_0.put_file(in_path, out_path)
    except Exception as error:
        print(error)
        sys.exit(1)


# Generated at 2022-06-25 09:09:00.848536
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    script = """
$ErrorActionPreference = 'Stop';
$ProgressPreference = 'SilentlyContinue';
$VerbosePreference = 'Continue';
"""
    cmd = Connection.exec_command(connection_0, script, False)
    return cmd
