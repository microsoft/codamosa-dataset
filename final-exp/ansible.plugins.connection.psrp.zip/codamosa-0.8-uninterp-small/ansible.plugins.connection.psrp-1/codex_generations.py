

# Generated at 2022-06-25 08:59:46.106463
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()


# Generated at 2022-06-25 08:59:48.387556
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    #fetch_file(self, in_path, out_path, use_sudo=True, dir_mode=None, use_module=False):
    assert True == True


# Generated at 2022-06-25 08:59:54.534027
# Unit test for method reset of class Connection
def test_Connection_reset():
    int_0 = -3
    connection_0 = Connection()
    with pytest.raises(Exception):
        connection_0.reset()

    # TODO: fix this, it needs some more work to get it to work outside of tox
    # int_0 = -2
    # connection_0 = Connection()
    # with pytest.raises(Exception):
    #     connection_0.reset()

    # int_0 = -1
    # connection_0 = Connection()
    # with pytest.raises(Exception):
    #     connection_0.reset()

    # int_0 = 0
    # connection_0 = Connection()
    # with pytest.raises(Exception):
    #     connection_0.reset()


# Generated at 2022-06-25 08:59:57.439121
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    str_0 = 'nI_Z'
    int_0 = -268
    # class Connection
    connection_0 = Connection()

	# void fetch_file(str path, str dest, str src)
    connection_0.fetch_file(str_0, str_0, str_0)

if __name__ == '__main__':
    test_case_0()
    test_Connection_fetch_file()

# Generated at 2022-06-25 09:00:00.601341
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    int_0 = -417
    connection_0 = Connection()
    path_0 = 'C:/'
    connection_0.fetch_file(path_0, path_0)


# Generated at 2022-06-25 09:00:09.376962
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    int_0 = -417
    connection_0 = Connection()
    int_1 = -83
    input_data_0 = b'\x02'
    bool_0 = bool()
    list_0 = []
    # invoke test
    retval_0 = connection_0.exec_command(int_0, input_data_0, bool_0, list_0)


# Generated at 2022-06-25 09:00:10.664601
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:00:14.470994
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    int_0 = -417
    connection_0 = Connection()
    string_0 = connection_0.fetch_file(string_0, string_1)
    raw_0 = connection_0.fetch_file(raw_0, string_1)



# Generated at 2022-06-25 09:00:20.465340
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    int_0 = string_0 = string_1 = None
    connection_0 = Connection()
    in_path_0 = ''
    out_path_0 = ''
    tmpdir_0 = ''
    with pytest.raises(Exception):
        connection_0.fetch_file(in_path_0, out_path_0)


# Generated at 2022-06-25 09:00:26.063791
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup test case
    connection_0 = Connection()

    # Execute method on test object
    cmd_output_0 = connection_0.exec_command(commands=connection_0._psrp_script)

    # Verify results
    assert cmd_output_0 is None


# Generated at 2022-06-25 09:00:49.935561
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    test_case_0()


# Generated at 2022-06-25 09:00:51.044011
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:00:55.470132
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    int_0 = -619
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool

# Generated at 2022-06-25 09:00:56.563338
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_case_0()


# Generated at 2022-06-25 09:01:03.648165
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection()
    assert connection.__class__ == Connection
    assert connection.has_pipelining == True
    assert connection.become_method == 'runas'
    assert connection.become_username == 'Administrator'
    assert connection.allow_executable_pipeline == True
    assert connection.always_pipeline_modules == True
    assert connection._become_method == None
    assert connection._become_exe == None
    assert connection._become_user == 'Administrator'
    assert connection._shell_type == None
    assert connection._connected == False
    assert connection._closed == False
    assert connection._last_pipeline == None
    assert connection._psrp_connection_timeout == 10.0
    assert connection._psrp_read_timeout == None
    assert connection._psrp_certificate

# Generated at 2022-06-25 09:01:06.202561
# Unit test for constructor of class Connection
def test_Connection():
    connection_1 = Connection()
    assert connection_1 is not None
    return connection_1



# Generated at 2022-06-25 09:01:11.623130
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = ''
    out_path_0 = ''
    file_attributes_0 = None
    buffer_size_0 = 4096
    test_case_0()


# Generated at 2022-06-25 09:01:20.540198
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    b_in_path = b'in_path'
    b_out_path = b'out_path'
    tmp_file_2 = NamedTemporaryFile(delete=False)
    b_buffer_size = b'buffer_size'

    connection_0.runspace = RunspacePoolState.OPENED

    connection_0.fetch_file(b_in_path, b_out_path, buffer_size=tmp_file_2.name)

    connection_0.runspace.close()
    connection_0.runspace = None
    connection_0._connected = False
    connection_0._last_pipeline = None

    connection_0._build_kwargs()

    script_case_11 = read_script % 0

    input_data_11 = None

    use_local

# Generated at 2022-06-25 09:01:23.912347
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    conn_0.reset()


# Generated at 2022-06-25 09:01:30.061355
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    in_path_0 = "./unit_test_data/put_file_in_file_0.txt"
    out_path_0 = "./unit_test_data/put_file_out_file_0.txt"
    test_Connection = Connection()
    test_Connection.put_file(in_path_0, out_path_0)
    if test_Connection.test_flag == 0:
        print ("test_put_file test case 0:")
        print ("test_put_file failed\n")
    else:
        print ("test_put_file test case 0:")
        print ("test_put_file pass\n")


# Generated at 2022-06-25 09:02:15.299671
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Declare test parameters
    connection_0 = Connection()
    in_path = "//"
    out_path = "//"

    # Call test method
    connection_0.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:02:18.307950
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection('localhost')
    try:
        connection_0.reset()
    except:
        print('Failed to execute test for Connection::reset')


# Generated at 2022-06-25 09:02:25.502186
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    int_0 = 0
    connection_0 = Connection()
    int_0 = connection_0.put_file('test/put_test.txt', 'test/put_test.txt')

# Generated at 2022-06-25 09:02:30.575494
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create an instance of the Connection class
    # For the real implementation, the variable connection_0 will be of type Connection
    connection_0 = Connection()
    in_path = 'E:/Thesis/Ansible/psrp/win_ping_test.yml'
    out_path = 'E:/Thesis/Ansible/psrp/win_ping_test.yml'
    # Call fetch_file on class Connection
    connection_0.fetch_file(in_path, out_path)


# Generated at 2022-06-25 09:02:39.469782
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    test_file_0 = 'test_fetch_file.txt'   # Set this to a file on the host
    local_path_0 = '/tmp/test_fetch_file.txt'
    connection_0 = Connection()
    s = connection_0.exec_command('get-content ' + test_file_0, False)
    with open(local_path_0, 'w') as f:
        f.write(s)
    if os.path.isfile(local_path_0):
        print(to_native("fetch_file test passed."))
    else:
        print(to_native("fetch_file test failed."))

if __name__ == '__main__':
    test_case_0()
    test_Connection_fetch_file()

# Generated at 2022-06-25 09:02:40.938302
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    int_0 = Connection.exec_command("x$y&%z")


# Generated at 2022-06-25 09:02:51.182144
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = 'C:\\Users\\jsera\\AppData\\Local\\Temp\\ansible-tmp-1519026320.41-42528778634352\\setup_win_4.ps1'
    out_path_0 = 'C:\\Users\\jsera\\AppData\\Local\\Temp\\ansible-tmp-1519026320.41-42528778634352\\setup_win_4.ps1'
    check_mode_0 = False
    try:
        connection_0.fetch_file(in_path_0, out_path_0, check_mode_0)
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-25 09:03:00.207312
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    int_0 = 0
    str_0 = "V"
    connection_0 = Connection()
    path_0 = ""
    file_0 = mode_0 = None
    bool_0 = False
    path_1 = ""
    file_1 = mode_1 = None
    bool_1 = False
    bool_2 = bool_3 = bool_4 = bool_5 = bool_6 = bool_7 = bool_8 = bool_9 = bool_10 = bool_11 = bool_12 = bool_13 = bool_14 = bool_15 = bool_16 = bool_17 = bool_18 = bool_19 = bool_20 = False
    bool_21 = bool_22 = bool_23 = bool_24 = bool_25 = bool_26 = bool_27 = bool_28 = bool_29 = bool_30 = bool_31 = bool

# Generated at 2022-06-25 09:03:06.645810
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = "lT?"
    out_path_0 = "sNg"
    local_0 = False
    tmp_0 = '?Wy'
    result_0 = connection_0.fetch_file(in_path_0, out_path_0, local_0, tmp_0)
    assert result_0 is None


# Generated at 2022-06-25 09:03:08.200422
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:04:50.951211
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    int_0 = -417
    connection_0 = Connection()
    str_0 = connection_0.fetch_file(int_0)
    assert str_0 is not None


# Generated at 2022-06-25 09:05:00.106159
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    int_0 = 0
    str_1 = 'test_put_test.py'
    filename_0 = 'test_put_test.py'
    shell_0 = Shell()
    connection_0 = Connection(shell_0)
    put_strategy_0 = 'flat'
    str_2 = 'C:\\Users\\wesle\\Documents\\Ansible\\test_put_test.py'
    file_path_0 = 'C:\\Users\\wesle\\Documents\\Ansible\\test_put_test.py'
    bool_0 = True
    connection_0.put_file(put_strategy_0, file_path_0, filename_0, bool_0)
    int_1 = 0
    assert int_0 == int_1, 'Failed  test_Connection_put_file'


# Generated at 2022-06-25 09:05:09.691790
# Unit test for method close of class Connection
def test_Connection_close():
    ansible_0 = Mock()
    ansible_1 = Mock()
    ansible_2 = Mock()
    ansible_3 = Mock()
    ansible_4 = Mock()
    ansible_5 = Mock()
    ansible_6 = Mock()
    ansible_7 = Mock()
    ansible_8 = Mock()
    ansible_9 = Mock()
    ansible_10 = Mock()
    ansible_11 = Mock()
    ansible_12 = Mock()
    ansible_13 = Mock()
    ansible_14 = Mock()
    ansible_15 = Mock()
    ansible_16 = Mock()
    ansible_17 = Mock()
    ansible_18 = Mock()
    ansible_19 = Mock()
    ansible_20 = Mock()
    ansible_21 = Mock()
   

# Generated at 2022-06-25 09:05:18.326982
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    in_path_0 = './test_resources/test_file_0.txt'
    out_path_0 = './test_resources/test_file_1.txt'
    for i_0 in range(0, 100, 1):
        connection_0.put_file(in_path_0, out_path_0)
        connection_0.fetch_file(out_path_0, in_path_0)


# Generated at 2022-06-25 09:05:26.326394
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    with pytest.raises(AnsibleError) as err:
        int_0 = -417
        str_0 = "test_value"
        str_1 = "test_value"
        connection_0 = Connection()
        tofile_0 = connection_0.fetch_file(in_path=str_0, out_path=str_1)
    assert err.type == AnsibleError

# Generated at 2022-06-25 09:05:28.554573
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    int_0 = -417
    connection_0 = Connection()
    dest_0 = 'test_dest'
    src_0 = 'test_src'
    try:
        connection_0.put_file(dest_0, src_0)
    except Exception as e:
        display.error(e)


# Generated at 2022-06-25 09:05:32.608073
# Unit test for method reset of class Connection
def test_Connection_reset():
    int_0 = -417
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:05:45.264326
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    int_0 = -417
    connection_0 = Connection()
    tmp_path_0 = tempfile.gettempdir() + os.sep + 'tmpfile_0'
    tmp_path_1 = tempfile.gettempdir() + os.sep + 'tmpfile_1'
    try:
        os.remove(tmp_path_0)
    except:
        pass
    try:
        os.remove(tmp_path_1)
    except:
        pass
    with open(tmp_path_0, 'w') as file_0:
        file_0.write("abc")
    connection_0.put_file(in_path=tmp_path_0, out_path=tmp_path_1)

# Generated at 2022-06-25 09:05:51.188170
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    int_0 = -417
    connection_0 = Connection()
    tmp_dir_0 = None
    input_data_0 = 't'
    module_name_0 = 'ansible.modules.files.patch'
    try:
        with tempfile.TemporaryDirectory() as tmp_dir_0:
            with open(os.path.join(tmp_dir_0, 'test.txt'), 'w') as input_data_0:
                input_data_0.write('t')
                assert True
    except:
        pytest.fail('Unhandled exception raised while testing Connection.put_file')


# Generated at 2022-06-25 09:05:52.572420
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    file_0 = "abc"
    file_1 = "xyz"
