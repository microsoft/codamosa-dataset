

# Generated at 2022-06-25 08:59:41.253533
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    # This is test code for method put_file of class Connection


# Generated at 2022-06-25 08:59:49.769255
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    if psrp.FAILED_IMPORTS:
        pytest.skip("Failed imports on module load: %s"
                    % ', '.join(psrp.FAILED_IMPORTS))

    connection_1 = Connection()

    # Test the exec_command method of class Connection
    # call exec_command with arguments (command, use_unsafe_shell=False, encoding_errors=strict)
    command = "echo hello world"
    rc, stdout, stderr = connection_1.exec_command(command, use_unsafe_shell=False, encoding_errors='strict')
    assert rc == 0
    assert to_text(stdout) == "hello world"
    assert to_text(stderr) == ""


# Generated at 2022-06-25 08:59:53.231355
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    from unittest import TestLoader, TextTestRunner
    from ansible.module_utils.powershell import PSRPConnection

    connection = PSRPConnection()
    rc, stdout, stderr = connection.exec_command("echo hello, world")

    assert rc == 0
    assert stdout == u'hello, world\r\n'
    assert stderr == u''



# Generated at 2022-06-25 09:00:04.707409
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    file_name = "DummyFile.txt"
    file_content = b"Hello World!\n"
    file_remote_path = "/tmp/DummyFile.txt"
    connection_0._exec_psrp_script('echo "Hello World\n" > ' + file_remote_path)
    connection_0.put_file(file_name, file_content)
    # File comparison
    put_ok = filecmp.cmp(file_name, file_remote_path)
    if not put_ok:
        print(file_name + " != " + file_remote_path)
        raise AssertionError
    # Clean up
    os.remove(file_name)
    connection_0._exec_psrp_script('rm ' + file_remote_path)
    connection

# Generated at 2022-06-25 09:00:06.996607
# Unit test for method reset of class Connection
def test_Connection_reset():

    connection = Connection()
    connection.reset()


# Generated at 2022-06-25 09:00:14.676279
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_1 = Connection()
    module_1 = 'file.ps1'
    path_1 = module_1
    fail_key_1 = 'test_1'
    diff_1 = 'test_2'
    try:
        connection_1.fetch_file(module_1, path_1, fail_key_1, diff_1)
    except Exception as ex:
        display.display(str(ex), color="red")
        raise ex


# Generated at 2022-06-25 09:00:18.706981
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    print("To be implemented")


# Generated at 2022-06-25 09:00:29.617132
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
  connection_0 = Connection()
  rc, stdout, stderr = connection_0.exec_command('echo')
  if (rc != 0):
    if (stderr != ''):
      raise AssertionError('"' + stderr + '" does not equal ""')
  if (stdout != '\r\n'):
    raise AssertionError('"' + stdout + '" does not match regex /^\\r\\n$/')
  rc, stdout, stderr = connection_0.exec_command('echo', '', False, False)
  if (rc != 0):
    if (stderr != ''):
      raise AssertionError('"' + stderr + '" does not equal ""')

# Generated at 2022-06-25 09:00:34.507727
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.connected = True
    connection_0.runspace = RunspacePoolState.OPENED
    connection_0.reset()
    assert connection_0.connected == False


# Generated at 2022-06-25 09:00:41.638554
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Init configuration data
    config = {'user': 'username', 'password': 'supersecurepassword', 'port': 5986, 'protocol': 'https', 'server': 'localhost', 'auth': 'basic', 'cert_validation': False}
    # Create the connection option object
    options = {'remote_addr': config.get('server'),
               'remote_user': config.get('user'),
               'remote_password': config.get('password'),
               'port': config.get('port'),
               'protocol': config.get('protocol'),
               'auth': config.get('auth'),
               'cert_validation': config.get('cert_validation')}
    # Create the connection object
    conn = Connection(**options)
    # Create the connection information object

# Generated at 2022-06-25 09:01:07.192730
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    try:
        result = connection_0.put_file('in_path', 'out_path')
    except Exception as e:
        print(e)
    else:
        print(result)


# Generated at 2022-06-25 09:01:12.521805
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    tmpdir_0 = tempfile.mkdtemp(prefix='ansible-temp')
    filename_0 = os.path.join(tmpdir_0, 'psrp_test_put_file')
    with open(os.path.join(filename_0), 'w') as f_0:
        pass
    result_0 = connection_0.put_file(filename_0, '{temp}', tmpdir_0)
    assert os.path.exists(filename_0)
    shutil.rmtree(tmpdir_0)


# Generated at 2022-06-25 09:01:19.613199
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    display.display('test_Connection_exec_command()', color='green')
    connection_0 = Connection()
    cmd_0 = 'ls'
    # Verify that the execution of command cmd_0 on connection_0 is successful
    connection_0.exec_command(cmd_0)



# Generated at 2022-06-25 09:01:26.579846
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cmd = connection_0.exec_command('ipconfig')
    if (cmd[0] == 0):
        print("Connection.exec_command() - Success")
        return True
    else:
        print("Connection.exec_command() - Failed")
        return False


# Generated at 2022-06-25 09:01:29.841196
# Unit test for method close of class Connection
def test_Connection_close():
    connection_1 = Connection()
    connection_1.close()


# Generated at 2022-06-25 09:01:33.358215
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    #
    connection_0.close()


# Generated at 2022-06-25 09:01:41.180225
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.bufsize = 10
    connection.host = 'localhost'
    connection.keepalive = '10'
    connection.local_addr = '127.0.0.1'
    connection.network_os = 'windows'
    connection.password = 'vagrant'
    connection.port = '5986'
    connection.remote_addr = '192.168.50.4'
    connection.remote_user = 'vagrant'
    connection.remote_password = 'vagrant'
    connection.url = 'https://192.168.50.4:5986/wsman'
    connection.user = 'vagrant'
    connection._psrp_auth = 'basic'
    connection._psrp_connection_timeout = 30

# Generated at 2022-06-25 09:01:42.485084
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    result = connection_0.exec_command('cmd')
    assert len(result) == 3


# Generated at 2022-06-25 09:01:46.461136
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    assert connection_0 is not None
    result_0 = connection_0.exec_command('echo "foobar"')
    assert result_0 != None


# Generated at 2022-06-25 09:01:48.503791
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    connection_0.runspace = None
    source_path = 'path_1'
    remote_path = 'path_2'
    connection_0.fetch_file(source_path, remote_path)


# Generated at 2022-06-25 09:02:33.741618
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 09:02:35.075572
# Unit test for method close of class Connection
def test_Connection_close():
    connection_0 = Connection()
    connection_0.close()


# Generated at 2022-06-25 09:02:41.545334
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Test for required parameter local_path being str or unicode and that it
    # is a file that exists
    local_path = 'ansible/test/files/test_file_0'
    if isinstance(local_path,str) and os.path.isfile(local_path):
        connection_0 = Connection()
        assert connection_0.put_file(local_path= local_path, remote_path=None, preserve_mode=None, preserve_times=None, dir_mode=None, remote_filename=None)
    else:
        # Test was invalid
        assert False


# Generated at 2022-06-25 09:02:44.486194
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test object creation
    test_object = Connection()

    # Test functionality
    assert not test_object.exec_command('')


# Generated at 2022-06-25 09:02:48.787086
# Unit test for constructor of class Connection
def test_Connection():
    try:
        connection_0 = Connection(host='host_0', port=80, user='user_0', password='password_0',
                                  extra_args=None, use_ssl=False)
    except:
        return False
    return True


# Generated at 2022-06-25 09:02:53.141500
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    print ("\nTesting fetch_file\n")
    connection_0 = Connection()
    connection_0._build_kwargs()
    connection_0.connect()    
    connection_0.fetch_file("C:\\test_file.txt", "C:\\test_file2.txt")
    connection_0.close()


# Generated at 2022-06-25 09:02:58.181698
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cmd_0 = "cmd"
    use_persistent_connection_0 = False
    args_0 = None
    in_data_0 = None
    checkrc_0 = False
    close_connection_0 = False
    executable_0 = None
    encoding_0 = None
    environ_update_0 = None
    errors_0 = "surrogate_or_strict"
    stdin_0 = None
    stdout_0 = None
    stderr_0 = None

# Generated at 2022-06-25 09:03:01.608349
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    exception_caught = None
    try:
        connection_0.exec_psrp_script('Test-Path -LiteralPath "%s"' % '[LocalPath]')
    except Exception as exception_1:
        exception_caught = exception_1
    if exception_caught == None:
        raise Exception('expected exception not caught')


# Generated at 2022-06-25 09:03:03.292270
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.runspace = RunspacePool()
    connection_0.runspace.host = PSRPHost()
    connection_0.reset()

# Generated at 2022-06-25 09:03:14.413934
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    host = 'localhost'
    connection_0 = Connection()
    # The test file 'test_file_0.txt' is located in the directory of this unit test file
    source_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_file_0.txt')
    remote_path = 'C:\\Users\\ansible\\test_file_0.txt'
    print('Testing put_file method...')
    # We expect 4 bytes in the test file 'test_file_0.txt'
    print('Local file length: ' + str(len(open(source_path, 'r', encoding='utf-8').read())))

    connection_0.put_file(local_path=source_path, remote_path=remote_path)

# Generated at 2022-06-25 09:04:46.530213
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    connection_0.put_file()


# Generated at 2022-06-25 09:04:48.360919
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Inittialize test variables
    connection, in_path, out_path, tmp_path, executable, write_mode, console_encoding, strip_crs
    # Put test code here
    pass


# Generated at 2022-06-25 09:04:54.678483
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection_0 = Connection()
    cmd = "echo \"hello\""
    rc_0, stdout_0, stderr_0 = connection_0.exec_command(cmd)
    print(stdout_0)
    print(stderr_0)


# Generated at 2022-06-25 09:05:01.334614
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    print('Testing Connection.exec_command...')
    connection_1 = Connection()

    rc_expected = 1
    stdout_expected = b''
    stderr_expected = b'Unknown command: \'Fail\'\r\n    + CategoryInfo          : ObjectNotFound: (Fail:String) [], CommandNotFoundException\r\n    + FullyQualifiedErrorId : CommandNotFoundException\r\n'
    (rc, stdout, stderr) = connection_1.exec_command('Fail')
    assert rc == rc_expected, 'rc=%r' % (rc)
    assert stdout == stdout_expected, 'stdout=%r' % (stdout)
    assert stderr == stderr_expected, 'stderr=%r' % (stderr)

    rc_expected = 0
    std

# Generated at 2022-06-25 09:05:08.452192
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    # Case 1: File content is empty
    file_content = b''
    in_path = 'C:\temp\hello.txt'
    out_path = 'C:\temp\hello.txt'
    connection_0.put_file(in_path, out_path)
    # Case 2: File content is not empty
    file_content = b'Hello World'
    in_path = 'C:\temp\hello.txt'
    out_path = 'C:\temp\hello.txt'
    connection_0.put_file(in_path, out_path)



# Generated at 2022-06-25 09:05:09.182038
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_0 = Connection()
    connection_0.reset()


# Generated at 2022-06-25 09:05:10.525411
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection_0 = Connection()
    connection_0.fetch_file(PATH, REMOTE_PATH)


# Generated at 2022-06-25 09:05:17.906689
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_1 = Connection()
    b_in_path = to_bytes("test_in_path")
    b_out_path = to_bytes("test_out_path")
    with pytest.raises(AnsibleError):
        connection_1.put_file(b_in_path, b_out_path)


# Generated at 2022-06-25 09:05:22.894583
# Unit test for method put_file of class Connection
def test_Connection_put_file():

    connection_0 = Connection()
    # should pass
    connection_0.put_file()


# Generated at 2022-06-25 09:05:28.256642
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_0 = Connection()
    in_path_0 = 'in_path_0'
    out_path_0 = 'out_path_0'
    follow_0 = False
    try:
        connection_0.put_file(in_path_0, out_path_0, follow_0)
    except:
        raise Exception("Exception happened when test_Connection_put_file")

