

# Generated at 2022-06-11 13:58:09.920812
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # TODO: unit test
    pass



# Generated at 2022-06-11 13:58:20.444779
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import pytest
    from .mock_psrp_transport import MockPSRPTransport
    from .mock_psrp_client import MockPSRPClient
    from .mock_psrp_runspace import MockPSRPRunspace
    from .mock_psrp_host import MockPSRPHost
    from ansible.plugins.connection import ConnectionPsrp
    connection = ConnectionPsrp()
    connection._psrp_client = MockPSRPClient()
    transport = MockPSRPTransport()
    connection._psrp_host = MockPSRPHost(transport)
    connection.runspace = MockPSRPRunspace(connection._psrp_host)

# Generated at 2022-06-11 13:58:30.172296
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    command = "Write-Host 'Hello Ansible!'"
    result = connection.exec_command(command)
    assert result[0] == 0
    assert result[1] == ""
    assert result[2] == ""

# Sample command line execution of above test
# python -c "from test_psrp_connection import test_Connection_exec_command; test_Connection_exec_command()"
# python -c "import unittest; import test_psrp_connection; suite = unittest.TestSuite(); suite.addTest(test_psrp_connection.test_Connection_exec_command()); runner = unittest.TextTestRunner(verbosity=1); runner.run(suite)"


# Generated at 2022-06-11 13:58:39.385714
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    _test_Connection = Connection(play_context=None)
    _test_Connection.runspace = RunspacePool(None, None, None)
    _test_Connection.runspace.state = RunspacePoolState.OPEN

    _mock_open_file = MagicMock()
    _mock_open_file.read.return_value = b'blahblah'

# Generated at 2022-06-11 13:58:40.808403
# Unit test for method close of class Connection
def test_Connection_close():
    conn = Connection()
    conn.close()


# Generated at 2022-06-11 13:58:42.681085
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    """ test_Connection_put_file """
    pass

# Generated at 2022-06-11 13:58:49.749766
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    display.display = Mock()
    get_winrm_transport = Mock()
    get_winrm_transport.return_value = 'ntlm'
    get_psrp_transport = Mock()
    get_psrp_transport.return_value = 'ntlm'
    set_file_attributes = Mock()
    create_file = Mock()
    write_file = Mock()
    close_file = Mock()

    set_file_attributes.return_value = 0
    create_file.return_value = 'test-file-handle'
    write_file.return_value = True
    close_file.return_value = True

    from ansible.plugins.connection.winrm import Connection

    obj = Connection(play_context=dict(timeout=1))
    obj.set_file_attributes

# Generated at 2022-06-11 13:59:02.323828
# Unit test for method reset of class Connection

# Generated at 2022-06-11 13:59:12.824934
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from ansible.compat.six.moves import StringIO

    # Mock class for the Connection
    class MockConnection():
        def __init__(self):
            self.psrp_host = 'MOCK_PSRP_HOST'

# Generated at 2022-06-11 13:59:23.111971
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup Vars
    runspace_pool_state = "Started"
    psrp_host = b'192.0.2.0'
    psrp_protocol = "http"
    psrp_port = 80
    psrp_ignore_proxy = True
    psrp_path = "wsman"
    psrp_user = "testuser"
    psrp_pass = "testpass"
    psrp_auth = "testauth"
    psrp_cert_validation = True
    psrp_connection_timeout = 5
    psrp_message_encryption = True
    psrp_proxy = "localhost"
    psrp_operation_timeout = 10
    psrp_max_envelope_size = 10

# Generated at 2022-06-11 13:59:42.886170
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()



# Generated at 2022-06-11 13:59:45.508113
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    # Set up mock
    url = 'mock://localhost/wsman'
    mock_url = mock.Mock()
    mock_url.return_value = url
    connection = Connection(mock_url)

    # Invoke method
    result = connection.exec_command('cmd', 'arg1', 'arg2')

    # Check the result
    assert result is None

# Generated at 2022-06-11 13:59:51.936356
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    """
    Test if put_file() function of class Connection works well when:
    - the Destination exists
    - the Destination is a directory
    - the Destination doesn't exist
    - the Destination is in a non-existing directory
    """
    conn = Connection()
    conn.host_data = dict()
    conn.host_data["ansible_winrm_server_cert_validation"] = "ignore"
    conn.host_data["ansible_connection"] = "winrm"
    conn.host_data["ansible_port"] = 5986
    conn.host_data['ansible_winrm_read_timeout_sec'] = 3600
    conn.host_data["ansible_winrm_transport"] = ["ntlm"]
    conn.host_data["ansible_winrm_connection_timeout"] = "3600"

# Generated at 2022-06-11 13:59:54.705379
# Unit test for method reset of class Connection
def test_Connection_reset():
    con = Connection()
    con_reset = con.reset(None)
    assert con_reset is None

# Unit tests for method put_file of class Connection

# Generated at 2022-06-11 13:59:59.926408
# Unit test for method close of class Connection
def test_Connection_close():
    con = get_connection()
    assert con.runspace is not None
    assert con.runspace.state == RunspacePoolState.OPENED
    con.close()
    assert con.runspace is None
    assert con._connected is False
    assert con._last_pipeline is None


# Generated at 2022-06-11 14:00:08.739129
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Connection with str type argument
    connection = Connection('string')
    # TODO construct the argument required for put_file
    arg1 = True
    arg2 = False
    arg3 = 1
    arg4 = 'string'
    arg5 = dict()
    arg6 = list()
    arg7 = ['string']
    arg8 = {'bool': True, 'int': 1, 'dict': {}, 'list': [], 'string': 'string'}
    # put_file with the argument list
    connection.put_file(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)



# Generated at 2022-06-11 14:00:19.795083
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    # declare instance of Connection class
    connection = Connection()

    # mock the template
    template = ". '. {0}'; '{1}' '{2}' '{3}'"
    patcher = mock.patch('ansible.plugins.connection.psrp.Connection._build_script_path',
                         return_value='/tmp/ansible_psrp_payload_ejRxGz.ps1')
    patcher.start()
    patcher = mock.patch('ansible.plugins.connection.psrp.PSRP_COMMAND_PATH',
                         return_value='. {0}')
    patcher.start()
    patcher = mock.patch('ansible.plugins.connection.psrp.PSRP_PAYLOAD_PATH',
                         return_value='{1}')

# Generated at 2022-06-11 14:00:30.703577
# Unit test for method put_file of class Connection
def test_Connection_put_file():

    from ansible.errors import AnsibleError
    from ansible.plugins.connection import ConnectionBase

    connection = ConnectionBase(play_context=None, new_stdin=None)
    assert connection._psrp_protocol is None

    # Test error raised when no runspace is available
    connection._connected = False
    try:
        connection.put_file(in_path=None, out_path=None)
    except AnsibleError as e:
        assert 'psrp connection not opened' in e.message
    connection._connected = True

    # Test error raised when no in_path provided
    try:
        connection.put_file(in_path=None, out_path=None)
    except AnsibleError as e:
        assert 'invalid or undefined src' in e.message

# Generated at 2022-06-11 14:00:36.278927
# Unit test for method close of class Connection
def test_Connection_close():
    ansible_options = AnsibleOptions(connection='local', forks=10, become=None,
                           become_method=None, become_user=None, check=False, diff=False)
    ansible_play_context = PlayContext(play=None, options=ansible_options,
                                variable_manager=None, loader=None, passwords=dict(),
                                connection=None)
    ansible_connection = Connection(ansible_play_context)
    ansible_connection.close()

# Generated at 2022-06-11 14:00:37.231611
# Unit test for method close of class Connection
def test_Connection_close():
    pass


# Generated at 2022-06-11 14:01:20.678762
# Unit test for method close of class Connection
def test_Connection_close():
    host = '10.20.30.40'
    protocol = 'https'
    port = 5986
    username = 'test'
    password = 'pass'
    connection = Connection(
        host,
        port=port,
        username=username,
        password=password,
        transport='psrp',
        protocol=protocol,
    )
    try:
        connection.runspace = MagicMock()
        connection.runspace.close.side_effect = Exception
        connection.close()
    except Exception as ex:
        assert True is False, "unexpected exception %s" % str(ex)



# Generated at 2022-06-11 14:01:23.409099
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    pytest.skip("No known way to create a Windows machine for testing this. Note that documentation for this module is also missing")
    pass

# Generated at 2022-06-11 14:01:25.470319
# Unit test for method reset of class Connection
def test_Connection_reset():
    con = Connection('user', 'b')
    con.reset()

# Generated at 2022-06-11 14:01:34.605508
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    import tempfile
    import os, sys
    from pickle import dump, load, HIGHEST_PROTOCOL
    from ansible_collections.notstdlib.moveitallout.plugins.connection.psrp.psrp_connection import Connection
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.six import iteritems
    from ansible.utils.display import Display
    display = Display()
    host = Display()
    # Test exec_command
    # Test default use case
    psrp_host = 'test_psrp_host'
    hostname = 'test_hostname'
    self = Connection('user', 'password', 'port', 'path', 'proto', display, hostname)

# Generated at 2022-06-11 14:01:45.475066
# Unit test for method put_file of class Connection

# Generated at 2022-06-11 14:01:51.149592
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    tmpdir = tempfile.mkdtemp()
    # Test case 1
    result = Connection().fetch_file(src=tmpdir, dest=tmpdir, validate_checksum=True, flat=True)
    assert result == None

    result = Connection().fetch_file(src=tmpdir, dest=tmpdir, validate_checksum=False, flat=False)
    assert result == None


# Generated at 2022-06-11 14:01:52.445838
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
  fetch_file = Connection().fetch_file
  assert fetch_file


# Generated at 2022-06-11 14:02:00.458280
# Unit test for method close of class Connection
def test_Connection_close():
    from ansible.module_utils.common._collections_compat import UserDict
    from ansible.module_utils.psrp.pypsrp.tests.runspace_mock import RunspacePoolMock
    import pdb
    #pdb.set_trace()

    test_instance = Connection(UserDict())
  
    test_instance.runspace = RunspacePoolMock()
    test_instance._connected = True
    
    assert test_instance.runspace.state != RunspacePoolState.CLOSED

    test_instance.close()
    assert test_instance.runspace.state == RunspacePoolState.CLOSED
    assert test_instance._connected == False

# Generated at 2022-06-11 14:02:09.977529
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    result = Connection()
    c = Connection()
    host = "value"
    tgt = "value"
    file = "value"
    tgt_path = "value"
    set_remote_user = None
    set_host_variable = None
    follow = None
    _ansible_check_mode = None
    tmp = "value"
    tmp_path = "value"
    insert_char = None
    insert_count = None

# Generated at 2022-06-11 14:02:15.306024
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    command = "ls"
    stdin = ""
    stdin_add_newline = False
    executable = None
    in_data = None
    sudoable = False
    args = None
    parser = 'freebsd'
    response = connection.exec_command(command, stdin, stdin_add_newline, executable, in_data, sudoable, args, parser)
    assert(response.rc == 0)
    connection.close()


# Generated at 2022-06-11 14:03:37.952335
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Ensure the test is runnable
    try:
        import pypsrp
    except ImportError:
        raise SkipTest('pypsrp is not available')

    # Setup the test
    from ansible.utils.path import unfrackpath
    from ansible.plugins.connection.psrp import Connection
    conn = Connection(unfrackpath('./test/runner/'))
    conn._build_kwargs()
    conn._connected = True
    conn._psrp_host = 'notlocalhost'
    conn._psrp_user = 'notlocaluser'
    conn._psrp_pass = 'notlocalpass'

    import tempfile
    src_fd, src_path = tempfile.mkstemp()
    os.close(src_fd)
    os.remove(src_path)

# Generated at 2022-06-11 14:03:39.519967
# Unit test for method close of class Connection
def test_Connection_close():
	connection = get_mock_connection("Connection")
	connection.close()


# Generated at 2022-06-11 14:03:49.346398
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, "test.tmp")
    write_random_file(temp_path, 100)
    if not os.path.exists(temp_path):
        raise AnsibleError("Unable to create test file")
    #############################################################################
    #
    # Test 1: Create PSRP connection to target Windows host
    #
    #############################################################################
    try:
        os.remove('test_output.txt')
    except OSError:
        pass

    test_results = ('___TO BE FILLED IN BY TEST___', '___TO BE FILLED IN BY TEST___', '___TO BE FILLED IN BY TEST___')


# Generated at 2022-06-11 14:03:58.172251
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print("STARTING TEST: test_Connection_put_file")

    params = {
        'ansible_psrp_server': '192.168.28.129',
        'ansible_psrp_username': 'ansible',
        'ansible_psrp_password': 'Ansible@2',
        'ansible_winrm_server_cert_validation': 'ignore',
        'ansible_connection': 'psrp',
    }
    play_context = PlayContext()

    connection = Connection(play_context, params)
    connection._connected = True
    connection._psrp_host = "192.168.28.129"
    connection._psrp_protocol = "https"
    connection._psrp_cert_validation = False
    connection._psrp_path = ""


# Generated at 2022-06-11 14:04:00.127027
# Unit test for method close of class Connection
def test_Connection_close():
    ssh_connection = Connection(play_context=None)
    res = ssh_connection.close()
    assert res is None


# Generated at 2022-06-11 14:04:03.103199
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    filename = 'psrp-example.txt'
    data = 'This is a test'
    conn = Connection()
    conn.put_file(filename, data)


if __name__ == '__main__':
    test_Connection_put_file()

# Generated at 2022-06-11 14:04:13.429822
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    '''
    Unit test for method put_file of class Connection
    '''
    # Initialize the class
    put_file_instance = Connection()
    # The variable filename has a value of None
    filename = None 
    # The variable data has a value of None
    data = None 
    # The variable file_attributes has a value of None
    file_attributes = None 
    # The variable follow has a value of None
    follow = None 
    # The variable path has a value of None
    path = None 
    # The variable force has a value of None
    force = None 
    # The variable remote_follow has a value of None
    remote_follow = None 
    # invoke put_file with parameters filename, data, file_attributes, follow, path, force, remote_follow
    put_file_instance

# Generated at 2022-06-11 14:04:16.943628
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection()
    rc, out, err = conn.exec_command("Write-Output 'test_out'")
    assert rc == 0 
    assert out == b'test_out\n'
    assert err == b''

# Generated at 2022-06-11 14:04:23.923058
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-11 14:04:30.630035
# Unit test for method reset of class Connection
def test_Connection_reset():
    import random
    import time
    random.seed(time.time())
    a_Connection = Connection()
    a_Connection._connected = random.choice([True, False])
    a_Connection._play_context = random.choice([None, "random value"])
    a_Connection.close = MagicMock()
    a_Connection.close.return_value = None
    a_Connection.reset()
    assert a_Connection._connected == True
    assert a_Connection._play_context == None



# Generated at 2022-06-11 14:07:00.070238
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    test_name = inspect.currentframe().f_code.co_name
    msg = "Test case : {0}".format(test_name)
    print(msg)

    psrp_host = "test_hostname"
    psrp_user = "test_username"
    psrp_pass = "test_password"
    psrp_protocol = "https"
    psrp_port = 5986
    psrp_path = ""
    psrp_auth = "basic"
    psrp_cert_validation = True
    psrp_connection_timeout = 30
    psrp_read_timeout = 120
    psrp_message_encryption = "Always"
    psrp_proxy = None
    psrp_ignore_proxy = False
    psrp_operation_

# Generated at 2022-06-11 14:07:03.286436
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = psrp_connection.Connection('example.com', psrp_protocol, psrp_port, psrp_username, psrp_password)
    test_cmd = '/sbin/reboot'
    out = connection.exec_command(test_cmd)
    pprint(out)


# Generated at 2022-06-11 14:07:13.235979
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print('\nTesting Connection_put_file():\n')
    # ------------
    print('put a single file into remote server')
    conn = Connection('windows')
    conn._build_kwargs()
    conn._set_shell_type('powershell')
    conn.winrm = WinRM()
    conn.winrm._psrp_conn = None
    conn.winrm._get_transport()
    conn._connect()

    put_file = conn._put_file('/home/test', 'C:/Users/root/Desktop/test.txt')
    print('\nput_file: ', put_file)
    # ------------
    print('put multiple files into remote server')
    conn = Connection('windows')
    conn._build_kwargs()
    conn._set_shell_type('powershell')

# Generated at 2022-06-11 14:07:23.014470
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test the module with a local protocol
    connection = Connection(local_addr='localhost', local_port=5985, local_protocol='http')
    connection._play_context = PlayContext()
    connection._play_context.connection = 'local'
    connection._connected = True
    connection.protocol = 'local'
    connection._shell = "/usr/bin/powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -InputFormat Text -OutputFormat Text -Command-"
    connection._shell = shlex.split(connection._shell)
    connection._load_name_to_path_functions()
    connection._psrp_host = 'localhost'

    result = connection.exec_command("test")
    assert result.rc == 0
    assert 'test' in result.stdout.lower()

# Generated at 2022-06-11 14:07:24.395240
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.fetch_file()

# Generated at 2022-06-11 14:07:32.415558
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    import mock
    from ansible.utils.unicode import to_bytes

    connection = Connection(play_context=play_context)
    mock_runspace = mock.MagicMock()
    connection.runspace = mock_runspace

    my_shell_script = b"$test = 'hello world';"
    my_shell_script_base64 = base64.b64encode(my_shell_script)
    my_shell_script_base64_str = to_bytes(my_shell_script_base64.decode('utf-8'))
    mock_pipeline = mock.MagicMock()
    mock_pipeline.invoke.return_value = 0
    mock_runspace.execute_powershell.return_value = mock_pipeline

    mock_result = mock.MagicMock()
    expected_rc

# Generated at 2022-06-11 14:07:37.348538
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection(play_context=play_context)
    # Test with exception
    with pytest.raises(AnsibleConnectionFailure) as excinfo:
        connection.close()
    assert "Error closing runspace: " in str(excinfo.value)



# Generated at 2022-06-11 14:07:46.181159
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    psrp_conn = Connection(None)
    psrp_conn.host = Mock()
    psrp_conn._psrp_host = 'myhost'
    psrp_conn.host.mock_add_spec(Host)
    psrp_conn.host.ui.mock_add_spec(HostUI)
    psrp_conn.host.ui.stdout = ['1','2','3','4','5','6','7','8','9','10']
    psrp_conn.host.ui.stderr = []
    psrp_conn.host.rc = 0
    test_out_path = 'test_out.txt'
    test_in_path = 'test_in.txt'

# Generated at 2022-06-11 14:07:53.510292
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.errors import AnsibleError
    from ansible.plugins.connection import ConnectionBase
    from tempfile import NamedTemporaryFile
    from io import StringIO
    from mock import patch
    from pathlib import Path

    from ansible.plugins.connection.psrp import PUT_FILE_POWERSHELL, PUT_FILE_BUFFER_SIZE, REMOVE_FILE_SCRIPT

    connection = ConnectionBase(module=None)
    connection._exec_psrp_script = lambda command, input, use_local_scope, arguments: (0, '', '')
    connection._build_kwargs = lambda: None
    connection.close = lambda: None

    file_contents = "hello world!"
    in_file_path = NamedTemporaryFile().name
    out_file_path = NamedTemporaryFile().name
