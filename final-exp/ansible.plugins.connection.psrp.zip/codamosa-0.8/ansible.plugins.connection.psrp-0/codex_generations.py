

# Generated at 2022-06-11 13:58:09.918981
# Unit test for method reset of class Connection
def test_Connection_reset():
    c = Connection()
    assert c != None
    c.reset()



# Generated at 2022-06-11 13:58:12.393579
# Unit test for method close of class Connection
def test_Connection_close():
    """
    Test the close method of the Connection class.
    
    """
    # Close the psrp connection
    m = Connection()
    m.close()

# Generated at 2022-06-11 13:58:23.299339
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # build input parameter(s)
    task_vars = dict()
    task_vars['ansible_psrp_read_timeout'] = 123
    task_vars['ansible_psrp_connection_timeout'] = 123
    task_vars['ansible_psrp_operation_timeout'] = 123
    task_vars['ansible_psrp_server'] = '127.0.0.1'
    task_vars['ansible_psrp_port'] = 5986
    task_vars['ansible_psrp_username'] = 'Administrator'
    task_vars['ansible_psrp_path'] = 'wsman'
    task_vars['ansible_psrp_auth'] = 'CredSSP'

# Generated at 2022-06-11 13:58:28.582417
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    assert connection.put_file(in_path=None, out_path=None, in_data=None,
                               out_data=None, mode=None,
                               flags=None,
                               exec_command=None, in_data_second=None,
                               out_data_second=None) == None



# Generated at 2022-06-11 13:58:35.146297
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    import os, tempfile

    b_rand = os.urandom(20)
    f_rand = tempfile.NamedTemporaryFile(delete=False)
    f_rand.write(b_rand)
    f_rand.close()

    f_local = tempfile.NamedTemporaryFile(delete=False)
    f_local.close()

    c = Connection(None)
    c.put_file(f_rand.name, f_local.name)

    assert to_bytes(open(f_local.name, 'rb').read()) == b_rand

    os.remove(f_local.name)
    os.remove(f_rand.name)


# Generated at 2022-06-11 13:58:45.515040
# Unit test for method close of class Connection
def test_Connection_close():
    # Connection setup
    test_connection = get_connection("winrm")
    test_connection.set_options(direct={'remote_addr': 'dummy', 'remote_user': 'dummy', 'remote_password': 'dummy'})
    test_connection._task.args = dict()
    test_connection._task.args['_ansible_connection'] = 'winrm'
    test_connection._task.args['_ansible_winrm_server_cert_validation'] = None
    test_connection.set_task_uuid('test-uuid')
    test_connection.set_loader(get_loader('test'))
    test_connection.set_play_context(get_play_context())
    test_connection.terminate()

# Generated at 2022-06-11 13:58:55.829728
# Unit test for method put_file of class Connection
def test_Connection_put_file():
  psrp_host = 'localhost'
  psrp_user = 'Administrator'
  psrp_pass = 'password'
  psrp_protocol = 'http'
  psrp_port = 5985
  psrp_path = '/wsman'
  psrp_protocol = 'https'

  conn = Connection(psrp_host, psrp_user, psrp_pass, psrp_protocol, psrp_port, psrp_path)
  conn.connect()
  conn.put_file('test.py', 'C:\\Users\\Administrator\\test.py')
  conn.close()


# Generated at 2022-06-11 13:59:07.499521
# Unit test for method put_file of class Connection
def test_Connection_put_file():
   # This is just a sanity check, as the primary function of put_file is to use pypsrp
    module_args = dict(
        host='test_host',
        port='test_port',
        username='test_username',
        password='test_password',
        path='test_path',
        protocol='test_protocol',
        connection_timeout=None,
        read_timeout=None
    )
    test_instance = Connection(module_args)
    display.display = lambda x: None
    from ansible.errors import AnsibleError
    # sanity test to make sure put_file is calling to_bytes
    remote_path = 'data.txt'
    in_data = 'hello'
    in_path = os.path.join(C.DEFAULT_LOCAL_TMP,remote_path)

# Generated at 2022-06-11 13:59:17.461103
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    def get_conn():
        conn = Connection(play_context=play_context, new_stdin=None,
                          prompt_regex=None, start_job_event=None)
        # Connection._init_psrp is called by Connection.__init__ so we stub it
        # here as it automatically calls _connect()
        conn._init_psrp = MagicMock(return_value=None)
        conn.runspace = MagicMock()
        conn.runspace.state = 1
        conn._parse_pipeline_result = MagicMock(return_value=(0, '', ''))
        return conn

    conn = get_conn()

    conn.put_file(in_path='src_file', out_path='dst_file')

# Generated at 2022-06-11 13:59:20.451144
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # build module connection
    m = Connection()
    # make sure it needs the module_utils library
    assert m.module_utils == "psrp_helper"


# Generated at 2022-06-11 13:59:40.340953
# Unit test for constructor of class Connection
def test_Connection():
    connection_psrp = Connection(play_context=None)
    connection_psrp.close()


# Generated at 2022-06-11 13:59:48.954187
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # 
    m = mock.Mock()

    with mock.patch('ansible.plugins.connection.psrp.Connection') as mock_psrp:
        mock_psrp.return_value = m
        connection = Connection(None, 'psrp')
        m.psrp_host = '127.0.0.1'
        m.psrp_user = 'Administrator'
        m.psrp_pass = 'P@ssw0rd'
        m.psrp_protocol = 'http'
        m.psrp_port = '8080'

        connection.exec_command('command')

# Generated at 2022-06-11 14:00:00.337547
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
  """Test that the Connection class exec_command() method behaves as expected"""

# Generated at 2022-06-11 14:00:10.398986
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    host = "10.10.10.10"
    psrp_host = host
    psrp_user = 'administrator'
    psrp_pass = 'pass!@#$%^'
    
    transport = 'psrp'
    port = None
    connection = Connection(play_context=play_context, new_stdin=new_stdin)
    psrp_path = None
    
    
    psrp_protocol = None
    psrp_port = None
    psrp_auth = None
    psrp_cert_validation = None
    psrp_connection_timeout = None  # Can be None
    psrp_read_timeout = None  # Can be None
    psrp_message_encryption = None
    psrp_proxy = None 
    ps

# Generated at 2022-06-11 14:00:18.442121
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    mock_runspace = Mock(Runspace)
    mock_psrp = Connection()
    mock_psrp.runspace = mock_runspace
    mock_psrp._psrp_host = '1.2.3.4'
    mock_psrp._last_pipeline = None
    test_args = "this is a test"
    mock_psrp.exec_command(test_args)
    mock_psrp._exec_psrp_script.assert_called_with(test_args, None, True, None)

# Generated at 2022-06-11 14:00:26.814864
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection('psrp', play_context=PlayContext())
    if connection.runspace:
        if connection.runspace.state == RunspacePoolState.OPENED:
            display.vvvvv(u"PSRP CLOSE RUNSPACE: %s" % (connection.runspace.id),
                            host=connection._psrp_host)
            connection.runspace.close()
    connection.runspace = None
    connection._connected = False
    connection._last_pipeline = None
    print("connection:", connection)

# Generated at 2022-06-11 14:00:35.979568
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-11 14:00:45.558979
# Unit test for method exec_command of class Connection

# Generated at 2022-06-11 14:00:54.766867
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    args = dict(
        in_path=dict(),
        out_path=dict(),
        preserve_mode=dict(default=False),
        preserve_times=dict(default=False)
    )
    # Instantiate object
    pc = plugins.connection.psrp.Connection()
    # From Ansible 2.8, calling to_text is necessary for py3 when dealing with
    # text input. This is not necessary for Ansible 2.7 and below
    if six.PY3 and not HAVE_PYPSRP:
        pytest.skip('psrp is required to run tests on python3')
    pc.set_options(direct=args)
    # Source path to the file to fetch

# Generated at 2022-06-11 14:00:57.291621
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection()
    rc, stdout, stderr = conn.exec_command('test')
    # assert rc == 0
    # assert stdout == 0
    # assert stderr == 0


# Generated at 2022-06-11 14:01:26.454486
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    import os
    import base64
    from json import dumps
    from time import time
    
    s_file_name = os.path.basename(__file__)
    s_file_content = open(s_file_name, 'r').read()
    d_file_name = str(int(time())) + ".txt"
    
    o_connection = Connection()
    o_connection.put_file(d_file_name, dumps({'file': s_file_name}))    
    
    s_put_content = base64.b64decode(o_connection.get_file(d_file_name)['content'])
    b_result = s_put_content == s_file_content
    
    os.remove(d_file_name)
    
    return b_result

# Unit

# Generated at 2022-06-11 14:01:34.495866
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # my_connection is a psrp.Connection object
    my_connection = Connection(task_uuid="f41a4c58-aa0c-4ce8-8e06-f557729e5e5b")
    # in_path=None
    in_path = None
    # out_path=None
    out_path = None
    # file_args=None
    file_args = None
    # my_connection.fetch_file(in_path=in_path, out_path=out_path, file_args=file_args)
    my_connection.fetch_file(in_path=in_path, out_path=out_path, file_args=file_args)
    return

# Generated at 2022-06-11 14:01:35.500024
# Unit test for method put_file of class Connection
def test_Connection_put_file():

    pass


# Generated at 2022-06-11 14:01:46.366349
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection(None)
    b_output_path = to_bytes(os.path.join(os.path.dirname(__file__), 'fetch_file_test_output.txt'))

    # Test fetching a file that does not exist on the remote machine
    b_invalid_input_path = to_bytes(os.path.join(os.path.dirname(__file__), 'invalid_file.txt'))
    with pytest.raises(AnsibleError):
        connection.fetch_file(b_invalid_input_path, b_output_path)

    # Test fetching a file that does exist on the remote machine

# Generated at 2022-06-11 14:01:56.013537
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    """
    Test that the put_file method correctly handles the case where a retryable exception is raised
    :return: None
    """
    # To test this, we use a mock_executor which returns a retryable exception from its execute method

# Generated at 2022-06-11 14:02:06.028272
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test the exec_command method of the Connection class
    # Calling with a string, should return an array [0, "", ""]
    # Test with array of strings, should return an array [0, "", ""]
    # return an array [0, "", ""]
    # TODO: If a shell module, connect to a remote system for testing.
    # TODO: Test for shell module
    # TODO: Test for additional arguments
    module_class = getattr(Connection, "exec_command")
    module_class_type, module_class_method_type = inspect.getmodule(module_class), type(module_class)
    print(str(module_class_type) + " " + str(module_class_method_type) + " " + str(module_class))
    module_class_object = Connection()
    module

# Generated at 2022-06-11 14:02:14.906238
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connectionArgs = dict()
    connectionArgs['remote_addr'] = "remote_addr"
    connectionArgs['remote_user'] = "remote_user"
    connectionArgs['remote_password'] = "remote_password"
    connectionArgs['port'] = "port"
    connectionArgs['protocol'] = "protocol"
    connectionArgs['path'] = "path"
    connectionArgs['auth'] = "auth"
    connectionArgs['cert_validation'] = "cert_validation"
    connectionArgs['ca_cert'] = "ca_cert"
    connectionArgs['connection_timeout'] = "connection_timeout"
    connectionArgs['read_timeout'] = "read_timeout"
    connectionArgs['message_encryption'] = "message_encryption"
    connectionArgs['proxy'] = "proxy"

# Generated at 2022-06-11 14:02:24.272425
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Set up mock objects
    display = C()
    display.vvvvv = Mock(return_value=None)
    display.warning = Mock(return_value=None)
    f = C()
    f.write = Mock(return_value=None)
    m = C()
    m.attach_mock(display.vvvvv, 'display.vvvvv')
    m.attach_mock(display.warning, 'display.warning')
    m.attach_mock(f.write, 'f.write')
    m.attach_mock(base64.b64decode, 'base64.b64decode')
    cmd_exec_rc = 0
    cmd_exec_stdout = 'base64 data'
    cmd_exec_stderr = 'stderr'
    _exec_psrp_

# Generated at 2022-06-11 14:02:26.507111
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection_reset_obj = Connection()
    out, err = capsys.readouterr()
    assert out == "PSRP RESET\n"


# Generated at 2022-06-11 14:02:28.584274
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create instance and call method
    scon = Connection()
    scon.fetch_file()
    print("Run test finished")


# Generated at 2022-06-11 14:02:58.092025
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup
    p = mock.patch('ansible.plugins.connection.psrp.Connection.runspace_ready')
    m = p.start()
    m.return_value = False
    m2 = mock.Mock()
    m2.return_value = True
    m.side_effect = m2
    m.return_value = True
    
    
    p1 = mock.patch('ansible.plugins.connection.psrp.Connection.exec_psrp_ps_script')
    m3 = p1.start()
    m4 = mock.Mock()
    m4.return_value = True
    m3.side_effect = m4
    m3.return_value = True
    
    

# Generated at 2022-06-11 14:03:04.423083
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    playbook_path = 'test/integration/sanity/'
    with PyPsrpTestServer() as server:
        connection = Connection(playbook_path + 'test.yml')
        connection.protocol = 'http'
        connection.port = server.port
        connection.put_file(playbook_path + 'test.yml', '/test.yml')
        connection.close()

    with open(playbook_path + 'test.yml', 'r') as file_obj:
        assert server.content == file_obj.read()



# Generated at 2022-06-11 14:03:13.176495
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
  transport = psrp.psrp.Connection(None)
  transport._exec_psrp_script = Mock(return_value=(0, b'', b''))
  transport.runspace = Mock(**{
    'invoke_command.return_value': Mock(**{
      'stdout': ['test_data']
    })
  })

  with patch('os.path.isfile') as os_path_isfile:
    with patch('os.makedirs') as os_makedirs:
      os_path_isfile.return_value = True
      os_makedirs.return_value = None

      assert transport.fetch_file('in_path', 'out_path') is None

# Generated at 2022-06-11 14:03:16.604384
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    """
    Connection.put_file()
    """
    connection = Connection(play_context=play_context_mock)
    assert connection.put_file(in_path="/tmp/test_file", out_path="test_out_file") is None



# Generated at 2022-06-11 14:03:25.537695
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    """
    Test for the method put_file of class Connection
    """

    class TestAnsibleModule(object):
        class TestAnsibleModule(object):
            no_log = True

            class TestConnection(object):
                conn = None

                def __init__(self, *args, **kwargs):
                    self.conn = Connection(*args, **kwargs)

            def __init__(self, *args, **kwargs):
                self.connection = self.TestConnection

        def __init__(self, *args, **kwargs):
            self.ansible_module = self.TestAnsibleModule(*args, **kwargs)

    test_module = TestAnsibleModule()
    test_module.ansible_module.params = {'transport': 'psrp'}
    test_module.ansible_

# Generated at 2022-06-11 14:03:28.323269
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection(play_context=PlayContext())
    assert isinstance(connection, Connection)
    connection.close()
    assert connection.runspace is None
    assert not connection._connected

# Generated at 2022-06-11 14:03:29.486888
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = PSRPConnection()



# Generated at 2022-06-11 14:03:30.848266
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = psrp_connection(None)
    connection.reset()


# Generated at 2022-06-11 14:03:41.683894
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    import os

    conn = Connection(connection_info={
        'host': 'localhost',
        'port': 5986,
        'user': 'vagrant',
        'password': 'vagrant',
        'protocol': 'https',
        'path': '/wsman',
        'auth': 'basic',
    })
    conn.connect()
    conn.exec_command('hostname')
    conn.disconnect()
    assert True, 'Connection exec_command() works'

if __name__ == '__main__':
    import os
    import tempfile


# Generated at 2022-06-11 14:03:51.531070
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file(): 
    host = 'test'
    remote_user = 'test'
    remote_password = 'test'
    port = 5985
    protocol = 'http'
    psrp_path = '/wsman'
    psrp_auth = 'test'
    psrp_cert_validation = False
    psrp_connection_timeout = 60
    psrp_message_encryption = False
    psrp_proxy = None
    psrp_ignore_proxy = True
    psrp_operation_timeout = 30
    psrp_max_envelope_size = 153600
    psrp_certificate_key_pem = None
    psrp_certificate_pem = None
    psrp_credssp_auth_mechanism = 'test'
    psrp_c

# Generated at 2022-06-11 14:04:21.197097
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    c = Connection(psrp_connection_config='psrp_connection_config', new_stdin='new_stdin')
    c._psrp_host_raw = '_psrp_host_raw'
    c._build_kwargs = MagicMock()
    c._build_kwargs.return_value = '_build_kwargs_return_value'
    c.runspace = RunspacePool('runspace')
    c.runspace.state = RunspacePoolState.OPENED
    c._exec_psrp_script = MagicMock()
    c._exec_psrp_script.return_value = (0, '_exec_psrp_script_return_value', '_exec_psrp_script_return_value')
    in_path = 'in_path'
    out_

# Generated at 2022-06-11 14:04:22.414679
# Unit test for method close of class Connection
def test_Connection_close():
    pass

# Generated at 2022-06-11 14:04:32.577275
# Unit test for method put_file of class Connection

# Generated at 2022-06-11 14:04:38.152481
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()

    # construct expected output and actual output
    # fail, fail, fail, fail, fail, fail, fail, fail, fail, fail
    # fail, fail, fail, fail, fail, fail, fail, fail, fail, fail
    # fail, fail, fail, fail, fail, fail, fail, fail, fail, fail
    # fail, fail, fail, fail, fail, fail, fail, fail, fail, fail
    # fail, fail, fail, fail, fail, fail, fail, fail, fail, fail
    # fail, fail, fail, fail, fail, fail, fail, fail, fail, fail
    # fail, fail, fail, fail, fail, fail, fail, fail, fail, fail
    # fail, fail, fail, fail, fail, fail, fail, fail, fail, fail
    # fail, fail, fail,

# Generated at 2022-06-11 14:04:48.017559
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    fake_host = 'fake_host'
    fake_in_path = 'fake_in_path'
    fake_out_path = 'fake_out_path'
    fake_buffer_size = 10 
    fake_runspace = 'fake_runspace'
    fake_rc = 'fake_rc'
    fake_stdout = 'fake_stdout' 
    fake_stderr = 'fake_stderr'
    read_script = 'read_script'
    offset = 0

    # create instance of  class Connection
    parser = configparser.ConfigParser()
    # Read sample configuration file
    parser.read("./plugins/connection/psrp.yml")
    config_data = {}

# Generated at 2022-06-11 14:04:56.897866
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conn = Connection()
    ansible_options = Options()
    ansible_options.__dict__['psrp_port'] = 5985
    ansible_options.__dict__['psrp_protocol'] = 'http'
    ansible_options.__dict__['psrp_configuration_name'] = 'http://schemas.microsoft.com/powershell/Microsoft.PowerShell'
    ansible_options.__dict__['psrp_proxy'] = None
    ansible_options.__dict__['psrp_message_encryption'] = None
    ansible_options.__dict__['psrp_cert_validation'] = True
    ansible_options.__dict__['psrp_read_timeout'] = None
    ansible_options.__dict__['psrp_connection_timeout']

# Generated at 2022-06-11 14:05:05.858258
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    hosts_file = 'hosts'
    hosts = File(hosts_file)
    options = {}
    c = Connection(hosts, options)

    hosts_file_content = """
    [test_host]
    foo.bar.abc ansible_psrp_port=5986 ansible_connection=winrm
    """
    hosts_file_content = to_text(hosts_file_content)
    hosts.write(hosts_file_content)
    hosts.seek(0)


# Generated at 2022-06-11 14:05:11.979315
# Unit test for method reset of class Connection
def test_Connection_reset():
    """
    Test if reset() from class Connection runs successfully
    """
    try:
        # Setup test
        connection = Connection()

        # Execute code to be tested
        connection.reset(None, None)

    except Exception as e:
        print("An exception was thrown during Connection reset() function testing")
        print("Exception is: {0}".format(e))
        traceback.print_exc()
        assert False
    else:
        assert True



# Generated at 2022-06-11 14:05:12.823355
# Unit test for method reset of class Connection
def test_Connection_reset():
    pass

# Generated at 2022-06-11 14:05:17.694567
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection()

    assert conn.runspace is None
    assert not hasattr(conn, 'ps_conn')
    assert conn._connected is False

    conn.runspace = 'test'
    conn.ps_conn = 'test2'
    conn._connected = True

    conn.reset()

    assert conn.runspace is None
    assert not hasattr(conn, 'ps_conn')
    assert conn._connected is False



# Generated at 2022-06-11 14:05:45.010785
# Unit test for method put_file of class Connection
def test_Connection_put_file():

    # Params
    protocol = 'http'
    port = 5985
    path = '/wsman'
    server = 'server'
    username = 'username'
    password = 'password'
    ssl = False
    auth = 'plaintext'
    connection_timeout = 'PT60S'
    read_timeout = 'PT60S'
    operation_timeout = 'PT60S'
    max_envelope_size = 153600
    encoding = 'utf-8'
    configuration_name = ''
    cert_validation = 'ignore'
    proxy = None
    no_proxy = None
    reconnection_retries = 5
    reconnection_backoff = 1.0
    message_encryption = 'auto'
    certificate_key_pem = None
    certificate_pem = None
    credssp_auth

# Generated at 2022-06-11 14:05:53.330258
# Unit test for method put_file of class Connection

# Generated at 2022-06-11 14:06:00.385197
# Unit test for method put_file of class Connection
def test_Connection_put_file():
        mock_put_file_pypsrp_response = [b'', b'', 0]
        class MockConnection(Connection):
            def __init__(self):
                self._local_action = False
                self._connected = False
                self._shell = None
                self._play_context = None
                self._last_pipeline = None
                self.default_output = 'default'
                self.stdin = None
                self.stdout = None
                self.stderr = None
                self.terminated = False
                self.runspace = None

            def _exec_psrp_script(self, script, input_data=None, use_local_scope=True, arguments=None):
                return mock_put_file_pypsrp_response
        mock_connection = MockConnection()

# Generated at 2022-06-11 14:06:01.155225
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    assert exec_command() == 1

# Generated at 2022-06-11 14:06:03.878918
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    assert connection.close() is None

# Generated at 2022-06-11 14:06:05.086076
# Unit test for method reset of class Connection
def test_Connection_reset():
    # TODO: We need to update this code with test code later
    pass

# Generated at 2022-06-11 14:06:05.673876
# Unit test for method reset of class Connection
def test_Connection_reset():
    assert True

# Generated at 2022-06-11 14:06:11.328795
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """
    Above method is tested, by test_connection_class.py in testcases/connection folder

    This test is added, to handle code coverage
    """
    test_connection = Connection()
    test_connection.exec_command("dir", use_persistent_connection="False")
    test_connection.exec_command("dir", use_persistent_connection="True")
    test_connection.exec_command("dir")
    test_connection.exec_command("dir", sudoable=False)
    test_connection.exec_command("dir", sudoable=True)



# Generated at 2022-06-11 14:06:13.104730
# Unit test for method reset of class Connection
def test_Connection_reset():
    for testcase in test_cases_Connection_reset():
        yield testcase


# Generated at 2022-06-11 14:06:23.131012
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    in_path = 'in_path'
    out_path = 'out_path'
    sudoable = True
    connection._psrp_path = 'path'
    connection._psrp_host = 'host'
    connection._psrp_pass = 'pass'
    connection._psrp_port = 5986
    connection._psrp_protocol = 'protocol'
    connection._psrp_user = 'user'
    connection._psrp_cert_validation = None

    with patch.object(pypsrp.client.Client, 'download_file', return_value=None) as mock_download_file:
        connection.fetch_file(in_path, out_path, sudoable)

# Generated at 2022-06-11 14:07:02.716995
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection()
    assert conn is not None

# Generated at 2022-06-11 14:07:05.264422
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection(None, plugin_path='')
    connection.reset()
    if not connection.conn:
        print(False)
    else:
        print(True)


# Generated at 2022-06-11 14:07:13.284123
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    data = b'a' * 10
    test_file = 'test.txt'
    file_path = os.path.join(os.getcwd(), test_file)
    remote_file_path = 'c:\\test\\test.txt'
    connection = Connection('127.0.0.1')
    with open(file_path, 'wb') as f:
        f.write(data)

    connection.put_file(file_path, remote_file_path)
    assert os.path.isfile(file_path)
    os.remove(file_path)

# Generated at 2022-06-11 14:07:23.012765
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-11 14:07:26.366668
# Unit test for method close of class Connection
def test_Connection_close():
    m = mock_open()
    with patch.object(builtins, 'open', m, create=True):
        p = ansible.plugins.connection.psrp.Connection(play_context=dict())
        p.close()

# Generated at 2022-06-11 14:07:32.358003
# Unit test for method close of class Connection
def test_Connection_close():
    hostname = 'fake_hostname'
    psrp_conn = Connection(become_method='sudo', become_user='root', become_password='password', timeout=10, host=hostname, port=5985)
    setattr(psrp_conn, 'runspace', psrp_conn.connect())
    setattr(psrp_conn.runspace, 'state', RunspacePoolState.OPENED)
    # Call method under test
    psrp_conn.close()
    assert psrp_conn.runspace.state == RunspacePoolState.DISPOSED

# Test case for method Connect of class Connection


# Generated at 2022-06-11 14:07:42.669295
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    mock_loader = MagicMock()
    mock_display = MagicMock()
    mock_options = MagicMock()
    mock_shell = MagicMock()
    mock_executable = MagicMock()
    mock_put_file = MagicMock()
    mock_close = MagicMock()
    mock_become = MagicMock()
    mock_become_method = MagicMock()
    mock_become_user = MagicMock()
    mock_set_become_plugin = MagicMock()
    mock_psrp_host = MagicMock()
    mock_psrp_port = MagicMock()
    mock_psrp_user = MagicMock()
    mock_psrp_pass = MagicMock()
    mock_psrp_path = MagicMock()
    mock_ps