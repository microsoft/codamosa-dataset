

# Generated at 2022-06-11 13:58:07.411748
# Unit test for method close of class Connection
def test_Connection_close():
    conn = Connection()
    try:
        conn.close()
    except Exception:
        print("\nFAILED")
    else:
        print("\nSUCCESS")



# Generated at 2022-06-11 13:58:15.152099
# Unit test for method close of class Connection
def test_Connection_close():
    from ansible.plugins.connection import Connection
    from ansible.errors import AnsibleError
    import ansible.constants as C

    print("Initialize")
    connection = Connection()
    connection._build_kwargs = lambda: {
        'server': 'testserver',
        'port': '5986',
        'username': 'testuser',
        'password': 'testpass',
    }

    print("Close")
    connection.close()


if __name__ == '__main__':
    test_Connection_close()

# Generated at 2022-06-11 13:58:25.835110
# Unit test for method put_file of class Connection

# Generated at 2022-06-11 13:58:34.615899
# Unit test for method close of class Connection
def test_Connection_close():
    h = 'test host'
    u = 'test user'
    p = 'test pass'
    mp = 'test mock path'
    protocol = 'test protocol'
    port = 'test port'
    paths = 'test paths'
    auth = 'test auth'
    ca = 'test ca'
    ct = 'test ct'
    rt = 'test rt'
    me = 'test me'
    proxy = 'test proxy'
    ip = 'test ip'
    ot = 'test ot'
    me = 'test max envelope size'
    conf = 'test conf'
    kpem = 'test key pem'
    cpem = 'test cert pem'
    cme = 'test credssp auth mech'
    cdt = 'test credssp disable tlsv1.2'
    c

# Generated at 2022-06-11 13:58:39.905639
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    test_cases = [
        {
            'description': 'fetch_file should succeed',
            'input': {
            },
            'assert': {
            }
        }
    ]

    for test_case in test_cases:
        conn = Connection()
        result = conn.fetch_file()

        assert result == test_case['assert']

# Generated at 2022-06-11 13:58:43.034504
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-11 13:58:47.867716
# Unit test for method reset of class Connection
def test_Connection_reset():
    hostname = "example-host"
    username = "example-user"
    password = "example-password"
    psrp_connection = Connection(host=hostname, user=username, password=password)
    psrp_connection.reset()
    assert psrp_connection._psrp_host == hostname
    assert psrp_connection._psrp_user == username
    assert psrp_connection._psrp_pass == password

# Generated at 2022-06-11 13:59:00.511842
# Unit test for method reset of class Connection
def test_Connection_reset():
    """
    Test reset method of class Connection
    """
    connection = Connection(module_name='test_module')

    cmd = connection._build_module_command('test_module', 'init', {}, True, [])

# Generated at 2022-06-11 13:59:11.431065
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Initialize host/user/pass
    host = '127.0.0.1'
    user = 'admin'
    password = 'calvin'

    # Initialize local path of file to be fetched and destination to be fetched to
    in_path = '/tmp/testfile.txt'
    out_path = '/tmp/psrp-fetch.txt'

    # Set options to pass to _build_kwargs

# Generated at 2022-06-11 13:59:13.855323
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    if connection._connected:
        raise AssertionError("Should fail when connection not connected")

# Generated at 2022-06-11 13:59:46.047630
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Dummy AnsibleModule object
    module = AnsibleModule(argument_spec={})
    module.params = {}
    # Dummy inventory object
    inventory = InventoryManager(module)
    # Dummy connection options
    connection_options = {}

    # Instantiate connection plugin
    c = Connection(module, inventory, connection_options)

    src = 'test_file1'
    dest = 'test_file2'
    output_path = 'test_file3'
    c.fetch_file(src, dest)

    # Check if test_file2 has write permission
    assert os.access(dest, os.W_OK)
    # Check if test_file2 has data from test_file1
    with open(src, 'r') as src_file, open(dest, 'r') as dest_file:
        assert src_

# Generated at 2022-06-11 13:59:47.287181
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection(play_context=play_context)
    conn.reset()


# Generated at 2022-06-11 13:59:50.778814
# Unit test for method close of class Connection
def test_Connection_close():
    module = AnsibleModule(
        argument_spec = dict()
    )

    connection = Connection(module._socket_path)
    # Unit test for close method of class Connection
    # The method is called without arguments

    connection.close()

# Generated at 2022-06-11 13:59:53.746246
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    '''
    Unit test for method fetch_file of class Connection
    '''
    obj = Connection()
    obj.fetch_file('in_path', 'out_path')


# Generated at 2022-06-11 14:00:05.587387
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Setup the class for testing
    psrp_protocol = 'https'
    psrp_port = 5986
    psrp_host = '127.0.0.1'
    psrp_user = 'vagrant'
    psrp_pass = 'vagrant'
    psrp_path = 'wsman'
    psrp_auth = 'ntlm'
    psrp_cert_validation = True
    psrp_connection_timeout = None
    psrp_read_timeout = None
    psrp_message_encryption = 'always'
    psrp_proxy = None
    psrp_ignore_proxy = None
    psrp_operation_timeout = int(30)
    psrp_configuration_name = 'Microsoft.PowerShell'
    psrp

# Generated at 2022-06-11 14:00:13.430570
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    import os

    support_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'support')
    if not os.path.exists(support_dir):
        support_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', '..', 'test', 'support')
    script_path = os.path.join(support_dir, 'connection_psrp', 'psrp_wrapper.ps1')
    winrm_host = os.environ.get('WINRM_HOST')
    winrm_port = os.environ.get('WINRM_PORT')
    winrm_path = os.environ.get('WINRM_PATH')
   

# Generated at 2022-06-11 14:00:14.830426
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(play_context=PlayContext())
    assert connection is not None

# Generated at 2022-06-11 14:00:24.582153
# Unit test for method close of class Connection
def test_Connection_close():
    """
    Test if the close method of class Connection works properly.
    """
    ### If ansible_psrp_transport is winrm and ansible_connection is psrp
    # Initialize arguments
    p = Connection(winrm_transport = 'kerberos',
                   connection_type = 'winrm')

    # Try to call the close function of Connection
    try:
        p.close()
        # Pass the test if no Exception is thrown
        print("Test passed: close method of class Connection works properly.")
    except Exception as e:
        print("Test failed. Reason: " + str(e))

# Generated at 2022-06-11 14:00:34.181611
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup a basic task which we'll use the connection to run
    task = MockTask()
    task._task.args['_raw_params'] = '''$false'''

    # Setup a basic connection which we'll run the task on
    connection = MockConnection()
    connection._play_context.become = False

    # Execute the task
    result = connection.exec_command(task)

    # Make sure the result is what we expect
    assert result['rc'] == 0
    assert to_text(result['stdout']) == to_text(u'')
    assert to_text(result['stderr']) == to_text(u'')

    # Make sure the host command was what we expect
    assert connection._host.command == "$false"


# Generated at 2022-06-11 14:00:39.514119
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    # TEST CASE 1
    from ansible_collections.ansible.builtin.plugins.module_utils.psrp import PSRPConnection
    psrp_conn = PSRPConnection()
    psrp_conn.set_options(remote_addr='HOSTNAME')
    psrp_conn._exec_psrp_script = MagicMock(return_value=(0, '', ''))
    rc, stdout, stderr = psrp_conn.exec_command('COMMAND')

    assert rc == 0
    assert stdout == b''
    assert stderr == b''

# Generated at 2022-06-11 14:01:04.662363
# Unit test for method reset of class Connection
def test_Connection_reset():
    runspace = RunspacePool(connect())
    ps = PowerShell(runspace)
    ps.add_script("hostname")
    ps.invoke();

    ps.add_script("sleep 1")
    ps.invoke();
    ps.add_script("Write-Host \"After sleeping\"")
    ps.invoke();
    ps.add_script("Write-Host \"Second after sleeping\"")
    ps.invoke();
    
    
    
    
    runspace.close()   
    

# Generated at 2022-06-11 14:01:08.552998
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    """
    fetch_file(self, in_path, out_path):
    Fetches a file from local to remote.
    """
    # unit test in here
    c = Connection()
    c.fetch_file('in_path', 'out_path')


# Generated at 2022-06-11 14:01:13.325978
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    argspec = inspect.getargspec(Connection.fetch_file)
    assert argspec.args == ['self', 'in_path', 'out_path', 'use_sudo']
    assert argspec.varargs == None
    assert argspec.keywords == None
    assert argspec.defaults == (False,)

# Generated at 2022-06-11 14:01:20.756152
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    # Test for when the file is not present on the remote host
    with pytest.raises(AnsibleError, match=r".*Unable to find.*"):
        Connection = PSRP(play_context=None)
        Connection.fetch_file('test.txt', '/')

    # Test for when the file is present on the remote host
    with pytest.raises(AnsibleError, match=r".*Unable to find.*"):
        Connection = PSRP(play_context=None)
        Connection.fetch_file('/home/some_user/some_file.txt', '/')

# Generated at 2022-06-11 14:01:24.559825
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    my_ansible = AnsibleModule()
    my_conn = Connection(my_ansible)
    my_conn.put_file("abc.txt", "abc.txt")


# Generated at 2022-06-11 14:01:25.877020
# Unit test for method reset of class Connection
def test_Connection_reset():
    assert True


# Generated at 2022-06-11 14:01:27.256802
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()



# Generated at 2022-06-11 14:01:35.380733
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    class Mock_RunspacePoolState:
        def __init__(self):
            self.name = "OPENED"
    class Mock_PSInvocationState:
        def __init__(self):
            self.name = "NOT_STARTED"
    class Mock_PipelineState:
        def __init__(self):
            self.name = "NOT_STARTED"
    class Mock_RunspacePool:
        def __init__(self):
            self.state = Mock_RunspacePoolState()
            self.id = 1
    class Mock_PowerShell:
        def __init__(self):
            self.pipelines = [Mock_PowerShell]
            self.state = Mock_PSInvocationState()
        def add_script(self, script, use_local_scope = False):
            pass


# Generated at 2022-06-11 14:01:46.277923
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    runspacepool = mock.Mock()
    connection = Connection(runspacepool=runspacepool)
    connection._parse_pipeline_result = mock.Mock()
    connection._exec_psrp_script = mock.Mock(return_value=(0, u'', u''))

    rc, stdout, stderr = connection.exec_command('echo "Hello world"', sudoable=False)
    assert rc == 0
    assert stdout == ''
    assert stderr == ''
    runspacepool.assert_not_called()
    connection._parse_pipeline_result.assert_not_called()
    connection._exec_psrp_script.assert_called_with('echo "Hello world"', None, True, None)

    rc, stdout, stderr = connection

# Generated at 2022-06-11 14:01:47.961909
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    

# Generated at 2022-06-11 14:02:15.788164
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Python 2.7 usage of StringIO
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    # Python 3.4+ usage of StringIO
    try:
        from io import StringIO
    except ImportError:
        pass

    con1 = Connection()
    con1._play_context = Mock(spec_set=PlayContext)
    con1._play_context.verbosity = 0
    con1._connected = True
    
    con1.reset()
    assert not con1._connected



# Generated at 2022-06-11 14:02:25.414887
# Unit test for constructor of class Connection
def test_Connection():
    # Create args to build the connection
    args = {}
    args['connection'] = 'psrp'
    args['remote_addr'] = '127.0.0.1'
    args['remote_user'] = 'test_user'
    args['remote_password'] = 'test_password'
    args['port'] = 5985
    # Build the connection
    psrp_connection = Connection(**args)
    # Test the connection
    assert psrp_connection._psrp_protocol == 'http'
    assert psrp_connection._psrp_port == 5985
    assert psrp_connection._psrp_host == '127.0.0.1'
    assert psrp_connection._psrp_user == 'test_user'
    assert psrp_connection._psrp_pass

# Generated at 2022-06-11 14:02:27.860067
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection=Connection()
    connection._psrp_reconnect()
    connection.close()
    assert connection._connected==False
    assert connection.runspace==None

# Generated at 2022-06-11 14:02:37.568062
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Test dict to pass to argument --extra-vars of ansible-playbook
    extra_vars = dict()

    # Initialize the class
    psrp_connection = Connection(extra_vars)

    # Get the test data for arguments of method put_file of class Connection
    test_data = load_fixture('test_Connection_put_file_args.yaml')
    args = test_data['args']

    # Get the expected result for method put_file of class Connection
    expected_result = load_fixture('test_Connection_put_file_result.yaml')
    expected_result = expected_result['result']

    # Get the actual result of method put_file of class Connection
    actual_result = psrp_connection.put_file(
        **args
    )

    # Assert if the actual result

# Generated at 2022-06-11 14:02:46.558042
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    tmp_path = os.path.realpath('test')
    b_in_path = to_bytes(tmp_path)
    b_out_path = to_bytes(tmp_path)
    buffer_size = 32
    offset = 0
    data = base64.b64decode(tmp_path)
    out_file = open(tmp_path, 'wb')
    out_file.write(data)
    if len(data) < buffer_size:
        pass

    offset += len(data)
    rc = 0
    stdout = tmp_path
    stderr = tmp_path
    if rc != 0:
        raise AnsibleError("failed to transfer file to '%s': %s"
                           % (out_path, to_native(stderr)))

    rc, stdout, stderr = 0

# Generated at 2022-06-11 14:02:47.541847
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    pass


# Generated at 2022-06-11 14:02:57.111301
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    f = open('test_put_file.txt', 'r+')

    # These are the parameters passed to the put_file method of the Connection
    # class.
    in_path = 'test_put_file.txt'
    out_path = 'test_put_file.txt'
    # These are the parameters that the put_file method expects to receive
    # as properties of the 'transfer' parameter.
    transfer = {'buffered_size': 32768, 'acl_method': 'posix', 'local_size': 100, 'local_mode': 420,
                'local_mtime': 0, 'compress': False, 'remote_size': 0, 'local_path': 'test_put_file.txt',
                'remote_mode': 420, 'remote_path': out_path}
    # These are the parameters that the put

# Generated at 2022-06-11 14:03:06.143731
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    psrp_host = 'localhost'
    psrp_port = 5986
    psrp_user = 'ansible_test_user'
    psrp_password = 'ansible_test_password'
    psrp_auth = 'ntlm'
    psrp_protocol = 'https'
    psrp_ssl = True
    psrp_cert_validation = 'ignore'
    psrp_path = '/wsman'
    psrp_proxy = None
    psrp_ignore_proxy = False
    psrp_connection_timeout = 30
    psrp_read_timeout = 30
    psrp_max_envelope_size = 153600
    psrp_operation_timeout = 120
    psrp_configuration_name = ''
    psrp

# Generated at 2022-06-11 14:03:07.089932
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # untested...
    pass

# Generated at 2022-06-11 14:03:15.618484
# Unit test for method reset of class Connection
def test_Connection_reset():
    psrp_host = '127.0.0.1'
    psrp_user = 'test_user'
    psrp_pass = 'test_pass'
    psrp_port = 5986
    psrp_protocol = 'https'
    psrp_message_encryption = 'auto'
    psrp_cert_validation = 'ignore'
    psrp_operation_timeout = 30
    use_ssl = True
    psrp = None
    psrp_conn_kwargs = dict(connection_timeout=600,
                            read_timeout=600,
                            server_cert_validation='ignore',
                            operation_timeout=30,
                            configuration_name='Microsoft.PowerShell')
    psrp_conn_kwargs['server'] = psrp_host
   

# Generated at 2022-06-11 14:03:59.827757
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Connection is a subclass of object
    assert issubclass(Connection, object)

    # Connection is a subclass of ConnectionBase
    assert issubclass(Connection, ConnectionBase)
    print('Executed {0}'.format(inspect.currentframe().f_code.co_name))

# Generated at 2022-06-11 14:04:08.837323
# Unit test for method fetch_file of class Connection

# Generated at 2022-06-11 14:04:19.618169
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    mock_play_context = MagicMock()
    mock_new_stdin = MagicMock()
    mock_exec_psrp_script = MagicMock()

    connection = Connection(play_context=mock_play_context, new_stdin=mock_new_stdin,
                            exec_psrp_script=mock_exec_psrp_script)
    cmd = 'this is a command'
    in_data = 'this is in_data'
    stdin = 'this is stdin'

    connection.exec_command(cmd, in_data=in_data)
    mock_exec_psrp_script.assert_called_with(cmd, input_data=in_data, arguments=None)

    mock_exec_psrp_script.reset_mock()

# Generated at 2022-06-11 14:04:23.104962
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection._exec_psrp_script('test')
    connection.reset()
    assert connection._last_pipeline is None


# Generated at 2022-06-11 14:04:25.551001
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    cp = Connection()


if __name__ == '__main__':
    test_Connection_exec_command()

# Generated at 2022-06-11 14:04:34.399283
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # setup
    mocker = Mocker()
    mock_ctxt = MockContext.from_ansible_module(TestModule())
    mock_ans_module = mock_ctxt.ansible_module
    mock_ans_module.get_option = lambda x, y=None: None
    mock_ans_module.get_bin_path = lambda x: x
    mock_ans_module.fail_json = fail_json

    mock_ps_conn = mocker.mock()

    host_info = {}
    host_info['server'] = 'test_server'
    host_info['psrp_host'] = 'test_server'
    host_info['transport'] = 'psrp'
    host_info['port'] = 5986
    host_info['psrp_port'] = 5986
    host_

# Generated at 2022-06-11 14:04:44.221780
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conn = Connection('42.42.42.42')
    conn.runspace = Mock()
    conn.runspace.state = RunspacePoolState.OPENED
    conn._exec_psrp_script = Mock()
    conn._exec_psrp_script.return_value = 0, '42', '42'
    in_path = '/my/in/path'
    out_path = '/my/out/path'
    conn.put_file(in_path, out_path)
    # Check that exec_psrp_script has been called

# Generated at 2022-06-11 14:04:49.072780
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Init test environment
    delegate = CConnection()
    method = Connection.exec_command.__get__(delegate)

    # Add specific code for test executin here
    #
    # Call tested method
    retval = method(b'echo "Test command"')
    assert retval == (0, b'Test command\n', b'')

# Generated at 2022-06-11 14:04:58.099196
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection(play_context=PlayContext())
    connection_obj = Connection()
    def mock_get_option(option, value=None, boolean=None, integer=None, floating=None, secret=None):
        if option == 'remote_addr':
            return '127.0.0.1'
        elif option == 'port':
            return 9999
        elif option == 'remote_user':
            return 'user'
        elif option == 'private_key_file':
            return 'private_key_file'

    connection.get_option = mock_get_option
    connection_obj.get_option = mock_get_option
    connection.open()
    connection_obj.open()
    connection.close()
    connection_obj.close()

    # Test with valid args
    # Test case 1
    data

# Generated at 2022-06-11 14:05:07.207979
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.module_utils.psrp.psrp_client import Connection
    from ansible.module_utils.six import StringIO, BytesIO
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.psrp.psrp_client import PSRPError
    # Create a connection object
    connection = Connection('10.10.10.10', 'corp\\psrp_user', 'psrp_pass')
    # Get a file to transfer to the remote host
    tmp_path = tempfile.mkdtemp()
    fd, orig_filename = tempfile.mkstemp(dir=tmp_path)
    fd, dest_filename = tempfile.mkstemp(dir=tmp_path)
    fd, in_path = tempfile.mk

# Generated at 2022-06-11 14:06:34.732983
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    args = dict(
            in_path='file1',
            out_path='file2',
            use_ntlm_auth=False,
            preserve_psrp_client_certificate=False,
            **{'ansible_psrp_connection_timeout': 30, 'ansible_psrp_read_timeout': 30}
        )
    kwargs = dict()
    b_in_path = to_bytes('file1')
    b_out_path = to_bytes('file2')
    p = pypsrp_put_file(Connection, args=args, kwargs=kwargs)
    assert p.rc == 0

    # check the headers and data sent are ok
    p.rc = -1
    p.l_session = Mock()

# Generated at 2022-06-11 14:06:42.489037
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup test
    conn = Connection()
    conn._build_kwargs = mock.MagicMock()
    # Build inputs
    in_command = 'echo hi'
    in_in_data = 'Hello, world!'
    in_sudoable = True
    in_checkrc = True
    in_executable = None
    in_use_shell = False
    in_unbuffered = False
    # Set up mocked PSRP runspace
    conn.runspace = mock.MagicMock()
    conn.runspace.state = RunspacePoolState.OPENED
    conn._exec_psrp_script = mock.MagicMock()
    conn._exec_psrp_script.side_effect = lambda x, y, z, a: (0, 'Output', 'Stderr')
    # Call function
    rc, out

# Generated at 2022-06-11 14:06:47.175084
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    import mock
    class MyArgs():
        def __init__(self):
            self.hostvars = dict()
            self.hostvars['localhost'] = dict()
            self.hostvars['localhost']['ansible_psrp_password'] = 'password'
    
    with mock.patch('ansible.plugins.connection.psrp.Connection._build_kwargs') as build_kwargs,\
         mock.patch('ansible.plugins.connection.psrp.Connection._exec_psrp_script') as exec_psrp_script,\
         mock.patch('ansible.plugins.connection.psrp.Connection.close') as close:
        build_kwargs.return_value = None
        exec_psrp_script.return_value = (0, '', '')

# Generated at 2022-06-11 14:06:55.419778
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    try:
        import pypsrp
    except ImportError:
        pytest.skip("pypsrp is not installed")

    conn = Connection(PlayContext())
    conn._connected = True
    conn.put_file = MagicMock()
    conn.put_file.return_value = (0, None)
    in_path = 'c:/users/me/songs/hello.txt'
    out_path = '/home/me/songs/hello.txt'
    conn.put_file(in_path, out_path)
    conn.put_file.assert_called_with(in_path, out_path)


# Generated at 2022-06-11 14:07:02.966051
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # setup the mock configuration
    mock_connection_class_config = ConnectionClassConfig({
        'transport': 'psrp',
        'remote_addr': '127.0.0.1',
        'remote_user': 'Administrator',
        'remote_password': 'SuperS3cret',
    })
    mock_play_context = PlayContext()
    mock_loader = DictDataLoader({})

    # instantiate the object
    connection = Connection(mock_connection_class_config, mock_play_context, mock_loader)

    # call the method
    rc, stdout, stderr = connection.exec_command(command="echo hello")

    # check the results
    assert rc == 0
    assert stdout == b"hello\r\n"
    assert stderr == b""

    # cleanup
   

# Generated at 2022-06-11 14:07:07.503406
# Unit test for method reset of class Connection
def test_Connection_reset():
    mock_socket = Mock()
    mock_socket.connect = Mock()

    m = Connection()
    m._socket = mock_socket
    m._connected = True

    m._connected = True
    result = m.reset()

    assert result == None
    mock_socket.close.assert_called_once()
    mock_socket.connect.assert_called_once()


# Generated at 2022-06-11 14:07:13.874375
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """Unit test for method 'exec_command' of class 'Ssh' """

    # Attributes
    connection = Ssh()
    connection.ip = None
    connection.user = None
    connection.password = None

    # Make sure the result of exec_command is the expected one
    result = connection.exec_command('echo foo')
    assert result.rc == 0
    assert result.stdout == 'foo\n'
    assert result.stderr == ''


# Generated at 2022-06-11 14:07:19.010092
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    con = CloudFormation.Connection()
    address = "CloudFormation/sample/path"
    in_path = "CloudFormation/sample/path"
    out_path = "CloudFormation/sample/path"
    tmp = "CloudFormation/sample/path"
    buf = "CloudFormation/sample/path"
    con.put_file(in_path, out_path)


# Generated at 2022-06-11 14:07:23.904823
# Unit test for method close of class Connection
def test_Connection_close():
	import pytest
	import ansible_psrp

	# Test 1 (ensure_connection is true)
	obj = ansible_psrp.Connection()
	obj._connect()
	obj.close()

	# Test 2 (ensure_connection is false)
	obj = ansible_psrp.Connection()
	obj.close()


# Generated at 2022-06-11 14:07:32.070368
# Unit test for method close of class Connection