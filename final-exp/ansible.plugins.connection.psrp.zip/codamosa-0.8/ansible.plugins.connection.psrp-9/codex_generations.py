

# Generated at 2022-06-11 13:58:10.437731
# Unit test for method close of class Connection
def test_Connection_close():
    pass # TODO

# Generated at 2022-06-11 13:58:18.695145
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Pass
    c = Connection()
    c._psrp_host = "TEST_PSRP_ADDRESS"
    script = "$Data = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $PSComputerName;"\
             "$Data.ConvertToDateTime($Data.LastBootUpTime) | Out-String"
    conn = c._exec_psrp_script(script)
    assert conn[0] == 0
    assert isinstance(conn[1], six.binary_type)
    assert isinstance(conn[2], six.binary_type)


# Generated at 2022-06-11 13:58:21.544701
# Unit test for method close of class Connection
def test_Connection_close():
    # Check if the method close exists
    assert isinstance(Connection, object)
    assert hasattr(Connection, "close")
    assert callable(Connection.close)

# Generated at 2022-06-11 13:58:31.596568
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """Test method Connection.exec_command"""
    x1 = psrp.Connection('example.com')
    x2 = psrp.Connection('example.com', 'admin', 'password')
    x3 = psrp.Connection('example.com', 'admin', 'password', 5986)
    x4 = psrp.Connection('example.com', 'admin', 'password', 5986, '/wsman')
    x5 = psrp.Connection('example.com', 'admin', 'password', 5986, '/wsman', ['credssp', 'kerberos'])
    x6 = psrp.Connection('example.com', 'admin', 'password', 5986, '/wsman', ['credssp', 'kerberos'], 'ignore')

# Generated at 2022-06-11 13:58:37.710737
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    test_object = Connection()
    test_file = 'test.txt'
    test_path = 'test_path'
    test_content = 'test content'
    test_dict = {'src': test_file, 'dest': test_path, 'content': test_content}
    test_tmp = NamedTemporaryFile(delete=True)
    test_tmp.write(to_bytes(test_content))
    test_tmp.flush()
    test_tmp.seek(0)
    
    # Arrange
    test_object.host_input_file = MagicMock(return_value=test_tmp.name)
    test_object.find_file = MagicMock(return_value=test_tmp.name)
    
    # Act
    rc = test_object.put_file(test_dict)

    # Ass

# Generated at 2022-06-11 13:58:44.435078
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    conn = Connection(play_context={'verbosity': 5}, new_stdin=None)
    conn.psrp_version = '0.3.0'
    args = _PutFileCallbackArgs()
    conn.put_file(
            _in="C:\\Users\\vagrant\\AppData\\Local\\Temp\\tmpm9Gkae",
            out='/tmp/example',
            mode=None,
            tmp_path='',
            callback=args.callback)
    assert args.value == 0


# Generated at 2022-06-11 13:58:45.490918
# Unit test for method close of class Connection
def test_Connection_close():
    pass

# Generated at 2022-06-11 13:58:55.203782
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.errors import AnsibleFileNotFound
    from ansible.parsing.dataloader import DataLoader

    # initialize needed objects
    dl = DataLoader()
    conn = Connection(None, dl)

    # execute method call
    # TODO: currently throws AnsibleFileNotFound error.  Need to mock the file
    #       and continue to test this method
    try:
        conn.put_file("", "", "")
    except AnsibleFileNotFound as e:
        assert("File is not found" in str(e))

    # TODO: Need to test path/string encodings

# Generated at 2022-06-11 13:58:56.551519
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    assert False



# Generated at 2022-06-11 13:59:07.939855
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection._psrp_host = 'localhost'
    connection._psrp_user = 'Administrator'
    connection._psrp_pass = 'p@ssw0rd'
    connection._psrp_protocol = 'https'
    connection._psrp_port = 5986
    connection._psrp_path = '/wsman'
    connection._psrp_auth = 'kerberos'
    connection._psrp_cert_validation = True
    connection._psrp_connection_timeout = 30
    connection._psrp_read_timeout = None
    connection._psrp_message_encryption = True
    connection._psrp_proxy = None
    connection._psrp_ignore_proxy = False
    connection._psrp_operation_timeout = 30
    connection

# Generated at 2022-06-11 13:59:29.530724
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection._connected = True
    connection.reset()
    
    assert connection._connected == True

# Generated at 2022-06-11 13:59:37.973609
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Testing will require a test connection that has the following set in its
    # ansible.cfg
    # [ssh_connection]
    # ssh_args = -o ControlMaster=auto -o ControlPersist=60s -o IdentitiesOnly=yes -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no
    # pipelining = True

    # The connection needs to have a valid user and host so we can't use the
    # local connection here without hard coding a user and host.

    test_conn = Connection(
        ansible_host='localhost', ansible_user='username',
        ansible_password='password',
        module_name='test', load_attr='load_attr')

    in_path = "/home/username/test/test_connection_put_file.py"

# Generated at 2022-06-11 13:59:46.950230
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    """
    fetch_file generates runtime exception when runspace is None
    """

    connection = Connection()
    assert connection.runspace is None, "unable to fetch_file"

    in_path = "../playbooks/inventory/local/hosts"
    out_path = "../playbooks/inventory/local/hosts"

    try:
        connection.fetch_file(in_path, out_path)
        assert False, "This function should have failed"
    except Exception as exception:
        assert exception.args[0] == "No runspace available for commands.", exception.args[0]



# Generated at 2022-06-11 13:59:48.145227
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.fetch_file('a', 'b')

# Generated at 2022-06-11 13:59:49.733212
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.send_command("Get-Process", use_pipelining=True)

# Generated at 2022-06-11 14:00:01.283144
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    '''
    Unit test for:

    ansible.plugins.connection.psrp.Connection.put_file
    '''

    # set up
    # we use the [psrp] connection plugin, so we can write a
    # simple unit test.
    #
    # NOTE: the unit test is intended to be run local to the
    # development environment.
    #
    connection_plugin = Connection('psrp')

    # NOTE: psrp official documentation doesn't define the
    # ansible_psrp_* options.
    # So we will set it based on the source code function
    # Connection._build_kwargs.
    #
    # If a new psrp option is added, we update the following
    # options and run the unit test.

    # We use a test PSHost to capture the output.
   

# Generated at 2022-06-11 14:00:02.894641
# Unit test for method reset of class Connection
def test_Connection_reset():
    conn = Connection()
    conn.reset()


# Generated at 2022-06-11 14:00:08.857142
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """
    Test Connection.exec_command
    """
    print("Test exec_command")
    # Create a connection to test with
    connection = Connection()
    # Connection setup
    connection._build_kwargs = MagicMock(return_value=None)
    # Test the execution
    connection.exec_command("echo Hello World!")
    assert connection._exec_psrp_script.called


# Generated at 2022-06-11 14:00:20.025991
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # set up the object
    conn = Connection()
    conn.runspace = MockRunspace(None, "test runspace", None)
    conn.runspace.session = MockPSSession(conn.runspace)
    conn.runspace.session.invoke_return_error_stream = False
    conn.runspace.session.invoke_return_output_stream = [b"0x01"]

    kwargs={}
    kwargs['_psrp_conn_kwargs'] = MockPSRPConnectionKwargs()
    conn._psrp_conn_kwargs = kwargs['_psrp_conn_kwargs']
    conn._psrp_conn_kwargs.server = 'server'
    conn._psrp_conn_kwargs.port = 5986

# Generated at 2022-06-11 14:00:31.008457
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    # Testcase 1: Test exec_command of class Connection
    # Make sure to set up the psrp_client connection properly
    psrp_client = psrp_client.PSRPClient(psrp_protocol="http",
                                         server="",
                                         remote_path="/wsman",
                                         port=5985,
                                         username="",
                                         password="",
                                         cert_validation=False,
                                         connection_timeout=None)
    test_Connection_exec_command_result = Connection(psrp_client).exec_command("dir")
    assert test_Connection_exec_command_result.rc == 0
    assert b"File(s)..." in test_Connection_exec_command_result.stdout
    assert test_Connection_exec_command_result.stderr == b""

# Unit

# Generated at 2022-06-11 14:01:17.621586
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    host = "test-host"
    user = "test-user"
    password = "test-password"
    local_addr = "test-local_addr"
    connection = Connection(host, user, password, local_addr)
    cmd = "test-cmd"
    tmpout_path = "test-tmpout_path"
    tmperr_path = "test-tmperr_path"
    in_data = "test-in_data"
    sudoable = "test-sudoable"
    executable = "test-executable"
    timing = "test-timing"
    su = "test-su"
    su_user = "test-su_user"
    su_pass = "test-su_pass"
    terminal = "test-terminal"
    success_key = "test-success_key"

# Generated at 2022-06-11 14:01:19.670017
# Unit test for method close of class Connection
def test_Connection_close():
    """
    Test close method of class Connection
    """
    con = Connection()
    con.close()
    assert True


# Generated at 2022-06-11 14:01:31.015732
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    cls = Connection
    import ansible.plugins.connection.psrp
    import ansible.plugins.connection.psrp.executor
    import ansible.plugins.connection.ssh
    import ansible.plugins.connection.ssh.executor

    cmd = 'echo "hello"'
    in_data = 'hello world'
    sudoable = True
    tmp_path = 't/'


    class MockRunspacePool(object):
        def __init__(self, *args, **kwargs):
            pass
        def close(self):
            pass


    class MockPlayContext(object):
        def __init__(self, tmp_path, connection):
            self.remote_addr = '127.0.0.1'
            self.port = 22
            self.remote_user = 'test_user'
            self

# Generated at 2022-06-11 14:01:33.747146
# Unit test for method reset of class Connection
def test_Connection_reset():
    C = Connection()
    # Default channelbox
    channelbox = None
    # Call method.
    C.reset(channelbox)
    # Call method.
    channelbox = 'foo'
    C.reset(channelbox)

# Generated at 2022-06-11 14:01:34.954685
# Unit test for method reset of class Connection
def test_Connection_reset():
    assert True


# Generated at 2022-06-11 14:01:45.832374
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection(play_context=PlayContext())
    connection.reset(None)
    assert 'http://localhost:5985' == connection._psrp_host;
    assert 'vagrant' == connection._psrp_user;
    assert 'vagrant' == connection._psrp_pass;
    assert 'http' == connection._psrp_protocol;
    assert 5985 == connection._psrp_port;
    assert True == connection._psrp_cert_validation;
    assert None == connection._psrp_connection_timeout;
    assert None == connection._psrp_read_timeout;
    assert None == connection._psrp_path;
    assert None == connection._psrp_auth;
    assert None == connection._psrp_proxy;
    assert False == connection._psrp_ignore

# Generated at 2022-06-11 14:01:55.504941
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    path = "test_path.txt"
    out_path = "test_path.txt"
    file_args = {}
    force = False


    # 1.
    # Call to fetch_file with the following parameters
    # path = "test_path.txt"
    # out_path = "test_path.txt"
    # file_args = {}
    # force = False
    #
    # Return code:
    # -1
    #
    # Return message:
    # "Cannot fetch file: no remote_addr available"
    #
    # Comment:
    # We call fetch_file with an invalid path, so the return code must be -1
    # and the return message must be : "Cannot fetch file: no remote_addr available"
    # We call the method get_option("

# Generated at 2022-06-11 14:02:05.505102
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from ansible.plugins.connection.psrp import Connection
    from ansible.errors import AnsibleError
    from ansible.mock import patch

    def test(mock_runspace, mock_powershell, mock_pipeline, mock_file, mock_open):
        mock_runspace.state = RunspacePoolState.OPENED
        mock_runspace.id = 'id'

        mock_powershell.return_value = mock_pipeline
        mock_pipeline.invoke.return_value = True

        c = Connection(play_context=mock.DEFAULT)
        c.runspace = mock_runspace
        c.host = mock.Mock()
        c.host.rc = 0
        c.host.ui.stdout = []
        c.host.ui.stderr = []
       

# Generated at 2022-06-11 14:02:14.509923
# Unit test for method exec_command of class Connection

# Generated at 2022-06-11 14:02:20.650000
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    
    file_to_upload = 'c:\\windows\\system32\\windowspowershell\\v1.0\\powershell.exe'
    destination_path = 'C:\\Windows\\Temp\\powershell.exe'
        
    ps_conn = psrp_connection()
    #ps_conn.connect(bastion_host, bastion_user, bastion_password)
    ps_conn.put_file(file_to_upload, destination_path)
    
    #ps_conn.close()
    

# Generated at 2022-06-11 14:03:37.953099
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():

    from pytest import raises

    remote_addr = 'remote_addr'
    remote_user = 'remote_user'
    remote_password = 'remote_password'
    protocol = 'protocol'
    port = 'port'
    path = 'path'
    auth = 'auth'
    cert_validation = 'cert_validation'
    ca_cert = 'ca_cert'
    connection_timeout = 'connection_timeout'
    read_timeout = 'read_timeout'
    message_encryption = 'message_encryption'
    proxy = 'proxy'
    ignore_proxy = 'ignore_proxy'
    operation_timeout = 'operation_timeout'
    max_envelope_size = 'max_envelope_size'
    configuration_name = 'configuration_name'

# Generated at 2022-06-11 14:03:47.264706
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Make sure that fetch_file accepts the 'use_powershell' param
    # and will set the mode accordingly.
    conn = Connection(
        module_name='win_ping'
    )

    # Setup the common mocks
    conn.runspace = MagicMock()
    conn.runspace.id = '1111'
    conn.runspace.state = RunspacePoolState.OPENED
    conn.runspace.session = MagicMock()
    conn.runspace.session.protocol_version = '2.3'
    conn.runspace.session.transport = 'https'
    conn.runspace.session.server = 'localhost'
    conn.runspace.session.port = 5986
    conn.runspace.session.configuration_name = 'Microsoft.PowerShell'
    conn.runspace.session.cred

# Generated at 2022-06-11 14:03:56.628703
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    host = 'localhost'
    port = 5985
    user = 'Administrator'
    passwd = 'Passw0rd!'
    protocol = 'http'
    path = None
    connection_timeout = 30
    read_timeout = None
    message_encryption = 'auto'
    auth = 'negotiate'
    cert_validation = True
    proxy = None
    ignore_proxy = False
    operation_timeout = 30
    max_envelope_size = 153600
    configuration_name = None
    certificate_key_pem = None
    certificate_pem = None
    credssp_auth_mechanism = 'auto'
    credssp_disable_tlsv1_2 = False
    credssp_minimum_version = None
    negotiate_send_cbt = False
    negotiate_delegate

# Generated at 2022-06-11 14:04:01.940905
# Unit test for method close of class Connection
def test_Connection_close():
    # setup
    psrp_module_obj = psrp_module.PSRPModule(
        connection=Connection(module=None), module_args={}, task_vars={}
    )


    ########################################################################
    # verify True if the connection is connected
    ########################################################################
    psrp_module_obj.connection._connected = True

    psrp_module_obj.connection.close()

    assert psrp_module_obj.connection._connected is False

# Generated at 2022-06-11 14:04:07.991189
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    print("Test Started: test_Connection_put_file")
    cmdp=subprocess.Popen(['python', '-m', 'pytest', '-v', 'C:\\Users\\msefe\\PycharmProjects\\FosstrakPythonClient\\psrp\\connection.py::test_Connection_put_file'])
    cmdp.wait()
    assert cmdp.returncode == 0
    print("Test Ended: test_Connection_put_file")


# Generated at 2022-06-11 14:04:18.526931
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import xml.etree.ElementTree as et
    _exec_psrp_script = Connection._exec_psrp_script
    def _exec_psrp_script_fake(script, input_data=None, use_local_scope=True, arguments=None):
        with open('Connection_fetch_file_script.txt', 'w') as out_file:
            out_file.write(script)
        rc = 0
        stdout = b''
        stderr = b''
        return rc, stdout, stderr

    def _parse_pipeline_result_fake(pipeline):
        rc = 0
        stdout = ''
        stderr = ''
        return rc, stdout, stderr

    Connection._exec_psrp_script = _exec_psrp_script_fake

# Generated at 2022-06-11 14:04:21.194941
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection(play_context=dict2obj({u'check_mode': False,
                                                   u'verbosity': 0}), new_stdin=None)
    assert connection



# Generated at 2022-06-11 14:04:32.170580
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(None)

    assert connection.host is None
    assert connection.connected is False
    assert connection._last_pipeline is None
    assert connection.ps1_base is None
    assert connection.protocol is None
    assert connection.shell_id is None
    assert connection.shell is None
    assert connection.delegate is None
    assert connection.runspace is None
    assert connection._psrp_host is None
    assert connection._psrp_port is None
    assert connection._psrp_user is None
    assert connection._psrp_pass is None
    assert connection._psrp_protocol is None
    assert connection._psrp_path is None
    assert connection._psrp_auth is None
    assert connection._psrp_cert_validation is None
    assert connection._psrp

# Generated at 2022-06-11 14:04:35.231493
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Setup test environment with a mock of the connection.
    mock_connection = MockConnection()
    mock_connection.put_file("in_path", "out_path", "remote_path", "user", "pass")
    assert mock_connection.invoked_methods.count("put_file") == 1



# Generated at 2022-06-11 14:04:44.912076
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    psrp_host = 'host'
    psrp_user = 'user'
    psrp_pass = 'pass'
    psrp_protocol = 'https'
    psrp_cert_validation = 'ignore'
    psrp_port = 5986
    psrp_path = '/wsman'
    psrp_auth = 'basic'
    psrp_connection_timeout = 5
    psrp_read_timeout = None
    psrp_message_encryption = 'never'
    psrp_proxy = None
    psrp_ignore_proxy = True
    psrp_operation_timeout = 5
    psrp_max_envelope_size = 153600
    psrp_configuration_name = 'Microsoft.PowerShell'
    psrp_re

# Generated at 2022-06-11 14:07:09.705642
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    assert connection.fetch_file(local_file, remote_file) == (None, None)

# Generated at 2022-06-11 14:07:19.589909
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection()

    assert connection is not None
    assert connection._psrp_host is None
    assert connection._psrp_user is None
    assert connection._psrp_pass is None
    assert connection._psrp_port == 5985
    assert connection._psrp_protocol == 'https'
    assert connection._psrp_path is None
    assert connection._psrp_auth is None
    assert connection._psrp_cert_validation is None
    assert connection._psrp_connection_timeout is None
    assert connection._psrp_read_timeout is None
    assert connection._psrp_message_encryption is None
    assert connection._psrp_proxy is None
    assert connection._psrp_ignore_proxy is None
    assert connection._psrp_operation_timeout == 30


# Generated at 2022-06-11 14:07:24.475560
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.runspace = runspace
    
    assert getattr(connection, 'runspace') is runspace
    
    connection.runspace.close = MagicMock()
    connection.close()
    connection.runspace.close.assert_called_once_with()
    assert getattr(connection, 'runspace') is None
    

# Generated at 2022-06-11 14:07:32.469503
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import zipfile

    host = "127.0.0.1"
    user = "vagrant"
    password = "vagrant"
    transport = "winrm"
    port = 5985
    connection = Connection(host, user, password, transport, port)
    connection._build_kwargs()
    try:
        connection.connect()
    except Exception as ex:
        print("Exception: {}".format(ex))

    # Fetch a file from Windows host to local machine, then check if the file has been successfully fetched.
    in_path = "C:/Windows/System32/calc.exe"
    out_path = "C:/Users/Public/Downloads/calc.exe"
    connection.fetch_file(in_path, out_path)
    assert os.path.isfile(out_path)
   

# Generated at 2022-06-11 14:07:42.832769
# Unit test for method put_file of class Connection
def test_Connection_put_file():

    # Set up mock
    url = mock.MagicMock()
    shell_id = mock.MagicMock()
    command_id = mock.MagicMock()
    in_path = mock.MagicMock()
    out_path = mock.MagicMock()
    actual_path = mock.MagicMock()
    transfer_encoding = mock.MagicMock()
    buffer_size = mock.MagicMock()
    follow = mock.MagicMock()
    use_ntlm_auth = mock.MagicMock()
    transport_decorator = mock.MagicMock()
    args = (actual_path, out_path, use_ntlm_auth)

# Generated at 2022-06-11 14:07:44.079378
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    Connection('http://localhost:5986')
    pass
