

# Generated at 2022-06-11 13:58:11.712414
# Unit test for method reset of class Connection
def test_Connection_reset():
    '''
    Unit test for method reset of class Connection
    '''
    connection = Connection(play_context=play_context)
    assert not connection.reset()


# Generated at 2022-06-11 13:58:22.519853
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection()
    conn._psrp_host = 'host'
    conn._psrp_user = 'user'
    conn._psrp_pass = 'pass'

    conn._psrp_path = "/wsman"
    conn._psrp_auth = "CredSSP"
    conn._psrp_cert_validation = True
    conn._psrp_operation_timeout = 15
    conn._psrp_message_encryption = "Auto"
    conn._psrp_proxy = None
    conn._psrp_connection_timeout = None
    conn._psrp_read_timeout = None
    conn._psrp_ignore_proxy = False
    conn._psrp_max_envelope_size = 153600

# Generated at 2022-06-11 13:58:27.614783
# Unit test for method reset of class Connection
def test_Connection_reset():

    # Setup the mock
    module_mock = MagicMock()
    module_mock.check_mode = False
    module_mock._config_module = None

    # Create an instance of our class and execute the reset method
    connection = Connection(module_mock)
    connection.reset()

    # Test that reset() method call did not raise any exceptions
    assert True


# Generated at 2022-06-11 13:58:29.374360
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    c = Connection()
    c.put_file()

# Generated at 2022-06-11 13:58:36.497323
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Initialize command argument
    cmd = 'ls'
    # Initialize command_args argument
    command_args = []
    # Initialize outgoing_channels argument
    outgoing_channels = DEFAULT_OUTGOING_CHANNELS
    # Initialize ask_pass argument
    ask_pass = False
    # Initialize ask_sudo_pass argument
    ask_sudo_pass = False
    # Initialize ask_su_pass argument
    ask_su_pass = False
    # Initialize ask_ssh_pass argument
    ask_ssh_pass = False
    # Initialize ssh_pass argument
    ssh_pass = None
    # Initialize transport argument
    transport = C.DEFAULT_TRANSPORT
    # Initialize become_pass argument
    become_pass = None
    # Initialize become_ask_pass argument
    become_

# Generated at 2022-06-11 13:58:37.836531
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    assert True


# Generated at 2022-06-11 13:58:47.302175
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from ansible.module_utils.powershell.common import ArgumentSpec
    from ansible.module_utils.powershell.setup_psrp_session import PSRPSession
    with patch.object(PSRPSession, 'runspace_id', 'ansible_WIN-123-ABC-123-ABC-123'):
        argument_spec = ArgumentSpec()
        connection = Connection(argument_spec.b_dict, ansible_facts=argument_spec.b_dict, connection_parameters=argument_spec.b_dict)
        b_in_path = to_bytes('path/in/file.txt', errors='surrogate_or_strict')
        b_out_path = to_bytes('path/out/file.txt', errors='surrogate_or_strict')

# Generated at 2022-06-11 13:58:48.532612
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    pass


# Generated at 2022-06-11 13:59:01.133809
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    remote_addr = '10.0.0.1'
    remote_user = 'Administrator'
    remote_password = 'foo'
    protocol = None
    port = None
    path = None
    connection_timeout = None
    read_timeout = None
    message_encryption = None
    proxy = None
    ignore_proxy = False
    operation_timeout = 30
    max_envelope_size = 153600
    ca_cert = 'test_certificate'
    auth = None
    cert_validation = True
    configuration_name = None
    reconnection_retries = 2
    reconnection_backoff = 1.0

# Generated at 2022-06-11 13:59:03.678475
# Unit test for method close of class Connection
def test_Connection_close():
    # Construct the object for testing
    connection = Connection()

    # Test the close method
    connection.close()

    # If we got here all is good

# Generated at 2022-06-11 13:59:24.853508
# Unit test for method close of class Connection
def test_Connection_close():
    pass

# Generated at 2022-06-11 13:59:28.880946
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn_exec_psrp_command = Connection('exec_psrp_command')
    cmd = "dir c:\\"
    conn_exec_psrp_command._exec_psrp_command(cmd)
    return True

# Generated at 2022-06-11 13:59:37.408126
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # setup
    import pypsrp
    from pypsrp.system_information import SystemInformation
    from pypsrp.wsman import WSMan

    # mock
    pypsrp.shell.runspace.SystemInformation = SystemInformation
    pypsrp.wsman.WSMan = WSMan

    # get the class object to instantiate
    # the object of the class under test
    cls = Connection()

    # instantiate the object
    inst = cls()

    # create arguments
    in_path = 'in_path'
    out_path = 'out_path'
    tmp = 'tmp'
    # run the test
    result = inst.put_file(in_path, out_path)

    # assert
    assert not result

# Generated at 2022-06-11 13:59:38.272210
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()



# Generated at 2022-06-11 13:59:48.781241
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    C = Connection(None)
    C._psrp_host = 'localhost'
    C._psrp_user = 'user'
    C._psrp_pass = 'password'
    C._psrp_protocol = 'protocol'
    C._psrp_port = 5985
    C._psrp_path = '/path'
    C._psrp_auth = 'auth'
    C._psrp_cert_validation = True
    C._psrp_certificate_key_pem = 'certificate_key_pem'
    C._psrp_certificate_pem = 'certificate_pem'
    C._psrp_credssp_auth_mechanism = 'credssp_auth_mechanism'
    C._psrp_c

# Generated at 2022-06-11 13:59:49.658460
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection()
    conn.exec_command()

# Generated at 2022-06-11 14:00:01.187799
# Unit test for method reset of class Connection
def test_Connection_reset():
    tmp = {}
    tmp['ansible_psrp_configuration_name'] = 'ansible'
    tmp['ansible_psrp_max_envelope_size'] = 512
    tmp['ansible_psrp_operation_timeout'] = 900
    tmp['ansible_psrp_reconnection_backoff'] = 1
    tmp['ansible_psrp_reconnection_retries'] = 10
    tmp['ansible_psrp_auth'] = 'Credssp'
    tmp['ansible_psrp_certificate_key_pem'] = 'No cert key'
    tmp['ansible_psrp_certificate_pem'] = 'No cert'
    tmp['ansible_psrp_credssp_auth_mechanism'] = 'Negotiate'
    tmp

# Generated at 2022-06-11 14:00:10.752561
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # basic test of the put_file
    ansible_runner = AnsibleRunner(connection_type='psrp')
    ansible_runner.test(
        'psrp',
        'put_file',
        "status=changed source=/var/opt/microsoft/docker-cimprov/state/output.json destination=/var/opt/microsoft/docker-cimprov/state/output.json",
        initial_file_tree=[
            {
                'file_path': '/var/opt/microsoft/docker-cimprov/state/output.json',
                'file_contents': '{ "containers" : [ ] }',
                'should_exist': True,
                'touch': True,
                'file_size': 0
            }
        ]
    )

# Generated at 2022-06-11 14:00:13.474310
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    result = connection.fetch_file(tmp_path="/tmp/foo", local_path="/tmp/bar")
    assert result == None


# Generated at 2022-06-11 14:00:25.459712
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
	#Prepare mock
	connection = Connection()
	connection._build_kwargs = mock.Mock()
	connection._exec_psrp_script = mock.Mock()
	connection._parse_pipeline_result = mock.Mock()
	#Invoke the exec_command method
	connection.exec_command('test command')
	#Assert that the method _build_kwargs and _parse_pipeline_result was called
	#assert connection._build_kwargs.call_count == 1, 'Expected call not found'
	#assert connection._exec_psrp_script.call_count == 1, 'Expected call not found'
	#assert connection._parse_pipeline_result.call_count == 1, 'Expected call not found'
	#assert connection._build_kwargs.call_args[0][

# Generated at 2022-06-11 14:01:14.596901
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    HOST = "10.0.0.1"
    USER = "ansible"
    PASS = "ansible"
    PORT = 5986
    PROTOCOL = "https"
    REMOTE_PATH = "C:\\"

    # Initiate connection object
    psrp_conn = Connection(play_context=play_context)
    psrp_conn.set_options(remote_addr=HOST,
                          remote_user=USER,
                          remote_password=PASS,
                          port=PORT,
                          protocol=PROTOCOL,
                          path=REMOTE_PATH)
    
    # Create the remote file which we will create the call to the file transfer
    # method to create the remote file

# Generated at 2022-06-11 14:01:17.234266
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    try:
        if connection:
            connection.close()
    except Exception:
        traceback.print_exc()
        raise

# Generated at 2022-06-11 14:01:24.425964
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    in_path = "C:\\Users\\VssAdministrator\\AppData\\Local\\Temp\\tmp_s0s1b"
    out_path = "C:\\Users\\VssAdministrator\\AppData\\Local\\Temp\\tmp_s0s1b"
    try:
        connection.fetch_file(in_path, out_path)
    except Exception as e:
        print('tearDown called')
        if os.path.exists(out_path):
            os.remove(out_path)


# Generated at 2022-06-11 14:01:34.159325
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection(None)
    script = '''
        $uri = [System.URI]('%s')
        $file = [System.IO.File]::OpenRead($uri.LocalPath)
        $reader = New-Object System.IO.BinaryReader($file)

        $base64 = [Convert]::ToBase64String($reader.ReadBytes(%d))
        $reader.Close()

        If ($base64) {
            $base64
        } Else {
            $?
        }
        '''

    remote_path = 'c:\\test_fetch_remote'
    local_path = 'c:\\test_fetch_local'

# Generated at 2022-06-11 14:01:36.269328
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # TODO: There are no params to pass to this function to test it, but it is a function we use ourselves.
    pass

# Generated at 2022-06-11 14:01:41.959779
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # This is to test the case of [put_file] param 'output_type' is None.
    file_path = "/Users/test/test.txt"
    remote_file = "C:/test/test.txt"
    # remote_file = "/home/test/test.txt"
    c = psrp_connection.Connection()
    c.put_file(file_path, remote_file)



# Generated at 2022-06-11 14:01:52.600920
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    stdout = b'hello\n'
    stderr = b'error\n'

    # Successful run
    with patch.object(psrp.PSRPConnection, '_exec_psrp_script', return_value=(0, stdout, stderr)):
        conn = psrp.Connection()
        conn.exec_command('some-command')
        assert stdout == conn._psrp_stdout
        assert stderr == conn._psrp_stderr

    # Failed run
    with patch.object(psrp.PSRPConnection, '_exec_psrp_script', return_value=(1, stdout, stderr)):
        conn = psrp.Connection()
        conn.exec_command('some-command')
        assert stdout == conn._psrp_stdout

# Generated at 2022-06-11 14:01:55.970281
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()

    # Message is to be printed
    msg = "Connection reset"
    out, err = capsys.readouterr()

    # Testing "msg" variable
    assert msg in to_text(out), "'msg' variable not present in the output"

# Generated at 2022-06-11 14:01:57.329809
# Unit test for method close of class Connection
def test_Connection_close():
    connection=Connection()
    connection.close()

# Generated at 2022-06-11 14:02:07.418907
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
        # fetch_file(self, in_path, out_path, temp_path, follow, use_unsafe_shell=False)
        # args:
        #   in_path(str) --
        #   out_path(str) --
        #   temp_path(str) --
        #   follow(bool) --
        #   use_unsafe_shell(bool) --
        # returns None

        # Mock - args
        arg0 = Mock(side_effect=['in_path'])
        arg1 = Mock(side_effect=['out_path'])
        arg2 = Mock(side_effect=['temp_path'])
        arg3 = Mock(side_effect=[False])
        arg4 = Mock(side_effect=[False])

        # Mock - response
        mock_temp_path = Mock()
        mock

# Generated at 2022-06-11 14:03:30.304621
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Initialize host, port, user, and password for testing
    host = "127.0.0.1"
    port = 5985
    user = "vagrant"
    password = "vagrant"

    # Create the psrp connection object
    psrp_conn = Connection(host=host,
                           port=port,
                           user=user,
                           password=password,
                           protocol="http",
                           cert_validation=False)

    # Connect to the psrp endpoint
    psrp_conn.connect()

    # Get the input file name
    in_path = psrp_conn._exec_psrp_script("$pwd").strip() + "\\ansible.txt"

    # Create the output file name

# Generated at 2022-06-11 14:03:41.179038
# Unit test for method put_file of class Connection

# Generated at 2022-06-11 14:03:50.959219
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection(None, None)
    source = os.path.join(CURRENT_DIR, 'test_PSRP_fetch_file_source.txt')

    # dummy temp file
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()
    # ensure for cleanup
    atexit.register(lambda: os.remove(temp_file.name))


# Generated at 2022-06-11 14:03:54.101922
# Unit test for method reset of class Connection
def test_Connection_reset():
    c = ansible.plugins.connection.psrp.Connection()
    c.runspace = None
    c.reset()
    assert c.runspace is not None


# Generated at 2022-06-11 14:04:02.242277
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection_obj = Connection()
    p = Mock()
    p.stdin.write.return_value = 1
    p.communicate.return_value = (b'', b'')
    connection_obj._exec_psrp_script = Mock()
    connection_obj._exec_psrp_script.return_value = (0, b'', b'')
    connection_obj._wait_for_shell = Mock()
    connection_obj._wait_for_shell.return_value = 0
    test_in_path = '/tmp/test_in_path'
    test_out_path = '/tmp/test_out_path'
    test_out_path_win = 'C:\\Users\\User\\Documents\\test_out_path'
    test_file_size = 10000
    test_data = 'a' * test

# Generated at 2022-06-11 14:04:12.773734
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    c = Connection()

    # Make sure the underlying protocol is not an unrecognized protocol
    expected = {
                'stdout': 'Hello World\r\n',
                'stdout_lines': ['Hello World'],
                'stderr': '',
                'stderr_lines': [],
                'rc': 0
               }
    if c.get_option('_psrp_protocol') != 'pwsh':
        assert c.exec_command('Write-Host "Hello World"') == expected

    # Test an 'exit' command
    expected = {
                'stdout': 'Hello World\r\n',
                'stdout_lines': ['Hello World'],
                'stderr': '',
                'stderr_lines': [],
                'rc': 0
               }
    assert c.exec_

# Generated at 2022-06-11 14:04:13.782092
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    pass # TODO


# Generated at 2022-06-11 14:04:18.023663
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    if hasattr(Connection, "put_file"):
        conn = Connection()
        file_path = 'some/file'
        out_path = 'some/out/path'

        conn.put_file(file_path, out_path)

        assert conn.put_file.call_count == 1

# Generated at 2022-06-11 14:04:19.618386
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    con = Connection()
    con.put_file()



# Generated at 2022-06-11 14:04:25.685658
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Initalise mock connection class
    connection = Connection()

    # Unit test
    in_path = ""
    out_path = ""
    file = ""

    try:
        connection.fetch_file(in_path, out_path, file)
    except Exception as e:
        return False
    return True


# Generated at 2022-06-11 14:06:59.653376
# Unit test for method close of class Connection
def test_Connection_close():
    # Declare all test variables
    ansible_psrp_connection_timeout = 15
    self = mock.Mock()
    self._psrp_host = "localhost"
    self._psrp_user = "Administrator"
    self._psrp_pass = "Password1"
    self._psrp_protocol = "https"
    self._psrp_port = 5986
    self._psrp_auth = "ssl"
    self._psrp_cert_validation = True
    self._psrp_connection_timeout = None
    self._psrp_read_timeout = None
    self._psrp_max_envelope_size = 153600
    self._psrp_configuration_name = None
    self._psrp_reconnection_retries = None


# Generated at 2022-06-11 14:07:06.113973
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # TODO: Test many parameters
    host = 'host'
    port = 9090
    user = 'user'
    password = 'password'
    protocol = 'protocol'
    path = 'path'
    auth = 'auth'
    cert_validation = 'cert_validation'
    connection_timeout = 'connection_timeout'
    read_timeout = 'read_timeout'
    message_encryption = 'message_encryption'
    proxy = 'proxy'
    ignore_proxy = 'ignore_proxy'
    operation_timeout = 'operation_timeout'
    max_envelope_size = 'max_envelope_size'
    configuration_name = 'configuration_name'
    reconnection_retries = 'reconnection_retries'
    reconnection_backoff = 'reconnection_backoff'
    certificate_

# Generated at 2022-06-11 14:07:07.594787
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()


# Generated at 2022-06-11 14:07:16.005160
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection=Connection("DUMMY")
    #This is a hard-coded path to the data directory.
    #This assumes that the test is being run by running python directly
    #In the ansible-connection directory.
    #If this is not the case, change the path to the correct data directory.
    connection._data_path="."
    in_path = os.path.join(connection._data_path, "data/upload/put_file_data.txt")
    out_path = os.path.join(connection._data_path, "data/upload/put_file_data.txt")
    connection.put_file(in_path,out_path)
    

# Generated at 2022-06-11 14:07:26.057322
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Set up mock
    from ansible.module_utils.six.moves import builtins
    builtins.__salt__ = {}
    builtins.__opts__ = {}

    mock_get_option = MagicMock()
    attrs = {'get_option.side_effect': mock_get_option}
    mock_PlayContext = MagicMock(**attrs)
    mock_get_option.return_value = 'testdir'
    mock_get_socket = MagicMock(return_value=mock_getsock)
    attrs = {'get_socket.return_value': mock_getsock,
             'get_transport.return_value': 'smart',
             'is_playbook.return_value': True}
    mock_PlayContext.configure_mock(**attrs)
    mock

# Generated at 2022-06-11 14:07:27.695775
# Unit test for method reset of class Connection
def test_Connection_reset():
    Connection = get_connection_class("psrp")
    connection = Connection()
    connection.reset()



# Generated at 2022-06-11 14:07:31.111110
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection('test_host')
    try:
        connection.put_file(
            in_path='test_inpath',
            out_path='test_outpath',
            use_sudo=True,
            preserve_times=True,
            print_stdout=True)
    except Exception:
        pass



# Generated at 2022-06-11 14:07:37.120307
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    conn = Connection()
    remote_path = 'remote_path'
    local_path = 'local_path'
    file_args = None
    execute_cmd = False
    tmp = None
    follow = False
    conn.fetch_file(remote_path, local_path,file_args=file_args,execute_cmd=execute_cmd,tmp=tmp,follow=follow)
# }}}

# Generated at 2022-06-11 14:07:45.234130
# Unit test for method reset of class Connection
def test_Connection_reset():
	ansible_psrp_host = 'server.domain.local'
	ansible_psrp_user = 'username'
	ansible_psrp_pass = 'password'

	connection = Connection(ansible_psrp_host,ansible_psrp_user,ansible_psrp_pass)

	# verify that the object is set to default values
	assert not connection._psrp_host

	# Execute function under test
	connection.reset()

	# verify that the object is set to default values
	assert not connection.protocol
	assert connection.port == 5986
	assert not connection._psrp_user
	assert not connection._psrp_pass
	assert not connection._psrp_auth



# Generated at 2022-06-11 14:07:46.828287
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    output = connection.put_file()
    assert output == connection.runspace
