

# Generated at 2022-06-11 13:58:12.038378
# Unit test for method close of class Connection
def test_Connection_close():
    c = Connection('bogus', 'bogus')
    c.runspace = Mock()
    c.runspace.state = RunspacePoolState.OPENED
    c.runspace.close = Mock(return_value=None)
    c.close()
    assert c.runspace is None
    assert c._connected == False
    assert c._last_pipeline == None
    c.runspace.close.assert_called_with()

# Generated at 2022-06-11 13:58:22.962682
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # hostname = "10.0.0.1"
    # remote_user = "Administrator"
    # remote_password = "GoodPassword"
    # port=5986
    hostname = "10.0.0.2"
    remote_user = "vagrant"
    remote_password = "vagrant"
    port=5985

    # conn = Connection(host=hostname, remote_user=remote_user, remote_password=remote_password, port=port, psrp_auth='ntlmssp', protocol='http', path='wsman')
    conn = Connection(host=hostname, remote_user=remote_user, remote_password=remote_password, port=port, psrp_auth='credssp', protocol='http', path='wsman')

    #conn = Connection(host=hostname,

# Generated at 2022-06-11 13:58:32.632822
# Unit test for method close of class Connection
def test_Connection_close():
    """
    Test for method close of class Connection
    """
    ps1script = 'Get-PSSession | Remove-PSSession'
    host = '127.0.0.1'
    user = 'myuser'
    password = 'mysecpass'
    port = 5986
    scheme = 'http'
    path = '/wsman'
    auth = 'basic'
    connection = Connection(
        host=host,
        user=user,
        password=password,
        port=port,
        scheme=scheme,
        path=path,
        auth=auth
    )
    data = dict(
        ps1script = ps1script
    )
    connection.connect()
    connection.exec_psrp_command('powershell', data)
    connection.close()
    assert connection.runspace is None

# Generated at 2022-06-11 13:58:35.468898
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    host = 'localhost'
    port = 5986
    user = 'test'
    password = 'pass'
    connection = Connection(host, port)
    connection.put_file(user, password)



# Generated at 2022-06-11 13:58:45.809611
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    """
    a unit test for the put_file method of the Connection class
    """
    mock_module = MagicMock(
        spec=PSRPModuleSpec,
        _psrp_protocol='http',
        _psrp_port=5985,
        _psrp_host='localhost',
        _psrp_user='unittest',
        _psrp_pass='unittest',
        _psrp_path='wsman',
        _psrp_auth='basic',
        _psrp_operation_timeout=30,
        _psrp_cert_validation=False
    )
    mock_connection = MagicMock()

# Generated at 2022-06-11 13:58:58.184039
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """
    @summary: Comparing Connection.exec_command with raw python script
    :return:
    """

    # Load class Connection
    load_class_connection= Connection(play_context=None, new_stdin=None)
    # Build psrp connection parameters
    load_class_connection._build_kwargs()
    # Connect to windows machine
    load_class_connection._connect()

    # Check if there's a command on the current pipeline that still needs to be closed.
    if load_class_connection._last_pipeline:
        # Current pypsrp versions raise an exception if the current state was not RUNNING. We manually set it so we
        # can call stop without any issues.
        load_class_connection._last_pipeline.state = PSInvocationState.RUNNING
        load_class_connection._last

# Generated at 2022-06-11 13:59:09.567020
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.six import PY3
    import tempfile

    # Since Ansible 2.2, fetch() will use a base64 encoder on a file
    # object. This will not work with fetch_file() so we need to decode
    # the file contents.
    def decode_b64_file(f):
        if f.readline() == b'#psrp base64\n':
            return base64.b64decode(f.read())
        else:
            return f.read()

    # Get path of a PS module from variable 'ansible_psmodule_x'
    def get_psmodule_path(var):
        psmodule_path = tempfile.mkdtemp()

# Generated at 2022-06-11 13:59:19.775007
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Get the class to be tested
    ConnectionClass = psrp_connection.Connection

    # Define test inputs, results and expected results
    b_tmp_path = u'/tmp/tmpM7jfAp'
    b_in_path = u'/tmp/tmpM7jfAp/testfile'
    b_out_path = u'/tmp/tmpM7jfAp/testfile'

# Generated at 2022-06-11 13:59:25.566270
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    
    # Arrange
    psrp_conn = Mock()
    psrp_conn.get_option.side_effect = lambda _ : 'test'
    connection = Connection(psrp_conn, 'test')
    
    # Act
    connection.put_file('test', 'test')
    
    # Assert
    assert_equal(psrp_conn.get_option.call_count, 3)


# Generated at 2022-06-11 13:59:34.193993
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    '''
    Unit test for method put_file of class Connection
    '''
    b_in_path = to_bytes('/path/to/src', errors='surrogate_or_strict')
    b_out_path = to_bytes('/path/to/dest', errors='surrogate_or_strict')
    c = Connection('localhost')
    c.put_file(b_in_path, b_out_path, chunked_transfer=True)
    assert set(c.transfers) == set((b_in_path, b_out_path))



# Generated at 2022-06-11 13:59:54.884161
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()



# Generated at 2022-06-11 14:00:06.643163
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # setup basic session settings
    psrp_kwargs = dict(
        server='localhost',
        username='vagrant',
        password='vagrant',
        operation_timeout=10,
        read_timeout=10,
        reconnection_retries=10,
        reconnection_backoff=2.0,
        max_envelope_size=153600,
        ssl=False,
        port=5985,
        auth='plaintext',
    )
    session = Session(**psrp_kwargs)
    session.protocol = 'http'
    session.server_cert_validation = None
    session.operation_timeout = 10
    session.no_proxy = None

    display = Display()
    terminal = Terminal()
    psrp_protocol = 'http://'
    psrp_host

# Generated at 2022-06-11 14:00:13.756819
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """
    Test the method exec_command of class Connection
    """
    global_connection = Connection()
    global_protocol = 'winrm'
    global_timeout = 10
    global_keepalive = 30
    global_winrm_server_cert_validation = 'ignore'
    global_winrm_read_timeout_sec = 5
    global_winrm_operation_timeout_sec = 5
    global_winrm_transport = 'plaintext'
    global_play_context = PlayContext()
    global_play_context.become = False
    global_play_context.become_method = None
    global_play_context.become_user = None
    global_play_context.remote_addr = None
    global_play_context.remote_user = None
    global_play_context.password = None


# Generated at 2022-06-11 14:00:26.000175
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from ansible.module_utils import basic
    from ansible.errors import AnsibleError


# Generated at 2022-06-11 14:00:35.334951
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.module_utils.connection import Connection
    ########################################################################################################################
    # Setup 
    ########################################################################################################################
    # Prepare the mocks
    mock_power_shell = MagicMock(name='PowerShell')
    type(mock_power_shell).runspace = PropertyMock(name='runspace', return_value=None)
    type(mock_power_shell).output = PropertyMock(name='output', return_value=None)
    type(mock_power_shell)._last_pipeline = PropertyMock(name='_last_pipeline', return_value=None)
    
    mock_con = MagicMock(name='Connection')
    type(mock_con).become = PropertyMock(name='become', return_value="")

# Generated at 2022-06-11 14:00:45.001564
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Arrange
    psrp_host = '127.0.0.1'
    psrp_port = 5986
    psrp_user = 'vagrant'
    psrp_pass = 'vagrant'
    psrp_protocol = 'https'
    psrp_path = '/wsman'
    psrp_cert_validation = False
    psrp_connection_timeout = 30
    psrp_read_timeout = 30
    psrp_message_encryption = 'always'
    psrp_proxy = None
    psrp_ignore_proxy = True
    psrp_operation_timeout = None
    psrp_max_envelope_size = None
    psrp_configuration_name = None


# Generated at 2022-06-11 14:00:54.302792
# Unit test for method put_file of class Connection

# Generated at 2022-06-11 14:00:56.611512
# Unit test for method close of class Connection
def test_Connection_close():
    conn = None
    try:
        conn = Connection('localhost')
        conn.close()
    finally:
        if conn:
            conn.close()



# Generated at 2022-06-11 14:01:06.593790
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    _mock_module()
    _mock_runner()
    _mock_psrp_client()
    _mock_settings()
    _mock_inventory()

    play_context = PlayContext()

    display.verbosity = 3
    
    path = 'C:/Users/Administrator/Desktop/test.txt'
    original_path = 'C:/Users/Administrator/Desktop/test.txt'
    module_style = True

    connection = Connection(play_context)
    connection._exec_psrp_script = MagicMock()
    
    connection.fetch_file(path, original_path)


# Generated at 2022-06-11 14:01:17.002371
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    dest = "/tmp/test_fetch"
    b_dest = to_bytes(dest, encoding='utf-8')
    text_result = """
    bG9jYWxob3N0OjEyMzQK
    """
    binary_result = base64.b64decode(text_result)
    # Test for fetch_file for fetching text
    connection = MockPSRPConnection()
    connection._exec_psrp_script = MagicMock(return_value=(0, text_result, ''))
    connection._psrp_host = 'localhost'
    connection.fetch_file('/tmp/test', dest)
    connection._exec_psrp_script.assert_called_once_with(
        ANY, ANY, False, ['/tmp/test', b_dest])

# Generated at 2022-06-11 14:01:54.108622
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    res = Connection().fetch_file('path', 'file')
    assert res == True


# Generated at 2022-06-11 14:02:03.894718
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    conn = Connection(module_name='module_name', connection_info={'transport': 'psrp'})
    conn.runspace = object()
    conn._connected = True
    conn._psrp_host = '_psrp_host'
    conn._psrp_protocol = '_psrp_protocol'
    conn._psrp_port = '_psrp_port'
    conn._psrp_user = '_psrp_user'
    conn._psrp_pass = '_psrp_pass'
    conn._psrp_cert_validation = '_psrp_cert_validation'
    conn._psrp_connection_timeout = '_psrp_connection_timeout'

# Generated at 2022-06-11 14:02:13.139662
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection(Pipelining(None, None, 0), None, None, None)
    with pytest.raises(AnsibleError):
        connection.put_file(None, None)
    with pytest.raises(AnsibleError):
        connection.put_file('./test1.txt', './test2.txt')
    with pytest.raises(AnsibleError):
        connection.put_file('./test1.txt', './test2.txt')
    with pytest.raises(AnsibleError):
        connection.put_file('./test1.txt', './test2.txt')
    with pytest.raises(AnsibleError):
        connection.put_file('./test1.txt', './test2.txt')

# Generated at 2022-06-11 14:02:19.122781
# Unit test for method close of class Connection
def test_Connection_close():
    _psrp_user = 'User'
    _psrp_pass = 'Password'
    _psrp_port = 10000
    _psrp_protocol = 'http'
    _psrp_host = '127.0.0.1'
    _psrp_connection_timeout = 30
    _psrp_read_timeout = 30
    _psrp_message_encryption = 'always'
    _psrp_cert_validation = False
    _psrp_ignore_proxy = True
    _psrp_operation_timeout = 30
    _psrp_max_envelope_size = 30
    _psrp_reconnection_retries = 10
    _psrp_reconnection_backoff = 3.1

# Generated at 2022-06-11 14:02:25.132597
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Arrange
    c = Connection()

    # mock the _exec_psrp_script method
    c._exec_psrp_script = lambda x, y, z: (0, b'Success', '')

    # mock the runspace property
    c.runspace = True

    # Act
    c.fetch_file('C:\\src.txt', 'C:\\dst.txt')

    # Assert
    # no need to assert




# Generated at 2022-06-11 14:02:34.043615
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    test_module = {'here': os.path.abspath(os.path.dirname(__file__))}
    test_connection = Connection(module_name='test', module_args='', 
                                 module_vars=test_module)
    test_connection.runspace = RunspacePool(host=None, auth=None, id='1', 
                                            uri='https://localhost:5986', 
                                            username='admin', password='1')
    test_connection.runspace.state = RunspacePoolState.OPENED
    # test_entries = ['file1_1.txt', 'file1_2.txt', 'file2_1.txt', 'file2_2.txt', 'file3_1.txt', 'file3_2.txt']

# Generated at 2022-06-11 14:02:40.239186
# Unit test for method reset of class Connection
def test_Connection_reset():
    # This method tests the reset method of class Connection
    display.info("Testing reset method of class Connection")

    conn = Connection("winrm")
    mock_controller = MockController()
    conn._set_connection_info(mock_controller)

    display.display("Created connection instance")

    conn.connect()
    display.display("Successfully connected")

    conn.reset()
    display.display("Successfully reset the connection")


# Generated at 2022-06-11 14:02:49.059125
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    config = {'ansible_connection': 'winrm',
              'ansible_winrm_server_cert_validation': 'ignore',
              'ansible_winrm_transport': 'credssp',
              'ansible_host': '$ANSIBLE_HOST',
              'ansible_port': '$ANSIBLE_PORT',
              'ansible_user': '$ANSIBLE_USER',
              'ansible_password': '$ANSIBLE_PASSWORD',
              'ansible_psrp_configuration_name': 'Microsoft.PowerShell',
              'ansible_psrp_reconnection_retries': '24',
              'ansible_psrp_reconnection_backoff': '5.0'}
    pc = PlayContext()

# Generated at 2022-06-11 14:02:58.194328
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
  connection = Connection()
  script = "Write-Host 'Hello World'"
  with mock.patch('ansible_collections.ansible.community.plugins.connection.winrm.Connection.send_input') as mock_send_input:
    mock_send_input.return_value = None
    with mock.patch('ansible_collections.ansible.community.plugins.connection.winrm.base.get_powershell_location') as mock_get_powershell_location:
      mock_get_powershell_location.return_value = None
      with mock.patch('ansible_collections.ansible.community.plugins.connection.winrm.Connection.get_option') as mock_get_option:
        mock_get_option.return_value = None

# Generated at 2022-06-11 14:03:01.079763
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection('http://example.com')
    assert connection.exec_command('echo hello') == (0, 'hello\r\n', '')

# Generated at 2022-06-11 14:04:21.164584
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection('.')
    #conn.exec_command()

    # More unit tests
    # Test ModuleUtility.get_powershell_version() method
    ansibleModuleUtility = ModuleUtility()
    ansibleModuleUtility.get_powershell_version()
    # Test ModuleUtility.is_powershell_v3_or_Newer() method
    ansibleModuleUtility.is_powershell_v3_or_Newer()
    # Test ModuleUtility.is_powershell_v4_or_Newer() method
    ansibleModuleUtility.is_powershell_v4_or_Newer()
    # Test ModuleUtility.is_powershell_v5_or_Newer() method
    ansibleModuleUtility.is_powershell_v5_or_Newer()
    # Test Module

# Generated at 2022-06-11 14:04:32.165537
# Unit test for method exec_command of class Connection

# Generated at 2022-06-11 14:04:35.987543
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    dest = "C:\\test"
    src = "c:\\test.txt"
    args = dict()
    headers = dict()
    content = u("test test")
    checksum = None
    follow = True
    remote_checksum = None
    diff = None
    allow_executable = False
    force = False

    c = Connection()
    c.put_file(dest,content,force=force)
    return


# Generated at 2022-06-11 14:04:46.259792
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    host = "192.168.1.1"
    port = 22
    path = "/here"
    user = "mio"
    password = "xyz"
    protocol = "http"
    remote_addr=host
    remote_user=user
    remote_password=password
    credssp_disable_tlsv1_2=True
    credssp_minimum_version=True
    ansible_psrp_connection_timeout=60
    ansible_psrp_read_timeout=60
    ansible_psrp_operation_timeout=60
    ansible_psrp_reconnection_retries=1
    ansible_psrp_reconnection_backoff=1
    ansible_psrp_max_envelope_size=1
    ansible_psrp_message_enc

# Generated at 2022-06-11 14:04:54.744404
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.module_utils.six.moves import StringIO

    # Prevent pytest from warning about version mismatch
    try:
        import pytest
        pytest.register_assert_rewrite('ansible.module_utils.six.moves')
    except ImportError:
        pass

    module = AnsibleModule(
        argument_spec=dict(
            src=dict(type='path'),
            dest=dict(type='path'),
        ),
        supports_check_mode=True
    )
    set_module_args(dict(src='%%os.path.sep%%', dest='%%os.path.sep%%'))
    connection = Connection()

    # test missing source
    module.params['src'] = None

# Generated at 2022-06-11 14:05:04.179817
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    connection.get_option = mock.MagicMock()
    connection.get_option.return_value = None
    connection._build_kwargs = mock.MagicMock()
    connection._build_kwargs.return_value = None
    connection._exec_psrp_script = mock.MagicMock()
    connection._exec_psrp_script.return_value = 0, None, None
    connection._parse_pipeline_result = mock.MagicMock()
    connection._parse_pipeline_result.return_value = (0, to_bytes(u'foo', encoding='utf-8'), to_bytes(u'bar', encoding='utf-8'))
    command = 'some string'
    rc, stdout, stderr = connection.exec_command(command)
    assert rc == 0

# Generated at 2022-06-11 14:05:06.296055
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.put_file(a_in_path="/c/temp/file01.txt", out_path="./file01.txt")
    

# Generated at 2022-06-11 14:05:11.404364
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    psrp_conn = Mock()

    conn = psrp.Connection(psrp_conn)
    conn.put_file("in_path", "out_path")

    assert mock_open.called
    assert write_mock.called
    assert psrp_conn._exec_psrp_script.called
    assert conn.close.called

# Generated at 2022-06-11 14:05:14.901231
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection(play_context=PlayContext())
    dest = 'C:\windows\temp\1.txt'
    src = 'c:\temp\1.txt'
    check = connection.fetch_file(src,dest)
    assert check == 0

# Generated at 2022-06-11 14:05:24.778097
# Unit test for method put_file of class Connection