

# Generated at 2022-06-11 13:58:28.583049
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    
    # Mock the input args
    my_Connection_instance = Connection()
    
    # Mock the input args
    cmd = "some cmd"
    in_data = "in data"
    sudoable = False
    # Set up our function call
    with patch('ansible.plugins.connection.psrp.Connection._exec_psrp_script') as mock_exec_psrp_script:
        mock_exec_psrp_script.return_value = 1, 'stdout', 'stderr'
        my_Connection_instance.exec_command(cmd=cmd, in_data=in_data, sudoable=sudoable)

        # Validate call
        mock_exec_psrp_script.assert_called_once()


# Generated at 2022-06-11 13:58:36.802633
# Unit test for method reset of class Connection

# Generated at 2022-06-11 13:58:39.080351
# Unit test for method reset of class Connection
def test_Connection_reset():
  from ansible.plugins.connection.psrp import Connection
  obj = Connection()
  obj.reset()


# Generated at 2022-06-11 13:58:48.122693
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Setup psrp for testing
    psrp = Mock()
    psrp.FEATURES = {
        'wsman_read_timeout',
    }
    # Setup the class for testing
    c = Connection(psrp)
    # Setup the runspace for testing
    r = Mock()
    r.state = RunspacePoolState.OPENED
    # Setup the pipeline for testing
    p = Mock()
    p.state = PSInvocationState.RUNNING
    # Setup the host for testing
    h = Mock()
    h.ui.stdout = []
    h.ui.stderr = []
    c.host = h
    # Setup other variables for testing
    c._psrp_conn_kwargs = {
        'connection_timeout': 3,
        'read_timeout': None,
    }

# Generated at 2022-06-11 13:59:00.786225
# Unit test for method put_file of class Connection
def test_Connection_put_file():
# Setup
    m = mock.MagicMock()
    m.get_option.return_value = None
    
    m.get_option = mock.MagicMock()
    m.get_option.side_effect = ["test_in","test_out"]
    
    m.reconnect = mock.MagicMock()
    m.exec_psrp_script = mock.MagicMock()
    m.exec_psrp_script.side_effect = [(0, "", "")]
    m.transfer_file = mock.MagicMock()
    m._build_kwargs = mock.MagicMock()
    
    
# Execution
    result = put_file(m)
    # Testing for valid return type
    assert isinstance(result, bool)
    
# Testing for method calls

# Generated at 2022-06-11 13:59:05.171150
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn_psrp = Connection('psrp')
    output = conn_psrp.exec_command('$PSVersionTable')
    return output

if __name__ == '__main__':
    output = test_Connection_exec_command()
    print(output)

# Generated at 2022-06-11 13:59:08.657461
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    self = Connection()
    in_path = ''
    out_path = ''
    flt = ''
    buffer_size = 1

    self.put_file(in_path, out_path, flt, buffer_size)

# Generated at 2022-06-11 13:59:18.996342
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.module_utils.psrp import ProtocolError
    from ansible.plugins.loader import connection_loader

    #  3.3.1.1.3: https://msdn.microsoft.com/en-us/library/cc677430.aspx
    #  The standard requires that, when the server sends a SOAP Fault back to the client, the IncludeTimeZoneInDateTime error detail must be set to true to indicate that the server MUST send all DateTime values in the time zone in which the server is located.
    #  When the client receives a SOAP Fault from the server and the IncludeTimeZoneInDateTime error detail is not set to true, the client MUST assume that all DateTime values in the SOAP Fault are based on Coordinated Universal Time (UTC).
    #  Because of this, we have to use specific Exchange PowerShell modules to allow us to use DateTime

# Generated at 2022-06-11 13:59:29.752969
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Input parameters tests
    connection_exec_command = Connection(
        host = 'ansible.windows.local', 
        port = 5986, 
        user = 'administrator', 
        password = 'Password123!', 
        protocol = 'https', 
        path = '/wsman', 
        auth = '', 
        cert_validation = True, 
        connection_timeout = 5, 
        read_timeout = 5, 
        message_encryption = 'auto', 
        proxy = None, 
        ignore_proxy = False, 
        operation_timeout = 30, 
        max_envelope_size = 153600, 
        configuration_name = 'ansible.windows.internal'
    )
    # Stub out the actual exec_command method

# Generated at 2022-06-11 13:59:38.093923
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Test with uninitialized object
    c = Connection()
    try:
        c.fetch_file(src='foo', dest='bar')
        assert False, 'Should have thrown'
    except AnsibleConnectionFailure:
        pass
    c.close()

    # Test with initialized object
    pytest.importorskip("pypsrp")
    c = Connection()
    c._build_kwargs()

# Generated at 2022-06-11 14:00:07.052486
# Unit test for method reset of class Connection

# Generated at 2022-06-11 14:00:09.619279
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    from ansible.plugins.connection.psrp import Connection

    psrp_connection = Connection()
    psrp_connection.put_file("foo","bar")
    return True

# Generated at 2022-06-11 14:00:21.349354
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    import psrp_interface as psrp_interface_mocked
    psrp_interface_mocked.text = "TestText"
    psrp_interface_mocked.rc = 0
    psrp_interface_mocked.stdout = "TestStdout"
    psrp_interface_mocked.stderr = "TestStderr"

    connection = Connection(host="host")
    connection._exec_psrp_script = MagicMock(return_value=(psrp_interface_mocked.rc, psrp_interface_mocked.text, psrp_interface_mocked.text))

# Generated at 2022-06-11 14:00:31.910727
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    '''
    Unit test for method `exec_command` of class `Connection`
    '''

    # setup
    logfile = 'test_Connection_exec_command.log'
    if os.path.isfile(logfile):
        os.remove(logfile)
    logging_config['handlers']['default']['filename'] = logfile
    logging.config.dictConfig(logging_config)
    logging.debug('Starting unit test %s' % __file__)

    # start testing
    logging.info('Testing method Connection.exec_command')
    cmd = 'Write-Output "Testing method Connection.exec_command"'
    options = ConnectionOptions('example.org')
    connection = Connection(options)

    # test
    logging.info("Testing method Connection.exec_command without any parameters.")

# Generated at 2022-06-11 14:00:39.305667
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    script = '''[System.Net.WebRequest]::DefaultWebProxy.Credentials = [System.Net.CredentialCache]::DefaultNetworkCredentials\n[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12\n$clientSession = New-PSSession -ComputerName server01 -Port 5986 -Credential $Credential -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck -SkipRevocationCheck)\nCopy-Item -Path "C:\\temp\\test.txt" -Destination "." -ToSession $clientSession\n'''
    script_psrp_session_file_path = 'C:\temp\test.txt'
    script_psrp_local_file_path = 'C:\temp\test.txt'
    assert Connection().f

# Generated at 2022-06-11 14:00:43.144624
# Unit test for method close of class Connection
def test_Connection_close():
    connection = psrp.Connection(psrp_kwargs={'server': 'localhost', 'port': 5986, 'username': 'Administrator', 'password': 'pass@word1'})
    expected = None
    actual = connection.close()
    assert actual == expected


# Generated at 2022-06-11 14:00:45.952146
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Test fetch_file function
    print("Starting test of fetch_file")
    unittest.main(exit=False, verbosity=2)
    print("Ending test of fetch_file")



# Generated at 2022-06-11 14:00:55.066571
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    # Testing with a good argument
    test_arg = os.path.dirname(os.path.realpath(__file__))
    test_arg = os.path.join(test_arg, '../test/test_connection_qpc_good.yaml')
    with patch('io.open', mock_open(read_data='bar')) as mock_file:
        assert connection.fetch_file(test_arg, 'test_dest') == 'test_dest'
    # Testing with a bad argument
    test_arg = os.path.dirname(os.path.realpath(__file__))
    test_arg = os.path.join(test_arg, '../test/test_connection_qpc_bad.yaml')

# Generated at 2022-06-11 14:00:56.314829
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()


# Generated at 2022-06-11 14:01:06.021210
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # create an instance of the class
    c = Connection(dict())
    # set attributes needed by method
    c._connected = True
    script = "cmd /c \"$input | ForEach-Object { $_ } | ForEach-Object { $_ }\""
    # call method
    with mock.patch.object(c, '_exec_psrp_script') as mock_exec:
        rc, stdout, stderr = c.exec_command("test")
    # check calls to mock
    mock_exec.assert_called_once_with(script,input_data=to_bytes('test',encoding='utf-8'), use_local_scope=True)
    # check returned values
    assert rc == 0
    assert stdout == to_bytes('test',encoding='utf-8')
    assert stderr == to_bytes

# Generated at 2022-06-11 14:01:51.679575
# Unit test for method close of class Connection
def test_Connection_close():

    import pyparsing
    import zipfile
    pypsrp_version = '0.3.1'
    match_ns = re.search("(\\d+\\.\\d+)\\.\\d+", pypsrp_version).group(1)

    import distutils.spawn
    if distutils.spawn.find_executable('powershell'):
        pypsrp_module = 'pypsrp'
        pypsrp_module_version = pypsrp_version
    else:
        pypsrp_module = 'pypsrp-%s' % match_ns
        pypsrp_module_version = '%s.*' % match_ns

    if pypsrp_module in sys.modules:
        del sys.modules[pypsrp_module]

    zipped_module

# Generated at 2022-06-11 14:02:01.051088
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    assert not connection._psrp_host
    assert not connection._psrp_user
    assert not connection._psrp_pass
    assert not connection._psrp_protocol
    assert not connection._psrp_port
    assert not connection._psrp_path
    assert not connection._psrp_auth
    assert not connection._psrp_cert_validation
    assert not connection._psrp_connection_timeout
    assert not connection._psrp_read_timeout
    assert connection._psrp_message_encryption is False
    assert not connection._psrp_proxy
    assert not connection._psrp_ignore_proxy
    assert connection._psrp_operation_timeout == 30000
    assert connection._psrp_max_envelope_size == 153600
   

# Generated at 2022-06-11 14:02:10.493259
# Unit test for method close of class Connection
def test_Connection_close():
    # start - begin unit test
    # Values
    ansible_connection = None
    ansible_shell = ShellModule(ansible_connection)
    ansible_shell.run_command = '$'
    ansible_shell.no_log = False
    ansible_shell._shell = ansible_shell
    ansible_shell._last_pipeline = None
    ansible_shell._psrp_host = None
    ansible_shell._psrp_user = None
    ansible_shell._psrp_pass = None
    ansible_shell._psrp_protocol = None
    ansible_shell._psrp_port = None
    ansible_shell._psrp_path = None
    ansible_shell._psrp_auth = None
    ansible_shell._psrp_cert_

# Generated at 2022-06-11 14:02:11.709514
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    conn = Connection()
    conn.fetch_file()
 

# Generated at 2022-06-11 14:02:18.545298
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    from ansible.module_utils.six.moves import StringIO
    import ansible.module_utils.basic

    # read in test data as bytes
    with open("./tests/data/PSRP.autodetect.py", "rb") as f:
        data = f.read()

    # run Connection() tests

    # test psrp fetch
    # start a module mock

# Generated at 2022-06-11 14:02:21.126841
# Unit test for method close of class Connection
def test_Connection_close():
    c = Connection()
    try:
        c.connect()
        c.close()
    except Exception as e:
        print('Exception: ' + str(e))



# Generated at 2022-06-11 14:02:23.432103
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    x = connection.fetch_file()
    y = {
    }
    assert x == y, x



# Generated at 2022-06-11 14:02:32.484641
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    runner = Runner()
    connection = Connection(runner, runner.host.vars, runner.host.name, '')
    
    # 1
    runner.host.vars['ansible_psrp_timeout'] = 20
    psrp_path = runner.get_option('path')
    fd = tempfile.TemporaryFile()
    fd.write(b'Hello, world!')
    fd.seek(0)
    connection.put_file(psrp_path, fd)
    assert os.path.exists(psrp_path)
    
    # 2
    runner.host.vars['ansible_psrp_timeout'] = 20
    psrp_path = runner.get_option('path')
    fd = tempfile.TemporaryFile()

# Generated at 2022-06-11 14:02:42.439681
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():

    runspace_pool_id = -10
    runspace_id = -12
    runspace_state = "Opened"
    runspace_pool_state = "Busy"
    runspace_pool_instance_id = -14
    psrp_host = "localhost"
    psrp_user = "localuser"
    psrp_pass = "localpass"
    psrp_protocol = "https"
    psrp_port = 5986
    psrp_path = "/wsman"
    psrp_auth = "ntlmdomain:MYDOMAIN.LOCAL"
    psrp_cert_validation = True
    psrp_connection_timeout = 10
    psrp_message_encryption = "auto"

# Generated at 2022-06-11 14:02:45.393501
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    with pytest.raises(AnsibleError) as error_info:
        n = Connection()
        n.put_file(src='src', dest='dest')
    assert 'not supported' in str(error_info.value)

# Generated at 2022-06-11 14:03:54.474642
# Unit test for method reset of class Connection
def test_Connection_reset():
    output=''
    args = {}
    p = patch('ansible.plugins.connection.psrp.Connection._reset_psrp', return_value=output)
    p.start()
    c = Connection(None)
    rc = c.reset(**args)
    # Need assert value
    p.stop()

# Generated at 2022-06-11 14:04:01.308808
# Unit test for method close of class Connection
def test_Connection_close():
    set_globals()
    new_stdout = ""
    new_stderr = ""
    new_stdout += "PSRP CLOSE RUNSPACE: 0\n"
    new_stderr += "PSRP CLOSE RUNSPACE: 0\n"

    with patch('sys.stdout', new=StringIO()) as fake_out, patch('sys.stderr', new=StringIO()) as fake_err:
        connection = Connection()
        connection.close()
        assert fake_out.getvalue() == new_stdout
        assert fake_err.getvalue() == new_stderr


# Generated at 2022-06-11 14:04:10.636831
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    assert_raises(AnsibleError, connection.put_file, None, None, None)
    assert_raises(AnsibleError, connection.put_file, 'foo', None, None)
    assert_raises(AnsibleError, connection.put_file, None, 'foo', None)
    assert_raises(AnsibleError, connection.put_file, None, None, 'foo')
    assert_raises(AnsibleError, connection.put_file, 'foo', 'foo', None)
    assert_raises(AnsibleError, connection.put_file, 'foo', None, 'foo')
    assert_raises(AnsibleError, connection.put_file, None, 'foo', 'foo')

# Generated at 2022-06-11 14:04:14.421008
# Unit test for method reset of class Connection
def test_Connection_reset():
    example_script = '''
    import sys
    import certifi
    certifi.where()'''
    exe = Connection()
    exe._exec_psrp_script(example_script)



# Generated at 2022-06-11 14:04:16.519004
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # TODO: Implement test_fetch_file
    assert False, 'Test not implemented'

# Generated at 2022-06-11 14:04:17.855493
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()



# Generated at 2022-06-11 14:04:18.439622
# Unit test for method close of class Connection
def test_Connection_close():
  pass

# Generated at 2022-06-11 14:04:20.009320
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    assert isinstance(connection, Connection)


# Generated at 2022-06-11 14:04:24.884765
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    ps = Connection(None)
    ps.put_file = MagicMock(name='put_file')
    ps.put_file.return_value = None
    assert not ps.put_file('test') is None


# Generated at 2022-06-11 14:04:33.971596
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # We're testing for:
    # 1. No exception raised
    # 2. No exception raised for invalid connections

    # 1. No exception raised
    temp_conn = Connection(play_context=PlayContext(), new_stdin=None)
    B_IN_PATH = b'ZmlsZW5hbWU='
    B_OUT_PATH = b'ZmlsZWdlaWJlZ2l2ZW5hbWU='
    B_DATA = 'ZGF0YQ=='

    class OutFile:
        def __init__(self):
            self.write_called = None

        def write(self, data):
            self.write_called = data

    class Runspace:
        def __init__(self):
            self.state = RunspacePoolState.OPENED


# Generated at 2022-06-11 14:06:49.732416
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection=Connection()
    connection._reset_connection()

# Generated at 2022-06-11 14:06:54.264771
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    in_path = os.path.normpath(os.path.join(BASE_DIR, "files\\hello.txt"))
    out_path = os.path.normpath(os.path.join(BASE_DIR, "files\\hello.txt"))
    connection = Connection()
    connection.put_file(in_path, out_path)


# Generated at 2022-06-11 14:06:56.699424
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    my_Connection = Connection(play_context=PlayContext())
    return my_Connection.fetch_file(in_path='in_path', out_path='out_path')


# Generated at 2022-06-11 14:07:04.102038
# Unit test for method reset of class Connection
def test_Connection_reset():
    mock_get_option = MagicMock(name='get_option')
    mock_psrp_host = MagicMock(name='remote_addr')
    mock_psrp_user = MagicMock(name='remote_user')
    mock_psrp_pass = MagicMock(name='remote_password')
    mock_psrp_protocol = MagicMock(name='protocol')
    mock_psrp_port = MagicMock(name='port')
    mock_psrp_path = MagicMock(name='path')
    mock_psrp_auth = MagicMock(name='auth')
    mock_psrp_cert_validation = MagicMock(name='cert_validation')
    mock_psrp_cert_trust_path = MagicMock(name='ca_cert')

# Generated at 2022-06-11 14:07:14.316666
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    import pytest
    import tempfile

    from .test_data import PSRPConnectionTestData as test_data

    fetch_script = """
$file = cat %s
$fs = $file.OpenRead()
$bytes = $fs.ReadToEnd()
$str = [System.Convert]::ToBase64String($bytes)
Write-Host $str
"""

    read_script = '$fs.Read($args[0], 0, %d) | ConvertTo-Base64'
    close_script = '$fs.Close()'

    on_unsupported_module = 'throw "Test module not supported on target!"'
    on_missing_module = 'throw "Test module required!"'


# Generated at 2022-06-11 14:07:24.109025
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    """
    Connection.exec_command
    """

    # Set up mock
    url = 'https://ansible.example.com:5986/wsman'
    mock_runspace_pool = MagicMock()
    mock_runspace = mock_runspace_pool.open.return_value.__enter__.return_value
    mock_runspace.transport.url = url
    mock_runspace_pool.connect.return_value = mock_runspace

    mock_play_context = MagicMock()
    mock_play_context.verbosity = 4
    mock_play_context.deprecation_warnings = False

    mock_variable_manager = MagicMock()
    mock_inventory = MagicMock()
    mock_loader = MagicMock()
    mock_options = MagicMock()

    # Invoke method


# Generated at 2022-06-11 14:07:26.057960
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    conn = Connection(None)
    result = conn.exec_command(None, None)
    assert result is None


# Generated at 2022-06-11 14:07:33.133431
# Unit test for method close of class Connection
def test_Connection_close():
    import tempfile
    import sys
    import os

    with tempfile.TemporaryDirectory() as temp_dir:
        inventory = os.path.join(temp_dir, 'inventory')
        playbooks = os.path.join(temp_dir, 'playbooks')
        os.mkdir(playbooks)

        inventory_file = os.path.join(inventory, 'inventory')
        inventory_cfg = "[local]\nlocalhost ansible_connection=local\n"

        with open(inventory_file, 'w+') as f:
            f.write(inventory_cfg)

        playbook_path = os.path.join(playbooks, 'test.yml')

# Generated at 2022-06-11 14:07:35.182115
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    assert True == False, "Test not implemented"



# Generated at 2022-06-11 14:07:36.732325
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    assert True == True