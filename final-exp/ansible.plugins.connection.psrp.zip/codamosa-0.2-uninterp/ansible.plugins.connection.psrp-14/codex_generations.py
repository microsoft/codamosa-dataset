

# Generated at 2022-06-17 11:12:48.595266
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # TODO: Implement unit test for method fetch_file of class Connection
    pass


# Generated at 2022-06-17 11:12:49.980648
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.put_file()

# Generated at 2022-06-17 11:12:53.530423
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:13:04.526121
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Setup test
    connection = Connection(None)
    connection._build_kwargs = MagicMock()
    connection._exec_psrp_script = MagicMock()
    connection._exec_psrp_script.return_value = (0, '', '')
    connection.runspace = MagicMock()
    connection.runspace.state = RunspacePoolState.OPENED
    connection._psrp_host = 'localhost'
    connection._psrp_protocol = 'http'
    connection._psrp_port = 5985
    connection._psrp_path = '/wsman'
    connection._psrp_auth = 'basic'
    connection._psrp_cert_validation = False
    connection._psrp_connection_timeout = None
    connection._psrp_read_timeout = None


# Generated at 2022-06-17 11:13:13.169935
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup
    connection = Connection(play_context=PlayContext())
    connection._build_kwargs = MagicMock()
    connection.runspace = MagicMock()
    connection.runspace.state = RunspacePoolState.OPENED
    connection._exec_psrp_script = MagicMock(return_value=(0, 'stdout', 'stderr'))

    # Test
    rc, stdout, stderr = connection.exec_command('command')

    # Assert
    assert rc == 0
    assert stdout == 'stdout'
    assert stderr == 'stderr'
    connection._exec_psrp_script.assert_called_once_with('command')

# Generated at 2022-06-17 11:13:21.578241
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test with a valid command
    conn = Connection()
    conn._build_kwargs()
    conn._psrp_host = 'localhost'
    conn._psrp_user = 'vagrant'
    conn._psrp_pass = 'vagrant'
    conn._psrp_protocol = 'http'
    conn._psrp_port = 5985
    conn._psrp_path = '/wsman'
    conn._psrp_auth = 'basic'
    conn._psrp_cert_validation = True
    conn._psrp_connection_timeout = None
    conn._psrp_read_timeout = None
    conn._psrp_message_encryption = False
    conn._psrp_proxy = None
    conn._psrp_ignore_proxy = False
    conn._ps

# Generated at 2022-06-17 11:13:22.489893
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.put_file()


# Generated at 2022-06-17 11:13:24.125102
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.fetch_file()


# Generated at 2022-06-17 11:13:36.064517
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock connection
    connection = Connection(None)
    # Create a mock ansible_module
    ansible_module = mock.MagicMock()
    # Create a mock ansible_module.params

# Generated at 2022-06-17 11:13:39.711790
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()



# Generated at 2022-06-17 11:14:00.285342
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # TODO: Implement unit test for fetch_file
    pass

# Generated at 2022-06-17 11:14:02.109814
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()


# Generated at 2022-06-17 11:14:04.538568
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()


# Generated at 2022-06-17 11:14:11.137387
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection(None)
    connection._exec_psrp_script = MagicMock(return_value=(0, '', ''))
    connection.runspace = MagicMock()
    connection.runspace.state = RunspacePoolState.OPENED
    connection.runspace.id = 1
    connection._psrp_host = 'localhost'
    connection._psrp_protocol = 'http'
    connection._psrp_port = 5985
    connection._psrp_path = '/wsman'
    connection._psrp_auth = 'basic'
    connection._psrp_cert_validation = False
    connection._psrp_connection_timeout = None
    connection._psrp_read_timeout = None
    connection._psrp_message_encryption = False
    connection._psrp_

# Generated at 2022-06-17 11:14:19.099023
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Test with a valid file
    test_file = os.path.join(os.path.dirname(__file__), 'test_data', 'test_file.txt')
    with open(test_file, 'r') as f:
        test_file_content = f.read()
    test_file_content_b64 = base64.b64encode(test_file_content.encode('utf-8'))
    test_file_content_b64_str = test_file_content_b64.decode('utf-8')

    # Create a mock connection
    mock_conn = Connection(None)
    mock_conn.runspace = mock.MagicMock()
    mock_conn.runspace.state = RunspacePoolState.OPENED

# Generated at 2022-06-17 11:14:27.576394
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Test with a file that exists
    conn = Connection(None, None)
    conn._exec_psrp_script = MagicMock(return_value=(0, 'test', ''))
    conn.fetch_file('test_file', 'test_dest')
    conn._exec_psrp_script.assert_called_with('$fs = New-Object -TypeName System.IO.FileStream -ArgumentList @("test_file", [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read); $fs.Length;', None, False, None)

# Generated at 2022-06-17 11:14:28.985844
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.fetch_file()


# Generated at 2022-06-17 11:14:34.013543
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None

# Generated at 2022-06-17 11:14:43.175048
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock of class Connection
    mock_Connection = mock.create_autospec(Connection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.create_autospec(AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.create_autospec(AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.create_autospec(AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.create_autospec(AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.create_autospec(AnsibleConnection)
    # Create a mock of class Ansible

# Generated at 2022-06-17 11:14:48.471428
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class Connection
    mock_Connection.runspace = mock.Mock(spec=RunspacePool)
    # Create a mock of the class RunspacePool
    mock_RunspacePool = mock.Mock(spec=RunspacePool)
    # Create a mock of the class RunspacePool
    mock_RunspacePool.state = mock.Mock(spec=RunspacePoolState)
    # Create a mock of the class RunspacePoolState
    mock_RunspacePoolState = mock.Mock(spec=RunspacePoolState)
    # Create a mock of the class RunspacePoolState
    mock_RunspacePoolState.OPENED = mock.Mock(spec=RunspacePoolState)
    # Create a mock of the

# Generated at 2022-06-17 11:15:12.374150
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the Connection class
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)
    # Create a mock of the AnsibleModule class

# Generated at 2022-06-17 11:15:20.895818
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class Connection
    mock_Connection = mock.create_autospec(Connection)
    # Create a mock of the class AnsibleOptions
    mock_AnsibleOptions = mock.create_autospec(AnsibleOptions)
    # Create a mock of the class AnsibleOptions
    mock_AnsibleOptions = mock.create_autospec(AnsibleOptions)
    # Create a mock of the class AnsibleOptions
    mock_AnsibleOptions = mock.create_autospec(AnsibleOptions)
    # Create a mock of the class AnsibleOptions
    mock_AnsibleOptions = mock.create_autospec(AnsibleOptions)
    # Create a mock of the class AnsibleOptions
    mock_AnsibleOptions = mock.create_autospec(AnsibleOptions)
    # Create

# Generated at 2022-06-17 11:15:24.843688
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Setup
    # Test
    # Verify
    assert True == True


# Generated at 2022-06-17 11:15:27.832419
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:15:28.609906
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.put_file()


# Generated at 2022-06-17 11:15:30.709925
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.fetch_file()


# Generated at 2022-06-17 11:15:39.328033
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of class Connection
    mock_Connection = mock.create_autospec(Connection)
    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create a mock of class Ansible

# Generated at 2022-06-17 11:15:44.866883
# Unit test for method reset of class Connection
def test_Connection_reset():
    # Create a mock of class Connection
    mock_Connection = mock.Mock(spec=Connection)
    mock_Connection.reset.return_value = None

    # Call the method
    mock_Connection.reset()

    # Check if the method was called
    assert mock_Connection.reset.called


# Generated at 2022-06-17 11:15:53.797785
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None
    assert connection._psrp_host is None
    assert connection._psrp_user is None
    assert connection._psrp_pass is None
    assert connection._psrp_protocol is None
    assert connection._psrp_port is None
    assert connection._psrp_path is None
    assert connection._psrp_auth is None
    assert connection._psrp_cert_validation is None
    assert connection._psrp_connection_timeout is None
    assert connection._psrp_read_timeout is None
    assert connection._psrp_message_encryption is None
    assert connection._psrp_proxy is None
    assert connection

# Generated at 2022-06-17 11:15:55.697195
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # TODO: Implement unit test for method exec_command of class Connection
    pass


# Generated at 2022-06-17 11:16:42.182804
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the class Connection
    mock_Connection = mock.MagicMock(spec=Connection)
    mock_Connection.runspace = mock.MagicMock()
    mock_Connection.runspace.state = RunspacePoolState.OPENED
    mock_Connection.runspace.id = 1
    mock_Connection.runspace.session_id = 1
    mock_Connection.runspace.connection = mock.MagicMock()
    mock_Connection.runspace.connection.protocol = 'https'
    mock_Connection.runspace.connection.server = 'localhost'
    mock_Connection.runspace.connection.port = 5986
    mock_Connection.runspace.connection.username = 'test'
    mock_Connection.runspace.connection.password = 'test'
    mock_Connection.runspace.connection.path = '/wsman'

# Generated at 2022-06-17 11:16:47.768441
# Unit test for constructor of class Connection
def test_Connection():
    conn = Connection(None)
    assert conn.runspace is None
    assert conn._connected is False
    assert conn._last_pipeline is None
    assert conn.host is None
    assert conn._psrp_host is None
    assert conn._psrp_user is None
    assert conn._psrp_pass is None
    assert conn._psrp_protocol is None
    assert conn._psrp_port is None
    assert conn._psrp_path is None
    assert conn._psrp_auth is None
    assert conn._psrp_cert_validation is None
    assert conn._psrp_connection_timeout is None
    assert conn._psrp_read_timeout is None
    assert conn._psrp_message_encryption is None
    assert conn._psrp_proxy is None

# Generated at 2022-06-17 11:16:56.916635
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the Connection class
    mock_Connection = mock.MagicMock(spec=Connection)

    # Define the parameters that the method will be called with
    in_path = 'C:\\Users\\vagrant\\AppData\\Local\\Temp\\ansible-tmp-1516498865.26-180177478972435\\source'
    out_path = '/home/vagrant/ansible-tmp-1516498865.26-180177478972435/source'

    # Set up the mock to return a value
    mock_Connection.runspace.invoke_command.return_value = 0, '', ''

    # Call the method being tested
    rc, stdout, stderr = mock_Connection.fetch_file(in_path, out_path)

    # Check the results
    assert rc

# Generated at 2022-06-17 11:17:03.379679
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock of class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of class RunspacePool
    mock_RunspacePool = mock.Mock(spec=RunspacePool)
    # Create a mock of class PowerShell
    mock_PowerShell = mock.Mock(spec=PowerShell)
    # Create a mock of class PSInvocationState
    mock_PSInvocationState = mock.Mock(spec=PSInvocationState)
    # Create a mock of class GenericComplexObject
    mock_GenericComplexObject = mock.Mock(spec=GenericComplexObject)
    # Create a mock of class Host
    mock_Host = mock.Mock(spec=Host)
    # Create a mock of class PSHostUserInterface

# Generated at 2022-06-17 11:17:11.698131
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock of class Connection
    mock_Connection = mock.Mock(spec=Connection)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_An

# Generated at 2022-06-17 11:17:20.271352
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup
    conn = Connection()
    conn.runspace = None
    conn._psrp_host = 'localhost'
    conn._psrp_user = 'test'
    conn._psrp_pass = 'test'
    conn._psrp_protocol = 'http'
    conn._psrp_port = 5985
    conn._psrp_path = '/wsman'
    conn._psrp_auth = 'basic'
    conn._psrp_cert_validation = False
    conn._psrp_connection_timeout = None
    conn._psrp_read_timeout = None
    conn._psrp_message_encryption = False
    conn._psrp_proxy = None
    conn._psrp_ignore_proxy = False

# Generated at 2022-06-17 11:17:27.378776
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class AnsibleError
    mock_AnsibleError = mock.Mock(spec=AnsibleError)
    # Create a mock of the class display
    mock_display = mock.Mock(spec=display)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock(spec=to_native)
    # Create a mock of the class base64
    mock_base64 = mock.Mock(spec=base64)
    # Create a mock of the class open
    mock_open = mock.Mock(spec=open)
    # Create a mock of the class RunspacePoolState

# Generated at 2022-06-17 11:17:32.391522
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    connection = Connection()
    connection.exec_command('echo "hello"')


# Generated at 2022-06-17 11:17:41.402584
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class AnsibleError
    mock_AnsibleError = mock.Mock(spec=AnsibleError)
    # Create a mock of the class display
    mock_display = mock.Mock(spec=display)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock(spec=to_native)
    # Create a mock of the class base64
    mock_base64 = mock.Mock(spec=base64)
    # Create a mock of the class open
    mock_open = mock.Mock(spec=open)
    # Create a mock of the class RunspacePoolState

# Generated at 2022-06-17 11:17:45.711788
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # TODO: Implement unit test
    pass


# Generated at 2022-06-17 11:19:08.109383
# Unit test for constructor of class Connection
def test_Connection():
    '''
    Unit test for constructor of class Connection
    '''
    connection = Connection(play_context=PlayContext())
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None
    assert connection._psrp_host is None
    assert connection._psrp_user is None
    assert connection._psrp_pass is None
    assert connection._psrp_protocol is None
    assert connection._psrp_port is None
    assert connection._psrp_path is None
    assert connection._psrp_auth is None
    assert connection._psrp_cert_validation is None
    assert connection._psrp_connection_timeout is None
    assert connection._psrp_read_timeout is None
    assert connection._psrp_message_encryption

# Generated at 2022-06-17 11:19:10.562779
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock connection object
    connection = Connection()
    # Create a mock file object
    in_path = 'test_in_path'
    out_path = 'test_out_path'
    # Call the put_file method
    connection.put_file(in_path, out_path)


# Generated at 2022-06-17 11:19:21.366603
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Test with a valid file
    conn = Connection(None)
    conn.put_file('/tmp/test_file', '/tmp/test_file')
    # Test with a non-existing file
    conn = Connection(None)
    conn.put_file('/tmp/test_file_not_exist', '/tmp/test_file_not_exist')
    # Test with a directory
    conn = Connection(None)
    conn.put_file('/tmp', '/tmp')
    # Test with a file with invalid permissions
    conn = Connection(None)
    conn.put_file('/tmp/test_file_invalid_permissions', '/tmp/test_file_invalid_permissions')
    # Test with a file with invalid permissions
    conn = Connection(None)

# Generated at 2022-06-17 11:19:28.842195
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class AnsibleError
    mock_AnsibleError = mock.Mock(spec=AnsibleError)
    # Create a mock of the class display
    mock_display = mock.Mock(spec=display)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock(spec=to_native)
    # Create a mock of the class base64
    mock_base64 = mock.Mock(spec=base64)
    # Create a mock of the class open
    mock_open = mock.Mock(spec=open)
    # Create a mock of the class to_bytes
    mock_to_bytes = mock.Mock(spec=to_bytes)
   

# Generated at 2022-06-17 11:19:30.706319
# Unit test for method close of class Connection
def test_Connection_close():
    conn = Connection()
    conn.close()
    assert conn.runspace is None
    assert conn._connected is False
    assert conn._last_pipeline is None


# Generated at 2022-06-17 11:19:32.824425
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()


# Generated at 2022-06-17 11:19:37.871117
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test with no arguments
    connection = Connection()
    result = connection.exec_command()
    assert result == (0, '', '')
    # Test with arguments
    connection = Connection()
    result = connection.exec_command('echo "Hello World"')
    assert result == (0, 'Hello World\r\n', '')


# Generated at 2022-06-17 11:19:41.452363
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:19:48.598274
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the method
    mock_fetch_file = mock.Mock(spec=Connection.fetch_file)
    # Assign the mock method to the mock object
    mock_Connection.fetch_file = mock_fetch_file
    # Set return value of the mock method
    mock_fetch_file.return_value = None
    # Call the method with required arguments
    mock_Connection.fetch_file(in_path='in_path', out_path='out_path')
    # Check if the mock method was called as expected
    mock_fetch_file.assert_called_once_with(in_path='in_path', out_path='out_path')

# Generated at 2022-06-17 11:19:59.829684
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock of the class Connection
    mock_Connection = mock.create_autospec(Connection)
    # Create a mock of the class AnsibleConnection
    mock_AnsibleConnection = mock.create_autospec(AnsibleConnection)
    # Create a mock of the class AnsibleConnection
    mock_AnsibleConnection.get_option.return_value = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'
    # Create a mock of the class AnsibleConnection
    mock_AnsibleConnection.get_option.return_value = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'
    # Create a mock of the class AnsibleConnection

# Generated at 2022-06-17 11:21:21.830744
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the class Connection
    class MockConnection(Connection):
        def __init__(self, *args, **kwargs):
            self.runspace = None
            self._connected = False
            self._last_pipeline = None
            self.host = None
            self._psrp_host = None
            self._psrp_user = None
            self._psrp_pass = None
            self._psrp_protocol = None
            self._psrp_port = None
            self._psrp_path = None
            self._psrp_auth = None
            self._psrp_cert_validation = None
            self._psrp_connection_timeout = None
            self._psrp_read_timeout = None
            self._psrp_message_encryption = None


# Generated at 2022-06-17 11:21:27.208659
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Test with a valid file
    test_file = 'test_file.txt'
    test_file_content = 'test_file_content'
    with open(test_file, 'w') as f:
        f.write(test_file_content)

    # Test with a non-existent file
    test_file_2 = 'test_file_2.txt'

    # Test with a directory
    test_dir = 'test_dir'
    os.mkdir(test_dir)

    # Test with a non-existent directory
    test_dir_2 = 'test_dir_2'

    # Test with a file with a non-ascii character in the name
    test_file_3 = 'test_file_3.txt'
    test_file_3_content = 'test_file_3_content'
   

# Generated at 2022-06-17 11:21:41.097555
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup
    connection = Connection()
    connection._psrp_host = 'localhost'
    connection._psrp_user = 'username'
    connection._psrp_pass = 'password'
    connection._psrp_protocol = 'http'
    connection._psrp_port = 5985
    connection._psrp_path = '/wsman'
    connection._psrp_auth = 'basic'
    connection._psrp_cert_validation = False
    connection._psrp_connection_timeout = None
    connection._psrp_read_timeout = None
    connection._psrp_message_encryption = False
    connection._psrp_proxy = None
    connection._psrp_ignore_proxy = False
    connection._psrp_operation_timeout = None
    connection._psrp

# Generated at 2022-06-17 11:21:45.709453
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:21:46.961580
# Unit test for constructor of class Connection
def test_Connection():
    connection = Connection(None)
    assert connection is not None


# Generated at 2022-06-17 11:21:58.201994
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class AnsibleError
    mock_AnsibleError = mock.Mock(spec=AnsibleError)
    # Create a mock of the class display
    mock_display = mock.Mock(spec=display)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock(spec=to_native)
    # Create a mock of the class base64
    mock_base64 = mock.Mock(spec=base64)
    # Create a mock of the class open
    mock_open = mock.Mock(spec=open)
    # Create a mock of the class RunspacePoolState

# Generated at 2022-06-17 11:22:09.746059
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the Connection class
    mock_Connection = mock.create_autospec(Connection)

    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)

    # Create a mock of the AnsibleFile class
    mock_AnsibleFile = mock.create_autospec(AnsibleFile)

    # Create a mock of the AnsibleFile class
    mock_AnsibleFile = mock.create_autospec(AnsibleFile)

    # Create a mock of the AnsibleFile class
    mock_AnsibleFile = mock.create_autospec(AnsibleFile)

    # Create a mock of the AnsibleFile class
    mock_AnsibleFile = mock.create_autospec(AnsibleFile)

    # Create

# Generated at 2022-06-17 11:22:11.970323
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:22:23.770404
# Unit test for method put_file of class Connection