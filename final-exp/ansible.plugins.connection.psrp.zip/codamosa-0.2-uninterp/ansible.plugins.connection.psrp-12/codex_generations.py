

# Generated at 2022-06-17 11:12:53.603795
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:12:56.042335
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection._connected == False
    assert connection._last_pipeline == None
    assert connection.runspace == None


# Generated at 2022-06-17 11:12:58.440212
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:13:00.448522
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.put_file()

# Generated at 2022-06-17 11:13:01.330314
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.fetch_file()


# Generated at 2022-06-17 11:13:03.110797
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # TODO: Add unit test for exec_command
    pass


# Generated at 2022-06-17 11:13:13.136876
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test with a valid command
    conn = Connection(None)
    conn._psrp_host = 'localhost'
    conn._psrp_user = 'test_user'
    conn._psrp_pass = 'test_pass'
    conn._psrp_protocol = 'http'
    conn._psrp_port = 5985
    conn._psrp_path = '/wsman'
    conn._psrp_auth = 'basic'
    conn._psrp_cert_validation = False
    conn._psrp_connection_timeout = None
    conn._psrp_read_timeout = None
    conn._psrp_message_encryption = False
    conn._psrp_proxy = None
    conn._psrp_ignore_proxy = False
    conn._psrp_operation_

# Generated at 2022-06-17 11:13:19.494430
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock of class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.Mock(spec=AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection.get_option.return_value = None
    # Create a mock of class RunspacePool
    mock_RunspacePool = mock.Mock(spec=RunspacePool)
    # Create a mock of class PowerShell
    mock_PowerShell = mock.Mock(spec=PowerShell)
    # Create a mock of class PSInvocationState
    mock_PSInvocationState = mock.Mock(spec=PSInvocationState)
    # Create a mock of class GenericComplexObject

# Generated at 2022-06-17 11:13:31.469724
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Setup
    connection = Connection()
    connection._psrp_host = 'localhost'
    connection._psrp_user = 'vagrant'
    connection._psrp_pass = 'vagrant'
    connection._psrp_protocol = 'http'
    connection._psrp_port = 5985
    connection._psrp_path = '/wsman'
    connection._psrp_auth = 'basic'
    connection._psrp_cert_validation = True
    connection._psrp_connection_timeout = None
    connection._psrp_read_timeout = None
    connection._psrp_message_encryption = False
    connection._psrp_proxy = None
    connection._psrp_ignore_proxy = False
    connection._psrp_operation_timeout = 30
    connection._ps

# Generated at 2022-06-17 11:13:34.153964
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # TODO: Implement test for method fetch_file of class Connection
    raise NotImplementedError

# Generated at 2022-06-17 11:13:55.336574
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:14:05.909748
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the Connection class
    connection_mock = mock.MagicMock(spec=Connection)
    # Create a mock of the AnsibleModule class
    ansible_module_mock = mock.MagicMock(spec=AnsibleModule)
    # Create a mock of the AnsibleModule class
    ansible_module_mock.params = {
        'path': 'C:\\Users\\Public\\Documents\\test.txt',
        'dest': 'C:\\Users\\Public\\Documents\\test_copy.txt'
    }
    # Create a mock of the AnsibleModule class
    ansible_module_mock.check_mode = False
    # Create a mock of the AnsibleModule class
    ansible_module_mock.no_log = False
    # Create a mock of the AnsibleModule class
    ansible

# Generated at 2022-06-17 11:14:09.587471
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:14:18.265006
# Unit test for method exec_command of class Connection

# Generated at 2022-06-17 11:14:27.008081
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock object for the module
    mock_module = mock.MagicMock()
    mock_module.params = {'_ansible_connection': 'psrp'}
    mock_module.params['_ansible_remote_tmp'] = 'C:\\Users\\vagrant\\AppData\\Local\\Temp'
    mock_module.params['_ansible_keep_remote_files'] = False
    mock_module.params['_ansible_no_log'] = False
    mock_module.params['_ansible_debug'] = False
    mock_module.params['_ansible_diff'] = False
    mock_module.params['_ansible_verbosity'] = 0
    mock_module.params['_ansible_check_mode'] = False
    mock_module.params['_ansible_socket'] = None
    mock

# Generated at 2022-06-17 11:14:30.987706
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:14:40.480654
# Unit test for method close of class Connection
def test_Connection_close():
    # Test with no runspace
    connection = Connection()
    connection.runspace = None
    connection.close()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None

    # Test with runspace that is not open
    connection = Connection()
    connection.runspace = Mock()
    connection.runspace.state = RunspacePoolState.CLOSED
    connection.close()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None

    # Test with runspace that is open
    connection = Connection()
    connection.runspace = Mock()
    connection.runspace.state = RunspacePoolState.OPENED
    connection.close()
    assert connection.runspace is None
    assert connection._connected is False


# Generated at 2022-06-17 11:14:41.453296
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # TODO: Implement test
    pass


# Generated at 2022-06-17 11:14:47.069021
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test with a valid command
    connection = Connection()
    connection._build_kwargs()
    connection._psrp_conn_kwargs['server'] = 'localhost'
    connection._psrp_conn_kwargs['username'] = 'vagrant'
    connection._psrp_conn_kwargs['password'] = 'vagrant'
    connection._psrp_conn_kwargs['port'] = 5986
    connection._psrp_conn_kwargs['ssl'] = True
    connection._psrp_conn_kwargs['operation_timeout'] = 60
    connection._psrp_conn_kwargs['read_timeout'] = 60
    connection._psrp_conn_kwargs['reconnection_retries'] = 5
    connection._psrp_conn_kwargs['reconnection_backoff'] = 1.0


# Generated at 2022-06-17 11:14:52.789810
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None

# Generated at 2022-06-17 11:15:15.241209
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()


# Generated at 2022-06-17 11:15:20.067454
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # TODO: implement test
    pass


# Generated at 2022-06-17 11:15:28.273324
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test exec_command method of class Connection
    # Create an instance of class Connection
    conn = Connection()
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of class Connection
    # Test exec_command method of

# Generated at 2022-06-17 11:15:38.607588
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Initialize the class
    connection = Connection()
    # Set the connection class attributes
    connection.runspace = None
    connection._connected = False
    connection._last_pipeline = None
    connection._psrp_host = None
    connection._psrp_user = None
    connection._psrp_pass = None
    connection._psrp_protocol = None
    connection._psrp_port = None
    connection._psrp_path = None
    connection._psrp_auth = None
    connection._psrp_cert_validation = None
    connection._psrp_connection_timeout = None
    connection._psrp_read_timeout = None
    connection._psrp_message_encryption = None
    connection._psrp_proxy = None
    connection._psrp_ignore_

# Generated at 2022-06-17 11:15:42.905759
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.fetch_file()

# Generated at 2022-06-17 11:15:52.999545
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the Connection class
    mock_Connection = mock.create_autospec(Connection)
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.create_autospec(AnsibleModule)
    # Create

# Generated at 2022-06-17 11:16:01.454938
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Test case data
    in_path = 'in_path'
    out_path = 'out_path'
    # Expected result
    expected_result = None
    # Expected exception
    expected_exception = None
    # Expected exception message
    expected_exception_message = None
    # Actual result
    actual_result = None
    # Actual exception
    actual_exception = None
    # Actual exception message
    actual_exception_message = None

    # Test case
    try:
        # Tested code
        connection = Connection()
        actual_result = connection.put_file(in_path, out_path)
    except Exception as e:
        actual_exception = e
        actual_exception_message = str(e)

    # Assertions
    assert actual_result == expected_result
   

# Generated at 2022-06-17 11:16:11.307855
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock of class Connection
    mock_Connection = mock.Mock(spec=Connection)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_An

# Generated at 2022-06-17 11:16:23.934675
# Unit test for method put_file of class Connection

# Generated at 2022-06-17 11:16:32.308894
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)
    # Create a mock of the class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)
    # Create a mock of the class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)
    # Create a mock of the class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)
    # Create a mock of the class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)
    # Create a mock of the class Ans

# Generated at 2022-06-17 11:17:18.912613
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock of class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.Mock(spec=AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.Mock(spec=AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.Mock(spec=AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.Mock(spec=AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_AnsibleConnection = mock.Mock(spec=AnsibleConnection)
    # Create a mock of class AnsibleConnection
    mock_An

# Generated at 2022-06-17 11:17:27.493317
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock of class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of class AnsibleModule
    mock_AnsibleModule = mock.Mock(spec=AnsibleModule)
    # Create a mock of class AnsibleModule
    mock_AnsibleModule_params = mock.Mock(spec=AnsibleModule)
    # Create a mock of class AnsibleModule
    mock_AnsibleModule_params_args = mock.Mock(spec=AnsibleModule)
    # Create a mock of class AnsibleModule
    mock_AnsibleModule_params_executable = mock.Mock(spec=AnsibleModule)
    # Create a mock of class AnsibleModule

# Generated at 2022-06-17 11:17:40.344361
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the Connection class
    mock_Connection = mock.MagicMock()
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.MagicMock()
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.MagicMock()
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.MagicMock()
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.MagicMock()
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.MagicMock()
    # Create a mock of the AnsibleModule class
    mock_AnsibleModule = mock.MagicMock()
    # Create a mock of the AnsibleModule class
    mock_

# Generated at 2022-06-17 11:17:50.709859
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Create a mock of class Connection
    mock_Connection = mock.create_autospec(Connection)
    # Create a mock of class AnsibleHost
    mock_AnsibleHost = mock.create_autospec(AnsibleHost)
    # Create a mock of class RunspacePool
    mock_RunspacePool = mock.create_autospec(RunspacePool)
    # Create a mock of class PowerShell
    mock_PowerShell = mock.create_autospec(PowerShell)
    # Create a mock of class Pipeline
    mock_Pipeline = mock.create_autospec(Pipeline)
    # Create a mock of class PSInvocationState
    mock_PSInvocationState = mock.create_autospec(PSInvocationState)
    # Create a mock of class GenericComplexObject

# Generated at 2022-06-17 11:17:59.129664
# Unit test for method put_file of class Connection

# Generated at 2022-06-17 11:18:09.862845
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class AnsibleError
    mock_AnsibleError = mock.Mock(spec=AnsibleError)
    # Create a mock of the class display
    mock_display = mock.Mock(spec=display)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock(spec=to_native)
    # Create a mock of the class base64
    mock_base64 = mock.Mock(spec=base64)
    # Create a mock of the class open
    mock_open = mock.Mock(spec=open)
    # Create a mock of the class RunspacePoolState

# Generated at 2022-06-17 11:18:18.653837
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the PSRP connection
    mock_psrp_conn = mock.MagicMock()
    mock_psrp_conn.runspace = mock.MagicMock()
    mock_psrp_conn.runspace.state = RunspacePoolState.OPENED
    mock_psrp_conn._exec_psrp_script = mock.MagicMock(return_value=(0, '', ''))
    mock_psrp_conn._psrp_host = 'localhost'
    mock_psrp_conn._psrp_protocol = 'https'
    mock_psrp_conn._psrp_port = 5986
    mock_psrp_conn._psrp_path = '/wsman'
    mock_psrp_conn._psrp_user = 'Administrator'

# Generated at 2022-06-17 11:18:21.839872
# Unit test for method reset of class Connection
def test_Connection_reset():
    connection = Connection()
    connection.reset()
    assert connection.runspace is None
    assert connection._connected is False
    assert connection._last_pipeline is None


# Generated at 2022-06-17 11:18:24.668200
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()


# Generated at 2022-06-17 11:18:28.173898
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    connection = Connection()
    connection.fetch_file()


# Generated at 2022-06-17 11:19:48.645056
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    # Create a mock of the module
    mock_module = MagicMock()
    mock_module.params = {
        'path': 'C:\\temp\\test.txt',
        'content': 'Hello World'
    }

    # Create a mock of the connection
    mock_connection = MagicMock()
    mock_connection.runspace = MagicMock()
    mock_connection.runspace.state = RunspacePoolState.OPENED

    # Create a mock of the PSRP connection
    mock_psrp_connection = MagicMock()
    mock_psrp_connection.runspace = MagicMock()
    mock_psrp_connection.runspace.state = RunspacePoolState.OPENED

    # Create a mock of the PSRP connection
    mock_psrp_connection = MagicMock()
    mock_

# Generated at 2022-06-17 11:19:59.829984
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Setup
    connection = Connection()
    connection.get_option = MagicMock()
    connection.get_option.return_value = None
    connection.runspace = MagicMock()
    connection.runspace.state = RunspacePoolState.OPENED
    connection.runspace.id = 'RunspacePool-1'
    connection.host = MagicMock()
    connection.host.rc = 0
    connection.host.ui.stdout = []
    connection.host.ui.stderr = []
    connection._last_pipeline = None
    connection._psrp_host = 'localhost'
    connection._psrp_user = 'test_user'
    connection._psrp_pass = 'test_pass'
    connection._psrp_protocol = 'https'
    connection._psrp_port

# Generated at 2022-06-17 11:20:03.699894
# Unit test for method put_file of class Connection
def test_Connection_put_file():
    connection = Connection()
    connection.put_file(in_path, out_path)
    assert connection.put_file(in_path, out_path) == None


# Generated at 2022-06-17 11:20:08.734933
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Test with no parameters
    connection = Connection()
    connection.fetch_file()
    # Test with valid parameters
    connection = Connection()
    connection.fetch_file(in_path='in_path', out_path='out_path')
    # Test with valid parameters and invalid parameters
    connection = Connection()
    connection.fetch_file(in_path='in_path', out_path='out_path', buffer_size='buffer_size')
    # Test with valid parameters and invalid parameters
    connection = Connection()
    connection.fetch_file(in_path='in_path', out_path='out_path', buffer_size=1)
    # Test with valid parameters and invalid parameters
    connection = Connection()

# Generated at 2022-06-17 11:20:17.728395
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class AnsibleError
    mock_AnsibleError = mock.Mock(spec=AnsibleError)
    # Create a mock of the class display
    mock_display = mock.Mock(spec=display)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock(spec=to_native)
    # Create a mock of the class base64
    mock_base64 = mock.Mock(spec=base64)
    # Create a mock of the class open
    mock_open = mock.Mock(spec=open)
    # Create a mock of the class RunspacePoolState

# Generated at 2022-06-17 11:20:28.804355
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class AnsibleError
    mock_AnsibleError = mock.Mock(spec=AnsibleError)
    # Create a mock of the class display
    mock_display = mock.Mock(spec=display)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock(spec=to_native)
    # Create a mock of the class base64
    mock_base64 = mock.Mock(spec=base64)
    # Create a mock of the class open
    mock_open = mock.Mock(spec=open)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock(spec=to_native)
   

# Generated at 2022-06-17 11:20:41.471700
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test with no arguments
    connection = Connection()
    assert connection.exec_command() == (0, '', '')
    # Test with arguments
    connection = Connection()
    assert connection.exec_command('echo "hello"') == (0, 'hello\r\n', '')
    # Test with arguments and check_rc
    connection = Connection()
    assert connection.exec_command('echo "hello"', check_rc=True) == (0, 'hello\r\n', '')
    # Test with arguments and check_rc
    connection = Connection()
    assert connection.exec_command('echo "hello"', check_rc=True) == (0, 'hello\r\n', '')
    # Test with arguments and check_rc
    connection = Connection()

# Generated at 2022-06-17 11:20:44.188368
# Unit test for method close of class Connection
def test_Connection_close():
    connection = Connection()
    connection.close()


# Generated at 2022-06-17 11:20:51.412206
# Unit test for method fetch_file of class Connection
def test_Connection_fetch_file():
    # Create a mock of the class Connection
    mock_Connection = mock.Mock(spec=Connection)
    # Create a mock of the class AnsibleError
    mock_AnsibleError = mock.Mock(spec=AnsibleError)
    # Create a mock of the class display
    mock_display = mock.Mock(spec=display)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock(spec=to_native)
    # Create a mock of the class base64
    mock_base64 = mock.Mock(spec=base64)
    # Create a mock of the class b64decode
    mock_b64decode = mock.Mock(spec=b64decode)
    # Create a mock of the class to_native
    mock_to_native = mock.Mock

# Generated at 2022-06-17 11:21:02.128019
# Unit test for method exec_command of class Connection
def test_Connection_exec_command():
    # Test with a valid connection
    connection = Connection()
    connection._psrp_host = 'localhost'
    connection._psrp_user = 'vagrant'
    connection._psrp_pass = 'vagrant'
    connection._psrp_protocol = 'http'
    connection._psrp_port = 5985
    connection._psrp_path = '/wsman'
    connection._psrp_auth = 'basic'
    connection._psrp_cert_validation = False
    connection._psrp_connection_timeout = None
    connection._psrp_read_timeout = None
    connection._psrp_message_encryption = False
    connection._psrp_proxy = None
    connection._psrp_ignore_proxy = False
    connection._psrp_operation_timeout = None
