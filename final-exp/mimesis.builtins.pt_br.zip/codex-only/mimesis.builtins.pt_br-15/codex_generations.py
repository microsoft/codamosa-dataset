

# Generated at 2022-06-23 20:37:16.165537
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider_cnpj."""
    import re
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert re.search("\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}", cnpj)

# Generated at 2022-06-23 20:37:18.107483
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bp = BrazilSpecProvider()
    assert bp.cpf()
    assert bp.cnpj()

# Generated at 2022-06-23 20:37:25.398543
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    brazil_cnpj = BrazilSpecProvider()
    assert isinstance(brazil_cnpj.cnpj(), str)
    assert len(brazil_cnpj.cnpj()) == 18
    brazil_cnpj = BrazilSpecProvider(seed=123456)
    assert len(brazil_cnpj.cnpj()) == 18
    assert brazil_cnpj.cnpj() == "33.711.834/0001-01"
    assert brazil_cnpj.cnpj(with_mask=False) == "33711834000101"


# Generated at 2022-06-23 20:37:34.743886
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    gen = BrazilSpecProvider()
    cpf = gen.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf == gen.cpf(with_mask=True)
    cpf_no_mask = gen.cpf(with_mask=False)
    assert len(cpf_no_mask) == 11
    assert cpf_no_mask[3] != '.'
    assert cpf_no_mask[7] != '.'
    assert cpf_no_mask[11] != '-'
    assert cpf_no_mask != cpf


# Generated at 2022-06-23 20:37:39.948534
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for BrazilSpecProvider.cnpj().
    :returns: The result of the test.
    """
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)

# Generated at 2022-06-23 20:37:41.319891
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider != None


# Generated at 2022-06-23 20:37:44.075601
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj."""
    import re
    a = BrazilSpecProvider()
    assert re.match("^\d{2}.\d{3}.\d{3}/\d{4}-\d{2}$", a.cnpj())

# Generated at 2022-06-23 20:37:47.014202
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    bra_provider = BrazilSpecProvider()
    #print(bra_provider.cpf(with_mask=False))

    result = bra_provider.person(gender=Gender.MALE)
    print(result)


# Generated at 2022-06-23 20:37:52.122257
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test = BrazilSpecProvider()
    result = test.cnpj(with_mask=True)
    assert len(result) == 18 # checa se o result tem o tamanho esperado (com máscara)
    assert result[2] == "." and result[6] == "." and result[10] == "/" and result[15] == "-" # checa se máscara está correta
    assert result[0] != "0" and result[1] != "0" # checa se primeira duas casas (antes do ponto) são válidas
    assert result[3] != "0" and result[4] != "0" and result[5] != "0" # checa se terceira, quarta e quinta casas (pós ponto) são válidas

# Generated at 2022-06-23 20:37:56.091558
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()

    result = brazil.cnpj(with_mask=True)
    assert len(result) == 18

    result = brazil.cnpj(with_mask=False)
    assert len(result) == 14



# Generated at 2022-06-23 20:37:59.832610
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    provider = BrazilSpecProvider()

    cnpj = provider.cnpj()
    print(cnpj)

    cnpj = provider.cnpj(with_mask=False)
    print(cnpj)


if __name__ == '__main__':

    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-23 20:38:03.590755
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert isinstance(cpf, str)


# Generated at 2022-06-23 20:38:12.362220
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = 'TEST_PATTERN'
    provider = BrazilSpecProvider(seed)

    cpf_list = ['049.653.556-73', '197.332.715-39', '786.741.265-26', '935.819.987-77', '569.203.749-04', '472.019.049-18']
    # Generate cpf
    for cpf in cpf_list:
        assert cpf == provider.cpf()
    # Generate cpf without mask
    for cpf in cpf_list:
        assert cpf.replace('.', '').replace('-', '') == provider.cpf(False)


# Generated at 2022-06-23 20:38:14.456845
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pt_BR = BrazilSpecProvider()
    print(pt_BR.cnpj())
    print(pt_BR.cpf())

# Generated at 2022-06-23 20:38:17.254743
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(False)
    assert len(cpf) == 11
    assert cpf != ''



# Generated at 2022-06-23 20:38:19.240781
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14


# Generated at 2022-06-23 20:38:20.189212
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    provider.cpf()

# Generated at 2022-06-23 20:38:23.506013
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:38:26.891877
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(0, 100):
        rnd = BrazilSpecProvider().cpf()
        print(rnd)
        assert isinstance(rnd, str)
        assert len(rnd) == 14


# Generated at 2022-06-23 20:38:32.857062
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()
    cnpj = bp.cnpj()

    # Check length
    assert len(cnpj) == 18
    assert len(bp.cnpj(with_mask=False)) == 14

    # Check digits are ok
    first_part = cnpj[:12]

    # Sum of the first twelve digits
    first_sum = sum([int(first_part[i]) * (13 - i) for i in range(12)])

    digit_1 = (first_sum % 11) % 10
    assert int(cnpj[12]) == digit_1

    second_part = cnpj[:13]

    # Sum of the first thirteen digits
    second_sum = sum([int(second_part[i]) * (14 - i) for i in range(13)])

   

# Generated at 2022-06-23 20:38:37.908680
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""

    # Create instance of BrazilSpecProvider class
    provider = BrazilSpecProvider()

    # Check if method retunrs correct CPF
    cpf_test = provider.cpf()
    assert len(cpf_test) == 14
    assert cpf_test[3] == '.'
    assert cpf_test[7] == '.'
    assert cpf_test[11] == '-'

    # Check if method retunrs correct CPF without mask
    cpf_test = provider.cpf(False)
    assert len(cpf_test) == 11


# Generated at 2022-06-23 20:38:43.312280
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BR = BrazilSpecProvider()
    num = BR.cnpj(with_mask=False)
    assert len(num) == 14
    assert num[0:2] == '77'
    assert num[2] == '.'
    assert num[5] == '.'
    assert num[8] == '/'
    assert num[12] == '-'


# Generated at 2022-06-23 20:38:45.619553
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf() is not None
    assert brazil.cnpj() is not None

# Generated at 2022-06-23 20:38:47.920358
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == '006.081.150-95'



# Generated at 2022-06-23 20:38:51.329983
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    test_array = [provider.cnpj(), len(provider.cnpj())]
    assert test_array == [True, 18], 'test_BrazilSpecProvider_cnpj() failed'


# Generated at 2022-06-23 20:38:54.937179
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected_result = '829.127.404-32'
    result = BrazilSpecProvider().cpf()
    assert result == expected_result

    expected_result = '82912743932'
    result = BrazilSpecProvider().cpf(with_mask=False)
    assert result == expected_result


# Generated at 2022-06-23 20:38:57.310105
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    #cpf_ = br.cpf()
    cpf_ = br.cpf()
    print(cpf_)


# Generated at 2022-06-23 20:39:07.608066
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=False) == '63612063000139'
    assert provider.cnpj(with_mask=False) == '89333813000113'
    assert provider.cnpj(with_mask=False) == '39684429000152'
    assert provider.cnpj(with_mask=False) == '81585418000150'
    assert provider.cnpj(with_mask=False) == '50761091000194'
    assert provider.cnpj(with_mask=False) == '84889487000103'
    assert provider.cnpj(with_mask=False) == '05758546000155'

# Generated at 2022-06-23 20:39:10.386492
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:39:16.459159
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=400)
    # test cpf
    assert provider.cpf(with_mask=True) == '746.691.879-78'
    assert provider.cpf(with_mask=False) == '74669187978'
    # test cnpj
    assert provider.cnpj(with_mask=True) == '65.706.209/0004-91'
    assert provider.cnpj(with_mask=False) == '65706209000491'

# Generated at 2022-06-23 20:39:18.823954
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    assert len(brazil.cnpj()) == 18


# Generated at 2022-06-23 20:39:22.490331
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cpf()."""
    bsp = BrazilSpecProvider()
    cpf = bsp.cnpj()
    assert bsp.cnpj(with_mask=False) == cpf.replace('.', '').replace('/', '').replace('-', '')


# Generated at 2022-06-23 20:39:25.083368
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for BrazilSpecProvider class."""
    provider = BrazilSpecProvider()
    assert provider.cpf() == '728.946.704-94'
    assert provider.cnpj() == '97.962.082/0001-52'

# Generated at 2022-06-23 20:39:27.658414
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cnpj() == '80.335.468/0001-20'
    assert BrazilSpecProvider().cnpj(with_mask=False) == '80335468000120'


# Generated at 2022-06-23 20:39:28.852429
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == "45.907.233/0001-96"


# Generated at 2022-06-23 20:39:32.600206
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()

    assert brazil.cpf() == '034.828.701-50'
    assert brazil.cnpj() == '63.267.896/0001-42'

    assert brazil.cpf(with_mask=False) == '03482870150'
    assert brazil.cnpj(with_mask=False) == '63267896000142'

# Generated at 2022-06-23 20:39:35.296923
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BrazilSpecProvider(seed=7).cnpj() #Returns 313.934.938/0001-10

# Generated at 2022-06-23 20:39:40.490689
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf()."""
    from mimesis.enums import Gender

    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()

    assert len(cpf) == 14
    assert bsp.cpf(with_mask=False) == bsp.cpf()[:3] + \
        bsp.cpf()[4:7] + bsp.cpf()[8:11] + bsp.cpf()[12:]


# Generated at 2022-06-23 20:39:45.844182
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    assert type(obj.cpf()) is str
    assert len(obj.cpf()) is 14
    assert type(obj.cpf(True)) is str
    assert len(obj.cpf(True)) is 14
    assert type(obj.cpf(False)) is str
    assert len(obj.cpf(False)) is 11


# Generated at 2022-06-23 20:39:49.585575
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj=BrazilSpecProvider()
    assert obj.cnpj() == "77.732.230/0001-70" , "Method cnpj should return '77.732.230/0001-70' "

# Generated at 2022-06-23 20:39:58.527263
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    # create an instance 'person' of the class BrazilSpecProvider
    person = Person('pt-br')
    # create a seed for the random generator
    seed = person._seed.generate()
    # create a new instance 'brazil_provider' of the class BrazilSpecProvider
    brazil_provider = BrazilSpecProvider(seed)
    # create two instances ('man', 'woman') of the class Person
    man = Person('pt-br')
    woman = Person('pt-br', gender=Gender.FEMALE)

    # set the seed 'seed' to the instances 'man' and 'woman' of the class Person
    man.seed(seed)
    woman.seed(seed)

    # create a new instance of the class Person (new

# Generated at 2022-06-23 20:40:00.272983
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '64.052.879/0001-58'



# Generated at 2022-06-23 20:40:02.625234
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14
    assert len(bsp.cpf(False)) == 11


# Generated at 2022-06-23 20:40:07.060167
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_cnpj = BrazilSpecProvider()
    cnpj = test_cnpj.cnpj()
    assert len(str(cnpj)) == 18
    assert str(cnpj)[2] == "."
    assert str(cnpj)[6] == "."
    assert str(cnpj)[10] == "/"
    assert str(cnpj)[15] == "-"



# Generated at 2022-06-23 20:40:08.994557
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()
    cpf = bp.cpf()
    assert len(cpf) == 14
    assert isinstance(cpf, str)



# Generated at 2022-06-23 20:40:13.277279
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test without mask in fpf
    provider = BrazilSpecProvider()
    fpf = provider.cpf(with_mask=False)
    assert len(fpf) == 11
    # Test with mask in fpf
    fpf = provider.cpf(with_mask=True)
    assert len(fpf) == 14
    assert fpf[3] == "."
    assert fpf[7] == "."
    assert fpf[11] == "-"
    assert fpf[-2:] != "00"


# Generated at 2022-06-23 20:40:19.483797
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider(seed=123)
    assert brazil_provider.cpf(False) == "16073406520"
    assert brazil_provider.cnpj(False) == "95729609000176"
    assert brazil_provider.cpf() == "160.734.065-20"
    assert brazil_provider.cnpj() == "95.729.609/0001-76"

# Generated at 2022-06-23 20:40:21.934001
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test to test the constructor of class."""
    br = BrazilSpecProvider()
    assert br != None


# Generated at 2022-06-23 20:40:22.943574
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()



# Generated at 2022-06-23 20:40:29.904824
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Setup
    from mimesis.enums import Gender

    # Exercise
    p = BrazilSpecProvider()

    # Verify
    assert p
    assert isinstance(p, BrazilSpecProvider)
    assert p.meta.name == 'brazil_provider'
    assert p.meta.gender == Gender.NEUTRAL
    assert p.meta.code == 'pt-br'
    assert p.meta.provides == 'Brazil'



# Generated at 2022-06-23 20:40:34.978513
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test random cnpj
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    print('cnpj', cnpj)
    assert len(cnpj) == 18
    # Test that with_mask works
    cnpj_masked = bsp.cnpj(True)
    print('cnpj_masked', cnpj_masked)
    assert len(cnpj_masked) == 18

# Generated at 2022-06-23 20:40:37.629830
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '997.767.323-12'
    assert BrazilSpecProvider().cpf(with_mask=False) == '99776232312'


# Generated at 2022-06-23 20:40:42.124219
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()

    for _ in range(5):
        cpf = bsp.cpf()
        assert len(cpf) == 14
        assert cpf[3] == '.'
        assert cpf[7] == '.'
        assert cpf[11] == '-'

    for _ in range(5):
        cpf = bsp.cpf(with_mask=False)
        assert len(cpf) == 11



# Generated at 2022-06-23 20:40:42.918078
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert cnpj != None

# Generated at 2022-06-23 20:40:44.621430
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    s = provider.cpf()
    assert len(s) == 14
    assert provider.cpf(False) == s[:9] + s[10:]
    assert provider.cpf(True) == s


# Generated at 2022-06-23 20:40:53.081129
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.brazil import BrazilSpecProvider

    p = Person('pt-br')
    b = BrazilSpecProvider()

    c = b.cnpj()
    if len(c) != 18:
        raise ValueError("cnpj is not 18 characters")
    if b.cnpj(with_mask=False) != c:
        raise ValueError("cnpj without the mask does not match")


# Generated at 2022-06-23 20:40:55.412689
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider().cpf()
    assert type(bsp) == str
    assert len(bsp) == 14  # With mask


# Generated at 2022-06-23 20:40:58.141146
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""

    prov = BrazilSpecProvider()
    cpf_without_mask = prov.cpf(with_mask=False)
    assert len(cpf_without_mask) == 11



# Generated at 2022-06-23 20:40:59.105325
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    print(bsp.cnpj())

# Generated at 2022-06-23 20:41:02.057769
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf[3: ] == '.' + cpf[3: 6] + '.' + cpf[6: 9] + '-' + cpf[9: ]


# Generated at 2022-06-23 20:41:06.864721
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of class BrazilSpecProvider."""
    from mimesis.providers.brazil.brazil import BrazilSpecProvider
    from datetime import datetime
    provider = BrazilSpecProvider(datetime.now())
    provider.cnpj()

# Generated at 2022-06-23 20:41:11.836856
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.' and cnpj[6] == '.' and cnpj[10] == '/' and cnpj[15] == '-'

# Generated at 2022-06-23 20:41:17.854914
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.base import BaseProvider
    from mimesis.specifiers import BrazilSpecProvider
    brazil = BrazilSpecProvider()
    base_provider = BaseProvider()
    for cnpj in range(0, 10):
        cnpj = brazil.cnpj(with_mask=False)
        base_provider.validate_cnpj(cnpj)
        

# Generated at 2022-06-23 20:41:18.627341
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    cpf = obj.cpf()
    print(cpf)



# Generated at 2022-06-23 20:41:20.867293
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cp = BrazilSpecProvider()
    assert len(cp.cnpj()) == 18
    assert len(cp.cnpj(False)) == 14

# Generated at 2022-06-23 20:41:22.554979
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Test Seed class
    BrazilSpecProvider(seed=1)


# Generated at 2022-06-23 20:41:24.333011
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert brazil.cnpj() == "92.145.921/0001-62"


# Generated at 2022-06-23 20:41:29.179790
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilProvider
    from mimesis.enums import Gender
    print("Unit test for method cnpj of class BrazilSpecProvider")
    brazil = BrazilProvider(None)
    assert(brazil.cnpj() != brazil.cnpj())


# Generated at 2022-06-23 20:41:32.648337
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test case to verify if the generated CPF is equal to the expected
    generated_cpf = BrazilSpecProvider().cpf(False)
    assert generated_cpf == "75186308734", "Generated CPF should be 75186308734"


# Generated at 2022-06-23 20:41:35.978098
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.__class__.__name__ == 'BrazilSpecProvider'


# Generated at 2022-06-23 20:41:38.005588
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert brazil.cnpj()


# Generated at 2022-06-23 20:41:39.409243
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider.cpf()
    assert cpf


# Generated at 2022-06-23 20:41:40.341892
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-23 20:41:47.959752
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider(seed=13).cnpj() == '60.346.931/0001-80'
    assert BrazilSpecProvider(seed=77).cnpj() == '75.484.020/0001-37'
    assert BrazilSpecProvider(seed=220).cnpj() == '51.773.873/0001-09'
    assert BrazilSpecProvider(seed=80).cnpj() == '34.818.414/0001-00'
    assert BrazilSpecProvider(seed=999).cnpj() == '61.866.190/0001-15'


# Generated at 2022-06-23 20:41:52.695811
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test a random CPF."""
    from mimesis.providers.pt_br.brazil_provider import BrazilSpecProvider
    cpf = BrazilSpecProvider().cpf(with_mask=True)
    assert isinstance(cpf, str)
    assert len(cpf) == 14


# Generated at 2022-06-23 20:41:56.753858
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14
    assert bsp.cpf() == '431.766.808-11'
    assert bsp.cpf(with_mask=False) == '43176680811'

# Generated at 2022-06-23 20:41:58.235401
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Todo:
    # write test code here
    # assert method == expected
    pass

# Generated at 2022-06-23 20:41:59.980380
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    doc = provider.cnpj()
    assert "" != doc


# Generated at 2022-06-23 20:42:01.170859
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() != None


# Generated at 2022-06-23 20:42:04.291122
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_obj = BrazilSpecProvider()
    for i in range(100):
        assert len(test_obj.cnpj(with_mask=True)) == 18


# Generated at 2022-06-23 20:42:06.109848
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-23 20:42:09.011434
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    bp = BrazilSpecProvider()
    assert len(bp.cpf()) == 14

    bp2 = BrazilSpecProvider()
    assert bp.cpf(with_mask=False) != bp2.cpf(with_mask=False)

    bp3 = BrazilSpecProvider()
    assert len(bp3.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:42:12.444798
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider(seed=42)
    assert brazil_provider.cnpj() == '518.091.528-2811'


# Generated at 2022-06-23 20:42:15.354252
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    print(bsp.cpf())
    print(bsp.cnpj())

# Generated at 2022-06-23 20:42:16.336239
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    x = BrazilSpecProvider()


# Generated at 2022-06-23 20:42:21.704843
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf_generated = bsp.cpf(with_mask=False)

    assert len(cpf_generated) == 11
    assert cpf_generated[3] == "."
    assert cpf_generated[7] == "."
    assert cpf_generated[11] == "-"


# Generated at 2022-06-23 20:42:23.256782
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider()
    print(cpf.cpf())


# Generated at 2022-06-23 20:42:27.068261
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '031.291.436-32'
    assert BrazilSpecProvider().cpf(False) == '03129143632'


# Generated at 2022-06-23 20:42:28.507502
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider) == True

# Generated at 2022-06-23 20:42:35.321912
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    pattern = r'\d{3}[\.-]?\d{3}[\.-]?\d{3}[-]?\d{2}'

    brazilSpecProvider = BrazilSpecProvider(seed=2)
    list_random_cpf = [brazilSpecProvider.cpf() for _ in range(100)]

    print('\nMethod cpf')
    print('='*10)
    print(list_random_cpf)

    for cpf in list_random_cpf:
        assert re.match(pattern, cpf)


# Generated at 2022-06-23 20:42:40.507362
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf == '383.016.295-89'
    cpf = provider.cpf(with_mask=False)
    assert cpf == '38301629589'


# Generated at 2022-06-23 20:42:42.719758
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:42:46.465771
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=42)
    assert repr(provider) == 'BrazilSpecProvider(seed=None)'
    assert str(provider) == 'BrazilSpecProvider'
    assert provider.__doc__ == 'Class that provides special data for Brazil (pt-br).'


# Generated at 2022-06-23 20:42:50.339893
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    braz_provider = BrazilSpecProvider()
    braz_provider.cpf()
if __name__ == "__main__":
    test_BrazilSpecProvider_cpf()

# Generated at 2022-06-23 20:42:53.035451
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=42).__init__()
    BrazilSpecProvider(seed=42).cpf()
    BrazilSpecProvider(seed=42).cnpj()

# Generated at 2022-06-23 20:42:57.186138
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test if cpf method return valid data"""
    bs = BrazilSpecProvider()
    cpf = bs.cpf()

    result = cpf[0:3] + cpf[4:7] + cpf[8:11] + cpf[12:14]
    result = int(result)

    assert 0 < result < 99999999999

# Generated at 2022-06-23 20:42:59.927418
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.generators.finance import Finance
    finance = Finance()
    print(finance.cpf())

# Generated at 2022-06-23 20:43:03.236807
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    pass

# Generated at 2022-06-23 20:43:07.244790
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider"""

    from mimesis.providers.brasil import BrazilSpecProvider
    test_cnpj = '77.732.230/0001-70'

    assert(BrazilSpecProvider().cnpj() == test_cnpj)

# Generated at 2022-06-23 20:43:10.495849
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj1 = BrazilSpecProvider().cnpj(with_mask=False)
    cnpj2 = BrazilSpecProvider().cnpj(with_mask=False)
    assert cnpj1 != cnpj2


# Generated at 2022-06-23 20:43:13.172028
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert 12 == len(BrazilSpecProvider().cnpj(False))
    assert 14 == len(BrazilSpecProvider().cnpj(True))


# Generated at 2022-06-23 20:43:13.702435
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=1)


# Generated at 2022-06-23 20:43:15.299122
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    loc = BrazilSpecProvider()
    m = loc.cnpj()
    assert m


# Generated at 2022-06-23 20:43:21.537226
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test para verificação de validade e format do cpf."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    person = Person('pt_BR')

    bsp = BrazilSpecProvider()
    bsp.seed(1)

    # Verificação do format do cpf
    assert bsp.cpf() == '002.035.801-21'
    # Verificação do format do cpf
    assert bsp.cpf(with_mask=False) == '00203580121'
    # Verificação da validade do cpf (Verificação de dígito verificador)
    cpf = person.cpf(with_mask=False)
    assert bsp.validate_cpf(cpf)

# Generated at 2022-06-23 20:43:22.553922
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    pass


# Generated at 2022-06-23 20:43:24.562743
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf()
    assert brazil.cnpj()

# Generated at 2022-06-23 20:43:26.234802
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    parsed = BrazilSpecProvider().cnpj(True)
    assert type(parsed) == str

# Generated at 2022-06-23 20:43:29.528465
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert 'BrazilSpecProvider' == brazil.Meta.name
    assert 'BrazilSpecProvider' == brazil.__repr__()


# Generated at 2022-06-23 20:43:31.943073
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    prov = BrazilSpecProvider()
    assert(prov.cpf(False) == prov.cpf(True).replace(".", "").replace("-", ""))



# Generated at 2022-06-23 20:43:35.825255
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj is not None

    cnpj_with_mask = provider.cnpj(with_mask=True)
    assert len(cnpj_with_mask) == 18
    assert cnpj_with_mask is not None

# Generated at 2022-06-23 20:43:39.044288
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    for i in range(100):
        cnpj = provider.cnpj(with_mask=False)
        assert len(cnpj) == 14



# Generated at 2022-06-23 20:43:49.015860
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider.cnpj"""
    # pylint: disable=protected-access

# Generated at 2022-06-23 20:43:53.538775
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider(seed=123)
    cpf = brazilSpecProvider.cpf(with_mask=True)
    cnpj = brazilSpecProvider.cnpj(with_mask=True)
    assert cpf == "818.300.731-77"
    assert cnpj == "78.944.045/0001-79"

# Generated at 2022-06-23 20:43:59.653192
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for BrazilSpecProvider - method cpf."""
    bsp = BrazilSpecProvider(seed=1234567890)
    assert bsp.cpf() == '738.599.207-95'
    assert bsp.cpf(False) == '73859920795'

    bsp = BrazilSpecProvider(seed=9876543210)
    assert bsp.cpf() == '715.428.670-66'
    assert bsp.cpf(False) == '71542867066'



# Generated at 2022-06-23 20:44:03.380471
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test class BrazilSpecProvider."""
    brazil = BrazilSpecProvider(seed=31230)
    assert brazil.cnpj(True) == '03.560.911/0001-17'
    assert brazil.cnpj(False) == '03560911000117'



# Generated at 2022-06-23 20:44:06.038062
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Verify CNPJ returns a valid CNPJ."""
    provider = BrazilSpecProvider(seed=0)
    result = provider.cnpj()
    assert result == '44.644.100/0001-64'


# Generated at 2022-06-23 20:44:08.537953
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    instance = BrazilSpecProvider()
    assert instance.cpf() == '907.740.521-17'


# Generated at 2022-06-23 20:44:10.167104
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    exp_cnpj = '77.732.230/0001-70'

    assert BrazilSpecProvider().cnpj() == exp_cnpj



# Generated at 2022-06-23 20:44:13.703346
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf()) == 14
    assert len(brazil.cpf(with_mask=False)) == 11
    assert len(brazil.cpf()) == 14
    assert len(brazil.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:44:17.263342
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    assert len(BrazilSpecProvider().cnpj())==18
    assert BrazilSpecProvider().cnpj().endswith('-00')

# Generated at 2022-06-23 20:44:21.152906
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """."""
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:44:22.997561
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()
    assert p.cpf()
    assert p.cpf(False)
    assert p.cnpj()
    assert p.cnpj(False)

# Generated at 2022-06-23 20:44:24.684447
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    result = bsp.cpf()
    print(result)


# Generated at 2022-06-23 20:44:29.892472
# Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-23 20:44:34.880690
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brutus = BrazilSpecProvider()
    cpf = brutus.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:44:36.630268
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:44:38.139918
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider()
    print(a.cnpj())

# Generated at 2022-06-23 20:44:40.420255
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj()

# Generated at 2022-06-23 20:44:45.375605
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
	p = BrazilSpecProvider()
	assert len(p.cnpj()) == 18
	assert len(p.cnpj(with_mask=False)) == 14
	assert len(p.cnpj(with_mask=True)) == 18


# Generated at 2022-06-23 20:44:45.995263
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    b.cpf()

# Generated at 2022-06-23 20:44:48.948892
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test = BrazilSpecProvider()
    test.seed = '42'
    # assert test.seed == '42'
    # assert test.__dict__.get('seed') == '42'
    # print("test_BrazilSpecProvider: success")


# Generated at 2022-06-23 20:44:51.029613
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 18


# Generated at 2022-06-23 20:44:54.496514
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider constructor."""
    # pylint: disable=W0212
    # pylint: disable=protected-access
    bsp = BrazilSpecProvider()
    assert(bsp._locale == 'pt-br')
    assert('BrazilSpecProvider' in repr(bsp))

# Generated at 2022-06-23 20:44:56.643579
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider is not None, "Failed to initialize a " \
                                 "BrazilSpecProvider object"

# Generated at 2022-06-23 20:45:00.593923
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    generated_cnpj = brazil_provider.cnpj()
    assert len(generated_cnpj) == 18
    assert type(generated_cnpj) == str
    assert generated_cnpj[2] == '.'
    assert generated_cnpj[6] == '.'
    assert generated_cnpj[10] == '/'
    assert generated_cnpj[15] == '-'
    assert generated_cnpj[2:3] != generated_cnpj[3:4]
    assert generated_cnpj[6:7] != generated_cnpj[7:8]
    assert generated_cnpj[10:11] != generated_cnpj[11:12]
    assert generated_cnpj[15:16] != generated_

# Generated at 2022-06-23 20:45:08.837353
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Verify the cnpj format"""
    for _ in range(100):
        cnpj = BrazilSpecProvider().cnpj()
        assert len(cnpj) == 18
        assert '.' in cnpj
        assert('-' in cnpj)
        assert '/' in cnpj
        assert cnpj[2] == '.'
        assert cnpj[6] == '.'
        assert cnpj[10] == '/'
        assert cnpj[15] == '-'
        assert cnpj[:15].replace('.', '').replace('-', '').replace('/', '').isdigit()
        assert cnpj[15:].isdigit()



# Generated at 2022-06-23 20:45:15.004466
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj(with_mask)."""
    g = BrazilSpecProvider()
    result = g.cnpj(True)
    assert len(result) == len("88.843.863/0001-16")
    assert result.find(".") == 2
    assert result.find("/") == 6
    assert result.find("-") == 12


# Generated at 2022-06-23 20:45:17.090700
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:45:20.037788
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider(seed=55)
    assert brazilSpecProvider.cpf() == "871.110.540-58"

# Generated at 2022-06-23 20:45:24.294330
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert len(brazil.cnpj()) == 18
    assert len(brazil.cnpj(with_mask=False)) == 14


# Generated at 2022-06-23 20:45:25.318965
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    fake = BrazilSpecProvider().cnpj()
    print(fake)
    return



# Generated at 2022-06-23 20:45:27.824776
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert isinstance(b.cnpj(False), str)
    assert isinstance(b.cnpj(True), str)


# Generated at 2022-06-23 20:45:29.288542
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-23 20:45:31.784546
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)


# Generated at 2022-06-23 20:45:34.291530
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    result = BrazilSpecProvider().cnpj(True)
    assert result
    assert len(result) == len('77.732.230/0001-70')


# Generated at 2022-06-23 20:45:36.881260
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)
    assert provider.cpf() is not None
    assert provider.cnpj() is not None

# Generated at 2022-06-23 20:45:38.416203
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    f = BrazilSpecProvider()
    #print(f)
    #print(f.cpf())
    #print(f.cnpj())
    pass

# Generated at 2022-06-23 20:45:39.655760
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()
    assert br.cpf() != None
    assert br.cnpj() != None

# Generated at 2022-06-23 20:45:49.725528
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Create a object of class BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()
    # Create a CNPJ
    cnpj = brazil_spec_provider.cnpj()
    # Create a CPF
    cpf = brazil_spec_provider.cpf()
    # Asserts
    assert len(cnpj) == 18
    assert len(cpf) == 14
    assert str(cnpj).count('.') == 2
    assert str(cpf).count('.') == 2
    assert str(cnpj).count('/') == 1
    assert str(cpf).count('-') == 1
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnp

# Generated at 2022-06-23 20:45:53.063259
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cnpj() == '84.051.545/0001-23'


# Generated at 2022-06-23 20:45:55.777419
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Testing the cnpj method"""
    brazil = BrazilSpecProvider()
    print(brazil.cnpj())


# Generated at 2022-06-23 20:46:04.652842
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.builtins.brazil import BrazilSpecProvider
    # create object BrazilSpecProvider
    brazil = BrazilSpecProvider(BrazilSpecProvider)
	#Create object Datetime
    datetime = Datetime(BrazilSpecProvider)
	#Create object Gender
    gender = Gender(BrazilSpecProvider)
    teste=brazil.cnpj(with_mask=True)
    print('cnpj:',teste)
    data=brazil.birthday(
                start=datetime.date(1970, 1, 1),
                end=datetime.date(2020, 1, 1),
                fmt='%Y-%m-%d',
                g=gender.gender())
    print('birthday:',data)


# Generated at 2022-06-23 20:46:14.039177
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Test with type Seed
    first_test = BrazilSpecProvider(seed=12345678)
    assert(first_test.cnpj() == '83.917.069/0001-10')
    assert(first_test.cpf() == '878.513.972-50')
    assert(first_test.cnpj() == '83.917.069/0001-10')
    assert(first_test.cpf() == '878.513.972-50')
    assert(first_test.cnpj(True) == '83.917.069/0001-10')
    assert(first_test.cpf(True) == '878.513.972-50')
    assert(first_test.cnpj() == '83.917.069/0001-10')

# Generated at 2022-06-23 20:46:15.450601
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider != None, 'BrazilSpecProvider isn\'t created'

# Generated at 2022-06-23 20:46:16.070493
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=None)

# Generated at 2022-06-23 20:46:19.442470
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    for _ in range(1000):
        cnpj = provider.cnpj()
        assert(len(cnpj) == 18)
        assert(cnpj.startswith('77'))

# Generated at 2022-06-23 20:46:22.780234
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers import BrazilSpecProvider
    provider = BrazilSpecProvider()
    for _ in range(0, 10):
        cnpj_test = provider.cnpj()
        assert (len(cnpj_test) == 18) and (cnpj_test.count('') == 2) and (cnpj_test[-2:].count('-') == 1)


# Generated at 2022-06-23 20:46:24.603200
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()

# Generated at 2022-06-23 20:46:25.734631
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.__class__.__name__ == "BrazilSpecProvider"


# Generated at 2022-06-23 20:46:27.444156
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf(False) == '34925910987'
    assert provider.cpf(True) == '349.259.109-87'


# Generated at 2022-06-23 20:46:30.306334
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert isinstance(obj, BrazilSpecProvider)
    assert isinstance(obj.random, Seed)
    assert isinstance(obj.datetime, Seed)



# Generated at 2022-06-23 20:46:34.300389
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    _BrazilSpecProvider = BrazilSpecProvider() 
    _cnpj = _BrazilSpecProvider.cnpj()
    assert(len(_cnpj) == 18)
    assert(_cnpj.isnumeric())


# Generated at 2022-06-23 20:46:40.502642
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender

    print(BrazilSpecProvider().cpf())
    print(BrazilSpecProvider().cpf(with_mask=False))

    # These work too
    print(BrazilSpecProvider(seed=10).cpf())
    print(BrazilSpecProvider(seed=20).cpf(with_mask=False))


# Generated at 2022-06-23 20:46:44.068255
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    
    # Checking the length of the generated cnpj
    assert len(cnpj) == 18 and cnpj != '00000000000000'


# Generated at 2022-06-23 20:46:45.611787
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    print('Cpf:', brazil.cpf())


# Generated at 2022-06-23 20:46:47.137623
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '097.641.842-10'


# Generated at 2022-06-23 20:46:57.811481
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider, USASpecProvider
    test = BrazilSpecProvider()
    test_r = RussiaSpecProvider()
    test_u = USASpecProvider()
    print(test.cnpj())
    print(test.cnpj())
    print(test.cnpj())
    print(test.cnpj())
    print(test.cnpj())
    print(test_r.patronymic('male', Gender.MALE))
    print(test_r.patronymic('female', Gender.MALE))
    print(test_u.social_security_number())

# Generated at 2022-06-23 20:46:59.123026
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    b.cnpj()
    b.cpf()

# Generated at 2022-06-23 20:47:01.296750
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_cnpj = BrazilSpecProvider()
    assert brazil_cnpj.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:47:04.868655
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    print(bsp.cnpj())
    print(bsp.cnpj(False))


# Generated at 2022-06-23 20:47:08.758810
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method BrazilSpecProvider.cnpj."""
    c = BrazilSpecProvider()
    cnpj = c.cnpj()
    assert(len(cnpj) == 18)


# Generated at 2022-06-23 20:47:11.296399
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_obj = BrazilSpecProvider(seed=42)
    assert test_obj.cpf(seed=42) is not None
    assert test_obj.cnpj(seed=42) is not None