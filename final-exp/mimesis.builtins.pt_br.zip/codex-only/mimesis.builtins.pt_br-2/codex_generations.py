

# Generated at 2022-06-23 20:37:17.877649
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider class."""
    seed = 4

    cpf_mask = '202.648.570-66'
    cpf_without_mask = '202642857066'

    cnpj_mask = '31.187.000/0001-52'
    cnpj_without_mask = '3118700000152'

    spec = BrazilSpecProvider(seed)

    assert seed == spec._seed
    assert cpf_mask == spec.cpf()
    assert cpf_without_mask == spec.cpf(with_mask=False)
    assert cnpj_mask == spec.cnpj()
    assert cnpj_without_mask == spec.cnpj(with_mask=False)

# Generated at 2022-06-23 20:37:19.511571
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14


# Generated at 2022-06-23 20:37:22.906613
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    c = b.cpf()
    assert bool(c) is True

# Generated at 2022-06-23 20:37:24.095506
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().provider  == 'brazil_provider'

# Generated at 2022-06-23 20:37:29.868049
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # This function is used to test the cnpj method of the class BrazilSpecProvider.
    # This function compares the last 2 digits of the cnpj obtained with the mask and without the mask

    # Arrange
    brazil = BrazilSpecProvider()

    # Act

    cnpj_with_mask = brazil.cnpj()
    number = int(cnpj_with_mask[-2:])
    cnpj_without_mask = brazil.cnpj(False)
    
    # Assert
    assert int(cnpj_without_mask) == number


# Generated at 2022-06-23 20:37:37.120940
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("test_BrazilSpecProvider")
    provider = BrazilSpecProvider()
    # test method cpf
    assert provider.cpf() == provider.cpf(with_mask=False)
    assert len(provider.cpf()) == 14
    # test method cnpj
    assert provider.cnpj() == provider.cnpj(with_mask=False)
    assert len(provider.cnpj()) == 18

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:37:41.677542
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf."""
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    cpf = int(cpf[:3] + cpf[4:7] + cpf[8:11] + cpf[12:])
    assert cpf > 0


# Generated at 2022-06-23 20:37:51.711701
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print ("\n")
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    print (provider.cpf())
    cnpj = provider.cnpj(True)
    print (provider.cnpj(True))
    print (cpf)
    print (cnpj)


# Generated at 2022-06-23 20:37:53.954571
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    print(cnpj)
    cnpj = BrazilSpecProvider().cnpj(with_mask=False)
    print(cnpj)



# Generated at 2022-06-23 20:37:56.010729
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Tests constructor of class BrazilSpecProvider"""
    brazil = BrazilSpecProvider()
    assert brazil != None


# Generated at 2022-06-23 20:38:00.350347
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for item in range(1, 100):
        cnpj_number = BrazilSpecProvider().cnpj()
        assert len(cnpj_number) == 18
        assert cnpj_number[2] == '.'
        assert cnpj_number[6] == '.'
        assert cnpj_number[10] == '/'
        assert cnpj_number[15] == '-'



# Generated at 2022-06-23 20:38:09.784367
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider as BrazilBuiltIn
    import re
    # Unit test for the method cnpj of the class BrazilSpecProvider
    bzprovider = BrazilSpecProvider()
    bzbuiltin = BrazilBuiltIn()
    # Test method cnpj with the parameter with_mask = True
    for _ in range(100):
        cnpj = bzprovider.cnpj()
        assert isinstance(cnpj, str)
        assert len(cnpj) == 18
        cnpj = cnpj.replace('.','').replace('/','').replace('-','')
        assert len(cnpj) == 14

# Generated at 2022-06-23 20:38:11.903761
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    br = BrazilSpecProvider()
    assert br.cpf().isdigit()
    assert br.cnpj().isdigit()

# Generated at 2022-06-23 20:38:19.739581
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.providers.date import Date
    p = Person('pt-br', seed=42)
    assert p.cnpj() == '31.847.097/0001-77'
    p = Person('pt-br')
    assert p.cnpj(with_mask=False) == '12171603000130'
    p = Person('pt-br', gender=Gender.FEMALE, seed=42)
    assert p.cpf() == '374.832.893-08'
    p = Person('pt-br', gender=Gender.FEMALE)
    assert p.cpf(with_mask=False) == '13272399999'
    d = Date('pt-br')


# Generated at 2022-06-23 20:38:26.890492
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import Mimesis

    mimesis = Mimesis('pt-br')
    assert len(mimesis.cnpj()) == 18
    assert len(mimesis.cnpj(False)) == 14
    # 54.873.630/0001-21
    assert len(mimesis.cnpj()) == 18
    assert type(mimesis.cnpj(False)) == str
    assert len(mimesis.cnpj(False)) == 14
    assert type(mimesis.cnpj(True)) == str
    assert len(mimesis.cnpj(True)) == 18

if __name__ == "__main__":
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-23 20:38:30.839840
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_cpf = BrazilSpecProvider()
    assert len(brazil_cpf.cpf()) == 14
    assert len(brazil_cpf.cpf(False)) == 11
    for _ in range(10):
        assert brazil_cpf.cpf() != brazil_cpf.cpf(False)


# Generated at 2022-06-23 20:38:37.558811
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    test = BrazilSpecProvider(seed = 42)
    assert test.full_name(gender=Gender.MALE) == 'Ricardo Costa Vieira'
    test.seed_ = 43
    assert test.full_name(gender=Gender.FEMALE) == 'Fatima Marques Siqueira'
    assert test.cnpj(with_mask=True) == '77.732.230/0001-70'
    assert test.cpf(with_mask=True) == '001.137.297-40'
    test.seed_ = None
    assert test.full_name(gender= Gender.MALE) != 'Ricardo Costa Vieira'
    assert test.full_name(gender=Gender.FEMALE) != 'Fatima Marques Siqueira'

# Generated at 2022-06-23 20:38:43.692034
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    b = BrazilSpecProvider(seed=42)

    assert b.cpf() == '001.137.297-40'

    # Unit test for method cpf of class BrazilSpecProvider with Mask
    assert b.cpf(with_mask=True) == '001.137.297-40'

    assert b.cpf(with_mask=False) == '001.137.297-40'


# Generated at 2022-06-23 20:38:47.293148
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask = True) == '77.732.230/0001-70'
    assert provider.cpf(with_mask = True) == '001.137.297-40'

test_BrazilSpecProvider()

# Generated at 2022-06-23 20:38:50.723868
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.specifiers import BrazilSpecProvider

    bsp = BrazilSpecProvider()
    resultado = bsp.cnpj()
    assert len(resultado) > 0
    assert len(resultado) == 18


# Generated at 2022-06-23 20:38:51.266405
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:38:53.359085
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    prov = BrazilSpecProvider()
    assert prov.cnpj() == '10.738.176/0001-06'

# Generated at 2022-06-23 20:38:55.961498
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(False)
    assert len(cnpj) == 14
    assert cnpj.isdigit()
    print(cnpj)


# Generated at 2022-06-23 20:39:06.123102
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the cnpj method of class BrazilSpecProvider."""
    from mimesis.enums import Gender
    pr = BrazilSpecProvider()
    cnpj = pr.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] != '.'
    assert cnpj[6] != '.'
    assert cnpj[10] != '/'
    assert cnpj[15] != '-'
    assert cnpj[14] == cnpj[17]
    assert cnpj[13] == cnpj[16]

    # Test number generated
    # cnpj = '77.732.230/0001-70'
    assert cnpj == '77.732.230/0001-70'


# Generated at 2022-06-23 20:39:10.014141
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    mimesis_pt_br = BrazilSpecProvider()
    mimesis_pt_br.cnpj(True)
    mimesis_pt_br.cnpj(False)


# Generated at 2022-06-23 20:39:13.656410
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert provider.cpf() != provider.cpf()


# Generated at 2022-06-23 20:39:15.219329
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider"""
    BrazilSpecProvider()


# Generated at 2022-06-23 20:39:19.626833
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    for i in range(0, 100):
        cnpj = brazil.cnpj()
        assert len(cnpj) == 18
        #assert type(cnpj) is unicode
        #assert type(cnpj) is str
        assert type(cnpj) is str

# Generated at 2022-06-23 20:39:20.425911
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    with BrazilSpecProvider() as brasil:
        assert brasil


# Generated at 2022-06-23 20:39:25.790913
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    # Test the CPF with the mask (dots and hyphen)
    cpf_with_mask = brazil_provider.cpf()
    assert len(cpf_with_mask) == 14
    assert '-' in cpf_with_mask
    assert '.' in cpf_with_mask
    # Test the CPF without the mask (dots and hyphen)
    cpf_without_mask = brazil_provider.cpf(with_mask=False)
    assert len(cpf_without_mask) == 11
    assert '-' not in cpf_without_mask
    assert '.' not in cpf_without_mask


# Generated at 2022-06-23 20:39:28.424244
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()

    # 9 digit expected
    assert len(cnpj) == 14

# Generated at 2022-06-23 20:39:29.967635
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=12345)
    assert provider.cpf() == '092.290.581-17'
    assert provider.cnpj() == '43.079.165/0001-57'

# Generated at 2022-06-23 20:39:32.788984
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    expected_len = 11
    assert(expected_len == len(cpf))


# Generated at 2022-06-23 20:39:39.514253
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert bsp.__class__.__name__ == 'BrazilSpecProvider'
    assert bsp.__dict__.get('_random')
    assert bsp.__dict__.get('_datetime')
    assert bsp.__dict__.get('_seed')
    assert bsp.seed
    assert bsp.locale == 'pt-br'
    assert bsp.__dict__.get('provider')


# Generated at 2022-06-23 20:39:48.928492
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Initialize the Class BrazilSpecProvider with a specific seed
    provider = BrazilSpecProvider(seed=123456)
    # Initialize the Class BrazilSpecProvider with a random seed
    provider_random = BrazilSpecProvider()
    # Test method cpf for the Class BrazilSpecProvider
    # Get a random cpf with mask (###.###.###-##) and without mask
    # The output must be '412.471.966-49' (str type)
    assert provider.cpf(with_mask=True) == '412.471.966-49'
    # The output must be '41246796649' (str type)
    assert provider.cpf(with_mask=False) == '41246796649'
    # Get a random cpf with mask (###.###.###-##) and without mask
    # The output must

# Generated at 2022-06-23 20:39:52.144285
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BSP = BrazilSpecProvider(seed="teste")
    assert BSP.cpf() == "958.009.967-80"
    assert BSP.cnpj() == "78.674.066/0001-52"

# Generated at 2022-06-23 20:39:58.727868
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    import time
    import traceback
    import mimesis
    # Instantiate the class BrazilSpecProvider
    bsp = mimesis.BrazilSpecProvider()
    # Generate a CPNJ
    cpnj = bsp.cnpj()
    # Print the cpnj
    print(cpnj)
    # Compare the cpnj and the regex
    cpnj_regex = r'\d{2}\.\d{3}\.\d{3}/\d{4}\-\d{2}'
    assert re.match(cpnj_regex, cpnj)



# Generated at 2022-06-23 20:40:02.463509
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert isinstance(cpf, str)
    assert cpf == provider.cpf(with_mask=True)
    assert len(provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:40:10.229591
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    import re
    import mimesis.providers.helpers.brazil as brazil

    inst = brazil.BrazilSpecProvider()

    assert inst.cnpj() == '77.732.230/0001-70'
    assert inst.cnpj(with_mask=False) == '77732230000170'

    assert re.match('^[1-9]{2}[0-9]{2}[0-9]{3}[0-9]{4}[0-9]{2}$', inst.cnpj(with_mask=False)) == None

# Generated at 2022-06-23 20:40:10.902654
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
  brazil_provider = BrazilSpecProvider()

# Generated at 2022-06-23 20:40:12.786503
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = '94276422006'
    assert BrazilSpecProvider(seed=0).cpf(with_mask=False) == result


# Generated at 2022-06-23 20:40:17.211429
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    brazil_brazil_provider_cpf = brazil_provider.cpf()
    assert brazil_brazil_provider_cpf is not None
    # Unit test for method cnpj of class BrazilSpecProvider


# Generated at 2022-06-23 20:40:18.587906
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf(True)) == 14
    assert len(brazil.cpf(False)) == 11

# Generated at 2022-06-23 20:40:21.637794
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() != bsp.cpf()
    assert bsp.cnpj() != bsp.cnpj()



# Generated at 2022-06-23 20:40:26.203017
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    try:
        random_data = BrazilSpecProvider()
        assert random_data.__class__.__name__ == 'BrazilSpecProvider'
        print("Class 'BrazilSpecProvider' initialised!")
    except Exception as e:
        print(e)



# Generated at 2022-06-23 20:40:27.399578
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pass



# Generated at 2022-06-23 20:40:29.072357
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'

# Generated at 2022-06-23 20:40:31.227009
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.enums import Gender

    brazi = BrazilSpecProvider(seed=490217530960715)

    assert brazi.cpf(with_mask=True) == '001.137.297-40'


# Generated at 2022-06-23 20:40:33.958867
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('\n');
    brazil = BrazilSpecProvider();
    print(brazil.cnpj(with_mask=True)); # random CNPJ



# Generated at 2022-06-23 20:40:37.667767
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert cpf == brazil.cpf(with_mask=True)
    assert len(cpf) == 14
    assert len(brazil.cpf(with_mask=False)) == 11

# Generated at 2022-06-23 20:40:48.323115
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person

    p = Person('pt-br')
    g = Generic('pt-br')

    # CNPJ case 1 - copy and paste, it works
    assert g.cnpj(with_mask=True) == '77.732.230/0001-70'

    # CNPJ case 2 - Some random data
    assert p.cnpj() != p.cnpj()

    # CNPJ case 3 - A specific data and no mask
    assert g.cnpj(with_mask=False) == '77732230000170'

    # CNPJ case 4 - A specific data and a mask
    assert g.cnpj(with_mask=True) == '77.732.230/0001-70'




# Generated at 2022-06-23 20:40:53.131467
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test case for construction of BrazilSpecProvider."""
    # Create BrazilSpecProvider
    genesis = BrazilSpecProvider()
    # Check its name is equal to 'brazil_provider'
    assert genesis.Meta.name == 'brazil_provider'


# Generated at 2022-06-23 20:40:57.465365
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Initialize a BrazilSpecProvider
    test_provider = BrazilSpecProvider()
    # Call method cpf of test_provider
    cpf = test_provider.cpf()
    # Check if cpf has 11 chars
    assert len(cpf) == 11


# Generated at 2022-06-23 20:41:00.221719
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    provider.cnpj(with_mask=True)
    provider.cnpj(with_mask=False)


# Generated at 2022-06-23 20:41:05.722855
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test to see if CNPJ starts with '11.', is the first number generated
    CNPJ_1 = BrazilSpecProvider().cnpj()
    assert CNPJ_1.startswith('11.') == True

    # Test to see if CNPJ has 13 digits, verified by the number of periods
    assert CNPJ_1.count('.') == 2
    assert CNPJ_1.count('-') == 1

    # Test to see if CNPJ is a string
    assert type(CNPJ_1) is str

    # Test to see if CNPJ is valid
    from validarcnpj import validarcnpj
    assert validarcnpj.cnpj(CNPJ_1) == True



# Generated at 2022-06-23 20:41:16.729877
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider class."""
    bsp = BrazilSpecProvider()

    test_cpf_valid = bsp.cpf(with_mask=False)

    def get_verifying_digit_cpf(cpf, peso):
        """Calculate the verifying digit for the CPF.

        :param cpf: List of integers with the CPF.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CPF.
        """
        soma = 0
        for index, digit in enumerate(cpf):
            soma += digit * (peso - index)
        resto = soma % 11
        if resto == 0 or resto == 1 or resto >= 11:
            return 0
        return 11 - resto

    first_d

# Generated at 2022-06-23 20:41:20.570065
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert BrazilSpecProvider.cpf(provider) == '035.969.705-31' or BrazilSpecProvider.cpf(provider) == '920.930.594-14'


# Generated at 2022-06-23 20:41:23.980438
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    print(bsp.cpf())

    bsp.seed(1)
    print(bsp.cpf())

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:41:29.232096
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("Testando gerar CNPJ")
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    length_mask = len('77.732.230/0001-70')
    assert len(cnpj) == length_mask
    return True


# Generated at 2022-06-23 20:41:31.270117
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    print(provider.cnpj())
    # >>> 77.732.230/0001-70


# Generated at 2022-06-23 20:41:34.668178
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj == provider.cnpj(True)

# Generated at 2022-06-23 20:41:36.781930
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '85.358.937/0001-21'


# Generated at 2022-06-23 20:41:38.837858
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brsp = BrazilSpecProvider()
    print(brsp.cpf())


# Generated at 2022-06-23 20:41:45.814785
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    Brazil = BrazilSpecProvider()

    # verify that the cpf returned has 11 digits
    cpf = Brazil.cpf()
    cpf_list = cpf.split('.')
    assert len(cpf) == len('.'.join(cpf_list)) + 2

    # verify that the cpf returned has 11 digits
    cpf = Brazil.cpf(with_mask=False)
    assert len(cpf) == 11

    # verify that a error is raised when the parameter is different from boolean
    try:
        Brazil.cpf(with_mask=0)
        assert False
    except TypeError:
        assert True

    # verify that the calculated cpf

# Generated at 2022-06-23 20:41:48.806227
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    if "." in cpf:
        assert len(cpf) == 14
        assert cpf[3] == "." and cpf[7] == "." and cpf[11] == "-"
    else:
        assert len(cpf) == 11


# Generated at 2022-06-23 20:41:51.811116
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    print(brazil_spec_provider)
    assert brazil_spec_provider is not None


# Generated at 2022-06-23 20:41:54.507735
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec = BrazilSpecProvider()
    print(brazil_spec.cpf())
    print(brazil_spec.cpf(with_mask=False))


# Generated at 2022-06-23 20:41:56.352631
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from pprint import pprint
    x = BrazilSpecProvider()
    pprint(x.cnpj())

# Generated at 2022-06-23 20:42:00.448245
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bs = BrazilSpecProvider()
    assert isinstance(bs.cpf(), str)
    assert len(bs.cpf()) == 14
    assert isinstance(bs.cpf(with_mask=False), str)
    assert len(bs.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:42:01.815290
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    c = b.cnpj()
    assert len(c) == 18

# Generated at 2022-06-23 20:42:05.127006
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert '230.426.424-21' == BrazilSpecProvider().cpf(with_mask=True)

# Unit tes for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-23 20:42:06.880780
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider(seed=12345)
    assert isinstance(br, BrazilSpecProvider)

# Generated at 2022-06-23 20:42:08.794533
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    result = BrazilSpecProvider().cnpj()
    assert len(result) == 18
    assert result.find("-") == 14


# Generated at 2022-06-23 20:42:12.998036
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=1234567890)
    assert provider.cnpj() == '61.922.839/0001-80'
    assert provider.cnpj(False) == '61922839000180'



# Generated at 2022-06-23 20:42:20.628205
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert cnpj != b.cnpj(with_mask=False)
    assert cnpj == b.cnpj(with_mask=False)
    cnpj_mask = b.cnpj()
    assert len(cnpj_mask) == 18



# Generated at 2022-06-23 20:42:21.231813
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:42:23.310147
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert bsp.cnpj() != bsp.cnpj()
    assert len(cnpj) == 14


# Generated at 2022-06-23 20:42:26.180240
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '908.324.988-44'


# Generated at 2022-06-23 20:42:35.753755
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf.count(".") == 2
    assert cpf.count("-") == 1

    CPF = [int(i) for i in cpf.replace(".", "").replace("-", "")]

    def get_verifying_digit_cpf(cpf, peso):
        """Calculate the verifying digit for the CPF.

        :param cpf: List of integers with the CPF.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CPF.
        """
        soma = 0
        for index, digit in enumerate(cpf):
            soma += digit * (peso - index)
        resto = som

# Generated at 2022-06-23 20:42:38.158037
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=123)
    None


# Generated at 2022-06-23 20:42:38.809255
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()

# Generated at 2022-06-23 20:42:41.591234
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    try:
        BrazilSpecProvider()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-23 20:42:44.343214
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    b = BrazilSpecProvider()
    assert b.cnpj() == b.cnpj()



# Generated at 2022-06-23 20:42:45.592521
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-23 20:42:52.920232
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    
    seed = '7b9629e582870f4e' #'99d23a7869ef2b1a'
    
    generator = BrazilSpecProvider()
    generator.seed(seed)
    
    assert generator.cpf() == '826.625.048-14'
    assert generator.cpf() == '826.625.048-14'
    assert generator.cpf(with_mask=False) == '8266254814'
    

# Generated at 2022-06-23 20:42:59.198234
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    Brazil_SpecProvider = BrazilSpecProvider()
    print(Brazil_SpecProvider.cpf())
    print(Brazil_SpecProvider.cpf(with_mask=False))


if __name__ == '__main__':
    test_BrazilSpecProvider_cpf()

# Generated at 2022-06-23 20:43:01.096727
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    for _ in range(1, 2):
        assert bsp.cpf() == '001.137.297-40'

# Generated at 2022-06-23 20:43:05.544542
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    _seed = 0
    bs = BrazilSpecProvider(seed=_seed)
    expected_output = '77.732.230/0001-70'
    output = bs.cnpj()
    assert output == expected_output

# Generated at 2022-06-23 20:43:14.173162
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    valid_cpfs = ['011.137.297-40', '001.027.567-09', '053.794.455-40']
    custom_cpfs = ['01113729740', '001027567009', '05379444540']
    def custom_random(a,b):
        return valid_cpfs
    BS = BrazilSpecProvider(seed=custom_random)
    assert BS.cpf(with_mask=False) == custom_cpfs[0]
    assert BS.cpf(with_mask=True) == valid_cpfs[0]
    assert BS.cpf(with_mask=False) == custom_cpfs[1]
    assert BS.cpf(with_mask=True) == valid_cpfs[1]
    assert BS.cpf(with_mask=False) == custom_

# Generated at 2022-06-23 20:43:16.695421
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print(cnpj)
    assert cnpj == "36.572.086/0001-51"


# Generated at 2022-06-23 20:43:18.349672
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider is not None


# Generated at 2022-06-23 20:43:20.722543
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Default constructor
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider != None


# Generated at 2022-06-23 20:43:22.129717
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test to verify the constructor."""
    BrazilSpecProvider()

# Generated at 2022-06-23 20:43:24.892972
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_subject = BrazilSpecProvider()
    cpf = test_subject.cpf(with_mask=False)
    print(cpf)


# Generated at 2022-06-23 20:43:27.398735
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br_sp = BrazilSpecProvider()
    assert br_sp.cnpj(with_mask = True) == '90.919.541/0001-60'


# Generated at 2022-06-23 20:43:31.900497
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import unittest

    class BrazilSpecProviderTestCase(unittest.TestCase):
        def test_cnpj(self):
            bsp = BrazilSpecProvider()
            r_cnpj = bsp.cnpj(False)
            self.assertEqual(len(r_cnpj), 14)

    unittest.main()

# Generated at 2022-06-23 20:43:33.565858
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    print(bsp.cpf())
    print(bsp.cnpj())

# Generated at 2022-06-23 20:43:40.417636
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()
    cpf = bp.cpf()

    assert len(cpf) == 14
    assert cpf[3] == "." and cpf[8] == "." and cpf[13] == "-"
    assert cpf == bp.cpf(with_mask=True)

    cpf = bp.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf != bp.cpf(with_mask=True)


# Generated at 2022-06-23 20:43:47.201593
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    # Instantiate class BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()

    # Generate cnpj
    cnpj = brazil_spec_provider.cnpj(with_mask=True)

    # Asserting if cnpj is valid
    assert len(cnpj) == 18 and cnpj == '77.732.230/0001-70'


# Generated at 2022-06-23 20:43:48.295067
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj()

# Generated at 2022-06-23 20:43:52.771147
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    s = b.cnpj(with_mask=True)
    assert (s[2] == '.') and (s[6] == '.') and (s[10] == '/') and (s[15] == '-') \
        and (len(s) == 18)


# Generated at 2022-06-23 20:43:56.458538
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bra = BrazilSpecProvider(seed=300)
    print("Brazil CNPJ: " + bra.cnpj())
    print("Brazil CPF: " + bra.cpf())

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:43:58.709630
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Testing cpf of class BrazilSpecProvider."""
    assert BrazilSpecProvider(seed=123).cpf() == '643.606.853-29'


# Generated at 2022-06-23 20:44:00.724982
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider.cpf()
    BrazilSpecProvider.cnpj()

# Generated at 2022-06-23 20:44:01.603677
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()


# Generated at 2022-06-23 20:44:06.519676
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[0:3].isnumeric() and cpf[4:7].isnumeric() and cpf[8:10].isnumeric() and cpf[11:14].isnumeric()
    assert cpf[3] == '.' and cpf[7] == '.' and cpf[10] == '-'


# Generated at 2022-06-23 20:44:09.285600
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    d = BrazilSpecProvider()
    cpf_a = d.cpf()
    cpf_b = d.cpf()
    assert cpf_a != cpf_b
    assert len(cpf_a)==14
    assert len(cpf_b)==14


# Generated at 2022-06-23 20:44:11.313212
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cpf())


# Generated at 2022-06-23 20:44:11.912978
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:44:14.518095
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert provider.cpf() == '571.435.124-44'


# Generated at 2022-06-23 20:44:20.122363
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cnpj()) == 18
    assert len(provider.cpf(with_mask=False)) == 11
    assert len(provider.cnpj(with_mask=False)) == 14

# Generated at 2022-06-23 20:44:28.153662
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # test default
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=True) == '31.853.823/0001-48'

    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=False) == '31853.823000148'

    # test seed
    provider = BrazilSpecProvider(seed=10)
    assert provider.cnpj(with_mask=True) == '65.602.865/0001-20'

    provider = BrazilSpecProvider(seed=10)
    assert provider.cnpj(with_mask=False) == '65602.865000120'

# Generated at 2022-06-23 20:44:32.307618
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins.br import BrazilSpecProvider
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf().strip('.').strip('-')) == 11


# Generated at 2022-06-23 20:44:37.378265
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    # Arrange
    provider = BrazilSpecProvider()
    expected = '001.137.297-40'

    # Act
    actual = provider.cpf(with_mask=True)

    # Assert
    assert expected == actual
    assert len(actual) == 14


# Generated at 2022-06-23 20:44:44.658837
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider class"""
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'
    assert BrazilSpecProvider(seed=1).cnpj() == '86.878.668/0001-86'
    assert BrazilSpecProvider(seed=2).cnpj() == '55.845.986/0001-97'


# Generated at 2022-06-23 20:44:48.764998
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    assert isinstance(obj.cpf(), str)
    assert len(obj.cpf()) == 14
    assert len(obj.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:44:55.978941
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil = BrazilSpecProvider()

    cpf_1 = brazil.cpf()
    print(cpf_1)
    assert len(cpf_1) == 14
    assert cpf_1.count('.') == 2
    assert cpf_1.count('-') == 1

    cpf_2 = brazil.cpf(with_mask=False)
    print(cpf_2)
    assert len(cpf_2) == 11
    assert cpf_2.count('.') == 0
    assert cpf_2.count('-') == 0


# Generated at 2022-06-23 20:45:01.926958
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
	
	from mimesis import BrazilSpecProvider
	
	# Create an instance of BrazilSpecProvider
	br = BrazilSpecProvider()
	
	# Create a series of random cpf's
	tests = [br.cpf() for _ in range(2000)] # Use default value of with_mask
	
	# Make sure all cpf's are valid
	for cpf in tests:
		if len(cpf) > 11:
			raise Exception('A CPF returned was more than 11 characters!')
		if len(cpf) < 11:
			raise Exception('A CPF returned was less than 11 characters!')
		if cpf[:3] not in [str(i) for i in range(10)]:
			raise Exception('A CPF returned was invalid: {}'.format(cpf))
		

# Generated at 2022-06-23 20:45:10.245317
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    # Calculate the verifying digit for the CPF.
    def get_verifying_digit_cpf(cpf, peso):
        soma = 0
        for index, digit in enumerate(cpf):
            soma += digit * (peso - index)
        resto = soma % 11
        if resto == 0 or resto == 1 or resto >= 11:
            return 0
        return 11 - resto

    # Create a random provider with a seed.
    bsp = BrazilSpecProvider(seed=123)

    # Create a random CPF with mask.
    cpf_withMask = bsp.cpf(with_mask=True)
    # Create a random CPF without mask.
    cpf_withoutMask = bsp.cpf(with_mask=False)

    # Get the number of the CPF without mask

# Generated at 2022-06-23 20:45:12.911325
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:45:19.114224
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.builtins.brazil import BrazilSpecProvider
    from mimesis.enums import Gender

    provider = BrazilSpecProvider()

    cpf_without_mask = provider.cpf(with_mask=False)
    assert cpf_without_mask is not None
    assert len(cpf_without_mask) == 11

    cpf_with_mask = provider.cpf(with_mask=True)
    assert cpf_with_mask is not None
    assert len(cpf_with_mask) == 14

    


# Generated at 2022-06-23 20:45:20.415560
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of class BrazilSpecProvider."""
    assert BrazilSpecProvider()


# Generated at 2022-06-23 20:45:23.081657
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for _ in range(20):
        print("cpf: ", BrazilSpecProvider().cpf())


# Generated at 2022-06-23 20:45:26.401926
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj(with_mask=True)
    assert cnpj
    # should not raise an exception

# Generated at 2022-06-23 20:45:28.780415
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()

    assert len(bsp.cpf()) == 14
    assert len(bsp.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:45:29.313667
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:45:30.496234
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-23 20:45:39.198608
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    
    # test cpf
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    
    # test cnpj
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    
    print('Test BrazilSpecProvider successfully!')

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:45.472904
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    brazil = BrazilSpecProvider()
    assert brazil.cpf() == '944.744.039-72'
    assert brazil.cnpj() == '76.876.744/0001-53'
    assert isinstance(brazil.telephone(), str)
    assert brazil.full_name(gender=Gender.MALE) == 'João Vitor Nunes'
    assert brazil.full_name(gender=Gender.FEMALE) == 'Beatriz Calheiros'
    assert isinstance(brazil.mothers_name(), str)
    assert isinstance(brazil.name(), str)
    assert isinstance(brazil.first_name(), str)

# Generated at 2022-06-23 20:45:54.398748
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test case for method cnpj of class BrazilSpecProvider"""
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider

    bsp = BrazilSpecProvider()

    for i in range(100):
        cnpj = bsp.cnpj()
        assert len(cnpj) == 14, "cnpj must have 14 characters"

    bsp.seed(1)
    cnpj = bsp.cnpj()
    assert cnpj == '77.732.230/0001-70'


# Generated at 2022-06-23 20:45:58.582640
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

    # Unit test for method cpf
    assert len(BrazilSpecProvider().cpf(with_mask=False)) == 11

    # Unit test for method cnpj
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14

# Generated at 2022-06-23 20:46:04.426689
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=True)
    assert cnpj.isdigit()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-23 20:46:06.496355
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider constructor."""
    bsp = BrazilSpecProvider()

# Generated at 2022-06-23 20:46:12.960555
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[0:3] != cpf[4:7] != cpf[8:11] != cpf[12:14]
    assert cpf.find('.') != -1
    assert cpf.find('-') != -1


# Generated at 2022-06-23 20:46:15.022007
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert cnpj == '77.732.230/0001-70'


# Generated at 2022-06-23 20:46:16.448708
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 20:46:18.676226
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(with_mask=True) == '00.007.352/0001-15'


# Generated at 2022-06-23 20:46:20.076671
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brasil_spec = BrazilSpecProvider()
    assert brasil_spec.cpf() == '065.371.541-79'


# Generated at 2022-06-23 20:46:24.798983
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    prov = BrazilSpecProvider()
    assert str(prov) == 'BrazilSpecProvider'
    assert repr(prov) == "Provider('pt-br')"
    assert prov.custom_code() == 'pt-br'
    prov.random.seed(13)
    assert prov.cpf() == '366.636.741-18'
    prov.random.seed(13)
    assert prov.cnpj() == '12.430.173/0001-43'

# Generated at 2022-06-23 20:46:27.221247
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(True)
    print(f"BrazilSpecProvider_cpf: {cpf}") 
    assert(len(cpf) == 14 and cpf.count('.') == 2 and cpf.count('-') == 1)


# Generated at 2022-06-23 20:46:30.130956
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert isinstance(cpf, str)
    assert cpf != provider.cpf() and cpf != provider.cpf()


# Generated at 2022-06-23 20:46:33.704652
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '682.815.891-01'
    assert provider.cpf(with_mask=False) == '68281589101'
    assert provider.cnpj() == '29.211.922/0001-71'
    assert provider.cnpj(with_mask=False) == '2921922000171'

# Generated at 2022-06-23 20:46:35.636724
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

    assert provider.cpf()
    assert provider.cnpj()


# Generated at 2022-06-23 20:46:42.482106
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of BrazilSpecProvider class."""

    bp = BrazilSpecProvider()

    cpf_without_mask = bp.cpf(with_mask=False)
    assert cpf_without_mask.isdigit()
    assert len(cpf_without_mask) == 11

    cpf = bp.cpf()
    assert len(cpf) == 14
    assert '.' in cpf
    assert '-' in cpf



# Generated at 2022-06-23 20:46:44.843074
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers import BrazilSpecProvider

    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:46:55.913735
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bz = BrazilSpecProvider()
    numbers = [bz.cpf(False) for _ in range(10)]

    assert numbers[0] == '00113729740'
    assert numbers[1] == '00717496520'
    assert numbers[2] == '00329656133'
    assert numbers[3] == '00382958850'
    assert numbers[4] == '00989221070'
    assert numbers[5] == '00090259232'
    assert numbers[6] == '00039189607'
    assert numbers[7] == '00149813437'
    assert numbers[8] == '00631837503'
    assert numbers[9] == '00265650292'

    numbers = [bz.cpf(True) for _ in range(10)]

    assert numbers

# Generated at 2022-06-23 20:47:04.088424
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.providers.address import Address

    b = BrazilSpecProvider()
    b2 = BrazilSpecProvider(seed='test')

    # test methods of mother class
    assert b.seed == b2.seed
    assert b.random is b2.random
    assert b.datetime is b2.datetime
    assert b.formatter is b2.formatter
    assert b.provider_list == b2.provider_list
    assert b.__dict__ is not b2.__dict__

    # test set_seed() of mother class
    b.set_seed('test')
    assert b.seed == 'test'

    # test reset_seed() of mother class
    b2.reset_seed()
   

# Generated at 2022-06-23 20:47:06.484583
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider()
    expected=p.cpf()
    assert len(expected) == 14


# Generated at 2022-06-23 20:47:08.121897
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'
