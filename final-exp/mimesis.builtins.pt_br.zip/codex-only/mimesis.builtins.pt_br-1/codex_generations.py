

# Generated at 2022-06-23 20:37:20.353557
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()

# Generated at 2022-06-23 20:37:22.900082
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.__class__.__name__ == 'BrazilSpecProvider'

# Generated at 2022-06-23 20:37:25.826207
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider class."""

# Generated at 2022-06-23 20:37:31.112028
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf(True) == "700.738.829-64" # doesn't have to be this, but have to have the format
    assert brazil.cnpj(True) == "30.269.742/0001-97" # doesn't have to be this, but have to have the format

# Generated at 2022-06-23 20:37:38.843375
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("Testing BrazilSpecProvider cnpj...")

    # Testing BrazilSpecProvider cnpj method
    bsp = BrazilSpecProvider()
    assert type(bsp.cnpj()) == str
    assert len(bsp.cnpj()) == 18
    assert len(bsp.cnpj(with_mask=False)) == 14
    assert bsp.cnpj() != bsp.cnpj()
    assert bsp.cnpj(with_mask=False) != bsp.cnpj(with_mask=False)


# Generated at 2022-06-23 20:37:42.959928
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.builtins import BrazilSpecProvider
    class CMyProvider(BrazilSpecProvider):
        def get_data(self):
            return {
                'cpf': '000.000.000-00',
            }

    provider = CMyProvider()
    assert provider.cpf() == '000.000.000-00'


# Generated at 2022-06-23 20:37:48.245116
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test function BrazilSpecProvider.cnpj."""
    p = BrazilSpecProvider()
    cnpj = p.cnpj()
    cnpj_with_mask = p.cnpj(True)
    assert len(cnpj) == 14
    assert len(cnpj_with_mask) == 18
    assert cnpj_with_mask[:2] == cnpj_with_mask[3:6] == cnpj_with_mask[7:10] == cnpj_with_mask[-4] == '.' == cnpj_with_mask[-1] == '-'
    assert cnpj_with_mask[12] == '/'

# Generated at 2022-06-23 20:37:51.136357
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    c = BrazilSpecProvider()
    cpf = c.cpf(with_mask=False)
    cpf_mask = c.cpf()
    assert len(cpf) == len(cpf_mask) == 11


# Generated at 2022-06-23 20:37:54.940365
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider."""

    b = BrazilSpecProvider()
    b.cnpj()
    b.cnpj(True)

    assert b.cnpj() == b.cnpj(False)

# Generated at 2022-06-23 20:37:55.800728
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider().__init__()

# Generated at 2022-06-23 20:37:57.722466
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    expected = '001.137.297-40'
    result = BrazilSpecProvider().cpf()

    assert expected == result



# Generated at 2022-06-23 20:37:59.178805
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().__class__.__name__ == "BrazilSpecProvider"


# Generated at 2022-06-23 20:38:01.675207
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    b.cpf()
    b.cnpj()

# Generated at 2022-06-23 20:38:04.536324
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()
    res = bp.cnpj()
    assert len(res) == 18
    print(f'BrazilSpecProvider_cnpj retorna {res}')


# Generated at 2022-06-23 20:38:07.192447
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    prov = BrazilSpecProvider()
    assert prov.cnpj() != None
    assert prov.cnpj(False) != None
    assert prov.cpf() != None
    assert prov.cpf(False) != None

# Generated at 2022-06-23 20:38:10.876979
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf(False)
    assert len(cpf) == 11
    assert type(cpf) == str
    #
    cpf = b.cpf()
    assert len(cpf) == 14
    assert type(cpf) == str


# Generated at 2022-06-23 20:38:14.138746
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[14] == None



# Generated at 2022-06-23 20:38:14.896006
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print(BrazilSpecProvider().cnpj(False))

# Generated at 2022-06-23 20:38:17.105905
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bzs = BrazilSpecProvider()
    assert bzs.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:38:18.079763
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    pass

# Generated at 2022-06-23 20:38:20.448295
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider"""
    supplier = BrazilSpecProvider()
    assert supplier != None


# Generated at 2022-06-23 20:38:23.771070
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    print(cpf)

    assert len(cpf) == 14
    assert cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-'


# Generated at 2022-06-23 20:38:27.454092
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    a1 = BrazilSpecProvider()
    for i in range(0, 20):
        if i % 2 == 0:
            with_mask = False
        else:
            with_mask = True
        print(a1.cnpj(with_mask))


# Generated at 2022-06-23 20:38:30.720576
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the cpf method of BrazilSpecProvider""" 
    brazil = BrazilSpecProvider()
    assert(len(brazil.cpf(with_mask=False)) == 11)
    assert(len(brazil.cpf(with_mask=True)) == 14)


# Generated at 2022-06-23 20:38:31.786904
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pr = BrazilSpecProvider()
    assert pr.cnpj()
    assert pr.cpf()

# Generated at 2022-06-23 20:38:34.540405
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test with mask in
    brazil_1 = BrazilSpecProvider()
    brazil_1.cnpj()

    # Test with mask out
    brazil_2 = BrazilSpecProvider()
    brazil_2.cnpj(with_mask=False)


# Generated at 2022-06-23 20:38:37.228355
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:38:42.216533
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for cnpj method of BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj == provider.cnpj(with_mask=False)
    assert len(cnpj) == 18
    assert isinstance(provider.cnpj(), str)


# Generated at 2022-06-23 20:38:43.219744
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider != None

# Generated at 2022-06-23 20:38:44.869135
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    print(bsp.cnpj(with_mask = True))



# Generated at 2022-06-23 20:38:47.251417
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Arrange
    # Act
    BSP = BrazilSpecProvider()
    # Assert



# Generated at 2022-06-23 20:38:49.034368
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '16.946.616/0001-60'

# Generated at 2022-06-23 20:38:49.581911
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:38:57.346742
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers import Address, BrazilSpecProvider
    from mimesis.providers.address import BrazilSpecProvider as BrazilAddressSpecProvider

    spec = BrazilSpecProvider()

    # test inheritance
    assert isinstance(spec, BrazilAddressSpecProvider), "Not inherited from BrazilSpecProvider"

    # test cpf
    assert isinstance(spec.cpf(), str), "Not string"
    assert spec.cpf().count('-') == 1, "Not contain one -"
    assert spec.cpf().count('.') == 2, "Not contain two ."

    # test cnpj
    assert isinstance(spec.cnpj(), str), "Not string"
    assert spec.cnpj().count('-') == 1, "Not contain one -"

# Generated at 2022-06-23 20:38:59.749237
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() != None
    assert provider.cnpj() != None

# Generated at 2022-06-23 20:39:03.134906
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the method cpf of class BrazilSpecProvider."""
    print("Testing BrazilSpecProvider.cpf()")
    print("Result: ", BrazilSpecProvider().cpf())
    print("\n")


# Generated at 2022-06-23 20:39:04.756249
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() != bsp.cpf()


# Generated at 2022-06-23 20:39:06.324929
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    # TODO: Implement this test
    pass

# Generated at 2022-06-23 20:39:07.796675
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert(not bsp is None)


# Generated at 2022-06-23 20:39:11.148218
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider cpf method."""
    assert len(BrazilSpecProvider().cpf()) == 14
    assert len(BrazilSpecProvider(seed=0).cpf()) == 14
    assert len(BrazilSpecProvider().cpf(with_mask=False)) == 11
    assert len(BrazilSpecProvider(seed=0).cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:39:13.014200
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    assert brazilSpecProvider.__class__.__name__ == 'BrazilSpecProvider'



# Generated at 2022-06-23 20:39:15.576596
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert type(cnpj) == str



# Generated at 2022-06-23 20:39:16.519337
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Method to test if the constructor is working as expected."""
    BrazilSpecProvider()

# Generated at 2022-06-23 20:39:25.050553
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    bz = BrazilSpecProvider()

    assert bz.__class__.__name__ == 'BrazilSpecProvider'

    assert bz.gender(gender=Gender.MALE) == 'masculino'

    assert bz.cnpj() == '77.732.230/0001-70'
    assert bz.cnpj() == '77.732.230/0001-70'
    assert bz.cnpj() == '77.732.230/0001-70'
    assert bz.cnpj() == '77.732.230/0001-70'
    assert bz.cnpj(with_mask=False) == '77732230000170'

    assert bz.cpf() == '001.137.297-40'
    assert bz

# Generated at 2022-06-23 20:39:31.285847
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import re
    from mimesis.enums import Gender
    from mimesis.providers.enums import Provider

    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)
    assert provider.__class__.__name__ == "BrazilSpecProvider"
    assert provider.__class__.__module__ == "mimesis.providers.brazil"

    # default
    result = provider.cnpj()
    assert isinstance(result, str)
    assert re.match(r'\d{2}.\d{3}.\d{3}/\d{4}-\d{2}', result), \
        "CNPJ (###.###.###-##) regex not found"

    # with mask
    result = provider.cnpj(with_mask=False)

# Generated at 2022-06-23 20:39:33.755760
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    assert isinstance(obj.cpf(), str)



# Generated at 2022-06-23 20:39:36.655993
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    if not BrazilSpecProvider(seed=2).cpf():
        raise AssertionError()
    if not BrazilSpecProvider(seed=2).cnpj():
        raise AssertionError()

# Generated at 2022-06-23 20:39:42.839283
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18
    num_cnpj = cnpj.replace('-','').replace('.','').replace('/','')
    num_cnpj_list = []
    for d in num_cnpj:
        num_cnpj_list.append(int(d))
    verified_num_cnpj = num_cnpj_list[0:12]
    first_dv = get_verifying_digit_cnpj(verified_num_cnpj, 5)
    verified_num_cnpj.append(first_dv)

# Generated at 2022-06-23 20:39:47.604439
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14
    assert BrazilSpecProvider().cnpj(with_mask=True) == '77.732.230/0001-70'


# Generated at 2022-06-23 20:39:51.183062
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider(seed=100)
    assert brazil_provider.cnpj() == '77.732.230/0001-70'
    assert brazil_provider.cpf() == '001.137.297-40'

# Generated at 2022-06-23 20:39:56.238044
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert isinstance(BrazilSpecProvider(), BrazilSpecProvider)
    assert BrazilSpecProvider.Meta.name == 'brazil_spec_provider'
    items = BrazilSpecProvider()
    assert isinstance(items.cpf(), str)
    assert isinstance(items.cnpj(), str)
    assert isinstance(items.cpf(), str)
    assert isinstance(items.cnpj(), str)

# Generated at 2022-06-23 20:40:03.593767
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider(seed=12345)

    # Input 0:
    assert brazil_provider.cpf() == '449.980.217-72'
    # Input 1:
    assert brazil_provider.cpf(with_mask=False) == '44998021772'

    # Input 2:
    assert brazil_provider.cnpj() == '67.216.016/0008-19'
    # Input 3:
    assert brazil_provider.cnpj(with_mask=False) == '67216016000819'

# Generated at 2022-06-23 20:40:10.782117
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    test_person = Person('pt-br')

    def test_BrazilSpecProvider_cpf_with_mask_not_null():
        for element in test_person.cpf(with_mask=True, gender=Gender.FEMALE):
            assert element is not None

    def test_BrazilSpecProvider_cpf_without_mask_not_null():
        for element in test_person.cpf(with_mask=False, gender=Gender.MALE):
            assert element is not None

    test_BrazilSpecProvider_cpf_with_mask_not_null()
    test_BrazilSpecProvider_cpf_without_mask_not_null()



# Generated at 2022-06-23 20:40:12.045622
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.cpf(with_mask=True)
    assert bsp.cnpj(with_mask=True)

# Generated at 2022-06-23 20:40:14.166904
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # coverage test
    BrazilSpecProvider('ABC')


# Generated at 2022-06-23 20:40:16.368139
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=0)
    assert provider.cnpj(with_mask=False) == '7773223000170'

# Generated at 2022-06-23 20:40:19.197817
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:40:22.794477
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert bool(re.match('\d{3}\.\d{3}\.\d{3}-\d{2}', cpf))



# Generated at 2022-06-23 20:40:25.734492
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-23 20:40:30.289400
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of class BrazilSpecProvider"""

    provider = BrazilSpecProvider()
    assert hasattr(provider, 'locale')
    assert hasattr(provider, 'seed')
    assert hasattr(provider, 'cpf')
    assert hasattr(provider, 'cnpj')


# Generated at 2022-06-23 20:40:32.886882
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert(cnpj == '55.831.739/0001-40')


# Generated at 2022-06-23 20:40:41.184117
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person.pt_br import BrazilPerson
    from mimesis.providers.person.base import BasePerson

    assert BrazilPerson(seed=42).cpf() == '568.787.850-56'
    assert BrazilPerson(seed=42).cpf(with_mask=False) == '56878785056'
    assert BrazilPerson(seed=42).cpf() == '568.787.850-56'
    assert BrazilPerson(seed=42).cpf(with_mask=False) == '56878785056'
    assert BrazilPerson(seed=1337).cpf() == '326.852.852-17'
    assert BrazilPerson(seed=1337).cpf(with_mask=False) == '32685325217'



# Generated at 2022-06-23 20:40:50.948550
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider method "cnpj"."""
    assert len(BrazilSpecProvider().cnpj()) == 18
    #
    cnpj = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(cnpj) == 14
    for i in range(14):
        assert cnpj[i] in [str(j) for j in range(10)]
    #
    cnpj = BrazilSpecProvider().cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert "." in cnpj
    assert "/" in cnpj
    assert "-" in cnpj


# Generated at 2022-06-23 20:40:55.712570
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bz = BrazilSpecProvider()
    cnpj = bz.cnpj()

    assert len(cnpj) == 18
    assert cnpj[2] == "."
    assert cnpj[6] == "."
    assert cnpj[10] == "/"
    assert cnpj[15] == "-"


# Generated at 2022-06-23 20:41:02.243225
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.date import Datetime
    from mimesis.providers.lorem import Lorem
    from mimesis.providers.identifier import BrazilIdentifier
    from mimesis.providers.code import Code
    from mimesis.providers.currency import BrazilCurrency

    provider = BrazilSpecProvider()

    assert provider.seed is None
    assert provider.locale == 'pt-br'
    assert provider.gender == 'both'
    assert isinstance(provider.person, Person)
    assert isinstance(provider.address, Address)
    assert isinstance(provider.date_time, Datetime)

# Generated at 2022-06-23 20:41:14.220634
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Valid CNPJ's
    valid1 = '77.732.230/0001-70'
    valid2 = '24.274.188/0001-78'

    # Masked valid CNPJ's
    valid3 = '77.732.230/0001-70'
    valid4 = '24.274.188/0001-78'

    # CNPJ without mask
    valid5 = '77732230000170'
    valid6 = '24274188000178'

    bsp = BrazilSpecProvider()
    assert bsp.cnpj() in [valid1, valid2]
    assert bsp.cnpj(with_mask=True) in [valid3, valid4]
    assert bsp.cnpj(with_mask=False) in [valid5, valid6]


# Generated at 2022-06-23 20:41:18.735241
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Testing method
    BrazilSpecProvider.cpf()
    """
    provider = BrazilSpecProvider()
    output = provider.cpf()
    assert len(output) == 14
    assert output.count('.') == 2
    assert output.count('-') == 1
    assert output[3] == '.'
    assert output[7] == '.'
    assert output[11] == '-'


# Generated at 2022-06-23 20:41:21.656742
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:41:26.061139
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  import mimesis.providers as providers
  brazil_provider = providers.BrazilSpecProvider()

  # test to validate a CNPJ in format ###.###.###/0001-##
  assert brazil_provider.cnpj(True) == '77.732.230/0001-70'

  # test to validate a CNPJ in format #############
  assert brazil_provider.cnpj(False) == '77732240000170'


# Generated at 2022-06-23 20:41:29.332644
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test Brazil Spec Provider."""
    data = BrazilSpecProvider()
    assert data.cpf()
    assert data.cnpj()

# Generated at 2022-06-23 20:41:31.757134
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert '.' in cnpj and '-' in cnpj

# Generated at 2022-06-23 20:41:33.530798
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    'Test BrazilSpecProvider'
    provider = BrazilSpecProvider()
    provider.cnpj()

# Generated at 2022-06-23 20:41:41.869565
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()

    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14

    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj) == 18

    cnpj = provider.cnpj(with_mask=True)
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'



# Generated at 2022-06-23 20:41:42.626571
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
   assert BrazilSpecProvider().cpf()


# Generated at 2022-06-23 20:41:44.573196
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()
    # Test constructor
    assert hasattr(p, 'locale')
    assert hasattr(p, 'seed')
    assert hasattr(p, 'random')
    

# Generated at 2022-06-23 20:41:46.670177
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    cnpj = br.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:41:54.629877
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider class."""
    from pprint import pprint
    from random import seed
    from mimesis.enums import Gender

    seed(0)
    brazil_provider = BrazilSpecProvider()

    assert brazil_provider.cpf() == '583.977.217-26'
    assert brazil_provider.cnpj() == '77.732.230/0001-70'
    assert brazil_provider.cnpj(with_mask=False) == '77732230000170'
    assert brazil_provider.cpf(with_mask=False) == '58397721726'

    assert brazil_provider.gender() == Gender.FEMALE
    assert brazil_provider.full_name() == 'Suellen Federica Dória'


# Generated at 2022-06-23 20:41:56.858957
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    s = BrazilSpecProvider()

    assert s._data == 'brazil_provider'
    assert isinstance(s.random, Seed)

# Generated at 2022-06-23 20:42:02.954853
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender

    br = BrazilSpecProvider(seed=0)

    cnpj_1 = br.cnpj()
    assert cnpj_1 == '27.564.550/0001-37'

    cnpj_2 = br.cnpj(with_mask=False)
    assert cnpj_2 == '27564550000137'

    br.seed(1)
    cnpj_3 = br.cnpj()
    assert cnpj_3 == '43.920.161/0001-10'

    cnpj_4 = br.cnpj(with_mask=False)
    assert cnpj_4 == '43920161000110'

# Generated at 2022-06-23 20:42:12.403021
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilProvider = BrazilSpecProvider()

    # Validating CPF:
    is_valid = False
    while not is_valid:
        cpf = brazilProvider.cpf()
        digito_verificador = cpf[-2:]
        cpf_without_dv = cpf[:-2]

        soma = 0
        peso = [10, 9, 8, 7, 6, 5, 4, 3, 2]
        for digito, p in zip(cpf_without_dv, peso):
            soma += int(digito) * p
        resto = soma % 11
        if resto == 0 or resto == 1:
            first_dv = 0
        else:
            first_dv = 11 - resto

        soma = 0

# Generated at 2022-06-23 20:42:15.306320
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    res = provider.cpf()
    assert len(res) == 14


# Generated at 2022-06-23 20:42:21.003387
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for provider method BrazilSpecProvider.cnpj."""
    result = BrazilSpecProvider().cnpj(with_mask=True)
    assert isinstance(result, str) and re.match('^[\d]{2}.[\d]{3}.[\d]{3}/[\d]{4}-[\d]{2}$', result)



# Generated at 2022-06-23 20:42:24.858312
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert cnpj[2] == "."
    assert cnpj[6] == "."
    assert cnpj[10] == "/"
    assert cnpj[15] == "-"


# Generated at 2022-06-23 20:42:25.534356
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:42:29.832596
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # unit test for constructor of class BrazilSpecProvider
    from mimesis.providers.person.components import Provider
    def test_BrazilSpecProvider():
        # unit test for constructor of class BrazilSpecProvider
        provider = BrazilSpecProvider()
        assert isinstance(provider, Provider)

# Generated at 2022-06-23 20:42:31.580424
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf()

# Generated at 2022-06-23 20:42:33.656791
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Test the object was created
    assert BrazilSpecProvider()

# Test to CPF method

# Generated at 2022-06-23 20:42:36.971075
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    b = BrazilSpecProvider()
    # Add assert for validate the cpf method
    assert re.match("\d{3}\.\d{3}\.\d{3}-\d{2}", b.cpf())


# Generated at 2022-06-23 20:42:38.374106
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(True)
    assert cnpj == '77.732.230/0001-70'


# Generated at 2022-06-23 20:42:44.191814
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider class method cpf."""

    # Create a instance of BrazilSpecProvider
    brazil = BrazilSpecProvider()

    # Call the method
    result = brazil.cpf()

    # Split the result
    result_list = [result[i:i+3] for i in range(0, 11, 3)]

    # Entire result without mask
    entire_result = ''.join(result_list)

    # List which will be used to calculate the two digits verification
    list_without_dv = []

    # Add the numbers of the entire result without mask in the list
    for c in entire_result:
        list_without_dv.append(int(c))

    # Define the peso for the modulo 11 calculation 
    # (The first digit of the CPF is calculated with the peso 10 and the

# Generated at 2022-06-23 20:42:46.382841
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() != BrazilSpecProvider().cnpj()
    assert BrazilSpecProvider().cnpj() != BrazilSpecProvider().cnpj(with_mask=False)

    assert BrazilSpecProvider().cnpj(with_mask=False) == '93495477000163'
    assert BrazilSpecProvider().cnpj() == '93.495.477/0001-63'


# Generated at 2022-06-23 20:42:55.318602
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    '''
    Unit test for method cnpj of class BrazilSpecProvider
    '''
    from mimesis.enums import Gender
    from mimesis.providers.brazil import BrazilSpecProvider

    brazil_provider = BrazilSpecProvider()

    cnpj = brazil_provider.cnpj()
    assert len(cnpj)  == 14

    cnpj = brazil_provider.cnpj(False)
    assert len(cnpj)  == 14

    cnpj = brazil_provider.cnpj(with_mask = False)
    assert len(cnpj)  == 14


# Generated at 2022-06-23 20:42:56.738194
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider.__name__ == "BrazilSpecProvider"


# Generated at 2022-06-23 20:43:01.276390
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '77.732.230/0001-70'
    assert bsp.cnpj(with_mask=False) == '77732230000170'


# Generated at 2022-06-23 20:43:11.350542
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider(seed=42)
    cpf1 = obj.cpf()
    assert len(cpf1) > 0
    assert cpf1 == '908.955.632-82'
    cpf2 = obj.cpf(False)
    assert len(cpf2) > 0
    assert cpf2 == '908955632'
    cnpj1 = obj.cnpj()
    assert len(cnpj1) > 0
    assert cnpj1 == '26.401.015/0001-98'
    cnpj2 = obj.cnpj(False)
    assert len(cnpj2) > 0
    assert cnpj2 == '26401015000198'

# Generated at 2022-06-23 20:43:16.710995
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for i in range(1000):
        cpf = provider.cpf()
        assert len(cpf) == 14
        assert isinstance(cpf, str)
        assert cpf[3] == '.'
        assert cpf[7] == '.'
        assert cpf[11] == '-'
        assert cpf[3:4].isdigit()
        assert cpf[7:8].isdigit()
        assert cpf[11:12].isdigit()
        assert cpf[0:3].isdigit()
        assert cpf[4:7].isdigit()
        assert cpf[8:11].isdigit()
        assert cpf[12:].isdigit()

# Generated at 2022-06-23 20:43:21.305410
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    cpf = BrazilSpecProvider().cpf()

    assert len(cpf) == 14
    assert cpf == '008.522.876-06'



# Generated at 2022-06-23 20:43:24.415267
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    test = brazil_spec_provider.cpf()
    assert len(test) == 14
    assert test[3] == "."

# Generated at 2022-06-23 20:43:27.695607
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    testObject = BrazilSpecProvider(seed = 100)
    assert testObject.cpf() == '891.856.858-07'


# Generated at 2022-06-23 20:43:37.066681
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj1 = BrazilSpecProvider().cnpj()
    assert len(cnpj1) == 18
    assert cnpj1[2] == "."
    assert cnpj1[6] == "."
    assert cnpj1[10] == "/"
    assert cnpj1[15] == "-"
    assert cnpj1[:2].isdigit()
    assert cnpj1[3:6].isdigit()
    assert cnpj1[7:10].isdigit()
    assert cnpj1[11:15].isdigit()
    assert cnpj1[16:].isdigit()

    cnpj2 = BrazilSpecProvider().cnpj(with_mask = False)
    assert len(cnpj2) == 14
    assert cnpj2.isdig

# Generated at 2022-06-23 20:43:43.484491
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    # Obtém o CNPJ formatado como esperado
    cnpj_with_mask = provider.cnpj()
    cnpj_without_mask = provider.cnpj(with_mask=False)
    assert(len(cnpj_with_mask) == len('99.999.999/9999-99'))
    assert(len(cnpj_without_mask) == len('99999999999999'))
    assert(cnpj_with_mask[2] == '.')
    assert(cnpj_with_mask[6] == '.')
    assert(cnpj_with_mask[10] == '/')
    assert(cnpj_with_mask[15] == '-')

# Generated at 2022-06-23 20:43:44.398906
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    loc = BrazilSpecProvider()
    print(loc.cnpj())


# Generated at 2022-06-23 20:43:46.271021
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '37.850.749/0001-59'


# Generated at 2022-06-23 20:43:47.862378
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert isinstance(BrazilSpecProvider().cnpj(), str)



# Generated at 2022-06-23 20:43:51.217688
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider"""
    i = 0
    print('method cnpj of class BrazilSpecProvider')
    while (i < 15): 
        print(i,'-',BrazilSpecProvider().cnpj())
        i += 1



# Generated at 2022-06-23 20:44:00.375708
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.date import DateTime
    from mimesis.providers.internet import Internet
    from mimesis.providers.geo import Geo
    from mimesis.providers.person import Person

    brasil = BrazilSpecProvider()
    gender = Gender()
    geo = Geo('pt-br')
    person = Person('pt-br')
    internet = Internet('pt-br')
    now = DateTime('pt-br')

# Generated at 2022-06-23 20:44:07.730535
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    my_generator = BrazilSpecProvider()
    my_generator.seed(10)
    print(my_generator.person.cpf)
    print(my_generator.person.cnpj)
    print(my_generator.person.name(gender=Gender.FEMALE))
    print(my_generator.person.surname(gender=Gender.FEMALE))
    print(my_generator.person.full_name(gender=Gender.FEMALE))
    print(my_generator.person.username())
    print(my_generator.person.email(domains=['hotmail.com']))

# Generated at 2022-06-23 20:44:13.133775
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(with_mask=True)
    tmp = cpf.split(".")
    assert len(tmp) == 3
    tmp = tmp[2].split("-")
    assert len(tmp) == 2
    assert len(cpf) == 14


# Generated at 2022-06-23 20:44:16.163789
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=42)
    cpf = provider.cpf()
    assert cpf == '001.137.297-40'
    cpf = provider.cpf(with_mask=False)
    assert cpf == '00113729740'


# Generated at 2022-06-23 20:44:21.153432
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Declare the BrazilSpecProvider object
    brazil_spec_provider = BrazilSpecProvider()
    # Call method cpf
    cpf = brazil_spec_provider.cpf()
    # Result
    print(cpf)


# Generated at 2022-06-23 20:44:27.384637
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider.cnpj(with_mask=False) == '0' * 14
    assert BrazilSpecProvider.cnpj(with_mask=True) == '00.000.000/0000-00'
    assert BrazilSpecProvider.cnpj(with_mask=True) == '92.237.356/0001-96'
    assert BrazilSpecProvider.cnpj(with_mask=True) == '49.522.891/0001-53'
    assert BrazilSpecProvider.cnpj(with_mask=True) == '67.949.908/0001-28'
    assert BrazilSpecProvider.cnpj(with_mask=True) == '87.794.993/0001-05'
    assert BrazilSpecProvider.cnpj(with_mask=True) == '95.567.215/0001-07'

# Generated at 2022-06-23 20:44:35.689643
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

    # Check if provider is an instance of class BrazilSpecProvider
    assert provider.__class__ == BrazilSpecProvider

    # Check if provider has valid Meta
    assert provider.Meta == BrazilSpecProvider.Meta

    # Check if provider has attribute CPF
    assert hasattr(provider, 'cpf')

    # Check if provider has attribute CNPJ
    assert hasattr(provider, 'cnpj')


# Generated at 2022-06-23 20:44:37.279047
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bs = BrazilSpecProvider()
    print(bs.cpf())

# Generated at 2022-06-23 20:44:41.238017
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert cpf


# Generated at 2022-06-23 20:44:43.118526
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cnpj()


# Generated at 2022-06-23 20:44:46.221795
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    print(bsp.cnpj(with_mask=True))

# Generated at 2022-06-23 20:44:46.849902
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pass

# Generated at 2022-06-23 20:44:53.829721
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    from mimesis.providers.base import Provider

    class BrazilDataProvider(BrazilSpecProvider, Provider):
        pass

    BRAZIL_PROVIDER = BrazilDataProvider()

    assert len(BRAZIL_PROVIDER.cpf()) == 14
    assert len(BRAZIL_PROVIDER.cpf(with_mask=False)) == 11
    assert isinstance(BRAZIL_PROVIDER.cpf(), str)
    assert isinstance(BRAZIL_PROVIDER.cpf(with_mask=False), str)


# Generated at 2022-06-23 20:44:58.127360
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for _ in range(1000):
        cnpj = BrazilSpecProvider().cnpj()
        assert len(cnpj) == 18
        assert cnpj.count('.') == 2 and cnpj.count('-') == 1 and cnpj.count('/') == 1
        assert cnpj[2] == '.'
        assert cnpj[6] == '/'
        assert cnpj[10] == '-'



# Generated at 2022-06-23 20:45:01.350105
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    data = provider.cpf()
    #print(data)
    return data


# Generated at 2022-06-23 20:45:05.549298
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert(provider.cpf(False) == provider.cpf())

    cnpj = provider.cnpj(False)
    assert(cnpj == provider.cnpj()), cnpj + "|" + provider.cpf()

# Generated at 2022-06-23 20:45:06.327092
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj()

# Generated at 2022-06-23 20:45:07.007822
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:45:16.757858
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # validar se a função cpf retorna um valor com 11 caracteres
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 11
    # validar se a função cpf retorna um valor com 11 caracteres, porém sem mascara
    assert len(BrazilSpecProvider().cpf(with_mask=False)) == 11
    # validar se a função cpf não retorna um CPF com um número repetido
    c = BrazilSpecProvider()
    ccpf = c.cpf(with_mask=False)
    assert len(set(ccpf)) != 1


# Generated at 2022-06-23 20:45:24.636718
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('Test BrazilSpecProvider_cpf')
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    print(cpf)

    number = [int(i) for i in cpf.replace('.', '').replace('-', '')]
    _number = number[:-2]

    def get_verifying_digit_cpf(cpf, peso):
        soma = 0
        for index, digit in enumerate(cpf):
            soma += digit * (peso - index)
        resto = soma % 11
        if resto == 0 or resto == 1 or resto >= 11:
            return 0
        return 11 - resto

    first_dv = get_verifying_digit_cpf(_number, 10)
    _number.append(first_dv)
   

# Generated at 2022-06-23 20:45:26.832752
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    b.cpf(with_mask=False)
    b.cnpj(with_mask=False)

# Generated at 2022-06-23 20:45:28.505619
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert b.cnpj() == b.cnpj()



# Generated at 2022-06-23 20:45:30.695074
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert len(b.cnpj()) == 18
    assert len(b.cnpj(with_mask=False)) == 14


# Generated at 2022-06-23 20:45:40.005386
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    p = Person('pt_BR', seed=1)
    print(p.full_name(gender=Gender.MALE))
    print(p.full_name(gender=Gender.FEMALE))
    print(p.full_name(gender=Gender.MALE))
    print(p.full_name(gender=Gender.FEMALE))
    print(p.full_name(gender=Gender.MALE))
    print(p.full_name(gender=Gender.FEMALE))
    provider = BrazilSpecProvider()
    cpf = provider.cnpj()
    print(cpf)
    assert cpf == '86.086.472/0001-95'
    cpf = provider.cnpj()
   

# Generated at 2022-06-23 20:45:49.633795
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    # test if the function return a cpf with the correct format
    assert b.cpf(True) == b.cpf()
    # test if the function return a cpf with the correct format
    assert b.cpf(False) == b.cpf().replace('.', '').replace('-', '')
    # test if the function return a string
    assert type(b.cpf()) == str
    # test if the function return a string
    assert type(b.cpf(False)) == str
    # test if the function return a string with a length of 14
    assert len(b.cpf()) == 14
    # test if the function return a string with a length of 11
    assert len(b.cpf(False)) == 11


# Generated at 2022-06-23 20:45:51.172586
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=0)
    assert provider.cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:45:57.186838
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider class."""
    provider = BrazilSpecProvider()
    for i in range(4):
        assert len(provider.cnpj(with_mask=False)) == 14
        assert len(provider.cnpj(with_mask=True)) == 18
        assert isinstance(provider.cnpj(with_mask=True), str)


# Generated at 2022-06-23 20:46:00.354572
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Tests for constructor of BrazilSpecProvider"""
    brian = BrazilSpecProvider()

    assert brian.cpf() == "001.137.297-40"
    assert brian.cnpj() == "77.732.230/0001-70"

# Generated at 2022-06-23 20:46:05.794172
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec = BrazilSpecProvider()
    print(f'CPF: {brazil_spec.cpf()}')
    print(f'CNPJ: {brazil_spec.cnpj()}')


if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:46:11.280023
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert str(brazil.cpf()) == "331.807.049-14"
    assert str(brazil.cnpj()) == "55.660.290/0001-33"
    assert type(brazil.cpf()) == str
    assert type(brazil.cnpj()) == str


# Generated at 2022-06-23 20:46:17.667436
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider

    # Using default seed
    x = BrazilSpecProvider()
    assert x.cpf() == '028.693.931-68'

    # Using seed
    y = BrazilSpecProvider(seed=102)
    assert y.cpf() == '717.357.943-01'


# Generated at 2022-06-23 20:46:20.500568
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    print("CPF: {}".format(brazilSpecProvider.cpf(True)))
    print("CNPJ: {}".format(brazilSpecProvider.cnpj(True)))

# Execute only if it is the main program
if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:46:27.328837
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider
    from mimesis import Datetime
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider as BS
    provider = BrazilSpecProvider()
    provider.datetime = Datetime()
    provider.datetime._true_random = True
    provider.datetime._seed = '0123456789'
    provider.random._true_random = True
    provider.random._seed = '0123456789'
    provider.person = BS.Person(provider.random, provider.datetime)
    provider.person._true_random = True
    provider.person._seed = '0123456789'
    provider.person._gender = Gender.FEMALE
    provider.person.random = provider.random
    provider.person.datetime = provider.datetime

# Generated at 2022-06-23 20:46:34.919246
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  from mimesis.enums import Gender
  from mimesis.builtins.brazil import BrazilSpecProvider
  from mimesis.person import Person
  from mimesis.providers.date_time import DateTime
  from mimesis.providers.address import Address
  from mimesis.providers.business import Business
  from mimesis.builtins.brazil import BrazilSpecProvider
  from mimesis.builtins.credit_card import CreditCard
  from mimesis.builtins.payment import Payment
  
  BR = BrazilSpecProvider()
  pt = Person('pt-BR')
  ad = Address('pt-BR')
  bz = Business('pt-BR')
  ct = CreditCard('pt-BR')
  py = Payment('pt-BR')
  dt = DateTime('pt-BR')


# Generated at 2022-06-23 20:46:40.244249
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == "83.269.886/0001-70"
    assert BrazilSpecProvider(seed=42).cnpj() == "82.684.083/0001-76"
    assert BrazilSpecProvider(seed="Brazil").cnpj() == "89.487.157/0001-36"


# Generated at 2022-06-23 20:46:44.154950
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bspcnpj = BrazilSpecProvider()
    cnpj = bspcnpj.cnpj()
    assert len(cnpj) == 18
    cnpj = bspcnpj.cnpj(False)
    assert len(cnpj) == 14


# Generated at 2022-06-23 20:46:47.587039
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    test_BrazilSpecProvider = BrazilSpecProvider()
    assert test_BrazilSpecProvider.Meta.provider_name == 'brazil_provider'
    assert test_BrazilSpecProvider.Meta.locale == 'pt-br'


# Generated at 2022-06-23 20:46:58.674142
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    import json
    from mimesis.enums import Gender

    with open('utils/data/pt-br.json') as file:
        data = json.load(file)
    
    provider = BrazilSpecProvider()

    cpf_male = provider.cpf(Gender.MALE)
    assert re.search(r'^[0-9]{3}.[0-9]{3}.[0-9]{3}-[0-9]{2}$', cpf_male) is not None
    cpf_female = provider.cpf(Gender.FEMALE)
    assert re.search(r'^[0-9]{3}.[0-9]{3}.[0-9]{3}-[0-9]{2}$', cpf_female) is not None

    cpf

# Generated at 2022-06-23 20:47:05.810033
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj(with_mask=True)
    cnpj_dv = BrazilSpecProvider().cnpj(with_mask=False)
    assert cnpj == cnpj_dv[:2] + '.' + cnpj_dv[2:5] + '.' + cnpj_dv[5:8] + '/' + cnpj_dv[8:12] + '-' + cnpj_dv[12:]
        # assert cnpj == cnpj_dv[:2] + '.' + cnpj_dv[2:5] + '.' + cnpj_dv[5:8] + '/' + cnpj_dv[8:12] + '-' + cnpj_dv[12:]


# Generated at 2022-06-23 20:47:14.341804
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import unittest
    import re
    class BrazilSpecProvider_cnpj(unittest.TestCase):
        def setUp(self):
            self.cnpj = BrazilSpecProvider().cnpj(with_mask=False)

        def test_cnpj_general(self):
            self.assertEqual(len(self.cnpj), 14)

        def test_cnpj_mask(self):
            self.assertRegex(BrazilSpecProvider().cnpj(), re.compile('^\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}$'))

        def test_cnpj_without_mask(self):
            self.assertRegex(self.cnpj, re.compile('^\d{14}$'))

