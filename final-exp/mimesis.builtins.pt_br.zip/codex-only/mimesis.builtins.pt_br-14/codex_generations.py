

# Generated at 2022-06-23 20:37:13.541130
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    
    cpfs = []
    while True:
        cpf = b.cpf(with_mask=False)
        if cpf in cpfs:
            break
        cpfs.append(cpf)
    assert len(cpfs) == 999



# Generated at 2022-06-23 20:37:17.555856
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    generator = BrazilSpecProvider()
    a = generator.cpf(False)
    assert len(a) == 11
    b = generator.cpf()
    assert len(b) == 14


# Generated at 2022-06-23 20:37:25.985724
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from unittest import TestCase

    class _TestBrazilSpecProvider(TestCase):
        def test_cpf(self):
            from mimesis.builtins import BrazilSpecProvider as pt_br

            n = pt_br()
            cpf = n.cpf()

            self.assertEqual(len(cpf), 14)

            # Check if CPF is valid.
            cpf_without_dv = [int(digit) for digit in cpf if digit.isdigit()]

            self.assertEqual(len(cpf_without_dv), 11)

            first_dv = n.get_verifying_digit_cpf(cpf_without_dv, 10)

            self.assertEqual(cpf_without_dv[9], first_dv)


# Generated at 2022-06-23 20:37:33.354557
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    provider = BrazilSpecProvider()
    person = Person(provider.locale)
    name = person.full_name(gender=Gender.MALE)
    cpf = provider.cpf()

    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert '.' in cpf
    assert '-' in cpf
    assert ' ' not in cpf


# Generated at 2022-06-23 20:37:39.063118
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.specifiers.brazil import BrazilSpecProvider

    for _ in range(10):
        cnpj = BrazilSpecProvider().cnpj()
        assert len(cnpj) == 18

        BaseSpecProvider(locale="pt-br").cnpj()
        assert len(cnpj) == 18

# Generated at 2022-06-23 20:37:40.556620
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider class."""
    brazilSpecProvider = BrazilSpecProvider()
    assert brazilSpecProvider is not None


# Generated at 2022-06-23 20:37:50.905235
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    assert cnpj.count('-') == 1
    assert cnpj[2] != '.'
    assert cnpj[6] != '.'
    assert cnpj[11] != '/'
    assert cnpj[15] != '-'
    assert cnpj[2] != '0'
    assert cnpj[5] != '0'
    assert cnpj[8] != '0'
    assert cnpj[12] != '0'

    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14


# Generated at 2022-06-23 20:37:53.982517
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cpf())
    print(brazil_provider.cnpj())


# Generated at 2022-06-23 20:37:57.073475
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_1 = BrazilSpecProvider().cnpj()
    cnpj_2 = BrazilSpecProvider().cnpj(with_mask=False)

    assert len(cnpj_1) > len(cnpj_2)


# Generated at 2022-06-23 20:38:01.472806
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    '''
    Function to test cnpj method of class BrazilSpecProvider
    Parameters
    ----------
    No Parameters
    Returns
    -------
    No returns
    '''
    # Creation of class BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()

    for i in range(10):
        # Calling method cnpj
        cnpj = brazil_spec_provider.cnpj()
        print(cnpj)

# Generated at 2022-06-23 20:38:03.947474
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = '36.310.929/0001-63'
    bsp = BrazilSpecProvider()
    assert cnpj == bsp.cnpj(with_mask=True)

# Generated at 2022-06-23 20:38:07.302089
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert len(brazil.__all__) == 2
    assert brazil.cpf() != None
    assert brazil.cnpj() != None
    assert 0 <= brazil.random.randint(0, 9) <= 9


# Generated at 2022-06-23 20:38:15.480227
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    provider = BrazilSpecProvider()
    # type(provider) is BrazilSpecProvider
    assert type(provider) == BrazilSpecProvider
    # Get CPF with mask
    cpf_with_mask = provider.cpf()
    assert cpf_with_mask
    assert provider.cpf(with_mask=True) == cpf_with_mask
    # Get CPF without mask
    cpf_without_mask = provider.cpf(with_mask=False)
    assert cpf_without_mask
    assert cpf_with_mask.replace('.','').replace('-','') == cpf_without_mask
    # Get CPF with mask for a man
    man_cpf = provider.cpf(with_mask=True, gender=Gender.MALE)
    assert man

# Generated at 2022-06-23 20:38:18.075887
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj(True) == '77.732.230/0001-70'
    assert provider.cnpj(False) == '77732240000170'


# Generated at 2022-06-23 20:38:24.662864
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=1)
    assert cnpj[:12].isdigit()
    assert cnpj[13].isdigit()
    assert cnpj[15].isdigit()
    assert cnpj[12] == '.'
    assert cnpj[8] == '.'
    assert cnpj[4] == '.'
    assert cnpj[14] == '-'
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:38:28.297341
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert brazil.cnpj(with_mask = True) == '77.732.230/0001-70'
    assert brazil.cnpj(with_mask = False) == '77732', '230000170'


# Generated at 2022-06-23 20:38:30.240360
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Construtor test")
    BrazilSpecProvider(seed=1)
    print("Pass\n")


# Generated at 2022-06-23 20:38:32.000860
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    _ = BrazilSpecProvider()
    _ = BrazilSpecProvider("")
    _ = BrazilSpecProvider("Testing")



# Generated at 2022-06-23 20:38:38.271694
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    # Test 1: Check whether the generated CNPJ is a valid one
    print(provider.cnpj())
    if not re.match(r'([0-9]{2}[.]?[0-9]{3}[.]?[0-9]{3}[/]?[0-9]{4}[-]?[0-9]{2}$)',
            provider.cnpj()):
        sys.exit(1)

    # Test 2: Check whether the generated CNPJ is a valid one
    print(provider.cnpj())

# Generated at 2022-06-23 20:38:40.412300
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    brazil_spec_provider = BrazilSpecProvider(seed=0) # Instance BrazilSpecProvider
    assert(brazil_spec_provider.cpf() == '211.520.736-28') # Test method cpf


# Generated at 2022-06-23 20:38:44.027398
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18
    cnpj = bsp.cnpj(with_mask=False)
    assert len(cnpj) == 14

# Generated at 2022-06-23 20:38:47.368111
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf  = provider.cpf()
    assert cpf == "591.503.369-72"


# Generated at 2022-06-23 20:38:51.302894
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()  # 582.319.126-73
    assert isinstance(cpf, str)
    assert len(cpf) == 14


# Generated at 2022-06-23 20:38:53.400191
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider is not None 
    assert isinstance(provider, BrazilSpecProvider)


# Generated at 2022-06-23 20:38:54.857097
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cnpj()

# Generated at 2022-06-23 20:38:58.068007
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    # Test for validate cpf.
    b = BrazilSpecProvider()
    a = b.cpf()
    assert a == '595.903.873-22'



# Generated at 2022-06-23 20:39:03.940586
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    Test BrazilSpecProvider.cnpj()

    :return: None
    """
    # cnpj with mask
    obj = BrazilSpecProvider()
    assert(len(obj.cnpj()) == 18)

    # cnpj without mask
    obj = BrazilSpecProvider()
    assert(len(obj.cnpj(False)) == 14)



# Generated at 2022-06-23 20:39:11.410304
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import sys
    import os
    import time
    import datetime
    
    sys.path.append(os.getcwd())

    import src.providers.brazil.brazil_provider as brazil_provider

    # Initializing global namespaces
    print("Initializing global namespaces ...")
    
    person = brazil_provider.BrazilSpecProvider()

    # Running unit test for class BrazilSpecProvider
    print("Running unit test for class BrazilSpecProvider ...")
    print("BrazilSpecProvider.cpf() == ", person.cpf())
    print("BrazilSpecProvider.cnpj() == ", person.cnpj())
    print("BrazilSpecProvider.cnpj(with_mask=False) == ", person.cnpj(with_mask=False))

    # Class documentation

# Generated at 2022-06-23 20:39:15.385708
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf() is not None
    assert brazil.cnpj() is not None

# Generated at 2022-06-23 20:39:20.407504
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Get a random CNPJ.
        :param with_mask: Use cnpj mask (###.###.###-##)
        :returns: Random cnpj.
    """
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '77.732.230/0001-70'
    assert bsp.cnpj(with_mask=False) == '77732'

# Generated at 2022-06-23 20:39:22.279871
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert brazil.cnpj() != brazil.cnpj()


# Generated at 2022-06-23 20:39:24.562543
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    assert BrazilSpecProvider() is not None


# Generated at 2022-06-23 20:39:31.001989
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    generator = BrazilSpecProvider()

    # Test for cpf function
    cpf = generator.cpf()
    print(f"cpf = {cpf}")
    assert len(cpf) == 14   # with mask
    assert isinstance(cpf[0], str)

    cpf = generator.cpf(with_mask=False)
    print(f"cpf = {cpf}")
    assert len(cpf) == 11  # without mask
    assert isinstance(cpf[0], str)

    # Test for cnpj function
    cnpj = generator.cnpj()
    print(f"cnpj = {cnpj}")
    assert len(cnpj) == 18   # with mask
    assert isinstance(cnpj[0], str)

    cnpj = generator.cnp

# Generated at 2022-06-23 20:39:33.756444
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    print(brazil.cpf())
    print(brazil.cnpj())

# Generated at 2022-06-23 20:39:38.037675
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider(seed=0)  # instantiate the class
    cnpj1 = p.cnpj(with_mask=False)
    cnpj2 = p.cnpj(with_mask=False)
    print(cnpj1)
    print(cnpj2)


# Generated at 2022-06-23 20:39:41.932822
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()

    assert isinstance(provider, BaseSpecProvider)
    assert isinstance(provider, BrazilSpecProvider)



# Generated at 2022-06-23 20:39:44.250191
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    locale = 'pt-br'
    with_mask = True
    provider = BrazilSpecProvider()
    assert len(provider.cpf(with_mask)) == 14


# Generated at 2022-06-23 20:39:47.524826
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj."""
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '77.732.230/0001-70'
    assert bsp.cnpj(False) == '77732230000170'

# Generated at 2022-06-23 20:39:49.675553
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) > 13


# Generated at 2022-06-23 20:39:50.633271
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()



# Generated at 2022-06-23 20:39:59.292542
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider cnpj method."""
    cnpj_list = [
        '77.732.230/0001-70',
        '14.726.995/0001-46',
        '00.876.229/0001-55',
        '62.843.220/0001-29',
        '08.221.056/0001-03',
        '71.111.831/0001-50',
    ]
    bsp = BrazilSpecProvider()
    for i in range(0, 100):
        cnpj = bsp.cnpj(with_mask=True)
        assert cnpj in cnpj_list
        assert len(cnpj) == 18
        assert cnpj[2] == '.'
        assert cnpj[6] == '.'
        assert cnp

# Generated at 2022-06-23 20:40:02.714743
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert isinstance(brazil_provider,BaseSpecProvider)
    assert brazil_provider.provider == 'pt-br'
    assert isinstance(brazil_provider.random, Seed)


# Generated at 2022-06-23 20:40:03.636859
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=12345)

# Generated at 2022-06-23 20:40:06.541552
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()

    cnpj = brazil_spec_provider.cnpj()
    assert(len(cnpj) == 18)

    cpf = brazil_spec_provider.cpf()
    assert(len(cpf) == 14)
    
    print(cnpj)
    print(cpf)

# Generated at 2022-06-23 20:40:10.735244
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert isinstance(cpf, str)


# Generated at 2022-06-23 20:40:13.425461
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() != None
    assert brazil_provider.cpf(False) != None
    assert brazil_provider.cnpj() != None
    assert brazil_provider.cnpj(False) != None
    return True
test_BrazilSpecProvider()


# Generated at 2022-06-23 20:40:17.789140
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    res1 = brazil_spec_provider.cpf()
    res2 = brazil_spec_provider.cpf(with_mask=False)
    assert len(res1) == 14
    assert len(res2) == 11


# Generated at 2022-06-23 20:40:21.321003
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import pytest
    br = BrazilSpecProvider()
    assert br.cpf() in ['001.137.297-40', '688.936.492-04']
    assert br.cpf(with_mask=False) in ['00113729740', '68893649204']
    with pytest.raises(NotImplementedError):
        br.cpf(with_mask=False, format='%d.%d.%d-%d')


# Generated at 2022-06-23 20:40:26.701425
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf_with_mask = provider.cpf()
    cpf_without_mask = provider.cpf(with_mask=False)
    assert cpf_with_mask == "549.405.067-32"
    assert cpf_without_mask == "54940506732"


# Generated at 2022-06-23 20:40:29.304763
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()
    print(br.cpf())
    print(br.cnpj())


# Generated at 2022-06-23 20:40:38.440468
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import sys
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.typing import Seed
    from pprint import pprint
    from random import Random
    from time import time

    # Set seed for the random number generator, for unit testing and
    # reproducibility
    seed = Seed(int(time()))
    seed.reset()

    # Create an instance of BrazilSpecProvider and test the cpf method
    provider = BrazilSpecProvider(seed=seed)
    cpf = provider.cpf()
    print("\ncpf = provider.cpf()")
    pprint(cpf)

    # Create a random number generator and test the cpf method
    rnd = Random(seed())
    cpf = rnd.cpf()
    print("\ncpf = rnd.cpf()")
    p

# Generated at 2022-06-23 20:40:39.571020
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()


# Generated at 2022-06-23 20:40:45.443954
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj"""
    gen = BrazilSpecProvider()
    cnpj = gen.cnpj()
    cnpj_assert = '{}.{}.{}/{}-{}'.format(cnpj[:2], cnpj[2:5],
                                          cnpj[5:8], cnpj[8:12], cnpj[12:])
    assert(len(cnpj_assert) == 18)


# Generated at 2022-06-23 20:40:51.490940
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test for the method cnpj of class BrazilSpecProvider
    # Test case 1
    # cnpj = '44.854.465/0001-62'
    # value = '44.854.465/0001-62'
    # result = BrazilSpecProvider.cnpj()
    # assert result == value
    pass

# Generated at 2022-06-23 20:40:55.795493
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert isinstance(result, str)
    assert len(result) == 14
    assert result[3] == '.' and result[7] == '.' and result[11] == '-'
    assert result[12:] != '00'


# Generated at 2022-06-23 20:40:58.401450
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider(seed = 1)
    print(brazil_provider.cpf(with_mask = True))
    print(brazil_provider.cnpj(with_mask = True))

# Generated at 2022-06-23 20:40:59.255528
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BrazilSpecProvider.cnpj()


# Generated at 2022-06-23 20:41:02.648952
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test of BrazilSpecProvider.cnpj()."""
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    
    
    brazil = BrazilSpecProvider('en')
    
    for i in range(10):
        cnpj = brazil.cnpj()
        print(cnpj)

# Generated at 2022-06-23 20:41:06.067195
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert len(result) == 14


# Generated at 2022-06-23 20:41:09.260375
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '898.189.184-22'

if __name__ == '__main__':
    test_BrazilSpecProvider_cpf()

# Generated at 2022-06-23 20:41:10.839361
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    ptbr = BrazilSpecProvider()

    assert ptbr is not None


# Generated at 2022-06-23 20:41:14.220668
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf()."""
    generator = BrazilSpecProvider()
    cpf = generator.cpf()
    assert cpf == generator.cpf(False)
    assert len(cpf) == 14


# Generated at 2022-06-23 20:41:16.641988
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'
    assert BrazilSpecProvider().cnpj(False) == '77732230000170'


# Generated at 2022-06-23 20:41:23.127728
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    br = BrazilSpecProvider()

    cnpj = br.cnpj()
    assert len(cnpj) == 18, "method cnpj of class BrazilSpecProvider is wrong"

    cnpj = br.cnpj(with_mask=False)
    assert len(cnpj) == 14, \
        "method cnpj of class BrazilSpecProvider is wrong"


# Generated at 2022-06-23 20:41:24.622521
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider()
    assert instance is not None


# Generated at 2022-06-23 20:41:35.037823
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    # Instance of class BrazilSpecProvider (using random seed)
    brazil_provider = BrazilSpecProvider()

    # Use CPF mask (###.###.###-##)
    cpf_with_mask = brazil_provider.cpf(with_mask=True)
    # => 001.137.297-40

    # Use CPF mask (###########)
    cpf_without_mask = brazil_provider.cpf(with_mask=False)
    # => 00113729740

    # Use cnpj mask (###.###.###-##)
    cnpj_with_mask = brazil_provider.cnpj(with_mask=True)
    # => 77.732.230/0001-70

    # Use cnpj mask (###########)
    cnpj_without_

# Generated at 2022-06-23 20:41:39.235560
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed = 0)
    assert provider.cpf(with_mask = True) == '212.007.499-13'
    assert provider.cnpj(with_mask = True) == '17.265.061/0001-07'

# Generated at 2022-06-23 20:41:41.439413
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('Teste para o construtor da classe BrazilSpecProvider')
    brazilSpecProvider = BrazilSpecProvider()
    print('Teste finalizado')


# Generated at 2022-06-23 20:41:43.076567
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider(seed=1)
    assert b.cpf() == '846.346.783-73'



# Generated at 2022-06-23 20:41:45.534653
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cpf = BrazilSpecProvider().cnpj()
    len(cpf) == 14
    assert cpf == '00.000.000/0001-91'


# Generated at 2022-06-23 20:41:48.003336
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf == bsp.cpf()


# Generated at 2022-06-23 20:41:51.000784
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=1)
    assert provider.cnpj() == '34.735.397/0001-30'


# Generated at 2022-06-23 20:41:56.835715
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    
    p = Person('pt-br')
    c = BrazilSpecProvider()
    cnpj = c.cnpj()
    cnpj_list = []
    erro = 0
    for i in range(50):
        cnpj = c.cnpj()
        cnpj_list.append(cnpj)
        if len(cnpj_list) != len(set(cnpj_list)):
            erro += 1
    assert erro == 0
    assert len(cnpj_list) == 50
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:42:02.465898
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
	assert BrazilSpecProvider(seed='123').cpf() == '877.872.622-50'
	assert BrazilSpecProvider(seed='123').cnpj() == '29.223.999/0001-30'

	assert BrazilSpecProvider(seed='123').cpf(with_mask=False) == '877872.96.722'
	assert BrazilSpecProvider(seed='123').cnpj(with_mask=False) == '2922390001.30'

# Generated at 2022-06-23 20:42:05.785867
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """UnitTest for BrazilSpecProvider class."""
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14, "unit test of cpf() is failed!"
    cnpj = provider.cnpj()
    assert len(cnpj) == 18, "unit test of cnpj() is failed!"

# Generated at 2022-06-23 20:42:10.068539
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cnpj() == '76.544.133/0001-39' or BrazilSpecProvider().cnpj() == '98.005.420/0001-74' or BrazilSpecProvider().cnpj() == '24.835.497/0001-66'



# Generated at 2022-06-23 20:42:13.305715
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '24.731.869/0001-74'
    assert provider.cnpj(with_mask=False) == '24726556000186'

test_BrazilSpecProvider()

# Generated at 2022-06-23 20:42:18.733429
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # pylint: disable=unused-variable
    # pylint: disable=W0612

    assert '77.732.230/0001-70' in BrazilSpecProvider().cnpj()
    assert '7773223000170' not in BrazilSpecProvider().cnpj()



# Generated at 2022-06-23 20:42:22.321747
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    x = BrazilSpecProvider().cpf(with_mask=True)
    assert len(x) == 14
    assert x[3] == x[7] == '.'
    assert x[11] == '-'


# Generated at 2022-06-23 20:42:25.983556
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=13)

# python -c 'import pt_br.brazil_provider; pt_br.brazil_provider.test_BrazilSpecProvider()'

# Generated at 2022-06-23 20:42:27.986088
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.cpf()
    assert bsp.cnpj()

# Generated at 2022-06-23 20:42:30.117241
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == "001.137.297-40"


# Generated at 2022-06-23 20:42:33.656933
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """function"""
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cnpj(with_mask=False))
#6d7b6ec20305bff7d6f853b35c88b1ab


# Generated at 2022-06-23 20:42:34.711851
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 18

# Generated at 2022-06-23 20:42:41.146262
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Method cnpj of class BrazilSpecProvider()
    # Creation of an object of class BrazilSpecProvider()
    # Instance provider of BrazilSpecProvider()
    provider = BrazilSpecProvider('104015664910123')

    # Obtaining a random cnpj
    provider.cnpj()

    # See docstring at BrazilSpecProvider.cnpj()


# Generated at 2022-06-23 20:42:49.372646
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Creating an object of class BrazilSpecProvider
    custom1 = BrazilSpecProvider()

    # Creating a list with cnpj without mask
    cnpj_list = []

    # Creating a list with cnpj with mask
    cnpj_list_mask = []

    # Creating a list with cnpj with mask and its respective cnpj_list
    cnpj_mask_list = []

    for i in range(100):
        cnpj_list.append(custom1.cnpj())
        cnpj_list_mask.append(custom1.cnpj(with_mask=True))
        cnpj_mask_list.append([custom1.cnpj(with_mask=True), custom1.cnpj()])

    # Using list comprehension

# Generated at 2022-06-23 20:43:00.470062
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '09.382.173/0001-43'
    assert provider.cnpj() == '69.914.921/0001-56'
    assert provider.cnpj() == '47.236.374/0001-90'
    assert provider.cnpj() == '68.126.914/0001-06'
    assert provider.cnpj() == '38.766.206/0001-77'
    assert provider.cnpj() == '90.378.426/0001-92'
    assert provider.cnpj() == '26.944.510/0001-73'
    assert provider.cnpj() == '87.625.871/0001-32'

# Generated at 2022-06-23 20:43:03.588885
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    cdata = BrazilSpecProvider()
    # test constructor
    assert cdata.locale == 'pt-br'

# Generated at 2022-06-23 20:43:12.087560
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    for i in range(1000):
        cnpj = brazil.cnpj(True)
        assert cnpj[2] == "."
        assert cnpj[6] == "."
        assert cnpj[10] == "/"
        assert cnpj[15] == "-"
        assert cnpj[0:2].isdigit()
        assert cnpj[3:6].isdigit()
        assert cnpj[7:10].isdigit()
        assert cnpj[11:15].isdigit()
        assert cnpj[16:].isdigit()
        assert len(cnpj) == 18


# Generated at 2022-06-23 20:43:13.914048
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test if method cnpj of BrazilSpecProvider is working as expected."""
    assert BrazilSpecProvider().cnpj() == '02.746.841/0001-32'
    assert BrazilSpecProvider().cnpj(with_mask=False) == '02746841000132'


# Generated at 2022-06-23 20:43:16.814072
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:43:20.907503
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'
    assert BrazilSpecProvider().cnpj(with_mask=False) == '77732242000170'


# Generated at 2022-06-23 20:43:21.883845
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    Brazil = BrazilSpecProvider()
    return Brazil

# Generated at 2022-06-23 20:43:26.061722
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""

    provider = BrazilSpecProvider()
    assert provider.__class__.__name__ == 'BrazilSpecProvider'

    assert provider._data_dir == 'mimesis/data/pt-br'

    assert provider.__doc__ == __doc__

# Generated at 2022-06-23 20:43:27.301613
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:43:28.866033
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert obj


# Generated at 2022-06-23 20:43:35.388440
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    actual_cnpj = cnpj
    expected_cnpj = '66.535.918/0001-00'
    assert actual_cnpj == expected_cnpj

    cnpj = brazil.cnpj(with_mask=False)
    actual_cnpj = cnpj
    expected_cnpj = '66535918000100'
    assert actual_cnpj == expected_cnpj


# Generated at 2022-06-23 20:43:41.051769
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    Test cnpj method of class BrazilSpecProvider.
    """
    for _ in range(100):
        cnpj = BrazilSpecProvider().cnpj(with_mask=True)
        assert len(cnpj) == 18
        assert cnpj[2] == '.' and cnpj[6] == '.' and cnpj[10] == '/' and cnpj[15] == '-'


# Generated at 2022-06-23 20:43:44.303548
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Creation of instance of class BrazilSpecProvider
    BrazilSpecProvider_instance = BrazilSpecProvider()

    # Call cnpj
    BrazilSpecProvider_instance.cnpj(False)

# Generated at 2022-06-23 20:43:45.148729
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    prov = BrazilSpecProvider()
    assert isinstance(prov, BrazilSpecProvider)

# Generated at 2022-06-23 20:43:47.582909
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test method cnpj of class BrazilSpecProvider."""
    cnpj = BrazilSpecProvider().cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:43:50.735624
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # call the function
    result = BrazilSpecProvider.cpf(with_mask=True)
    # assert
    assert ("." in result) and ("-" in result) and (len(result) == 14)


# Generated at 2022-06-23 20:43:53.439598
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert(len(BrazilSpecProvider().cpf(False)) == 11)
    assert(len(BrazilSpecProvider().cpf(True)) == 14)


# Generated at 2022-06-23 20:43:56.414347
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()
    print("CNPJ: " + br.cnpj())
    print("CPF: " + br.cpf())

test_BrazilSpecProvider()

# Generated at 2022-06-23 20:43:58.260442
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    data = BrazilSpecProvider()
    assert data.cpf()
    assert data.cnpj()

# Unit tests for methods of class BrazilSpecProvider

# Generated at 2022-06-23 20:43:59.914528
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:44:02.012332
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert(provider.locale == 'pt-br')
    assert(provider.seed is not None)

# Generated at 2022-06-23 20:44:03.809638
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    assert type(brazil_provider.cnpj(True)) == str



# Generated at 2022-06-23 20:44:09.508722
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Test case: cpf()")
    br_spec = BrazilSpecProvider()
    cpf = br_spec.cpf()
    print("cpf = " + cpf)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:44:12.758578
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = '966.972.217-21'
    provider = BrazilSpecProvider()
    result = provider.cpf(with_mask=True)
    assert result == cpf


# Generated at 2022-06-23 20:44:15.892030
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpjs = [provider.cnpj() for _ in range(20)]

    assert len(cnpjs) == 20

    for cnpj in cnpjs:
        assert len(cnpj) == 18

# Generated at 2022-06-23 20:44:18.964649
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cpf(with_mask=False) == '0011372974'

# Generated at 2022-06-23 20:44:21.978944
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for BrazilSpecProvider"""
    BSP = BrazilSpecProvider()
    assert BSP.cpf()
    assert BSP.cnpj()

# Generated at 2022-06-23 20:44:23.261735
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    # check if provider is object of class BrazilSpecProvider
    assert isinstance(provider, BrazilSpecProvider)


# Generated at 2022-06-23 20:44:24.838878
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == '068.164.841-02'
    assert bsp.cpf(with_mask=False) == '06816484102'



# Generated at 2022-06-23 20:44:29.447772
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    PROVIDER = BrazilSpecProvider()
    cnpj = PROVIDER.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == "."
    assert cnpj[6] == "."
    assert cnpj[10] == "/"
    assert cnpj[15] == "-"
    assert cnpj[12:14] != "00"
    assert cnpj[17] != "0"


# Generated at 2022-06-23 20:44:40.667977
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    Test if function cnpj of class BrazilSpecProvider returns a valid brazilian CNPJ.
    A CNPJ is valid if, reading from left to right, first two digits are not equal,
    the sum of first 9 digits modulo 11 is equal to two last digits and the sum of
    first 12 digits modulo 11 is equal to the CNPJ's last two digits.
    """
    provider = BrazilSpecProvider()

    def get_verifying_digit_cnpj(cnpj, peso):
        """
        Calculate the verifying digit for the CNPJ.
        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0

# Generated at 2022-06-23 20:44:42.512677
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for BrazilSpecProvider"""

    bsp = BrazilSpecProvider()
    for i in range(10):
        print(bsp.cnpj())


# Generated at 2022-06-23 20:44:45.376646
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    result = BrazilSpecProvider()
    assert result.cpf()
    assert result.cnpj()

# Generated at 2022-06-23 20:44:46.425575
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = BrazilSpecProvider().cpf()
    assert len(result) == 14


# Generated at 2022-06-23 20:44:57.543201
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Validation test for method cnpj of class BrazilSpecProvider"""
    print("Validation test for method cnpj of class BrazilSpecProvider: Start")
    br = BrazilSpecProvider()

    # Test 1: Validate CNPJ without mask
    print("Validate CNPJ without mask")
    cnpj = br.cnpj(False)
    assert len(cnpj) == 14
    assert cnpj.isdigit()

    # Test 2: Validate CNPJ with mask
    print("Validate CNPJ with mask")
    cnpj = br.cnpj(True)
    assert len(cnpj) == 18
    assert cnpj.isdigit() == False
    assert "." in cnpj
    assert "/" in cnpj
    assert "-" in cnpj


# Generated at 2022-06-23 20:45:03.994389
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for BrazilSpecProvider"""
    brazil_provider = BrazilSpecProvider()

    assert brazil_provider is not None
    assert brazil_provider.cpf() is not None
    assert brazil_provider.cnpj() is not None



if __name__ == "__main__":
    print(BrazilSpecProvider().cnpj())
    print(BrazilSpecProvider().cpf())

# Generated at 2022-06-23 20:45:11.087733
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj."""
    def check_cnpj(cnpj: str) -> bool:
        """Check if the cnpj is valid."""
        if len(cnpj) != 14:
            return False

        temp = cnpj[:-2]
        base = [int(x) for x in temp]

        # Calculate the first digit.
        result = 0
        for index, digit in enumerate(base):
            result = result + digit * (5 - index)

        result = result % 11
        if result < 2:
            first_digit = 0
        else:
            first_digit = 11 - result

        base.append(first_digit)

        # Calculate the second digit.
        result = 0
        for index, digit in enumerate(base):
            result = result + digit

# Generated at 2022-06-23 20:45:12.679455
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider is not None
    assert provider.cpf() is not None
    assert provider.cnpj() is not None
    assert provider.cnpj(with_mask=False) is not None

# Generated at 2022-06-23 20:45:17.436231
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilSpecProvider = BrazilSpecProvider()
    cnpj = brazilSpecProvider.cnpj(False)
    assert len(cnpj) == 14
    assert cnpj[2] == "."
    assert cnpj[6] == "."
    assert cnpj[10] == "/"
    assert cnpj[15] == "-"


# Generated at 2022-06-23 20:45:18.553051
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    assert len(br.cpf()) == 14


# Generated at 2022-06-23 20:45:20.819715
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=199890907)
    result = provider.cpf()
    assert result == '524.756.906-14'


# Generated at 2022-06-23 20:45:24.980682
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    assert br.cpf() == "558.153.362-24"
    assert br.cpf(with_mask=False) == "55815336256"


# Generated at 2022-06-23 20:45:27.518134
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    print('\nBrazilSpecProvider.cpf()')
    print('*******************************')
    print(bsp.cpf())



# Generated at 2022-06-23 20:45:32.775997
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    # Seed has been set to 3
    brazil_spec_provider = BrazilSpecProvider()
    # with_mask = True
    assert brazil_spec_provider.cpf(with_mask=True) == "868.359.603-73"
    # with_mask = False
    assert brazil_spec_provider.cpf(with_mask=False) == "76322631673"


# Generated at 2022-06-23 20:45:34.577212
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:45:36.744392
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
   bz = BrazilSpecProvider()
   print(bz.cnpj())
   print(type(bz.cnpj()))



# Generated at 2022-06-23 20:45:38.420898
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert len(provider.cnpj()) == 18


# Generated at 2022-06-23 20:45:39.968856
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    print(b.cpf())
    print(b.cnpj())

# Generated at 2022-06-23 20:45:44.378276
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider(seed=123)
    assert bsp.cpf() == '450.129.520-35'
    assert bsp.cpf(with_mask=False) == '45012952035'


# Generated at 2022-06-23 20:45:46.002728
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert isinstance(brazil, BrazilSpecProvider)


# Generated at 2022-06-23 20:45:47.894610
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider() is not None

# Generated at 2022-06-23 20:45:52.366599
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf(with_mask=False) not in (None, '', ' ')
    assert brazil_provider.cnpj(with_mask=False) not in (None, '', ' ')

# Generated at 2022-06-23 20:45:53.022336
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()

# Generated at 2022-06-23 20:45:54.761342
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider(None)
    brazil_provider.cnpj()
    pass

# Generated at 2022-06-23 20:45:57.352371
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bz_provider = BrazilSpecProvider()
    assert bz_provider.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-23 20:45:59.407276
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    x = BrazilSpecProvider(seed=1).cpf()
    assert x == '941.914.092-94'


# Generated at 2022-06-23 20:46:00.755975
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider is not None


# Generated at 2022-06-23 20:46:01.965332
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert(BrazilSpecProvider() is not None)

# Generated at 2022-06-23 20:46:05.847042
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf()) == 14
    assert brazil.cpf(with_mask=False) in brazil.cpf()


# Generated at 2022-06-23 20:46:14.421386
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("Test for BrazilSpecProvider method cnpj")

    brazil = BrazilSpecProvider()
    cnpj_with_mask = brazil.cnpj()
    cnpj_without_mask = brazil.cnpj(with_mask=False)

    cnpj_without_mask_unmasked = cnpj_with_mask.replace('.', '')
    cnpj_without_mask_unmasked = cnpj_without_mask_unmasked.replace('-', '')
    cnpj_without_mask_unmasked = cnpj_without_mask_unmasked.replace('/', '')

    print(cnpj_with_mask)
    print(cnpj_without_mask)

# Generated at 2022-06-23 20:46:19.783985
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    bs = BrazilSpecProvider(seed=42)
    assert bs.cpf() == '506.106.598-01'
    assert bs.cpf(with_mask=False) == '5061065980'
    # No mask
    assert bs.cpf(with_mask=False) == '5061065980'


# Generated at 2022-06-23 20:46:26.288890
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf.
    The cpf method returns a string with the CPF.
    I don't know if the CPF is valid or not.
    So I will check if the method returns a string.
    """
    provider = BrazilSpecProvider()
    assert isinstance(provider.cpf(), str)
    assert isinstance(provider.cpf(with_mask=False), str)


# Generated at 2022-06-23 20:46:27.715840
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    print(bsp.cpf())


# Generated at 2022-06-23 20:46:32.756860
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Arrange
    from mimesis.enums import Format
    seed = 42
    spec = BrazilSpecProvider(seed)
    with_mask = False

    # Act
    result = spec.cnpj(with_mask)

    # Assert
    assert result == '41382938000156'
    assert spec.cnpj(Format.FORMAT.value) == '41.382.938/0001-56'



# Generated at 2022-06-23 20:46:35.124911
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    print(bsp.cnpj())
    print(bsp.cnpj(with_mask=True))

# Generated at 2022-06-23 20:46:41.637672
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj method."""
    # Number of tries to check there is no invalid generated cnpj
    number_tries = 1000

    provider = BrazilSpecProvider()
    # Testing method cnpj with and without mask
    for _ in range(number_tries):
        assert len(provider.cnpj()) == 14
        assert len(provider.cnpj(with_mask=False)) == 14



# Generated at 2022-06-23 20:46:51.641748
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        elif peso == 6:
            peso_list = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        for i, _ in enumerate(cnpj):
            soma += peso_

# Generated at 2022-06-23 20:46:56.881085
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj() method."""
    brazil = BrazilSpecProvider()
    assert len(brazil.cnpj(False)) == 14
    assert len(brazil.cnpj()) == 18
    assert not brazil.cnpj(False).startswith('00')
    assert not brazil.cnpj().startswith('00')



# Generated at 2022-06-23 20:47:04.710816
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.base import BaseProvider
    from random import randint
    from mimesis.enums import Gender
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    p = BaseProvider(seed=randint(0, 100000))
    person = Person(seed=p.seed)
    address = Address(seed=person.seed)
    provider = BrazilSpecProvider(seed=address.seed)

    cnpj = provider.cnpj(True)
    print(f"cnpj: {cnpj}")
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'

# Generated at 2022-06-23 20:47:10.132276
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_test_1 = BrazilSpecProvider.cpf()
    cpf_test_2 = BrazilSpecProvider.cpf()
    assert isinstance(cpf_test_1, str) is True
    assert len(cpf_test_1) == 14
    assert cpf_test_1 != cpf_test_2
