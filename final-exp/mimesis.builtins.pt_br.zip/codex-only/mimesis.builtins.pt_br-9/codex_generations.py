

# Generated at 2022-06-23 20:37:10.821335
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj() == '76.497.735/0001-31'

# Generated at 2022-06-23 20:37:12.172693
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert(BrazilSpecProvider().cpf() == BrazilSpecProvider().cpf())


# Generated at 2022-06-23 20:37:16.543251
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    mask = [True, False]
    seed = [None, 123, 1234567890]
    for i in mask:
        for s in seed:
            print(BrazilSpecProvider(s).cnpj(i))


# Generated at 2022-06-23 20:37:20.775489
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider"""
    brazil_provider = BrazilSpecProvider()
    if (brazil_provider.cnpj() != brazil_provider.cnpj(with_mask=False)):
        raise AssertionError('Wrong behavior of method cnpj.')


# Generated at 2022-06-23 20:37:25.980624
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    test_cpf = provider.cpf()
    assert len(test_cpf) == 14
    assert test_cpf.count('.') == 2
    assert test_cpf.count('-') == 1
    assert test_cpf[3] == '.'
    assert test_cpf[7] == '.'
    assert test_cpf[11] == '-'

# Generated at 2022-06-23 20:37:32.476078
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import random
    from mimesis import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    # Set up a random seed
    seed = random.randint(1, 9999)
    random.seed(seed)

    cpf_provider = BrazilSpecProvider()

    for _ in range(999):

        # Generate a CPF
        cpf = cpf_provider.cpf()

        print(cpf)

        # Validate the CPF mask according CPF pattern
        assert len(cpf) == 14
        assert cpf == cpf[:3] + '.' + cpf[3:6] + '.' + cpf[6:9] + '-' + cpf[9:]

        # Validate the function cpf of class Person

# Generated at 2022-06-23 20:37:37.173637
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.brasil import BrazilSpecProvider
    br = BrazilSpecProvider()
    cnpj = br.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert type(cnpj) == str


# Generated at 2022-06-23 20:37:43.408159
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from sys import stderr
    from mimesis import BrazilSpecProvider
    from mimesis.enums import Gender

    brazilSpecProvider = BrazilSpecProvider()

    with stderr.redirect_stderr():
        result1 = brazilSpecProvider.cnpj()
        result2 = brazilSpecProvider.cnpj(with_mask=False)

    assert len(result1) == 18
    assert len(result2) == 14

    assert result1 == result2


# Generated at 2022-06-23 20:37:46.656432
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilFormats = BrazilSpecProvider()
    cpf = brazilFormats.cpf()
    print(cpf)



# Generated at 2022-06-23 20:37:53.738909
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[3] == cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[0:3].isdigit()
    assert cpf[4:7].isdigit()
    assert cpf[8:11].isdigit()
    assert cpf[12:14].isdigit()
    cpf = bsp.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf[0:11].isdigit()


# Generated at 2022-06-23 20:37:54.813329
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()

# Generated at 2022-06-23 20:37:56.010664
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil is not None


# Generated at 2022-06-23 20:37:58.892393
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider1 = BrazilSpecProvider()
    provider2 = BrazilSpecProvider(seed='Paulo')
    provider3 = BrazilSpecProvider(seed='Paulo')
    assert provider1.cnpj() == '77.732.230/0001-70'
    assert provider2.cnpj(with_mask=False) == '2563228000140'
    assert provider3.cnpj(with_mask=False) == '2563228000140'

# Generated at 2022-06-23 20:38:02.338918
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    test_cpf = provider.cpf()
    assert test_cpf.replace('.', '').replace('-', '').isdigit()

    test_cnpj = provider.cnpj()
    assert test_cnpj.replace('.', '').replace('-', '').replace('/', '').isdigit()

# Generated at 2022-06-23 20:38:12.324456
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    from random import seed
    from .utils import jaccard_similarity
    item = BrazilSpecProvider()
    item.seed(seed(4))

    assert jaccard_similarity(item.cpf(), '094.487.298-21') == 1
    assert jaccard_similarity(item.cpf(with_mask=False), '09448729821') == 1

    item.seed(seed(5))
    assert jaccard_similarity(item.cpf(), '329.711.542-71') == 1
    assert jaccard_similarity(item.cpf(with_mask=False), '32912654892') == 1

    item.seed(seed(13))

# Generated at 2022-06-23 20:38:15.090207
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    a = BrazilSpecProvider()
    b = a.cnpj()
    assert b.count(".") == 2
    assert b.count("-") == 1
    assert len(b) == 18


# Generated at 2022-06-23 20:38:17.756893
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Testing BrazilSpecProvider method")
    bsp = BrazilSpecProvider()
    bsp.cpf()
    bsp.cnpj()

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:38:21.841261
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:38:24.112230
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider();
    assert obj.cpf()

# Generated at 2022-06-23 20:38:25.310149
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()

# Generated at 2022-06-23 20:38:29.263733
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Create a seed for generator
    seed = 'ABC123'
    provider = BrazilSpecProvider(seed)
    # Set the provider to return the expected CPF
    provider.random.randint = lambda x, y: 3
    cpf = provider.cpf()
    assert cpf == '000.000.000-03'


# Generated at 2022-06-23 20:38:31.506994
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=False) is not None
    assert provider.cnpj(with_mask=False) is not None

# Generated at 2022-06-23 20:38:32.517231
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.cpf()
    assert bsp.cnpj()

# Generated at 2022-06-23 20:38:34.243227
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj1 = BrazilSpecProvider().cnpj()
    cnpj2 = BrazilSpecProvider().cnpj()
    assert cnpj1 != cnpj2
    assert type(cnpj1) == str
    assert len(cnpj1) == 18

# Generated at 2022-06-23 20:38:40.615997
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()

    # This is the result of calling the method in the constructor, if the result
    # is correct, this test is correct.
    if br.cpf() == '688.558.730-19' and br.cnpj() == '28.129.253/0001-46':
        console.log("Successfull test.")
    else:
        console.log("Fail test.")

# Generated at 2022-06-23 20:38:44.265953
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Docstring."""
    bsp = BrazilSpecProvider(seed=0)

    expected_cnpj = '77.732.230/0001-70'
    assert bsp.cnpj() == expected_cnpj


# Generated at 2022-06-23 20:38:53.763740
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Check that the CNPJ generated is valid."""
    data = BrazilSpecProvider().cnpj(with_mask=False)
    # The first eight digits must be random
    assert data[0:8] != '11111111'
    # D1 First digit of the CNPJ must be 2
    assert data[8] == '2'
    # D2 Second digit of the CNPJ must be 7
    assert data[9] == '7'
    # D3 Third digit of the CNPJ must be 7
    assert data[10] == '7'
    # The verification digits must match
    assert data[12] == '6'
    assert data[13] == '7'

# Generated at 2022-06-23 20:38:55.478475
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cnpj()
    assert provider.cpf()

test_BrazilSpecProvider()

# Generated at 2022-06-23 20:39:00.376289
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()

    print(cnpj)

if __name__ == "__main__":
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-23 20:39:09.179516
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # If called by py.test, we need to mock the spec_set.
    # Assert that the cnpj is a string with 14 chars.
    test_class = BrazilSpecProvider(seed=0)
    assert isinstance(test_class.cnpj(), str) and len(test_class.cnpj()) == 14
    assert isinstance(test_class.cnpj(with_mask=False), str) and \
        len(test_class.cnpj(with_mask=False)) == 14
    assert test_class.cnpj() == test_class.cnpj() and \
        test_class.cnpj(with_mask=False) == test_class.cnpj(with_mask=False)

    test_class = BrazilSpecProvider(seed=123456789)

# Generated at 2022-06-23 20:39:11.337506
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj(with_mask = True) # 77.732.230/0001-70

# Generated at 2022-06-23 20:39:17.250524
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf_list = []
    for i in range(100):
        cpf = bsp.cpf()
        if cpf in cpf_list:
            raise Exception("Repeat CPF!")
        cpf_list.append(cpf)


# Generated at 2022-06-23 20:39:20.364286
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj."""
    cnpj = BrazilSpecProvider().cnpj(with_mask=True)
    assert cnpj == "15.903.368/0001-62"

# Generated at 2022-06-23 20:39:23.793083
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '77.732.230/0001-70'
    assert (provider.cnpj(with_mask=False) == '7773223000170')

# Generated at 2022-06-23 20:39:28.544335
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider class."""
    pt_br = BrazilSpecProvider()
    pt_br_ = BrazilSpecProvider(seed=42)
    assert pt_br.cpf()
    assert pt_br_.cpf()
    assert pt_br.cnpj()
    assert pt_br_.cnpj()


# Generated at 2022-06-23 20:39:31.142418
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert brazil.cpf(with_mask=False) == cpf.replace(".","").replace("-","")


# Generated at 2022-06-23 20:39:33.755839
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of class BrazilSpecProvider."""
    specp = BrazilSpecProvider()
    assert specp is not None

# Generated at 2022-06-23 20:39:41.679693
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj."""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=True)

# Generated at 2022-06-23 20:39:44.701626
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br_cnpj = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(br_cnpj) == 14
    assert br_cnpj.isdigit()


# Generated at 2022-06-23 20:39:48.981834
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider(seed = 5)
    assert brazil.cnpj() == '77.732.230/0001-70'
    assert brazil.cpf() == '001.137.297-40'

# Generated at 2022-06-23 20:39:50.678909
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    print(brazil.cpf())



# Generated at 2022-06-23 20:39:54.386200
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bfp = BrazilSpecProvider()
    cpf = bfp.cpf(with_mask=False)
    assert len(cpf) == 11
    assert isinstance(cpf, str)
    assert cpf != bfp.cpf(with_mask=False)


# Generated at 2022-06-23 20:39:56.313457
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf_1 = provider.cpf()
    assert len(cpf_1) == 14
    assert cpf_1[3] == '.' and cpf_1[7] == '.' and cpf_1[11] == '-'
    print(cpf_1)


# Generated at 2022-06-23 20:39:59.790353
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '017.267.107-31'
    assert BrazilSpecProvider().cpf(with_mask=False) == '01726710731'


# Generated at 2022-06-23 20:40:02.839106
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert(provider.cpf() == '001.137.297-40')
    assert(provider.cpf(with_mask=False) == '00113729740')


# Generated at 2022-06-23 20:40:13.977659
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.builtins.base import RandomGenerator
    from mimesis import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    my_seed = Seed('hello')
    my_random = RandomGenerator(seed=my_seed)
    my_provider = BrazilSpecProvider(seed=my_seed)
    my_provider_no_seed = BrazilSpecProvider()
    assert my_provider._random == my_random
    assert my_provider._seed == my_seed == my_random._seed
    assert my_provider._locale == 'pt-br'
    assert my_provider._datetime_provider.seed == my_seed
    assert my_provider._gender == Gender.MALE

# Generated at 2022-06-23 20:40:16.701620
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    csp = BrazilSpecProvider()
    for i in range(10):
        print("Test " + str(i) + ": " + csp.cpf())


# Generated at 2022-06-23 20:40:22.843788
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    result = provider.cnpj(with_mask=True)
    assert len(result) == 18

    # test mask
    assert result.count('.') == 2
    assert result.count('/') == 1
    assert result.count('-') == 1
    # test validating code
    assert result[-2:] == BrazilSpecProvider.get_validating_code_cnpj(
        result[:-2])


# Generated at 2022-06-23 20:40:29.072525
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider.cnpj()."""
    test_cnpj = BrazilSpecProvider().cnpj()

    assert len(test_cnpj) == 18
    assert test_cnpj[2] == '.' and test_cnpj[6] == '.' and test_cnpj[10] == '/' and test_cnpj[15] == '-'

# Generated at 2022-06-23 20:40:38.259677
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    cpf = BrazilSpecProvider().cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf[0].isdigit()
    assert cpf[1].isdigit()
    assert cpf[2].isdigit()
    assert cpf[3] == '.'
    assert cpf[4].isdigit()
    assert cpf[5].isdigit()
    assert cpf[6].isdigit()
    assert cpf[7] == '.'
    assert cpf[8].isdigit()
    assert cpf[9].isdigit()
    assert cpf[10].isdigit()
    assert cpf[11] == '-'
    assert cpf[12].isdig

# Generated at 2022-06-23 20:40:42.796439
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    seed = 0
    p = Person('pt_BR', seed=seed)
    b = BrazilSpecProvider('pt_BR', seed=seed)
    assert '05.343.112/0001-60' == b.cnpj()
    assert '05.343.112/0001-60' == b.cnpj(with_mask=True)
    assert '05343113000160' == b.cnpj(with_mask=False)


# Generated at 2022-06-23 20:40:54.393729
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person.base import BasePerson
    from mimesis.providers.person.br import BrazilSpecProvider
    brazil_custom = BrazilSpecProvider(seed=1)

    # test whether the cpf is valid  
    cpf = brazil_custom.cpf(with_mask=False)
    #print(cpf)

    # test whether the cpf is generated with mask
    cpf_with_mask = brazil_custom.cpf(with_mask=True)
    #print(cpf_with_mask)

    # test whether the cpf follows the regex rules
    regex_cpf = BrazilSpecProvider().cpf(with_mask=True)
    #print(regex_cpf)
        
    # test whether the cpf is the same

# Generated at 2022-06-23 20:41:01.833168
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of BrasilSpecProvider class."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pt-BR', seed=1123581321)
    name = p.name(gender=Gender.FEMALE)
    cpf = p.cpf(with_mask=False)

    # Test method cpf and test_mask_cpf
    print(cpf)                  # 77310068971
    print(p.cpf(with_mask=True))# 773.100.689-71

    # Test method __repr__
    print(p)                    # <Person (pt-BR)>



# Generated at 2022-06-23 20:41:08.715891
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf from class BrazilSpecProvider."""
    from mimesis.builtins.brasil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    test_cpf = provider.cpf()
    assert test_cpf == provider.cpf(with_mask=True)
    assert test_cpf == provider.cpf(with_mask=False)


# Generated at 2022-06-23 20:41:11.038768
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_object = BrazilSpecProvider()
    assert(test_object.cnpj() != test_object.cnpj())


# Generated at 2022-06-23 20:41:14.088677
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert isinstance(BrazilSpecProvider(seed=1).cnpj(), str)
    assert BrazilSpecProvider(seed=1).cnpj() == '73.998.331/0001-35'


# Generated at 2022-06-23 20:41:15.322148
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 20:41:20.214060
# Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-23 20:41:23.365768
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Test BrazilSpecProvider constructor")
    brazilspecprovider = BrazilSpecProvider(seed=None)
    print("Initial brazilspecprovider: " + str(brazilspecprovider))
    return


# Generated at 2022-06-23 20:41:26.030410
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()

    assert len(bsp.cpf(True)) == 14
    assert len(bsp.cpf(False)) == 11


# Generated at 2022-06-23 20:41:30.473089
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=123)
    assert provider.cnpj() == "10.943.731/0001-53"
    assert provider.cnpj(with_mask=False) == "10943.731000153"

# Generated at 2022-06-23 20:41:37.900517
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.brazil import BrazilSpecProvider

    bsp = BrazilSpecProvider()

    # test for cnpj mask
    test_conformity_with_mask = bsp.cnpj()

    conform_with_mask = True
    if test_conformity_with_mask[2] != '.' or test_conformity_with_mask[6] != '.' \
            or test_conformity_with_mask[10] != '/' or test_conformity_with_mask[15] != '-':
        conform_with_mask = False

    assert len(test_conformity_with_mask) == 18
    assert conform_with_mask is True

    # test for cnpj without mask
    test_conformity_without_mask = bsp.cnpj(False)



# Generated at 2022-06-23 20:41:41.906671
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Create a brazil_provider with a specific seed and print
    the method value of cnpj with different parameters."""

    test = BrazilSpecProvider()
    test.seed(1)
    print(test.cnpj(with_mask=True))
    print(test.cnpj(with_mask=False))


# Generated at 2022-06-23 20:41:44.926517
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = BrazilSpecProvider().cpf()
    assert isinstance(result, str)
    assert len(result) == 14
    result_with_mask = BrazilSpecProvider().cpf(with_mask=False)
    assert isinstance(result_with_mask, str)
    assert len(result_with_mask) == 11



# Generated at 2022-06-23 20:41:45.923432
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider().cpf()


# Generated at 2022-06-23 20:41:48.925807
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br_spec_provider = BrazilSpecProvider()
    assert len(br_spec_provider.cnpj()) >= 14
    assert br_spec_provider.cnpj() == "77.732.230/0001-70"


# Generated at 2022-06-23 20:41:50.578505
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(locale='pt-br', seed=None)

# Generated at 2022-06-23 20:41:54.023492
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    for i in range(0,20):
        my_pro=BrazilSpecProvider()
        print ("CNPJ: ",my_pro.cnpj())


if __name__ == '__main__':
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-23 20:42:00.284836
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert '.' in cpf
    assert '-' in cpf

    cpf = brazil.cpf(with_mask=False)
    assert isinstance(cpf, str)
    assert len(cpf) == 11
    assert not '.' in cpf
    assert not '-' in cpf



# Generated at 2022-06-23 20:42:01.500095
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BR = BrazilSpecProvider()
    print(BR)


# Generated at 2022-06-23 20:42:08.433340
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("Test cnpj method")
    provider = BrazilSpecProvider()
    results = []
    for i in range(0, 10000):
        results.append(provider.cnpj(with_mask=True))
    assert 0 < results.count("00.000.000/0001-91")
    assert 0 < results.count("03.638.842/0001-09")
    assert 0 < results.count("06.818.200/0001-71")
    assert 0 < results.count("15.433.700/0001-16")
    assert 0 < results.count("18.206.100/0001-73")
    assert 0 < results.count("21.920.300/0001-80")
    assert 0 < results.count("24.964.600/0001-81")

# Generated at 2022-06-23 20:42:11.886259
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj().
    """
    provider = BrazilSpecProvider()
    cnpj1 = provider.cnpj()
    cnpj2 = provider.cnpj(with_mask=False)
    assert len(cnpj1) == len(cnpj2)

# Generated at 2022-06-23 20:42:16.657751
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = 'f531ba05-34fe-48e5-ad3f-d3b6e797e6a3'
    bsp = BrazilSpecProvider(seed)
    assert bsp.cpf() == '643.541.968-05'


# Generated at 2022-06-23 20:42:23.588295
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import Person
    from mimesis.enums import Gender
    from mimesis.enums import Localization
    from mimesis.providers.person.en_US import enUSPerson

    p = Person('pt-br')
    p = p.set_locale(Localization.PORTUGUESE)
    p.set_gender(Gender.MALE)
    p.set_locale_class(enUSPerson)
    return p.cnpj()


# Generated at 2022-06-23 20:42:27.120137
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider('erwin', 'erwin')
    assert provider.cpf()
    assert provider.cnpj()
    assert provider.cpf(True)

# Generated at 2022-06-23 20:42:30.072185
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider.

    Parameters:
            seed: Seed for the random.
    """
    BrazilSpecProvider()



# Generated at 2022-06-23 20:42:35.572785
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Test CRUD BrazilSpecProvider")
    locale = 'pt'
    provider_brazil = BrazilSpecProvider(locale)
    # Test test
    assert provider_brazil.cpf(True) is not None
    assert provider_brazil.cnpj(True) is not None
    print("Success Test CRUD BrazilSpecProvider")

# Init test for BrazilSpecProvider
test_BrazilSpecProvider()

# Generated at 2022-06-23 20:42:38.499631
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    n = BrazilSpecProvider().cnpj()
    assert len(n) == 18


# Generated at 2022-06-23 20:42:41.243021
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14

# Generated at 2022-06-23 20:42:46.044856
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    cnpj = BrazilSpecProvider().cnpj()
    cpf = BrazilSpecProvider().cpf()
    #print(cnpj)
    #print(len(cnpj))
    #print(cpf)
    #print(len(cpf))
    assert cnpj != cpf

#if __name__ == "__main__":
#    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:42:54.432772
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = '6cdf77f9-9a3d-5b78-a6a3-ab5d6d8dbb47'
    other = BrazilSpecProvider(seed=seed)
    results = ['028.393.162-60', '911.816.373-00', '269.932.200-05', '643.192.016-76', '353.869.867-91',
               '079.936.200-62']
    assert all(other.cpf() in r for r in results)


# Generated at 2022-06-23 20:42:59.973647
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br_spec_provider = BrazilSpecProvider(seed=42)
    assert br_spec_provider.cpf() == '374.086.819-93'
    assert br_spec_provider.cnpj() == '47.797.734/0001-76'



# Generated at 2022-06-23 20:43:05.845170
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Testing method BrazilSpecProvider.cnpj."""    
    from mimesis.providers.base import BaseSpecProvider
    spec = BrazilSpecProvider()
    assert len(spec.cnpj()) == 18
    assert len(spec.cnpj(with_mask = False)) == 14
    assert spec.cnpj().count('.') == 2
    assert spec.cnpj().count('/') == 1
    assert spec.cnpj().count('-') == 1
    assert spec.cnpj(with_mask = False).count('.') == 0
    assert spec.cnpj(with_mask = False).count('/') == 0
    assert spec.cnpj(with_mask = False).count('-') == 0
    assert not spec.cnpj(with_mask = False)[0] == '0'

# Generated at 2022-06-23 20:43:14.336511
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    provider = BrazilSpecProvider()

    assert provider.cpf() == '100.934.944-61'
    assert provider.cpf() == '140.554.798-48'
    assert provider.cpf() == '955.638.045-34'
    assert provider.cpf() == '055.854.421-62'
    assert provider.cpf() == '800.344.021-21'
    assert provider.cpf() == '715.039.906-51'
    assert provider.cpf() == '064.741.236-13'
    assert provider.cpf() == '721.773.078-42'
    assert provider.cpf() == '843.803.951-77'
    assert provider.cpf

# Generated at 2022-06-23 20:43:15.914396
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
  from mimesis.enums import Gender
  from mimesis.builtins import BrazilSpecProvider
  brazil = BrazilSpecProvider(seed=123)
  assert brazil.cpf(with_mask=True) == "012.438.247-12"

# Generated at 2022-06-23 20:43:18.956417
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Make sure that the constructor of BrazilSpecProvider is correct
    assert isinstance(BrazilSpecProvider(), BrazilSpecProvider)

    # Make sure that the inherited functions from BaseSpecProvider are
    # accessible
    assert isinstance(BrazilSpecProvider().cpf(), str)
    assert isinstance(BrazilSpecProvider().cnpj(), str)

# Generated at 2022-06-23 20:43:27.321241
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pt_BR')
    cpfs = {
        'male': {p.gender(Gender.MALE): p.cpf(False)},
        'female': {p.gender(Gender.FEMALE): p.cpf(False)},
    }
    print(cpfs)

    cpf = p.cpf()
    assert len(cpf) == 14
    print(cpf)

    cpf = p.cpf(False)
    assert len(cpf) == 11
    print(cpf)


# Generated at 2022-06-23 20:43:30.354342
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf.replace('.', '').replace('-', '').isnumeric()


# Generated at 2022-06-23 20:43:32.029379
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()



# Generated at 2022-06-23 20:43:34.747417
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    result = b.cpf()
    assert result
    assert len(result) == len('###.###.###-##')


# Generated at 2022-06-23 20:43:36.722046
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert isinstance(bsp, BrazilSpecProvider)

# Generated at 2022-06-23 20:43:43.161574
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    cpf_male_mask = '081.857.535-47'
    cpf_male_no_mask = '08185753547'

    cpf_female_mask = '007.363.196-01'
    cpf_female_no_mask = '00736319601'

    # Instance of BrazilSpecProvider class
    brazil = BrazilSpecProvider(seed=654321)

    # With mask
    assert brazil.cpf() == cpf_male_mask
    assert brazil.cpf(with_mask=True) == cpf_male_mask
    assert brazil.cpf(with_mask=False) == cpf_male_no_mask

    # No mask
    assert brazil.cpf(with_mask=False) == cpf_

# Generated at 2022-06-23 20:43:45.037759
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14

# Generated at 2022-06-23 20:43:47.036529
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    cpf = brazilSpecProvider.cpf()
    print('cpf',cpf)


# Generated at 2022-06-23 20:43:55.384554
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider(seed=123123123123123123123123123123123123123)
    assert cnpj.cnpj(True) == "39.037.667/0001-93"
    cnpj2 = BrazilSpecProvider(seed=123123123123123123123123123123123123123)
    assert cnpj2.cnpj(True) == "39.037.667/0001-93"
    cnpj3 = BrazilSpecProvider(seed=223123123123123123123123123123123123123)
    assert cnpj3.cnpj(True) == "78.104.873/0001-74"



# Generated at 2022-06-23 20:43:57.620392
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    bsp = BrazilSpecProvider()
    print(bsp.cpf())
    print(bsp.cnpj())

# Generated at 2022-06-23 20:44:04.878676
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    # length of cpf is 14
    assert len(cpf) == 14
    # the string has to have a mask of CPF "+###.###.###.##"
    assert cpf[3] == cpf[7] == cpf[11] == "."
    assert cpf[-2] == "-"
    # split the numbers and convert to integer
    new_cpf = []
    for token in cpf:
        if token.isdigit():
            new_cpf.append(int(token))
    # get the last digit
    digit = new_cpf.pop()
    # get the second last digit
    digit2 = new_cpf.pop()
    # get the first nine digits of list
    first9_digits = new_cpf[:9]

# Generated at 2022-06-23 20:44:12.763713
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import random
    import re
    from mimesis.builtins.brazil import BrazilSpecProvider
    
    bsp = BrazilSpecProvider()
    
    def generate_cnpj():
        cnpj = bsp.cnpj()
        sum_of_products = 0
        for digit in re.findall(r'\d', cnpj)[:-2]:
            sum_of_products += int(digit)
        return sum_of_products
    
    n = int(input('Sample size: '))
    sample_of_sum_of_products = [generate_cnpj() for i in range(n)]
    mean_of_sum_of_products = sum(sample_of_sum_of_products)/n
    

# Generated at 2022-06-23 20:44:16.519439
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    x = BrazilSpecProvider()
    assert x.cpf(with_mask=False) == '{}'.format('0' * 11)

# Generated at 2022-06-23 20:44:18.695909
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test to verify if the BrazilSpecProvider exists."""
    x = BrazilSpecProvider()
    assert (x != None)

# Generated at 2022-06-23 20:44:28.756700
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    mask = '###.###.###-##'
    for _ in range(0, 20):
        assert len(provider.cpf()) == 11
        assert len(provider.cpf(with_mask=False)) == 11
        assert all(digit.isdigit() for digit in provider.cpf())
        assert all(digit.isdigit() for digit in provider.cpf(with_mask=False))

        assert len(provider.cpf(with_mask=True)) == 14
        assert provider.cpf(with_mask=True).count('.') == 2
        assert provider.cpf(with_mask=True).count('-') == 1
        assert provider.cpf(with_mask=True).replace('.', '').replace('-', '') \
            == provider.cp

# Generated at 2022-06-23 20:44:36.048696
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  provider = BrazilSpecProvider()
  cnpj = provider.cnpj()
  assert cnpj is not None
  cnpj = cnpj.replace('.', '')
  cnpj = cnpj.replace('/', '')
  cnpj = cnpj.replace('-', '')
  assert len(cnpj) == 14
  assert cnpj.isdigit()

# Generated at 2022-06-23 20:44:38.953794
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bs = BrazilSpecProvider()
    cpf = bs.cpf(True)
    cnpj = bs.cnpj(True)
    print(cpf)
    print(cnpj)

# Generated at 2022-06-23 20:44:47.457620
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec = BrazilSpecProvider()
    cpf = brazil_spec.cpf()
    assert cpf, 'CPF generated must be True'
    cpf_with_mask = brazil_spec.cpf(True)
    assert cpf_with_mask, 'CPF generated with mask must be True'
    cpf_without_mask = brazil_spec.cpf(False)
    assert cpf_without_mask, 'CPF generated without mask must be True'


# Generated at 2022-06-23 20:44:53.657536
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_list = []
    for count in range(100):
        cnpj_list.append(BrazilSpecProvider().cnpj())
    for cnpj in cnpj_list:
        assert '.' in cnpj
        assert '-' in cnpj
        assert len(cnpj) == 18


# Generated at 2022-06-23 20:45:00.578771
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import random
    import numpy as np

    random.seed(0)
    np.random.seed(0)

    def cpf_is_valid(cpf):
        """Verify if a Brazilian CPF is valid.

        :param cpf: String with the CPF in format ###.###.###-##.
        :returns: A boolean which indicates if the CPF is valid.
        """
        def get_verifying_digit_cpf(cpf, peso):
            """Calculate the verifying digit for the CPF.

            :param cpf: List of integers with the CPF.
            :param peso: Integer with the weight for the modulo 11 calculate.
            :returns: The verifying digit for the CPF.
            """
            soma = 0

# Generated at 2022-06-23 20:45:05.120656
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # create instance of BrazilSpecProvider
    provider = BrazilSpecProvider()
    # execute function of BrazilSpecProvider class
    cpf = provider.cpf()
    cnpj = provider.cnpj()
    # assert the result with expected result
    assert cpf != cnpj, "False: same result!"

# Generated at 2022-06-23 20:45:12.958536
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Create a random instance
    brazil_provider = BrazilSpecProvider()
    # Get a random cpf
    cpf = brazil_provider.cpf()
    # Print cpf
    print(cpf)
    # Get a random cnpj
    cnpj = brazil_provider.cnpj()
    # Print cnpj
    print(cnpj)

# Entry point to run specified function for testing
if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:14.837995
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    resp = b.cnpj()
    assert len(resp) == 18

# Generated at 2022-06-23 20:45:16.530987
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of class BrazilSpecProvider."""
    assert BrazilSpecProvider()

# Generated at 2022-06-23 20:45:19.249842
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider is not None


# Generated at 2022-06-23 20:45:20.570158
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=True) is not None


# Generated at 2022-06-23 20:45:25.318009
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    obj_BrazilSpecProvider = BrazilSpecProvider()

    assert obj_BrazilSpecProvider is not None
    assert obj_BrazilSpecProvider.cpf() is not None
    assert obj_BrazilSpecProvider.cnpj() is not None

test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:28.769265
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj(with_mask=False)
    assert len(cnpj) == 14 and type(cnpj) == str


# Generated at 2022-06-23 20:45:31.270443
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    
    for i in range(10):
        generated_cpf = provider.cpf()
        assert len(generated_cpf) == 14


# Generated at 2022-06-23 20:45:31.831254
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:45:35.161771
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider()
    cnpj = obj.cnpj(with_mask=True)
    print(cnpj)
    print(len(cnpj))

# test_BrazilSpecProvider_cnpj()



# Generated at 2022-06-23 20:45:36.880934
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(with_mask=False) == '747668041139'

# Generated at 2022-06-23 20:45:39.561327
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    class_ = BrazilSpecProvider

    assert class_.__name__ == 'BrazilSpecProvider'
    assert class_.Meta.name == 'brazil_provider'


# Test of the BrazilSpecProvider.cpf function

# Generated at 2022-06-23 20:45:43.406482
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result = provider.cnpj()

# Generated at 2022-06-23 20:45:46.124022
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print(">>>>> test_BrazilSpecProvider_cpf")

    provider = BrazilSpecProvider()
    print(">>>>> test_SpecProvider_cpf. cpf: " + provider.cpf())


# Generated at 2022-06-23 20:45:50.633685
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person.names import BRNamesProvider
    import re
    prov = BrazilSpecProvider()
    result = prov.cnpj()
    assert re.fullmatch(r"\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}", result)



# Generated at 2022-06-23 20:45:56.368676
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import random
    import pytest

    random.seed(seed=1234)
    cnpj = BrazilSpecProvider(seed=1234).cnpj(with_mask=False)

    assert cnpj == '38603659000158'
    assert len(cnpj) == 14
    assert type(cnpj) == str


# Generated at 2022-06-23 20:46:02.405488
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    unit = BrazilSpecProvider()
    # Test CPF masking
    cpf = unit.cpf(with_mask = True)
    test = True 
    if not cpf[3] == '.' or not cpf[7] == '.' or not cpf[11] == '-':
        test = False
    if test:
        print("Unit test for BrazilSpecProvider.cpf was successful.")
    else:
        print("Unit test for BrazilSpecProvider.cpf failed.")


# Generated at 2022-06-23 20:46:05.344866
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert type(brazil_spec_provider.cpf()) is str



# Generated at 2022-06-23 20:46:06.637471
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18

# Generated at 2022-06-23 20:46:12.014529
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert isinstance(repr(brazil_spec_provider), str)
    assert isinstance(str(brazil_spec_provider), str)
    assert isinstance(brazil_spec_provider.cpf(), str)
    assert isinstance(brazil_spec_provider.cnpj(), str)

# Generated at 2022-06-23 20:46:15.798365
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:46:18.401034
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj(False)
    print(cnpj)
    assert len(cnpj) == 14


# Generated at 2022-06-23 20:46:22.445154
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpfs = [bsp.cpf() for _ in range(100)]
    assert cpfs
    assert bsp.cpf() == '524.401.862-39'
    assert bsp.cpf(with_mask=False) == '67686495898'


# Generated at 2022-06-23 20:46:28.096085
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """ Unit test for method cpf of class BrazilSpecProvider """
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 14
    assert len(b.cpf(with_mask=False)) == 11
    assert b.cpf(with_mask=False).isdigit() == True


# Generated at 2022-06-23 20:46:31.448193
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(with_mask=False)
    assert ''.join(cpf.split('.'))
    assert ''.join(cpf.split('-'))
    assert len(cpf) == 11



# Generated at 2022-06-23 20:46:33.621715
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    actual = provider.cpf()
    assert len(actual) == 14


# Generated at 2022-06-23 20:46:35.174873
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '57.400.776/0001-35'

# Generated at 2022-06-23 20:46:44.538461
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test case 1
    provider = BrazilSpecProvider()
    cnpj1 = provider.cnpj()
    cnpj2 = provider.cnpj()

    assert isinstance(cnpj1, str)
    assert isinstance(cnpj2, str)
    assert cnpj1 != cnpj2

    # Test case 2
    provider = BrazilSpecProvider()
    cnpj1 = provider.cnpj(with_mask=False)
    cnpj2 = provider.cnpj(with_mask=False)

    assert isinstance(cnpj1, str)
    assert isinstance(cnpj2, str)
    assert cnpj1 != cnpj2



# Generated at 2022-06-23 20:46:46.300930
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    for i in range(0, 100):
        brazilSpecProvider.cpf()


# Generated at 2022-06-23 20:46:53.067684
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p1 = BrazilSpecProvider()
    p2 = BrazilSpecProvider()
    p3 = BrazilSpecProvider()
    p4 = BrazilSpecProvider()
    p5 = BrazilSpecProvider()

    cpfList = []
    cpfList.append(p1.cpf())
    cpfList.append(p2.cpf())
    cpfList.append(p3.cpf())
    cpfList.append(p4.cpf())
    cpfList.append(p5.cpf())

    cpfMaskedList = []
    cpfMaskedList.append(p1.cpf(True))
    cpfMaskedList.append(p2.cpf(True))
    cpfMaskedList.append(p3.cpf(True))

# Generated at 2022-06-23 20:46:55.289008
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    for i in range(5):
        assert len(br.cpf()) == 14


# Generated at 2022-06-23 20:46:56.726922
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
   brazil_provider = BrazilSpecProvider()
   assert  brazil_provider.cpf() != brazil_provider.cpf()
   

# Generated at 2022-06-23 20:46:58.036275
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert obj != None


# Generated at 2022-06-23 20:46:59.342862
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-23 20:46:59.913593
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:47:01.084856
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(with_mask=True)
    return cpf


# Generated at 2022-06-23 20:47:12.749528
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()