

# Generated at 2022-06-23 20:37:10.063287
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method for Provider cnpj."""

    expected = "36.376.834/0001-24"
    actual = BrazilSpecProvider().cnpj()

    assert actual == expected

# Generated at 2022-06-23 20:37:14.503930
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Resetting seed and getting BrazilSpecProvider
    bsp = BrazilSpecProvider().seed(17)
    # Testing attributes of BrazilSpecProvider
    assert bsp.cpf(False) == '06417818802'
    assert bsp.cpf(with_mask=True) == '064.178.188-02'
    assert bsp.cnpj(False) == '95958663000126'
    assert bsp.cnpj(with_mask=True) == '95.958.663/0001-26'

# Generated at 2022-06-23 20:37:17.600734
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bs = BrazilSpecProvider()
    assert bs._locale == 'pt-br'
    assert bs._seed is None


# Generated at 2022-06-23 20:37:18.923257
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Check default value of constructor without parameters
    BrazilSpecProvider()

# Generated at 2022-06-23 20:37:19.962319
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test = BrazilSpecProvider()
    test.cpf()


# Generated at 2022-06-23 20:37:23.189997
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    Brazilian = BrazilSpecProvider()
    assert len(Brazilian.cpf()) == 14
    assert len(Brazilian.cnpj()) == 18

# Generated at 2022-06-23 20:37:30.859923
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import pytest
    from mimesis.enums import Gender
    from mimesis.enums import Specialization
    from mimesis.generators import BusinessGenerator
    from mimesis.generators import DatetimeGenerator
    from mimesis.generators import GenericGenerator
    from mimesis.generators import PersonGenerator
    from mimesis.generators import ScienceGenerator
    from mimesis.generators import TextGenerator
    from mimesis.providers import Address
    from mimesis.providers import Financial
    from mimesis.providers import Internet
    from mimesis.providers import Person


    # Set up unit tests
    seed = 'test_BrazilSpecProvider'

    # Instantiate classes
    person = Person('pt-br', seed=seed)

# Generated at 2022-06-23 20:37:33.011594
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
        Test cnpj method of class BrazilSpecProvider
    """
    torico = BrazilSpecProvider()
    print(torico.cnpj())

# Generated at 2022-06-23 20:37:37.721610
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    from mimesis.builtins.brazil import BrazilSpecProvider
    # Criando instancia para teste
    brazilSpec = BrazilSpecProvider()

    # Gerando cnpj sem máscara
    cnpj_without_mask = brazilSpec.cnpj(with_mask=False)

    # Gerando cnpj com máscara
    cnpj_with_mask = brazilSpec.cnpj(with_mask=True)

    # Imprimindo os resultados
    print(cnpj_without_mask)
    print(cnpj_with_mask)

    # Testando tamanho do CNPJ SEM máscara
    assert len(cnpj_without_mask) == 14

    # Testando tamanho do CNPJ COM máscara

# Generated at 2022-06-23 20:37:48.351545
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    # Random CPF
    cpf = BrazilSpecProvider().cpf()
    # Get the first 9 digits of the CPF
    first_9_digits = cpf[:3] + cpf[4:7] + cpf[8:11]
    assert int(first_9_digits) == int(cpf[:9])
    # Get the last 2 digits of the CPF
    last_2_digits = cpf[12:]
    # Get the last two digits of what is before the point (.)
    dv1 = cpf[9]
    # Get the last two digits of what is after the point (.)
    dv2 = cpf[13]
    # Calculate the expected dv2
    # Get the sum of the numbers that are before

# Generated at 2022-06-23 20:37:59.563434
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(with_mask=False)
    assert len(cpf) == 11
    assert isinstance(cpf, str)
    cpf_masked = brazil.cpf(with_mask=True)
    assert len(cpf_masked) == 14
    assert len(cpf_masked[:3]) == 3
    assert len(cpf_masked[3]) == 1
    assert len(cpf_masked[4:7]) == 3
    assert len(cpf_masked[7]) == 1
    assert len(cpf_masked[8:11]) == 3
    assert len(cpf_masked[11]) == 1
    assert len(cpf_masked[12:]) == 2


# Generated at 2022-06-23 20:38:02.843940
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == "016.120.692-33"
    assert BrazilSpecProvider().cpf() == "047.246.433-19"


# Generated at 2022-06-23 20:38:08.381397
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider()
    instance.seed(1)
    assert instance.cpf(with_mask=False) == '80794118003'
    assert instance.cnpj(with_mask=False) == '6211267000167'
    assert instance.cpf(with_mask=True) == '807.941.180-03'
    assert instance.cnpj(with_mask=True) == '62.112.670/0001-67'


# Generated at 2022-06-23 20:38:09.761411
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    b.cpf()
    b.cnpj()

# Generated at 2022-06-23 20:38:12.199146
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    for _ in range(5):
        b1 = BrazilSpecProvider()
        b2 = BrazilSpecProvider()
        print(b1.cnpj())
        print(b2.cnpj())

# Generated at 2022-06-23 20:38:20.106092
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test if method cnpj of class BrazilSpecProvider works properly."""
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert len(BrazilSpecProvider().cnpj(False)) == 14
    assert BrazilSpecProvider().cnpj()[2] == '.'
    assert BrazilSpecProvider().cnpj(False)[2] != '.'
    assert BrazilSpecProvider().cnpj()[6] == '.'
    assert BrazilSpecProvider().cnpj(False)[6] != '.'
    assert BrazilSpecProvider().cnpj()[10] == '/'
    assert BrazilSpecProvider().cnpj(False)[10] != '/'
    assert BrazilSpecProvider().cnpj()[15] == '-'
    assert BrazilSpecProvider().cnpj(False)[15] != '-'


# Generated at 2022-06-23 20:38:23.247369
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=False) == provider.cpf(with_mask=False)
    assert len(provider.cpf(with_mask=False)) == 11



# Generated at 2022-06-23 20:38:25.974815
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert cpf >= '000.000.000-00'
    assert cpf <= '999.999.999-99'


# Generated at 2022-06-23 20:38:28.587314
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf(with_mask=False)) == 11
    assert len(provider.cpf(with_mask=True)) == 14


# Generated at 2022-06-23 20:38:31.156956
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj(with_mask=False)
    assert len(cnpj) == 14

# Unit test method cpf of class BrazilSpecProvider

# Generated at 2022-06-23 20:38:32.255487
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=12345)


# Generated at 2022-06-23 20:38:38.248345
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider - method cnpj."""
    brazil_sp = BrazilSpecProvider()
    cnpj = brazil_sp.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert brazil_sp.cnpj(with_mask=True).count('.') == 2
    assert brazil_sp.cnpj(with_mask=True).count('-') == 1
    assert brazil_sp.cnpj(with_mask=True).count('/') == 1
    cnpj = brazil_sp.cnpj(with_mask=True)
    assert cnpj.count('.') + cnpj.count('-') + cnpj.count('/') == 3



# Generated at 2022-06-23 20:38:43.261919
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider(seed='test_BrazilSpecProvider')
    assert a.cnpj(True) == '40.404.620/0001-34'
    assert a.cnpj(False) == '40404620000134'
    assert a.cpf(True) == '129.829.299-87'
    assert a.cpf(False) == '12982929987'
    assert a.cnpj(True) == '62.007.251/0001-35'
    assert a.cnpj(False) == '62007251000135'
    assert a.cpf(True) == '133.614.088-92'
    assert a.cpf(False) == '13361408892'



# Generated at 2022-06-23 20:38:43.773874
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    _ = BrazilSpecProvider()


# Generated at 2022-06-23 20:38:45.012053
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=123456)


# Generated at 2022-06-23 20:38:48.523203
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test creation of a cnpj."""
    value = BrazilSpecProvider(seed=8).cnpj()
    assert value == '77.732.230/0001-70'

# Generated at 2022-06-23 20:38:53.483221
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""

    testObject = BrazilSpecProvider()

    assert(len(testObject.cnpj())  == 19)
    assert(testObject.cnpj()[-2] == '-')
    assert(len(testObject.cnpj(with_mask=False)) == 14)


# Generated at 2022-06-23 20:38:56.747434
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    gen = BrazilSpecProvider()
    cnpj = gen.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[5] == '.'
    assert cnpj[8] == '/'
    assert cnpj[13] == '-'


# Generated at 2022-06-23 20:39:07.180176
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.helpers import replace
    from mimesis.providers.person import Person
    from mimesis.providers.financial import Financial

    _person = Person('pt-br')
    _financial = Financial('pt-br')

    # print( '\n', _financial.cnpj() )
    # print( '\ncnpj   =', _person.cnpj(), '\n' )

    # print( '\n', _financial.cnpj(True) )
    # print( 'cnpj   =', _person.cnpj(True), '\n' )

    # print('\n', _financial.cnpj(False))
    # print('cnpj   =', _person.cnpj(False), '\n')

    s = _financial.cnpj

# Generated at 2022-06-23 20:39:13.772168
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider(seed=123)

    assert br.cpf(with_mask=True) == '533.143.724-14'
    assert br.cpf(with_mask=False) == '53314372414'
    assert br.cnpj(with_mask=True) == '30.622.866/0002-73'
    assert br.cnpj(with_mask=False) == '30622866000273'

# Generated at 2022-06-23 20:39:16.009151
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    print(bsp.cpf())

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:39:18.029102
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj(True)
    b.cnpj(False)


# Generated at 2022-06-23 20:39:18.886058
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf()
    assert brazil.cnpj()

# Generated at 2022-06-23 20:39:23.147933
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # initialize and check if all attributes are defined in the object
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.random is not None
    assert hasattr(brazil_provider, 'seed')
    assert hasattr(brazil_provider, '_locale')
    assert brazil_provider.__repr__ is not None


# Generated at 2022-06-23 20:39:24.653948
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    expected = "99.999.999/0001-99"
    assert BrazilSpecProvider().cnpj() == expected

# Generated at 2022-06-23 20:39:27.440550
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    cpf = provider.cpf()
    assert len(cpf) == 14
    assert isinstance(cpf, str)



# Generated at 2022-06-23 20:39:29.113957
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('Brazil Spec Provider')
    brazil_spec_provider = BrazilSpecProvider()
    print(brazil_spec_provider.cpf())
    print(brazil_spec_provider.cnpj())


# Generated at 2022-06-23 20:39:39.847072
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # cnpj with mask
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert(len(cnpj) == 18)
    assert(cnpj[2] == '.')
    assert(cnpj[6] == '.')
    assert(cnpj[10] == '/')
    assert(cnpj[15] == '-')
    # cnpj without mask
    cnpj = provider.cnpj(with_mask=False)
    assert(len(cnpj) == 14)
    # cnpj format validation
    assert(cnpj[0:2].isnumeric())
    assert(cnpj[2].isnumeric())
    assert(cnpj[3:6].isnumeric())

# Generated at 2022-06-23 20:39:47.230670
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test of method cpf on class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()

    # Test when with_mask is True
    cpf = bsp.cpf()
    assert len(cpf) == 14,\
        'The length of cpf should be 14'
    
    # Test when with_mask is False
    cpf = bsp.cpf(with_mask=False)
    assert len(cpf) == 11,\
        'The length of cpf should be 11'


# Generated at 2022-06-23 20:39:48.267496
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider

# Generated at 2022-06-23 20:39:52.237190
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cpf(with_mask=False)) == 11
    assert provider.cpf().count('-') == 1
    assert provider.cpf(with_mask=False).count('-') == 0


# Generated at 2022-06-23 20:39:59.668652
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("\nStart testing BrazilSpecProvider...")
    # Test BrazilSpecProvider attributes
    bp = BrazilSpecProvider()

    assert bp.Meta.name == 'brazil_provider'
    assert bp.locale == 'pt-br'

    # Test BrazilSpecProvider methods
    assert len(bp.cpf()) == 14
    assert bp.cpf(with_mask=False) != bp.cpf()
    assert len(bp.cnpj()) == 18
    assert bp.cnpj(with_mask=False) != bp.cnpj()

    print("...Passed!")

# This is for testing
if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:40:03.065404
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    l=[]
    for i in range(1,10):
        l.append(BrazilSpecProvider().cpf())
    for i in l:
        for j in l:
            if i!=j:
                assert(i!=j)


# Generated at 2022-06-23 20:40:04.952094
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:40:08.794090
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_1 = '001.137.297-40'
    cpf_2 = '16173741071'
    CPF_TEST = BrazilSpecProvider()
    assert CPF_TEST.cpf(with_mask=True) in cpf_1
    assert CPF_TEST.cpf(with_mask=False) in cpf_2


# Generated at 2022-06-23 20:40:12.104090
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test of the cnpj method of BrazilSpecProvider."""
    assert len(BrazilSpecProvider().cnpj()) == 18 
    assert len(BrazilSpecProvider().cnpj()) == 18 
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14 
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14 



# Generated at 2022-06-23 20:40:17.616232
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    _cpf_1 = bsp.cpf(True)
    _cpf_2 = bsp.cpf(False)

    assert len(_cpf_1) == len(_cpf_2) + 3
    assert _cpf_1 != _cpf_2



# Generated at 2022-06-23 20:40:20.300684
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=1234567)
    assert provider.cpf() == provider.cpf()
    assert all([str(i).isnumeric() for i in provider.cpf(with_mask=False)])
    assert provider.cpf(with_mask=False).__len__() == 11


# Generated at 2022-06-23 20:40:22.228564
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider(seed=5).cnpj() == '70.135.554/0001-89'

# Generated at 2022-06-23 20:40:23.536983
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    inst = BrazilSpecProvider()

# Generated at 2022-06-23 20:40:28.410889
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Arrange
    import re
    provider = BrazilSpecProvider()
    expected = "000.000.000-00"
    # Act
    result = provider.cpf()
    # Assert
    assert len(result) == 14
    assert re.match(expected, result) is not None


# Generated at 2022-06-23 20:40:32.396307
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf.isdecimal()
    assert cpf[-2:] == provider.cpf(with_mask=False)[-2:]


# Generated at 2022-06-23 20:40:40.854410
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test all cnpj's generated
    for cnpj in BrazilSpecProvider().cnpj():
        assert(copy(cnpj).replace(".", "").replace("-", "").isnumeric())
        assert(len(copy(cnpj).replace(".", "").replace("-", "")) == 14)

    # Check if cnpj has the right format

# Generated at 2022-06-23 20:40:52.945136
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test of method cnpj:

    It is tested that the data is correct by checking the length of the
    string, the presence of periods and dashes and the correct digit.
    """
    # Unit test for method cnpj of class BrazilSpecProvider
    brazilSpecProvider = BrazilSpecProvider()

    cnpj_list = []
    for i in range(20):
        cnpj = brazilSpecProvider.cnpj()
        cnpj_list.append(cnpj)

    # Check if the strings are the correct length
    for cnpj in cnpj_list:
        assert len(cnpj) == 18

    # Check if the strings have a period and slash
    for cnpj in cnpj_list:
        assert '.' in cnpj
        assert '/' in cnpj

# Generated at 2022-06-23 20:41:01.693589
# Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-23 20:41:09.307281
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
   # Initialize BrazilSpecProvider with a seed value
   brazil_provider = BrazilSpecProvider(seed=42)
   cnpj = brazil_provider.cnpj(with_mask=False)
   print("cnpj: {}".format(cnpj))
   print("cnpj with mask: {}".format(brazil_provider.cnpj(with_mask=True)))

if __name__ == "__main__":
   test_BrazilSpecProvider()

# Generated at 2022-06-23 20:41:13.733075
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    bp = BrazilSpecProvider()
    # CPF
    c = bp.cpf()
    assert len(c) == 14
    # CNPJ
    c = bp.cnpj()
    assert len(c) == 18

# Generated at 2022-06-23 20:41:15.931746
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.builtins import BrazilSpecProvider
    a = BrazilSpecProvider()
    assert a.cpf() is not None
    assert a.cnpj() is not None

# Generated at 2022-06-23 20:41:18.774294
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert callable(BrazilSpecProvider().cpf) == True
    assert callable(BrazilSpecProvider().cnpj) == True



# Generated at 2022-06-23 20:41:20.620758
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '28.864.733/0002-80'


# Generated at 2022-06-23 20:41:28.144382
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    test_cnpj_witout_mask = BrazilSpecProvider().cnpj(with_mask=False)
    test_cnpj_with_mask = BrazilSpecProvider().cnpj(with_mask=True)

    assert isinstance(test_cnpj_witout_mask, str)
    assert isinstance(test_cnpj_with_mask, str)

    assert len(test_cnpj_witout_mask) == 14
    assert len(test_cnpj_with_mask) == 18

    assert test_cnpj_witout_mask.isdigit() is True
    assert test_cnpj_with_mask.isdigit() is False


# Generated at 2022-06-23 20:41:29.824060
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().cpf()
    assert BrazilSpecProvider().cnpj()

# Generated at 2022-06-23 20:41:32.204441
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    Program that tests the method cnpj of class BrazilSpecProvider
    """
    print(BrazilSpecProvider().cnpj(with_mask=True))


# Generated at 2022-06-23 20:41:34.367568
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print(BrazilSpecProvider().cnpj())

# Generated at 2022-06-23 20:41:39.902958
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj1 = '77.732.230/0001-70'
    cnpj2 = bsp.cnpj()
    if cnpj1 == cnpj2:
        print("CNPJ gerado corretamente")
    else:
        print("CNPJ gerado incorretamente")

        

# Generated at 2022-06-23 20:41:42.042755
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14
    

# Generated at 2022-06-23 20:41:47.426861
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj."""
    instance = BrazilSpecProvider()
    result = instance.cnpj(with_mask=False)
    assert len(result) == 14

    with_mask = instance.cnpj(with_mask=True)
    assert with_mask == instance.cnpj(with_mask=True)
    assert with_mask[-3:] == instance.cnpj(with_mask=True)[-3:]


# Generated at 2022-06-23 20:41:53.260518
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for the BrazilSpecProvider class."""
    brazillian = BrazilSpecProvider(seed=666)
    # test __init__
    assert brazillian is not None
    # test cpf
    assert brazillian.cpf(with_mask=True) is not None
    # test cnpj
    assert brazillian.cnpj(with_mask=True) is not None

# Generated at 2022-06-23 20:41:57.505685
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj1 = provider.cnpj()
    cnpj2 = provider.cnpj()
    # Verify if CNPJ1 and CNPJ2 are different
    assert cnpj1 != cnpj2


# Generated at 2022-06-23 20:42:00.024112
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()

    assert(obj != None)
    assert(obj.__class__.__name__ == "BrazilSpecProvider")


# Generated at 2022-06-23 20:42:02.542928
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bp = BrazilSpecProvider(seed=25)
    assert bp.cpf() == '649.008.251-05'
    assert bp.cnpj() == '67.786.907/0001-00'

# Generated at 2022-06-23 20:42:11.378234
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Initialize provider
    provider = BrazilSpecProvider()
    # Get a random cpf without mask
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11
    # Get a random cpf with mask
    cpf_mask = provider.cpf(with_mask=True)
    assert len(cpf_mask) == 14
    # Get a random cnpj without mask
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14
    # Get a random cnpj with mask
    cnpj_mask = provider.cnpj(with_mask=True)
    assert len(cnpj_mask) == 18

# Generated at 2022-06-23 20:42:11.823250
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:42:12.507143
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()

# Generated at 2022-06-23 20:42:18.586344
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    import unittest.mock
    with unittest.mock.patch('mimesis.builtins.base.random') as _rand:
        b = BrazilSpecProvider()
        b.cnpj()
        b.cnpj(with_mask=False)


# Generated at 2022-06-23 20:42:24.042718
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14

    cpf_without_mask = brazil_spec_provider.cpf(with_mask=False)
    assert isinstance(cpf_without_mask, str)
    assert len(cpf_without_mask) == 11


# Generated at 2022-06-23 20:42:27.726151
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    random = BrazilSpecProvider(seed=0)
    cpf = random.cpf(with_mask=True)
    assert cpf == '356.344.054-31'


# Generated at 2022-06-23 20:42:31.037150
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result = provider.cnpj()
    assert result == '77.732.230/0001-70'

    # Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-23 20:42:33.195974
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import random
    tester = BrazilSpecProvider(random.random())
    assert tester.cpf() == '978.611.628-40'

# Generated at 2022-06-23 20:42:38.934903
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    cnpj = BrazilSpecProvider().cnpj()
    cpf = BrazilSpecProvider().cpf()

    assert len(cnpj) == 18
    assert len(cpf) == 14

    assert BrazilSpecProvider().cnpj(False) == '07467981000190'
    assert BrazilSpecProvider().cpf(False) == '29953377377'


# Generated at 2022-06-23 20:42:45.632364
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf1 = BrazilSpecProvider().cpf()
    assert len(cpf1) == 14
    assert cpf1.count('.') == 2
    assert cpf1[11] == '-'
    assert cpf1 == BrazilSpecProvider().cpf(True)

    cpf2 = BrazilSpecProvider().cpf(False)
    assert len(cpf2) == 11
    assert cpf2.count('.') == 0
    assert cpf2[9] != '-'


# Generated at 2022-06-23 20:42:50.846112
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Check if BrazilSpecProvider is working fine."""
    brazil = BrazilSpecProvider()
    assert brazil.seed
    assert brazil.random
    assert brazil.datetime
    assert brazil.cpf(with_mask=False)
    assert brazil.cnpj(with_mask=False)

# Generated at 2022-06-23 20:42:54.956361
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    assert type(a.cpf()) == str
    assert type(a.cpf(True)) == str
    assert len(a.cpf()) == 11
    assert len(a.cpf(True)) == 14
    assert a.cpf().isdigit()


# Generated at 2022-06-23 20:42:57.576369
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    s = BrazilSpecProvider()
    assert s.cpf() == '501.934.876-81'
    assert s.cnpj() == '75.735.366/0001-92'



# Generated at 2022-06-23 20:42:59.928400
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider


# Generated at 2022-06-23 20:43:09.931047
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert provider.cpf() == '014.931.917-10'
    assert provider.cpf() == '496.811.742-00'
    assert provider.cpf() == '077.873.653-46'
    assert provider.cpf(with_mask=False) == '25481199243'
    assert provider.cpf(with_mask=False) == '1493191710'
    assert provider.cpf(with_mask=False) == '49838814808'


# Generated at 2022-06-23 20:43:12.749668
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:43:19.305241
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert isinstance(brazil.cpf(with_mask=False), str)
    assert isinstance(brazil.cpf(), str)
    assert len(brazil.cpf(with_mask=False)) == 11
    assert len(brazil.cpf()) == 14
    assert isinstance(brazil.cnpj(with_mask=False), str)
    assert isinstance(brazil.cnpj(), str)
    assert len(brazil.cnpj(with_mask=False)) == 14
    assert len(brazil.cnpj()) == 18
    assert brazil.provider_name == 'brazil_provider'

# Generated at 2022-06-23 20:43:21.646069
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    expected = "88.851.127/0001-46"
    assert provider.cnpj() == expected

# Generated at 2022-06-23 20:43:22.605928
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:43:26.394976
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=1234)
    assert repr(provider) == 'BrazilSpecProvider()'
    assert provider.__str__() == 'BrazilSpecProvider()'
    assert provider.__repr__() == 'BrazilSpecProvider()'


# Generated at 2022-06-23 20:43:32.070290
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Tests for the BrazilSpecProvider.cpf method."""
    provider = BrazilSpecProvider()
    cpf_test = provider.cpf()
    assert cpf_test
    assert len(cpf_test) == 14
    assert cpf_test[3] == '.'
    assert cpf_test[7] == '.'
    assert cpf_test[11] == '-'


# Generated at 2022-06-23 20:43:39.483277
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert len(cpf) == 14, "If use mask, size of cpf should be equal to 14"
    assert cpf[3] == cpf[7] == "." and cpf[11] == "-", ". and - should be in the right position"
    assert not b.cpf(with_mask=False) == cpf, "Digits should be the same, but without mask"

# Generated at 2022-06-23 20:43:41.101402
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    _BrazilSpecProvider = BrazilSpecProvider()
    return _BrazilSpecProvider

# Generated at 2022-06-23 20:43:43.024543
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:43:46.698975
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()

    length_cnpj = len(cnpj)
    assert length_cnpj == 18


# Generated at 2022-06-23 20:43:50.856136
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for BrazilSpecProvider.cpf."""

    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf.rstrip('-')) == 11

    cpf_without_mask = provider.cpf(with_mask=False)
    assert len(cpf_without_mask) == 11


# Generated at 2022-06-23 20:43:53.222550
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    cls = BrazilSpecProvider()
    assert cls.locale == 'pt-br'
    assert cls.seed is None

# Generated at 2022-06-23 20:43:54.770001
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-23 20:44:00.132175
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == provider.cnpj(False)
    cnpj = provider.cnpj()
    mask = "{}.{}.{}/{}-{}".format(
        cnpj[:2],
        cnpj[2:5],
        cnpj[5:8],
        cnpj[8:12],
        cnpj[12:])
    assert provider.cnpj(True) == mask



# Generated at 2022-06-23 20:44:04.122881
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins.brazil import BrazilSpecProvider

    provider = BrazilSpecProvider()

    for _ in range(5):
        cpf = provider.cpf()
        assert cpf.count('-') == 1
        assert cpf.count('.') == 2
        assert len(cpf) == 14


# Generated at 2022-06-23 20:44:07.815132
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br_spec_pro = BrazilSpecProvider()
    cnpj = br_spec_pro.cnpj()

    assert len(cnpj) == 18
    assert cnpj[5] == '.'
    assert cnpj[9] == '.'
    assert cnpj[14] == '/'
    assert cnpj[19] == '-'


# Generated at 2022-06-23 20:44:09.795279
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider.Meta.name == 'brazil_provider'



# Generated at 2022-06-23 20:44:12.138942
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider class method cpf."""
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-23 20:44:13.956700
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    assert BrazilSpecProvider().__class__.__name__ == "BrazilSpecProvider"


# Generated at 2022-06-23 20:44:26.515005
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """BrazilSpecProvider_cpf is a unit test for BrazilSpecProvider class
    Method cpf. This method generates a valid cpf."""

    from mimesis.providers.base import BaseSpecProvider

    cpf = BrazilSpecProvider().cpf()

    assert type(cpf) is str # Check if cpf is a string
    assert len(cpf) == 14 # Check if len of cpf is 14
    assert cpf[3] == '.' # Check if char 4 is a '.'
    assert cpf[7] == '.' # Check if char 8 is a '.'
    assert cpf[11] == '-' # Check if char 12 is a '-'
    assert cpf.count('.') == 2 # Check if there are 2 '.'
    assert cpf.count('-') == 1 # Check if there is 1 '-'

# Generated at 2022-06-23 20:44:31.310182
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    provider = BrazilSpecProvider()
    cpf = provider.cnpj()

    assert len(cpf)  # Retorno deve ter tamanho maior que zero
    assert cpf[0:2].isdigit()  # Primeito bloco deve ser um inteiro
    assert cpf[2] == "."  # Terceiro bloco deve ser um ponto
    assert cpf[3:5].isdigit()  # Segundo bloco deve ser um inteiro
    assert cpf[5] == "."  # Quinto bloco deve ser um ponto
    assert cpf[6:8].isdigit()  # Terceiro bloco deve ser um inteiro
    assert cpf[8] == "/"  # Setimo bloco deve ser uma barra

# Generated at 2022-06-23 20:44:34.685420
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() # noqa: S101
    assert provider.cnpj() # noqa: S101


# Generated at 2022-06-23 20:44:42.906419
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.identification import Identification
    from mimesis.providers.cpf_cnpj import CPFCNPJ

    from mimesis.builtins.brazil import BrazilSpecProvider

    cnpj_provider = CPFCNPJ('pt-br')
    person_provider = Person('pt-br')
    address_provider = Address('pt-br')
    identification_provider = Identification('pt-br')

    address = address_provider.address()
    birthday = person_provider.birthday().date()
    gender = person_provider.gender(Gender.FEMALE)
    height = person_provider.height()
   

# Generated at 2022-06-23 20:44:46.363311
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    c = b.cpf(with_mask=False)
    assert len(c) == 11


# Generated at 2022-06-23 20:44:49.267299
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert isinstance(obj, BaseSpecProvider)
    assert obj is not None
    assert obj.seed is not None
    assert obj.locale == 'pt-br'



# Generated at 2022-06-23 20:44:52.937578
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider()
    cnpj = obj.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert cnpj == '36.514.959/0001-44'


# Generated at 2022-06-23 20:44:55.379894
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    # Call method cpf of class BrazilSpecProvider
    result = BrazilSpecProvider().cpf()

    # Assert result with CPF masked
    assert(result == '001.137.297-40')


# Generated at 2022-06-23 20:44:56.879619
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print(provider)


# Generated at 2022-06-23 20:44:58.818590
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    provider = BrazilSpecProvider()

    assert provider.cpf() is not None
    assert provider.cnpj() is not None

# Generated at 2022-06-23 20:45:03.352708
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpjs = []
    for i in range(100):
        cnpjs.append(bsp.cnpj())
    assert len(cnpjs) == 100
    
    assert len(cnpjs[0]) == 14


# Generated at 2022-06-23 20:45:10.245327
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for cnpj function."""

    cnpj_list = [
        '01.444.575/0001-01',
        '59.735.885/0001-75',
        '30.678.732/0001-70',
        '06.306.173/0001-45',
        '83.882.446/0001-57',
        '05.902.316/0001-99',
        '57.437.697/0001-55',
        '77.732.230/0001-70',
    ]

    provider = BrazilSpecProvider()
    for _ in range(100):
        cnpj = provider.cnpj()
        assert cnpj in cnpj_list

# Generated at 2022-06-23 20:45:12.542236
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '902.814.318-41'


# Generated at 2022-06-23 20:45:16.177831
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    bsp = BrazilSpecProvider()

    assert bsp.cpf() == '031.224.391-38'
    assert bsp.cnpj() == '91.967.506/0001-94'

# Generated at 2022-06-23 20:45:20.578313
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print('provider=', provider)
    print('provider.cpf=', provider.cpf())
    print('provider.cnpj=', provider.cnpj())


if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:31.321636
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    cpf = bsp.cpf()
    assert not bsp.cnpj_is_valid(cnpj) and bsp.cnpj_is_valid(cnpj, bsp.cnpj_without_digit(cnpj)) and bsp.cnpj_is_valid(cnpj, bsp.cnpj_without_digit(cnpj), True) and not bsp.cnpj_is_valid(cnpj, True)

# Generated at 2022-06-23 20:45:31.762247
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    assert True == True

# Generated at 2022-06-23 20:45:34.392469
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Testing BrazilSpecProvider_cpf():")
    
    provider = BrazilSpecProvider()
    
    cpf = provider.cpf()
    
    print("CPF: %s" % cpf)
    
    assert len(cpf) == 14
    assert cpf[3] == cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:45:37.337431
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = ''.join([str(i) for i in BrazilSpecProvider().cpf().split(".")])
    result = ''.join(result.split("-"))
    assert len(result) == 11


# Generated at 2022-06-23 20:45:42.591803
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    for _ in range(100):
        result = brazil.cnpj(with_mask=True)
        assert (result == '77.732.230/0001-70') == False
        assert (len(result) == 18)
        assert (result == '77.732.230/0001-70') == False
        assert (result == '77.732.230/0001-70') == False
        assert (result == '77.732.230/0001-70') == False

# Generated at 2022-06-23 20:45:44.081047
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider()
    assert p.cpf() == '708.945.919-04'


# Generated at 2022-06-23 20:45:46.009751
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    provider = BrazilSpecProvider()
    def test_cpf():
        nonlocal provider
        cpf = provider.cpf()
        # print(cpf)
        assert len(cpf) == 14

    test_cpf()



# Generated at 2022-06-23 20:45:48.207144
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert hasattr(brazil_provider, 'cpf')
    assert hasattr(brazil_provider, 'cnpj')

# Generated at 2022-06-23 20:45:52.694733
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    with_mask = True
    result = b.cpf(with_mask)
    result = (result == b.cpf(with_mask) == b.cpf(with_mask) == b.cpf(with_mask))
    assert result

# Generated at 2022-06-23 20:46:01.172742
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    import re
    bs = BrazilSpecProvider()
    pattern = re.compile('\d{3}\.\d{3}\.\d{3}-\d{2}')
    for _ in range(10):
        cpf_masc = bs.cpf()
        assert(pattern.match(cpf_masc)) is not None
        cpf_no_masc = bs.cpf(with_mask=False)
        assert(pattern.match(cpf_no_masc)) is None
        assert(len(cpf_no_masc) == 11)


# Generated at 2022-06-23 20:46:04.507951
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    n = BrazilSpecProvider()
    cnpj = n.cnpj()
    assert cnpj != '' & len(cnpj) == 18


# Generated at 2022-06-23 20:46:11.470558
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf().replace('.', '').replace('-', '')) == 11
    assert len(BrazilSpecProvider().cpf().replace('.', '').replace('-', '')) == 11
    assert len(BrazilSpecProvider().cpf().replace('.', '').replace('-', '')) == 11
    assert len(BrazilSpecProvider().cpf().replace('.', '').replace('-', '')) == 11


# Generated at 2022-06-23 20:46:15.449474
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test."""
    bsp = BrazilSpecProvider()
    assert bsp.__class__.__name__ == 'BrazilSpecProvider'


# Generated at 2022-06-23 20:46:17.030170
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    '''Test method cpf of class BrazilSpecProvider'''
    provider = BrazilSpecProvider()
    assert provider.cpf() == '608.871.524-71'


# Generated at 2022-06-23 20:46:19.588432
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    assert BrazilSpecProvider().cpf() == '066.610.839-99'


# Generated at 2022-06-23 20:46:20.878193
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().cnpj()
    assert BrazilSpecProvider().cpf()

# Generated at 2022-06-23 20:46:28.944291
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers import BrazilSpecProvider
    from mimesis.data import BASE_DATA
    br = BrazilSpecProvider()
    cnpj = br.cnpj(with_mask=False)
    # Test that the CNPJ is a string
    assert type(cnpj) == str
    # Test that the returned CNPJ is valid
    assert cnpj in BASE_DATA['pt-br']['cnpj']


# Generated at 2022-06-23 20:46:32.394162
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    myobj1 = BrazilSpecProvider()
    myobj2 = BrazilSpecProvider(seed = 'pisma')

    assert myobj1.cpf() == '830.872.012-07'
    assert myobj2.cpf() == '870.439.054-62'


# Generated at 2022-06-23 20:46:34.735581
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=23)
    assert provider.cnpj() == '14.992.344/0001-83'


# Generated at 2022-06-23 20:46:39.195715
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Initialize a seed
    seed = '1234567'
    # Initialize the BrazilSpecProvider
    provider = BrazilSpecProvider(seed)
    # Verify the CPF
    assert provider.cpf(with_mask=False) == '0011372976'

# Generated at 2022-06-23 20:46:44.707810
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create instance of BrazilSpecProvider class
    brazilspec = BrazilSpecProvider()

    assert len(brazilspec.cnpj()) == 14
    assert brazilspec.cnpj()[2] == '.'
    assert brazilspec.cnpj()[6] == '.'
    assert brazilspec.cnpj()[10] == '/'
    assert brazilspec.cnpj()[15] == '-'


# Generated at 2022-06-23 20:46:47.138403
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Arrange
    bsp = BrazilSpecProvider()

    # Act
    cpf = bsp.cpf()

    # Assert
    assert len(cpf) == 14



# Generated at 2022-06-23 20:46:51.897878
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # test with_mask=False
    cpf = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.isdigit()

    # test with_mask=True
    cpf = BrazilSpecProvider().cpf(with_mask=True)
    assert len(cpf) == 14
    assert '-' in cpf
    assert '.' in cpf
    assert cpf[-2].isdigit()
    assert cpf[-1].isdigit()



# Generated at 2022-06-23 20:46:54.383112
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert cpf == "123.456.789-10"

# Generated at 2022-06-23 20:46:56.514215
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Check random CNPJ generate."""
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == bsp.cnpj()

# Generated at 2022-06-23 20:46:58.170445
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf(False)
    assert provider.cnpj(False)

# Generated at 2022-06-23 20:47:02.276420
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj(True)
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-23 20:47:07.282642
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('Test method __init__ of class BrazilSpecProvider()')
    provider = BrazilSpecProvider(seed=1)
    assert provider.seed == 1
    assert provider.locale == 'pt-br'
    assert provider.random is not None


# Generated at 2022-06-23 20:47:10.130970
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert isinstance(cnpj, str) and len(cnpj) == 18
