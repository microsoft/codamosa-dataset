

# Generated at 2022-06-23 20:37:10.815602
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()
    assert bp.cpf() is not None
    assert bp.cpf(with_mask=False) is not None


# Generated at 2022-06-23 20:37:13.101954
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
        provider = BrazilSpecProvider()
        assert provider.cpf(with_mask=True) == "123.456.789-10"



# Generated at 2022-06-23 20:37:17.061651
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    u = BrazilSpecProvider()
    cpf = u.cpf()
    assert len(cpf)==14
    cpf = u.cpf(False)
    assert len(cpf)==11


# Generated at 2022-06-23 20:37:20.700263
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilSpecProvider = BrazilSpecProvider()
    assert len(brazilSpecProvider.cnpj()) == 18
    assert len(brazilSpecProvider.cnpj(False)) == 14
    print(brazilSpecProvider.cnpj())
    print(brazilSpecProvider.cnpj(False))

# Generated at 2022-06-23 20:37:24.002463
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=47)
    assert provider.cpf() == '013.048.779-72'
    assert provider.cnpj() == '55.422.349/0002-35'


# Generated at 2022-06-23 20:37:24.556294
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    pass

# Generated at 2022-06-23 20:37:29.710702
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj_mask_result = bsp.cnpj(with_mask=True)
    cnpj_without_mask_result = bsp.cnpj(with_mask=False)
    cnpj_mask_expected = cnpj_mask_result
    cnpj_expected = cnpj_without_mask_result

    assert cnpj_mask_result == cnpj_mask_expected
    assert cnpj_without_mask_result == cnpj_expected

# Generated at 2022-06-23 20:37:33.401348
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpcPrvdr = BrazilSpecProvider()
    assert brazilSpcPrvdr.cpf() == '350.942.463-90'
    assert brazilSpcPrvdr.cpf(False) == '35094246390'


# Generated at 2022-06-23 20:37:37.222502
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf(with_mask=True)

    print("CPF with mask:", cpf)
    assert cpf[:3].isdigit() == True
    assert cpf[4:7].isdigit() == True
    assert cpf[8:11].isdigit() == True
    assert cpf[-2:].isdigit() == True
    assert cpf[3:4] == '.'
    assert cpf[7:8] == '.'
    assert cpf[11:12] == '-'
    assert len(cpf) == 14


# Generated at 2022-06-23 20:37:47.935127
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test to check method cnpj of class BrazilSpecProvider."""
    # Check if method returns a string
    provider = BrazilSpecProvider()
    assert type(provider.cnpj()) == str
    assert type(provider.cnpj(True)) == str
    # Check if method returns a formatted string
    cnpj_with_mask = provider.cnpj(True)
    assert cnpj_with_mask[2] == "."
    assert cnpj_with_mask[6] == "."
    assert cnpj_with_mask[10] == "/"
    assert cnpj_with_mask[15] == "-"
    # Check if method returns an unformatted string
    cnpj_without_mask = provider.cnpj()
    assert len(cnpj_without_mask) == 14

# Generated at 2022-06-23 20:37:49.584687
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    test = brazil.cnpj()
    assert test

# Generated at 2022-06-23 20:37:50.441053
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider()

# Generated at 2022-06-23 20:37:52.829219
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(10):
        cnpj = BrazilSpecProvider.cnpj()
        assert isinstance(cnpj, str) and len(cnpj) > 1



# Generated at 2022-06-23 20:37:58.362637
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result = provider.cnpj()
    result_with_mask = provider.cnpj(with_mask=True)

    assert len(result) == 14
    assert len(result_with_mask) == 18
    for digit in result:
        assert digit.isdigit()
    for digit in result_with_mask:
        assert digit.isdigit() or digit == '.' or digit == '/' or digit == '-'


# Generated at 2022-06-23 20:38:09.177803
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj.

    Expectation:
        Case 1:
            All digits generated are the same (1).
        Case 2:
            All digits generated are the same (2).
        Case 3:
            All digits generated are the same (3).
        Case 4:
            All digits generated are the same (4).
        Case 5:
            All digits generated are the same (5).
        Case 6:
            All digits generated are the same (6).
        Case 7:
            All digits generated are the same (7).
        Case 8:
            All digits generated are the same (8).
        Case 9:
            All digits generated are the same (9).
        Case 10:
            All digits generated are the same (0).
    """
    provider = BrazilSpecProvider()
    cnpj_list = []
   

# Generated at 2022-06-23 20:38:12.921671
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    assert hasattr(brazil_spec_provider, 'seed')
    assert hasattr(brazil_spec_provider, '_random')
    assert hasattr(brazil_spec_provider, '_datetime')
    


# Generated at 2022-06-23 20:38:15.962503
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cnpj(True) == '77.732.230/0001-70'
    assert brazil_spec_provider.cnpj(False) == '77732230000170'

# Generated at 2022-06-23 20:38:17.092829
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()[:3] == '000'


# Generated at 2022-06-23 20:38:17.793925
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert callable(BrazilSpecProvider)


# Generated at 2022-06-23 20:38:21.926586
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    foo = BrazilSpecProvider()
    cpf = foo.cpf()
    cnpj = foo.cnpj()

    assert cpf == '517.496.577-66'
    assert cnpj == '80.051.965/0001-10'

# Generated at 2022-06-23 20:38:25.582363
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=100)
    cpf = provider.cpf()
    assert cpf == '701.908.917-02'


# Generated at 2022-06-23 20:38:33.907286
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider Class."""

    from mimesis.schema import Field
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.builtins import Person
    from mimesis.builtins import Address
    from mimesis.builtins import BrazilSpecProvider

    br_person = Person('pt-br')
    br_address = Address('pt-br')

    seed = br_person.generate_seed()
    peso = 5
    cnpj_without_dv = [br_person.random.randint(0, 9) for _ in range(12)]

    first_dv = BrazilSpecProvider(seed).get_verifying_digit_cnpj(cnpj_without_dv, peso) if peso == 5 else BrazilSpecProvider

# Generated at 2022-06-23 20:38:39.077512
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Unit test for method cpf of class BrazilSpecProvider
    provider = BrazilSpecProvider()
    # cpf without mask
    print(provider.cpf(with_mask=False))
    # cpf with mask
    print(provider.cpf(with_mask=True))



# Generated at 2022-06-23 20:38:43.505526
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=10001)
    target = '130.454.307-80'
    result = provider.cpf(with_mask=True)
    print(result)

    assert(result == target)


if __name__ == '__main__':
    test_BrazilSpecProvider_cpf()

# Generated at 2022-06-23 20:38:44.481348
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()

# Generated at 2022-06-23 20:38:48.436028
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cnpj()
    assert provider.cnpj(with_mask=False)
    assert provider.cpf(with_mask=False)

# Generated at 2022-06-23 20:38:51.680139
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider class."""

    bz_sp = BrazilSpecProvider()
    cnpj = bz_sp.cnpj()
    assert cnpj

# Generated at 2022-06-23 20:38:58.091131
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 18
    for i in range(5):
        cnpj = bsp.cnpj()
        cnpj_without_mask = cnpj.replace('.', '').replace('-', '').replace('/', '')
        cnpj_int_list = [int(i) for i in cnpj_without_mask]
        j = 2
        k = 0
        sum = 0
        while j >= 0:
            sum = sum + cnpj_int_list[k] * (6 - j)
            j = j - 1
            k = k + 1
        sum = sum % 11
        if sum < 2:
            sum = 0
        else:
            sum = 11 - sum

# Generated at 2022-06-23 20:39:03.271469
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis import BrazilSpecProvider
    from mimesis import Seed

    seed = Seed.create_seed()
    cnpj = BrazilSpecProvider(seed=seed)
    print(cnpj.cnpj())

    cpf = BrazilSpecProvider(seed=seed)
    print(cpf.cpf())

# Generated at 2022-06-23 20:39:05.877632
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender

    provider = BrazilSpecProvider()
    # print(provider.cnpj())
    # print(provider.cnpj(with_mask=False))



# Generated at 2022-06-23 20:39:12.141431
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert cnpj.count('-') == 1
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:39:13.973062
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()

# Generated at 2022-06-23 20:39:15.574223
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bs = BrazilSpecProvider()

    assert bs() == bs

# Generated at 2022-06-23 20:39:17.344531
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert isinstance(cnpj, str)


# Generated at 2022-06-23 20:39:19.368599
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    cpf = BrazilSpecProvider.cpf()
    print(cpf)



# Generated at 2022-06-23 20:39:23.242939
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Locale initialization.
    provider = BrazilSpecProvider(seed = None)
    is_cpf_valid = provider.cpf(with_mask = True)
    assert len(is_cpf_valid) == 14
    assert is_cpf_valid[3] == '.'
    assert is_cpf_valid[7] == '.'
    assert is_cpf_valid[11] == '-'
    print("BrazilSpecProvider.cpf() test passed")


# Generated at 2022-06-23 20:39:25.872995
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert hasattr(bsp, 'cpf')
    assert isinstance(bsp.cpf(), str) and len(bsp.cpf()) == 14


# Generated at 2022-06-23 20:39:30.437731
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import pytest
    from mimesis.enums import Gender
    from mimesis.builtins.person import Person

    brazil_spec = BrazilSpecProvider()
    person = Person('pt-br')

    assert brazil_spec._data['brazil']['address']['city']['types']['first_names_female'][0] == 'Araguari'
    assert brazil_spec._data['brazil']['address']['city']['types']['first_names_male'][0] == 'Diadema'
    assert brazil_spec._data['brazil']['address']['city']['types']['last_names_female'][0] == 'Recife'

# Generated at 2022-06-23 20:39:33.903415
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    assert brazil is not None


# Generated at 2022-06-23 20:39:37.518550
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilprovider = BrazilSpecProvider(seed=1)

    assert brazilprovider.cnpj() == '77.732.230/0001-70'
    assert brazilprovider.cpf() == '001.137.297-40'

# Generated at 2022-06-23 20:39:39.869050
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    result = BrazilSpecProvider().cnpj()
    assert len(result) == 18

# Generated at 2022-06-23 20:39:46.060787
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf with defaults."""
    # Preconditions
    expected = "###.###.###-##"
    # Execution
    bsp = BrazilSpecProvider()
    result = bsp.cpf()
    # Postconditions
    assert result is not None
    assert type(result) is str
    assert result.lower() != result
    assert len(result) == len(expected)
    assert result != expected


# Generated at 2022-06-23 20:39:50.972910
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[12:].isnumeric()
    assert cpf[:12].replace('.', '').isnumeric()


# Generated at 2022-06-23 20:39:54.292369
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() in ['28.056.716/0001-14', '27.240.874/0001-19', '85.072.831/0001-53']

# Generated at 2022-06-23 20:39:56.924663
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for constructor BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert provider.cpf() # Return a cpf with mask
    assert provider.cnpj() # Return a cnpj with mask

# Generated at 2022-06-23 20:39:59.336970
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    cnpj = br.cnpj()
    print(cnpj)
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:40:03.109252
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for BrazilSpecProvider.cpf."""
    data_provider = BrazilSpecProvider()
    cpf = data_provider.cpf()
    assert len(cpf) == 14
    cpf = data_provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:40:09.194297
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider(seed=0)
    assert provider.cpf(with_mask=False) == '64243374306'
    assert provider.cpf() == '642.433.743-06'


# Generated at 2022-06-23 20:40:11.594576
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # test BrazilSpecProvider
    brazil_provider = BrazilSpecProvider()

    assert brazil_provider.cnpj() == "50.872.387/0001-08"
    assert brazil_provider.cpf() == "754.109.163-87"

# Generated at 2022-06-23 20:40:14.601616
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    random_generator = BrazilSpecProvider(seed = "TEST_VALID_SEED_123")
    test_cpf = random_generator.cpf(random_generator.seed)
    assert test_cpf == "525.297.224-14" 


# Generated at 2022-06-23 20:40:19.403066
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test class BrazilSpecProvider.

    :returns: None
    """

    brazil_provider = BrazilSpecProvider()

    cpf = brazil_provider.cpf()
    assert cpf == '051.017.310-58'

    cnpj = brazil_provider.cnpj()
    assert cnpj == '27.123.111/0001-50'

# Generated at 2022-06-23 20:40:23.040281
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p1 = BrazilSpecProvider()
    cnpj = p1.cnpj()
    assert len(cnpj) == 18
    cnpj = p1.cnpj(with_mask=False)
    assert len(cnpj) == 14

# Generated at 2022-06-23 20:40:29.899364
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    for _ in range(0, 100):
        cpf = provider.cpf(with_mask=True)
        assert len(cpf) == 14
        assert cpf[9] == '-'
        assert cpf[:9].replace(".", "").isdigit()
        assert cpf[10:-2].isdigit()


# Generated at 2022-06-23 20:40:32.845245
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    assert BrazilSpecProvider().cnpj() #  BUG:  assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-23 20:40:36.240396
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bzp = BrazilSpecProvider()

    assert bzp.cpf(with_mask=False).__len__() == 11
    assert bzp.cpf(with_mask=True).__len__() == 14


# Generated at 2022-06-23 20:40:37.478257
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=234234)



# Generated at 2022-06-23 20:40:40.854380
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf."""
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14, 'Invalid CPF!'


# Generated at 2022-06-23 20:40:44.077409
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    for i in range(100):
        cnpj = bsp.cnpj()
        assert len(cnpj) == 18, "The lengh of the cnpj is greater than 18"

# Generated at 2022-06-23 20:40:46.356478
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(1000):
        print(str(i) + ": " + BrazilSpecProvider().cnpj())


# Generated at 2022-06-23 20:40:53.954171
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    # Use cpf mask
    print(bsp.cpf())
    # Unused cpf mask
    print(bsp.cpf(False))
    # Check if cpf is validated correctly
    print(bsp.cpf().isnumeric())
    print(bsp.cpf().isdigit())
    print(bsp.cpf().count('.')==2)
    print(bsp.cpf().count('-')==1)


# Generated at 2022-06-23 20:40:58.811452
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for _ in range(10):
        cpf = provider.cpf()
        assert len(cpf) == 14, cpf
        assert cpf[3] == ".", cpf
        assert cpf[7] == ".", cpf
        assert cpf[11] == "-", cpf
        assert cpf[9] != "0", cpf


# Generated at 2022-06-23 20:41:01.412019
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()
    print(bp.cpf(with_mask=True))
    print(bp.cpf(with_mask=False))
    print(bp.cpf(with_mask=False))


# Generated at 2022-06-23 20:41:03.609367
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-23 20:41:14.869257
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()

    # Some examples:
    assert bp.cnpj() in ['33.936.928/0001-56', '35.002.986/0001-16',
                         '24.880.493/0001-40', '10.185.395/0001-17',
                         '81.901.066/0001-60', '04.734.942/0001-63',
                         '72.599.308/0001-01', '56.285.678/0001-95',
                         '05.654.111/0001-06', '85.470.160/0001-90']

    # For a given seed, the result should be the same:
    bp2 = BrazilSpecProvider(seed=bp.seed)
    assert bp.cnpj() == bp2.cnpj()



# Generated at 2022-06-23 20:41:17.754072
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider class."""
    bsp = BrazilSpecProvider()
    assert bsp.cpf(with_mask=True)

# Generated at 2022-06-23 20:41:23.522518
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    braz = BrazilSpecProvider()
    braz_cpf = braz.cpf()
    assert len(braz_cpf) == 14
    assert braz_cpf[3] == '.'
    assert braz_cpf[7] == '.'
    assert braz_cpf[11] == '-'
    assert braz_cpf[12:] == "40"


# Generated at 2022-06-23 20:41:24.275532
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pass

# Generated at 2022-06-23 20:41:29.130277
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    output = BrazilSpecProvider().cnpj(True)
    assert output.__class__ == str
    assert len(output) == 18

    output = BrazilSpecProvider().cnpj(False)
    assert output.__class__ == str
    assert len(output) == 14


# Generated at 2022-06-23 20:41:31.536004
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_cpf = BrazilSpecProvider()
    assert len(brazil_cpf.cpf().replace('.', '').replace('-', '')) == 11


# Generated at 2022-06-23 20:41:38.509417
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pt-br')
    basic_data = {
        'with_mask': True,
        'without_mask': False,
        'gender': Gender.MALE,
    }

    for data in basic_data:
        print("\nTesting BrazilSpecProvider's method cnpj with {}".format(data))
        provider = BrazilSpecProvider()

# Generated at 2022-06-23 20:41:41.714171
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf(with_mask=False)) == 11
    assert len(brazil_spec_provider.cpf(with_mask=True)) == 14


# Generated at 2022-06-23 20:41:44.751728
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    for i in range(100):
        assert len(provider.cnpj()) == 18

        assert len(provider.cnpj(True)) == 18
        assert len(provider.cnpj(False)) == 14


# Generated at 2022-06-23 20:41:46.120414
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cpf = BrazilSpecProvider.cnpj()
    assert len(cpf) == 18

# Generated at 2022-06-23 20:41:49.113427
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender
    provider = BrazilSpecProvider()
    expected = Gender.FEMALE
    actual = provider.gender()
    assert expected == actual

# Generated at 2022-06-23 20:41:50.310890
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
  pass


# Generated at 2022-06-23 20:41:52.217372
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    print(cpf)


# Generated at 2022-06-23 20:41:57.507319
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # arrange
    expected = ['079.955.922-97']

    # act
    actual = []
    provider = BrazilSpecProvider()
    for _ in range(1):
        actual.append(provider.cpf())

    # assert
    for x in range(len(expected)):
        assert expected[x] == actual[x]


# Generated at 2022-06-23 20:41:59.979354
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider
    bp = BrazilSpecProvider(seed=0)
    resposta = bp.cnpj()
    assert resposta == '18.527.697/0001-43'


# Generated at 2022-06-23 20:42:01.540873
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '00.346.073/0003-20'


# Generated at 2022-06-23 20:42:03.015238
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bs = BrazilSpecProvider()
    assert len(bs.cnpj()) == 18

# Generated at 2022-06-23 20:42:07.091803
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert(len(bsp.cpf()) == 14)
    assert(len(bsp.cpf(False)) == 11)
    

# Generated at 2022-06-23 20:42:12.372530
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  from mimesis.builtins.br import BrazilSpecProvider
  br = BrazilSpecProvider()

  # 14.464.741/0001-57
  cnpj = br.cnpj(with_mask = True)
  assert (cnpj == '14.464.741/0001-57')

  # 14.464.741/0001-57
  cnpj = br.cnpj(with_mask = False)
  assert (cnpj == '144647410000157')

# Generated at 2022-06-23 20:42:15.256652
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
	instance = BrazilSpecProvider()
	assert instance.cnpj() == 11644589000161


# Generated at 2022-06-23 20:42:22.057185
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from datetime import datetime
    a = BrazilSpecProvider()
    assert a.date_time() < datetime.now()
    assert len(a.id_number()) == 11
    assert len(a.cpf()) == 14
    assert len(a.cnpj()) == 18
    assert a.id_number() != a.id_number()
    assert a.cpf() != a.cpf()
    assert a.cnpj() != a.cnpj()

# Generated at 2022-06-23 20:42:25.329129
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    prov = BrazilSpecProvider()
    assert prov.data == {
        'cpf': prov.cpf(),
        'cnpj': prov.cnpj()
    }

# Generated at 2022-06-23 20:42:35.203608
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Initialize the object
    brazil_provider = BrazilSpecProvider()
    # Generate cpf without mask
    cpf = brazil_provider.cpf(False)
    # Generate cnpj without mask
    cnpj = brazil_provider.cnpj(False)
    # Generate cpf with mask
    cpf_with_mask = brazil_provider.cpf()
    # Generate cnpj with mask
    cnpj_with_mask = brazil_provider.cnpj()
    # Test cpf and cnpj
    assert len(cpf) == 11
    assert len(cnpj) == 14
    # Test cpf and cnpj with mask
    assert len(cpf_with_mask) == 14

# Generated at 2022-06-23 20:42:40.106835
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from numpy.random import Generator, PCG64
    rng = Generator(PCG64())
    # CPF code summary
    assert BrazilSpecProvider(seed=rng).cpf() == '817.081.336-53'


# Generated at 2022-06-23 20:42:41.928155
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for i in range(10):
        result = provider.cpf()
        assert len(result) == 14


# Generated at 2022-06-23 20:42:44.254990
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # This test check if class BrazilSpecProvider is callable
    provider_test = BrazilSpecProvider()

    assert callable(provider_test)

# Generated at 2022-06-23 20:42:44.855140
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:42:48.737222
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    assert provider.cnpj(True) == '77.732.230/0001-70'
    assert provider.cnpj(False) == '77732240000170'

# Generated at 2022-06-23 20:42:58.338145
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import unittest
    set_default_mask_for_cnpj_tests = False
    class TestBrazilSpecProvider(unittest.TestCase):
        def test_cnpj_with_mask(self):
            bsp = BrazilSpecProvider(seed=10)
            self.assertEqual(bsp.cnpj(), "21.063.908/0001-52")
        def test_cnpj_without_mask(self):
            bsp = BrazilSpecProvider(seed=10)
            self.assertEqual(bsp.cnpj(with_mask=False), "21063990000152")
    # Mask in the result of method cnpj of class BrazilSpecProvider
    if not set_default_mask_for_cnpj_tests:
        rev_BSP = BrazilSpecProvider(seed=10)
       

# Generated at 2022-06-23 20:43:01.275710
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert bsp._cpf_verifier(cpf)


# Generated at 2022-06-23 20:43:04.363159
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    print(brazil.cpf(True))
    print(brazil.cnpj(True))

# Generated at 2022-06-23 20:43:13.243981
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    locale = 'pt-br'
    seed = 'test'
    b = BrazilSpecProvider(seed)
    cpf_with_mask = b.cpf(with_mask=True)
    assert int(cpf_with_mask[0:3]) > 0
    assert int(cpf_with_mask[3:6]) > 0
    assert int(cpf_with_mask[6:9]) > 0
    assert int(cpf_with_mask[9:]) > 0
    cpf_without_mask = b.cpf(with_mask=False)
    assert int(cpf_without_mask[0:3]) > 0
    assert int(cpf_without_mask[3:6]) > 0
    assert int(cpf_without_mask[6:9]) > 0

# Generated at 2022-06-23 20:43:15.505806
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf(with_mask=False) != None
    assert brazil.cnpj(with_mask=False) != None

# Generated at 2022-06-23 20:43:16.695560
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    return provider


# Generated at 2022-06-23 20:43:19.685868
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '924.822.126-00'


# Generated at 2022-06-23 20:43:20.674029
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()


# Generated at 2022-06-23 20:43:21.697402
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-23 20:43:22.318996
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:43:25.073848
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp=BrazilSpecProvider()
    for i in range(10):
        cpf=bsp.cpf()
        assert len(cpf)==14


# Generated at 2022-06-23 20:43:27.242156
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider class."""
    test_instance = BrazilSpecProvider()
    assert test_instance is not None


# Generated at 2022-06-23 20:43:28.824582
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """The test for the constructor of class BrazilSpecProvider."""
    BrazilSpecProvider()

# Generated at 2022-06-23 20:43:29.432251
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert True

# Generated at 2022-06-23 20:43:32.154310
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Testing BrazilSpecProvider")
    brazil = BrazilSpecProvider()
    assert brazil.cpf() == "010.004.779-26"
    print("Test succesfully")


# Generated at 2022-06-23 20:43:38.746079
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers import BrazilSpecProvider

    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert cnpj

    brazil_provider_without_mask = BrazilSpecProvider()
    cnpj_without_mask = brazil_provider_without_mask.cnpj(with_mask=False)
    assert cnpj_without_mask


# Generated at 2022-06-23 20:43:41.076481
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert len(provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:43:43.023418
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert isinstance(cpf, str)



# Generated at 2022-06-23 20:43:45.375039
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider(seed=12)
    assert b != None


# Generated at 2022-06-23 20:43:50.774992
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cpf(False)) == 11
    assert provider.cpf().startswith("###.###.###") == False
    assert provider.cpf(False).startswith("###.###.###") == False
    assert provider.cpf().endswith("-##") == False
    assert provider.cpf(False).endswith("-##") == False


# Generated at 2022-06-23 20:43:55.184292
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    spec = BrazilSpecProvider()

    assert len(spec.cpf()) == 14
    assert spec.cpf(with_mask=False) == '08291098110'
    assert spec.cpf(with_mask=True) == '082.910.981-10'



# Generated at 2022-06-23 20:43:56.770741
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for _ in range(10):
        print(BrazilSpecProvider().cpf())


# Generated at 2022-06-23 20:43:58.260294
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert isinstance(bsp.cnpj(), str)


# Generated at 2022-06-23 20:44:00.249051
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of BrazilSpecProvider."""
    assert BrazilSpecProvider()


# Generated at 2022-06-23 20:44:05.694822
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj_1 = provider.cnpj()
    cnpj_2 = provider.cnpj(with_mask=False)

    assert len(cnpj_1) == 18 and len(cnpj_2) == 14
    assert cnpj_1[2] == '.' and cnpj_1[6] == '.' and cnpj_1[10] == '/' and cnpj_1[15] == '-'


# Generated at 2022-06-23 20:44:13.180755
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test 1, check whether there is a verification digit in the CNPJ.
    provider = BrazilSpecProvider()
    invalid_cnpj = provider.cnpj(with_mask=False)
    assert (len(invalid_cnpj) == 14)
    assert (invalid_cnpj[12] != invalid_cnpj[13])
    # Test 2, check whether the CNPJ starts with 80.
    provider = BrazilSpecProvider()
    valid_cnpj = provider.cnpj()
    assert(valid_cnpj[0:3] == '80.')
    # Test 3, check whether the CNPJ ends with 45.
    assert(valid_cnpj[len(valid_cnpj) - 3:] == '-45')


# Generated at 2022-06-23 20:44:17.080873
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf()) == 14
    assert len(brazil_spec_provider.cpf(with_mask=False)) == 11
    assert len(brazil_spec_provider.cnpj()) == 18
    assert len(brazil_spec_provider.cnpj(with_mask=False)) == 14


# Generated at 2022-06-23 20:44:22.762975
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    d = BrazilSpecProvider()
    cpf = d.cpf()
    print(cpf)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    

# Generated at 2022-06-23 20:44:25.180055
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(0, 100):
        cpf = BrazilSpecProvider().cpf()
        assert len(cpf) == 14 or len(cpf) == 11



# Generated at 2022-06-23 20:44:31.627320
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    for _ in range(0, 200):
        cnpj_formatted = brazil.cnpj(with_mask=True)
        assert(len(cnpj_formatted) == 18)
        assert(cnpj_formatted[2] == '.')
        assert(cnpj_formatted[6] == '.')
        assert(cnpj_formatted[10] == '/')
        assert(cnpj_formatted[15] == '-')

        cnpj_plain = brazil.cnpj(with_mask=False)
        assert(len(cnpj_plain) == 14)
        assert(cnpj_plain[:2] == cnpj_formatted[:2])

# Generated at 2022-06-23 20:44:39.148506
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider."""
    from mimesis.providers.datetime import Datetime
    from .. import BrazilSpecProvider
    import re

    r = re.compile(r'\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}')

    bs = BrazilSpecProvider(seed=Datetime().timestamp())
    assert r.match(bs.cnpj(with_mask=True)) is not None

# Generated at 2022-06-23 20:44:45.079497
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.locale == 'pt-br'

    # test_cpf method
    assert brazil.cpf(with_mask=False)
    assert brazil.cpf(with_mask=True)

    # test_cnpj method
    assert brazil.cnpj()

# Generated at 2022-06-23 20:44:48.818062
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '77.732.230/0001-70'
    assert provider.cnpj(with_mask=False) == '77732230000170'


# Generated at 2022-06-23 20:44:51.280949
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  instance = BrazilSpecProvider(seed=42)
  assert instance.cnpj() == '72.931.032/0001-48'


# Generated at 2022-06-23 20:44:53.743808
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider()
    assert instance.cpf(with_mask=False)
    assert instance.cnpj(with_mask=False)


# Generated at 2022-06-23 20:44:55.801748
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test CPF output."""
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:44:56.872473
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=1)


# Generated at 2022-06-23 20:44:58.469119
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    cnpj = provider.cnpj()


# Generated at 2022-06-23 20:45:04.042985
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider()
    assert cnpj.cnpj() == '77.732.230/0001-70'
    assert cnpj.cnpj(True) == '77.732.230/0001-70'
    assert cnpj.cnpj(False) == '77732230000170'


# Generated at 2022-06-23 20:45:04.661473
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:45:05.554265
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    import doctest
    doctest.testmod(extraglobs={'bp': BrazilSpecProvider()})

# Generated at 2022-06-23 20:45:07.413775
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj()) >= 14


# Generated at 2022-06-23 20:45:18.351176
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    - ID: BR-CP-4
    - Name: BrazilSpecProvider - cnpj
    - Feature: BrazilSpecProvider
    - TestCase: BrazilSpecProvider.cnpj()
    - Operation: Generate 10 random cnpj using with_mask=True and save them in a file
    - Expected: The result should be a valid cnpj, according to the mask and the rules
    """
    print("Running test for method 'cnpj' in class BrazilSpecProvider")
    brazil_cnpj = BrazilSpecProvider()
    file = open("BrazilSpecProvider_cnpj.txt", "w")
    for i in range(10):
        file.write("{0:0>14}\n".format(brazil_cnpj.cnpj(with_mask=False)))
    file.close()

#

# Generated at 2022-06-23 20:45:19.329803
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider() != ""

# Generated at 2022-06-23 20:45:29.889904
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    example = BrazilSpecProvider()
    # test for method cpf
    cpf = example.cpf()
    len_str = len(cpf)
    dv1 = cpf[-2]
    dv2 = cpf[-1]
    cpf = cpf[:-2]
    soma = 0
    index = 10
    for digit in cpf:
        if index == 1:
            break
        if digit.isdigit():
            soma += int(digit) * index
            index -= 1
    resto = soma % 11
    if resto == 0 or resto == 1 or resto >= 11:
        resto = 0
    else:
        resto = 11 - resto

    assert resto == int(dv1)

    soma = 0
    index = 11

# Generated at 2022-06-23 20:45:31.740235
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert brazil.cpf() == '025.257.738-10'


# Generated at 2022-06-23 20:45:40.712271
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test with_mask argument
    for _ in range(10):
        cpf = BrazilSpecProvider().cnpj()
        assert len(cpf) == 18
        assert r'\d{14}' not in cpf

        cpf = BrazilSpecProvider().cnpj(with_mask=False)
        assert len(cpf) == 14
        assert r'\d{14}' in cpf

    # Test generated CNPJ with validators
    from validators import cnpj as validator_cnpj
    for _ in range(10):
        cnpj = BrazilSpecProvider().cnpj().replace('.', '').replace('-', '').replace('/', '')
        assert validator_cnpj(cnpj)


# Generated at 2022-06-23 20:45:42.947871
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert obj is not None


# Unit tests for cpf() method

# Generated at 2022-06-23 20:45:45.382274
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf(with_mask=True)
    assert isinstance(cpf, str)


# Generated at 2022-06-23 20:45:56.982884
# Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-23 20:46:05.412076
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test CPF in format ###.###.###-##, the first 3 are not 0 and all
    digits are different.
    """
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    # test if the pattern is correct
    assert cpf.count('.') == 2 and cpf.count('-') == 1
    # test if the first 3 digits are not 0
    assert not cpf[0] == '0' and not cpf[1] == '0' and not cpf[2] == '0'
    # test if all digits are different
    digits = [int(cpf[i]) for i in range(0, len(cpf)) if (
        cpf[i] != '.' and cpf[i] != '-')]

# Generated at 2022-06-23 20:46:11.050052
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Instantiate BrazilSpecProvider
    brazil = BrazilSpecProvider()
    # Get random CPF
    cpf = brazil.cpf()
    # Get random CNPJ
    cnpj = brazil.cnpj()
    print(f"Random CPF: {cpf}\nRandom CNPJ: {cnpj}")


# Generated at 2022-06-23 20:46:15.798236
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider(seed=1)
    assert bp.cpf() == '014.484.446-04'
    assert bp.cpf(with_mask=False) == '01448444604'


# Generated at 2022-06-23 20:46:17.568498
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(False)
    assert len(cnpj) == 14
    assert cnpj == '7773223000170'



# Generated at 2022-06-23 20:46:19.631318
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Test method cpf of class BrazilSpecProvider")
    assert BrazilSpecProvider().cpf(False) == '00113729740'
    assert BrazilSpecProvider().cpf() == '001.137.297-40'    


# Generated at 2022-06-23 20:46:22.809438
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert len(b.cnpj()) == 18
    assert len(b.cnpj(with_mask = False)) == 14
    assert len(b.cnpj(with_mask = True)) == 18


# Generated at 2022-06-23 20:46:27.562931
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert(len(cpf) == 14)
    assert(cpf[3] == '.')
    assert(cpf[7] == '.')
    assert(cpf[11] == '-')
    cnpj = b.cnpj()
    assert(len(cnpj) == 18)
    assert(cnpj[2] == '.')
    assert(cnpj[6] == '.')
    assert(cnpj[10] == '/')
    assert(cnpj[15] == '-')

# Generated at 2022-06-23 20:46:31.067873
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of class BrazilSpecProvider"""
    B = BrazilSpecProvider()
    assert B.metadata['name'] == 'brazil_provider'
    assert B.metadata['locale'] == 'pt-br'
    assert B.metadata['provides'] == []


# Generated at 2022-06-23 20:46:34.037470
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    #cpf = a.cpf()
    #print(cpf)


# Generated at 2022-06-23 20:46:44.666488
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider.

    Relevant rule: RULE #1
    """
    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]

# Generated at 2022-06-23 20:46:47.800860
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert isinstance(result, str)
    assert len(result) == 14
    assert result.count('.') == 2
    assert result.count('-') == 1


# Generated at 2022-06-23 20:46:50.125727
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider  # assert if the provider instance is created



# Generated at 2022-06-23 20:46:55.336431
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(0, 10000):
        cpf = BrazilSpecProvider().cpf()
        assert len(cpf) == 14
        assert cpf[3] == '.'
        assert cpf[7] == '.'
        assert cpf[11] == '-'
        assert cpf.isnumeric()


# Generated at 2022-06-23 20:46:58.128641
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '730.019.198-87'
    assert provider.cnpj() == '63.492.217/0001-89'



# Generated at 2022-06-23 20:46:59.774917
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    spec = BrazilSpecProvider()
    assert spec.cnpj() != None
    assert spec.cpf() != None

# Generated at 2022-06-23 20:47:05.187908
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data_set = {
        '999.888.777-66': False,
        '111.111.111-11': False,
        '222.222.222-22': False,
        '333.333.333-33': False,
        '444.444.444-44': False,
        '555.555.555-55': False,
        '666.666.666-66': False,
        '777.777.777-77': False,
        '888.888.888-88': False,
        '999.999.999-99': False,
        '12345678901234': False,
    }

    for cpf, result in data_set.items():
        assert BrazilSpecProvider().validate_cpf(cpf) is result


# Generated at 2022-06-23 20:47:11.348241
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert cpf[-2:] != "00"
    assert cpf[-1:] != "0"

test_BrazilSpecProvider_cpf()
