

# Generated at 2022-06-23 20:37:13.190314
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    brazilSpecProvider = BrazilSpecProvider()
    assert issubclass(brazilSpecProvider.__class__, BaseSpecProvider) and brazilSpecProvider.__class__.__name__ == 'BrazilSpecProvider', "Erro ao testar construtor da classe BrazilSpecProvider"


# Generated at 2022-06-23 20:37:23.734109
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import pytest
    from mimesis.builtins import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert cpf.count(cpf[0]) <= 2
    assert cpf[0] != 0
    assert cpf[-2] != cpf[-1]
    cpf = bsp.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.count(cpf[0]) <= 2
    assert cpf[0] != 0
   

# Generated at 2022-06-23 20:37:25.661491
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    result = brazil_provider.cnpj()
    print(result)



# Generated at 2022-06-23 20:37:28.965498
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    a = BrazilSpecProvider()
    assert a.cpf(True)

    b = BrazilSpecProvider()
    assert b.cnpj(True)

# Generated at 2022-06-23 20:37:31.111787
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    b = BrazilSpecProvider()
    assert a.cpf() != b.cpf()


# Generated at 2022-06-23 20:37:34.153555
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test function for method BrazilSpecProvider.cnpj()"""
    brazil = BrazilSpecProvider()
    for i in range(0, 100):
        assert len(brazil.cnpj()) == 18


# Generated at 2022-06-23 20:37:37.935784
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_data_provider = BrazilSpecProvider()
    assert brazil_data_provider.cpf() is not None
    assert brazil_data_provider.cnpj() is not None


# Generated at 2022-06-23 20:37:41.726763
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bs = BrazilSpecProvider(seed=1)
    list_cnpj = []
    for i in range(1000):
        list_cnpj.append(bs.cnpj())
    assert(len(set(list_cnpj))==1000)

# Generated at 2022-06-23 20:37:47.032350
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_class = BrazilSpecProvider()
    assert (len(test_class.cnpj(with_mask=False)) == 14)
    assert (len(test_class.cnpj()) == 18)
    #assert (test_class.cnpj(with_mask=False) != test_class.cnpj())


# Generated at 2022-06-23 20:37:49.748123
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=12345)
    cnpj = provider.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:37:57.521089
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf.

    Args:
        bz (BrazilSpecProvider): Instance of class BrazilSpecProvider.

    """
    bz = BrazilSpecProvider()

    cpf = bz.cpf(with_mask=True)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    
    cpf = bz.cpf(with_mask=False)
    assert len(cpf) == 11


# Generated at 2022-06-23 20:38:00.493110
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    cnpj = provider.cnpj()
    assert len(cnpj) == 18

    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14


# Generated at 2022-06-23 20:38:02.034564
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()
    assert BrazilSpecProvider(seed=123)

# Generated at 2022-06-23 20:38:04.541376
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    rand = BrazilSpecProvider()
    assert rand.cpf()
    assert rand.cnpj()
    print(rand.cpf())
    print(rand.cnpj())

# Generated at 2022-06-23 20:38:06.202339
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pass

# Generated at 2022-06-23 20:38:06.827381
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:38:10.875728
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()

    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'



# Generated at 2022-06-23 20:38:12.819910
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Test for class
    assert BrazilSpecProvider().__class__.__name__ == 'BrazilSpecProvider'


# Generated at 2022-06-23 20:38:14.210953
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()
    _ = br.cpf()
    _ = br.cnpj()

# Generated at 2022-06-23 20:38:15.167598
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()


# Generated at 2022-06-23 20:38:16.633225
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:38:19.596804
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of the class BrazilSpecProvider."""

    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(with_mask=False)
    assert len(cpf) == 11

    cnpj = brazil.cnpj(with_mask=False)
    assert len(cnpj) == 14

# Generated at 2022-06-23 20:38:22.811005
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("\nunit test for method cpf of class BrazilSpecProvider")
    bs = BrazilSpecProvider()
    result = bs.cpf()
    print(result)
    assert len(result) == 14


# Generated at 2022-06-23 20:38:26.850076
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    result = re.match(r'^\d{3}\.\d{3}\.\d{3}-\d{2}$', brazil_provider.cpf())
    assert result is not None


# Generated at 2022-06-23 20:38:31.735474
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    # Test random cpf
    assert provider.cpf()
    assert provider.cpf(False)
    assert provider.cpf(True)
    # Specify a seed that generates
    provider.seed(seed=1582811865581)
    assert provider.cpf(False) == '64530782268'
    assert provider.cpf(True) == '645.307.822-68'


# Generated at 2022-06-23 20:38:33.133404
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    try:
        BrazilSpecProvider()
    except:
        assert False

    try:
        BrazilSpecProvider(seed=1234)
    except:
        assert False

    assert True

# Generated at 2022-06-23 20:38:35.644654
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf(False)
    assert len(result) == 11
    


# Generated at 2022-06-23 20:38:38.454281
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for function cpf() of class BrazilSpecProvider."""
    brazil_spc = BrazilSpecProvider()
    print(brazil_spc.cpf())


# Generated at 2022-06-23 20:38:39.636071
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    '''Test is BrazilSpecProvider.cnpj works as expected'''
    brazilSpec = BrazilSpecProvider()
    value = brazilSpec.cnpj()
    assert len(value) == 18



# Generated at 2022-06-23 20:38:50.620284
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import re
    from mimesis import BrazilSpecProvider

    bsp = BrazilSpecProvider()

    dt = bsp.cnpj(True)
    # This test is a typical example of a unit test. It is a test that is
    # limited to a single function. A unit test should test the smallest unit
    # of code possible, so you need to ensure the unit test execution time is
    # small, because this test may be executed several times during the test
    # cycle.

    # The pattern used to validate the CNPJ is a set of rules that define how
    # the validation will be done.
    pattern = re.compile(r'^\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}$')

    # The assert is used to check if the data returned by the

# Generated at 2022-06-23 20:38:54.486529
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilprovider = BrazilSpecProvider()

    assert len(brazilprovider.cpf()) == 14
    assert len(brazilprovider.cpf().replace('.', '').replace('-', '')) == 11
    assert brazilprovider.cpf(False) == "06281637720"


# Generated at 2022-06-23 20:38:57.003522
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.brazil import BrazilSpecProvider
    from mimesis.enums import Gender

    brazil = BrazilSpecProvider(Gender.MALE, 'en')
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:38:58.829581
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider().provider.cpf())
    # print(BrazilSpecProvider().provider.cnpj())

# Generated at 2022-06-23 20:39:06.572105
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider - cnpj"""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    
    qtd = 100
    for _ in range(qtd):
        provider = BrazilSpecProvider()
        person = Person('pt-br')
        gender = Gender(provider.random.randint(0, 1))
        name = person.full_name(gender)
        cpf = provider.cpf()
        cnpj = provider.cnpj()
        print(f'{name},{cpf},{cnpj}')

# Generated at 2022-06-23 20:39:08.875071
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert str(BrazilSpecProvider()) == 'BrazilSpecProvider'


# Generated at 2022-06-23 20:39:11.241436
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    cnpj = provider.cnpj()
    assert cpf and cnpj

# Generated at 2022-06-23 20:39:13.052322
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Testing the constructor of class BrazilSpecProvider"""
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-23 20:39:15.874867
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf()) == 14
    assert len(brazil.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:39:18.292202
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # This code is used when running the unit test only
    provider = BrazilSpecProvider()

    cnpj = provider.cnpj()
    print(cnpj)


# Generated at 2022-06-23 20:39:22.648182
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider_default = BrazilSpecProvider()
    provider_seed_11 = BrazilSpecProvider(seed=11)
    assert provider_default.cnpj() == '77.732.230/0001-70'
    assert provider_seed_11.cnpj() == '57.468.660/0001-17'

# Generated at 2022-06-23 20:39:23.576151
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pass

# Generated at 2022-06-23 20:39:28.927106
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    seed = '123456789'

    provider = BrazilSpecProvider(seed=seed)
    assert provider.cnpj() == '7773223000170'

    # Verify that if with_mask is False, mask is absent in the result
    assert provider.cnpj(with_mask=False) == '777322300017000'



# Generated at 2022-06-23 20:39:29.882381
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()
    BrazilSpecProvider(seed=None)


# Generated at 2022-06-23 20:39:39.231899
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    seed = "0d7f73af8f8b4389afdbd18ddfc57f1d"
    bsp = BrazilSpecProvider(seed)
    # cpf
    assert bsp.cpf() == "611.914.541-12"
    assert bsp.cpf(False) == "61191454112"
    # cnpj
    assert bsp.cnpj() == "04.098.391/0001-29"
    assert bsp.cnpj(False) == "04098391000129"
# End unit test for constructor of class BrazilSpecProvider


# Generated at 2022-06-23 20:39:42.864343
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '001.137.297-40'
    assert provider.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-23 20:39:43.852930
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()


# Generated at 2022-06-23 20:39:48.217307
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()

    cpf = brazil.cpf()
    assert len(cpf) == 14

    cnpj = brazil.cnpj()
    assert len(cnpj) == 18



# Generated at 2022-06-23 20:39:51.437757
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Type checking
    assert isinstance(BrazilSpecProvider(), BrazilSpecProvider)
    assert isinstance(BrazilSpecProvider(seed=1), BrazilSpecProvider)
    assert isinstance(BrazilSpecProvider().seed, int)


# Generated at 2022-06-23 20:39:58.223256
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    cnpj = BrazilSpecProvider().cnpj()

    assert len(cnpj) == 18 or len(cnpj) == 14

    first_digit = int(cnpj[12])
    second_digit = int(cnpj[13])

    assert first_digit >= 0 and first_digit <= 9
    assert second_digit >= 0 and second_digit <= 9

    cnpj_no_mask = BrazilSpecProvider().cnpj(with_mask=False)

    assert len(cnpj_no_mask) == 14



# Generated at 2022-06-23 20:39:59.950759
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj(with_mask=False)
    assert len(cnpj) == 14

# Generated at 2022-06-23 20:40:02.669053
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins.brazil import BrazilSpecProvider
    b = BrazilSpecProvider()
    cpf = b.cpf()
    print('CPF:', cpf)



# Generated at 2022-06-23 20:40:10.386891
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis import BrazilSpecProvider
    from mimesis import Generic
    from mimesis import __version__

    # Generate Brazil gender
    gen = Generic('pt-br')
    assert gen.gender() in ('Masculino', 'Feminino')
    gen = Generic('en')
    assert gen.gender() in ('Male', 'Female')
    gen = Generic('ru')
    assert gen.gender() in ('Мужской', 'Женский')

    # Generate Brazil cpf
    assert len(BrazilSpecProvider().cpf()) == 14
    assert len(BrazilSpecProvider().cpf(False)) == 11

    # Generate Brazil cnpj
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert len(BrazilSpecProvider().cnpj(False))

# Generated at 2022-06-23 20:40:13.258307
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(with_mask=False) == '24634523000177'
    assert BrazilSpecProvider().cnpj(with_mask=True) == '24.634.523/0001-77'


# Generated at 2022-06-23 20:40:24.030093
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.date_time import DateTime
    import pytest

    bsp = BrazilSpecProvider(seed=666)
    dt_provider = DateTime(seed=666)

# Generated at 2022-06-23 20:40:26.653112
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_data = BrazilSpecProvider()
    print(brazil_data.cpf())
    print(brazil_data.cnpj())

# Generated at 2022-06-23 20:40:28.297410
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    test_object = BrazilSpecProvider()
    assert test_object


# Generated at 2022-06-23 20:40:30.648565
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec = BrazilSpecProvider()
    cpf = brazil_spec.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:40:33.544679
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14
    assert len(BrazilSpecProvider().cnpj(with_mask=True)) == 18

# Generated at 2022-06-23 20:40:35.214817
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider()
    print(p.cpf())



# Generated at 2022-06-23 20:40:38.250846
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    result = b.cpf()
    print(result)


# Generated at 2022-06-23 20:40:44.312336
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    s = bsp.cnpj()
    assert s != ''
    assert len(s) == 18
    s = bsp.cnpj(False)
    assert s != ''
    assert len(s) == 14
    s = bsp.cpf()
    assert s != ''
    assert len(s) == 14
    s = bsp.cpf(False)
    assert s != ''
    assert len(s) == 11

# Generated at 2022-06-23 20:40:46.210301
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilProvider = BrazilSpecProvider()
    assert brazilProvider.locale == 'pt-br'


# Generated at 2022-06-23 20:40:49.929883
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cnpj())
    print(brazil_provider.cpf())



# Generated at 2022-06-23 20:40:51.974474
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilprovider = BrazilSpecProvider()
    brazilprovider.cnpj(with_mask=True)

# Generated at 2022-06-23 20:40:54.197786
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.__class__.__name__ == 'BrazilSpecProvider'

# Generated at 2022-06-23 20:40:59.334724
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = '3a8a5bd9-30d7-41b0-8a8e-e95015c64350'
    provider = BrazilSpecProvider(seed=seed)
    cpf1 = provider.cpf()
    cpf2 = provider.cpf(with_mask=False)
    assert cpf1 == '938.432.835-99'
    assert cpf2 == '93843283599'


# Generated at 2022-06-23 20:41:01.296924
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for class BrazilSpecProvider constructor."""
    provider = BrazilSpecProvider()
    assert provider is not None

# Unit tests for method cpf of class BrazilSpecProvider

# Generated at 2022-06-23 20:41:12.762070
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj() method from BrazilSpecProvider class."""
    from mimesis.enums import Gender

    b = BrazilSpecProvider(seed=10)

    assert b.cnpj() == '08.864.534/0001-50'
    assert b.cnpj(with_mask=False) == '0886534000150'

    b.seed(b.seed(Gender.MALE))

    assert b.cnpj() == '09.272.366/0001-33'
    assert b.cnpj(with_mask=False) == '09272366000133'

    b.seed(b.seed(Gender.FEMALE))
    assert b.cnpj() == '07.876.336/0001-89'

# Generated at 2022-06-23 20:41:23.789396
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    print("\n" + "#"*3 + " " + "Testing method cpf of BrazilSpecProvider class" + " " + "#"*3 + "\n")

    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.typing import Seed


    print("\nTesting method cpf with the default seed\n")

    seed = Seed.DEFAULT

    provider_without_seed = BrazilSpecProvider()
    provider_with_seed = BrazilSpecProvider(seed=seed)

    for _ in range(5):
        print("\n<Default Provider>\n")
        for _ in range(5):
            print("\t{}".format(provider_without_seed.cpf()))

# Generated at 2022-06-23 20:41:34.512018
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import Generic
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender

    g = Generic('pt-br')
    b = BrazilSpecProvider('pt-br')
    print(b.cnpj())
    print(b.cnpj(with_mask=False))

    assert b.cnpj() == '17.483.461/0001-07'
    assert b.cnpj(with_mask=False) == '17483461000107'
    assert b.cnpj() != '17.483.461/0001-08'

    # Test the example
    print('-'*33 + 'CNPJ' + '-'*33)
    print('-'*33)
    print('With mask:')

# Generated at 2022-06-23 20:41:38.971527
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("test_BrazilSpecProvider_cpf:")
    cpf = BrazilSpecProvider().cpf()
    print("cpf =", cpf)
    assert cpf == BrazilSpecProvider().cpf(True)
    assert len(cpf) == 14


# Generated at 2022-06-23 20:41:43.927639
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj(with_mask = False)
    assert len(cnpj) == 14
    cnpj_with_mask = b.cnpj()
    assert len(cnpj_with_mask) == 18


# Generated at 2022-06-23 20:41:45.029973
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    print(obj.cpf())
    print(obj.cnpj())

# Generated at 2022-06-23 20:41:45.593915
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=4)

# Generated at 2022-06-23 20:41:49.590349
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == "."
    assert cpf[7] == "."
    assert cpf[11] == "-"

    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == "."
    assert cnpj[6] == "."
    assert cnpj[10] == "/"
    assert cnpj[15] == "-"

# Generated at 2022-06-23 20:41:54.557063
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    br_provider = BrazilSpecProvider()
    assert br_provider.cpf(with_mask=True) == '988.624.236-44'
    assert br_provider.cpf(with_mask=False) == '98862423644'



# Generated at 2022-06-23 20:42:03.546602
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()

    #mask param is defaulted to True, to test if the mask is applied
    result = brazil.cnpj()
    assert(len(result) == 18)
    assert(result[2] == '.')
    assert(result[6] == '.')
    assert(result[10] == '/')
    assert(result[15] == '-')

    #mask param is set to false, to test if mask is not applied
    result = brazil.cnpj(False)
    assert(len(result) == 14)
    assert(result[2] != '.')
    assert(result[6] != '.')
    assert(result[10] != '/')
    assert(result[15] != '-')

# Generated at 2022-06-23 20:42:10.291530
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj.count('-') == 1
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    first_part = cnpj[:12]
    second_part = cnpj[13:]
    assert first_part.isdigit()
    assert second_part.isdigit()


# Generated at 2022-06-23 20:42:14.348548
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    cpf = BrazilSpecProvider().cpf()

    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:42:20.537850
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf().replace(".", "")) == 11
    assert len(brazil.cpf(with_mask=False).replace(".", "")) == 9
    assert brazil.cpf(with_mask=False).isdigit() == True
    assert brazil.cpf(with_mask=False).isalnum() == True


# Generated at 2022-06-23 20:42:22.910695
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert len(brazil_provider.cpf()) == 14
    assert len(brazil_provider.cnpj()) == 18

# Generated at 2022-06-23 20:42:25.731732
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() != provider.cnpj()


# Generated at 2022-06-23 20:42:32.630616
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.localization import set_locale
    from mimesis.providers.brazil.brazil import BrazilSpecProvider

    set_locale('pt-br')
    brazil = BrazilSpecProvider()

    # Changing seed with random int from randint
    seed = BrazilSpecProvider.__randint__(0, 100)
    brazil.seed(seed)
    assert brazil.cnpj() == '78.863.782/0001-06'

    set_locale(None)

# Generated at 2022-06-23 20:42:34.186184
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '012.967.816-08'


# Generated at 2022-06-23 20:42:36.870604
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == '191.631.813-72'
    assert bsp.cpf() != '191.631.813-72'


# Generated at 2022-06-23 20:42:38.060313
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cnpj()

# Generated at 2022-06-23 20:42:42.769256
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    brazil_cnpjs = []
    for _ in range(10):
        cnpj = provider.cnpj()
        assert len(cnpj) == 18
        brazil_cnpjs.append(cnpj)
    assert len(set(brazil_cnpjs)) == 10

# Generated at 2022-06-23 20:42:44.623043
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() != provider.cpf()


# Generated at 2022-06-23 20:42:52.920050
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    mask = "###.###.###-##"
    assert len(provider.cpf()) == 11
    assert len(provider.cpf(False)) == 9
    assert len(provider.cpf(True)) == len(mask)
    assert provider.cpf(True).replace('.', '').replace('-', '').isdigit()
    assert provider.cpf(False).isdigit()


# Generated at 2022-06-23 20:43:00.435145
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        elif peso == 6:
            peso_list = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        for i, _ in enumerate(cnpj):
            soma += peso_

# Generated at 2022-06-23 20:43:04.462156
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('\nTest for constructor of class BrazilSpecProvider')
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider)


# Generated at 2022-06-23 20:43:06.327118
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    
    assert BrazilSpecProvider.cpf() == "001.137.297-40"


# Generated at 2022-06-23 20:43:10.682436
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    seed = "c9d9b921-eb70-4fea-a81c-d89d6db1b8bd"
    provider = BrazilSpecProvider(seed=seed)
    assert provider.cpf() == '004.373.448-42'
    assert provider.cnpj() == '37.932.879/0001-32'

# Generated at 2022-06-23 20:43:13.008393
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '771.817.438-31'


# Generated at 2022-06-23 20:43:17.515215
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    b = BrazilSpecProvider()
    # print(b.cpf(with_mask = True))
    # print(b.cpf(with_mask = False))
    assert len(b.cpf(with_mask = True)) == 14
    assert len(b.cpf(with_mask = False)) == 11


# Generated at 2022-06-23 20:43:25.350153
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender

    bsp = BrazilSpecProvider()
    for i in range(1000):
        with_mask = not i % 2
        cnpj = bsp.cnpj(with_mask)
        assert '-' in cnpj or not with_mask
        assert '.' in cnpj or not with_mask
        assert len(cnpj) == 14 or not with_mask
        assert len(cnpj) == 18 or with_mask


# Generated at 2022-06-23 20:43:28.574404
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method for BrazilSpecProvider"""
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() is not None
    assert brazil_provider.cpf(with_mask=False) is not None


# Generated at 2022-06-23 20:43:29.574206
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print(BrazilSpecProvider().cnpj())

# Generated at 2022-06-23 20:43:31.862661
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=False)


# Generated at 2022-06-23 20:43:33.064098
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Constructor of class BrazilSpecProvider
    BrazilSpecProvider(seed=None)

# Generated at 2022-06-23 20:43:34.520416
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider.cnpj()) == 18



# Generated at 2022-06-23 20:43:36.435218
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-23 20:43:38.897321
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brasil = BrazilSpecProvider()

    assert brasil._data['cpf'][0] == '001.137.297-40'

# Generated at 2022-06-23 20:43:41.632661
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
	test_provider = BrazilSpecProvider(seed=None)
	print(test_provider.cpf())

# Generated at 2022-06-23 20:43:44.303711
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result = provider.cnpj(with_mask=False)
    assert len(result) == 14

# Generated at 2022-06-23 20:43:50.858645
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of class BrazilSpecProvider"""
    test_seed = "test_BrazilSpecProvider"
    test_BrazilSpecProvider = BrazilSpecProvider(seed=test_seed)

    assert test_BrazilSpecProvider, "Error: BrazilSpecProvider not created"
    assert test_BrazilSpecProvider.Meta.name == "brazil_provider",\
        "Error: BrazilSpecProvider has not name brazil_provider"
    assert test_BrazilSpecProvider.Meta.locale == "pt-br",\
        "Error: BrazilSpecProvider has not locale pt-br"


# Generated at 2022-06-23 20:43:52.859172
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf()) == 14


# Generated at 2022-06-23 20:43:54.441818
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() != ''


# Generated at 2022-06-23 20:43:59.240596
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == "639.280.888-27"
    assert BrazilSpecProvider().cpf() == "382.938.944-59"
    assert BrazilSpecProvider().cpf() == "308.828.715-71"
    assert BrazilSpecProvider().cpf() == "997.768.562-96"
    assert BrazilSpecProvider().cpf() == "902.896.248-15"


# Generated at 2022-06-23 20:44:06.519890
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    test_data = brazil_provider.cpf()
    assert len(test_data) == 14
    brazil_provider = BrazilSpecProvider()
    test_data = brazil_provider.cpf(with_mask=False)
    assert len(test_data) == 11
    brazil_provider = BrazilSpecProvider()
    test_data = brazil_provider.cnpj()
    assert len(test_data) == 18
    brazil_provider = BrazilSpecProvider()
    test_data = brazil_provider.cnpj(with_mask=False)
    assert len(test_data) == 14

# Generated at 2022-06-23 20:44:14.047276
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    from . import BrazilSpecProvider

    bsp = BrazilSpecProvider()
    p = Person('pt-br')

    cpf = BrazilSpecProvider.cpf(bsp, with_mask=False)

    # CPF should have 11 digits
    assert len(cpf) == 11

    # CPF should be all numbers
    assert cpf.isnumeric()

    # Let's do some math to check the CPF digit validity
    # First digit
    # The first digit is calculated based on the adding of first nine digits
    # multiplied by the weight
    # weight = [10, 9, 8, 7, 6, 5, 4, 3, 2]
    # and the result is divided by 11
    # Ex.: 123456789 * 10 + 12345

# Generated at 2022-06-23 20:44:23.665400
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test whether cnpj method of class BrazilSpecProvider returns a valid cnpj."""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj[-2:] == str(prv.get_verifying_digit_cnpj(list(map(int, cnpj[:-2])), 5))
    assert cnpj[-1:] == str(prv.get_verifying_digit_cnpj(list(map(int, cnpj[:-1])), 6))


# Generated at 2022-06-23 20:44:26.063355
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()

    assert cpf == '333.778.076-85'


# Generated at 2022-06-23 20:44:30.045377
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider_cpf"""
    brazilSpecProvider = BrazilSpecProvider()
    cpf0 = brazilSpecProvider.cpf(with_mask=True)
    assert len(cpf0) == 14
    cpf1 = brazilSpecProvider.cpf(with_mask=False)
    assert len(cpf1) == 11
    print("cpf0: {}, cpf1: {}", cpf0, cpf1)


# Generated at 2022-06-23 20:44:33.111350
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() != ''
    assert provider.cnpj() != ''

# Generated at 2022-06-23 20:44:35.347232
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
   bsp = BrazilSpecProvider()
   assert bsp


# Generated at 2022-06-23 20:44:36.402069
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider()

# Generated at 2022-06-23 20:44:38.954178
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilspecprovider = BrazilSpecProvider()
    print(brazilspecprovider)

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:44:40.768302
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()
    BrazilSpecProvider(seed=1)


# Generated at 2022-06-23 20:44:45.833916
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert result
    assert len(result) == 14
    assert result[3] == '.'
    assert result[7] == '.'
    assert result[11] == '-'


# Generated at 2022-06-23 20:44:47.413363
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-23 20:44:51.326017
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test function cnpj of class BrazilSpecProvider."""

    cnpj = BrazilSpecProvider().cnpj(with_mask=True)
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:44:59.188745
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider."""
    from . import BrazilSpecProvider

    cnpj_masked = BrazilSpecProvider().cnpj(with_mask=True)
    cnpj_unmasked = BrazilSpecProvider().cnpj(with_mask=False)
    assert cnpj_masked.count('.') == 2
    assert cnpj_masked.count('/') == 1
    assert cnpj_masked.count('-') == 1
    assert cnpj_masked.count('-') == 1
    assert cnpj_unmasked.count('.') == 0
    assert cnpj_unmasked.count('/') == 0
    assert cnpj_unmasked.count('-') == 0
    assert len(cnpj_unmasked) == 14


# Generated at 2022-06-23 20:45:03.790274
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Initialize BrazilSpecProvider
    brazil = BrazilSpecProvider()

    # Return a random cnpj without mask
    print(brazil.cnpj(with_mask=False))

    # Return a random cnpj whit mask
    print(brazil.cnpj(with_mask=True))


# Generated at 2022-06-23 20:45:10.953107
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class ``BrazilSpecProvider``."""
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.providers.brazil.cpf_cnpj import CNPJ

    # Seed random number generator to deterministic value
    # Make sure to use the same value here and in cnpj() method
    # to get a valid number
    rand_seed = 1599747049
    rand_gen = BrazilSpecProvider(seed=rand_seed)

    assert isinstance(rand_gen.cnpj(with_mask=False), str)
    assert len(rand_gen.cnpj(with_mask=False)) == 14
    assert rand_gen.cnpj(with_mask=False) == '07317230000176'


# Generated at 2022-06-23 20:45:14.838569
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_BrazilSpecProvider = BrazilSpecProvider('12345')
    assert test_BrazilSpecProvider.cpf().__len__() == 14
    assert test_BrazilSpecProvider.cnpj().__len__() == 18
    
test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:15.685426
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider is not None

# Generated at 2022-06-23 20:45:23.536686
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    expected_results = [
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70'
    ]
    for i in range(0, len(expected_results)):
        seed_value = i
        result = BrazilSpecProvider(seed=seed_value).cnpj()
        assert result == expected_results[i]


# Generated at 2022-06-23 20:45:26.935707
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpfs = set()
    for _ in range(1000):
        cpf = BrazilSpecProvider().cpf()
        assert isinstance(cpf, str)
        assert len(cpf) == 14
        assert cpf not in cpfs



# Generated at 2022-06-23 20:45:29.237378
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = '12'
    cpf = BrazilSpecProvider(seed)
    assert cpf.cpf(with_mask=False) == '00113729740'


# Generated at 2022-06-23 20:45:30.869936
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    print(cpf)


# Generated at 2022-06-23 20:45:32.834640
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf) == 11


# Generated at 2022-06-23 20:45:36.606222
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider(seed=1234567)
    assert bp.cpf() == '028.904.942-52'
    assert bp.cpf(with_mask=False) == '02890944252'



# Generated at 2022-06-23 20:45:38.989208
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    print(brazil.cpf())
    print(brazil.cpf(with_mask = False))


# Generated at 2022-06-23 20:45:42.994233
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of BrazilSpecProvider."""
    br = BrazilSpecProvider()
    assert br.Meta.name == "brazil_provider"

# Unit tests for method cpf of class BrazilSpecProvider

# Generated at 2022-06-23 20:45:45.433063
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()

    assert len(cnpj) == 18

# Generated at 2022-06-23 20:45:47.710022
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()

# Generated at 2022-06-23 20:45:50.715539
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj."""
    provider = BrazilSpecProvider(seed=123456)
    assert provider.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-23 20:45:55.928592
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '096.425.003-16'
    cpf = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf == (cpf[:3] + cpf[4:7] + cpf[8:11])


# Generated at 2022-06-23 20:45:59.868648
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    class_name = 'BrazilSpecProvider'
    try:
        bsp = BrazilSpecProvider()
        print(f'\nConstructor of class {class_name} is OK')
    except:
        print(f'\nConstructor of class {class_name} is failed')


# Generated at 2022-06-23 20:46:04.620535
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pt-br', seed=12345)
    assert p.cpf(Gender.MALE) == '301.706.960-49'
    assert p.cpf(Gender.FEMALE) == '646.096.420-85'
    assert p.cpf() == '085.711.530-37'

# Generated at 2022-06-23 20:46:05.847419
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=123)

# Generated at 2022-06-23 20:46:07.202263
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider


# Generated at 2022-06-23 20:46:10.733064
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14     # 3+1+3+1+3+1+2
    assert cpf.count('.') == 3
    assert cpf.count('-') == 1
    assert int(cpf[0]) != 0    # At least one digit at the beginning cannot be zero


# Generated at 2022-06-23 20:46:19.074758
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj()."""
    # The names are consistent with the Brazilian document specification.
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    # The CNPJ has 14 characters (2 digits from the company + 4 digits from
    # the company's branch + 2 digits from the company's state number +
    # 6 digits from the serial number + 2 verification digits),
    # in the format of 8 - 4 - 2 - 6 - 2.
    assert len(cnpj) == 18



# Generated at 2022-06-23 20:46:21.266573
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    gen = BrazilSpecProvider()
    cpf = gen.cpf()

    assert len(cpf) == 14
    assert cpf[3] == cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:46:26.745903
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider(seed=42)
    assert(a.cpf(with_mask=True) == '813.313.906-60')
    assert(a.cpf(with_mask=False) == '81331390660')
    assert(a.cnpj(with_mask=True) == '62.643.439/0001-59')
    assert(a.cnpj(with_mask=False) == '62643449000159')
    assert(a.cnpj() == '62.643.439/0001-59')
    assert(a.cpf() == '813.313.906-60')

# Generated at 2022-06-23 20:46:30.405198
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=12345)
    assert bsp.cnpj() == '77.732.230/0001-70'
    assert bsp.cnpj(with_mask=False) == '77732230000170'


# Generated at 2022-06-23 20:46:34.457723
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert(provider.cpf().__class__ == str)
    assert(provider.cnpj().__class__ == str)

# Unit Test for function cpf of class BrazilSpecProvider

# Generated at 2022-06-23 20:46:35.127845
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:46:43.861242
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    # test method cpf()
    assert (bsp.cpf() == '082.801.043-64')
    assert (bsp.cpf(True) == '082.801.043-64')
    assert (bsp.cpf(False) == '08280104364')

    # test method cnpj()
    assert (bsp.cnpj() == '56.412.518/0001-45')
    assert (bsp.cnpj(True) == '56.412.518/0001-45')
    assert (bsp.cnpj(False) == '56412518000145')

# Generated at 2022-06-23 20:46:45.810621
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11


# Generated at 2022-06-23 20:46:49.462686
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    expected_output = "77.732.230/0001-70" # statically generated CNPJ number (random)
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == expected_output

# Generated at 2022-06-23 20:46:55.865974
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf_result = provider.cpf(with_mask=True)
    assert cpf_result is not None
    assert len(cpf_result) == 14
    assert isinstance(cpf_result, str)
    assert cpf_result[3] == '.'
    assert cpf_result[7] == '.'
    assert cpf_result[11] == '-'


# Generated at 2022-06-23 20:46:59.687037
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:47:06.386836
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for method cpf of class BrazilSpecProvider."""
    sp = BrazilSpecProvider()
    assert len(sp.cpf()) == 14
    assert len(sp.cpf(with_mask=False)) == 11
    assert '-' in sp.cpf()
    assert '-' not in sp.cpf(with_mask=False)
    assert '.' in sp.cpf()
    assert '.' not in sp.cpf(with_mask=False)
    assert sp.cpf().isdigit() == False
    assert sp.cpf(with_mask=False).isdigit() == True
    assert ' ' not in sp.cpf()
    assert ' ' not in sp.cpf(with_mask=False)
    assert sp.cpf().isalnum() == True

# Generated at 2022-06-23 20:47:14.610626
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.data import PROVIDERS
    from mimesis.enums import Gender

    import re

    pt_provider = BrazilSpecProvider()
    for i in range(1000):
        cnpj = pt_provider.cnpj()

    assert bool(re.match(r'[0-9]{2}[.][0-9]{3}[.][0-9]{3}[/][0-9]{4}[-][0-9]{2}', cnpj)) == True
    assert bool(re.match(r'\A[1-9]\d{11}\Z', cnpj.replace('.', '').replace('-', '').replace('/', ''))) == True