

# Generated at 2022-06-23 20:37:18.425851
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # TEST: random.seed(0)
    provider = BrazilSpecProvider(seed=0)

#     assert provider.cnpj(with_mask=False) == '57239332000110'
#     assert provider.cnpj(with_mask=True) == '57.239.332/0001-10'

# # Unit test for method cpf of class BrazilSpecProvider
# def test_BrazilSpecProvider_cpf():
#     # TEST: random.seed(0)
#     provider = BrazilSpecProvider(seed=0)

#     assert provider.cpf(with_mask=False) == '00113729740'
#     assert provider.cpf(with_mask=True) == '001.137.297-40'

# Generated at 2022-06-23 20:37:21.621668
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider('teste')
    cnpj = b.cnpj(False)
    print(cnpj)
    print(len(cnpj))


# Generated at 2022-06-23 20:37:23.452920
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    bsp.cpf()
    bsp.cnpj()

# Generated at 2022-06-23 20:37:28.567179
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test case for BrazilSpecProvider::cnpj
    """
    
    from mimesis.builtins import BrazilSpecProvider as bsp
    
    b = bsp()
    cnpj = b.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-23 20:37:33.011222
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=1)
    cnpj = bsp.cnpj()
    assert cnpj == '77.732.230/0001-70'
    cnpj = bsp.cnpj(with_mask=False)
    assert cnpj == '77732.23000170'


# Generated at 2022-06-23 20:37:37.173508
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    expected_value = '77.732.230/0001-70'
    returned_value = BrazilSpecProvider().cnpj()
    assert returned_value == expected_value


# Generated at 2022-06-23 20:37:38.023155
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert isinstance(obj, BrazilSpecProvider)


# Generated at 2022-06-23 20:37:42.140352
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    adelaide = BrazilSpecProvider()
    cnpj = '17.563.835/0001-70'
    assert adelaide.cnpj(with_mask=False) == cnpj
    assert adelaide.cnpj(with_mask=True) == cnpj


# Generated at 2022-06-23 20:37:45.119362
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider class."""
    provider = BrazilSpecProvider(seed=12345)

    print(provider.cpf())
    print(provider.cnpj())
    print(provider.cnpj_masked())
    print(provider.cpf_masked())

# Generated at 2022-06-23 20:37:47.301437
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """unit test for method cnpj of class BrazilSpecProvider"""
    assert BrazilSpecProvider().cnpj().count('.') == 2


# Generated at 2022-06-23 20:37:48.986740
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert(BrazilSpecProvider().cpf() == '000.000.000-00')



# Generated at 2022-06-23 20:37:52.717209
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    # method cpf
    assert len(brazil.cpf(with_mask=False)) == 11
    # method cnpj
    assert len(brazil.cnpj(with_mask=False)) == 14

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:38:01.314706
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    #
    # 1. Generate a random Brazilian CNPJ with mask
    #
    print("Case 1. Generate a random Brazilian CNPJ with mask")
    br_provider = BrazilSpecProvider()
    cnpj = br_provider.cnpj(with_mask=True)
    print(f"CNPJ: {cnpj}")

    #
    # 2. Generate a random Brazilian CNPJ without mask
    #
    print("\nCase 2. Generate a random Brazilian CNPJ without mask")
    br_provider = BrazilSpecProvider()
    cnpj = br_provider.cnpj(with_mask=False)
    print(f"CNPJ: {cnpj}")

# Generated at 2022-06-23 20:38:06.385670
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    br = BrazilSpecProvider()
    # Get a random CPF (with mask)
    cpf = br.cpf()
    assert type(cpf) == str
    # Get a random CPF (without mask)
    cpf = br.cpf(with_mask=False)
    assert type(cpf) == str


# Generated at 2022-06-23 20:38:09.837193
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    brazil = BrazilSpecProvider()

    for i in range(10):
        cnpj = brazil.cnpj(with_mask=False)
        assert cnpj.isnumeric() == True
        assert len(cnpj) == 14


# Generated at 2022-06-23 20:38:11.002932
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print(BrazilSpecProvider().cpf())
    

# Generated at 2022-06-23 20:38:13.672926
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Constructor test for class BrazilSpecProvider.
    """
    print('Test for initialization of BrazilSpecProvider')
    brazilSpecProvider = BrazilSpecProvider()
    assert isinstance(brazilSpecProvider, BrazilSpecProvider)


# Generated at 2022-06-23 20:38:16.795443
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print(cnpj)
    assert cnpj == '77.732.230/0001-70'

test_BrazilSpecProvider_cnpj()


# Generated at 2022-06-23 20:38:18.250531
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    seed = bsp.get_seed()
    res = bsp.cnpj(seed)
    return res

# Generated at 2022-06-23 20:38:20.024062
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    print(b.cpf())

# Generated at 2022-06-23 20:38:25.204094
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider()
    # Test for method cpf
    print(instance.cpf(with_mask=False))
    # Test for method cnpj
    print(instance.cnpj(with_mask=False))
if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:38:27.546179
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert(BrazilSpecProvider.Meta.name == 'brazil_provider')
    assert(BrazilSpecProvider().Meta.name == 'brazil_provider')


# Generated at 2022-06-23 20:38:29.066324
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider()
    print(cpf.cpf())


# Generated at 2022-06-23 20:38:30.679297
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cnpj())

# Generated at 2022-06-23 20:38:31.506781
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() != None


# Generated at 2022-06-23 20:38:33.979803
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.specifiers.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    print(provider.cpf())


# Generated at 2022-06-23 20:38:38.800390
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    a = BrazilSpecProvider()
    assert(len(a.cpf(with_mask=False)) == 11)
    assert(len(a.cpf(with_mask=True)) == 14)



# Generated at 2022-06-23 20:38:39.387243
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:38:43.457719
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Given
    bsp = BrazilSpecProvider(seed=42)

    # When
    cnpj = bsp.cnpj(with_mask=True)
    expected = '38.851.780/0001-59'

    # Then
    assert cnpj == expected

# Generated at 2022-06-23 20:38:53.739765
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for BrazilSpecProvider.cpf()"""
    
    # Test case:
    #   calling cpf() should return a string
    tested_case = '''Test case:
    calling cpf() should return a string
    '''
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf(True)
    assert isinstance(cpf, str)
    
    # Test case:
    #   calling cpf() should retrun a string with 11 characters.
    tested_case = '''Test case:
    calling cpf() should retrun a string with 11 characters.
    '''
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf(True)
    assert len(cpf) == 14
    
    # Test case:


# Generated at 2022-06-23 20:38:54.553330
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
   assert BrazilSpecProvider


# Generated at 2022-06-23 20:38:56.825861
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
	br_spec_provider = BrazilSpecProvider()
	assert (br_spec_provider.cnpj(with_mask = False) == br_spec_provider.cnpj(with_mask = False))


# Generated at 2022-06-23 20:39:07.220611
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14
    # Check if the cpf is valid
    cpf_num = BrazilSpecProvider().cpf(with_mask=False)
    cpf_list = list(map(int, cpf_num))[:-2]

    def get_verifying_digit_cpf(cpf, peso):
        """Calculate the verifying digit for the CPF."""
        soma = 0
        for index, digit in enumerate(cpf):
            soma += digit * (peso - index)
        resto = soma % 11
        if resto == 0 or resto == 1 or resto >= 11:
            return 0
        return 11 - resto

    first_dv = get_verifying_digit_cpf(cpf_list, 10)
    cpf_list

# Generated at 2022-06-23 20:39:15.539692
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.brazil import BrazilSpecProvider

    # Test for BrazilSpecProvider
    bp = BrazilSpecProvider()

    # Test for the length of CNPJ which is 14 characters
    # Test for the format of CNPJ
    value = '14.851.068/0001-67'
    assert bp.cnpj(True) == value
    # Test for the format of CNPJ without mask
    assert bp.cnpj() == value.replace('.','').replace('/','').replace('-','')


# Generated at 2022-06-23 20:39:21.538547
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf_1 = brazil.cpf()
    cpf_2 = brazil.cpf(with_mask=False)
    if len(cpf_1) != 14:
        assert False
    for i in cpf_1:
        if not i in '1234567890.-':
            assert False
    for i in cpf_2:
        if not i in '1234567890':
            assert False
    assert True


# Generated at 2022-06-23 20:39:23.644407
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1

# Generated at 2022-06-23 20:39:30.237644
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def assertraises(e, a, b):
        try:
            a.assertRaises(e)
        except:
            b()

    from mimesis.enums import ErrorCode
    from mimesis.exceptions import NonEnumerableError
    from mimesis.builtins import BrazilSpecProvider
    bsp = BrazilSpecProvider('pt-br')

    assertraises(NonEnumerableError(ErrorCode.NON_ITERABLE_DATA),Exception,
        bsp.cnpj('a'))


# Generated at 2022-06-23 20:39:32.789611
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    assert BrazilSpecProvider() is not None

# Generated at 2022-06-23 20:39:41.539004
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_with_mask = BrazilSpecProvider().cnpj(with_mask=True)
    assert len(cnpj_with_mask) == 18
    assert cnpj_with_mask[2] == "."
    assert cnpj_with_mask[6] == "."
    assert cnpj_with_mask[10] == "/"
    assert cnpj_with_mask[15] == "-"
    assert cnpj_with_mask.replace(".","").replace("/","").replace("-","").isnumeric()

    cnpj_without_mask = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(cnpj_without_mask) == 14

# Generated at 2022-06-23 20:39:46.168131
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider_cpf method."""
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf.isdigit() == False
    assert cpf[3:4] == '.'
    assert cpf[7:8] == '.'
    assert cpf[11:12] == '-'


# Generated at 2022-06-23 20:39:48.950888
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    assert br.cpf() == br.cpf(with_mask=True)
    assert len(br.cpf(with_mask=True)) == 14
    assert len(br.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:39:51.812593
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('\nTesting method cpf of class BrazilSpecProvider')
    print('> ', BrazilSpecProvider().cpf())
    print('> ', BrazilSpecProvider().cpf(False))


# Generated at 2022-06-23 20:39:52.423775
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:39:54.524888
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    result = b.cnpj()
    print(result)
    assert isinstance(result, str)


# Generated at 2022-06-23 20:39:55.822263
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    b = BrazilSpecProvider(seed=1234)

# Generated at 2022-06-23 20:39:59.135126
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    c = brazil.cpf()
    print(c)
    c = brazil.cnpj()
    print(c)


# Generated at 2022-06-23 20:39:59.704128
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()

# Generated at 2022-06-23 20:40:02.756899
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()

    assert brazil.cnpj() == '77.732.230/0001-70'
    assert brazil.cnpj(with_mask=False) == '77732230000170'


# Generated at 2022-06-23 20:40:04.659222
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    teste = provider.cpf()
    assert teste != provider.cpf()


# Generated at 2022-06-23 20:40:06.440833
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    spec = BrazilSpecProvider()
    assert hasattr(spec, 'cpf')
    assert hasattr(spec, 'cnpj')


# Generated at 2022-06-23 20:40:09.528305
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.builtins.providers.brazil import BrazilSpecProvider
    import random
    import sys
    brazil = BrazilSpecProvider(random)
    print(brazil.cpf(), brazil.cnpj())


# Generated at 2022-06-23 20:40:13.928178
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br_provider = BrazilSpecProvider()

    cpf_0 = br_provider.cpf()
    assert cpf_0
    assert len(cpf_0) == 14
    assert cpf_0[3] == '.'
    assert cpf_0[7] == '.'
    assert cpf_0[11] == '-'


    cpf_1 = br_provider.cpf(with_mask=False)
    assert cpf_1
    assert len(cpf_1) == 11
    assert not cpf_1[3] == '.'
    assert not cpf_1[7] == '.'
    assert not cpf_1[11] == '-'

# Generated at 2022-06-23 20:40:18.535857
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()

    # test for CPF
    cpf = brazil.cpf()
    print(cpf)
    assert len(cpf) == 14

    # test for CNPJ
    cnpj = brazil.cnpj()
    print(cnpj)
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:40:22.794740
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_cnpj = BrazilSpecProvider().cnpj()
    print(test_cnpj)

    if test_cnpj == '24.395.850/0001-43':
        return {'test_cnpj': True}
    else:
        return False



# Generated at 2022-06-23 20:40:24.719629
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test function BrazilSpecProvider.cpf()"""
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14 or len(cpf) == 11
    assert cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-'


# Generated at 2022-06-23 20:40:25.598443
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    n = BrazilSpecProvider()
    print(n.cnpj())

# Generated at 2022-06-23 20:40:30.918005
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    with_mask = provider.cpf(with_mask=True)

    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert len(with_mask) == 14
    assert len(cpf) == 11


# Generated at 2022-06-23 20:40:34.397153
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    b.seed = 1
    b.random.seed(0)
    print(b.cpf(True))
    print(b.cnpj(True))
    print("Ending unit test for BrazilSpecProvider")

# Generated at 2022-06-23 20:40:41.797513
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    
    from mimesis.enums import Gender
    from mimesis.providers import BrazilSpecProvider
    from mimesis.providers.person import Person


    #instanciando a classe
    p = BrazilSpecProvider()
    #instanciando a classe Person
    person = Person('pt_BR')
    
    #Modo de Uso
    #print(p.cpf())
    
    #Modo de testar
    assert p.cpf(with_mask=None)
    assert p.cpf(with_mask=True)
    assert len(p.cpf()) == 11
    assert len(p.cpf(with_mask=True)) == 14
    assert type(p.cpf())==str
    

# Generated at 2022-06-23 20:40:44.626355
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider()
    assert isinstance(cpf.cpf(), str)
    assert len(cpf.cpf()) == 14

test_BrazilSpecProvider_cpf()


# Generated at 2022-06-23 20:40:47.124339
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    c = b.cnpj()
    assert len(c) == 18


# Generated at 2022-06-23 20:40:58.155333
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    def test_cpf_is_valid(cpf): # test wheter given CPF is valid according to the algorithm for CPF
        first_verif_digit = 0
        second_verif_digit = 0

        def first_verif_digit_calc(cpf):
            i = 0
            sum = 0
            while i < 9:
                sum += int(cpf[i]) * (10 - i)
                i += 1
            if (sum % 11) < 2:
                return 0
            return 11 - (sum % 11)

        def second_verif_digit_calc(cpf):
            i = 0
            sum = 0
            while i < 10:
                sum += int(cpf[i]) * (11 - i)
                i += 1
            if (sum % 11) < 2:
                return

# Generated at 2022-06-23 20:40:59.704426
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider
    assert type(bsp) == type



# Generated at 2022-06-23 20:41:02.013725
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider class."""
    # testing BrazilSpecProvider class
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == "54.936.395/0002-01"



# Generated at 2022-06-23 20:41:05.513497
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    cnpj_ok = cnpj[:2] + cnpj[3] + cnpj[4] + cnpj[6] + cnpj[7] + \
              cnpj[9] + cnpj[10] + cnpj[12] + cnpj[13]
    assert sum([int(cnpj_ok[i]) * (6 - i) for i in range(8)]) % 11 == 0
    assert sum([int(cnpj_ok[i]) * (7 - i) for i in range(8, 12)]) % 11 == 0


# Generated at 2022-06-23 20:41:08.380654
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider class constructor."""
    provider = BrazilSpecProvider()
    assert provider.__class__.__name__ == 'BrazilSpecProvider'



# Generated at 2022-06-23 20:41:19.540707
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    brazil = BrazilSpecProvider(seed=123)
    # All digits are the same
    assert brazil.cpf() == '111.111.111-11'
    # But, for more security, all digits are not the same
    assert brazil.cpf(with_mask=False) != '111.111.111-11'
    # A real CPF
    assert brazil.cpf() == '001.137.297-40'
    # A male CPF
    assert brazil.cpf(gender=Gender.MALE) == '117.435.926-70'
    # A female CPF
    assert brazil.cpf(gender=Gender.FEMALE) == '660.919.931-02'


# Generated at 2022-06-23 20:41:22.833338
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj(False) == '7773223000170'
    assert provider.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-23 20:41:25.275886
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()
    assert bp.cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:41:27.667268
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
	test = BrazilSpecProvider()
	print(test.cpf())
	print(test.cnpj())

# Generated at 2022-06-23 20:41:32.515237
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of the BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert bsp.cpf(True) is not None
    assert bsp.cnpj(True) is not None
    assert bsp.cpf(False) is not None
    assert bsp.cnpj(False) is not None

# Generated at 2022-06-23 20:41:34.440956
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider"""
    brazil = BrazilSpecProvider()
    assert brazil.cpf()
    assert brazil.cnpj()

# Generated at 2022-06-23 20:41:41.289230
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    prov = BrazilSpecProvider()
    cpf = prov.cpf()
    cnpj = prov.cnpj()

    assert len(cpf) == 14
    assert len(cnpj) == 18

    assert prov.cpf(with_mask=False) == cpf.replace('.', '').replace('-', '')
    assert prov.cnpj(with_mask=False) == cnpj.replace('.', '').replace('/', '').replace('-', '')


# Generated at 2022-06-23 20:41:41.837132
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:41:42.872725
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    for i in range(1):
        print(BrazilSpecProvider().cpf())

# Generated at 2022-06-23 20:41:43.885117
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """The test class for BrazilSpecProvider."""
    pass

# Generated at 2022-06-23 20:41:48.814385
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf.count('-') == 1
    assert cpf.count('.') == 2
    assert cpf.replace('-', '').replace('.', '').isdigit()



# Generated at 2022-06-23 20:41:52.525102
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    cpf_provider = BrazilSpecProvider()

    print(cpf_provider.cpf())
    #cpf_provider.cpf(gender=Gender.FEMALE)


# Generated at 2022-06-23 20:41:56.155373
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=872)
    assert provider.cnpj() == '77.732.230/0001-70'
    assert provider.cnpj(with_mask=False) == '77732250000170'


# Generated at 2022-06-23 20:42:01.937414
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method from BrazilSpecProvider class."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    print('Test BrazilSpecProvider - cnpj')
    seed = 4
    locale = 'pt-br'
    gender = Gender.FEMALE
    brazil_person = Person(locale=locale, gender=gender, seed=seed)
    print(brazil_person.cnpj())



# Generated at 2022-06-23 20:42:05.881752
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """
    Tests for the constructor __init__() of the class BrazilSpecProvider.
        
        Parameters:
            None.

        Returns:
            None.

        Raises:
            None.
    """
    # Case 1:
    brazil_provider = BrazilSpecProvider()

    assert brazil_provider is not None
    assert brazil_provider.locale == 'pt-br'


# Generated at 2022-06-23 20:42:06.857041
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    sbp = BrazilSpecProvider()
    assert len(sbp.cpf()) == 14
    assert len(sbp.cnpj()) == 18

# Generated at 2022-06-23 20:42:07.712514
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    return BrazilSpecProvider(None)

# Generated at 2022-06-23 20:42:10.734644
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() != brazil_provider.cpf()
    assert brazil_provider.cnpj() != brazil_provider.cnpj()

# Generated at 2022-06-23 20:42:14.385133
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj(with_mask=True)
    assert cnpj == '77.732.230/0001-70'

# Generated at 2022-06-23 20:42:19.742750
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.reset_seed()
    
    # Test with_mask = False (default)
    assert b.cnpj() == '22032277000166'

    # Test with_mask = True
    assert b.cnpj(True) == '22.032.277/0001-66'

    # Test same value generated with same seed
    b.reset_seed('1')
    assert b.cnpj() == '75297213000159'

    b.reset_seed('1')
    assert b.cnpj(True) == '75.297.213/0001-59'

    # Test same value generated with same seed set manually
    b.reset_seed('1')
    assert b.cnpj() == '75297213000159'

    b.reset_seed('1')

# Generated at 2022-06-23 20:42:23.141673
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpfs = []
    for _ in range(10000):
        cpf = BrazilSpecProvider().cpf()
        assert len(cpf) == 14
        cpfs.append(cpf)
    assert len(set(cpfs)) == 10000



# Generated at 2022-06-23 20:42:25.984008
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(100):
        c = BrazilSpecProvider()
        c.cpf()

# Generated at 2022-06-23 20:42:31.083802
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bp = BrazilSpecProvider()
    assert bp.cpf().__len__() == 14
    assert bp.cpf(with_mask=False).__len__() == 11
    assert bp.cnpj().__len__() == 18
    assert bp.cnpj(with_mask=False).__len__() == 14

# Generated at 2022-06-23 20:42:32.715180
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BRAZIL_SPEC_PROVIDER = BrazilSpecProvider()
    BRAZIL_SPEC_PROVIDER.cpf(False)

# Generated at 2022-06-23 20:42:38.847740
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    cnpj = p.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    cnpj_no_mask = p.cnpj(with_mask=False)
    assert isinstance(cnpj_no_mask, str)
    assert len(cnpj_no_mask) == 14


# Generated at 2022-06-23 20:42:42.055694
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
	BrazilSpecProvider_obj = BrazilSpecProvider()
	BrazilSpecProvider_cpf = BrazilSpecProvider_obj.cpf()
	assert BrazilSpecProvider_cpf == "011.890.107-44"

# Generated at 2022-06-23 20:42:43.597825
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().__class__.__name__ == 'BrazilSpecProvider'

# Generated at 2022-06-23 20:42:45.270764
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '792.149.862-34'


# Generated at 2022-06-23 20:42:55.746253
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Arrange
    from mimesis.enums import Gender

    person = BrazilSpecProvider()

    # Act
    name = person.full_name(gender=Gender.FEMALE)
    cpf = person.cpf()
    cnpj = person.cnpj()

    # Assert
    assert type(name) == str
    assert type(cpf) == str
    assert type(cnpj) == str
    assert len(name) > 0
    assert len(cpf) > 0
    assert len(cnpj) > 0
    print("Nome: " + name)
    print("CPF: " + cpf)
    print("CNPJ: " + cnpj)

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:43:04.172938
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    from mimesis.builtins.brazil import BrazilSpecProvider
    import re
    pattern = re.compile('[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}')

    obj = BrazilSpecProvider()
    cnpj = obj.cnpj()
    cnpj = cnpj = cnpj.split('-')
    cnpj = cnpj[0].split('/')
    cnpj = cnpj[0].split('.')
    cnpj = ''.join(cnpj)
    cnpj = cnpj + ''.join(obj.cnpj().split('-')[1])

   

# Generated at 2022-06-23 20:43:08.648535
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """CNPJ (Cadastro Nacional da Pessoa Jurídica) is the Brazilian
    company register.
    """
    assert BrazilSpecProvider.cnpj(with_mask=True)
    assert BrazilSpecProvider.cnpj(with_mask=False)


# Generated at 2022-06-23 20:43:13.303353
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert provider.cpf(with_mask=True).count('.') == 2


# Generated at 2022-06-23 20:43:17.176051
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    first_digit = int(cpf[0])
    assert first_digit != 0
    assert cpf[3] == "."
    assert cpf[7] == "."
    assert cpf[11] == "-"



# Generated at 2022-06-23 20:43:20.483697
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b1 = BrazilSpecProvider()
    b2 = BrazilSpecProvider()
    assert b1.cpf() != b2.cpf()


# Generated at 2022-06-23 20:43:29.656651
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    length = len(cnpj)
    assert(length == 18)

    cpf_as_number = [int(i) for i in cnpj if i.isdigit()]
    verifying_digit_expected = cpf_as_number[-2:]

    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0

# Generated at 2022-06-23 20:43:40.308955
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis import Person
    from mimesis.providers.base import BaseProvider

    brazilianProvider = BrazilSpecProvider(seed=1)
    person = Person(seed=1)
    person.set_locale('pt-br')


# Generated at 2022-06-23 20:43:49.320530
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    # Instance of BrazilSpecProvider
    print( 'BrazilSpecProvider(seed)')
    p = BrazilSpecProvider(seed="myseed")

    # Convert provider to string
    print( 'p => ' + str(p) )

    # Convert provider to string
    print( 'p.seed => ' + str(p.seed) )

    # Returns a random CPF
    # Example: 001.137.297-40
    print( 'p.cpf(with_mask=True) => ' + p.cpf(with_mask=True) )

    # Returns a random CNPJ
    # Example: 01.838.741/0001-02
    print( 'p.cnpj(with_mask=True) => ' + p.cnpj(with_mask=True) )


# Generated at 2022-06-23 20:43:58.862699
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Seed so that the result is always the same:
    # https://docs.python.org/3/library/random.html#random.seed
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.names import Name
    from mimesis.typing import Seed

    def test_each_digit_is_valid(cpf):
        """Each digit of a valid CPF must be between 0 and 9."""
        for digit in cpf:
            assert int(digit) in range(0, 10)

    def test_with_mask(cpf):
        assert len(cpf) == 14
        assert cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-'


# Generated at 2022-06-23 20:44:01.135605
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Verify if cpf works."""
    BSP = BrazilSpecProvider()
    assert isinstance(BSP.cpf(), str)
    assert len(BSP.cpf()) == 14


# Generated at 2022-06-23 20:44:02.538177
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider(seed=12).cnpj() == "77.732.230/0001-70"

# Generated at 2022-06-23 20:44:05.843742
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    prov = BrazilSpecProvider()
    cnpj = prov.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-23 20:44:08.054193
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for BrazilSpecProvider.cnpj."""
    provider = BrazilSpecProvider()
    result = provider.cnpj()
    print(result)
    assert len(result) == 18

# Generated at 2022-06-23 20:44:13.380466
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf == '144.912.335-04'
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert provider.cpf(with_mask=False) == '14491233504'


# Generated at 2022-06-23 20:44:17.680630
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '377.278.879-35'
    assert provider.cnpj() == '89.457.110/0001-05'

# Generated at 2022-06-23 20:44:20.797213
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cnpj() != provider.cnpj()
    assert provider.cpf() != provider.cpf()

# Generated at 2022-06-23 20:44:28.286170
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br_provider = BrazilSpecProvider()
    Cpf = br_provider.cpf()
    assert len(Cpf) == 14
    assert Cpf[3] == '.'
    assert Cpf[7] == '.'
    assert Cpf[11] == '-'

    Cnpj = br_provider.cnpj()
    assert len(Cnpj) == 18
    assert Cnpj[2] == '.'
    assert Cnpj[6] == '.'
    assert Cnpj[10] == '/'
    assert Cnpj[15] == '-'


# Generated at 2022-06-23 20:44:30.813291
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    b.cpf()
    b.cnpj()


# Generated at 2022-06-23 20:44:34.782043
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider()
    assert True == isinstance(cpf.cpf(True), str)
    assert False == isinstance(cpf.cpf(False), bool)
    

# Generated at 2022-06-23 20:44:38.598664
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    x = BrazilSpecProvider()
    y = x.cpf()
    assert re.match("\d{3}\.\d{3}\.\d{3}\-\d{2}", y)


# Generated at 2022-06-23 20:44:43.164007
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    result = BrazilSpecProvider().cnpj(with_mask=False)
    assert(type(result)==str)
    assert(len(result)==14)
    assert(result!='7773224000170')
    result = BrazilSpecProvider(seed=7773224000170).cnpj(with_mask=False)
    assert(result=='7773224000170')
    result = BrazilSpecProvider(seed=7773224000170).cnpj(with_mask=True)
    assert(result=='77.732.240/0001-70')


# Generated at 2022-06-23 20:44:46.279539
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    value = bsp.cnpj()
    assert value



# Generated at 2022-06-23 20:44:47.158287
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    b.cpf()


# Generated at 2022-06-23 20:44:48.815130
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-23 20:44:56.321598
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.datetime import Datetime
    # from random import seed
    # seed(1)
    datetime = Datetime()
    datetime.seed(1)
    provider = BrazilSpecProvider(datetime)
    test_cases = {
        'with_mask': True,
        'return_type': 'str',
        'return_value': '001.137.297-40'
    }

    cpf = provider.cpf(test_cases['with_mask'])
    assert isinstance(cpf, test_cases['return_type'])
    assert cpf == test_cases['return_value']


# Generated at 2022-06-23 20:45:01.163326
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    test_cpf = brazil_provider.cpf()
    #Check if output is a string
    assert isinstance(test_cpf, str)
    #Check if output has 11 characteres
    assert len(test_cpf) == 14


# Generated at 2022-06-23 20:45:06.081305
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider

    provider = BrazilSpecProvider()
    # provider = BrazilSpecProvider(seed='454545')
    print("provider.cpf()", provider.cpf())
    print("provider.cnpj()", provider.cnpj())

# Generated at 2022-06-23 20:45:09.403499
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brasil = BrazilSpecProvider()
    cpf = brasil.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:45:13.903315
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'

# Generated at 2022-06-23 20:45:23.622800
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    # Test a check digit.
    brazil_spec_provider = BrazilSpecProvider(seed=123)
    cpf = brazil_spec_provider.cpf()
    assert cpf == "515.942.427-93"

    # Test another check digit.
    brazil_spec_provider = BrazilSpecProvider(seed=321)
    cpf = brazil_spec_provider.cpf()
    assert cpf == "836.895.812-90"

    # Test with mask.
    brazil_spec_provider = BrazilSpecProvider(seed=123)
    cpf = brazil_spec_provider.cpf(with_mask=True)
    assert cpf == "515.942.427-93"

    # Test without mask.
    brazil_spec_provider = BrazilSpec

# Generated at 2022-06-23 20:45:27.739462
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'



# Generated at 2022-06-23 20:45:32.812642
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    for i in range(10):
        cnpj = provider.cnpj()
        assert len(cnpj) == 18
        for j in range(14):
            assert cnpj[j].isnumeric()
        assert cnpj[2] == '.'
        assert cnpj[6] == '.'
        assert cnpj[10] == '/'
        assert cnpj[15] == '-'


# Generated at 2022-06-23 20:45:36.193196
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf()
    assert brazil.cnpj()
    assert brazil.cpf(with_mask=False)
    assert brazil.cnpj(with_mask=False)

# Generated at 2022-06-23 20:45:39.285592
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brl = BrazilSpecProvider()
    for i in range(0,10):
        cpf = brl.cpf()
        print(cpf)
        print(type(cpf))
        assert len(cpf) == 14


# Generated at 2022-06-23 20:45:44.898009
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    a = BrazilSpecProvider()
    cnpjs = []
    for i in range(1000):
        cnpj = a.cnpj(with_mask=True)
        assert len(cnpj) == 18
        assert cnpj not in cnpjs
        cnpjs.append(cnpj)


# Generated at 2022-06-23 20:45:46.855473
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    
    for i in range(10):
        print('CPF =', BrazilSpecProvider().cpf(with_mask = True))

# Generated at 2022-06-23 20:45:49.290797
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider(seed=0)
    assert brazil.cpf() == '001.137.297-40'
    return 'test_BrazilSpecProvider_cpf passed'



# Generated at 2022-06-23 20:45:58.791527
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # instantiate BrazilSpecProvider
    brazil_pt_provider = BrazilSpecProvider()

    # test cpf() method
    assert len(brazil_pt_provider.cpf()) == 14
    assert len(brazil_pt_provider.cpf(with_mask=False)) == 11
    assert brazil_pt_provider.cpf()[3] == '.'
    assert brazil_pt_provider.cpf()[7] == '.'
    assert brazil_pt_provider.cpf()[11] == '-'

    # test  cnpj() method
    assert len(brazil_pt_provider.cnpj()) == 18
    assert len(brazil_pt_provider.cnpj(with_mask=False)) == 14
    assert brazil_pt_provider.cnpj

# Generated at 2022-06-23 20:46:01.101738
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.__doc__ == 'Class that provides special data for Brazil (pt-br).'


# Generated at 2022-06-23 20:46:10.310952
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    for i in range(18):
        if i==2 or i==6 or i==10:
            assert cnpj[i] == '.'
        elif i==5 or i==9:
            assert cnpj[i] == '/'
        elif i==15:
            assert cnpj[i] == '-'
        else:
            assert cnpj[i].isdigit()


# Generated at 2022-06-23 20:46:20.879893
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """[Unit test for method cnpj of class BrazilSpecProvider]
    
    Returns:
        [bool] -- [True if cpf has a valid format]
    """
    bz = BrazilSpecProvider()
    cnpj = bz.cnpj()
    split_cnpj = cnpj.split('-')
    if len(split_cnpj[0]) != 14:
        return False
    if len(split_cnpj[1]) != 2:
        return False
    if cnpj[2] != '.':
        return False
    if cnpj[6] != '.':
        return False
    if cnpj[10] != '/':
        return False
    return True


# Generated at 2022-06-23 20:46:23.510105
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj()

# Generated at 2022-06-23 20:46:28.703242
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('\nMethod cpf of BrazilSpecProvider:')
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    print(cpf)
    assert 3 == cpf.count('.')
    assert 1 == cpf.count('-')
    assert 11 == cpf.count('\d')


# Generated at 2022-06-23 20:46:32.217795
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf1 = BrazilSpecProvider(seed=0).cpf()
    cpf2 = BrazilSpecProvider(seed=1).cpf()
    assert cpf1 == '001.137.296-00'
    assert cpf2 == '051.846.738-60'


# Generated at 2022-06-23 20:46:35.845801
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    with BrazilSpecProvider(seed=123) as specProvider:
        assert specProvider.cnpj() == "13.235.784/0001-40"
        assert specProvider.cpf() == "564.976.337-99"

# Generated at 2022-06-23 20:46:41.501607
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brasilprovider = BrazilSpecProvider()
    cnpjs = [brasilprovider.cnpj() for _ in range(5)]
    assert len(list(set(cnpjs))) != 1
    assert brasilprovider.cnpj(with_mask = False) != brasilprovider.cnpj(with_mask = True)


# Generated at 2022-06-23 20:46:44.918442
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider constructor."""
    brazilprovider = BrazilSpecProvider()
    np.testing.assert_equal(brazilprovider.cnpj(), "77.732.230/0001-70")
    np.testing.assert_equal(brazilprovider.cpf(), "001.137.297-40")

# Generated at 2022-06-23 20:46:46.040478
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    assert len(p.cnpj()) == 18 # True

# Generated at 2022-06-23 20:46:48.881664
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bz = BrazilSpecProvider()
    assert bz.cpf() == '302.313.275-77'


# Generated at 2022-06-23 20:46:59.342764
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    stats = {
        'cnpj_masked': { 'with_mask': True, 'without_mask': False },
        'cnpj_unmasked': { 'with_mask': False, 'without_mask': True },
    }
    person = Person('pt-br')
    for gender in Gender:
        for test_type, _ in stats.items():
            for _ in range(100):
                name = person.name(gender)
                cnpj = person.cnpj(with_mask=stats[test_type]['with_mask'])
                if (stats[test_type]['with_mask'] and not stats[test_type]['without_mask']):
                    assert len(cnpj) == 18

# Generated at 2022-06-23 20:47:01.688726
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_obj = BrazilSpecProvider()
    assert(type(test_obj.cnpj()) == str)
    assert (len(test_obj.cnpj()) == 18)
    assert (type(test_obj.cpf()) == str)
    assert (test_obj.cpf(with_mask=True)[3] == '.')

# Generated at 2022-06-23 20:47:04.505306
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_instance = BrazilSpecProvider()
    print(test_instance)


# Generated at 2022-06-23 20:47:06.426947
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test = BrazilSpecProvider(seed=42)
    assert test

# Generated at 2022-06-23 20:47:09.449020
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf.count(".") == 3
    assert cpf.count("-") == 1