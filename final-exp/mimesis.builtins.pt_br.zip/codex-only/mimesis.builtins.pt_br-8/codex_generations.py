

# Generated at 2022-06-23 20:37:08.818118
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert brazil.cpf(True) == '001.137.297-40'


# Generated at 2022-06-23 20:37:11.475539
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('\n----- BEGIN: test_BrazilSpecProvider -----\n')

    print('\n----- END: test_BrazilSpecProvider -----\n')

# Main

# Generated at 2022-06-23 20:37:15.300095
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for BrazilSpecProvider.cpf()."""
    from unittest import TestCase
    import re

    provider = BrazilSpecProvider()

    assert provider.cpf() != provider.cpf()
    assert provider.cpf(with_mask=False) != provider.cpf(with_mask=False)
    assert re.match(r'\d{3}\.\d{3}\.\d{3}\-\d{2}',
                    provider.cpf(with_mask=True))



# Generated at 2022-06-23 20:37:19.302780
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Testing class BrazilSpecProvider constructor."""
    from mimesis.builtins.brazil import BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()
    print(brazil_spec_provider)


# Generated at 2022-06-23 20:37:22.509209
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print('CPF:', provider.cpf())
    print('CNPJ:', provider.cnpj())

# Generated at 2022-06-23 20:37:24.075785
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    response = provider.cpf()

    assert len(response) == 13


# Generated at 2022-06-23 20:37:25.340644
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:37:28.110036
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    for i in range(1000):
        cnpj = provider.cnpj()
        assert len(cnpj) == 18
        assert isinstance(cnpj, str)


# Generated at 2022-06-23 20:37:34.743437
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    random_1 = BrazilSpecProvider().cnpj()
    assert len(random_1) == 14
    assert random_1[2] == '.'
    assert random_1[6] == '.'
    assert random_1[10] == '/'
    assert random_1[13] == '-'

    random_2 = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(random_2) == 14


# Generated at 2022-06-23 20:37:35.736932
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:37:39.713450
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    '''The first method is tested'''
    #Generic tests
    assert BrazilSpecProvider.cpf("1") == "1.137.297-40"
    # print("unit test passed")

if __name__ == '__main__':
    test_BrazilSpecProvider_cpf()

# Generated at 2022-06-23 20:37:45.019126
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import datetime
    import pytest

    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)

    assert len(provider.cpf()) == 14
    assert len(provider.cpf(with_mask=False)) == 11
    assert len(provider.cnpj()) == 18
    assert len(provider.cnpj(with_mask=False)) == 14

    with pytest.raises(TypeError):
        BrazilSpecProvider(123)

    with pytest.raises(TypeError):
        BrazilSpecProvider(locale='en-US')

# Generated at 2022-06-23 20:37:50.363435
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender

    provider = BrazilSpecProvider()
    x = provider.cpf()
    print(x)
    assert len(x) == 14
    x = provider.cpf(with_mask=False)
    assert len(x) == 11
    assert x == '00113729740'

    # Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-23 20:37:54.346664
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == "."
    assert cpf[7] == "."
    assert cpf[11] == "-"
    parts = cpf.split('.')
    parts2 = parts[2].split('-')


# Generated at 2022-06-23 20:37:55.679286
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider()
    assert isinstance(a.__dict__, dict)

# Generated at 2022-06-23 20:37:56.217029
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:38:00.565491
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider_1 = BrazilSpecProvider()
    assert type(provider_1.cpf()) == str, 'The type of return value must be str.'
    assert len(provider_1.cpf()) == 14, 'The return value must have 14 digits.'
    assert len(provider_1.cpf(with_mask=False)) == 11, 'The return value must have 11 digits.'


# Generated at 2022-06-23 20:38:05.538719
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    # Test cnpj without mask
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14
    # Test cnpj with mask
    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:38:09.598198
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    result1 = BrazilSpecProvider.cnpj
    assert result1 is not None
    result2 = BrazilSpecProvider.cnpj(with_mask=False)
    assert result2 is not None
    result3 = BrazilSpecProvider.cnpj(with_mask=True)
    assert result3 is not None

# Generated at 2022-06-23 20:38:13.938587
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert isinstance(provider.cnpj(), str)
    assert len(provider.cnpj()) == 18

# Generated at 2022-06-23 20:38:17.356149
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj_no_mask = provider.cnpj(with_mask=False)
    cnpj_mask = provider.cnpj()

    assert len(cnpj_no_mask) == 14
    assert len(cnpj_mask) == 18


# Generated at 2022-06-23 20:38:19.032702
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().seed == 8675309



# Generated at 2022-06-23 20:38:21.341644
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18


# Generated at 2022-06-23 20:38:22.388482
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider() is not None


# Generated at 2022-06-23 20:38:27.112130
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider(seed=123)
    cpf_original = p.cpf(with_mask=False)
    p = BrazilSpecProvider(seed=123)
    cpf_new = p.cpf(with_mask=False)
    assert cpf_original == cpf_new


# Generated at 2022-06-23 20:38:30.075585
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from .common import generate_provider_test
    provider = BrazilSpecProvider()
    provider.cpf()
    generate_provider_test(provider, 'cpf', '77.732.230/0001-70')


# Generated at 2022-06-23 20:38:32.736207
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    result = brazil.cpf()
    assert result.isdigit()
    assert len(result) == 14


# Generated at 2022-06-23 20:38:34.403001
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bs = BrazilSpecProvider()
    print(bs.cnpj())


# Generated at 2022-06-23 20:38:39.600846
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    from asserts import assert_equal

    assert_equal(BrazilSpecProvider().__class__.__name__,
                 'BrazilSpecProvider')
    assert_equal(BrazilSpecProvider().__class__.__bases__,
                 (BaseSpecProvider,))


# Generated at 2022-06-23 20:38:44.755902
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    bsp.seed(12345)
    cnpj_1 = bsp.cnpj()
    cnpj_2 = bsp.cnpj()
    assert cnpj_1 == '80.628.401/0001-01'
    assert cnpj_2 == '75.093.254/0001-02'


# Generated at 2022-06-23 20:38:46.545955
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)


# Generated at 2022-06-23 20:38:51.844243
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    for i in range(10):
        cnpj = provider.cnpj(with_mask=False)
        assert len(cnpj) == 14
        assert cnpj.isdigit()
        assert cnpj[12:14] == '45' # verifica se os dois digitos verificadores estão sempre iguais a 45


# Generated at 2022-06-23 20:38:58.157763
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    
    brazil = BrazilSpecProvider()
    person = Person('pt-br')
    cpf = brazil.cpf()
    cnpj = brazil.cnpj()

    # for cpf_convert in cnpj:
    #     assert cpf_convert.isdigit()
    # assert len(cnpj) == 14
    # assert type(brazil.cnpj(with_mask=True)) is str
    # assert type(brazil.cnpj(with_mask=False)) is str
    # assert cpf != cnpj
    # assert brazil.cpf() != brazil.cnpj()
    # assert person.cpf() != person.cnpj()


# Generated at 2022-06-23 20:39:03.314901
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.providers.person import Person
    from mimesis.builtins.brazil import BrazilSpecProvider

    s = BrazilSpecProvider()
    p = Person()

    print(s.cpf())
    print(s.cnpj())
    print(p.full_name())


# Generated at 2022-06-23 20:39:04.590181
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-23 20:39:06.447065
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=1234567890)
    assert provider.cnpj() == "77.732.230/0001-70"

# Generated at 2022-06-23 20:39:12.647312
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    brazil_spec_provider = BrazilSpecProvider(seed=4)

    assert brazil_spec_provider.cpf() == '903.830.818-52'
    assert brazil_spec_provider.cnpj() == '28.630.927/0001-03'
    assert brazil_spec_provider.cnpj(with_mask=False) == '28630927000103'
    assert type(brazil_spec_provider.cpf()) == str
    assert type(brazil_spec_provider.cnpj()) == str
    assert type(brazil_spec_provider.cnpj(with_mask=False)) == str

if __name__ == "__main__":
    test_BrazilSpecProvider()
    print("Everything passed")

# Generated at 2022-06-23 20:39:14.394264
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()==['BrazilSpecProvider']

# Generated at 2022-06-23 20:39:18.645910
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()

    assert len(cnpj) == 18
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    assert cnpj.count('-') == 1


# Generated at 2022-06-23 20:39:22.324554
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert len(result) == 14
    assert result[3] == "."
    assert result[7] == "."
    assert result[11] == "-"



# Generated at 2022-06-23 20:39:25.668517
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected_result = '001.137.297-40'
    bp = BrazilSpecProvider()
    actual_result = bp.cpf()
    assert actual_result == expected_result


# Generated at 2022-06-23 20:39:29.852559
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf() == brazil.cpf()
    assert brazil.cpf() != brazil.cpf()
    assert brazil.cnpj() == brazil.cnpj()
    assert brazil.cnpj() != brazil.cnpj()

# Generated at 2022-06-23 20:39:31.877655
# Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-23 20:39:33.902860
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider()
    cpf.cpf()


# Generated at 2022-06-23 20:39:36.357397
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf)==11


# Generated at 2022-06-23 20:39:39.444853
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=False) == '0011372974'
    assert provider.cnpj(with_mask=False) == '77732230000170'

    print(provider.cnpj())

# Generated at 2022-06-23 20:39:46.024758
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    from mimesis.builtins import BrazilSpecProvider
    bs = BrazilSpecProvider()
    assert bs.cpf() == '861.458.044-38'
    # Test with mask
    assert bs.cnpj() == '59.846.489/0001-93'
    # Test without mask
    assert bs.cnpj(with_mask=False) == '59846489000193'

# Generated at 2022-06-23 20:39:53.172440
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Expected result
    expectedBool = True
    expectedResult = "000.000.000-00"
    # Call the method
    result = BrazilSpecProvider().cpf(True)
    # Check the result
    assert result == expectedResult
    assert type(result) is str
    assert len(result) == 14
    assert result[3] == "."
    assert result[7] == "."
    assert result[11] == "-"
    assert expectedBool == result.isalnum()


# Generated at 2022-06-23 20:39:54.525521
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() is not None


# Generated at 2022-06-23 20:39:55.848366
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:39:57.862290
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider


# Generated at 2022-06-23 20:40:03.636393
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()

    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[12:].isnumeric()
    assert cpf[:12].replace('.', '').isnumeric()


# Generated at 2022-06-23 20:40:06.279561
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj(with_mask=True)) == 18
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14


# Generated at 2022-06-23 20:40:10.117103
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    cpf = br.cpf()
    assert cpf == '250.320.846-32'


# Generated at 2022-06-23 20:40:15.296313
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create object
    provider = BrazilSpecProvider()

    # Test if is a string
    assert isinstance(provider.cnpj(), str)
    CNPJ_LEN = 18

    # Test if length (with mask) is correct
    assert CNPJ_LEN == len(provider.cnpj())

    # Test if length (without mask) is correct
    assert CNPJ_LEN - 6 == len(provider.cnpj(with_mask=False))


# Generated at 2022-06-23 20:40:21.388889
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    raw = BrazilSpecProvider()
    # raw.__class__
    # print(raw)
    """
    BrazilSpecProvider(seed=None)
    """
    assert raw.__class__.__name__ == 'BrazilSpecProvider'
    assert str(raw) == 'BrazilSpecProvider(seed=None)'
    assert raw.locale == 'pt-br'
    assert raw.seed == None
    assert BrazilSpecProvider().Meta.name == 'brazil_provider'


# Generated at 2022-06-23 20:40:23.931109
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:40:33.213978
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.person.en import Person
    from mimesis.enums import Gender
    
    br = BrazilSpecProvider()
    person = Person('en')
    for _ in range(10):
        cpf = br.cpf()
        assert cpf.count(".") == 2
        assert cpf.count("-") == 1
        assert len(cpf) == 14
        assert cpf[3] == cpf[7] == "."
        assert cpf[11] == "-"
        assert cpf[0:3] != cpf[4:7] != cpf[8:11] != cpf[12:14] != cpf[0:3]


# Generated at 2022-06-23 20:40:36.626269
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert isinstance(b.cpf(False), str)
    assert len(b.cpf(False)) == 11


# Generated at 2022-06-23 20:40:40.652333
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf == '16755543906'


# Generated at 2022-06-23 20:40:42.041459
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()

# Generated at 2022-06-23 20:40:46.210587
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print(provider.cpf())
    print(provider.cnpj())
    print(provider.cpf(with_mask=False))
    print(provider.cnpj(with_mask=False))
# End of test_BrazilSpecProvider() function


# Generated at 2022-06-23 20:40:49.565615
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert '683.491.732-29' == provider.cpf()


# Generated at 2022-06-23 20:40:52.023822
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    random = BrazilSpecProvider(seed=1)
    assert random.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-23 20:40:55.457162
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=42)
    assert provider.cpf() == '824.955.906-78'
    assert provider.cpf(with_mask=False) == '82495590678'


# Generated at 2022-06-23 20:40:58.413211
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    spr = BrazilSpecProvider()
    assert spr._seed is not None
    assert spr._locale == 'pt-br'
    assert spr._datetime_provider is not None
    assert spr._random is not None
    assert spr._text_provider is not None


# Generated at 2022-06-23 20:41:00.999658
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    # Arrange
    # Act
    obj_brazilSpecProvider = BrazilSpecProvider()

    # Assert
    actual = obj_brazilSpecProvider.__class__.__name__
    expected = 'BrazilSpecProvider'
    assert actual == expected


# Generated at 2022-06-23 20:41:09.761206
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf from class BrazilSpecProvider."""
    cpf = BrazilSpecProvider().cpf(with_mask=True)
    # Check if the string has the right format.
    assert cpf.__len__() == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    # Check if all numbers are equal.
    for i in range(0, 14):
        if cpf[i] != '.' and cpf[i] != '-':
            assert int(cpf[i]) > 0


# Generated at 2022-06-23 20:41:21.031628
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime

    data = BrazilSpecProvider(Seed(1))

    test_cpf = '24261427722'
    assert data.cpf(False) == test_cpf
    assert data.cpf(True) == '242.614.277-22'

    assert data.cpf() == '242.614.277-22'
    assert data.cpf(mask=False) == test_cpf

    test_cpf = '47110696843'
    assert data.cpf(with_mask=False, gender=Gender.MALE) == test_cpf
    assert data.cpf(with_mask=True, gender=Gender.MALE) == '471.106.968-43'

    assert data.cp

# Generated at 2022-06-23 20:41:23.902935
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider.

    """
    expected = '00.063.503/0003-00'

    result = BrazilSpecProvider().cnpj()

    assert result == expected

# Generated at 2022-06-23 20:41:34.548835
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Test for constructor BrazilSpecProvider
    provider = BrazilSpecProvider()

    # Test for get_verifying_digit_cpf
    assert provider.get_verifying_digit_cpf([1, 1, 3, 7, 2, 9, 7, 0, 4], 10) == 0
    assert provider.get_verifying_digit_cpf([1, 1, 3, 7, 2, 9, 7, 0, 4, 0], 11) == 8

    # Test for get_verifying_digit_cnpj
    assert provider.get_verifying_digit_cnpj([2, 7, 7, 7, 3, 2, 2, 3, 0, 0, 0, 1], 5) == 7

# Generated at 2022-06-23 20:41:35.978672
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()


# Generated at 2022-06-23 20:41:41.833047
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of BrazilSpecProvider."""
    from mimesis.enums import DataType, FieldConstraint
    brazil = BrazilSpecProvider()
    # Test of class attribute
    assert brazil.Meta.name == 'brazil_provider'
    assert brazil.Meta.provides.__len__() > 0
    # Test of data field
    assert brazil.Meta.provides['cnpj'] == (DataType.NORMAL, FieldConstraint.REQUIRED)

# Generated at 2022-06-23 20:41:43.405816
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    brazil = BrazilSpecProvider()

    result = brazil.cpf()
    assert result


# Generated at 2022-06-23 20:41:51.772843
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf_with_mask = b.cpf(with_mask=True)
    cpf_without_mask = b.cpf(with_mask=False)

    # Do the cpf have the mask?
    assert cpf_with_mask.count('.') == 2
    assert cpf_with_mask.count('-') == 1
    assert cpf_without_mask.count('.') == 0
    assert cpf_without_mask.count('-') == 0

    # Do the cpf have 11 digits?
    assert 11 == len(cpf_with_mask.replace('.', '').replace('-', ''))
    assert 11 == len(cpf_without_mask)


# Generated at 2022-06-23 20:41:58.956965
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    assert brazilSpecProvider.cpf() == '029.253.345-47'
    assert brazilSpecProvider.cnpj() == '79.692.303/0001-22'
    assert brazilSpecProvider.cpf(False) == '26129613923'
    assert brazilSpecProvider.cnpj(False) == '13863051000120'
    assert len(brazilSpecProvider.cpf()) == 14
    assert len(brazilSpecProvider.cnpj()) == 18

# Generated at 2022-06-23 20:42:02.261321
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(100):
        cnpj = BrazilSpecProvider().cnpj()
        assert len(cnpj) == 18 and cnpj.count("-") == 1 and cnpj.count(".") == 2 and cnpj.count("/") == 1
    return True

# Generated at 2022-06-23 20:42:04.013473
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14
    assert len(BrazilSpecProvider().cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:42:06.714568
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    braz_provider = BrazilSpecProvider()
    assert len(braz_provider.cpf(with_mask = False)) == 11

# Generated at 2022-06-23 20:42:14.692586
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # test cases
    testCases = [
        {
            "case": 1,
            "input": {'with_mask': False},
            "expected": '77732243000170'
        },
        {
            "case": 2,
            "input": {'with_mask': True},
            "expected": '77.732.230/0001-70'
        }
    ]
    for test in testCases:
        assert BrazilSpecProvider().cnpj(**test['input']) == test['expected'], f'Teste {test["case"]}'


# Generated at 2022-06-23 20:42:19.020342
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:42:21.137243
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
  brazil = BrazilSpecProvider()
  print(brazil.cpf())
  print(brazil.cnpj())

# Generated at 2022-06-23 20:42:24.499849
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    assert b.__class__.__module__ == 'mimesis.providers.brazil'
    assert b.seed is not None
    assert b.random is not None
    assert b.datetime is not None
    assert b.__version__ is not None


# Generated at 2022-06-23 20:42:30.069486
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    assert(b.cpf(False) != b.cpf(False))
    assert(b.cpf(True) != b.cpf(True))
    assert(b.cnpj(False) != b.cnpj(False))
    assert(b.cnpj(True) != b.cnpj(True))

# Generated at 2022-06-23 20:42:34.974225
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-'
    assert len(cpf) == 14
    assert cpf == provider.cpf(True)
    assert len(provider.cpf(False)) == 11


# Generated at 2022-06-23 20:42:45.146767
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """The CPF generator."""
    b = BrazilSpecProvider()
    assert isinstance(b.cpf(), str)
    assert len(b.cpf()) == 14
    assert isinstance(b.cpf(with_mask=False), str)
    assert len(b.cpf(with_mask=False)) == 11
    assert isinstance(b.cpf(seed=123), str)
    assert len(b.cpf(seed=123)) == 14
    assert isinstance(b.cpf(with_mask=False, seed=123), str)
    assert len(b.cpf(with_mask=False, seed=123)) == 11


# Generated at 2022-06-23 20:42:49.803105
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    lst_cnpj = []

    for i in range(100000):
        lst_cnpj.append(BrazilSpecProvider().cnpj())

    assert ('02446576000130' in set(lst_cnpj))


# Generated at 2022-06-23 20:42:58.337589
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    cpf = brazilSpecProvider.cpf()
    
    # Validation of cpf format
    assert len(cpf) == 14
    assert cpf[3:4] == '.'
    assert cpf[7:8] == '.'
    assert cpf[11:12] == '-'

    # Validation of cpf
    assert cpf[9:10] == str(11-(sum(int(cpf[i])*(10-i)
                              for i in range(9))%11))
    assert cpf[10:11] == str(11-(sum(int(cpf[i])*(11-i)
                              for i in range(10))%11))


# Generated at 2022-06-23 20:43:00.065524
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
	br = BrazilSpecProvider()
	print(br.cnpj())

# Generated at 2022-06-23 20:43:07.807964
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Instantiation of the class
    provider = BrazilSpecProvider(seed=123)

    # Test for attributes
    assert provider.__doc__ == "Class that provides special data for Brazil (pt-br)."
    assert provider.Meta.name == 'brazil_provider'

    # Test for methods
    assert provider.cpf() == '005.138.593-37'
    assert provider.cnpj() == '12.906.109/0001-49'

# Generated at 2022-06-23 20:43:11.118259
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bs = BrazilSpecProvider()

    assert(type(bs.cpf()) is str)
    assert(type(bs.cnpj()) is str)

# Generated at 2022-06-23 20:43:12.736764
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_BrazilSpecProvider = BrazilSpecProvider()
    assert test_BrazilSpecProvider.cnpj() != test_BrazilSpecProvider.cnpj()


# Generated at 2022-06-23 20:43:13.969826
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()
    BrazilSpecProvider(seed=1234)


# Generated at 2022-06-23 20:43:18.051012
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Create the object BrazilSpecProvider
    obj = BrazilSpecProvider()
    # Return data
    cpf = obj.cpf()
    # Return data
    cnpj = obj.cnpj()
    # Print data
    print(cpf)
    print(cnpj)

# Unit test

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:43:19.237746
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    return BrazilSpecProvider().cpf()


# Generated at 2022-06-23 20:43:21.645419
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    print(cpf)
    assert len(cpf) == 14

# Generated at 2022-06-23 20:43:24.811468
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == "001.137.297-40"
    assert provider.cnpj() == "77.732.230-0001-70"


# Generated at 2022-06-23 20:43:29.284833
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of class BrazilSpecProvider"""
    cnpj1 = BrazilSpecProvider().cnpj()
    cnpj2 = BrazilSpecProvider().cnpj()
    assert len(cnpj1) == len(cnpj2)
    assert cnpj1 != cnpj2


# Generated at 2022-06-23 20:43:34.515516
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test if constructor is working."""
    brazil = BrazilSpecProvider()
    assert brazil.cpf() == '477.104.852-44'
    assert brazil.cpf(with_mask=False) == '47710008033'
    assert brazil.cnpj() == '16.804.409/0001-60'
    assert brazil.cnpj(with_mask=False) == '16804409000160'

# Generated at 2022-06-23 20:43:41.764947
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

    # test 'cpf'
    assert provider.cpf(with_mask=True) == '278.163.805-66'

    # test 'cnpj'
    assert provider.cnpj(with_mask=True) == '40.954.696/0001-05'

    # test 'cep'
    assert provider.cep() == '35270-170'


"""Unit test for constructor of class BrazilSpecProvider."""

provider = BrazilSpecProvider()

# test 'cpf'
assert provider.cpf(with_mask=True) == '278.163.805-66'

# test 'cnpj'
assert provider.cnpj(with_mask=True) == '40.954.696/0001-05'

# test 'cep'

# Generated at 2022-06-23 20:43:47.930396
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider(seed=12345)
    assert brazil_spec_provider
    assert hasattr(brazil_spec_provider, 'seed')
    assert hasattr(brazil_spec_provider, 'locale')
    assert hasattr(brazil_spec_provider, '_data')
    assert hasattr(brazil_spec_provider, 'providers')


# Generated at 2022-06-23 20:43:50.580378
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test that cnpj() method return the expected result."""
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 18

# Generated at 2022-06-23 20:43:52.532353
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result = provider.cnpj()
    print(result)


# Generated at 2022-06-23 20:44:01.136775
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import pytest
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet
    from mimesis.providers.person import Person
    from mimesis.providers.brazil import BrazilSpecProvider
    import re
    import tqdm
    # Test cpf without mask
        # Test cpf without mask - Generate a cpf and verify that the generated cpf is valid
    brazil = BrazilSpecProvider(seed=42)
    cpf_without_mask = brazil.cpf(with_mask=False)
    if (re.match(r'[0-9]{11}', cpf_without_mask)):
        assert True
    else:
        assert False

        # Test cpf without mask - Generate a quantity of cpf and verify that the all generated cpfs are valid
   

# Generated at 2022-06-23 20:44:05.167748
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.set_seed(None)
    cnpj = b.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert cnpj[:2] in ['11', '22', '33', '44', '55', '66', '77', '88', '99']



# Generated at 2022-06-23 20:44:13.032009
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '27.104.636/0001-41'
    assert provider.cnpj() == '92.507.091/0001-00'
    assert provider.cnpj() == '81.302.685/0001-09'
    assert provider.cnpj() == '17.217.856/0001-86'
    assert provider.cnpj() == '18.506.289/0001-79'
    assert provider.cnpj() == '41.386.779/0001-12'
    assert provider.cnpj() == '47.647.845/0001-62'
    assert provider.cnpj() == '13.552.987/0001-99'

# Generated at 2022-06-23 20:44:17.357802
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    bs = BrazilSpecProvider()
    cpf = bs.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:44:19.924437
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    for i in range(0, 10):
        print(BrazilSpecProvider().cnpj())


# Generated at 2022-06-23 20:44:23.750817
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider_cpf"""
    try:
        BrazilSpecProvider(seed = 1).cpf()
    except:
        assert False, 'Error running BrazilSpecProvider.cpf()'



# Generated at 2022-06-23 20:44:27.379266
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Tests the method cnpj of class BrazilSpecProvider.

    Parameters
    ----------
    None

    Returns
    -------
    None

    Notes
    -----
    None
    """

    spec = BrazilSpecProvider()
    print(spec.cnpj(with_mask=True))


# Generated at 2022-06-23 20:44:38.516698
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis_test_case import MimesisTestCase

    provider = BrazilSpecProvider()
    expected_cnpj_mask = '77.732.230/0001-70'
    expected_cnpj_no_mask = '77732230000170'
    cnpj = provider.cnpj()
    self.assertEqual(cnpj, expected_cnpj_mask)
    cnpj = provider.cnpj(with_mask=False)
    self.assertEqual(cnpj, expected_cnpj_no_mask)


# Generated at 2022-06-23 20:44:41.829636
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    # Print brazil_spec_provider
    print(brazil_spec_provider)


# Generated at 2022-06-23 20:44:47.457494
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    ''' Unit testing for method BrazilSpecProvider.cpf
        To run the test, execute in terminal:
        python test_BrazilSpecProvider_cpf.py
    '''
    provider = BrazilSpecProvider()
    for i in range(0,10):
        print(provider.cpf())


# Generated at 2022-06-23 20:44:50.169378
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider()
    print(a.cnpj())
    print(a.cpf())

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:44:51.611539
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert isinstance(BrazilSpecProvider().cnpj(), str)

# Generated at 2022-06-23 20:44:54.962111
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    assert re.match("[0-9]{3}[.][0-9]{3}[.][0-9]{3}[-][0-9]{2}", br.cpf())


# Generated at 2022-06-23 20:45:06.126466
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    print('\n[Class BrazilSpecProvider]')
    print('get_verifying_digit_cnpj(list, 5):', b.get_verifying_digit_cnpj([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], 5))
    print('get_verifying_digit_cnpj(list, 6):', b.get_verifying_digit_cnpj([1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,], 6))
    print('get_verifying_digit_cpf(list, 10):', b.get_verifying_digit_cpf([1, 1, 1, 1, 1, 1, 1, 1, 1, ], 10))

# Generated at 2022-06-23 20:45:12.337663
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for BrazilSpecProvider.cpf()"""
    # create instance
    item = BrazilSpecProvider()
    # test
    cpf = item.cpf()
    # assertion
    assert len(cpf)==14
    assert cpf[3] == "."
    assert cpf[7] == "."


# Generated at 2022-06-23 20:45:17.684349
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = 0
    bp = BrazilSpecProvider()
    for i in range(100):
        print(bp.cpf())
        if bp.cpf() == '0.0.0.0-0':
            result += 1
    print("\n")
    print("-----------------------")
    print("Number of CPF equal to 0.0.0.0-0 = ", result)
    print("-----------------------")


# Generated at 2022-06-23 20:45:21.955595
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj(with_mask=False)
    cnpj = cnpj[:2] + cnpj[3:6] + cnpj[7:10] + cnpj[11:]
    assert len(cnpj) == 14

test_BrazilSpecProvider_cnpj()


# Generated at 2022-06-23 20:45:25.031133
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert isinstance(cpf, str)


# Generated at 2022-06-23 20:45:26.055511
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj()

# Generated at 2022-06-23 20:45:30.087151
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test basic constructor of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    assert provider.__class__.__name__ == 'BrazilSpecProvider'
    assert provider.locale == 'pt-br'
    assert provider.seed is None
    assert provider.random is not None
    assert provider.datetime is not None


# Generated at 2022-06-23 20:45:32.683431
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    instance = BrazilSpecProvider()
    print(instance.cnpj())
    print(instance.cpf())

test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:41.647313
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    iter_times = 10000
    provider = BrazilSpecProvider()
    for iteration in range(iter_times):
        cnpj = provider.cnpj(with_mask=False)
        # Check if verify digit 1 is correct
        first_12_digits = cnpj[:-2]
        verify_digit_1 = cnpj[12]
        verify_digit_1_expected = provider.get_verifying_digit_cnpj(
            first_12_digits, 5)

# Generated at 2022-06-23 20:45:45.962194
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """
    Testing the constructor of BrazilSpecProvider class.
    """
    brazil_provider_object = BrazilSpecProvider()
    print("Verifying if brazil_provider_object is a valid object of BrazilSpecProvider class...\n")
    assert isinstance(brazil_provider_object, BrazilSpecProvider)


# Generated at 2022-06-23 20:45:57.110037
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    from mimesis.schema import Field, Schema
    br = BrazilSpecProvider()
    test_schema = Schema(seed=123456)
    cpfs = test_schema.create(100, Field('cpf', provider=br))

    method_result = br.cpf()
    assert not method_result.startswith('0')

    method_result = br.cpf(with_mask=False)
    assert len(method_result) == 11
    assert not method_result.startswith('0')

    for cpf in cpfs:
        assert len(cpf) == 14
        assert cpf.count('.') == 2
        assert cpf.count('-') == 1
        mask_split = cpf.split('.')


# Generated at 2022-06-23 20:46:02.405699
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    first_random_cnpj = BrazilSpecProvider().cnpj()
    second_random_cnpj = BrazilSpecProvider().cnpj()
    if first_random_cnpj != second_random_cnpj:
        print("First random cnpj = ", first_random_cnpj)
        print("Second random cnpj = ", second_random_cnpj)
        return True
    return False


# Generated at 2022-06-23 20:46:05.351188
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(1000):
        cnpj = BrazilSpecProvider().cnpj()
        assert len(cnpj) == 18


# Generated at 2022-06-23 20:46:12.675873
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # New instance of BrazilSpecProvider
    bsp = BrazilSpecProvider()
    # verify if a cnpj contains only digits
    assert bsp.cnpj(with_mask=False).replace('.', '').replace('/', '') \
                                                .replace('-', '').isdigit()
    # Verify if a cnpj length is 14
    assert len(bsp.cnpj(with_mask=False).replace('.', '').replace('/', '') \
                                                .replace('-', '')) == 14


# Generated at 2022-06-23 20:46:14.912534
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider(seed=123)
    print('[Unit test method cnpj]')
    print('cnpj output:', obj.cnpj())
    print('cnpj without mask output:', obj.cnpj(False))

# Generated at 2022-06-23 20:46:23.981157
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        elif peso == 6:
            peso_list = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        for i, _ in enumerate(cnpj):
            soma += peso_

# Generated at 2022-06-23 20:46:25.903513
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = BrazilSpecProvider().cpf()
    assert result is not None


# Generated at 2022-06-23 20:46:30.715515
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider.seed(10)
    cpf = BrazilSpecProvider.cpf()
    assert(cpf == '220.029.407-26')
    cnpj = BrazilSpecProvider.cnpj()
    assert(cnpj == '99.211.977/0001-93')


if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:46:35.691701
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider class cnpj method."""
    cpf_pattern = re.compile('^\d{3}.\d{3}.\d{3}/\d{4}-\d{2}$')
    assert cpf_pattern.match(BrazilSpecProvider().cnpj()) != None

# Generated at 2022-06-23 20:46:38.186322
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14
    assert isinstance(bsp.cpf(), str)
    assert bsp.cpf(with_mask=False) != bsp.cpf()



# Generated at 2022-06-23 20:46:47.665929
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    seed = 123
    person = Person('en', seed)

    op = BrazilSpecProvider(seed)
    cpf = op.cpf(with_mask = True)
    cpf_numbers = person.cpf(with_mask=False) + '0'
    cpf_numbers_12 = ''.join([cpf[0], cpf[1], cpf[3], cpf[4], cpf[5], cpf[7], cpf[8], cpf[9], cpf[11], cpf[12], cpf[13], cpf[15]])

    assert cpf == '001.137.297-40', 'The cpf() method of the BrazilSpecProvider class did not return the expected value'

# Generated at 2022-06-23 20:46:51.024464
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cpf(True))
    print(brazil_provider.cnpj(True))

# Generated at 2022-06-23 20:47:00.914219
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider(seed=44444444444444444444444444444444)
    print(brazil.cpf())
    print(brazil.cpf())
    print(brazil.cpf())
    print(brazil.cpf())
    print(brazil.cpf())
    print(brazil.cpf())
    print(brazil.cpf())
    print(brazil.cpf())
    print(brazil.cpf())
    print(brazil.cpf())
    print(brazil.cnpj())
    print(brazil.cnpj())
    print(brazil.cnpj())
    print(brazil.cnpj())
    print(brazil.cnpj())
    print(brazil.cnpj())

# Generated at 2022-06-23 20:47:06.426533
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider's cpf method."""

    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=True)
    assert isinstance(cpf, str)
    assert len(cpf) == 14

