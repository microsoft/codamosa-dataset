

# Generated at 2022-06-23 20:37:20.472419
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=123)

    provider_obj = BrazilSpecProvider()
    # Test for assert of class
    assert provider_obj._assert is not None

    # Test for assert of class
    assert provider_obj._datetime_data is not None

    assert provider_obj._data is not None

    assert provider_obj._localization is not None

    assert provider_obj._math is not None

    assert provider_obj._random is not None

    assert provider_obj._regex is not None

    assert provider_obj._string is not None

    assert provider_obj._system is not None

    assert provider_obj._tracker is not None

    assert provider_obj._seed is not None

    assert provider_obj.seed != provider.seed


# Generated at 2022-06-23 20:37:29.551625
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Create a new BrazilSpecProvider object
    bsp = BrazilSpecProvider()

    # Check if cpf works and returns a value with the default mask
    cpf1 = bsp.cpf()
    assert len(cpf1) == 14
    assert cpf1[3] == '.'
    assert cpf1[7] == '.'
    assert cpf1[11] == '-'

    # Check if cpf works and returns a value with the format provided in argument
    cpf1 = bsp.cpf(False)
    assert len(cpf1) == 11

    # Check if cpf returns the same value every time
    cpf1 = bsp.cpf()
    cpf2 = bsp.cpf()
    assert cpf1 == cpf2

    # Create a new BrazilSpecProvider object
    bsp = Brazil

# Generated at 2022-06-23 20:37:30.886522
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()
    assert p is not None


# Generated at 2022-06-23 20:37:32.208300
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print(BrazilSpecProvider.cpf())


# Generated at 2022-06-23 20:37:34.518791
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    for _ in range(5):
        print(b.cpf())
    return True


# Generated at 2022-06-23 20:37:37.545275
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    seed = b'\x00\x01\x02'
    spec = BrazilSpecProvider(seed)
    assert spec is not None


# Generated at 2022-06-23 20:37:41.722477
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    for i in range(10):
        cnpj = bsp.cnpj(with_mask = False)
        assert len(cnpj) == 14
        assert isinstance(cnpj, str)
        assert isinstance(int(cnpj), int)

# Generated at 2022-06-23 20:37:43.388550
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider()
    result = obj.cnpj(True)
    assert result == '00.000.000/0000-00'

# Generated at 2022-06-23 20:37:46.656515
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14
    assert len(BrazilSpecProvider().cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:37:49.748685
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()
    assert BrazilSpecProvider.Meta.name == 'brazil_provider'
    assert p.provider == 'brazil_provider'
    assert p.locale == 'pt-br'


# Generated at 2022-06-23 20:37:51.215762
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf(False)) == 11


# Generated at 2022-06-23 20:38:00.386210
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Verify the correct operation of the cpf method of BrazilSpecProvider class."""
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseSpecProvider, DatetimeProvider
    from mimesis.providers.person import Person

    random = BaseSpecProvider(seed=42)
    brazil_spec_provider = BrazilSpecProvider(random)
    datetime_provider = DatetimeProvider(random)
    person = Person('pt-br', random)

    person.create(gender=Gender.MALE)
    birth_date_in_the_future = datetime_provider.datetime(start=datetime_provider.now(), end=datetime_provider.future())
    birth_date = datetime_provider.datetime(end=datetime_provider.now())

# Generated at 2022-06-23 20:38:05.405824
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    ob = BrazilSpecProvider()
    # Tests CPF
    assert len(ob.cpf(with_mask=False)) == 11
    assert len(ob.cpf(with_mask=True)) == 14
    # Tests CNPJ
    assert len(ob.cnpj(with_mask=False)) == 14
    assert len(ob.cnpj(with_mask=True)) == 18

# Generated at 2022-06-23 20:38:08.458830
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of class BrazilSpecProvider"""
    random_provider = BrazilSpecProvider()
    assert random_provider.cpf() is not None
    assert random_provider.cnpj() is not None

# Generated at 2022-06-23 20:38:10.720358
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider class."""
    provider = BrazilSpecProvider()
    assert provider.provider == 'brazil_provider'


# Generated at 2022-06-23 20:38:17.933525
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    def cnpj_pattern_test(cnpj):
        """Test cnpj pattern with regex."""
        import re
        regex = re.compile(r'^[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}$')
        if not regex.match(cnpj):
            print(f'{cnpj} is not a valid cnpj!')
            return False
        return True

    def cnpj_calculate_test(cnpj):
        """Test cnpj calculate with raw digits of cnpj."""

# Generated at 2022-06-23 20:38:19.805723
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    data = BrazilSpecProvider()
    print(data)


# Generated at 2022-06-23 20:38:22.242734
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf(with_mask=False) != ''


# Generated at 2022-06-23 20:38:24.663609
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert len(b.cpf(with_mask=True)) == 14



# Generated at 2022-06-23 20:38:26.033921
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:38:27.290181
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    c = BrazilSpecProvider()
    c.cpf()


# Generated at 2022-06-23 20:38:29.146161
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert isinstance(brazil_provider, BrazilSpecProvider)



# Generated at 2022-06-23 20:38:35.576648
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf.count(".") == 3, f"{cpf} must have 3 dots in it"
    assert cpf[-2] == "-", f"{cpf} must have '-' in it"
    cpf_numbers = [int(i) for i in "".join(cpf.split(".")).split("-")]
    assert len(cpf_numbers) == 9, f"{cpf_numbers} cannot be larger than 9"
    assert len(cpf_numbers) == 9, f"{cpf_numbers} cannot be smaller than 9"


# Generated at 2022-06-23 20:38:42.038605
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.typing import Seed
    from locale import setlocale, LC_ALL

    setlocale(LC_ALL, 'pt_BR.utf8')
    seed = Seed()
    spec = BrazilSpecProvider(seed)
    assert isinstance(spec, BaseSpecProvider) == True
    assert isinstance(spec.seed, Seed) == True


# Generated at 2022-06-23 20:38:44.522448
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the method cpf of class BrazilSpecProvider."""
    brazilSpecProvider = BrazilSpecProvider()
    brazilSpecProvider.cpf()


# Generated at 2022-06-23 20:38:52.379402
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    
    cnpj = provider.cnpj()

    # CNPJ must have the following mask: nn.nnn.nnn/nnnn-nn
    mask = '[0-9]{2}[.][0-9]{3}[.][0-9]{3}[\/][0-9]{4}[-][0-9]{2}'
    assert re.match(mask, cnpj)


# Generated at 2022-06-23 20:38:53.935102
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    brazilSpecProvider.cpf(with_mask=True)

# Generated at 2022-06-23 20:38:55.331856
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    temp = BrazilSpecProvider()
    assert temp.provider_name == "BrazilSpecProvider"


# Generated at 2022-06-23 20:39:03.807099
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = 12345
    bsp = BrazilSpecProvider(seed)
    cnpj = bsp.cnpj()
    if cnpj != "10.653.904/0001-22":
        print("Error - test_BrazilSpecProvider_cnpj() - Return value = " + cnpj)
    bsp = BrazilSpecProvider(seed)
    cnpj = bsp.cnpj(False)
    if cnpj != "10653904000122":
        print("Error - test_BrazilSpecProvider_cnpj() - Return value = " + cnpj)


# Generated at 2022-06-23 20:39:05.715609
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:39:10.226289
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of class BrazilSpecProvider."""

    obj1 = BrazilSpecProvider()
    assert obj1.locale == 'pt-br'
    assert 'BrazilSpecProvider' == BrazilSpecProvider.Meta.name


# Generated at 2022-06-23 20:39:12.341602
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(with_mask=True)
    print(cpf)


# Generated at 2022-06-23 20:39:15.803070
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Running unit test for method cpf of class BrazilSpecProvider")
    print("Creating BrazilSpecProvider object")
    provider = BrazilSpecProvider()
    print("Calling method cpf of object provider")
    print(provider.cpf())


# Generated at 2022-06-23 20:39:18.849493
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    pattern = re.compile('^\d{3}.\d{3}.\d{3}-\d{2}$')
    assert (pattern.match(provider.cpf()))


# Generated at 2022-06-23 20:39:19.956166
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    document = provider.cnpj()
    assert len(document) == 18 and '/' in document


# Generated at 2022-06-23 20:39:23.417806
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """test_BrazilSpecProvider_cnpj"""
    from mimesis.providers.datetime import Datetime
    dt = Datetime()
    for i in range(100):
        print(dt.date(start="today", end="today"), BrazilSpecProvider().cnpj())


# Generated at 2022-06-23 20:39:26.391078
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('Testing for CPF...')
    brazil = BrazilSpecProvider()
    for _ in range(100):
        cpf = brazil.cpf()
        print('CPF:',cpf)
    print('Done.')


# Generated at 2022-06-23 20:39:29.117669
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider()
    actual = obj.cnpj()
    assert len(actual) == 14
    assert (actual[2:3] == '.' and
            actual[6:7] == '.' and
            actual[10:11] == '/' and
            actual[15:16] == '-')

# Generated at 2022-06-23 20:39:32.741582
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:39:41.513596
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    # Test case 1:
    # Test if cnpj is formatted correctly (without mask)
    cnpj = bsp.cnpj(with_mask=False)
    assert cnpj.isdigit()

    # Test case 2:
    # Test if cnpj is formatted correctly (with mask)
    cnpj_mask = bsp.cnpj(with_mask=True)
    assert cnpj_mask.replace('.', '').replace('/', '').replace('-', '') == cnpj

    # Test case 3:
    # Test if method cnpj returns a different cnpj for each call
    cnpj_1 = bsp.cnpj(with_mask=False)
   

# Generated at 2022-06-23 20:39:52.098617
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    # test if cnpj is a string
    cnpj = brazil.cnpj()
    assert type(cnpj) == str
    # test if cnpj length is 14
    assert len(cnpj) == 14
    # test if cnpj has the correct mask
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    # test if first and second DV are correct

# Generated at 2022-06-23 20:39:54.621062
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bz = BrazilSpecProvider()

    cpf = bz.cpf()
    print(cpf)

    assert len(cpf) == 14


# Generated at 2022-06-23 20:39:57.498010
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for i in range(10):
        assert len(provider.cpf(with_mask=False)) == 11
        assert len(provider.cpf(with_mask=True)) == 14


# Generated at 2022-06-23 20:40:01.912698
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Creates object and executes method
    brazilobj = BrazilSpecProvider()
    result_cpf = brazilobj.cpf()
    result_cnpj = brazilobj.cnpj()

    # Verifies if the method is returning a valid result
    assert len(result_cpf) == 14
    assert len(result_cnpj) == 18

# Generated at 2022-06-23 20:40:04.956210
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '851.876.136-97'
    assert provider.cpf(with_mask=False) == '85187613697'
    assert provider.cpf() != '399.109.466-48'
    assert provider.cpf() != '399.109466-48'


# Generated at 2022-06-23 20:40:05.765033
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider.cpf()

# Generated at 2022-06-23 20:40:10.652308
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider.cpf() == "570.959.621-68"
    assert BrazilSpecProvider.cpf(with_mask=False) == "570959621-68"


# Generated at 2022-06-23 20:40:12.215839
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()

    assert len(result) == 14


# Generated at 2022-06-23 20:40:12.748968
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pass

# Generated at 2022-06-23 20:40:16.869211
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    all_methods = [attr for attr in dir(BrazilSpecProvider)
                   if callable(getattr(BrazilSpecProvider, attr))
                   if not attr.startswith('__')]
    print(all_methods)

# Generated at 2022-06-23 20:40:18.259226
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert len(b.cnpj()) == 18

# Generated at 2022-06-23 20:40:20.028271
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj_1 = provider.cnpj()
    cnpj_2 = provider.cnpj()
    assert cnpj_1 != cnpj_2


# Generated at 2022-06-23 20:40:26.849170
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_tree = """
    def test_{{randint(1,100)}}():
        assert bsp.cpf(with_mask=True) in """ + str(
        set([BrazilSpecProvider().cpf(
            with_mask=True) for _ in range(100)])) + """

    """
    exec(test_tree, {'bsp': BrazilSpecProvider(), 'BrazilSpecProvider':BrazilSpecProvider, 'set':set})


# Generated at 2022-06-23 20:40:29.809501
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=4569)
    result = provider.cpf(with_mask=False)

    assert result == '95675743397'


# Generated at 2022-06-23 20:40:31.468253
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert "039.937.892-36" == BrazilSpecProvider().cpf()


# Generated at 2022-06-23 20:40:34.095411
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider()
    res = p.cpf()
    assert isinstance(res,str)
    assert len(res) == 14


# Generated at 2022-06-23 20:40:36.088903
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert isinstance(provider.cpf(), str)



# Generated at 2022-06-23 20:40:38.222510
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert bsp.__class__.__name__ == 'BrazilSpecProvider'



# Generated at 2022-06-23 20:40:40.521140
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    print(b.cpf())
    print(b.cnpj())

test_BrazilSpecProvider()

# Generated at 2022-06-23 20:40:43.044711
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Arrange
    # Act
    brazil = BrazilSpecProvider()
    # Assert
    assert isinstance(brazil, BrazilSpecProvider)


# Generated at 2022-06-23 20:40:50.900921
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    assert cnpj[2:6].isdigit()
    assert cnpj[6:10].isdigit()
    assert cnpj[10:15].isdigit()

# Generated at 2022-06-23 20:40:53.702911
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    assert (b.cpf() != b.cpf())
    assert (b.cnpj() != b.cnpj())

# Generated at 2022-06-23 20:40:54.304629
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pass

# Generated at 2022-06-23 20:40:59.412907
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

    # Test cpf()
    for _ in range(10):
        provider.cpf()
    for _ in range(10):
        provider.cpf(with_mask=False)

    # Test cnpj()
    for _ in range(10):
        provider.cnpj()
    for _ in range(10):
        provider.cnpj(with_mask=False)


# Generated at 2022-06-23 20:41:01.231842
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf."""
    provider = BrazilSpecProvider()
    cpf = '00113729740'
    assert provider.cpf() == cpf


# Generated at 2022-06-23 20:41:03.335259
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Tests method cnpj of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider(seed=Faker())
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:41:06.267362
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cnpj()

# Generated at 2022-06-23 20:41:16.829459
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # instanciando o objeto da classe
    brazil_provider = BrazilSpecProvider()
    
    
    # chamando a função cnpj
    cnpj = brazil_provider.cnpj()
    
    # testando se a função está retornando um valor string
    assert isinstance(cnpj, str)

    # testando se o valor da string retornada é um cnpj válido
    assert ''.join(cnpj.split('.')).replace('/', '').replace('-', '').isdigit()

    # testando se a função cnpj está retornando o valor None
    assert brazil_provider.cnpj(False) is not None


# Generated at 2022-06-23 20:41:17.835692
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    my_BrazilSpecProvider = BrazilSpecProvider()
    assert my_BrazilSpecProvider != None

# Generated at 2022-06-23 20:41:23.903230
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cnpj() == brazil_provider.cnpj()
    assert brazil_provider.cnpj() == brazil_provider.cnpj()
    assert brazil_provider.cnpj() == brazil_provider.cnpj()
    assert brazil_provider.cnpj() == brazil_provider.cnpj()

# Generated at 2022-06-23 20:41:33.930273
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    mask = "###.###.###-##"
    mask_cnpj = "##.###.###/####-##"

    cnpj = brazil_provider.cnpj(with_mask = False)
    assert len(cnpj) == 14
    assert brazil_provider.cnpj(with_mask = True)  == brazil_provider.mask(mask_cnpj,cnpj)

    cpf = brazil_provider.cpf(with_mask = False)
    assert len(cpf) == 11
    assert brazil_provider.cpf(with_mask = True) == brazil_provider.mask(mask,cpf)

# Generated at 2022-06-23 20:41:37.955951
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert cpf == '319.122.015-05', 'CPF should be 319.122.015-05'


# Generated at 2022-06-23 20:41:40.432174
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:41:44.027473
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.isdigit() == True


# Generated at 2022-06-23 20:41:46.491410
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask = True)
    print(cnpj)

# test_BrazilSpecProvider()

# Generated at 2022-06-23 20:41:49.113910
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test = BrazilSpecProvider(seed = 123)
    assert isinstance(test, BrazilSpecProvider)
    assert isinstance(test.random, Seed)
    assert test.random.seed == 123


# Generated at 2022-06-23 20:41:50.311349
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=12345)

# Generated at 2022-06-23 20:41:53.251258
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider.

    :Returns:
        void
    """
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:41:56.599841
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    brazil_provider = BrazilSpecProvider()

    for i in range(100):
        cnpj = brazil_provider.cnpj()
        assert len(cnpj) == 18



# Generated at 2022-06-23 20:41:59.980160
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj();
    print('cnpj: ' + cnpj)
    assert len(cnpj) == 18 or len(cnpj) == 14

# Generated at 2022-06-23 20:42:06.479273
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()

    cpf_result = brazil_spec_provider.cpf()
    print(cpf_result)
    print(type(cpf_result))

    cnpj_result = brazil_spec_provider.cnpj()
    print(cnpj_result)
    print(type(cnpj_result))

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:42:07.665874
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    foo = BrazilSpecProvider()
    foo.cpf()


# Generated at 2022-06-23 20:42:08.572255
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider() != None


# Generated at 2022-06-23 20:42:13.572669
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    '''
    Unit test for method cnpj of class BrazilSpecProvider
    '''
    from mimesis import BrazilSpecProvider
    bsp=BrazilSpecProvider()
    cnpj=bsp.cnpj()
    assert len(cnpj)!=0 and not ' ' in cnpj


# Generated at 2022-06-23 20:42:16.799610
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  from mimesis.enums import Gender
  from mimesis.providers.person import Person

  
  BrazilSpecProvider().cnpj()


# Generated at 2022-06-23 20:42:17.707416
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
   provider = BrazilSpecProvider()
   cnpj = provider.cnpj()
   assert len(cnpj) == 18

# Generated at 2022-06-23 20:42:19.088645
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=12345)
    result = bsp.cnpj()
    assert result == "37.469.621/0001-16", "result: " + result


# Generated at 2022-06-23 20:42:21.565468
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf == "###.###.###-##"


# Generated at 2022-06-23 20:42:29.636373
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    provider = BrazilSpecProvider(seed=97)

    for i in range(0, 10):
        print(f"Patient {i}")
        name = provider.person.full_name(gender=Gender.MALE)
        print(f"Name: {name}")
        cpf = provider.cpf(with_mask=False)
        print(f"CPF: {cpf}")
        address = provider.address.address()
        print(f"Address: {address}")
        print("")


# Generated at 2022-06-23 20:42:31.037492
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()
    print(bp.cnpj())

# Generated at 2022-06-23 20:42:33.656859
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:42:44.896237
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    assert cnpj[:2].isdigit()
    assert cnpj[3:6].isdigit()
    assert cnpj[7:10].isdigit()
    assert cnpj[11:15].isdigit()
    assert cnpj[16:].isdigit()

# Generated at 2022-06-23 20:42:47.172756
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    p = a.cpf(True)


# Generated at 2022-06-23 20:42:52.290951
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br_provider = BrazilSpecProvider()
    cpf = br_provider.cpf()
    print(cpf)
    cnpj = br_provider.cnpj()
    print(cnpj)

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:42:54.148236
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('Testing BrazilSpecProvider.cpf():')
    print(BrazilSpecProvider().cpf())


# Generated at 2022-06-23 20:42:58.670976
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    fn = bsp.cnpj
    assert fn(False) == '92767986000157'
    assert fn(True) == '92.767.986/0001-57'


# Generated at 2022-06-23 20:43:01.238610
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider()
    cpf = p.cpf()
    print(cpf)
    assert len(cpf) == 14


# Generated at 2022-06-23 20:43:06.006041
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of class BrazilSpecProvider."""
    obj = BrazilSpecProvider()
    assert obj.__class__.__name__ == 'BrazilSpecProvider'
    assert isinstance(obj.seed, int)
    assert obj.seed > 0


# Generated at 2022-06-23 20:43:07.379699
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider.cpf(with_mask=True)


# Generated at 2022-06-23 20:43:14.316181
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert (provider.cnpj() == "43.557.587/0001-13") or (provider.cnpj() == "67.713.061/0001-19")
    assert (provider.cpf() == "849.389.099-39") or (provider.cpf() == "022.904.534-45")
    assert isinstance(provider.cnpj(False), str)
    assert isinstance(provider.cpf(False), str)
    assert provider.cnpj(False) == "88086216000142"
    assert provider.cpf(False) == "45782273227"

# Generated at 2022-06-23 20:43:17.175042
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Test BrazilSpecProvider")
    provider = BrazilSpecProvider()
    assert provider.cpf() == '094.002.215-26'
    assert provider.cnpj() == '53.091.163/0001-25'



# Generated at 2022-06-23 20:43:28.137398
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider."""

        # Call method cnpj with with_mask=True
    brazil_provider = BrazilSpecProvider()
    cnpj_with_mask = brazil_provider.cnpj(with_mask=True)
    # Verify if cnpj_with_mask is a string
    assert isinstance(cnpj_with_mask, str)
    # Verify if len(cnpj_with_mask) == 18
    assert len(cnpj_with_mask) == 18

    # Call method cnpj with with_mask=False
    cnpj_without_mask = brazil_provider.cnpj(with_mask=False)
    # Verify if len(cnpj_without_mask) == 14

# Generated at 2022-06-23 20:43:35.592206
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    cnpj_2 = provider.cnpj()
    assert len(cnpj_2) == 18
    assert cnpj != cnpj_2
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14
    cnpj_2 = provider.cnpj(with_mask=False)
    assert len(cnpj_2) == 14
    assert cnpj != cnpj_2




# Generated at 2022-06-23 20:43:37.067238
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider"""
    bs = BrazilSpecProvider()
    assert len(str(bs.cnpj(True))) == 18
    assert len(str(bs.cnpj(False))) == 14


# Generated at 2022-06-23 20:43:40.656455
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    # instantiating brazilSpecProvider
    brazilSpecProvider = BrazilSpecProvider()

    # testing class BrazilSpecProvider
    assert brazilSpecProvider.cpf()
    assert brazilSpecProvider.cnpj()

# Generated at 2022-06-23 20:43:48.142934
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    hash = [60980113000145,85317630000105,91049789000680,44446444444444,11223344556677,11223344556677]
    for i in range(0,10000000):
        cpf = BrazilSpecProvider().cnpj()
        cod = int(cpf.replace('.', '').replace('-', '').replace('/', ''))
        if cod not in hash:
            hash.append(cod)
            print("{}, {}".format(len(hash), cod))



# Generated at 2022-06-23 20:43:51.373439
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    class_object = BrazilSpecProvider()
    assert isinstance(class_object, BrazilSpecProvider)
    assert isinstance(class_object, BaseSpecProvider)
    assert isinstance(class_object, object)


# Generated at 2022-06-23 20:43:57.707618
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("\n========== cnpj ==========")
    print("Test BrazilSpecProvider Class - cnpj method")
    bsp = BrazilSpecProvider()
    print("cnpj(False): ", bsp.cnpj(False))
    print("cnpj(False): ", bsp.cnpj(False))
    print("cnpj(True): ", bsp.cnpj(True))
    print("cnpj(True): ", bsp.cnpj(True))


# Generated at 2022-06-23 20:44:02.050949
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """BaseSpecProvider's add."""
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cnpj(with_mask=True) is not None
    assert brazil_provider.cpf(with_mask=True) is not None

# Generated at 2022-06-23 20:44:13.300643
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for BrazilSpecProvider Class."""
    bs = BrazilSpecProvider()

    def valid_cpf(cpf):
        """Validate cpf."""
        cpf_list = [int(i) for i in cpf]
        soma = 0
        for index, digit in enumerate(cpf_list[:-2]):
            soma += digit * (11 - index)
        resto = soma % 11
        if resto == 1:
            primeiro_dv = 0
        else:
            primeiro_dv = 11 - resto

        if primeiro_dv != cpf_list[9]:
            return False

        soma = 0
        for index, digit in enumerate(cpf_list[:-1]):
            soma += digit * (12 - index)

        resto = som

# Generated at 2022-06-23 20:44:15.535958
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_provider = BrazilSpecProvider(seed=1234567890)
    assert cpf_provider.cpf(False) == "97910872568"



# Generated at 2022-06-23 20:44:23.413284
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    provider.seed(12345)
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    fcnpj = provider.cnpj(with_mask=False)
    assert len(fcnpj) == 14
    assert cnpj == "02.867.533/0001-18"
    assert fcnpj == "02867533000118"
    provider.reset_seed()


# Generated at 2022-06-23 20:44:27.961382
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("\n===========================\nTesting BrazilSpecProvider()")
    braz_spec_provider = BrazilSpecProvider()
    print("braz_spec_provider.cpf() =", braz_spec_provider.cpf())
    print("braz_spec_provider.cnpj() =", braz_spec_provider.cnpj())

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:44:39.988357
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import USASpecProvider
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code


    c = BrazilSpecProvider()
    c.cpf()
    c.cpf(with_mask=False)
    c.cnpj()
    c.cnpj(with_mask=False)
    c.provider_code.random()
    c.provider_code.random(mask='SSSSSSSS-SS')
    c.provider_code.random(mask='SSSSSSSS-SS', codes=['4014', '4015'])
    c.provider_code.iss

# Generated at 2022-06-23 20:44:42.831305
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    assert len(provider.cpf()) == 14
    assert len(provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:44:52.793946
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins.utils import replace_diacritics
    from mimesis.builtins.generic import GenericSpecProvider

    bzp = BrazilSpecProvider()
    gsp = GenericSpecProvider()

    for _ in range(100):
        assert len(bzp.cpf(with_mask=False)) == 11
        assert len(bzp.cpf()) == 14
        assert replace_diacritics(bzp.cpf()) == bzp.cpf()
        assert not bzp.cpf().endswith('-0')
        assert all([gsp.digit() in bzp.cpf()])


# Generated at 2022-06-23 20:44:56.462640
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf1 = BrazilSpecProvider().cpf(with_mask=False)
    cpf2 = BrazilSpecProvider().cpf(with_mask=True)

    assert len(cpf1) == 11
    assert cpf2[3] == '.'
    assert cpf2[7] == '.'
    assert cpf2[11] == '-'

# Generated at 2022-06-23 20:44:58.606891
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18 
    assert cnpj[2] == '.'



# Generated at 2022-06-23 20:45:07.137954
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_cnpj = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(test_cnpj) == 14, 'The expected size of the value for cnpj is 14, not {}'.format(len(test_cnpj))
    assert test_cnpj.isdigit(), 'The value for cnpj should be a number only. Actual value: {}'.format(test_cnpj)
    assert BrazilSpecProvider().cnpj(with_mask=True) != BrazilSpecProvider().cnpj(with_mask=True), 'The cnpj should be random.'


# Generated at 2022-06-23 20:45:11.613896
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.cpf(with_mask=False) == '03182079893'
    assert bsp.cpf() == '031.820.798-93'

# Generated at 2022-06-23 20:45:14.878153
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:45:19.113600
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit tests for the BrazilSpecProvider.cnpj method."""
    base = BrazilSpecProvider()
    assert isinstance(base.cnpj(), str)
    assert len(base.cnpj()) == 18


# Generated at 2022-06-23 20:45:20.724677
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14



# Generated at 2022-06-23 20:45:25.363115
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(False)
    assert len(cpf) == 11
    assert cpf[0] != '0'
    assert cpf.isnumeric() is True


# Generated at 2022-06-23 20:45:27.519437
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    print(cnpj)
    assert cnpj


# Generated at 2022-06-23 20:45:32.801836
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """ Test case for method cnpj.
    """
    bsp = BrazilSpecProvider(seed=42)
    cnpj = bsp.cnpj(with_mask=True)
    bsp2 = BrazilSpecProvider(seed=42)
    cnpj2 = bsp.cnpj(with_mask=True)
    assert cnpj == '82.212.855/0001-53'
    assert cnpj2 == '82.212.855/0001-53'

# Generated at 2022-06-23 20:45:38.059279
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
	from mimesis import Person

	print("\n===========================================================================================")

	# Gets the instance of class BrazilSpecProvider
	data = Person('pt-br')

	# Gets a cnpj with mask
	cnpj = data.cnpj()
	print("cnpj data with mask")
	print(cnpj)
	print("===========================================================================================\n")



# Generated at 2022-06-23 20:45:42.286875
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    assert b.cnpj(with_mask=False) == '59666897000129'

    b = BrazilSpecProvider(seed=42)
    assert b.cnpj(with_mask=True) == '598.934.440-0006'

# Generated at 2022-06-23 20:45:45.340823
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Testing the constructor of class BrazilSpecProvider"""
    seed = "0"
    bsp = BrazilSpecProvider(seed)
    random_numbers = []
    for _ in range(10):
        random_numbers.append(bsp.random.randint(0, 9))
    assert random_numbers == [0, 0, 1, 2, 3, 4, 5, 6, 7, 8]

# Generated at 2022-06-23 20:45:47.709521
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider != None

# Generated at 2022-06-23 20:45:55.741062
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """ 
    Unit test for constructor of class BrazilSpecProvider.
    """
    # test__init__
    sbp = BrazilSpecProvider(seed=1)
    assert sbp.cpf(with_mask=True) == '593.346.743-40'
    assert sbp.cpf(with_mask=False) == '59334674340'

    assert sbp.cnpj(with_mask=True) == '17.685.030/0001-90'
    assert sbp.cnpj(with_mask=False) == '1768503000190'

# Generated at 2022-06-23 20:46:04.621283
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Criação de um objeto da classe BrazilSpecProvider e atribuição para a variável b
    b = BrazilSpecProvider()
    # Primeiro, testa-se a função quando ela recebe como argumento True:
    string = b.cpf(True)
    # Verifica se o tamanho da string é de onze caracteres
    assert len(string) == 11
    # Verifica se o uso da máscara está correto:
    assert string[3] == '.'
    assert string[7] == '.'
    assert string[11] == '-'
    # Verifica se o primeiro dígito verificador está correto:
    soma = 0
    peso = 10

# Generated at 2022-06-23 20:46:08.031810
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.__class__.__bases__[0].__name__ == "BaseSpecProvider"
    # assert provider.__class__.__bases__[1].__name__ == "BaseProvider"


# Generated at 2022-06-23 20:46:10.308642
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf(False)
    assert len(cpf) == 11
    assert cpf.isdigit()


# Generated at 2022-06-23 20:46:20.126368
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    # tests if the length of the string is constant, to avoid errors in the mask
    assert len(provider.cpf(with_mask=True)) == 14, 'Error in the CPF'
    assert len(provider.cpf(with_mask=False)) == 11, 'Error in the CPF'
    assert isinstance(provider.cpf(), str), 'Error in the CPF'
    assert provider.cpf(with_mask=False) != provider.cpf(with_mask=True), 'Error in the CPF'
    assert len(provider.cpf(with_mask=True)) == 14, 'Error in the CPF'



# Generated at 2022-06-23 20:46:26.534433
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    br = BrazilSpecProvider()

    cnpj = br.cnpj(with_mask=False)
    assert len(cnpj) == 14
    
    cnpj2 = br.cnpj()
    assert len(cnpj2) == 18
    assert '-' in cnpj2

# Generated at 2022-06-23 20:46:29.866316
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=True) == '020.566.155-47'
    assert provider.cnpj(with_mask=True) == '42.614.213/0001-12'

# Generated at 2022-06-23 20:46:36.367426
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    provider = BrazilSpecProvider()

    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj == "77.941.844/0001-92"
    assert provider.cnpj(with_mask=True) == "77.941.844/0001-92"

    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert cnpj == "77941844000192"

    cnpj = provider.cnpj(with_mask=False, seed=None)
    assert cnpj == "77941844000192"

    cnpj = provider.cnpj(with_mask=False, seed='seed')
    assert cnpj == "63983247000182"



# Generated at 2022-06-23 20:46:37.950624
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert len(b.cnpj()) == 18

# Generated at 2022-06-23 20:46:45.241849
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider(seed=12345)

    assert brazil_provider.cpf(with_mask=True) == '898.837.951-09'
    assert brazil_provider.cpf(with_mask=False) == '898.837.951-09'

    assert brazil_provider.cnpj(with_mask=True) == '63.373.230/0001-56'
    assert brazil_provider.cnpj(with_mask=False) == '63373230000156'

# Generated at 2022-06-23 20:46:52.348302
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    c = provider.cnpj()
    assert c[0:1] == '0'
    assert c[1:2] == '0'
    assert c[2:3] == '1' or c[2:3] == '2' or c[2:3] == '3' or c[2:3] == '4' or c[2:3] == '5' or c[2:3] == '6' or c[2:3] == '7' or c[2:3] == '8' or c[2:3] == '9'
    assert c[3:4] == '.'

# Generated at 2022-06-23 20:47:01.636376
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # preparing test data
    from mimesis import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.schema import Field, Schema
    import random

    seed = random.randint(1, 100)
    test_quantity = 3
    locale = 'pt-br'
    gender = Gender.MALE
    pattern = [
        Field('cpf'),
    ]

    print('Test start (seed = %s)' % seed)

    # preparing test data
    data = Schema(locale=locale, seed=seed).create(pattern)

    # preparing provider
    provider = BrazilSpecProvider(seed=seed)

    for index, value in enumerate(data):
        if index >= test_quantity:
            break

        test_value = provider.cpf(with_mask=True)



# Generated at 2022-06-23 20:47:04.918412
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    assert obj.cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:47:13.962005
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider.

    :returns: True if method BrazilSpecProvider.cpf returns random cpf with mask, otherwise False and error message.
    :rtype: bool
    """
    # Test when with_mask is True
    try:
        brazil_provider = BrazilSpecProvider()
        cpf = brazil_provider.cpf()
        return len(cpf) == 14, "Wrong cpf: {}".format(cpf)
    except Exception as err:
        return False, "Error when calling method cpf with True: {}".format(err)
    # Test when with_mask is False