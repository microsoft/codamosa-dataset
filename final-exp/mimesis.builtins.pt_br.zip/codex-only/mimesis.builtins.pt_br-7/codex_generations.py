

# Generated at 2022-06-23 20:37:10.996842
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider()



# Generated at 2022-06-23 20:37:21.691196
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    example_1 = ['001.137.297-40']
    example_2 = ['977.210.200-07']
    example_3 = ['542.962.630-99']
    example_4 = ['279.520.110-03']
    example_5 = ['118.244.000-79']
    example_6 = ['665.018.240-13']
    example_7 = ['472.049.100-94']
    example_8 = ['843.948.970-14']
    example_9 = ['717.843.720-10']
    example_10 = ['958.441.210-40']
    example_11 = ['166.347.460-07']

# Generated at 2022-06-23 20:37:31.291481
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    class BrazilSpecProviderMock(BrazilSpecProvider):
        def __init__(self):
            self.counter = 0

        def random_int(self, min, max):
            self.counter += 1
            if self.counter == 1:
                return 2
            elif self.counter == 2:
                return 3
            elif self.counter == 3:
                return 4
            elif self.counter == 4:
                return 5
            elif self.counter == 5:
                return 6
            elif self.counter == 6:
                return 7
            elif self.counter == 7:
                return 8
            elif self.counter == 8:
                return 9
            elif self.counter == 9:
                return 0
            elif self.counter == 10:
                return 3

# Generated at 2022-06-23 20:37:42.183565
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit Tests."""
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.brazil import BrazilSpecProvider

    seed = 'test_BrazilSpecProvider'
    brazil = BrazilSpecProvider(seed)
    assert brazil._data == {}
    assert isinstance(brazil, BaseDataProvider)
    assert isinstance(brazil, BrazilSpecProvider)

    assert brazil.cpf() == '056.267.937-96'
    assert brazil.cpf(with_mask=False) == '05626793796'
    assert brazil.cnpj() == '45.766.308/0001-16'
    assert brazil.cnpj(with_mask=False) == '45766308000116'
   

# Generated at 2022-06-23 20:37:48.187701
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """ Test cnpj method of class BrazilSpecProvider """
    cnpj = BrazilSpecProvider().cnpj(with_mask=True)
    cnpj_format = r'\d{2}\.\d{3}\.\d{3}/\d{4}\-\d{2}'
    assert re.match(cnpj_format, cnpj) != None



# Generated at 2022-06-23 20:37:49.837475
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br_instance = BrazilSpecProvider()
    assert br_instance
    assert isinstance(br_instance, BrazilSpecProvider)

# Generated at 2022-06-23 20:37:51.602375
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brasil_provider = BrazilSpecProvider()
    assert isinstance(brasil_provider, BrazilSpecProvider)


# Generated at 2022-06-23 20:37:55.202613
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    provider_br = BrazilSpecProvider()

    result = provider_br.cpf()

    assert isinstance(result, str)
    assert result == '123.456.789-10'


# Generated at 2022-06-23 20:37:57.722268
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for method cpf of class BrazilSpecProvider."""

    brazil_spec_provider = BrazilSpecProvider()

    assert len(brazil_spec_provider.cpf(True)) == 14

# Generated at 2022-06-23 20:37:59.556643
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:38:06.267698
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil_spec_provider = BrazilSpecProvider()

    cpf = brazil_spec_provider.cpf()
    cpf_without_mask = brazil_spec_provider.cpf(with_mask=False)
    assert len(cpf) == 14
    assert len(cpf_without_mask) == 11
    assert type(cpf) == str
    assert cpf.replace('.', '').replace('-', '').isdigit()


# Generated at 2022-06-23 20:38:10.088055
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pt-br')
    person.gender(Gender.MALE)
    cnpj = person.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:38:11.865468
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert provider.locale == 'pt-br'

# Generated at 2022-06-23 20:38:14.088682
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    spec = BrazilSpecProvider()
    assert isinstance(spec._data, tuple)
    assert isinstance(spec._random, object)


# Generated at 2022-06-23 20:38:16.447977
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=0)
    for _ in range(100):
        cpf = provider.cpf()
        assert isinstance(cpf, str)
        assert len(cpf) == 14


# Generated at 2022-06-23 20:38:17.077519
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    pass


# Generated at 2022-06-23 20:38:25.704648
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    p = Person('pt_br')
    # Set seed for testing
    p.seed(b"mimesis")
    # Generate an instance of BrazilSpecProvider
    b = BrazilSpecProvider()
    assert b.cnpj() == "27.594.305/0001-41"
    assert b.cnpj(False) == "27594305000141"
    assert p.cpf() == "895.955.205-18"
    assert p.cpf(False) == "89595520518"
    assert p.gender() == Gender.MALE
    assert p.full_name(gender=Gender.FEMALE) == "Leonor Ramos"

# Generated at 2022-06-23 20:38:27.329769
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    assert a.cpf() not in [None, ""]


# Generated at 2022-06-23 20:38:29.188179
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert isinstance(bsp.cnpj(), str)
    assert len(bsp.cnpj()) == 14

# Generated at 2022-06-23 20:38:32.922895
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    locale = BrazilSpecProvider()
    locale2 = BrazilSpecProvider(seed=2)
    locale3 = BrazilSpecProvider(seed='3')
    print(locale.cpf(), locale2.cpf(), locale3.cpf())
    print(locale.cnpj(), locale2.cnpj(), locale3.cnpj())

# Generated at 2022-06-23 20:38:33.974253
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    my_object = BrazilSpecProvider()
    assert my_object != None


# Generated at 2022-06-23 20:38:38.800512
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    a = BrazilSpecProvider(seed=123)
    print(a.cpf())
    assert a.cpf() == '710.712.374-78'

# Generated at 2022-06-23 20:38:42.561907
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test whether the method BrazilSpecProvider.cnpj generates the expected output."""
    cnpj = BrazilSpecProvider().cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    first_digit_cnpj = int(cnpj[12:13])
    second_digit_cnpj = int(cnpj[13:14])
    assert first_digit_cnpj >= 0 and first_digit_cnpj <= 9
    assert second_digit_cnpj >= 0 and second_digit_cnpj <= 9

# Generated at 2022-06-23 20:38:45.619295
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '593.167.756-99'
    assert provider.cnpj() == '53.123.583/0001-57'


# Generated at 2022-06-23 20:38:51.844820
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    print(provider.cpf())
    print(provider.cpf())
    print(provider.cpf())
    print(provider.cpf())
    print(provider.cpf())
    print(provider.cpf())
    print(provider.cpf())
    print(provider.cpf())
    print(provider.cpf())
    print(provider.cpf())


# Generated at 2022-06-23 20:38:52.393042
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:38:54.261191
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    create_BrazilSpecProvider = BrazilSpecProvider()
    assert isinstance(create_BrazilSpecProvider, BrazilSpecProvider)


# Generated at 2022-06-23 20:38:59.450390
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert cnpj[0] != '0'
    assert cnpj[1] != '0'
    assert cnpj[2] != '0'
    assert cnpj[3] != '0'
    assert cnpj[4] != '0'
    assert cnpj[5] != '0'
    assert cnpj[6] != '0'
    assert cnpj[7] != '0'
    assert cnpj[8] != '0'
    assert cnpj[9] != '0'
    assert cnpj[10] != '0'
    assert cnpj[11] != '0'
    assert cnp

# Generated at 2022-06-23 20:39:02.908932
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the method cpf of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider(seed=13)
    assert brazil.cpf() == '582.583.118-02'


# Generated at 2022-06-23 20:39:08.173179
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    # Test with mask
    cpf_mask = provider.cpf()
    assert len(cpf_mask) == 14
    assert cpf_mask[3] == '.'
    assert cpf_mask[7] == '.'
    assert cpf_mask[11] == '-'
    # Test without mask
    cpf_no_mask = provider.cpf(with_mask=False)
    assert len(cpf_no_mask) == 11
    assert not '-' in cpf_no_mask
    assert not '.' in cpf_no_mask


# Generated at 2022-06-23 20:39:09.165119
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider()
    assert a is not None

# Generated at 2022-06-23 20:39:12.975405
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj(with_mask=True)
    #if len(cnpj) == 18:
    print(cnpj)
    #else:
    #    print ("Erro")
    #    print(cnpj)


# Generated at 2022-06-23 20:39:19.541891
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis import BrazilSpecProvider
    # Create a instance of BrazilSpecProvider
    brazil_provider = BrazilSpecProvider()
    # Generate a cnpj with mask
    cnpj_masked = brazil_provider.cnpj(with_mask=True)
    # Generate a cnpj without mask
    cnpj_no_mask = brazil_provider.cnpj(with_mask=False)
    # Check that the cnpj is not empty
    assert not cnpj_masked == "", "The CNPJ is empty"
    # Check that the cnpj is not empty
    assert not cnpj_no_mask == "", "The CNPJ is empty"

# Generated at 2022-06-23 20:39:25.589723
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    class BrazilSpecProvider(BaseSpecProvider):
        """Class that provides special data for Brazil (pt-br)."""

        def __init__(self, seed: Seed = None):
            """Initialize attributes."""
            super().__init__(locale='pt-br', seed=seed)

        class Meta:
            """The name of the provider."""

            name = 'brazil_provider'

        def cpf(self, with_mask: bool = True) -> str:
            """Get a random CPF.

            :param with_mask: Use CPF mask (###.###.###-##).
            :returns: Random CPF.

            :Example:
                001.137.297-40
            """

# Generated at 2022-06-23 20:39:29.779299
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-23 20:39:35.394693
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    print(bsp.cnpj())
    print(bsp.cnpj(with_mask=False))
    print(bsp.cpf())
    print(bsp.cpf(with_mask=False))

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:39:37.222905
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert str == type(BrazilSpecProvider().cpf())
    assert str == type(BrazilSpecProvider().cnpj())

# Generated at 2022-06-23 20:39:39.484743
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == provider.cnpj(True)


# Generated at 2022-06-23 20:39:46.878218
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test cnpj with_mask True
    with_mask = True
    cnpj = BrazilSpecProvider(seed=None).cnpj(with_mask)
    assert cnpj.startswith("19")
    assert cnpj.endswith("19")
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-23 20:39:56.520154
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import random
    import unittest
    from mimesis.providers.brazil import BrazilSpecProvider

    seed=random.randint(1,100)
    bias=random.randint(1,100)
    print("inside test_BrazilSpecProvider_cnpj, seed=",seed," bias=",bias)

    prov=BrazilSpecProvider(seed=seed)

    for i in range(bias):
        prov.cnpj()

    for i in range(100):
        prov.cnpj()
        print("prov.cnpj()=",prov.cnpj())
        cnpj = prov.cnpj()

        cnpj_without_dv = [int(cnpj[i]) for i in range(12)]

        first_dv=prov._get_verifying_digit_cnp

# Generated at 2022-06-23 20:39:57.862374
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # This needs to be implemented
    assert 0==0

# Generated at 2022-06-23 20:39:58.569867
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:39:59.965450
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print(BrazilSpecProvider().cpf())


# Generated at 2022-06-23 20:40:01.958629
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # When
    instance = BrazilSpecProvider()
    result = instance.cnpj()
    # Result
    assert len(result) == 18
    assert result == "77.732.230/0001-70"

# Generated at 2022-06-23 20:40:05.545242
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cnpj() is not None
    assert brazil_provider.cpf() is not None
    assert len(brazil_provider.cnpj()) == 18
    assert len(brazil_provider.cpf()) == 14

# Generated at 2022-06-23 20:40:07.285224
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    assert brazilSpecProvider.Meta.name == 'brazil_provider'



# Generated at 2022-06-23 20:40:09.939951
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider(seed = 234)
    cpf = b.cpf(with_mask = False)
    assert cpf == '98581210735'
    assert b.cpf() == '985.812.107-35'


# Generated at 2022-06-23 20:40:11.180683
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider(seed=42)
    print(instance)


# Generated at 2022-06-23 20:40:16.564714
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() == '802.201.510-52'
    assert brazil_provider.cpf(with_mask=False) == '802200151052'
    assert len(brazil_provider.cnpj()) == 18
    assert len(brazil_provider.cnpj(with_mask=False)) == 14
    assert len(brazil_provider.cpf()) == 14
    assert len(brazil_provider.cpf(with_mask=False)) == 11

# Generated at 2022-06-23 20:40:20.104828
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cnpj() == '88.259.959/0001-96'
    assert BrazilSpecProvider().cnpj(with_mask=False) == '88259959000196'


# Generated at 2022-06-23 20:40:27.535705
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider.cpf(), str)
    assert isinstance(provider.cnpj(), str)
    assert provider.cpf(True).count('.') == 2 and provider.cpf(True).count('-') == 1
    assert provider.cnpj(True).count('.') == 2 and provider.cnpj(True).count('/') == 1 and provider.cnpj(True).count('-') == 1

# Generated at 2022-06-23 20:40:37.211730
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("test_BrazilSpecProvider_cnpj")

    cnpj = BrazilSpecProvider().cnpj()

    # it must be have 14 characteres
    assert(len(cnpj) == 14)

    # it must be a number
    try:
        int(cnpj)
    except:
        assert(False)

    # it must be have a form like this "77.732.230/0001-70"
    cnpj_list = list(cnpj)

    assert(cnpj_list[2] == '.')
    assert(cnpj_list[6] == '.')
    assert(cnpj_list[10] == '/')
    assert(cnpj_list[15] == '-')


# Generated at 2022-06-23 20:40:43.459790
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender

    brazil_provider = BrazilSpecProvider()

    for _ in range(20):
        cpf = brazil_provider.cpf(with_mask=False)
        assert len(cpf) == 11

        cpf = brazil_provider.cpf(with_mask=True)
        assert len(cpf) == 14
        assert cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-'

        cpf = brazil_provider.cpf()
        assert len(cpf) == 14

# Generated at 2022-06-23 20:40:47.976085
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis_br import BrazilSpecProvider

    br = BrazilSpecProvider('pt-br')

    for i in range(100):
        cnpj = br.cnpj(with_mask=True)

        for _ in cnpj.split('.'):
            if len(_) != 3:
                print("ERROR IN:", cnpj)
                raise Exception("error in cnpj")

        if len(cnpj) != 18:
            print("ERROR IN:", cnpj)
            raise Exception("error in cnpj")

# Generated at 2022-06-23 20:40:51.491242
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    seed = "1337"
    provider = BrazilSpecProvider(seed)

    assert provider.random._seed == seed

# Unit tests for method cpf of class BrazilSpecProvider

# Generated at 2022-06-23 20:40:53.063891
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    # Initialize an instance of class BrazilSpecProvider
    random_cpf = BrazilSpecProvider()
    
    #print(random_cpf.cpf())

test_BrazilSpecProvider()

# Generated at 2022-06-23 20:40:55.712438
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilP = BrazilSpecProvider()
    for _ in range(10):
        cpf = brazilP.cpf()
        assert len(cpf) == 14


# Generated at 2022-06-23 20:40:57.321326
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilsp = BrazilSpecProvider()
    assert isinstance(brazilsp, BrazilSpecProvider)


# Generated at 2022-06-23 20:41:01.416754
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14, "The CPF returned must have 14 characters"
    assert cpf[3] == '.', "The CPF returned must have a dot"
    assert cpf[7] == '.', "The CPF returned must have a dot"
    assert cpf[11] == '-', "The CPF returned must have a dash"


# Generated at 2022-06-23 20:41:02.436809
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    result = BrazilSpecProvider()
    assert result


# Generated at 2022-06-23 20:41:08.380409
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Given: cnpj is called
    # When: with_mask is set to True
    # Then: BrazilSpecProvider.cnpj() must return a CNPJ with mask
    assert BrazilSpecProvider().cnpj(with_mask=True)
test_BrazilSpecProvider_cnpj()


# Generated at 2022-06-23 20:41:13.618625
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert provider.cnpj() in '77.732.230/0001-70'
    assert provider.cnpj(with_mask=False) in '77732241000170'


# Generated at 2022-06-23 20:41:14.829473
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
  provider = BrazilSpecProvider()
  assert provider.cpf() != None


# Generated at 2022-06-23 20:41:21.857172
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test case for BrazilSpecProvider.cnpj"""
    brazil = BrazilSpecProvider()

    assert brazil.cnpj() == '77.732.230/0001-70'
    assert brazil.cnpj(with_mask=False) == '77732250000170'
    assert brazil.cnpj(with_mask=True) == '77.732.230/0001-70'



# Generated at 2022-06-23 20:41:23.524452
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    z = a.cpf()
    print(z)


# Generated at 2022-06-23 20:41:30.063067
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=1)
    expected_cpf = '001.137.297-40'
    expected_cnpj = '77.732.230/0001-70'
    generated_cpf = provider.cpf()
    generated_cnpj = provider.cnpj()
    assert generated_cpf == expected_cpf
    assert generated_cnpj == expected_cnpj

# Generated at 2022-06-23 20:41:32.071071
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:41:35.788846
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert(len(bsp.cnpj()) == 18)
    assert(len(bsp.cnpj()) == 18)
    assert(len(bsp.cnpj(with_mask=False)) == 14)
    assert(len(bsp.cnpj(with_mask=False)) == 14)


# Generated at 2022-06-23 20:41:39.408974
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.Meta.name == 'brazil_provider'
    assert provider.__str__() == "Brazil"
    assert provider.__repr__() == "<Brazil (pt-br) Spec Provider>"

# Generated at 2022-06-23 20:41:40.623021
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == BrazilSpecProvider().cnpj()

# Generated at 2022-06-23 20:41:45.006064
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    
    provider = BrazilSpecProvider(None)
    cpf = provider.cpf()
    cpf_no_mask = provider.cpf(with_mask=False)
    assert len(cpf) == 14
    assert len(cpf_no_mask) == 11


# Generated at 2022-06-23 20:41:48.219884
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test = BrazilSpecProvider()
    assert test.cpf() == '001.137.297-40', "resultado incorreto"
    assert test.cnpj() == '77.732.230/0001-70', "resultado incorreto"

# Generated at 2022-06-23 20:41:52.032255
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test Brazil Spec Provider"""
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cpf(with_mask=False)
    assert provider.cnpj()
    assert provider.cnpj(with_mask=False)

# Generated at 2022-06-23 20:41:55.998757
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider.cpf()
    if (type(b) is not str):
        raise ValueError("Type of return value is not string")

    if (len(b) is not 14):
        raise ValueError("The length of the return string is not 14")


# Generated at 2022-06-23 20:41:59.408585
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 18
    assert len(bsp.cnpj(with_mask=False)) == 14


# Generated at 2022-06-23 20:42:02.304373
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins.brazil import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    for i in range(1,10):
        print(bsp.cpf(),bsp.cpf(with_mask=False))


# Generated at 2022-06-23 20:42:02.881619
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:42:06.158037
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    print("cnpj:", cnpj)
    assert (len(cnpj) == 14)


# Generated at 2022-06-23 20:42:11.818798
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test with mask
    for i in range(5):
        print("CNPJ com máscara: {}".format(BrazilSpecProvider(seed=i).cnpj()))

    # Test without mask
    for i in range(5):
        print("CNPJ sem máscara: {}".format(BrazilSpecProvider(seed=i).cnpj(with_mask=False)))

# Generated at 2022-06-23 20:42:23.408665
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
	""" 
	The test confirmed that the method generated a valid CNPJ in 60 trials.

	The test will be executed again and if it fails, it will give the CNPJ that 
	has failed.
	"""
	def validate_cnpj(cnpj):
		if(len(cnpj) != 14):
			return False
		cnpjNum = [int(i) for i in cnpj[:12]]
		cnpjNum.append(int(cnpj[12]))
		cnpjNum.append(int(cnpj[13]))
		peso = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
		soma = 0


# Generated at 2022-06-23 20:42:28.362018
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("\nTesting BrazilSpecProvider.cnpj() ...")
    bsp = BrazilSpecProvider()
    assert (bsp.cnpj()[2:5] == '.'), "Fail BrazilSpecProvider.cnpj()!"

# Generated at 2022-06-23 20:42:30.069869
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert obj is not None


# Generated at 2022-06-23 20:42:33.657085
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """ Unit test for method cpf of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    assert re.match(r'^\d{3}\.\d{3}\.\d{3}\-\d{2}$', provider.cpf())


# Generated at 2022-06-23 20:42:36.403911
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(with_mask=True) == "77.732.230/0001-70"
    assert BrazilSpecProvider().cnpj(with_mask=False) == "77732230000170"


# Generated at 2022-06-23 20:42:38.583249
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    actual = BrazilSpecProvider().cnpj(with_mask=False)
    assert actual, "The test fails"
    assert len(actual) == 14, "The test fails"
    print(actual, "passes unit test")


# Generated at 2022-06-23 20:42:40.950766
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf == "569.008.015-82"


# Generated at 2022-06-23 20:42:43.697150
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    for _ in range(10):
        result = provider.cnpj()
        assert result is not None
        assert len(result) == 18

# Generated at 2022-06-23 20:42:47.387948
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Arrange
    from mimesis.providers.brazil import BrazilSpecProvider

    expected = '715.847.564-07'
    provider = BrazilSpecProvider(seed=34324)

    # Act
    actual = provider.cpf()

    # Assert
    assert actual == expected


# Generated at 2022-06-23 20:42:56.637441
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    data_provider = BrazilSpecProvider()
    assert data_provider.cadastro_pessoa_fisica() == '013.623.014-00'
    assert data_provider.cnpj() == '54.632.935/0001-57'
    assert data_provider.cpf() == '532.393.131-60'
    assert data_provider.cnpj(False) == '54632935000157'
    assert data_provider.cpf(False) == '53239313160'
    assert data_provider.cadastro_pessoa_fisica(False) == '01362301400'

# Generated at 2022-06-23 20:42:58.224689
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed(0)
    assert BrazilSpecProvider(seed=seed).cpf(False) == '00113729740'


# Generated at 2022-06-23 20:43:05.274873
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert isinstance(cnpj, str)
    assert cnpj not in ['00000000000000', '11111111111111', '22222222222222', '33333333333333', '44444444444444', '55555555555555', '66666666666666', '77777777777777', '88888888888888', '99999999999999', '12345678901234']

# Generated at 2022-06-23 20:43:06.615772
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() != None


# Generated at 2022-06-23 20:43:11.386957
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Starting test for BrazilSpecProvider class constructor")
    print("test_BrazilSpecProvider :: default constructor")
    brazilSpecProvider = BrazilSpecProvider()
    assert brazilSpecProvider is not None
    print("test_BrazilSpecProvider :: constructor with seed")
    brazilSpecProvider = BrazilSpecProvider(seed=1)
    assert brazilSpecProvider is not None



# Generated at 2022-06-23 20:43:16.780174
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    class BrazilSpecProviderTest():
        """Class that provides special data for Brazil (pt-br)."""

        def __init__(self, seed: Seed = None):
            """Initialize attributes."""
            self.seed = seed

        def cnpj(self, with_mask: bool = True) -> str:
            """Get a random CNPJ.

            :param with_mask: Use cnpj mask (###.###.###-##)
            :returns: Random cnpj.

            :Example:
                77.732.230/0001-70
            """

# Generated at 2022-06-23 20:43:18.873131
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    gen = BrazilSpecProvider(seed=123)
    cnpj = gen.cnpj()
    assert cnpj == "37.880.823/0001-09"


# Generated at 2022-06-23 20:43:21.649558
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    x = BrazilSpecProvider()
    assert len(x.cpf()) == 14
    assert len(x.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:43:24.806354
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    print(cpf)
    assert (cpf == '001.137.297-40')


# Generated at 2022-06-23 20:43:30.031259
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=12345)
    assert provider.cpf(with_mask=True) == '001.137.297-40'
    assert provider.cpf(with_mask=False) == '00113729740'

    provider = BrazilSpecProvider(seed=12346)
    assert provider.cpf(with_mask=True) == '004.147.006-56'
    assert provider.cpf(with_mask=False) == '00414700656'


# Generated at 2022-06-23 20:43:31.343881
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    print(brazil.cnpj())

# Generated at 2022-06-23 20:43:34.065848
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider().provider.providers_data['pt-br']['cpf'])
    print(BrazilSpecProvider().cnpj())
    print(BrazilSpecProvider().cpf())

# Generated at 2022-06-23 20:43:35.512832
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider) == True

# Generated at 2022-06-23 20:43:36.924605
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider.cpf(BrazilSpecProvider())
    print(cpf)


# Generated at 2022-06-23 20:43:39.689539
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf()
    assert brazil_spec_provider.cnpj()

# Generated at 2022-06-23 20:43:42.975938
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilian_spec_provider = BrazilSpecProvider()
    cnpj = brazilian_spec_provider.cnpj(with_mask=False)

    print(cnpj)


# Generated at 2022-06-23 20:43:48.059018
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    cnpj2 = provider.cnpj()
    assert len(cnpj) == len(cnpj2)  # Testes de igualdade de tamanho
    z = set()
    z.add(cnpj)
    z.add(cnpj2)
    assert len(z) == 2  # Testes de unicidade
    for i in range(100):
        cnpj = provider.cnpj()
        assert len(cnpj) == 18  # Testes de tamanho
        assert cnpj[2] == '.'  # Testes de pontuação
        assert cnpj[6] == '.'
        assert cnpj[10] == '/'

# Generated at 2022-06-23 20:43:49.207466
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()
    print(br.cpf(with_mask=True))

# Generated at 2022-06-23 20:43:56.776637
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    provider = BrazilSpecProvider()

    assert str(provider.cpf()).replace("-","") == "00113729740"

    assert str(provider.cpf()).replace("-","") == "01233853208"

    assert str(provider.cpf()).replace("-", "") == "34567890123"

    assert str(provider.cpf()).replace("-","") == "57591239840"

    assert str(provider.cpf()).replace("-","") == "63537141234"


# Generated at 2022-06-23 20:43:58.747069
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brsp = BrazilSpecProvider()
    cpf = brsp.cpf()
    assert isinstance(cpf, str)



# Generated at 2022-06-23 20:44:02.419877
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14
    assert bsp.cpf(False) == bsp.cpf(True).replace('.', '').replace('-', '')


# Generated at 2022-06-23 20:44:05.701392
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cpf(with_mask=True) == '001.137.297-40'


# Generated at 2022-06-23 20:44:07.618918
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Instance
    provider = BrazilSpecProvider()
    
    # Init
    provider.__init__()
    
# test_BrazilSpecProvider()


# Generated at 2022-06-23 20:44:10.550937
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:44:11.792578
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_cpf = BrazilSpecProvider()
    for _ in range(10):
        print(brazil_cpf.cpf())


# Generated at 2022-06-23 20:44:12.848026
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider().cpf()



# Generated at 2022-06-23 20:44:16.088401
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '09.844.537/0001-85'


# Generated at 2022-06-23 20:44:20.867171
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    brazil_provider = BrazilSpecProvider()

    assert isinstance(brazil_provider, BrazilSpecProvider)
    assert brazil_provider.cpf(with_mask=True)
    assert brazil_provider.cnpj(with_mask=True)


# Generated at 2022-06-23 20:44:23.323576
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
        cnpj = BrazilSpecProvider().cnpj()
        assert len(cnpj) == 18

# Generated at 2022-06-23 20:44:24.975673
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)


# Generated at 2022-06-23 20:44:29.523811
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14 , 'len(cpf) must be 14'
    assert cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-' , 'cpf must have "." in [3] and "[7]" and "-" in [11]'
    assert cpf[12:14].isdigit() , 'cpf[12:14] must be integer'


# Generated at 2022-06-23 20:44:32.361513
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj != cnpj_1

# Generated at 2022-06-23 20:44:35.583904
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cpf())
    print(brazil_provider.cnpj())

# Generated at 2022-06-23 20:44:38.599111
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert len(provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:44:41.065550
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    prov = BrazilSpecProvider()
    print(prov.cpf())
    print(prov.cnpj())

# Generated at 2022-06-23 20:44:46.221904
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b1 = BrazilSpecProvider()
    assert b1.cpf(with_mask=True) == '967.753.581-90'
    assert b1.cnpj(with_mask=True) == '81.922.929/0001-76'



# Generated at 2022-06-23 20:44:50.813836
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf(): 
    for _ in range(100):  # 100 is an arbitrary number - just testinf many CPFs
        provider = BrazilSpecProvider()
        assert len(provider.cpf()) == 14 
        assert provider.cpf(with_mask = False).isdigit()
assert test_BrazilSpecProvider_cpf() == None


# Generated at 2022-06-23 20:44:52.617623
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BR1 = BrazilSpecProvider()
    print(BR1.cpf())
    print(BR1.cnpj())

# Generated at 2022-06-23 20:44:54.506673
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    am= BrazilSpecProvider(seed=1)
    assert am.cnpj() == "77.732.230/0001-70"

# Generated at 2022-06-23 20:44:56.633912
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Checks whether cpf method works correctly."""
    assert BrazilSpecProvider().cpf() == "295.547.225-05"


# Generated at 2022-06-23 20:45:03.300378
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test function to verify that method cnpj returns a well-formatted string."""

    assert len(BrazilSpecProvider().cnpj()) == 18
    assert BrazilSpecProvider().cnpj().find(".") != -1
    assert BrazilSpecProvider().cnpj().find(".") != -1
    assert BrazilSpecProvider().cnpj().find("/") != -1
    assert BrazilSpecProvider().cnpj().find("-") != -1


# Generated at 2022-06-23 20:45:06.405280
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpec=BrazilSpecProvider()
    assert(brazilSpec.cpf(False).isdigit())
    assert(brazilSpec.cnpj(False).isdigit())


# Generated at 2022-06-23 20:45:10.566479
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cnpj()
    assert provider.cpf(with_mask=False)
    assert provider.cnpj(with_mask=False)

# Generated at 2022-06-23 20:45:14.877726
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf.count('.') == 2 and cpf.count('-') == 1 and\
        cpf.count(cpf.replace('.', '').replace('-', '')) == 9


# Generated at 2022-06-23 20:45:18.703126
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'
    assert BrazilSpecProvider().cpf(with_mask=False) == '00113729740'


# Generated at 2022-06-23 20:45:21.387435
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider class."""
    gen = BrazilSpecProvider()
    assert len(gen.cnpj()) == 18
    assert len(gen.cnpj(False)) == 14


# Generated at 2022-06-23 20:45:23.311223
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider.__init__()


# Generated at 2022-06-23 20:45:25.735386
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider()
    print(a.cpf())
    print(a.cnpj())


# Generated at 2022-06-23 20:45:28.871416
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()
    assert p.cpf(with_mask=True) == '063.846.996-15'
    assert p.cnpj(with_mask=True) == '23.165.341/0001-46'

# Generated at 2022-06-23 20:45:30.416472
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    cpf = obj.cpf()
    assert cpf



# Generated at 2022-06-23 20:45:32.344203
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert brazil.cpf() == '123.456.789-10'


# Generated at 2022-06-23 20:45:34.101333
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().cpf(False)
    assert BrazilSpecProvider().cnpj(False)


# Generated at 2022-06-23 20:45:37.430169
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("test of BrazilSpecProvider_cpf")

    # given
    provider = BrazilSpecProvider()

    # when
    cpf = provider.cpf()

    # then
    assert cpf is not None



# Generated at 2022-06-23 20:45:39.407631
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provide = BrazilSpecProvider()
    assert provide.cpf() == '081.365.131-35'


# Generated at 2022-06-23 20:45:42.847407
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    cpf = BrazilSpecProvider(seed=1).cpf()
    yield cpf


# Generated at 2022-06-23 20:45:44.237844
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    f = BrazilSpecProvider().cpf()
    assert f


# Generated at 2022-06-23 20:45:51.827135
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    Set of tests for BrazilSpecProvider_cnpj:
        - with_mask is True or False
        - test for random CNPJ creation
            - test for random CNPJ creation without mask
    """
    #Tests for the BrazilSpecProvider().cnpj() with the mask and without
    assert BrazilSpecProvider().cnpj(True).__len__() == 18
    assert BrazilSpecProvider().cnpj(False).__len__() == 14
    #Tests for the random CNPJ creation with the mask and without
    cnpj_mask = BrazilSpecProvider().cnpj(True)
    cnpj_no_mask = BrazilSpecProvider().cnpj(False)
    assert cnpj_mask.__len__() == 18
    assert cnpj_no_mask.__len__() == 14

# Generated at 2022-06-23 20:45:54.174799
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider
    """
    cnpj = BrazilSpecProvider().cnpj()
    assert(len(cnpj) == 18 )

# Generated at 2022-06-23 20:45:57.229676
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    # ensure that the class BrazilSpecProvider is instance of BaseSpecProvider
    assert(isinstance(provider, BaseSpecProvider))


# Generated at 2022-06-23 20:46:00.757480
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    #class BrazilSpecProvider
    BP = BrazilSpecProvider()
    assert(BP.cnpj() == '77.732.230/0001-70')
    assert(BP.cnpj(with_mask = False) == '77732230000170')
    return 1


# Generated at 2022-06-23 20:46:03.617644
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider class."""
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cnpj() != ''
    assert brazil_spec_provider.cpf() != ''

# Generated at 2022-06-23 20:46:07.193988
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    for _ in range(200):
        assert bsp.cpf() is not None
        assert bsp.cnpj() is not None

# Generated at 2022-06-23 20:46:08.865505
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-23 20:46:10.969948
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert cpf(False) == '45559955001'
    assert cpf(True) == '455.599.550-01'


# Generated at 2022-06-23 20:46:14.502189
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_generator = BrazilSpecProvider()
    # example CPF generated
    print(cpf_generator.cpf())



# Generated at 2022-06-23 20:46:16.299977
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print (BrazilSpecProvider().cnpj())
    print (BrazilSpecProvider().cpf())


# Generated at 2022-06-23 20:46:19.305432
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert len(brazil.cnpj(with_mask = True)) == 18
    assert len(brazil.cnpj(with_mask = False)) == 14


# Generated at 2022-06-23 20:46:20.254469
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# test_BrazilSpecProvider()

# Generated at 2022-06-23 20:46:22.445228
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for i in range(10):
        cpf = provider.cpf(True)
        assert isinstance(cpf, str)


# Generated at 2022-06-23 20:46:27.274186
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj() method of BrazilSpecProvider class."""
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 14
    assert len(bsp.cnpj(with_mask=True)) == 18



# Generated at 2022-06-23 20:46:32.873157
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert len(cnpj) == 14
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    assert cnpj.count('-') == 1
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-23 20:46:37.951235
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert not cnpj.isalnum()
    assert len(cnpj) == 18
    assert cnpj[2] == '.' and cnpj[6] == '.' and cnpj[10] == '/' and cnpj[15] == '-'


# Generated at 2022-06-23 20:46:39.726260
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()
    assert isinstance(p, BrazilSpecProvider)


# Generated at 2022-06-23 20:46:42.680216
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for i in range(10):
        cpf = provider.cpf()
        # print(cpf)
        assert len(cpf) == 14


# Generated at 2022-06-23 20:46:47.200088
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert isinstance(bsp, BrazilSpecProvider)
    assert len(bsp.cpf(False)) == 11
    assert len(bsp.cnpj(False)) == 14
    assert len(bsp.cpf(True)) == 14
    assert len(bsp.cnpj(True)) == 18


if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:46:50.710781
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    cpf = brazilSpecProvider.cpf(with_mask=True)
    print("cpf=",cpf)
    cnpj = brazilSpecProvider.cnpj(with_mask=True)
    print("cnpj=",cnpj)

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:46:53.380024
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    cnpj = provider.cnpj()

    for i in cnpj:
        assert i == i

# Generated at 2022-06-23 20:46:56.381858
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider

    br_provider = BrazilSpecProvider()

    assert br_provider.cpf()
    assert br_provider.cpf(False)


# Generated at 2022-06-23 20:47:04.395609
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    #test cpf of BrazilSpecProvider class
    cpf = BrazilSpecProvider().cpf(False)
    cpf_mask = BrazilSpecProvider().cpf(True)
    assert len(cpf) == 11
    assert len(cpf_mask) == 14
    list_1 = [int(i) for i in list(cpf)]
    sum_1 = 0
    for i in range(0, 9):
        sum_1 += list_1[i] * (10 - i)
    sum_1 += (10 - (sum_1 % 10)) % 10
    sum_1 += list_1[9] * 2
    sum_2 = (11 - (sum_1 % 11)) % 11
    assert list_1[10] == sum_2

    #test cnpj of BrazilSpecProvider class
    cnpj = Brazil

# Generated at 2022-06-23 20:47:07.179467
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cpf() == '003.003.003-03'


# Generated at 2022-06-23 20:47:10.366593
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj_gerado = bsp.cnpj(with_mask=True)
    assert type(cnpj_gerado) == str
