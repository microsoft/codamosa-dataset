

# Generated at 2022-06-23 20:37:12.999495
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Create a BrazilSpecProvider instance
    br = BrazilSpecProvider()
    # result = br.cnpj()
    result = br.cpf()
    print(result)

# Generated at 2022-06-23 20:37:21.642931
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    br = BrazilSpecProvider()
    assert br.cnpj() == br.cnpj(False)
    assert len(br.cnpj()) == 18
    assert len(br.cnpj(False)) == 14
    assert br.cnpj() != br.cnpj(False)
    # check whether a sample contains a number
    assert len(br.cnpj(False).replace('.', '').replace('/', '').replace('-', '')) == 14
    assert br.cnpj() != br.cnpj()


# Generated at 2022-06-23 20:37:22.780917
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider


# Generated at 2022-06-23 20:37:30.582656
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pt = BrazilSpecProvider()
    assert pt is not None
    assert pt.cpf() is not None
    assert pt.cnpj() is not None

# # Unit test for method cpf of class BrazilSpecProvider
# def test_cpf():
#     pt = BrazilSpecProvider()
#     result = pt.cpf()
#     assert result is not None
#     assert type(result) is str
#     result = pt.cpf(with_mask=False)
#     assert result is not None
#     assert type(result) is str

# # Unit test for method cnpj of class BrazilSpecProvider
# def test_cnpj():
#     pt = BrazilSpecProvider()
#     result = pt.cnpj()
#     assert result is not None
#     assert type(result) is str
#     result =

# Generated at 2022-06-23 20:37:34.334967
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider's cnpj method."""
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(with_mask=False)
    assert isinstance(cnpj, str) and len(cnpj) == 14


# Generated at 2022-06-23 20:37:35.677330
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()



# Generated at 2022-06-23 20:37:41.409137
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method BrazilSpecProvider.cnpj"""
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert '.' in cnpj
    assert '/' in cnpj
    assert '-' in cnpj


# Generated at 2022-06-23 20:37:49.588691
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14, 'length is not right'

    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11, 'length is not right'

    cpf = provider.cpf(with_mask=False)
    assert cpf[3] == '.', 'position 3 is not right'
    assert cpf[7] == '.', 'position 7 is not right'
    assert cpf[11] == '-', 'position 11 is not right'



# Generated at 2022-06-23 20:37:59.680556
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    result_1 = BrazilSpecProvider().cnpj()

    result_2 = BrazilSpecProvider().cnpj(False)
    assert result_2.replace('.', '').replace('-', '').replace('/', '').isdigit()

    person = Person(BrazilSpecProvider())

    result_3 = person.cnpj()
    result_4 = person.cnpj(gender=Gender.FEMALE)
    result_5 = person.cnpj(gender=Gender.MALE)

    result_6 = person.cnpj(with_mask=False)

    print(result_1)
    print(result_2)
    print(result_3)
    print(result_4)

# Generated at 2022-06-23 20:38:05.106826
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider"""
    # Arrange
    cpf = BrazilSpecProvider()
    
    # Act
    data = cpf.cpf()
    
    # Assert
    assert len(data) == 14
    assert data[3] == '.'
    assert data[7] == '.'
    assert data[11] == '-'


# Generated at 2022-06-23 20:38:07.707344
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    print(b.cpf())
    assert len(b.cpf()) == 14


# Generated at 2022-06-23 20:38:13.561309
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    output1 = bsp.cpf()
    output2 = bsp.cpf(with_mask=False)
    assert output1 is not None
    assert output2 is not None
    assert isinstance(output1, str)
    assert output1[3] == "."
    assert output1[7] == "."
    assert output1[11] == "-"
    assert output2 is not output1
    assert len(output2) == 11
    assert len(output1) == 14


# Generated at 2022-06-23 20:38:14.456328
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider



# Generated at 2022-06-23 20:38:15.282130
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    pass


# Generated at 2022-06-23 20:38:17.920487
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Sample cpf
    assert BrazilSpecProvider().cpf() == "056.972.593-70"
    # Sample cpf without mask
    assert BrazilSpecProvider().cpf(False) == "56803915596"


# Generated at 2022-06-23 20:38:26.628002
# Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-23 20:38:29.522785
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:38:32.726159
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider"""

    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider as BrazilSpecProviderEnum

    cnpj_masked = BrazilSpecProvider().cnpj()
    cnpj_unmasked = BrazilSpecProvider().cnpj(with_mask=False)

# Generated at 2022-06-23 20:38:36.949724
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for BrazilSpecProvider.cpf()."""
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf(with_mask=False)
    assert len(cpf) == 11


# Generated at 2022-06-23 20:38:47.216699
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    import pytest
    
    # Must fail without mask
    bp             = BrazilSpecProvider()
    invalid_cnpj   = bp.cnpj(with_mask = False)
    assert len(invalid_cnpj) != 14, 'CNPJ must have 14 characters'

    # Must fail with mask
    invalid_cnpj   = bp.cnpj(with_mask = True)
    assert len(invalid_cnpj) != 18, 'CNPJ must have 18 characters'
    
    # BrazilSpecProvider(seed = 1)
    bp             = BrazilSpecProvider(seed = 1)

    # CNPJ must have 14 characters
    cnpj           = bp.cnpj(with_mask = False)

# Generated at 2022-06-23 20:38:47.974108
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:38:49.534144
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for constructor of class BrazilSpecProvider."""
    assert BrazilSpecProvider.Meta.name == 'brazil_provider'

# Generated at 2022-06-23 20:38:51.599599
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:38:56.661139
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    test_cnpj = bsp.cnpj()
    assert len(test_cnpj) == 18
    assert test_cnpj[2] == '.'
    assert test_cnpj[6] == '.'
    assert test_cnpj[10] == '/'
    assert test_cnpj[15] == '-'
    assert test_cnpj[-2].isnumeric()
    assert test_cnpj[-1].isnumeric()


# Generated at 2022-06-23 20:39:01.689324
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    print(bsp.cpf())
    print(bsp.cpf())
    print(bsp.cpf())
    print(bsp.cpf(False))
    print(bsp.cpf(False))
    print(bsp.cpf(False))


# Generated at 2022-06-23 20:39:04.340167
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=12345)
    cpf = provider.cpf()
    assert cpf == '941.412.830-85'

# Generated at 2022-06-23 20:39:08.911327
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brasil_spec_provider = BrazilSpecProvider()
    assert len(brasil_spec_provider.cpf(True)) == 14
    assert len(brasil_spec_provider.cpf(True).split('-')) == 2
    assert len(brasil_spec_provider.cpf(True).split('.')) == 3
    assert len(brasil_spec_provider.cpf(False)) == 11



# Generated at 2022-06-23 20:39:11.609208
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.Meta.name == "brazil_provider"


# Generated at 2022-06-23 20:39:16.716125
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    assert (brazilSpecProvider.__str__() == "BrazilSpecProvider()")
    assert (brazilSpecProvider.__class__.__name__ == "BrazilSpecProvider")


# Generated at 2022-06-23 20:39:20.529859
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    data = provider.cpf()
    assert data.count(".") == 2, "Dots are incorrect"
    assert data.count("-") == 1, "Hypen is missing"
    assert len(data) == 14, "Length is incorrect"


# Generated at 2022-06-23 20:39:28.016548
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.random import Random
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis.typing import Seed

    r = Random()

    r.add_provider(BrazilSpecProvider)

    # Tests
    cpf = r.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'

    cpf = r.cpf(with_mask=False)
    assert isinstance(cpf, str)
    assert len(cpf) == 11
    assert cpf.isdigit()



# Generated at 2022-06-23 20:39:32.461679
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    b = BrazilSpecProvider()

    for x in range(10):
        i = b.cpf()

    for x in range(10):
        i = b.cpf(with_mask=False)

    for x in range(10):
        i = b.cpf(gender=Gender.MALE)

    for x in range(10):
        i = b.cpf(gender=Gender.FEMALE)


# Generated at 2022-06-23 20:39:36.358694
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert (provider.cpf() == provider.cpf(with_mask=True))
    assert (provider.cnpj() == provider.cnpj(with_mask=True))

# Generated at 2022-06-23 20:39:38.591478
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()
    BrazilSpecProvider('cpf')
    BrazilSpecProvider('cpf', 'cnpj')
    BrazilSpecProvider('cnpj', 'cpf')

# Generated at 2022-06-23 20:39:43.596575
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_provider = BrazilSpecProvider()
    assert test_provider._locale == 'pt-br'
    assert hasattr(test_provider, 'cpf')
    assert hasattr(test_provider, 'cnpj')
    test_provider.cpf()
    test_provider.cnpj()

# Generated at 2022-06-23 20:39:45.074369
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.__name__ == "BrazilSpecProvider"

# Generated at 2022-06-23 20:39:56.072650
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Initialise class
    bsp = BrazilSpecProvider()

    #  Test method cpf
    assert(len(bsp.cpf()) == 14)
    assert(bsp.cpf()[3] == '.')
    assert(bsp.cpf()[7] == '.')
    assert(bsp.cpf()[11] == '-')

    #  Test method cpf with mask
    assert(len(bsp.cpf(True)) == 14)
    assert(bsp.cpf(True)[3] == '.')
    assert(bsp.cpf(True)[7] == '.')
    assert(bsp.cpf(True)[11] == '-')

    # Test method cpf without mask
    assert(len(bsp.cpf(False)) == 11)

# Generated at 2022-06-23 20:40:05.742724
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # cnpj(with_mask: bool = True) -> str
    # Get a random CNPJ.
    # :param with_mask: Use cnpj mask (###.###.###-##)
    # :returns: Random cnpj.
    # :Example:
    #     77.732.230/0001-70
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    cnpj_without_mask = brazil_provider.cnpj(with_mask=False)

# Generated at 2022-06-23 20:40:12.005855
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj_1 = bsp.cnpj()
    assert cnpj_1 == '77.732.230/0001-70'
    cnpj_2 = bsp.cnpj(with_mask=False)
    assert cpnj_2 == '77732230000170'

# Generated at 2022-06-23 20:40:12.366431
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:40:15.269763
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

    assert provider.cpf()
    assert provider.cnpj()

# Generated at 2022-06-23 20:40:16.656954
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for cpf."""
    pass



# Generated at 2022-06-23 20:40:21.589812
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    gen = provider.cpf()
    assert gen not in ['00000000000', '11111111111', '22222222222',
                       '33333333333', '44444444444', '55555555555',
                       '66666666666', '77777777777', '88888888888',
                       '99999999999']



# Generated at 2022-06-23 20:40:27.535845
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for class BrazilSpecProvider method cpf."""
    provider_cpf = BrazilSpecProvider()
    cpf = provider_cpf.cpf()

    # len is 14 (without mask)
    assert len(cpf) == 14

    # is integer
    for i in range(14):
        assert isinstance(int(cpf[i]), int)



# Generated at 2022-06-23 20:40:31.985743
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert isinstance(cpf, str)
    cpf = b.cpf(with_mask=True)
    assert isinstance(cpf, str)
    cpf = b.cpf(with_mask=False)
    assert isinstance(cpf, str)

# Generated at 2022-06-23 20:40:36.722785
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    obj = BrazilSpecProvider()
    cnpj = obj.cnpj()

    assert(len(cnpj) == 18)

    assert(cnpj[2] == '.')
    assert(cnpj[6] == '.')
    assert(cnpj[10] == '/')
    assert(cnpj[15] == '-')


# Generated at 2022-06-23 20:40:39.526922
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    result = b.cpf()
    print(result)


# Generated at 2022-06-23 20:40:50.687388
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    print("\n Testing Class BrazilSpecProvider")
    print("test_BrazilSpecProvider()")
    print("get_verifying_digit_cnpj = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]")
    print("cnpj_without_dv [15, 5, 4, 3, 6, 5, 4, 3, 7, 0, 8, 3]")
    print("first_dv = ", brazil_provider.get_verifying_digit_cnpj([5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2], 5))

# Generated at 2022-06-23 20:40:51.880361
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '39713688000128'


# Generated at 2022-06-23 20:40:54.930478
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '378.923.171-35'
    assert provider.cnpj() == '89.796.082/0001-58'

# Generated at 2022-06-23 20:40:57.971053
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the BrazilSpecProvider class method ``cpf``."""
    from re import search
    provider = BrazilSpecProvider()
    assert search('\d{3}\.\d{3}\.\d{3}-\d{2}', provider.cpf())


# Generated at 2022-06-23 20:40:58.859321
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:41:00.940339
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Check if cnpj() method work fine."""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:41:03.101183
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cpf())
    print(brazil_provider.cnpj())

#test_BrazilSpecProvider()

# Generated at 2022-06-23 20:41:05.422461
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test = BrazilSpecProvider()
    assert test is not None

# Generated at 2022-06-23 20:41:09.116174
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    b.seed(1234)
    assert b.cnpj() == '28.919.848/0001-59'
    assert b.cpf() == '497.726.377-90'

# Generated at 2022-06-23 20:41:11.044978
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()


# Generated at 2022-06-23 20:41:15.855488
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Create an instance of the class BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider(seed=8)

    # Duplicate the generated random value
    brazil_spec_provider.random.seed(8)
    cpf = brazil_spec_provider.cpf()

    assert cpf == "724.781.983-39"


# Generated at 2022-06-23 20:41:16.739509
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:41:22.833277
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider(seed=1)

    assert obj.cpf(with_mask=False) == '0011312974'
    assert obj.cpf() == '001.137.297-40'

    assert obj.cnpj(with_mask=False) == '77732241265'
    assert obj.cnpj() == '77.732.240/1265-66'

# Generated at 2022-06-23 20:41:26.129586
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider's method cnpj."""
    provider = BrazilSpecProvider()
    result = provider.cnpj()
    assert len(result) == 18
    assert not result.startswith('0')

# Generated at 2022-06-23 20:41:30.157433
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider()
    assert isinstance(instance, BrazilSpecProvider)
    instance = BrazilSpecProvider(seed=1)
    assert isinstance(instance, BrazilSpecProvider)


# Generated at 2022-06-23 20:41:31.799787
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() != provider.cnpj()


# Generated at 2022-06-23 20:41:37.217891
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    # Make sure the function is case insensitive
    cnpj = provider.cnpj(with_mask=True)
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:41:45.187493
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)
    assert cnpj[2] == '.' and cnpj[6] == '.' and cnpj[10] == '/' and cnpj[15] == '-'

# Generated at 2022-06-23 20:41:47.264517
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(123456)
    print(bsp.cnpj())
    print(bsp.cnpj(False))

# Generated at 2022-06-23 20:41:48.176867
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    return brazil

# Generated at 2022-06-23 20:41:51.686761
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf()
    assert brazil_spec_provider.cpf(False)



# Generated at 2022-06-23 20:41:57.691616
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test for method cnpj of class BrazilSpecProvider
    provider = BrazilSpecProvider()

    # Test cnpj method
    assert isinstance(provider.cnpj(), str)
    assert len(provider.cnpj()) == 18
    assert isinstance(provider.cnpj(with_mask=False), str)
    assert len(provider.cnpj(with_mask=False)) == 14


# Generated at 2022-06-23 20:42:00.195018
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf."""
    provider = BrazilSpecProvider()
    assert provider.cpf() == '343.550.302-45'


# Generated at 2022-06-23 20:42:04.823874
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Given
    brazil_spec_provider = BrazilSpecProvider()

    # When
    cpf = brazil_spec_provider.cpf()

    # Then
    # Test length
    assert len(cpf) == 14

    # Test mask
    assert cpf.find('.') == 3
    assert cpf.find('.', 4) == 7
    assert cpf.find('-', 8) == 12



# Generated at 2022-06-23 20:42:09.380564
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf().

    :return: True if assert
    """
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    assert BrazilSpecProvider().cpf() == '002.245.929-95'
    assert BrazilSpecProvider().cpf(with_mask=False) == '00286482429'


# Generated at 2022-06-23 20:42:10.444801
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:42:16.708229
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for the method BrazilSpecProvider.cpf."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    pprov = Person('pt_BR', seed=12345)

    for _ in range(0, 10):
        cpf = pprov.spec.cpf()
        assert len(cpf) == 14



# Generated at 2022-06-23 20:42:19.756047
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert isinstance(brazil_provider, BrazilSpecProvider)


# Generated at 2022-06-23 20:42:24.424045
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    assert br.cnpj() == '43.345.866/0001-71'
    assert br.cnpj(with_mask=False) == '43345866000171'
    assert br.cnpj() == '31.465.101/0001-19'
    assert br.cnpj(with_mask=False) == '31465101000119'
    assert br.cnpj() == '23.253.838/0001-90'
    assert br.cnpj(with_mask=False) == '23253838000190'
    assert br.cnpj() == '66.006.786/0001-60'
    assert br.cnpj(with_mask=False) == '66006786000160'


# Generated at 2022-06-23 20:42:27.273035
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    generator = BrazilSpecProvider(seed=4815162342) # Set the seed manually, otherwise it will be randomized
    assert type(generator) == BrazilSpecProvider



# Generated at 2022-06-23 20:42:29.430684
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()

    assert brazil_spec_provider


# Generated at 2022-06-23 20:42:35.162404
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider class. Atributtes, __init__() and types"""
    # Test type of attribute 'random'
    rdp = BrazilSpecProvider()
    assert isinstance(rdp.random, type(BrazilSpecProvider().random))
    # Test type of attribute 'provider'
    assert isinstance(rdp.provider, type(BrazilSpecProvider().provider))
    # Test type of attribute 'locale'
    assert isinstance(rdp.locale, type(BrazilSpecProvider().locale))


# Generated at 2022-06-23 20:42:46.465666
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    expected_cnpj = provider.cnpj()
    assert len(expected_cnpj) == 18

    cnpj_first_12_digits = expected_cnpj[:12]
    cnpj_first_12_digits_list = [int(digit) for digit in cnpj_first_12_digits]

    assert expected_cnpj[12:] == str(provider.get_verifying_digit_cnpj(cnpj_first_12_digits_list, 5))

    cnpj_first_13_digits = expected_cnpj[:13]
    cnpj_first_13_digits_list = [int(digit) for digit in cnpj_first_13_digits]


# Generated at 2022-06-23 20:42:53.662954
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(0, 10):
        cpf = BrazilSpecProvider.cpf()
        assert len(cpf) == 14
        assert cpf[3] == '.'
        assert cpf[7] == '.'
        assert cpf[11] == '-'
        assert cpf.count(cpf[3]) == 3
        assert cpf[3] != cpf[7]
        assert cpf[7] != cpf[11]
    return True


# Generated at 2022-06-23 20:42:55.488320
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

# Generated at 2022-06-23 20:43:02.951500
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    cnpj = ''.join([str(i) for i in p.cnpj(False)])
    test_cnpj = p.cnpj(False)
    assert (cnpj[:2] == test_cnpj[:2] and cnpj[2:5] == test_cnpj[3:6] and
            cnpj[5:8] == test_cnpj[6:9] and cnpj[8:12] == test_cnpj[10:14] and
            cnpj[12:] == test_cnpj[15:])



# Generated at 2022-06-23 20:43:12.604013
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.schema import Field
    from mimesis.enums import FieldType
    from mimesis.providers import BrazilSpecProvider

    class TestProvider(BaseSpecProvider):
        """Test BrazilSpecProvider."""

        cnpj = Field(type_=str,
                     provider=BrazilSpecProvider,
                     method='cnpj',
                     value=False)

    tp = TestProvider()
    field = Field(type_=FieldType.CNPJ,
                  provider=tp,
                  value=False)

    cnpj = field.create()
    assert cnpj is not None
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnp

# Generated at 2022-06-23 20:43:15.504389
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    with open('tests/data/cpf-test-cases.txt') as file:
        lines = file.read().splitlines()
        b = BrazilSpecProvider()
        assert b.cnpj() == lines[0]


# Generated at 2022-06-23 20:43:17.134189
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() != ''


# Generated at 2022-06-23 20:43:20.864254
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14
    assert len(bsp.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:43:23.071873
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider()

    assert isinstance(instance, BrazilSpecProvider)
    assert isinstance(instance, BaseSpecProvider)


# Generated at 2022-06-23 20:43:24.961285
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.locale == 'pt-br'
    assert bsp.seed == bsp._random.getstate()



# Generated at 2022-06-23 20:43:31.388299
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""

    provider = BrazilSpecProvider()
    
    # Check if length of CPF is 11
    assert(len(provider.cpf()) == 11)
    assert(len(provider.cpf(with_mask=False)) == 11)

    # Check if length of CPF with mask is 14
    assert(len(provider.cpf(with_mask=True)) == 14)


# Generated at 2022-06-23 20:43:33.689026
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    prop = BrazilSpecProvider()
    prop.cpf()



# Generated at 2022-06-23 20:43:35.788002
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == "015.151.245-98"


# Generated at 2022-06-23 20:43:41.271323
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert type(b.cnpj(with_mask=True)) == str
    assert len(b.cnpj(with_mask=True)) == 18
    assert len(b.cnpj(with_mask=False)) == 14
    assert len(b.cpf(with_mask=True)) == 14
    assert len(b.cpf(with_mask=False)) == 11
    assert type(b.cpf(with_mask=True)) == str

# Generated at 2022-06-23 20:43:42.983005
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed='testing')
    cnpj = bsp.cnpj(False)
    assert len(cnpj) == 14
    assert bsp.cnpj(True) == "32.132.651/0001-91"



# Generated at 2022-06-23 20:43:48.031948
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert isinstance(brazil_spec_provider, BrazilSpecProvider)
    brazil_spec_provider_2 = BrazilSpecProvider(seed=1234)
    assert isinstance(brazil_spec_provider_2, BrazilSpecProvider)
    print("Constructor of class BrazilSpecProvider works")


# Generated at 2022-06-23 20:43:50.339055
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider.cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:43:55.095406
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 14
    assert cnpj[2:3] == "."
    assert cnpj[5:6] == "."
    assert cnpj[8:9] == "/"
    assert cnpj[12:13] == '-'


# Generated at 2022-06-23 20:43:57.986479
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    print(bsp.cpf())
    bsp = BrazilSpecProvider(seed=12345)
    assert bsp.cpf() == "428.629.832-27"



# Generated at 2022-06-23 20:44:01.887577
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(10):
        assert len(BrazilSpecProvider().cpf()) == 14
        assert len(BrazilSpecProvider().cpf(False)) == 11
        print(BrazilSpecProvider().cpf(False))


# Generated at 2022-06-23 20:44:08.312445
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Verify if the cnpj method generate a valid cnpj.

    :returns: True if all tests passed.
    """
    from re import compile

    regex = compile(r'^\d{2}.\d{3}.\d{3}/\d{4}-\d{2}$')
    p = BrazilSpecProvider()

    # As it is a random function, is executed 100 times, in order to
    # make sure that a valid cnpj is returned
    for _ in range(100):
        cnpj = p.cnpj()
        assert regex.match(cnpj), 'The generated cnpj is invalid.'
    return True

# Generated at 2022-06-23 20:44:11.005578
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    tst = BrazilSpecProvider()
    assert tst.__class__.__name__ == "BrazilSpecProvider"


# Generated at 2022-06-23 20:44:12.452579
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert isinstance(BrazilSpecProvider(), BrazilSpecProvider)


# Generated at 2022-06-23 20:44:14.900582
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    test_cnpj = provider.cnpj()
    print(test_cnpj)
    assert len(test_cnpj) == 18
    print("Teste de cnpj com sucesso")


# Generated at 2022-06-23 20:44:21.153431
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """This will test method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cnpj1 = provider.cnpj()
    cnpj2 = provider.cnpj()
    assert len(cnpj1) == len(cnpj2)
    assert cnpj1 != cnpj2


test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-23 20:44:24.916096
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[:3].isdigit()
    assert cpf[4:7].isdigit()
    assert cpf[8:11].isdigit()
    assert cpf[12:14].isdigit()


# Generated at 2022-06-23 20:44:31.489791
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("\n")
    bsp = BrazilSpecProvider()
    print(bsp.cnpj())
    cnpj = bsp.cnpj()
    print(cnpj)
    print("\n")
    assert len(cnpj) == 18
    assert cnpj[2] in "0123456789"
    assert cnpj[3] in "0123456789"
    assert cnpj[4] in "0123456789"
    assert cnpj[6] in "0123456789"
    assert cnpj[7] in "0123456789"
    assert cnpj[8] in "0123456789"
    assert cnpj[10] in "0123456789"

# Generated at 2022-06-23 20:44:34.380853
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()

    assert cnpj == provider.cnpj()

# Generated at 2022-06-23 20:44:38.642025
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    result = brazil_provider.cpf()
    assert result != None
    assert isinstance(result,str)
    print(result)
    assert result == "001.137.297-40"


# Generated at 2022-06-23 20:44:40.925403
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    assert provider.cpf() != provider.cpf()
    assert len(provider.cpf()) == 14


# Generated at 2022-06-23 20:44:45.972980
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print("cnpj:",cnpj)
    assert len(cnpj) == 18, "provider.cnpj() return invalid lenght"
    


# Generated at 2022-06-23 20:44:47.457582
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj()



# Generated at 2022-06-23 20:44:48.080471
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:44:57.116148
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    class BrazilSpecProvider(BaseSpecProvider):
        """Class that provides special data for Brazil (pt-br)."""
        def __init__(self, seed: Seed = None):
            """Initialize attributes."""
            super().__init__(locale='pt-br', seed=seed)

        class Meta:
            """The name of the provider."""
            name = 'brazil_provider'

        def cpf(self, with_mask: bool = True) -> str:
            """Get a random CPF.

            :param with_mask: Use CPF mask (###.###.###-##).
            :returns: Random CPF.

            :Example:
                001.137.297-40
            """

# Generated at 2022-06-23 20:45:07.883915
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test class BrazilSpecProvider - provider for Brazil."""
    from mimesis.enums import Gender
    from mimesis.providers.internet import Internet

    bsp = BrazilSpecProvider()

    # Test get_cpf
    cpf = bsp.cpf(with_mask=True)
    assert cpf is not None

    # Test get_cnpj
    cnpj = bsp.cnpj(with_mask=True)
    assert cnpj is not None

    # Test get_email
    email = bsp.email(gender=Gender.MALE)
    assert email is not None

    # Test get_password
    password = bsp.password(length=2)
    assert password is not None

    # Test get_iban
    iban = bsp.iban()
    assert iban is not None



# Generated at 2022-06-23 20:45:15.898483
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    # Create a new instance of the class BrazilSpecProvider and Person
    b = BrazilSpecProvider(seed='NP')
    p = Person('pt-br', seed='NP')

    # Get a random cpf and name
    cpf = b.cpf(with_mask=False)
    name = p.full_name(gender=Gender.FEMALE)

    print("Name: {}, CPF: {}".format(name, cpf))


# Generated at 2022-06-23 20:45:23.858119
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    expected_cnpjs = ['77.732.230/0001-70', '12.896.837/0001-07', '62.220.325/0001-69', '31.738.519/0001-50', '35.522.068/0001-15', '29.742.849/0001-24', '51.751.115/0001-75', '90.744.155/0001-17', '61.814.908/0001-95', '97.668.283/0001-24']
    brazil_spec_provider = BrazilSpecProvider()
    for i in range(10):
        assert expected_cnpjs[i] == brazil_spec_provider.cnpj()


# Generated at 2022-06-23 20:45:28.289541
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider(seed=1234).cnpj()) == 18
    assert len(BrazilSpecProvider(seed=1234).cnpj(with_mask=False)) == 14
    assert BrazilSpecProvider(seed=1234).cnpj(with_mask=False) == '37732240000170'


# Generated at 2022-06-23 20:45:30.466052
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider is not None, 'Error creating BrazilSpecProvider'
    assert provider.locale == 'pt-br', 'Error setting locale for BrazilSpecProvider'

# Generated at 2022-06-23 20:45:33.109581
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert ((brazil_spec_provider.cpf(True)) and
            (brazil_spec_provider.cnpj(True)))

# Generated at 2022-06-23 20:45:33.726202
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:45:35.971886
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()

    cpf = a.cpf()
    assert (len(cpf) == 14)



# Generated at 2022-06-23 20:45:38.755991
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=1)
    assert bsp.cnpj(with_mask=False) == '37446544000172'
    assert bsp.cnpj(with_mask=True) == '37.446.544/0001-72'


# Generated at 2022-06-23 20:45:40.892132
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    c = BrazilSpecProvider()
    c.cpf()
    c.cpf(False)


# Generated at 2022-06-23 20:45:44.496326
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider())
    print(BrazilSpecProvider(seed=42).cpf())
    print(BrazilSpecProvider(seed=42).cnpj())

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:46.816125
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print(cnpj)
    assert cnpj == cnpj
    

# Generated at 2022-06-23 20:45:49.197270
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Test BrazilSpecProvider()")
    provider = BrazilSpecProvider()
    assert provider.cpf() != None
    assert provider.cnpj() != None

# Generated at 2022-06-23 20:45:53.944498
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    x = BrazilSpecProvider()
    assert x.cnpj() == "23.283.964/0001-65"
    assert x.cnpj(with_mask=False) == "23283964000165"


# Generated at 2022-06-23 20:46:03.083392
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    # provider.cnpj()
    digits = ['20.147.155/0001-00', '36.904.867/0001-01', '23.104.607/0001-00', '46.312.297/0001-01', '67.854.397/0001-01', '47.386.241/0001-05', '69.718.103/0001-03', '56.072.463/0001-04', '21.848.813/0001-02', '53.577.967/0001-09']
    assert provider.cnpj() in digits
    assert provider.cnpj() in digits
    assert provider.cnpj() in digits


# Generated at 2022-06-23 20:46:09.863219
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert len(cpf.split('.')[0]) == 3
    assert len(cpf.split('.')[1]) == 3
    assert len(cpf.split('.')[2]) == 3
    assert len(cpf.split('-')[1]) == 2

# Generated at 2022-06-23 20:46:14.807338
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider(seed=1)
    assert brazil.cpf() == '539.354.360-03'
    assert brazil.cpf(with_mask=False) == '5393543603'


# Generated at 2022-06-23 20:46:15.400286
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()

# Generated at 2022-06-23 20:46:21.287218
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    assert(cnpj.startswith('92') and cnpj.endswith('01'))
    assert(b.cnpj(with_mask=False).startswith('92') and cnpj.endswith('01'))
    assert(b.cnpj(with_mask=True).startswith('92') and cnpj.endswith('01'))

# Generated at 2022-06-23 20:46:22.634965
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    locale = 'pt-br'
    seed = 0
    BrazilSpecProvider(locale=locale, seed=seed)
    pass

# Generated at 2022-06-23 20:46:26.140272
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider().seed
    BrazilSpecProvider().seed
    BrazilSpecProvider().seed
    BrazilSpecProvider().seed
    BrazilSpecProvider().seed

# Generated at 2022-06-23 20:46:28.382182
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider()
    assert p.cpf() == '921.093.118-31'


# Generated at 2022-06-23 20:46:35.442335
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  from mimesis.providers import BrazilSpecProvider
  from mimesis.enums import Gender
  from mimesis.builtins.cz import CzechiaSpecProvider
  import re
  br_pt = BrazilSpecProvider()
  
  cnpj = br_pt.cnpj(with_mask=False)
  assert len(cnpj) == 14
  assert re.match(r'^[0-9]{14}$', cnpj)
  
  cnpj2 = br_pt.cnpj(with_mask=True)
  assert re.match(r'^[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}$', cnpj2)
  

# Generated at 2022-06-23 20:46:38.416649
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for BrazilSpecProvider.cpf()."""
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == "001.137.297-40"

# Generated at 2022-06-23 20:46:39.892423
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    cnpj = provider.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:46:40.903494
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # TODO Algoritmo de teste
    print("Nothing implemented")


# Generated at 2022-06-23 20:46:42.525549
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('\nTest CPF Provider of BrazilSpecProvider')
    cpf = BrazilSpecProvider(seed=1234).cpf()
    print(cpf)



# Generated at 2022-06-23 20:46:44.881257
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    prov = BrazilSpecProvider()
    assert str(type(prov)) == "<class 'mimesis.providers.brazil_provider.BrazilSpecProvider'>"
    return prov


# Generated at 2022-06-23 20:46:46.002360
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(10):
        print(BrazilSpecProvider().cnpj())

# Generated at 2022-06-23 20:46:50.078773
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Test the constructor of BrazilSpecProvider
    brazilian_provider = BrazilSpecProvider()
    assert brazilian_provider is not None
    assert brazilian_provider.locale == 'pt-br'


# Generated at 2022-06-23 20:47:00.037006
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import unittest.mock as mock
    bzp = BrazilSpecProvider.__new__(BrazilSpecProvider)
    bzp._random = mock.MagicMock()
    bzp._random.randint.side_effect = [0, 0, 0, 1, 1, 3, 2, 9, 7]
    bzp._random.randint.side_effect.extend([0, 0, 0, 0, 0, 0, 0, 0, 0])
    bzp._random.randint.side_effect.extend([0, 0, 0, 0, 0])
    assert bzp.cpf() == '001.137.297-40'
    assert bzp.cpf(False) == '00113729740'


# Generated at 2022-06-23 20:47:09.397525
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()
    cnpj = bp.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    cnpj = cnpj.replace(".", "")
    cnpj = cnpj.replace("/", "")
    cnpj = cnpj.replace("-", "")
    assert len(cnpj) == 14
    for i in range(14):
        assert cnpj[i] in "0123456789"

# Generated at 2022-06-23 20:47:11.295139
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)
