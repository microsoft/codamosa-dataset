

# Generated at 2022-06-23 20:37:12.662859
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider(seed=0).cpf() == '939.867.829-79' and BrazilSpecProvider(seed=0).cnpj() == '25.675.918/0001-09'


# Generated at 2022-06-23 20:37:13.679940
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print(BrazilSpecProvider().cnpj())

# Generated at 2022-06-23 20:37:22.390188
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider_cnpj."""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert len(cnpj.split('/')[0].split('.')[0]) == 2
    assert len(cnpj.split('/')[0].split('.')[1]) == 3
    assert len(cnpj.split('/')[0].split('.')[2]) == 3
    assert len(cnpj.split('/')[1]) == 4
    assert len(cnpj.split('-')[1]) == 2



# Generated at 2022-06-23 20:37:24.856213
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider(seed=123)
    assert brazil.cpf(False) == '88251351715'
    assert brazil.cnpj(False) == '54517209000152'

# Generated at 2022-06-23 20:37:25.985533
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() != ''
    assert provider.cnpj() != ''

# Generated at 2022-06-23 20:37:31.340584
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider

    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 14
    assert cnpj[2] == "."
    assert cnpj[6] == "."
    assert cnpj[10] == "/"
    assert cnpj[15] == "-"


# Generated at 2022-06-23 20:37:36.063843
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # test_BrazilSpecProvider_cpf_with_mask
    assert BrazilSpecProvider().cpf() == '001.137.297-40'

    # test_BrazilSpecProvider_cpf_without_mask
    assert BrazilSpecProvider().cpf(False) == '00113729740'


# Generated at 2022-06-23 20:37:42.048226
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bp = BrazilSpecProvider()
    assert bp.cpf() == '977.927.979-20'
    assert bp.cpf(True) == '977.927.979-20'
    assert bp.cnpj() == '32.792.133/0001-06'
    assert bp.cnpj(True) == '32.792.133/0001-06'


# Generated at 2022-06-23 20:37:43.557145
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert len(b.cnpj()) == 18


# Generated at 2022-06-23 20:37:45.119969
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:37:49.459224
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()

    expected = '565.240.794-37'
    result = brazil_spec_provider.cpf()
    assert result == expected, str(result) + ' is not ' + str(expected)



# Generated at 2022-06-23 20:37:51.565520
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bzp = BrazilSpecProvider()
    print(bzp.cnpj(False))
    print(bzp.cnpj())


# Generated at 2022-06-23 20:37:52.051175
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:37:56.010431
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf(with_mask = True)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:37:58.719251
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Testing if the class BrazilSpecProvider works correctly:")

    print("Constructor test: ")
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider)
    print("cpf() test: ")
    print(brazil_provider.cpf())
    print("cnpj() test: ")
    print(brazil_provider.cnpj())
    return True

# Test call
if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:38:04.222877
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider class."""
    b = BrazilSpecProvider()
    assert isinstance(b.cnpj(), str)
    assert len(b.cnpj()) == 14
    assert len(b.cnpj(with_mask=False)) == 12


# Generated at 2022-06-23 20:38:05.978843
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    data = provider.cnpj()
    assert isinstance(data, str)

# Generated at 2022-06-23 20:38:10.164359
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider('en')
    cpf = provider.cpf(with_mask=True)
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:38:11.638142
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    instance = BrazilSpecProvider()
    assert len(instance.cpf()) == 14


# Generated at 2022-06-23 20:38:13.075448
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    result = obj.cpf(False)
    assert result is not None


# Generated at 2022-06-23 20:38:15.367455
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    assert BrazilSpecProvider
    assert isinstance(b, BrazilSpecProvider)
    assert b.cnpj()
    assert b.cpf()

# Generated at 2022-06-23 20:38:21.151718
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj()."""
    brazil_provider = BrazilSpecProvider()
    result = brazil_provider.cnpj()
    assert isinstance(result, str)
    assert len(result) == 18
    assert brasil_provider.cnpj()[2] == '.'
    assert brasil_provider.cnpj()[6] == '.'
    assert brasil_provider.cnpj()[10] == '/'
    assert brasil_provider.cnpj()[15] == '-'
    assert brasil_provider.cnpj(with_mask=False)[15] == result[-2]
    assert brasil_provider.cnpj(with_mask=False)[14] == result[-1]


# Generated at 2022-06-23 20:38:27.199523
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()

    # 100 numbers
    for _ in range(100):
        cnpj = bp.cnpj()
        assert len(cnpj) == 18
    # 100 numbers with mask
    for _ in range(100):
        cnpj = bp.cnpj(with_mask=True)
        assert len(cnpj) == 18


# Generated at 2022-06-23 20:38:29.868139
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for _ in range(0, 10):
        assert len(provider.cpf(False)) == 11
        assert len(provider.cpf()) == 14


# Generated at 2022-06-23 20:38:36.283863
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import unittest
    from mimesis.providers.brazil.util import BrazilSpecProvider
    from mimesis.providers.base import BaseProvider

    class TestBrazilSpecProvider(unittest.TestCase):
        def setUp(self):
            self.unit = BrazilSpecProvider()

        def test_instance(self):
            class_name = 'BrazilSpecProvider'
            self.assertIsInstance(self.unit, BrazilSpecProvider, msg='Should be {0}'.format(class_name))

        def test_inheritance(self):
            class_name = 'BaseProvider'
            self.assertIsInstance(self.unit, BaseProvider, msg='Should be {0}'.format(class_name))

# Generated at 2022-06-23 20:38:37.632818
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().seed is not None


# Generated at 2022-06-23 20:38:40.267720
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:38:42.860850
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert brazil.cpf() == '454.318.744-44'


# Generated at 2022-06-23 20:38:44.603109
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Teste class constructor."""
    x = BrazilSpecProvider()
    assert x._locale == 'pt-br'

# Generated at 2022-06-23 20:38:48.436253
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    result = BrazilSpecProvider(seed=0).cnpj(with_mask=True)
    assert result.__eq__("77.732.230/0001-70")   


# Generated at 2022-06-23 20:38:51.158943
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Testing constructor of class BrazilSpecProvider."""
    b = BrazilSpecProvider()
    # Verify that is an instance of BrazilSpecProvider
    assert isinstance(b, BrazilSpecProvider)

# Generated at 2022-06-23 20:38:57.206797
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    from mimesis.schema import Field, Schema

    # Checking if CPF is valid (Brazil)
    brazil_provider = BrazilSpecProvider()
    cpf_schema = Schema(cpf=Field(brazil_provider.cpf))
    print(cpf_schema.create(iterations=100))

    # Checking if CPF is valid (Brazil) without mask
    brazil_provider = BrazilSpecProvider()
    cpf_schema = Schema(cpf=Field(brazil_provider.cpf, mask=False))
    print(cpf_schema.create(iterations=100))


# Generated at 2022-06-23 20:39:06.903333
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    test for the method cpf of class BrazilSpecProvider,
    check if the generated cpf has 11 digits, 
    and if it has the mask '###.###.###-##'.
    """
    brazil_provider = BrazilSpecProvider(seed=0)
    
    cpf_without_mask = brazil_provider.cpf(with_mask=False)
    cpf_with_mask = brazil_provider.cpf(with_mask=True)
    
    assert len(cpf_without_mask) == 11
    assert cpf_with_mask[3] == '.'
    assert cpf_with_mask[7] == '.'
    assert cpf_with_mask[11] == '-'


# Generated at 2022-06-23 20:39:08.875424
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()


# Generated at 2022-06-23 20:39:13.772811
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    if provider.cpf() != '001.137.297-40':
        # If the generated text is not in the expected format.
        return False
    
    if provider.cpf(with_mask=False) != '00113729740':
        # If the generated text is not in the expected format.
        return False
    return True


# Generated at 2022-06-23 20:39:17.344621
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'



# Generated at 2022-06-23 20:39:18.651814
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for BrazilSpecProvider."""
    assert BrazilSpecProvider(seed=42)

# Generated at 2022-06-23 20:39:22.644373
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'



# Generated at 2022-06-23 20:39:28.424537
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test brazil_provider_cnpj"""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-23 20:39:32.721808
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    a = b.cnpj()
    c = b.cnpj()
    
    old = b.seed
    b.seed = '14227920746344'
    b.cnpj()
    b.seed = old
    
    assert isinstance(a, str)
    assert len(a) == 18
    assert isinstance(c, str)
    assert len(c) == 18
    assert a != c

# Generated at 2022-06-23 20:39:34.002009
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:39:38.520058
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # arrange
    cpf = '001.137.297-40'
    provider = BrazilSpecProvider()

    # act
    generated_cpf = provider.cpf()

    # assert
    assert generated_cpf == cpf, 'CPF ' + generated_cpf + ' diferente de ' + cpf


# Generated at 2022-06-23 20:39:41.515886
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    tcnpj = BrazilSpecProvider().cnpj(with_mask=True)
    assert len(tcnpj) == 18


# Generated at 2022-06-23 20:39:44.133931
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # GIVEN
    provider = BrazilSpecProvider()

    # WHEN
    result = provider.cnpj()

    # THEN
    # result must be a string
    assert isinstance(result, str)


# Generated at 2022-06-23 20:39:48.149134
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Testando o método cpf de BrazilSpecProvider."""
    from mimesis.providers.person import Person

    person = Person('pt-br')
    test_cpf = person.cpf(True)

    print(test_cpf)

    if (type(test_cpf) == str):
        assert True
    else:
        assert False


# Generated at 2022-06-23 20:39:54.431945
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider_cnpj."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.builtins.brazil import BrazilSpecProvider

    p = Person('en')
    gender = p.gender()
    print('[{}] {} {}'.format(gender.name, p.name(gender), p.surname(gender)))
    print('[CNPJ] {}'.format(BrazilSpecProvider().cnpj()))

# Generated at 2022-06-23 20:39:54.942499
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider() is not None


# Generated at 2022-06-23 20:40:00.318049
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for BrazilSpecProvider constructor."""
    bsp = BrazilSpecProvider(seed=12345)

    assert bsp.cpf() == '348.405.279-05'
    assert bsp.cnpj() == '92.876.332/0001-36'



# Generated at 2022-06-23 20:40:03.023397
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    print('method cpf:')
    print(provider.cpf(with_mask=True))
    print(provider.cpf(with_mask=False))


# Generated at 2022-06-23 20:40:09.528379
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider class."""

    brazil = BrazilSpecProvider()

    cnpj = brazil.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert re.match(r'\d{2}\.\d{3}\.\d{3}/\d{4}\-\d{2}', cnpj)

    cnpj = brazil.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert re.match(r'\d{14}', cnpj)



# Generated at 2022-06-23 20:40:12.945737
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert cpf is not None, "Returned cpf is none"
    assert len(cpf) == 14, "Returned cpf is not 14 characters"


# Generated at 2022-06-23 20:40:23.979256
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)
    assert isinstance(provider, Person)
    assert isinstance(provider, Address)
    assert provider.cnpj() == "18.807.764/0001-05"
    assert provider.cnpj(with_mask=False) == "18807764000105"
    assert provider.cpf() == "923.329.992-32"
    assert provider.cpf(with_mask=False) == "92332999232"
    assert provider.gender() == Gender.UNKNOWN
    assert provider.birth_date() == "19/12/1993"
    assert provider

# Generated at 2022-06-23 20:40:25.785865
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    print(bsp.cpf())


# Generated at 2022-06-23 20:40:28.200268
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    assert BrazilSpecProvider is not None


# Generated at 2022-06-23 20:40:31.217696
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-23 20:40:40.046107
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    tmp_provider = BrazilSpecProvider()
    tmp_result = tmp_provider.cpf()
    assert len(tmp_result) == 14
    tmp_result = tmp_provider.cpf(with_mask=False)
    assert len(tmp_result) == 11
    tmp_provider_1 = BrazilSpecProvider(seed="a")
    tmp_result_1 = tmp_provider_1.cpf()
    tmp_provider_1 = BrazilSpecProvider(seed="a")
    tmp_result_2 = tmp_provider_1.cpf()
    assert tmp_result_1 == tmp_result_2


# Generated at 2022-06-23 20:40:42.896046
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()

    assert isinstance(cnpj, str)
    assert len(cnpj) == 14


# Generated at 2022-06-23 20:40:45.481431
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert cnpj.isdigit()

    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    assert cnpj.count('-') == 1

# Generated at 2022-06-23 20:40:47.610142
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    cpf = BrazilSpecProvider()
    print(cpf.cpf())

# Generated at 2022-06-23 20:40:49.641682
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    instance = BrazilSpecProvider()
    assert instance.cnpj(with_mask=False)

if __name__ == '__main__':
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-23 20:40:51.198950
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor."""
    assert BrazilSpecProvider().__init__() is None

# Generated at 2022-06-23 20:40:54.878460
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider(seed=12345)
    result = provider.cpf()
    assert result == "813.822.637-82"


# Generated at 2022-06-23 20:40:57.197627
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
	provider = BrazilSpecProvider()
	cpf = provider.cpf()
	assert cpf == "895.742.509-68"


# Generated at 2022-06-23 20:40:58.724092
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert bsp.cnpj()


# Generated at 2022-06-23 20:41:04.344698
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf.endswith('-00') or cpf.endswith('-11')
    assert cpf.endswith('-22') or cpf.endswith('-33')
    assert cpf.endswith('-44') or cpf.endswith('-55')
    assert cpf.endswith('-66') or cpf.endswith('-77')
    assert cpf.endswith('-88') or cpf.endswith('-99')


# Generated at 2022-06-23 20:41:07.783636
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unittest to verify if cnpj method of class BrazilSpecProvider returns a 
    14 digit string
    """
    provider = BrazilSpecProvider()
    assert(  len(provider.cnpj()) == 14  )

# Generated at 2022-06-23 20:41:13.350396
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('')
    print('Testing BrazilSpecProvider_cpf')
    print('')

    # Initialize a instance of BrazilSpecProvider class
    brazil_local_provider = BrazilSpecProvider()
    # Call the method cpf()
    result = brazil_local_provider.cpf()
    print('Result BrazilSpecProvider.cpf: ' + result.__str__())



# Generated at 2022-06-23 20:41:14.630188
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj()


# Generated at 2022-06-23 20:41:22.505574
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider
    b = BrazilSpecProvider()
    # assert b.cnpj() == '84.711.698/0001-75'
    print(b.cnpj())
    # assert b.cnpj() == '36.876.896/0001-28'
    print(b.cnpj())
    # assert b.cnpj() == '77.872.539/0001-01'
    print(b.cnpj())


# Generated at 2022-06-23 20:41:25.507068
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilspec = BrazilSpecProvider()
    print("brazilspec = ", brazilspec)
#     print("brazilspec = ", brazilspec.cpf())
#     print("brazilspec = ", brazilspec.cnpj())

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:41:35.689792
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test with mask
    bp = BrazilSpecProvider()
    cpf = bp.cpf(with_mask=True)
    first_dv = int(cpf[9])
    second_dv = int(cpf[10])
    number = [int(i) for i in cpf[:9].replace('.', '')]

    # Validate first digit
    first_dv_calc = first_dv
    for index, digit in enumerate(number):
        first_dv_calc += digit * (10 - index + 1)
    first_dv_calc = first_dv_calc % 11
    if first_dv_calc <= 1:
        first_dv_calc = 0
    else:
        first_dv_calc = 11 - first_dv_

# Generated at 2022-06-23 20:41:38.133601
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected1 = "746.684.218-13"
    assert BrazilSpecProvider().cpf() == expected1


# Generated at 2022-06-23 20:41:44.693078
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf."""
    random = BrazilSpecProvider()
    assert isinstance(random.cpf(), str)
    assert len(random.cpf()) == 14
    assert random.cpf()[3] == '.'
    assert random.cpf()[7] == '.'
    assert random.cpf()[11] == '-'

    assert isinstance(random.cpf(False), str)
    assert len(random.cpf(False)) == 11
    assert random.cpf(False)[3] != '.'
    assert random.cpf(False)[7] != '.'
    assert random.cpf(False)[11] != '-'


# Generated at 2022-06-23 20:41:53.406946
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for BrazilSpecProvider.cnpj method."""
    provider = BrazilSpecProvider()
    # Check if it is str
    assert isinstance(provider.cnpj(), str)
    # Check length of the string returned
    assert len(provider.cnpj()) == 18
    # Check if the first part has a mask to delimit
    assert len(provider.cnpj()[0:2]) == 2
    assert len(provider.cnpj()[3:6]) == 3
    assert len(provider.cnpj()[7:10]) == 3
    assert len(provider.cnpj()[11:15]) == 4
    assert len(provider.cnpj()[16:18]) == 2
    # Check if the second part has a mask to delimit

# Generated at 2022-06-23 20:41:56.797669
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Instantiate a BrazilSpecProvider
    brazil = BrazilSpecProvider()
    # Call method
    cpf = brazil.cpf()
    # Check if values are in the list
    assert cpf



# Generated at 2022-06-23 20:41:59.002378
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj(with_mask = False)
    assert len(cnpj) == 14


# Generated at 2022-06-23 20:42:00.994867
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    print(brazil.cpf())
    print(brazil.cnpj())

# Generated at 2022-06-23 20:42:08.134147
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    provider = BrazilSpecProvider()
    seed_int = 1
    seed_float = 1.0
    seed_string = '1'
    seed_tuple = (1,)
    seed_list = [1]
    seed_set = {1}
    seed_dict = {'1': 1}
    provider.gender(seed=seed_int)
    provider.full_name(gender=Gender.MALE, seed=seed_float)
    provider.cpf(with_mask=True, seed=seed_string)
    provider.cnpj(with_mask=False, seed=seed_tuple)
    provider.cpf(seed=seed_list)
    provider.cnpj(seed=seed_set)
    provider.cpf(seed=seed_dict)

# Generated at 2022-06-23 20:42:15.805780
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider(seed=42)
    brazil2 = BrazilSpecProvider(seed=42)
    assert brazil.cpf(with_mask=False) == brazil2.cpf(with_mask=False)
    assert brazil.cpf(with_mask=True) == brazil2.cpf(with_mask=True)
    assert brazil.cnpj(with_mask=False) == brazil2.cnpj(with_mask=False)
    assert brazil.cnpj(with_mask=True) == brazil2.cnpj(with_mask=True)

# Generated at 2022-06-23 20:42:20.719412
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed_value = "Test_BrazilSpecProvider_cpf"
    br = BrazilSpecProvider(seed=seed_value)
    cpf = br.cpf(with_mask=True)
    assert cpf == "773.442.250-91" or cpf == "399.021.957-05"

# Generated at 2022-06-23 20:42:24.211261
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()

    # Test of BrazilSpecProvider.cpf()
    cpf = bsp.cpf()
    assert len(cpf) == 14

    # Test of BrazilSpecProvider.cnpj()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:42:27.221105
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brasilprovider = BrazilSpecProvider()
    assert brasilprovider.cpf(1)
    assert brasilprovider.cpf(0)


# Generated at 2022-06-23 20:42:29.782875
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert BrazilSpecProvider().cpf() == '000.000.000-00'

# Generated at 2022-06-23 20:42:32.918664
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Arrange
    seed = 'mimesis'

    # Act
    util = BrazilSpecProvider(seed)

    # Assert
    assert util.cpf() == '071.085.941-10'

# Generated at 2022-06-23 20:42:36.289864
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method BrazilSpecProvider.cpf.

        The CPF must be a 11 digit string.
    """
    bp = BrazilSpecProvider()
    cpf = bp.cpf()
    assert len(cpf) == 11
    assert type(cpf) == str


# Generated at 2022-06-23 20:42:39.287434
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    print('CPF:', brazilSpecProvider.cpf())
    print('CNPJ:', brazilSpecProvider.cnpj())

# Generated at 2022-06-23 20:42:42.055481
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    print("Testing constructor of class BrazilSpecProvider")

    b = BrazilSpecProvider()
    assert b is not None
    assert b.__class__.__name__ == "BrazilSpecProvider"

# Generated at 2022-06-23 20:42:44.716323
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Class that test methods from BrazilSpecProvider."""
    try:
        BrazilSpecProvider()
    except:
        assert False
    assert True


# Generated at 2022-06-23 20:42:46.264324
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BrazilSpecProvider().cnpj()

# Generated at 2022-06-23 20:42:53.845591
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[0:3].isdigit()
    assert cpf[4:7].isdigit()
    assert cpf[8:11].isdigit()
    assert cpf[12:14].isdigit()


# Generated at 2022-06-23 20:43:00.988705
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test CPF method."""
    bz = BrazilSpecProvider()
    assert re.match(r'\d{3}\.\d{3}\.\d{3}-\d{2}', bz.cpf())
    assert len(bz.cpf(False)) == 11
    assert bz.cpf() == bz.cpf()
    bz = BrazilSpecProvider(seed=1337)
    assert bz.cpf() == '036.522.209-37'
    assert len(bz.cpf(False)) == 11
    assert bz.cpf() == bz.cpf()
    bz = BrazilSpecProvider(seed=1337)
    assert bz.cpf() == '036.522.209-37'
    assert len(bz.cpf(False)) == 11

# Generated at 2022-06-23 20:43:06.526042
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-23 20:43:09.931423
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpjs = []
    for i in range(10000):
        cnpjs.append(BrazilSpecProvider().cnpj())
    cnpjs = list(set(cnpjs))
    assert len(cnpjs) == 10000

# Generated at 2022-06-23 20:43:16.191691
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    import re

    bsp = BrazilSpecProvider()

    valid_cnpj = re.compile(r'[1-9]{2}.[1-9]{3}.[1-9]{3}/[1-9]{4}-[1-9]{2}')
    first_run = bsp.cnpj()
    second_run = bsp.cnpj()
    third_run = bsp.cnpj()

    assert first_run != second_run
    assert first_run != third_run
    assert second_run != third_run
    assert valid_cnpj.match(first_run) is not None
    assert valid

# Generated at 2022-06-23 20:43:16.653779
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
     BrazilSpecProvider()

# Generated at 2022-06-23 20:43:22.284804
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider(seed=0).cpf() == '443.060.738-52'
    assert BrazilSpecProvider().cpf() == '000.104.899-76'
    assert BrazilSpecProvider(seed=1).cnpj() == '04.963.095/0001-34'
    assert BrazilSpecProvider().cnpj() == '05.967.744/0001-63'
    assert BrazilSpecProvider(seed=0).cpf(with_mask=False) == '44306073852'
    assert BrazilSpecProvider().cpf(with_mask=False) == '00010489976'
    assert BrazilSpecProvider(seed=1).cnpj(with_mask=False) == '04963095000134'

# Generated at 2022-06-23 20:43:25.749557
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == '723.456.157-05'
    assert bsp.cpf(with_mask=False) == '72345615705'


# Generated at 2022-06-23 20:43:34.149717
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    def seed_test(seed):
        """Unit test for constructor of class BrazilSpecProvider with seed."""
        s = BrazilSpecProvider(seed)
        assert (s.cnpj(with_mask=True) == '42.081.228/0001-90')
        assert (s.cnpj(with_mask=False) == '42081228000190')
        assert (s.cpf(with_mask=True) == '917.237.207-46')
        assert (s.cpf(with_mask=False) == '91723720746')

    seed_test(None)
    seed_test(8895)
    seed_test('test')

# Generated at 2022-06-23 20:43:36.520689
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    # print(provider.cnpj())
    assert provider.cnpj() == '89.729.241/0001-60'



# Generated at 2022-06-23 20:43:41.270651
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()

    assert(type(cnpj) is str)
    assert(cnpj.__len__() == 18)
    assert(cnpj[2] is '.')
    assert(cnpj[6] is '.')
    assert(cnpj[10] is '/')
    assert(cnpj[15] is '-')


# Generated at 2022-06-23 20:43:43.464552
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    cpf = brazilSpecProvider.cpf()
    # print(cpf)
    assert (cpf is not None) and (len(cpf) == 14)
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:43:44.598895
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider() is BrazilSpecProvider())
# result: True
    

# Generated at 2022-06-23 20:43:46.918582
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert type(result) == str
    assert len(result) == 14


# Generated at 2022-06-23 20:43:52.902378
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import Person, BrazilSpecProvider
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.typing import Seed
    from mimesis.enums import Gender

    person = Person(locale='en', seed=500)
    BrazilSpecProvider.cpf(with_mask=True) == '971.957.093-30'
    BrazilSpecProvider.cpf(with_mask=False) == '971957'


# Generated at 2022-06-23 20:44:02.943094
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider(seed=10)
    assert provider.cpf(with_mask=False) != provider.cpf(
        with_mask=False)  # Two different values
    assert provider.cpf(with_mask=False)[:9].isdigit()  # First 9 digits are ints
    assert provider.cpf(with_mask=False)[9].isdigit()  # 10th digit is int
    assert '.' not in provider.cpf(with_mask=False)  # No period
    assert '-' not in provider.cpf(with_mask=False)  # No hyphen
    assert provider.cpf(with_mask=True)[:3].isdigit()  # First 3 digits are ints

# Generated at 2022-06-23 20:44:12.151094
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # generate 25 random values and add them all to a list
    list_of_values = []
    for i in range(25):
        list_of_values.append(BrazilSpecProvider().cnpj())
    # mask
    assert BrazilSpecProvider().cnpj(with_mask=True)
    # no mask
    assert BrazilSpecProvider().cnpj(with_mask=False)
    # test if the generated values are unique
    assert len(list_of_values) == len(set(list_of_values))
# end of unit test for method cnpj of class BrazilSpecProvider


# Generated at 2022-06-23 20:44:17.318005
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Check that the result of cnpj method is a valid CNPJ."""
    from mimesis.enums import Gender
    from re import compile

    p = BrazilSpecProvider()
    cnpj_pattern = compile(r'^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$')
    assert cnpj_pattern.match(p.cnpj())
    assert p.cnpj(False) == '11111111111111'
    p = BrazilSpecProvider(seed=666)
    assert p.cnpj() == '07.446.715/0001-90'
    assert p.cnpj(False) == '07446715000190'



# Generated at 2022-06-23 20:44:20.276872
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf()) == 14


# Generated at 2022-06-23 20:44:26.062660
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test that the method cnpj from class BrazilSpecProvider return a valid cnpj object."""
    # Since the CNPJ is create using random values we need to check that the calculate
    # method using the modulo 11 is correct to know if the cnpj is valid.
    # The constants 5 used in the calculate method is used to calculate the first
    # digit of the string and the constant 6 is used to calculate the second digit.
    # The list of cpf is used to check each part of the first and second digits,
    # and the cnpj is a valid value to check.
    # Each CNPJ is check using the first digit of the list and the second digit is check
    # using the second number of the list.
    constants_list = [5, 6]

    # List of valid cpf is taken from http://www.cnpj.

# Generated at 2022-06-23 20:44:26.761953
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    x = BrazilSpecProvider()
    assert x


# Generated at 2022-06-23 20:44:29.518127
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider as brazilSpec
    brazil = BrazilSpecProvider()
    print(brazil.cpf())
# Test Result
# >>> 001.137.297-40


# Generated at 2022-06-23 20:44:40.734025
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseDataProvider
    from mimesis.providers.person import Person

    locale = 'pt-br'
    p = Person(locale)
    g = p._gender_factory(Gender.FEMALE)
    msg = "The CNPJ generated by the BrazilSpecProvider is wrong."
    dp = BaseDataProvider()

    for _ in range(100):
        cnpj = dp.cnpj()
        cnpj_without_dv = cnpj[:12]
        first_dv = dp.get_verifying_digit_cnpj(cnpj_without_dv, 5)
        cnpj_without_dv += first_dv

        second_dv = dp.get_

# Generated at 2022-06-23 20:44:43.423109
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    random.seed(42)
    cpf = BrazilSpecProvider().cpf()
    assert cpf == "730.580.842-43"


# Generated at 2022-06-23 20:44:48.106541
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    assert(b.cnpj() is not None)
    assert(len(b.cnpj()) == 18)
    assert(b.cnpj(False) is not None)
    assert(len(b.cnpj(False)) == 14)
    assert(b.cpf() is not None)
    assert(len(b.cpf()) == 14)
    assert(b.cpf(False) is not None)
    assert(len(b.cpf(False)) == 11)


# Generated at 2022-06-23 20:44:50.081473
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider constructor"""
    assert BrazilSpecProvider().cnpj()
    assert BrazilSpecProvider().cpf()

# Generated at 2022-06-23 20:44:58.448653
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask = False)
    assert len(cpf) == 11
    cpf = provider.cpf(with_mask = True)
    assert len(cpf) == 14
    cpf_list = list(cpf)
    mask = ['.','.','-',cpf_list[3] ,cpf_list[4],cpf_list[5],cpf_list[6] ,cpf_list[7],cpf_list[8],cpf_list[9]]

# Generated at 2022-06-23 20:45:03.640419
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    cnpj = brazil_provider.cnpj()
    assert cpf == '001.137.297-40'
    assert cnpj == '77.732.230/0001-70'

# Generated at 2022-06-23 20:45:07.546270
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    b = BrazilSpecProvider(seed=1)
    assert b.cnpj() == '77.732.230/0001-70'
    assert b.cnpj(with_mask=False) == '77732230000170'



# Generated at 2022-06-23 20:45:15.561575
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert len(cpf) == 14
    assert cpf[2: 3] == '.'
    assert cpf[6: 7] == '.'
    assert cpf[10: 11] == '-'
    assert cpf[3: 6] in '1234567890'
    assert cpf[7: 10] in '1234567890'
    assert cpf[11: 14] in '1234567890'


# Generated at 2022-06-23 20:45:24.150336
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18, "A mask must be applied."
    cnpj = bsp.cnpj(True)
    assert cnpj == "41.860.689/0001-26", str(cnpj) + " != " + '41.860.689/0001-26'
    cnpj = bsp.cnpj(False)
    assert cnpj == "41860689000126", str(cnpj) + " != " + '41860689000126'
    assert bsp.cnpj() == "41.860.689/0001-26"

    bsp.seed(19)
    assert bsp.cnpj(False) == "41860689000126"

# Generated at 2022-06-23 20:45:28.199586
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-23 20:45:31.018255
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test to cpf method of BrazilSpecProvider class"""
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf()) == 14
    assert len(brazil.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:45:38.012830
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj  # cnpj is not empty
    assert len(cnpj) == 18  # cnpj has 18 characters
    assert cnpj[2] == '.'  # 3rd character is '.'
    assert cnpj[6] == '.'  # 7th character is '.'
    assert cnpj[10] == '/'  # 11th character is '/'
    assert cnpj[15] == '-'  # 16th character is '-'


# Generated at 2022-06-23 20:45:42.286720
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf(with_mask=True)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:45:44.055220
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:45:47.695705
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Testing constructor of BrazilSpecProvider class...", end=' ')
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() != ""
    assert brazil_provider.cnpj() != ""
    print("OK")

# Executes the tests
# test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:51.018724
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    class _BrazilSpecProvider(BrazilSpecProvider):
        class Meta:
            seed = None

    a = _BrazilSpecProvider()
    cnpj = a.cnpj()

    assert len(cnpj) == 18


# Generated at 2022-06-23 20:45:53.914602
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    x = BrazilSpecProvider(seed=42)
    cpf = x.cpf()

    assert cpf == "350.512.278-68"


# Generated at 2022-06-23 20:45:58.854565
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Creating object
    brazilProvider = BrazilSpecProvider()
    cnpj = brazilProvider.cnpj()
    assert len(cnpj) == 18
    cnpj = cnpj.replace(".","").replace("/","").replace("-","")
    assert len(cnpj) == 14



# Generated at 2022-06-23 20:46:02.333450
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)


# Generated at 2022-06-23 20:46:04.777089
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result = provider.cnpj()
    assert len(result) == 18

# Generated at 2022-06-23 20:46:12.645466
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    for i in range(10):
        for mask in [True, False]:
            cnpj = provider.cnpj(mask)
            assert isinstance(cnpj, str)
            if mask:
                assert len(cnpj) == 18
                assert cnpj[2] == '.'
                assert cnpj[6] == '.'
                assert cnpj[10] == '/'
                assert cnpj[15] == '-'
            else:
                assert len(cnpj) == 14


# Generated at 2022-06-23 20:46:14.658029
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=4)



# Generated at 2022-06-23 20:46:17.253148
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    BS = BrazilSpecProvider()
    assert len(BS.cpf()) == 14


# Generated at 2022-06-23 20:46:19.514347
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert(brazil.cnpj(with_mask=False) == '77732304000170')
    assert(brazil.cnpj(with_mask=True) == '77.732.304/0001-70')



# Generated at 2022-06-23 20:46:26.719171
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert int(cpf[-2:]) == int(cpf[:-2]) % 11
    
    cnpj = brazil_spec_provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-23 20:46:33.468670
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print('Test BrazilSpecProvider method cnpj.')
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    cnpj = brazil_provider.cnpj(with_mask=False)
    assert len(cnpj) == 14
    print('OK.\n')


# Generated at 2022-06-23 20:46:36.798448
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    for i in range(1, 100):
        cnpj = provider.cnpj(with_mask=False)
        assert len(cnpj) == 14

# Generated at 2022-06-23 20:46:41.897105
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-23 20:46:45.572590
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    Brazil = BrazilSpecProvider()
    print(Brazil.random)
    print(Brazil.cnpj())
    print(Brazil.cpf())
    print(Brazil.reg_exp('CPF'))
    print(Brazil.reg_exp('CNPJ'))
#test_BrazilSpecProvider()

# Generated at 2022-06-23 20:46:52.526160
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    mask = bsp.cpf()
    assert mask == '775.987.500-83'
    mask = bsp.cpf(False)
    assert mask == '77598750083'
    mask = bsp.cnpj()
    assert mask == '96.876.065/0001-92'
    mask = bsp.cnpj(False)
    assert mask == '96868060000192'

# Generated at 2022-06-23 20:46:55.958601
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b_provider = BrazilSpecProvider()
    assert b_provider.cpf() == '117.427.560-96'
    assert b_provider.cnpj() == '31.955.547/0001-29'

# Generated at 2022-06-23 20:46:57.989072
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    # testando o método cpf()
    brazil.cpf()
    brazil.cnpj()

# Generated at 2022-06-23 20:47:00.639628
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().cpf() == '965.065.934-25'
    assert BrazilSpecProvider().cnpj() == '01.868.493/0093-31'

# Generated at 2022-06-23 20:47:10.289177
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider

    """
    brazil_provider = BrazilSpecProvider()
    brazil_provider.seed(0)
    # Test method with_mask = False
    cnpj = brazil_provider.cnpj(False)
    assert(cnpj == '55581687289837')
    # Test method with_mask = True
    cnpj = brazil_provider.cnpj(True)
    assert(cnpj == '55.581.687/2898-37')
