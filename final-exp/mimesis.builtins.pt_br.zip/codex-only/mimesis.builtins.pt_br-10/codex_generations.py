

# Generated at 2022-06-23 20:37:12.373428
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    print('-----Test if successfully initialize the class BrazilSpecProvider-----')
    print(brazil)


# Generated at 2022-06-23 20:37:17.555529
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()

    assert provider.cnpj() == '41.593.797/0001-80'
    assert provider.cnpj(with_mask=False) == '41593796200180'


# Generated at 2022-06-23 20:37:24.389583
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    seed = 12345
    brazil_spec_provider = BrazilSpecProvider(seed)
    assert  brazil_spec_provider.cpf(False) == '65009162812'
    assert  brazil_spec_provider.cpf() == '650.091.628-12'
    assert  brazil_spec_provider.cnpj(False) == '32839221000114'
    assert  brazil_spec_provider.cnpj() == '32.839.221/0001-14'



# Generated at 2022-06-23 20:37:27.929710
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    providers = [
        BrazilSpecProvider(),
    ]
    assert_cnpj = '77.732.230/0001-70'
    for provider in providers:
        result = provider.cnpj()
        assert len(result) == 18
        assert result == assert_cnpj


# Generated at 2022-06-23 20:37:29.944962
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    assert isinstance(a.cpf(), str)


# Generated at 2022-06-23 20:37:32.389171
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.__str__() == 'BrazilSpecProvider(pt-br)'



# Generated at 2022-06-23 20:37:35.304906
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    brazil_specprovider = BrazilSpecProvider()
    assert brazil_specprovider.__class__.__name__ == 'BrazilSpecProvider'
    

# Generated at 2022-06-23 20:37:38.421892
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()
    assert p.cpf(with_mask=False)
    assert p.cnpj()
    assert p.cnpj(with_mask=False)

# Generated at 2022-06-23 20:37:45.738008
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider as bzsp
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider

    seed = 10987654321

    # test using random
    bz = bzsp()
    bz.random.seed(seed)
    cpf = bz.cpf(with_mask=False)
    assert cpf == '83713262357'
    assert bz.cpf(with_mask=True) == '837.132.623-57'

    # test using seed
    bz = BrazilSpecProvider(seed)
    cpf = bz.cpf(with_mask=False)
    assert cpf == '83713262357'
    assert bz.cpf

# Generated at 2022-06-23 20:37:47.172885
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    print(brazil.cpf())

# Generated at 2022-06-23 20:37:49.198733
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '475.541.293-90'



# Generated at 2022-06-23 20:37:51.020727
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test constructor of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    assert isinstance(brazil, BrazilSpecProvider)

# Generated at 2022-06-23 20:37:53.897359
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
	provider = BrazilSpecProvider()
	assert provider.cpf() == "887.913.982-24", "DEVE PASSAR"
	assert provider.cnpj() == "45.818.919/0001-00", "DEVE PASSAR"


# Generated at 2022-06-23 20:37:54.626426
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:37:57.153166
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=42)
    assert provider.cpf() == "841.029.647-04"
    assert provider.cnpj() == "61.314.130/0013-42"

# Generated at 2022-06-23 20:37:58.846658
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(False)
    try:
        assert int(cpf)
        assert len(cpf) == 11
    except ValueError:
        assert False



# Generated at 2022-06-23 20:38:00.088831
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert isinstance(cpf,str)
    assert len(cpf) == 14


# Generated at 2022-06-23 20:38:03.590754
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert b.cnpj() == '01.098.528/0001-09'
    assert b.cnpj(False) == '01098528000109'



# Generated at 2022-06-23 20:38:06.700096
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    cpf = BrazilSpecProvider.cpf()
    assert re.match('\d{3}\.\d{3}\.\d{3}-\d{2}', cpf) is not None


# Generated at 2022-06-23 20:38:09.441353
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 14
    assert b.cpf(with_mask=False) == '63130635056'


# Generated at 2022-06-23 20:38:13.747122
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 18

    assert isinstance(bsp.cnpj(with_mask=False), str)
    assert bsp.cnpj(with_mask=False).isdigit()
    assert len(bsp.cnpj(with_mask=False)) == 14



# Generated at 2022-06-23 20:38:16.191409
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=False) == '86007198026'
    assert len(provider.cpf()) == 14


# Generated at 2022-06-23 20:38:17.614154
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    print(brazil_spec_provider.cpf())

# Generated at 2022-06-23 20:38:19.756600
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('BrazilSpecProvider()')
    BrazilSpecProvider(seed=None)


# Generated at 2022-06-23 20:38:21.887148
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    ptbr = BrazilSpecProvider()
    assert ptbr.cnpj() != ptbr.cnpj()


# Generated at 2022-06-23 20:38:24.876573
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    assert(brazilSpecProvider.meta.name == 'brazil_provider')


# Generated at 2022-06-23 20:38:28.449130
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()

    # Test for method cpf()
    cpf_test = '772.323.000/0001-70'
    print(brazil.cpf())
    assert brazil.cpf() != cpf_test
    assert brazil.cpf(with_mask=True) == cpf_test
    assert brazil.cpf(with_mask=False) != cpf_test

# Generated at 2022-06-23 20:38:33.731559
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.helpers import reify

    data = {'cpf': '', 'with_mask': True}

    brazil = BrazilSpecProvider()
    cpf = brazil.cpf
    assert reify(cpf, data) is not None
    assert len(reify(cpf, data)) == 14

    data['with_mask'] = False

    assert reify(cpf, data) is not None
    assert len(reify(cpf, data)) == 11


# Generated at 2022-06-23 20:38:39.948444
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    c = BrazilSpecProvider()
    cnpj = c.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == "."
    assert cnpj[6] == "."
    assert cnpj[10] == "/"
    assert cnpj[15] == "-"


# Generated at 2022-06-23 20:38:44.756550
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    # Arrange
    from mimesis.enums import Gender

    brazil_spec_provider = BrazilSpecProvider()

    # Act
    result = brazil_spec_provider.cnpj(True)

    # Assert
    assert result != ''


# Generated at 2022-06-23 20:38:54.855732
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test that BrazilSpecProvider.cnpj returns a valid cnpj."""
    from mimesis.exceptions import NonFieldError
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(with_mask=False)
    cnpj_int = int(cnpj)
    assert isinstance(cnpj, str)
    assert isinstance(cnpj_int, int)
    last_digit = cnpj_int % 10
    firat_to_last_digit = cnpj_int // 10 % 100
    assert len(cnpj) == 14
    assert last_digit == 0
    assert firat_to_last_digit == 0
    assert len(brazil.cnpj(with_mask=True)) == 18

# Generated at 2022-06-23 20:39:01.689307
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender

    b = BrazilSpecProvider(Gender.MALE)
    cnpj = b.cnpj()
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

    cnpj = b.cnpj(with_mask=False)
    assert len(cnpj) == 14


# Generated at 2022-06-23 20:39:03.985082
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    brazil = BrazilSpecProvider()
    print(brazil.cpf())

# Generated at 2022-06-23 20:39:11.438527
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    assert cnpj[:2].isdigit()
    assert cnpj[3:6].isdigit()
    assert cnpj[7:10].isdigit()
    assert cnpj[11:15].isdigit()
    assert cnpj[16:].isdigit()


# Generated at 2022-06-23 20:39:17.029609
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf of class BrazilSpecProvider."""

    bsp = BrazilSpecProvider()
    print (bsp.cpf()) # Ex: 870.030.841-44
    print (bsp.cpf(with_mask=False)) # Ex: 97308701796


# Generated at 2022-06-23 20:39:20.867074
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert len(BrazilSpecProvider().cpf()) == 14
    assert len(BrazilSpecProvider().cpf(with_mask=False)) == 11
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14


# Generated at 2022-06-23 20:39:24.560860
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf(with_mask=True)
    cnpj = bsp.cnpj(with_mask=True)

    assert isinstance(cpf, str)

    assert isinstance(cnpj, str)


# Generated at 2022-06-23 20:39:31.591282
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    first_dv = cnpj[len(cnpj)-2]
    second_dv = cnpj[len(cnpj)-1]
    try:
        first_dv = int(first_dv)
        second_dv = int(second_dv)
    except Exception as e:
        print(e)
    assert first_dv >= 0 and first_dv < 10
    assert second_dv >= 0 and second_dv < 10


# Generated at 2022-06-23 20:39:35.026791
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test whether method cpf of class BrazilSpecProvider is working
    assert len(BrazilSpecProvider().cpf(with_mask=True)) == 14


# Generated at 2022-06-23 20:39:38.189530
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider(seed = '1')
    assert provider.cpf(with_mask = True) == '000.000.002-00'


# Generated at 2022-06-23 20:39:39.771947
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj_brazil = BrazilSpecProvider()
    assert obj_brazil is not None

# Generated at 2022-06-23 20:39:41.932708
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BrazilSpecProvider().cnpj(True)


# Generated at 2022-06-23 20:39:49.797726
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the BrazilSpecProvider method cnpj."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    from mimesis.providers.country import Country
    from mimesis.providers.bank import Bank
    from mimesis.providers.address import Address

    br_person = Person('pt-br')
    br_internet = Internet('pt-br')
    br_country = Country("pt-br")
    bank = Bank("pt-br")
    address = Address("pt-br")
    br_spec = BrazilSpecProvider()
    print("Digite o número de CPF válidos: ")
    cpf_counter = int(input())

# Generated at 2022-06-23 20:39:54.941392
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pt-br')
    cpf = p.cpf()
    dv = p.cpf(gender=Gender.FEMALE, with_mask=False)
    
    assert len(cpf) == 14
    assert len(dv) == 11
    return cpf, dv


# Generated at 2022-06-23 20:40:00.367344
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test BrazilSpecProvider by instantiating the class."""
    class_name = 'BrazilSpecProvider'
    class_ = BrazilSpecProvider

    # Create BrazilSpecProvider object
    obj = class_()

    # Test if object is instance of class
    assert isinstance(obj, class_)


# Generated at 2022-06-23 20:40:02.112714
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cnpj())
    print(brazil_provider.cnpj(False))


# Generated at 2022-06-23 20:40:05.026044
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=1)

    result = provider.cpf()
    assert result == '987.560.938-00'

    result = provider.cnpj()
    assert result == '65.462.053/0001-91'

# Generated at 2022-06-23 20:40:07.098133
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider for testing validity of class."""
    provider = BrazilSpecProvider()
    print(provider.cnpj())
    print(provider.cpf())

# Generated at 2022-06-23 20:40:10.371124
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Verifica o construtor da classe BrazilSpecProvider."""
    BrazilSpecProvider()

# Generated at 2022-06-23 20:40:14.711523
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    print(BrazilSpecProvider().cpf())
    print(BrazilSpecProvider().cpf(with_mask=False))
    # Criar método para retornar a lista de estados brasileiros
    #print(BrazilSpecProvider().address(gender=Gender.MALE))


# Generated at 2022-06-23 20:40:17.790634
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    response = provider.cpf()
    assert len(response) == 14 or len(response) == 11


# Generated at 2022-06-23 20:40:27.251445
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil = BrazilSpecProvider()

    cpf = brazil.cpf()
    assert len(cpf) == 14, f'length {len(cpf)}  not equal to 14'
    assert cpf[3] == '.', 'must have the period char on fourth char'
    assert cpf[7] == '.', 'must have the period char on eighth char'
    assert cpf[11] == '-', 'must have the dash char on twelfth char'

    cpf = brazil.cpf(with_mask=False)
    assert len(cpf) == 11, f'length {len(cpf)}  not equal to 11'


# Generated at 2022-06-23 20:40:30.780356
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
	print("Testing Constructor of BrazilSpecProvider...")
	test_object = BrazilSpecProvider()
	test_object.cnpj()
	test_object.cpf()

if __name__ == "__main__":
	test_BrazilSpecProvider()

# Generated at 2022-06-23 20:40:40.178839
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    provider = BrazilSpecProvider()

    cpf = provider.cpf(with_mask=False)

    assert len(cpf) == 11

    assert provider.cpf(with_mask=False) != provider.cpf(
        with_mask=False
    )

    provider = BrazilSpecProvider()

    assert len(provider.cpf()) == 14

    assert provider.cpf() != provider.cpf()

    provider = BrazilSpecProvider()

    assert provider.cpf(with_mask=False).isdigit() is True
    assert provider.cpf(with_mask=False).isnumeric() is True



# Generated at 2022-06-23 20:40:43.030909
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18
    assert type(cnpj) is str


# Generated at 2022-06-23 20:40:46.009683
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14
    assert BrazilSpecProvider().cpf().count('.') == 2
    assert BrazilSpecProvider().cpf().count('-') == 1


# Generated at 2022-06-23 20:40:49.720520
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider(seed=1)
    expect = '001.137.297-40'
    assert bsp.cpf() == expect


# Generated at 2022-06-23 20:40:53.398886
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for i in range(10):
        result = provider.cpf(with_mask=True)
        assert len(result) == 14
        assert '.' in result
        assert '-' in result


# Generated at 2022-06-23 20:40:54.387267
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pass


# Generated at 2022-06-23 20:40:55.457385
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    c = BrazilSpecProvider()


# Generated at 2022-06-23 20:40:59.698879
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Checks if the BrazilSpecProvider.cnpj method works correctly."""
    bsp = BrazilSpecProvider(seed=42)
    result = bsp.cnpj()
    assert result == '77.732.230/0001-70'

    result = bsp.cnpj(with_mask=False)
    assert result == '77732230000170'

# Generated at 2022-06-23 20:41:02.014090
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Test BrazilSpecProvider - constructor:")
    test_obj = BrazilSpecProvider()
    assert_equal(test_obj.locale, "pt-br")
    assert_true(test_obj.seed.__class__ == int)


# Generated at 2022-06-23 20:41:04.746629
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert isinstance(bsp, BrazilSpecProvider)

# Generated at 2022-06-23 20:41:07.415054
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf(with_mask=False)
    assert brazil.cnpj(with_mask=False)

# Generated at 2022-06-23 20:41:09.718302
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider._data['cnpj'] is not None
    assert provider._data['cpf'] is not None

# Generated at 2022-06-23 20:41:13.778613
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    prov = BrazilSpecProvider()
    cnpj = prov.cnpj()
    assert prov.cnpj() == cnpj
    assert len(cnpj) == 14
    assert prov.cnpj(False) == cnpj


# Generated at 2022-06-23 20:41:15.003449
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    print(provider.cpf())


# Generated at 2022-06-23 20:41:19.293448
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert cpf[12:].isdigit()
    assert cpf[:12].replace('.', '').replace('-', '').isdigit()


# Generated at 2022-06-23 20:41:27.535538
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    provider = BrazilSpecProvider()
    # test cpf with mask
    cpf = provider.cpf()
    cpf_str_list = cpf.split('.')
    assert len(cpf_str_list) == 3
    cpf_str_list = cpf_str_list[2].split('-')
    assert len(cpf_str_list) == 2
    # test cpf without mask
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11
    cpf_int_list = [int(i) for i in cpf]
    # test digit sum
    digit_sum = 0
    weight = 10

# Generated at 2022-06-23 20:41:32.739600
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    # TODO
    # print(provider.cpf())
    # print(provider.cnpj())
    # print(provider.cnpj(with_mask=False))
    # print(provider.cpf(with_mask=False))
    # print(provider.cnpj(with_mask=False))

# Generated at 2022-06-23 20:41:39.367523
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    data_test = {}

    #test só com o primeiro argumento: with_mask
    for with_mask in [True, False]:
        seed = with_mask
        data_test[seed] = BrazilSpecProvider(seed=seed).cnpj(with_mask)
        print(data_test[seed])

if __name__ == "__main__":
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-23 20:41:43.790975
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert '.' in cpf
    assert '-' in cpf
    cpf_without_mask = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf_without_mask) == 11
    assert '.' not in cpf_without_mask
    assert '-' not in cpf_without_mask


# Generated at 2022-06-23 20:41:45.484189
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bs = BrazilSpecProvider()
    assert bs.cpf() != bs.cpf()


# Generated at 2022-06-23 20:41:49.481179
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("Test method cnpj of class BrazilSpecProvider")
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print("Random CNPJ: ", cnpj)
    print("Type of random CNPJ: ", type(cnpj))
    assert type(cnpj) is str


# Generated at 2022-06-23 20:41:51.001086
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()


# Generated at 2022-06-23 20:41:52.258622
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec = BrazilSpecProvider()
    print(brazil_spec.cpf())

# Generated at 2022-06-23 20:41:59.848558
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert cpf[3] == cpf[7] == '.' 
    assert cpf[11] == '-' 
    assert cpf[0:3].isdigit()
    assert cpf[4:7].isdigit()
    assert cpf[8:11].isdigit()
    assert cpf[12:14].isdigit()
    assert len(cpf) == 14
    assert type(cpf) == str
    print(f'{cpf} test succeeded')


# Generated at 2022-06-23 20:42:03.623442
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpjs = [] # list to store 20 different cnpjs
    #get 20 different cnpjs
    for i in range(21):
        cnpjs.append(BrazilSpecProvider().cnpj())

    #test if list has 20 different cnpjs
    assert len(cnpjs) == len(set(cnpjs))


# Generated at 2022-06-23 20:42:05.912715
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    obj = BrazilSpecProvider()
    print(obj)

# Generated at 2022-06-23 20:42:06.437277
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    obj = BrazilSpecProvider()



# Generated at 2022-06-23 20:42:13.814996
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider()
    assert isinstance(obj.cnpj(), str)
    assert obj.cnpj() == '22.906.916/0001-32'
    assert obj.cnpj() == '83.092.746/0001-17'
    assert obj.cnpj() == '09.130.038/0001-94'
    assert obj.cnpj() == '72.907.619/0001-63'
    assert obj.cnpj() == '57.409.105/0001-07'
    obj = BrazilSpecProvider('0123456789')
    assert obj.cnpj() == '24.798.913/0001-54'
    obj = BrazilSpecProvider('1234567890')

# Generated at 2022-06-23 20:42:18.975420
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    bsp = BrazilSpecProvider()
    if bsp.cnpj() == '77.732.230/0001-70':
        print("Test Passed!")
    else:
        print("Test Failed!")


# Generated at 2022-06-23 20:42:23.218918
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider()
    assert isinstance(instance, BrazilSpecProvider)
    assert isinstance(instance, BaseSpecProvider)
    assert isinstance(instance.seed, int)
    assert isinstance(instance._data, dict)
    assert instance._validate_seed('seed') == None


# Generated at 2022-06-23 20:42:27.428963
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test function for class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    assert brazil.cpf() != None
    assert brazil.cnpj() != None


# Generated at 2022-06-23 20:42:36.654466
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    mask_result = provider.cnpj()
    assert len(mask_result) == 18
    assert mask_result[:2].isnumeric()
    assert mask_result[3:6].isnumeric()
    assert mask_result[7:10].isnumeric()
    assert mask_result[11:16].isnumeric()
    assert mask_result[17:].isnumeric()
    assert mask_result[2] == "."
    assert mask_result[6] == "."
    assert mask_result[10] == "/"
    assert mask_result[16] == "-"

    no_mask_result = provider.cnpj(with_mask=False)
    assert len(no_mask_result) == 14
    assert no_mask_result.isnumeric()



# Generated at 2022-06-23 20:42:38.286425
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj()

# Generated at 2022-06-23 20:42:42.116694
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider class"""
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'



# Generated at 2022-06-23 20:42:44.392826
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:42:48.315515
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilian_data_provider = BrazilSpecProvider(seed=42)
    assert brazilian_data_provider.__class__.__name__ == 'BrazilSpecProvider'
    assert brazilian_data_provider.__module__ == 'mimesis.builtins.br'
    assert brazilian_data_provider.__doc__ is not None


# Generated at 2022-06-23 20:42:52.194744
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    # Arrange
    provider = BrazilSpecProvider()

    # Act
    result_1 = provider.cnpj(with_mask=False)

    # Assert
    assert len(result_1) == 14


# Generated at 2022-06-23 20:43:00.038498
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from datetime import datetime
    from random import seed
    from sys import version_info
    from re import sub
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from datetime import datetime
    from random import seed
    from sys import version_info
    from re import sub
    
    if version_info.major < 3:
        int = long  # noqa

    p = Person('pt-br' )
    seed(int(datetime.now().strftime("%s")))

    assert p.cpf() == BrazilSpecProvider().cpf()

    if version_info.major < 3:
        int = long  # noqa


# Generated at 2022-06-23 20:43:11.097893
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Create instance
    brazil_provider = BrazilSpecProvider()

    # CPF
    assert isinstance(brazil_provider.cpf(), str)
    assert isinstance(brazil_provider.cpf(with_mask=True), str)
    assert brazil_provider.cpf()[3] == '.'
    assert len(brazil_provider.cpf()) == 14

    # CNPJ
    assert isinstance(brazil_provider.cnpj(), str)
    assert isinstance(brazil_provider.cnpj(with_mask=True), str)
    assert brazil_provider.cnpj()[2] == '.'
    assert len(brazil_provider.cnpj()) == 18

# Generated at 2022-06-23 20:43:13.344014
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert len(brazil.cnpj()) == 18



# Generated at 2022-06-23 20:43:18.085224
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.isdecimal() is True
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:43:21.407902
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test function cnpj."""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14



# Generated at 2022-06-23 20:43:24.163475
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    provider_pt_BR = BrazilSpecProvider()
    assert provider_pt_BR.cpf() == '050.566.921-10'


# Generated at 2022-06-23 20:43:31.049379
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    "test BrazilSpecProvider method cnpj, ensure that \
    returned value is properly formatted"
    assert BrazilSpecProvider().cnpj(with_mask=False).__len__() == 14
    assert BrazilSpecProvider().cnpj(with_mask=True).__len__() == 18
    assert BrazilSpecProvider().cnpj(with_mask=True)[2:3] == '.'
    assert BrazilSpecProvider().cnpj(with_mask=True)[6:7] == '.'
    assert BrazilSpecProvider().cnpj(with_mask=True)[10:11] == '/'
    assert BrazilSpecProvider().cnpj(with_mask=True)[15:16] == '-'

# Generated at 2022-06-23 20:43:33.922021
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    f = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(f) == 14



# Generated at 2022-06-23 20:43:38.391035
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import re
    provider = BrazilSpecProvider()
    for _ in range(10):
        cnpj = provider.cnpj()
        print(cnpj)
        assert re.match(r"[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}-[0-9]{2}", cnpj) is not None


# Generated at 2022-06-23 20:43:39.689193
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print(BrazilSpecProvider().cpf(with_mask=True))


# Generated at 2022-06-23 20:43:48.114364
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Method cnpj with parameter False
    assert BrazilSpecProvider().cnpj(False) == '7773223000170'
    # Method cnpj with parameter True
    assert BrazilSpecProvider().cnpj(True) == '77.732.230/0001-70'
    # Method mask_cnpj
    assert BrazilSpecProvider().mask_cnpj('7773223000170') == '77.732.230/0001-70'
    # Method unmask_cnpj
    assert BrazilSpecProvider().unmask_cnpj('77.732.230/0001-70') == '7773223000170'


# Generated at 2022-06-23 20:43:56.945353
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("test_BrazilSpecProvider")
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    cpf_with_mask = brazil_provider.cpf(True)
    print("cpf: ", cpf)
    print("cpf_with_mask: ", cpf_with_mask)
    cnpj = brazil_provider.cnpj()
    cnpj_with_mask = brazil_provider.cnpj(True)
    print("cnpj: ", cnpj)
    print("cnpj_with_mask: ", cnpj_with_mask)


if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:43:59.989197
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider
    # This should always pass so long as there are no bugs in the above code.
    """
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-23 20:44:06.730527
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.enums import PersonTitle
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.builtins import Person

    p = Person('pt_br')
    p.seed(42)
    bsp = BrazilSpecProvider('pt_br')
    bsp.seed(42)

    nome = p.full_name(gender=Gender.FEMALE, title=PersonTitle.MRS)
    sobrenome = p.last_name()
    cpf = bsp.cpf()
    assert cpf == '578.398.527-94'


# Generated at 2022-06-23 20:44:09.946982
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for method cpf of class BrazilSpecProvider."""
    b = BrazilSpecProvider()

    random_cpf = b.cpf()
    assert len(random_cpf) == 14
    assert random_cpf[3] == '.'
    assert random_cpf[7] == '.'
    assert random_cpf[11] == '-'


# Generated at 2022-06-23 20:44:11.909188
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '805.851.782-49'



# Generated at 2022-06-23 20:44:17.143964
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # CPFs generated with: http://www.geradordecpf.org/
    # The website doesn't generate CPF with valid verification digit
    # but analyzer in Brazil doesn't validate the verification digit.
    cpf_generated = BrazilSpecProvider().cpf()

# Generated at 2022-06-23 20:44:22.248956
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    testCase = BrazilSpecProvider()
    # Test 1
    cnpj = testCase.cnpj()
    assert len(cnpj) == 18

    # Test 2
    cnpj = testCase.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:44:25.427758
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf)
    assert len(provider.cpf())
    assert len(provider.cpf(with_mask=False))



# Generated at 2022-06-23 20:44:27.085821
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert cpf == '029.449.906-90', 'CPF {}'.format(cpf)


# Generated at 2022-06-23 20:44:29.754397
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider('seed') is not None
    assert BrazilSpecProvider('seed').cpf() is not None
    assert BrazilSpecProvider('seed').cnpj() is not None

    assert BrazilSpecProvider('seed').cpf(False) is not None
    assert BrazilSpecProvider('seed').cnpj(False) is not None

# Generated at 2022-06-23 20:44:37.746200
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Function to test the constructor of BrazilSpecProvider class
    """
    print("Test constructor of BrazilSpecProvider class...")
    try:
        brazil_spec_provider = BrazilSpecProvider()
        print("BrazilSpecProvider class instantiated successfully")
    except Exception as e:
        print("Error instantiating BrazilSpecProvider class")
        print("\t{}: {}".format(type(e).__name__, str(e)))
    print("\n")


# Generated at 2022-06-23 20:44:40.367345
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider constructor."""
    BrazilSpecProvider("123")


# Generated at 2022-06-23 20:44:52.050583
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Brazilian locale should be available, but only if Portuguese locale is available
    brazil_provider = BrazilSpecProvider()
    assert 'brazil_provider' == brazil_provider.Meta.name

    # Checks if it's a new instance of the class BrazilSpecProvider
    brazil_provider2 = BrazilSpecProvider()
    brazil_provider3 = BrazilSpecProvider()
    assert brazil_provider is not brazil_provider2
    assert brazil_provider3 is not brazil_provider2
    assert brazil_provider is not brazil_provider3

    # Checks if cpf returns a string
    cpf = brazil_provider.cpf()
    assert isinstance(cpf, str)

    # Checks if cnpj returns a string
    cnpj = brazil_provider.cnpj

# Generated at 2022-06-23 20:44:53.659918
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == "77.732.230/0001-70"


# Generated at 2022-06-23 20:44:55.508683
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf(with_mask=False) == '00113729740'


# Generated at 2022-06-23 20:44:56.918364
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)

# Generated at 2022-06-23 20:44:58.110739
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    try:
        BrazilSpecProvider(seed=HashableSeed(1))
    except:
        raise unittest.SkipTest("Seed is not hashable")



# Generated at 2022-06-23 20:45:01.349700
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == provider.cnpj(with_mask=False)



# Generated at 2022-06-23 20:45:03.397862
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert (len(b.cpf())) == 14


# Generated at 2022-06-23 20:45:07.691569
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider."""
    provider1 = BrazilSpecProvider()
    assert provider1.locale == 'pt-br'
    assert provider1.seed is None

    provider2 = BrazilSpecProvider(seed=1234)
    assert provider2.locale == 'pt-br'
    assert provider2.seed == 1234

# Generated at 2022-06-23 20:45:11.921763
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
#     print(cnpj)
    if (cnpj[2] != '.'):
        print('FAIL!!!')


# Generated at 2022-06-23 20:45:19.284623
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Create BrazilSpecProvider instance
    braz = BrazilSpecProvider()
    # Execute cpf method
    result = braz.cpf()
    # Check if the result is valid
    assert len(result) == 14
    assert result[3] == '.'
    assert result[7] == '.'
    assert result[11] == '-'
    assert int(result[:3]) < 1000
    assert int(result[4:7]) < 1000
    assert int(result[8:11]) < 1000
    assert int(result[12:14]) < 100


# Generated at 2022-06-23 20:45:21.899508
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    locale = 'pt-br'
    provider = BrazilSpecProvider(locale)
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:45:25.031161
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    assert br.cnpj() != br.cnpj()


# Generated at 2022-06-23 20:45:34.153935
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    def get_number_of_digits(cnpj:str):
        if len(cnpj) == 14:
            return 1
        if len(cnpj) == 18:
            return 2
    assert provider.cnpj() == '10.823.095/0001-05'
    assert provider.cnpj(with_mask=True) == '10.823.095/0001-05'
    assert provider.cnpj(with_mask=False) == '10823095000105'
    cnpj = provider.cnpj()
    assert len(cnpj) == 14 or len(cnpj) == 18
    assert get_number_of_digits(cnpj) == 18

# Generated at 2022-06-23 20:45:36.744771
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    assert BrazilSpecProvider().cpf(False) == "55542837862"


# Generated at 2022-06-23 20:45:38.237920
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test of constructor of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    assert brazil


# Generated at 2022-06-23 20:45:43.773487
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of class BrazilSpecProvider."""
    from mimesis.enums import Flavor

    brazil_provider = BrazilSpecProvider(seed=123456)

    assert brazil_provider._seed == 123456
    assert brazil_provider._flavor == Flavor.ENTROPY
    assert brazil_provider.locale == 'pt-br'


# Generated at 2022-06-23 20:45:45.048026
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    x = BrazilSpecProvider()
    assert isinstance(x, BrazilSpecProvider)


# Generated at 2022-06-23 20:45:47.291245
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bz = BrazilSpecProvider()
    cpf = bz.cpf()
    print(cpf)
    # 001.137.297-40


# Generated at 2022-06-23 20:45:50.729521
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider(seed=10).cpf()
    # print ('Testing the BrazilSpecProvider ...')
    # result = BrazilSpecProvider(seed=10).cpf()
    # assert result == '056.177.862-89'
    # print('[ok] Method cpf of BrazilSpecProvider works properly')



# Generated at 2022-06-23 20:45:53.464508
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18

# Generated at 2022-06-23 20:45:57.720922
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    #print("Test constructor of class BrazilSpecProvider")
    #print("provider.cpf()=", provider.cpf())
    #print("provider.cnpj()=", provider.cnpj())
    
test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:59.407197
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(with_mask=False) == '74746481000150'


# Generated at 2022-06-23 20:46:01.137759
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert(cpf[3] == '.')
    assert(len(cpf) == 14)


# Generated at 2022-06-23 20:46:12.736092
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """ Test method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    mask = '##.###.###/####-##'
    cnpj = provider.cnpj(with_mask=False)
    assert len(re.findall(r'\d{2}', cnpj[:2])) == 1
    assert len(re.findall(r'\d{3}', cnpj[3:6])) == 1
    assert len(re.findall(r'\d{3}', cnpj[7:10])) == 1
    assert len(re.findall(r'\d{4}', cnpj[11:15])) == 1
    assert len(re.findall(r'\d{2}', cnpj[16:])) == 1



# Generated at 2022-06-23 20:46:17.099971
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider class."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pt-br', gender=Gender.MALE)
    print(p.cpf())



# Generated at 2022-06-23 20:46:19.260310
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bs = BrazilSpecProvider()
    assert bs.cnpj()

    bs = BrazilSpecProvider()
    assert bs.cpf()

# Generated at 2022-06-23 20:46:20.550848
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    b.cpf()
    b.cnpj()

# Generated at 2022-06-23 20:46:31.892803
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed
    bsp = BrazilSpecProvider()
    assert bsp._seed._generator.uniform(0, 1) is not None
    assert bsp.cnpj() is not None
    assert bsp.cnpj(False) is not None
    assert bsp.cpf() is not None
    assert bsp.cpf(False) is not None
    assert bsp.full_name(gender=Gender.MALE) is not None
    assert bsp.full_name(gender=Gender.FEMALE) is not None
    assert bsp.full_name() is not None
    assert bsp.occupation() is not None

# Generated at 2022-06-23 20:46:34.685927
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cp = BrazilSpecProvider()
    print(cp.cnpj())


if __name__ == '__main__':
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-23 20:46:35.740584
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider(seed=10)

# Generated at 2022-06-23 20:46:42.569994
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    brazilProvider = BrazilSpecProvider()

    # test case 1
    cnpj = '24.735.498/0001-60'
    assert brazilProvider.cnpj(with_mask=True) == cnpj

    # test case 2
    cnpj = '93470718000121'
    assert brazilProvider.cnpj(with_mask=False) == cnpj


# Generated at 2022-06-23 20:46:45.813065
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    cpf = brazilSpecProvider.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf == '025.843.778-61'



# Generated at 2022-06-23 20:46:48.986154
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_example = BrazilSpecProvider().cpf(with_mask=True)
    assert cpf_example == '415.418.286-68'


# Generated at 2022-06-23 20:46:51.494984
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilprovider = BrazilSpecProvider()
    assert brazilprovider.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-23 20:46:54.037565
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf(False)) == 11
    assert len(bsp.cpf(True)) == 14

# Generated at 2022-06-23 20:47:00.119689
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    # Check mask
    assert len(provider.cnpj()) == 18
    assert len(provider.cnpj(False)) == 14
    # Check if cnpj is valid
    assert len(provider.cnpj()) == 18
    assert len(provider.cnpj(False)) == 14
    # Check if cnpj is string
    assert isinstance(provider.cnpj(), str)
    assert isinstance(provider.cnpj(False), str)

# Generated at 2022-06-23 20:47:03.205466
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brsp = BrazilSpecProvider()
    #print(brsp)
    assert isinstance(brsp, BrazilSpecProvider)


# Generated at 2022-06-23 20:47:06.892168
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14
    assert len(bsp.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:47:14.636517
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers import BrazilSpecProvider
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cnpj() in ('28.079.608/0001-89', '00.007.695/0002-07',
                                      '51.856.912/0001-09', '60.869.852/0001-09',
                                      '33.872.064/0001-04', '49.771.985/0001-55',
                                      '06.133.655/0001-86', '62.779.069/0001-93',
                                      '79.531.996/0001-38', '99.093.105/0001-56')

