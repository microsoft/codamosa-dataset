

# Generated at 2022-06-23 20:37:10.911666
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()
    BrazilSpecProvider(seed=12345)


# Generated at 2022-06-23 20:37:19.512029
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()

    assert(len(brazil.cnpj()) == 18)
    assert(len(brazil.cnpj(with_mask=False)) == 14)

    d1 = brazil.cnpj()[12:14]

    dg = sum([int(x)*(5-i) for i,x in enumerate(brazil.cnpj()[:12])]) % 11

    if dg == 0 or dg == 1:
        d2 = 0
    else:
        d2 = 11 - dg

    assert(d1 == str(d2))


# Generated at 2022-06-23 20:37:21.719958
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider

# Generated at 2022-06-23 20:37:24.111441
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider(seed=65536)
    cpf = bsp.cpf()
    assert cpf == "004.979.866-95"


# Generated at 2022-06-23 20:37:28.924446
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    Brazilian = BrazilSpecProvider()
    #CPF
    cpf = Brazilian.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.isdigit()
    #CNPJ
    cnpj = Brazilian.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert cnpj.isdigit()

# Generated at 2022-06-23 20:37:30.691482
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for BrazilSpecProvider"""
    brazilSpecProvider = BrazilSpecProvider()


# Generated at 2022-06-23 20:37:34.789526
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    result = provider.cpf(with_mask=False)
    print(result)
    assert len(result) == 11

    result = provider.cnpj(with_mask=False)
    print(result)
    assert len(result) == 14


# Generated at 2022-06-23 20:37:38.564998
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert(len(brazil.cpf()) == 14)
    assert(len(brazil.cpf(with_mask=False)) == 11)


# Generated at 2022-06-23 20:37:39.601805
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    print(bsp.cnpj())

# Generated at 2022-06-23 20:37:43.561126
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider"""
    assert BrazilSpecProvider().cnpj() != BrazilSpecProvider().cnpj()
    assert BrazilSpecProvider().cnpj() != BrazilSpecProvider().cnpj()
    assert BrazilSpecProvider().cnpj() != BrazilSpecProvider().cnpj()
    assert BrazilSpecProvider().cnpj() != BrazilSpecProvider().cnpj()


# Generated at 2022-06-23 20:37:50.083955
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("\nBrazilSpecProvider\n")
    print("Create a object of BrazilSpecProvider")
    brasilSpecProvider = BrazilSpecProvider()

    print("Return a random CPF, without mask")
    print(brasilSpecProvider.cpf(with_mask=False))

    print("Return a random CNPJ, without mask")
    print(brasilSpecProvider.cnpj(with_mask=False))

test_BrazilSpecProvider()

# Generated at 2022-06-23 20:37:51.526173
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cnpj()

# Generated at 2022-06-23 20:37:57.120492
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
        # Create an instance of BrazilSpecProvider
        bsp = BrazilSpecProvider()

        # Generate a cnpj
        cnpj = bsp.cnpj(with_mask=True)
        # Check if method cnpj generates a valid cnpj
        assert isinstance(cnpj, str), "Type of the generated cnpj is not 'str'"
        assert len(cnpj) == 18, "len(cnpj) != 18"
        assert cnpj.isnumeric(), "The generated cnpj isn't numeric"
        assert len(cnpj) == 18, "len(cnpj) != 18"

        # Generate another cnpj without mask
        cnpj = bsp.cnpj(with_mask=False)
        # Check if method cnpj generates a valid cnpj

# Generated at 2022-06-23 20:37:59.838937
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br_spec_provider_cpf = BrazilSpecProvider()
    c = br_spec_provider_cpf.cpf()
    assert isinstance(c, str)
    assert len(c) == 14


# Generated at 2022-06-23 20:38:04.806401
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    from mimesis.builtins.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    assert len(provider.cpf(with_mask=True)) == 14
    assert len(provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:38:09.521189
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test of the method BrazilSpecProvider.cnpj()."""
    specprovider = BrazilSpecProvider()
    expectedCnpj = '14.105.539/0001-64'
    cnpj = specprovider.cnpj()
    assert (expectedCnpj == cnpj)


# Generated at 2022-06-23 20:38:11.367820
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    gen = BrazilSpecProvider()
    assert gen.cpf() == '742.412.446-40'


# Generated at 2022-06-23 20:38:15.419069
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj_1 = brazil_spec_provider.cnpj(with_mask=True)
    cnpj_2 = brazil_spec_provider.cnpj(with_mask=False)
    assert len(cnpj_1) == 18
    assert len(cnpj_2) == 14



# Generated at 2022-06-23 20:38:17.504320
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the BrazilSpecProvider method cpf."""
    brazil = BrazilSpecProvider()
    assert brazil.cpf(with_mask=True)


# Generated at 2022-06-23 20:38:20.817937
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider method cnpj."""
    expected_cnpj = '34.267.598/0001-27'
    assert BrazilSpecProvider().cnpj() == expected_cnpj


# Generated at 2022-06-23 20:38:25.561318
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for method cpf of class BrazilSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseSpecProvider

    provider = BrazilSpecProvider(BaseSpecProvider())
    # Format: ###.###.###-##
    assert provider.cpf(with_mask=True)
    # Format: #########
    assert provider.cpf(with_mask=False)



# Generated at 2022-06-23 20:38:31.196356
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    from mimesis.providers.locales.pt_br.brazil import BrazilSpecProvider
    cpf = BrazilSpecProvider()
    cpf_number = cpf.cpf()
    print("\ncpf_number:", cpf_number)
    assert isinstance(cpf_number, str)
    assert len(cpf_number.replace(".", "").replace("-", "")) == 11
    
    

# Generated at 2022-06-23 20:38:37.502658
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Run BrazilSpecProvider.cpf() unit test.
    """
    bsp = BrazilSpecProvider()
    result = bsp.cpf()
    assert result == bsp.cpf()
    result_1 = bsp.cpf(with_mask=False)
    assert result_1 == bsp.cpf(with_mask=False)


# Generated at 2022-06-23 20:38:40.610941
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.isdigit()


# Generated at 2022-06-23 20:38:48.169338
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert len(cpf) == 14
    assert cpf.count(".") == 3
    assert cpf.count("-") == 1
    assert cpf.count("/") == 0
    cpf = brazil_provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.count(".") == 0
    assert cpf.count("-") == 0
    assert cpf.count("/") == 0


# Generated at 2022-06-23 20:38:50.723906
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider(seed=12345)
    assert brazil_provider.cpf() == "077.294.449-55"

# Generated at 2022-06-23 20:38:57.782142
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    assert(cpf.__doc__ == "Get a random CPF.\n\n        :param with_mask: Use CPF mask (###.###.###-##).\n        :returns: Random CPF.\n\n        :Example:\n            001.137.297-40\n        ")

    assert(cnpj.__doc__ == "Get a random CNPJ.\n\n        :param with_mask: Use cnpj mask (###.###.###-##)\n        :returns: Random cnpj.\n\n        :Example:\n            77.732.230/0001-70\n        ")


# Generated at 2022-06-23 20:39:00.832544
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the cnpj method"""
    #define inputs
    with_mask = True
    pass
    #define outputs
    pass


# Generated at 2022-06-23 20:39:04.253953
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    print(obj.cpf())
    print(obj.cpf(with_mask=False))
    print(obj.cnpj())
    print(obj.cnpj(with_mask=False))

# Generated at 2022-06-23 20:39:06.447224
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()
    print(bp.cnpj())
    print(bp.cnpj(with_mask = False))


# Generated at 2022-06-23 20:39:07.904338
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    seed = None
    assert BrazilSpecProvider(seed).locale == 'pt-br'


# Generated at 2022-06-23 20:39:09.697397
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_provider = BrazilSpecProvider()
    assert len(test_provider.cpf(with_mask=True)) == 14


# Generated at 2022-06-23 20:39:11.857422
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for the main constructor."""

    result = "abc"
    assert BrazilSpecProvider().cpf()
    BrazilSpecProvider().cnpj()

# Generated at 2022-06-23 20:39:20.369346
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    assert len(brazilSpecProvider.cpf(True)) == 14 # cpf length is 14 with mask
    assert brazilSpecProvider.cpf(True)[3] == '.' # 1st line separator
    assert brazilSpecProvider.cpf(True)[7] == '.' # 2nd line separator
    assert brazilSpecProvider.cpf(True)[11] == '-' # 3rd line separator

    assert len(brazilSpecProvider.cpf(False)) == 11 # cpf length is 11 without mask


# Generated at 2022-06-23 20:39:23.505134
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    # Default is without mask
    cpf = provider.cpf()
    assert len(cpf) == 11
    assert cpf[3] != '.'

    # With mask
    cpf = provider.cpf(with_mask=True)
    assert len(cpf) == 14
    assert cpf[3] == '.'

# Generated at 2022-06-23 20:39:25.504468
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=True)
    print(cnpj)

# Generated at 2022-06-23 20:39:29.699112
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Method: cpf, Parameter: with_mask (default)
    # Expected value: 001.137.297-40
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:39:31.072055
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() != None
    assert provider.cnpj() != None

# Generated at 2022-06-23 20:39:40.772898
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask = True) == "002.129.152-24"
    assert provider.cnpj() == "04301324700062"
    assert provider.cnpj(with_mask = True) == "04.301.324/7006-2"
    assert provider.cpf() == "00212915224"
    assert provider.cnpj() == "04301324700062"
    assert provider.cnpj(with_mask = True) == "04.301.324/7006-2"
    assert provider.cpf() == "00212915224"
    assert provider.cnpj() == "04301324700062"
    assert provider.cnpj(with_mask = True) == "04.301.324/7006-2"

# Generated at 2022-06-23 20:39:45.661174
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Initialization
    brazilspecpv = BrazilSpecProvider()
    # Assertion
    assert brazilspecpv.cnpj() == "62.410.096/0001-57"
    assert brazilspecpv.cnpj(with_mask=False) == "62410096000157"

# Generated at 2022-06-23 20:39:49.586087
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert(provider.__class__.__name__ == 'BrazilSpecProvider')
    assert(provider.locale == 'pt-br')


# Generated at 2022-06-23 20:39:54.390206
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    data1 = BrazilSpecProvider()
    assert len(data1.cnpj()) == 18
    data2 = BrazilSpecProvider()
    assert len(data2.cnpj()) == 18
    # to check if generate always the same value, like the other test, even with seed
    data3 = BrazilSpecProvider(seed=0)
    assert len(data3.cnpj()) == 18

# Generated at 2022-06-23 20:39:58.696668
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    # generator of CNPJ validation
    assert provider.cnpj(with_mask=True)
    # generator of CPF validation
    assert provider.cpf(with_mask=True)

# Generated at 2022-06-23 20:40:02.582451
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.builtins.base import SpecProvider
    from mimesis.builtins.brazil import BrazilSpecProvider

    spec_provider = BrazilSpecProvider()
    assert isinstance(spec_provider, SpecProvider)
    assert isinstance(spec_provider, BrazilSpecProvider)


# Generated at 2022-06-23 20:40:03.842943
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 20:40:04.384089
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:40:07.098534
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Cria uma instancia de BrazilSpecProvider
    bsp = BrazilSpecProvider()
    # Chama o metodo cnpj e imprime o retorno
    print(bsp.cnpj())



# Generated at 2022-06-23 20:40:09.354738
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:40:10.324229
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == BrazilSpecProvider().cpf()


# Generated at 2022-06-23 20:40:12.214399
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:40:14.920261
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert isinstance(provider.cnpj(), str)


# Generated at 2022-06-23 20:40:16.706155
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(True) == '37.529.272/0001-69'

# Generated at 2022-06-23 20:40:18.267371
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert '913.441.099-96' == BrazilSpecProvider().cpf(with_mask=True)


# Generated at 2022-06-23 20:40:22.116800
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    seed = 'test_BrazilSpecProvider'
    provider1 = BrazilSpecProvider(seed=seed)
    provider2 = BrazilSpecProvider(seed=seed)
    assert provider1.cpf() == provider2.cpf()
    assert provider1.cnpj() == provider2.cnpj()
    assert provider1.cpf(with_mask=False) == provider2.cpf(with_mask=False)
    assert provider1.cnpj(with_mask=False) == provider2.cnpj(with_mask=False)

# Generated at 2022-06-23 20:40:23.558337
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.Meta.name == 'brazil_provider'
    assert provider.__module__ == 'mimesis.builtins.brazil_provider'

# Generated at 2022-06-23 20:40:30.513977
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()

    # Verificando se o tipo do resultado é string
    assert isinstance(result, str)

    # Verificando se o resultado tem o tamalho correto
    assert len(result) == 14

    # Verificando se o resultado é composto somente por digitos e pontos
    assert (set('0123456789.') == set(result))

test_BrazilSpecProvider_cpf()

# Generated at 2022-06-23 20:40:33.686004
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() == '006.005.759-32'


# Generated at 2022-06-23 20:40:36.423709
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.providers.brazil import BrazilSpecProvider

    bsp = BrazilSpecProvider()

    assert bsp.cpf()
    assert bsp.cnpj()

# Generated at 2022-06-23 20:40:37.926060
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider().__class__

    assert provider.name == 'brazil_provider'


# Generated at 2022-06-23 20:40:39.120872
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider.__init__(None)

# Generated at 2022-06-23 20:40:43.133621
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:40:47.023779
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    seed = '4f25a6'
    bsp = BrazilSpecProvider(seed = seed)
    cpf_test = bsp.cpf()
    cnpj_test = bsp.cnpj()
    assert cpf_test == '447.063.992-49'
    assert cnpj_test == '61.225.218/0001-93'

# Generated at 2022-06-23 20:40:49.822279
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  assert BrazilSpecProvider().cnpj() == "77.732.230/0001-70"

# Generated at 2022-06-23 20:40:55.838340
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test class BrazilSpecProvider - method cnpj."""

    assert BrazilSpecProvider().cnpj() != BrazilSpecProvider().cnpj()

    assert len(BrazilSpecProvider().cnpj()) == 18
    assert BrazilSpecProvider().cnpj(with_mask=False) != BrazilSpecProvider().cnpj(with_mask=False)
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14


# Generated at 2022-06-23 20:40:59.413142
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for BrazilSpecProvider.cnpj method."""
    pattern = r'\d{2}\.\d{3}\.\d{3}\/\d{4}\-\d{2}'
    assert re.fullmatch(pattern, BrazilSpecProvider().cnpj())


# Generated at 2022-06-23 20:41:06.119732
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of Class BrazilSpecProvider."""
    from re import match
    bz = BrazilSpecProvider()
    for _ in range(10):
        cnpj = bz.cnpj(with_mask=True)
        assert match("[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}", cnpj)
        assert len(cnpj) == 18


# Generated at 2022-06-23 20:41:12.233122
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    DATA = BrazilSpecProvider(seed=1234)

    RESULT = DATA.cpf()
    EXPECTED = '506.254.299-28'
    assert RESULT == EXPECTED

    RESULT = DATA.cpf(with_mask=False)
    EXPECTED = '50625429928'
    assert RESULT == EXPECTED


# Generated at 2022-06-23 20:41:14.421683
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Unit test for BrazilSpecProvider")
    print("\nTesting the creation of the BrazilSpecProvider class")
    print("\nWe expect the variable to be an instance of BrazilSpecProvider")

    def test_BrazilSpecProvider():
        return BrazilSpecProvider(seed=1423)

    brazil = test_BrazilSpecProvider()

    assert isinstance(brazil, BrazilSpecProvider)


# Generated at 2022-06-23 20:41:17.650861
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj()."""
    b = BrazilSpecProvider()
    assert len(b.cnpj()) == 18
    assert len(b.cnpj(with_mask=False)) == 14
    assert b.cnpj() == b.cnpj()


# Generated at 2022-06-23 20:41:24.051439
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test that cpf method works correctly."""
    brazil_cpf = BrazilSpecProvider()
    cpf = brazil_cpf.cpf()
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'

    cpf_without_mask = brazil_cpf.cpf(with_mask=False)
    assert len(cpf_without_mask) == 11



# Generated at 2022-06-23 20:41:27.171270
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilian = BrazilSpecProvider()
    assert brazilian.locale == 'pt-br'
    assert hasattr(brazilian, 'random')



# Generated at 2022-06-23 20:41:28.020125
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """ Unit test for BrazilSpecProvider()
    """
    provider = BrazilSpecProvider()
    assert provider.cnpj()
    assert provider.cpf()

# Generated at 2022-06-23 20:41:31.494254
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    spec = BrazilSpecProvider()
    test_cpf = spec.cpf()
    test_cpf_with_mask = spec.cpf(with_mask=True)
    test_cnpj = spec.cnpj()
    test_cnpj_with_mask = spec.cnpj(with_mask=True)
    assert test_cpf.isdigit() == True, 'Return a digit for cpf'
    assert len(test_cpf) == 11, 'Return a correct length of cpf(11)'
    assert test_cpf_with_mask[3] == '.', 'Return cpf with mask(.) in correct position'
    assert test_cpf_with_mask[7] == '.', 'Return cpf with mask(.) in correct position'

# Generated at 2022-06-23 20:41:32.783954
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    spec_provider = BrazilSpecProvider()
    assert spec_provider is not None

# Generated at 2022-06-23 20:41:35.980210
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '241.515.979-36'


# Generated at 2022-06-23 20:41:39.445831
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf"""
    import pytest
    from mimesis.providers.datetime.datetime import Datetime
    from mimesis.providers.person.person import Person

    from .__common__ import assert_cpf

    dt = Datetime(seed=20200101)
    person = Person()
    brp = BrazilSpecProvider()

    for _ in range(10):
        cpf = brp.cpf()
        assert_cpf(cpf)


# Generated at 2022-06-23 20:41:42.246151
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    ob = BrazilSpecProvider()

    assert ob.cpf() is not None
    assert ob.cpf() != ob.cpf()
    assert ob.cnpj() is not None
    assert ob.cnpj() != ob.cnpj()

# Generated at 2022-06-23 20:41:43.927303
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cpf = BrazilSpecProvider().cnpj()
    print(cpf)


# Generated at 2022-06-23 20:41:51.626805
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test case for method cpf of class BrazilSpecProvider."""
    brazil_provider = BrazilSpecProvider()
    cpf_1 = brazil_provider.cpf()
    assert isinstance(cpf_1, str)
    assert len(cpf_1) == 14
    assert cpf_1[3] == "."
    assert cpf_1[7] == "."
    assert cpf_1[11] == "-"

    cpf_2 = brazil_provider.cpf(with_mask=False)
    assert isinstance(cpf_2, str)
    assert len(cpf_2) == 11


# Generated at 2022-06-23 20:41:57.645181
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider class."""
    print("Unit test for BrazilSpecProvider class")
    provider = BrazilSpecProvider()
    print("CPF CPF: {}".format(provider.cpf()))
    print()
    print("CNPJ CNPJ: {}".format(provider.cnpj()))

# Unit test to run the module
if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:42:00.150978
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    prov = BrazilSpecProvider()
    assert prov.cpf(with_mask=True) not in ['123.456.789-01', '000.000.000-00']


# Generated at 2022-06-23 20:42:07.546048
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider(seed=1)
    # Test random cpf
    cpf = b.cpf()
    assert cpf == '826.127.163-79'
    # Test cpf without mask
    cpf = b.cpf(with_mask=False)
    assert cpf == '82612716379'
    # Test cpf with mask
    cpf = b.cpf(with_mask=True)
    assert cpf == '826.127.163-79'

    # Test cpf created with a seed
    cpf = b.cpf(with_mask=False)
    assert cpf == '90871779220'
    # Test cpf created with a seed
    cpf = b.cpf(with_mask=True)

# Generated at 2022-06-23 20:42:10.876546
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider('en')
    assert provider.cpf() is not None
    assert provider.cnpj() is not None
    assert len(provider.cnpj()) == 14
    assert len(provider.cpf()) == 11


# Generated at 2022-06-23 20:42:12.040966
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider

# Generated at 2022-06-23 20:42:16.384074
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis import BrazilSpecProvider as bsp
    from mimesis import Seed
    seed = Seed('test')
    brazil = bsp(seed=seed)
    print(brazil.cpf())
    print(brazil.cnpj())

# Generated at 2022-06-23 20:42:16.981756
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider())


# Generated at 2022-06-23 20:42:20.952981
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider

    brazil = BrazilSpecProvider()

    assert len(brazil.cpf()) == 14

    assert brazil.cpf(with_mask=False).isdigit()


# Generated at 2022-06-23 20:42:23.837776
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    # test 1
    assert provider.cpf(False)
    # test 2
    assert provider.cpf(True)



# Generated at 2022-06-23 20:42:27.985587
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    cpf_func = BrazilSpecProvider().cnpj
    cpf_retorno = cpf_func()
    assert len(cpf_retorno) == 18

# Generated at 2022-06-23 20:42:29.291409
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()


# Generated at 2022-06-23 20:42:32.156934
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = Seed()
    especprov = BrazilSpecProvider(seed=seed)
    cpf = especprov.cpf()
    assert cpf == "726.654.650-72"



# Generated at 2022-06-23 20:42:37.965733
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test case for method cnpj of class BrazilSpecProvider."""
    from mimesis.providers import BrazilSpecProvider
    bz = BrazilSpecProvider ()
    cnpj = bz.cnpj(with_mask=True)
    if cnpj != '58.042.845/0304-25' :
        raise AssertionError


# Generated at 2022-06-23 20:42:40.287336
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider(seed=42)
    # Test CPF
    assert "837.162.682-85" == brazil_provider.cpf()
    # Test CNPJ
    assert "27.823.905/0001-29" == brazil_provider.cnpj()

# Generated at 2022-06-23 20:42:48.941361
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() == '02.551.128-42' or brazil_provider.cpf() == '391.157.465-05' or brazil_provider.cpf() == '307.868.446-88' or brazil_provider.cpf() == '818.373.855-90' or brazil_provider.cpf() == '892.375.617-69'
    assert brazil_provider.cnpj() == '14.978.708/0001-51' or brazil_provider.cnpj() == '43.039.976/0001-57' or brazil_provider.cnpj() == '75.553.397/0001-02' or brazil_provider.cnpj

# Generated at 2022-06-23 20:42:58.020545
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test function"""
    def compare_attr(attr: str, attr_name: str):
        """Test function"""
        temp = getattr(name, attr)
        assert len(temp.split('.')) == 4
        assert len(temp.split('/')) == 2
        assert len(temp.split('-')) == 2
        assert len(temp) == 18
        assert temp[2] == '.'
        assert temp[6] == '.'
        assert temp[10] == '/'
        assert temp[15] == '-'
        print(attr_name, temp)

    name = BrazilSpecProvider()
    for _ in range(10):
        compare_attr('cnpj', 'cnpj')


# Generated at 2022-06-23 20:43:05.250492
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Imports
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.enums import Gender
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.address import Address
    from mimesis.providers.person import Person

    # Create instances
    brazilSpecProvider = BrazilSpecProvider()
    person = Person('pt-br')
    address = Address('pt-br')
    datetime = Datetime('pt-br')

    # Test method cnpj
    assert brazilSpecProvider.cnpj(True) == "60.460.497/0001-66"

# Generated at 2022-06-23 20:43:08.378640
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('Testing init and set attributes of class BrazilSpecProvider')
    try:
        test = BrazilSpecProvider()
        print('Success!')
    except Exception:
        print('Fail!')


# Generated at 2022-06-23 20:43:11.212692
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    result = BrazilSpecProvider().cnpj(with_mask=True)
    assert result is not None


# Generated at 2022-06-23 20:43:13.175413
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    res = BrazilSpecProvider().cnpj()
    print(res)
    assert len(res) == 18
    assert len(res.split('-')) == 2
    assert len(res.split('/')) == 2


# Generated at 2022-06-23 20:43:15.419533
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    temp = BrazilSpecProvider()
    cpf = temp.cpf()
    assert len(cpf) == 14
    assert isinstance(cpf, str)



# Generated at 2022-06-23 20:43:26.474467
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test if method cpf of class BrazilSpecProvider is working."""

    # Check if returns the correct size of a CPF.
    assert len(BrazilSpecProvider().cpf()) == 14

    # Check if CPF returned by method contains only digits.
    assert BrazilSpecProvider().cpf().isdigit()

    # Check if CPF returned by method contains the correct number of dots and
    # dashes.
    assert BrazilSpecProvider().cpf().count('.') == 3
    assert BrazilSpecProvider().cpf().count('-') == 1

    # Check if method returns the correct number of digits.
    assert len((BrazilSpecProvider().cpf()).replace('.', '').replace('-', '')) == 11

    # Check if method returns the correct number of digits.

# Generated at 2022-06-23 20:43:29.149893
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:43:30.128207
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=123)


# Generated at 2022-06-23 20:43:31.813878
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert isinstance(bsp, BrazilSpecProvider)


# Generated at 2022-06-23 20:43:34.362181
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider"""
    print(BrazilSpecProvider().cnpj())


# Generated at 2022-06-23 20:43:37.923756
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18
    test = BrazilSpecProvider().cnpj()
    count = 0
    while test == cnpj:
        test = BrazilSpecProvider().cnpj()
        count += 1
    assert count < 5


# Generated at 2022-06-23 20:43:38.946603
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    t1 = BrazilSpecProvider()


# Generated at 2022-06-23 20:43:42.795174
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('Test for method cpf of class BrazilSpecProvider : ')
    bsp = BrazilSpecProvider()
    for i in range (10):
        print('{}'.format(bsp.cpf()))


# Generated at 2022-06-23 20:43:47.375829
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()

    assert len(cpf) == 11
    assert cpf[3] == cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[12:].isdigit()


# Generated at 2022-06-23 20:43:56.669691
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print('Test BrazilSpecProvider cnpj')

    list_cnpj = []
    for i in range(100000):
        list_cnpj.append(BrazilSpecProvider.cnpj(BrazilSpecProvider(), with_mask=False))

    for cnpj in list_cnpj:
        if len(cnpj) != 14:
            print('Error len cnpj')
        else:
            # https://www.geradorcnpj.com/validacao-cnpj.htm
            soma = 0
            if len(cnpj) == 14:
                verificadores = cnpj[12:]
                cnpj_bruto = cnpj[:12]
                peso = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]



# Generated at 2022-06-23 20:43:57.210959
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-23 20:44:04.520818
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Validate the format of the CNPJ generated by the class BrazilSpecProvider."""
    # Arrange
    from mimesis.providers import BrazilSpecProvider
    brazilSpecProvider = BrazilSpecProvider()

    # Act
    cnpj_with_mask = brazilSpecProvider.cnpj(with_mask=True)
    cnpj_without_mask = brazilSpecProvider.cnpj(with_mask=False)

    # Assert
    assert cnpj_with_mask is not None
    assert type(cnpj_with_mask) is str
    assert cnpj_with_mask[2] == "."
    assert cnpj_with_mask[6] == "."
    assert cnpj_with_mask[10] == "/"

# Generated at 2022-06-23 20:44:05.918299
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(False) == '06716445000183'


# Generated at 2022-06-23 20:44:16.106892
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    mask_cpf = brazil.cpf()
    if(mask_cpf[3] == '.' and mask_cpf[7] == '.' and mask_cpf[11] == '-'):
        assert mask_cpf[0].isdigit() and mask_cpf[1].isdigit() and mask_cpf[2].isdigit() and \
               mask_cpf[4].isdigit() and mask_cpf[5].isdigit() and mask_cpf[6].isdigit() and \
               mask_cpf[8].isdigit() and mask_cpf[9].isdigit() and mask_cpf[10].isdigit() and \
               mask_cpf[12].isdigit() and mask_cpf[13].isdig

# Generated at 2022-06-23 20:44:17.218063
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-23 20:44:26.594968
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf[3] == "."
    assert cpf[7] == "."
    assert cpf[11] == "-"
    assert cpf.count(".") == 2
    assert cpf.count("-") == 1
    assert cpf[:3].isdigit() is True
    assert cpf[4:7].isdigit() is True  # noqa
    assert cpf[8:11].isdigit() is True
    assert cpf[12:14].isdigit() is True


# Generated at 2022-06-23 20:44:29.395756
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    output = provider.cpf(with_mask=False)
    assert len(output) == 11
    assert provider.cpf(with_mask=True).find('.') != -1
    assert provider.cpf(with_mask=True).find('-') != -1


# Generated at 2022-06-23 20:44:32.202400
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test to get a random cpf."""
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14


# Generated at 2022-06-23 20:44:34.225524
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    spec = BrazilSpecProvider()
    assert isinstance(spec, BaseSpecProvider)

# Generated at 2022-06-23 20:44:37.790758
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == "331.935.266-74"
    assert bsp.cnpj() == "78.821.896/0001-79"


# Generated at 2022-06-23 20:44:47.877494
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    sp = BrazilSpecProvider()
    # test if the provider is instance of the BrazilSpecProvider class
    assert isinstance(sp, BrazilSpecProvider)
    # test if the provider is instance of the BaseSpecProvider class
    assert isinstance(sp, BaseSpecProvider)

    # test cpf method
    assert len(sp.cpf()) == 14
    assert all(i.isdigit() for i in sp.cpf())

    # test cnpj method
    assert len(sp.cnpj()) == 18
    assert all(i.isdigit() for i in sp.cnpj())

# Generated at 2022-06-23 20:44:49.178592
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().cpf()
    assert BrazilSpecProvider().cnpj()

# Generated at 2022-06-23 20:44:53.193149
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj, 'Failed to generate CNPJ'
    assert len(cnpj) == 18, 'Invalid length of generated CNPJ'

test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-23 20:44:56.212688
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert (cpf == '999.999.999-99')
    cnpj = brazil.cnpj()
    assert (cnpj == '99.999.999/9999-99')

# Generated at 2022-06-23 20:44:58.882664
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    Função criada para testar a função cpf da classe BrazilSpecProvider
    :return: void
    """
    bs = BrazilSpecProvider()
    assert bs.cpf() == "722.240.081-53"


# Generated at 2022-06-23 20:45:01.163964
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brsp = BrazilSpecProvider()
    print(brsp.cpf())


# Generated at 2022-06-23 20:45:09.853081
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider(seed=1)
    cpfs = set()
    for i in range(100):
        cpfs.add(bsp.cpf())

# Generated at 2022-06-23 20:45:12.552929
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert (len(provider.cpf()) == 14)
    assert (len(provider.cnpj()) == 18)

# Generated at 2022-06-23 20:45:18.269270
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test = BrazilSpecProvider()
    # Unit test for method cpf()
    print(test.cpf())
    # Unit test for method cpf() with_mask
    print(test.cpf(with_mask=True))
    # Unit test for method cnpj()
    print(test.cnpj())
    # Unit test for method cnpj() with_mask
    print(test.cnpj(with_mask=True))

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-23 20:45:23.565312
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Number of tests: 100"""
    bsp = BrazilSpecProvider()
    for i in range(100):
        print("Test " + str(i))
        cpf = bsp.cpf(with_mask=False)
        assert len(cpf) == 11
        assert int(cpf[9]) == bsp.digits.cpf_verifier(cpf[:9])
        assert int(cpf[10]) == bsp.digits.cpf_verifier(cpf[:10])
    assert True


# Generated at 2022-06-23 20:45:31.564408
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj method."""
    test_data = [
        ('03.539.971/0001-07', '03539971000107' ),
        ('35.739.971/0001-07', '3573971000107' ),
        ('65.739.971/0001-07', '6573971000107' ),
        ('95.739.971/0001-07', '9573971000107' ),
    ]
    brazil_provider = BrazilSpecProvider()
    for cnpj_to_check, cnpj_without_mask in test_data:
        assert cnpj_to_check == brazil_provider.cnpj(with_mask=True)
        assert cnpj_without_mask == brazil_provider.cnpj

# Generated at 2022-06-23 20:45:34.435833
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.typing import Seed

    test_seed = Seed()
    test_provider = BrazilSpecProvider(seed=test_seed)
    assert test_provider.seed is test_seed



# Generated at 2022-06-23 20:45:36.293757
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(100):
        print(BrazilSpecProvider().cpf())


# Generated at 2022-06-23 20:45:40.637739
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsbp = BrazilSpecProvider()
    cnpj_gen = bsbp.cnpj()
    assert len(cnpj_gen) == 14
    assert (int(cnpj_gen[12])*10 + int(cnpj_gen[13]))%11 == 0


# Generated at 2022-06-23 20:45:44.777619
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    print("cnpj: " + cnpj)

    cpf = brazil.cpf()
    print("cpf: " + cpf)


# Generated at 2022-06-23 20:45:48.648956
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider(seed=2)
    assert brazilSpecProvider.cpf(with_mask=True) == '838.834.155-22'
    assert brazilSpecProvider.cnpj(with_mask=True) == '74.839.841/0001-23'



# Generated at 2022-06-23 20:45:53.206691
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj is not None
    assert len(cnpj) == 18
    assert cnpj == provider.cnpj(with_mask=False)


# Generated at 2022-06-23 20:46:02.159184
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Ensure the generation of cnpj."""
    cnpj = cnpj_mask = '49.499.541/0001-80'
    cnpj = cnpj.replace('.', '').replace('-', '').replace('/', '')

    brazil_spec_provider = BrazilSpecProvider()

    assert brazil_spec_provider.cnpj(with_mask=False) == cnpj
    assert brazil_spec_provider.cnpj() == cnpj_mask
    assert isinstance(brazil_spec_provider.cnpj(), str)
    assert len(brazil_spec_provider.cnpj()) == 18


# Generated at 2022-06-23 20:46:05.558721
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Init the class
    BrazilSpecProvider(seed=1644)
    assert BrazilSpecProvider.Meta.name == 'brazil_provider'



# Generated at 2022-06-23 20:46:08.866942
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf(False)
    assert cpf == '60017067120'


# Generated at 2022-06-23 20:46:14.746538
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()

    assert brazil.__doc__ == __doc__

    assert BrazilSpecProvider.Meta.name == 'brazil_provider'

    # Test output method
    cnpj = brazil.cnpj(with_mask=False)
    assert cnpj == '7773223000170'

    cnpj = brazil.cnpj()
    assert cnpj == '77.732.230/0001-70'
 
    cpf = brazil.cpf(with_mask=False)
    assert cpf == '00113729740'

    cpf = brazil.cpf()
    assert cpf == '001.137.297-40'

# Generated at 2022-06-23 20:46:23.850290
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of BrazilSpecProvider class."""
    for _ in range(1000):
        cpf = BrazilSpecProvider().cpf(with_mask=False)
        assert len(cpf) == 11

# Generated at 2022-06-23 20:46:27.870712
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    
    brazil_spec_provider = BrazilSpecProvider()
    result = brazil_spec_provider.cnpj()
    expected = "77.732.230/0001-70"
    assert(result == expected)



# Generated at 2022-06-23 20:46:30.356375
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=42)
    cpf = provider.cpf()
    assert cpf == '038.453.518-21'


# Generated at 2022-06-23 20:46:36.198697
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    test_cpf = BrazilSpecProvider().cpf()

    assert cpf != test_cpf
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-23 20:46:38.836942
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-23 20:46:40.796826
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    gen = BrazilSpecProvider(seed=1)
    assert gen.cnpj() == '7773223000170'

# Generated at 2022-06-23 20:46:43.287309
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()

    expected = "142.865.849-11"
    actual = bsp.cpf()
    assert expected == actual


# Generated at 2022-06-23 20:46:50.988847
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from copy import copy

    person_male = Person('pt_br')
    person_female = Person('pt_br', gender=Gender.FEMALE)
    person_male.seed(0)
    person_female.seed(0)

    provider_male = BrazilSpecProvider(seed=0)
    provider_female = BrazilSpecProvider(seed=0)
    provider_male.cpf()
    provider_female.cpf()

    # Checking if the CPF is different between gender
    assert provider_male.cpf() != provider_female.cpf()

    # Checking if the CPF are different for different people
    for i in range(1, 10):
        person_male.seed(i)

# Generated at 2022-06-23 20:46:54.036797
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data = '001.137.297-40'
    c = BrazilSpecProvider()
    x = c.cpf()
    assert x == data


# Generated at 2022-06-23 20:46:56.558522
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.__class__.__name__ == 'BrazilSpecProvider'


# Generated at 2022-06-23 20:46:58.215131
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'


# Generated at 2022-06-23 20:47:00.521329
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf()) == 14
    assert len(brazil.cpf(with_mask=False)) == 11


# Generated at 2022-06-23 20:47:09.497812
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj1 = provider.cnpj(with_mask=True)
    cnpj2 = provider.cnpj(with_mask=True)
    cnpj3 = provider.cnpj(with_mask=True)
    assert cnpj1 != cnpj2 and cnpj2 != cnpj3 and cnpj1 != cnpj3
    print(cnpj1)
    print(cnpj2)
    print(cnpj3)