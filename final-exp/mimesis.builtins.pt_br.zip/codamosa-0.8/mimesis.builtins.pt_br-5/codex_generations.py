

# Generated at 2022-06-12 01:13:58.997701
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    pass
if __name__=='__main__':
    bsp = BrazilSpecProvider()
    for i in range(0, 10):
        print(bsp.cnpj())

# Generated at 2022-06-12 01:14:00.367984
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br_provider = BrazilSpecProvider()
    cnpj = br_provider.cnpj()
    assert cnpj

# Generated at 2022-06-12 01:14:10.349467
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider's cnpj method."""
    b1 = BrazilSpecProvider()
    assert len(b1.cnpj()) == 18

    with_mask = b1.cnpj(True)
    with_mask_checks = list(with_mask)
    assert with_mask_checks[2] == '.' and with_mask_checks[6] == '.' and \
        with_mask_checks[10] == '/' and with_mask_checks[15] == '-'

    assert len(b1.cnpj(False)) == 14



# Generated at 2022-06-12 01:14:19.583389
# Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-12 01:14:22.434161
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider(seed=42)
    result = b.cnpj()
    assert result == '69.606.827/0001-04'
    

# Generated at 2022-06-12 01:14:25.452528
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()
    assert bp.cpf() == "410.585.881-82", bp.cpf()


# Generated at 2022-06-12 01:14:34.071194
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[3] == "."
    assert cpf[7] == "."
    assert cpf[11] == "-"
    assert cpf[:3] != "000".ljust(3, "0")
    assert cpf[4:7] != "000".ljust(3, "0")
    assert cpf[8:11] != "000".ljust(3, "0")
    assert cpf[12:] != "00".ljust(2, "0")


# Generated at 2022-06-12 01:14:38.886213
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    # cpf = brazil_spec_provider.cpf()
    # print(cpf)
    assert len(brazil_spec_provider.cpf()) == 14



# Generated at 2022-06-12 01:14:41.842093
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=False).isdigit()
    assert len(provider.cpf(with_mask=False)) == 11

# Generated at 2022-06-12 01:14:43.767785
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider()
    print(p.cpf())


# Generated at 2022-06-12 01:15:02.211847
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf(with_mask=False)

    assert len(result) == 11 and type(result) == str, \
        'The result must a string with 11 numbers'

    assert provider.cpf() == provider.cpf() and provider.cpf() != provider.cpf(), \
        'The result must be constant while the seed is the same and \
        different while the seed change'


# Generated at 2022-06-12 01:15:05.833888
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18

    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14

# Generated at 2022-06-12 01:15:06.904349
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() is not None

# Generated at 2022-06-12 01:15:17.182180
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    :returns: True if method cpf of class BrazilSpecProvider return a valid CPF, False otherwise.
    """
    from mimesis.datetime import Datetime
    cpf = BrazilSpecProvider().cpf()
    def is_valid_cpf(cpf):
        """
        :param cpf: String with the cpf
        :returns: True if is a valid cpf, False otherwise.
        """
        invalid_cpfs = [11 * str(n) for n in range(10)]
        if cpf in invalid_cpfs:
            return False
        aux = cpf[:-2]

# Generated at 2022-06-12 01:15:19.503665
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=10)
    bsp.cnpj()


# Generated at 2022-06-12 01:15:28.019842
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider.

    :return: None
    """
    cpf = BrazilSpecProvider().cpf()
    assert(len(cpf) == 14)
    assert(cpf[3] == '.')
    assert(cpf[7] == '.')
    assert(cpf[11] == '-')
    assert(cpf[0:3].isnumeric())
    assert(cpf[4:7].isnumeric())
    assert(cpf[8:11].isnumeric())
    assert(cpf[12:].isnumeric())


# Generated at 2022-06-12 01:15:35.697686
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider
    with argument with_mask as true."""
    bzp = BrazilSpecProvider()
    test_result = bzp.cnpj(True)
    assert len(test_result) == 18
    assert (test_result[2] == '.' and test_result[6] == '.'
            and test_result[10] == '/')
    assert test_result[15] == '-'


# Generated at 2022-06-12 01:15:41.024105
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.typing import Seed

    seed = 123456789
    provider = BrazilSpecProvider(seed)
    name = provider.name(Gender.MALE)
    email = provider.email(name=name)
    cnpj = provider.cnpj()
    assert cnpj == '31.240.358/8681-27'

# Generated at 2022-06-12 01:15:46.048201
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    cpf_gen = BrazilSpecProvider()
    assert cpf_gen._validate_cpf(cpf_gen.cpf())


# Generated at 2022-06-12 01:15:52.825507
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # test with mask
    seed = 'a5b5c5d5e5'
    provider = BrazilSpecProvider(seed=seed)
    assert provider.cnpj(with_mask=True) == '70.602.089/0001-20'
    assert provider.cnpj(with_mask=True) == '34.610.919/0001-81'
    assert provider.cnpj(with_mask=True) == '70.602.089/0001-20'

    # test without mask
    seed = 'f5g5h5i5j5'
    provider = BrazilSpecProvider(seed=seed)
    assert provider.cnpj(with_mask=False) == '54128973000150'
    assert provider.cnpj(with_mask=False) == '59150280000176'

# Generated at 2022-06-12 01:16:08.516856
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    assert (BrazilSpecProvider().cpf() == '515.254.295-53')


# Generated at 2022-06-12 01:16:13.415983
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Testing BrazilSpecProvider.cpf()")
    print(BrazilSpecProvider().cpf())
    print(BrazilSpecProvider().cpf())
    print(BrazilSpecProvider().cpf())
    print(BrazilSpecProvider().cpf())
    print(BrazilSpecProvider().cpf())


# Generated at 2022-06-12 01:16:25.528842
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def cnpj_mask(cnpj):
        """Return the CNPJ with the mask."""
        return '{}.{}.{}/{}-{}'.format(cnpj[:2], cnpj[2:5],
                                       cnpj[5:8], cnpj[8:12], cnpj[12:])

    provider = BrazilSpecProvider(seed=0)
    # first random CNPJ generated by the seed
    output_1 = provider.cnpj()
    result_1 = '77.732.230/0001-70'
    # second CNPJ generated by the seed
    output_2 = provider.cnpj(with_mask=False)
    result_2 = '22267989000164'

    # third random CNPJ
    output_3 = cnpj

# Generated at 2022-06-12 01:16:27.866822
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert len(brazil.cnpj()) == 18


# Generated at 2022-06-12 01:16:37.452934
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import re

    brazil_provider = BrazilSpecProvider()
    
    def is_cnpj(cnpj):
        pattern = re.compile(r"([0-9]{2}[\.][0-9]{3}[\.][0-9]{3}[/][0-9]{4}[-][0-9]{2})")
        return pattern.match(cnpj)

    for i in range(500):
        assert is_cnpj(brazil_provider.cnpj())

# Generated at 2022-06-12 01:16:42.272145
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import re
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(True)
    assert (type(cnpj) is str and len(cnpj) == 18)
    assert re.match(r"\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}", cnpj)

# Generated at 2022-06-12 01:16:44.011350
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(0,1000):
        a = BrazilSpecProvider.cnpj
        if a != "":
            print (a)


# Generated at 2022-06-12 01:16:52.592241
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Given
    brazilSpecProvider = BrazilSpecProvider()

    # When
    cnpj_without_mask = brazilSpecProvider.cnpj(with_mask=False)
    cnpj_with_mask = brazilSpecProvider.cnpj(with_mask=True)

    # Then
    print(cnpj_without_mask)
    print(cnpj_with_mask)

# Generated at 2022-06-12 01:17:03.778748
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.datetime import Datetime
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.builtins.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender

    locale = 'pt-br'
    spec_provider = BrazilSpecProvider(seed=1337)
    datetime = Datetime(locale=locale)

    assert spec_provider._formatter(
        '{0.date_time:%Y-%m-%d}', datetime) == '2015-07-01'

    assert spec_provider.cpf() == '939.282.401-76'

    assert spec_provider.cnpj() == '75.315.995/0001-14'


# Generated at 2022-06-12 01:17:06.596140
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    newCnpj = BrazilSpecProvider.cnpj(BrazilSpecProvider)
    if newCnpj is not None:
        print(newCnpj)
        return True
    return False


# Generated at 2022-06-12 01:17:39.952392
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    actual = BrazilSpecProvider().cpf()
    print(actual)
    assert len(actual) == 14


# Generated at 2022-06-12 01:17:43.044206
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18



# Generated at 2022-06-12 01:17:53.386700
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the method cpf of class BrazilSpecProvider."""
    from mimesis.builtins.brasil.endereco import BrazilSpecProvider
    seed = BrazilSpecProvider.seed
    brazil = BrazilSpecProvider()

    # Verify uniqueness of the cpf
    cpf = brazil.cpf()
    for _ in range(10):
        assert brazil.cpf() == cpf

    # Verify uniqueness of cpf using mask
    cpf = brazil.cpf(with_mask=True)
    for _ in range(10):
        assert brazil.cpf(with_mask=True) == cpf

    # Verify uniqueness of the cpf (using a fixed seed)
    init_seed = BrazilSpecProvider.seed
    BrazilSpecProvider.seed = seed
    cpf = brazil.cpf()

# Generated at 2022-06-12 01:17:55.412139
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert (len(cnpj) == 14)

# Generated at 2022-06-12 01:18:01.630316
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.generic import Generic
    generic = Generic('pt-br')
    brazil = BrazilSpecProvider('pt-br')
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf[-2] == '2' or cpf[-2] == '3'
    assert generic.cpf() == cpf


# Generated at 2022-06-12 01:18:06.124996
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of BrazilSpecProvider."""
    from mimesis.providers import BrazilSpecProvider
    provider = BrazilSpecProvider()

    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14

# Generated at 2022-06-12 01:18:09.473148
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider(seed=12345)
    assert brazil_provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-12 01:18:16.329788
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=0)
    cnpj = bsp.cnpj()
    assert cnpj == '77.732.230/0001-70'

    cnpj_2 = bsp.cnpj()
    assert cnpj_2 == '19.222.072/0001-67'


# Generated at 2022-06-12 01:18:21.141185
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_SP = BrazilSpecProvider()
    cnpj = brazil_SP.cnpj()
    if len(cnpj) != 18:
        raise AssertionError(
            "Test failed - BrazilSpecProvider_cnpj - brazil_SP: {}; cnpj: {}".format(brazil_SP, cnpj))


# Generated at 2022-06-12 01:18:32.309905
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import pytest
    from mimesis.enums import Gender
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    cnpj_no_mask = cnpj.replace('-', '').replace('.', '').replace('/', '')
    assert len(cnpj_no_mask) == 14
    assert cnpj == provider.cnpj(True)
    assert cnpj_no_mask == provider.cnpj(False)
    assert cnpj_no_mask != provider.cnpj()

# Generated at 2022-06-12 01:19:40.498947
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    # There is no seed for method, we cannot test the probability of getting a specific CNPJ
    # Let's just test that the mask is applied correctly

    assert BrazilSpecProvider().cnpj(with_mask=True) == '77.732.230/0001-70'
    assert BrazilSpecProvider().cnpj(with_mask=False) == '77732230000170'

# Generated at 2022-06-12 01:19:46.281573
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    dv1 = [int(digit) for digit in cnpj[12:13]]
    dv2 = [int(digit) for digit in cnpj[13:14]] 
    cnpj_digits = [int(digit) for digit in cnpj[:12]]
    peso1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    peso2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    soma = 0  

# Generated at 2022-06-12 01:19:50.994278
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider cnpj method."""
    cnpj1 = '77.732.230/0001-70'
    cnpj2 = '77732' + '23000001' + '70'
    assert BrazilSpecProvider().cnpj() == cnpj1
    assert BrazilSpecProvider().cnpj(with_mask=False) == cnpj2

# Generated at 2022-06-12 01:19:52.968366
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilProvider = BrazilSpecProvider()
    print(brazilProvider.cpf())


# Generated at 2022-06-12 01:19:55.461181
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpjs = [brazil_spec_provider.cnpj(with_mask=False) for i in range(10)]
    for cnpj in cnpjs:
        assert len(cnpj) == 14

# Generated at 2022-06-12 01:19:57.314021
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert type(cpf) == str


# Generated at 2022-06-12 01:20:01.305634
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    cnpj = p.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert cnpj.isdigit()

# Generated at 2022-06-12 01:20:05.651967
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_list = []
    for i in range(0, 10):
        cnpj = BrazilSpecProvider().cnpj(with_mask=False)
        cnpj_list.append(cnpj)
    return cnpj_list



# Generated at 2022-06-12 01:20:16.281066
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Checking if method cpf return a CPF string with valid data
    from mimesis.enums import Gender
    from mimesis.providers import BrazilSpecProvider
    provider = BrazilSpecProvider()
    assert provider.cpf() == '252.593.824-94'
    assert provider.cpf() == '128.854.527-45'
    assert provider.cpf() == '857.287.015-17'
    assert provider.cpf() == '577.904.386-82'
    assert provider.cpf() == '442.298.055-27'
    assert provider.cpf() == '982.986.844-44'
    assert provider.cpf() == '516.821.443-09'

# Generated at 2022-06-12 01:20:24.107163
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj()."""
    # test regex
    pattern = re.compile(r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}')
    for _ in range(20):
        a = BrazilSpecProvider()
        assert pattern.match(a.cnpj(with_mask=True)) != None
    # test if values are equal to examples on cnpj() docstring
    # if assert fails, the next is printed
    # the number of random numbers generated follows the pattern
    cnpj = BrazilSpecProvider()
    assert cnpj.cnpj(with_mask=True) == '77.732.230/0001-70'

# Generated at 2022-06-12 01:23:07.603111
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:23:11.938011
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf() of BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cpf_value = provider.cpf()
    assert len(cpf_value) == 14
    assert cpf_value[3] == '.'
    assert cpf_value[7] == '.'
    assert cpf_value[11] == '-'


# Generated at 2022-06-12 01:23:14.543484
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-12 01:23:20.058797
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=1)
    assert provider.cpf() == "045.688.633-95"
    assert provider.cpf() == "046.549.630-66"
    assert provider.cpf() == "047.426.147-38"
    assert provider.cpf() == "048.668.075-37"
    assert provider.cpf() == "049.020.904-57"


# Generated at 2022-06-12 01:23:21.410033
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()
    print(bp.cnpj(with_mask=True))


# Generated at 2022-06-12 01:23:26.002390
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    from mimesis.enums import Gender

    p = BrazilSpecProvider()
    for i in range(10):
        print(p.cpf())



# Generated at 2022-06-12 01:23:27.252186
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    print(brazil.cnpj())


# Generated at 2022-06-12 01:23:30.508090
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    print(cnpj)
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18


# Generated at 2022-06-12 01:23:32.881000
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    spec = BrazilSpecProvider()

    with_mask = True
    cpf = spec.cpf(with_mask)
    assert cpf == '459.817.848-80', 'Test failed'



# Generated at 2022-06-12 01:23:40.925997
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # TODO: Maybe we can use a singleton instead of instantiating one
    #       BrazilSpecProvider every time we need one.
    brazil = BrazilSpecProvider()
    for _ in range(100):
        assert len(brazil.cpf()) == 14
        assert brazil.cpf()[3] == '.'
        assert brazil.cpf()[7] == '.'
        assert brazil.cpf()[11] == '-'
        assert all(map(lambda x: x.isdigit() and x != '0', brazil.cpf()[:3]))
        assert all(map(lambda x: x.isdigit() and x != '0', brazil.cpf()[4:7]))