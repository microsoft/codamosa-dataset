

# Generated at 2022-06-12 01:13:56.247533
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    braz = BrazilSpecProvider()
    assert braz.cnpj() != braz.cnpj()
    assert braz.cnpj() != braz.cnpj()
    assert braz.cnpj() != braz.cnpj()


# Generated at 2022-06-12 01:13:58.515146
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider.cpf()

    assert len(cpf) == 14


# Generated at 2022-06-12 01:14:00.879202
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_cpf = BrazilSpecProvider()
    assert len(brazil_cpf.cpf()) == 14


# Generated at 2022-06-12 01:14:10.015171
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()  # 001.137.297-40
    assert len(cpf) == 14
    assert cpf[:3] == "001"
    assert cpf[4] == "."
    assert cpf[8] == "."
    assert cpf[12] == "-"
    assert cpf[3] != "."
    assert cpf[7] != "."
    assert cpf[11] != "-"


# Generated at 2022-06-12 01:14:12.577180
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    b = BrazilSpecProvider()
    c = BrazilSpecProvider()
    assert a.cpf() != b.cpf() != c.cpf()


# Generated at 2022-06-12 01:14:13.988586
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilSpecProvider = BrazilSpecProvider()
    assert len(brazilSpecProvider.cnpj()) == 18

# Generated at 2022-06-12 01:14:16.936485
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Class CNPJ
    cnpj = BrazilSpecProvider()
    assert cnpj.cnpj()
    assert cnpj.cnpj(False)
    cnpj2 = BrazilSpecProvider()
    assert cnpj != cnpj2

# Generated at 2022-06-12 01:14:24.203196
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Teste the method cnpj of class BrazilSpecProvider."""
    value = BrazilSpecProvider().cnpj()
    assert len(value) == 18
    assert isinstance(value, str)

    value = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(value) == 14
    assert isinstance(value, str)

    print('CNPJ: {}'.format(value))


# Generated at 2022-06-12 01:14:32.103241
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[0:3].isdigit()
    assert cpf[4:7].isdigit()
    assert cpf[8:11].isdigit()
    assert cpf[12:14].isdigit()


# Generated at 2022-06-12 01:14:36.118921
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=True) == provider.cpf(with_mask=False)


# Generated at 2022-06-12 01:14:56.627480
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for the method cpf of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider(seed=42)

    cpf = brazil_spec_provider.cpf(True)
    assert cpf == '075.039.431-29'

    cpf_without_mask = brazil_spec_provider.cpf(False)
    assert cpf_without_mask == '075039413129'



# Generated at 2022-06-12 01:15:00.911008
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 14
    assert b.cpf()[3] == '.'
    assert b.cpf()[7] == '.'
    assert b.cpf()[11] == '-'



# Generated at 2022-06-12 01:15:03.817423
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    instance = BrazilSpecProvider()
    row1 = instance.cpf()
    row2 = instance.cpf()
    assert (len(row1) == 14 and len(row2) == 14)


# Generated at 2022-06-12 01:15:05.394114
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    expected = '57.586.816/0001-60'
    assert brazil.cnpj() == expected


# Generated at 2022-06-12 01:15:11.323794
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Create an instance of BrazilSpecProvider
    brazil = BrazilSpecProvider()
    # Generate a random CPF
    cpf = brazil.cpf()
    # Check if CPF have last two digits
    assert len(cpf[-2:]) == 2
    # Check if CPF is valid
    assert len(cpf) == 14


# Generated at 2022-06-12 01:15:13.596042
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider()
    cnpj = obj.cnpj()
    assert len(cnpj) == 18
    assert cnpj.isdigit() == True

# Generated at 2022-06-12 01:15:20.692055
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test if the return value of method cpf of class BrazilSpecProvider
    returns a valid CPF."""
    from mimesis.builtins.brazil import BrazilSpecProvider as brasil
    brazil = brasil()
    for i in range(0, 100):
        cpf = brazil.cpf()
        assert len(cpf) == 14
        assert cpf[3] == '.'
        assert cpf[7] == '.'
        assert cpf[11] == '-'


# Generated at 2022-06-12 01:15:23.469450
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    x = cnpj()
    if len(x) != 18:
        raise Exception('BrazilSpecProvider_cnpj() function return error')


# Generated at 2022-06-12 01:15:31.319038
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj."""
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '83.503.971/0001-42'
    assert bsp.cnpj() == '83.503.971/0001-42'
    assert bsp.cnpj() == '83.503.971/0001-42'
    assert bsp.cnpj() == '83.503.971/0001-42'


# Generated at 2022-06-12 01:15:32.598757
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    print(cpf)


# Generated at 2022-06-12 01:16:03.636858
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result = provider.cnpj(with_mask=False)
    assert(result)


# Generated at 2022-06-12 01:16:06.263544
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    results = []
    for i in range(10):
        obj = BrazilSpecProvider()
        cpf = obj.cpf()
        results.append(cpf)
        assert len(cpf) == 14

    return results


# Generated at 2022-06-12 01:16:12.200754
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == "."
    assert cpf[7] == "."
    assert cpf[11] == "-"


# Generated at 2022-06-12 01:16:13.986904
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider(seed = 1)
    response = b.cpf()
    print(response)
    assert response == '001.137.297-40'


# Generated at 2022-06-12 01:16:26.139659
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider(seed=42)


# Generated at 2022-06-12 01:16:29.900036
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert "111.222.333-00" == BrazilSpecProvider().cpf()
    assert not BrazilSpecProvider().cpf() == BrazilSpecProvider().cpf()


# Generated at 2022-06-12 01:16:32.730611
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '017.586.780-38'


# Generated at 2022-06-12 01:16:41.912686
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from pytest import raises, fail
    from mimesis.exceptions import NonEnumerableError
    from mimesis.providers.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=False) == '77732230000170'
    assert provider.cnpj(with_mask=True) == '77.732.230/0001-70'
    with raises(NonEnumerableError):
        provider.cnpj(with_mask=None)
    try:
        provider.cnpj(with_mask=1)
    except Exception as e:
        fail(e)


# Generated at 2022-06-12 01:16:46.957054
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    class BrazilSpecProviderTest(BrazilSpecProvider):
        def __init__(self, seed=None):
            super().__init__(seed=seed)

    br1 = BrazilSpecProviderTest()
    cnpj = br1.cnpj()
    print("cnpj: " + cnpj)
    cnpj_without_mask = cnpj.replace(".", "").replace("-", "").replace("/", "")
    first_digit = cnpj_without_mask[-2]
    print("first digit: " + first_digit)
    second_digit = cnpj_without_mask[-1]
    print("second digit: " + second_digit)

# Generated at 2022-06-12 01:16:51.229886
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    spec = BrazilSpecProvider()
    cpf = spec.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14


# Generated at 2022-06-12 01:18:04.529510
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf()."""

    provider = BrazilSpecProvider(seed=42)

    assert len(provider.cpf(with_mask=True)) == 14
    assert len(provider.cpf(with_mask=False)) == 11
    assert provider.cpf(with_mask=True) == '402.382.738-26'
    assert provider.cpf(with_mask=False) == '40238273826'
    assert provider.cpf() == '402.382.738-26'


# Generated at 2022-06-12 01:18:06.625132
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'


# Generated at 2022-06-12 01:18:07.641126
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider.cpf()

# Generated at 2022-06-12 01:18:18.308837
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test if method cpf return a CPF"""
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf == BrazilSpecProvider().cpf(True)
    assert cpf[len(cpf)-2] == '-'
    cpf_without_mask = BrazilSpecProvider().cpf(False)
    assert len(cpf_without_mask) == 11
    assert cpf_without_mask == cpf[:3] + cpf[4:7] + cpf[8:11] + cpf[12:]


# Generated at 2022-06-12 01:18:20.911686
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    print(cpf)


# Generated at 2022-06-12 01:18:24.111483
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    print(provider.cnpj(True))
    print(provider.cnpj(False))


# Generated at 2022-06-12 01:18:33.864740
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_with_mask = BrazilSpecProvider().cnpj(True)
    assert cnpj_with_mask.isdigit() is False
    assert cnpj_with_mask[0:2].isdigit() is True
    assert cnpj_with_mask[3:5].isdigit() is True
    assert cnpj_with_mask[6:8].isdigit() is True
    assert cnpj_with_mask[9:12].isdigit() is True
    assert cnpj_with_mask[13:14].isdigit() is True

    cnpj_without_mask = BrazilSpecProvider().cnpj(False)
    assert cnpj_without_mask.isdigit() is True



# Generated at 2022-06-12 01:18:35.758813
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert b.cnpj() == "57.028.721/0001-44"


# Generated at 2022-06-12 01:18:38.746390
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:18:43.489641
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # create object BrazilSpecProvider
    brazil = BrazilSpecProvider(seed = 42)
    # execute method cpf
    result = brazil.cpf()

    # verify and compare result of method cpf
    assert result == "305.307.229-00"


# Generated at 2022-06-12 01:21:35.322285
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the BrazilSpecProvider"""
    obj = BrazilSpecProvider(seed=100)
    r = obj.cnpj()
    assert r == "24.304.515/0001-80"

# Generated at 2022-06-12 01:21:38.846583
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert b.cpf() == '560.839.826-82'
    assert b.cpf(with_mask=False) == '56083982182'


# Generated at 2022-06-12 01:21:43.058230
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import math
    import random
    from mimesis.providers.brazil_spec import BrazilSpecProvider

    seed = 0
    random.seed(seed)
    math.seed = 0
    provider = BrazilSpecProvider(seed=seed)

    cnpj_provider = provider.cnpj()
    print(cnpj_provider)
    assert cnpj_provider == '77.732.230/0001-70'



# Generated at 2022-06-12 01:21:45.490896
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Bets test for BrazilSpecProvider class method cnpj."""
    assert BrazilSpecProvider().cnpj() != BrazilSpecProvider().cnpj()


if __name__ == '__main__':
    test_BrazilSpecProvider_cnpj()
    print(BrazilSpecProvider().cnpj())

# Generated at 2022-06-12 01:21:47.873123
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == "632.853.812-00"

# Generated at 2022-06-12 01:21:54.645597
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    

# Generated at 2022-06-12 01:21:59.852750
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Assert that cpf method returns a valid CPF."""
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    cpfs = []
    for _ in range(100):
        cpf = provider.cpf()
        assert cpf not in cpfs
        cpfs.append(cpf)

# Generated at 2022-06-12 01:22:04.174650
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert re.match(r"^[0-9]{3}\.[0-9]{3}\.[0-9]{3}-[0-9]{2}$", provider.cpf())


# Generated at 2022-06-12 01:22:06.362442
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=42)
    cnpj = provider.cnpj(with_mask=True)
    assert(cnpj == '77.732.230/0001-70')

# Generated at 2022-06-12 01:22:09.718097
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj.

    :returns: None
    """
    from mimesis.builtins import BrazilSpecProvider

    brasil = BrazilSpecProvider()
    for _ in range(0, 5):
        print(brasil.cnpj())
