

# Generated at 2022-06-12 01:13:58.058886
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=12345)
    print(bsp.cnpj())


# Generated at 2022-06-12 01:14:00.878734
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    expected = "77.732.230/0001-70"
    result = BrazilSpecProvider().cnpj(with_mask=True)
    assert result == expected

# Generated at 2022-06-12 01:14:07.453190
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert cpf == '{}.{}.{}-{}'.format(cpf[:3], cpf[3:6],
                                       cpf[6:9], cpf[9:])


# Generated at 2022-06-12 01:14:15.097598
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test method cpf with param with_mask = True
    random.seed(seed=1)
    result = BrazilSpecProvider(seed=1).cpf(with_mask=True)
    if result != "594.109.298-77":
        print("Test number 1 of method 'cpf' of class 'BrazilSpecProvider' has failed!")

    # Test method cpf with param with_mask = False
    random.seed(seed=2)
    result = BrazilSpecProvider(seed=2).cpf(with_mask=False)
    if result != "92342334379":
        print("Test number 2 of method 'cpf' of class 'BrazilSpecProvider' has failed!")


# Generated at 2022-06-12 01:14:16.935718
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert brazil.cpf(with_mask=True) == "215.672.133-15"



# Generated at 2022-06-12 01:14:20.447470
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert type(cnpj) == str
    assert len(cnpj) == 18



# Generated at 2022-06-12 01:14:25.307909
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Setup
    provider = BrazilSpecProvider()

    # Exercise
    result = provider.cnpj()

    # Verify
    assert result.count('.') == 2
    assert result.count('/') == 1
    assert result.count('-') == 1
    assert len(result) == 18


# Generated at 2022-06-12 01:14:30.178111
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for method cpf of class BrazilSpecProvider"""
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf(with_mask=False)
    assert cpf.isdigit () == True
    assert len(cpf) == 11


# Generated at 2022-06-12 01:14:34.853632
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    def func_cpf(with_mask = True):
        return provider.cpf(with_mask)

    assert isinstance(func_cpf(True), str)
    assert isinstance(func_cpf(False), str)


# Generated at 2022-06-12 01:14:36.989278
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    prov = BrazilSpecProvider()
    prov.cnpj()


# Generated at 2022-06-12 01:14:55.675553
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider's cnpj method"""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    # cnpj must be in the form nn.nnn.nnn/nnnn-nn
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    assert len(cnpj) == 18
    for i in range(2, 15, 3):
        assert cnpj[i-1] != '0'
        assert cnpj[i] != '0'
        assert cnpj[i+1] != '0'

    cnpj = provider.cnpj(with_mask=False)
    # cnpj must be in the

# Generated at 2022-06-12 01:14:59.307989
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for cpf of class BrazilSpecProvider."""
    # Call method cpf of class BrazilSpecProvider on object bsp
    bsp = BrazilSpecProvider()
    s = bsp.cpf()
    # Assert isinstance(s, str)
    assert isinstance(s, str)
    # Assert len(s) == 14
    assert len(s) == 14
    # Assert s[3] == '.'
    assert s[3] == '.'
    # Assert s[7] == '.'
    assert s[7] == '.'
    # Assert s[11] == '-'
    assert s[11] == '-'


# Generated at 2022-06-12 01:15:01.951788
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'


# Generated at 2022-06-12 01:15:05.537679
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf.count(".") == 2
    assert cpf.count("-") == 1


# Generated at 2022-06-12 01:15:09.266089
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj"""
    cnpj = BrazilSpecProvider().cnpj(with_mask=False)
    assert cnpj
    assert len(cnpj) == 14

# Generated at 2022-06-12 01:15:14.385589
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = seed_from_bytes(b'\xfa\xe3\x07\x8f\xdf\xa7\x11\xe9')
    random = Random()
    random.seed(seed)
    b = BrazilSpecProvider(seed)
    print(b.cnpj(True))

if __name__ == "__main__":
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-12 01:15:18.504869
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    with BrazilSpecProvider() as brsp:
        assert brsp.cnpj(with_mask=True) == '77.732.230/0001-70'
        assert brsp.cnpj(with_mask=False) == '77732230000170'

# Generated at 2022-06-12 01:15:22.004239
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=int(1234))
    print(provider.cpf())
    print(provider.cpf())


# Generated at 2022-06-12 01:15:23.801475
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider(seed=123)
    assert bsp.cpf() == '017.303.848-72'


# Generated at 2022-06-12 01:15:32.435899
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()
    cnpj = bp.cnpj()

    cnpj_mask = bp.cnpj(with_mask=True)
    assert(cnpj == cnpj_mask.replace('.', '') or cnpj == cnpj_mask.replace('/', '') or cnpj == cnpj_mask.replace('-', '') or cnpj == cnpj_mask.replace('.', '').replace('/', '').replace('-', ''))


# Generated at 2022-06-12 01:15:43.810519
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    generated = b.cpf(True)
    assert generated == "205-835-237-56", "Generated CPF doesn't match the expected value!"


# Generated at 2022-06-12 01:15:48.256423
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert '.' in cnpj and '/' in cnpj and '-' in cnpj


# Generated at 2022-06-12 01:15:57.405469
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import Brazil

    brazil = Brazil('pt_BR')
    cnpjs = [brazil.cnpj(with_mask=False) for _ in range(10)]
    mask_cnpjs = [brazil.cnpj(with_mask=True) for _ in range(10)]

    for cnpj in cnpjs:
        assert len(cnpj) == 14

    for mask_cnpj in mask_cnpjs:
        assert len(mask_cnpj) == 18



# Generated at 2022-06-12 01:15:58.900083
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    print(obj.cpf(True))

# Generated at 2022-06-12 01:16:07.460132
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
	provider = BrazilSpecProvider()
	cpf = provider.cpf()
	assert cpf[:3] in "123456789" # cpf[:3] is always the last digit of the cpf
	assert cpf[3] == '.'
	assert cpf[7] == '.'
	assert cpf[11] == '-'

'''
assert cpf[4:7] in "123456789" # cpf[4:7] is always the current year of Brazil
	assert cpf[12:14] in "0112" # cpf[12:14] is always the current month of Brazil
	assert cpf[14:16] in "3123" # cpf[14:16] is always the current day of Brazil
'''

# Generated at 2022-06-12 01:16:08.821610
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() != BrazilSpecProvider().cpf()

# Generated at 2022-06-12 01:16:12.364568
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()

    assert bsp.cnpj(with_mask=True) == '52.380.214/0001-40'

# Generated at 2022-06-12 01:16:14.766726
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=False)
    cnpj = cnpj[:12] + '0001'
    assert cnpj[:2] == '77'

# Generated at 2022-06-12 01:16:17.789859
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed(1)
    b = BrazilSpecProvider()
    print(b.cpf())


# Generated at 2022-06-12 01:16:27.334136
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.validators import cpf_validator
    from mimesis.validators import cnpj_validator
    provider = BrazilSpecProvider('pt')
    p = Person('pt', seed=42)
    p.gender = Gender.FEMALE
    assert cpf_validator(provider.cpf()) == True
    assert cpf_validator(provider.cpf(with_mask=False)) == True
    assert cpf_validator(provider.cpf(with_mask=True)) == True
    assert p.cpf_v2() == provider.cpf()


# Generated at 2022-06-12 01:16:44.803393
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14 # 3 + 1 + 3 + 1 + 3 + 2
    assert cpf[3] == cpf[7] == '.'
    assert cpf[11] == '-'
    assert int(cpf[9:]) == provider._get_verifying_digit(cpf)


# Generated at 2022-06-12 01:16:55.857590
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for cnpj method of the BrazilSpecProvider class."""
    provider = BrazilSpecProvider()
    # cnpj without_mask
    cnpj_1 = provider.cnpj(with_mask=False)
    # cnpj with mask
    cnpj_2 = provider.cnpj(with_mask=True)
    assert len(cnpj_1) == 14
    assert type(cnpj_1) is str
    assert len(cnpj_2) == 18
    assert type(cnpj_2) is str
    print('cnpj with mask: {}\ncnpj without mask: {}'.format(cnpj_1, cnpj_2))
    # check if the process of calculating the verifying digit is correct
    # split the cnpj string into a list of integers
    c

# Generated at 2022-06-12 01:16:58.405537
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert (len(cpf) == 14)


# Generated at 2022-06-12 01:17:03.377280
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("# TEST : class BrazilSpecProvider method cnpj")
    print("# TEST : 1 - Start BrazilSpecProvider")
    provider = BrazilSpecProvider()
    print("# TEST : 2 - Call method cnpj for class BrazilSpecProvider")
    print("# TEST : 1 - Call method ")
    print("# TEST : 1 - Call method ")
    print("# TEST : 1 - Call method ")
    provider.cnpj()

# Generated at 2022-06-12 01:17:05.341454
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '018.299.450-19'


# Generated at 2022-06-12 01:17:10.270351
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider.cnpj."""
    provider = BrazilSpecProvider()
    cnpj_number = provider.cnpj(with_mask=False)

    # Get the last two digits of the cnpj number
    last_two_digits = cnpj_number[-2:]

    # Get the first 12 digits of the cnpj number
    first_12_digits = cnpj_number[:-2]

    # Ca

# Generated at 2022-06-12 01:17:12.535086
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:17:15.287050
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    result = provider.cpf()
    assert result == '001.137.297-40'
    assert result != '001.137.297-41'
    assert len(result) == 14


# Generated at 2022-06-12 01:17:19.170802
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    assert br.cnpj(with_mask=False) == '30347524900017'
    assert br.cnpj(with_mask=True) == '30.347.524/9000-17'


# Generated at 2022-06-12 01:17:23.892135
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """

    :return:
    """
    import time
    for i in range(0, 10):
        print(BrazilSpecProvider().cpf())
        time.sleep(1)

# Generated at 2022-06-12 01:18:02.471782
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj != ""

# Generated at 2022-06-12 01:18:06.302353
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    assert(type(cnpj) == str)
    assert(b.validate_cnpj(cnpj) == True)


# Generated at 2022-06-12 01:18:11.176229
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cnpj_code = provider.cnpj(with_mask=False)
    assert isinstance(cnpj_code, str)
    assert len(cnpj_code) == 14


# Generated at 2022-06-12 01:18:18.308912
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """For a given initial seed, the result should be always the same."""
    from mimesis.builtins import BrazilSpecProvider

    brazil_spec_provider = BrazilSpecProvider(seed=42)
    assert brazil_spec_provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-12 01:18:21.250592
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf(False)) == 11
    assert len(provider.cpf(True)) == 14

# Generated at 2022-06-12 01:18:26.023512
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf(with_mask=False)
    if len(cpf) == 11:
        return True
    else:
        return False

# Generated at 2022-06-12 01:18:28.378043
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(with_mask=False)
    assert BrazilSpecProvider().cpf()


# Generated at 2022-06-12 01:18:30.735669
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Function to test method cpf of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cpf() == '362.111.290-08'


# Generated at 2022-06-12 01:18:34.279065
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider

    bz = BrazilSpecProvider()
    cpf = bz.cpf()
    print(cpf)


# Generated at 2022-06-12 01:18:36.688082
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    from mimesis.builtins import BrazilSpecProvider

    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14


# Generated at 2022-06-12 01:19:50.587990
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_cpfs = []
    test_cpfs.append('701.089.086-31')
    test_cpfs.append('143.362.908-48')
    test_cpfs.append('091.118.879-61')
    test_cpfs.append('903.397.865-43')
    test_cpfs.append('821.536.749-04')
    # Check if generated cpf is in test set
    for _ in range(10000):
        assert BrazilSpecProvider().cpf(with_mask = True) in test_cpfs


# Generated at 2022-06-12 01:19:52.667809
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    print(b.cnpj(with_mask=True))



# Generated at 2022-06-12 01:19:54.202548
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    print(cnpj)
    assert len(cnpj) == 18


# Generated at 2022-06-12 01:19:56.288979
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    assert BrazilSpecProvider.cpf(True) == BrazilSpecProvider.cpf(True)

if __name__ == "__main__":
    test_BrazilSpecProvider_cpf()

# Generated at 2022-06-12 01:19:59.282981
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pt-br', gender=Gender.MALE)

    # Test should return False if CNPJ is not valid
    print(p.cnpj())
    print('============================')
    # Test should return True if CNPJ is valid
    print(p.cnpj(mask=True))

# Generated at 2022-06-12 01:20:03.383632
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    a = BrazilSpecProvider(seed=1002)
    assert a.cnpj(with_mask=False) == '56625733000155'
    assert a.cnpj(with_mask=True) == '56.625.733/0001-55'


# Generated at 2022-06-12 01:20:08.592402
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Initialization
    bsp = BrazilSpecProvider()

    # Test if method cpf of class BrazilSpecProvider returns a CPF with mask
    assert bsp.cpf() == '527.921.592-98'

    # Test if method cpf of class BrazilSpecProvider returns a CPF without mask
    assert bsp.cpf(with_mask=False) == '52792488718'


# Generated at 2022-06-12 01:20:10.487551
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    prov = BrazilSpecProvider()
    assert True == isinstance(prov, BrazilSpecProvider)
    assert 11 == len(prov.cpf(False))



# Generated at 2022-06-12 01:20:14.204315
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider

    provider = BrazilSpecProvider()
    n = provider.cnpj(with_mask=True)
    print(n)



# Generated at 2022-06-12 01:20:15.684686
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider().cpf()


# Generated at 2022-06-12 01:23:15.745441
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    from .brazil_provider import BrazilSpecProvider

    b = BrazilSpecProvider(seed=0)

    cpf_with_dv = b.cpf(with_mask=True)
    print('cpf_with_dv = %s' % cpf_with_dv)

    assert cpf_with_dv == '018.863.937-10'

    cpf_without_dv = b.cpf(with_mask=False)
    print('cpf_without_dv = %s' % cpf_without_dv)

    assert cpf_without_dv == '018.863.937-10'



# Generated at 2022-06-12 01:23:20.059235
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider

    bzsp = BrazilSpecProvider()
    a = bzsp.cnpj()
    assert a is not None
    assert len(a) == 18
    assert a[2] == '.'
    assert a[6] == '.'
    assert a[10] == '/'
    assert a[15] == '-'


# Generated at 2022-06-12 01:23:21.169538
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() != ''


# Generated at 2022-06-12 01:23:26.874729
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj(with_mask=True)
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    assert cnpj.count('-') == 1


# Generated at 2022-06-12 01:23:32.881351
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    test_cnpj = BrazilSpecProvider(seed = 1)
    test = test_cnpj.cnpj()
    assert test == '28.455.973/0001-01'


# Generated at 2022-06-12 01:23:34.897296
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj."""
    assert BrazilSpecProvider().cnpj(with_mask=False) == '77732230000170'

# Generated at 2022-06-12 01:23:37.758039
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_mask = '00.000.000/0000-00'
    cnpj = BrazilSpecProvider().cnpj()
    assert(len(cnpj) == len(cnpj_mask))


# Generated at 2022-06-12 01:23:44.183713
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj.

    :returns: True if tests passed, otherwise False.
    :rtype: bool
    """
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=False)
    first_dv = cnpj[-2]
    second_dv = cnpj[-1]
    cnpj_without_dv = cnpj[:-2]
    assert _verify_modulo11_cnpj(cnpj_without_dv, first_dv, 5)
    assert _verify_modulo11_cnpj(cnpj_without_dv + first_dv, second_dv, 6)
