

# Generated at 2022-06-12 01:13:59.558402
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert '.' in cpf
    assert '-' in cpf


# Generated at 2022-06-12 01:14:00.945365
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(5):
        print(BrazilSpecProvider().cnpj())

# Generated at 2022-06-12 01:14:03.545628
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    assert len(br.cnpj()) == 18


# Generated at 2022-06-12 01:14:10.558662
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
  brazilData = BrazilSpecProvider()
  cpfTest = brazilData.cpf(False)
  print(cpfTest)

  # Assert that the cpf is a string
  assert(isinstance(cpfTest, str))

  # Assert the length of cpfTest
  assert(len(cpfTest) == 11)

# Unit tests for the method cnpj of class BrazilSpecProvider

# Generated at 2022-06-12 01:14:14.620580
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test"""
    provider = BrazilSpecProvider()
    assert len(provider.cnpj()) > 12
    assert len(provider.cnpj()) <= 18
    assert provider.cnpj(True) == '84.498.914/0001-29'


# Generated at 2022-06-12 01:14:20.952208
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person
    from mimesis.providers.person.pt_br import BrazilSpecProvider
    
    p = Person('en')
    print("\n########## TEST CNPJ ##########\n")
    # The following line of code generates the name of a brazilian person,
    # with the complete address (street, number and neighborhood of São Paulo),
    # age, gender, number of cell phones, and a phone number (without mask)

# Generated at 2022-06-12 01:14:24.388933
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test 1: test with the mask
    assert len(BrazilSpecProvider().cpf()) == 14

    # Test 2: test without the mask
    assert len(BrazilSpecProvider().cpf(False)) == 11


# Generated at 2022-06-12 01:14:34.554887
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    brasil_provider = BrazilSpecProvider()

    person_provider = Person(locale='pt-br')

    for _ in range(10):
        gender = person_provider.gender(dataset=Gender.FEMALE)
        if gender.startswith('F'):
            cpf = brasil_provider.cpf()
            assert len(cpf) == 14
            assert '.' in cpf
            assert '-' in cpf
        else:
            cpf = brasil_provider.cpf(with_mask=False)
            assert len(cpf) == 11
            assert '.' not in cpf
            assert '-' not in cpf

# Unit test to class BrazilSpecProvider

# Generated at 2022-06-12 01:14:37.486197
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    print(brazil.cpf(with_mask=False))


# Generated at 2022-06-12 01:14:44.484373
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    
    mask = re.compile("^[0-9]{3}.[0-9]{3}.[0-9]{3}-[0-9]{2}$")

    provider = BrazilSpecProvider(seed=42)

    assert mask.match(provider.cpf()) is not None
    assert mask.match(provider.cpf(True)) is not None
    assert mask.match(provider.cpf(False)) is None


# Generated at 2022-06-12 01:14:54.360102
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    generated_cpf = provider.cpf(with_mask=False)
    assert len(generated_cpf) == 11


# Generated at 2022-06-12 01:14:55.178301
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:14:56.626684
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert b.cpf() == '001.137.297-40'


# Generated at 2022-06-12 01:15:03.278708
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import re

    provider = BrazilSpecProvider()

    for x in range(100):
        cnpj = provider.cnpj()
        print(cnpj)
        assert len(cnpj) == 18  # CNPJ tem 18 dígitos
        assert re.search(r'\d\d\.\d\d\d\.\d\d\d/\d\d\d\d-\d\d', cnpj)


# Generated at 2022-06-12 01:15:05.933443
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-12 01:15:08.430023
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-12 01:15:12.412492
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of BrazilSpecProvider

    :return: boolean
    """

    assert(BrazilSpecProvider().cpf() != BrazilSpecProvider().cpf())
    assert(len(BrazilSpecProvider().cpf()) == 14)
    assert(len(BrazilSpecProvider().cpf(False)) == 11)
    return True


# Generated at 2022-06-12 01:15:16.823799
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj().__len__() == 18
    assert provider.cnpj(with_mask=False).__len__() == 14
    assert provider.cnpj(with_mask=False).isdigit() == True


# Generated at 2022-06-12 01:15:19.222573
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data = BrazilSpecProvider.cpf()
    assert isinstance(data, str)

# Generated at 2022-06-12 01:15:21.807064
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider_cnpj = BrazilSpecProvider()
    cnpj = '77.732.230/0001-70'
    assert provider_cnpj.cnpj() == cnpj


# Generated at 2022-06-12 01:15:38.473123
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(False)
    assert isinstance(cnpj, str)
    assert len(cnpj) == 14


# Generated at 2022-06-12 01:15:41.087988
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # GIVEN
    provider = BrazilSpecProvider()

    # WHEN
    cpf_output = provider.cnpj(with_mask = True)

    # THEN
    assert cpf_output is not None


# Generated at 2022-06-12 01:15:51.018766
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=42)

    with_mask = provider.cnpj()
    print(with_mask)
    print(type(with_mask))
    assert len(with_mask) == 18

    without_mask = provider.cnpj(with_mask=False)
    print(without_mask)
    print(type(without_mask))
    assert len(without_mask) == 14

    # invalid
    provider = BrazilSpecProvider(seed=None)
    for _ in range(100):
        with_mask = provider.cnpj()
        without_mask = provider.cnpj(with_mask=False)
        assert len(without_mask) == 14
        assert len(with_mask) == 18



# Generated at 2022-06-12 01:15:55.517684
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj(with_mask = False)
    if cnpj != '31471402802301':
        print('ERRO: ' + cnpj)
    else:
        print('OK: ' + cnpj)


# Generated at 2022-06-12 01:16:03.555169
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    random_generator = BrazilSpecProvider()

    cpf_result = random_generator.cpf()
    assert len(cpf_result) == 14
    assert cpf_result[3] == "."
    assert cpf_result[7] == "."
    assert cpf_result[11] == "-"

    # CPF without mask
    cpf_result = random_generator.cpf(with_mask=False)
    assert len(cpf_result) == 11


# Generated at 2022-06-12 01:16:05.110224
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    provider.cnpj()
    assert provider


# Generated at 2022-06-12 01:16:13.978840
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf.find('.') == 3
    assert cpf.find('-') == 7
    assert cpf != cpf.replace('.', '').replace('-', '')
    cpf = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf == cpf.replace('.', '').replace('-', '')
    assert cpf.isdigit()


# Generated at 2022-06-12 01:16:18.382277
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    expected = '77.732.230/0001-70'
    provider = BrazilSpecProvider()
    result = provider.cnpj(True)
    assert result == expected, 'CPF: {}'.format(result)


# Generated at 2022-06-12 01:16:19.927122
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("cnpj: ", BrazilSpecProvider().cnpj())

# Generated at 2022-06-12 01:16:24.638067
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj(with_mask = False)
    print(bnpj)
    print(type(cnpj))
    


# Generated at 2022-06-12 01:16:57.656046
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    bp = BrazilSpecProvider()
    assert re.match('\d\d\d.\d\d\d.\d\d\d-\d\d', bp.cpf())


# Generated at 2022-06-12 01:17:05.372737
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.date_time import DateTime
    from mimesis.providers.name import Name

    # Initialization of class BrazilSpecProvider
    bsp = BrazilSpecProvider()

    # Initialization of class Name
    name = Name('pt-br')

    # Initialization of class DateTime
    dt = DateTime('pt-br')

    # Initialization of a list of documents
    documents = []

    # Loop of the method cnpj
    # bsp.cnpj()

    # Check the length of the list
    # assert len(documents) == 40000

    # Calculate the value of the method cnpj
    cnpj = bsp.cnpj()

    # Check the return of method cnpj

# Generated at 2022-06-12 01:17:07.679250
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14



# Generated at 2022-06-12 01:17:12.265387
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    x = BrazilSpecProvider()
    y = x.cpf()
    z = x.cpf()
    assert(len(y) == 14)
    assert(len(z) == 14)
    assert(y != z)
    assert(y[3] == '.')
    assert(y[7] == '.')
    assert(y[11] == '-')
    assert(z[3] == '.')
    assert(z[7] == '.')
    assert(z[11] == '-')


# Generated at 2022-06-12 01:17:16.384748
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    # Test case 1
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'

    # Test case 2
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11


# Generated at 2022-06-12 01:17:21.630123
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # create object BrazilSpecProvider
    object_BrazilSpecProvider_cnpj = BrazilSpecProvider()

    # run method cnpj
    result_BrazilSpecProvider_cnpj = object_BrazilSpecProvider_cnpj.cnpj()

    # print result
    print(result_BrazilSpecProvider_cnpj)


# Generated at 2022-06-12 01:17:25.030824
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers import BrazilSpecProvider
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() != None


# Generated at 2022-06-12 01:17:29.816112
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    # Remove mask
    assert len(cpf.replace('.', '').replace('-', '')) == 11


# Generated at 2022-06-12 01:17:36.523162
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    num_tests = 1000
    provider = BrazilSpecProvider()
    for i in range(num_tests):
        cpf = provider.cpf()
        assert isinstance(cpf, str)
        assert len(cpf) == 14
        assert cpf[3] == "."
        assert cpf[7] == "."
        assert cpf[11] == "-"
        cpf = cpf.replace(".", "")
        cpf = cpf.replace("-", "")
        assert int(cpf)


# Generated at 2022-06-12 01:17:46.669844
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf() of class BrazilSpecProvider."""
    sut = BrazilSpecProvider(seed=1)
    result = sut.cpf(with_mask=False)
    assert result == "14904901129"

    def get_verifying_digit_cpf(cpf, peso):
        """Calculate the verifying digit for the CPF."""
        soma = 0
        for index, digit in enumerate(cpf):
            soma += digit * (peso - index)
        resto = soma % 11
        if resto == 0 or resto == 1 or resto >= 11:
            return 0
        return 11 - resto

    cpf_without_dv = [1, 4, 9, 0, 4, 9, 0, 1, 1]
    first_dv = get_verifying

# Generated at 2022-06-12 01:18:56.506934
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=True)
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert cpf.count('/') == 0
    assert len(cpf) == 14


# Generated at 2022-06-12 01:19:00.696301
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Arrange
    provider = BrazilSpecProvider()

    # Act
    result = provider.cnpj(False)

    # Assert
    assert len(result) == 14


# Generated at 2022-06-12 01:19:03.684415
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf == '034.806.792-56'


# Generated at 2022-06-12 01:19:06.625346
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert len(result) is 14


# Generated at 2022-06-12 01:19:07.865686
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    np1 = BrazilSpecProvider()
    np2 = BrazilSpecProvider()
    assert np1.cnpj() != np2.cnpj()


# Generated at 2022-06-12 01:19:10.729729
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf."""
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 14


# Generated at 2022-06-12 01:19:19.968129
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import datetime

    brazil_provider = BrazilSpecProvider()

    result = brazil_provider.cnpj()
    print(result)
    assert result == '77.732.230/0001-70'

    # cnpj_orig = '77.732.230/0001-70'
    cnpj_orig = '77.929.909/0001-92'
    cnpj_orig_no_mask = cnpj_orig.replace('.', '').replace('/', '').replace('-', '')

    def dn(cnpj_full):
        # print(cnpj_full)
        weight = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        digit = cnpj_full[12]

# Generated at 2022-06-12 01:19:24.494240
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the method cpf of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cpf() == '077.913.611-31'
    assert BrazilSpecProvider().cpf(with_mask=False) == '07791361131'


# Generated at 2022-06-12 01:19:26.422730
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cPf = provider.cpf()
    print(cPf)
    print(type(cPf))


# Generated at 2022-06-12 01:19:31.237981
# Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-12 01:22:33.353512
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert brazil.cnpj() == '77.732.230/0001-70'
    assert len(brazil.cnpj()) == 18
    assert 'Brasília' in brazil.cnpj()


# Generated at 2022-06-12 01:22:35.394007
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    assert br.cpf(with_mask=False) == '00113729750'


# Generated at 2022-06-12 01:22:50.154128
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    expected = ['096.919.344-76', '046.982.719-85', '083.587.098-46',
                '039.620.942-72', '071.512.868-50', '019.848.308-71',
                '094.113.232-75', '037.244.949-63', '098.847.294-53',
                '035.006.836-45', '007.495.204-22']

    actual = provider.cpf()

    assert expected == actual


# Generated at 2022-06-12 01:22:51.443228
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    prov = BrazilSpecProvider()
    for _ in range(100):
        assert prov.cpf(with_mask=False)
        assert prov.cpf(with_mask=True)


# Generated at 2022-06-12 01:22:56.707941
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result_one = provider.cnpj()
    cnpj_one = list(result_one)
    cnpj_one.insert(2, '.')
    cnpj_one.insert(6, '.')
    cnpj_one.insert(10, '/')
    cnpj_one.insert(15, '-')
    cnpj_one = ''.join(cnpj_one)

    assert len(cnpj_one) == 18
    assert len(provider.cnpj(with_mask=False)) == 14



# Generated at 2022-06-12 01:23:01.562981
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert b.cpf() == '062.048.610-62'
    assert b.cpf() == '813.638.893-89'
    assert b.cpf() == '421.116.794-94'
    assert b.cpf() == '306.055.541-58'
    assert b.cpf() == '204.237.901-31'
    assert b.cpf() == '884.656.531-86'
    assert b.cpf() == '811.913.912-89'
    assert b.cpf() == '996.092.347-97'
    assert b.cpf() == '081.423.414-03'
    assert b.cpf() == '927.975.832-24'

# Generated at 2022-06-12 01:23:06.251413
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider cnpj method.
    Returned value should be a string of 14 characters.
    First two characters should be numbers from 0 to 9,
    following by a period and then 3 numbers, then another period
    and then 3 numbers, then a backward slash, and then 4 numbers,
    and finally a dash and then 2 numbers.
    """
    import re

    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 14
    assert re.match(r'\d\d\.\d\d\d\.\d\d\d/\d\d\d\d-\d\d', cnpj) is not None



# Generated at 2022-06-12 01:23:09.212803
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
   # cpf = BrazilSpecProvider.cpf(BrazilSpecProvider())
   # print ("cpf = ", cpf)
   assert len(BrazilSpecProvider.cpf(BrazilSpecProvider())) == 14


# Generated at 2022-06-12 01:23:10.660343
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    print(bsp.cnpj())

# Generated at 2022-06-12 01:23:14.152725
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bb = BrazilSpecProvider()
    cnpj = bb.cnpj(with_mask=True)
    assert cnpj[12:14] == bb.cpf(with_mask=False)[9:]
