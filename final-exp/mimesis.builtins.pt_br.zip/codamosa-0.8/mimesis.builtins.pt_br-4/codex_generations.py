

# Generated at 2022-06-12 01:14:00.238941
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    # Teste dentro do escopo de validação de uma empresa real
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    if cnpj != '24.071.209/0001-79':
        return False

    return True

# Generated at 2022-06-12 01:14:06.345634
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf method"""
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert '-' in cpf
    assert '.' in cpf
    return None


# Generated at 2022-06-12 01:14:09.100369
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider(seed=4).cpf()
    assert cpf == '834.703.658-17'


# Generated at 2022-06-12 01:14:17.240588
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method BrazilSpecProvider.cnpj."""
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.schema import Field, Schema

    b = BrazilSpecProvider()
    # Create an instance of the schema, defining some fields and their types.
    schema_instance = Schema(
        gender=Field(enum=Gender),
        cnpj=Field(cnpj=True)
    )

    # Create a SQLAlchemy engine.
    #engine = create_engine(
    #    'postgresql://postgres:postgres@localhost:5432/northwind')

    # Create all tables in the engine.
    #Base.metadata.create_all(engine)

    # Create a SQLAlchemy session.
    #Session = sessionmaker(bind=

# Generated at 2022-06-12 01:14:20.916848
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_locale = BrazilSpecProvider()
    cpf = brazil_locale.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:14:32.639249
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Cria um objeto BrazilSpecProvider
    bp = BrazilSpecProvider()
    cnpj = bp.cnpj()
    # Divide o cnpj em partes e testa se a soma é correta
    x1 = int(str(cnpj[0])) + int(str(cnpj[1])) + int(str(cnpj[2])) + int(str(cnpj[3]))
    x2 = int(str(cnpj[4])) + int(str(cnpj[5])) + int(str(cnpj[6])) + int(str(cnpj[7]))

# Generated at 2022-06-12 01:14:37.613821
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of class BrazilSpecProvider."""
    # test mask
    assert BrazilSpecProvider.cpf(with_mask = True)
    # test no_mask
    assert BrazilSpecProvider.cpf(with_mask = False)


# Generated at 2022-06-12 01:14:44.562058
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider class."""
    seed = '9ff4f1ee-8b4c-1b2e-d637-f8c7a6eaab15'
    assert BrazilSpecProvider(seed=seed).cnpj(with_mask=False) == '06785687000162'
    assert BrazilSpecProvider(seed=seed).cnpj(with_mask=True) == '06.785.687/0001-62'

# Generated at 2022-06-12 01:14:52.792333
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    # cnpj = provider.cnpj()
    cnpj = "11.245.115/0001-47"
    assert isinstance(cnpj, str)
    # assert len(cnpj) == 18
    # assert provider.cnpj() != provider.cnpj()
    assert provider.cnpj(True) != provider.cnpj(False)


# Generated at 2022-06-12 01:15:00.568242
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""

    br = BrazilSpecProvider()

    for _ in range(10):
        assert br.cpf(with_mask=True).count('.') == 2, "CPF should have mask with 2 dots"
        assert br.cpf(with_mask=True).count('-') == 1, "CPF should have mask with 1 dash"
        assert len(br.cpf(with_mask=False)) == 11, "CPF without mask should have 11 digits"
        assert len(br.cpf()) == 14, "CPF with mask should have 14 digits"



# Generated at 2022-06-12 01:15:11.916696
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj from class BrazilSpecProvider."""
    from mimesis import BrazilSpecProvider
    spec = BrazilSpecProvider()
    cnpj = spec.cnpj()
    assert cnpj == '83.843.834/0001-29'


# Generated at 2022-06-12 01:15:20.405743
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider._cpf()."""
    # CPF with mask
    expected_cpf = '444.544.484-06'

# Generated at 2022-06-12 01:15:30.157428
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""

    print("\n# Unit test for method cpf of class BrazilSpecProvider")

    import re
    from random import seed
    from mimesis.providers.brazil import BrazilSpecProvider

    seed(12345)
    state = BrazilSpecProvider()

    cpf = state.cpf()
    print("\tFirst cpf: %s" % cpf)

    cpf = state.cpf(with_mask=False)
    print("\tSecond cpf: %s" % cpf)

    assert re.match("^\d{3}.\d{3}.\d{3}-\d{2}$", cpf), "Invalid CPF format"
    assert len(cpf) == 14, "Invalid CPF length"


test_BrazilSpecProvider

# Generated at 2022-06-12 01:15:32.929219
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    cnpj = BrazilSpecProvider().cpf()
    assert len(cnpj) == 14


# Generated at 2022-06-12 01:15:37.069386
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert set(cpf) == set("0123456789-.")

# Generated at 2022-06-12 01:15:38.926816
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-12 01:15:50.468066
# Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-12 01:15:55.728893
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method ''cpf'' of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cpf1 = provider.cpf()
    cpf2 = provider.cpf()
    assert len(cpf1) == 14
    assert len(cpf1) == 14
    assert cpf1 != cpf2


# Generated at 2022-06-12 01:16:05.385680
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    bsp = BrazilSpecProvider()
    male = Person('pt-br', gender=Gender.MALE)
    male.cpf()

    mask = male.cpf(with_mask=True)
    pattern = r'^([0-9]{3}\.){2}[0-9]{3}-[0-9]{2}$'
    assert re.fullmatch(pattern, mask) is not None

    non_mask = male.cpf(with_mask=False)
    assert len(non_mask) == 11
    assert type(non_mask) is str



# Generated at 2022-06-12 01:16:11.989565
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender

    bsp = BrazilSpecProvider()

    # Gender is MALE since it doesn't affect the CPF generation
    assert bsp.cpf(Gender.MALE) in '###.###.###-##'


# Generated at 2022-06-12 01:16:31.856713
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit tests for BrazilSpecProvider.cnpj.

    :returns: Nothing.
    """
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'
    assert BrazilSpecProvider().cnpj(with_mask=False) == '77732240000170'


# Generated at 2022-06-12 01:16:35.652131
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(with_mask=False)
    #assert len(cnpj) == 14
    #assert cnpj.isdigit()

# Generated at 2022-06-12 01:16:41.505482
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Verify if the return of BrazilSpecProvider.cnpj method is a valid CNPJ."""
    brazil = BrazilSpecProvider()
    assert len(brazil.cnpj()) == 18

    # Verify if the mask is right.
    assert len(brazil.cnpj(False)) == 14
    assert len(brazil.cnpj(True)) == 18



# Generated at 2022-06-12 01:16:44.989530
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    c = BrazilSpecProvider()
    cpf = c.cpf(with_mask=False)
    cpf1 = c.cpf(with_mask=True)
    assert len(cpf) == 11
    assert len(cpf1) == 14
    assert cpf == cpf1[:11] or cpf == cpf1[13]


# Generated at 2022-06-12 01:16:54.638797
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 14
    assert len(bsp.cnpj(with_mask=False)) == 14
    assert len(brazil_spec_provider.cnpj()) == 14
    assert len(BrazilProviders.BrazilSpecProvider().cnpj()) == 14
    assert BrazilSpecProvider.cnpj(brazil_spec_provider) == BrazilProviders.BrazilSpecProvider().cnpj()
    assert BrazilSpecProvider.cnpj(BrazilProviders.BrazilSpecProvider()) == BrazilProviders.BrazilSpecProvider().cnpj()



# Generated at 2022-06-12 01:16:58.235282
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider(seed=13)
    cnpj = obj.cnpj()
    assert cnpj == '38.669.815/0001-91'

# Generated at 2022-06-12 01:17:01.369646
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Test BrazilSpecProvider_cpf")
    provider = BrazilSpecProvider()
    for i in range(0, 10):
        print(provider.cpf(with_mask=True))
    return


# Generated at 2022-06-12 01:17:05.695468
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    bsp = BrazilSpecProvider()
    result = bsp.cpf()
    assert len(result) == 14 and not result.endswith('-0')


# Generated at 2022-06-12 01:17:09.307119
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert all([ x in "0123456789." for x in cnpj ])


# Generated at 2022-06-12 01:17:11.793701
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    assert len(brazil_provider.cnpj()) == 18
    assert brazil_provider.cnpj()[13:] != '-'

# Generated at 2022-06-12 01:17:55.438242
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    c = BrazilSpecProvider()
    c1 = c.cpf()
    print(c1)
    assert len(c1) == 14
    assert re.match(r'\d{3}\.\d{3}\.\d{3}-\d{2}', c1) is not None


# Generated at 2022-06-12 01:17:57.962356
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    print (brazil_spec_provider.cpf())

# Generated at 2022-06-12 01:18:03.417060
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    with BrazilSpecProvider() as b:
        assert b.cnpj(True) == '31.944.645/0001-10' and \
               b.cnpj(True) == '57.827.958/0001-00' and \
               b.cnpj(True) == '17.314.414/0001-30'


# Generated at 2022-06-12 01:18:05.502649
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider.cpf(BrazilSpecProvider)
    assert cpf == BrazilSpecProvider().cpf()

# Generated at 2022-06-12 01:18:07.731570
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    b.cpf() == '1'
    assert len(b.cpf()) == 14


# Generated at 2022-06-12 01:18:18.385883
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    def _cnpj():
        return provider.cnpj(with_mask=False)

    cnpj1 = _cnpj()
    cnpj2 = _cnpj()
    cnpj3 = _cnpj()

    assert len(cnpj1) == 14
    assert len(cnpj2) == 14
    assert len(cnpj3) == 14

    assert cnpj1 != cnpj2
    assert cnpj1 != cnpj3
    assert cnpj2 != cnpj3

# Generated at 2022-06-12 01:18:30.072858
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    cpf_mask = "874.313.420-17"
    cpf_no_mask = "87431342017"
    cpf_generate = BrazilSpecProvider.cpf()
    assert isinstance(cpf_generate, str)
    cpf_mask_generate = BrazilSpecProvider.cpf(with_mask = True)
    assert isinstance(cpf_mask_generate, str)
    cpf_no_mask_generate = BrazilSpecProvider.cpf(with_mask=False)
    assert isinstance(cpf_no_mask_generate, str)
    assert BrazilSpecProvider(seed=42).cpf() == cpf_mask
    assert BrazilSpecProvider(seed=42).cpf(with_mask=True) == cp

# Generated at 2022-06-12 01:18:34.236517
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_provider = BrazilSpecProvider()
    for i in range(500):
        cpf = test_provider.cpf()
        assert len(cpf) == 14
        for char in cpf:
            assert char.isdigit() or char == "." or char == "-"


# Generated at 2022-06-12 01:18:35.757973
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert isinstance(cpf, str)



# Generated at 2022-06-12 01:18:39.731212
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=12345678)

    assert provider.cnpj() == "85.927.738/0001-06"
    assert provider.cnpj(with_mask=False) == "859277380"

# Generated at 2022-06-12 01:20:03.490700
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    from mimesis.builtins.brazil.brazil_provider import BrazilSpecProvider
    provider = BrazilSpecProvider('pt-br')
    assert provider.cpf(False) == '00113729740'


# Generated at 2022-06-12 01:20:13.745724
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    # test_data=['77.732.230/0001-70',
    #           '27.639.942/0001-75',
    #           '06.542.404/0001-37',
    #           '84.345.933/0001-13',
    #           '06.807.406/0001-15',
    #           '50.668.944/0001-12',
    #           '93.878.633/0001-53',
    #           '27.939.503/0001-13',
    #           '43.766.182/0001-71',
    #           '22.919.913/0001-59',
    #           '37.719.033/0001-82',
    #          

# Generated at 2022-06-12 01:20:17.447163
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil_provider import BrazilSpecProvider as bs
    provider = bs()
    assert provider.cpf() == '001.137.297-40'



# Generated at 2022-06-12 01:20:20.600846
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.person.brazil_provider import BrazilSpecProvider
    provider = BrazilSpecProvider()
    assert provider.cnpj() != ''
# Verify method cnpj of class BrazilSpecProvider
test_BrazilSpecProvider_cnpj()


# Generated at 2022-06-12 01:20:21.577603
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    print(provider.cpf())



# Generated at 2022-06-12 01:20:28.029114
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Running BrazilSpecProvider.cpf()...")
    provider = BrazilSpecProvider()
    first = provider.cpf()
    second = provider.cpf()
    assert provider.cpf(False) != provider.cpf(True)
    assert len(first) == len(second) == len("000.000.000-00")
    assert isinstance(first, str)
    assert provider.cpf() != first
    print("BrazilSpecProvider.cpf() - OK")


# Generated at 2022-06-12 01:20:29.909421
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # given
    provider = BrazilSpecProvider()

    # when
    result = provider.cnpj()

    # then
    assert len(result.replace('.', '').replace('-', '')) == 14
    assert result.count('.') == 2
    assert result.count('-') == 1

# Generated at 2022-06-12 01:20:33.337262
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the CPF provided by Brazil."""
    b = BrazilSpecProvider()
    cpf = b.cpf()
    print(cpf)
    assert len(cpf) == 14


# Generated at 2022-06-12 01:20:36.211869
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    bsp = BrazilSpecProvider()
    s = bsp.cpf()
    assert re.search(r'\d{3}\.\d{3}\.\d{3}-\d{2}', s), s


# Generated at 2022-06-12 01:20:38.835894
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert brazil.cpf() == '585.992.933-56' or brazil.cpf() == '034.555.705-32'


# Generated at 2022-06-12 01:23:44.213415
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test to verify the data generated by method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    # test method "cnpj"
    cnpj_1 = provider.cnpj(True)
    assert len(cnpj_1) == 18
    cnpj_2 = provider.cnpj(False)
    assert len(cnpj_2) == 14
    assert cnpj_1 != cnpj_2
    assert cnpj_1[2] == '.'
    assert cnpj_1[6] == '.'
    assert cnpj_1[10] == '/'
    assert cnpj_1[15] == '-'