

# Generated at 2022-06-12 01:14:00.070048
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf(True)
    assert cpf
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert cpf.replace('.', '').replace('-', '').isnumeric()

# Generated at 2022-06-12 01:14:06.064696
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf(True)
    assert cpf is not None
    assert len(cpf) == 14
    assert '/' not in cpf
    assert '-' in cpf


# Generated at 2022-06-12 01:14:12.577686
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for _ in range(100):
        cpf = provider.cpf()
        assert isinstance(cpf, str)
        assert len(cpf) == 14
        assert cpf.count('.') == 2
        assert cpf.count('-') == 1
        for item in cpf:
            assert isinstance(item, str)
            assert item in [str(i) for i in range(10)]
            assert item in ['.', '-']


# Generated at 2022-06-12 01:14:15.356470
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-12 01:14:21.278104
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Verify method returns a string
    assert type(BrazilSpecProvider().cnpj()) == str
    # Verify method return a cnpj with mask when setting with_mask to True
    assert len(BrazilSpecProvider().cnpj(with_mask=True)) == 18
    assert BrazilSpecProvider().cnpj(with_mask=True)[2] == '.'
    assert BrazilSpecProvider().cnpj(with_mask=True)[6] == '.'
    assert BrazilSpecProvider().cnpj(with_mask=True)[10] == '/'
    assert BrazilSpecProvider().cnpj(with_mask=True)[15] == '-'

    # Verify method return a cnpj without mask when setting with_mask to False
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14


# Generated at 2022-06-12 01:14:32.901735
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    sample_size = 10
    provider = BrazilSpecProvider()
    provider.seed(int(provider.timestamp()))
    for i in range(sample_size):
        cnpj_value = provider.cnpj()
        assert len(cnpj_value) == 18, f"[[TEST]] Length of CNPJ value '{cnpj_value}' is not 18."
        
        cnpj_value = provider.cnpj(False)
        assert len(cnpj_value) == 14, f"[[TEST]] Length of CNPJ value '{cnpj_value}' is not 14."
    print(f"[[TEST SUCCESS]] BrazilSpecProvider.cnpj(with_mask) passed.")

if __name__ == "__main__":
    test_BrazilSpecProvider_cnp

# Generated at 2022-06-12 01:14:43.937433
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test the normal case
    assert(BrazilSpecProvider().cpf(False) == '7273224034')
    assert(BrazilSpecProvider().cpf() == '727.322.403-34')

    # Test the weird case of cpf with all digits equal
    assert(BrazilSpecProvider().cpf(False) == '00000000000')
    assert(BrazilSpecProvider().cpf() == '000.000.000-00')

    # Test the weird case of cpf with all digits equal except the last one
    assert(BrazilSpecProvider().cpf(False) == '11111111111')
    assert(BrazilSpecProvider().cpf() == '111.111.111-11')



# Generated at 2022-06-12 01:14:46.866815
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    cpf = a.cpf()
    print(cpf)
    assert len(cpf) == 14


# Generated at 2022-06-12 01:14:51.879423
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins.brazil import BrazilSpecProvider
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() is not None


# Generated at 2022-06-12 01:14:56.212566
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    b = BrazilSpecProvider()
    b.seed(4321)
    assert b.cnpj(with_mask=True) == '34.112.631/0001-15'
    assert b.cnpj(with_mask=False) == '34112631000115'

# Generated at 2022-06-12 01:15:05.685291
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    print(provider.cpf())


# Generated at 2022-06-12 01:15:09.022136
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bz = BrazilSpecProvider()
    assert len(bz.cnpj()) == 18
    assert len(bz.cnpj(with_mask=False)) == 14

# Generated at 2022-06-12 01:15:13.782702
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj(with_mask=False)
    cnpj2 = b.cnpj(with_mask=False)
    assert cnpj != cnpj2
    assert len(cnpj) == 14
    assert len(cnpj2) == 14
    assert cnpj != cnpj2


# Generated at 2022-06-12 01:15:16.735432
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()

    assert len(cpf) == 14
    assert type(cpf) is str


# Generated at 2022-06-12 01:15:28.145162
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    collection = list()
    c = BrazilSpecProvider()
    for _ in range(0, 100):
        collection.append(c.cpf())
    assert len(collection) == 100
    assert collection[10] == '436.675.301-03'
    assert collection[15] == '904.959.822-62'
    assert collection[24] == '007.569.017-07'
    assert collection[30] == '826.076.540-09'
    assert collection[51] == '559.091.037-68'
    assert collection[71] == '582.739.463-86'
    assert collection[80] == '392.929.927-62'
    assert collection[96] == '911.098.024-42'


# Generated at 2022-06-12 01:15:38.431027
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import unittest
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender

    class BrazilSpecProviderTestCase(unittest.TestCase):
        def setUp(self):
            self.cpf = BrazilSpecProvider().cpf()

        def test_cpf(self):
            self.assertEqual(len(self.cpf), 14)
            self.assertRegex(self.cpf, '\d{3}\.\d{3}\.\d{3}-\d{2}')
            self.assertNotRegex(self.cpf, '(.)\1{10,}')

    unittest.main()


# Generated at 2022-06-12 01:15:39.973157
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert (result) == result


# Generated at 2022-06-12 01:15:49.291153
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers import BrazilSpecProvider
    from mimesis.providers.person import Person

    test = BrazilSpecProvider()
    assert len(test.cnpj()) == 18

    test_person = Person('pt-br')
    test.seed(test_person.random(gender=Gender.FEMALE))

    cnpj = test.cnpj()
    assert len(cnpj) == 18
    assert cnpj == '77.732.230/0001-70'

# Generated at 2022-06-12 01:15:53.610452
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    tester = BrazilSpecProvider()
    assert tester.cpf(with_mask=False) == '14335775497'
    assert tester.cpf(with_mask=True) == '143.357.754-97'



# Generated at 2022-06-12 01:15:55.857960
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert len(BrazilSpecProvider().cnpj(True)) == 18


# Generated at 2022-06-12 01:16:16.995893
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    start_time = datetime.now()
    b = BrazilSpecProvider()


# Generated at 2022-06-12 01:16:24.973161
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider method cpf"""
    # prepare
    bsp = BrazilSpecProvider()

    # run
    result1 = bsp.cpf(with_mask=True)
    result2 = bsp.cpf(with_mask=False)

    # verify
    assert result1 != result2
    assert result1.count('.') == 2
    assert result1.count('-') == 1
    assert result2.count('.') == 0
    assert result2.count('-') == 0


# Generated at 2022-06-12 01:16:27.741137
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider(seed=123)

    assert bsp.cpf() == '161.185.118-64'



# Generated at 2022-06-12 01:16:31.767712
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1


# Generated at 2022-06-12 01:16:34.019132
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert result.__len__() == 14

# Generated at 2022-06-12 01:16:37.192055
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider.cpf()
    str(cpf)


# Generated at 2022-06-12 01:16:45.419608
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    cnpj_generator = BrazilSpecProvider()
    cnpj = cnpj_generator.cnpj(with_mask=False)
    cnpj_without_dv = cnpj[:-2]

    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0

# Generated at 2022-06-12 01:16:52.103314
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert (len(cpf) == 14)
    assert (cpf[3] == '.')
    assert (cpf[7] == '.')
    assert (cpf[11] == '-')



# Generated at 2022-06-12 01:17:03.550779
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    from .mimesis_test import TestCase

    class _BrazilSpecProviderMixin(TestCase):

        def setUp(self):
            super().setUp()
            self.provider = BrazilSpecProvider()

        def test_cnpj(self):
            cnpj = self.provider.cnpj()
            self.assertNotEqual(cnpj, '', False)
            self.assertEqual(len(cnpj), 18, True)
            self.assertEqual('{}.{}.{}/{}-{}'.format(cnpj[:2], cnpj[2:5],
                                                     cnpj[5:8], cnpj[8:12], cnpj[12:]), cnpj, True)

# Generated at 2022-06-12 01:17:11.679005
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider

    This method is similar to random_cnpj (in file random_cnpj.py), but
    has a different implementation.
    """

    # Random object
    bs = BrazilSpecProvider()

    # Number of CNPJ's tested
    n = 10000

    for _ in range(n):
        # Random CNPJ generated
        cnpj = bs.cnpj()

        # Purpose: The CNPJ must have 14 characters
        assert len(cnpj) == 14

        # Purpose: All characters must be numbers
        assert cnpj.isnumeric()

        # Purpose: The first two numbers must be different from zero
        assert int(cnpj[0]) != 0 and int(cnpj[1]) != 0

        # Purpose: Positions 1 and 2 of

# Generated at 2022-06-12 01:17:52.356456
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    set_seed()
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18



# Generated at 2022-06-12 01:17:58.043305
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf_1 = provider.cpf()
    assert len(cpf_1) == 14
    assert cpf_1.count('.') == 2
    assert cpf_1.count('-') == 1
    assert cpf_1.replace('.', '').replace('-', '').isdigit()


# Generated at 2022-06-12 01:18:07.049493
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_1 = BrazilSpecProvider().cnpj()
    cnpj_2 = BrazilSpecProvider().cnpj()

    # Make sure the two CNPJs are different
    assert(cnpj_1 is not cnpj_2)

    # Make sure the CNPJ constructed from the string is equal to the original
    cnpj_3 = BrazilSpecProvider(seed=cnpj_1).cnpj()
    assert(cnpj_1 == cnpj_3)

    # Make sure the length of the generated strings is 14
    assert( len(cnpj_1) == 14 and len(cnpj_2) == 14 )

# Generated at 2022-06-12 01:18:15.542608
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18
    assert '.' in cnpj and '-' in cnpj
    cnpj = brazil.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert '.' not in cnpj and '-' not in cnpj

# Generated at 2022-06-12 01:18:17.019424
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-12 01:18:21.423975
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method that creates a valid CNPJ."""
    from mimesis.providers.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'



# Generated at 2022-06-12 01:18:25.078828
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert cpf == '529.827.871-38'

# Generated at 2022-06-12 01:18:27.803601
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:18:36.509204
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf1 = bsp.cpf(with_mask=True)
    cpf2 = bsp.cpf(with_mask=False)
    assert len(cpf1) == 14
    assert len(cpf2) == 11
    test_cases = [
        "001.137.297-40",
        "477.567.987-80",
        "009.631.964-00",
        "064.996.833-43",
        "555.773.637-02",
        "632.894.363-00",
        "790.084.895-49",
        "957.931.274-07",
    ]

# Generated at 2022-06-12 01:18:39.113392
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print(BrazilSpecProvider().cpf())
# test_BrazilSpecProvider_cpf()


# Generated at 2022-06-12 01:20:00.178337
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("Test of method cnpj of class BrazilSpecProvider\n")
    # We create a object
    obj = BrazilSpecProvider()
    # We call method cnpj
    cnpj = obj.cnpj()
    print(cnpj)

    # Test assert
    assert len(cnpj) == 14
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

    # We call method cnpj
    cnpj = obj.cnpj(with_mask=False)
    print(cnpj)

    # Test assert
    assert len(cnpj) == 12
    assert cnpj[2] != '.'

# Generated at 2022-06-12 01:20:04.837806
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider.cpf.__doc__ == "Get a random CPF.\n\n        :param with_mask: Use CPF mask (###.###.###-##).\n        :returns: Random CPF.\n\n        :Example:\n            001.137.297-40\n        "


# Generated at 2022-06-12 01:20:07.240584
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14


# Generated at 2022-06-12 01:20:09.484115
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14


# Generated at 2022-06-12 01:20:17.367593
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    import re
    brazil = BrazilSpecProvider(seed=42)

    assert re.match(r'\d\d\d\.\d\d\d\.\d\d\d\-\d\d',
                    brazil.cpf(with_mask=True)), "Falha na geração do CPF"

    assert isinstance(brazil.cpf(with_mask=False), str)


# Generated at 2022-06-12 01:20:24.470780
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    cnpj_num = int(cnpj[12:])
    # Test by example, this is a valid cnpj number.
    assert cnpj == '77.732.230/0001-70'
    # Test by example, this is a valid base, without the last two digits
    base = '77732' + str(cnpj_num)
    # Test the last digit
    assert cnpj_num % 11 == 0
    # Test the penultimate digit
    x = 0
    soma = 0
    for i in range(6, 1, -1):
        soma += int(base[x]) * i
        x += 1
    x+=1
    rest1 = int(base[x])

# Generated at 2022-06-12 01:20:25.568408
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj()


# Generated at 2022-06-12 01:20:26.396948
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf(False)) == 11


# Generated at 2022-06-12 01:20:28.741855
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=None)
    assert provider.cpf() == '365.357.294-93'


# Generated at 2022-06-12 01:20:36.051583
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider, Datetime, Generator
    from mimesis.builtins import BrazilSpecProvider as BrazilSpecProvider_builtin

    seed = '1580234663751'
    datetime = Datetime(seed=seed)
    generator = Generator(seed=seed)
    brazil_provider = BrazilSpecProvider(seed=seed)

    assert brazil_provider.cnpj(with_mask=False) == '47732230000170'
    assert brazil_provider.cnpj(with_mask=True) == '47.732.230/0001-70'

    brazil_provider_builtin = BrazilSpecProvider_builtin(seed=seed)
    assert brazil_provider_builtin.cnpj(with_mask=False) == '47732230000170'
    assert b

# Generated at 2022-06-12 01:23:35.217854
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Expected results
    instance1 = BrazilSpecProvider(seed=1)
    instance2 = BrazilSpecProvider(seed=2)
    instance3 = BrazilSpecProvider(seed=3)
    instance4 = BrazilSpecProvider(seed=4)
    instance5 = BrazilSpecProvider(seed=5)

    assert instance1.cnpj() == '77.732.230/0001-70'
    assert instance2.cnpj() == '71.356.255/0001-70'
    assert instance3.cnpj() == '85.901.702/0001-33'
    assert instance4.cnpj() == '47.933.824/0001-91'
    assert instance5.cnpj() == '87.121.660/0001-28'

    assert instance1.cnpj(with_mask=False)

# Generated at 2022-06-12 01:23:38.879163
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_cnpj = BrazilSpecProvider()
    cnpj = brazil_cnpj.cnpj()
    assert len(cnpj) == 18
    cnpj = cnpj.replace('.', '').replace('-', '').replace('/', '')
    assert len(cnpj) == 14



# Generated at 2022-06-12 01:23:41.097093
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    testes = ['59.992.335/0001-11']

    for i in testes:
        print(i + ' -> ' + BrazilSpecProvider().cnpj(False))


# Generated at 2022-06-12 01:23:43.145160
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    instance = BrazilSpecProvider()
    assert len(instance.cpf()) == 14
    assert instance.cpf(with_mask=False) == '93564995554'
