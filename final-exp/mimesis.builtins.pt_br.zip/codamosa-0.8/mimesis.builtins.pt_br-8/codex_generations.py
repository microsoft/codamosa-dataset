

# Generated at 2022-06-12 01:13:57.112904
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.generic import Generic
    from mimesis.providers.person import Person

    g = Generic('pt-br')
    p = Person('pt-br')

    cpf = p.cpf(with_mask=True)
    cpf2 = p.cpf(with_mask=False)
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert cpf.count(' ') == 0
    assert g.digits(cpf) == cpf2
    assert len(g.digits(cpf)) == 11


# Generated at 2022-06-12 01:14:02.230962
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    for i in range(100):
        assert len(b.cnpj(False)) == 14
        assert isinstance(b.cnpj(False), str)
        assert isinstance(b.cnpj(True), str)
        assert len(b.cnpj(True)) == 18


# Generated at 2022-06-12 01:14:07.306293
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test = BrazilSpecProvider()
    assert test.cpf() == '006.162.698-45'
    assert test.cpf(with_mask=False) == '00216269845'


# Generated at 2022-06-12 01:14:13.988871
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    cpf_random_1 = brazil_spec_provider.cpf()
    assert len(cpf_random_1) == 14
    assert len(brazil_spec_provider.cpf(with_mask=False)) == 11

    brazil_spec_provider = BrazilSpecProvider()
    cpf_random_2 = brazil_spec_provider.cpf()
    assert cpf_random_1 != cpf_random_2



# Generated at 2022-06-12 01:14:15.651765
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert b.cnpj() == "60.632.937/0001-00"

# Generated at 2022-06-12 01:14:18.970149
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    testProvider = BrazilSpecProvider()
    assert len(testProvider.cpf()) == 14
    assert len(testProvider.cpf(with_mask=False)) == 11


# Generated at 2022-06-12 01:14:22.379948
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert b.cpf() == '937.101.360-64'
    assert b.cpf(with_mask=False) == "93210136064"



# Generated at 2022-06-12 01:14:24.981710
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    for _ in range(1000):
        assert len(b.cnpj()) == 14


# Generated at 2022-06-12 01:14:34.452159
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_1 = BrazilSpecProvider().cpf()
    assert len(cpf_1) == 14
    assert cpf_1[3] == '.'
    assert cpf_1[7] == '.'
    assert cpf_1[11] == '-'
    assert not cpf_1[12:].isdigit()
    assert cpf_1[:12].isdigit()

    cpf_2 = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf_2) == 11
    assert cpf_2[12] == '-'
    assert not cpf_2[12:].isdigit()
    assert cpf_2[:12].isdigit()


# Generated at 2022-06-12 01:14:40.833186
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    prov = BrazilSpecProvider('pt-br')
    prov.seed(1)
    assert prov.cnpj() == '77.732.230/0001-70'
    prov.seed(2)
    assert prov.cnpj(with_mask=False) == '7773223000170'

# Generated at 2022-06-12 01:14:55.903480
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert b.cnpj(with_mask=False) == b.cnpj(with_mask=True)

# Generated at 2022-06-12 01:15:03.814063
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import unittest
    import re

    class TestBrazilSpecProvider_cnpj(unittest.TestCase):
        def setUp(self):
            self.cnpjRegex = re.compile(r'\d\d\.\d\d\d\.\d\d\d\/\d\d\d\d-\d\d')

        def test_BrazilSpecProvider_cnpj(self):
            for i in range(1000):
                cnpj = BrazilSpecProvider().cnpj()
                if self.cnpjRegex.match(cnpj):
                    print(cnpj)

# Generated at 2022-06-12 01:15:08.430371
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj in BrazilSpecProvider."""
    brazileiro = BrazilSpecProvider()
    cnpj = brazileiro.cnpj()
    assert(len(cnpj) == 14)


# Generated at 2022-06-12 01:15:11.142667
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    print(brazil_spec_provider.cpf(with_mask=True))


# Generated at 2022-06-12 01:15:13.481961
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    a = BrazilSpecProvider()
    result = a.cnpj(False)
    print("CNPJ: "+str(result))
    assert len(result) == 14


# Generated at 2022-06-12 01:15:16.646802
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert len(provider.cnpj(True)) == 18
    assert len(provider.cnpj(False)) == 14



# Generated at 2022-06-12 01:15:20.002922
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(False) == '90823619056'
    assert BrazilSpecProvider().cpf(True) == '908.236.190-56'


# Generated at 2022-06-12 01:15:23.801535
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test BrazilSpecProvider.cpf"""
    brazil_provider = BrazilSpecProvider(seed=42)
    cpf = brazil_provider.cpf()
    assert cpf == '724.790.946-80'


# Generated at 2022-06-12 01:15:26.208793
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj()


# Generated at 2022-06-12 01:15:28.371230
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:15:57.291552
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test to check if method cnpj of class BrazilSpecProvider is working.

    :returns: None.
    """
    cnpj = BrazilSpecProvider().cnpj(with_mask=True)

    print(cnpj)
    assert cnpj is not None


# Generated at 2022-06-12 01:16:02.057494
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj for class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj()) == 18
    assert len(brazil_spec_provider.cnpj(with_mask=False)) == 14


# Generated at 2022-06-12 01:16:03.914921
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-12 01:16:06.228752
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert(isinstance(brazil.cnpj(), str))
    assert(isinstance(brazil.cnpj(False), str))


# Generated at 2022-06-12 01:16:10.366214
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    random = BrazilSpecProvider(seed=42)
    assert random.cnpj() == '28.659.703/0001-83'

# Generated at 2022-06-12 01:16:12.954130
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    prov = BrazilSpecProvider()
    assert prov.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-12 01:16:14.249830
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(with_mask=False) != '00000000000'


# Generated at 2022-06-12 01:16:24.099974
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test with mask
    number = BrazilSpecProvider().cnpj()
    assert len(number) == 18
    assert number[2] == '.'
    assert number[6] == '.'
    assert number[10] == '/'
    assert number[15] == '-'

    # Test without mask
    number = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(number) == 14

    # Test if mask is not valid
    with_mask = 'a'
    BrazilSpecProvider().cnpj(with_mask)


# Generated at 2022-06-12 01:16:31.151949
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    locale = 'pt-br'
    # Create a BrazilSpecProvider object and some values
    obj = BrazilSpecProvider(seed=None)
    test_cnpj = '77531677000143'
    # Invoke the cnpj method of BrazilSpecProvider
    res = obj.cnpj(with_mask=False)
    # Check the result
    assert isinstance(res, str)
    assert res == test_cnpj

# Generated at 2022-06-12 01:16:35.228981
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bz = BrazilSpecProvider()
    res = bz.cnpj()
    assert res[2] == '.'
    assert res[6] == '.'
    assert res[10] == '/'
    assert res[15] == '-'

# Generated at 2022-06-12 01:17:41.389515
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.schema import Field
    from mimesis.enums import FieldName
    bs = BrazilSpecProvider()
    person = {
        FieldName.NAME: 'Test',
        FieldName.SURNAME: 'CNPJ',
        FieldName.CNPJ: Field('cnpj'),
    }
    data = bs.create(person)
    assert len(data[FieldName.CNPJ]) == 18

# Generated at 2022-06-12 01:17:44.938009
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(with_mask=True) == '28.885.150/0001-77'
    assert BrazilSpecProvider().cnpj(with_mask=False) == '28885150000177'

# Generated at 2022-06-12 01:17:48.114944
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    my_cnpj = BrazilSpecProvider()
    assert my_cnpj.cnpj().replace(".","").replace("/","").replace("-","") == my_cnpj.cnpj(False)


# Generated at 2022-06-12 01:17:50.789434
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print(BrazilSpecProvider().cpf())


# Generated at 2022-06-12 01:17:54.325279
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    s = b.cpf()
    assert len(s) == 14
    assert s[3] == '.'
    assert s[7] == '.'
    assert s[11] == '-'


# Generated at 2022-06-12 01:18:00.273775
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider

    brasil = BrazilSpecProvider()
    cnpj = brasil.cnpj()

    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-12 01:18:04.269452
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    sut = BrazilSpecProvider()
    cnpj = sut.cnpj()
    assert len(cnpj) == 18 and isinstance(cnpj, str)


# Generated at 2022-06-12 01:18:14.873875
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    result = bsp.cnpj()
    assert '.' in result
    assert '-' in result
    assert result[0] not in '-.'
    assert result[-1] not in '-.'
    assert result[2] not in '-.'
    assert result[-4] not in '-.'
    assert result[6] not in '-.'
    assert result[-7] not in '-.'
    assert result[10] not in '-.'
    assert result[-12] not in '-.'
    assert result[14] not in '-.'
    assert len(result) == 18


# Generated at 2022-06-12 01:18:16.758662
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    assert isinstance(br.cpf(), str)



# Generated at 2022-06-12 01:18:20.587514
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Code under test
    provider = BrazilSpecProvider()
    # Test
    assert provider.cpf(with_mask=False)

    # Code under test
    provider = BrazilSpecProvider()
    # Test
    assert provider.cpf(with_mask=True)


# Generated at 2022-06-12 01:20:57.219866
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    import re
    from mimesis.enums import Gender

    bp = BrazilSpecProvider(Gender.MALE)
    assert len(re.findall('[\d]', bp.cnpj())) == 14
    assert type(bp.cnpj()) == str


# Generated at 2022-06-12 01:21:02.006546
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    assert len(obj.cpf()) == 14
    with_mask = obj.cpf(with_mask=True)
    assert len(with_mask) == 14
    assert with_mask[3] == '.'
    assert with_mask[7] == '.'
    assert with_mask[11] == '-'


# Generated at 2022-06-12 01:21:04.138982
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for BrazilSpecProvider's method cpf"""
    provider = BrazilSpecProvider()
    assert provider.cpf() == "001.137.297-40"

# Generated at 2022-06-12 01:21:06.464159
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for _ in range(100):
        print(BrazilSpecProvider().cnpj(with_mask=False))


# Generated at 2022-06-12 01:21:10.955393
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Tests that the function cnpj returns different values from 1 to 100."""
    random_list = []
    provider = BrazilSpecProvider()
    for i in range(0, 1000):
        cnpj = provider.cnpj()
        random_list.append(cnpj)
    assert len(random_list) == len(set(random_list))

# Generated at 2022-06-12 01:21:14.056613
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test setup
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()

    # Test
    assert(len(cnpj) == 18)


# Generated at 2022-06-12 01:21:16.003455
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    mimesis_ptbr = BrazilSpecProvider()
    print(mimesis_ptbr.cnpj())


# Generated at 2022-06-12 01:21:19.412981
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    b = BrazilSpecProvider()
    x = b.cpf()
    assert x == '001.137.297-40'


# Generated at 2022-06-12 01:21:27.724756
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import unittest
    import re

    class TestBrazilCPF(unittest.TestCase):
        """TestBrazilCPF."""

        def setUp(self):
            """Test setup."""
            self.provider = BrazilSpecProvider()

        def test_cpf(self):
            """Test method cpf of class BrazilSpecProvider."""
            cpf = self.provider.cpf()
            self.assertNotEqual(cpf[-2:], '00')
            self.assertRegex(cpf, r'\d{3}\.\d{3}\.\d{3}-\d{2}')
            valid_cpf = re.compile('[0-9]{3}.[0-9]{3}.[0-9]{3}-[0-9]{2}')
           

# Generated at 2022-06-12 01:21:37.305875
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(with_mask=True)
    splitted_cnpj = cnpj.split('.')
    
    
    def verify_cnpj(cnpj):
        """Verify if the CNPJ is correct.
        """
        cnpj_list = [int(digit) for digit in cnpj]