

# Generated at 2022-06-12 01:14:05.316625
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj() of class BrazilSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pt-br')
    person.seed(15)
    person_with_mask = person.cnpj(with_mask=True)
    assert len(person_with_mask) == 18
    person_without_mask = person.cnpj(with_mask=False)
    assert len(person_without_mask) == 14

# Generated at 2022-06-12 01:14:09.642143
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert(len(brazil.cpf(with_mask=False)) == 11)
    assert(len(brazil.cpf(with_mask=True)) == 14)


# Generated at 2022-06-12 01:14:15.337199
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    for _ in range(10):
        cpf = brazil_provider.cpf(with_mask=True)
        assert len(cpf) == 14
        assert '.' in cpf
        assert '-' in cpf
        assert ' ' not in cpf

    cpf = brazil_provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert '.' not in cpf
    assert '-' not in cpf
    assert ' ' not in cpf


# Generated at 2022-06-12 01:14:17.950395
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf[3] == cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-12 01:14:24.333522
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # instantiate class
    class_instance = BrazilSpecProvider(seed = "123")
    # call method
    result = class_instance.cpf()
    # ensure result is not None
    assert result is not None
    # ensure result contains only digits and '.'
    assert all(char.isdigit() or char == '.' for char in result)


# Generated at 2022-06-12 01:14:26.353729
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '577.892.695-87'

# Generated at 2022-06-12 01:14:35.371534
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    result = obj.cpf()
    expected = '###.###.###-##'
    assert len(result) == 14
    assert isinstance(result, str)
    assert result.count('.') == 2
    assert result.count('-') == 1
    assert True if result[3] == '.' else False
    assert True if result[7] == '.' else False
    assert True if result[11] == '-' else False

    brazil_spec_provider = BrazilSpecProvider()
    result = brazil_spec_provider.cpf(with_mask=False)
    assert len(result) == 11
    assert isinstance(result, str)

    brazil_spec_provider = BrazilSpecProvider()

# Generated at 2022-06-12 01:14:39.702406
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # call method
    br_provider = BrazilSpecProvider()
    cnpj = br_provider.cnpj()

    # Check if its a CNPJ
    assert len(cnpj) == 14


# Generated at 2022-06-12 01:14:44.773516
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Arrange
    # Act
    brazil_provider = BrazilSpecProvider()
    actual = brazil_provider.cnpj()

    # Assert
    assert isinstance(actual, str)
    assert '.' in actual
    assert '/' in actual
    assert '-' in actual
    assert 14 == len(actual)


# Generated at 2022-06-12 01:14:47.542386
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    r = BrazilSpecProvider(seed=2)
    assert r.cpf() == '877.616.978-41'


# Generated at 2022-06-12 01:15:06.070987
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf_one = provider.cpf()
    print(cpf_one)
    cpf_two = provider.cpf(with_mask=False)
    print(cpf_two)
    assert len(cpf_one) == 14
    assert len(cpf_two) == 11


# Generated at 2022-06-12 01:15:10.678507
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilSpecProvider = BrazilSpecProvider()
    assert brazilSpecProvider.cnpj() == "98.337.624/0001-35"
    assert brazilSpecProvider.cnpj(with_mask=False) == "98337624000135"


# Generated at 2022-06-12 01:15:16.143011
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)
    cnpj_without_mask = provider.cnpj(with_mask=False)
    assert len(cnpj_without_mask) == 14
    assert isinstance(cnpj_without_mask, str)

# Generated at 2022-06-12 01:15:21.916563
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert len(result) == 14
    assert result[3] == '.'
    assert result[7] == '.'
    assert result[11] == '-'
    assert int(result[0]) >= 0
    assert int(result[13]) <= 9
    assert int(result[0]) <= 9
    assert int(result[13]) >= 0


# Generated at 2022-06-12 01:15:23.728049
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert(len(cnpj) == 18)

# Generated at 2022-06-12 01:15:28.533567
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import random
    b = BrazilSpecProvider()
    b.random = random.Random(3)
    cpf = b.cpf()

    assert cpf == '071.735.931-84'


# Generated at 2022-06-12 01:15:31.239751
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    s = BrazilSpecProvider()
    assert s.cpf()
    assert type(s.cpf()) == str
    assert len(s.cpf()) == 14



# Generated at 2022-06-12 01:15:32.908256
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf.__len__() == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'

# Generated at 2022-06-12 01:15:39.760603
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf_gen = brazil.cpf()
    cpf_list = cpf_gen.split('-')
    cpf_tuple = tuple(cpf_list)
    # Check that the format is correct
    assert (cpf_tuple[0] == '###.###.###')
    # Check that the digit is correct
    assert len(cpf_tuple[1]) == 2

# Generated at 2022-06-12 01:15:44.511709
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider(seed=42)
    assert brazil_provider.cpf() == '567.740.496-32'


# Generated at 2022-06-12 01:16:16.173636
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf(with_mask=False)
    assert len(cpf) == 11


# Generated at 2022-06-12 01:16:18.485541
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    a = BrazilSpecProvider()
    assert a.cnpj() == '34.822.436/0001-30'

# Generated at 2022-06-12 01:16:26.072021
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    Unit test for method cnpj of class BrazilSpecProvider
    """
    # Without mask
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(False)
    assert len(cnpj) == 14, "Length of cnpj must be 14"

    # With mask
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(True)
    assert len(cnpj) == 18, "Length of cnpj must be 18"


# Generated at 2022-06-12 01:16:29.472954
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Function for testing cpf method of class BrazilSpecProvider."""
    
    BrazilSpecProvider().cpf()


# Generated at 2022-06-12 01:16:37.020200
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """."""
    cnpj_1 = BrazilSpecProvider().cnpj(with_mask=True)
    cnpj_2 = BrazilSpecProvider().cnpj(with_mask=True)
    cnpj_3 = BrazilSpecProvider().cnpj(with_mask=True)
    print(cnpj_1, cnpj_2, cnpj_3)

# Generated at 2022-06-12 01:16:38.950743
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(17)
    assert provider.cnpj() == '36.623.307/0001-08'


# Generated at 2022-06-12 01:16:43.365724
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider with Brazilian cpf."""
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert len(cpf) == 14
    assert int(cpf[:3]) > 0
    assert int(cpf[3:6]) > 0
    assert int(cpf[6:9]) > 0
    assert int(cpf[9:]) > 0
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'



# Generated at 2022-06-12 01:16:48.410972
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider()
    a = cpf.cpf()
    assert len(a) == 14
    b = cpf.cpf(with_mask=False)
    assert len(b) == 11


# Generated at 2022-06-12 01:16:51.791386
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    g = BrazilSpecProvider()
    f = g.cpf()
    print(f)
    assert len(f) == 14

# Generated at 2022-06-12 01:16:55.256624
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf()) == 14


# Generated at 2022-06-12 01:18:09.475820
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-12 01:18:17.542703
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_list = []
    for i in range(100):
        cnpj = BrazilSpecProvider().cnpj()
        cnpj_list.append(cnpj)
        assert len(cnpj) == 18
        assert len(set(cnpj.replace('.', '').replace('-', ''))) == len(cnpj.replace('.', '').replace('-', ''))

# Generated at 2022-06-12 01:18:23.363498
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BSP = BrazilSpecProvider()
    CPF = BSP.cpf(True)
    a, b, c, d, e, f, g, h, i, j, k, l = [False]*12
    n = 0
    while n < 12:
        if CPF[n] == '0':
            a = True
        if CPF[n] == '1':
            b = True
        if CPF[n] == '2':
            c = True
        if CPF[n] == '3':
            d = True
        if CPF[n] == '4':
            e = True
        if CPF[n] == '5':
            f = True
        if CPF[n] == '6':
            g = True

# Generated at 2022-06-12 01:18:28.295085
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert cpf is not None

    cpf1 = brazil_provider.cpf(with_mask=True)
    assert cpf1 is not None


# Generated at 2022-06-12 01:18:31.263242
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_cnpj = BrazilSpecProvider()
    assert len(brazil_cnpj.cnpj()) == 18
    assert brazil_cnpj.cnpj(True) == '90.235.060/0001-34'


# Generated at 2022-06-12 01:18:35.069371
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask = True) == '77.732.230/0001-70'
    assert provider.cnpj(with_mask = False) == '77732240000017'


# Generated at 2022-06-12 01:18:36.170983
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.generated import BrazilSpecProvider as CP
    CP().cnpj()

# Generated at 2022-06-12 01:18:41.276461
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    provider = BrazilSpecProvider()
    for _ in range(3):
        print('CPF: ', provider.cpf())
    print('CPF: ', provider.cpf(True))



# Generated at 2022-06-12 01:18:44.586910
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(None)
    cpf = provider.cpf(with_mask=False)

    assert (len(cpf) == 11)
    assert (cpf.isdigit())


# Generated at 2022-06-12 01:18:47.680285
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    cnpj_provider = BrazilSpecProvider()
    cnpj = cnpj_provider.cnpj()
    assert "-" in cnpj


# Generated at 2022-06-12 01:21:44.315949
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()
    for i in range(0, 10):
        cpf = bp.cpf()
        assert len(cpf) == 14
        assert cpf[3] == '.'
        assert cpf[7] == '.'
        assert cpf[11] == '-'


# Generated at 2022-06-12 01:21:55.590324
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider
    brazil_sp = BrazilSpecProvider()
    for _ in range(1000):
        cnpj = brazil_sp.cnpj()
        numones = lambda s: sum(map(lambda c: c=='1', s))
        assert numones(cnpj) == 2
        assert cnpj[2] != cnpj[3]
        assert cnpj[3] != cnpj[4]
        assert cnpj[4] != cnpj[5]
        assert cnpj[5] != cnpj[6]
        assert cnpj[6] != cnpj[7]
        assert cnpj[7] != cnpj[8]
        assert cnpj[8] != cnpj[9]
        assert cnpj[9]

# Generated at 2022-06-12 01:21:58.981225
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider(seed=143)
    cpf = brazil_provider.cpf(with_mask=False)
    assert cpf == "49365255580"


# Generated at 2022-06-12 01:22:02.787280
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Should return a valid cnpj."""
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-12 01:22:06.249348
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider."""
    b = BrazilSpecProvider()

    actual = b.cnpj(with_mask=True)
    expected = b.cnpj(with_mask=True)
    assert len(actual) == 18
    assert actual != expected

# Generated at 2022-06-12 01:22:09.538776
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf(with_mask=False)
    assert len(result) == 11
    assert result == provider.cpf(with_mask=False)
    assert result != provider.cpf(with_mask=False)


# Generated at 2022-06-12 01:22:18.362503
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Check if the CNPJ number generated by the BrazilSpecProvider is valid
    from cnpj import cnpj_valid
    import re
    bspobj = BrazilSpecProvider()
    bspobj.set_seed(4321)
    cnpj_number = bspobj.cnpj()
    assert isinstance(cnpj_number, str)
    print("CNPJ generated: " + cnpj_number)  # print CNPJ generated

    # Extract numbers from CNPJ number
    regex = re.compile(r'[1-9]\d{13}')
    cnpj_number = regex.findall(cnpj_number)
    cnpj_number = cnpj_number[0].split()
    cnpj_number = int(''.join(cnpj_number))



# Generated at 2022-06-12 01:22:19.760391
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_total = 100
    for i in range(cnpj_total):
        print(BrazilSpecProvider().cnpj())


# Generated at 2022-06-12 01:22:25.143465
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.enums import Gender

    brazil_provider = BrazilSpecProvider()
    misc = Misc('pt-br')
    person = Person('pt-br')

    for _ in range(1000):
        cpf = brazil_provider.cpf(with_mask=False)
        assert len(cpf) == 11
        assert cpf.isdecimal()

        masked_cpf = brazil_provider.cpf(with_mask=True)
        assert len(masked_cpf) == 14
        assert masked_cpf.replace('.', '').replace('-', '').isdecimal()

        gender = person.gender(full=True)
        gender_code = misc.gender_code

# Generated at 2022-06-12 01:22:32.817031
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.providers.helpers import re_pattern
    cnpj_pattern = re_pattern('cnpj')
    cnpj = BrazilSpecProvider()
    result = cnpj.cnpj(with_mask = True)
    assert isinstance(result,str)
    assert result[12] == '-'
    assert result[12:14] == '-1' #always with last digits 1
    assert re_pattern('cnpj').match(result)
