

# Generated at 2022-06-12 01:14:01.928985
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test the method with the format of the Brazilian document
    
    from mimesis import BrazilSpecProvider
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    for i in cpf:
        assert i.isdigit() or i == '.' or i == '-', "The generated CPF has wrong characters"
    assert len(cpf) == 14, "Length of the generated CPF is wrong"
    assert cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-', "The format of the generated CPF is wrong"
    
    # Test cpf without format
    cpf = brazil_provider.cpf(False)

# Generated at 2022-06-12 01:14:04.593096
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    data = brazil.cnpj()
    print(data)


# Generated at 2022-06-12 01:14:10.431757
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider's method cpf."""
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf(with_mask=False)
    assert len(cpf) == 11
    cpf_maksed = bsp.cpf(with_mask=True)
    assert len(cpf_maksed) == 14

# Generated at 2022-06-12 01:14:12.462982
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14



# Generated at 2022-06-12 01:14:14.857570
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj())==18

# Generated at 2022-06-12 01:14:18.794766
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    x = BrazilSpecProvider(seed=1)
    assert x.cnpj() == '77.732.230/0001-70'
    assert x.cnpj(False) == '77732230000170'
    assert x.cnpj() == '77.732.230/0001-70'
    assert x.cnpj(False) == '77732230000170'


# Generated at 2022-06-12 01:14:21.440222
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    print( "BrazilSpecProvider_cnpj: " + b.cnpj() )


# Generated at 2022-06-12 01:14:30.265595
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Initializes a BrazilSpecProvider with a fixed seed
    brazil_provider = BrazilSpecProvider(seed=12345)

    # Uses cnpj method of BrazilSpecProvider class
    cnpj = brazil_provider.cnpj()
    cnpj2 = brazil_provider.cnpj(with_mask=False)

    # Tests if cnpj is the first cnpj generated with the fixed seed
    assert cnpj == '12.622.371/0001-26'
    assert cnpj2 == '12622371000126'

# Generated at 2022-06-12 01:14:33.457763
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(cnpj) == 14 and cnpj.isdigit()



# Generated at 2022-06-12 01:14:37.867014
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert cpf == "039.931.926-62"

# Generated at 2022-06-12 01:14:57.872084
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf of BrazilSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pt-br', seed=42)

    person.cpf(with_mask=True)
    assert person.cpf(False) == "08451098793"

    person.gender = Gender.MALE
    person.cpf()
    person.cpf(True)

# Generated at 2022-06-12 01:15:05.537831
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11

    cpf = provider.cpf(with_mask=True)
    assert len(cpf) == 14
    assert cpf[3] == cpf[7] == '.'
    assert cpf[11] == '-'

    cpfs = [provider.cpf(with_mask=False) for _ in range(100)]

    assert len(set(cpfs)) == 100



# Generated at 2022-06-12 01:15:12.152499
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create provider instance
    brazil_spec_provider = BrazilSpecProvider()

    # Create a cnpj without mask
    cnpj = brazil_spec_provider.cnpj(with_mask=False)

    # Assert the cnpj without mask has a valid number of digits
    assert len(cnpj) == 14

    # Create a cnpj with mask
    cnpj = brazil_spec_provider.cnpj(with_mask=True)

    # Assert the cpnj with mask has a valid number of digits
    assert len(cnpj) == 18

    # Create a cnpj with mask
    cnpj = brazil_spec_provider.cnpj(with_mask=True)

    # Assert the cpnj with mask has a valid format

# Generated at 2022-06-12 01:15:21.879262
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for BrazilSpecProvider class."""
    from mimesis.enums import Gender
    from mimesis.builtins.brazil import BrazilSpecProvider
    from mimesis.providers.datetime import Datetime

    bsp = BrazilSpecProvider()

    cnpj1 = bsp.cnpj()
    assert len(cnpj1) == len('00.000.000/0001-91')
    assert cnpj1[2] == '.'
    assert cnpj1[6] == '.'
    assert cnpj1[10] == '/'
    assert cnpj1[15] == '-'

    cnpj2 = bsp.cnpj(with_mask=False)
    assert len(cnpj2) == 14

    class Person:
        """Fake class."""

        age = Dat

# Generated at 2022-06-12 01:15:25.135320
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    # Expected results
    expected = '081.824.965-89'

    # Object for the test class
    obj_test = BrazilSpecProvider()

    # Actual result
    assert obj_test.cpf() == expected


# Generated at 2022-06-12 01:15:27.534321
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cpf = BrazilSpecProvider.cnpj(False)
    assert len(cpf) == 14

# Generated at 2022-06-12 01:15:37.397475
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    # Test 1
    cpf = provider.cpf()
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert len(cpf) == 14
    # Test 2
    cpf = provider.cpf(with_mask=False)
    assert '.' not in cpf
    assert '-' not in cpf
    assert len(cpf) == 11
    assert cpf.isdigit()
    # Test 3
    cpf = provider.cpf()
    assert '.' in cpf
    assert '-' in cpf
    assert len(cpf) == 14


# Generated at 2022-06-12 01:15:40.498265
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf1 = BrazilSpecProvider().cpf()
    assert len(cpf1) == 14

    cpf2 = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf2) == 11




# Generated at 2022-06-12 01:15:51.403581
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create a BrazilSpecProvider with the seed 42
    provider = BrazilSpecProvider(seed=42)
    # Create a list of expected results based on the seed 42

# Generated at 2022-06-12 01:15:54.721474
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br_provider = BrazilSpecProvider(seed=1)
    assert br_provider.cnpj() == "77.732.230/0001-70"


# Generated at 2022-06-12 01:16:27.369968
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '001.137.297-40'


# Generated at 2022-06-12 01:16:33.052026
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert(cpf[3] == '.')
    assert(cpf[7] == '.')
    assert(cpf[11] == '-')
    assert(len(cpf) == 14)


# Generated at 2022-06-12 01:16:34.313828
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    # Testing with default parameters
    assert BrazilSpecProvider().cnpj()


# Generated at 2022-06-12 01:16:42.657413
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # check if the cnpj has a mask and the size is 18
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

    # check if the cnpj has not a mask and the size is 14
    cnpj = provider.cnpj(False)
    assert len(cnpj) == 14

# Generated at 2022-06-12 01:16:51.614971
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.brazil import BrazilSpecProvider
    brazil_provider = BrazilSpecProvider()
    # test 1
    print('test 1: ', brazil_provider.cnpj(with_mask= True))
    # test 2
    print('test 2: ', brazil_provider.cnpj(with_mask= True))
    # test 3
    print('test 3: ', brazil_provider.cnpj(with_mask= True))


# Generated at 2022-06-12 01:16:57.784027
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    
    for i in range(10):
        with_mask = brazil_provider.random.randint(0, 1)
        assert 10 < len(brazil_provider.cpf(with_mask)) < 14


# Generated at 2022-06-12 01:17:05.445508
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    res = bsp.cnpj(with_mask=False)
    assert(len(res) == 14)
    assert(res.isdigit())
    assert(int(res[0]) >= 2)
    assert(int(res[1]) >= 0)
    assert(int(res[2]) >= 2)
    assert(int(res[3]) >= 0)
    assert(int(res[4]) >= 0)
    assert(int(res[5]) >= 0)
    assert(int(res[6]) >= 0)
    assert(int(res[7]) >= 0)
    assert(int(res[8]) >= 0)
    assert(int(res[9]) >= 0)
    assert(int(res[10]) >= 0)

# Generated at 2022-06-12 01:17:12.548175
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == '935.047.946-64'
    assert bsp.cpf() == '644.268.188-47'
    assert bsp.cpf() == '366.874.342-78'
    assert bsp.cpf() == '821.356.381-35'
    assert bsp.cpf() == '543.671.126-60'
    assert bsp.cpf() == '093.616.890-58'
    assert bsp.cpf() == '560.612.898-06'
    assert bsp.cpf() == '849.380.457-94'
    assert bsp.cpf() == '935.430.719-68'
    assert bsp.cpf()

# Generated at 2022-06-12 01:17:15.286268
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender
    assert BrazilSpecProvider(gender=Gender.MALE).cnpj() == '00.000.000/0001-91'

# Generated at 2022-06-12 01:17:20.237536
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """ Test BrazilSpecProvider cpf."""
    provider = BrazilSpecProvider()
    assert provider.provider_data.cpf() == "165.967.837-56"
    assert provider.provider_data.cpf(False) == "16596783765"


# Generated at 2022-06-12 01:18:38.701691
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    provider = BrazilSpecProvider()

    cpf_1 = provider.cpf()
    assert cpf_1 is not None
    assert cpf_1 != '000.000.000-00'
    assert len(cpf_1) == 14

    assert provider.cpf(with_mask=False) != '000000000'
    assert provider.cpf(with_mask=True) != '000000000'

    cpf_2 = provider.cpf(seed='test')
    assert cpf_1 == cpf_2
    assert cpf_2 != '000.000.000-00'
    assert cpf_2 != '123.123.123-12'
    assert len(cpf_2) == 14


# Generated at 2022-06-12 01:18:41.741586
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    mimesis_BrazilSpecProvider = BrazilSpecProvider('Seed')
    assert len(mimesis_BrazilSpecProvider.cnpj()) == 18


# Generated at 2022-06-12 01:18:45.463867
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert brazil.cpf(with_mask=False) == '0011375958'
    assert brazil.cpf(with_mask=True) == '001.137.595-8'


# Generated at 2022-06-12 01:18:48.805979
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider
    cpf = provider().cpf(with_mask=False)

    assert len(cpf) == 11
    for digit in cpf:
        assert digit in list(map(str, range(10)))

    # Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-12 01:18:54.926251
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert bsp.cnpj(with_mask=False) == '07318078000183'
    assert bsp.cnpj(with_mask=True) == '07.318.078/0001-83'


# Generated at 2022-06-12 01:19:00.816185
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()

    indexs_to_check = {
        "first_digit": 2,
        "second_digit": 5,
        "third_digit": 8,
        "fourth_digit": 12
    }
    for key, index in indexs_to_check.items():
        assert cnpj[index] == ".", "The " + key + " digit is not '.'"

    wrong_cnpj_mask = False
    if cnpj[13] != "-" or cnpj[17] != "/":
        wrong_cnpj_mask = True
    assert not wrong_cnpj_mask, "CNPJ with the wrong mask."

# Generated at 2022-06-12 01:19:03.365284
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test."""
    assert BrazilSpecProvider().cpf() in ['123.456.789-10', '123.456.789-09']


# Generated at 2022-06-12 01:19:06.627593
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert len(brazil.cnpj(with_mask=False)) == 14


# Generated at 2022-06-12 01:19:08.989769
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    cnpj_com_mascara = '77.732.230/0001-70'
    cnpj_sem_mascara = '77732230000170'
    assert cnpj_com_mascara == BrazilSpecProvider().cnpj()
    assert cnpj_sem_mascara == BrazilSpecProvider().cnpj(with_mask=False)

# Generated at 2022-06-12 01:19:13.136211
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print(BrazilSpecProvider().cnpj())
    print(BrazilSpecProvider().cnpj())
    print(BrazilSpecProvider().cnpj())


# Generated at 2022-06-12 01:22:21.294574
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    print(cnpj)


# Generated at 2022-06-12 01:22:23.241696
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    assert(len(brazil_provider.cpf()) == 14)


# Generated at 2022-06-12 01:22:24.218243
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider() 
    A = provider.cnpj()
    print(A)

# Generated at 2022-06-12 01:22:27.030322
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1


# Generated at 2022-06-12 01:22:28.671087
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data = BrazilSpecProvider().cpf()
    # print(data)
    assert len(data) == 14


# Generated at 2022-06-12 01:22:37.323348
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import SpecialChar
    provider = BrazilSpecProvider()
    cnpj_1 = provider.cnpj(with_mask=True)
    cnpj_2 = provider.cnpj(with_mask=False)
    assert len(cnpj_1)==18
    assert len(cnpj_2)==14
    assert cnpj_1.count(SpecialChar.DOT)==2
    assert cnpj_1.count(SpecialChar.SLASH)==1
    assert cnpj_1.count(SpecialChar.HYPHEN)==1
    assert cnpj_2.count(SpecialChar.SLASH)==1
    assert cnpj_2.count(SpecialChar.HYPHEN)==1
    assert cnpj_1[2:3]==cnpj

# Generated at 2022-06-12 01:22:39.906322
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == "95.755.641/0001-22"



# Generated at 2022-06-12 01:22:50.154081
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    # Test cnpj with w/o mask
    cnpj = provider.cnpj()
    print("cnpj: ", cnpj)
    assert type(cnpj) == str
    assert len(cnpj) == 14

    cnpj = provider.cnpj(with_mask = False)
    print("cnpj: ", cnpj)
    assert type(cnpj) == str
    assert len(cnpj) == 14


# Generated at 2022-06-12 01:22:52.736070
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from unittest import TestCase
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    t = TestCase()
    t.assertEqual(BrazilSpecProvider().cpf(), '001.137.297-40')


# Generated at 2022-06-12 01:22:58.974417
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    cnpj_first_verifier = int(cnpj[12])
    cnpj_second_verifier = int(cnpj[13])
    first_verifier = int(cnpj[12])
    second_verifier = int(cnpj[13])

    cnpj_without_verifiers = [int(i) for i in cnpj[:12]]

    # Test the first verifier
    soma = 0
    peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    for i, _ in enumerate(cnpj_without_verifiers):
        soma += peso_list[i] * cnpj_without_verifiers