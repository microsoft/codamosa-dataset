

# Generated at 2022-06-12 01:13:56.902308
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
   provider = BrazilSpecProvider()
   cpf = provider.cpf()
   assert isinstance(cpf, str)  # verifies type of cpf
   assert cpf == cpf[:3] + '.' + cpf[3:6] + '.' + cpf[6:9] + '-' + cpf[9:]
   assert len(cpf) == 14
   
   

# Generated at 2022-06-12 01:14:00.407202
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider(seed=0)
    expected = '001.137.297-40'
    actual = brazil.cpf()
    assert actual == expected



# Generated at 2022-06-12 01:14:03.546311
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert(len(cnpj) == 18)



# Generated at 2022-06-12 01:14:07.303818
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for _ in range(0,10):
        assert(False == BrazilSpecProvider.cpf('aaa'))


# Generated at 2022-06-12 01:14:09.470384
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    cpfs_set = set()
    for _ in range(1000):
        cpfs_set.add(bsp.cpf())
    assert len(cpfs_set) == 1000


# Generated at 2022-06-12 01:14:11.028562
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    a = BrazilSpecProvider()
    b = a.cnpj()
    assert len(b) == 14

# Generated at 2022-06-12 01:14:14.374245
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for _ in range(10):
        assert len(provider.cpf()) == 14
        assert len(provider.cpf(with_mask=False)) == 11
        assert len(provider.cpf(with_mask=True)) == 14



# Generated at 2022-06-12 01:14:18.513142
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf_mask = provider.cpf()
    cpf_no_mask = provider.cpf(False)
    assert cpf_mask == cpf_no_mask
    assert len(cpf_mask) == 14
    assert len(cpf_no_mask) == 11
    assert cpf_mask == '###.###.###-##'




# Generated at 2022-06-12 01:14:20.619512
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert len(b.cnpj()) == 18


# Generated at 2022-06-12 01:14:26.452426
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj with cnpj_without_mask = False."""
    print("Test method cnpj with cnpj_without_mask = False.")
    provider = BrazilSpecProvider()
    print(provider.cnpj(with_mask=False))


if __name__ == "__main__":
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-12 01:14:38.459289
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    bsp = BrazilSpecProvider(seed=42)

    # the following test is expected to fail 10% of the time
    assert bsp.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-12 01:14:44.483697
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of BrazilSpecProvider."""
    import pytest
    from mimesis.exceptions import FieldValidationError

    provider = BrazilSpecProvider()

    assert provider.cpf() is not None
    assert provider.cpf(with_mask=False) is not None

    with pytest.raises(FieldValidationError):
        provider.cpf(with_mask=0.0)


# Generated at 2022-06-12 01:14:47.542823
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    test = BrazilSpecProvider()
    for i in range(100):
        print(test.cnpj())


# Generated at 2022-06-12 01:14:59.133155
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.person import Person
    from mimesis.providers.internet import Internet
    from mimesis.providers.misc import Misc
    from mimesis.providers.geo import Geo
    from mimesis.providers.banking import Banking
    from mimesis.providers.phone import Phone

    seed = 'UFO'
    provider = BrazilSpecProvider(seed)
    cpf_pattern = re.compile(r'[0-9]{3}[.][0-9]{3}[.][0-9]{3}[-][0-9]{2}')

    # Generating random cpf
    cpf = provider.cpf()
    assert re.match

# Generated at 2022-06-12 01:15:02.125765
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    print(provider.cpf())


# Generated at 2022-06-12 01:15:05.735192
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '02.771.400/0001-40'

# Generated at 2022-06-12 01:15:09.864971
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cpf = provider.cnpj(with_mask=False)

    assert type(cpf) == str
    assert len(cpf) == 14
    assert cpf.isdigit()



# Generated at 2022-06-12 01:15:13.855739
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    csp = BrazilSpecProvider()
    cpf = csp.cpf()
    assert len(cpf) >= (3+1+3+1+3+1+2)
    assert cpf.count('.') == 3
    assert cpf.count('-') == 1


# Generated at 2022-06-12 01:15:17.086629
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()

    len_cnpj = len(cnpj)
    assert len_cnpj == 18


# Generated at 2022-06-12 01:15:19.466068
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    assert len(br.cpf()) == 14


# Generated at 2022-06-12 01:15:35.950620
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test with mask
    with_mask_cnpj = BrazilSpecProvider().cnpj()
    assert len(with_mask_cnpj) == 18
    assert with_mask_cnpj[2] == '.'
    assert with_mask_cnpj[6] == '.'
    assert with_mask_cnpj[10] == '/'
    assert with_mask_cnpj[15] == '-'
    # Test without mask
    without_mask_cnpj = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(without_mask_cnpj) == 14


# Generated at 2022-06-12 01:15:38.842843
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf(with_mask=False)
    assert cpf != 99999999999
    assert len(cpf) == 11


# Generated at 2022-06-12 01:15:49.950369
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.brazil import BrazilSpecProvider
    from mimesis.enums import Gender

    provider = BrazilSpecProvider(seed=42)

    # Default mask
    assert provider.cnpj() == '42.215.852/0001-48'
    assert provider.cnpj(with_mask=False) == '42215852' + '000148'

    # # Test with specific mask    
    # assert provider.cnpj(mask='{{cnpj_mask}}') == '77.732.230/0001-70'
    # assert provider.cnpj(mask='{{cnpj_mask}}', with_mask=False) == '77732' + '230000170' 


# Generated at 2022-06-12 01:15:55.685917
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import os, sys
    # sys.path.insert(0, os.path.abspath('.'))
    import src.providers as prov

    b = BrazilSpecProvider()
    b.seed(1)
    result = b.cnpj()
    assert result == '49.432.875/0001-51'
    print(result)


# Generated at 2022-06-12 01:16:00.764348
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider()
    assert type(cnpj.cnpj()) == str
    assert len(cnpj.cnpj()) == 18
    assert type(cnpj.cnpj(with_mask=False)) == str
    assert len(cnpj.cnpj(with_mask=False)) == 14

# Generated at 2022-06-12 01:16:02.861641
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-12 01:16:06.481233
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    cnpj = p.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-12 01:16:15.710575
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider
    a = brazil.cpf()
    print(a)
    assert len(a) == 14
    assert a[3] == a[7] == a[11] == '.'
    assert a[12] == '-'
    assert a.count('.') == 3
    assert a.count('-') == 1
    assert a.count('0') == a.count('1') == a.count('2') == a.count('3') == \
        a.count('4') == a.count('5') == a.count('6') == a.count('7') == \
        a.count('8') == a.count('9') == 1


# Generated at 2022-06-12 01:16:21.343470
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers import BrazilSpecProvider
    from mimesis.enums import Gender
    bsp = BrazilSpecProvider(seed=1)
    print(bsp.cpf())
    # 001.137.297-40
    print(bsp.cpf(with_mask=False))
    # 00113729740

# Generated at 2022-06-12 01:16:25.566021
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    s = BrazilSpecProvider()

    assert len(s.cpf()) == 14
    assert len(s.cpf(with_mask = False)) == 11
    assert s.cpf() == "317.073.244-31"


# Generated at 2022-06-12 01:16:43.651331
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[:9].isdigit()
    assert cpf[8] == cpf[12]
    assert cpf[9] == cpf[13]


# Generated at 2022-06-12 01:16:48.359001
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    cpf = BrazilSpecProvider().cpf(False)
    assert len(cpf) == 11


# Generated at 2022-06-12 01:16:53.576526
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.data import PROVIDER_DEFAULTS
    cnpjNumber = '52.085.469/0001-36'
    provider = BrazilSpecProvider(PROVIDER_DEFAULTS['seed'])
    assert cnpjNumber == provider.cnpj(with_mask=True)


# Generated at 2022-06-12 01:17:04.114542
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    from mimesis.enums import Gender
    gender = Gender.MALE
    seed = 'QG_M0lZ4v4bW0x0_fKh'
    g = gender.value
    s = seed
    expected = '97.638.346/5636-12'
    expected_seed = 'QG_M0lZ4v4bW0x0_fKh'
    actual = BrazilSpecProvider(seed=seed).cnpj()
    actual == expected
    actual_seed = BrazilSpecProvider(seed=seed).seed
    actual_seed == expected_seed
    expected = '85.628.174/5837-21'

# Generated at 2022-06-12 01:17:06.611493
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bzp = BrazilSpecProvider()
    result = bzp.cnpj(with_mask=True)
    assert str(result)
    assert len(result) >= 14


# Generated at 2022-06-12 01:17:09.509879
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)


# Generated at 2022-06-12 01:17:11.024143
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    assert BrazilSpecProvider().cnpj(with_mask=False) == '4118665000109'

# Generated at 2022-06-12 01:17:13.597812
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from doctest import testmod
    from mimesis.builtins.brazil_provider import BrazilSpecProvider
    testmod(BrazilSpecProvider)


# Generated at 2022-06-12 01:17:18.374034
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
	seed = 0
	with_mask = True
	expect_result = '77.732.230/0001-70'
	brazil_provider = BrazilSpecProvider(seed=seed)
	result = brazil_provider.cnpj(with_mask)
	assert result == expect_result


# Generated at 2022-06-12 01:17:29.519551
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person.pt_br import Person
    from mimesis.providers.person.base import BasePerson
    from mimesis.builtins.pt_br import BrazilSpecProvider
    from mimesis.random import Random

    r = Random(seed=0)

    data = [
        ['369.037.343-00', '367.588.223-40', '125.896.732-02',
         '869.026.808-11', '387.966.918-40', '976.670.260-79',
         '895.430.652-49', '714.697.948-53', '073.607.089-72',
         '817.750.990-90'],
    ]

   

# Generated at 2022-06-12 01:18:07.146180
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf == '328.708.030-50'


# Generated at 2022-06-12 01:18:09.826160
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilProvider = BrazilSpecProvider()
    for x in range(10):
        assert len(brazilProvider.cnpj()) == 18


# Generated at 2022-06-12 01:18:11.496086
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj()


# Generated at 2022-06-12 01:18:17.823841
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    result = brazil_provider.cpf(with_mask=False)
    # Testa se o tamanho da string resultante é igual a 11
    assert len(result) == 11


# Generated at 2022-06-12 01:18:20.143117
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()

    for _ in range(5):
        print(b.cpf())


# Generated at 2022-06-12 01:18:31.193719
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person as Person_en
    from mimesis.providers.person.pt_br import Person as Person_pt_br

    seed = 123456789
    provider_en = Person_en(seed=seed)
    provider_pt_br = Person_pt_br(seed=seed)

    assert provider_en.cnpj() == provider_pt_br.cnpj()
    assert provider_en.rut() == provider_pt_br.rut()
    assert provider_en.taxpayer_identification_number() == provider_pt_br.taxpayer_identification_number()
    assert provider_en.taxpayer_identification_number_type() == provider_pt_br.taxpayer_identification_number_type()


# Generated at 2022-06-12 01:18:35.604683
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(10):
        provider = BrazilSpecProvider()
        result = provider.cpf()
        print(result)
        assert isinstance(result, str), 'O retorno não é uma string.'
        assert len(result) == 14, 'O tamanho da string não é 14.'


# Generated at 2022-06-12 01:18:37.434674
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    spec = BrazilSpecProvider()
    result = spec.cnpj()
    assert isinstance(result, str)
    assert len(result) == 18


# Generated at 2022-06-12 01:18:46.752539
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import random
    import pytest
    seed = random.randint(0, 99999)
    test1 = BrazilSpecProvider(seed=seed)
    test2 = BrazilSpecProvider(seed=seed)
    cpf1 = test1.cpf()
    cpf2 = test2.cpf()
    assert cpf1 == cpf2

    cpf1 = test1.cpf(with_mask=False)
    cpf2 = test2.cpf(with_mask=False)
    assert cpf1 == cpf2

    # Test with_mask
    with pytest.raises(TypeError):
        test1.cpf(with_mask='abc')


# Generated at 2022-06-12 01:18:48.200249
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj(with_mask=False) == "7773223000170"

# Generated at 2022-06-12 01:20:05.982591
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider(seed=1234)
    expected = bsp.cnpj(with_mask=False)
    result = "77732130000170"
    assert expected == result

# Generated at 2022-06-12 01:20:08.111282
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(100):
        brazil = BrazilSpecProvider()
        cnpj = brazil.cnpj()
        print(cnpj)

# Generated at 2022-06-12 01:20:10.628395
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert result is not None
    assert len(result) == 14
    for digit in result:
        assert digit in '0123456789.'


# Generated at 2022-06-12 01:20:17.411428
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pt-br')
    brazil = BrazilSpecProvider(seed=1)
    assert brazil.cnpj() == '00.770.020/0011-35'
    assert brazil.cnpj(with_mask=False) == '00770020000135'

# Generated at 2022-06-12 01:20:22.778703
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert cpf.count(".") == 2
    assert cpf.count("-") == 1
    assert len(cpf.replace(".", "").replace("-", "")) == 11
    # Check CPF is new
    history = [cpf]
    assert cpf != b.cpf(with_mask=True)
    for i in range(500):
        cpf = b.cpf(with_mask=True)
        assert cpf not in history
        history.append(cpf)


# Generated at 2022-06-12 01:20:24.493214
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider('test')
    cnpj = b.cnpj()
    assert cnpj == '09.107.926/0001-94'


# Generated at 2022-06-12 01:20:33.510109
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import Person

    brasil = Person ('pt-br')

    cnpj = brasil.cnpj()
    assert len (cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

    cnpj = brasil.cnpj(with_mask = False)
    assert len (cnpj) == 14
    assert cnpj[2].isdigit()
    assert cnpj[6].isdigit()
    assert cnpj[10].isdigit()
    assert cnpj[15].isdigit()




# Generated at 2022-06-12 01:20:35.534311
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    prov = BrazilSpecProvider(seed=123)
    assert prov.cpf() == '001.137.297-40'
    prov = BrazilSpecProvider(seed=None)
    assert prov.cpf() == '858.035.358-52'



# Generated at 2022-06-12 01:20:37.752134
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = BrazilSpecProvider.cpf()
    # Check if length of cpf is 11
    assert len(result) == 11


# Generated at 2022-06-12 01:20:41.315614
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[14] != '-'
    assert cpf[14] != '.'


# Generated at 2022-06-12 01:23:25.337984
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_cnpj()
    test_cnpj_with_mask()


# Generated at 2022-06-12 01:23:30.006769
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    local_seed = b'\x86\xeb\x9a\x12\xec\x98\x1b\xcf\xa2\x0b\x9d\x9c\x8c\x17\xfc\x10\x1a\x94\xd6\xa0\x9d\x9e\xd4\xea\x19\xab\x04\x8a\xe7\x1b\x9d\x8b'
    locale = BrazilSpecProvider(seed=local_seed)
    assert_equals(locale.cnpj(), '77.732.230/0001-70')
    assert_equals(locale.cnpj(), '77.732.230/0001-70')

# Generated at 2022-06-12 01:23:32.881482
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(with_mask=True) == "345.080.743-18"
    assert BrazilSpecProvider().cpf(with_mask=False) == "34508074318"
    

# Generated at 2022-06-12 01:23:40.937515
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.providers.brazil.utils import _calc_verifying_digit_cnpj

    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

    cnpj_list = list(cnpj.replace('.', '').replace('-', '').replace('/', ''))
    cnpj_list_without_dv = cnpj_list[:12]

# Generated at 2022-06-12 01:23:42.255684
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    assert bool(p.cnpj()) == True
