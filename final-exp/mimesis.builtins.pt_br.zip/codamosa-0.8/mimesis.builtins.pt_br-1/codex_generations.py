

# Generated at 2022-06-12 01:13:56.616336
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    provider = BrazilSpecProvider()
    values = [provider.cpf(with_mask=False) for _ in range(1000)]
    for value in values:
        assert re.match("^\d{11}$", value) is not None, "incorrect cpf value: "+value


# Generated at 2022-06-12 01:14:00.102428
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider.cnpj()
    if len(cnpj) != 14:
        raise Exception('Unexpected length for cnpj: {}'.format(cnpj))
    if cnpj[2] != '.' or cnpj[6] != '.' or cnpj[10] != '/' or cnpj[15] != '-':
        raise Exception('Unexpected format for cnpj: {}'.format(cnpj))


# Generated at 2022-06-12 01:14:07.166981
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for _ in range(10):
        provider = BrazilSpecProvider(seed=None)
        cpf = provider.cpf(with_mask=False)
        print(cpf)
        cpf_with_mask = provider.cpf(with_mask=True)
        print(cpf_with_mask)


# Generated at 2022-06-12 01:14:14.445662
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    provider = BrazilSpecProvider()
    def check_format(cpf):
        assert len(cpf) == 14
        assert set(cpf) <= set('0123456789.')
        assert cpf[3] == '.'
        assert cpf[7] == '.'
        assert cpf[11] == '-'
    cpf = provider.cpf()
    check_format(cpf)
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert set(cpf) <= set('0123456789')


# Generated at 2022-06-12 01:14:16.369603
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("test_BrazilSpecProvider_cnpj()")
    print("cnpj: ", BrazilSpecProvider().cnpj())


# Generated at 2022-06-12 01:14:24.636570
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the cpf method of BrazilSpecProvider."""
    seed = 'kHufIgx56VCw5NdZ'
    bsp = BrazilSpecProvider(seed=seed)
    expected_cpf = '998.522.585-72'
    assert expected_cpf == bsp.cpf(with_mask=True)
    assert expected_cpf.replace('.', '').replace('-', '') == bsp.cpf(with_mask=False)


# Generated at 2022-06-12 01:14:33.009608
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = '70.944.071/0001-69'
    
    b = BrazilSpecProvider(seed=cnpj)
    b2 = BrazilSpecProvider(seed=cnpj)
    assert b.cnpj() == cnpj
    assert b.cnpj() == cnpj
    assert b2.cnpj(with_mask=False) == '70944071000169'
    assert b2.cnpj(with_mask=False) == '70944071000169'
    
test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-12 01:14:39.191852
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    x = provider.cnpj()
    print(x)
    assert len(x) == 18
    assert x[2] == '.'
    assert x[6] == '.'
    assert x[10] == '/'
    assert x[15] == '-'
    assert x[2:6] == '7000'

# Generated at 2022-06-12 01:14:48.134983
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Testa method cnpj da class BrazilSpecProvider."""
    print('Testing method cnpj of class BrazilSpecProvider')
    bz = BrazilSpecProvider(seed=42)
    cnpj = bz.cnpj()
    # Checking if cnpj is valid
    assert cnpj == '77.732.230/0001-70'
    # Testing if, with seed, results are the same
    bz = BrazilSpecProvider(seed=42)
    cnpj = bz.cnpj()
    assert cnpj == '77.732.230/0001-70'
    # Testing without mask
    bz = BrazilSpecProvider(seed=42)
    cnpj = bz.cnpj(with_mask=False)
    assert cnpj == '77732240000170'
    # Testing

# Generated at 2022-06-12 01:14:50.528353
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == "77.732.230/0001-70"

# Generated at 2022-06-12 01:15:10.581724
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.schema import Field, Schema

    cpf_schema = Schema(BrazilSpecProvider)
    cpf = cpf_schema.create(
        field=Field('cpf')
    )
    assert bool(re.match('\d{3}\.\d{3}\.\d{3}-\d{2}', cpf)) is True


# Generated at 2022-06-12 01:15:12.408936
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=False)


# Generated at 2022-06-12 01:15:22.792525
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from collections import Counter
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.seed import SeedGenerator
    import random

    seed = SeedGenerator(random.random())
    seed.data = {'cnpj_data': {'cnpj_data_set': [], 'cnpj_with_mask_set': []}}
    provider = BrazilSpecProvider(seed=seed)

    for _ in range(100):
        cnpj = provider.cnpj()
        cnpj_with_mask = provider.cnpj()

        assert len(cnpj) == 14
        assert len(cnpj_with_mask) == 18
        assert cnpj[2] == '.'
        assert cnpj[6] == '.'
        assert cnpj[10] == '/'

# Generated at 2022-06-12 01:15:25.570278
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(set(BrazilSpecProvider().cnpj() for _ in range(100))) == 100

# Generated at 2022-06-12 01:15:29.596904
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    assert provider.cpf(with_mask=True) != provider.cpf(with_mask=True)
    assert len(provider.cpf(with_mask=True)) == 14


# Generated at 2022-06-12 01:15:32.219969
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf(with_mask=False) in bsp


# Generated at 2022-06-12 01:15:34.542776
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider class CNPJ method."""
    assert len(BrazilSpecProvider().cnpj()) == 18

# Generated at 2022-06-12 01:15:36.904728
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf(): # test Brasil.cpf
    print("BrazilSpecProvider.cpf:", BrazilSpecProvider().cpf())


# Generated at 2022-06-12 01:15:44.407254
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Testando Método cpf da Classe BrazilSpecProvider")
    provider_br = BrazilSpecProvider()
    cpf = provider_br.cpf()
    print(cpf + ' -> CPF gerado')
    assert len(cpf) == 14 # O CPF deve possuir 14 caracteres
    teste = True
    for i in range(0, 3):
        if cpf[i] != '.':
            teste = False
    for i in range(4, 7):
        if cpf[i] != '.':
            teste = False
    for i in range(8, 11):
        if cpf[i] != '-':
            teste = False

# Generated at 2022-06-12 01:15:48.924752
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()
    # one possible result: '000.000.000-00'
    assert len(bp.cpf()) == 14
    # one possible result: '000.000.000-00'
    assert len(bp.cpf(with_mask=False)) == 11


# Generated at 2022-06-12 01:16:20.136006
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    random_number = 123
    cpf_number = BrazilSpecProvider(seed=random_number).cpf()
    assert cpf_number == '415.073.852-77'


# Generated at 2022-06-12 01:16:23.154239
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from pprint import pprint as pp
    pp(BrazilSpecProvider().cpf())



# Generated at 2022-06-12 01:16:27.613371
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    for i in range(100):
        cpf = provider.cpf()
        assert len(cpf) == 14
        assert cpf.count('.') == 2
        assert cpf.count('-') == 1

    for i in range(100):
        cpf = provider.cpf(with_mask=False)
        assert len(cpf) == 11
        assert cpf.isdigit()



# Generated at 2022-06-12 01:16:32.960787
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert re.fullmatch('\d{2}\.\d{3}\.\d{3}\/\d{4}\-\d{2}', provider.cnpj())
    assert len(provider.cnpj()) == 18


# Generated at 2022-06-12 01:16:37.538958
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Testing BrazilSpecProvider.cpf."""
    provider = BrazilSpecProvider()
    assert provider.cpf() == '847.716.180-00'
    assert provider.cpf(with_mask=False) == '8477161800'

# Generated at 2022-06-12 01:16:39.787682
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() == '093.394.844-87'


# Generated at 2022-06-12 01:16:43.926473
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    ## setup ##
    brazil_spec_provider = BrazilSpecProvider()
    ## test ##
    cnpj1 = brazil_spec_provider.cnpj()
    print(cnpj1)
    ## assert ##
    assert cnpj1 is not None
    
test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-12 01:16:55.490364
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    class BrazilSpecProvider(BaseSpecProvider):

        def __init__(self, seed: Seed = None):
            """Initialize attributes."""
            super().__init__(locale='pt-br', seed=seed)

        class Meta:
            """The name of the provider."""

            name = 'brazil_provider'

        def cpf(self, with_mask: bool = True) -> str:
            """Get a random CPF.

            :param with_mask: Use CPF mask (###.###.###-##).
            :returns: Random CPF.

            :Example:
                001.137.297-40
            """

# Generated at 2022-06-12 01:16:57.048214
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method of BrazilSpecProvider."""
    pass

# Generated at 2022-06-12 01:17:02.328575
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""

    from mimesis.providers.brazil_provider import BrazilSpecProvider
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-12 01:17:37.077569
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider()
    assert len(obj.cnpj()) == 18


# Generated at 2022-06-12 01:17:40.035101
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test with a mask
    assert BrazilSpecProvider().cnpj() == '65.944.792/0001-91'
    # Test without a mask
    assert BrazilSpecProvider().cnpj(False) == '65.944.792/0001-91'


# Generated at 2022-06-12 01:17:52.419020
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the method cnpj.

    Test the method cnpj with the following inputs:

    ========  ==================  ============
    Input     Expected Output     Remarks
    ========  ==================  ============
    with_mask = False              Random cnpj
    with_mask = True               Random cnpj with mask
    ========  ==================  ============
    """
    with_mask = [False, True]
    for mask in with_mask:
        cnpj = BrazilSpecProvider().cnpj(with_mask= mask)
        if mask:
            assert(isinstance(cnpj, str))
            assert(len(cnpj) == 18)
        else:
            assert(isinstance(cnpj, str))
            assert(len(cnpj) == 14)

# Unit

# Generated at 2022-06-12 01:17:54.741584
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    cnpj = br.cnpj()
    assert cnpj == '77.732.230/0001-70'

# Generated at 2022-06-12 01:17:58.469841
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=4815162342)
    assert provider.cpf() == '127.695.300-35'
    assert provider.cpf(with_mask=False) == '12769530035'


# Generated at 2022-06-12 01:18:00.017156
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj(with_mask=False)
    print(cnpj)
    print(len(cnpj))


# Generated at 2022-06-12 01:18:11.971745
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Tests BrazilSpecProvider.cpf"""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.code import Code
    person = Person('pt-br')
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[3] == cpf[7] == '.' and  cpf[11] == '-'
    assert bsp.cpf(False) == cpf.replace('.', '').replace('-', '')
    assert bsp.cpf_mask() == '###.###.###-##'
    assert person.cpf() == person.cpf(Gender.MALE)

# Generated at 2022-06-12 01:18:16.172550
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    a = BrazilSpecProvider()
    #print(a.cpf())


# Generated at 2022-06-12 01:18:20.568216
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '77.732.230/0001-70'
    assert bsp.cnpj(with_mask=False) == '77732230000170'
    

# Generated at 2022-06-12 01:18:25.773544
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-12 01:19:40.593215
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    a = BrazilSpecProvider(seed=12345)
    for _ in range(100):
        cpf = a.cpf()
        assert len(cpf) == 14
        assert cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-'
        assert a.random.randint(0, 9) == int(cpf[0])
        assert a.random.randint(0, 9) == int(cpf[1])
        assert a.random.randint(0, 9) == int(cpf[2])
        assert a.random.randint(0, 9) == int(cpf[4])

# Generated at 2022-06-12 01:19:41.692090
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '16.890.542/0001-36'


# Generated at 2022-06-12 01:19:43.193001
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider(seed=0)
    result = cpf.cpf()
    assert(result == '841.176.735-93')


# Generated at 2022-06-12 01:19:48.439345
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cases of method cpf of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == '734.535.281-10'
    assert bsp.cpf() == '471.998.737-72'
    assert bsp.cpf() == '742.592.943-78'
    assert bsp.cpf() == '553.896.736-41'
    assert bsp.cpf() == '967.965.382-79'
    assert bsp.cpf(with_mask=True) == '874.923.346-48'
    assert bsp.cpf(with_mask=False) == '93648814760'

# Generated at 2022-06-12 01:19:54.487178
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for the method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cnpj_0 = provider.cnpj()
    assert cnpj_0 == provider.cnpj(True)
    assert len(cnpj_0) == 18

    cnpj_1 = provider.cnpj(True)
    assert '.' in cnpj_1
    assert '/' in cnpj_1

    cnpj_2 = provider.cnpj(False)
    assert len(cnpj_2) == 14
    assert cnpj_2 != cnpj_1


# Generated at 2022-06-12 01:19:56.839069
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import random
    import pytest
    random.seed(0)
    bsp = BrazilSpecProvider()
    assert(bsp.cnpj() == '77.732.230/0001-70')


# Generated at 2022-06-12 01:20:03.188935
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider."""
    from mimesis.providers.brazil import BrazilSpecProvider

    brasil_provider = BrazilSpecProvider()

    assert len(brasil_provider.cnpj()) == 18

    assert brasil_provider.cnpj() == brasil_provider.cnpj(False)



# Generated at 2022-06-12 01:20:13.070161
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import os
    import sys
    lib_path = os.path.abspath(os.path.join('..'))
    sys.path.append(lib_path)
    from Mimesis_Mimic.mimesis_mimic import MimesisMimic
    mimesis_mimic = MimesisMimic(os.path.join(lib_path, 'data', 'cpf.json'), no_mimesis=True)
    mimesis_mimic.load_data()
    import unittest
    import json
    from pprint import pprint
    class TestBrazilSpecProviderMethods(unittest.TestCase):
        
        # Unit test for method cpf of class BrazilSpecProvider
        def test_BrazilSpecProvider_cpf(self):
            provider = BrazilSpecProvider()
           

# Generated at 2022-06-12 01:20:18.305938
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider(seed=100)
    cpf = br.cpf()
    assert cpf == '068.477.848-35'

    cpf_with_mask = br.cpf(with_mask=False)
    assert cpf_with_mask == '06847784835'



# Generated at 2022-06-12 01:20:21.577570
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # test base class
    from mimesis.specifiers.brazil import BrazilSpecProvider
    spec = BrazilSpecProvider()
    spec.cnpj()
    spec.cnpj(with_mask=False)
    spec.cpf()
    spec.cpf(with_mask=False)



# Generated at 2022-06-12 01:23:13.177897
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()

    for _ in range(100):
        pattern = r'\d{3}\.\d{3}\.\d{3}-\d{2}'
        assert re.search(pattern, brazil.cpf())


# Generated at 2022-06-12 01:23:16.804378
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 14
    assert b.cpf() == '636.647.059-09'
    assert b.cpf(with_mask=False) == '63664705909'


# Generated at 2022-06-12 01:23:21.064122
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert type(cpf) is str
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    

# Generated at 2022-06-12 01:23:23.990986
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == '032.183.503-62'


# Generated at 2022-06-12 01:23:26.678937
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    data = provider.cpf(with_mask=False)
    assert len(data) == 11
    assert data == '00113702510'

# Generated at 2022-06-12 01:23:34.528293
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    mask = b.cnpj(with_mask = True)
    # Check length of return string
    assert len(mask) == 18
    # Check format
    assert mask[2] == '.'
    assert mask[6] == '.'
    assert mask[10] == '/'
    assert mask[15] == '-'
    assert mask[0:2].isdigit()
    assert mask[3:6].isdigit()
    assert mask[7:10].isdigit()
    assert mask[11:15].isdigit()
    assert mask[16:18].isdigit()

    noMask = b.cnpj(with_mask = False)
    # Check length of return string
    assert len(noMask) == 14

# Generated at 2022-06-12 01:23:36.957603
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Return the example of data generated by cnpj method of
    class BrazilSpecProvider.
    """

    provider = BrazilSpecProvider()
    return provider.cnpj()

# Generated at 2022-06-12 01:23:39.714744
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    #Returns true if the cnpj has the expected lenght, and false otherwise
    brazil = BrazilSpecProvider()
    cnpj_test = brazil.cnpj(with_mask=False)
    assert len(cnpj_test) == 14, "Error"

# Generated at 2022-06-12 01:23:42.484104
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    new_c = BrazilSpecProvider()
    assert(new_c.cnpj() == '77.732.230/0001-70')
    assert(new_c.cnpj(with_mask=False) == '7773223000170')
