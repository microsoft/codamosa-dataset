

# Generated at 2022-06-12 01:13:58.733521
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    rnd = BrazilSpecProvider()
    result = rnd.cnpj()

    assert result



# Generated at 2022-06-12 01:14:01.704262
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj method."""
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-12 01:14:13.515006
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """ Unit Test for method cnpj of class BrazilSpecProvider"""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.interfaces import Address as IAddress
    from mimesis.providers.interfaces import Person as IPerson
    from mimesis.providers.phone import Phone
    from mimesis.providers.interfaces import Phone as IPhone

    p = Person(seed=1)
    a = Address(seed=1)
    ph = Phone(seed=1)
    b = BrazilSpecProvider(seed=1)

    print("\nCNPJ - Test")
    print("\nExpected value: 77.732.230/0001-70")

# Generated at 2022-06-12 01:14:17.379426
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    print('\ncnpj with mask 00.000.000/0001-00 :\n{}'.format(bsp.cnpj()))
    print('\ncnpj without mask 00000000000100 :\n{}'.format(bsp.cnpj(False)))


# Generated at 2022-06-12 01:14:20.058966
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    print('<' + provider.cpf() + '>')


# Generated at 2022-06-12 01:14:21.686320
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert(len(BrazilSpecProvider().cnpj()) == 18)


# Generated at 2022-06-12 01:14:24.687340
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf_format = provider.cpf()
    assert cpf_format == '###.###.###-##'


# Generated at 2022-06-12 01:14:27.976318
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    get_cnpj = BrazilSpecProvider()

    assert get_cnpj.cnpj()
    assert get_cnpj.cnpj()


# Generated at 2022-06-12 01:14:32.370848
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    numbers_to_generate = 100
    brazil = BrazilSpecProvider(seed=1)
    for i in range(0, numbers_to_generate):
        print(i, " -> ", brazil.cpf(False))
        i += 1



# Generated at 2022-06-12 01:14:34.596349
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '103.165.079-46'


# Generated at 2022-06-12 01:14:52.851349
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp=BrazilSpecProvider()
    # Testing cnpj method of BrazilSpecProvider Class
    assert bsp.cnpj() == "77.732.230/0001-70"


# Generated at 2022-06-12 01:14:57.873378
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from random import randrange, seed

    seed(0)

    for _ in range(100):
        bsp = BrazilSpecProvider(seed=randrange(2**32))
        assert len(bsp.cpf()) == 14
        assert len(bsp.cpf(False)) == 11

        try:
            bsp.cpf(None)
        except TypeError:
            pass


# Generated at 2022-06-12 01:14:59.154564
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test docstring of BrazilSpecProvider.cpf."""
    provider = BrazilSpecProvider()
    obj = provider.cpf()
    assert len(obj) == 14


# Generated at 2022-06-12 01:15:05.833093
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj(with_mask=True)
    print(cnpj)
    assert len(cnpj) == 18
    assert cnpj[2] == "."
    assert cnpj[6] == "."
    assert cnpj[10] == "/"
    assert cnpj[15] == "-"

test_BrazilSpecProvider_cnpj()


# Generated at 2022-06-12 01:15:10.364226
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    Source [Spec Provider Tests File](https://www.github.com/lk-geimfari/mimesis/blob/master/mimesis/tests/test_builtins.py)
    """
    assert BrazilSpecProvider().cpf()



# Generated at 2022-06-12 01:15:12.582125
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider method cpf"""
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:15:16.297116
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    mimesis = BrazilSpecProvider()

    assert len(mimesis.cnpj()) == 14

    assert mimesis.cnpj() != mimesis.cnpj()



# Generated at 2022-06-12 01:15:19.692482
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bp = BrazilSpecProvider()
    for _ in range(20):
        assert len(bp.cnpj()) == 18, "cnpj retornou vazio"


# Generated at 2022-06-12 01:15:22.637893
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14
    assert bsp.cpf(False) != bsp.cpf()


# Generated at 2022-06-12 01:15:28.773839
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # CPF with mask
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=True)
    print(provider.cnpj(with_mask=True))
    print(len(provider.cnpj(with_mask=True))) # verificar tamanho de uma string é 14



# Generated at 2022-06-12 01:16:06.632078
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf1 = provider.cpf()
    expected_cpf = '001.137.297-40'
    date_cpf = '944.038.285-81'
    #Check that all the digits are different
    assert not (cpf1[0] == cpf1[1] == cpf1[2] == cpf1[3] or
                cpf1[4] == cpf1[5] == cpf1[6] == cpf1[7] or
                cpf1[8] == cpf1[9] == cpf1[10] == cpf1[11] or
                cpf1[12] == cpf1[13] == cpf1[14] == cpf1[15])
    #Check if expected cpf is correct

# Generated at 2022-06-12 01:16:08.866184
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider(seed=12345).cpf() == '077.933.688-34'

# Generated at 2022-06-12 01:16:11.718147
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    x = BrazilSpecProvider()
    cpf = x.cpf()
    assert cpf


# Generated at 2022-06-12 01:16:12.420972
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()

# Generated at 2022-06-12 01:16:14.248757
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    cpf = obj.cpf()
    assert len(cpf) == 14, "expected length of 14"


# Generated at 2022-06-12 01:16:19.068202
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    sp = BrazilSpecProvider()
    bool_list = [False, True]
    for i in range(10):
        bool_value = bool_list[i % 2]
        print(sp.cpf(with_mask=bool_value))


# Generated at 2022-06-12 01:16:20.839340
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '12.421.111/0001-03'

# Generated at 2022-06-12 01:16:27.695569
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import pandas as pd
    import pandas.io.parsers as pd_io_parsers
    from mimesis.providers import BrazilSpecProvider
    all_numbers = []
    for _ in range(0, 100000):
        all_numbers.append(BrazilSpecProvider().cnpj(with_mask=True))
    data = pd.DataFrame(data=all_numbers, columns=None)
    data.to_csv('cnpj_test_file.csv', index=False)



# Generated at 2022-06-12 01:16:34.594097
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    cpf = BrazilSpecProvider().cnpj()
    assert len(cpf) == 14
    assert cpf[2] == '.'
    assert cpf[6] == '.'
    assert cpf[10] == '/'
    assert cpf[12] == '-'
    assert cpf[13:] == '00'

# Generated at 2022-06-12 01:16:37.581540
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-12 01:17:41.693672
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    print(cnpj)
    assert len(cnpj) == 18


# Generated at 2022-06-12 01:17:47.081913
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj()."""
    bsp = BrazilSpecProvider()
    for i in range(10):
        cnpj = bsp.cnpj()
        assert len(cnpj.split('.')) == 3
        assert len(cnpj.split('-')) == 2
        assert len(cnpj.split('/')) == 2


# Generated at 2022-06-12 01:17:55.573757
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        elif peso == 6:
            peso_list = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        for i, _ in enumerate(cnpj):
            soma += peso_

# Generated at 2022-06-12 01:17:59.185238
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    from mimesis.providers import BrazilSpecProvider

    br = BrazilSpecProvider()
    mask = br.cpf(with_mask=True)
    print(mask,len(mask))


# Generated at 2022-06-12 01:18:04.132912
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    for _ in range(0,10):
        assert len(bsp.cpf()) == 14
        assert bsp.cpf()[3] == '.' and bsp.cpf()[7] == '.' and bsp.cpf()[11] == '-'


# Generated at 2022-06-12 01:18:07.323932
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_cnpj = BrazilSpecProvider(seed=964)
    cnpj = brazil_cnpj.cnpj()
    assert cnpj == '77.732.230/0001-70'

# Generated at 2022-06-12 01:18:16.915389
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers import BrazilSpecProvider

    # Creating an instance
    br = BrazilSpecProvider()

    # Getting cpf
    for _ in range(0,2):
        cpf = br.cpf(with_mask=True)
        print(cpf)
        assert len(cpf) == 14

    # Getting cpf
    cpf = br.cpf(with_mask=False)
    print(cpf)
    assert len(cpf) == 11

# Generated at 2022-06-12 01:18:18.780791
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14


# Generated at 2022-06-12 01:18:29.438103
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    assert (int(cnpj[12]) * 2) - (int(cnpj[13]) * 9) == int(cnpj[16])
    assert (int(cnpj[13]) * 2) - (int(cnpj[14]) * 9) == int(cnpj[17])


# Generated at 2022-06-12 01:18:30.815637
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed(1)
    provider = BrazilSpecProvider()
    provider.cnpj(True)


# Generated at 2022-06-12 01:21:19.459209
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br_datatype = BrazilSpecProvider()
    cpf = br_datatype.cpf(with_mask=True)
    assert len(cpf) == 14
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert cpf[0:14].isdigit()


# Generated at 2022-06-12 01:21:22.517817
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cpf(with_mask=False)) == 11
    assert not provider.cpf(with_mask=False).startswith('0')


# Generated at 2022-06-12 01:21:25.310130
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14


# Generated at 2022-06-12 01:21:28.100978
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf(with_mask=True) == '001.137.297-40'
    assert brazil_provider.cpf(with_mask=False) == '00113729740'


# Generated at 2022-06-12 01:21:30.117668
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert(BrazilSpecProvider().cpf(with_mask=False) == BrazilSpecProvider().cpf(with_mask=False))


# Generated at 2022-06-12 01:21:33.214606
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj."""
    brazil = BrazilSpecProvider()
    # Verify if the length of cnpj is 14
    assert len(brazil.cnpj()) == 14



# Generated at 2022-06-12 01:21:35.077953
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '004.817.921-88'


# Generated at 2022-06-12 01:21:37.091574
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilSpecProvider = BrazilSpecProvider()
    assert brazilSpecProvider.cnpj() == "03.216.964/0001-64"


# Generated at 2022-06-12 01:21:45.246601
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test default argument with_mask = True and value = 111.111.111-11
    p = BrazilSpecProvider()
    CPF = p.cpf()
    assert CPF == '111.111.111-11'
    assert CPF != '111.111.111-12'

    # Test argument with_mask = False and value = 11111111111
    CPF = p.cpf(with_mask=False)
    assert CPF == '11111111111'
    assert CPF != '11111111112'

    # Test argument with_mask = False and value = 111.111.111-11
    CPF = p.cpf(with_mask=True)
    assert CPF == '111.111.111-11'
    assert CPF != '111.111.111-12'

    # Test method name
    p = Brazil

# Generated at 2022-06-12 01:21:48.721009
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider(seed=4747)
    print(bsp.cpf())
    print(bsp.cpf(with_mask=False))
