

# Generated at 2022-06-12 01:13:58.772819
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider.cnpj()."""
    from mimesis.providers.brazil.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person.en_GB import Name as NameEn
    import re
    n = BrazilSpecProvider()
    assert n.cnpj() is not None
    assert n.cnpj(True) is not None
    assert n.cnpj(False) is not None
    assert n.cnpj().startswith('00') is False
    assert n.cnpj(True).startswith('00') is False
    assert n.cnpj(False).startswith('00') is False

# Generated at 2022-06-12 01:14:00.753472
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14


# Generated at 2022-06-12 01:14:03.881960
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=1)
    assert provider.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-12 01:14:07.157158
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '52.633.716/0001-92'


# Generated at 2022-06-12 01:14:10.265915
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider.cpf()
    assert len(cpf) == 14 and cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-'


# Generated at 2022-06-12 01:14:18.902755
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    provider = BrazilSpecProvider()     # create BrazilSpecProvider instance
    cnpj = provider.cnpj(False)         # create cnpj sequence

    assert len(cnpj) == 14              # check if cnpj length is 14
    for digit in cnpj:                  # check if all cnpj digits are numbers
        assert digit.isdigit()

    cnpj_mask = provider.cnpj()         # create cnpj masked sequence
    assert len(cnpj_mask) == 18         # check if cnpj masked length is 18

    assert len(provider.cnpj(False)) == 14   # check if cnpj length is 14
    assert len(provider.cnpj()) == 18        # check if cnpj masked length is 18


# Generated at 2022-06-12 01:14:31.160324
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    invalid_cpf = brazil_provider.cpf()

    # Verify if the CPF has the correct mask
    assert invalid_cpf[3] == invalid_cpf[7] == '.' and \
        invalid_cpf[11] == '-'

    # Verify if the CPF has the correct number of digits
    assert len(invalid_cpf) == 14

    # Verify if the CPF is invalid

# Generated at 2022-06-12 01:14:42.127189
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    
    cnpj1 = bsp.cnpj()
    cnpj2 = bsp.cnpj()
     
    assert len(cnpj1) == 14
    assert len(cnpj2) == 14
    
    assert cnpj1 != cnpj2

    with_mask1 = bsp.cnpj(with_mask=True)
    with_mask2 = bsp.cnpj(with_mask=True)
     
    assert len(with_mask1) == 18
    assert len(with_mask2) == 18
    
    assert with_mask1 != with_mask2



# Generated at 2022-06-12 01:14:44.873402
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    bsp.cnpj()

    return True


# Generated at 2022-06-12 01:14:46.718139
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == "014.358.619-18"

# Generated at 2022-06-12 01:15:03.857134
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print(cnpj)
    assert(cnpj.isnumeric())
    assert(len(cnpj)==18)
    assert(cnpj[2]=='.')
    assert(cnpj[6]=='.')
    assert(cnpj[10]=='/')
    assert(cnpj[15]=='-')
    assert(cnpj[~2].isnumeric())
    assert(cnpj[~4].isnumeric())
    assert(cnpj[~3].isnumeric())
    assert(cnpj[~5].isnumeric())
    assert(cnpj[~6].isnumeric())
    assert(cnpj[~7].isnumeric())

# Generated at 2022-06-12 01:15:10.629476
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj_list = []
    for _ in range(100):
        cnpj = provider.cnpj()
        assert len(cnpj) == 18
        cnpj_list.append(cnpj)
    assert ''.join(cnpj_list[0]) != ''.join(cnpj_list[1])


# Generated at 2022-06-12 01:15:13.783070
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj."""
    obj = BrazilSpecProvider(seed=1234)
    result = obj.cnpj()
    assert result == '02.158.744/0005-86'


# Generated at 2022-06-12 01:15:16.742785
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider.
    """
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14

# Generated at 2022-06-12 01:15:22.658374
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    expected_format_with_mask = '000.000.000-00'
    expected_format_without_mask = '00000000000'

    assert len(brazil_provider.cpf(with_mask=True)) == len(expected_format_with_mask)
    assert len(brazil_provider.cpf(with_mask=False)) == len(expected_format_without_mask)


# Generated at 2022-06-12 01:15:29.494010
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the method cnpj of class BrazilSpecProvider."""
    cnpj = BrazilSpecProvider.cnpj()
    cnpj_without_mask = cnpj.replace(".", "").replace("-", "").replace("/", "")
    assert cnpj_without_mask.isdigit()
    assert len(cnpj_without_mask) == 14


# Generated at 2022-06-12 01:15:32.126535
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BSP = BrazilSpecProvider()
    assert BSP.cnpj(with_mask=False) == '7773223000170'

# Generated at 2022-06-12 01:15:35.910919
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    spec = BrazilSpecProvider()
    string = spec.cpf()
    assert(string == '527.948.065-79')


# Generated at 2022-06-12 01:15:43.876884
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    '''
    Test the cnpj function from BrazilSpecProvider class
    '''
    from time import time
    from mimesis.enums import Gender
    brazil_provider = BrazilSpecProvider()
    start = time()
    cnpj = brazil_provider.cnpj()
    end = time()
    print(cnpj)
    print(end-start)
    print(type(cnpj))
    print(len(cnpj))
    #assert len(cnpj) == 18
    #assert cnpj in ['31737113/0001-00', '28807870/0001-00', '73969547/0001-00', '83044562/0001-00', '79898081/0001-00',
    #                '96698194/0001-00', '9545

# Generated at 2022-06-12 01:15:47.641871
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == "11.764.020/0005-40"
    assert BrazilSpecProvider().cnpj(with_mask=False) == "1176402000540"


# Generated at 2022-06-12 01:16:08.361247
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("Test method BrazilSpecProvider.cnpj")
    
    from mimesis.enums import Gender

    locale = 'pt-br'
    seed = 2

    seed = Seed(seed)
    br = BrazilSpecProvider(seed=seed)
    #print('masculine_first_name:', br.masculine_first_name(locale=locale))
    print('cnpj:', br.cnpj(with_mask=True))
    
test_BrazilSpecProvider_cnpj()


# Generated at 2022-06-12 01:16:13.842490
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    bp = BrazilSpecProvider()
    p = Person('pt-br', seed=12345)
    cpf = bp.cpf(with_mask=False)
    assert p.cpf(mask=False, seed=12345) == cpf



# Generated at 2022-06-12 01:16:25.972805
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.datetime import Datetime
    class BrazilSpecProvider1(BrazilSpecProvider):
        def __init__(self, seed: Seed = None):
            super().__init__(locale='pt-br', seed=seed)
            self.__datetime = Datetime(seed)
            self.__person = Person(seed)

    provider1 = BrazilSpecProvider1(seed=None)

    # test method cpf
    # case 1: cpf masks
    mask_list = ['###.###.###-##', '##.###.###/####-##', '###########', '##########']
    for mask in mask_list:
        p1 = provider1.cpf(with_mask=True)


# Generated at 2022-06-12 01:16:31.811708
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider.Meta.name == 'brazil_provider'
    provider = BrazilSpecProvider()
    assert len(provider.cnpj()) == 18
    assert provider.cnpj().startswith('0')
    assert provider.cnpj(False).startswith('0')

# Generated at 2022-06-12 01:16:36.955787
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp= BrazilSpecProvider
    cnpj = bsp.cnpj(with_mask=True)
    print(cnpj)
    assert cnpj != ""
    assert cnpj != None


# Generated at 2022-06-12 01:16:38.583593
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:16:40.726825
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()

    assert len(cnpj) == 18

    cnpj_without_mask = bsp.cnpj(False)

    assert len(cnpj_without_mask) == 14


# Generated at 2022-06-12 01:16:43.514323
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print("cnpj = ", cnpj)
    assert cnpj == cnpj


# Generated at 2022-06-12 01:16:52.706065
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()

    # Test cpf with mask
    cpf_with_mask = brazil.cpf(with_mask=True)
    assert len(cpf_with_mask.replace('.', '').replace('-', '')) == 11

    # Test cpf with not mask
    cpf_no_mask = brazil.cpf(with_mask=False)
    assert len(cpf_no_mask) == 11


# Generated at 2022-06-12 01:16:58.602122
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider=BrazilSpecProvider()
    cpf=provider.cpf()
    print(cpf)
    if provider.validate_cpf(cpf):
        print("CPF Valid!")
    else:
        print("CPF Invalid!")


# Generated at 2022-06-12 01:17:37.399844
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(with_mask=False)
    assert cnpj.isdigit()
    assert len(cnpj) == 14

# Generated at 2022-06-12 01:17:47.305285
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    status = True
    if len(cpf) != 14:
        status = False
    dots = 0
    for c in cpf:
        if c == '.': dots += 1
    if dots != 2:
        status = False
    if cpf[3] != '.' or cpf[8] != '.' or cpf[13] != '-':
        status = False
    first_dv = int(cpf[9])
    second_dv = int(cpf[10])
    # print(cpf)
    # print(first_dv)
    # print(second_dv)

# Generated at 2022-06-12 01:17:51.806561
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=0)
    cnpj = bsp.cnpj()
    assert '35.867.878/0001-00' == cnpj

# Generated at 2022-06-12 01:17:55.950924
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    pattern = re.compile(r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}')
    # Run test.
    assert pattern.match(BrazilSpecProvider().cnpj())

# Generated at 2022-06-12 01:17:57.883743
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()


# Generated at 2022-06-12 01:17:59.511851
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '001.137.297-40'


# Generated at 2022-06-12 01:18:04.065170
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider(seed=1234567890)
    assert brazil_spec_provider.cnpj() == '77.732.230/0001-70'



# Generated at 2022-06-12 01:18:05.623193
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    brazil.cpf()

# Generated at 2022-06-12 01:18:14.492894
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    brs = BrazilSpecProvider()
    cpf_not_masked = brs.cpf(False)
    assert cpf_not_masked == '25932241710'
    assert 14 == len(cpf_not_masked)
    cpf_masked = brs.cpf(True)
    assert cpf_masked == '382.003.145-83'
    assert 14 == len(cpf_masked)



# Generated at 2022-06-12 01:18:19.024633
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    if not isinstance(cnpj, str):
        raise AssertionError()
    assert len(cnpj) == 18


# Generated at 2022-06-12 01:19:33.430204
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf1 = b.cpf()
    cpf2 = b.cpf(True)
    assert cpf1 == cpf2, 'The numbers %s and %s are different.' % (cpf1, cpf2)


# Generated at 2022-06-12 01:19:37.493608
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Generate a random CNPJ number
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cnpj(True))

    # Using mask
    print(brazil_provider.cnpj(False))



# Generated at 2022-06-12 01:19:42.499723
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test if cnpj() method of BrazilSpecProvider works fine."""
    b = BrazilSpecProvider()

    for i in range(100):
        cnpj = b.cnpj()
        assert len(cnpj) == 18
        assert cnpj.count('.') == 2
        assert cnpj.count('-') == 1
        assert cnpj.count('/') == 1
        assert len(cnpj.replace('.', '').replace('/', '').replace('-', '')) == 14


# Generated at 2022-06-12 01:19:44.157437
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider(seed=12345)
    result = cpf.cpf()
    assert result == '459.356.727-71'


# Generated at 2022-06-12 01:19:46.306660
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
   br = BrazilSpecProvider()
   assert len(br.cpf().replace('.', '').replace('-', '')) == 9
   assert len(br.cpf(with_mask=False).replace('.', '').replace('-', '')) == 9


# Generated at 2022-06-12 01:19:48.781509
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data = BrazilSpecProvider()
    print(data.cpf())


# Generated at 2022-06-12 01:19:49.994211
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()

# Generated at 2022-06-12 01:19:53.005373
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    prov = BrazilSpecProvider()
    assert prov.cnpj(True) == '77.732.230/0001-70'
    assert prov.cnpj(False) == '77732302000170'



# Generated at 2022-06-12 01:19:54.720794
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    print(brazilSpecProvider.cpf())
    print(brazilSpecProvider.cpf(with_mask = False))


# Generated at 2022-06-12 01:20:00.361675
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for _ in range(10):
        brazil_spec_provider = BrazilSpecProvider()
        cnpj_formatado = brazil_spec_provider.cnpj(with_mask=True)
        assert len(cnpj_formatado) == 18
        assert cnpj_formatado[2] == "."
        assert cnpj_formatado[6] == "."
        assert cnpj_formatado[10] == "/"
        assert cnpj_formatado[15] == "-"
        cnpj_sem_formatacao = brazil_spec_provider.cnpj(with_mask=False)
        assert len(cnpj_sem_formatacao) == 14
        assert cnpj_sem_formatacao[8] != "/"
        assert cnpj_sem_formatac

# Generated at 2022-06-12 01:23:09.186622
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    prov = BrazilSpecProvider()

    cpfs = set()

    for i in range(0, 500):
        cpfs.add(prov.cpf())

    assert len(cpfs) > 10


# Generated at 2022-06-12 01:23:16.107594
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    aux = []
    for i in range(100):
        cpf = b.cpf(with_mask=False)
        aux.append(cpf)
        if (len(cpf) != 11):
            raise ValueError(f'Length of cpf is wrong: {len(cpf)}')

    print(aux)
    if (len(aux) != len(set(aux))):
        raise ValueError(f'Duplicated CPF')

    # Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-12 01:23:23.189364
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Does module import correctly?
    from mimesis.providers.brazil import BrazilSpecProvider

    # Does method cnpj work correctly?
    test_provider = BrazilSpecProvider()
    assert bool(test_provider.cnpj(with_mask=False))
    assert bool(test_provider.cnpj(with_mask=True))
    assert isinstance(test_provider.cnpj(with_mask=False), str)
    assert isinstance(test_provider.cnpj(with_mask=True), str)



# Generated at 2022-06-12 01:23:26.915818
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
  brazil_spec_provider = BrazilSpecProvider()
  x = brazil_spec_provider.cpf()
  assert len(x) == 14
  assert x[3] == x[7] == '.'
  assert x[11] == '-'


# Generated at 2022-06-12 01:23:35.146283
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brp = BrazilSpecProvider()
    #teste 1
    cpf = brp.cpf()
    try:
        assert cpf == 'xxx.xxx.xxx-xx'
        print(f'A função cpf foi executada com sucesso. O retorno é: {cpf}')
    except AssertionError:
        print('Erro na função cpf. O retorno é: ', cpf)
    #teste 2
    cpf = brp.cpf(with_mask=True)

# Generated at 2022-06-12 01:23:42.730514
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test with mask
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '77.732.230/0001-70'
    assert provider.cnpj() == '82.641.225/0001-67'
    assert provider.cnpj() == '50.865.324/0001-99'
    assert provider.cnpj() == '05.977.635/0001-49'
    assert provider.cnpj() == '08.994.321/0001-90'
    assert provider.cnpj() == '96.579.072/0001-31'
    assert provider.cnpj() == '48.906.068/0001-76'
    assert provider.cnpj() == '85.064.835/0001-37'