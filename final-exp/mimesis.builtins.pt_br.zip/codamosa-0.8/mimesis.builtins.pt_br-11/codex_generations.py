

# Generated at 2022-06-12 01:13:56.151532
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("\nTest method cnpj of class BrazilSpecProvider")
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    print(cnpj)
    assert len(cnpj) == 18
    cnpj = bsp.cnpj(False)
    print(cnpj)
    assert len(cnpj) == 14

# Generated at 2022-06-12 01:14:01.075029
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = cnpj_generator()
    assert len(cnpj) == 14
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-12 01:14:06.232820
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # given
    provider = BrazilSpecProvider()

    # when
    cnpj = provider.cnpj()
    print(cnpj)

    # then
    assert len(cnpj) == 18

# Generated at 2022-06-12 01:14:10.707214
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert not cpf.isdigit()
    assert cpf.replace('-', '').replace('.', '').isdigit()



# Generated at 2022-06-12 01:14:14.621144
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Checks if the value returned by method is valid."""
    # Valido
    fp = BrazilSpecProvider(seed=42)
    test_value = fp.cpf()
    assert test_value == '504.667.320-33'


# Generated at 2022-06-12 01:14:18.192489
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert isinstance(provider.cnpj(), str)
    assert len(provider.cnpj()) == 18
    assert provider.cnpj(False) == "54529408000107"
    assert provider.cnpj() == "54.529.408/0001-07"


# Generated at 2022-06-12 01:14:21.166706
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:14:31.906116
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test 1
    cnpj = 77106051000165
    cnpj_mask = '77.106.051/0001-65'
    assert BrazilSpecProvider().cnpj() == cnpj
    assert BrazilSpecProvider().cnpj(with_mask=True) == cnpj_mask
    # Test 2
    cnpj = '41804043000147'
    cnpj_mask = '41.804.043/0001-47'
    assert BrazilSpecProvider(seed=41804043000147).cnpj() == cnpj
    assert BrazilSpecProvider(seed=41804043000147).cnpj(with_mask=True) == cnpj_mask


# Generated at 2022-06-12 01:14:44.634871
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    brasil = BrazilSpecProvider()

    # Without mask
    for _ in range(1000):
        cnpj = brasil.cnpj(False)
        assert len(cnpj) == 14
        digits = [int(i) for i in cnpj]
        assert digits[12] == get_verifying_digit_cnpj(digits, 5)
        assert digits[13] == get_verifying_digit_cnpj(digits, 6)

    # With mask
    for _ in range(1000):
        cnpj = brasil.cnpj()
        assert len(cnpj) == 18

# Generated at 2022-06-12 01:14:47.915841
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:15:10.727211
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    # Testes reais:
    provider.seed('')
    assert provider.cpf() == '001.138.171-75'

    provider.seed('Esta teste')
    assert provider.cpf() == '241.481.367-68'

    provider.seed('test')
    cpf = provider.cpf()
    assert cpf != '000.000.000-00'
    assert '.' not in cpf[:3] and '.' not in cpf[3:6] and '.' not in cpf[6:9] and '-' not in cpf[9:] and len(cpf) == 11
    for digit in cpf:
        assert digit in '0123456789' 
    

# Generated at 2022-06-12 01:15:17.612626
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    full = BrazilSpecProvider()

    for _ in range(10):
        result = full.cpf()
        cpf_numbers = result.replace('.', '').replace('-', '')
        assert len(cpf_numbers) == 11
        assert len(result) == 14
        assert type(cpf_numbers) == str

    n_mask = BrazilSpecProvider()
    for _ in range(10):
        result_nm = n_mask.cpf(False)
        assert len(result_nm) == 11
        assert type(result_nm) == str


# Generated at 2022-06-12 01:15:19.999971
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    cpf = br.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:15:23.207613
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the method cnpj of class BrazilSpecProvider
    """
    provider = BrazilSpecProvider()
    assert provider.cnpj() == "77.732.230/0001-70"


# Generated at 2022-06-12 01:15:27.612249
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider method cpf."""
    bsp = BrazilSpecProvider()
    generated_cpf = bsp.cpf()
    assert len(generated_cpf) == 14
    assert generated_cpf[3] == '.'
    assert generated_cpf[7] == '.'
    assert generated_cpf[11] == '-'


# Generated at 2022-06-12 01:15:29.757400
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    a = BrazilSpecProvider()
    result = a.cnpj()
    assert len(result) == 18

# Generated at 2022-06-12 01:15:40.770720
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Create instance of BrazilSpecProvider class
    provider = BrazilSpecProvider()
    # Call method cpf
    cpf = provider.cpf()
    # cpf have mask
    assert cpf.count('.') == 2
    # cpf ends with digito verificador
    assert cpf.count('-') == 1
    # cpf have 9 dígitos
    assert len(cpf) == 14
    # Call method cpf(False)
    cpf2 = provider.cpf(False)
    # cpf2 dont have mask
    assert cpf2.count('.') == 0
    # cpf2 dont have digito verificador
    assert cpf2.count('-') == 0
    # cpf2 have 11 dígitos
    assert len(cpf2) == 11



# Generated at 2022-06-12 01:15:45.991746
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()

    cpf = brazil_provider.cpf()
    assert len(cpf) == 14, "The size of cpf should be 14"


# Generated at 2022-06-12 01:15:48.850677
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider.cnpj."""
    assert not BrazilSpecProvider().cnpj() == ""
    assert not BrazilSpecProvider().cnpj(with_mask=False) == ""


# Generated at 2022-06-12 01:15:51.823397
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.brazil import BrazilSpecProvider

    jt_provider = BrazilSpecProvider()

    cpf = jt_provider.cpf()

    print(cpf)

    cpf = jt_provider.cpf(with_mask=False)

    print(cpf)


# Generated at 2022-06-12 01:16:20.790624
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider(seed=1)
    assert brazil_provider.cnpj() == '77.732.230/0001-70'
    assert brazil_provider.cnpj(with_mask=False) == '77732230000170'


# Generated at 2022-06-12 01:16:28.264088
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    cnpj_with_mask = bsp.cnpj(with_mask=True)
    assert cnpj != cnpj_with_mask
    assert len(cnpj) == 14
    assert len(cnpj_with_mask) == 18
    assert cnpj_with_mask[2] == '.'
    assert cnpj_with_mask[6] == '.'
    assert cnpj_with_mask[10] == '/'
    assert cnpj_with_mask[15] == '-'


# Generated at 2022-06-12 01:16:38.540414
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider as bsp
    cpf_pattern = re.compile('^[0-9]{3}.[0-9]{3}.[0-9]{3}-[0-9]{2}$')
    cpf_pattern2 = re.compile('^[0-9]{11}$')
    ret1 = bsp(seed=1).cpf()
    ret2 = bsp(seed=1).cpf(with_mask=False)
    assert cpf_pattern.match(ret1)
    assert cpf_pattern2.match(ret2)


# Generated at 2022-06-12 01:16:41.997347
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method."""
    bsp = BrazilSpecProvider()
    assert bsp.cpf(with_mask=False) is not None
    assert bsp.cpf(with_mask=True) is not None


# Generated at 2022-06-12 01:16:43.918502
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18
    
    

# Generated at 2022-06-12 01:16:46.799554
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '000.000.000-00'


# Generated at 2022-06-12 01:16:53.543500
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider_cnpj = BrazilSpecProvider()
    brazil_provider_cnpj_cnpj_0001_70 = brazil_provider_cnpj.cnpj()
    assert brazil_provider_cnpj_cnpj_0001_70 == "77.732.230/0001-70"



# Generated at 2022-06-12 01:16:59.999963
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    instance = BrazilSpecProvider()
    assert instance.cnpj() == '77.732.230/0001-70'
    assert instance.cnpj(True) == '77.732.230/0001-70'
    assert instance.cnpj(False) == '77732230000170'


# Generated at 2022-06-12 01:17:06.129929
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj_verify = bsp.cnpj(True)
    cnpj_verify = cnpj_verify[0:2] + cnpj_verify[3:6] + cnpj_verify[7:10] + cnpj_verify[11:15] + cnpj_verify[16:18]
    cnpj_verify = list(map(int, cnpj_verify))
    peso1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    peso2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    soma1 = 0
    soma2 = 0

# Generated at 2022-06-12 01:17:11.221918
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=True)
    assert len(cpf) == 14
    assert cpf[3] == "."
    assert cpf[7] == "."
    assert cpf[11] == "-"
    cpf_numbers = [i for i in cpf if i.isdigit()]
    assert len(cpf_numbers) == 11


# Generated at 2022-06-12 01:18:19.125657
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider

    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    fmt_cnpj = '{}.{}.{}/{}-{}'.format(cnpj[:2], cnpj[2:5], cnpj[5:8], cnpj[8:12], cnpj[12:])
    return fmt_cnpj


# Generated at 2022-06-12 01:18:20.428170
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()


# Generated at 2022-06-12 01:18:28.402586
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert isinstance(cnpj, str)

    cnpj = provider.cnpj(with_mask=True)
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    assert cnpj.count('-') == 1
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18


# Generated at 2022-06-12 01:18:32.135745
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    cnpjs = []
    for _ in range(1000):
        cnpjs.append(b.cnpj())
    assert cnpjs.count(cnpj) == 1

# Generated at 2022-06-12 01:18:35.144114
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Universal test for BrazilSpecProvider class."""
    provider = BrazilSpecProvider()
    result = provider.cnpj(with_mask=False)
    assert len(result) == 14
    assert result.isdigit()

# Generated at 2022-06-12 01:18:36.543353
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '056.194.619-65'


# Generated at 2022-06-12 01:18:47.834678
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    c1 = provider.cpf(with_mask=False)
    c2 = provider.cpf(with_mask=False)
    c3 = provider.cpf(with_mask=False)
    c4 = provider.cpf(with_mask=False)
    c5 = provider.cpf(with_mask=False)
    c6 = provider.cpf(with_mask=False)

    assert len(c1) == 11
    assert len(c2) == 11
    assert len(c3) == 11
    assert len(c4) == 11
    assert len(c5) == 11
    assert len(c6) == 11

    assert c1 != c2 != c3 != c4 != c5 != c6
    assert type(c1) == str

# Generated at 2022-06-12 01:18:50.803026
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    mask_cnpj = bsp.cnpj(True)
    assert(mask_cnpj[:2] == '77')
    cnpj = bsp.cnpj(False)
    assert(cnpj[:2] == '77')
    assert(len(cnpj) == 14)

# Generated at 2022-06-12 01:18:56.471607
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider(seed=1)
    assert b.cnpj(with_mask=False) == '20436575000298'
    assert b.cnpj(with_mask=True) == '20.436.575/0002-98'

# Generated at 2022-06-12 01:19:01.157477
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf(with_mask=False)) == 11
    # With mask
    assert len(brazil.cpf(with_mask=True)) == 14


# Generated at 2022-06-12 01:21:36.181901
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_1 = BrazilSpecProvider.cnpj()
    cnpj_2 = BrazilSpecProvider.cnpj(with_mask=False)

    assert len(cnpj_1) == 18
    assert len(cnpj_2) == 14

# Generated at 2022-06-12 01:21:41.538988
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    import re
    esperado = "^[0-9]{3}.[0-9]{3}.[0-9]{3}-[0-9]{2}$"
    resposta = BrazilSpecProvider.cpf().__str__()
    assert re.match(esperado, resposta)


# Generated at 2022-06-12 01:21:44.816385
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 14
    assert b.cpf()[3] == '.'
    assert b.cpf()[7] == '.'
    assert b.cpf()[11] == '-'
    assert b.cpf(with_mask=False) == '90766540041'

# Generated at 2022-06-12 01:21:48.154021
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() in list(BrazilSpecProvider().cpf() for i in range(0, 100))


# Generated at 2022-06-12 01:21:56.482004
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Check if the cnpj is valid
    def check_cnpj(cnpj):
        for i in range(2):
            cnpj, dv = cnpj[:-2], cnpj[-2:]
            sum, pos = 0, len(cnpj) + 1
            for n in cnpj:
                sum += int(n) * pos
                pos -= 1
            dv = 11 - sum % 11
            if dv > 9:
                dv = 0

            if int(dv) != int(dv[-1]):
                return False
        return True

    cnpj = BrazilSpecProvider().cnpj()
    assert(check_cnpj(cnpj)) is True


# Generated at 2022-06-12 01:22:02.517478
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers import BrazilSpecProvider

    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print(cnpj)
    assert len(cnpj) == 18
    assert cnpj.replace('.', '').replace('/', '').replace('-', '').isdigit()

# Generated at 2022-06-12 01:22:05.068848
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BR = BrazilSpecProvider()
    # assert type(BR.cnpj()) == str
    print(BR.cnpj())


# Generated at 2022-06-12 01:22:15.311829
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    cnpj_without_mask = cnpj.replace('.','').replace('-','').replace('/','')

    # 1º Digito
    peso = [5,4,3,2,9,8,7,6,5,4,3,2]

    sum = 0
    for i in range(12):
        sum += int(cnpj_without_mask[i]) * peso[i]

    rest = sum % 11

    if rest < 2:
        first_dv = 0
    else:
        first_dv = 11 - rest

    # 2º Digito

# Generated at 2022-06-12 01:22:18.260175
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    prov = BrazilSpecProvider()
    print(prov.cpf())


test_BrazilSpecProvider_cpf()


# Generated at 2022-06-12 01:22:21.768672
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    prov = BrazilSpecProvider()
    cnpj = prov.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
