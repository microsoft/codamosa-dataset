

# Generated at 2022-06-12 01:14:00.376569
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    brazil = BrazilSpecProvider()

    cnpj = brazil.cnpj(with_mask=False)
    assert len(cnpj) == 14



# Generated at 2022-06-12 01:14:07.022865
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    brazil_provider_test = BrazilSpecProvider()
    cnpj_without_mask = brazil_provider_test.cnpj(with_mask=False)
    assert len(cnpj_without_mask) == 14


# Generated at 2022-06-12 01:14:10.183680
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(with_mask = False) == '37170458766'
    assert BrazilSpecProvider().cpf(with_mask = True) == '371.704.587-66'


# Generated at 2022-06-12 01:14:12.422085
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    # Test length of the number.
    assert len(cnpj) == 14



# Generated at 2022-06-12 01:14:19.107504
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    for _ in range(1000):
        brazil_cnpj = BrazilSpecProvider()

        cnpj_without_mask = brazil_cnpj.cnpj(with_mask=False)
        assert isinstance(cnpj_without_mask, str)
        assert len(cnpj_without_mask) == 14

        cnpj_with_mask = brazil_cnpj.cnpj(with_mask=True)
        assert isinstance(cnpj_with_mask, str)
        assert len(cnpj_with_mask) == 18


# Generated at 2022-06-12 01:14:31.359722
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.types import Code

    person = Person('pt-br')
    brazil = BrazilSpecProvider('pt-br')

    user = {
        'name': person.full_name(gender=Gender.FEMALE),
        'age': person.age(),
        'cpf': brazil.cpf(),
        'cnpj': brazil.cnpj()
    }

    # Unit test for method cpf of class BrazilSpecProvider
    assert user['name'] == 'Maria Melo'
    assert user['age'] == 57
    assert user['cpf'] == '848.311.097-22'
    assert user['cnpj']

# Generated at 2022-06-12 01:14:36.024034
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(100):
        cpf = BrazilSpecProvider().cpf(with_mask=False)
        assert len(cpf) == 11
        assert not isinstance(cpf, type(None))


# Generated at 2022-06-12 01:14:39.490596
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf() == '823.928.102-74'


# Generated at 2022-06-12 01:14:45.183390
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    from mimesis.providers.brazil import BrazilSpecProvider
    import random

    brazil = BrazilSpecProvider()

    i = 0
    while i <= 1000:
        cpf = brazil.cpf()
        if cpf == '000.000.000-00':
            print(cpf, "invalido")
            i = i + 1

test_BrazilSpecProvider_cpf()


# Generated at 2022-06-12 01:14:54.693485
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print ("\n********** UNIT TEST **********\n")
    print ("Unit test for method cpf of class BrazilSpecProvider")

    provider = BrazilSpecProvider()
    p = provider.cpf(with_mask = False)

    # check cpf lenght
    if len(p) == 11 :
        print ("Method cpf of class BrazilSpecProvider ok")
    else:
        print ("Method cpf of class BrazilSpecProvider fail")
        print ("Provided cpf = ", p, " - CPF length is not 11 chars")


# Generated at 2022-06-12 01:15:12.540578
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    data = BrazilSpecProvider()
    assert data.cnpj() == '77.732.230/0001-70'
    assert data.cnpj(False) == '77732230000170'


# Generated at 2022-06-12 01:15:16.562223
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the cpf method of BrazilSpecProvider."""
    tester = BrazilSpecProvider()
    assert len(tester.cpf()) == 14
    assert len(tester.cpf(False)) == 11


# Generated at 2022-06-12 01:15:20.206083
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    Unit test for method cpf of class BrazilSpecProvider.
    """
    bsp = BrazilSpecProvider()
    assert bsp.cpf() is not None
    assert len(bsp.cpf()) == 14


# Generated at 2022-06-12 01:15:24.153285
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj.replace('.','').replace('-','').replace('/','')) == 14


# Generated at 2022-06-12 01:15:29.433846
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print(cnpj)
    # assert provider.cnpj(with_mask=False) == cnpj.replace('.','').replace('/','').replace('-','')

test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-12 01:15:34.499855
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Get a random CPF."""
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cpf(with_mask=False)) == 11
    assert provider.cpf() == '001.137.297-40'


# Generated at 2022-06-12 01:15:39.266971
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    r = BrazilSpecProvider.cnpj(with_mask=True)

    assert isinstance(r, str)
    assert r.count('.') == 2
    assert r.count('-') == 1
    assert r.count('/') == 1
    assert len(r) == 18



# Generated at 2022-06-12 01:15:47.296779
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider's cpf method."""
    data_provider = BrazilSpecProvider(seed=0)
    cpf1 = data_provider.cpf()
    assert cpf1 == "639.300.845-40"
    cpf2 = data_provider.cpf(with_mask=False)
    assert cpf2 == "63930084540"


# Generated at 2022-06-12 01:15:50.979947
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) is 14


# Generated at 2022-06-12 01:15:54.486054
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj(with_mask=False)
    assert len(b.cnpj(with_mask=False)) == 14


# Generated at 2022-06-12 01:16:33.140639
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    for _ in range(100):
        cpf_1 = BrazilSpecProvider().cnpj()
        cpf_2 = BrazilSpecProvider().cnpj()

        assert cpf_1 != cpf_2

    for _ in range(100):
        cpf_1 = BrazilSpecProvider().cnpj(with_mask=False)
        cpf_2 = BrazilSpecProvider().cnpj(with_mask=False)

        assert cpf_1 != cpf_2

# Generated at 2022-06-12 01:16:34.061257
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    pass


# Generated at 2022-06-12 01:16:38.950982
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Tests the BrazilSpecProvider.cpf method"""
    random = BrazilSpecProvider()
    cpf = random.cpf()
    if(type(cpf) is str):
        assert(1)
    else:
        assert(0)


# Generated at 2022-06-12 01:16:42.998975
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method BrazilSpecProvider.cnpj."""
    provider = BrazilSpecProvider()
    # Entering a seed avoids randomness, allowing for testing using the same generated string
    provider.seed(8674083436421)    
    assert provider.cnpj() == '36.343.985/0001-24'

# Generated at 2022-06-12 01:16:53.881271
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert( cnpj.count(".") == 2 )
    assert( cnpj.count("/") == 1 )
    assert( cnpj.count("-") == 1 )
    assert( cnpj[0:2].isdigit() )
    assert( cnpj[3:6].isdigit() )
    assert( cnpj[7:10].isdigit() )
    assert( cnpj[11:15].isdigit() )
    assert( cnpj[16:18].isdigit() )
    assert( len(cnpj) == 18 )


# Generated at 2022-06-12 01:16:59.091379
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the method cpf"""

    from mimesis.builtins.br.providers import BrazilSpecProvider

    result = BrazilSpecProvider().cpf()

    try:
        print(result)
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-12 01:17:02.600853
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method BrazilSpecProvider.cpf."""
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf(with_mask=True)) == 14
    assert type(bsp.cpf(with_mask=False)) == str


# Generated at 2022-06-12 01:17:06.478927
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result = provider.cnpj()
    assert len(result) == 18
    assert result[2] == '.'
    assert result[6] == '.'
    assert result[10] == '/'
    assert result[15] == '-'

# Generated at 2022-06-12 01:17:07.829093
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    print(b.cpf())

# Generated at 2022-06-12 01:17:12.168594
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()

    cpf_without_mask = bsp.cpf(with_mask=False)
    assert len(cpf_without_mask) == 11
    assert cpf_without_mask.isdigit()

    cpf_with_mask = bsp.cpf(with_mask=True)
    assert len(cpf_with_mask) == 14
    assert '.' in cpf_with_mask
    assert '-' in cpf_with_mask


# Generated at 2022-06-12 01:18:29.102472
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brasilProvider = BrazilSpecProvider()
    cnpj = brasilProvider.cnpj()
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)
    assert isinstance(brasilProvider.cnpj(False), str)


# Generated at 2022-06-12 01:18:30.780008
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    res = provider.cnpj()
    assert isinstance(res, str)


# Generated at 2022-06-12 01:18:32.560195
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()

    assert cnpj is not None

# Generated at 2022-06-12 01:18:36.992267
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create a special data provider for Brazil using seed 42
    provider = BrazilSpecProvider(seed=42)
    # Generate a random cnpj
    provider.cnpj() == '77.732.230/0001-70'
    # Generate a random cnpj without mask
    provider.cnpj(with_mask=False) == '77732230000170'

# Generated at 2022-06-12 01:18:39.547677
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()
    result = bp.cpf(with_mask=False)
    assert len(result) == 11

# Generated at 2022-06-12 01:18:45.864122
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    _cnpj = BrazilSpecProvider()
    cnpj = _cnpj.cnpj()
    assert cnpj == _cnpj.cnpj(True)
    assert len(cnpj) == 18
    assert cnpj[2] == cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-12 01:18:47.356437
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == "819.896.447-00"


# Generated at 2022-06-12 01:18:51.604998
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for method cpf of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-12 01:18:56.251388
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider('seed')
    cnpj = brazil_provider.cnpj()
    assert cnpj == brazil_provider.cnpj()

# Generated at 2022-06-12 01:19:05.256588
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert type(provider.cnpj()) == str
    cpf = provider.cnpj()
    assert len(cpf) == 18
    assert cpf[2:3] == '.'
    assert cpf[6:7] == '.'
    assert cpf[10:11] == '/'
    assert cpf[15:16] == '-'
    assert type(provider.cnpj(with_mask=False)) == str
    cpf = provider.cnpj(with_mask=False)
    assert len(cpf) == 14

# Generated at 2022-06-12 01:22:19.205258
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    provider = BrazilSpecProvider()

    # Test True (with mask)
    seed = 'test_BrazilSpecProvider_cpf'

    result = provider.cpf(with_mask=True, seed=seed)
    expected = '064.577.033-89'

    assert result == expected, 'test_BrazilSpecProvider_cpf: True'

    # Test False (without mask)
    seed = 'test_BrazilSpecProvider_cpf'

    result = provider.cpf(with_mask=False, seed=seed)
    expected = '06457703389'

    assert result == expected, 'test_BrazilSpecProvider_cpf: False'


# Generated at 2022-06-12 01:22:20.616525
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    data = BrazilSpecProvider()
    print(data.cnpj(with_mask=False))
    print(data.cnpj(with_mask=True))


# Generated at 2022-06-12 01:22:23.141760
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Return a string"""
    cpf = BrazilSpecProvider().cpf()
    assert type(cpf) == str
    assert len(cpf) == 14


# Generated at 2022-06-12 01:22:27.832279
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf == '807.618.492-34'
    cpf = brazil.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf == '85318602870'
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf == '021.023.537-30'
    cpf = brazil.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf == '78137734787'
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf == '035.165.064-40'


# Generated at 2022-06-12 01:22:29.620516
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '001.137.297-40'


# Generated at 2022-06-12 01:22:32.439956
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
   brazil_spec_provider = BrazilSpecProvider()
   assert brazil_spec_provider.cnpj(with_mask=True)=='54.558.555/0015-62'


# Generated at 2022-06-12 01:22:34.627954
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    assert len(cpf) == 14

# Generated at 2022-06-12 01:22:36.366194
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj1 = BrazilSpecProvider().cnpj()
    test_cnpj = BrazilSpecProvider().cnpj(True)
    assert cnpj1 == test_cnpj

# Generated at 2022-06-12 01:22:39.854740
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print('Test cnpj method of BrazilSpecProvider class')
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print('---->', cnpj)
    assert(cnpj is not None)


# Generated at 2022-06-12 01:22:50.156250
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '02.832.294/0001-72'
    assert provider.cnpj() == '79.297.482/0001-79'
    assert provider.cnpj() == '57.238.045/0001-11'
    assert provider.cnpj() == '88.955.636/0001-98'
    assert provider.cnpj() == '97.367.067/0001-90'
    assert provider.cnpj() == '22.099.394/0001-68'
    assert provider.cnpj() == '12.916.315/0001-19'
    assert provider.cnpj() == '35.133.724/0001-40'