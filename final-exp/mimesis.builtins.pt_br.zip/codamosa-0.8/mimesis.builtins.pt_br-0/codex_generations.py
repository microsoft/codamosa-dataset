

# Generated at 2022-06-12 01:13:53.859700
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test if the method cnpj returns a valid CNPJ."""
    provider = BrazilSpecProvider()
    assert len(provider.cnpj()) == 14


# Generated at 2022-06-12 01:13:57.051353
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    result = provider.cnpj()
    # check if result is a string
    assert isinstance(result, str)
    # check if result is in the correct format
    assert result.count('-') == 1
    assert result.count('/') == 1
    assert result.count('.') == 2


# Generated at 2022-06-12 01:13:59.559293
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for _ in range(10):
        print(provider.cpf())


# Generated at 2022-06-12 01:14:03.813520
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  provider = BrazilSpecProvider()
  assert provider.cnpj() == '74.497.992/0001-74'
  assert provider.cnpj(with_mask=True) == '74.497.992/0001-74'


# Generated at 2022-06-12 01:14:09.060667
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf.count(".") == 3
    assert cpf.count("-") == 1


# Generated at 2022-06-12 01:14:10.596204
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14


# Generated at 2022-06-12 01:14:15.317557
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Testing method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    bsp.seed(100)
    assert bsp.cnpj() == '7773223000170'
    assert bsp.cnpj(True) == '77.732.230/0001-70'
    

# Generated at 2022-06-12 01:14:17.417233
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj1 = BrazilSpecProvider().cnpj()
    cnpj2 = BrazilSpecProvider().cnpj()
    assert cnpj1 != cnpj2


# Generated at 2022-06-12 01:14:22.333954
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=1)
    assert provider.cpf(with_mask=False) == '95955022002'
    assert provider.cpf(with_mask=True) == '959.550.220-02'


# Generated at 2022-06-12 01:14:25.358734
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf()."""
    cpf_number = BrazilSpecProvider().cpf()
    print(cpf_number)


# Generated at 2022-06-12 01:14:44.841274
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    provider_cnpj = BrazilSpecProvider()

    cnpj_mascara = provider_cnpj.cnpj()
    cnpj_sem_mascara = provider_cnpj.cnpj(False)

    assert len(cnpj_mascara) == 18
    assert len(cnpj_sem_mascara) == 14
    assert cnpj_mascara[2] == '.'
    assert cnpj_mascara[6] == '.'
    assert cnpj_mascara[10] == '/'
    assert cnpj_mascara[15] == '-'
    assert cnpj_sem_mascara[2] != '.'
    assert cnpj_sem_mascara[6] != '.'
    assert cnpj_sem_mascara

# Generated at 2022-06-12 01:14:53.662787
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    testClass = BrazilSpecProvider()
    resultado = 'a'
    while(resultado[3] != '.' or resultado[7] != '.' or resultado[11] != '-'):
        resultado = testClass.cpf()
        print(resultado)
        # print(resultado[3])
    assert resultado[3] == '.'
    assert resultado[7] == '.'
    assert resultado[11] == '-'


# Generated at 2022-06-12 01:15:03.526879
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the method cnpj of class BrazilSpecProvider.
    """
    # Get the length of an unmasked cnpj
    length = len(BrazilSpecProvider().cnpj(with_mask=False))

    # Test the method with correct and incorrect parameter for with_mask
    assert length == len(BrazilSpecProvider().cnpj(with_mask=True))
    assert length == len(BrazilSpecProvider().cnpj())
    assert type(BrazilSpecProvider().cnpj(with_mask=False)) == str
    assert type(BrazilSpecProvider().cnpj(with_mask=True)) == str
    assert type(BrazilSpecProvider().cnpj()) == str

    # Test the method with wrong parameter for with_mask

# Generated at 2022-06-12 01:15:09.730901
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print(cnpj)
    assert len(cnpj) == 14
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-12 01:15:12.093961
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BSP = BrazilSpecProvider()
    assert BSP.cnpj() == '80.997.592/0001-01'



# Generated at 2022-06-12 01:15:13.321268
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert bsp.cnpj()

# Generated at 2022-06-12 01:15:15.814543
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14


# Generated at 2022-06-12 01:15:23.456843
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider"""

    import pytest
    from mimesis.builtins import BrazilSpecProvider

    br_spec_provider = BrazilSpecProvider('pt-br')

    with pytest.raises(ValueError):
        br_spec_provider.cpf('fail')

    cpf = br_spec_provider.cpf()
    assert len(cpf) == 14
    assert isinstance(cpf, str)

    cpf = br_spec_provider.cpf(False)
    assert len(cpf) == 11
    assert isinstance(cpf, str)


# Generated at 2022-06-12 01:15:31.901418
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj method."""
    from re import compile as make_regex

    bsp = BrazilSpecProvider()
    cnpj_regex = make_regex(r'^\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}$')
    assert cnpj_regex.match(bsp.cnpj())
    assert len(bsp.cnpj(with_mask=False)) == 14


# Generated at 2022-06-12 01:15:35.686970
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    assert br.cpf(with_mask=False)
    assert br.cpf(with_mask=True)



# Generated at 2022-06-12 01:15:54.235887
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    all_ok = True
    for i in range(100):
        # A CPF number has 11 digits.
        cpf = BrazilSpecProvider().cpf(False)
        if len(cpf) != 11:
            print("ERROR: CPF do not have 11 digits")
            all_ok = False

        # A CPF number has 11 digits and each digit is different of zero.
        # If a digit is zero, then the test will pass because we generate all
        # possible CPF numbers.

# Generated at 2022-06-12 01:15:57.751856
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf(with_mask=False) == '22859565204'
    assert bsp.cpf(with_mask=True) == '228.595.652-04'


# Generated at 2022-06-12 01:16:01.198153
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert result == '003.440.814-67'

    result = provider.cpf()
    assert result == '001.137.297-40'


# Generated at 2022-06-12 01:16:03.758381
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_data = BrazilSpecProvider()
    cpf = brazil_data.cpf()
    assert len(cpf) == 14

# Generated at 2022-06-12 01:16:09.712240
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """ checks if the function cnpj generates a valid cnpj. """
    # just run the function once
    cnpj = BrazilSpecProvider().cnpj()
    # strip the cnpj of all chars except digits
    cnpj = [int(d) for d in cnpj if d.isdigit()]
    # some assertions
    assert len(cnpj) == 14, "cnpj length should be 14"
    assert cnpj[0] != 0, "cnpj should not start with 0"
    assert cnpj[1] != 0, "cnpj should not start with 0"
    
    # get first and second dv
    first_dv = cnpj[-2]
    second_dv = cnpj[-1]

    # remove both dv from the cnpj before

# Generated at 2022-06-12 01:16:13.618177
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=True) == '187.874.746-05'
    assert provider.cpf(with_mask=False) == '18787474605'


# Generated at 2022-06-12 01:16:18.229519
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    Test method cpf of the class BrazilSpecProvider
    """

    assert BrazilSpecProvider().cpf() == BrazilSpecProvider().cpf()
    assert BrazilSpecProvider().cpf(with_mask=True) != BrazilSpecProvider().cpf(with_mask=True)


# Generated at 2022-06-12 01:16:22.847176
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj."""
    from mimesis.providers.brazil import BrazilSpecProvider
    br = BrazilSpecProvider()
    created_cnpj = br.cnpj()
    print(created_cnpj)



# Generated at 2022-06-12 01:16:27.047030
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider."""

    bsp = BrazilSpecProvider()

    cnpj = bsp.cnpj()
    expected = ''.join(cnpj.split('.'))
    expected = ''.join(expected.split('/'))
    expected = ''.join(expected.split('-'))

    assert len(expected) == 14

    #assert expectedesg[]

# Generated at 2022-06-12 01:16:31.345975
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    prov = BrazilSpecProvider()
    cpf = prov.cpf()
    assert prov.censor.validate(cpf, 'cpf')
    assert isinstance(cpf, str)
    assert len(cpf) == 14


# Generated at 2022-06-12 01:17:00.877196
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj()


# Generated at 2022-06-12 01:17:11.169215
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider as BuiltInBrazilSpecProvider
    from mimesis.builtins import BrazilSpecProvider as BuiltInBrazilSpecProvider

    brazil_sp = BrazilSpecProvider()
    print(brazil_sp.cnpj())

    # Test if the method cnpj of class BrazilSpecProvider returns a valid CNPJ
    brazil_sp = BrazilSpecProvider()
    assert BuiltInBrazilSpecProvider.is_valid_cnpj(brazil_sp.cnpj())
    # Test if the method cnpj of class BrazilSpecProvider returns a valid CNPJ without mask
    brazil_sp = BrazilSpecProvider()
    assert BuiltInBrazilSpecProvider.is_valid_cnpj

# Generated at 2022-06-12 01:17:14.279708
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14
    assert BrazilSpecProvider().cpf(with_mask=False) == BrazilSpecProvider().cpf(with_mask=True).replace(".", "").replace("-", "")


# Generated at 2022-06-12 01:17:17.398064
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf) == 11
    assert BrazilSpecProvider().cpf_validator(cpf)


# Generated at 2022-06-12 01:17:29.144555
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    assert provider.cnpj() == '20.010.336/0001-61'

    assert provider.cnpj() == '67.554.907/0001-56'

    assert provider.cnpj() == '76.749.176/0001-43'

    assert provider.cnpj() == '49.543.528/0001-91'

    assert provider.cnpj() == '59.902.942/0001-34'

    assert provider.cnpj() == '66.704.164/0001-02'

    assert provider.cnpj() == '83.839.812/0001-75'

    assert provider.cnpj() == '58.976.931/0001-77'


# Generated at 2022-06-12 01:17:32.998286
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    """ Unit test for method cnpj of class BrazilSpecProvider """

    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-12 01:17:37.548015
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_cpf = BrazilSpecProvider()
    for _ in range(5):
        assert len(brazil_cpf.cpf(with_mask=False)) == 11
        assert len(brazil_cpf.cpf(with_mask=True)) == 14



# Generated at 2022-06-12 01:17:42.487323
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from re import match

    provider= BrazilSpecProvider()
    cnpj = provider.cnpj()

    assert type(cnpj) is str
    assert match(r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}', cnpj) is not None


# Generated at 2022-06-12 01:17:47.990972
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_cpf_without_mask = BrazilSpecProvider(seed=42).cpf(with_mask=False)
    brazil_cpf_with_mask = BrazilSpecProvider(seed=42).cpf(with_mask=True)
    assert brazil_cpf_without_mask == '73485394301'
    assert brazil_cpf_with_mask == '734.853.943-01'


# Generated at 2022-06-12 01:17:50.666402
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf(False)) == 11


# Generated at 2022-06-12 01:18:59.274067
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.local import BrazilSpecProvider
    # get
    brazil = BrazilSpecProvider()
    # make
    cpf1 = brazil.cpf()
    cpf2 = brazil.cpf(with_mask=False)

    # test
    assert brazil.cpf.__doc__ is not None
    assert isinstance(cpf1, str)
    assert cpf2 == cpf1.replace('.', '').replace('-', '')


# Generated at 2022-06-12 01:19:09.263582
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.person.en import Person
    person = Person('pt-br')
    from mimesis.providers.address.en import Address
    address = Address('pt-br')

    from mimesis.providers.internet.en import Internet
    internet = Internet('pt-br')
    from mimesis.providers.business.en import Business
    business = Business('pt-br')
    from mimesis.providers.datetime.en import Datetime
    datetime = Datetime('pt-br')
    from mimesis.providers.misc.en import Misc
    misc = Misc('pt-br')

    cpfs = []
    max_cpfs = 10000
    fake_cpfs = 0

    for cpf in range(max_cpfs):
        cpf = person.cpf()


# Generated at 2022-06-12 01:19:12.414905
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(with_mask=False) == "87732302000170"


# Generated at 2022-06-12 01:19:20.660526
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br_valid_cnpj_1 = '07.353.809/0001-04'
    br_valid_cnpj_2 = '25.974.955/0001-36'
    br_valid_cnpj_3 = '15.873.183/0001-40'
    br_valid_cnpj_4 = '45.633.545/0001-10'
    br_valid_cnpj_5 = '01.646.292/0001-54'
    br_valid_cnpj_6 = '75.266.942/0001-08'
    br_valid_cnpj_7 = '34.347.859/0001-96'
    br_valid_cnpj_8 = '46.101.548/0001-84'
    br_valid_cnpj_

# Generated at 2022-06-12 01:19:25.379850
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    cnpj = br.cnpj()
    assert len(cnpj) == 18
    assert (cnpj.find('.') > 0)
    assert (cnpj.find('-') > 0)
    assert (cnpj.find('/') > 0)


# Generated at 2022-06-12 01:19:28.225350
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method BrazilSpecProvider.cpf."""
    prov = BrazilSpecProvider()
    cpf = prov.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-12 01:19:34.906938
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Testing BrazilSpecProvider class method cpf."""
    bz = BrazilSpecProvider()
    data = list()
    for i in range(100):
        cpf = bz.cpf(with_mask=False)
        assert len(cpf) == 11 and cpf.isnumeric()
        data.append(cpf)
    assert len(set(data)) == len(data)


# Generated at 2022-06-12 01:19:37.493302
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    data = BrazilSpecProvider()
    assert len(data.cnpj()) == 18

# Generated at 2022-06-12 01:19:38.636897
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=0)
    assert provider.cpf(with_mask=True) == "003.282.882-19"


# Generated at 2022-06-12 01:19:41.161921
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj method.

    Check for invalid CNPJ.
    """
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask = True)
    assert len(cnpj) != 14


# Generated at 2022-06-12 01:22:40.377025
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    print(cpf)


# Generated at 2022-06-12 01:22:50.154091
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method validate_cpf of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()

    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-12 01:22:56.822705
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    This unit test test the method cpf() of class BrazilSpecProvider.

    This unit test is designed to test if the random CPF generated by
    the method cpf() of class BrazilSpecProvider, is in the format of
    ###.###.###-## and also, if the penultimate digit of the generated
    CPF is the verifying digit of CPF
    """
    def get_verifying_digit_cpf(cpf, peso):
        """Calculate the verifying digit for the CPF.

        :param cpf: List of integers with the CPF.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CPF.
        """
        soma = 0

# Generated at 2022-06-12 01:22:57.676486
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider(seed=1)
    print(bp.cpf())


# Generated at 2022-06-12 01:23:02.656163
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    if cnpj[2] == '.' and cnpj[6] == '.' and cnpj[10] == '/' and cnpj[15]=='-':
        print("cnpj() is ok")
    else:
        print("cnpj() is wrong")


# Generated at 2022-06-12 01:23:04.027438
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    assert obj.cpf() == '717.927.918-44'


# Generated at 2022-06-12 01:23:10.039716
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    from mimesis import BrazilSpecProvider
    from re import match

    spec_provider = BrazilSpecProvider()
    result = spec_provider.cnpj()

    assert match(r'^\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}$', result)


# Generated at 2022-06-12 01:23:19.831564
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    Test cpf method.
    """
    br_provider = BrazilSpecProvider()
    assert isinstance(br_provider.cpf(), str)
    assert len(br_provider.cpf()) == 14
    assert br_provider.cpf() == '859.066.428-57'
    assert all(br_provider.cpf()[i] == '.' if i in [3, 7]
               else br_provider.cpf()[i] == '-' if i == 11
               else br_provider.cpf()[i].isdigit()
               for i in range(len(br_provider.cpf())))
    assert len(br_provider.cpf(with_mask=False)) == 11

# Generated at 2022-06-12 01:23:26.477843
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Teste 1
    from mimesis.builtins import BrazilSpecProvider
    brazil = BrazilSpecProvider()
    print(brazil.cpf())
    assert len(brazil.cpf()) == 14
    assert brazil.cpf().count('.') == 2
    assert brazil.cpf().count('-') == 1
    # Teste 2
    print(brazil.cpf(False))
    assert len(brazil.cpf(False)) == 11


# Generated at 2022-06-12 01:23:30.939870
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # With mask
    provider = BrazilSpecProvider()
    cpf_1 = provider.cpf(True)
    assert len(cpf_1) == 14
    assert isinstance(cpf_1, str)
    assert cpf_1[3] == '.'
    assert cpf_1[7] == '.'
    assert cpf_1[11] == '-'
    # Without mask
    cpf_2 = provider.cpf(False)
    assert len(cpf_2) == 11
    assert isinstance(cpf_2, str)
    assert cpf_2[3] != '.'
    assert cpf_2[7] != '.'
    assert cpf_2[11] != '-'
