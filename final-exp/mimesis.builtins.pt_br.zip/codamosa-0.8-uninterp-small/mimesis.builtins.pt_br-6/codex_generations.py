

# Generated at 2022-06-25 19:55:01.381250
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    string_0 = brazil_spec_provider_0.cnpj()
    print(string_0)


# Generated at 2022-06-25 19:55:06.100348
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    print(brazil_spec_provider_0.cpf())
    print(brazil_spec_provider_0.cpf())
    print(brazil_spec_provider_0.cpf())
    print(brazil_spec_provider_0.cpf(False))


# Generated at 2022-06-25 19:55:11.484262
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_cases = [
        dict(
            with_mask=True,
            expected='152.913.575-14',
        ),
        dict(
            with_mask=False,
            expected='15291357514',
        ),
    ]
    for test_case in test_cases:
        result = BrazilSpecProvider.cpf(**test_case)
        assert result == test_case['expected']


# Generated at 2022-06-25 19:55:18.711517
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    # Test 1 - Value of parameter with_mask equal to True
    result = brazil_spec_provider.cnpj()
    assert len(result.split('.')) == 3 and len(result.split('/')) == 2 and len(result.split('-')) == 2
    # Test 2 - Value of parameter with_mask equal to False
    result = brazil_spec_provider.cnpj(with_mask=False)
    assert len(result) == 14


# Generated at 2022-06-25 19:55:28.556016
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = 'test BrazilSpecProvider cnpj'
    brazil_spec_provider = BrazilSpecProvider(seed=seed)

    assert brazil_spec_provider.cnpj() == '95.484.568/0001-23'
    assert brazil_spec_provider.cnpj() == '21.064.485/0001-54'
    assert brazil_spec_provider.cnpj(with_mask=False) == '53033135000134'
    assert brazil_spec_provider.cnpj() == '00.077.856/0001-27'
    assert brazil_spec_provider.cnpj() == '39.972.726/0001-55'

# Generated at 2022-06-25 19:55:31.774851
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilSpecProvider = BrazilSpecProvider()
    cnpj = brazilSpecProvider.cnpj()
    assert (len(cnpj) == 18 and cnpj[2] == '.' and cnpj[6] == '.' and
            cnpj[10] == '/' and cnpj[15] == '-')

# Generated at 2022-06-25 19:55:34.862629
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf()) == 14
    assert len(brazil_spec_provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-25 19:55:39.201458
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    '''
    Check the method cnpj of class BrazilSpecProvider.
    '''
    brazil_sp_instance_0 = BrazilSpecProvider(2)

    assert brazil_sp_instance_0.cnpj(False) == '27960704000121'
    assert brazil_sp_instance_0.cnpj(True) == '27.960.704/0001-21'


# Generated at 2022-06-25 19:55:43.069533
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Result is string
    result = BrazilSpecProvider().cpf()
    assert type(result) == str

    # Regex for CPF mask
    result = BrazilSpecProvider().cpf()
    assert re.search("\d{3}.\d{3}.\d{3}-\d{2}", result)


# Generated at 2022-06-25 19:55:45.485528
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj_str = brazil_spec_provider.cnpj()
    assert len(cnpj_str) == 18


# Generated at 2022-06-25 19:56:00.226206
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == '163.454.826-42'

    brazil_spec_provider_1 = BrazilSpecProvider(seed=1)
    assert brazil_spec_provider_1.cpf() == '489.243.257-19'

    brazil_spec_provider_2 = BrazilSpecProvider(seed=3)
    assert brazil_spec_provider_2.cpf() == '460.056.898-52'

    brazil_spec_provider_3 = BrazilSpecProvider(seed=2)
    assert brazil_spec_provider_3.cpf() == '244.263.085-42'

# Generated at 2022-06-25 19:56:08.580617
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj(with_mask=False)) == 14
    assert brazil_spec_provider.cnpj(with_mask=False)[12:14].isdigit()
    assert len(brazil_spec_provider.cnpj(with_mask=True)) == 18
    assert brazil_spec_provider.cnpj(with_mask=True)[14:18].isdigit()



# Generated at 2022-06-25 19:56:17.518076
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_0.cnpj(with_mask=False)
    assert int(cnpj)

    brazil_spec_provider_1 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_1.cnpj(with_mask=False)
    assert int(cnpj)

    brazil_spec_provider_2 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_2.cnpj(with_mask=False)
    assert int(cnpj)

    brazil_spec_provider_3 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_3.cnpj(with_mask=False)

# Generated at 2022-06-25 19:56:22.143735
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_str_0 = brazil_spec_provider_0.cpf(seed=25280)
    assert cpf_str_0 == '187.199.936-04'


# Generated at 2022-06-25 19:56:26.203518
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-25 19:56:30.978548
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_0.cnpj()
    str_2 = brazil_spec_provider_0.cnpj()
    str_3 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:56:34.086122
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    generated_cpf = BrazilSpecProvider().cpf(with_mask = False)
    assert generated_cpf.replace('.', '').replace('-', '').isdigit() and len(generated_cpf) == 11


# Generated at 2022-06-25 19:56:38.126390
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_cpf = BrazilSpecProvider().cpf()
    assert len(brazil_cpf) == 14
    assert brazil_cpf[3] == '.'
    assert brazil_cpf[7] == '.'
    assert brazil_cpf[11] == '-'


# Generated at 2022-06-25 19:56:42.022339
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj(1) == '331.071.108/8884-63'


# Generated at 2022-06-25 19:56:48.939426
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    def verify_cpf(cpf):
        """Validate the cpf.

        :param cpf: CPF to validate.
        :returns: Verification of the CPF.
        """
        if len(cpf) > 14:
            return False
        cpf = cpf.replace('.', '')
        cpf = cpf.replace('-', '')
        if len(cpf) > 11:
            return False
        if len(cpf) < 11:
            return False
        cpf_without_dv = cpf[:9]
        cpf_without_dv = ''.join(str(i) for i in cpf_without_dv)
        first_dv = int(cpf[9])
        second_dv = int(cpf[10])
        first_dv

# Generated at 2022-06-25 19:57:03.824379
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:57:06.121596
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cpf() == '541.254.203-23'


# Generated at 2022-06-25 19:57:07.412095
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    pass


# Generated at 2022-06-25 19:57:10.211446
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == '645.904.419-32'


# Generated at 2022-06-25 19:57:13.061598
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider.cpf(BrazilSpecProvider(), False) is not None
    assert len(BrazilSpecProvider.cpf(BrazilSpecProvider(), False)) == 11


# Generated at 2022-06-25 19:57:18.663479
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create an instance of BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()
    # Create an instance of BrazilSpecProvider using seed '123'
    brazil_spec_provider_0 = BrazilSpecProvider(seed=123)

    # Call method cnpj in class BrazilSpecProvider
    cnpj = brazil_spec_provider.cnpj()
    # Call method cnpj in class BrazilSpecProvider
    cnpj_0 = brazil_spec_provider_0.cnpj()



# Generated at 2022-06-25 19:57:23.900508
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for i in range(10):
        brazil_spec_provider_cpf_0 = BrazilSpecProvider()
        brazil_spec_provider_cpf_0_result = brazil_spec_provider_cpf_0.cpf()
        assert brazil_spec_provider_cpf_0_result != ''


# Generated at 2022-06-25 19:57:27.521282
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj()) == 18
    assert len(brazil_spec_provider.cnpj(with_mask = False)) == 14
    

# Generated at 2022-06-25 19:57:30.426174
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result = brazil_spec_provider_0.cpf(with_mask = False)
    assert len(result) == 11 and type(result) is str


# Generated at 2022-06-25 19:57:32.046084
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '27.872.933/0001-34'


# Generated at 2022-06-25 19:57:59.621394
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider.cpf(BrazilSpecProvider, True)
    assert BrazilSpecProvider.cpf(BrazilSpecProvider, False)


# Generated at 2022-06-25 19:58:01.597301
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj()


# Generated at 2022-06-25 19:58:09.135109
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test cpf method of the BrazilSpecProvider class
    brazil_spec_provider_1 = BrazilSpecProvider()
    cpf = brazil_spec_provider_1.cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    with_mask = brazil_spec_provider_1.cpf(with_mask=False)
    assert isinstance(with_mask, str)
    assert len(with_mask) == 11
    print('with_mask: ', with_mask)
    print('cpf: ', cpf)



# Generated at 2022-06-25 19:58:14.225756
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf(with_mask=True) == "164.781.115-79"
    assert brazil_spec_provider.cpf(with_mask=True) == "002.563.366-16"
    assert brazil_spec_provider.cpf(with_mask=True) == "490.437.124-32"
    assert brazil_spec_provider.cpf(with_mask=True) == "871.324.253-97"
    assert brazil_spec_provider.cpf(with_mask=True) == "044.754.825-68"


# Generated at 2022-06-25 19:58:21.381707
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj_0 = brazil_spec_provider_0.cnpj()
    assert len(cnpj_0) == 14
    assert cnpj_0[2] == '.'
    assert cnpj_0[6] == '.'
    assert cnpj_0[10] == '/'
    assert cnpj_0[12] == '-'


# Generated at 2022-06-25 19:58:23.737568
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf(True) == "908.957.320-70"



# Generated at 2022-06-25 19:58:27.164963
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    if BrazilSpecProvider.cnj(True) is not None:
        if BrazilSpecProvider.cnj(False) is not None:
            return True
        return False
    return False


# Generated at 2022-06-25 19:58:29.753603
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    return_value_0 = BrazilSpecProvider().cnpj()
    assert isinstance(return_value_0, str)


# Generated at 2022-06-25 19:58:34.386827
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cnpj()
    brazil_spec_provider_0.cnpj(with_mask=False)
    brazil_spec_provider_0.cnpj(with_mask=True)



# Generated at 2022-06-25 19:58:37.034071
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider_0.cpf()
    assert cpf_0 == '033.580.758-96'


# Generated at 2022-06-25 19:59:48.134925
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf = brazil_spec_provider_0.cpf()
    result = len(cpf)
    assert result == 14


# Generated at 2022-06-25 19:59:49.208458
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert True


# Generated at 2022-06-25 19:59:51.269193
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    brazil_provider.cpf()
    brazil_provider.cpf(False)



# Generated at 2022-06-25 19:59:58.961461
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_cpf_0 = BrazilSpecProvider()
    cpf = brazil_spec_provider_cpf_0.cpf()
    print("cpf " + cpf)
    expected = True
    count = 0
    for i in cpf:
        if i == '.' or i == '-':
            count += 1
    if count == 2:
        actual = True
        assert expected == actual
    else:
        actual = False
        assert expected == actual


# Generated at 2022-06-25 20:00:01.373916
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert BrazilSpecProvider().cnpj()[:4] == '0527'


# Generated at 2022-06-25 20:00:06.138625
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    for _ in range(100):
        print(brazil_spec_provider_0.cpf(False))



# Generated at 2022-06-25 20:00:09.373074
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_0.cnpj(False)
    assert len(cnpj) == 14


# Generated at 2022-06-25 20:00:15.624280
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_result = brazil_spec_provider_0.cpf()

    def cpf_aux(cpf):
        cpf_number = [int(digit) for digit in cpf]
        first_digit = cpf_number[9]
        second_digit = cpf_number[10]

        def get_verifying_digit_cpf(cpf, peso):
            soma = 0
            for index, digit in enumerate(cpf):
                soma += digit * (peso - index)
            resto = soma % 11
            if resto == 0 or resto == 1 or resto >= 11:
                return 0
            return 11 - resto


# Generated at 2022-06-25 20:00:18.678931
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == '383.937.829-49'



# Generated at 2022-06-25 20:00:22.214821
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf_ret = brazil_spec_provider.cpf()
    assert len(cpf_ret) == 14
    cpf_ret = brazil_spec_provider.cpf(with_mask = False)
    assert len(cpf_ret) == 11


# Generated at 2022-06-25 20:02:49.570371
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf_1 = brazil_spec_provider.cpf(with_mask=False)
    assert len(cpf_1) == 11
    cpf_2 = brazil_spec_provider.cpf(with_mask=True)
    assert len(cpf_2) == 14



# Generated at 2022-06-25 20:02:52.382082
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    result = brazil_spec_provider.cnpj()
    assert result


# Generated at 2022-06-25 20:02:57.203983
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert type(brazil_spec_provider_0.cpf(True)) == str


# Generated at 2022-06-25 20:02:59.552637
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cpf(True) == "718.547.968-80"


# Generated at 2022-06-25 20:03:06.938799
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():    
    brazil_spec_provider = BrazilSpecProvider()

    result1 = brazil_spec_provider.cnpj(with_mask=True)
    result2 = brazil_spec_provider.cnpj(with_mask=False)

    assert len(result1) == 18
    assert len(result2) == 14
    assert (result1[:2]).isdigit() == True
    assert (result2[:2]).isdigit() == True
    assert (result1[2:5]).isdigit() == True
    assert (result2[2:5]).isdigit() == True
    assert (result1[5:8]).isdigit() == True
    assert (result2[5:8]).isdigit() == True
    assert (result1[8:12]).isdigit() == True
   

# Generated at 2022-06-25 20:03:09.104803
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    result = brazil_spec_provider_0.cnpj()
    assert len(result) == 18
    assert type(result) is str


# Generated at 2022-06-25 20:03:14.540681
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_0 = BrazilSpecProvider().cpf()
    assert len(cpf_0.split('.')) == 3
    print(cpf_0)
    cpf_1 = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf_1.split('.')) != 3
    print(cpf_1)



# Generated at 2022-06-25 20:03:20.549047
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_cpf = BrazilSpecProvider()

    result = {'cpf': brazil_spec_provider_cpf.cpf()}

    assert len(result['cpf']) == 14, 'Length of the result should be 14'
    assert '/' not in result['cpf'], 'The result should not contain \"/\" character'
    assert '-' in result['cpf'], 'The result should contain \"-\" character'
    assert '.' in result['cpf'], 'The result should contain \".\" character'
    assert ' ' not in result['cpf'], 'The result should not contain \" \" character'


# Generated at 2022-06-25 20:03:21.888732
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cnpj()) == 18


# Generated at 2022-06-25 20:03:25.870689
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert re.match("\d{3}.\d{3}.\d{3}-\d{2}", brazil_spec_provider.cpf())
