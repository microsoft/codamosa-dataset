

# Generated at 2022-06-25 19:55:02.841652
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    # The type of the method cnpj of BrazilSpecProvider must be str
    assert isinstance(brazil_spec_provider_0.cnpj(), str)


# Generated at 2022-06-25 19:55:04.255039
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_0 = BrazilSpecProvider().cpf()
    assert cpf_0 != None


# Generated at 2022-06-25 19:55:07.346793
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
   brazil_spec_provider = BrazilSpecProvider()
   string = brazil_spec_provider.cpf()
   assert (string[3] == '.')
   assert (string[7] == '.')
   assert (string[11] == '-')


# Generated at 2022-06-25 19:55:10.072620
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert len(brazil_spec_provider_1.cnpj()) == 18


# Generated at 2022-06-25 19:55:12.788500
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    print("" + str_0 + "")


# Generated at 2022-06-25 19:55:14.489936
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    str_0 = BrazilSpecProvider().cnpj()
    assert str_0 == '33.192.298/0001-17'


# Generated at 2022-06-25 19:55:19.050462
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14
    assert str_0.count('.') == 2
    assert str_0.count('-') == 1


# Generated at 2022-06-25 19:55:27.856458
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import pytest
    from mimesis.enums import Gender

    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cnpj()
    assert (str_0.count('-') == 1 and len(str_0) == 14)
    assert (str_1.count('-') == 1 and len(str_1) == 18)
    str_2 = brazil_spec_provider_0.cnpj(with_mask=False)
    assert str_2.count('-') == 0 and len(str_2) == 14


# Generated at 2022-06-25 19:55:29.612599
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cpf()



# Generated at 2022-06-25 19:55:32.126313
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14


# Generated at 2022-06-25 19:55:52.443094
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert cnpj.count('.') == 2
    cnpj = cnpj.replace('.', '')
    cnpj = cnpj.replace('/', '')
    cnpj = cnpj.replace('-', '')
    assert len(cnpj) == 14
    assert cnpj.isdigit()


# Generated at 2022-06-25 19:55:54.167116
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()



# Generated at 2022-06-25 19:56:01.299787
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider_cnpj_0 = BrazilSpecProvider().cnpj()
    assert isinstance(brazil_provider_cnpj_0, str)
    assert len(brazil_provider_cnpj_0) == 18
    assert brazil_provider_cnpj_0[2] == '.'
    assert brazil_provider_cnpj_0[6] == '.'
    assert brazil_provider_cnpj_0[10] == '/'
    assert brazil_provider_cnpj_0[15] == '-'


# Generated at 2022-06-25 19:56:06.716455
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Setup
    brazil_spec_provider_0 = BrazilSpecProvider()
    with_mask_0 = bool()

    # Testing
    str_0 = brazil_spec_provider_0.cnpj(with_mask_0)
    

# Generated at 2022-06-25 19:56:14.350267
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf(with_mask=False)
    str_1 = brazil_spec_provider_0.cpf(with_mask=False)
    str_2 = brazil_spec_provider_0.cpf(with_mask=False)
    str_3 = brazil_spec_provider_0.cpf(with_mask=False)
    str_4 = brazil_spec_provider_0.cpf(with_mask=False)
    str_5 = brazil_spec_provider_0.cpf(with_mask=False)
    str_6 = brazil_spec_provider_0.cpf(with_mask=False)
    str_7 = brazil_

# Generated at 2022-06-25 19:56:19.374047
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0.isalnum()
    assert len(str_0) == 14
    

# Generated at 2022-06-25 19:56:23.890293
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(100):
        brazil_spec_provider_0 = BrazilSpecProvider()
        str_0 = brazil_spec_provider_0.cnpj()
        assert str_0 is not None
        assert '.' in str_0
        assert '/' in str_0
        assert '-' in str_0


# Generated at 2022-06-25 19:56:30.514435
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    if brazil_spec_provider_0.cpf() == '222.446.818-85' and brazil_spec_provider_0.cpf() == '222.446.818-85':
        return True
    else:
        return False


# Generated at 2022-06-25 19:56:34.010021
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert isinstance(str_0, str)
    assert str_0 == '987.653.210-85'


# Generated at 2022-06-25 19:56:38.054102
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for cpf of module mimesis.providers.brazil_provider."""
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert isinstance(str_0, str) == 1


# Generated at 2022-06-25 19:57:09.492724
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:57:11.735166
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:57:14.253332
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:57:16.279878
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf()) == 14


# Generated at 2022-06-25 19:57:18.207370
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf() == brazil_spec_provider.cpf()


# Generated at 2022-06-25 19:57:28.418451
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    bool_0 = brazil_spec_provider_0.cnpj()
    bool_0 = brazil_spec_provider_0.cnpj()
    bool_0 = brazil_spec_provider_0.cnpj()
    bool_0 = brazil_spec_provider_0.cnpj()
    bool_0 = brazil_spec_provider_0.cnpj()
    bool_0 = brazil_spec_provider_0.cnpj()
    bool_0 = brazil_spec_provider_0.cnpj()
    bool_0 = brazil_spec_provider_0.cnpj()
    bool_0 = brazil_spec_provider_0.cnpj()
    bool_

# Generated at 2022-06-25 19:57:32.745625
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Arrange
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = False
    str_1 = True

    # Act
    # Assert
    assert len(brazil_spec_provider.cnpj(str_0)) == 14
    assert len(brazil_spec_provider.cnpj(str_1)) == 18


# Generated at 2022-06-25 19:57:34.267322
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(seed=47)
    assert brazil_spec_provider_0.cpf(with_mask=True) is None
    assert brazil_spec_provider_0.cpf(with_mask=False) is None


# Generated at 2022-06-25 19:57:36.257389
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert True


# Generated at 2022-06-25 19:57:37.816682
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print(BrazilSpecProvider().cnpj())
    print(BrazilSpecProvider().cnpj(with_mask=False))


# Generated at 2022-06-25 19:58:45.885289
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf(False)
    str_2 = brazil_spec_provider_0.cpf(True)


# Generated at 2022-06-25 19:58:49.150461
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf()
    assert len(str_1) == 14


# Generated at 2022-06-25 19:58:52.628397
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    with open("test_BrazilSpecProvider_cpf.txt") as file:
        for i in range(10):
            assert brazil_spec_provider_0.cpf() in file.read()


# Generated at 2022-06-25 19:58:55.038448
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()



# Generated at 2022-06-25 19:58:57.612200
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = 123
    expected_result = "001.137.297-40"
    actual_result = BrazilSpecProvider(seed=seed).cpf()
    assert expected_result == actual_result


# Generated at 2022-06-25 19:58:59.173216
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf()) == 14


# Generated at 2022-06-25 19:59:05.117846
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    brazil_spec_provider_0 = BrazilSpecProvider(seed=0)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '259.075.018-78'
    str_1 = brazil_spec_provider_0.cpf()
    assert str_1 == '259.075.018-78'
    str_2 = brazil_spec_provider_0.cpf(with_mask=False)
    assert str_2 == '2590750187'
    str_3 = brazil_spec_provider_0.cpf()
    assert str_3 == '259.075.018-78'

# Generated at 2022-06-25 19:59:07.789183
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    
    # Setup
    brazil_spec_provider_0 = BrazilSpecProvider()

    # Assert
    assert isinstance(brazil_spec_provider_0.cnpj(), str,
                      "Return type mismatch")



# Generated at 2022-06-25 19:59:09.445127
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cpf()) == 14


# Generated at 2022-06-25 19:59:11.024335
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()

# Generated at 2022-06-25 20:01:58.707471
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert isinstance(cnpj, str)


# Generated at 2022-06-25 20:02:00.660069
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import pytest
    assert '0' in BrazilSpecProvider().cpf()
    with pytest.raises(TypeError):
        BrazilSpecProvider().cpf(1234)


# Generated at 2022-06-25 20:02:06.228085
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    spec_provider = BrazilSpecProvider(seed=42)

    # Test case 0
    result = spec_provider.cpf()
    assert result == '003.831.658-08'

    # Test case 1
    result = spec_provider.cpf()
    assert result == '859.865.787-23'

    # Test case 2
    result = spec_provider.cpf(with_mask=False)
    assert result == '4921880220'

    # Test case 3
    result = spec_provider.cpf(with_mask=False)
    assert result == '0641075644'

    # Test case 4
    result = spec_provider.cpf()
    assert result == '364.928.948-61'

    # Test case 5
    result = spec_prov

# Generated at 2022-06-25 20:02:07.779064
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    assert type(a.cpf()) == str


# Generated at 2022-06-25 20:02:09.130743
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()

# Generated at 2022-06-25 20:02:10.941396
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 20:02:12.358470
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert isinstance(brazil_spec_provider.cnpj(), str)


# Generated at 2022-06-25 20:02:13.759851
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str = brazil_spec_provider.cpf()

# Generated at 2022-06-25 20:02:15.015665
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-25 20:02:17.886322
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()

