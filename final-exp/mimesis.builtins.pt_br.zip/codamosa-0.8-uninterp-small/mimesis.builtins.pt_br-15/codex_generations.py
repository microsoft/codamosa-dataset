

# Generated at 2022-06-25 19:55:03.509613
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Generate a valid CNPJ."""
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert isinstance(brazil_spec_provider_1.cnpj(), str)


# Generated at 2022-06-25 19:55:05.375919
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:55:09.355353
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert cnpj in ['04.094.962/0001-50', '21.002.094/0001-80', '57.388.513/0001-35']


# Generated at 2022-06-25 19:55:12.299372
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(False) == '22380034005606'
    assert BrazilSpecProvider().cnpj(True) == '22.380.034/0056-06'


# Generated at 2022-06-25 19:55:21.615944
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # test for default case
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'

    # test for with_mask = False
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cnpj(with_mask=False) == '77732230000170'

    # test for with_mask = True
    brazil_spec_provider_2 = BrazilSpecProvider()
    assert brazil_spec_provider_2.cnpj(with_mask=True) == '77.732.230/0001-70'
    pass


# Generated at 2022-06-25 19:55:25.418563
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    cpf_0 = BrazilSpecProvider().cpf()
    assert len(cpf_0) == 14
    assert cpf_0[3] == "."
    assert cpf_0[7] == "."
    assert cpf_0[11] == "-"


# Generated at 2022-06-25 19:55:28.109482
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_1.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-25 19:55:30.939485
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_2 = BrazilSpecProvider()
    brazil_spec_provider_1.cpf()
    brazil_spec_provider_2.cpf()


# Generated at 2022-06-25 19:55:32.778673
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_1.cpf()


# Generated at 2022-06-25 19:55:36.892337
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_1.random.seed(1701)
    expected_cnpj = '77732230001770'
    assert brazil_spec_provider_1.cnpj(False) == expected_cnpj
    

# Generated at 2022-06-25 19:55:48.748600
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    result_1 = brazil_spec_provider_1.cnpj(True)
    brazil_spec_provider_2 = BrazilSpecProvider()
    result_2 = brazil_spec_provider_2.cnpj(True)
    assert len(result_1) == 18 and len(result_2) == 18 and type(result_1) == type(result_2) == str


# Generated at 2022-06-25 19:55:52.305531
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[-2] == '-'
    assert cpf[-4] != '.'


# Generated at 2022-06-25 19:55:55.214214
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-25 19:55:58.063543
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() in ['004.331.324-10',
                                          '363.914.691-38',
                                          '227.590.661-01']


# Generated at 2022-06-25 19:55:59.632240
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data = BrazilSpecProvider().cpf()
    assert data != None


# Generated at 2022-06-25 19:56:02.592568
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert cpf == '286.463.336-15'


# Generated at 2022-06-25 19:56:07.927328
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()

    try:
        assert brazil_spec_provider_0.cnpj()
        assert True
    except AssertionError:
        assert False


# Generated at 2022-06-25 19:56:10.906042
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-25 19:56:18.677686
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed_0 = [
        '0',
        '1',
        '2',
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9',
    ]


# Generated at 2022-06-25 19:56:24.698471
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_1.cnpj()
    cnpj_with_mask = brazil_spec_provider_1.cnpj(with_mask=False)
    assert len(cnpj) == len('99.999.999/9999-99')
    assert len(cnpj_with_mask) == len('99.999.999/9999-99')


# Generated at 2022-06-25 19:56:39.813268
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_2 = BrazilSpecProvider()
    brazil_spec_provider_3 = BrazilSpecProvider()
    brazil_spec_provider_4 = BrazilSpecProvider()
    brazil_spec_provider_5 = BrazilSpecProvider()
    brazil_spec_provider_6 = BrazilSpecProvider()
    brazil_spec_provider_7 = BrazilSpecProvider()
    brazil_spec_provider_8 = BrazilSpecProvider()
    brazil_spec_provider_9 = BrazilSpecProvider()
    brazil_spec_provider_10 = BrazilSpecProvider()
    brazil_spec_provider_11 = BrazilSpecProvider()
    brazil_spec_provider_12 = BrazilSpecProvider()
    brazil_spec_prov

# Generated at 2022-06-25 19:56:42.343520
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()

    assert len(brazil_spec_provider.cnpj()) == 18


# Generated at 2022-06-25 19:56:44.567783
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    actual = brazil_spec_provider.cnpj()
    assert(len(actual) == 18)


# Generated at 2022-06-25 19:56:47.121840
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf(with_mask=False) == '00113729740'
    assert brazil_spec_provider_0.cpf(with_mask=True) == '001.137.297-40'


# Generated at 2022-06-25 19:56:51.405466
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert type(cpf) is str
    assert len(cpf) == 14


# Generated at 2022-06-25 19:56:54.511036
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    expected_result = '77.732.230/0001-70'
    assert brazil_spec_provider_0.cnpj() == expected_result


# Generated at 2022-06-25 19:56:56.245486
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected_0 = '015.449.852-98'
    actual_0 = BrazilSpecProvider().cpf(with_mask=True)
    assert actual_0 == expected_0


# Generated at 2022-06-25 19:56:59.806282
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()

    assert isinstance(brazil_spec_provider.cnpj(), str)
    assert len(brazil_spec_provider.cnpj()) == 18
    assert len(brazil_spec_provider.cnpj(with_mask=False)) == 14



# Generated at 2022-06-25 19:57:05.327696
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    with_mask_0 = False
    cpf_0 = brazil_spec_provider_0.cpf(with_mask=with_mask_0)
    # Check value of cpf_0.
    assert isinstance(cpf_0, str)
    # Check length of cpf_0.
    assert len(cpf_0) == 11


# Generated at 2022-06-25 19:57:07.414821
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() != None, 'Test fail: function return None'
    

# Generated at 2022-06-25 19:57:22.691135
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(brazil_spec_provider_0.cnpj()) == 18


# Generated at 2022-06-25 19:57:26.647143
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cpf(with_mask=True)
    assert brazil_spec_provider_1.cpf(with_mask=False)


# Generated at 2022-06-25 19:57:30.189406
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    # Assert the value of brazil_spec_provider_0.cnpj
    assert brazil_spec_provider_0.cnpj() == "54.865.038/0005-60"


# Generated at 2022-06-25 19:57:32.745462
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '01.239.456/0001-05'


# Generated at 2022-06-25 19:57:36.257743
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.schema import Field
    from mimesis.enums import Gender
    from mimesis.builtins.brazil_provider import BrazilSpecProvider
    mock_field = Field(BrazilSpecProvider, Gender.MALE, seed=1)
    output_0 = mock_field.cnpj()


# Generated at 2022-06-25 19:57:38.884323
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cpf(with_mask= True) == '321.081.754-13'


# Generated at 2022-06-25 19:57:47.360744
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_cpf_0 = BrazilSpecProvider(seed=5)
    assert brazil_spec_provider_cpf_0.cpf(with_mask=True) == '913.947.207-74'
    brazil_spec_provider_cpf_1 = BrazilSpecProvider(seed=5)
    assert brazil_spec_provider_cpf_1.cpf(with_mask=False) == '91394720774'


# Generated at 2022-06-25 19:57:50.280651
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Testing method cpf of class BrazilSpecProvider")
    brazil_spec_provider_0 = BrazilSpecProvider()
    print("Cpf: " + brazil_spec_provider_0.cpf())
    print()


# Generated at 2022-06-25 19:57:51.909625
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(False) == BrazilSpecProvider().cnpj(False)

# Generated at 2022-06-25 19:57:55.874487
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    print(str_0)
    str_1 = brazil_spec_provider_0.cpf()
    print(str_1)


# Generated at 2022-06-25 19:58:29.793742
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_0.cnpj(with_mask=True)
    assert cnpj == '04.876.966/0001-57'
    assert isinstance(cnpj, str)


# Generated at 2022-06-25 19:58:36.894308
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_instance_0 = BrazilSpecProvider()
    assert brazil_spec_provider_instance_0.cnpj() == '61.040.824/0001-43'
    assert brazil_spec_provider_instance_0.cnpj() == '41.130.819/0001-88'
    assert brazil_spec_provider_instance_0.cnpj() == '60.100.844/0001-49'
    assert brazil_spec_provider_instance_0.cnpj() == '99.700.816/0001-85'


# Generated at 2022-06-25 19:58:44.969680
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # test case 0
    brazil_spec_provider_0 = BrazilSpecProvider(seed=0)
    s_0 = brazil_spec_provider_0.cnpj(True)
    assert s_0 == '93.456.272/0001-18'
    # test case 1
    brazil_spec_provider_1 = BrazilSpecProvider(seed=1)
    s_1 = brazil_spec_provider_1.cnpj(True)
    assert s_1 == '59.193.108/0001-91'
    # test case 2
    brazil_spec_provider_2 = BrazilSpecProvider(seed=2)
    s_2 = brazil_spec_provider_2.cnpj(True)
    assert s_2 == '66.063.701/0001-49'


# Generated at 2022-06-25 19:58:48.287534
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj(True) == '10.698.814/0001-55'


# Generated at 2022-06-25 19:58:50.166269
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    res = brazil_spec_provider.cpf(with_mask=True)
    assert len(res) == 14

# Generated at 2022-06-25 19:58:58.319288
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '92.974.838/0001-62'
    assert brazil_spec_provider_0.cnpj() == '37.936.932/0001-31'
    assert brazil_spec_provider_0.cnpj() == '48.183.943/0001-95'
    assert brazil_spec_provider_0.cnpj() == '80.276.170/0001-09'
    assert brazil_spec_provider_0.cnpj() == '46.882.188/0001-07'


# Generated at 2022-06-25 19:59:02.507808
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj(with_mask=True)
    assert isinstance(str_0, str)
    assert len(str_0) == 18
    assert re.match(
        '\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}', str_0, flags=re.ASCII)


# Generated at 2022-06-25 19:59:07.005134
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    # Test with mask
    # Get a random CPF number without mask
    result = brazil_spec_provider_0.cpf(False)
    assert len(result) == 11
    assert result == '25788456041'
    # Get a random CPF number with mask
    result = brazil_spec_provider_0.cpf(True)
    assert len(result) == 14
    assert result == '257.884.560-41'


# Generated at 2022-06-25 19:59:10.530555
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider.cnpj()."""
    # Define input arguments
    with_mask = True
    # Invoke the target method with defined input arguments.
    result = BrazilSpecProvider().cnpj(with_mask)
    # Check the output type.
    assert(isinstance(result, str))


# Generated at 2022-06-25 19:59:13.633678
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider(seed=1597111297)
    assert brazil_spec_provider_0.cnpj(True) == '75.350.837/0001-22'



# Generated at 2022-06-25 20:00:31.021122
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected_result = "429.530.024-63"
    brazil_spec_provider = BrazilSpecProvider(seed=0)
    result = brazil_spec_provider.cpf()
    assert result == expected_result



# Generated at 2022-06-25 20:00:37.374612
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf(True) in ['090.358.464-61', '708.834.977-22', '126.961.841-91', '513.794.463-77', '860.835.672-70', '935.459.531-64', '064.367.815-42', '092.635.853-53', '802.184.429-79', '624.231.128-96']

# Generated at 2022-06-25 20:00:40.088653
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == '123.145.376-49'


# Generated at 2022-06-25 20:00:42.700360
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(seed=9515)


# Generated at 2022-06-25 20:00:44.529912
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_2 = BrazilSpecProvider()
    brazil_spec_provider_2.cpf()

# Generated at 2022-06-25 20:00:47.726414
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_0.cnpj()
    cnpj_1 = brazil_spec_provider_0.cnpj()
    assert cnpj != cnpj_1


# Generated at 2022-06-25 20:00:50.422230
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    exp_cnpj = brazil_spec_provider_0.cnpj()
    print(brazil_spec_provider_0.cnpj())
    print(type(exp_cnpj))
    assert isinstance(exp_cnpj, str), "Result should be of type string."


# Generated at 2022-06-25 20:00:55.967755
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == "926.633.834-05"


# Generated at 2022-06-25 20:01:03.249931
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_cnpj_0 = BrazilSpecProvider()
    brazil_spec_provider_cnpj_1 = BrazilSpecProvider()
    brazil_spec_provider_cnpj_1_result = brazil_spec_provider_cnpj_1.cnpj(False)
    assert len(brazil_spec_provider_cnpj_1_result) == 14
    brazil_spec_provider_cnpj_2 = BrazilSpecProvider()
    brazil_spec_provider_cnpj_2_result = brazil_spec_provider_cnpj_2.cnpj(True)
    assert len(brazil_spec_provider_cnpj_2_result) == 18


# Generated at 2022-06-25 20:01:04.059447
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print(BrazilSpecProvider().cnpj())


# Generated at 2022-06-25 20:03:21.277519
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = b'\xb8\xba\x9a\x15\xfa\xc4\x1e\xf5\x1e\xce\x8a\xed\xab\xb3\x1a' \
           b'l\x01s\x01\x0c\xd0RXu\x16\xbc\xee\xbc\xa4\xcd\xc0m\x91\xa1\x1a'
    brazil_spec_provider_1 = BrazilSpecProvider(seed=seed)
    cpf = brazil_spec_provider_1.cpf(with_mask=True)
    assert cpf == '789.265.751-80'


# Generated at 2022-06-25 20:03:25.870587
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method BrazilSpecProvider.cnpj."""

    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()

    assert len(cnpj) == 18 and cnpj[2] == '.' and cnpj[6] == '.' and cnpj[10] == '/' and cnpj[15] == '-'


# Generated at 2022-06-25 20:03:33.445087
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    for _ in range(100):
        cpf = brazil_spec_provider_1.cpf()
        assert len(cpf) == 14
        assert (cpf[:3] + '.' + cpf[3:6] + '.' + cpf[6:9] + '-' + cpf[9:]) == \
               brazil_spec_provider_1.cpf(with_mask=True)
        assert len(brazil_spec_provider_1.cpf(with_mask=False)) == 11



# Generated at 2022-06-25 20:03:40.373010
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_cpf = BrazilSpecProvider()

    cpf_with_mask = brazil_spec_provider_cpf.cpf(True)
    cpf_with_mask_expectation_result = True
    cpf_with_mask_expectation_type = "<class 'str'>"

    assert cpf_with_mask_expectation_result == isinstance(cpf_with_mask,
                                                          str), \
        "Assertion error: Expectation result for cpf_with_mask is {} and returned result is {}".format(
            cpf_with_mask_expectation_type, type(cpf_with_mask))

    cpf_without_mask = brazil_spec_provider_cpf.cpf(False)
    cpf_without_mask_ex

# Generated at 2022-06-25 20:03:41.955470
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cnpj()) == 18


# Generated at 2022-06-25 20:03:44.797736
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.isdigit()


# Generated at 2022-06-25 20:03:46.760796
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    with_mask = True
    output = brazil_spec_provider.cnpj(with_mask)
    assert len(output) > 1


# Generated at 2022-06-25 20:03:53.658330
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_0.cnpj()
    assert cnpj == '70.750.509/0001-01'
    cnpj = brazil_spec_provider_0.cnpj()
    assert cnpj == '47.738.404/0001-36'
    cnpj = brazil_spec_provider_0.cnpj()
    assert cnpj == '96.110.937/0001-61'
    cnpj = brazil_spec_provider_0.cnpj()
    assert cnpj == '92.815.877/0001-83'
    cnpj = brazil_spec_provider_0.cnpj()

# Generated at 2022-06-25 20:03:56.251526
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '44.652.698/0001-80'
    assert BrazilSpecProvider().cnpj(with_mask=False) == '44652698000180'


# Generated at 2022-06-25 20:03:59.817855
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(with_mask=False) == '44132226048'
    assert BrazilSpecProvider().cpf(with_mask=True) == '441.322.260-48'
