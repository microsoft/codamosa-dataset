

# Generated at 2022-06-25 19:55:03.369177
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cnpj()) == 18


# Generated at 2022-06-25 19:55:06.221591
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 is not None
    assert str_0 is not None


# Generated at 2022-06-25 19:55:07.791272
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert len(brazil_spec_provider_1.cnpj()) == 18


# Generated at 2022-06-25 19:55:10.965533
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BrazilSpecProvider_0 = BrazilSpecProvider()
    BrazilSpecProvider_0.cnpj()
    str_0 = BrazilSpecProvider_0.cnpj(with_mask=True)


# Generated at 2022-06-25 19:55:11.988566
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
	test_case_0()

# Generated at 2022-06-25 19:55:18.179355
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from copy import copy
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pt-br')
    brazil_spec_provider = BrazilSpecProvider()

    gender = None
    if person.gender() == Gender.MALE:
        gender = '1'
    elif person.gender() == Gender.FEMALE:
        gender = '2'

    def fake_random_choice(sequence):
        return '2233333333'

    def fake_random_int(lower, upper):
        return 9


    # save the old method
    brazil_spec_provider.random.choice = copy(brazil_spec_provider.random.choice)

# Generated at 2022-06-25 19:55:22.147286
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from seed.helper.print_method import print_method
    brazil_spec_provider_0 = BrazilSpecProvider()
    print_method(brazil_spec_provider_0, brazil_spec_provider_0.cpf)


# Generated at 2022-06-25 19:55:26.224703
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    some_cpf = BrazilSpecProvider().cpf()

    expected = some_cpf[3] == '.' and some_cpf[7] == '.' and some_cpf[11] == '-'
    result = BrazilSpecProvider().cpf(with_mask=True)

    assert result == expected


# Generated at 2022-06-25 19:55:33.219750
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider(seed = 28101678871405)
    brazil_spec_provider_0.seed = 28101678871405
    # Unit test for method cnpj of class BrazilSpecProvider
    # Parameter with_mask is set to True
    str_0 = brazil_spec_provider_0.cnpj(with_mask = True)
    assert str_0 == '47.559.099/0001-67'
    del brazil_spec_provider_0
    # Unit test for method cnpj of class BrazilSpecProvider
    # Parameter with_mask is set to False
    brazil_spec_provider_0 = BrazilSpecProvider(seed = 17763013329609)
    brazil_spec_provider_0.seed = 17763013329

# Generated at 2022-06-25 19:55:38.581845
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    # Test for cnpj (with_mask=True)
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj(with_mask=True)

    # Test for cnpj (with_mask=False)
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj(with_mask=False)



# Generated at 2022-06-25 19:55:51.788225
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    for _ in range(1):
        assert len(brazil_spec_provider.cpf()) == 14


# Generated at 2022-06-25 19:55:53.832198
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj()
    assert isinstance(str_1, str)
    assert len(str_1) == 18


# Generated at 2022-06-25 19:55:56.326536
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:55:59.745650
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # get address data
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 is not None


# Generated at 2022-06-25 19:56:10.136760
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    # First test case
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    bool_0 = bool(str_0)
    assert isinstance(str_0, str)
    assert isinstance(bool_0, bool)

    # Second test case
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_1.cnpj(True)
    bool_0 = bool(str_0)
    assert isinstance(str_0, str)
    assert isinstance(bool_0, bool)


# Generated at 2022-06-25 19:56:14.733871
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj(with_mask=True)
    str_1 = brazil_spec_provider_0.cnpj(with_mask=False)

    assert isinstance(str_0, str)

# Generated at 2022-06-25 19:56:17.281246
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = BrazilSpecProvider().cpf()
    assert result == '420.862.214-61'



# Generated at 2022-06-25 19:56:20.747982
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert isinstance(cpf, str)



# Generated at 2022-06-25 19:56:24.525561
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-25 19:56:30.562400
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj()
    str_2 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:57:01.978753
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit tests for method 'BrazilSpecProvider.cnpj'"""
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cnpj()

    assert (str_0.__class__ == str)
    assert len(str_0) == 18
    assert str_0.count('.') == 2
    assert str_0.count('/') == 1
    assert str_0.count('-') == 1

    str_1 = brazil_spec_provider.cnpj(with_mask=False)

    assert (str_1.__class__ == str)
    assert len(str_1) == 14
    assert str_1.count('.') == 0
    assert str_1.count('/') == 0

# Generated at 2022-06-25 19:57:12.650639
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf()
    str_2 = brazil_spec_provider_0.cpf()
    counter = 0
    for number in range(0,1000):
        if brazil_spec_provider_0.cpf() == str_0:
            counter += 1
    for number in range(0,1000):
        if brazil_spec_provider_0.cpf() == str_1:
            counter += 1
    for number in range(0,1000):
        if brazil_spec_provider_0.cpf() == str_2:
            counter += 1
    assert counter == 0

# Unit test

# Generated at 2022-06-25 19:57:20.061010
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import unittest

    class BrazilSpecProvider_cpf_TestCase(unittest.TestCase):
        def test_case_1(self):
            brazil_spec_provider_0 = BrazilSpecProvider()
            str_0 = brazil_spec_provider_0.cpf()
            self.assertIn('.', brazil_spec_provider_0.cpf())

        def test_case_2(self):
            brazil_spec_provider_0 = BrazilSpecProvider()
            str_0 = brazil_spec_provider_0.cpf()
            self.assertIn('.', brazil_spec_provider_0.cpf(True))

        def test_case_3(self):
            brazil_spec_provider_0 = BrazilSpecProvider()
            str_0 = brazil_

# Generated at 2022-06-25 19:57:23.622656
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf()
    assert str_1 is not None


# Generated at 2022-06-25 19:57:27.291861
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()

    assert len(str_0) == 18
    assert not isinstance(str_0, bool)


# Generated at 2022-06-25 19:57:29.880137
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 != ""


# Generated at 2022-06-25 19:57:33.126970
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Create instance of class BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()

    # Get a random cadastro de pessoas físicas
    str_0 = brazil_spec_provider.cpf()



# Generated at 2022-06-25 19:57:40.057972
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj()
    brazil_spec_provider_2 = BrazilSpecProvider()
    str_2 = brazil_spec_provider_2.cnpj()
    brazil_spec_provider_3 = BrazilSpecProvider()
    str_3 = brazil_spec_provider_3.cnpj()
    brazil_spec_provider_4 = BrazilSpecProvider()
    str_4 = brazil_spec_provider_4.cnpj()
    brazil_spec_provider_5 = BrazilSpecProvider()
    str_5 = brazil_spec_provider_5.cnpj()
    brazil_spec_provider_6 = BrazilSpecProvider()
    str_

# Generated at 2022-06-25 19:57:44.287493
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj()
    assert type(str_1) == str
    assert len(str_1) == 18
    assert str_1[2] == '.'
    assert str_1[6] == '.'
    assert str_1[10] == '/'
    assert str_1[15] == '-'

    str_2 = brazil_spec_provider_1.cnpj(with_mask=False)
    assert type(str_2) == str
    assert len(str_2) == 14
    assert str_2[2] != '.'
    assert str_2[6] != '.'
    assert str_2[8] != '/'

# Generated at 2022-06-25 19:57:47.242583
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 19:58:43.086098
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf(with_mask=False)
    assert len(str_0) == 14
    assert len(str_1) == 11


# Generated at 2022-06-25 19:58:49.115962
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test case 0
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14
    assert brazil_spec_provider_0.cpf(with_mask=False) == str_0.replace('.', '').replace('-', '')
    assert isinstance(brazil_spec_provider_0.cpf(with_mask=True), str)


# Generated at 2022-06-25 19:58:57.546854
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert isinstance(str_0, str)
    assert len(str_0) == 14
    assert str_0[3] == '.'
    assert str_0[7] == '.'
    assert str_0[11] == '-'
    assert not isinstance(str_0, int)
    assert not isinstance(str_0, float)
    assert not isinstance(str_0, bool)
    assert not isinstance(str_0, list)
    assert not isinstance(str_0, dict)
    assert not isinstance(str_0, tuple)


# Generated at 2022-06-25 19:59:00.179622
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    assert re.match(
        r'^\d{3}\.\d{3}\.\d{3}-\d{2}$',
        BrazilSpecProvider().cpf(),
    ), 'BrazilSpecProvider.cpf must return a CPF.'


# Generated at 2022-06-25 19:59:01.079831
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = BrazilSpecProvider().cpf()
    assert result is not None


# Generated at 2022-06-25 19:59:06.375097
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    brazil_spec_provider = BrazilSpecProvider(seed=123)
    str_0 = brazil_spec_provider.cpf()
    match_0 = re.match(r'^([0-9]{3}\.[0-9]{3}\.[0-9]{3}\-[0-9]{2})$', str_0)
    assert match_0 != None
    str_1 = brazil_spec_provider.cpf(with_mask=False)
    match_1 = re.match(r'^([0-9]{11})$', str_1)
    assert match_1 != None
    str_2 = brazil_spec_provider.cpf()

# Generated at 2022-06-25 19:59:08.612507
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result = brazil_spec_provider_0.cnpj()
    assert result is not None


# Generated at 2022-06-25 19:59:10.625975
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18


# Generated at 2022-06-25 19:59:18.665616
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # arrange
    brazil_spec_provider = BrazilSpecProvider()
    # act
    cnpj = brazil_spec_provider.cnpj()
    # assert
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert cnpj[0:2] in ['93', '95', '97', '98', '99']
    assert cnpj[2:5] in ['345', '666', '688', '900', '910', '912', '930', '933', '935', '938']
    assert cnpj[5:8] in ['006', '039', '071', '094', '120', '125', '147', '149', '153', '154']

# Generated at 2022-06-25 19:59:20.744836
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected = "414.813.448-72"
    method_output = BrazilSpecProvider().cpf()
    assert method_output == expected


# Generated at 2022-06-25 20:01:36.927996
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(str_0) == 14
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:01:40.800549
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.data import BRAZIL_DATA
    br = BrazilSpecProvider()
    for _ in range(10):
        result_0 = br.cpf()
    result_1 = br.cpf(with_mask=False)
    assert result_0 in BRAZIL_DATA['cpf']
    assert len(result_0) == 14
    assert len(result_1) == 11


# Generated at 2022-06-25 20:01:41.637399
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    str_1 = BrazilSpecProvider.cnpj()


# Generated at 2022-06-25 20:01:43.636393
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18


# Generated at 2022-06-25 20:01:45.093068
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:01:46.806899
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender

    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:01:50.584052
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 20:01:59.365114
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Case 0:
    from mimesis.builtins.brazil import brazil_spec_provider as brazil
    # Test 0:
    str_0 = brazil.cpf()
    # Test 1:
    str_1 = brazil.cpf(with_mask=False)
    # Test 2:
    str_2 = brazil.cpf()
    # Test 3:
    str_3 = brazil.cpf(with_mask=False)
    # Test 4:
    str_4 = brazil.cpf()
    # Test 5:
    str_5 = brazil.cpf(with_mask=False)
    # Test 6:
    str_6 = brazil.cpf()
    # Test 7:
    str_7 = brazil.cpf(with_mask=False)
    #

# Generated at 2022-06-25 20:02:02.540305
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '827.623.077-06'
    str_1 = brazil_spec_provider_0.cpf(with_mask=False)
    assert str_1 == '08683557199'


# Generated at 2022-06-25 20:02:04.437859
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider(seed=42)
    str_0 = brazil_spec_provider_0.cnpj()
    print('Test for cnpj(): ' + str(str_0))
