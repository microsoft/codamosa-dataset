

# Generated at 2022-06-25 19:55:03.922483
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:55:09.699162
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider(seed=0)
    assert brazil_spec_provider_1.cnpj() == '70787925008849'
    assert brazil_spec_provider_1.cnpj(with_mask=False) == '70787925008849'
    assert brazil_spec_provider_1.cnpj(with_mask=True) == '70.787.925/0088-49'
    brazil_spec_provider_2 = BrazilSpecProvider(seed=1)
    assert brazil_spec_provider_2.cnpj() == '75205911904174'
    assert brazil_spec_provider_2.cnpj(with_mask=False) == '75205911904174'
    assert brazil_spec_

# Generated at 2022-06-25 19:55:13.423816
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Creating instance of BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()
    
    # Testing method cpf with parameters
    res = brazil_spec_provider.cpf(True)
    assert isinstance(res, str)
    assert res.__len__() == 14



# Generated at 2022-06-25 19:55:15.857570
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    results = []
    for i in range(100):
        instance = BrazilSpecProvider()
        cnpj = instance.cnpj()
        results.append(cnpj)
    assert results


# Generated at 2022-06-25 19:55:18.666278
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cnpj()



# Generated at 2022-06-25 19:55:23.370337
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == "80.827.858/0002-04" or brazil_spec_provider_0.cnpj() == "70.093.983/0001-58"


# Generated at 2022-06-25 19:55:28.065445
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    result = brazil_spec_provider_1.cpf()
    assert isinstance(result, str)
    assert len(result) == 14
    assert re.search('\d{3}\.\d{3}\.\d{3}-\d{2}', result)


# Generated at 2022-06-25 19:55:30.355452
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == '982.087.936-15'



# Generated at 2022-06-25 19:55:32.858976
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result = brazil_spec_provider_0.cnpj()
    assert type(result) is str


# Generated at 2022-06-25 19:55:35.680107
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_result = brazil_spec_provider_0.cpf()
    assert len(cpf_result) == 14 # If length of result is 14, then test case passed


# Generated at 2022-06-25 19:55:57.369730
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_cpf_1 = brazil_spec_provider_1.cpf(with_mask=True)
    assert len(brazil_spec_provider_cpf_1) > 0
    brazil_spec_provider_2 = BrazilSpecProvider()
    brazil_spec_provider_cpf_2 = brazil_spec_provider_2.cpf(with_mask=True)
    assert len(brazil_spec_provider_cpf_2) > 0
    brazil_spec_provider_3 = BrazilSpecProvider()
    brazil_spec_provider_cpf_3 = brazil_spec_provider_3.cpf(with_mask=True)

# Generated at 2022-06-25 19:56:00.731579
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    test_case_1 = brazil_spec_provider.cnpj()
    print(test_case_1)


# Generated at 2022-06-25 19:56:12.028428
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    list_cpf = list()
    for n in range(0, 10000):
        cpf = BrazilSpecProvider().cpf()
        list_cpf.append(cpf)
    assert '719.531.018-52' in list_cpf
    assert '413.122.842-96' in list_cpf
    assert '323.814.425-44' in list_cpf
    assert '301.904.268-54' in list_cpf
    assert '192.092.064-08' in list_cpf
    assert '082.925.892-47' in list_cpf
    assert '061.282.743-74' in list_cpf
    assert '010.732.845-83' in list_cpf

# Generated at 2022-06-25 19:56:14.241255
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    for _ in range(0, 100):
        if not isinstance(brazil_spec_provider.cpf(), str):
            print(brazil_spec_provider.cpf())
            raise AssertionError


# Generated at 2022-06-25 19:56:22.951603
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()

    cpf = brazil_spec_provider.cpf(with_mask=True)
    assert len(cpf) == 14
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1

    cpf = brazil_spec_provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.count('.') == 0
    assert cpf.count('-') == 0



# Generated at 2022-06-25 19:56:26.905831
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()  # Instanciation
    cnpj = brazil_spec_provider_1.cnpj()
    cnpj = cnpj.replace('.', '').replace('-', '').replace('/', '')
    assert len(cnpj) == 14
    for c in cnpj:
        assert c in '0123456789'


# Generated at 2022-06-25 19:56:30.514274
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    result = brazil_spec_provider.cnpj()
    assert result
    assert type(result) == str
    assert len(result) == 18


# Generated at 2022-06-25 19:56:39.351721
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers import Person
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_2 = BrazilSpecProvider(seed=42)
    person_1 = Person('pt-BR')
    assert len(set(brazil_spec_provider_1.cpf() for _ in range(5))) == 5
    assert len(set(brazil_spec_provider_2.cpf() for _ in range(5))) == 5
    assert brazil_spec_provider_1.cpf(with_mask=False) == brazil_spec_provider_2.cpf(with_mask=False)
    assert brazil_spec_provider_1.cpf(with_mask=True) == brazil_spec_provider

# Generated at 2022-06-25 19:56:46.361991
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    for _ in range(50):
        cnpj = brazil_spec_provider_0.cnpj()
        assert (len(cnpj) == 18)
        assert cnpj  # implemented as a generator
    # cnpj(with_mask=False)
    for _ in range(50):
        cnpj = brazil_spec_provider_0.cnpj(with_mask=False)
        assert (len(cnpj) == 14)
        assert cnpj  # implemented as a generator


# Generated at 2022-06-25 19:56:52.081297
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(with_mask=False) == '75991295654'
    assert BrazilSpecProvider().cpf(with_mask=True) == '759.912.956-54'


# Generated at 2022-06-25 19:57:22.959445
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    result = brazil_spec_provider.cnpj()
    assert len(result) >= 14 and len(result) <= 18


# Generated at 2022-06-25 19:57:26.215621
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cnpj(with_mask=False) == '47452082000134'


# Generated at 2022-06-25 19:57:34.633543
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_2 = BrazilSpecProvider()
    brazil_spec_provider_3 = BrazilSpecProvider()

    brazil_spec_provider_1_result = brazil_spec_provider_1.cnpj(with_mask=False)
    brazil_spec_provider_2_result = brazil_spec_provider_2.cnpj(with_mask=False)
    brazil_spec_provider_3_result = brazil_spec_provider_3.cnpj(with_mask=False)
    assert brazil_spec_provider_1_result != brazil_spec_provider_2_result
    assert brazil_spec_provider_1_result != brazil_spec_provider_3

# Generated at 2022-06-25 19:57:38.184183
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    # Test cpf with CPF mask (###.###.###-##) and without mask
    assert isinstance(brazil_spec_provider.cpf(with_mask=True), str)
    assert isinstance(brazil_spec_provider.cpf(with_mask=False), str)


# Generated at 2022-06-25 19:57:42.704328
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    print(brazil_spec_provider_0.cnpj())
    

# Generated at 2022-06-25 19:57:51.790269
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    result = brazil_spec_provider_1.cpf()
    assert result
    first_verifying_digit = int(result[9])
    last_verifying_digit = int(result[12])
    assert len(result) == 14
    assert result[3] == '.'
    assert result[7] == '.'
    assert result[11] == '-'
    assert first_verifying_digit == (
        (first_verifying_digit * 10 + last_verifying_digit * 11) % 11)

# Generated at 2022-06-25 19:57:55.154482
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    res_1 = brazil_spec_provider_1.cpf()
    assert type(res_1) is str and len(res_1) == 14


# Generated at 2022-06-25 19:57:58.036441
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    cpf = brazil_spec_provider_1.cpf(with_mask = False)
    assert len(cpf) == 11


# Generated at 2022-06-25 19:58:07.144555
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    name = 'BrazilSpecProvider.cnpj'
    brazil_spec_provider = BrazilSpecProvider()
    actual = brazil_spec_provider.cnpj()
    if not isinstance(actual, str):
        raise TypeError(f'{name}: expected {str}, got {type(actual)}. '
                        f'@str return type is not consistent.')
    if len(actual) != 18:
        raise ValueError(f'{name}: expected 18 chars, got {len(actual)}.')
    if actual[2] != '.' or actual[6] != '.' or actual[10] != '/' or actual[15] != '-':
        raise ValueError(f'{name}: mask is not correct')


# Generated at 2022-06-25 19:58:09.305786
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf(with_mask=False) == brazil_spec_provider.cpf(with_mask=True)
    assert True


# Generated at 2022-06-25 19:59:16.313477
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=True)

    assert cpf == '030.778.675-77'


# Generated at 2022-06-25 19:59:18.693134
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result = brazil_spec_provider_0.cnpj()
    assert isinstance(result, str)


# Generated at 2022-06-25 19:59:20.977528
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf = brazil_spec_provider_0.cpf()
    assert isinstance(cpf, str)


# Generated at 2022-06-25 19:59:22.542775
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    brazil_spec_provider_cnpj = brazil_spec_provider.cnpj()


# Generated at 2022-06-25 19:59:24.767866
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf[3] == "."
    assert cpf[7] == "."
    assert cpf[11] == "-"


# Generated at 2022-06-25 19:59:27.444038
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    from mimesis.typing import Seed

    seed = Seed(seed=100)
    brazil_spec_provider_1 = BrazilSpecProvider(seed=seed)
    assert brazil_spec_provider_1.cnpj() == "97.938.322/0001-42"

# Test if the method cnpj returns a random value

# Generated at 2022-06-25 19:59:29.303017
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) in (18, 14)


# Generated at 2022-06-25 19:59:36.311896
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_with_mask_0 = BrazilSpecProvider().cpf()
    assert(bool(re.fullmatch(r"[0-9]{3}.[0-9]{3}.[0-9]{3}-[0-9]{2}", cpf_with_mask_0)))
    cpf_without_mak_0 = BrazilSpecProvider().cpf(False)
    assert(bool(re.fullmatch(r"[0-9]{11}", cpf_without_mask_0)))


# Generated at 2022-06-25 19:59:42.310100
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import re
    brazil_spec_provider_0 = BrazilSpecProvider()
    print(brazil_spec_provider_0.cnpj(False))
    assert re.match(r'\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d', brazil_spec_provider_0.cnpj(False))
    

# Generated at 2022-06-25 19:59:45.170980
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_0 = BrazilSpecProvider(seed=1).cpf()
    cpf_1 = BrazilSpecProvider(seed=1).cpf()
    assert cpf_0 == cpf_1


# Generated at 2022-06-25 20:02:14.265870
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_cpf_0 = BrazilSpecProvider()
    assert brazil_spec_provider_cpf_0.cpf()


# Generated at 2022-06-25 20:02:16.091987
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_ = BrazilSpecProvider().cpf()
    assert len(cpf_) == 14


# Generated at 2022-06-25 20:02:19.133381
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf(with_mask=False) is not None


# Generated at 2022-06-25 20:02:24.003531
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Testing method BrazilSpecProvider.cpf"""
    # Initializing Provider
    brazil_spec_provider_0 = BrazilSpecProvider()

    # Initializing variables
    expected_regex = r'(\d{3}\.){2}\d{3}\-\d{2}'

    # Verifying Method
    cpf = brazil_spec_provider_0.cpf()
    assert re.fullmatch(expected_regex, cpf) is not None


# Generated at 2022-06-25 20:02:29.983995
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    for i in range(10):
        assert len(brazil_spec_provider.cpf(False)) == 11
        assert len(brazil_spec_provider.cpf()) == 14


# Generated at 2022-06-25 20:02:37.489329
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    with_mask = True
    assert (brazil_spec_provider_0.cpf(with_mask) == '764.842.413-62')


# Generated at 2022-06-25 20:02:49.540628
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(seed=0)
    assert brazil_spec_provider_0.cpf() == '097.983.895-40'
    assert brazil_spec_provider_0.cpf(with_mask=False) == '097983895040'
    brazil_spec_provider_1 = BrazilSpecProvider(seed=1)
    assert brazil_spec_provider_1.cpf(with_mask=False) == '387529014140'
    assert brazil_spec_provider_1.cpf() == '387.529.014-40'
    brazil_spec_provider_2 = BrazilSpecProvider(seed=2)

# Generated at 2022-06-25 20:02:52.633405
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    for i in range(0,2):
        brazil_spec_provider.cpf(i)


# Generated at 2022-06-25 20:02:57.776415
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result = brazil_spec_provider_0.cnpj(True)
    assert result == '16.000.519/0001-51'


# Generated at 2022-06-25 20:02:59.167886
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == "564.288.809/0001-90"
