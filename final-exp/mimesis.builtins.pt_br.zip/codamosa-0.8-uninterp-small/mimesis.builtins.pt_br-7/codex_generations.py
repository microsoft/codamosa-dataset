

# Generated at 2022-06-25 19:55:10.256217
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    string_0 = BrazilSpecProvider(7).cnpj(False)
    str_0 = '%c' % -73
    assert "19.636.771/0001-58" == brazil_spec_provider_0.cnpj(True)
    assert "34.054.064/0001-64" == brazil_spec_provider_0.cnpj()
    assert "77.732.230/0001-70" == brazil_spec_provider_0.cnpj(True)
    assert "77.732.230/0001-70" == brazil_spec_provider_0.cnpj(False)
    assert "05.847.202/0001-77" == brazil_spec_provider_0.cnpj()

# Generated at 2022-06-25 19:55:16.300902
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    arg0 = True
    arg1 = True
    arg2 = True
    arg3 = True

    ret0 = BrazilSpecProvider.Meta.name
    ret1 = BrazilSpecProvider.cnpj(arg0)
    ret2 = BrazilSpecProvider.cnpj(arg1)
    ret3 = BrazilSpecProvider.cnpj(arg2)
    ret4 = BrazilSpecProvider.cnpj(arg3)

    assert type(ret0) is str
    assert type(ret1) is str
    assert type(ret2) is str
    assert type(ret3) is str
    assert type(ret4) is str


# Generated at 2022-06-25 19:55:26.995622
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    with_mask = True
    int_0 = -1
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    cpf_0 = brazil_spec_provider_0.cpf(with_mask)
    int_0 = -9998
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    cpf_0 = brazil_spec_provider_0.cpf(with_mask)
    int_0 = -9999
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    cpf_0 = brazil_spec_provider_0.cpf(with_mask)
    int_0 = -99999
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)

# Generated at 2022-06-25 19:55:30.105352
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = brazil_spec_provider_0 = BrazilSpecProvider()

    assert brazil_spec_provider.cnpj(True).__len__() == 18
    assert brazil_spec_provider.cnpj(False).__len__() == 14


# Generated at 2022-06-25 19:55:35.839481
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    int_0 = -10
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    with_mask_0 = True
    cnpj_0 = brazil_spec_provider_0.cnpj(with_mask_0)

    # Test with a real cnpj
    # assert cnpj_0 == '34.092.421/0001-72'
    # Test with a random cnpj
    assert len(cnpj_0) == 18


# Generated at 2022-06-25 19:55:40.360574
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_with_mask = brazil_spec_provider_0.cpf()
    cpf_without_mask = brazil_spec_provider_0.cpf(False)

    assert isinstance(cpf_with_mask, str)
    assert isinstance(cpf_without_mask, str)

    assert len(cpf_with_mask) == 14
    assert len(cpf_without_mask) == 11



# Generated at 2022-06-25 19:55:45.218647
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('Testing cpf')
    int_0 = 838
    bool_0 = False
    str_0 = BrazilSpecProvider(int_0).cpf(bool_0)
    str_1 = BrazilSpecProvider(int_0).cpf(bool_0)
    # print(str_0)  # 468.738.597-94
    # print(str_1)  # 846.839.423-66



# Generated at 2022-06-25 19:55:53.715903
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    # Test for cnpj 1
    result = brazil_spec_provider_0.cnpj()
    assert result is not None
    assert type(result) in [str, ]
    assert len(result) > 1
    # Test for cnpj 2
    result = brazil_spec_provider_0.cnpj()
    assert result is not None
    assert type(result) in [str, ]
    assert len(result) > 1
    # Test for cnpj 3
    result = brazil_spec_provider_0.cnpj()
    assert result is not None
    assert type(result) in [str, ]
    assert len(result) > 1
    # Test for cnpj 4
    result = brazil_spec_prov

# Generated at 2022-06-25 19:55:56.576128
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    with_mask = True
    _int = -1408
    _expected = "77.732.230/0001-70"
    _result = BrazilSpecProvider(_int).cnpj(with_mask)
    assert _result == _expected


# Generated at 2022-06-25 19:55:59.692548
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cpf()
    return brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:56:09.940551
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(11)
    result = brazil_spec_provider_0.cpf()

    assert result != None
    assert type(result) == str


# Generated at 2022-06-25 19:56:14.655073
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()

    assert brazil_spec_provider_0.cnpj() == '34.851.676/0001-50', \
        'assert brazil_spec_provider.cnpj() == \'34.851.676/0001-50\''


# Generated at 2022-06-25 19:56:21.226328
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj(with_mask=True) == '11.936.681/0001-56'
    assert brazil_spec_provider_0.cnpj(with_mask=False) == '11936681000156'


# Generated at 2022-06-25 19:56:25.140166
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  print('Method cnpj of class BrazilSpecProvider')
  int_0 = -1408
  instance_0 = BrazilSpecProvider(int_0)
  boolean_0 = True
  string_0 = instance_0.cnpj(boolean_0)
  assert string_0 == '46.608.709/0071-18'


# Generated at 2022-06-25 19:56:28.977229
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_0 = brazil_spec_provider_0.cpf()



# Generated at 2022-06-25 19:56:31.816176
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_0 = -89430
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_0 = brazil_spec_provider_0.cpf(False)


# Generated at 2022-06-25 19:56:37.300861
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = 678
    brazil_spec_provider_0 = BrazilSpecProvider(seed)
    with_mask = True
    result = brazil_spec_provider_0.cnpj(with_mask)
    assert isinstance(result, str)


# Generated at 2022-06-25 19:56:46.950470
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert '974.863.370/0001-48' == brazil_spec_provider_0.cnpj()
    assert '80.665.560/0001-38' == brazil_spec_provider_0.cnpj()
    assert '919.988.450/0001-69' == brazil_spec_provider_0.cnpj()
    assert '924.054.980/0001-43' == brazil_spec_provider_0.cnpj()
    assert '52.918.130/0001-49' == brazil_spec_provider_0.cnpj()
    assert '60.739.060/0001-57' == brazil_spec_provider_0.cnpj()
    assert '810.861.570/0001-40' == brazil

# Generated at 2022-06-25 19:56:57.160916
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    args_0 = 1
    # Get cpf without mask
    result_0 = brazil_spec_provider_0.cpf()
    # Get cpf with mask
    result_1 = brazil_spec_provider_0.cpf(args_0)
    assert len(result_0) == 11
    assert len(result_1) == 14
    assert result_0[3] == result_1[3]
    assert result_0[6] == result_1[6]
    assert result_1[9] == '-'
    assert result_0[9] == result_1[10]



# Generated at 2022-06-25 19:56:59.276393
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    if cpf:
        assert len(cpf) == 14
    cpf = provider.cpf(with_mask=False)
    if cpf:
        assert len(cpf) == 11



# Generated at 2022-06-25 19:57:16.794671
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    with_mask_0 = False
    str_0 = brazil_spec_provider_0.cpf(with_mask_0)
    assert len(str_0) == 11


# Generated at 2022-06-25 19:57:27.371553
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    # testing with seed -1408
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_true_0 = "954.151.481-80"
    assert str_true_0 == brazil_spec_provider_0.cpf()

    # testing with seed -1408
    int_1 = -1408
    brazil_spec_provider_1 = BrazilSpecProvider(int_1)
    str_true_1 = "954.151.481-80"
    assert str_true_1 == brazil_spec_provider_1.cpf()

    # testing with seed -1408
    int_2 = -1408
    brazil_spec_provider_2 = BrazilSpecProvider(int_2)

# Generated at 2022-06-25 19:57:30.938898
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    bool_0 = True
    str_0 = brazil_spec_provider_0.cnpj(bool_0)
    assert len(str_0) == 18


# Generated at 2022-06-25 19:57:38.536819
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    Brazil_Spec_Provider_0 = BrazilSpecProvider(seed=0)
    Brazil_Spec_Provider_0_cpf_0 = Brazil_Spec_Provider_0.cpf()
    Brazil_Spec_Provider_0_cpf_1 = Brazil_Spec_Provider_0.cpf()
    Brazil_Spec_Provider_0_cpf_2 = Brazil_Spec_Provider_0.cpf()
    Brazil_Spec_Provider_0_cpf_3 = Brazil_Spec_Provider_0.cpf()
    Brazil_Spec_Provider_0_cpf_4 = Brazil_Spec_Provider_0.cpf()
    Brazil_Spec_Provider_0_cpf_5 = Brazil_Spec_Provider_0.cpf()
    Brazil_Spec_Provider_0_cpf_6 = Brazil_Spec_Provider_0.cpf()

# Generated at 2022-06-25 19:57:42.851295
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14
    assert len(BrazilSpecProvider().cpf()) != 13


# Generated at 2022-06-25 19:57:52.020828
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_1 = BrazilSpecProvider(-1847)
    brazil_spec_provider_2 = BrazilSpecProvider(-9107)
    brazil_spec_provider_3 = BrazilSpecProvider(-1261)
    brazil_spec_provider_4 = BrazilSpecProvider(-566)
    brazil_spec_provider_5 = BrazilSpecProvider(-9107)
    brazil_spec_provider_6 = BrazilSpecProvider(-1092)
    brazil_spec_provider_7 = BrazilSpecProvider(-9107)
    brazil_spec_provider_8 = BrazilSpecProvider(-9107)
    brazil_spec_provider_9 = BrazilSpecProvider(-1261)

    str_0 = brazil_spec_provider

# Generated at 2022-06-25 19:57:58.583922
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()

    result_0 = brazil_spec_provider_0.cnpj()
    expected_0 = '77.732.230/0001-70'
    assert result_0 == expected_0

    result_1 = brazil_spec_provider_0.cnpj(with_mask=True)
    expected_1 = '77.732.230/0001-70'
    assert result_1 == expected_1


# Generated at 2022-06-25 19:58:01.948456
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cpf()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 19:58:05.150532
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    with_mask_0 = True
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider_0.cpf(with_mask_0)


# Generated at 2022-06-25 19:58:08.330725
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    with_mask_0 = 1
    seed_0 = -725554935
    brazil_spec_provider_0 = BrazilSpecProvider(seed_0)
    assert brazil_spec_provider_0.cpf(with_mask_0) == '991.482.000-86'


# Generated at 2022-06-25 19:58:44.727229
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins.brazil import BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider(6416)
    brazil_spec_provider.cpf()

# Generated at 2022-06-25 19:58:48.066628
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_0 = brazil_spec_provider_0.cnpj()



# Generated at 2022-06-25 19:58:53.044140
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    int_1 = -1408
    brazil_spec_provider_1 = BrazilSpecProvider(int_1)
    str_0 = brazil_spec_provider_0.cpf(True)

    assert str_0 == brazil_spec_provider_1.cpf(True)


# Generated at 2022-06-25 19:58:58.093279
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cases for method cnpj of class BrazilSpecProvider.

    """
    # Arrange
    seed = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(seed)

    # Act
    act_0 = brazil_spec_provider_0.cnpj(True)

    # Assert
    assert act_0 == '33.699.817/0001-98'



# Generated at 2022-06-25 19:59:04.287364
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    assert brazil_spec_provider_0.cpf(True) == '115.385.189-72'
    assert brazil_spec_provider_0.cpf(False) == '1153851897'
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    assert brazil_spec_provider_0.cpf(0) == '208.332.606-61'
    assert brazil_spec_provider_0.cpf(1) == '20.833.260-66'
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    assert b

# Generated at 2022-06-25 19:59:11.428099
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '025.441.950-24'
    assert BrazilSpecProvider().cpf(with_mask=True) == '846.944.037-84'
    assert BrazilSpecProvider().cpf() == '433.362.891-51'
    assert BrazilSpecProvider().cpf(with_mask=True) == '836.436.723-32'
    assert BrazilSpecProvider().cpf() == '110.483.371-65'
    assert BrazilSpecProvider().cpf(with_mask=True) == '997.919.780-91'
    assert BrazilSpecProvider().cpf() == '633.277.032-47'
    assert BrazilSpecProvider().cpf(with_mask=True) == '925.248.743-96'

# Generated at 2022-06-25 19:59:20.594613
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_1 = 7127
    brazil_spec_provider_1 = BrazilSpecProvider(int_1)
    str_1 = brazil_spec_provider_1.cpf(False)
    assert str_1 == "22974224485"
    int_2 = 2978
    brazil_spec_provider_2 = BrazilSpecProvider(int_2)
    str_2 = brazil_spec_provider_2.cpf(True)
    assert str_2 == "716.962.977-14"
    int_3 = 4287
    brazil_spec_provider_3 = BrazilSpecProvider(int_3)
    str_3 = brazil_spec_provider_3.cpf(False)
    assert str_3 == "24354441872"

# Generated at 2022-06-25 19:59:24.417803
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    bool_0 = False
    str_0 = brazil_spec_provider_0.cpf(bool_0)
    assert str_0 is not None
    bool_1 = True
    str_1 = brazil_spec_provider_0.cpf(bool_1)
    assert str_1 is not None


# Generated at 2022-06-25 19:59:25.088419
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    pass


# Generated at 2022-06-25 19:59:33.163762
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from random import Random
    from mimesis.enums import Gender
    from mimesis.builtins.brazil import BrazilSpecProvider
    from mimesis.typing import Seed

    brazil_spec_provider_0 = BrazilSpecProvider(Seed(0))
    assert isinstance(brazil_spec_provider_0._random, Random)
    assert brazil_spec_provider_0.random_cpf()
    assert brazil_spec_provider_0.random_cnpj()
    assert brazil_spec_provider_0.full_name(Gender.FEMALE)
    assert brazil_spec_provider_0.full_name(Gender.MALE)
    assert brazil_spec_provider_0.name(Gender.MALE)

# Generated at 2022-06-25 20:00:50.200705
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_0 = brazil_spec_provider_0.cpf(False)
    assert len(str_0) == 11
    assert str_0 == '92564444444'


# Generated at 2022-06-25 20:00:55.967527
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(739)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '065.707.930-93'


# Generated at 2022-06-25 20:00:56.847622
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()


# Generated at 2022-06-25 20:00:58.951698
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:01:01.422756
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    int_0 = -1
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    b: bool = brazil_spec_provider_0.cnpj()
    assert b == False


# Generated at 2022-06-25 20:01:03.938402
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_0 = -32839
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == "481.865.175-73"


# Generated at 2022-06-25 20:01:06.550219
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    float_0 = -0.395732388
    bool_0 = True
    brazil_spec_provider_0 = BrazilSpecProvider(float_0)
    assert brazil_spec_provider_0.cpf(bool_0) != '025.420.355-24'


# Generated at 2022-06-25 20:01:16.054804
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(1408)
    assert brazil_spec_provider_0.cpf(False) == '92912663847'
    brazil_spec_provider_1 = BrazilSpecProvider(1408)
    assert brazil_spec_provider_1.cpf(True) == '929.126.638-47'
    brazil_spec_provider_2 = BrazilSpecProvider(1408)
    assert brazil_spec_provider_2.cpf(False) == '93788056457'
    brazil_spec_provider_3 = BrazilSpecProvider(1408)
    assert brazil_spec_provider_3.cpf(True) == '937.880.564-57'
    brazil_spec_provider_4

# Generated at 2022-06-25 20:01:17.914481
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    int_0 = -7
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_0 = brazil_spec_provider_0.cpf(True)


# Generated at 2022-06-25 20:01:21.292187
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """This function tests the method cnpj of the BrazilSpecProvider class."""
    # Testing case 0
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_0 = brazil_spec_provider_0.cnpj(False)


# Generated at 2022-06-25 20:03:34.748735
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    print(str_0)


# Generated at 2022-06-25 20:03:37.031187
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj(0)
    assert len(str_0) == 14


# Generated at 2022-06-25 20:03:39.210590
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Initialization of BrazilSpecProvider instance
    brazil_spec_provider_0 = BrazilSpecProvider(-66)
    # Test of method cnpj of class BrazilSpecProvider with arguments
    brazil_spec_provider_0.cnpj(False)


# Generated at 2022-06-25 20:03:40.651517
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result_0 = BrazilSpecProvider().cpf(True)
    assert result_0 == '093.160.678-14'


# Generated at 2022-06-25 20:03:46.936303
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # with_mask = True
    bool_0 = True
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_0 = brazil_spec_provider_0.cpf(bool_0)
    assert str_0 is not None and len(str_0) > 0
    # with_mask = False
    bool_0 = False
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    str_0 = brazil_spec_provider_0.cpf(bool_0)
    assert str_0 is not None and len(str_0) > 0


# Generated at 2022-06-25 20:03:51.269043
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(471951)
    # Tests for type of object returned
    assert isinstance(brazil_spec_provider_0.cpf(), str)
    # Tests for length of object returned
    assert len(brazil_spec_provider_0.cpf()) == 14
    assert len(brazil_spec_provider_0.cpf(True)) == 14



# Generated at 2022-06-25 20:03:56.764128
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    with_mask_0 = False
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    cnpj_0 = brazil_spec_provider_0.cnpj(with_mask_0)
    print(str(cnpj_0))
    with_mask_0 = True
    int_1 = -1245
    brazil_spec_provider_1 = BrazilSpecProvider(int_1)
    cnpj_1 = brazil_spec_provider_1.cnpj(with_mask_0)
    print(str(cnpj_1))
    with_mask_0 = True
    int_0 = -1408
    brazil_spec_provider_0 = BrazilSpecProvider(int_0)
    cnpj_

# Generated at 2022-06-25 20:04:02.110822
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    expected_0 = '82.236.840/0001-04'
    brazil_spec_provider_0 = BrazilSpecProvider(0)
    actual_0 = brazil_spec_provider_0.cnpj(with_mask=True)
    assert actual_0 == expected_0


# Generated at 2022-06-25 20:04:03.923071
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_0.cnpj()
    assert isinstance(cnpj, str)


# Generated at 2022-06-25 20:04:14.270085
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf(0) == "628.459.214-82"
    assert brazil_spec_provider_0.cpf(1) == "628.459.214-82"
    assert brazil_spec_provider_0.cpf(0) == "628.459.214-82"
    assert brazil_spec_provider_0.cpf(0) == "628.459.214-82"
    assert brazil_spec_provider_0.cpf(0) == "628.459.214-82"
    assert brazil_spec_provider_0.cpf(1) == "628.459.214-82"