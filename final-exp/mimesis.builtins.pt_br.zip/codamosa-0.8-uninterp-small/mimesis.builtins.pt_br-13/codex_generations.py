

# Generated at 2022-06-25 19:55:04.679695
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    # assert str_0 == '77.732.230/0001-70'
    # assert brazil_spec_provider.cpf(with_mask=True) == '001.137.297-40'
    print(brazil_spec_provider.cpf(with_mask=False))



# Generated at 2022-06-25 19:55:05.539107
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_case_0()

# Generated at 2022-06-25 19:55:09.430019
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed(1)
    BrazilSpecProvider_cpf = BrazilSpecProvider()
    BrazilSpecProvider_cpf_cases = [
        ('050.854.567-01', True), ('05085456701', False), ('050.854.567-01', True), ('05085456701', False)
    ]
    for cpf_case in BrazilSpecProvider_cpf_cases:
        assert BrazilSpecProvider_cpf.cpf(cpf_case[1]) == cpf_case[0]



# Generated at 2022-06-25 19:55:17.236515
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj()
    assert type(str_0) == type(str_1)
    assert len(str_0) == len(str_1)
    assert str_0 != str_1
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj(with_mask=True)
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj(with_mask=True)
   

# Generated at 2022-06-25 19:55:21.398927
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    expected = '02.490.283/0001-73'
    brazil_spec_provider_1 = BrazilSpecProvider(seed=expected)
    str_1 = brazil_spec_provider_1.cnpj()
    assert str_1 == expected



# Generated at 2022-06-25 19:55:24.613574
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cnpj()) == 18
    assert brazil_spec_provider_0.cnpj()[2] == '.'
    assert brazil_spec_provider_0.cnpj()[6] == '.'
    assert brazil_spec_provider_0.cnpj()[10] == '/'
    assert brazil_spec_provider_0.cnpj()[15] == '-'



# Generated at 2022-06-25 19:55:28.109113
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf()
    assert str_0 is not str_1


# Generated at 2022-06-25 19:55:30.488629
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:55:31.333383
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_case_0()


# Generated at 2022-06-25 19:55:33.489344
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()

    str = brazil_spec_provider.cpf()
    assert isinstance(str, str)



# Generated at 2022-06-25 19:55:48.292240
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    str_0 = provider.cpf()
    assert len(str_0) == 14
    assert len(str_0.split('.')) == 3
    assert len(str_0.split('-')) == 2


# Generated at 2022-06-25 19:55:56.220494
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    #Case 0: A CNPJ is generated
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()

    assert len(str_0) == 18
    assert str_0[2] == '.'
    assert str_0[6] == '.'
    assert str_0[10] == '/'
    assert str_0[15] == '-'
    assert str_0[0:2].isdigit()
    assert str_0[3:6].isdigit()
    assert str_0[7:10].isdigit()
    assert str_0[11:15].isdigit()
    assert str_0[16:18].isdigit()

    #Case 1: A CNPJ without mask is generated
    brazil

# Generated at 2022-06-25 19:55:57.903895
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()

    assert len(cnpj) == 18


# Generated at 2022-06-25 19:56:10.098138
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import random
    # Assumptions
    unit_test_cpf_with_mask_0 = False  # type: bool
    unit_test_cpf_with_mask_1 = False  # type: bool
    unit_test_cpf_with_mask_2 = False  # type: bool
    unit_test_cpf_with_mask_3 = False  # type: bool
    unit_test_cpf_with_mask_4 = False  # type: bool
    unit_test_cpf_with_mask_5 = False  # type: bool
    unit_test_cpf_with_mask_6 = False  # type: bool
    unit_test_cpf_with_mask_7 = False  # type: bool
    unit_test_cpf_with_mask_8 = False  # type: bool


# Generated at 2022-06-25 19:56:12.328930
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    instance = BrazilSpecProvider()
    assert isinstance(instance.cnpj(), str)


# Generated at 2022-06-25 19:56:15.193954
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert BrazilSpecProvider.Meta.name == 'brazil_provider'
    assert type(brazil_spec_provider_0.cnpj(True)) == str


# Generated at 2022-06-25 19:56:19.845575
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert isinstance(str_0, str) == True
    assert True == True



# Generated at 2022-06-25 19:56:22.101865
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14
    assert isinstance(BrazilSpecProvider().cpf(), str)


# Generated at 2022-06-25 19:56:24.428192
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()

    # Failure Case
    # 093.019.951-78
    assert obj.cpf(with_mask = True) != ""


# Generated at 2022-06-25 19:56:32.129178
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert isinstance(str_0, str)
    assert len(str_0) == 14
    assert str_0[3] == "."
    assert str_0[7] == "."
    assert str_0[11] == "-"


# Generated at 2022-06-25 19:56:56.718178
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    bool_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:57:02.902446
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18
    seed = 16
    brazil_spec_provider_1 = BrazilSpecProvider(seed=seed)
    str_1 = brazil_spec_provider_1.cnpj()
    assert str_1 == '64.634.548/0001-83'
    brazil_spec_provider_2 = BrazilSpecProvider(seed=seed)
    str_2 = brazil_spec_provider_2.cnpj()
    assert str_2 == '64.634.548/0001-83'


# Generated at 2022-06-25 19:57:11.348220
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14
    assert eval('type(str_0)==type("")')
    assert str_0 == "1.920.118.894-53"
    assert eval('type(str_0)==type("")')
    assert str_0 == "2.054.942.797-41"
    assert eval('type(str_0)==type("")')
    assert str_0 == "9.912.367.369-25"


# Generated at 2022-06-25 19:57:14.677590
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    current_provider = BrazilSpecProvider()

    assert len(current_provider.cpf(with_mask=False)) == 11
    assert len(current_provider.cpf(with_mask=True)) == 14


# Generated at 2022-06-25 19:57:16.863688
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:57:27.418165
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Unit test for method cnpj of class BrazilSpecProvider
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj()
    str_2 = brazil_spec_provider_0.cnpj()
    str_3 = brazil_spec_provider_0.cnpj()
    str_4 = brazil_spec_provider_0.cnpj()
    str_5 = brazil_spec_provider_0.cnpj()
    str_6 = brazil_spec_provider_0.cnpj()
    str_7 = brazil_spec_provider_0.cnpj()
    str_8 = brazil_

# Generated at 2022-06-25 19:57:34.854237
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    # Test with a mask
    cpf_with_mask = brazil_spec_provider.cpf()
    assert isinstance(cpf_with_mask, str)
    assert len(cpf_with_mask) == 14
    assert "###.###.###-##" in cpf_with_mask
    # Test without a mask
    cpf_without_mask = brazil_spec_provider.cpf(True)
    assert isinstance(cpf_without_mask, str)
    assert len(cpf_without_mask) == 11
    assert cpf_without_mask != "###.###.###-##"


# Generated at 2022-06-25 19:57:37.695839
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf()
    assert len(str_1) == 14


# Generated at 2022-06-25 19:57:43.029943
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert __builtins__.isinstance(str_0, __builtins__.str)



# Generated at 2022-06-25 19:57:44.798182
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() != BrazilSpecProvider().cnpj()


# Generated at 2022-06-25 19:58:40.701245
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()

    cpf = brazil_spec_provider.cpf()
    parts = cpf.split('-')
    cpf_without_dv = parts[0]
    cpf_without_dv = cpf_without_dv.split(r'\.')
    list_cpf_without_dv = [int(i) for i in cpf_without_dv]
    list_with_dv = list_cpf_without_dv.append(int(parts[1]))

    list_cpf = [int(i) for i in cpf]
    assert len(list_cpf) == 11
    assert len(list_cpf_without_dv) == 10


# Generated at 2022-06-25 19:58:44.728090
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert isinstance(
        brazil_spec_provider.cpf(),
        str,
        'Method cpf of class BrazilSpecProvider does not work.'
    )

# Generated at 2022-06-25 19:58:53.868607
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Arrange
    from mimesis.typing import Seed
    brazil_spec_provider = BrazilSpecProvider()

    # Act
    for i in range(10):
        str_0 = brazil_spec_provider.cpf()
        str_1 = brazil_spec_provider.cpf(1)
        str_2 = brazil_spec_provider.cpf(0)
    brazil_spec_provider_0 = BrazilSpecProvider(Seed.random())
    str_3 = brazil_spec_provider_0.cpf()
    brazil_spec_provider_1 = BrazilSpecProvider(Seed.random())
    str_4 = brazil_spec_provider_1.cpf()
    # Assert


# Generated at 2022-06-25 19:58:56.699567
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj().replace(".", "").replace("-", "").replace("/", "")) == 14


# Generated at 2022-06-25 19:59:03.255740
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cnpj() == '15.077.928/0001-11'
    assert brazil_spec_provider_1.cnpj(True) == '15.077.928/0001-11'
    assert brazil_spec_provider_1.cnpj(False) == '15077928000111'
    assert brazil_spec_provider_1.cnpj() == '72.721.135/0001-06'
    assert brazil_spec_provider_1.cnpj(True) == '72.721.135/0001-06'
    assert brazil_spec_provider_1.cnpj(False) == '72721135000106'
    assert b

# Generated at 2022-06-25 19:59:05.686812
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import random
    random.seed(0)
    brazil = BrazilSpecProvider()
    str_2 = brazil.cpf()
    assert str_2 == "458.079.942-03"
    return


# Generated at 2022-06-25 19:59:07.095767
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    rnd = BrazilSpecProvider().random
    for _ in range(100):
        assert rnd.cnpj() == BrazilSpecProvider().cnpj()

# Generated at 2022-06-25 19:59:10.531357
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_0.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert '.' in cnpj
    assert '-' in cnpj


# Generated at 2022-06-25 19:59:12.884838
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:59:17.559528
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    random_cpf = BrazilSpecProvider().cpf(with_mask=False)
    first_dv = int(random_cpf[9])
    second_dv = int(random_cpf[10])
    assert(len(random_cpf) == 11)
    assert(first_dv == 1 or first_dv == 0)
    assert(second_dv == 1 or second_dv == 0)


# Generated at 2022-06-25 20:01:28.168756
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18

# Generated at 2022-06-25 20:01:32.203237
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    str = brazil_spec_provider.cnpj()
    
    assert str.count("0") + str.count("1") + str.count("2") + str.count("3") + str.count("4") + \
           str.count("5") + str.count("6") + str.count("7") + str.count("8") + str.count("9") == 14
    assert str.count("-") == 1
    assert str.count(".") == 2
    assert str.count("/") == 1


# Generated at 2022-06-25 20:01:36.568511
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0


# Generated at 2022-06-25 20:01:42.452754
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # BrazilSpecProvider without parameters
    brazil_spec_provider_0 = BrazilSpecProvider()
    # BrazilSpecProvider with parameters
    seed_0 = "34B9717B-DA9C-4E92-8921-5F5FC5FD6E5D"
    brazil_spec_provider_1 = BrazilSpecProvider(seed_0)

    # method cpf without parameters
    str_0 = brazil_spec_provider_0.cpf()
    # method cpf with parameters
    str_1 = brazil_spec_provider_1.cpf(True)

    # str with parameters
    str_2 = BrazilSpecProvider(seed_0).cpf(False)


# Generated at 2022-06-25 20:01:47.924157
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print()
    print('Method "cpf" of class BrazilSpecProvider...', end='')
    # Test 1
    brazil_spec_provider_1 = BrazilSpecProvider()
    cpf_1 = brazil_spec_provider_1.cpf()
    assert len(cpf_1) == 14
    assert cpf_1[3] == cpf_1[7] == '.' and cpf_1[11] == '-'
    assert cpf_1[0:3]+cpf_1[4:7]+cpf_1[8:11]+cpf_1[12:] == brazil_spec_provider_1.cpf(with_mask=False)
    # Test 2
    brazil_spec_provider_2 = BrazilSpecProvider()
    cpf_2 = brazil_spec_prov

# Generated at 2022-06-25 20:01:55.521938
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(seed=0)
    brazil_spec_provider_1 = BrazilSpecProvider(seed=0)
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf()
    str_2 = brazil_spec_provider_1.cpf()
    assert str_0 == str_1 == str_2


# Generated at 2022-06-25 20:02:02.155579
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj()
    str_2 = brazil_spec_provider_0.cnpj()
    str_3 = brazil_spec_provider_0.cnpj()
    str_4 = brazil_spec_provider_0.cnpj()
    str_5 = brazil_spec_provider_0.cnpj()
    str_6 = brazil_spec_provider_0.cnpj()
    str_7 = brazil_spec_provider_0.cnpj()
    str_8 = brazil_spec_provider_0.cnpj()
    str_

# Generated at 2022-06-25 20:02:03.854034
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14


# Generated at 2022-06-25 20:02:05.907263
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed_0 = 0
    Brazil_spec_provider_0 = BrazilSpecProvider(seed=seed_0)
    str_0 = Brazil_spec_provider_0.cpf()
    assert str_0 == '873.816.425-29'



# Generated at 2022-06-25 20:02:12.669424
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed_0 = 0
    seed_1 = 1
    spec_provider_0 = BrazilSpecProvider(seed_1)
    brazil_spec_provider_cpf_str_0 = spec_provider_0.cpf()
    brazil_spec_provider_cpf_str_1 = spec_provider_0.cpf(False)
    brazil_spec_provider_cpf_str_2 = spec_provider_0.cpf(True)
    seed_2 = 2
    seed_3 = 3
    spec_provider_1 = BrazilSpecProvider(seed_3)
    brazil_spec_provider_cpf_str_3 = spec_provider_1.cpf()
    brazil_spec_provider_cpf_str_4 = spec_provider_1.cpf