

# Generated at 2022-06-25 19:55:01.036857
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf(True) == "677.804.631-46"


# Generated at 2022-06-25 19:55:03.841064
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for _ in range(100):
        brazil_spec_provider = BrazilSpecProvider()
        cnpj = brazil_spec_provider.cnpj()
 

# Generated at 2022-06-25 19:55:06.967764
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil_spec_provider = BrazilSpecProvider()

    assert isinstance(brazil_spec_provider.cpf(), str) == True  # Check type
    assert len(brazil_spec_provider.cpf()) == 14 # Check length


# Generated at 2022-06-25 19:55:15.571548
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    def test_case_0():
        brazil_spec_provider_0 = BrazilSpecProvider(seed=314586)
        assert brazil_spec_provider_0.cpf() == '706.294.911-35'
    def test_case_1():
        brazil_spec_provider_1 = BrazilSpecProvider(seed=132109)
        assert brazil_spec_provider_1.cpf() == '847.451.589-97'
    def test_case_2():
        brazil_spec_provider_2 = BrazilSpecProvider(seed=121406)
        assert brazil_spec_provider_2.cpf() == '712.004.759-68'

# Generated at 2022-06-25 19:55:23.745908
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Checks if the generated CNPJ is valid."""
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj(False)  # without mask
    cnpj_number = int(cnpj)
    assert len(str(cnpj_number)) == 14, "cnpj length is not valid"
    assert cnpj_number % 1 == 0, "cnpj is not a number"
    assert type(cnpj_number) == int, "cnpj is not an int"



# Generated at 2022-06-25 19:55:31.789787
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider.cpf()
    cpf_1 = brazil_spec_provider.cpf(with_mask=False)
    # Check if the returned value is a string
    assert isinstance(cpf_0, str), f'{cpf_0} is not a string'
    assert isinstance(cpf_1, str), f'{cpf_1} is not a string'
    # Check if the returned value is a valid cpf
    assert len(cpf_0) == 14, f'{cpf_0} is not a valid cpf'
    assert len(cpf_1) == 11, f'{cpf_1} is not a valid cpf'


# Generated at 2022-06-25 19:55:40.183681
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    actual_cnpjs = []
    n = 1000
    for _ in range(n):
        actual_cnpjs.append(BrazilSpecProvider().cnpj())


# Generated at 2022-06-25 19:55:48.862366
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected_output = "005.151.016-28"
    brazil_spec_provider_0 = BrazilSpecProvider(seed=1781025531829280042)
    actual_output = brazil_spec_provider_0.cpf()
    assert actual_output == expected_output
    assert brazil_spec_provider_0.cpf() == "907.728.082-14"
    assert brazil_spec_provider_0.cpf() == "832.847.622-52"
    assert brazil_spec_provider_0.cpf() == "623.660.835-27"
    assert brazil_spec_provider_0.cpf() == "728.096.066-23"
    assert brazil_spec_provider_0.cpf()

# Generated at 2022-06-25 19:55:51.751985
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    print(brazil_spec_provider_1.cnpj())
    print(brazil_spec_provider_1.cnpj(with_mask=False))


# Generated at 2022-06-25 19:55:55.536871
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert len(cnpj) == 18
    assert brazil_spec_provider.cnpj(with_mask=False) == cnpj.replace(".", "").replace("/", "").replace("-", "")


# Generated at 2022-06-25 19:56:11.161596
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_a = BrazilSpecProvider()

    assert isinstance(brazil_spec_provider_a.cnpj(), str)
    assert len(brazil_spec_provider_a.cnpj()) == 18
    assert brazil_spec_provider_a.cnpj() == '94.126.244/0001-24'

    brazil_spec_provider_b = BrazilSpecProvider()
    assert brazil_spec_provider_a.cnpj() != brazil_spec_provider_b.cnpj()


# Generated at 2022-06-25 19:56:16.608161
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj_0 = brazil_spec_provider_0.cnpj()
    cnpj_1 = brazil_spec_provider_0.cnpj()
    assert len(cnpj_0) == len(cnpj_1)
    assert len(cnpj_1) == 18
    assert cnpj_0 != cnpj_1


# Generated at 2022-06-25 19:56:20.198005
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    result = brazil_spec_provider.cnpj()
    assert isinstance(result, str)


# Generated at 2022-06-25 19:56:26.830454
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil_spec_provider = BrazilSpecProvider()

    cpf = brazil_spec_provider.cpf()
    assert len(cpf) == 14
    assert cpf == brazil_spec_provider.cpf()

    cpf = brazil_spec_provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf[9:] == str(brazil_spec_provider.get_verifying_digit(
        cpf[:9], weight=11, modulo=2))
    assert cpf == brazil_spec_provider.cpf(with_mask=False)


# Generated at 2022-06-25 19:56:30.742895
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    # Test with default arguments
    brazil_spec_provider_0.cpf()
    # Test with different arguments
    brazil_spec_provider_0.cpf(False)


# Generated at 2022-06-25 19:56:35.091864
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
   cnpj = BrazilSpecProvider()
   assert len(cnpj.cnpj()) == 18
   cnpj = cnpj.cnpj(with_mask = True)
   cnpj = cnpj.replace(".","")
   cnpj = cnpj.replace("-","")
   assert len(cnpj) == 14


# Generated at 2022-06-25 19:56:40.766872
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf() == '001.137.297-40'


# Generated at 2022-06-25 19:56:48.374925
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Arrange
    expected_result_0 = r'\d{3}\.\d{3}\.\d{3}\-\d{2}'
    expected_result_1 = r'\d{3}\.\d{3}\.\d{3}\-\d{2}'
    expected_result_2 = r'\d{3}\.\d{3}\.\d{3}\-\d{2}'

    # Act
    brazil_spec_provider_0 = BrazilSpecProvider()
    result_0 = brazil_spec_provider_0.cpf()
    brazil_spec_provider_1 = BrazilSpecProvider(seed=9920)
    result_1 = brazil_spec_provider_1.cpf()
    brazil_spec_provider_2 = BrazilSpec

# Generated at 2022-06-25 19:56:51.569834
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert len(cpf) != 0


# Generated at 2022-06-25 19:56:54.637394
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = 'Test for method cnpj of class BrazilSpecProvider'
    brazil_spec_provider_0 = BrazilSpecProvider(seed=seed)
    assert brazil_spec_provider_0.cnpj() == '24.969.109/0001-44'

if __name__ == "__main__":
    pass

# Generated at 2022-06-25 19:57:11.635347
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider_0 = BrazilSpecProvider()
    brazil_provider_1 = BrazilSpecProvider()
    assert brazil_provider_0.cpf(with_mask=False) != brazil_provider_1.cpf(with_mask=False)
    assert brazil_provider_0.cpf(with_mask=True) != brazil_provider_1.cpf(with_mask=True)
    assert brazil_provider_0.cpf(with_mask=True) != brazil_provider_1.cpf(with_mask=False)
    assert brazil_provider_0.cpf(with_mask=False) != brazil_provider_1.cpf(with_mask=True)

# Generated at 2022-06-25 19:57:17.180594
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test case to check if method cnpj of class BrazilSpecProvider is executed properly.

    Checks if the return value is a string of length 14 or 18.
    """
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert (len(brazil_spec_provider_0.cnpj(with_mask=False)) == 14 or len(brazil_spec_provider_0.cnpj(with_mask=True)) == 18)


# Generated at 2022-06-25 19:57:27.712385
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil_spec_provider_0 = BrazilSpecProvider()
    # cpf_0 stores the returned value of method cpf of object brazil_spec_provider_0
    cpf_0 = brazil_spec_provider_0.cpf()
    assert cpf_0 == '260.391.548-69'
    print(cpf_0)

    brazil_spec_provider_1 = BrazilSpecProvider(seed=8965)
    # cpf_1 stores the returned value of method cpf of object brazil_spec_provider_1
    cpf_1 = brazil_spec_provider_1.cpf()
    assert cpf_1 == '361.580.671-94'
    print(cpf_1)


# Generated at 2022-06-25 19:57:33.915196
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len( BrazilSpecProvider().cpf() ) == 14
    assert BrazilSpecProvider().cpf()[3] == "."
    assert BrazilSpecProvider().cpf()[7] == "."
    assert BrazilSpecProvider().cpf()[11] == "-"
    assert BrazilSpecProvider().cpf()[3:14] == ".".join( BrazilSpecProvider().cpf()[3:14].split(".") )
    assert BrazilSpecProvider().cpf()[9:] == "".join( BrazilSpecProvider().cpf()[9:].split("-") )
    
    

# Generated at 2022-06-25 19:57:37.013949
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()

    # Check if method cpf returns a CPF string with mask
    cpf_string_0 = brazil_spec_provider_1.cpf()
    assert len(cpf_string_0) == 14


# Generated at 2022-06-25 19:57:39.669086
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == '111.654.879-44'


# Generated at 2022-06-25 19:57:45.379827
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cnpj()) == 18
    assert len(brazil_spec_provider_0.cnpj(with_mask=False)) == 14


# Generated at 2022-06-25 19:57:52.327208
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import unittest
    from . import BrazilSpecProvider
    from random import Random

    class Test_BrazilSpecProvider_cpf(unittest.TestCase):
        def test_cpf(self):

            # Initialize
            rd = Random()
            rd.seed(1)
            br_sp = BrazilSpecProvider(seed=rd)

            cpf = br_sp.cpf()
            assert cpf == '944.816.535-04'

            cpf = br_sp.cpf(with_mask=False)
            assert cpf == '94481653504'



# Generated at 2022-06-25 19:57:53.873088
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert isinstance(BrazilSpecProvider().cnpj(), str)


# Generated at 2022-06-25 19:58:04.181529
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(False) == '63632242789'
    assert BrazilSpecProvider().cpf(False) == '64179314864'
    assert BrazilSpecProvider().cpf(False) == '03563331782'
    assert BrazilSpecProvider().cpf(False) == '30572862531'
    assert BrazilSpecProvider().cpf(False) == '72675688721'
    assert BrazilSpecProvider().cpf(False) == '96181644651'
    assert BrazilSpecProvider().cpf(False) == '13554328263'
    assert BrazilSpecProvider().cpf(False) == '72149695775'
    assert BrazilSpecProvider().cpf(False) == '77275737205'

# Generated at 2022-06-25 19:58:23.636275
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.seed(0)
    result_0 = brazil_spec_provider_0.cnpj()
    expected_result_0 = '38.001.319/0001-54'

    # Test one type of result
    assert result_0 == expected_result_0

# Generated at 2022-06-25 19:58:30.429262
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert isinstance(brazil_spec_provider.cnpj(), str)
    assert brazil_spec_provider.cnpj()[0] == '6'
    assert brazil_spec_provider.cnpj()[-2] == '6'
    assert brazil_spec_provider.cnpj(with_mask=False)[-2] == '6'


# Generated at 2022-06-25 19:58:35.054170
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert len(brazil_spec_provider_1.cpf()) == 14
    assert len(brazil_spec_provider_1.cpf(True)) == 14
    assert len(brazil_spec_provider_1.cpf(False)) == 11


# Generated at 2022-06-25 19:58:41.530929
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    def test_case_0():
        brazil_spec_provider_0 = BrazilSpecProvider()
        result = brazil_spec_provider_0.cpf()
    def test_case_1():
        brazil_spec_provider_1 = BrazilSpecProvider()
        result = brazil_spec_provider_1.cpf()
    def test_case_2():
        brazil_spec_provider_2 = BrazilSpecProvider()
        result = brazil_spec_provider_2.cpf()
    def test_case_3():
        brazil_spec_provider_3 = BrazilSpecProvider()
        result = brazil_spec_provider_3.cpf()
    def test_case_4():
        brazil_spec_provider_4 = BrazilSpecProvider()
        result = brazil_

# Generated at 2022-06-25 19:58:44.240554
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:58:45.920744
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    my_BrazilSpecProvider = BrazilSpecProvider()
    assert len(my_BrazilSpecProvider.cpf(with_mask=True)) == 14


# Generated at 2022-06-25 19:58:51.650021
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj_str = brazil_spec_provider_0.cnpj(True)
    cnpj_str2 = brazil_spec_provider_0.cnpj(False)
    # print(cnpj_str)
    assert len(cnpj_str) == 18
    assert len(cnpj_str2) == 14


# Generated at 2022-06-25 19:59:00.057755
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert len(brazil_spec_provider_1.cpf(False)) == 11, 'The length of the returned string is not 11'
    assert len(brazil_spec_provider_1.cpf(True)) == 14, 'The length of the returned string is not 14'
    assert brazil_spec_provider_1.cpf(False).isdigit(), 'The returned string does not contain only digits'
    assert brazil_spec_provider_1.cpf(True).isdigit() or '-', 'The returned string does not contain only digits'
    assert len(brazil_spec_provider_1.cpf(False).replace('-', '')) == 11, 'The length of the returned string is not 11'

# Generated at 2022-06-25 19:59:02.653737
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    results = []

    for _ in range(1000):
        results.append(brazil_spec_provider_1.cnpj())

    assert len(results) == 1000
    assert type(results[0]) == str


# Generated at 2022-06-25 19:59:04.375914
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    cpf = brazil_spec_provider_1.cpf()
    assert cpf
    assert type(cpf) is str


# Generated at 2022-06-25 19:59:49.937583
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # case 0: without mask
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider_0.cpf(with_mask=False)
    assert(len(cpf_0) == 11)
    # case 1: with mask
    brazil_spec_provider_1 = BrazilSpecProvider()
    cpf_1 = brazil_spec_provider_1.cpf(with_mask=True)
    assert(len(cpf_1) == 14)


# Generated at 2022-06-25 19:59:55.129367
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_2 = BrazilSpecProvider()
    brazil_spec_provider_3 = BrazilSpecProvider()
    brazil_spec_provider_4 = BrazilSpecProvider()
    brazil_spec_provider_5 = BrazilSpecProvider()
    brazil_spec_provider_6 = BrazilSpecProvider()
    brazil_spec_provider_7 = BrazilSpecProvider()

    assert ((len(brazil_spec_provider_1.cpf()) == 11)) is True
    assert ((brazil_spec_provider_2.cpf().isdigit()) is True) is True
    assert ((len(brazil_spec_provider_3.cpf()) == 14)) is True

# Generated at 2022-06-25 20:00:00.115207
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj_0 = brazil_spec_provider_0.cnpj(with_mask=False)
    assert cnpj_0 == '96709186000169'
    cnpj_0 = brazil_spec_provider_0.cnpj()
    assert cnpj_0 == '96.709.186/0001-69'


# Generated at 2022-06-25 20:00:04.455112
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert cpf == '907.919.084-81'

# Generated at 2022-06-25 20:00:13.320686
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cnpj(with_mask=True) == '38.548.420/0001-97'
    assert brazil_spec_provider_1.cnpj(with_mask=True) == '725.794.020/0001-05'
    assert brazil_spec_provider_1.cnpj(with_mask=True) == '543.448.620/0001-43'
    assert brazil_spec_provider_1.cnpj(with_mask=True) == '743.498.580/0001-26'
    assert brazil_spec_provider_1.cnpj(with_mask=True) == '762.796.940/0001-82'


# Generated at 2022-06-25 20:00:21.907973
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    array_cnpj_expected = [
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70',
        '77.732.230/0001-70'
    ]

    brazil_spec_provider = BrazilSpecProvider()
    array_cnpj = []

    # Create array of cnpj
    for index in range(10):
        array_cn

# Generated at 2022-06-25 20:00:31.021367
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result = brazil_spec_provider_0.cnpj()
    assert isinstance(result, str)
    assert len(result) == 18
    result = brazil_spec_provider_0.cnpj(True)
    assert isinstance(result, str)
    assert len(result) == 18
    result = brazil_spec_provider_0.cnpj(False)
    assert isinstance(result, str)
    assert len(result) == 14



# Generated at 2022-06-25 20:00:36.231942
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.person.pt_br import Person

    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0_cpf = brazil_spec_provider_0.cpf()
    datetime_0 = Datetime('pt_BR')
    person_0 = Person('pt_BR')
    person_1 = Person('pt_BR', seed=0)
    person_2 = Person('pt_BR', seed=1)
    person_3 = Person('pt_BR', seed=2)



# Generated at 2022-06-25 20:00:40.122944
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed_0 = Seed()
    brazil_spec_provider_0 = BrazilSpecProvider(seed=seed_0)
    assert (brazil_spec_provider_0.cpf(with_mask=False) == '67628152663')


# Generated at 2022-06-25 20:00:46.479074
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider_0 = BrazilSpecProvider()
    actual_result_0 = provider_0.cpf(True)
    expected_result_0 = '111.343.093-34'
    assert actual_result_0 == expected_result_0
    actual_result_1 = provider_0.cpf(False)
    expected_result_1 = '23306544015'
    assert actual_result_1 == expected_result_1

# Generated at 2022-06-25 20:02:02.652353
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:02:07.733860
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj_0_0 = brazil_spec_provider_0.cnpj(True)
    assert cnpj_0_0 == "54.756.861/0001-83"
    cnpj_0_1 = brazil_spec_provider_0.cnpj(True)
    assert cnpj_0_1 == "06.066.595/0001-65"
    cnpj_0_2 = brazil_spec_provider_0.cnpj(True)
    assert cnpj_0_2 == "29.520.653/0001-96"
    cnpj_0_3 = brazil_spec_provider_0.cnpj(True)

# Generated at 2022-06-25 20:02:10.649825
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()

    assert brazil.cpf() == brazil.cpf(with_mask=True)
    assert brazil.cpf(with_mask=False) == 92360289499
    assert brazil.cpf(with_mask=True) == '923.602.894-99'


# Generated at 2022-06-25 20:02:19.486015
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == '783.823.184-34'
    assert brazil_spec_provider_0.cpf() == '350.380.305-29'
    assert brazil_spec_provider_0.cpf() == '263.065.227-20'
    assert brazil_spec_provider_0.cpf() == '845.726.913-47'
    assert brazil_spec_provider_0.cpf() == '475.724.825-84'
    assert brazil_spec_provider_0.cpf() == '663.863.109-51'

# Generated at 2022-06-25 20:02:25.524258
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_cnpj_1 = brazil_spec_provider_1.cnpj()
    brazil_spec_cnpj_with_mask_1 = brazil_spec_provider_1.cnpj(True)

    assert isinstance(brazil_spec_cnpj_1, str) and len(brazil_spec_cnpj_1) == 14
    assert isinstance(brazil_spec_cnpj_with_mask_1, str) and len(brazil_spec_cnpj_with_mask_1) == 18


# Generated at 2022-06-25 20:02:30.921283
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cpf()) == 14
    assert len(brazil_spec_provider_0.cpf(False)) == 11


# Generated at 2022-06-25 20:02:38.370056
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test 1
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider_0.cpf()
    assert (cpf_0 == '000.000.000-00')

    # Test 2
    brazil_spec_provider_1 = BrazilSpecProvider()
    cpf_1 = brazil_spec_provider_1.cpf(True)
    assert (cpf_1 == '001.137.297-40')

    # Test 3
    brazil_spec_provider_2 = BrazilSpecProvider()
    cpf_2 = brazil_spec_provider_2.cpf(False)
    assert (cpf_2 == '00113729740')


# Generated at 2022-06-25 20:02:42.651445
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert isinstance(brazil_spec_provider_0.cpf(), str)
    assert len(brazil_spec_provider_0.cpf()) == 14


# Generated at 2022-06-25 20:02:49.357514
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider(seed=1)

    cpf = brazil_spec_provider_1.cpf()
    assert cpf == '161.933.684-62'
    assert len(cpf) == 14

    cpf = brazil_spec_provider_1.cpf(with_mask=False)
    assert cpf == '16193368462'
    assert len(cpf) == 11



# Generated at 2022-06-25 20:02:54.107318
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    result = brazil_spec_provider.cnpj()
    assert type(result) == str
    assert len(result) == 14
    result = brazil_spec_provider.cnpj(with_mask=False)
    assert type(result) == str
    assert len(result) == 14
