

# Generated at 2022-06-25 19:54:58.619437
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0


# Generated at 2022-06-25 19:55:04.923971
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider(seed=10)
    assert brazil_spec_provider.cpf() == '494.865.306-66'
    assert brazil_spec_provider.cpf(with_mask=False) == '49486530666'
    assert brazil_spec_provider.cpf(with_mask=True) == '494.865.306-66'


# Generated at 2022-06-25 19:55:07.731491
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_3 = brazil_spec_provider.cpf()
    assert len(str_3) == 14
    assert str_3[3] == '.'
    assert str_3[7] == '.'
    assert str_3[11] == '-'


# Generated at 2022-06-25 19:55:10.181579
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider_0.cpf()
    cpf_1 = brazil_spec_provider_0.cpf(True)
    assert cpf_0 == "02680343575"
    assert cpf_1 == "026.803.435-75"


# Generated at 2022-06-25 19:55:14.384949
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_0.cpf()
    assert isinstance(str_1, str)
    assert len(str_1) == 14
    assert str_1.find('-') >= 0
    assert str_1.find('.') >= 0


# Generated at 2022-06-25 19:55:19.695628
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()

    assert str_0 is not None
    assert len(str_0) == 14
    assert str_0[3] == '.'
    assert str_0[7] == '.'
    assert str_0[11] == '-'



# Generated at 2022-06-25 19:55:23.278282
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 == '59.533.401/4310-49'


# Generated at 2022-06-25 19:55:28.941183
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BrazilSpecProvider_cnpj_0 = BrazilSpecProvider()
    str_0 = BrazilSpecProvider_cnpj_0.cnpj()
    BrazilSpecProvider_cnpj_1 = BrazilSpecProvider()
    str_1 = BrazilSpecProvider_cnpj_1.cnpj()
    assert str_0 == '13.566.446/0001-58'
    assert str_1 == '46.959.823/0001-01'


# Generated at 2022-06-25 19:55:31.827029
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 == '74.744.140/0001-02'


# Generated at 2022-06-25 19:55:37.519962
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf()) == 14
    assert len(brazil_spec_provider.cpf(with_mask=False)) == 11
    with_mask =  brazil_spec_provider.cpf(with_mask=True)
    assert with_mask[3] == '.'
    assert with_mask[7] == '.'
    assert with_mask[11] == '-'


# Generated at 2022-06-25 19:55:52.063968
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:55:54.364374
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18


# Generated at 2022-06-25 19:55:56.492918
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:56:00.819868
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider(seed=2001903390038732874)
    str_0 = brazil_spec_provider_0.cnpj(with_mask=True)
    assert str_0 == '77.732.230/0001-70'



# Generated at 2022-06-25 19:56:12.091459
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Tests if cpf method of class BrazilSpecProvider return a string
    assert isinstance(BrazilSpecProvider().cpf(), str), 'Returned value is not a string'
    # Tests if cpf method of class BrazilSpecProvider return a string with 11 chars
    assert len(BrazilSpecProvider().cpf()) == 11, 'Returned value should have 11 chars'
    # Tests if cpf method of class BrazilSpecProvider return a string with 9 characteres and 2 dots
    assert '.' in BrazilSpecProvider().cpf()[3:6] and '.' in BrazilSpecProvider().cpf()[6:9], 'Dots are not placed in the correct position'
    # Tests if cpf method of class BrazilSpecProvider return a string with a minus
    assert '-' in BrazilSpecProvider().cpf(), 'Returned value should have a minus'
    # Tests if cpf

# Generated at 2022-06-25 19:56:14.239286
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18


# Generated at 2022-06-25 19:56:18.774026
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 != ''


# Generated at 2022-06-25 19:56:22.012335
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf(False)
    assert str_0 == ('903.494.816-33')
    assert str_1 == ('9034941633')



# Generated at 2022-06-25 19:56:24.355483
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:56:27.681098
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    str_0 = BrazilSpecProvider.cpf(None)
    assert len(str_0) == 14



# Generated at 2022-06-25 19:56:53.594154
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-25 19:56:56.088098
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj(with_mask=False)


# Generated at 2022-06-25 19:56:58.043255
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()



# Generated at 2022-06-25 19:57:01.870288
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0.count('.') == 2
    assert str_0.count('/') == 1
    assert str_0.count('-') == 1
    assert isinstance(str_0, str)
    assert len(str_0) == 18


# Generated at 2022-06-25 19:57:04.825656
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:57:06.732019
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert (str_0 == '001.137.297-40') is True


# Generated at 2022-06-25 19:57:09.605238
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert isinstance(str_0, str)

# Generated at 2022-06-25 19:57:12.781723
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    print(str_0)



# Generated at 2022-06-25 19:57:16.505128
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    cnpj_with_mask = BrazilSpecProvider().cpf()
    assert (cnpj_with_mask[3] == '.')

    cnpj_without_mask = BrazilSpecProvider().cpf(False)
    assert (cnpj_without_mask[3] != '.')


# Generated at 2022-06-25 19:57:20.082578
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert len(cpf) == 14
    assert len(brazil_spec_provider.cpf(with_mask=False)) == 11
    assert len(brazil_spec_provider.cnpj()) == 18
    assert len(brazil_spec_provider.cnpj(with_mask=False)) == 14

# Generated at 2022-06-25 19:58:17.812391
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed1 = '<seed>'
    seed2 = '<seed>'
    seed3 = '<seed>'
    brazil1 = BrazilSpecProvider(seed=seed1)
    brazil2 = BrazilSpecProvider(seed=seed2)
    brazil3 = BrazilSpecProvider(seed=seed3)
    expected1 = '766.193.387-03'
    expected2 = '989.384.912-87'
    expected3 = '244.274.095-82'
    assert brazil1.cpf() == expected1
    assert brazil2.cpf() == expected2
    assert brazil3.cpf() == expected3



# Generated at 2022-06-25 19:58:22.641818
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert (type(brazil_spec_provider_0.cpf()) == str)
    assert (len(brazil_spec_provider_0.cpf()) == 14)


# Generated at 2022-06-25 19:58:27.787034
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert len(cpf) == 14
    assert cpf.count('.') == 2 and cpf.count('-') == 1


# Generated at 2022-06-25 19:58:30.752849
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br_provider =  BrazilSpecProvider()
    assert br_provider.cpf() == '961.469.249-85'

# Unit tests for method cpf of class BrazilSpecProvider

# Generated at 2022-06-25 19:58:33.897723
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:58:37.130532
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str = brazil_spec_provider.cpf()
    assert len(str) == 14
    assert str[3] == "."
    assert str[7] == "."
    assert str[11] == "-"


# Generated at 2022-06-25 19:58:41.819344
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    print(str_0)


# Generated at 2022-06-25 19:58:47.694761
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    with open("tests/data/cpf_test_cases.txt", "r") as file_0:
        for line_0 in file_0:
            str_0 = line_0.strip()
            brazil_spec_provider_0 = BrazilSpecProvider()
            str_1 = brazil_spec_provider_0.cpf()
            assert str_0 == str_1


# Generated at 2022-06-25 19:58:51.515446
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    # Should be a cpf string with mask
    assert len(str_0) == 14 and str_0.count('.') == 2 and str_0.count('-') == 1


# Generated at 2022-06-25 19:58:54.401005
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'



# Generated at 2022-06-25 20:01:15.971935
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('Testing method BrazilSpecProvider.cpf')
    for i in range(10000):
        cpf_str = BrazilSpecProvider().cpf()
        assert cpf_str.count('.') == 2
        assert cpf_str.count('-') == 1

        cpf_str = BrazilSpecProvider().cpf(with_mask=False)
        assert cpf_str.count('.') == 0
        assert cpf_str.count('-') == 0



# Generated at 2022-06-25 20:01:17.575268
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:01:21.131196
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider_cpf_0 = BrazilSpecProvider()
    str_0 = BrazilSpecProvider_cpf_0.cpf()
    assert len(str_0) == 14



# Generated at 2022-06-25 20:01:23.395056
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj(True)
    assert str_1 == '90.100.916/0001-01'
    assert len(str_1) == 18

# Generated at 2022-06-25 20:01:26.510243
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj()
    set_1 = set(str_1)

    assert {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '/', '-', '.'} == set_1


# Generated at 2022-06-25 20:01:28.748648
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    # assert str(brazil_spec_provider.cpf()) == "37.780.002/0001-50"
    assert brazil_spec_provider.cpf() == "37.780.002/0001-50"


# Generated at 2022-06-25 20:01:29.535563
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-25 20:01:31.380680
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_0.cnpj()
    assert cnpj == "70.899.457/0001-21"


# Generated at 2022-06-25 20:01:41.556909
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert str(brazil_spec_provider.cpf()).count('-') == 1  # assert for the presence of the '-' symbol
    assert str(brazil_spec_provider.cpf()).count('.') == 2  # assert for the presence of the '.' symbol
    assert len(str(brazil_spec_provider.cpf())) == 14  # assert for the length of cpf
    assert str(brazil_spec_provider.cpf())[3] == '.'  # assert for the position of '.'
    assert str(brazil_spec_provider.cpf())[7] == '.'  # assert for the position of '.'
    assert str(brazil_spec_provider.cpf())[11] == '-'  # assert for

# Generated at 2022-06-25 20:01:43.324314
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18
