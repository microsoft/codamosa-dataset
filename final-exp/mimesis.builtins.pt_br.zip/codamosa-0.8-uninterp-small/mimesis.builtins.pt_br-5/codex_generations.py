

# Generated at 2022-06-25 19:55:04.641243
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()

    cnpj_0 = brazil_spec_provider.cnpj()
    assert isinstance(cnpj_0, str)

    cnpj_1 = brazil_spec_provider.cnpj(True)
    assert isinstance(cnpj_1, str)


# Generated at 2022-06-25 19:55:07.646379
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    # Test 1
    brazil_spec_provider_cpf_1 = brazil_spec_provider.cpf()
    assert type(brazil_spec_provider_cpf_1) is str
    assert len(brazil_spec_provider_cpf_1) == 14


# Generated at 2022-06-25 19:55:11.484359
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_cpf = BrazilSpecProvider()
    assert brazil_spec_provider_cpf.cpf(with_mask=True) == brazil_spec_provider_cpf.cpf(with_mask=True)


# Generated at 2022-06-25 19:55:14.136751
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj().__len__() == 18


# Generated at 2022-06-25 19:55:18.955066
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj_result = brazil_spec_provider_0.cnpj(with_mask=True)
    assert isinstance(cnpj_result, str)
    assert cnpj_result.strip()=="74.114.998/0001-22"


# Generated at 2022-06-25 19:55:26.734846
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()

    assert type(brazil_spec_provider_1.cnpj()) == str
    assert len(brazil_spec_provider_1.cnpj()) == 18
    assert len(brazil_spec_provider_1.cnpj(with_mask = False)) == 14

    assert type(brazil_spec_provider_1.cnpj(with_mask = False)) == str
    assert len(brazil_spec_provider_1.cnpj(with_mask = False)) == 14


# Generated at 2022-06-25 19:55:31.454179
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert isinstance(brazil_spec_provider_0.cpf(), str)
    assert len(brazil_spec_provider_0.cpf()) == 14
    assert isinstance(brazil_spec_provider_0.cpf(with_mask=False), str)
    assert len(brazil_spec_provider_0.cpf(with_mask=False)) == 11


# Generated at 2022-06-25 19:55:32.975022
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '635.887.828-78'


# Generated at 2022-06-25 19:55:37.118828
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for _ in range(100):
        brazil_spec_provider_0 = BrazilSpecProvider()
        brazil_spec_provider_0.cnpj()
        brazil_spec_provider_0.cnpj(True)
        brazil_spec_provider_0.cnpj(False)


# Generated at 2022-06-25 19:55:45.337832
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result_cnpj = brazil_spec_provider_0.cnpj()
    assert type(result_cnpj) is str
    # Test that the string has exactly 14 chars
    assert len(result_cnpj) is 14
    # Test if string literal is only numbers and the special chars '.' and '-'
    assert result_cnpj.isdigit() or result_cnpj.endswith('.') or result_cnpj.endswith('-')
    # Test that '.' is the 3rd and 6th char, and '-' is the 11th char
    assert result_cnpj[2] is '.' and result_cnpj[5] is '.' and result_cnpj[10] is '-'

# Unit test

# Generated at 2022-06-25 19:55:55.854187
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_1_cnpj_0 = brazil_spec_provider_1.cnpj()
    brazil_spec_provider_1_cnpj_1 = brazil_spec_provider_1.cnpj(with_mask=False)


# Generated at 2022-06-25 19:56:02.103663
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    cpf = brazil_spec_provider_1.cpf()
    assert len(cpf) == 14
    assert cpf[:3] != '000'
    assert cpf[4:7] != '000'
    assert cpf[8:11] != '000'
    assert cpf[12] != '0'
    assert cpf[-2] != '0'


# Generated at 2022-06-25 19:56:07.438021
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf()) == 14
    assert len(brazil_spec_provider.cpf(False)) == 11


# Generated at 2022-06-25 19:56:16.574578
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    # Creating the object BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()
    print('\nMethod cpf call with_mask = True')

    # Call method cpf with parameter with_mask = True
    result = brazil_spec_provider.cpf(with_mask=True)
    print('Real Result: {}'.format(result))
    print('Expected Result: ###.###.###-##')

    print('\nMethod cpf call with_mask = False')

    # Call method cpf with parameter with_mask = False
    result = brazil_spec_provider.cpf(with_mask=False)
    print('Real Result: {}'.format(result))
    print('Expected Result: #######-#')



# Generated at 2022-06-25 19:56:26.341473
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cpf()
    brazil_spec_provider_0.cpf(True)
    brazil_spec_provider_0.cpf(True)
    brazil_spec_provider_0.cpf(True)
    brazil_spec_provider_0.cpf(True)
    brazil_spec_provider_0.cpf(True)
    brazil_spec_provider_0.cpf(True)
    brazil_spec_provider_0.cpf(True)
    brazil_spec_provider_0.cpf(True)
    brazil_spec_provider_0.cpf(True)

# Generated at 2022-06-25 19:56:31.459219
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert len(brazil_spec_provider_1.cpf()) == 14
    assert len(brazil_spec_provider_1.cpf(False)) == 11
    assert brazil_spec_provider_1.cpf(True) == brazil_spec_provider_1.cpf()


# Generated at 2022-06-25 19:56:38.365897
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf_without_mask = brazil_spec_provider.cpf(with_mask=False)
    assert cpf_without_mask.isdigit() is True
    assert len(cpf_without_mask) == 11

    cpf_with_mask = brazil_spec_provider.cpf(with_mask=True)
    assert cpf_with_mask.isdigit() is False
    assert '-' in cpf_with_mask
    assert '.' in cpf_with_mask


# Generated at 2022-06-25 19:56:42.370096
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # BrazilSpecProvider instance
    brazil_spec_provider_1 = BrazilSpecProvider()
    # Generate cpf
    assert len(brazil_spec_provider_1.cpf()) == 14  # Return a string


# Generated at 2022-06-25 19:56:45.778317
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider(seed='brazil_spec_provider')
    for _ in range(1000):
        assert len(brazil_spec_provider.cpf()) == 14
        assert len(brazil_spec_provider.cpf(False)) == 11


# Generated at 2022-06-25 19:56:50.780777
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    # Test dummy data
    cpf1 = brazil_spec_provider_1.cpf()
    cpf2 = brazil_spec_provider_1.cpf()
    assert (len(cpf1) == 14)
    assert (len(cpf2) == 14)
    assert (cpf1 != cpf2)
    cpf1_2 = brazil_spec_provider_1.cpf(with_mask=False)
    cpf2_2 = brazil_spec_provider_1.cpf(with_mask=False)
    assert (len(cpf1_2) == 11)
    assert (len(cpf2_2) == 11)
    assert (cpf1_2 != cpf2_2)



# Generated at 2022-06-25 19:56:59.276379
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider()
    assert(a.cpf() == '412.912.479-65')
    assert(a.cpf(with_mask=False) == '41291247965')


# Generated at 2022-06-25 19:57:01.539394
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider(seed=None)
    cpf = brazil_spec_provider_1.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-25 19:57:05.067165
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(with_mask=True) == '939.052.842-96'
    assert BrazilSpecProvider().cpf(with_mask=False) == '93905284263'


# Generated at 2022-06-25 19:57:12.270619
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    with_mask1 = True
    with_mask2 = False

    brazil_spec_provider_cnpj = BrazilSpecProvider()
    cnpj_with_mask1 = brazil_spec_provider_cnpj.cnpj(with_mask1)
    cnpj_with_mask2 = brazil_spec_provider_cnpj.cnpj(with_mask2)

    assert len(cnpj_with_mask1) == 18
    assert len(cnpj_with_mask2) == 14


# Generated at 2022-06-25 19:57:19.845834
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert BrazilSpecProvider().cnpj(False) not in ['00000000000000', '11111111111111', '22222222222222', '33333333333333', '44444444444444', '55555555555555', '66666666666666', '77777777777777', '88888888888888', '99999999999999']

# Generated at 2022-06-25 19:57:25.540653
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    cpf=brazil_spec_provider_1.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[12:].isdigit()


# Generated at 2022-06-25 19:57:29.042153
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf() == "474.902.339-02"
    assert brazil_spec_provider.cpf(with_mask=False) == "47490233902"


# Generated at 2022-06-25 19:57:37.186765
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    print('test_BrazilSpecProvider_cpf')
    brazil_spec_provider_1 = BrazilSpecProvider(seed=0)
    cpfs_1 = ['056.929.895-45', '184.341.011-69', '055.827.543-35',
              '691.924.898-46', '659.350.457-76', '046.856.537-01',
              '834.741.967-48', '235.073.822-36', '632.574.087-87',
              '476.913.444-30']

# Generated at 2022-06-25 19:57:39.839748
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    generated_cnpj = brazil_spec_provider.cnpj()
    print(generated_cnpj)


# Generated at 2022-06-25 19:57:44.853917
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    
    brazil_spec_provider_1 = BrazilSpecProvider()

    # test with mask = True
    assert len(brazil_spec_provider_1.cnpj()) == 18


# Generated at 2022-06-25 19:58:07.674282
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj0 = BrazilSpecProvider().cnpj()
    assert cnpj0 == '01.639.179/0002-95'

    cnpj1 = BrazilSpecProvider().cnpj()
    assert cnpj1 == '95.488.872/0001-46'

    cnpj2 = BrazilSpecProvider().cnpj()
    assert cnpj2 == '74.513.763/0002-00'

    cnpj3 = BrazilSpecProvider().cnpj()
    assert cnpj3 == '16.781.503/0003-62'

    cnpj4 = BrazilSpecProvider().cnpj()
    assert cnpj4 == '42.028.250/0004-24'

    cnpj5 = BrazilSpecProvider().cnpj()

# Generated at 2022-06-25 19:58:08.763161
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj()


# Generated at 2022-06-25 19:58:10.773099
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()

    cnpj_0 = brazil_spec_provider_1.cnpj()

    assert (cnpj_0 != None)


# Generated at 2022-06-25 19:58:13.546527
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result = brazil_spec_provider_0.cnpj(with_mask = False)
    assert isinstance(result, str)


# Generated at 2022-06-25 19:58:23.871054
# Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-25 19:58:27.787011
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '13.638.848/0001-46'
    assert provider.cnpj(with_mask=False) == '13638848000146'


# Generated at 2022-06-25 19:58:30.119920
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert cpf == '235.857.319-08'


# Generated at 2022-06-25 19:58:33.896001
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf(True)) == 14
    assert brazil_spec_provider.cpf(False).isdigit()


# Generated at 2022-06-25 19:58:40.725983
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0_cpf = brazil_spec_provider_0.cpf()
    assert brazil_spec_provider_0_cpf == '596.180.024-18'
    assert brazil_spec_provider_0_cpf == '732.249.442-79'
    brazil_spec_provider_0_cpf = brazil_spec_provider_0.cpf()
    assert brazil_spec_provider_0_cpf == '936.574.976-34'
    assert brazil_spec_provider_0_cpf == '849.197.931-25'
    brazil_spec_provider_0_cpf = brazil_spec_provider_

# Generated at 2022-06-25 19:58:45.019774
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    with_mask = True
    result = brazil_spec_provider_0.cnpj(with_mask)
    print(result)


# Generated at 2022-06-25 19:59:26.523338
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == '893.867.938-88'
    assert brazil_spec_provider_0.cpf() == '330.216.898-62'
    assert brazil_spec_provider_0.cpf() == '049.619.795-72'
    assert brazil_spec_provider_0.cpf() == '832.464.896-06'
    assert brazil_spec_provider_0.cpf() == '893.867.938-88'


# Generated at 2022-06-25 19:59:28.127232
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider(seed=0)
    assert '52.852.127/0001-23' == brazil_spec_provider.cnpj()


# Generated at 2022-06-25 19:59:38.121904
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == "482.259.755-55"
    assert brazil_spec_provider_0.cpf() == "367.684.360-63"
    assert brazil_spec_provider_0.cpf() == "652.040.497-15"
    assert brazil_spec_provider_0.cpf() == "457.294.807-16"
    assert brazil_spec_provider_0.cpf() == "955.935.787-53"
    assert brazil_spec_provider_0.cpf() == "244.871.979-22"

# Generated at 2022-06-25 19:59:40.551965
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cpf() == '819.941.082-45'


# Generated at 2022-06-25 19:59:46.943975
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_case_1_input_value = True
    test_case_1_expected_value = '000.000.000-00'

    brazil_spec_provider_1 = BrazilSpecProvider()
    test_case_1_actual_value = brazil_spec_provider_1.cpf(test_case_1_input_value)

    assert test_case_1_actual_value == test_case_1_expected_value



# Generated at 2022-06-25 19:59:50.173977
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()

    assert type(BrazilSpecProvider.cnpj(brazil_spec_provider_0, with_mask=False)) is str
    assert type(BrazilSpecProvider.cnpj(brazil_spec_provider_0, with_mask=True)) is str


# Generated at 2022-06-25 19:59:59.152862
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("run unit test method BrazilSpecProvider.cnpj")
    brazil_spec_provider_0 = BrazilSpecProvider()
    print("Test case 0 :")
    cnpj_0 = brazil_spec_provider_0.cnpj(with_mask=False)
    assert isinstance(cnpj_0, str)
    print(cnpj_0)
    cnpj_0 = brazil_spec_provider_0.cnpj(with_mask=True)
    assert isinstance(cnpj_0, str)
    print(cnpj_0)


# Generated at 2022-06-25 20:00:09.566874
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert cpf
    assert len(cpf) == 14
    cpf = brazil_spec_provider.cpf(with_mask=False)
    assert cpf
    assert len(cpf) == 11
    cpf_list = [brazil_spec_provider.cpf() for _ in range(10)]
    assert len(cpf_list) == 10
    cpf_list = [brazil_spec_provider.cpf(with_mask=False) for _ in range(10)]
    assert len(cpf_list) == 10


# Generated at 2022-06-25 20:00:11.438452
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()


# Generated at 2022-06-25 20:00:17.917428
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj()) == 18
    assert len(brazil_spec_provider.cnpj(with_mask=False)) == 14


# Generated at 2022-06-25 20:01:42.264703
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_1.seed(57)
    cnpj_1 = brazil_spec_provider_1.cnpj(with_mask=True)
    assert cnpj_1 == '19.744.871/0001-78'


# Generated at 2022-06-25 20:01:43.845275
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert type(brazil_spec_provider_1.cpf()) == str


# Generated at 2022-06-25 20:01:45.206222
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cnpj() == '94.340.551/0001-00'


# Generated at 2022-06-25 20:01:46.913415
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_cnpj_0 = BrazilSpecProvider()
    assert brazil_spec_provider_cnpj_0.cnpj() is not None


# Generated at 2022-06-25 20:01:55.840419
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    lista_cnpjs = []
    brazil_spec_provider = BrazilSpecProvider()
    for i in range(0, 1000):
        cnpj = brazil_spec_provider.cnpj(with_mask=True)
        lista_cnpjs.append(cnpj)
        assert len(cnpj) == 18
        assert cnpj[2] == '.'
        assert cnpj[6] == '.'
        assert cnpj[10] == '/'
        assert cnpj[15] == '-'
        assert cnpj[17] != '5'



# Generated at 2022-06-25 20:02:01.618969
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'



# Generated at 2022-06-25 20:02:03.436476
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == "71.676.718/0001-06"
    assert BrazilSpecProvider().cnpj(with_mask=False) == "71676718000106"


# Generated at 2022-06-25 20:02:04.464474
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '09.857.971/0001-21'


# Generated at 2022-06-25 20:02:06.107382
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf1 = bsp.cpf()
    cpf2 = bsp.cpf()
    assert cpf1 != cpf2


# Generated at 2022-06-25 20:02:07.880931
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    try:
        print(BrazilSpecProvider().cnpj())
    except TypeError:
        assert False
    else:
        assert True


# Generated at 2022-06-25 20:04:15.223359
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test result with two different random seeds
    brazil_spec_provider_0 = BrazilSpecProvider(seed=0)
    brazil_spec_provider_1 = BrazilSpecProvider(seed=1)
    for _ in range(1):
        assert brazil_spec_provider_0.cnpj() != brazil_spec_provider_1.cnpj()
    # Test results with and without the mask
    brazil_spec_provider_2 = BrazilSpecProvider(seed=2)
    assert len(brazil_spec_provider_0.cnpj()) == 14
    assert len(brazil_spec_provider_0.cnpj(with_mask=True)) == 18
    assert brazil_spec_provider_0.cnpj() == '02649071000198'
    assert brazil

# Generated at 2022-06-25 20:04:17.434973
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    print(brazil_spec_provider_0.cpf())


# Generated at 2022-06-25 20:04:23.038352
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    Unit test for method BrazilSpecProvider.cnpj(with_mask: bool = True)
    """
    cases = [
        {"with_mask": True},
        {"with_mask": False}
    ]

    brazil_spec_provider = BrazilSpecProvider()

    for case in cases:
        assert isinstance(brazil_spec_provider.cnpj(case['with_mask']), str)


# Generated at 2022-06-25 20:04:27.327489
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import pytest
    from unittest.mock import patch

    with patch('mimesis.builtins.Brazil.spec.BrazilSpecProvider.seed') as mock_seed:
        mock_seed.return_value = 'MY_SEED'
        brazil_spec_provider = BrazilSpecProvider()
    with patch('mimesis.builtins.Brazil.spec.BrazilSpecProvider.random') as mock_random:
        mock_random.randint = lambda x, y: 1
        assert brazil_spec_provider.cnpj() == '11.111.111/1111-11'
        assert brazil_spec_provider.cnpj(with_mask=False) == '11111111111111'


# Generated at 2022-06-25 20:04:31.134520
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cnpj() == brazil_spec_provider_1.cnpj()


# Generated at 2022-06-25 20:04:34.407450
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Testing cpf")
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert (len(cpf) == 14) or (len(cpf) == 11)


# Generated at 2022-06-25 20:04:39.048880
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    # test case 0
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider_0.cpf()
    assert len(cpf_0) == 14
    assert cpf_0[3] == '.'
    assert cpf_0[7] == '.'
    assert cpf_0[11] == '-'

    # test case 1
    brazil_spec_provider_1 = BrazilSpecProvider()
    cpf_1 = brazil_spec_provider_1.cpf()
    assert len(cpf_1) == 14
    assert cpf_1[3] == '.'
    assert cpf_1[7] == '.'
    assert cpf_1[11] == '-'

# Generated at 2022-06-25 20:04:42.011295
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:04:44.516737
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert '15.695.355/0001-00' == brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:04:47.282402
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    value = brazil_spec_provider_0.cpf()
    assert len(value) == 14
    assert str(value).isdigit() == True
    assert any([c.isalpha() for c in str(value)]) == False
