

# Generated at 2022-06-25 19:55:04.117439
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14


# Generated at 2022-06-25 19:55:08.513198
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bytes_0 = b'\xd4\x1a\x84\xf8\xc6\xb1\x1c@\x03\x8d\x9d\xcd\x12\xa6\x10\xac\xed\xee\xaa\xe8\x9c'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    str_0 = brazil_spec_provider_0.cnpj(False)
    assert str_0 == '02286030008464'


# Generated at 2022-06-25 19:55:14.972212
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\x03\xcfM\x8a\xc5\xed\xdd\x1d\xf8\xfb\x0f\x89\xfa\x8f\xb4'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    assert brazil_spec_provider_0.cpf() == '282.912.971-13'
    assert brazil_spec_provider_0.cpf(with_mask=False) == '28291297112'


# Generated at 2022-06-25 19:55:18.458508
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Create an instance of class BrazilSpecProvider
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert isinstance(brazil_spec_provider_0.cpf(), str)


# Generated at 2022-06-25 19:55:23.973380
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\x97\x9c\x9bP\xe0"\x11\xfd\xa0\x1cQ\x9f\x02\x01\xb9'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    assert brazil_spec_provider_0.cpf(False) == '36238258461'


# Generated at 2022-06-25 19:55:27.475257
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert (len(BrazilSpecProvider().cnpj()) == 14)
    assert (len(BrazilSpecProvider().cnpj(with_mask=False)) == 14)
    assert (len(BrazilSpecProvider().cnpj()) == 18)
    assert (len(BrazilSpecProvider().cnpj(with_mask=False)) == 18)


# Generated at 2022-06-25 19:55:32.201149
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    brazil_spec_provider_0_0 = brazil_spec_provider_0.cnpj()
    assert True


# Generated at 2022-06-25 19:55:34.107099
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:55:42.627959
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bytes_1 = b'\x0f\xe2\x93\xb9\x9a\xce\x80;\xd8\xac\x8e\xfb\xe5\x08\xeb\x9a'
    brazil_spec_provider_1 = BrazilSpecProvider(bytes_1)
    str_0 = brazil_spec_provider_1.cnpj()
    str_1 = brazil_spec_provider_1.cnpj()
    str_2 = brazil_spec_provider_1.cnpj()
    str_3 = brazil_spec_provider_1.cnpj()
    assert str_1 != str_0
    assert str_1 != str_2
    assert str_2 != str_3


# Generated at 2022-06-25 19:55:44.708097
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() is not None


# Generated at 2022-06-25 19:56:08.215566
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\x85\xe8/\xbd\x97\x0e\x07\xe9\x9d\xb1\xc9\xac\xee\x8e'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    str_0 = brazil_spec_provider_0.cpf(with_mask=False)
    str_1 = brazil_spec_provider_0.cpf(with_mask=True)
    assert str_0 == '23132710215'
    assert str_1 == '231.327.102-15'


# Generated at 2022-06-25 19:56:14.574890
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 == '04.828.128/0001-10'


# Generated at 2022-06-25 19:56:22.993788
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '973.766.551-58', 'AssertionError: {0}'.format(str_0)


# Generated at 2022-06-25 19:56:28.091369
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Arrange
    seed = b'\xab\x9c\xa4\xaa\xaf\xafL\xd5\x1f\x1a\xfa\x8a\x9e\x9b/\x8e'
    brazil_spec_provider_0 = BrazilSpecProvider(seed)
    expected_0 = '64.875.256/0001-84'
    # Act
    actual_0 = brazil_spec_provider_0.cnpj(True)
    # Assert
    assert expected_0 == actual_0


# Generated at 2022-06-25 19:56:30.743359
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = brazil_spec_provider_0.cpf()
    print(result)
    # Example result: '335.238.027-72'


# Generated at 2022-06-25 19:56:33.569668
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider_0 = BrazilSpecProvider()
    result_0 = provider_0.cpf()
    assert result_0 is not None
    assert type(result_0) is str


# Generated at 2022-06-25 19:56:38.974903
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bytes_0 = b')\x9c\x9e\xfa\xe8\xb0-\xcb\xab*\x98\x10\\\x90\xbd\x84\x10\x1c'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    arg_0 = True
    if arg_0:
        brazil_spec_provider_0.cnpj()
    assert True


# Generated at 2022-06-25 19:56:47.293592
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_2 = b'\xde0\xdc\x81\xcd\xa9\x1c\xb7\x14\xa0\xec\x01\x1b\x0b'
    brazil_spec_provider_1 = BrazilSpecProvider(bytes_2)
    str_0 = brazil_spec_provider_1.cpf()
    assert isinstance(str_0, str)
    assert len(str_0) == 14
    for k, v in enumerate(str_0):
        assert str_0[k] in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '-']


# Generated at 2022-06-25 19:56:55.339088
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    name_0 = 'BrazilSpecProvider.cnpj'
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = '48.182.879/0001-89'
    assert brazil_spec_provider_0.cnpj(True) == str_0
    str_0 = '16.434.918/0001-84'
    assert brazil_spec_provider_0.cnpj(True) == str_0


# Generated at 2022-06-25 19:56:58.300054
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Setup
    byte_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider = BrazilSpecProvider(byte_0)
    # Assertions
    # Execution
    brazil_spec_provider.cnpj(True)


# Generated at 2022-06-25 19:57:31.526304
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xd2\xe1\xad\xb3\x80\x85\xcf\x81\xe2h'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    # Test with default arguments
    assert (brazil_spec_provider_0.cpf() == '338.988.439-97')
    # Test with explicit arguments
    assert (brazil_spec_provider_0.cpf(False) == '33898843997')
    assert (brazil_spec_provider_0.cpf(True) == '338.988.439-97')


# Generated at 2022-06-25 19:57:36.042633
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b"S'\x8b0\xf4\x99\xde\x0b\xd4\xa4\x1c\xe6\x8e\xed"
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '379.989.293-03'



# Generated at 2022-06-25 19:57:39.549095
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xae\x8c%\xe7\x80u\x15\x9f\xfb\x03\xc3F\x15\xf3\x92\x1d'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    brazil_spec_provider_0.cpf(False)


# Generated at 2022-06-25 19:57:43.078890
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # This method tests case #0
    test_case_0()


# Generated at 2022-06-25 19:57:49.147365
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    assert brazil_spec_provider_0.cpf() == '418.168.616-29'
    assert brazil_spec_provider_0.cpf(with_mask=False) == '41816861629'


# Generated at 2022-06-25 19:57:51.446730
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    spec_provider = BrazilSpecProvider()
    result = spec_provider.cpf()
    assert result is not None


# Generated at 2022-06-25 19:57:57.149503
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = b'@\x88\xe6&\x83\x87V\x1d\xab\x9e\x87\xf2\x12\x14\x8b\x1e'
    brazil_spec_provider_0 = BrazilSpecProvider(seed=seed)
    result = brazil_spec_provider_0.cnpj()
    assert result == '33.767.925/0001-53'


# Generated at 2022-06-25 19:58:02.699496
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(seed)
    brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:58:05.617944
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cnpj = brazil_spec_provider_0.cnpj()
    assert cnpj == '12.934.480/0001-64'


# Generated at 2022-06-25 19:58:09.853523
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    str_0 = brazil_spec_provider_0.cpf(False)
    assert str_0 == '63003721006'


# Generated at 2022-06-25 19:59:16.019968
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    # This will throw an error. 
    # It seems that whenever with-mask argument is False, 
    # it appends a wrong mask for the generated CPF number.
    brazil_spec_provider_0.cpf(False) 


# Generated at 2022-06-25 19:59:20.591243
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider = BrazilSpecProvider(seed)
    cpf = brazil_spec_provider.cpf()
    assert cpf == '991.663.633-07'


# Generated at 2022-06-25 19:59:24.790692
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from random import Random

    seed_0 = Random()
    seed_0.seed(3701666840)
    brazil_spec_provider_0 = BrazilSpecProvider(seed=seed_0)
    assert brazil_spec_provider_0.cnpj() == '43.293.675/0001-01'

    seed_1 = Random()
    seed_1.seed(1515090322)
    brazil_spec_provider_1 = BrazilSpecProvider(seed=seed_1)
    assert brazil_spec_provider_1.cnpj() == '19.054.861/0001-31'
    assert brazil_spec_provider_1.cnpj() == '69.216.409/0001-37'

    seed_2 = Random()

# Generated at 2022-06-25 19:59:26.524512
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '31.787.004/0001-73'


# Generated at 2022-06-25 19:59:35.919329
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    assert brazil_spec_provider_0.cpf() == '092.103.309-02'
    assert brazil_spec_provider_0.cpf(False) == '09210330902'
    assert brazil_spec_provider_0.cpf() == '955.874.305-59'
    assert brazil_spec_provider_0.cpf(False) == '955874330559'

# Generated at 2022-06-25 19:59:41.438833
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_cases = [
        ['15.724.803/0001-23', True],
        ['15724803000123', False],
    ]
    for test_case in test_cases:
        for _ in range(1):
            assert brazil_spec_provider_0.cnpj(test_case[1]) == test_case[0]


# Generated at 2022-06-25 19:59:46.908932
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cpf(bool_0=False)) == 11
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cpf(bool_0=True)) == 14


# Generated at 2022-06-25 19:59:50.383479
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider(seed=2585)
    brazil_spec_provider_brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider.cnpj(with_mask=False)
    BrazilSpecProvider(seed=None).cnpj(with_mask=False)


# Generated at 2022-06-25 19:59:59.284322
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    str_0 = brazil_spec_provider_0.cnpj(False)
    str_1 = brazil_spec_provider_0.cnpj()
    assert str_0 == '78835945000187'
    assert len(str_1) == 18


# Generated at 2022-06-25 20:00:10.630314
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xcd\xaa\xe8\x11Vu\xc1\x7f\x8ej\xfb9\x9b\x99\xb8\x1a\x03\xe2'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    cpf_0 = brazil_spec_provider_0.cpf(True)
    assert cpf_0 == '323.186.799-72'
    cpf_1 = brazil_spec_provider_0.cpf(True)
    assert cpf_1 == '725.410.645-89'
    cpf_2 = brazil_spec_provider_0.cpf(True)
    assert cpf_2 == '245.849.721-85'
   

# Generated at 2022-06-25 20:02:49.629617
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Initializing a random seed for reproducibility
    seed_0 = b'\x9e\x8a\x0e1\x88\x0f\xb8:$\x9b\x9e\x8e\x04\x13\xb4\xdd\x8d\x83\x94'
    brazil_spec_provider_0 = BrazilSpecProvider(seed_0)
    # Calling method cpf with parameters: (with_mask=True),
    # (with_mask=False)
    output_str_0 = brazil_spec_provider_0.cpf(True)
    # Calling method cpf with parameters: (with_mask=True),
    # (with_mask=False)
    output_str_1 = brazil_spec_provider_0.cpf(False)

# Generated at 2022-06-25 20:02:55.506894
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\x9f\x08\xe8\x06\x16\x95\xb2\x8f\xf0\xa6\x9e\xb6\x16\x95'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    bool_0 = brazil_spec_provider_0._regex_check(
        str_0='cpf',
        regex_0=brazil_spec_provider_0.cpf(),
    )


# Generated at 2022-06-25 20:03:01.725579
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    assert brazil_spec_provider_0.cpf() == '779.078.219-91'
    assert brazil_spec_provider_0.cpf(True) == '779.078.219-91'
    assert brazil_spec_provider_0.cpf(False) == '77907821991'


# Generated at 2022-06-25 20:03:05.246471
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed_0 = b'\x80\xa5\x8b\x18\xde'
    provider_0 = BrazilSpecProvider(seed_0)
    value_0 = provider_0.cnpj(False)
    expected_0 = '69232076000196'
    assert value_0 == expected_0


# Generated at 2022-06-25 20:03:14.714993
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    assert isinstance(brazil_spec_provider_0, BrazilSpecProvider)
    str_0 = '\u8b96a6\u7559\u0b7eR\u0505\u2ad6\u5b5f\u4d3b\u0c4f\u7d3a\u44d3\u99ab\u0c03\u9bd8\u044e'

# Generated at 2022-06-25 20:03:18.891196
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\xe5\xed3_\xe0l]a\xf7\xe1^\x96\x9e\x9c\xa8\x04z2H\xb8'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    assert brazil_spec_provider_0.cpf() == '389.273.033-85'


# Generated at 2022-06-25 20:03:20.144442
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '855.403.915-10'


# Generated at 2022-06-25 20:03:26.874674
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bytes_0 = b'\x05\x03\x00\xe7\x1b\x9b\x1e\x85i\x8b\x8e\x15\xb7\\\x8f\x9c\'\xec\x10\x95\x97\xad\xf6\x9c\x10\x8e`\x84f\x02\x00\x05\x12\x0e\x0f\x03'
    brazil_spec_provider_0 = BrazilSpecProvider(bytes_0)
    str_0 = brazil_spec_provider_0.cpf()
    assert isinstance(str_0, str)
    str_1 = brazil_spec_provider_0.cpf()
    assert isinstance(str_1, str)

# Generated at 2022-06-25 20:03:32.794652
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj(with_mask=True)
    assert str_0 == '77.732.230/0001-70'
    str_1 = brazil_spec_provider_0.cnpj(with_mask=False)
    assert str_1 == '77732230000170'


# Generated at 2022-06-25 20:03:36.845163
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected = '624.752.746-36'
    assert BrazilSpecProvider(seed=b'\xf9\xaa\x8c\x88\x82\xca\xee\x15\xe3\xa9\xaa\x04\x8c\x87\x93\xa2\xba').cpf() == expected
