

# Generated at 2022-06-25 19:55:05.899761
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for method cnpj of class BrazilSpecProvider"""
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert cnpj == "21.406.087/0001-66"


# Generated at 2022-06-25 19:55:08.813411
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 == "02.323.901/0001-76"


# Generated at 2022-06-25 19:55:16.662746
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    random_seed_0 = 'aRnDe8W'
    brazil_spec_provider_0 = BrazilSpecProvider(seed=random_seed_0)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '264.492.928-04'
    random_seed_0 = 'L0oKbk'
    brazil_spec_provider_0 = BrazilSpecProvider(seed=random_seed_0)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '345.089.134-82'
    random_seed_0 = 'Yi2LRn'
    brazil_spec_provider_0 = BrazilSpecProvider(seed=random_seed_0)
    str_0 = brazil_spec

# Generated at 2022-06-25 19:55:19.833284
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'


# Generated at 2022-06-25 19:55:21.826439
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(False) == '25101895216'


# Generated at 2022-06-25 19:55:23.225562
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for _ in range(100):
        BrazilSpecProvider().cpf()


# Generated at 2022-06-25 19:55:26.866324
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf(False)
    # assert False


# Generated at 2022-06-25 19:55:29.649971
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj()



# Generated at 2022-06-25 19:55:38.281337
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj_BrazilSpecProvider = BrazilSpecProvider(seed=4321)
    func_return_0 = obj_BrazilSpecProvider.cnpj()
    assert func_return_0 == '62.741.824/0001-33'
    func_return_1 = obj_BrazilSpecProvider.cnpj()
    assert func_return_1 == '62.741.824/0001-33'
    func_return_2 = obj_BrazilSpecProvider.cnpj()
    assert func_return_2 == '62.741.824/0001-33'
    func_return_3 = obj_BrazilSpecProvider.cnpj()
    assert func_return_3 == '62.741.824/0001-33'
    func_return_4 = obj_BrazilSpecProvider.cnpj()
    assert func_

# Generated at 2022-06-25 19:55:43.368033
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # GIVEN
    brazil_spec_provider_0 = BrazilSpecProvider()
    # WHEN
    str_0 = brazil_spec_provider_0.cnpj()
    # THEN check
    assert len(str_0) == 18
    assert str_0[2] == '.'
    assert str_0[6] == '.'
    assert str_0[10] == '/'
    assert str_0[15] == '-'


# Generated at 2022-06-25 19:55:52.143900
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()



# Generated at 2022-06-25 19:55:58.663027
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    # verify cpf's length
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14
    # verify cpf's length when with_mask is False
    str_0 = brazil_spec_provider_0.cpf(False)
    assert len(str_0) == 11
    # verify cpf's format
    str_0 = brazil_spec_provider_0.cpf(True)
    assert str_0[3] == '.' and str_0[7] == '.' and str_0[11] == '-'


# Generated at 2022-06-25 19:56:02.097382
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == "159.879.311-34"


# Generated at 2022-06-25 19:56:05.635507
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_1.cnpj()

# Generated at 2022-06-25 19:56:09.396848
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    ret = brazil_spec_provider.cpf(with_mask=True)
    assert len(ret) == 14 and type(ret) is str


# Generated at 2022-06-25 19:56:13.215886
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj()) == 18
    assert len(brazil_spec_provider.cnpj(False)) == 14


# Generated at 2022-06-25 19:56:15.090816
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    str_0 = BrazilSpecProvider().cnpj()
    assert('77.732.230/0001-70' == str_0)


# Generated at 2022-06-25 19:56:19.744122
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Arrange
    brazil_spec_provider = BrazilSpecProvider()

    # Act
    cnpj = brazil_spec_provider.cnpj()

    # Assert
    assert len(cnpj) == 18


# Generated at 2022-06-25 19:56:24.157488
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14
    str_1 = brazil_spec_provider_0.cpf(False)
    assert len(str_1) == 11


# Generated at 2022-06-25 19:56:35.347758
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create an instance of BrazilSpecProvider
    brazil_spec_provider_handler = BrazilSpecProvider()
    # Get a random cnpj
    cnpj = brazil_spec_provider_handler.cnpj()
    # Get the first digit
    first_digit = cnpj[:2]
    # Get the second digit
    second_digit = cnpj[2:5]
    # Get the third digit
    third_digit = cnpj[5:8]
    # Get the fourth digit
    fourth_digit = cnpj[8:12]
    # Get the fifth digit
    fifth_digit = cnpj[12:]
    assert len(cnpj) == 14
    assert first_digit.isdigit()
    assert second_digit.isdigit()
    assert third_digit.isdigit

# Generated at 2022-06-25 19:56:56.225616
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf() == "060.087.313-90"
    assert brazil_spec_provider_0.cpf() == "822.783.073-04"
    assert brazil_spec_provider_0.cpf() == "681.827.280-16"
    assert brazil_spec_provider_0.cpf() == "650.354.716-76"
    assert brazil_spec_provider_0.cpf() == "942.172.905-00"
    assert brazil_spec_provider_0.cpf() == "127.971.912-49"

# Generated at 2022-06-25 19:56:58.352794
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj(True)


# Generated at 2022-06-25 19:56:59.702424
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '357.575.449-51'


# Generated at 2022-06-25 19:57:01.259954
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()

# Generated at 2022-06-25 19:57:06.980251
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    str_0 = '573.052.827-79'
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_0.cpf()
    str_1_test = str_0
    assert str_1 == str_1_test, "Expected: {}\nGot: {}".format(str_1, str_1_test)


# Generated at 2022-06-25 19:57:09.796166
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj().replace('.', '').replace('-', '').replace('/', '')
    assert len(cnpj) == 14


# Generated at 2022-06-25 19:57:12.219588
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:57:14.964445
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(str_0) == 14
    assert str_0[3] == '.'
    assert str_0[7] == '.'
    assert str_0[11] == '-'


# Generated at 2022-06-25 19:57:16.299719
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf()[0] == '0'
    assert len(brazil_spec_provider.cpf()) == 14


# Generated at 2022-06-25 19:57:18.445532
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()

# Generated at 2022-06-25 19:57:47.751926
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj_0 = BrazilSpecProvider.Meta.name
    obj_1 = BrazilSpecProvider(seed=1).cnpj(with_mask=True)
    obj_2 = BrazilSpecProvider(seed=1).cnpj(with_mask=False)



# Generated at 2022-06-25 19:57:55.270369
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Case 0
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert(str_0[3] == '.')
    assert(str_0[7] == '.')
    assert(str_0[11] == '-')
    assert(str_0.length == 14)

    # Case 1
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf(False)
    assert(str_1.length == 11)


# Generated at 2022-06-25 19:57:58.359256
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-25 19:58:02.699345
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed_0 = "seed"
    brazil_spec_provider_0 = BrazilSpecProvider(seed=seed_0)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == "192.721.425-53"


# Generated at 2022-06-25 19:58:09.159491
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Create a new instance of BrazilSpecProvider class
    brazil_spec_provider = BrazilSpecProvider()
    # Call the BrazilSpecProvider class method cpf
    str_cpf = brazil_spec_provider.cpf()
    # Verify if the lenght of the returned string is valid
    assert len(str_cpf) == 14
    # Verify if index 3 has a dot
    assert str_cpf[3] == '.'
    # Verify if index 7 has a dot
    assert str_cpf[7] == '.'
    # Verify if index 11 has a dash
    assert str_cpf[11] == '-'
    

# Generated at 2022-06-25 19:58:11.155569
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '72.288.637/0001-65'


# Generated at 2022-06-25 19:58:22.033161
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Arrange
    from datetime import datetime
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    from mimesis.builtins.base import (BaseSpecProvider, BaseProvider)
    from mimesis.providers.person import Person

    class BrazilSpecProvider(BaseSpecProvider):
        """Class that provides special data for Brazil (pt-br)."""
        def __init__(self, seed: Seed = None):
            """Initialize attributes."""
            super().__init__(locale='pt-br', seed=seed)

        class Meta:
            """The name of the provider."""
            name = 'brazil_provider'


# Generated at 2022-06-25 19:58:24.137775
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_var_1 = brazil_spec_provider.cpf()
    assert len(str_var_1) == 14


# Generated at 2022-06-25 19:58:34.644646
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(seed=0)
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf()
    assert str_0 == "048.625.439-77"
    assert str_1 == "210.583.701-76"
    brazil_spec_provider_1 = BrazilSpecProvider(seed=3)
    str_2 = brazil_spec_provider_1.cpf()
    str_3 = brazil_spec_provider_1.cpf()
    assert str_2 == "248.416.084-35"
    assert str_3 == "686.634.587-87"


# Generated at 2022-06-25 19:58:36.399433
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf()) == 14


# Generated at 2022-06-25 19:59:49.945588
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()

    assert str_0.count('.') == 2 and str_0.count('-') == 1


# Generated at 2022-06-25 19:59:53.278244
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj()
    str_2 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 14
    assert len(str_1) == 14
    assert len(str_2) == 14


# Generated at 2022-06-25 19:59:56.794219
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj()
    assert isinstance(str_1, str)


# Generated at 2022-06-25 19:59:59.585043
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    str_0 = BrazilSpecProvider(seed=0).cpf()
    str_1 = BrazilSpecProvider(seed=0).cpf()
    assert str_0 == str_1


# Generated at 2022-06-25 20:00:01.407014
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:00:12.497335
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def get_verifying_digit_cnpj(cnpj, peso):
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        elif peso == 6:
            peso_list = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        for i, _ in enumerate(cnpj):
            soma += peso_list[i] * cnpj[i]
        resto = soma % 11
        if resto < 2:
            return 0
        return 11 - resto

    brazil_spec_provider_1 = BrazilSpecProvider()


    cnpj_without_dv_0

# Generated at 2022-06-25 20:00:14.843319
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    str_0 = BrazilSpecProvider().cnpj()
    assert str_0

# Generated at 2022-06-25 20:00:17.648904
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test case 0
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()

# Generated at 2022-06-25 20:00:22.778368
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert isinstance(str_0, str)
    assert len(str_0) == 14

    brazil_spec_provider_1 = BrazilSpecProvider(seed=12345678)
    str_1 = brazil_spec_provider_1.cpf()
    assert isinstance(str_1, str)
    assert len(str_1) == 14
    assert str_1 == "319.867.626-32"

# Generated at 2022-06-25 20:00:31.020877
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = '208.438.981-54'
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf(True) == cpf


# Generated at 2022-06-25 20:02:56.851528
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    # test_case_0
    brazil_spec_provider_0 = BrazilSpecProvider()
    _str_0 = brazil_spec_provider_0.cpf()
    if not isinstance(_str_0, str):
        raise TypeError("Incorrect type returned.")
    if not len(_str_0) == 14:
        raise ValueError("Incorrect length of return.")
    if not _str_0[:3] in range(0, 1000):
        raise ValueError("Incorrect range of return.")
    if not _str_0[3:6] in range(0, 1000):
        raise ValueError("Incorrect range of return.")
    if not _str_0[6:9] in range(0, 1000):
        raise ValueError("Incorrect range of return.")

# Generated at 2022-06-25 20:02:59.785703
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14
    assert str_0 == '041.541.730-05'


# Generated at 2022-06-25 20:03:07.156571
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18
    list_0 = list(str_0)
    str_1 = ''.join(list_0)
    assert str_0 == str_1
    assert str_1 == '84.635.966/0001-67'
    str_2 = brazil_spec_provider_0.cnpj(with_mask=False)
    assert len(str_2) == 14
    list_1 = list(str_2)
    str_3 = ''.join(list_1)
    assert str_2 == str_3
    assert str_3 == '84.635.966/0001-67'

# Generated at 2022-06-25 20:03:09.722105
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    #    A call to method cpf of class BrazilSpecProvider
    #    returns the string
    assert(BrazilSpecProvider().cpf() == '010.979.273-88')


# Generated at 2022-06-25 20:03:13.122450
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18

# Generated at 2022-06-25 20:03:14.430633
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    unitTests.test_case_0()

# Generated at 2022-06-25 20:03:21.334126
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    '''
    Test method cpf of class BrazilSpecProvider
    '''
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf()
    # Test if str_1 is a string

    assert isinstance(str_1, str)
    # Test if len(str_1) == 14
    assert len(str_1) == 14
    # Test if len(str_1.split('.')[0]) == 3
    assert len(str_1.split('.')[0]) == 3
    # Test if len(str_1.split('.')[1]) == 3
    assert len(str_1.split('.')[1]) == 3
    # Test if len(str_1.split('.')[2]) == 3

# Generated at 2022-06-25 20:03:25.870136
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert re.search(r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}', str_0) is not None


# Generated at 2022-06-25 20:03:33.025495
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 == '52.869.516/0001-83'
    str_1 = brazil_spec_provider_0.cnpj(True)
    assert str_1 == '52.869.516/0001-83'
    str_2 = brazil_spec_provider_0.cnpj(False)
    assert str_2 == '5286.9516000183'


# Generated at 2022-06-25 20:03:34.709859
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert '.' in str_0
