

# Generated at 2022-06-25 19:55:01.128604
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '316.030.158-36'


# Generated at 2022-06-25 19:55:04.229656
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cpf(with_mask=False).__len__() == 11


# Generated at 2022-06-25 19:55:07.308431
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf_result_string = brazil_spec_provider.cpf()
    assert isinstance(cpf_result_string, str)
    assert len(cpf_result_string) >= 11


# Generated at 2022-06-25 19:55:12.869344
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    len_0 = len(str_0)
    assert len_0 == 14
    str_1 = brazil_spec_provider_0.cpf(with_mask=False)
    len_1 = len(str_1)
    assert len_1 == 11


# Generated at 2022-06-25 19:55:15.217149
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0[5] == '.'


# Generated at 2022-06-25 19:55:18.761818
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-25 19:55:23.079835
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider(seed=0)
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf()
    assert str_0 == str_1


# Generated at 2022-06-25 19:55:25.987958
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cpf()
    assert str_0 == "418.426.293-66"


# Generated at 2022-06-25 19:55:33.108513
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    str_0 = '374.551.722-80'
    str_1 = '205.874.712-73'
    str_2 = '209.874.722-71'
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_2 = BrazilSpecProvider()
    str_3 = brazil_spec_provider_0.cpf()
    str_4 = brazil_spec_provider_1.cpf()
    str_5 = brazil_spec_provider_2.cpf()
    assert str_3 == '374.551.722-80'
    assert str_4 == '205.874.712-73'

# Generated at 2022-06-25 19:55:36.280238
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test for case 1
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14


# Generated at 2022-06-25 19:55:44.221762
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_BrazilSpecProvider_cpf_0()
    test_BrazilSpecProvider_cpf_1()
    test_BrazilSpecProvider_cpf_2()


# Generated at 2022-06-25 19:55:52.139016
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    # cnpj with mask
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_0.cnpj(with_mask=True)
    assert len(str_1) == 18
    assert str_1[2:3] == '.'
    assert str_1[6:7] == '.'
    assert str_1[10:11] == '/'
    assert str_1[15:16] == '-'

    # cnpj without mask
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj(with_mask=False)
    assert len(str_1) == 14


# Generated at 2022-06-25 19:55:54.216295
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = 12345
    provider = BrazilSpecProvider(seed=seed)
    expected_result = "021.759.104-41"
    assert provider.cpf() == expected_result
    assert provider.cpf() != expected_result



# Generated at 2022-06-25 19:56:00.319703
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    result = brazil_spec_provider.cnpj()
    assert isinstance(result, str)
    assert len(result) == 18
    assert result.count('.') == 2
    assert result.count('-') == 1
    assert result.count('/') == 1
    assert result[2] == '.'
    assert result[6] == '.'
    assert result[10] == '/'
    assert result[15] == '-'


# Generated at 2022-06-25 19:56:11.727864
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    c_0 = brazil_spec_provider.cpf()
    # assert c_0.endswith('-')
    # assert c_0.count('.') == 3
    assert len(c_0) == 14
    c_1 = brazil_spec_provider.cpf()
    # assert c_1.count('.') == 3
    # assert c_1.endswith('-')
    assert len(c_1) == 14
    c_2 = brazil_spec_provider.cpf(True)
    # assert c_2.count('.') == 2
    # assert c_2.endswith('-')
    assert len(c_2) == 14
    c_3 = brazil_spec_provider.cpf

# Generated at 2022-06-25 19:56:17.487940
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    # test case 1
    str_0 = brazil_spec_provider_0.cpf(False)
    str_1 = brazil_spec_provider_0.cpf(True)
    assert len(str_0) == 11
    assert len(str_1) == 14
    assert str_1 == str_0[:3] + '.' + str_0[3:6] + '.' + str_0[6:9] + '-' + str_0[9:]


# Generated at 2022-06-25 19:56:25.339066
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf()
    str_1_n = brazil_spec_provider_1.cpf(False)
    assert len(str_1) == 14
    assert len(str_1_n) == 11
    assert str_1 == str_1_n[:3] + "." + str_1_n[3:6] + "." +\
        str_1_n[6:9] + "-" + str_1_n[9:]


# Generated at 2022-06-25 19:56:32.563706
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cpf()
    assert re.fullmatch('\\d{3}.\\d{3}.\\d{3}-\\d{2}', str_0)

    str_1 = brazil_spec_provider.cnpj()
    assert re.fullmatch('\\d{2}.\\d{3}.\\d{3}/\\d{4}-\\d{2}', str_1)

# Generated at 2022-06-25 19:56:35.633520
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf()
    assert(len(str_1) == 14)


# Generated at 2022-06-25 19:56:37.599128
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_case_0()



# Generated at 2022-06-25 19:56:51.594160
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 14

# Generated at 2022-06-25 19:56:59.918600
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.address import Address
    from mimesis.typing import Seed
    from mimesis.providers.datetime import Datetime
    from mimesis.providers.internet import Internet
    from mimesis.providers.personal import Personal
    from mimesis.providers.payment import Payment
    from mimesis.providers.text import Text

    # Seed used to create the provider
    seed = Seed(3)
    # Creating a provider
    provider = BrazilSpecProvider(seed)

    # Verify object provider is BrazilSpecProvider
    assert type(provider) is BrazilSpecProvider
    # Verify object provider is BaseSpecProvider
    assert isinstance(provider, BaseSpecProvider)

    # Verify that seed is 3
    assert provider._seed == 3
    # Verify that seed is Seed
    assert type(seed)

# Generated at 2022-06-25 19:57:01.537812
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(with_mask=True) == "760.866.668-80"



# Generated at 2022-06-25 19:57:05.370528
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '163.157.803-33' or str_0 == '163.157.803-33'


# Generated at 2022-06-25 19:57:15.560582
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Arrange
    brazil_spec_provider = BrazilSpecProvider()

    # Act
    str_0 = brazil_spec_provider.cnpj()
    str_1 = brazil_spec_provider.cnpj(with_mask=False)
    str_2 = brazil_spec_provider.cnpj(with_mask=False)
    str_3 = brazil_spec_provider.cnpj(with_mask=False)
    str_4 = brazil_spec_provider.cnpj()

    # Assert
    assert str_0 == '03.637.860/0001-83'
    assert len(str_1) == 14
    assert str_1 != str_2
    assert str_2 != str_3
    assert str_3 != str_4
    assert str

# Generated at 2022-06-25 19:57:19.091520
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider.cpf()
    assert len(cpf_0) == 14
    assert cpf_0[3] == '.'
    assert cpf_0[7] == '.'
    assert cpf_0[11] == '-'


# Generated at 2022-06-25 19:57:22.373688
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:57:26.353403
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    print("Esta é a saída do nosso método cnpj:")
    print(str_0)


# Generated at 2022-06-25 19:57:29.929177
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    try:
        brazil_spec_provider.cpf(with_mask=True)
        brazil_spec_provider.cpf(with_mask=False)
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 19:57:31.874064
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    a = BrazilSpecProvider()
    b = a.cnpj(with_mask=True)

    assert len(b) == 18



# Generated at 2022-06-25 19:57:59.440758
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    string = brazil_spec_provider.cpf()
    assert isinstance(string, str)
    assert len(string) == 14
    assert string[3] == '.'
    assert string[7] == '.'
    assert string[11] == '-'


# Generated at 2022-06-25 19:58:07.907688
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = "brazil_spec_provider_cpf"
    brazil_spec_provider = BrazilSpecProvider(seed=seed)
    str_0 = brazil_spec_provider.cpf()
    str_1 = brazil_spec_provider.cpf()
    str_2 = brazil_spec_provider.cpf()
    str_3 = brazil_spec_provider.cpf()
    assert str_0 == "890.693.421-13"
    assert str_1 == "890.693.421-13"
    assert str_2 == "890.693.421-13"
    assert str_3 == "890.693.421-13"


# Generated at 2022-06-25 19:58:10.193184
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cnpj()) == 18


# Generated at 2022-06-25 19:58:11.574647
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(str_0) == 14
    assert check_document_cpf(str_0) == True


# Generated at 2022-06-25 19:58:22.474995
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()

# Generated at 2022-06-25 19:58:26.867976
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender
    import re
    brazil_spec_provider = BrazilSpecProvider(seed=11111111)
    assert re.match(r'^\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}$', brazil_spec_provider.cnpj()) == None
    brazil_spec_provider = BrazilSpecProvider(seed=11111111)
    assert re.match(r'^\d{14}$', brazil_spec_provider.cnpj(with_mask=False)) == None


# Generated at 2022-06-25 19:58:29.792490
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_0 = BrazilSpecProvider().cnpj()
    cnpj_1 = BrazilSpecProvider().cnpj(with_mask=False)


# Generated at 2022-06-25 19:58:35.053866
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf0 = provider.cpf()
    assert len(cpf0) == 14
    assert cpf0[3] == '.'
    assert cpf0[7] == '.'
    assert cpf0[11] == '-'
    cpf1 = provider.cpf(with_mask=False)
    assert len(cpf1) == 11


# Generated at 2022-06-25 19:58:41.528594
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    brazil_spec_provider_2 = BrazilSpecProvider(seed=1.0)

    str_1 = brazil_spec_provider_1.cpf()
    assert str_1 == '348.068.965-51'
    str_2 = brazil_spec_provider_2.cpf()
    assert str_2 == '919.972.579-37'
    str_3 = brazil_spec_provider_1.cpf(with_mask=False)
    assert str_3 == '34806896551'
    str_4 = brazil_spec_provider_1.cpf(with_mask=True)
    assert str_4 == '348.068.965-51'
    # Check that hashing

# Generated at 2022-06-25 19:58:45.382985
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider
    BrazilSpecProvider = BrazilSpecProvider

    provider = BrazilSpecProvider()
    result = provider.cnpj()
    assert isinstance(result, str)
    assert len(result) == 18
    assert len(result) == 14


# Generated at 2022-06-25 19:59:50.862025
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    spec = BrazilSpecProvider()
    cpf = spec.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-25 20:00:00.898175
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test the following conditions.
    # len(str) == 18
    # str[2] == '.'
    # str[23] == '-'
    # str[6] == '.'
    # str[11] == '/'
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj()
    str_2 = brazil_spec_provider_0.cnpj()
    str_3 = brazil_spec_provider_0.cnpj()
    str_4 = brazil_spec_provider_0.cnpj()
    str_5 = brazil_spec_provider_0.cnpj()
    str_6 = b

# Generated at 2022-06-25 20:00:09.604875
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '47.760.626/0001-69'
    assert brazil_spec_provider_0.cnpj() == '92.899.629/0001-78'
    assert brazil_spec_provider_0.cnpj(False) == '35825413000132'
    assert brazil_spec_provider_0.cnpj(False) == '62323413000195'


# Generated at 2022-06-25 20:00:12.014396
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    cpf1 = BrazilSpecProvider().cpf()
    cpf2 = BrazilSpecProvider().cpf(False)

    assert len(cpf1) == 14
    assert len(cpf2) == 11


# Generated at 2022-06-25 20:00:18.193902
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert type(BrazilSpecProvider().cpf()) is str
    assert len(BrazilSpecProvider().cpf()) == 14
    assert BrazilSpecProvider().cpf()[3] == '.'
    assert BrazilSpecProvider().cpf()[7] == '.'
    assert BrazilSpecProvider().cpf()[11] == '-'


# Generated at 2022-06-25 20:00:21.006347
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cnpj()
    assert str_0 == '83.857.789/0001-83'


# Generated at 2022-06-25 20:00:31.097763
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18


# Generated at 2022-06-25 20:00:37.377169
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    str = brazil_spec_provider.cnpj()
    assert str == '77.732.230/0001-70'
    assert len(str) == 18
    assert str[2] == '.'
    assert str[6] == '.'
    assert str[10] == '/'
    assert str[15] == '-'

# Generated at 2022-06-25 20:00:42.939988
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = BrazilSpecProvider().cnpj()

    assert str(str_0).startswith('0')
    assert str(str_1).endswith('0')


# Generated at 2022-06-25 20:00:48.657264
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()

    # Variable is None
    assert(str_0 is not None)
    # Length equal to 14
    assert(len(str_0) == 14)
    # Type is str
    assert(isinstance(str_0, str) == True)
    # Type is not int
    assert(isinstance(str_0, int) == False)


# Generated at 2022-06-25 20:02:57.714256
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider.cpf()
    assert len(cpf_0) == 14
    assert cpf_0.isdigit()

# Generated at 2022-06-25 20:03:05.216664
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # cpf_0 = BrazilSpecProvider().cpf()
    # cpf_1 = BrazilSpecProvider().cpf()
    # cpf_2 = BrazilSpecProvider().cpf()
    # cpf_3 = BrazilSpecProvider().cpf()
    # cpf_4 = BrazilSpecProvider().cpf()
    cpf_5 = BrazilSpecProvider().cpf()
    # cpf_6 = BrazilSpecProvider().cpf()
    # cpf_7 = BrazilSpecProvider().cpf()
    # cpf_8 = BrazilSpecProvider().cpf()
    # cpf_9 = BrazilSpecProvider().cpf()


# Generated at 2022-06-25 20:03:06.938749
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj()) == 18


# Generated at 2022-06-25 20:03:10.106662
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    em = brazil_spec_provider.cpf()
    assert len(em) == 14
    assert em.count('.') == 2
    assert em.count('-') == 1


# Generated at 2022-06-25 20:03:19.143561
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test with default value of the parameter with_mask
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider_0.cpf()
    assert len(cpf_0) > 0
    assert (cpf_0.count('.') == 2 and cpf_0.count('-') == 1)
    assert (cpf_0[3] == '.' and cpf_0[7] == '.' and cpf_0[11] == '-')
    assert ((cpf_0[3] + cpf_0[4] + cpf_0[5]).isnumeric())
    assert ((cpf_0[7] + cpf_0[8] + cpf_0[9]).isnumeric())

# Generated at 2022-06-25 20:03:20.774921
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:03:22.287449
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_2 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_2.cnpj()


# Generated at 2022-06-25 20:03:25.870588
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider_0 = BrazilSpecProvider()
    str_0 = BrazilSpecProvider_0.cpf()
    str_1 = BrazilSpecProvider_0.cpf(True)
    str_2 = BrazilSpecProvider_0.cpf(True)
    str_3 = BrazilSpecProvider_0.cpf(False)


# Generated at 2022-06-25 20:03:30.981773
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # verify the format
    assert len(BrazilSpecProvider().cpf()) == 14
    assert len(BrazilSpecProvider().cpf(with_mask=False)) == 11
    assert BrazilSpecProvider().cpf() == BrazilSpecProvider().cpf()
    assert BrazilSpecProvider().cpf(with_mask=False) == BrazilSpecProvider().cpf(with_mask=False)



# Generated at 2022-06-25 20:03:35.428910
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test the method cnpj of the class BrazilSpecProvider
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()

    # Assert if str_0 equals '04.848.199/0001-35'
    assert str_0 == '04.848.199/0001-35'