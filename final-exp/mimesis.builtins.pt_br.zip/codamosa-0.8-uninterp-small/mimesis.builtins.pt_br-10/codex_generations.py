

# Generated at 2022-06-25 19:55:01.331004
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    with_mask = False
    str_0 = BrazilSpecProvider.cpf(with_mask)
    assert str_0 is not None


# Generated at 2022-06-25 19:55:10.825898
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    bool_0 = False
    assert brazil_spec_provider_0.cnpj(bool_0) == '74074626820447'
    assert brazil_spec_provider_0.cnpj(bool_0) == '74074626820447'
    assert brazil_spec_provider_0.cnpj(bool_0) == '74074626820447'
    assert brazil_spec_provider_0.cnpj(bool_0) == '74074626820447'
    bool_0 = True
    assert brazil_spec_provider_0.cnpj(bool_0) == '74.074.626/8204-47'
    assert brazil_spec_provider_0.cnp

# Generated at 2022-06-25 19:55:13.481917
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:55:23.801103
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    bool_0 = False
    assert len(brazil_spec_provider_0.cnpj(bool_0)) == 14
    assert brazil_spec_provider_0.cnpj(bool_0) == '17241607000159'
    assert brazil_spec_provider_0.cnpj(bool_0) == '17241607000159'
    assert brazil_spec_provider_0.cnpj(bool_0) == '17241607000159'
    assert brazil_spec_provider_0.cnpj(bool_0) == '17241607000159'
    assert brazil_spec_provider_0.cnpj(bool_0) == '17241607000159'
   

# Generated at 2022-06-25 19:55:27.384530
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_cpf = BrazilSpecProvider()
    with_mask = None
    try:
        str_cpf = brazil_spec_provider_cpf.cpf(with_mask)
    except TypeError:
        pass


# Generated at 2022-06-25 19:55:30.076808
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider_0 = BrazilSpecProvider()
    bool_1 = False
    str_1 = BrazilSpecProvider_0.cpf(bool_1)
    print(bool_1)
    print(str_1)


# Generated at 2022-06-25 19:55:33.206346
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    bool_0 = True
    str_0 = brazil_spec_provider_0.cpf(bool_0)
    assert str_0 == '495.612.861-33'


# Generated at 2022-06-25 19:55:41.961056
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    _seed = 1337
    _numeric_seed = 1337
    brazil_spec_provider_0 = BrazilSpecProvider(seed=_seed)
    brazil_spec_provider_1 = BrazilSpecProvider(seed=_seed)
    brazil_spec_provider_2 = BrazilSpecProvider(seed=_seed)

    # Validate CPF
    
    # Validate 1st CPF
    str_0 = brazil_spec_provider_0.cpf(with_mask=False)
    print(str_0)
    assert len(str_0) == 11
    assert isinstance(str_0, str)
    assert str_0.isdigit()
    # Calculate the check digit
    int_0 = 0
    int_1 = 9
    list_0 = []

# Generated at 2022-06-25 19:55:45.599682
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    bool_0 = True
    str_0 = brazil_spec_provider_0.cpf(bool_0)
    assert len(str_0) == 14
    assert '-' in str_0
    assert '.' in str_0


# Generated at 2022-06-25 19:55:48.900987
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    bool_0 = True
    str_0 = brazil_spec_provider_0.cnpj(bool_0)
    assert isinstance(str_0, str) and str_0 is not None


# Generated at 2022-06-25 19:56:06.804147
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj(False)
    assert str_0 == '0532034600017'
    str_1 = brazil_spec_provider_0.cnpj(False)
    assert str_1 == '0650113050018'
    str_2 = brazil_spec_provider_0.cnpj(False)
    assert str_2 == '7634304800012'
    str_3 = brazil_spec_provider_0.cnpj(False)
    assert str_3 == '9913011400010'
    str_4 = brazil_spec_provider_0.cnpj(False)
    assert str_4 == '5765352300012'

# Generated at 2022-06-25 19:56:13.811934
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # No mask CPF example
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf(with_mask=False)
    assert str_0 == '61922659325', '{!r} != 61922659325'.format(str_0)

    # Masked CPF example
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf(with_mask=True)
    assert str_1 == '824.760.340-71', '{!r} != 824.760.340-71'.format(str_1)


# Generated at 2022-06-25 19:56:17.697655
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '66.081.816/0001-12'


# Generated at 2022-06-25 19:56:21.562810
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider_0 = BrazilSpecProvider()
    str_0 = BrazilSpecProvider_0.cpf()
    assert isinstance(str_0,str)
    assert len(str_0) == 14


# Generated at 2022-06-25 19:56:23.552386
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    string_0 = BrazilSpecProvider.cnpj(None)
    assert '00.000.000/0000-00' == string_0


# Generated at 2022-06-25 19:56:30.466456
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf(False)
    assert len(str_0) == 14
    assert len(str_1) == 11


# Generated at 2022-06-25 19:56:33.974376
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # BrazilSpecProvider instance
    brazil_spec_provider_obj_0 = BrazilSpecProvider()
    # bool
    var_0 = True
    # str
    var_1 = brazil_spec_provider_obj_0.cnpj(var_0)



# Generated at 2022-06-25 19:56:35.959429
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:56:38.049815
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len( BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-25 19:56:43.948790
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Creating seed for brazil_spec_provider
    seed = Seed(1234567890)
    # Creating brazil_spec_provider
    brazil_spec_provider = BrazilSpecProvider(seed=seed)
    # Getting cpf
    cpf = brazil_spec_provider.cpf()
    # Assertion
    assert cpf == '111.111.111-11'


# Generated at 2022-06-25 19:57:00.759389
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cnpj()
    str_1 = brazil_spec_provider.cnpj(False)
    str_2 = brazil_spec_provider.cnpj(True)
    assert str_0 == str_1 == str_2
    assert str_1 == str_2
    assert str_2 == str_0
    assert len(str_0) == 14
    assert len(str_1) == 14
    assert len(str_2) == 18


# Generated at 2022-06-25 19:57:02.290223
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cpf()) == 14


# Generated at 2022-06-25 19:57:05.289662
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:57:08.138847
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:57:16.911573
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    brazil_spec_provider.cpf(with_mask=True)
    # Test for queries = 100
    for _ in range(100):
        result = brazil_spec_provider.cpf(with_mask=True)
        assert len(result) == 14
        assert type(result) is str
        assert result[3] == "."
        assert result[7] == "."
        assert result[11] == "-"
    # Test for queries = 100
    for _ in range(100):
        result = brazil_spec_provider.cpf(with_mask=False)
        assert len(result) == 11
        assert type(result) is str


# Generated at 2022-06-25 19:57:19.726217
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider_0 = BrazilSpecProvider()
    str_0 = provider_0.cpf()
    assert len(str_0) == 14
    assert len(str_0) == 14
    return None


# Generated at 2022-06-25 19:57:24.201403
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Expected result
    expected_result = """04.554.625/0001-76"""

    brazil_spec_provider = BrazilSpecProvider()
    generated_result = brazil_spec_provider.cnpj()

    assert expected_result == generated_result


# Generated at 2022-06-25 19:57:27.446932
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == "034.836.204-24"
    assert bsp.cpf(with_mask=False) == "03483620424"


# Generated at 2022-06-25 19:57:31.715273
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18
    assert not ('-' in str_0)
    assert ('.' in str_0)
    assert ('/' in str_0)
    assert str_0.isdigit()


# Generated at 2022-06-25 19:57:34.107918
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 != "00113729740"


# Generated at 2022-06-25 19:58:04.517380
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf(True)
    str_2 = brazil_spec_provider_0.cpf(False)
    assert str_0
    assert str_1
    assert str_2


# Generated at 2022-06-25 19:58:07.071883
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 != None


# Generated at 2022-06-25 19:58:09.017455
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    print(str_0)


# Generated at 2022-06-25 19:58:14.715725
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("\nTest method 'cpf' from class BrazilSpecProvider")

    # Set a custom seed
    seed = 1
    brazil_spec_provider = BrazilSpecProvider(seed)

    # Use the CPF mask
    cpf_with_mask_1 = brazil_spec_provider.cpf(True)
    cpf_with_mask_2 = brazil_spec_provider.cpf(with_mask=True)

    assert cpf_with_mask_1 == '235.172.898-06'
    assert cpf_with_mask_2 == cpf_with_mask_1

    # Don't use the CPF mask
    cpf_without_mask_1 = brazil_spec_provider.cpf(False)
    cpf_without_mask_2 = brazil_spec_provider

# Generated at 2022-06-25 19:58:23.175436
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj(with_mask=False)
    assert len(str_0) == 14
    str_1 = brazil_spec_provider_0.cnpj(with_mask=True)
    assert str_1[0] == '5'
    assert str_1[2] == '.'
    assert str_1[6] == '.'
    assert str_1[10] == '/'
    assert str_1[15] == '-'
    assert len(str_1) == 18

# Generated at 2022-06-25 19:58:25.184544
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    brazil_spec_provider_0.seed(49)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '045.429.724-48'

# Generated at 2022-06-25 19:58:34.310628
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Initialize the class
    spec_provider = BrazilSpecProvider()

    # Execute the function and save the result to a variable
    result = spec_provider.cpf()

    #  Assert that the type of the result is a String
    assert isinstance(result, str)

    # Assert that the result is a string that has the following pattern
    assert result[0:3].isdigit() and result[4:7].isdigit() \
        and result[8:11].isdigit() and result[-2:].isdigit()
    assert result[3] == '.' and result[7] == '.' and result[12] == '-'


# Generated at 2022-06-25 19:58:37.496789
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()

    cnpj = brazil_spec_provider.cnpj()

    assert len(cnpj) == 18
    assert len(brazil_spec_provider.cnpj(with_mask=False)) == 14


# Generated at 2022-06-25 19:58:42.733652
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    given_0 = BrazilSpecProvider()
    expected_0 = given_0.cpf()
    assert type(expected_0) == str
    assert len(expected_0) == 14
    assert expected_0[3] == '.'
    assert expected_0[7] == '.'
    assert expected_0[11] == '-'


# Generated at 2022-06-25 19:58:46.388770
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result_str_0 = brazil_spec_provider_0.cpf(True)
    print(result_str_0)
    assert result_str_0 == '002.135.910-83'


# Generated at 2022-06-25 20:00:01.692676
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()

    # Test case 0
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 == '37.824.937/0001-32'

    # Test case 1
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_1.cnpj()
    assert str_0 == '41.822.734/0001-40'

    # Test case 2
    brazil_spec_provider_2 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_2.cnpj()
    assert str_0 == '66.903.373/0001-21'

    # Test case 3
    brazil_spec_provider

# Generated at 2022-06-25 20:00:07.002612
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cpf()
    str_1 = brazil_spec_provider.cpf(with_mask=False)



# Generated at 2022-06-25 20:00:09.715576
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() != ''


# Generated at 2022-06-25 20:00:14.254909
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected = "###.###.###-##"
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf(False)
    str_2 = brazil_spec_provider_1.cpf()
    assert str_1 == str_2
    assert len(str_1) == 11
    assert len(str_2) == 14
    assert isinstance(str_1, str)
    assert isinstance(str_2, str)


# Generated at 2022-06-25 20:00:17.461896
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_5 = BrazilSpecProvider()
    str_5 = brazil_spec_provider_5.cnpj()
    str_5.__len__()


# Generated at 2022-06-25 20:00:19.533801
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cpf()
    print(str_0)


# Generated at 2022-06-25 20:00:23.936033
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for method cpf of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    cpf_result = brazil_spec_provider.cpf()
    assert len(cpf_result) == 14
    assert cpf_result[3] == '.'
    assert cpf_result[7] == '.'
    assert cpf_result[11] == '-'
    cpf_result = brazil_spec_provider.cpf(with_mask=False)
    assert len(cpf_result) == 11


# Generated at 2022-06-25 20:00:33.313855
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Run
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()

    # Assert
    assert str_0



# Generated at 2022-06-25 20:00:37.218973
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    from . import string_types as st

    # Test for method cpf of class BrazilSpecProvider
    spec = BrazilSpecProvider()
    assert isinstance(spec.cpf(), st)
    assert len(spec.cpf()) == 14
    assert spec.cpf(with_mask=False)
    assert isinstance(spec.cpf(), st)
    assert len(spec.cpf()) == 11
    assert spec.cpf(with_mask=False)


# Generated at 2022-06-25 20:00:47.552125
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = 1
    brazil_spec_provider_1 = BrazilSpecProvider(seed)
    str_1 = brazil_spec_provider_1.cnpj()
    assert (str_1 == '07.575.913/0001-56')

    seed = 2
    brazil_spec_provider_2 = BrazilSpecProvider(seed)
    str_2 = brazil_spec_provider_2.cnpj()
    assert (str_2 == '08.812.908/0001-87')

    seed = 3
    brazil_spec_provider_3 = BrazilSpecProvider(seed)
    str_3 = brazil_spec_provider_3.cnpj()
    assert (str_3 == '26.729.063/0001-27')



# Generated at 2022-06-25 20:03:01.447339
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Verify using the CNPJ mask (###.###.###-##)
    assert BrazilSpecProvider().cnpj(with_mask=True) == '32.760.638/0001-69'
    # Verify without using the CNPJ mask (###.###.###-##)
    assert BrazilSpecProvider().cnpj(with_mask=False) == '32760638000169'


# Generated at 2022-06-25 20:03:06.439661
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf(False)
    str_2 = brazil_spec_provider_0.cpf(True)

    print("""
    {0}
    {1}
    {2}""".format(
        str_0,
        str_1,
        str_2
    ))



# Generated at 2022-06-25 20:03:12.310929
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    
    assert isinstance(str_0, str)
    assert len(str_0) == 18
    assert str_0[2] == '.'
    assert str_0[6] == '.'
    assert str_0[10] == '/'
    assert str_0[15] == '-'



# Generated at 2022-06-25 20:03:20.144410
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert (int(str_0[0]) in range(1, 10))
    assert (int(str_0[1]) in range(1, 10))
    assert (str_0[2] == '.')
    assert (int(str_0[3]) in range(1, 10))
    assert (int(str_0[4]) in range(1, 10))
    assert (int(str_0[5]) in range(1, 10))
    assert (str_0[6] == '.')
    assert (int(str_0[7]) in range(1, 10))
    assert (int(str_0[8]) in range(1, 10))

# Generated at 2022-06-25 20:03:21.462468
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    brazil_spec_provider = BrazilSpecProvider()

    cnpj = brazil_spec_provider.cnpj()


# Generated at 2022-06-25 20:03:30.433936
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    def get_verifying_digit_cpf(cpf, peso):
        """Calculate the verifying digit for the CPF.
        :param cpf: List of integers with the CPF.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CPF.
        """
        soma = 0
        for index, digit in enumerate(cpf):
            soma += digit * (peso - index)
        resto = soma % 11
        if resto == 0 or resto == 1 or resto >= 11:
            return 0
        return 11 - resto

# Generated at 2022-06-25 20:03:31.961951
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    s = BrazilSpecProvider()
    assert (s.cnpj() == '20.878.319/0001-93')

# Generated at 2022-06-25 20:03:34.922800
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 != ''
    assert len(str_0) == 14


# Generated at 2022-06-25 20:03:39.590989
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Define values for method test
    with_mask = True

    # Initialize class
    brazil_spec_provider = BrazilSpecProvider()

    # Execute method with arguments
    cnpj_str = brazil_spec_provider.cnpj(with_mask)

    # Check if the type of the result is str
    assert isinstance(cnpj_str, str) == True

    # Check if the value of the result is expected
    assert cnpj_str == '07.933.906/0001-55'


# Generated at 2022-06-25 20:03:41.497319
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18
