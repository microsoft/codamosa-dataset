

# Generated at 2022-06-25 19:55:00.985312
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(True) != ''


# Generated at 2022-06-25 19:55:04.472333
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("Test for method cnpj() of class BrazilSpecProvider")
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-25 19:55:13.538805
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '738.934.058-77'
    str_1 = brazil_spec_provider_0.cpf()
    assert str_1 == '280.641.568-61'
    str_2 = brazil_spec_provider_0.cpf(False)
    assert str_2 == '04232445229'
    str_3 = brazil_spec_provider_0.cpf(False)
    assert str_3 == '05455581422'
    str_4 = brazil_spec_provider_0.cpf()
    assert str_4 == '728.715.636-16'
    str_

# Generated at 2022-06-25 19:55:17.944693
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert re.fullmatch('[0-9]{3}[.][0-9]{3}[.][0-9]{3}[-][0-9]{2}', brazil_spec_provider_0.cpf()) != None


# Generated at 2022-06-25 19:55:20.809755
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:55:25.847304
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf()
    assert str_0 != str_1
    assert len(str_0) == 14
    assert len(str_1) == 14



# Generated at 2022-06-25 19:55:28.515584
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()

    assert len(str_0) == 14


# Generated at 2022-06-25 19:55:31.275506
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert isinstance(str_0, str) == True
    # TODO: Find a better way for testing this method



# Generated at 2022-06-25 19:55:35.442922
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert len(str_0) == 14
    str_1 = brazil_spec_provider_0.cpf(with_mask=False)
    assert len(str_1) == 11


# Generated at 2022-06-25 19:55:37.906597
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cnpj()
    assert len(str_0) == 18



# Generated at 2022-06-25 19:55:46.891309
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:55:52.303215
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test with default value of parameter with_mask.
    brazil_spec_provider_0 = BrazilSpecProvider(seed=123)
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '024.608.080-27'
    # Test with different value of parameter with_mask.
    str_1 = brazil_spec_provider_0.cpf(with_mask=False)
    assert str_1 == '59928409840'


# Generated at 2022-06-25 19:55:54.723535
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_ = BrazilSpecProvider()
    cnpj = brazil_spec_provider_.cnpj()
    #print(cnpj)
    assert cnpj == '11.555.861/0001-51'


# Generated at 2022-06-25 19:55:58.970735
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected_str_1 = '609.954.033-69'
    brazil_spec_provider_0 = BrazilSpecProvider(seed=917081467)
    actual_str_1 = brazil_spec_provider_0.cpf()
    assert actual_str_1 == expected_str_1


# Generated at 2022-06-25 19:56:01.557489
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:56:07.350656
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test cases for BrazilSpecProvider.cpf
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf(True)
    assert len(str_0) == 14


# Generated at 2022-06-25 19:56:09.526158
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    str_0 = BrazilSpecProvider().cnpj(True)
    assert len(str_0) == 18


# Generated at 2022-06-25 19:56:12.966655
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert(len(str_0) == 18)


# Generated at 2022-06-25 19:56:15.758485
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18


# Generated at 2022-06-25 19:56:19.424702
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:56:34.169807
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert '31.766.614/0001-54' == BrazilSpecProvider().cnpj()


# Generated at 2022-06-25 19:56:38.233510
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:56:47.463183
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert brazil_spec_provider_0.cpf(False) == "88443879636"
    assert brazil_spec_provider_0.cpf(True) == "884.438.796-36"
    assert brazil_spec_provider_0.cpf(False) == "36890115777"
    assert brazil_spec_provider_0.cpf(False) == "36890115777"
    assert brazil_spec_provider_0.cpf(True) == "368.901.157-77"
    assert brazil_spec_provider_0.cpf(False) == "53111759103"

# Generated at 2022-06-25 19:56:58.603553
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf()
    str_2 = brazil_spec_provider_0.cpf()
    str_3 = brazil_spec_provider_0.cpf()
    assert re.match('\d{3}.\d{3}.\d{3}-\d{2}', str_0)
    assert re.match('\d{3}.\d{3}.\d{3}-\d{2}', str_1)
    assert re.match('\d{3}.\d{3}.\d{3}-\d{2}', str_2)

# Generated at 2022-06-25 19:57:01.506534
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj()
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)
    assert cnpj[len(cnpj)-1] != '-'


# Generated at 2022-06-25 19:57:05.724118
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Given
    brazil_spec_provider_0 = BrazilSpecProvider()
    # When
    str_0 = brazil_spec_provider_0.cnpj()
    # There
    assert str_0 is not None
    assert len(str_0) == 18


# Generated at 2022-06-25 19:57:09.655805
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cnpj()) == 18
    assert len(brazil_spec_provider_0.cnpj(True)) == 18
    


# Generated at 2022-06-25 19:57:13.195892
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_1.cpf()
    assert len(str_0) == 14
    assert isinstance(str_0, str)


# Generated at 2022-06-25 19:57:16.538413
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test case 0"""
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 == '77.732.230/0001-70'



# Generated at 2022-06-25 19:57:18.663324
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()

    cpf = brazil_spec_provider.cpf(with_mask=True)

    assert len(cpf) == 14


# Generated at 2022-06-25 19:57:46.769165
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert (brazil_spec_provider_0.cnpj() == '77.732.230/0001-70')

# Generated at 2022-06-25 19:57:48.005915
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:57:49.954153
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert len(brazil_spec_provider_0.cpf()) == 14

# Generated at 2022-06-25 19:57:53.441922
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 is not None
    assert str_0 != ''
    assert isinstance(str_0, str)


# Generated at 2022-06-25 19:57:56.091396
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    print(str_0)


# Generated at 2022-06-25 19:57:58.958461
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:58:05.735443
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test case # 1
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf(True)
    assert str_0 == '001.137.297-40'
    # Test case # 2
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf(False)
    assert str_1 == '00113729740'


# Generated at 2022-06-25 19:58:08.006845
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18


# Generated at 2022-06-25 19:58:10.733546
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert (len(str_0) == 14)


# Generated at 2022-06-25 19:58:15.130974
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test 0
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    # Test 1
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf()
    assert str_1 != str_0


# Generated at 2022-06-25 19:59:20.592843
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:59:22.407423
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # unit_test_0
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()



# Generated at 2022-06-25 19:59:23.487844
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18


# Generated at 2022-06-25 19:59:28.420938
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj(with_mask=False)
    str_2 = brazil_spec_provider_0.cnpj(with_mask=True)
    str_3 = brazil_spec_provider_0.cnpj(with_mask=False)
    assert isinstance(str_0, str)
    assert isinstance(str_1, str)
    assert isinstance(str_2, str)
    assert isinstance(str_3, str)


# Generated at 2022-06-25 19:59:31.974947
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    result_str_0 = brazil_spec_provider_0.cpf()
    assert result_str_0 is not None


# Generated at 2022-06-25 19:59:35.172312
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()


# Generated at 2022-06-25 19:59:40.852709
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = 'RandomSeed'
    brazil_spec_provider_0 = BrazilSpecProvider(seed)
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 == '79.965.919/0001-03'


# Generated at 2022-06-25 19:59:50.062476
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf_without_mask = brazil_spec_provider.cpf(with_mask=False)
    assert len(cpf_without_mask) == 11
    assert all(digit.isdigit() for digit in cpf_without_mask)
    cpf_with_mask = brazil_spec_provider.cpf(with_mask=True)
    assert len(cpf_with_mask) == 14
    assert cpf_with_mask[3] == '.'
    assert cpf_with_mask[7] == '.'
    assert cpf_with_mask[11] == '-'
    assert all(digit.isdigit() or digit == '.' or digit == '-' for digit in cpf_with_mask)



# Generated at 2022-06-25 20:00:00.507373
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test results."""
    # Test with explicit locale
    brazil_spec_provider = BrazilSpecProvider()
    expected = '065.867.168-04'
    result = brazil_spec_provider.cpf()
    assert result == expected
    expected = '06586.7168-04'
    result = brazil_spec_provider.cpf(False)
    assert result == expected

    # Test with implicit locale
    from mimesis.builder import Builder
    brazil_spec_provider_2 = Builder('pt_br').brazil_provider()
    expected = '854.093.919-13'
    result = brazil_spec_provider_2.cpf()
    assert result == expected
    expected = '85409391913'
    result = brazil_spec

# Generated at 2022-06-25 20:00:06.282184
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cpf(False)
    assert len(str_0) == 11
    str_1 = brazil_spec_provider.cpf(True)
    assert len(str_1) == 14


# Generated at 2022-06-25 20:02:31.375414
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()

    assert str_0 is not None



# Generated at 2022-06-25 20:02:37.489589
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cnpj()
    assert len(str_0) == 18


# Generated at 2022-06-25 20:02:43.299877
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # cnpj with_mask
    cnpj_0 = BrazilSpecProvider().cnpj(True)
    assert cnpj_0 is not None
    # cnpj with_mask
    cnpj_1 = BrazilSpecProvider().cnpj(False)
    assert cnpj_1 is not None


# Generated at 2022-06-25 20:02:46.775242
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 18, "unexpected CNPJ length"


# Generated at 2022-06-25 20:02:53.014063
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for _ in range(10000):
        brazil_spec_provider_0 = BrazilSpecProvider()
        str_0 = brazil_spec_provider_0.cpf()

        # Check if the cpf is valid
        assert len(str_0) == 14
        cpf = str_0.replace(".","").replace("-", "")
        assert int(cpf[-2]) == BrazilSpecProvider.get_verifying_digit_cpf(cpf[:-2])
        assert int(cpf[-1]) == BrazilSpecProvider.get_verifying_digit_cpf(cpf[:-1])


# Generated at 2022-06-25 20:02:59.518111
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test with_mask
    with_mask = True
    cnj_test_1 = BrazilSpecProvider().cnpj(with_mask)
    assert len(cnj_test_1) == 18
    with_mask = False
    cnj_test_2 = BrazilSpecProvider().cnpj(with_mask)
    assert len(cnj_test_2) == 14


# Generated at 2022-06-25 20:03:04.094479
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert isinstance(str_0, str)
    assert len(str_0) == 18
    str_1 = brazil_spec_provider_0.cnpj(with_mask=False)
    assert isinstance(str_1, str)
    assert len(str_1) == 14


# Generated at 2022-06-25 20:03:06.308831
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 20:03:15.565076
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    str_1 = brazil_spec_provider_0.cpf()
    str_2 = brazil_spec_provider_0.cpf()
    str_3 = brazil_spec_provider_0.cpf()
    str_4 = brazil_spec_provider_0.cpf()
    str_5 = brazil_spec_provider_0.cpf()
    assert str_0 == str_1
    assert str_1 == str_2
    assert str_2 == str_3
    assert str_3 == str_4
    assert str_4 == str_5


# Generated at 2022-06-25 20:03:17.947363
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    print(str_0)
    assert len(str_0) is 14
