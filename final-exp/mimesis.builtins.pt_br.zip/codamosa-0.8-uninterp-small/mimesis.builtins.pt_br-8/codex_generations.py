

# Generated at 2022-06-25 19:55:01.442043
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    brazil_spec_provider.cnpj()
    assert True


# Generated at 2022-06-25 19:55:05.458501
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 14
    assert b.cpf(False) == b.cpf(True).replace(".","").replace("-","")
    assert b.cpf().count(".") == 2
    assert b.cpf().count("-") == 1


# Generated at 2022-06-25 19:55:06.871704
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    string_0 = BrazilSpecProvider().cpf()
    assert isinstance(string_0, str) == True



# Generated at 2022-06-25 19:55:11.312064
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cnpj()
    assert re.match('^\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}$', str_1)


# Generated at 2022-06-25 19:55:13.882098
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 19:55:17.942921
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cnpj(False) == '28505612000104'
    assert brazil_spec_provider.cnpj(True) == '28.505.612/0001-04'


# Generated at 2022-06-25 19:55:22.541369
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0
    str_0 = brazil_spec_provider_0.cpf(False)
    assert str_0


# Generated at 2022-06-25 19:55:25.898334
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # declarations
    brazil_spec_provider_0 = BrazilSpecProvider()
    # Unit test for method cnpj of class BrazilSpecProvider
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:55:33.060340
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed_0 = Seed.random()
    seed_1 = Seed.random()
    brazil_spec_provider_0 = BrazilSpecProvider(seed=seed_0)
    brazil_spec_provider_1 = BrazilSpecProvider(seed=seed_1)
    assert brazil_spec_provider_0.cpf() != brazil_spec_provider_1.cpf()
    brazil_spec_provider_0 = BrazilSpecProvider(seed=seed_1)
    brazil_spec_provider_1 = BrazilSpecProvider(seed=seed_0)
    assert brazil_spec_provider_0.cpf() == brazil_spec_provider_1.cpf()
    brazil_spec_provider_0 = BrazilSpecProvider(seed=seed_0)
    brazil_spec_provider_

# Generated at 2022-06-25 19:55:41.813062
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()

    # Test with default value of argument with_mask
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj()
    str_2 = brazil_spec_provider_0.cnpj()
    str_3 = brazil_spec_provider_0.cnpj()
    str_4 = brazil_spec_provider_0.cnpj()
    str_5 = brazil_spec_provider_0.cnpj()
    str_6 = brazil_spec_provider_0.cnpj()
    str_7 = brazil_spec_provider_0.cnpj()
    str_8 = brazil_spec_prov

# Generated at 2022-06-25 19:55:52.255238
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert re.search(r'\d{2}\.\d{3}\.\d{3}\/\d{4}\-\d{2}', str_0)


# Generated at 2022-06-25 19:55:55.979114
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf_0 = brazil_spec_provider_0.cpf()
    # Check if  cpf_0 is a string
    assert isinstance(cpf_0, str)
    # Check if  cpf_0 is a str of length 14
    assert len(cpf_0) == 14


# Generated at 2022-06-25 19:55:57.934058
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 is not None


# Generated at 2022-06-25 19:56:01.753942
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pt-br')
    BrazilSpecProvider().cpf(with_mask=True)
    BrazilSpecProvider().cpf(with_mask=False)



# Generated at 2022-06-25 19:56:06.110636
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert type(str_0) == str


# Generated at 2022-06-25 19:56:10.401278
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import mimesis
    brazil_spec_provider_0 = mimesis.BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert str_0 == '77.732.230/0001-70'


# Generated at 2022-06-25 19:56:12.629568
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider()
    assert len(p.cpf()) == 14


# Generated at 2022-06-25 19:56:14.859143
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider_cnpj = BrazilSpecProvider()
    cnpj = provider_cnpj.cnpj(False)
    assert len(cnpj) == 14


# Generated at 2022-06-25 19:56:17.626393
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    brazil_spec_provider.cnpj()

# Generated at 2022-06-25 19:56:22.228892
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    print(str_0)
    # assert str_0 == '77.732.230/0001-70'


# Generated at 2022-06-25 19:56:44.947362
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # arg0 is just a placeholder for the first argument (self), because
    # it is a method of a class.
    arg0 = BrazilSpecProvider()
    arg1 = True

    # The following line calls the cpf method of the BrazilSpecProvider class
    # with the arguments arg0 and arg1 and assigns the return value (a CPF)
    # to the local variable x
    x = BrazilSpecProvider.cpf(arg0, arg1)

    # The following line asserts that the expected type of the return value is
    # string
    assert type(x) is str

    # The following line asserts that the return value has the expected format
    assert len(x) == 14

# Generated at 2022-06-25 19:56:46.618560
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilSpecProvider_instance_0 = BrazilSpecProvider()
    str_0 = brazilSpecProvider_instance_0.cnpj()

# Generated at 2022-06-25 19:56:52.603850
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18
    assert isinstance(str_0, str)


# Generated at 2022-06-25 19:56:54.410710
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Case 0:
    str_0 = BrazilSpecProvider().cpf()
    assert len(str_0) == 14


# Generated at 2022-06-25 19:56:57.533854
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = 12
    brazil_spec_provider_0 = BrazilSpecProvider(seed=seed)
    str_0 = brazil_spec_provider_0.cpf(False)

    assert str_0 == "11104603476"
    

# Generated at 2022-06-25 19:57:05.370061
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_1 = BrazilSpecProvider()
    assert brazil_spec_provider_1.cnpj() != None
    assert brazil_spec_provider_1.cnpj() != ''
    assert brazil_spec_provider_1.cnpj() == brazil_spec_provider_1.cnpj(False)
    assert brazil_spec_provider_1.cnpj() != brazil_spec_provider_1.cnpj(False)
    assert type(brazil_spec_provider_1.cnpj()) == str
    assert len(brazil_spec_provider_1.cnpj()) == 18
    assert len(brazil_spec_provider_1.cnpj(False)) == 14
    # Should raise ValueError exception

# Generated at 2022-06-25 19:57:13.013770
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test case for the method BrazilSpecProvider.cpf."""
    # Arrange
    brazil_spec_provider = BrazilSpecProvider()
    expected_format = "###.###.###-##"
    actual_format = ""
    # Act
    str_0 = brazil_spec_provider.cpf()
    actual_format = str_0[0:3] + '.' + str_0[3:6] + '.' + str_0[6:9] + '-' + str_0[9:]
    assert actual_format == expected_format


# Generated at 2022-06-25 19:57:16.971092
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert '019.387.631-23' == provider.cpf(with_mask=True), "provider.cpf(with_mask=True)"
    assert '019387631-23' == provider.cpf(with_mask=False), "provider.cpf(with_mask=False)"


# Generated at 2022-06-25 19:57:26.894959
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 == '853.764.472-64'
    str_1 = brazil_spec_provider_0.cpf()
    assert str_1 == '993.303.027-21'
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_2 = brazil_spec_provider_1.cpf()
    assert str_2 == '000.235.099-35'
    str_3 = brazil_spec_provider_1.cpf()
    assert str_3 == '706.392.879-85'


# Generated at 2022-06-25 19:57:30.770521
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert str_0 != None
    assert brazil_spec_provider_0._mask_for('cpf', True) == "###.###.###-##"


# Generated at 2022-06-25 19:57:58.112543
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_1 = BrazilSpecProvider()
    # Check to see if method returns a str type
    assert isinstance(brazil_spec_provider_1.cpf(), str)
    # Check to see if method returns a non-empty string
    assert len(brazil_spec_provider_1.cpf()) > 0


# Generated at 2022-06-25 19:58:02.470048
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Negative test case for method cpf
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_0.cpf(False)
    assert len(str_1) >= 11
    assert len(str_1) <= 11

# Generated at 2022-06-25 19:58:05.465248
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert isinstance(str_0, str)


# Generated at 2022-06-25 19:58:09.468241
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj()
    str_2 = brazil_spec_provider_0.cnpj()

    assert(str_1 != str_0 and str_2 != str_0 and str_2 != str_1)


# Generated at 2022-06-25 19:58:13.059922
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from hypothesis import given
    from hypothesis.strategies import sampled_from, text, booleans
    # https://www.receita.fazenda.gov.br/aplicacoes/atcta/cpf/funcoes.js
    brazil_spec_provider_1 = BrazilSpecProvider()
    str_1 = brazil_spec_provider_1.cpf()
    assert isinstance(str_1, str)


# Generated at 2022-06-25 19:58:15.172010
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cnpj() == '52.432.168/0001-01'


# Generated at 2022-06-25 19:58:17.974120
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()



# Generated at 2022-06-25 19:58:21.727573
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:58:24.310641
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert len(str_0) == 18
    assert str_0.isalpha() is not None


# Generated at 2022-06-25 19:58:27.244831
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    assert isinstance(brazil_spec_provider_0.cnpj(), str)


# Generated at 2022-06-25 19:59:36.896843
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert re.match(r'^\d{3}[.]\d{3}[.]\d{3}[-]\d{2}$', str_0)


# Generated at 2022-06-25 19:59:42.361396
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    test_cases = [
        {
            'with_mask': False,
        },
    ]

    for test_case in test_cases:
        with_mask = test_case.get('with_mask')
        str_0 = brazil_spec_provider_0.cnpj(with_mask)


# Generated at 2022-06-25 19:59:44.334171
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert test_case_0() == '766.941.912-11'


# Generated at 2022-06-25 19:59:48.028546
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test for method cnpj of class BrazilSpecProvider
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    assert isinstance(str_0, str)
    assert len(str_0) == 18


# Generated at 2022-06-25 19:59:49.666051
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 19:59:52.043238
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    cpf = brazil_spec_provider_0.cpf()
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-25 19:59:58.648223
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()

    assert isinstance(str_0, str)
    assert len(str_0) == 14
    assert str_0[3] == '.'
    assert str_0[7] == '.'
    assert str_0[11] == '-'



# Generated at 2022-06-25 19:59:59.685386
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert str_0 == '752.197.627-93'


# Generated at 2022-06-25 20:00:04.696649
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # mock object
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()

    assert type(str_0) == str
    assert len(str_0) == 14



# Generated at 2022-06-25 20:00:13.013917
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Testing BrazilSpecProvider.cpf")
    brazil_spec_provider = BrazilSpecProvider()
    # Test with the mask on
    res = brazil_spec_provider.cpf()
    print(f"BrazilSpecProvider.cpf()={res}")
    mask = res.split('.')
    assert (len(mask) == 3)
    assert (len(mask[0]) == 3)
    assert (len(mask[1]) == 3)
    assert (len(mask[2].split('-')) == 2)
    # Test with the mask off
    assert len(brazil_spec_provider.cpf(False)) == 11

if __name__ == "__main__":
    test_BrazilSpecProvider_cpf()

# Generated at 2022-06-25 20:02:37.489408
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    # '77.732.230/0001-70'
    print(str_0)


# Generated at 2022-06-25 20:02:41.776522
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()


# Generated at 2022-06-25 20:02:45.666013
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
    assert hasattr(brazil_spec_provider_0, 'cpf')


# Generated at 2022-06-25 20:02:50.071374
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cnpj()
    str_1 = brazil_spec_provider_0.cnpj(with_mask=False)

    assert(len(str_0) == 18)
    assert(len(str_1) == 14)



# Generated at 2022-06-25 20:02:53.597652
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test cases
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cnpj()
    str_1 = brazil_spec_provider.cnpj()
    str_2 = brazil_spec_provider.cnpj()



# Generated at 2022-06-25 20:02:58.152882
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert len(brazil_spec_provider.cnpj(with_mask=False)) == 14
    assert len(brazil_spec_provider.cnpj(with_mask=True)) == 18


# Generated at 2022-06-25 20:03:01.036344
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cpf(False)
    if str_0.isnumeric():
        print("Pass")
    else:
        print("Fail")


# Generated at 2022-06-25 20:03:02.871488
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()



# Generated at 2022-06-25 20:03:06.440121
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    str_0 = brazil_spec_provider.cpf()
    assert str_0
    assert isinstance(str_0, str)
    assert len(str_0) == 14
    assert all(c in '0123456789.-' for c in str_0)


# Generated at 2022-06-25 20:03:08.484216
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider_0 = BrazilSpecProvider()
    str_0 = brazil_spec_provider_0.cpf()
