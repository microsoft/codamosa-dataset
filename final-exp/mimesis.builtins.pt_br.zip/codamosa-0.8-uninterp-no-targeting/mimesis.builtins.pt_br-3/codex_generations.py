

# Generated at 2022-06-21 15:22:03.249372
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider constructor."""
    BrazilSpecProvider()
    BrazilSpecProvider(seed=42)

# Generated at 2022-06-21 15:22:05.924724
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('Method: cpf()')
    bs = BrazilSpecProvider()
    print(bs.cpf())
    print(bs.cpf(with_mask = False))


# Generated at 2022-06-21 15:22:12.758850
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf."""
    brazil_provider = BrazilSpecProvider()

    cpf = brazil_provider.cpf()

    cpf_string, cpf_digits = cpf[:-2], cpf[-2:]
    list_cpf_digits = [int(d) for d in cpf_digits]

    # First digit of CPF
    first_digit = list_cpf_digits[0]
    cpf_int_list = [int(d) for d in cpf_string]

    temp = []
    for i, _ in enumerate(cpf_int_list):
        cpf_int_list[i] = cpf_int_list[i] * (10 - i)
        temp.append(cpf_int_list[i])

# Generated at 2022-06-21 15:22:24.879834
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    spec_provider = BrazilSpecProvider(seed = 1234)

    assert spec_provider.cpf() == "865.821.618-52"
    assert spec_provider.cpf() == "704.368.250-37"
    assert spec_provider.cpf() == "212.450.898-73"
    assert spec_provider.cpf() == "878.346.738-52"
    assert spec_provider.cpf() == "540.782.036-65"
    assert spec_provider.cpf() == "238.745.828-17"
    assert spec_provider.cpf() == "332.917.977-00"
    assert spec_provider.cpf() == "001.136.300-98"

# Generated at 2022-06-21 15:22:28.189422
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider() 
    assert len(brazil_spec_provider.cnpj()) == 18

# Generated at 2022-06-21 15:22:30.960240
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    from mimesis.enums import Gender
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.get_locale() == 'pt_br'
    assert brazil_provider.seed == None


# Generated at 2022-06-21 15:22:40.606354
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Assert first 16 digits count 
    instance = BrazilSpecProvider()
    assert len(str(instance.cnpj(False))) == 16
    # Assert first 16 digits value
    instance = BrazilSpecProvider(seed=123)
    assert instance.cnpj(False) == "77732230000170"
    # Assert full count 
    instance = BrazilSpecProvider()
    assert len(str(instance.cnpj(True))) == 18
    # Assert full value
    instance = BrazilSpecProvider(seed=123)
    assert instance.cnpj(True) == "77.732.230/0001-70"


# Generated at 2022-06-21 15:22:44.131800
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert(bsp.cpf(False) == bsp.cpf(True).replace(".", "").replace("-", ""))
    assert(bsp.cnpj(False) == bsp.cnpj(True).replace(".", "").replace("-", "").replace("/", ""))

# Generated at 2022-06-21 15:22:44.924713
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    pass



# Generated at 2022-06-21 15:22:52.195718
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj()."""
    import re
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    print (cnpj)
    is_valid = re.match(r'^[0-9]{2}\.[0-9]{3}\.[0-9]{3}/[0-9]{4}-[0-9]{2}$', cnpj)
    assert is_valid!=None



# Generated at 2022-06-21 15:23:10.427920
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_with_mask = BrazilSpecProvider(seed=42).cpf(with_mask=True)
    assert cpf_with_mask == '719.172.523-14'
    cpf_without_mask = BrazilSpecProvider(seed=42).cpf(with_mask=False)
    assert cpf_without_mask == '71917252314'


# Generated at 2022-06-21 15:23:12.885029
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    try:
        class_ = BrazilSpecProvider()
    except Exception as e:
        raise e
    else:
        assert isinstance(class_, BrazilSpecProvider)

# Generated at 2022-06-21 15:23:20.597193
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = 'dfbc8c68d70f-4847-9e74-9d8c-f5ad5f34b05d'
    cpf_pattern = re.compile(r'^(\d{3})\.(\d{3})\.(\d{3})\-(\d{2})$')
    cpf = BrazilSpecProvider(seed).cpf()
    assert cpf_pattern.match(cpf) is not None


# Generated at 2022-06-21 15:23:24.917953
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    assert len(cnpj) == 18
    assert cnpj.count('.') == 2
    assert cnpj.count('-') == 1
    assert cnpj.count('/') == 1



# Generated at 2022-06-21 15:23:27.863960
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    assert isinstance(BrazilSpecProvider(), BrazilSpecProvider)
    assert isinstance(BrazilSpecProvider(seed=10), BrazilSpecProvider)



# Generated at 2022-06-21 15:23:32.078510
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj function class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert (len(cnpj) == 18)
    assert (cnpj[2] == '.')
    assert (cnpj[6] == '.')
    assert (cnpj[10] == '/')
    assert (cnpj[15] == '-')


# Generated at 2022-06-21 15:23:33.827149
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj()=='77.732.230/0001-70'

# Generated at 2022-06-21 15:23:40.258711
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert '.' in cpf
    assert '-' in cpf
    assert ' ' not in cpf
    assert cpf[:3].isnumeric()
    assert cpf[3] == '.'
    assert cpf[4:7].isnumeric()
    assert cpf[7] == '.'
    assert cpf[8:11].isnumeric()
    assert cpf[11] == '-'
    assert cpf[12:].isnumeric()
    assert not brazil.cpf(with_mask=False).endswith('.')
    assert not brazil.cpf(with_mask=False).endswith('-')
    assert not brazil.cpf(with_mask=False).endswith(' ')
   

# Generated at 2022-06-21 15:23:51.193567
# Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-21 15:23:57.706002
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import unittest

    from mimesis.builtins.brazil import BrazilSpecProvider as BSP

    class BrazilSpecProviderTestCase(unittest.TestCase):
        def setUp(self):
            self.bsp = BSP()

        def test_cpf(self):
            result = self.bsp.cpf()
            self.assertEqual(type(result), str)
            self.assertEqual(len(result), 14)
            self.assertTrue(1 <= int(result[0:3]) <= 999)
            self.assertTrue(1 <= int(result[4:7]) <= 999)
            self.assertTrue(1 <= int(result[8:11]) <= 999)
            self.assertTrue(1 <= int(result[12:]) <= 99)

    unittest.main()


# Generated at 2022-06-21 15:24:36.104262
# Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-21 15:24:40.429849
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    cpf = brazil.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.isdigit()


# Generated at 2022-06-21 15:24:47.508411
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[-2] == '-'
    assert cpf[-5] == '.'
    assert cpf[-9] == '.'
    assert cpf[-3] == cpf[-1]
    assert cpf[-4] == cpf[-2]
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18
    assert cnpj[-2] == '-'
    assert cnpj[-6] == '/'
    assert cnpj[-9] == '.'
    assert cnpj[-13] == '.'
    assert cnpj[-3] == cnpj[-1]

# Generated at 2022-06-21 15:24:58.449912
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    prov = BrazilSpecProvider()
    actual = prov.cnpj(False)
    assert isinstance(actual, str)
    assert len(actual) == 14
    assert actual[0] != '0'
    assert actual[1] != '0'
    assert actual[2] != '0'
    assert actual[3] != '0'
    assert actual[4] != '0'
    assert actual[5] != '0'
    assert actual[6] != '0'
    assert actual[7] != '0'
    assert actual[8] != '0'
    assert actual[9] != '0'
    assert actual[10] != '0'
    assert actual[11] != '0'
    assert actual.isdigit()


# Generated at 2022-06-21 15:25:00.375166
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    return BrazilSpecProvider().cnpj()


# Generated at 2022-06-21 15:25:09.085217
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""

    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert isinstance(cnpj, str), 'The returned value is not a string.'
    assert len(cnpj) == 18, 'The returned value does not have the expected length.'
    assert cnpj[2] == '.' and cnpj[6] == '.' and cnpj[10] == '/' and cnpj[15] == '-'
    assert cnpj[:2].isdigit() and cnpj[3:6].isdigit() and cnpj[7:10].isdigit() \
        and cnpj[11:15].isdigit() and cnpj[16:].isdigit()

    cnpj = b

# Generated at 2022-06-21 15:25:14.414337
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test if the method cnpj generates a valid CNPJ."""
    from mimesis.providers.cnpj import is_valid_cnpj

    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=False)
    assert is_valid_cnpj(cnpj)

# Generated at 2022-06-21 15:25:21.669382
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.providers.date import DateTime
    from mimesis.providers.geo import Geography
    from mimesis.builtins.base import BaseSpecProvider

    bsp = BrazilSpecProvider('Rafael')
    assert bsp._seed == 'Rafael'
    assert bsp._data == {}
    assert bsp.locale == 'pt-br'
    assert isinstance(bsp.datetime, DateTime)
    assert isinstance(bsp.geo, Geography)
    assert isinstance(bsp, BaseSpecProvider)


# Generated at 2022-06-21 15:25:24.632077
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().cpf(with_mask=False) == BrazilSpecProvider().cpf(with_mask=True)
    assert BrazilSpecProvider().cnpj(with_mask=False) == BrazilSpecProvider().cnpj(with_mask=True)

# Generated at 2022-06-21 15:25:33.577605
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.schema import Field
    from mimesis.providers.generic import Generic

    provider = BrazilSpecProvider(seed=12345)

    field_ = Field(provider.cpf)
    cpf = field_.create()
    for i in range(1, 10):
        assert(provider.cpf() == field_.create())

    assert(cpf == field_.create())

    provider.reset_seed()

    generic = Generic(12345)
    provider_1 = BrazilSpecProvider(seed=generic.create_seed(
        gender=Gender.MALE,
    ))
    field_1 = Field(provider_1.cpf)
    cpf_1 = field_1.create()


# Generated at 2022-06-21 15:26:54.920191
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for BrazilSpecProvider.cpf."""
    provider = BrazilSpecProvider()
    # 1 - Test generator with mask
    cpf = provider.cpf()
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    cpf = provider.cpf()
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    cpf = provider.cpf()
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    # 2 - Test generator without mask
    cpf = provider.cpf(with_mask=False)
    assert not cpf.count('.')
    assert not cpf.count('-')
    cpf = provider.cpf(with_mask=False)

# Generated at 2022-06-21 15:26:58.473228
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil_sp = BrazilSpecProvider()
    assert len(brazil_sp.cpf()) == 14

    brazil_sp2 = BrazilSpecProvider()
    assert len(brazil_sp2.cpf(with_mask = False)) == 11



# Generated at 2022-06-21 15:27:02.754486
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=None)
    assert bsp.cnpj() == '19.848.542/0001-76'
    assert bsp.cnpj(with_mask=False) == '19848542' + '000176'

# Generated at 2022-06-21 15:27:05.542134
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bs = BrazilSpecProvider()
    assert bs.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-21 15:27:09.242904
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf1 = BrazilSpecProvider.cpf()
    assert len(cpf1) == 14
    
    cpf2 = BrazilSpecProvider.cpf(False)
    assert len(cpf2) == 11


# Generated at 2022-06-21 15:27:10.448612
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bp = BrazilSpecProvider()
    assert bp


# Generated at 2022-06-21 15:27:23.017250
# Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-21 15:27:25.439494
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print("CPF:", provider.cpf())
    print("CNPJ:", provider.cnpj())

# Generated at 2022-06-21 15:27:27.471088
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-21 15:27:29.409967
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.brazil import BrazilSpecProvider
    brazil = BrazilSpecProvider()
    assert len(brazil.cnpj()) == 18


# Generated at 2022-06-21 15:30:05.067260
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Given a BrazilSpecProvider instance
    
    brazilSpecProvider = BrazilSpecProvider()

    # When i use the 'cnpj' method

    result = brazilSpecProvider.cnpj()

    # Then the result should not be empty
    
    assert result

# Generated at 2022-06-21 15:30:06.596644
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()  # Set seed
    cpf = brazil_provider.cpf()
    assert '.' not in cpf
    assert '-' not in cpf
    assert len(cpf) == 11


# Generated at 2022-06-21 15:30:11.597479
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf_test_set = set()
    case_amount = 100000
    for case in range(case_amount):
        brazil_provider = BrazilSpecProvider(seed=case)
        cpf_test_set.add(brazil_provider.cpf(with_mask=False))
    print('CPF AMOUNT:', len(cpf_test_set))


# Generated at 2022-06-21 15:30:13.568499
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    prov = BrazilSpecProvider('UTF-8')
    assert prov is not None


# Generated at 2022-06-21 15:30:17.146788
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test that the BrazilSpecProvider.cnpj() method
    returns the correct string.
    """
    seed = 1090809
    bsp = BrazilSpecProvider(seed=seed)

    assert bsp.cnpj() == '47.340.232/0001-43'



# Generated at 2022-06-21 15:30:22.601913
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    # Verify that the length of cpf is 14 (11 digits + 3 dots + 1 dash)
    assert len(cpf) == 14
    # Verify that cpf has 11 digits
    digits = cpf.replace('.', '').replace('-', '')
    assert all(c.isdigit() for c in digits)
    # Verify that the first nine digits are distinct
    assert len(set(digits[:9])) == 9


# Generated at 2022-06-21 15:30:23.794857
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '01.003.495/0001-60'


# Generated at 2022-06-21 15:30:24.872369
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brasil = BrazilSpecProvider()
    assert brasil is not None


# Generated at 2022-06-21 15:30:25.313712
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:30:28.080099
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'
