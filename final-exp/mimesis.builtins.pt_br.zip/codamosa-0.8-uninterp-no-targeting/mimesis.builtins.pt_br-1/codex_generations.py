

# Generated at 2022-06-21 15:22:04.345203
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    cnpj = brazil_provider.cnpj()
    assert isinstance(cnpj, str)

# Generated at 2022-06-21 15:22:07.679915
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    for i in range(1000):
        cpf1 = provider.cpf(with_mask=True)
        cpf2 = provider.cpf(with_mask=False)
        assert len(cpf1) == 14
        assert len(cpf2) == 11


# Generated at 2022-06-21 15:22:11.396597
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '689.289.106-21'
    assert provider.cpf(with_mask=False) == '68928910621'


# Generated at 2022-06-21 15:22:15.126154
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider._meta.name == 'brazil_provider'
    assert provider._meta.locale == 'pt-br'
    assert provider._meta.seed is None


# Generated at 2022-06-21 15:22:21.669518
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis import BrazilSpecProvider

    cnpj = BrazilSpecProvider().cnpj()
    if len(cnpj) != 14:
        raise AssertionError(
            "Unexpected length for the generated CNPJ. Expected 14, got {}."
            .format(len(cnpj)))
    else:
        print("CNPJ gerado: {}".format(cnpj))
        return cnpj


# Generated at 2022-06-21 15:22:28.739446
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test that CNPJs are valid
    assert BrazilSpecProvider().cnpj() in [
        '77.732.230/0001-70',
        '15.179.890/0001-32',
        '73.497.510/0001-37',
    ]
    assert BrazilSpecProvider().cnpj(with_mask=False) in [
        '77732230000170',
        '15179890000132',
        '73497510000137',
    ]



# Generated at 2022-06-21 15:22:31.084577
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import json
    x = BrazilSpecProvider()
    print(x.cpf())
    print(x.cnpj())

if __name__ == '__main__': test_BrazilSpecProvider()

# Generated at 2022-06-21 15:22:34.260232
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider(seed=31415).cpf(with_mask=True) == '137.297-40'


# Generated at 2022-06-21 15:22:37.077285
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():

    brazil_provider = BrazilSpecProvider()

    cpf = brazil_provider.cpf()

    print(cpf)


# Generated at 2022-06-21 15:22:40.439190
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() == '032.759.398-17'
    assert brazil_provider.cnpj() == '07.932.085/0001-26'

# Generated at 2022-06-21 15:22:49.176919
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == "812.610.646-00"


# Generated at 2022-06-21 15:22:50.387127
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    result = BrazilSpecProvider()
    assert result

# Generated at 2022-06-21 15:22:52.691684
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_BrazilSpecProvider = BrazilSpecProvider()
    assert test_BrazilSpecProvider.__class__.__name__ == 'BrazilSpecProvider'



# Generated at 2022-06-21 15:22:56.811096
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # provider = BrazilSpecProvider()
    # assert provider._locale == 'pt-br'
    # assert provider._seed is None
    #
    # seed = 'test_seed'
    # provider = BrazilSpecProvider(seed)
    # assert provider._locale == 'pt-br'
    # assert provider._seed == 'test_seed'
    assert True
    pass



# Generated at 2022-06-21 15:22:58.463337
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '013.117.023-75'


# Generated at 2022-06-21 15:23:02.110916
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_cnpj = BrazilSpecProvider()
    assert test_cnpj.cnpj() == '66.925.067/0001-07'


# Generated at 2022-06-21 15:23:04.564467
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    s = b.cpf(True)

    assert len(s) == 14


# Generated at 2022-06-21 15:23:06.606825
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf()
    assert brazil.cnpj()

# Generated at 2022-06-21 15:23:07.653186
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    assert BrazilSpecProvider()


# Generated at 2022-06-21 15:23:12.605746
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Check the values ​​generated by random.
    Random type: random.randint
    """
    # Initialize BrazilSpecProvider
    BrazilSpecProvider()
    # Test cpf
    assert BrazilSpecProvider().cpf() == '099.664.974-59'
    # Test cnpj
    assert BrazilSpecProvider().cnpj() == '01.802.775/0001-96'

# Generated at 2022-06-21 15:23:27.128164
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.locale == 'pt-br'



# Generated at 2022-06-21 15:23:29.984772
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    objetivo = BrazilSpecProvider()
    assert objetivo.cnpj() == '77.732.230/0001-70'


#Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-21 15:23:33.471912
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-21 15:23:34.301316
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '521.798.968-28'

# Generated at 2022-06-21 15:23:36.113755
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj == '77.732.230/0001-70'

# Generated at 2022-06-21 15:23:38.700402
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of BrazilSpecProvider."""
    seed = "3eb3b6d7e6cd37dc"
    locale_name = 'pt-br'

    provider = BrazilSpecProvider(seed=seed)

    assert provider.locale == locale_name
    assert provider.seed == seed

# Generated at 2022-06-21 15:23:42.070650
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    from mimesis import BrazilSpecProvider

    br = BrazilSpecProvider()
    assert br.cnpj()
    assert br.cnpj(True)
    assert len(br.cnpj()) == 14
    assert len(br.cnpj(True)) == 18

# Generated at 2022-06-21 15:23:45.433479
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test"""
    bp = BrazilSpecProvider()
    assert bp.cpf()
    assert bp.cnpj()

# Generated at 2022-06-21 15:23:52.497511
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    def check_cpf(result, with_mask):
        # Check the formatting of the CPF
        assert len(result) == 14 if with_mask else 11
        for i in range(3 if with_mask else 9):
            assert result[i*3] == '.' if with_mask else result[i]
        assert result[-2] == '-' if with_mask else result[9]

    provider = BrazilSpecProvider()
    result = provider.cpf()
    check_cpf(result, True)
    result = provider.cpf(False)
    check_cpf(result, False)


# Generated at 2022-06-21 15:23:56.263957
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    a = BrazilSpecProvider()
    assert a.cnpj() == '09.169.845/0001-93'

# Generated at 2022-06-21 15:24:30.546126
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    # Test cnpj with mask.
    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

    # Test cnpj without mask.
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert cnpj.isdigit()



# Generated at 2022-06-21 15:24:37.454540
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cp = BrazilSpecProvider()
    cnpj = cp.cnpj(with_mask=True)
    assert cnpj[0:2] == '77'
    assert cnpj[3:5] == '732'
    assert cnpj[6:8] == '230'
    assert cnpj[9:11] == '0001'
    assert cnpj[-2:] == '70'



# Generated at 2022-06-21 15:24:40.773993
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the method cnpj() of class BrazilSpecProvider."""
    prov = BrazilSpecProvider()
    print(
        prov.cnpj(with_mask=True),
        prov.cnpj(with_mask=False),
    )


# Generated at 2022-06-21 15:24:44.921434
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for _ in range(100):
        cpf = provider.cpf()
        assert len(cpf) == 14, 'Invalid length'
        assert cpf[3] == '.', 'No dot in first group'
        assert cpf[7] == '.', 'No dot in second group'
        assert cpf[11] == '-', 'No dash in third group'


# Generated at 2022-06-21 15:24:49.190850
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider class, method cnpj."""
    print('Start test BrazilSpecProvider class, method cnpj')
    print('Create a object of class BrazilSpecProvider')
    br = BrazilSpecProvider()
    print('Get cnpj')
    print(br.cnpj())
    print('test BrazilSpecProvider class, method cnpj is successfull')


# Run unit tests for BrazilSpecProvider
if __name__ == '__main__':
    """Run the unit tests."""    
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-21 15:24:50.986520
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider(seed=42)

# Generated at 2022-06-21 15:24:51.862323
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()
    assert br is not None

# Generated at 2022-06-21 15:24:56.858999
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    '''Test method "cpf" of class BrazilSpecProvider.'''
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf() #   '220.204.831-74'
    print(cpf)
    assert isinstance(cpf, str)
    assert len(cpf) == 14



# Generated at 2022-06-21 15:24:59.941071
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider"""
    bs = BrazilSpecProvider()
    cnpj = bs.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:25:08.801049
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    def test_Brazil_spec_provider_seed(seed):
        provider1 = BrazilSpecProvider(seed=seed)
        provider2 = BrazilSpecProvider(seed=seed)
        cpf1 = provider1.cpf()
        cpf2 = provider2.cpf()
        assert cpf1 == cpf2, "CPF Mismatch: {} != {}".format(cpf1, cpf2)
        cnpj1 = provider1.cnpj()
        cnpj2 = provider2.cnpj()
        assert cnpj1 == cnpj2, "CNPJ Mismatch: {} != {}".format(cnpj1, cnpj2)

    test_Brazil_spec_provider_seed(0)
    test_Brazil_spec_provider_seed(1)
    test_Brazil_spec

# Generated at 2022-06-21 15:26:18.559994
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj(False)) == 14
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert isinstance(BrazilSpecProvider().cnpj(True), str)
    assert isinstance(BrazilSpecProvider().cnpj(False), str)


# Generated at 2022-06-21 15:26:27.360975
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider.
    """
    # Arrange
    p = BrazilSpecProvider()

    # Act
    result = p.cpf()

    # Assert
    assert result == '015.936.717-40'

    # Arrange
    p = BrazilSpecProvider(seed=1)

    # Act
    result = p.cpf()

    # Assert
    assert result == '153.456.686-52'

    # Arrange
    p = BrazilSpecProvider(seed=2)

    # Act
    result = p.cpf()

    # Assert
    assert result == '933.045.147-05'

    # Arrange
    p = BrazilSpecProvider(seed=3)

    # Act
    result = p.cpf()

    # Assert


# Generated at 2022-06-21 15:26:33.309407
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    random_cnpj = brazil.cnpj(with_mask=True)
    print('cnpj:')
    print('\t',random_cnpj)
    assert type(random_cnpj) is str
    assert random_cnpj == '77.732.230/0001-70'

# Generated at 2022-06-21 15:26:37.260080
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()

    assert cpf.count('.') == 2
    assert cpf.count('-') == 1
    assert cpf.replace('-', '').replace('.', '').isdigit()


# Generated at 2022-06-21 15:26:45.382035
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from random import seed
    from mimesis.providers.brazil import BrazilSpecProvider
    from datetime import datetime

    seed(datetime.now())   # to have a different set of random numbers each time
    brazilsp = BrazilSpecProvider()

    zeros_cnpj_without_dv = [0 for i in range(12)]
    first_dv = brazilsp.get_verifying_digit_cnpj(zeros_cnpj_without_dv, 5)
    zeros_cnpj_without_dv.append(first_dv)
    second_dv = brazilsp.get_verifying_digit_cnpj(zeros_cnpj_without_dv, 6)
    zeros_cnpj_without_dv.append(second_dv)
   

# Generated at 2022-06-21 15:26:46.971957
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the cnpj method"""
    assert "17.615.012/0001-65" == BrazilSpecProvider().cnpj()


# Generated at 2022-06-21 15:26:56.234630
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address

    brazil = BrazilSpecProvider()
    person = Person('pt-br')
    address = Address('pt-br')

    data = {}
    data['cpf'] = brazil.cpf(with_mask=False)
    data['name'] = person.full_name(gender=Gender.MALE)
    data['street'] = address.street_name()
    data['number'] = address.house_number()
    data['district'] = address.district()
    data['city'] = address.city()
    data['state'] = address.state()
    data['zip_code'] = address.post

# Generated at 2022-06-21 15:26:59.588748
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """ Unit test for method BrazilSpecProvider.cpf() """
    bsp = BrazilSpecProvider(seed=12345)
    assert bsp.cpf() == '377.839.495-77'


# Generated at 2022-06-21 15:27:05.583695
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pt-br')
    print(p.cpf(with_mask=False))
    assert p.cpf() == '009.177.242-22'
    assert p.cpf(with_mask=False) == '00917724222'



# Generated at 2022-06-21 15:27:06.568554
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()


# Generated at 2022-06-21 15:29:38.211158
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert(len(cpf) == 14)
    assert(cpf[3] == '.')
    assert(cpf[7] == '.')
    assert(cpf[11] == '-')
    assert(cpf.isdigit())
    assert(cpf[-2:].isdigit())
    assert(cpf[:-2].replace('.', '').replace('-', '').isdigit())
    assert(int(cpf[-2:]) ==
           int(cpf[:9].replace('.', '')))


# Generated at 2022-06-21 15:29:45.483779
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import random
    from mimesis.enums import Gender
    from mimesis.providers.date_time import DateTime
    from mimesis.providers.person import Person
    from mimesis.providers.text import Text

    tipoPessoa = random.randint(0, 1) # Se tipoPessoa == 0 pessoa física, se tipoPessoa == 1 pessoa jurídica
    if tipoPessoa == 0:
        pessoa = Person('pt-br')
        cpf = pessoa.document(document='cpf')
    elif tipoPessoa == 1:
        pessoa = BrazilSpecProvider()
        cpf = pessoa.cnpj()

    hora = DateTime()
    info = Text()

    #print('Tipo

# Generated at 2022-06-21 15:29:47.990449
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.__class__.__name__ == 'BrazilSpecProvider'
    assert brazil_provider.__class__.__module__ == 'mimesis.builtins.br'



# Generated at 2022-06-21 15:29:55.242564
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    assert len(brazil.cpf()) == 14
    assert len(brazil.cpf(with_mask=False)) == 11
    assert brazil.cpf(with_mask=False).isdigit()
    assert '.' not in brazil.cpf(with_mask=False)
    assert '-' not in brazil.cpf(with_mask=False)
    cpf_formatado = brazil.cpf()
    assert cpf_formatado[3] == '.' and cpf_formatado[7] == '.' and cpf_formatado[11] == '-'


# Generated at 2022-06-21 15:29:57.072685
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    res = brazil.cpf()
    assert len(res) == 14


# Generated at 2022-06-21 15:29:58.237233
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    spec = BrazilSpecProvider()
    spec.cpf()


# Generated at 2022-06-21 15:29:59.604080
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert isinstance(bsp.cpf(), str)


# Generated at 2022-06-21 15:30:01.724172
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider."""
    bsp = BrazilSpecProvider()

    assert bsp, 'Could not instantiate BrazilSpecProvider'

# Generated at 2022-06-21 15:30:02.470315
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:30:03.369883
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()  # noqa: WPS421