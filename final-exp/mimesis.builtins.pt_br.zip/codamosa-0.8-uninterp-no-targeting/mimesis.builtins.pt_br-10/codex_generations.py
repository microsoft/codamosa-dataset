

# Generated at 2022-06-21 15:22:06.717358
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.builtins import RussiaSpecProvider

    rsp = RussiaSpecProvider()

    for seed in range(1000):
        prov = BrazilSpecProvider(seed=seed)

        mask = '%s.%s.%s/%s-%s' % tuple(rsp.random_element(rsp.string(2))) + tuple(rsp.random_element(rsp.string(1))) * 3
        sample = prov.cnpj(with_mask=False)
        assert sample == prov.cnpj()
        assert type(sample) == str
        assert len(sample) == 14
        assert sample.isdigit()
        assert prov.cnpj() == prov.cnpj()



# Generated at 2022-06-21 15:22:08.343338
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor BrazilSpecProvider

    :returns: None
    """
    assert BrazilSpecProvider().__init__


# Generated at 2022-06-21 15:22:10.477872
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_spec = BrazilSpecProvider()
    
    assert test_spec.cpf() != test_spec.cpf()
    assert test_spec.cnpj() != test_spec.cnpj()

# Generated at 2022-06-21 15:22:14.321559
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cpf = b.cnpj(with_mask=False)
    assert len(cpf) == 14 or len(cpf) == 18


# Generated at 2022-06-21 15:22:18.897471
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert repr(provider) == 'BrazilSpecProvider()'
    assert provider.cpf() == '702.086.837-95'
    assert provider.cnpj() == '58.727.947/0001-05'

# Generated at 2022-06-21 15:22:20.587140
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert isinstance(obj, BrazilSpecProvider)

# Generated at 2022-06-21 15:22:22.988533
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    # example call method, print cpf
    print(provider.cpf())

# Generated at 2022-06-21 15:22:28.878601
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider(seed=12345)
    assert brazil.cpf() == '193.096.808-63'
    assert brazil.cpf() == '773.426.829-30'
    assert brazil.cnpj() == '28.814.748/0001-61'
    assert brazil.cnpj() == '94.734.917/0001-07'

# Generated at 2022-06-21 15:22:33.474414
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Given
    provider = BrazilSpecProvider()

    # When
    cpf = provider.cpf(with_mask=False)

    # Then
    assert len(cpf) == 11


# Generated at 2022-06-21 15:22:35.473717
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """This method unit test BrazilSpecProvider."""
    BrazilSpecProvider()


# Generated at 2022-06-21 15:22:57.653157
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create a --brazil_provider
    my_brazil_provider = BrazilSpecProvider()

    # Get a --cnpj
    my_cnpj = my_brazil_provider.cnpj(with_mask=True)

    # Get another --cnpj
    my_other_cnpj = my_brazil_provider.cnpj(with_mask=True)

    # Verify if my_cnpj is a string
    assert isinstance(my_cnpj, str)

    # Verify if my_cnpj and my_other_cnpj are different
    assert my_cnpj != my_other_cnpj

    # Verify if my_cnpj length is 18 (with mask)
    assert len(my_cnpj) == 18

    # Get a --cnpj without

# Generated at 2022-06-21 15:23:09.164878
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print("Testing BrazilSpecProvider_cnpj:")
    import re
    # Testing with_mask=True
    print("Testing with_mask=True:")
    cnpj = BrazilSpecProvider().cnpj(with_mask=True)
    # Regex to check if the value is a valid CNPJ
    regex = re.compile(r'^\d{2}\.\d{3}\.\d{3}\/\d{4}\-\d{2}$')
    if regex.match(cnpj):
        print(repr(cnpj))
    else:
        print('ERROR - The generated CNPJ is not valid.')
    # Testing with_mask=False
    print("Testing with_mask=False:")

# Generated at 2022-06-21 15:23:11.298184
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    print(cpf)


# Generated at 2022-06-21 15:23:13.653121
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj_formatado = provider.cnpj()
    tam = len(cnpj_formatado)
    assert tam <= 18

# Generated at 2022-06-21 15:23:16.085380
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cnpj()

# Generated at 2022-06-21 15:23:16.909868
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    BrazilSpecProvider().cpf()


# Generated at 2022-06-21 15:23:20.646584
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    brazil = BrazilSpecProvider()

    cnpj = brazil.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18

# Generated at 2022-06-21 15:23:23.526328
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    text = BrazilSpecProvider()
    cpf = text.cpf(with_mask=True)
    assert cpf.isnumeric() and len(cpf) == 14


# Generated at 2022-06-21 15:23:30.325559
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    def test_constructor():
        provider = BrazilSpecProvider()
        assert isinstance(provider, BrazilSpecProvider)
        assert isinstance(provider, BaseSpecProvider)
        assert provider.__doc__ == 'Class that provides special data for Brazil (pt-br).'
        assert provider.Meta.name == 'brazil_provider'
        assert provider.locale == 'pt-br'

    def test_calls():
        provider = BrazilSpecProvider()
        provider.cnpj()
        provider.cpf()

    test_constructor()

    # test_calls()

# Generated at 2022-06-21 15:23:38.700276
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create a BrazilSpecProvider
    bsp = BrazilSpecProvider(seed=123456789)
    # Get the cnpj without mask
    cnpj = bsp.cnpj()
    # Check if the returned value is valid
    assert cnpj == '067227250890'    # Expected value
    # Get the cnpj with mask
    cnpj = bsp.cnpj(with_mask=True)
    # Check if the returned value is valid
    assert cnpj == '06.722.725/0890-00'     # Expected value
    # Instantiate a BrazilSpecProvider
    bsp = BrazilSpecProvider()
    # Instance the seed
    seed = 123456789
    # Get the seed for the BrazilSpecProvider
    bsp.seed(seed)
    # Generate the

# Generated at 2022-06-21 15:24:15.109376
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    # Instantiate a person
    person = Person('pt-br')

    # Capture the result of the function
    cpf = person.cpf()

    # Test the length of cpf
    assert len(cpf) == 14

    # Test if cpf are crescent
    crescent = True
    for i in range(13):
        if i % 3 == 2:
            if cpf[i] != '-':
                crescent = False
        elif i % 3 == 0:
            if cpf[i] != '.':
                crescent = False
        else:
            v = cpf[i]
            v = ord(v)

# Generated at 2022-06-21 15:24:16.832823
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    Brazil = BrazilSpecProvider()

# Generated at 2022-06-21 15:24:23.901522
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()

    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'

    cpf = bsp.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf[3] != '.'
    assert cpf[7] != '.'
    assert cpf[11] != '-'


# Generated at 2022-06-21 15:24:27.587547
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import re
    assert re.match("^(\d{3}\.\d{3}\.\d{3}\-\d{2})$", BrazilSpecProvider().cpf())

test_BrazilSpecProvider_cpf()


# Generated at 2022-06-21 15:24:38.211533
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    #Test with all masks

    provider = BrazilSpecProvider(seed=0)
    expected_with_mask_1 = '60.788.240/0001-29'
    expected_with_mask_2 = '60.788.240/0001-29'
    expected_with_mask_3 = '60.788.240/0001-29'
    expected_with_mask_4 = '60.788.240/0001-29'
    expected_with_mask_5 = '60.788.240/0001-29'
    expected_with_mask_6 = '60.788.240/0001-29'
    expected_with_mask_7 = '60.788.240/0001-29'
    expected_with_mask_8 = '60.788.240/0001-29'
    expected_with

# Generated at 2022-06-21 15:24:39.676488
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    print(b.cnpj(with_mask=True))


# Generated at 2022-06-21 15:24:42.142510
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider()
    assert len(obj.cnpj(with_mask=True)) == 18
    assert len(obj.cnpj(with_mask=False)) == 14


# Generated at 2022-06-21 15:24:43.136792
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert(BrazilSpecProvider() != None)


# Generated at 2022-06-21 15:24:44.523976
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    print(brazil.cpf())
    print(brazil.cnpj())

# Generated at 2022-06-21 15:24:48.531331
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Verifies if the method cpf of class BrazilSpecProvider works well.
    """
    brazil = BrazilSpecProvider()
    assert brazil.cpf() == '447.927.912-60', 'Error in BrazilSpecProvider.cpf'
    assert isinstance(brazil.cpf(), str)
    assert len(brazil.cpf()) == 14
    assert brazil.cpf(with_mask=False) == '44792791260'



# Generated at 2022-06-21 15:25:48.078093
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert len(provider.cnpj()) == 18
    assert len(provider.cnpj(False)) == 14
    assert provider.cnpj().replace('.', '').replace('/', '').replace('-', '').isdigit()
    assert provider.cnpj(False).isdigit()



# Generated at 2022-06-21 15:25:51.470677
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test creation of class BrazilSpecProvider.

    :returns: Nothing
    :rtype: None
    """
    brazil = BrazilSpecProvider()
    assert (len(brazil.cpf()) == 14) == True
    assert (len(brazil.cnpj()) == 18) == True

# Generated at 2022-06-21 15:25:52.672888
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    i = BrazilSpecProvider()
    test_cnpj = i.cnpj()
    assert len(test_cnpj) == 14

# Generated at 2022-06-21 15:25:57.784859
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    cnpj_with_mask = brazil.cnpj(with_mask=True)

    print(cnpj + '\n' + cnpj_with_mask)
    assert len(cnpj) == 14
    assert len(cnpj_with_mask) == 18


# Generated at 2022-06-21 15:26:03.178400
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the function `cpf` of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cpf_format = re.compile('^\d{3}\.\d{3}\.\d{3}-\d{2}$')
    cpf = provider.cpf()
    assert cpf_format.match(cpf) is not None


# Generated at 2022-06-21 15:26:06.075358
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import Generic
    g = Generic('pt-br')
    for i in range(50):
        cpf = g.brazil_provider.cpf()
        assert isinstance(cpf, str)
        assert len(cpf) == 14


# Generated at 2022-06-21 15:26:08.244803
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider(seed=1).cpf() == '088.624.173-05'
    assert BrazilSpecProvider(seed=2).cpf() == '159.160.881-59'



# Generated at 2022-06-21 15:26:11.758895
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=0)

    cpf = provider.cpf(with_mask=False)
    assert cpf == '15710990793'
    assert len(cpf) == 11


# Generated at 2022-06-21 15:26:13.920933
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    Test method cpf
    :return: 'Test Passed'
    """
    print(BrazilSpecProvider().cpf())
    return 'Test Passed'



# Generated at 2022-06-21 15:26:18.189773
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for BrazilSpecProvider class."""
    obj = BrazilSpecProvider()
    assert obj.cpf() != obj.cpf()
    assert obj.cnpj() != obj.cnpj()

# Generated at 2022-06-21 15:28:43.668273
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()
    cpf = br.cpf()
    cnpj = br.cnpj()

    print(cpf)
    print(cnpj)

# test_BrazilSpecProvider()

# Generated at 2022-06-21 15:28:45.556443
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '28.971.848/0001-58'


# Generated at 2022-06-21 15:28:54.990816
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    mimesis.seed(0)
    brazil_provider = mimesis.Brazil()
    assert brazil_provider.cpf(True) == '083.108.564-02'
    assert brazil_provider.cpf(True) == '914.718.514-33'
    assert brazil_provider.cpf(True) == '734.924.974-83'
    assert brazil_provider.cnpj(True) == '92.156.738/0001-70'
    assert brazil_provider.cnpj(True) == '76.247.674/0001-39'
    assert brazil_provider.cnpj(True) == '37.658.072/0001-55'

# Generated at 2022-06-21 15:28:58.487384
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    cnpj = brazil_spec_provider.cnpj(with_mask=True)
    assert cnpj is not None and len(cnpj)==18
    print(cnpj)

# Generated at 2022-06-21 15:29:00.381862
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)
    assert provider.cpf(with_mask=False)
    assert provider.cnpj(with_mask=False)

# Generated at 2022-06-21 15:29:01.032020
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()

# Generated at 2022-06-21 15:29:01.681629
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    _ = BrazilSpecProvider()

# Generated at 2022-06-21 15:29:02.336838
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider() is not None

# Generated at 2022-06-21 15:29:03.776205
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """This function tests the constructor of BrazilSpecProvider class."""

    spec = BrazilSpecProvider()
    assert spec.cpf(False)
    assert spec.cnpj(False)

# Generated at 2022-06-21 15:29:06.141232
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider.Meta.name == 'brazil_provider'
