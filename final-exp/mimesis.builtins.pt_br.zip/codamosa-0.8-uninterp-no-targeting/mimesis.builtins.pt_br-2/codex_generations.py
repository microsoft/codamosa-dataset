

# Generated at 2022-06-21 15:22:10.507131
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
 #   generator = BrazilSpecProvider()
 #   for _ in range(0, 100):
 #       cnpj = generator.cnpj()
 #       assert len(cnpj) == 18
 #       assert cnpj[2] == '.'
 #       assert cnpj[6] == '.'
 #       assert cnpj[10] == '/'
 #       assert cnpj[15] == '-'

    generator = BrazilSpecProvider()
    for _ in range(0, 100):
        cnpj = generator.cnpj(with_mask=False)
        assert len(cnpj) == 14
        assert cnpj[2] != '.'
        assert cnpj[6] != '.'
        assert cnpj[10] != '/'
        assert cnpj[15] != '-'


# Generated at 2022-06-21 15:22:12.073432
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print(provider)

# Generated at 2022-06-21 15:22:14.524501
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsf = BrazilSpecProvider()
    cnpj = bsf.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:22:16.409680
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == BrazilSpecProvider().cpf()



# Generated at 2022-06-21 15:22:19.222268
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert len(b.cpf(True)) == 14
    assert len(b.cpf(False)) == 11


# Generated at 2022-06-21 15:22:25.162164
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == "77.732.230/0001-70"
    assert provider.cpf() == "001.137.297-40"
    assert provider.cnpj(with_mask=False) == "77732230000170"
    assert provider.cpf(with_mask=False) == "00113729740"

# Generated at 2022-06-21 15:22:31.462733
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bw =  BrazilSpecProvider()
    assert bw.cpf() == '936.291.458-90'
    assert bw.cpf() == '192.349.103-37'
    assert bw.cpf() == '078.832.600-76'
    assert bw.cpf() == '223.801.938-12'
    assert bw.cpf() == '653.785.049-04'
    assert bw.cpf() == '042.669.207-47'


# Generated at 2022-06-21 15:22:35.833905
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    cnpj = provider.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-21 15:22:38.291220
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '77.732.230/0001-70'



# Generated at 2022-06-21 15:22:42.805074
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-21 15:22:52.239184
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.__class__ == BrazilSpecProvider


# Generated at 2022-06-21 15:22:55.261884
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    result = BrazilSpecProvider().cnpj()
    result2 = BrazilSpecProvider().cnpj()

    assert result != result2
    assert len(result) == 18
    assert len(result2) == 18


# Generated at 2022-06-21 15:22:58.291119
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis import BrazilSpecProvider
    from mimesis.providers.base import BaseProvider

    provider = BrazilSpecProvider(seed=42)
    assert isinstance(provider, BaseProvider)


# Generated at 2022-06-21 15:23:05.978902
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    prov = BrazilSpecProvider(seed=11)
    cpf = prov.cpf(with_mask=False)
    name = prov.full_name(gender = Gender.MALE)
    print('Resultado: ' + name)
    print('CPF: ' + cpf[:3] + '.' + cpf[3:6] + '.' + cpf[6:9] + '-' + cpf[9:])

# Generated at 2022-06-21 15:23:08.189865
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-21 15:23:10.922240
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method for BrazilSpecProvider."""
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cnpj() == '12.097.869/0001-70'

# Generated at 2022-06-21 15:23:12.557821
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider(seed=12345)
    assert bsp != None


# Generated at 2022-06-21 15:23:16.040396
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    try:
        provider = BrazilSpecProvider()
        assert provider.cpf()
        assert provider.cnpj()
    except:
        print("Error in BrazilSpecProvider")
        


# Generated at 2022-06-21 15:23:21.588063
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('Test Brazil Spec Provider')
    bsp = BrazilSpecProvider(seed=123)
    print('CPF: {}'.format(bsp.cpf()))
    print('CNPJ: {}'.format(bsp.cnpj()))

# Unit tests
if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:23:23.663843
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    brazil = BrazilSpecProvider()
    print(brazil.cnpj())
    print(brazil.cpf())

# Generated at 2022-06-21 15:23:38.690671
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of BrazilSpecProvider"""
    BrazilSpecProvider.create()

# Generated at 2022-06-21 15:23:47.564673
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import re
    b = BrazilSpecProvider()
    for _ in range(1000):
        cnpj = b.cnpj()
        assert isinstance(cnpj, str)
        assert re.match('^[0-9]{14}$', cnpj) is not None

    cnpj = b.cnpj(True)
    assert isinstance(cnpj, str)
    assert re.match('^[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}$', cnpj) is not None

# Generated at 2022-06-21 15:23:55.452500
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    obj = BrazilSpecProvider()

# Generated at 2022-06-21 15:23:57.817192
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider"""
    data = BrazilSpecProvider().cpf()
    assert data == "59373417032"


# Generated at 2022-06-21 15:24:00.030693
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Tests method cnpj."""
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:24:02.419254
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp is not None
    bsp = BrazilSpecProvider(seed=1)
    assert bsp is not None

# Unit tests for methods of class BrazilSpecProvider

# Generated at 2022-06-21 15:24:06.074845
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider(seed=3)
    assert bsp.cpf() == '052.191.557-85'
    assert bsp.cpf(with_mask=False) == '05219155785'


# Generated at 2022-06-21 15:24:09.411023
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    x = br.cpf()
    assert x == "504.733.988-76"


# Generated at 2022-06-21 15:24:12.426015
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(with_mask=False) == '7773223000170'
    assert BrazilSpecProvider().cnpj(with_mask=True) == '77.732.230/0001-70'

# Generated at 2022-06-21 15:24:14.864788
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    print(cnpj)
    if len(cnpj) != 18:
        raise Exception("CNPJ length not valid")

# Generated at 2022-06-21 15:24:44.488588
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj."""
    bsp = BrazilSpecProvider(seed=42)
    assert bsp.cnpj() == '00.813.049/0001-26'

# Generated at 2022-06-21 15:24:49.462491
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    n = 10
    if n > 0:
        brazil_spec_provider = BrazilSpecProvider()
        cpf_list = []
        for i in range(0, n):
            cpf = brazil_spec_provider.cpf()
            cpf = cpf.replace('.', '')
            cpf = cpf.replace('-', '')
            cpf_list.append(cpf)
        cpf_set = set(cpf_list)
        # verifica se mais de um cpf è igual
        assert len(cpf_set) == len(cpf_list)


# Generated at 2022-06-21 15:24:52.066122
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected_cpf = "012.345.678-90"
    assert BrazilSpecProvider().cpf() == expected_cpf


# Generated at 2022-06-21 15:24:52.957126
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider())

# Generated at 2022-06-21 15:24:57.259101
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Teste cnpj method"""
    br = BrazilSpecProvider()
    cnpj = br.cnpj()
    assert len(cnpj) == 18
    cnpj = br.cnpj(with_mask=False)
    assert len(cnpj) == 14

# Generated at 2022-06-21 15:25:03.168194
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import random

    for _ in range(1000):
        # get random CPF
        cpf = BrazilSpecProvider(seed=random.randint(0, 1000)).cpf()
        assert len(cpf) == 14
        assert '/' not in cpf
        assert '-' not in cpf
        assert '.' in cpf

if __name__ == "__main__":
    print(BrazilSpecProvider().cnpj())
    print(BrazilSpecProvider().cpf())

# Generated at 2022-06-21 15:25:05.346055
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = BrazilSpecProvider().cpf()
    print(result)
    assert result is not None


# Generated at 2022-06-21 15:25:07.304724
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    b = BrazilSpecProvider()
    for _ in range(10):
        print(b.cpf(), b.cnpj())

# Generated at 2022-06-21 15:25:12.092170
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    # Test case 1: cnpj with mask
    random_cnpj = BrazilSpecProvider().cnpj()
    cnpj_mask = BrazilSpecProvider().cnpj(with_mask=True)

    assert random_cnpj == cnpj_mask.replace('.', '').replace('/', '').replace('-', '')

    # Test case 2: cnpj without mask
    random_cnpj = BrazilSpecProvider().cnpj(with_mask=False)
    cnpj_mask = BrazilSpecProvider().cnpj()

    assert random_cnpj == cnpj_mask.replace('.', '').replace('/', '').replace('-', '')

# Generated at 2022-06-21 15:25:22.121172
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    def is_valid_cpf(cpf):
        if (len(cpf) != 11):
            return False

        if (cpf == '00000000000') or (cpf == '11111111111') or \
           (cpf == '22222222222') or (cpf == '33333333333') or \
           (cpf == '44444444444') or (cpf == '55555555555') or \
           (cpf == '66666666666') or (cpf == '77777777777') or \
           (cpf == '88888888888') or (cpf == '99999999999'):
           return False

        num = [int(x) for x in cpf]

# Generated at 2022-06-21 15:26:34.154444
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Verify if the method BrazilSpecProvider.cpf is working properly."""
    assert BrazilSpecProvider().cpf() == '896.844.678-34'



# Generated at 2022-06-21 15:26:43.706849
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    from mimesis.enums import Gender

    prov = BrazilSpecProvider()
    assert prov.cpf() == prov.cpf(with_mask=True)
    assert prov.cpf(with_mask=False) == '00113729193'
    assert prov.cpf(with_mask=True) == '001.137.291-93'
    assert prov.cpf(with_mask=False) in ('37184183210', '37184183204', '37184183202')
    assert prov.cpf(with_mask=True) in ('371.841.832-10', '371.841.832-04', '371.841.832-02')

    prov.seed(12345)

# Generated at 2022-06-21 15:26:50.186413
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()

    # unit test for method cpf with_mask == True
    cpf = bsp.cpf(with_mask=True)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[0:10].isdigit()
    assert cpf[12:14].isdigit()


# Generated at 2022-06-21 15:26:57.697236
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    my_cnpj = provider.cnpj(with_mask=True)
    if len(my_cnpj) != 18:
        raise Exception("Error - test_BrazilSpecProvider_cnpj()")
    if my_cnpj[2] != my_cnpj[6] or my_cnpj[3] != my_cnpj[7] or my_cnpj[4] != my_cnpj[8]:
        raise Exception("Error - test_BrazilSpecProvider_cnpj()")
    if my_cnpj[5] != my_cnpj[9]:
        raise Exception("Error - test_BrazilSpecProvider_cnpj()")

# Generated at 2022-06-21 15:27:01.588450
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert hasattr(obj, 'cpf')
    assert hasattr(obj, 'cnpj')
    assert hasattr(obj, 'Meta')
    assert hasattr(obj, 'seed')

# Unit tests for BrazilSpecProvider

# Generated at 2022-06-21 15:27:05.245272
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider.cnpj()) == 18
    assert type(BrazilSpecProvider.cnpj()) is str
test_BrazilSpecProvider_cnpj()


# Generated at 2022-06-21 15:27:09.966570
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    cpf = brazilSpecProvider.cpf()

    assert(len(cpf) == 14)
    assert(cpf[3] == '.')
    assert(cpf[7] == '.')
    assert(cpf[11] == '-')



# Generated at 2022-06-21 15:27:14.716956
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for seed in range(1, 99):
        b = BrazilSpecProvider(seed)
        cpf = b.cpf()
        print("BrazilSpecProvider_cpf({}): {}".format(seed, cpf))
        assert (len(cpf) == 14) and (cpf[3] == '.') and (cpf[7] == '.') and (cpf[11] == '-') and (cpf[12:].isdigit())
        cpf = b.cpf(with_mask=False)
        print("BrazilSpecProvider_cpf({}): {}".format(seed, cpf))
        assert (len(cpf) == 11) and (cpf.isdigit())


# Generated at 2022-06-21 15:27:17.127483
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert isinstance(brazil_spec_provider, BrazilSpecProvider)



# Generated at 2022-06-21 15:27:24.555966
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    bsp = BrazilSpecProvider()

    result = bsp.cpf(with_mask=True)
    assert result is not None and len(result) == 14
    assert result.count('.') == 2 and result.count('-') == 1

    result = bsp.cpf(with_mask=False)
    assert result is not None and len(result) == 11
    assert result.count('.') == 0 and result.count('-') == 0


# Generated at 2022-06-21 15:29:59.845922
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    for i in range(10):
        cpf = b.cpf()
        assert len(cpf) == 14
        assert cpf[3] == '.'
        assert cpf[7] == '.'
        assert cpf[11] == '-'
        assert cpf[3:7] != '000'
        assert cpf[7:11] != '000'
        assert cpf[11:] != '00'


# Generated at 2022-06-21 15:30:02.792215
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert bsp.cnpj(with_mask=False) == '7773223000170'
    assert bsp.cnpj() == '77.732.230/0001-70'



# Generated at 2022-06-21 15:30:09.391975
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_cnpj = set()

    assert len(brazil_cnpj) < 10000
    assert 0 < len(brazil_cnpj) < 10000

    # Old method
    while True:
        c = BrazilSpecProvider(seed=12345)
        cnpj = c.cnpj(with_mask=False)
        brazil_cnpj.add(cnpj)

        if len(brazil_cnpj) > 10000:
            break

    assert len(brazil_cnpj) == 10000
    assert '97625625000175' in brazil_cnpj
    assert c.cnpj(with_mask=False) == '97625625000175'
    assert c.cnpj(with_mask=True) == '97.625.625/0001-75'

   

# Generated at 2022-06-21 15:30:12.558683
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method BrazilSpecProvider.cpf"""
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert provider.cpf(False) == provider.cpf(False)

# Generated at 2022-06-21 15:30:17.625072
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    list_of_cpfs = []
    for i in range(100):
        list_of_cpfs.append(provider.cpf())
    # We expect that all CPFs in the list are different
    if len(list_of_cpfs) != len(set(list_of_cpfs)):
        raise Exception("CPF generated twice")


# Generated at 2022-06-21 15:30:22.495866
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    assert hasattr(b, '_data')
    assert hasattr(b, '_seed')
    assert hasattr(b, '_random')
    assert hasattr(b, '_locale')
    assert hasattr(b, '_LOCALE')
    assert hasattr(b, 'Meta')
    assert hasattr(b, 'cpf')
    assert hasattr(b, 'cnpj')



# Generated at 2022-06-21 15:30:25.309004
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    cnpj = provider.cnpj()
    assert len(cpf) == 14
    assert len(cnpj) == 18
    assert provider.cpf(False) == cpf
    assert provider.cnpj(False) == cnpj

# Generated at 2022-06-21 15:30:33.135502
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test using the default value for parameter with_mask
    assert len(BrazilSpecProvider().cpf()) == 11
    assert len(BrazilSpecProvider().cpf(with_mask=False)) == 11

    # Test using the other allowed values for parameter with_mask
    assert len(BrazilSpecProvider().cpf(with_mask=True)) == 14
    assert len(BrazilSpecProvider().cpf(with_mask=False)) == 11



# Generated at 2022-06-21 15:30:38.924767
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method BrazilSpecProvider.cnpj."""
    fields = {
        'cnpj1': BrazilSpecProvider.cnpj(),
        'cnpj2': BrazilSpecProvider.cnpj(),
        'cnpj3': BrazilSpecProvider.cnpj(),
        'cnpj4': BrazilSpecProvider.cnpj(False),
        'cnpj5': BrazilSpecProvider.cnpj(False)
    }
    # Test if the length of a CNPJ with mask is 18
    for cnpj in [fields['cnpj1'], fields['cnpj2'], fields['cnpj3']]:
        assert len(cnpj) == 18

    # Test if the length of a CNPJ without mask is 14

# Generated at 2022-06-21 15:30:42.969467
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert len(BrazilSpecProvider().cnpj(with_mask=False)) == 14
