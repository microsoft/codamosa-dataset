

# Generated at 2022-06-21 15:22:02.283678
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Test if BrazilSpecProvider creates an instance of BrazilSpecProvider
    BrazilSpecProvider(seed=42)

# Generated at 2022-06-21 15:22:10.677067
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Given
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.providers.internet import Internet
    import re

    def validar_cpf(cpf):
        if len(cpf) != 11:
            return False
        # Elimina os caracteres especias
        cpf = re.sub('[^0-9]', '', cpf)
        if len(cpf) != 11:
            return False
        # Elimina CPFs invalidos conhecidos

# Generated at 2022-06-21 15:22:12.119504
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    print(cpf)
    assert len(cpf) == 14


# Generated at 2022-06-21 15:22:18.043301
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.providers.locale.pt_BR.addresses import BrazilSpecProvider
    brsp = BrazilSpecProvider()
    nome = brsp.name()
    nome2 = 'José'
    cpf = brsp.cpf(False)
    cnpj = brsp.cnpj(False)
    assert nome == nome2

# Generated at 2022-06-21 15:22:20.340105
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for _ in range(100):
        cnpj = BrazilSpecProvider().cnpj()
        assert len(cnpj) == 18

# Generated at 2022-06-21 15:22:24.632558
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()

    assert provider.cnpj() == '31.247.710/0001-10'

    assert provider.cnpj(True) == '31.247.710/0001-10'


# Generated at 2022-06-21 15:22:31.145681
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # initialise class
    test = BrazilSpecProvider()

    # generate cpf
    cpf = test.cpf()  # variable to keep the generated cpf

    # verify cpf structure
    assert len(cpf) == 14  # verify length of cpf

    assert cpf[3] == '.'  # verify position of dot after 3 characters
    assert cpf[7] == '.'  # verify position of dot after 7 characters
    assert cpf[11] == '-'  # verify position of dash after 11 characters


# Generated at 2022-06-21 15:22:33.193925
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil != None

# Generated at 2022-06-21 15:22:36.482540
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    # Default Usage
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == "."
    assert cpf[7] == "."
    assert cpf[11] == "-"

    # Testing without mask
    assert len(provider.cpf(False)) == 11
    assert provider.cpf(False)[0] == "0"
    assert provider.cpf(False)[1] == "0"



# Generated at 2022-06-21 15:22:43.460294
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("\nUnit test for method cpf of class BrazilSpecProvider.")
    b = BrazilSpecProvider()
    cpf1 = b.cpf()
    cpf2 = b.cpf(with_mask = False)
    print("Random CPF: {}. Length: {}.".format(cpf1, len(cpf1)))
    print("Random CPF: {}. Length: {}.".format(cpf2, len(cpf2)))
    assert len(cpf1) == 14
    assert len(cpf2) == 11
    return


# Generated at 2022-06-21 15:22:52.240256
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() is not None


# Generated at 2022-06-21 15:22:54.093126
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for cnpj method of BrazilSpecProvider class."""
    bp = BrazilSpecProvider()
    cnpj = bp.cnpj()
    assert len(cnpj) == 18

# Generated at 2022-06-21 15:22:56.035392
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider is not None


# Generated at 2022-06-21 15:22:58.194915
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    for _ in range(10):
        print(p.cnpj())


# Generated at 2022-06-21 15:22:59.274299
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-21 15:23:01.618985
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    provider = BrazilSpecProvider()
    assert len(provider.cnpj()) == 18

# Generated at 2022-06-21 15:23:02.640557
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) == 18

# Generated at 2022-06-21 15:23:06.876638
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bp = BrazilSpecProvider()

    assert int(bp.cpf(with_mask=False)[9:]) == int(bp.cpf(with_mask=False)[-2:])

    assert len(bp.cpf(with_mask=False)) == 11


# Generated at 2022-06-21 15:23:13.055601
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj(with_mask = False)
    cnpj = cnpj.replace(".", "").replace("-", "").replace("/", "")
    assert cnpj.isdigit() == True, "CNPJ deve ser composto por digitos numericos!"
    assert len(cnpj) == 14, "CNPJ tem 14 digitos!"
    print("Teste do metodo cnpj da classe BrazilSpecProvider: PASS")



# Generated at 2022-06-21 15:23:16.635812
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf(False) == '65005621604'
    assert provider.cpf() == '650.056.216-04'


# Generated at 2022-06-21 15:23:36.506553
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=42)
    cpf = provider.cpf()
    assert cpf == '561.771.552-93'
    cnpj = provider.cnpj()
    assert cnpj == '14.311.326/0001-78'
    assert provider.cpf(with_mask = False) == '56177155293'
    assert provider.cnpj(with_mask = False) == '14311326000178'


# Generated at 2022-06-21 15:23:43.810138
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the correct instantiation of the BrazilSpecProvider class."""
    from mimesis.enums import Gender
    from mimesis.tools import resolve_spec
    from mimesis.builtins import BrazilSpecProvider
    spec_provider = resolve_spec('pt-br')
    p1 = BrazilSpecProvider()
    p2 = spec_provider()
    assert p1.cpf() == p2.cpf()
    assert p1.cnpj() == p2.cnpj()

# Generated at 2022-06-21 15:23:46.861945
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert isinstance(brazil.cpf(with_mask = True), str)
    assert isinstance(brazil.cnpj(with_mask = True), str)

# Generated at 2022-06-21 15:23:48.884857
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    print(brazil.cpf())
    print(brazil.cpf(with_mask=False))

# Generated at 2022-06-21 15:23:50.617567
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    class_ = BrazilSpecProvider()
    assert class_.cpf() != None
    assert class_.cnpj() != None

# Generated at 2022-06-21 15:23:57.394565
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Instance of BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()
    # test for method cnpj
    cnpj = brazil_spec_provider.cnpj()
    assert cnpj is not None, 'CNPJ is None!'
    assert len(cnpj) == 18, 'CNPJ len is not equal 18!'
    assert '.' in cnpj, 'No mask!'
    assert '/' in cnpj, 'No mask!'
    assert '-' in cnpj, 'No mask!'
    cnpj_without_mask = brazil_spec_provider.cnpj(with_mask=False)
    assert cnpj_without_mask is not None, 'CNPJ is None!'

# Generated at 2022-06-21 15:24:03.040289
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.locales import Brazil
    from mimesis.providers.base import BaseSpecProvider
    
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf()
    cnpj = brazil_provider.cnpj()
    assert isinstance(cpf, str)
    assert isinstance(cnpj, str)
    assert len(cpf) == 14
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:24:08.476265
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    from mimesis.providers.brazil import BrazilSpecProvider
    assert len(BrazilSpecProvider().cpf()) == 14
    assert BrazilSpecProvider().cpf()[3] == '.'
    assert BrazilSpecProvider().cpf()[7] == '.'
    assert BrazilSpecProvider().cpf()[11] == '-'
    assert BrazilSpecProvider().cpf(with_mask=False) == BrazilSpecProvider().cpf(with_mask=False)

    BrazilSpecProvider(seed=1).cpf() == '302.049.814-61'
    BrazilSpecProvider(seed=2).cpf() == '048.631.273-39'
    BrazilSpecProvider(seed=3).cpf() == '449.835.869-95'
   

# Generated at 2022-06-21 15:24:11.159268
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=123456)
    assert provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-21 15:24:13.720300
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    s = BrazilSpecProvider()
    s.cnpj()
    s.cpf()
    s.cpf(with_mask = False)
    s.cnpj(with_mask = False)

# Generated at 2022-06-21 15:24:44.238592
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    data = [p.cnpj() for _ in range(1000)]
    cnpj = data[0]
    assert cnpj in data

# Generated at 2022-06-21 15:24:48.281352
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf1 = bsp.cpf(with_mask = True)
    cpf2 = bsp.cpf(with_mask = True)
    cpf3 = bsp.cpf(with_mask = True)
    cpf4 = bsp.cpf(with_mask = True)
    print(cpf1)
    print(cpf2)
    print(cpf3)
    print(cpf4)



# Generated at 2022-06-21 15:24:59.577931
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider

# Generated at 2022-06-21 15:25:08.301096
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.builtins import BrazilSpecProvider

    br = BrazilSpecProvider(seed=1)

    # First run
    cpf1 = br.cpf()
    assert cpf1 == '154.611.936-58'
    assert type(cpf1) == str

    # Second run
    cpf2 = br.cpf()
    assert cpf2 == '154.611.936-58'
    assert type(cpf2) == str

    # Third run
    br.reset_seed()
    cpf = br.cpf()
    assert cpf == '154.611.936-58'
    assert type(cpf) == str


# Generated at 2022-06-21 15:25:12.171352
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    '''
    test_BrazilSpecProvider()

    test method for BrazilSpecProvider()
    '''

    brazil = BrazilSpecProvider()
    brazil.cpf()

# Generated at 2022-06-21 15:25:16.299382
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() != '77.732.230/0001-70'  # The cnpj should be random, not fixed
    assert BrazilSpecProvider().cnpj(with_mask=False) != '77732'  # The cnpj should be random, not fixed



# Generated at 2022-06-21 15:25:19.963618
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    seed = Seed(int(1))
    provider = BrazilSpecProvider(seed)

    assert provider.cnpj() == "77.732.230/0001-70"


# Generated at 2022-06-21 15:25:23.055814
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-21 15:25:24.275585
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider(seed=666)
    assert provider.seed == 666

# Generated at 2022-06-21 15:25:24.824788
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:26:41.404521
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == bsp.cnpj(True)
    assert bsp.cnpj(with_mask=False) is not None
    assert bsp.cnpj(with_mask=True) is not None


# Generated at 2022-06-21 15:26:46.972185
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cpf() == '001.137.297-40'
    assert brazil_spec_provider.cpf(with_mask=False) == '00113729740'
    assert brazil_spec_provider.cnpj() == '77.732.230/0001-70'
    assert brazil_spec_provider.cnpj(with_mask=False) == '77732240000170'

test_BrazilSpecProvider()

# Generated at 2022-06-21 15:26:54.919411
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Arrange
    # (Nothing to do)

    # Act
    class_instance = BrazilSpecProvider()
    cnpj = class_instance.cnpj(with_mask=False)

    # Assert
    assert len(cnpj) == 14, 'The CNPJ returned has less than 14 characters.'
    assert cnpj.isdigit(), 'The CNPJ returned is not a number.'

# Generated at 2022-06-21 15:26:56.575265
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    random_provider = BrazilSpecProvider()
    assert random_provider.cnpj(True) == '55.227.248/0001-80'

# Generated at 2022-06-21 15:26:59.589207
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    instance = BrazilSpecProvider()
    cnpj = instance.cnpj()
    assert len(cnpj) == 18
    assert isinstance(cnpj, str)

# Generated at 2022-06-21 15:27:01.466859
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    #!TODO
    pass


# Generated at 2022-06-21 15:27:06.269878
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()

    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-21 15:27:12.046917
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf)==14
    assert cpf[3]=='.' and cpf[7]=='.' and cpf[11]=='-'
    cpf = brazil.cpf(with_mask=False)
    assert len(cpf)==11
    cpf = brazil.cpf()
    assert len(cpf)==14


# Generated at 2022-06-21 15:27:22.121221
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Main function for BrazilSpecProvider.cpf method."""
    provider = BrazilSpecProvider()
    cpf = provider.cpf(False)
    assert int(cpf[:3]) >= 0 and int(cpf[:3]) < 1000
    assert int(cpf[3:6]) >= 0 and int(cpf[3:6]) < 1000
    assert int(cpf[6:9]) >= 0 and int(cpf[6:9]) < 1000
    assert int(cpf[:9]) >= 0 and int(cpf[:9]) < 1000000000
    assert int(cpf[9:11]) >= 0 and int(cpf[9:11]) < 100

# Generated at 2022-06-21 15:27:23.360878
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-21 15:30:00.058915
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    BSP = BrazilSpecProvider()
    b = BSP.cnpj()
    print(b)
    assert len(b) == 18


# Generated at 2022-06-21 15:30:07.704355
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    cpfs = [
        '928.617.838-22',
        '412.216.720-87',
        '972.877.744-28',
        '878.725.700-62',
        '076.771.826-18',
        '928.790.821-87',
        '456.984.698-22',
        '094.322.646-88',
        '879.827.962-66'
    ]
    test_cpfs = []
    provider = BrazilSpecProvider()
    for i in range(1, 10):
        test_cpfs.append(provider.cpf())
    for test_cpf in test_cpfs:
        assert test_cpf in cp

# Generated at 2022-06-21 15:30:09.709024
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf() == "774.607.258-70"


# Generated at 2022-06-21 15:30:16.514633
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == BrazilSpecProvider().cpf(False)
    assert len(BrazilSpecProvider().cpf()) == 14
    assert len(BrazilSpecProvider().cpf(False)) == 11
    assert BrazilSpecProvider().cpf(False).isdigit() == True

    cpf = BrazilSpecProvider().cpf(False)
    aux = cpf[:3] + '.' + cpf[3:6] + '.' + cpf[6:9] + '-' + cpf[9:]
    assert aux == BrazilSpecProvider().cpf()

# Generated at 2022-06-21 15:30:18.035961
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brasil = BrazilSpecProvider()
    cpf = brasil.cpf()
    return cpf


# Generated at 2022-06-21 15:30:19.468995
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert b.cpf() == "001.137.297-40"


# Generated at 2022-06-21 15:30:20.594436
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    b = BrazilSpecProvider()
    assert isinstance(b, BrazilSpecProvider)

# Generated at 2022-06-21 15:30:22.356433
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    #print("cpf = ",provider.cpf())


# Generated at 2022-06-21 15:30:23.088470
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()


# Generated at 2022-06-21 15:30:24.030583
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert isinstance(cpf, str)