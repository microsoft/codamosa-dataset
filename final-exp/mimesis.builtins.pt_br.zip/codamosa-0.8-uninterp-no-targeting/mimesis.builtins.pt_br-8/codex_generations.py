

# Generated at 2022-06-21 15:22:02.831377
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    c = BrazilSpecProvider()
    assert c.cnpj() , c.cpf()


# Generated at 2022-06-21 15:22:06.964622
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    res = bsp.cnpj(with_mask=False)
    res1 = bsp.cnpj(with_mask=True)
    print(res)
    print(res1)

if __name__ == '__main__':
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-21 15:22:10.210032
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    value = provider.cnpj(with_mask = True)

    assert len(value) == 18
    assert value[2] == '.'
    assert value[6] == '.'
    assert value[10] == '/'
    assert value[15] == '-'


# Generated at 2022-06-21 15:22:15.913944
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test to validate cpf."""
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(True)
    assert cpf is not None
    assert cpf.count(".") == 2
    assert cpf.count("-") == 1
    assert len(cpf) == 14


# Generated at 2022-06-21 15:22:18.850215
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert(len(cpf) == 14)
    assert isinstance(cpf,str)



# Generated at 2022-06-21 15:22:23.331234
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    cpf_without_mask = bsp.cpf(with_mask=False)
    assert len(cpf_without_mask) == 11


# Generated at 2022-06-21 15:22:27.198066
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf1 = provider.cpf()
    cpf2 = provider.cpf(with_mask=False)
    assert len(cpf1) == 14
    assert len(cpf2) == 11


# Generated at 2022-06-21 15:22:30.556664
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert cpf
    assert len(cpf) == 14
    assert cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-'


# Generated at 2022-06-21 15:22:32.678987
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'


# Generated at 2022-06-21 15:22:39.380281
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Test constructor of class BrazilSpecProvider")
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis import Person
    person = Person('pt-br')
    gen = BrazilSpecProvider()
    gen.full_name(gender=Gender.MALE)
    print(gen.cpf())
    print(gen.cnpj())

# Generated at 2022-06-21 15:22:48.241298
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=1234)
    # Expect no errors


# Generated at 2022-06-21 15:22:52.369903
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import unittest
    # Arrange
    class TestCase(unittest.TestCase):
        def runTest(self):
            pass
    # Act
    test = TestCase()
    test.assertIsInstance(BrazilSpecProvider(seed='8'), BrazilSpecProvider)



# Generated at 2022-06-21 15:22:56.845693
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    brazil = BrazilSpecProvider()

    assert len(brazil.cnpj()) == 18
    assert brazil.cnpj() == '77.732.230/0001-70'
    print(brazil.cnpj())


# Generated at 2022-06-21 15:22:58.503474
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=12345)
    print(provider.cpf())


# Generated at 2022-06-21 15:23:10.015349
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.providers.person import Person
    from mimesis.builtins import datetime
    from mimesis.providers.credit_card import CreditCard
    from mimesis.providers.business import Business
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.providers.person import Person

    person = Person('pt-br')
    cpf_number = person.cpf()

    brazil_specprovider = BrazilSpecProvider()
    brazil_specprovider_cpf = brazil_specprovider.cpf()

    assert len(brazil_specprovider_cpf) >= 11
    assert brazil_specprovider_cpf != cpf_number

# Unit test

# Generated at 2022-06-21 15:23:12.766349
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert '142.066.957-46' == provider.cpf(with_mask=True)

test_BrazilSpecProvider_cpf()


# Generated at 2022-06-21 15:23:20.194702
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj."""
    brazil = BrazilSpecProvider()
    cnpj = strToIntList(brazil.cnpj(True))
    assert len(cnpj) == 14
    assert cnpj[:12].count(0) < 2
    assert cnpj[12] == brazil.cnpjGetVerifyingDigit(cnpj[:12], 5)
    assert cnpj[13] == brazil.cnpjGetVerifyingDigit(cnpj[:13], 6)

    cnpj = strToIntList(brazil.cnpj(False))
    assert len(cnpj) == 14
    assert cnpj[:12].count(0) < 2

# Generated at 2022-06-21 15:23:22.073640
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf() == "012.235.884-86"


# Generated at 2022-06-21 15:23:27.514693
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test the definition method cpf of class BrazilSpecProvider."""
    from mimesis import BrazilSpecProvider
    
    p = BrazilSpecProvider()
    for _ in range(300):
        cpf = p.cpf()
        assert len(cpf) == 14
        assert cpf[3] == '.'
        assert cpf[7] == '.'
        assert cpf[11] == '-'


# Generated at 2022-06-21 15:23:29.352476
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    #print(brazil_provider.cpf())



# Generated at 2022-06-21 15:23:48.433508
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.' and cnpj[6] == '.' and cnpj[10] == '/' and cnpj[15] == '-'


# Generated at 2022-06-21 15:23:50.798631
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    # print(cpf)
    assert len(cpf) == 14


# Generated at 2022-06-21 15:23:53.710863
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """"""
    from mimesis.providers.citizen import Citizen
    ci = Citizen(seed=5)
    bsp = BrazilSpecProvider(seed=5)
    cnpj = ci.cnpj()
    assert bsp.cnpj() == cnpj

# Generated at 2022-06-21 15:23:57.288229
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = 1547842961

    provider = BrazilSpecProvider(seed)
    cnpj1 = provider.cnpj()
    cnpj2 = provider.cnpj()

    assert cnpj1 != cnpj2

# Generated at 2022-06-21 15:24:00.500261
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test a random CPF."""
    assert BrazilSpecProvider().cpf(with_mask=True) == '001.137.297-40'
    assert BrazilSpecProvider().cpf(with_mask=False) == '00113729740'



# Generated at 2022-06-21 15:24:01.343616
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-21 15:24:03.398635
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    ''' Test constructor of class BrazilSpecProvider '''
    brasil_spec_provider = BrazilSpecProvider()
    assert brasil_spec_provider is not None

# Generated at 2022-06-21 15:24:04.434976
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider().cnpj())
    print(BrazilSpecProvider().cpf())

# Generated at 2022-06-21 15:24:07.156995
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    print(provider.cnpj())
    assert len(provider.cnpj()) == 18

# Generated at 2022-06-21 15:24:14.390376
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '77.732.230/0001-70'
    bsp = BrazilSpecProvider(seed=54321)
    assert bsp.cnpj() == '42.491.024/0001-72'
    bsp = BrazilSpecProvider(seed=12345)
    assert bsp.cnpj() == '90.836.879/0001-30'
    assert bsp.cnpj(with_mask=False) == '90836879000130'

# Generated at 2022-06-21 15:24:54.883550
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider method."""
    def is_valid(cpf):
        """Verify whether a CPF is valid."""
        cpf = [int(i) for i in cpf]
        first_dv = cpf[9]
        second_dv = cpf[10]
        cpf.pop()
        cpf.pop()
        return cpf[-2] == get_verifying_digit_cpf(cpf, 9) and cpf[-1] == get_verifying_digit_cpf(cpf, 10)
    counter = 0

    for _ in range(1000):
        if is_valid(BrazilSpecProvider().cpf(False)):
            counter += 1

    assert counter == 1000


# Generated at 2022-06-21 15:24:57.670667
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Unit test for method cnpj of class BrazilSpecProvider
    assert len(BrazilSpecProvider().cnpj()) == 18
    assert len(BrazilSpecProvider().cnpj(False)) == 14


# Generated at 2022-06-21 15:25:04.554017
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    brazil = BrazilSpecProvider(seed=0)
    person = Person(seed=0)
    cpf = brazil.cpf(with_mask=False)
    name = person.full_name(gender=Gender.MALE)

    assert cpf == '00113729740'
    assert name == 'Jonathan B. Meeks'


# Generated at 2022-06-21 15:25:07.792286
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Verifies if the method 'cnpj' of class 'BrazilSpecProvider' is correct.
    """
    Brazilian = BrazilSpecProvider()

    assert Brazilian.cnpj() == '77.732.230/0001-70'

    assert Brazilian.cnpj(with_mask=False) == '77732230000170'

# Generated at 2022-06-21 15:25:10.448344
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print(cnpj)


# Generated at 2022-06-21 15:25:17.388603
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    cpf = "380.833.980-67"
    result = provider.cpf(False)
    assert result == cpf, "Espero retorno do cpf com somente numeros: %s" % result

    cpf = "380.833.980-67"
    result = provider.cpf()
    assert result == cpf, "Espero retorno do cpf no formato padrao: %s" % result


# Generated at 2022-06-21 15:25:27.640247
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    for _ in range(10):
        cpf = brazil.cpf()
        assert len(cpf) == 14
        # Check if string has 11 digits
        assert all([d.isdigit() for d in cpf.replace('.', '').replace('-', '')])
        # Check if string has 3 dots
        assert cpf.count('.') == 3
        # Check if string has 1 dash
        assert cpf.count('-') == 1
    cpf = brazil.cpf(with_mask=False)
    assert len(cpf) == 11
    # Check if string has 11 digits
    assert all([d.isdigit() for d in cpf.replace('.', '').replace('-', '')])
    # Check if string has 3 dots
    assert cpf

# Generated at 2022-06-21 15:25:32.475855
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of BrazilSpecProvider."""
    from mimesis.builtins import BrazilSpecProvider as bsp
    seed = 134
    bs = bsp(seed=seed)
    # check if is a BrazilSpecProvider
    print(isinstance(bs, bsp))
    # check if seed is the same
    print(bs.seed == seed)
    # check if seed is an int
    print(isinstance(bs.seed, int))


# Generated at 2022-06-21 15:25:34.049414
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert len(b.cnpj()) == 18


# Generated at 2022-06-21 15:25:43.954431
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    expected_types = {
        'cnpj_one': '23.734.306/0001-06',
        'cnpj_two': '23.734.306/0001-06',
        'cnpj_three': '23.734.306/0001-06',
    }
    data = {
        'cnpj_one': provider.cnpj(),
        'cnpj_two': provider.cnpj(with_mask=True),
        'cnpj_three': provider.cnpj(with_mask=False),
    }
    assert expected_types == data


# Generated at 2022-06-21 15:27:05.501226
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 14
    assert len(b.cpf(False)) == 11


# Generated at 2022-06-21 15:27:06.628623
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    BrazilSpecProvider().cnpj()
    BrazilSpecProvider().cpf()
    BrazilSpecProvider().cnpj()
    BrazilSpecProvider().cpf()

# Generated at 2022-06-21 15:27:08.844038
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    print('cpf: ' + b.cpf())


# Generated at 2022-06-21 15:27:10.330719
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert obj.cpf() != None
    assert obj.cnpj() != None

# Generated at 2022-06-21 15:27:12.279289
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print("Random CPF:", provider.cpf())
    print("Random CNPJ:", provider.cnpj())


# Generated at 2022-06-21 15:27:17.125077
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
	cnpj = BrazilSpecProvider()
	cnpj_test_1 = cnpj.cnpj()
	cnpj_test_2 = cnpj.cnpj()
	assert cnpj_test_1 != cnpj_test_2


# Generated at 2022-06-21 15:27:18.742545
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

    assert provider is not None


# Generated at 2022-06-21 15:27:26.458849
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import pytest
    from mimesis.providers.brazil_provider import BrazilSpecProvider

    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(with_mask=True)
    assert cpf.count('.') == 2 and cpf.count('-') == 1
    assert len(cpf) == 14

    cpf = brazil.cpf(with_mask=False)
    assert len(cpf) == 11

    with pytest.raises(TypeError):
        brazil.cpf(with_mask='invalid type')



# Generated at 2022-06-21 15:27:27.981353
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:27:32.551257
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BSP = BrazilSpecProvider()
    assert len(BSP.cnpj(with_mask=True)) == 18
    assert BSP.cnpj(with_mask=True)[2] == '.'
    assert BSP.cnpj(with_mask=True)[6] == '.'
    assert BSP.cnpj(with_mask=True)[10] == '/'
    assert BSP.cnpj(with_mask=True)[15] == '-'

    BSP = BrazilSpecProvider()
    assert len(BSP.cnpj(with_mask=False)) == 14


# Generated at 2022-06-21 15:30:15.418418
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print('\n' + '# Unit test for method cnpj of class BrazilSpecProvider')
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print('cnpj = ' + cnpj)
    assert len(cnpj) == 18



# Generated at 2022-06-21 15:30:16.299936
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Testing BrazilSpecProvider")


# Generated at 2022-06-21 15:30:17.810336
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
	brazil = BrazilSpecProvider()
	assert isinstance(brazil.cpf(False), str)


# Generated at 2022-06-21 15:30:25.526786
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for BrazilSpecProvider"""
    brazil = BrazilSpecProvider(seed=12345)
    assert brazil.cpf() == '945.186.115-68'
    assert brazil.cpf(True) == '945.186.115-68'
    assert brazil.cnpj() == '83.251.721/0001-50'
    assert brazil.cnpj(True) == '83.251.721/0001-50'

# Generated at 2022-06-21 15:30:26.688116
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test = BrazilSpecProvider()
    assert test is not None



# Generated at 2022-06-21 15:30:29.870476
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=42)
    result = provider.cpf()
    assert result == "365.867.925-67"

# Generated at 2022-06-21 15:30:37.902783
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    
    def test_BrazilSpecProvider_cpf_validity(cpf_num: str, cpf_num_int: list):
        assert len(cpf_num) == 14 and len(cpf_num_int) == 11
        assert cpf_num[-2:] == str(get_verifying_digit_cpf(cpf_num_int, 11))
    
    def get_verifying_digit_cpf(cpf_num_int: list, peso: int):
        soma = 0
        for index, digit in enumerate(cpf_num_int):
            soma += digit * (peso - index)
        resto = soma % 11
        if resto == 0 or resto == 1:
            return 0
        return 11 - resto
    
   

# Generated at 2022-06-21 15:30:47.051112
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        elif peso == 6:
            peso_list = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        for i, _ in enumerate(cnpj):
            soma += peso_

# Generated at 2022-06-21 15:30:50.571596
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    from datetime import datetime
    startTime = datetime.now()
    for i in range(10000):
        BrazilSpecProvider(seed=i).cnpj()
    print('10000 calls to cnpj() took ', datetime.now()-startTime, 'seconds to run')


# Generated at 2022-06-21 15:30:51.644807
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider(seed=123) != None
