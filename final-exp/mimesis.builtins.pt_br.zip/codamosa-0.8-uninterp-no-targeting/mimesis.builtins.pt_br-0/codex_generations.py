

# Generated at 2022-06-21 15:22:04.127769
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_BrazilSpecProvider = BrazilSpecProvider()
    assert test_BrazilSpecProvider != None

# Generated at 2022-06-21 15:22:07.123539
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf = brazil_provider.cpf(with_mask=False)
    assert len(cpf) == 11
    assert isinstance(cpf, str)


# Generated at 2022-06-21 15:22:09.006695
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf() is not None
    assert brazil.cnpj() is not None

# Generated at 2022-06-21 15:22:11.966013
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert result is not None

# Generated at 2022-06-21 15:22:14.424200
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
	provider = BrazilSpecProvider()
	cpf = provider.cpf()
	assert len(cpf) == 14


# Generated at 2022-06-21 15:22:16.863399
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '001.137.297-40'

# Generated at 2022-06-21 15:22:19.985732
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    print(b.cnpj())
    # The return result is correct
    assert b.cnpj() == '69.964.924/0001-90'



# Generated at 2022-06-21 15:22:21.291711
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-21 15:22:24.525352
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18
    assert cnpj == '77.732.230/0001-70'

# Generated at 2022-06-21 15:22:26.993969
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert obj is not None

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:22:36.579921
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    prov = BrazilSpecProvider()
    print("CNPJ: ", prov.cnpj())



# Generated at 2022-06-21 15:22:43.166012
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    cnpj_list = cnpj.split('.')
    cnpj_list_2 = cnpj_list[2].split('/')
    cnpj_list_3 = cnpj_list_2[1].split('-')
    print(cnpj)
    print(cnpj_list)
    print(cnpj_list_2)
    print(cnpj_list_3)

# Generated at 2022-06-21 15:22:44.934902
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    instance = BrazilSpecProvider("random_seed")
    assert len(instance.cpf()) == 14
    assert len(instance.cnpj()) == 18

# Generated at 2022-06-21 15:22:46.904189
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().provider_name == 'brazil_provider'


# Generated at 2022-06-21 15:22:47.544876
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:22:48.396109
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Create object
    assert BrazilSpecProvider()

# Generated at 2022-06-21 15:22:51.108243
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    brazilSpecProvider.cpf()
    brazilSpecProvider.cnpj()

# Generated at 2022-06-21 15:22:55.804654
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers import BrazilSpecProvider
    from mimesis.enums import Gender

    b = BrazilSpecProvider()

    bool = b.cnpj()

    assert len(bool) == 18
    assert bool[2] == '.'
    assert bool[6] == '.'
    assert bool[10] == '/'
    assert bool[15] == '-'


# Generated at 2022-06-21 15:22:57.628384
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

    assert provider.cpf() is not None
    assert provider.cnpj() is not None

# Generated at 2022-06-21 15:23:01.519004
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data = BrazilSpecProvider().cpf(with_mask=False)
    assert len(data) == 11
    data_mask = BrazilSpecProvider().cpf()
    assert len(data_mask) == 14


# Generated at 2022-06-21 15:23:21.258293
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    cnpj_number_only = provider.cnpj(with_mask=False)
    assert len(cnpj_number_only) == 14

# Generated at 2022-06-21 15:23:24.089414
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
  brazil_spec_provider = BrazilSpecProvider()
  assert len(brazil_spec_provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-21 15:23:26.911010
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test Brazilian cnpj."""
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    bsp.reset_seed()
    assert bsp.cnpj() == cnpj

# Generated at 2022-06-21 15:23:33.703139
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """ Check cnpj method of BrazilSpecProvider class. """
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert type(cnpj) is str
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    assert cnpj[:2].isnumeric()
    assert cnpj[3:6].isnumeric()
    assert cnpj[7:10].isnumeric()
    assert cnpj[11:15].isnumeric()
    assert cnpj[16:].isnumeric()
    # test cnpj without mask
    cnpj_without_mask = provider.cn

# Generated at 2022-06-21 15:23:38.433467
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    Brazil = BrazilSpecProvider()
    cpf = Brazil.cpf()
    cpf_list = cpf.split('.') + cpf.split('-')
    assert len(cpf_list) == 3
    assert len(cpf_list[0]) == 3
    assert len(cpf_list[1]) == 3
    assert len(cpf_list[2]) == 3
    assert len(cpf_list[3]) == 2


# Generated at 2022-06-21 15:23:40.197276
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert len(b.cpf()) == 14
    assert len(b.cpf(with_mask=False)) == 11

# Generated at 2022-06-21 15:23:44.801715
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person.en import Person

    p = Person("en")
    fname = p.full_name(gender=Gender.FEMALE)
    assert fname is not None

# Generated at 2022-06-21 15:23:53.711374
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()

# Generated at 2022-06-21 15:23:59.018054
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider"""

    locale = 'pt-br'
    br_provider = BrazilSpecProvider(locale)

    cpf = br_provider.cpf()
    assert cpf

    cpf = br_provider.cpf(True)
    assert cpf

    cpf = br_provider.cpf(False)
    assert cpf


# Generated at 2022-06-21 15:24:01.418342
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    assert not b.cnpj_is_valid(cnpj)
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:24:37.052428
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazilSpecProvider = BrazilSpecProvider()
    print("\nTest Method BrazilSpecProvider --> cpf:")
    print("\tcpf without mask: '" + brazilSpecProvider.cpf(with_mask=False) + "'")
    print("\tcpf: '" + brazilSpecProvider.cpf() + "'")


# Generated at 2022-06-21 15:24:38.506495
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    x = BrazilSpecProvider(seed=None)
    print(x.cpf())
    print(x.cnpj())

# Generated at 2022-06-21 15:24:41.187619
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import mimesis.providers.brazil_provider as brazil_provider
    BrazilSpecProvider_test = brazil_provider.BrazilSpecProvider()
    BrazilSpecProvider_test.cpf()



# Generated at 2022-06-21 15:24:46.841342
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import json
    import os.path
    import pprint
    import unittest
    class TestBrazilSpecProvider(unittest.TestCase):
        def test_cnpj(self):
            provider = BrazilSpecProvider()
            result = provider.cnpj()
            print(result)
            self.assertEqual(len(result), 18)
            self.assertEqual(result[2], '.')
            self.assertEqual(result[6], '.')
            self.assertEqual(result[10], '/')
            self.assertEqual(result[15], '-')
    unittest.main()


# Generated at 2022-06-21 15:24:58.377982
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj(with_mask=False)
    l = list(cnpj)
    a = 0
    b = 0
    while a<6:
        b = int(b) + int(l[a])
        a = a + 1
    while a<12:
        b = int(b) + int(l[a])*3
        a = a + 1
    b = b + int(l[12])
    b = b + int(l[13]) * 3
    c = int(b)
    c = c % 10
    d = 10 - c
    if d == 10:
        d = 0
    else:
        d = d
    print(cnpj)
    print(d)

# Generated at 2022-06-21 15:25:05.920837
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider.cnpj method."""
    b = BrazilSpecProvider()
    for _ in range(100):
        cnpj = b.cnpj()
        assert len(cnpj) == 18
        assert cnpj[2] == '.'
        assert cnpj[6] == '.'
        assert cnpj[10] == '/'
        assert cnpj[15] == '-'

    cnpj = b.cnpj()
    assert cnpj == '75.865.177/0001-88'



# Generated at 2022-06-21 15:25:08.866563
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    provider_obj = BrazilSpecProvider()
    expected_value = '77.732.230/0001-70'
    assert expected_value == provider_obj.cnpj()


# Generated at 2022-06-21 15:25:15.267490
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test function cpf."""
    bsp = BrazilSpecProvider()
    test_cpf = bsp.cpf()
    parts = [test_cpf[:3], test_cpf[4:7], test_cpf[8:11], test_cpf[12:14]]
    for part in parts:
        assert len(part) == 3
    assert len(test_cpf) == 14


# Generated at 2022-06-21 15:25:18.591427
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Testing constructor BrazilSpecProvider"""
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider
    assert brazil_spec_provider.cpf(with_mask=False)



# Generated at 2022-06-21 15:25:28.898356
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj."""
    bsp = BrazilSpecProvider()
    assert isinstance(bsp.cnpj(), str)
    assert bsp.cnpj(with_mask=False) == bsp.cnpj(with_mask=True).replace('.', '').replace('-', '').replace('/', '')
    assert len(bsp.cnpj(with_mask=True).replace('.', '').replace('-', '').replace('/', '')) == 14
    assert bsp.cnpj(with_mask=True)[2] == '.'
    assert bsp.cnpj(with_mask=True)[6] == '.'
    assert bsp.cnpj(with_mask=True)[10] == '/'

# Generated at 2022-06-21 15:26:46.703265
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():    
    instance = BrazilSpecProvider()
    assert isinstance(instance.cnpj(), str)



# Generated at 2022-06-21 15:26:50.655921
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Given
    brazilProvider = BrazilSpecProvider()

    # Check
    assert len(brazilProvider.cpf()) == 14
    assert len(brazilProvider.cpf(with_mask=False)) == 11


# Generated at 2022-06-21 15:26:57.875249
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    brazil_spec_provider = BrazilSpecProvider()

    assert isinstance(brazil_spec_provider.cnpj(with_mask=False), str)
    assert isinstance(brazil_spec_provider.cnpj(with_mask=True), str)

    cnpj_formatted = '77.732.230/0001-70'
    cnpj_unformatted = '77732250000170'

    assert brazil_spec_provider.cnpj(with_mask=True) != brazil_spec_provider.cnpj(with_mask=True)
    assert brazil_spec_provider.cnpj(with_mask=True) != brazil_spec_provider.cnpj(with_mask=True)

# Generated at 2022-06-21 15:27:00.114744
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=12345)
    assert bsp.cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-21 15:27:09.204971
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers import BrazilProvider
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender

    provider = BrazilProvider('pt-BR', seed=123456)
    seed = BrazilSpecProvider(seed=123456)

    x = provider.person(gender=Gender.MALE)
    cnpj = seed.cnpj()
    cnpj_number = cnpj.replace('.','').replace('-','').replace('/','')
    assert(cnpj_number == '77732240000170')




# Generated at 2022-06-21 15:27:12.558906
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    brazil_spec_provider = BrazilSpecProvider(seed=1577959955)
    result_cpf = brazil_spec_provider.cpf()
    print(result_cpf)
    assert result_cpf == '353.812.875-15'


# Generated at 2022-06-21 15:27:20.142273
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Arrange
    provider = BrazilSpecProvider()

    # Act
    cpf_1 = provider.cpf(False)
    cpf_2 = provider.cpf(True)

    format_1 = len(cpf_1) == 11
    format_2 = len(cpf_2) == 14

    # Assert
    assert len(cpf_1) == len(cpf_2)
    assert format_1 == format_2

# Generated at 2022-06-21 15:27:23.196349
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    list = []
    for i in range(10):
        list.append(p.cnpj(with_mask=False))

    assert len(list) == len(set(list))



# Generated at 2022-06-21 15:27:26.843005
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1


# Generated at 2022-06-21 15:27:27.323874
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-21 15:30:09.177913
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider('seed')

# Generated at 2022-06-21 15:30:14.497048
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bs = BrazilSpecProvider()

    cpf = bs.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf == '00113729740'

    # Mismatch between the return of the method and the expected result
    assert bs.cpf(with_mask=False) != '00113729741'


# Generated at 2022-06-21 15:30:16.756512
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cpf(with_mask=False)) == 11

# Generated at 2022-06-21 15:30:18.647623
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import doctest
    doctest.testmod(verbose=False, optionflags=doctest.NORMALIZE_WHITESPACE)


# Generated at 2022-06-21 15:30:20.992125
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
	test = BrazilSpecProvider()
	assert test.cnpj() == '94.061.096/0001-01'
	assert test.cnpj(with_mask=False) == '94061108000101'

# Generated at 2022-06-21 15:30:27.440119
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider class for cnpj method."""
    cnpj = BrazilSpecProvider().cnpj()
#    assert len(cnpj) == 14
#    assert cnpj.isdigit() is True
#    cnpj = BrazilSpecProvider().cnpj(with_mask=False)
#    assert len(cnpj) == 14
#    assert cnpj.isdigit() is True
#    print(cnpj)
#    cnpj = BrazilSpecProvider().cnpj(with_mask=True)
#    assert len(cnpj) == 18
#    assert cnpj.isdigit() is False
#    print(cnpj)
#
# # Unit test for method cpf of class BrazilSpecProvider
# def test_BrazilSpecProvider_cpf():
# """Test Brazil

# Generated at 2022-06-21 15:30:32.403976
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for i in range(0,15):
        x = BrazilSpecProvider().cnpj()
        print('CNPJ:', x)
        print('\n')


# Generated at 2022-06-21 15:30:34.715982
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Arrange
    provider = BrazilSpecProvider()

    # Act
    result = provider.cpf(with_mask=False)

    # Assert
    # TODO: implement real test
    assert result == "42560753212"


# Generated at 2022-06-21 15:30:37.513244
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    expected_value = '174.832.965-35'
    assert BrazilSpecProvider().cpf() == expected_value


# Generated at 2022-06-21 15:30:43.310698
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    Test BrazilSpecProvider.cpf method
    """
    brazil_spec_provider = BrazilSpecProvider(seed=42)
    result = brazil_spec_provider.cpf()
    assert result == '965.292.726-78'
    result = brazil_spec_provider.cpf(with_mask=False)
    assert result == '96529272678'