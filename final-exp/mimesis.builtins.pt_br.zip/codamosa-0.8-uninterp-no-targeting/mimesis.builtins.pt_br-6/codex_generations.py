

# Generated at 2022-06-21 15:22:10.025576
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Given a random number generator, get an instance of BrazilSpecProvider
    cnpj1 = BrazilSpecProvider().cnpj()
    cnpj2 = BrazilSpecProvider().cnpj()

    # Then the CNPJs generated are different
    assert cnpj1 != cnpj2

    # And they have the pattern: nn.nnn.nnn/nnnn-nn
    assert cnpj1.find('nn.nnn.nnn/nnnn-nn') != -1
    assert cnpj2.find('nn.nnn.nnn/nnnn-nn') != -1

    # And they have the correct checksum
    assert BrazilSpecProvider().cnpj_check(cnpj1) == True
    assert BrazilSpecProvider().cnpj_check(cnpj2) == True



# Generated at 2022-06-21 15:22:21.207861
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("--------------------------")
    print("Testing BrazilSpecProvider.cpf()")
    provider = BrazilSpecProvider()

    # Valid CNPJs
    print("--------------------------")
    print("Valid CPFs")
    cpf1 = provider.cpf()
    print("cpf1: ", cpf1)
    cpf2 = provider.cpf()
    print("cpf2: ", cpf2)
    cpf3 = provider.cpf()
    print("cpf3: ", cpf3)
    cpf4 = provider.cpf()
    print("cpf4: ", cpf4)
    cpf5 = provider.cpf()
    print("cpf5: ", cpf5)



# Generated at 2022-06-21 15:22:29.458419
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers import GenderProvider
    from mimesis.providers.person import Person

    gender_provider = GenderProvider(seed=42)
    person_provider = Person(seed=42)
    brazil_provider = person_provider.brazil

    assert brazil_provider.cnpj(with_mask=False) == '247131503386'
    assert brazil_provider.cnpj(with_mask=True) == '24.713.150/3386-12'


# Generated at 2022-06-21 15:22:31.918528
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    tmp = BrazilSpecProvider()
    assert tmp.cpf()
    assert tmp.cnpj()

# Generated at 2022-06-21 15:22:38.096768
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cnpj() == '77.732.230/0001-70'
    assert brazil_provider.cpf() == '001.137.297-40'

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:22:39.421687
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider()."""
    assert BrazilSpecProvider()


# Generated at 2022-06-21 15:22:42.076176
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()  # noqa: F841
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18

# Generated at 2022-06-21 15:22:42.997560
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()


# Generated at 2022-06-21 15:22:48.772256
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    import json

    # load the test data
    with open('tests/test_data/test_BrazilSpecProvider_cpf.json', 'r') as f:
        data = json.load(f)

    assert data

    # create a person
    person = Person('pt-br')

    # Iterate over each data entry
    for actual in data:
        gender = Gender.FEMALE if actual['gender'] == 'F' else Gender.MALE

        # Build the expected CPF

# Generated at 2022-06-21 15:22:51.405907
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert '27.143.816/0001-37' == provider.cnpj()


# Generated at 2022-06-21 15:23:03.125851
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    x = BrazilSpecProvider()
    assert len(x.cnpj()) == 18
    assert len(x.cnpj(True)) == 18
    assert len(x.cnpj(False)) == 14


# Generated at 2022-06-21 15:23:07.322412
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    cnpj = br.cnpj(with_mask=True)
    print('cnpj: ', cnpj)
    print('cnpj length: ', len(cnpj))
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:23:09.850625
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    #print('cnpj: ' + cnpj)
    assert len(cnpj) == 18

# Generated at 2022-06-21 15:23:14.241379
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    num = int(cpf[0:3])
    assert 0 <= num <= 999
    assert len(cpf) == 14


# Generated at 2022-06-21 15:23:16.753690
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    _ = BrazilSpecProvider()
    _ = BrazilSpecProvider(seed=54)
    _ = BrazilSpecProvider(seed='test_seed')

# Generated at 2022-06-21 15:23:17.296399
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:23:21.600332
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test the cnpj method of class BrazilSpecProvider."""
    provider = BrazilSpecProvider(seed=123)
    assert provider.cnpj() == "73.869.181/0001-15"


# Generated at 2022-06-21 15:23:28.111606
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.builtins import BrazilSpecProvider as bzsp

    teste = bzsp()

    cpf = teste.cpf()
    cpf_m = teste.cpf(with_mask=False)

    print(cpf)

    assert len(cpf) == 14
    assert len(cpf_m) == 11

    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'



# Generated at 2022-06-21 15:23:30.905014
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf == '935.442.932-00'


# Generated at 2022-06-21 15:23:36.113258
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf = brazil_spec_provider.cpf()
    assert len(cpf) == 14 and cpf.count('.') == 2 and cpf.count('-') == 1
    print(cpf)
    cpf = brazil_spec_provider.cpf(with_mask=False)
    assert len(cpf) == 11
    print(cpf)


# Generated at 2022-06-21 15:23:52.906779
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.providers.brazil import BrazilSpecProvider

    new_instance = BrazilSpecProvider()
    assert new_instance is not None
    assert new_instance.cnpj() is not None
    assert new_instance.cpf() is not None

# Generated at 2022-06-21 15:23:55.541213
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print("Test BrazilSpecProvider_cpf")
    obj = BrazilSpecProvider()
    assert len(obj.cpf()) == 14
    print("Test BrazilSpecProvider_cpf: OK")


# Generated at 2022-06-21 15:23:57.563165
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert cnpj is not None


# Generated at 2022-06-21 15:23:59.136477
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""

    brazil_provider = BrazilSpecProvider()

# Generated at 2022-06-21 15:24:02.455400
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cnpj() == '77.732.230/0001-70'
    assert brazil_spec_provider.cnpj(with_mask=False) == '77732208000170'

# Generated at 2022-06-21 15:24:09.986686
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider method cpf."""
    import re
    provider = BrazilSpecProvider()
    cpf = provider.cpf(False)
    assert cpf.isdigit()
    assert len(cpf) == 11
    assert re.match(r"^\d{3}.\d{3}.\d{3}-\d{2}$", provider.cpf(True))
    assert provider.cpf() == provider.cpf(True)


# Generated at 2022-06-21 15:24:17.013780
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == "74.715.296/0001-29"
    assert provider.cnpj(with_mask=False) == "74715296000129"
    assert provider.cpf() == '964.931.923-33'
    assert provider.cpf(with_mask=False) == '96493112233'
    assert provider.cnpj() == "13.019.094/0001-54"
    assert provider.cnpj(with_mask=False) == "13019094000154"
    assert provider.cpf() == '793.801.331-09'
    assert provider.cpf(with_mask=False) == '79380133109'

# Generated at 2022-06-21 15:24:19.368436
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_object = BrazilSpecProvider()
    assert test_object.cnpj() == '19.853.834/0001-15'


# Generated at 2022-06-21 15:24:26.162431
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    # randomizer
    cpf = brazil_provider.cpf()
    cnpj = brazil_provider.cnpj()
    # assert
    assert len(cpf) == 14
    assert len(cnpj) == 18
    print(cpf)
    print(cnpj)


if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:24:27.663590
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '27.214.264/0001-02'



# Generated at 2022-06-21 15:25:05.854130
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '28.399.167/0001-40'
    assert provider.cnpj() == '53.346.382/0001-86'
    assert provider.cnpj() == '04.370.132/0001-20'
    assert provider.cnpj() == '37.824.569/0001-41'
    assert provider.cnpj() == '98.004.955/0001-56'
    assert provider.cnpj() == '66.099.934/0001-30'
    assert provider.cnpj() == '83.898.891/0001-02'
    assert provider.cnpj() == '68.307.691/0001-24'

# Generated at 2022-06-21 15:25:07.548401
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf()[0:11] == "872.994.984-4"
    

# Generated at 2022-06-21 15:25:12.688569
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    result = provider.cpf(True)

    assert type(result) == str
    assert len(result) == 14
    assert result[3] == "."
    assert result[7] == "."
    assert result[11] == "-"


# Generated at 2022-06-21 15:25:18.673505
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()

    # Get a CNPJ using the mask
    cnpj_with_mask = bsp.cnpj(with_mask=True)
    assert cnpj_with_mask == "91.661.091/0001-22"

    # Get a CNPJ without the mask
    cnpj_without_mask = bsp.cnpj(with_mask=False)
    assert cnpj_without_mask == "91661109010122"

# Generated at 2022-06-21 15:25:22.566475
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '096.959.984-68'
    assert provider.cnpj() == '64.859.518/0396-36'
# test_BrazilSpecProvider()


# Generated at 2022-06-21 15:25:24.512572
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert cpf == '878.529.374-80'


# Generated at 2022-06-21 15:25:27.306188
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    print(cnpj)


# Generated at 2022-06-21 15:25:34.830807
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    assert cnpj.count('-') == 1

    cnpj_without_mask = brazil.cnpj(with_mask=False)
    assert isinstance(cnpj_without_mask, str)
    assert len(cnpj_without_mask) == 14
    assert cnpj_without_mask.count('.') == 0
    assert cnpj_without_mask.count('/') == 0

# Generated at 2022-06-21 15:25:36.862034
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().cpf() is not None
    assert BrazilSpecProvider().cnpj() is not None

# Generated at 2022-06-21 15:25:40.103546
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    if not cnpj:
        print("The cnpj is none")
    else:
        print("The cnpj is: " + cnpj)


# Generated at 2022-06-21 15:26:54.918983
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14
    assert len(cpf) == len(BrazilSpecProvider().cpf())


# Generated at 2022-06-21 15:26:58.083327
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    info_provider_br = BrazilSpecProvider()

    assert info_provider_br.cnpj() != info_provider_br.cnpj()
    assert info_provider_br.cpf() != info_provider_br.cpf()

# Generated at 2022-06-21 15:27:01.589147
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br_spec = BrazilSpecProvider()
    print('Expected: BR')
    print('Actual: ' + br_spec.generator.seed.region)
    assert br_spec.generator.seed.region == 'BR'

# Generated at 2022-06-21 15:27:05.584156
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    assert provider.cpf() == '966.944.827-76'


# Generated at 2022-06-21 15:27:08.646857
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf(with_mask=True)
    expected_value = 11
    assert len(cpf) == expected_value


# Generated at 2022-06-21 15:27:11.225575
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == "019.738.624-62"
    assert provider.cnpj() == "81.761.820/0001-90"

# Generated at 2022-06-21 15:27:23.302353
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    # CPF
    cpf = provider.cpf()
    assert cpf.count('.') == 2
    assert cpf.count('-') == 1

    cpf = provider.cpf(with_mask=False)
    assert cpf.count('.') == 0
    assert cpf.count('-') == 0

    # CNPJ
    cnpj = provider.cnpj()
    assert cnpj.count('.') == 2
    assert cnpj.count('/') == 1
    assert cnpj.count('-') == 1

    cpf = provider.cnpj(with_mask=False)
    assert cpf.count('.') == 0
    assert cpf.count('/') == 0
    assert cpf.count('-') == 0

# Generated at 2022-06-21 15:27:25.945593
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    provider.cpf() == '004.741.853-16'


# Generated at 2022-06-21 15:27:26.842025
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    pass



# Generated at 2022-06-21 15:27:29.142614
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().__class__.__name__ == 'BrazilSpecProvider'
    assert BrazilSpecProvider().__class__.__bases__[0].__name__ == 'BaseSpecProvider'


# Generated at 2022-06-21 15:30:08.915127
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        elif peso == 6:
            peso_list = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        for i, _ in enumerate(cnpj):
            soma += peso_

# Generated at 2022-06-21 15:30:11.517702
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import random
    provider = BrazilSpecProvider(random.Random())
    print(provider.cpf())
    print(provider.cnpj())

# Generated at 2022-06-21 15:30:13.790113
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    for _ in range(10):
        assert brazil.cpf() == brazil.cpf()


# Generated at 2022-06-21 15:30:15.334728
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider()
    assert br.cpf() == "536.669.144-32"


# Generated at 2022-06-21 15:30:16.549203
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider


# Generated at 2022-06-21 15:30:22.669098
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf(with_mask=False)
    first_dv = int(cpf[9])
    cpf_without_dv = [int(cpf[i]) for i in range(9)]
    second_dv = brazil.Meta.get_verifying_digit_cpf(cpf_without_dv, first_dv, 11)
    assert int(cpf[10]) == second_dv
    print("CPF: " + brazil.cpf())


# Generated at 2022-06-21 15:30:25.382363
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj_list = []
    for i in range(1000):
        cnpj_list.append(bsp.cnpj())
    num_set = set(cnpj_list)
    assert len(num_set) == len(cnpj_list)
    #print(cnpj_list[0:1000])
    #print(num_set)
    #print(len(num_set))


# Generated at 2022-06-21 15:30:35.871966
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
     # Create an instance of BrazilSpecProvider
     bsp = BrazilSpecProvider()

     # Generate random cnpj
     cnpj = bsp.cnpj(with_mask=False)

     # Check if the generated cnpj has 14 digits
     assert len(cnpj) == 14

     # Check if the generated cnpj contains only digits
     assert cnpj.isdigit() == True

     # Check wich are the last 2 digits of generated cnpj
     aux_cnpj = list(cnpj)
     first_dv = aux_cnpj[-2]
     second_dv = aux_cnpj[-1]

     # Check if the first digit of the verifying digit is right
     aux_cnpj.pop(-2)
     aux_cnpj.pop(-1)
     aux

# Generated at 2022-06-21 15:30:39.112434
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazilprovider = BrazilSpecProvider()
    cnpj = brazilprovider.cnpj()
    assert cnpj == "87.061.662/0001-28"

# Generated at 2022-06-21 15:30:42.125997
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider()
    assert br.cnpj() == "77.732.230/0001-70"

