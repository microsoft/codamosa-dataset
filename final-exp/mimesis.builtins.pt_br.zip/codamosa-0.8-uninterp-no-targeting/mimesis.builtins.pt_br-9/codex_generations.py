

# Generated at 2022-06-21 15:22:06.555606
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Testing constructor of BrazilSpecProvider class."""
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)
    assert hasattr(provider, 'random')
    assert hasattr(provider, 'datetime')
    assert hasattr(provider, 'seed')
    assert isinstance(provider.seed, int)
    assert hasattr(provider, 'provider')

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:22:11.132552
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    seed = "abcdefghijklmnopqrstuvwxyz"
    assert BrazilSpecProvider(seed).cpf() == "003.310.959-60"
    assert BrazilSpecProvider(seed).cpf(False) == "00331095960"
    assert BrazilSpecProvider(seed).cnpj() == "47.905.887/0001-16"
    assert BrazilSpecProvider(seed).cnpj(False) == "47905887000116"

# Generated at 2022-06-21 15:22:15.859373
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    esp = BrazilSpecProvider(seed=0)
    expected = "60.859.374/0001-61"
    got = esp.cnpj()

    assert expected == got


# Generated at 2022-06-21 15:22:25.256785
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit tests for the BrazilSpecProvider class."""

    # Create instance of BrazilSpecProvider
    brazil_provider = BrazilSpecProvider(seed=123)

    # Get one value
    cpf = brazil_provider.cpf()
    print(cpf)
    print(type(cpf))
    assert type(cpf) == str

    # Get one value
    cnpj = brazil_provider.cnpj()
    print(cnpj)
    print(type(cnpj))
    assert type(cnpj) == str

    print('Teste da classe BrazilSpecProvider: OK')

# Generated at 2022-06-21 15:22:26.994055
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor of class BrazilSpecProvider."""
    assert BrazilSpecProvider


# Generated at 2022-06-21 15:22:29.151508
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_BrazilSpecProvider = BrazilSpecProvider()
    assert test_BrazilSpecProvider is not None

# Unit tests for function cpf

# Generated at 2022-06-21 15:22:31.689740
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bz = BrazilSpecProvider()
    assert len(bz.cnpj()) == 18


# Generated at 2022-06-21 15:22:33.475894
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=0)


# Generated at 2022-06-21 15:22:35.023769
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("test_BrazilSpecProvider()")
    brazilSpecProvider = BrazilSpecProvider()
    print(brazilSpecProvider)


# Generated at 2022-06-21 15:22:39.704568
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # initialize the provider
    provider_ptbr = BrazilSpecProvider()

    # without mask
    cpf = provider_ptbr.cpf()

    # verify is the result match with the regex
    assert re.search(r'\d{11}', cpf)

    # with mask
    cpf = provider_ptbr.cpf(with_mask=True)

    # verify is the result match with the regex
    assert re.search(r'\d{3}\.\d{3}\.\d{3}-\d{2}', cpf)



# Generated at 2022-06-21 15:23:00.737901
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider

    b = BrazilSpecProvider()

    cpf = b.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'

    assert b.cpf(False) == cpf.replace('.', '').replace('-', '')



# Generated at 2022-06-21 15:23:02.210497
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj()


# Generated at 2022-06-21 15:23:08.434012
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """ Test if cnpj method generates a valid CNPJ. """

    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.enums import Gender

    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask = False)

    assert len(cnpj) == 14
    
    for char in cnpj:
        assert char in "0123456789"

# Generated at 2022-06-21 15:23:10.093450
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilProvider = BrazilSpecProvider()
    BrazilProvider.cpf()
    BrazilProvider.cnpj()

# Generated at 2022-06-21 15:23:12.131212
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert isinstance(cpf, str)
    assert len(cpf) == 14


# Generated at 2022-06-21 15:23:14.418475
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cpf() != None
    assert brazil.cnpj() != None



# Generated at 2022-06-21 15:23:19.588841
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.providers.brazil import BrazilSpecProvider
    br = BrazilSpecProvider()
    cnpj = br.cnpj()
    assert cnpj[12:].isdigit()
    assert cnpj.count('.') == 2
    assert cnpj.count('-') == 1


# Generated at 2022-06-21 15:23:21.721337
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.locale == 'pt-br'



# Generated at 2022-06-21 15:23:27.040966
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_cnpj = BrazilSpecProvider().cnpj()
    assert len(brazil_cnpj) == 18
    assert brazil_cnpj[2] == '.'
    assert brazil_cnpj[6] == '.'
    assert brazil_cnpj[10] == '/'
    assert brazil_cnpj[15] == '-'


# Generated at 2022-06-21 15:23:29.662580
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    print(cnpj)
    print(len(cnpj))


# Generated at 2022-06-21 15:24:02.342750
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Seeded
    spec_provider = BrazilSpecProvider(seed=42)
    assert spec_provider.cnpj(with_mask=False) == '74344812000118'

    # Non-Seeded
    spec_provider = BrazilSpecProvider()
    assert spec_provider.cnpj(with_mask=False) == '33220749000115'


# Generated at 2022-06-21 15:24:04.039283
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf(with_mask=True)
    assert BrazilSpecProvider().cpf(with_mask=False)


# Generated at 2022-06-21 15:24:08.638841
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.specs.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    cnpj = provider.cnpj()
    assert cpf != cnpj

# Generated at 2022-06-21 15:24:12.948623
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()

    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'


# Generated at 2022-06-21 15:24:14.767850
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(str(cpf)) == 14


# Generated at 2022-06-21 15:24:17.577183
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider"""
    brazilSpecProvider = BrazilSpecProvider()
    assert(brazilSpecProvider is not None)

# Generated at 2022-06-21 15:24:20.957082
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
  n = ""
  while(len(n) != 14):
    n = BrazilSpecProvider().cpf()
  assert len(n) == 14


# Generated at 2022-06-21 15:24:25.773975
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_provider = BrazilSpecProvider()
    cnpj = test_provider.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

# Generated at 2022-06-21 15:24:27.994656
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.__class__.__name__ == 'BrazilSpecProvider'


# Generated at 2022-06-21 15:24:31.572762
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for constructor of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    assert provider is not None
    assert provider.cpf() is not None
    assert provider.cnpj() is not None

# Generated at 2022-06-21 15:25:32.684416
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for BrazilSpecProvider constructor."""
    provider = BrazilSpecProvider(seed=12345)
    return provider


# Generated at 2022-06-21 15:25:34.450208
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider(seed=42)
    assert bsp.cnpj() == "42.358.913/0004-11"


# Generated at 2022-06-21 15:25:36.595868
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    assert brazil.cnpj() != brazil.cnpj()

# Generated at 2022-06-21 15:25:44.190930
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider._cnpj().

    :returns: No return

    """
    from mimesis.providers.brazil import BrazilSpecProvider
    from re import compile

    regex = compile('^[0-9]{2}.[0-9]{3}.[0-9]{3}/[0-9]{4}-[0-9]{2}$')
    assert regex.match(BrazilSpecProvider().cnpj()) != None


# Generated at 2022-06-21 15:25:46.302448
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()

    assert len(br.cpf()) == 14
    assert len(br.cnpj()) == 18


# Generated at 2022-06-21 15:25:47.490914
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    f = BrazilSpecProvider()
    assert f is not None


# Generated at 2022-06-21 15:25:50.097376
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test initializing class BrazilSpecProvider."""
    brazil = BrazilSpecProvider()
    assert brazil is not None

    assert brazil.cpf() is not None
    assert brazil.cnpj() is not None

# Generated at 2022-06-21 15:25:52.397849
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider(seed='1234')
    assert brazil.cpf() == '857.943.227-58'

test_BrazilSpecProvider_cpf()


# Generated at 2022-06-21 15:25:56.211823
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cnpj() == '05.964.849/0001-35'
    assert brazil_provider.cnpj(with_mask=False) == '05964849000135'



# Generated at 2022-06-21 15:26:05.594686
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'

    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'

    cnpj = brazil.cnpj(with_mask=False)
    assert len(cnpj) == 14
    assert cnpj[2] != '.'
    assert cnpj[6] != '.'

# Generated at 2022-06-21 15:28:47.094484
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create instances of classes BrazilSpecProvider and Person
    obj = BrazilSpecProvider()
    # Check the cnpj method
    assert obj.cnpj() == '77.732.230/0001-70'
    assert obj.cnpj(with_mask=False) == '77732230000170'

# Generated at 2022-06-21 15:28:49.070932
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    for i in range(200):
        assert len(provider.cpf()) == 14



# Generated at 2022-06-21 15:28:53.341773
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=123456789)
    result = provider.cnpj()
    assert result == '77.732.230/0001-70'
    result = provider.cnpj(with_mask=False)
    assert result == '77732230000170'


# Generated at 2022-06-21 15:28:58.624519
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf."""
    # Arrange
    bsp = BrazilSpecProvider()

    # Act
    actual_cpf = bsp.cpf()

    # Assert
    assert len(actual_cpf) == 14
    assert actual_cpf[3] == '.'
    assert actual_cpf[7] == '.'
    assert actual_cpf[11] == '-'


# Generated at 2022-06-21 15:29:00.525099
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import Generic
    data = Generic('pt-br')
    assert len(data.cpf()) == 14
    assert len(data.cpf(with_mask=False)) == 11


# Generated at 2022-06-21 15:29:03.212843
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import pytest
    from mimesis.enums import Gender

    obj = BrazilSpecProvider()
    assert isinstance(obj, BrazilSpecProvider)
    assert obj.cpf()
    assert obj.cnpj()
    assert obj.cpf(with_mask=False)
    assert obj.cnpj(with_mask=False)


# Generated at 2022-06-21 15:29:06.541345
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    result = provider.cpf()
    assert isinstance(result, str)
    assert len(result) == 14

# Generated at 2022-06-21 15:29:12.216928
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj()

    try:
        int(cnpj[-2:])
        int(cnpj[-5:-3])
        int(cnpj[-8:-6])
        int(cnpj[-12:-9])
    except:
        assert 0
    assert 1


# Generated at 2022-06-21 15:29:19.978311
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import unittest

    class TestBrazilSpecProvider(unittest.TestCase):
        def test_BrazilSpecProvider(self):
            provider = BrazilSpecProvider()
            self.assertTrue(provider.cpf(with_mask=False))
            self.assertTrue(provider.cnpj(with_mask=False))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestBrazilSpecProvider)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 15:29:23.624800
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Initialize instance of BrazilSpecProvider
    BrazilSpecProvider_ = BrazilSpecProvider()
    # Get a random CPF
    BrazilSpecProvider_.cpf()
    # Get a random cnpj
    BrazilSpecProvider_.cnpj()
    # Get a random rg
    BrazilSpecProvider_.rg()