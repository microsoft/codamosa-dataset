

# Generated at 2022-06-21 15:22:04.519690
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == cnpj.count('-') + 4 + cnpj.count('.')

# Generated at 2022-06-21 15:22:05.169863
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
  assert BrazilSpecProvider()

# Generated at 2022-06-21 15:22:08.112768
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    #CNPJ valido
    cnpj = brazil_provider.cnpj()
    assert(cnpj == "77.732.230/0001-78")


# Generated at 2022-06-21 15:22:20.233661
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Testing BrazilSpecProvider")
    brazil_spec_provider = BrazilSpecProvider(seed=0)
    assert brazil_spec_provider.locale == 'pt-br', "Expected locale 'pt-br'"
    cpf = brazil_spec_provider.cpf()
    assert cpf == "946.459.070-00", "Expected cpf 946.459.070-00"
    brazil_spec_provider.random.seed(0)
    #Test without mask
    cpf = brazil_spec_provider.cpf(with_mask=False)
    assert cpf == "9466.590700", "Expected cpf 9466.590700"
    #Test method __repr__ and __str__

# Generated at 2022-06-21 15:22:24.525881
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method BrazilSpecProvider.cpf."""
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()
    assert len(cpf) == 14
    assert isinstance(cpf, str)


# Generated at 2022-06-21 15:22:28.968856
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider(seed=12345)
    cnpjN = b.cnpj(with_mask = False)
    cnpj = b.cnpj()
    print(cnpj)
    print(cnpjN)
test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-21 15:22:34.522137
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test that the method cpf returns a correct value."""
    from mimesis.providers.geo.brazil import BrazilSpecProvider
    brazil = BrazilSpecProvider(seed=12345)
    assert brazil.cpf() == '003.527.308-88'

# Generated at 2022-06-21 15:22:40.828861
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.providers.person.en_gb import Person

    br = BrazilSpecProvider()

    p = Person(Gender.MALE)
    print('Name: {}'.format(p.full_name()))
    print('Age: {}'.format(p.age()))
    print('Bith date: {}'.format(p.birth_date()))
    print('Full Address: {}'.format(p.address()))
    print('Citie: {}'.format(p.city()))
    print('CPF: {}'.format(br.cpf()))
    print('CNPJ: {}'.format(br.cnpj()))
    print('Gender: {}'.format(p.gender()))

# Generated at 2022-06-21 15:22:45.792962
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of BrazilSpecProvider class"""
    br_provider = BrazilSpecProvider()
    cpf = br_provider.cpf(with_mask=False)
    cnpj = br_provider.cnpj(with_mask=False)
    assert len(cpf) == 11, "CPF length should be 11"
    assert len(cnpj) == 14, "CNPJ length should be 14"
    return None


# Generated at 2022-06-21 15:22:48.280647
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    obj.cpf()
    cpf2 = obj.cpf()
    print (cpf2)


# Generated at 2022-06-21 15:22:58.587872
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

    assert provider.cpf(False) != ''
    assert provider.cpf(True) != ''

    assert provider.cnpj(False) != ''
    assert provider.cnpj(True) != ''

# Generated at 2022-06-21 15:23:06.598300
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_provider = BrazilSpecProvider()
    for i in range(1000):
        cnpj = test_provider.cnpj()
        assert cnpj.count('.') == 2
        assert cnpj.count('/') == 1
        assert cnpj.count('-') == 1
        separadores = cnpj.count('.') + cnpj.count('/') + cnpj.count('-')
        assert len(cnpj) == separadores + 18


# Generated at 2022-06-21 15:23:09.600586
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf()[3] == '.'
    assert brazil_provider.cnpj()[3] == '.'

# Generated at 2022-06-21 15:23:19.483134
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider_cpf."""
    provider = BrazilSpecProvider()
    data = []
    for _ in range(32):
        data.append(provider.cpf())

# Generated at 2022-06-21 15:23:21.630275
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider(seed=43).cpf() == '405.885.286-93'


# Generated at 2022-06-21 15:23:25.432380
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()

    assert len(bsp.cnpj(with_mask=False)) == 14
    assert isinstance(bsp.cnpj(), str)



# Generated at 2022-06-21 15:23:29.311835
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf() == '248.607.196-55'
    assert provider.cnpj() == '79.881.903/0018-72'
    
if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:23:32.564391
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print("Teste Constructor sem herdar BaseProvider")
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider)
    # assert(isinstance(brazil_provider, BaseSpecProvider))


# Generated at 2022-06-21 15:23:35.290268
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert(cpf[3] == '.' and cpf[7] == '.' and cpf[11] == '-')


# Generated at 2022-06-21 15:23:36.363214
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bspc = BrazilSpecProvider()
    assert bspc.cnpj() == '53.094.576/0001-70'

# Generated at 2022-06-21 15:23:56.918742
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()

    list1 = [int(item) for item in cpf.split('.')]
    array1 = []
    for item in list1:
        list2 = [int(item) for item in item.split('-')]
        array1.extend(list2)
    cpf_without_mask = ''.join([str(i) for i in array1])

    # Test proposed in http://www.receita.fazenda.gov.br/Aplicacoes/Aplicacoes/atcta/cpf/funcoes.js
    # Test if the CPF is valid

# Generated at 2022-06-21 15:24:02.306335
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test function to test `cpf` method of BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    # check if there is any repeated number
    for digit in cpf:
        if digit.isdigit():
            assert cpf.count(digit) == 1


# Generated at 2022-06-21 15:24:06.626918
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from random import Random
    rnd = Random()
    rnd.seed(0)
    brazil_provider = BrazilSpecProvider(seed=rnd)
    output = brazil_provider.cpf(with_mask=True)
    assert output == '000.000.000-00'

# Generated at 2022-06-21 15:24:09.984773
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider.Meta.name)
    o = BrazilSpecProvider()
    assert o.cnpj()


# Generated at 2022-06-21 15:24:11.993466
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14



# Generated at 2022-06-21 15:24:13.921245
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    print(cpf)

    assert cpf == BrazilSpecProvider().cpf()


# Generated at 2022-06-21 15:24:14.720995
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider(seed=42) is not None

# Generated at 2022-06-21 15:24:26.328651
# Unit test for method cnpj of class BrazilSpecProvider

# Generated at 2022-06-21 15:24:29.689848
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data = BrazilSpecProvider().cpf()
    assert data != None
    assert type(data) == str
    assert len(data) == 14
    data = BrazilSpecProvider().cpf(with_mask=False)
    assert data != None
    assert type(data) == str
    assert len(data) == 11


# Generated at 2022-06-21 15:24:36.102695
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test = BrazilSpecProvider()
    test_cpf = test.cpf()
    test_cnpj = test.cnpj()
    #assert len(test_cpf) == 14
    #assert len(test_cnpj) == 18
    print(test_cpf)
    print(test_cnpj)

# Generated at 2022-06-21 15:25:06.286263
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    br = BrazilSpecProvider()
    assert len(br.cpf()) == 14
    assert len(br.cpf(False)) == 11


# Generated at 2022-06-21 15:25:12.234625
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.providers.base import BaseSpecProvider
    provider = BrazilSpecProvider()
    assert isinstance(provider, BaseSpecProvider)

# Generated at 2022-06-21 15:25:14.847298
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    a = BrazilSpecProvider(seed=42)
    assert a.cpf(with_mask=True) == '011.137.297-40'


# Generated at 2022-06-21 15:25:20.389069
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers import BrazilSpecProvider
    spec_provider = BrazilSpecProvider()
    
    data = {
        'first_name': spec_provider.first_name(gender=Gender.FEMALE)
    }

    print(data)
    cnpj = spec_provider.cnpj()
    print(cnpj)
    

# Generated at 2022-06-21 15:25:24.154645
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    def mock_random(x):
        return 1
    brazil_provider = BrazilSpecProvider()
    brazil_provider.random = mock_random
    resp = brazil_provider.cpf()
    assert resp == '001.137.297-40'


# Generated at 2022-06-21 15:25:28.659803
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_cnpj = BrazilSpecProvider()
    cnpj = brazil_cnpj.cnpj()
    assert isinstance(cnpj, str), \
        'Expected to return a str, instead return a {0}'.format(type(cnpj))


# Generated at 2022-06-21 15:25:32.777481
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test 1: verify that the lenght of cpf is 11, including the mask
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 11
    print("Test 1 passed")

    # Test 2: verify that the lenght of cpf is 11, excluding the mask
    assert len(provider.cpf(with_mask=False)) == 11
    print("Test 2 passed")



# Generated at 2022-06-21 15:25:33.580330
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    return BrazilSpecProvider().cpf()


# Generated at 2022-06-21 15:25:36.175679
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Verify if the BrazilSpecProvider was created."""
    brazil = BrazilSpecProvider()
    assert brazil
    assert brazil.cpf()
    assert brazil.cnpj()

# Generated at 2022-06-21 15:25:39.301409
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    x = brazil.cpf(True)
    y = brazil.cnpj(True)
    print(x)
    print(y)


# Generated at 2022-06-21 15:26:54.919447
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test = BrazilSpecProvider(seed=1)
    assert test.cnpj(with_mask = False) == '77732230000170'
    #assert test.cnpj(with_mask = True) == '77.732.230/0001-70'

# Generated at 2022-06-21 15:26:56.415416
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-21 15:27:00.607450
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br = BrazilSpecProvider(seed=1000)
    assert br.cpf(with_mask=False) == '08815678822'
    assert br.cpf(with_mask=True) == '088.156.788-22'


# Generated at 2022-06-21 15:27:07.914067
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    # second_dv = get_verifying_digit_cnpj([5, 5, 2, 6, 2, 5, 2, 3, 2, 5, 2, 3, 2], 6)
    result = provider.cnpj(with_mask=False)
    assert result == "552.625.235/2352" or result == "553.625.235/2352"


# Generated at 2022-06-21 15:27:10.943895
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=False) == '77732240000170'
    assert provider.cnpj(with_mask=True) == '77.732.240/0001-70'

# Generated at 2022-06-21 15:27:12.816073
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()


# Generated at 2022-06-21 15:27:14.633897
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider('test') is not None

# Generated at 2022-06-21 15:27:15.888063
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert str(BrazilSpecProvider()) is not None


# Generated at 2022-06-21 15:27:20.386900
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert b.cnpj() in ('05.073.946/0002-78',)
    assert b.cnpj(with_mask=False) in ('05073946000278',)


# Generated at 2022-06-21 15:27:23.369094
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cnpj() != brazil_provider.cnpj()
    assert brazil_provider.cpf() != brazil_provider.cpf()

# Generated at 2022-06-21 15:30:00.207236
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert (len(cnpj) == 14)
    assert (cnpj[2] == '.')
    assert (cnpj[6] == '.')
    assert (cnpj[10] == '/')
    assert (cnpj[15] == '-')
    cnpj = provider.cnpj(with_mask=False)
    assert (len(cnpj) == 14)
    assert (cnpj[2] != '.')
    assert (cnpj[6] != '.')
    assert (cnpj[10] != '/')
    assert (cnpj[15] != '-')


# Generated at 2022-06-21 15:30:07.765250
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj."""
    provider = BrazilSpecProvider(seed=0)
    # Unit tests for default case
    assert provider.cnpj() == '77.732.230/0001-70'
    assert provider.cnpj(with_mask=False) == '77732302000170'

    # Unit tests for case without mask
    assert provider.cnpj(with_mask=False) == '77732302000170'
    assert provider.cnpj(with_mask=False) == '34777927000153'
    assert provider.cnpj(with_mask=False) == '42465942000110'
    assert provider.cnpj(with_mask=False) == '90694848000104'

# Generated at 2022-06-21 15:30:11.366982
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test_obj = BrazilSpecProvider()
    assert hasattr(test_obj, 'Meta')
    assert hasattr(test_obj, 'cpf')
    assert hasattr(test_obj, 'cnpj')


# Generated at 2022-06-21 15:30:13.644756
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    data = BrazilSpecProvider()
    assert data is not None
    assert data.cnpj() is not None
    assert data.cpf() is not None

# Generated at 2022-06-21 15:30:17.810376
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test without mask
    bsp = BrazilSpecProvider()
    assert not bsp.cpf(False).__contains__(".") and not bsp.cpf(False).__contains__("-")
    # Test with mask
    assert bsp.cpf(True).__contains__(".") and bsp.cpf(True).__contains__("-")


# Generated at 2022-06-21 15:30:19.947450
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:30:21.959880
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert bsp.cnpj() == '04.324.919/0001-00'



# Generated at 2022-06-21 15:30:23.241889
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    print(brazil_provider.cpf())


# Generated at 2022-06-21 15:30:24.168083
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for _ in range(100):
        cpf = BrazilSpecProvider().cpf()
        assert len(cpf) == 14


# Generated at 2022-06-21 15:30:29.113215
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test if the method cnpj of class BrazilSpecProvider generates a valid CNPJ."""
    provider = BrazilSpecProvider()
    cnpj_provider = provider.cnpj()
    assert cnpj_provider.count('.') == 2
    assert cnpj_provider.count('/') == 1
    assert cnpj_provider.count('-') == 1
    cnpj_split = cnpj_provider.replace('.', '').replace('/', '').replace('-', '')
    assert get_verifying_digit_cnpj(list(map(int, list(cnpj_split))), 5) == int(cnpj_split[12])
    assert get_verifying_digit_cnpj(list(map(int, list(cnpj_split))), 6)