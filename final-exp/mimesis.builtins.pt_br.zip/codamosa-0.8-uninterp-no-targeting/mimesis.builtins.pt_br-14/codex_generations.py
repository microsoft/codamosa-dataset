

# Generated at 2022-06-21 15:22:06.008603
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cpf = BrazilSpecProvider().cnpj()
    assert len(cpf) == 14
    assert cpf.count('.') == 2
    assert cpf.count('/') == 1
    assert cpf.count('-') == 1

    cpf_without_mask = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(cpf_without_mask) == 14
    assert cpf_without_mask.count('.') == 0
    assert cpf_without_mask.count('/') == 0
    assert cpf_without_mask.count('-') == 0
    
    return True
    

# Generated at 2022-06-21 15:22:09.195219
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    instance = BrazilSpecProvider()
    assert instance.cnpj() != None
    assert instance.cpf() != None
    assert instance._data["numbers"]["cnpj"] != None
    assert instance._data["numbers"]["cpf"] != None

# Generated at 2022-06-21 15:22:13.402454
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    data = BrazilSpecProvider()
    # cnpj = data.cnpj()
    cnpj = data.cnpj(with_mask=False)
    return isinstance(cnpj, str)

# Generated at 2022-06-21 15:22:14.772959
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider(seed=1)
    assert brazil_provider.cpf() == "839.273.045-49"
    assert brazil_provider.cpf(with_mask=False) == "83927304549"


# Generated at 2022-06-21 15:22:16.678744
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import Person

    p = Person('pt-br')
    expected = p.cpf(True)
    print (expected)


# Generated at 2022-06-21 15:22:28.201413
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider."""
    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        elif peso == 6:
            peso_list = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]

# Generated at 2022-06-21 15:22:31.456633
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:22:34.150841
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj() == '15.166.595/0001-67'

# Generated at 2022-06-21 15:22:35.632379
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
	assert BrazilSpecProvider()


# Generated at 2022-06-21 15:22:39.333383
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print(provider.cpf())
    print(provider.cnpj())

"""Output:

088.556.153-48
18.807.848/0001-26

"""

# Generated at 2022-06-21 15:23:02.402241
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj) == 18
    assert cnpj[2] == '.'
    assert cnpj[6] == '.'
    assert cnpj[10] == '/'
    assert cnpj[15] == '-'
    assert provider.cnpj(with_mask=False) == cnpj.replace('.', '') \
                                              .replace('/', '') \
                                              .replace('-', '')



# Generated at 2022-06-21 15:23:05.928422
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider.cpf()."""
    # pylint: disable=protected-access
    assert BrazilSpecProvider().cpf() == BrazilSpecProvider()._cpf()


# Generated at 2022-06-21 15:23:11.071443
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import random
    import time
    import datetime
    time.sleep(1)
    random.seed(datetime.date(2019, 10, 8))
    localizer = BrazilSpecProvider(seed=random.seed(datetime.date(2019, 10, 8)))

    assert localizer.cnpj(with_mask=True) == '98.867.611/0001-10'


# Generated at 2022-06-21 15:23:14.408897
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-21 15:23:20.222548
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Test import
    from mimesis.providers.brazil_provider import BrazilSpecProvider

    # Test instance of the class
    bsp = BrazilSpecProvider()
    assert isinstance(bsp, BrazilSpecProvider)

    # Test parent class
    from mimesis.builtins import BaseSpecProvider
    assert issubclass(BrazilSpecProvider, BaseSpecProvider)
    assert issubclass(BrazilSpecProvider, BaseSpecProvider)

    # Test use of constructor
    bsp = BrazilSpecProvider(seed=42)
    assert bsp.random.randint(0, 100), bsp.random.randint(0, 100)



# Generated at 2022-06-21 15:23:26.466207
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=True)
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'

    cpf = provider.cpf(with_mask=False)
    assert len(cpf) == 11



# Generated at 2022-06-21 15:23:31.934008
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    assert brazil.cnpj(with_mask = False) == brazil.cnpj()
    assert brazil.cnpj(with_mask = True).replace(".", "").replace("/", "").replace("-", "") == brazil.cnpj()

    assert brazil.cpf(with_mask = False) == brazil.cpf()
    assert brazil.cpf(with_mask = True).replace(".", "").replace("-", "") == brazil.cpf()

# Generated at 2022-06-21 15:23:35.058626
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    res = BrazilSpecProvider(seed=123).cpf()
    assert res == '033.599.528-42'

    res = BrazilSpecProvider(seed=123).cpf(False)
    assert res == '03359952842'


# Generated at 2022-06-21 15:23:40.809245
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    provider = BrazilSpecProvider()

    assert provider.cpf(with_mask=False) == '04023533053'
    assert provider.cpf(with_mask=True) == '040.235.330-53'

    assert provider.cpf(with_mask=False, gender=Gender.FEMALE) == '81327950054'
    assert provider.cpf(with_mask=True, gender=Gender.FEMALE) == '813.279.500-54'

    assert provider.cpf(with_mask=False, gender=Gender.MALE) == '09753824046'
    assert provider.cpf(with_mask=True, gender=Gender.MALE) == '097.538.240-46'


# Generated at 2022-06-21 15:23:45.026983
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method BrazilSpecProvider.cpf()."""
    bcpf = BrazilSpecProvider()
    cpf = bcpf.cpf()
    assert len(cpf) == 14



# Generated at 2022-06-21 15:24:16.755710
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider()
    for i in range(10):
        assert len(cpf.cpf()) == 14
        assert len(cpf.cpf()) == 11
        assert len(cpf.cpf(False)) == 11


# Generated at 2022-06-21 15:24:17.294231
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:24:21.336278
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    data = BrazilSpecProvider()
    assert len(data.cpf()) == 14
    assert data.cpf(with_mask=False) == '00113709371'



# Generated at 2022-06-21 15:24:23.276877
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_test = BrazilSpecProvider()
    assert brazil_test.cpf() == brazil_test.cpf()


# Generated at 2022-06-21 15:24:26.652875
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    g = BrazilSpecProvider()
    assert g.cnpj()
    assert g.cpf()
    assert g.cnpj(with_mask=False)
    assert g.cpf(with_mask=False)

# Generated at 2022-06-21 15:24:27.508008
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert obj

# Generated at 2022-06-21 15:24:38.103360
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    def get_verifying_digit_cnpj(cnpj, peso):
        """Calculate the verifying digit for the CNPJ.

        :param cnpj: List of integers with the CNPJ.
        :param peso: Integer with the weight for the modulo 11 calculate.
        :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        if peso == 5:
            peso_list = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        elif peso == 6:
            peso_list = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        for i, _ in enumerate(cnpj):
            soma += peso_

# Generated at 2022-06-21 15:24:40.457151
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider(seed=123).cnpj(with_mask=False)
    assert cnpj == '35387972000158'


# Generated at 2022-06-21 15:24:43.555245
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpfs = []
    for i in range(10):
        cpf = BrazilSpecProvider().cpf()
        assert(isinstance(cpf, str))
        assert(len(cpf) == 14)
        assert(cpf not in cpfs)
        cpfs.append(cpf)
    # TODO



# Generated at 2022-06-21 15:24:45.770958
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    assert len(provider.cpf(with_mask=False)) == 11
    assert len(provider.cpf(with_mask=True)) == 14



# Generated at 2022-06-21 15:25:50.847007
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cpf(with_mask=False)) == 11


# Generated at 2022-06-21 15:25:52.527165
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()
    assert len(p.cpf()) == len("00569092106")


# Generated at 2022-06-21 15:26:00.680354
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider(seed = 'test')
    print(f'\nSize of data: {len(brazil.data)}')
    for item in brazil.data:
        print(f'{item} : {brazil.data[item]}')
    
    # Unit test for cpf()
    print(f'\ncpf(): {brazil.cpf()}')
    
    # Unit test for cnpj()
    print(f'\ncnpj(): {brazil.cnpj()}')

if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:26:01.604728
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider is not None

# Generated at 2022-06-21 15:26:06.489566
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for cpf method of class BrazilSpecProvider."""
    from mimesis.providers.brazil import BrazilSpecProvider
    provider = BrazilSpecProvider()
    # Test with a seed
    provider.seed(1)
    res = provider.cpf()
    assert res == '777.819.962-43'

    # Test without seed
    res = provider.cpf()
    assert res == '954.295.869-13'


# Generated at 2022-06-21 15:26:09.989519
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    test_cpf = bsp.cpf()
    test_cnpj = bsp.cnpj()
    assert len(test_cpf) > 11
    assert type(test_cpf) == str
    assert len(test_cnpj) > 13
    assert type(test_cnpj) == str


# Generated at 2022-06-21 15:26:14.847106
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '947.852.485-56'
    assert BrazilSpecProvider(seed=727).cpf() == '148.972.764-86'
    assert BrazilSpecProvider(seed=727).cpf(with_mask=False) == '14897276486'


# Generated at 2022-06-21 15:26:19.604457
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    for _ in range(10):
        cpf = BrazilSpecProvider().cpf()
        assert len(cpf) == 14
        assert cpf[3] == cpf[7] == '.'
        assert cpf[11] == '-'


# Generated at 2022-06-21 15:26:23.606184
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf_list = []
    for i in range(1,10):
        cpf = bsp.cpf()
        cpf_list.append(cpf)
    print('CPF List: ', cpf_list)


# Generated at 2022-06-21 15:26:26.891671
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    # print("cpf: " + cpf)
    assert cpf is not None
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-21 15:29:08.891807
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bs = BrazilSpecProvider()
    assert bs.cpf() == '093.152.116-73'


# Generated at 2022-06-21 15:29:10.926812
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=None)

# Generated at 2022-06-21 15:29:14.269229
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert provider.cpf()[3] == '.'
    assert provider.cpf()[7] == '.'
    assert provider.cpf()[11] == '-'
    assert provider.cpf(with_mask=False)[-2:] >= '00'


# Generated at 2022-06-21 15:29:17.114887
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    for _ in range(10):
        print(BrazilSpecProvider().cnpj())



# Generated at 2022-06-21 15:29:18.415728
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:29:21.583421
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf_1 = provider.cpf()
    cpf_2 = provider.cpf()
    assert cpf_1 != cpf_2
    assert len(cpf_1) == 14


# Generated at 2022-06-21 15:29:24.371461
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider(seed=123)
    assert brazil_provider.cnpj(False) == '39211030000171'
    assert brazil_provider.cpf(False) == '33270710519'

# Generated at 2022-06-21 15:29:24.973192
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:29:27.133017
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    assert bsp.cpf(with_mask=False)
    assert bsp.cpf(with_mask=True)


# Generated at 2022-06-21 15:29:30.507157
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = '1234567890'
    bsp = BrazilSpecProvider(seed)
    expected = '7773223000170'
    actual = bsp.cnpj(with_mask=False)
    assert expected == actual

