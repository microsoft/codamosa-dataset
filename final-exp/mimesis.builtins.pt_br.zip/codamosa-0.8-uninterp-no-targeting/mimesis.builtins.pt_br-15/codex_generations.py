

# Generated at 2022-06-21 15:22:01.533721
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    person = Person('pt-br', seed=42)
    person.use_gender(Gender.MALE)
    expected = '299.876.576-05'
    assert expected == person.cpf()


# Generated at 2022-06-21 15:22:03.991661
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    cpf = BrazilSpecProvider().cpf()
    assert cpf == '123.456.789-00'



# Generated at 2022-06-21 15:22:05.624565
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '78.060.399/0001-56'



# Generated at 2022-06-21 15:22:06.176565
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:22:10.619119
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    from mimesis.enums import Gender
    provider = BrazilSpecProvider
    for _ in range(10):
        print('Gender: ', provider().gender(gender=Gender.MALE))
        print('CPF: ', provider().cpf())
        print('CNPJ: ', provider().cnpj())
if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:22:13.060828
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    import pprint
    pp = pprint.PrettyPrinter()
    pp.pprint(brazil_spec_provider.cpf())
    pp.pprint(brazil_spec_provider.cpf(with_mask=False))
    assert True


# Generated at 2022-06-21 15:22:17.677503
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    br_provider = BrazilSpecProvider()
    #print("BrazilSpecProvider.cpf() -> " + br_provider.cpf())
    assert br_provider.cpf()[3] == "."
    assert type(br_provider.cpf()) is str


# Generated at 2022-06-21 15:22:19.985960
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = "a"
    bs = BrazilSpecProvider(seed)
    print(bs.cnpj())


# Generated at 2022-06-21 15:22:27.400445
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    provider = BrazilSpecProvider()
    brazil_cnpj = provider.cnpj()
    # check if cnpj has 14 chars
    assert len(brazil_cnpj) == 18

    brazil_cnpj = provider.cnpj(False)
    # check if cnpj has 14 chars
    assert len(brazil_cnpj) == 14



# Generated at 2022-06-21 15:22:29.833405
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of BrazilSpecProvider class."""
    bsp = BrazilSpecProvider()

    assert len(bsp.cpf()) == 14


# Generated at 2022-06-21 15:22:45.446548
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    b = BrazilSpecProvider()

    b.random.seed(42)
    cpf_1 = b.cpf()
    assert cpf_1 == '736.487.957-91'

    cpf_2 = b.cpf(with_mask=False)
    assert cpf_2 == '73648770391'

    cnpj = b.cnpj()
    assert cnpj == '76.816.877/0001-68'

    cnpj_2 = b.cnpj(with_mask=False)
    assert cnpj_2 == '76816877000168'

    b.random.seed(42)
    assert b.random.randint(0, 10) == 3

# Generated at 2022-06-21 15:22:47.226749
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cpf= BrazilSpecProvider()
    print(cpf.cnpj())

# Generated at 2022-06-21 15:22:51.659454
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    Test method BrazilSpecProvider.cnpj()
    """
    provider = BrazilSpecProvider()
    cnpjs = set()

    for _ in range(100):
        cnpjs.add(provider.cnpj())
    assert len(cnpjs) == 100


# Generated at 2022-06-21 15:22:56.293354
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    # test cpf
    assert provider.cpf() == '000.000.000-00'
    assert provider.cpf(with_mask=False) == '00000000000'
    # test cnpj
    assert provider.cnpj() == '00.000.000/0000-00'
    assert provider.cnpj(with_mask=False) == '00000000000000'

# Generated at 2022-06-21 15:22:59.744438
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print('test_BrazilSpecProvider_cpf()')
    print(BrazilSpecProvider().cpf())
    print(BrazilSpecProvider().cpf(False))
    print(BrazilSpecProvider().cpf(True))


# Generated at 2022-06-21 15:23:08.720989
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert all(char.isdigit() for char in cpf[:3])
    assert all(char.isdigit() for char in cpf[4:7])
    assert all(char.isdigit() for char in cpf[8:11])
    assert all(char.isdigit() for char in cpf[12:])


# Generated at 2022-06-21 15:23:12.504107
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br = BrazilSpecProvider(seed=42)  # same seed for make it easier to test
    assert br.cnpj(with_mask=True) == '76.967.957/0001-95'
    assert br.cnpj(with_mask=False) == '76967957000195'

# Generated at 2022-06-21 15:23:14.731240
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import doctest
    doctest.run_docstring_examples(BrazilSpecProvider.cnpj,
                                    globals(),
                                    verbose=True)

# Generated at 2022-06-21 15:23:16.479822
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    assert bsp is not None
    assert bsp._random is not None

# Generated at 2022-06-21 15:23:22.117214
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""

    cpfs = set()
    for x in range(10):
        cpf = BrazilSpecProvider().cpf(with_mask=False)
        assert len(cpf) == 11
        assert cpf not in cpfs
        cpfs.add(cpf)


# Generated at 2022-06-21 15:23:37.628052
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    
    if brazil.cpf() == None:
        assert False
    if brazil.cnpj() == None:
        assert False
    
    assert True

# Generated at 2022-06-21 15:23:41.433167
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test class BrazilSpecProvider."""
    seed = 123456789
    provider = BrazilSpecProvider(seed)
    assert provider._random_provider.seed == seed
    assert provider._locale == 'pt-br'
    assert str(provider) == '<BrazilSpecProvider> pt-br'

# Generated at 2022-06-21 15:23:52.116773
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()

# Generated at 2022-06-21 15:23:54.448160
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider().cnpj())

# Generated at 2022-06-21 15:23:58.529242
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import pytest
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    provider = BrazilSpecProvider()
    # Only 1 test because testing the CNPJ is validating
    # if there're no repeating digits.
    assert provider.cnpj(False) != None
    return

# Generated at 2022-06-21 15:23:59.692682
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf(with_mask=False)
    assert isinstance(cpf, str)


# Generated at 2022-06-21 15:24:01.750569
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider().cnpj(True))
    print(BrazilSpecProvider().cpf(False))

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:24:03.210770
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()

    print(brazil_provider.cnpj())
    print(brazil_provider.cpf())

# Generated at 2022-06-21 15:24:11.243670
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider()
    cpf_without_mask = brazil_spec_provider.cpf(False)
    cpf_with_mask = brazil_spec_provider.cpf(True)
    assert len(cpf_without_mask) == 11
    assert len(cpf_with_mask) == 14
    assert cpf_without_mask == cpf_with_mask.translate(
        str.maketrans('', '', '.'))


# Generated at 2022-06-21 15:24:12.755581
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    assert len(bsp.cnpj()) == 18


# Generated at 2022-06-21 15:24:40.130147
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
  BrazilSpecProvider()



# Generated at 2022-06-21 15:24:41.580054
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(True) == '77.732.230/0001-70'

# Generated at 2022-06-21 15:24:43.104110
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    assert b.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-21 15:24:46.183916
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    x = BrazilSpecProvider()
    a = x.cpf() # String type
    assert len(a) == 14
    assert type(a) == str
    assert a[3] == '.'
    assert a[7] == '.'
    assert a[11] == '-'


# Generated at 2022-06-21 15:24:47.634369
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider()
    print(a.cpf())
    print(a.cnpj())


# Generated at 2022-06-21 15:24:53.238897
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert len(provider.cpf(False)) == 11
    assert provider.cpf().replace('.', '').replace('-', '').isdigit()
    assert provider.cpf(False).isdigit()


# Generated at 2022-06-21 15:24:56.034541
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj(False)
    assert len(cnpj) == 14


# Generated at 2022-06-21 15:24:56.977753
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider()
    print(a)

# Generated at 2022-06-21 15:24:57.829827
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()


# Generated at 2022-06-21 15:24:59.532411
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()

    return br


# Generated at 2022-06-21 15:26:04.530140
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()

    cpf1 = bsp.cpf(with_mask=False)
    cpf2 = bsp.cpf()

    assert cpf1.isnumeric()
    assert len(cpf1) == 11
    assert cpf2.replace('.', '').replace('-', '').isnumeric()
    assert len(cpf2) == 14


# Generated at 2022-06-21 15:26:11.071202
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for BrazilSpecProvider.cnpj."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from mimesis.builtins.base import BaseSpecProvider
    from mimesis.builtins.brazil import BrazilSpecProvider

    seed = 77777777777
    person = Person("pt-BR", seed=seed)
    address = Address("pt-BR", seed=seed)

    provider = BrazilSpecProvider(seed=seed)
    print("Test CNPJ:")
    print("Seu CNPJ é: ", end="")
    print(provider.cnpj())

    print("\nTest CPF:")
    print("Seu CPF é: ", end="")

# Generated at 2022-06-21 15:26:12.994222
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    cpf = BrazilSpecProvider().cpf()
    assert len(cpf) == 14


# Generated at 2022-06-21 15:26:16.520810
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=False)
    assert cnpj == '19608391000105'


# Generated at 2022-06-21 15:26:18.489946
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
  provider = BrazilSpecProvider()
  assert provider.__class__.__name__ == "BrazilSpecProvider"


# Generated at 2022-06-21 15:26:21.949588
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider is not None
    assert brazil_provider.locale == "pt-br"


# Generated at 2022-06-21 15:26:26.022441
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = "test_BrazilSpecProvider_cnpj"
    bz = BrazilSpecProvider(seed)
    cnpj = '31.955.988/0001-60'
    assert bz.cnpj() == cnpj
    assert bz.cnpj(with_mask=False) == cnpj.replace('.','').replace('-',"").replace('/','')


# Generated at 2022-06-21 15:26:31.852650
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj()
    assert len(cnpj) == 18 and cnpj[2] == "." and cnpj[6] == "." and cnpj[10] == "/" and cnpj[15] == "-"


# Generated at 2022-06-21 15:26:37.410036
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=True) == '77.732.230/0001-70'
    assert provider.cnpj(with_mask=False) == '77732230000170'
    assert provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-21 15:26:45.455269
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    seed = 'B62P2QNGBWPAIH7V'
    generator = BrazilSpecProvider(seed)
    cnpj_with_mask = generator.cnpj(with_mask=True)
    # Test format
    assert len(cnpj_with_mask) == 18
    assert cnpj_with_mask[2] == '.'
    assert cnpj_with_mask[6] == '.'
    assert cnpj_with_mask[10] == '/'
    assert cnpj_with_mask[15] == '-'
    # Test consistency
    cnpj_without_mask = cnpj_with_mask.replace('.', '').replace('/', '').replace('-', '')
    generator = BrazilSpecProvider(seed)

# Generated at 2022-06-21 15:29:12.542463
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    obj = BrazilSpecProvider()
    assert obj.cpf() is not None


# Generated at 2022-06-21 15:29:23.324935
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil = BrazilSpecProvider()
    # cpf
    assert len(brazil.cpf(True)) == 14
    assert len(brazil.cpf(False)) == 11
    # cnpj
    assert len(brazil.cnpj(True)) == 18
    assert len(brazil.cnpj(False)) == 14
    # _get_data
    assert brazil._get_data('cel')[0] == '21'
    assert brazil._get_data('ddd')[0] == '21'
    assert brazil._get_data('zip')[0] == '20945-410'
    assert brazil._get_data('state')[0] == 'Rio de Janeiro'
    assert brazil._get_data('cep_state')[0] == 'Rio de Janeiro'

# Generated at 2022-06-21 15:29:33.194069
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():

    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()

    assert len(cnpj) == 18

    cnpj_split = cnpj.split(".")
    assert len(cnpj_split) == 3

    cnpj_split = cnpj_split[2].split("-")
    assert len(cnpj_split) == 2

    cnpj_split = cnpj_split[0].split("/")
    assert len(cnpj_split) == 2

    assert len(cnpj_split[0]) == 8
    assert len(cnpj_split[1]) == 4
    assert len(cnpj_split[0] + cnpj_split[1]) == 12


# Generated at 2022-06-21 15:29:41.344390
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person.en_US import EnglishUSNameProvider
    from mimesis.providers.person.pt_BR import BrazilPersonProvider

    seed = "aadf3cbb-8a45-4b1f-b0a2-0f8bfc906939"

    # create a generator
    gen = BrazilPersonProvider(seed=seed)

    # create a name provider
    name_gen = EnglishUSNameProvider(seed=seed)

    # create a provider for Brazil
    pt_br = BrazilSpecProvider(seed=seed)

    # check last results for person
    if gen.last_results["cpf"] is None:
        assert pt_br.cpf() == "035.854.043-52"
    else:
        assert gen

# Generated at 2022-06-21 15:29:46.671717
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
        # Create a instance of BrazilSpecProvider
    brazil_spec = BrazilSpecProvider()
        # Call method cpf of class BrazilSpecProvider and save the result in variable cpf_result
    cpf_result = brazil_spec.cpf()
    print(f"cpf_result = {cpf_result}")
        # with_mask = False
    cpf_result = brazil_spec.cpf(False)
    print(f"cpf_result = {cpf_result}")
        # Check if cpf_result is a string type
    assert type(cpf_result) is str


# Generated at 2022-06-21 15:29:48.161424
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj(with_mask=True) == '77.732.230/0001-70'


# Generated at 2022-06-21 15:29:51.511769
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test class BrazilSpecProvider."""
    from mimesis.providers.locales.pt_br.brazil_provider import BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider is not None


# Generated at 2022-06-21 15:29:59.670961
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test BrazilSpecProvider class method cpf."""
    cpf = BrazilSpecProvider.cpf()
    assert cpf
    assert isinstance(cpf, str)
    assert len(cpf) == 14
    assert cpf[9] == '-'
    assert cpf[3] == '.'
    assert cpf[6] == '.'
    assert cpf[12] != '-'

    cpf = BrazilSpecProvider.cpf(with_mask=False)
    assert cpf
    assert isinstance(cpf, str)
    assert len(cpf) == 11
    assert cpf[9] != '-'
    assert cpf[3] != '.'
    assert cpf[6] != '.'
    assert cpf[12] != '-'



# Generated at 2022-06-21 15:30:07.383807
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Initialize an object of class BrazilSpecProvider
    brazil_spec_provider = BrazilSpecProvider()

    # Generate a cnpj
    cnpj = brazil_spec_provider.cnpj()

    # Get the cnpj without the mask
    cnpj = cnpj[0:2] + cnpj[3:6] + cnpj[7:10] + cnpj[11:15] + cnpj[16:]

    # Get the first, second and third digits of the cnpj
    c, n, p, j = int(cnpj[0]), int(cnpj[1]), int(cnpj[2]), int(cnpj[3])

    # Get the fourth, fifth, sixth, seventh and eighth digits of the cnpj
    n1, p1, j1

# Generated at 2022-06-21 15:30:11.562781
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    lista_cnpj = []

    # Gera 100 cnpjs e os adiciona a lista de cnpjs
    for i in range(100):
        lista_cnpj.append(bsp.cnpj())

    # Adiciona a primeira string da lista, caso ela não se repita
    lista_cnpj_unica = []
    for c in lista_cnpj:
        if c not in lista_cnpj_unica:
            lista_cnpj_unica.append(c)

    # Se a lista de cnpjs únicos for maior que 0, a 