

# Generated at 2022-06-21 15:21:59.939141
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    cnpj_example = brazil_spec_provider.cnpj()
    print('CNPJ: {}'.format(cnpj_example))



# Generated at 2022-06-21 15:22:02.708546
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    x = BrazilSpecProvider()
    assert x.cpf() is not None
    assert x.cnpj() is not None



# Generated at 2022-06-21 15:22:06.695858
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    assert len(cnpj) == 18
    assert cnpj.isdigit()
    assert cnpj.find('.') > -1
    assert cnpj.find('-') > -1
    assert cnpj.find('/') > -1


# Generated at 2022-06-21 15:22:07.586192
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider(seed=1)

# Generated at 2022-06-21 15:22:09.659600
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert len(provider.cnpj()) == 18
    assert len(provider.cnpj(with_mask=False)) == 14


# Generated at 2022-06-21 15:22:12.759865
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    try:
        BrazilSpecProvider()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-21 15:22:16.642028
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    local = BrazilSpecProvider()
    cpf = []
    for _ in range(100):
        cpf.append(local.cpf())
    assert len(cpf) == 100
    print(cpf)


# Generated at 2022-06-21 15:22:19.358545
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    br = BrazilSpecProvider()
    assert br.cpf() != br.cpf()
    assert br.cnpj() != br.cnpj()



# Generated at 2022-06-21 15:22:23.041601
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cnpj(True) == '77.732.230/0001-70'
    assert provider.cpf(True) == '001.137.297-40'

# Generated at 2022-06-21 15:22:25.838352
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    assert provider.cpf() == "001.137.297-40"
    
test_BrazilSpecProvider_cpf()


# Generated at 2022-06-21 15:22:35.938798
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=1)
    assert provider.cnpj() == '33.903.129/0001-43'


# Generated at 2022-06-21 15:22:37.157620
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data = BrazilSpecProvider().cpf()
    assert data == '832.084.328-73'


# Generated at 2022-06-21 15:22:40.627209
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test for cnpj method of class BrazilSpecProvider."""
    
    from mimesis.enums import Gender

    br = BrazilSpecProvider(seed=123)
    cpf = br.cnpj()
    assert cpf == '35.400.086/0001-44'

    cpf = br.cnpj(with_mask=False)
    assert cpf == '35400086000144'

# Generated at 2022-06-21 15:22:43.890967
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14


# Generated at 2022-06-21 15:22:47.498269
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == '435.244.125-24'
    assert BrazilSpecProvider().cpf() == '404.252.917-71'
    assert BrazilSpecProvider().cpf() == '879.452.917-16'


# Generated at 2022-06-21 15:22:50.077929
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    '''
    Random cnpj must be a string with 14 characters
    '''
    assert len(BrazilSpecProvider().cnpj()) == 14


# Generated at 2022-06-21 15:22:51.924735
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    obj = BrazilSpecProvider()
    result = obj.cnpj(with_mask=False)
    assert len(result) == 14
    assert result != obj.cnpj(with_mask=False)



# Generated at 2022-06-21 15:22:54.196970
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=False) == '7773223000170'
    assert provider.cnpj(with_mask=True) == '77.732.230/0001-70'


# Generated at 2022-06-21 15:23:06.120595
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of BrazilSpecProvider class.
    """

    from random import Random
    from mimesis.enums import Gender

    seed = Random().getrandbits(128)
    bsp = BrazilSpecProvider(seed)

    assert len(bsp.cpf()) == 14

    assert bsp.cpf(with_mask=True) == '003.863.774-80'

    bsp = BrazilSpecProvider(seed, gender=Gender.MALE)
    assert len(bsp.cpf()) == 14
    assert bsp.cpf(with_mask=False) == '6386377480'

    bsp = BrazilSpecProvider(seed, gender=Gender.FEMALE)
    assert len(bsp.cpf()) == 14

# Generated at 2022-06-21 15:23:09.512720
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    brazil_provider = BrazilSpecProvider(seed = 0)
    assert brazil_provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-21 15:23:24.569557
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider == BrazilSpecProvider.__class__
    assert type(BrazilSpecProvider) == type


# Generated at 2022-06-21 15:23:27.515335
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=42)
    str_cpf = provider.cpf()
    assert str_cpf == '077.871.165-71'


# Generated at 2022-06-21 15:23:32.472536
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method cnpj of class BrazilSpecProvider."""
    cnpj_list = ['44.398.813/0001-01', '39.543.879/0001-03', '11.587.446/0001-06']
    provider = BrazilSpecProvider()
    assert provider.cnpj(with_mask=True) in cnpj_list


# Generated at 2022-06-21 15:23:33.016757
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:23:36.773059
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test method cpf of class BrazilSpecProvider."""
    gen = BrazilSpecProvider()
    output = gen.cpf()
    assert len(output) == 14
    assert output[3] == '.'
    assert output[7] == '.'
    assert output[11] == '-'


# Generated at 2022-06-21 15:23:40.048427
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj()
    assert len(cnpj) == 18
    assert '.' in cnpj
    assert '/' in cnpj
    assert '-' in cnpj


# Generated at 2022-06-21 15:23:50.962932
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.biodata import BioData
    from mimesis.providers.address import Address
    
    #given
    person = Person('pt_BR')
    bioData = BioData('pt_BR')
    address = Address('pt_BR')
    cpf = BrazilSpecProvider().cpf()
    cnpj = BrazilSpecProvider().cnpj()
    
    #when
    name = person.full_name(gender=Gender.MALE)
    bio = bioData.bio(gender=Gender.MALE)
    country = address.country_code()
    address = address.address()
    city = address.split()[-2].split('-')[0]

# Generated at 2022-06-21 15:23:52.078729
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-21 15:23:56.947239
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len( BrazilSpecProvider().cnpj() ) == 18
    assert len( BrazilSpecProvider().cnpj( with_mask=False ) ) == 14
    assert BrazilSpecProvider().cnpj( with_mask=False ).isdigit() == True

# Generated at 2022-06-21 15:23:58.882086
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    assert b.cpf() == '409.832.923-58'


# Generated at 2022-06-21 15:24:27.479639
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:24:28.637039
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert obj.provider == 'brazil_provider'

# Generated at 2022-06-21 15:24:29.614608
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    pass


# Generated at 2022-06-21 15:24:30.753918
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:24:32.174318
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()



# Generated at 2022-06-21 15:24:36.501105
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_cnpj = BrazilSpecProvider()
    cnpj_formatado = brazil_cnpj.cnpj(with_mask=True)
    assert cnpj_formatado == cnpj_formatado


# Generated at 2022-06-21 15:24:37.379186
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() is not None

# Generated at 2022-06-21 15:24:45.150770
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf = b.cpf()

    assert isinstance(cpf, str)
    # Check that the lenght of the string
    assert len(cpf) == 14
    # Check that the mask is correct
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    # Check that the verifying digit is correct
    # Check for the first digit

# Generated at 2022-06-21 15:24:47.243172
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    Test
    """
    assert len(BrazilSpecProvider().cnpj(with_mask=True)) == 18

if __name__ == '__main__':
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-21 15:24:55.346821
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.builtins import BrazilSpecProvider
    b = BrazilSpecProvider()

    b.cpf()

    # Unit test for method cnpj of class BrazilSpecProvider
    def test_BrazilSpecProvider_cnpj():
        from mimesis.enums import Gender
        from mimesis.builtins import BrazilSpecProvider

        b = BrazilSpecProvider()
        b.cnpj()

# Generated at 2022-06-21 15:26:02.833847
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Unit test for method BrazilSpecProvider.cpf()
    x = BrazilSpecProvider()
    cpf = x.cpf()
    print(cpf)

    # Unit test for method BrazilSpecProvider.cnpj()
    y = BrazilSpecProvider()
    cnpj = y.cnpj()
    print(cnpj)


# Generated at 2022-06-21 15:26:05.768843
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # given the BrazilSpecProvider object
    pt_br_provider = BrazilSpecProvider()

    # when call the method cpf
    result = pt_br_provider.cpf()

    # then the result should be one string
    assert type(result) == str

# Generated at 2022-06-21 15:26:08.096843
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    import uuid
    seed = uuid.uuid4()
    bsp = BrazilSpecProvider(seed=seed)
    print(bsp)

# Generated at 2022-06-21 15:26:10.107272
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider.cpf() == "474.604.153-17"


# Generated at 2022-06-21 15:26:12.149955
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    _BrazilSpecProvider = BrazilSpecProvider()
    assert _BrazilSpecProvider is not None


# Generated at 2022-06-21 15:26:23.573332
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pt-br')
    d1 = p.cpf()
    d2 = p.cpf(with_mask=False)
    d3 = p.cpf()
    d4 = p.cpf(with_mask=False)
    d5 = p.cpf()
    d6 = p.cpf(with_mask=False)
    d7 = p.cpf()
    d8 = p.cpf(with_mask=False)
    d9 = p.cpf()
    d10 = p.cpf(with_mask=False)

    assert d1 != d2 and d2 != d3 and d3 != d4 and d4 != d5
    assert d5 != d6 and d

# Generated at 2022-06-21 15:26:26.384771
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj() method of BrazilSpecProvider class."""
    provider = BrazilSpecProvider('123456789')
    cnpj = provider.cnpj()
    assert cnpj == '36.711.243/0001-00'



# Generated at 2022-06-21 15:26:38.346507
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    from mimesis.enums import Gender

    brazil_provider = BrazilSpecProvider()

    assert brazil_provider.cpf(with_mask=True) == '004.811.227-06'
    assert brazil_provider.cpf(with_mask=True) == '132.789.189-67'
    assert brazil_provider.cpf(with_mask=True) == '938.125.696-72'
    assert brazil_provider.cpf(with_mask=True) == '977.907.216-08'
    assert brazil_provider.cpf(with_mask=True) == '904.923.995-03'

# Generated at 2022-06-21 15:26:43.591547
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    cnpj = cnpj[0:2] + cnpj[3:6] + cnpj[7:10] + cnpj[11:15] + cnpj[16:]
    for digit in cnpj:
        assert digit.isdecimal()
    assert len(cnpj) == 14


# Generated at 2022-06-21 15:26:44.841047
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:29:19.030299
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=5)
    result = provider.cnpj()
    assert result == "87.504.871/0001-81"



# Generated at 2022-06-21 15:29:20.881440
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=True) == '362.657.618-32'


# Generated at 2022-06-21 15:29:24.074608
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert isinstance(cnpj, str)
    assert len(cnpj) == 18
    assert len(bsp.cnpj(with_mask=False)) == 14



# Generated at 2022-06-21 15:29:26.373026
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)
    assert isinstance(provider.cpf(), str)
    assert isinstance(provider.cnpj(), str)

# Generated at 2022-06-21 15:29:28.900256
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    p = BrazilSpecProvider()
    assert len(p.cpf()) == 14
    assert len(p.cnpj()) == 18
        

# Generated at 2022-06-21 15:29:32.828050
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    seed = 'test_BrazilSpecProvider_cpf'
    provider = BrazilSpecProvider(seed=seed)
    assert provider.cpf() == '601.182.090-30'



# Generated at 2022-06-21 15:29:39.908997
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    obj = BrazilSpecProvider()
    assert obj.cpf() is not None
    assert obj.cpf()[3] == '.'
    assert obj.cpf()[7] == '.'
    assert obj.cpf()[11] == '-'
    assert obj.cpf(False) is not None
    assert obj.cnpj() is not None
    assert obj.cnpj()[2] == '.'
    assert obj.cnpj()[6] == '.'
    assert obj.cnpj()[10] == '/'
    assert obj.cnpj()[15] == '-'
    assert obj.cnpj(False) is not None

# Generated at 2022-06-21 15:29:42.224983
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'
    assert BrazilSpecProvider().cpf() == '001.137.297-40'


# Generated at 2022-06-21 15:29:45.903546
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for BrazilSpecProvider.cnpj
    """
    import re

    br = BrazilSpecProvider()
    for i in range(10):
        cnpj = br.cnpj()
        assert re.match(r'\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}', cnpj)


# Generated at 2022-06-21 15:29:47.071989
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrSP = BrazilSpecProvider()
    assert (isinstance(BrSP, BrazilSpecProvider))

