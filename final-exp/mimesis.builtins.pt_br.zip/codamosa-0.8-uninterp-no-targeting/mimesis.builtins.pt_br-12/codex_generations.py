

# Generated at 2022-06-21 15:22:02.405279
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    brazil_provider = BrazilSpecProvider()
    assert brazil_provider
    assert brazil_provider._data_provider
    assert brazil_provider._data_provider.locale == 'pt-br'


# Generated at 2022-06-21 15:22:04.265668
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil_provider import BrazilSpecProvider
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-21 15:22:14.576661
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    assert len(provider.cnpj(False)) == 14
    assert len(provider.cnpj()) == 18
    cnpjMask = re.compile(r'[\d]{2}[.][\d]{3}[.][\d]{3}[/][\d]{4}[-][\d]{2}')
    assert cnpjMask.match(provider.cnpj(True)) != None

# Generated at 2022-06-21 15:22:16.925577
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('Testando o construtor')
    provider = BrazilSpecProvider()
    print('...')


# Generated at 2022-06-21 15:22:20.033359
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    p = BrazilSpecProvider()
    assert p.cpf() == '001.137.297-40'
    assert p.cpf(with_mask=False) == '00113729740'


# Generated at 2022-06-21 15:22:22.940368
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:22:32.068178
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.identity import Identity
    from mimesis.providers.address import Address
    from mimesis.builtins import BrazilSpecProvider
    import time

    seed = 'brazil_provider'
    start_time = time.time()
    test_time = 0
    n = int(input('Enter number of test:'))
    while n != 0:
        i = int(input('Enter the number of CNPJ: '))
        while i != 0:
            b = BrazilSpecProvider(seed)
            cnpj = b.cnpj()
            print(cnpj)
            i = i - 1
        print("--- %s seconds ---" % (time.time() - start_time))

# Generated at 2022-06-21 15:22:35.530770
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18


# Generated at 2022-06-21 15:22:37.080428
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test BrazilSpecProvider"""
    BrazilSpecProvider()

# Generated at 2022-06-21 15:22:38.923522
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Should create instance of BrazilSpecProvider
    bsp = BrazilSpecProvider()
    # Should create instance of BrazilSpecProvider with seed
    bsp = BrazilSpecProvider(seed=123)

# Generated at 2022-06-21 15:22:56.146998
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider().cpf())
    print(BrazilSpecProvider().cpf(with_mask=False))

    print(BrazilSpecProvider().cnpj())
    print(BrazilSpecProvider().cnpj(with_mask=False))

test_BrazilSpecProvider()

# Generated at 2022-06-21 15:23:02.839271
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider_1 = BrazilSpecProvider(seed=1)
    provider_2 = BrazilSpecProvider(seed=2)

    # Test for CNPJ with mask
    assert provider_1.cnpj(with_mask=True) == '77.732.230/0001-70'

    # Test for CNPJ without mask
    assert provider_2.cnpj(with_mask=False) == '67346715000128'



# Generated at 2022-06-21 15:23:09.518391
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bs = BrazilSpecProvider()

    cpf = bs.cpf()
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'
    assert cpf[12:].isdigit()

    cpf = bs.cpf(with_mask=False)
    assert len(cpf) == 11
    assert cpf.isdigit()


# Generated at 2022-06-21 15:23:11.882638
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print(provider.cpf())
    print(provider.cnpj())


if __name__ == "__main__":
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:23:12.805980
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider


# Generated at 2022-06-21 15:23:15.307764
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    brazil.cpf()
    brazil.cpf(False)
    brazil.cpf(True)

test_BrazilSpecProvider_cpf()


# Generated at 2022-06-21 15:23:16.161145
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf()

# Generated at 2022-06-21 15:23:27.207921
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.utils import random_int
    import re

    provider = BrazilSpecProvider()

    for _ in range(10):
        for cnpj_len in [14, 18]:
            cnpj = provider.cnpj(with_mask=(cnpj_len == 18))
            assert len(cnpj) == cnpj_len
            regex = r'^[0-9]{2}.[0-9]{3}.[0-9]{3}/[0-9]{4}-[0-9]{2}$'
            assert re.match(regex, cnpj)

    for _ in range(random_int(100)):
        cnpj = provider.cnpj()
        assert len(cnpj) == 14

# Generated at 2022-06-21 15:23:30.393217
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    expected_cpf = "500.595.890-89"
    assert provider.cpf(False) == expected_cpf
    assert provider.cpf() == expected_cpf


# Generated at 2022-06-21 15:23:32.472310
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    with pytest.raises(Exception):
        bsp.cnpj(with_mask=False)

# Generated at 2022-06-21 15:24:00.924666
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider
    assert provider.cpf()
    assert provider.cnpj()

# Generated at 2022-06-21 15:24:02.667044
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    b = BrazilSpecProvider()
    b.cnpj() == '34.499.166/0001-56'


# Generated at 2022-06-21 15:24:07.961013
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender

    bsp = BrazilSpecProvider()

    cpf = bsp.cpf()
    assert len(cpf) == 14
    assert cpf == bsp.cpf(True)

    cpf_n = bsp.cpf(False)
    assert len(cpf_n) == 11

    ccpf = bsp.cpf(False)[:9] + bsp.cpf(False)[10:]
    assert cpf == bsp.cpf(True, ccpf)

    try:
        bsp.cpf(ccpf='asd')
    except TypeError as e:
        assert str(e) == 'ccpf must be string.'



# Generated at 2022-06-21 15:24:10.200377
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().cpf() is not None
    assert BrazilSpecProvider().cnpj() is not None

# Generated at 2022-06-21 15:24:12.794335
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bi = BrazilSpecProvider()
    assert bi.cpf() == '864.959.534-96'
    assert bi.cnpj() == "72.300.165/0001-53"

# Generated at 2022-06-21 15:24:14.060931
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 15:24:17.811190
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Arrange
    from mimesis.enums import Gender
    from mimesis.schema import Field

    # Act
    bsp = BrazilSpecProvider()

    # Assert
    assert bsp.gender(gender=Gender.MALE)
    assert bsp.cpf()
    assert bsp.cnpj()

    assert bsp.create(schema=[Field('cpf')]) == {'cpf': '835.578.826-01'}

# Generated at 2022-06-21 15:24:27.783984
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil_provider = BrazilSpecProvider("1234")
    assert brazil_provider.locale == "pt-br"
    assert str(brazil_provider.seed) == "1234"
    assert repr(brazil_provider) == "<BrazilSpecProvider('pt-br')>"

    brazil_provider = BrazilSpecProvider("1234")
    assert brazil_provider.spec().locale == "pt-br"
    assert str(brazil_provider.spec().seed) == "1234"
    assert repr(brazil_provider.spec()) == "<BrazilSpecProvider('pt-br')>"
    assert brazil_provider.spec().Provider.Meta.name == 'brazil_provider'


# Generated at 2022-06-21 15:24:31.758492
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    digits = "".join([cpf[0], cpf[1], cpf[2], cpf[4], cpf[5], cpf[6], cpf[8], cpf[9], cpf[10], cpf[12], cpf[13], cpf[14]])
    for index, digit in enumerate(digits):
        assert (int(digit) >= 0 and int(digit) <= 9)
    assert(len(cpf) == 14)


# Generated at 2022-06-21 15:24:33.773846
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    result = bsp.cnpj()
    assert len(result) == 18


# Generated at 2022-06-21 15:25:33.247966
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazilSpecProvider = BrazilSpecProvider()
    assert brazilSpecProvider.cpf(True)
    assert brazilSpecProvider.cpf(False)
    assert brazilSpecProvider.cnpj(True)
    assert brazilSpecProvider.cnpj(False)

# Generated at 2022-06-21 15:25:43.556583
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider.cnpj(False)) >= 14
    assert len(BrazilSpecProvider.cnpj(True)) >= 18
    assert BrazilSpecProvider.cnpj(True) == "00.968.007/0001-31"
    assert BrazilSpecProvider.cnpj(True) == "85.858.704/0001-06"
    assert BrazilSpecProvider.cnpj(True) == "35.984.407/0001-27"
    assert BrazilSpecProvider.cnpj(True) == "04.657.941/0001-80"
    assert BrazilSpecProvider.cnpj(True) == "00.958.788/0001-20"


# Generated at 2022-06-21 15:25:45.159372
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert cnpj is not None

# Generated at 2022-06-21 15:25:46.413769
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor BrazilSpecProvider."""
    bp = BrazilSpecProvider()

# Generated at 2022-06-21 15:25:48.757092
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj(with_mask=False)
    assert cnpj == '72963922288358'

# Generated at 2022-06-21 15:25:50.171239
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.__class__.__name__ == 'BrazilSpecProvider'


# Generated at 2022-06-21 15:25:54.884178
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    '''
    Test case for method cpf of BrazilSpecProvider class
    '''
    bsp = BrazilSpecProvider()

    # Test 1
    cpf = bsp.cpf(False)

    assert(len(cpf) == 11)
    assert(cpf[9:11] == str(int(cpf[:9]) % 11))

    # Test 2
    cpf = bsp.cpf()

    assert(len(cpf) == 14)
    assert(cpf[12:14] == str(int(cpf[:9] + cpf[10:12]) % 11))


# Generated at 2022-06-21 15:25:57.017285
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Test cpf
    b = BrazilSpecProvider()
    cpf = b.cpf()
    assert(len(cpf) == 14)


# Generated at 2022-06-21 15:26:06.257829
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    # Create BrazilSpecProvider with locale 'pt-br'
    provider = BrazilSpecProvider(locale='pt-br')

    # Get a cnpj with mask
    cnpj1 = provider.cnpj(with_mask=True)
    # Get a cnpj without mask
    cnpj2 = provider.cnpj(with_mask=False)
    # Get a cpf with mask
    cpf1 = provider.cpf(with_mask=True)
    # Get a cpf without mask
    cpf2 = provider.cpf(with_mask=False)

    assert cnpj1 != cnpj2
    assert cpf1 != cpf2

    # Split cnpj1 with . and /
    cnpj1_split_dot_slash = cnpj1.split('.', 2)
   

# Generated at 2022-06-21 15:26:09.358246
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil= BrazilSpecProvider()
    sample_cpf = brazil.cpf()
    assert(len(sample_cpf) == 14)
    assert(sample_cpf[3] == '.')
    assert(sample_cpf[7] == '.')
    assert(sample_cpf[11] == '-')


# Generated at 2022-06-21 15:28:48.114888
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() not in ('11111111111', '22222222222', '33333333333', '44444444444', '55555555555', '66666666666', '77777777777', '88888888888', '99999999999')
    assert BrazilSpecProvider().cpf(with_mask = True) not in ('111.111.111-11', '222.222.222-22', '333.333.333-33', '444.444.444-44', '555.555.555-55', '666.666.666-66', '777.777.777-77', '888.888.888-88', '999.999.999-99')

# Generated at 2022-06-21 15:28:53.017956
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    cnpj = provider.cnpj(True)
    assert len(cnpj) == 18
    assert '.' in cnpj
    assert '/' in cnpj
    assert '-' in cnpj
#Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-21 15:28:57.437428
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    cpf = bsp.cpf()
    assert cpf
    assert len(cpf) == 14
    assert cpf[3] == '.'
    assert cpf[7] == '.'
    assert cpf[11] == '-'


# Generated at 2022-06-21 15:28:58.374060
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-21 15:29:00.497042
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider(seed=1)
    assert '058.872.972-69' == provider.cpf()
    assert provider.cpf(with_mask=False) == '05887297269'


# Generated at 2022-06-21 15:29:04.092493
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilianSpecProvider

    instance = BrazilianSpecProvider()
    cpf_masked = instance.cpf()
    assert len(cpf_masked) == 14
    assert cpf_masked[3] == '.'
    assert cpf_masked[7] == '.'
    assert cpf_masked[11] == '-'
    cpf_unmasked = instance.cpf(False)
    assert len(cpf_unmasked) == 11


# Generated at 2022-06-21 15:29:08.199925
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test class."""
    provider =  BrazilSpecProvider()
    assert provider.cpf() == '001.137.297-40'
    assert provider.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-21 15:29:11.604537
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_spec_provider = BrazilSpecProvider(seed=1)
    for _ in range(5):
        print(brazil_spec_provider.cpf())


# Generated at 2022-06-21 15:29:21.359478
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider"""
    p = BrazilSpecProvider()
    cpf_1 = p.cpf()
    cpf_2 = p.cpf(True)
    cpf_3 = BrazilSpecProvider().cpf()
    cpf_4 = BrazilSpecProvider().cpf()
    assert len(cpf_1) == 11
    assert len(cpf_2) == 14
    assert cpf_1 == cpf_2[:3]+cpf_2[4:7]+cpf_2[8:11]+cpf_2[12:]
    assert cpf_1 != cpf_3 != cpf_4


# Generated at 2022-06-21 15:29:23.126388
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    cpf = provider.cpf()
    assert True
