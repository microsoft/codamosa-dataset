

# Generated at 2022-06-21 15:22:02.409926
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis import BrazilSpecProvider
    from mimesis.enums import Gender
    from mimesis.schema import Field, Schema

    schema = Schema(BrazilSpecProvider)
    schema.add_field('cpf', Field('cpf'))
    data = schema.create(iterations=5)
    print(data)


# Generated at 2022-06-21 15:22:08.529458
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    for _ in range(10):
        assert bsp.cpf() != bsp.cpf()
        with_mask = bsp.cpf(with_mask=True)
        assert len(with_mask) == 14
        assert with_mask[3] == '.'
        assert with_mask[7] == '.'
        assert with_mask[11] == '-'
        without_mask = bsp.cpf(with_mask=False)
        assert len(without_mask) == 11


# Generated at 2022-06-21 15:22:09.659524
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert len(BrazilSpecProvider().cpf()) == 14


# Generated at 2022-06-21 15:22:17.278022
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test constructor of class BrazilSpecProvider."""
    data_provider = BrazilSpecProvider()
    #assert isinstance(data_provider.random, Random)
    assert data_provider._validate_cpf('71342617011')
    assert data_provider._validate_cnpj('7466982000118')
    #assert data_provider.meta.name == 'brazil_provider'


# Generated at 2022-06-21 15:22:19.985109
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = '29.904.934/0001-94'
    assert provider.cnpj() == cnpj

# Generated at 2022-06-21 15:22:23.329367
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider().cnpj())
    print(BrazilSpecProvider().cpf())

if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:22:25.304606
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert brazil_provider.cpf() == '015.105.819-37'


# Generated at 2022-06-21 15:22:29.672180
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj method of BrazilSpecProvider."""
    b = BrazilSpecProvider()
    cnpj = b.cnpj()
    correct = cnpj[12:] == '{0:02d}'.format(
        int(cnpj[:12]) % 97)
    assert correct


# Generated at 2022-06-21 15:22:31.975724
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.__class__.__name__ == 'BrazilSpecProvider'

# Generated at 2022-06-21 15:22:34.195938
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print ("Testing constructor ...")
    print(BrazilSpecProvider())


# Generated at 2022-06-21 15:22:41.148477
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    pass

# Generated at 2022-06-21 15:22:48.872895
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
  """Test BrazilSpecProvider.cnpj()."""
  import json
  with open('data/br.json') as f:
    data = json.load(f)
  data = data['cnpj']
  n = len(data)

  if False:
    for i in range(n):
      cnpj = BrazilSpecProvider().cnpj()
      print("{} : {}".format(cnpj, cnpj in data))
      assert cnpj in data
    print("--> test_BrazilSpecProvider_cnpj() PASSED")
  else:
    print("--> test_BrazilSpecProvider_cnpj() SKIPPED")



# Generated at 2022-06-21 15:22:53.602212
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Tests cpf method of BrazilSpecProvider"""
    bsp = BrazilSpecProvider()
    assert len(bsp.cpf()) == 14
    assert bsp.cpf()[-2] == '-'
    assert bsp.cpf()[3] == '.'
    assert bsp.cpf()[7] == '.'


# Generated at 2022-06-21 15:22:57.143115
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    print(brazil_spec_provider.cnpj(with_mask=False))
    print(brazil_spec_provider.cnpj(with_mask=True))


# Generated at 2022-06-21 15:22:59.275807
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    count = 0
    while count < 10:
        bsp.cnpj()
        count += 1

# Generated at 2022-06-21 15:23:05.126355
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider._data['states'][0] == 'Acre'
    assert provider._data['vehicle_types'][0] == 'Carro'
    assert provider._data['blood_types'][0] == 'A+'
    assert provider._data['sexes'][0] == 'M'

# Generated at 2022-06-21 15:23:09.021031
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test CPF provider."""
    spec_provider = BrazilSpecProvider()
    assert len(spec_provider.cpf()) == 14    # with mask
    assert len(spec_provider.cpf(with_mask=False)) == 11



# Generated at 2022-06-21 15:23:13.176287
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    test_list = []
    for i in range(10):
        test_list.append(BrazilSpecProvider().cnpj(with_mask = True))
    first = test_list[0]
    same = 0
    while i < 10 and test_list[i] == first:
        same = same + 1
        i = i + 1
    assert(same == 0)


# Generated at 2022-06-21 15:23:16.160554
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print(BrazilSpecProvider().cpf(with_mask=False))
    print(BrazilSpecProvider().cnpj(with_mask=False))

# Generated at 2022-06-21 15:23:19.373556
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    for i in range(4):
        assert provider.cpf()
        assert provider.cpf(with_mask=False)



# Generated at 2022-06-21 15:23:39.678855
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    #não faz sentido testar o cpf e o cnpj, pois não tem como validar se os resultados estão corretos
    #testando o nome nacionalidade
    assert provider.nationality() == 'Brasileiro'
    #testando uf
    assert provider.state() in ('AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO')
    #testando a cidade

# Generated at 2022-06-21 15:23:42.069096
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider(seed=42)
    test = brazil.cnpj()
    assert test == "56.285.683/0001-59"

# Generated at 2022-06-21 15:23:47.440499
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.person.pt_br import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    cpf_list = [bsp.cpf(with_mask=True) for _ in range(100)]
    assert all([('-' in cpf) for cpf in cpf_list])


# Generated at 2022-06-21 15:23:49.113908
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    bsp = BrazilSpecProvider()
    print(bsp.cnpj())
    print(bsp.cpf())

# Generated at 2022-06-21 15:23:51.771932
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """ test cnpj method of BrazilSpecProvider() """
    cnpj_generador = BrazilSpecProvider().cnpj()
    assert(len(cnpj_generador) == 18)


# Generated at 2022-06-21 15:23:56.530130
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test case and print result for method cnpj of BrazilSpecProvider."""
    cnpj = BrazilSpecProvider()
    print(cnpj.cnpj())  # 77.732.230/0001-70



# Generated at 2022-06-21 15:23:59.763734
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_provider = BrazilSpecProvider()
    cnpj = BrazilSpecProvider.cnpj(brazil_provider, with_mask=True)
    if len(cnpj) == 18:
        print("Success")
    else:
        print("Failure")


# Generated at 2022-06-21 15:24:01.784967
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    This function tests the method BrazilSpecProvider.cnpj()
    Call this function and print the result
    """
    print(BrazilSpecProvider().cnpj())

# Generated at 2022-06-21 15:24:07.802245
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.enums import Gender
    from mimesis.providers.base import BaseSpecProvider
    from mimesis.providers.br.br_provider import BrazilSpecProvider as Provider
    from mimesis.specifiers import Specifier
    from mimesis.types import Code

    provider = Provider()
    specifier = Specifier(provider, gender=Gender.MALE, code=Code.CPF)

    assert isinstance(provider, BaseSpecProvider)
    assert isinstance(provider.seed, int)
    assert isinstance(provider.datetime.seed, int)

    mask = False
    for i in range(0, 1000):
        assert provider.cnpj(mask) is not None
        assert isinstance(provider.cnpj(mask), str)

    mask = True

# Generated at 2022-06-21 15:24:09.771979
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider != None


# Generated at 2022-06-21 15:24:37.453679
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():

    b = BrazilSpecProvider()
    return b.cpf()


# Generated at 2022-06-21 15:24:44.257157
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the Brazilian data provider."""
    import sys
    import unittest
    import re

    sys.path.append(".")
    pattern_cpf_format = re.compile(r'\d{3}\.\d{3}\.\d{3}-\d{2}')
    pattern_cnpj_format = re.compile(r'\d{2}\.\d{3}\.\d{3}/\d{4}\-\d{2}')

    class BrazilSpecProviderTestCase(unittest.TestCase):

        def setUp(self):
            self.provider = BrazilSpecProvider()

        def test_cpf(self):
            cpf = self.provider.cpf()

# Generated at 2022-06-21 15:24:50.108003
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test cpf method of BrazilSpecProvider class."""
    provider = BrazilSpecProvider()

    assert len(provider.cpf()) == 14

    assert len(provider.cpf(with_mask=False)) == 11

    assert len(provider.cnpj()) == 18

    assert len(provider.cnpj(with_mask=False)) == 14

# Generated at 2022-06-21 15:24:52.298065
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    data = BrazilSpecProvider();
    cpf = data.cpf()
    assert len(cpf) == 14


# Generated at 2022-06-21 15:24:55.386853
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj_str = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(cnpj_str) == 14
    assert cnpj_str.isdigit()

# Generated at 2022-06-21 15:25:04.059254
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test 1
    a_brazil = BrazilSpecProvider()
    cnpj = a_brazil.cnpj(True)
    assert(len(cnpj) == 18)
    assert(cnpj[2:3] == '.')
    assert(cnpj[6:7] == '.')
    assert(cnpj[10:11] == '/')
    assert(cnpj[15:16] == '-')

    # Test 2
    a_brazil = BrazilSpecProvider()
    cnpj = a_brazil.cnpj(False)
    assert(len(cnpj) == 14)


# Generated at 2022-06-21 15:25:06.511166
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.cnpj(with_mask=True) == '85.927.734/0001-33'

# Generated at 2022-06-21 15:25:10.611931
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    from mimesis.data import BRAZIL_CNPJS
    from mimesis.providers import BrazilSpecProvider

    bsp = BrazilSpecProvider()
    data = bsp.cnpj()
    assert data in BRAZIL_CNPJS
    data = bsp.cnpj(with_mask=False)
    assert data not in BRAZIL_CNPJS



# Generated at 2022-06-21 15:25:14.091228
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Get a random CPF without mask."""
    bsp = BrazilSpecProvider()
    for i in range(10):
        print(bsp.cpf(False))



# Generated at 2022-06-21 15:25:16.133730
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert len(provider.cpf()) == 14
    assert type(provider.cpf()) == str


# Generated at 2022-06-21 15:26:25.329497
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    b = BrazilSpecProvider()
    cpf1 = b.cpf()
    cpf2 = b.cpf(with_mask=False)

    assert len(cpf1) == 14
    assert len(cpf2) == 11

    assert cpf1.count(".") == 2
    assert cpf1.count("-") == 1

    assert cpf1[3] == "."
    assert cpf1[7] == "."
    assert cpf1[11] == "-"


# Generated at 2022-06-21 15:26:27.331450
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test whether BrazilSpecProvider.cpf correctly generates a CPF."""
    from mimesis import BrazilSpecProvider
    assert BrazilSpecProvider().cpf() == '008.739.511-40'


# Generated at 2022-06-21 15:26:31.597412
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    assert len(cnpj) == 19
    assert bsp.cnpj().__class__ == str


# Generated at 2022-06-21 15:26:41.923438
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person('pt-br')

    def callback():
        return p.full_name('male', Gender.MALE)

    human = BrazilSpecProvider(callback)

    # Unit test for cpf method
    for i in range(0, 100):
        cpf = human.cpf(with_mask=True)
        assert len(cpf) == 14
        assert isinstance(cpf, str)

    # Unit test for cnpj method
    for i in range(0, 100):
        cnpj = human.cnpj(with_mask=False)
        assert len(cnpj) == 14
        assert isinstance(cnpj, str)

# Generated at 2022-06-21 15:26:44.617088
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
#    assert bsp.cpf() == '093.306.809-57'
    assert bsp.cpf() != '093.306.809-57'

# Generated at 2022-06-21 15:26:49.787682
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    p = BrazilSpecProvider()
    cnpj = p.cnpj()
    assert isinstance(cnpj[:2], str)
    assert isinstance(cnpj[2:5], str)
    assert isinstance(cnpj[5:8], str)
    assert isinstance(cnpj[8:12], str)
    assert isinstance(cnpj[12:], str)


# Generated at 2022-06-21 15:26:56.171168
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf().count(".") == 2
    assert provider.cpf().count("-") == 1
    assert provider.cnpj().count(".") == 2
    assert provider.cnpj().count("/") == 1
    assert provider.cnpj().count("-") == 1
    assert provider.cnpj(with_mask=False).count(".") == 0
    assert provider.cnpj(with_mask=False).count("/") == 0
    assert provider.cnpj(with_mask=False).count("-") == 0



# Generated at 2022-06-21 15:26:58.590829
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert isinstance(provider, BrazilSpecProvider)
    assert isinstance(provider, BaseSpecProvider)



# Generated at 2022-06-21 15:27:08.309788
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins.brazil import BrazilSpecProvider
    bsp = BrazilSpecProvider()
    for i in range(20):
        cnpj = bsp.cnpj()
        assert len(cnpj) == 18
        assert cnpj[2] == '.'
        assert cnpj[6] == '.'
        assert cnpj[10] == '/'
        assert cnpj[15] == '-'
        for j in range(0, len(cnpj)):
            assert cnpj[j] in ("0123456789."), "Invalid character found in cnpj"

# Generated at 2022-06-21 15:27:10.902915
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert BrazilSpecProvider().cnpj() == '80.224.575/0001-30'
    assert BrazilSpecProvider().cnpj(False) == '80224575000130'


# Generated at 2022-06-21 15:29:35.696657
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    result = BrazilSpecProvider().cnpj(with_mask=False)
    assert len(result) == 14
    assert result.isdigit()
    # TODO: Add more tests


# Generated at 2022-06-21 15:29:39.418541
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert BrazilSpecProvider().cpf() == "758.095.959-70"
    assert BrazilSpecProvider().cpf(with_mask=False) == "75809595970"
    assert BrazilSpecProvider().cpf() == "590.819.225-05"
    assert BrazilSpecProvider().cpf(with_mask=False) == "590819225"


# Generated at 2022-06-21 15:29:44.771149
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """This test checks if the method cnpj of the class BrazilSpecProvider
    is working fine."""
    brazilSpecProvider = BrazilSpecProvider()
    newCnpj = brazilSpecProvider.cnpj()
    assert len(newCnpj) == 18
    assert newCnpj[2] == '.'
    assert newCnpj[6] == '.'
    assert newCnpj[10] == '/'
    assert newCnpj[15] == '-'
    assert newCnpj[2:6] == newCnpj[13:17]

# Generated at 2022-06-21 15:29:51.353614
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    import os
    from mimesis.builtins.brazil import BrazilSpecProvider
    from mimesis.enums import Gender
    import mimesis.schema as schema

    data = schema.Schema(
        BrazilSpecProvider(os.urandom(1024)), seed=os.urandom(1024)
    )
    # without-mask
    actual_result = data.cpf(with_mask=False)

    assert len(actual_result) == 11

    # with-mask
    actual_result_2 = data.cpf(with_mask=True)
    assert len(actual_result_2) == 14


# Generated at 2022-06-21 15:29:55.748048
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()

    # Verify if the type returned is correct.
    assert isinstance(provider.cpf(), str)

    # Verify if the cpf mask is correct.
    cpf = provider.cpf(with_mask=True)
    assert len(cpf) == 14
    assert provider.cpf(with_mask=True) == cpf


# Generated at 2022-06-21 15:30:03.977085
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test for constructor of BrazilSpecProvider."""
    test = BrazilSpecProvider(seed = 0)
    # Check if random.seed has been correctly set
    assert(test._seed == 0)

# Generated at 2022-06-21 15:30:05.863087
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    print("cnpj = " + cnpj)
    assert len(cnpj) == 18

# Generated at 2022-06-21 15:30:07.112479
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    result = BrazilSpecProvider().cpf()
    assert isinstance(result, str)


# Generated at 2022-06-21 15:30:08.654017
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test if method cnpj of BrazilSpecProvider returns the right value."""
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'

# Generated at 2022-06-21 15:30:12.128134
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bz = BrazilSpecProvider()
    assert bz.cnpj() == '22.706.152/0001-60'
    assert bz.cnpj(with_mask=False) == '22706152000160'
