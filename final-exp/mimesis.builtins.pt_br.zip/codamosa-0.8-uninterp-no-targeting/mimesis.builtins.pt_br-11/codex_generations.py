

# Generated at 2022-06-21 15:22:02.322987
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider(seed=444)
    print("True cnpj: " + provider.cnpj())
    seed = 444
    provider = BrazilSpecProvider(seed=seed)
    assert provider.cnpj() == '93875472000154'


# Generated at 2022-06-21 15:22:03.674195
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print(BrazilSpecProvider().cnpj())

# Generated at 2022-06-21 15:22:06.009049
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj."""
    assert BrazilSpecProvider().cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-21 15:22:08.530929
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider()
    print("-------------------------------")
    print("Teste de cpf")
    print("CPF: ", bsp.cpf())
    print("-------------------------------")


# Generated at 2022-06-21 15:22:09.002658
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    BrazilSpecProvider()

# Generated at 2022-06-21 15:22:17.278550
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test."""
    bsp = BrazilSpecProvider()
    for _ in range(100):
        cpf = bsp.cpf()
        assert len(cpf) == 14, 'Not equal 14'
        assert cpf.count('.') == 2, 'Not equal 2'
        assert cpf.count('-') == 1, 'Not equal 1'
        assert cpf.replace('.', '').replace('-', '').isdigit(), 'Not digit'


# Generated at 2022-06-21 15:22:23.714247
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil = BrazilSpecProvider()
    cpf = brazil.cpf()

    first_dv = int(cpf[9])
    second_dv = int(cpf[10])

    cpf_without_dv = [int(i) for i in cpf if i != '.' or i != '-']

    def __get_verifying_digit_cpf(cpf, peso):
        """Calculate the verifying digit for the CNPJ.

            :param cpf: List of integers with the CNPJ.
            :param peso: Integer with the weight for the modulo 11 calculate.
            :returns: The verifying digit for the CNPJ.
        """
        soma = 0
        for index, digit in enumerate(cpf):
            soma += digit * (peso - index)
       

# Generated at 2022-06-21 15:22:26.004986
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brz = BrazilSpecProvider()
    cpf = brz.cpf(with_mask=True)
    print(cpf)


# Generated at 2022-06-21 15:22:29.587907
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """
    Test to make sure that the constructor works.
    """
    try:
        BrazilSpecProvider().cpf()
        BrazilSpecProvider().cnpj()
    except Exception as exception:
        assert False, exception.args
    assert True

# Generated at 2022-06-21 15:22:35.150766
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj."""
    b1 = BrazilSpecProvider()
    cnpj = b1.cnpj(with_mask=True)

    assert cnpj == '77.732.230/0001-70'


# Generated at 2022-06-21 15:22:47.162347
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_provider = BrazilSpecProvider()
    cpf_normal = brazil_provider.cpf()
    cpf_mask = brazil_provider.cpf(with_mask=True)

    assert len(cpf_normal) == 11
    assert cpf_normal == cpf_mask[0:3] + cpf_mask[4:7] + cpf_mask[8:11] + cpf_mask[12:14]


# Generated at 2022-06-21 15:22:48.354844
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    x = BrazilSpecProvider()
    assert x is not None


# Generated at 2022-06-21 15:22:53.863365
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj = bsp.cnpj()
    cnpj_mask = bsp.cnpj(with_mask=True)

    assert len(cnpj) == 14
    assert len(cnpj_mask) == 18
    assert cnpj == cnpj_mask.replace('.', '').replace('/', '').replace('-', '')



# Generated at 2022-06-21 15:22:57.763805
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    '''BrazilSpecProvider.cnpj'''
    provider = BrazilSpecProvider()
    # print(provider.cnpj())
    # Out: "77.732.230/0001-70"
    # print(provider.cnpj(with_mask=False))
    # Out: "7773223000170"

###############################################################################



# Generated at 2022-06-21 15:22:59.650840
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    assert provider.cpf()
    assert provider.cnpj()

# Generated at 2022-06-21 15:23:04.566955
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    print('\n', end='')
    print(BrazilSpecProvider.cnpj.__doc__)
    print('\n')
    for i in range(10):
        print(BrazilSpecProvider().cnpj())
    print('\n')





# Generated at 2022-06-21 15:23:14.245390
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test CNPJ returns a compliant unformatted CNPJ.

    CNPJ is a 14-digit number that conforms to the following format:
        8-4-4-2-2

    """
    # Setup
    br_provider = BrazilSpecProvider()
    # Exercise
    cnpj = br_provider.cnpj(with_mask = False)
    # Verify
    assert len(cnpj) == 14
    assert cnpj[0] in '123456789'
    assert cnpj[1] in '123456789'
    assert cnpj[2] in '1234567890'
    assert cnpj[3] in '1234567890'
    assert cnpj[4] in '1234567890'

# Generated at 2022-06-21 15:23:14.923875
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    pass

# Generated at 2022-06-21 15:23:20.693623
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Create the subject under test
    bsp = BrazilSpecProvider()
    # Run the method under test
    result = bsp.cnpj()
    # Assert that all conditions are met
    assert len(result) == 18
    assert result[2] == '.'
    assert result[6] == '.'
    assert result[10] == '/'
    assert result[15] == '-'

# Generated at 2022-06-21 15:23:22.848089
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    i = BrazilSpecProvider()
    assert i.cnpj() != None
    assert i.cpf() != None

# Generated at 2022-06-21 15:23:30.469446
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()


# Generated at 2022-06-21 15:23:33.224403
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    test_obj = BrazilSpecProvider()
    assert test_obj.cpf().__len__() == 14
    assert test_obj.cpf(False).__len__() == 11


# Generated at 2022-06-21 15:23:34.646651
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert len(BrazilSpecProvider().cnpj()) is 14


# Generated at 2022-06-21 15:23:37.145424
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    cnpj = BrazilSpecProvider().cnpj(False)
    if len(cnpj) != 14:
        print('Test cnpj of class BrazilSpecProvider FAILED')
    

# Generated at 2022-06-21 15:23:40.773363
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """
    This unit test was created for verify validity of cpf method of BrazilSpecProvider.
    """

    assert BrazilSpecProvider().cpf() == '001.137.297-40'
    assert BrazilSpecProvider().cpf(with_mask = False) == '00113729740'


# Generated at 2022-06-21 15:23:41.768222
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()

# Generated at 2022-06-21 15:23:46.169521
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test BrazilSpecProvider's method cnpj."""
    b = BrazilSpecProvider(seed=None)
    result = b.cnpj(True)
    assert result == '77.732.230/0001-70'

# Generated at 2022-06-21 15:23:49.517521
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    brazil_cpf = BrazilSpecProvider(seed=1).cpf(with_mask=True)
    # Cpf should be equal to '001.137.297-40'
    assert brazil_cpf == '001.137.297-40'


# Generated at 2022-06-21 15:23:56.871061
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.providers.brazil import BrazilSpecProvider
    for _ in range(50):
        cpf = BrazilSpecProvider().cpf(with_mask=True)
        assert cpf != ""
        assert len(cpf) == 14
        assert cpf[3] == "."
        assert cpf[7] == "."
        assert cpf[11] == '-'
        assert cpf[3:7] != "...."
        assert cpf[7:11] != "...."
        assert cpf[12:14] != ".."
        assert cpf[12:14] != ".."
        assert cpf[:3] != "000"
        assert cpf[3:6] != "000"
        assert cpf[6:9] != "000"

# Generated at 2022-06-21 15:24:04.816992
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()

    assert len(bsp.cnpj(with_mask=False)) == 14
    assert len(bsp.cnpj(with_mask=True)) == 18

    with_mask_cnpj = bsp.cnpj(with_mask=True)
    without_mask_cnpj = bsp.cnpj(with_mask=False)

    # First digit of without_mask_cnpj must be the same of without_mask_cnpj
    assert without_mask_cnpj[0] == with_mask_cnpj[0]
    # Second digit of without_mask_cnpj must be the same of without_mask_cnpj
    assert without_mask_cnpj[1] == with_mask_cnpj[1]

    # Third digit of without_mask

# Generated at 2022-06-21 15:24:21.700213
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Test for method cpf of class BrazilSpecProvider."""
    obj = BrazilSpecProvider()
    assert len(obj.cpf()) == 14


# Generated at 2022-06-21 15:24:24.360835
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider.
    """
    provider = BrazilSpecProvider(seed=1)
    assert '55.355.711/0151-80' == provider.cnpj()

# Generated at 2022-06-21 15:24:31.224270
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    br_provider = BrazilSpecProvider()
    cnpj = br_provider.cnpj(with_mask=False)
    cnpj_with_mask = br_provider.cnpj(with_mask=True)
    first_dv = get_verifying_digit_cnpj([int(x) for x in cnpj[:-2]], 5)
    second_dv = get_verifying_digit_cnpj([int(x) for x in cnpj], 6)
    assert len(cnpj) == 14 and len(cnpj_with_mask) == 18 and first_dv == cnpj[-2] and second_dv == cnpj[-1]

# Generated at 2022-06-21 15:24:37.991230
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    spec = BrazilSpecProvider()
    # Without mask
    assert len(spec.cpf()) == 11
    assert not spec.cpf(with_mask=False).isdigit()
    # With mask
    assert '.' in spec.cpf(with_mask=True)
    assert '-' in spec.cpf(with_mask=True)
    # Invalid parameter
    with pytest.raises(TypeError):
        spec.cpf(with_mask=None)


# Generated at 2022-06-21 15:24:39.131460
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print(BrazilSpecProvider().cpf())


# Generated at 2022-06-21 15:24:40.537448
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider()
    assert BrazilSpecProvider(seed=123)

# Generated at 2022-06-21 15:24:44.627856
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test cnpj of BrazilSpecProvider"""
    bsp = BrazilSpecProvider()
    cnpj_with_mask = bsp.cnpj()
    assert cnpj_with_mask == '77.732.230/0001-70'
    cnpj_without_mask = bsp.cnpj(False)
    assert cnpj_without_mask == '7773223000170'


# Generated at 2022-06-21 15:24:50.256861
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider"""
    bsp = BrazilSpecProvider()

    cnpj_without_mask_test_values = ['7773223000170', '7773223000170']
    cnpj_with_mask_test_values = ['77.732.230/0001-70', '77.732.230/0001-70']

    for i in range(2):
        assert bsp.cnpj(with_mask = False) == cnpj_without_mask_test_values[i]
        assert bsp.cnpj(with_mask = True) == cnpj_with_mask_test_values[i]
        print("Test ", i+1, " completed.")
    print("Test completed.")


# Generated at 2022-06-21 15:24:54.408822
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    cnpj_true_0 = '24.085.965/0001-35'
    cnpj_true_1 = '42.554.568/0001-86'
    cnpj_true_2 = '84.709.253/0001-17'
    cnpj_true_3 = '96.080.917/0001-56'
    cnpj_true_4 = '64.990.642/0001-62'
    cnpj_true_5 = '11.708.915/0001-80'
    cnpj_true_6 = '86.292.127/0001-42'
    cnpj_true_7 = '97.827.975/0001-71'

# Generated at 2022-06-21 15:24:55.245852
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    BrazilSpecProvider.cnpj()

# Generated at 2022-06-21 15:25:24.745856
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    test = BrazilSpecProvider()
    test.cpf() # Return string of CPF
    test.cnpj() # Return string of CNPJ

# Generated at 2022-06-21 15:25:25.797356
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    assert BrazilSpecProvider().__init__


# Generated at 2022-06-21 15:25:29.727770
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    provider = BrazilSpecProvider()
    print(provider.cnpj())
    print(provider.cnpj())
    print(provider.cpf())
    print(provider.cpf())


if __name__ == '__main__':
    test_BrazilSpecProvider()

# Generated at 2022-06-21 15:25:30.844764
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test constructor."""
    BrazilSpecProvider()


# Generated at 2022-06-21 15:25:31.675939
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    a = BrazilSpecProvider()

# Generated at 2022-06-21 15:25:34.384240
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    ================================
    Unit test for method cnpj
    of class BrazilSpecProvider
    ================================
    """
    bs = BrazilSpecProvider()
    assert bs.cnpj() == '77.732.230/0001-70'


# Generated at 2022-06-21 15:25:39.074187
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj()
    assert len(cnpj) == 18
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14

#Unit test for method cpf of class BrazilSpecProvider

# Generated at 2022-06-21 15:25:43.457810
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    random.seed(1)
    bsp = BrazilSpecProvider()
    assert bsp.cpf(with_mask=True) == "104.636.264-97"


# Generated at 2022-06-21 15:25:44.741592
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    print(BrazilSpecProvider().cpf(with_mask=False))


# Generated at 2022-06-21 15:25:49.035063
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """
    >>> from mimesis.builtins import BrazilSpecProvider
    >>> bsp = BrazilSpecProvider()
    >>> bsp.cnpj()
    '43.924.541/0001-11'
    >>> bsp.cnpj(with_mask=False)
    '43924541000111'
    """


# Generated at 2022-06-21 15:27:02.207004
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    # Assign
    provider = BrazilSpecProvider()

    # Act
    cpf = provider.cpf()

    # Assert
    assert len(cpf) == 14
    


# Generated at 2022-06-21 15:27:12.253349
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    from mimesis.builtins import BrazilSpecProvider
    from mimesis.enums import Gender
    bsp = BrazilSpecProvider(seed=5)
    bsp.cnpj()
    print("\nName: " + bsp.name(gender=Gender.MALE))
    print("Age: " + str(bsp.age()))
    print("Birthday: " + bsp.date(minimum=2000, maximum=2020))
    print("Phone: " + bsp.telephone(mask='#########'))
    print("\nCPF: " + bsp.cpf())
    print("\nCNPJ: " + bsp.cnpj())


if __name__ == "__main__":
    test_BrazilSpecProvider_cnpj()

# Generated at 2022-06-21 15:27:14.960037
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Test the constructor of class BrazilSpecProvider."""
    obj = BrazilSpecProvider()
    assert obj is not None

# Generated at 2022-06-21 15:27:16.233484
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    assert isinstance(BrazilSpecProvider().cpf(), str)


# Generated at 2022-06-21 15:27:18.988195
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    assert provider.cpf(with_mask=True) == "217.788.946-06"


# Generated at 2022-06-21 15:27:20.199800
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    provider = BrazilSpecProvider()
    value = provider.cpf()
    assert len(value) == 14
    assert isinstance(value, str)


# Generated at 2022-06-21 15:27:22.898191
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    print('Running test_BrazilSpecProvider...')
    bsp = BrazilSpecProvider()
    print('CPF  : ', bsp.cpf())
    print('CNPJ : ', bsp.cnpj())

# Generated at 2022-06-21 15:27:26.145926
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Unit test for method cnpj of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()
    assert (bsp.cnpj(with_mask=True) == '77.732.230/0001-70')

# Generated at 2022-06-21 15:27:30.860900
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Unit test for method cpf of class BrazilSpecProvider."""
    bsp = BrazilSpecProvider()

    assert bsp.cpf() == '049.888.525-98'
    assert bsp.cpf(False) == '04988852598'
    assert bsp.cpf(with_mask=False) == '04988852598'
    assert bsp.cpf(with_mask=True) == '049.888.525-98'


# Generated at 2022-06-21 15:27:34.741758
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    brazil1 = BrazilSpecProvider(seed=42)
    brazil2 = BrazilSpecProvider(seed=42)

    for i in range(5):
        assert brazil1.cpf() == brazil2.cpf()
        assert brazil1.cnpj() == brazil2.cnpj()

# Generated at 2022-06-21 15:30:02.399355
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=False)
    assert len(cnpj) == 14

    provider = BrazilSpecProvider()
    cnpj = provider.cnpj(with_mask=True)
    assert len(cnpj) == 18



# Generated at 2022-06-21 15:30:09.145982
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    """Test method BrazilSpecProvider.cnpj."""
    from mimesis.providers.brazil import BrazilSpecProvider
    
    brazil_provider = BrazilSpecProvider()
    cnpj_test = brazil_provider.cnpj()
    
    assert len(cnpj_test) == 18
    assert cnpj_test[2] == '.'
    assert cnpj_test[6] == '.'
    assert cnpj_test[10] == '/'
    assert cnpj_test[15] == '-'
    

# Generated at 2022-06-21 15:30:14.166354
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    """Method to test the method cpf of class BrazilSpecProvider."""

    from mimesis.providers import BrazilSpecProvider

    bsp = BrazilSpecProvider()

    cpf_test = bsp.cpf()

    assert len(cpf_test) == 14
    assert cpf_test == bsp.cpf()



# Generated at 2022-06-21 15:30:16.093533
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    bsp = BrazilSpecProvider(seed = 1)
    assert bsp.cpf(False) == '77308851904'


# Generated at 2022-06-21 15:30:24.097299
# Unit test for method cpf of class BrazilSpecProvider
def test_BrazilSpecProvider_cpf():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.builtins import BrazilSpecProvider

    data = Person('pt-br', seed=123456789)
    bs = BrazilSpecProvider(seed=123456789)

    for _ in range(10000):
        cpf = bs.cpf(with_mask=False)
        d_nasc = data.birthday(minimum_age=18, maximum_age=100)
        d_nasc = d_nasc.strftime('%d%m%Y')
        s_nasc = data.century(start=19, end=20).value
        full_cpf = int(d_nasc + s_nasc)
        cpf = int(cpf)
        assert full_cpf == cp

# Generated at 2022-06-21 15:30:24.728121
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    assert isinstance(BrazilSpecProvider().cnpj(), str)


# Generated at 2022-06-21 15:30:27.027572
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    # Test without_mask
    without_mask = BrazilSpecProvider()
    assert len(without_mask.cnpj(with_mask=False)) == 14
    # Test with_mask
    with_mask = BrazilSpecProvider()
    assert len(with_mask.cnpj(with_mask=True)) == 18
    assert with_mask.cnpj(with_mask=True) == '77.732.230/0001-70'



# Generated at 2022-06-21 15:30:32.363936
# Unit test for constructor of class BrazilSpecProvider
def test_BrazilSpecProvider():
    """Unit test for constructor of class BrazilSpecProvider."""
    brazil_spec_provider = BrazilSpecProvider()
    assert brazil_spec_provider.__class__.__name__ == 'BrazilSpecProvider'

# Generated at 2022-06-21 15:30:33.927338
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    bsp = BrazilSpecProvider()
    for i in range(1, 200):
        assert bsp.cnpj()


# Generated at 2022-06-21 15:30:36.840204
# Unit test for method cnpj of class BrazilSpecProvider
def test_BrazilSpecProvider_cnpj():
    brazil = BrazilSpecProvider()
    cnpj = brazil.cnpj(with_mask=False)
    print(cnpj)
