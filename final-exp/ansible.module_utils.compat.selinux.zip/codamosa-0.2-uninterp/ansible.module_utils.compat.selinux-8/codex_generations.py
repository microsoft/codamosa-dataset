

# Generated at 2022-06-16 23:19:43.340891
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-16 23:19:52.201182
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that has a context
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con.startswith('unconfined_u:object_r:etc_t:s0')

    # Test with a file that doesn't have a context
    rc, con = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con.startswith('unconfined_u:object_r:etc_t:s0')

    # Test with a file that doesn't exist
    rc, con = lgetfilecon_raw('/etc/doesnotexist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:19:56.594442
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(path)



# Generated at 2022-06-16 23:19:59.980220
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:05.186139
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con

    # Cleanup
    os.remove(path)

# Generated at 2022-06-16 23:20:16.179692
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    # Set the file mode to 0644
    os.chmod(tmpfile, stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)
    # Get the context of the file
    rc, con = matchpathcon(tmpfile, 0)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    # Check the return code
    assert rc == 0
    # Check the context

# Generated at 2022-06-16 23:20:19.375975
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:20:29.840673
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for a path that does not exist
    path = '/etc/passwd_not_exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test for a path that is not a file
    path = '/etc/'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:40.640179
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a file that does not exist
    path = '/etc/doesnotexist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a file that exists, but is not readable
    path = '/etc/shadow'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:20:48.797725
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:20:54.926546
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd_does_not_exist') == [-1, None]


# Generated at 2022-06-16 23:21:00.618179
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0

    # Delete the temporary file
    os.unlink(path)



# Generated at 2022-06-16 23:21:09.745409
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    rc, con = matchpathcon('/etc/passwd1', 0)
    assert rc == -1
    assert con == ''

    # Test with a valid path and mode
    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path and mode
    rc, con = matchpathcon('/etc/passwd1', 1)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:21:18.291673
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for file
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test for directory
    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for non-existent file
    path = '/etc/passwd-non-existent'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    # Test for non-existent directory
    path = '/etc-non-existent'

# Generated at 2022-06-16 23:21:29.373211
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:21:36.425825
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)



# Generated at 2022-06-16 23:21:40.857842
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        fname = os.path.join(tmpdir, 'test')
        with open(fname, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(fname)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:21:44.909067
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd2') == [-1, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:21:53.264157
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, "testfile")
    with open(testfile, 'w') as f:
        f.write("test")

    # Get the context of the file
    [rc, con] = matchpathcon(testfile, stat.S_IFREG)
    assert rc == 0
    assert con == "system_u:object_r:user_tmp_t:s0"

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:21:59.342606
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, fname = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = matchpathcon(fname, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(fname)

# Generated at 2022-06-16 23:22:07.485261
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import os
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')
        rc, con = lgetfilecon_raw(testfile)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:22:17.125141
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:22:24.317543
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:22:32.798852
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for a file that does not exist
    path = '/tmp/this_file_does_not_exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''
    # Test for a file that does exist
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:22:38.154273
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that doesn't exist
    rc, con = lgetfilecon_raw('/etc/passwd_does_not_exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:22:43.306840
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd1'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:22:46.769467
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:58.219102
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the temporary directory
    (rc, con) = matchpathcon(tmpdir, 0)
    if rc != 0:
        raise Exception("matchpathcon failed: %s" % con)

    # Set the context of the temporary file
    rc = lsetfilecon(tmpfile, con)
    if rc != 0:
        raise Exception("lsetfilecon failed: %s" % con)

    # Get the context of the temporary file
    (rc, con) = lgetfilecon_raw(tmpfile)
   

# Generated at 2022-06-16 23:23:04.262710
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that is not present
    path = "/tmp/test_matchpathcon"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a file that is present
    path = "/etc/passwd"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con is not None



# Generated at 2022-06-16 23:23:07.068952
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/hosts'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-16 23:23:22.351359
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
   

# Generated at 2022-06-16 23:23:26.845306
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:23:35.556479
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-16 23:23:39.609501
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:23:48.626069
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, context = lgetfilecon_raw(path)
    assert rc == 0, "lgetfilecon_raw failed"
    assert context is not None, "lgetfilecon_raw failed"

    # Clean up
    os.unlink(path)
    shutil.rmtree(tmpdir)


# Generated at 2022-06-16 23:23:50.887550
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:24:01.145888
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', os.R_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', os.W_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', os.X_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:24:02.579233
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:24:13.281109
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        tmpfile = os.path.join(tmpdir, 'testfile')
        with open(tmpfile, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(tmpfile)
        assert rc == 0
        assert con == 'system_u:object_r:tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-16 23:24:17.064665
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:39.258303
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = "/etc/passwd"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with an invalid path
    path = "/etc/passwd/invalid"
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == None

    # Test with a valid path and mode
    path = "/etc/passwd"
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a valid path and invalid mode

# Generated at 2022-06-16 23:24:47.678053
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a path that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a path that is not a file
    path = '/etc'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a path that is not a file and does not exist
    path = '/etc/does_not_exist'

# Generated at 2022-06-16 23:24:52.871874
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:25:02.272947
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:25:08.884453
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw('/etc/passwd')
    except OSError as e:
        if e.errno == errno.ENOENT:
            print("/etc/passwd does not exist")
        else:
            raise
    else:
        print("/etc/passwd context is: %s" % con)


# Generated at 2022-06-16 23:25:16.909440
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:25:23.125760
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd-does-not-exist')
    assert rc == -1
    assert con is None


# Generated at 2022-06-16 23:25:27.028360
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:25:30.198641
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:25:33.862519
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:25:58.181122
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the file context
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:26:00.021542
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:26:06.777780
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a file that does not exist
    path = "/etc/passwd-does-not-exist"
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:26:17.469375
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
   

# Generated at 2022-06-16 23:26:21.577244
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:26:31.777790
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist

# Generated at 2022-06-16 23:26:34.631116
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:26:36.634412
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-16 23:26:40.165932
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:26:43.106214
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:27:37.027068
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 1
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test 2
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test 3
    path = '/etc/passwd'
    mode = 2
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test 4
    path

# Generated at 2022-06-16 23:27:42.303280
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:27:47.163590
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:27:50.306286
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/shadow'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'

# Generated at 2022-06-16 23:27:52.877660
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con
    finally:
        os.remove(path)



# Generated at 2022-06-16 23:27:57.127409
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:28:06.447420
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:28:10.766733
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile()
    tmpfile.close()

    # Get the context of the temporary file
    [rc, context] = matchpathcon(tmpfile.name, 0)
    assert rc == 0
    assert context is not None

    # Cleanup
    os.remove(tmpfile.name)

# Generated at 2022-06-16 23:28:21.988736
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a file that doesn't exist
    rc, con = matchpathcon('/etc/passwd-not-found', 0)
    assert rc == -1
    assert con is None

    # Test with a directory that exists
    rc, con = matchpathcon('/etc', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that doesn't exist
    rc, con = matchpathcon('/etc-not-found', 0)
    assert rc == -1
    assert con is None

    # Test

# Generated at 2022-06-16 23:28:27.592442
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for function matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:29:17.413586
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-16 23:29:22.819466
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)

    # Remove the temporary file
    os.remove(path)

    # Check the return code
    assert rc == 0

    # Check the context
    assert con.startswith('system_u:object_r:')


# Generated at 2022-06-16 23:29:32.364878
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the temporary file
    (rc, con) = matchpathcon(tmpfile, 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Get the context of the temporary directory
    (rc, con) = matchpathcon(tmpdir, 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Clean up
    os.unlink(tmpfile)
    os.rmdir(tmpdir)

# Generated at 2022-06-16 23:29:40.500505
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

