

# Generated at 2022-06-16 23:19:56.397640
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that doesn't exist
    path = '/etc/passwd-not-exist'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that doesn't exist
   

# Generated at 2022-06-16 23:20:08.031502
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for file
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test for directory
    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for non-existent file
    path = '/etc/passwd_'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con == ''

    # Test for non-existent directory
    path = '/etc_'
    rc, con = lgetfilecon_raw(path)

# Generated at 2022-06-16 23:20:18.511894
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-not-exist'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that exists
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:20:29.151749
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    rc, con = matchpathcon('/etc/passwd/invalid', 0)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    rc, con = matchpathcon('/etc/passwd', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path and mode
    rc, con = matchpathcon('/etc/passwd/invalid', os.R_OK)
    assert rc == -1

# Generated at 2022-06-16 23:20:32.735043
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:36.631383
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:39.232671
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:42.058989
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:20:48.828692
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    (rc, con) = matchpathcon(tmpfile, stat.S_IFREG)

    # Delete the temporary directory
    shutil.rmtree(tmpdir)

    # Check the return code and context
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:20:53.594413
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:59.827442
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:02.656705
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-16 23:21:05.675516
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile() as f:
        rc, con = matchpathcon(f.name, os.R_OK)
        assert rc == 0
        assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:21:10.047293
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:18.668485
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:21:20.354639
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:24.363841
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:21:27.107102
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:21:35.806233
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    # Test for matchpathcon
    # Test for matchpathcon
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:21:42.174499
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:21:51.478038
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd/invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:21:54.800338
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-16 23:21:59.341609
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/test'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-16 23:22:01.697765
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:22:11.367851
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with an invalid mode
    path = '/etc/passwd'
    mode = -1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:22:14.271327
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:22:18.070678
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:22:23.398868
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd_') == [2, None]
    assert lgetfilecon_raw('/etc/passwd_')[0] == 2


# Generated at 2022-06-16 23:22:26.512809
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:22:30.480166
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:42.540088
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that has a context
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that doesn't have a context
    path = '/dev/null'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == '<<none>>'

    # Test with a file that doesn't exist
    path = '/does/not/exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:22:46.413450
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:22:57.687695
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t:s0']
    assert matchpathcon('/', 1) == [0, 'system_u:object_r:root_t:s0']
    assert matchpathcon('/', 2) == [0, 'system_u:object_r:root_t:s0']
    assert matchpathcon('/', 3) == [0, 'system_u:object_r:root_t:s0']
    assert matchpathcon('/', 4) == [0, 'system_u:object_r:root_t:s0']
    assert matchpathcon('/', 5) == [0, 'system_u:object_r:root_t:s0']

# Generated at 2022-06-16 23:23:00.498577
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test'
    mode = 0
    rc, con = matchpathcon(path, mode)
    print(rc, con)


# Generated at 2022-06-16 23:23:02.050858
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:23:09.935659
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:23:19.433531
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, "testfile")
    with open(testfile, 'w') as f:
        f.write("test")

    # Get the context of the file
    [rc, con] = matchpathcon(testfile, 0)
    assert rc == 0
    assert con is not None

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:23:24.373824
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        test_file = os.path.join(temp_dir, "test_file")
        with open(test_file, "w") as f:
            f.write("test")

        rc, con = lgetfilecon_raw(test_file)
        assert rc == 0
        assert con.startswith("system_u:object_r:")
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-16 23:23:31.405553
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:23:37.395145
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:23:52.255249
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    (fd, path) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Change the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con.startswith('system_u:object_r:')

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:23:55.712417
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:23:58.933542
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:02.596629
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    (fd, path) = tempfile.mkstemp()
    os.close(fd)
    try:
        (rc, con) = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:tmp_t:s0'
    finally:
        os.unlink(path)



# Generated at 2022-06-16 23:24:09.272198
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:24:15.879948
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(testfile)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)


# Generated at 2022-06-16 23:24:19.822982
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:28.807311
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and an invalid mode
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:24:32.411698
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:36.494434
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:25:02.246683
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a valid path and invalid mode

# Generated at 2022-06-16 23:25:07.405493
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/test'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-16 23:25:10.353836
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:25:17.344228
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the temporary directory
    (rc, con) = matchpathcon(tmpdir, 0)
    if rc != 0:
        raise Exception("matchpathcon failed")

    # Get the context of the temporary file
    (rc, con) = matchpathcon(tmpfile, 0)
    if rc != 0:
        raise Exception("matchpathcon failed")

    # Clean up
    os.unlink(tmpfile)
    os.rmdir(tmpdir)

# Generated at 2022-06-16 23:25:21.434440
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:25:25.123160
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"


# Generated at 2022-06-16 23:25:27.834775
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:25:34.834909
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:25:36.263901
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:25:47.018893
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:26:15.805459
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as f:
        f.write('test')

    # Get the context of the file
    rc, con = matchpathcon(testfile, stat.S_IFREG)
    assert rc == 0

    # Set the context of the file
    rc = lsetfilecon(testfile, con)
    assert rc == 0

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:26:20.139194
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:26:30.887516
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con.startswith('system_u:object_r:')

    # Change the context of the file
    rc = lsetfilecon(path, 'system_u:object_r:tmp_t:s0')
    assert rc == 0

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0

# Generated at 2022-06-16 23:26:33.595304
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:26:36.554973
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:26:39.352189
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:26:49.722037
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:26:53.718841
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        rc, con = lgetfilecon_raw(f.name)
        assert rc == 0
        assert con == 'system_u:object_r:unlabeled_t:s0'



# Generated at 2022-06-16 23:26:56.304873
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:27:03.950050
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as f:
        f.write('test')

    # Set the file context
    rc, con = lgetfilecon_raw(testfile)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:27:53.455362
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, 'testfile')
        with open(path, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:user_home_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:28:01.335040
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Delete the temporary file
    os.remove(path)



# Generated at 2022-06-16 23:28:04.065515
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:28:09.210644
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    # Get the context of the temporary file
    [rc, context] = matchpathcon(tmp_file.name, 0)
    assert rc == 0
    assert context is not None

    # Clean up
    os.unlink(tmp_file.name)

# Generated at 2022-06-16 23:28:11.727851
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:28:17.603461
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:28:19.856138
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:28:21.548181
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    if rc != 0:
        raise Exception('matchpathcon failed')
    print('matchpathcon: {}'.format(con))



# Generated at 2022-06-16 23:28:27.536762
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:28:31.641726
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/foo'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:29:22.287484
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd_does_not_exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:29:32.255029
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a file that does not exist
    rc, con = matchpathcon('/etc/passwd-does-not-exist', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a directory that exists
    rc, con = matchpathcon('/etc', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist

# Generated at 2022-06-16 23:29:38.221161
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    print('rc: {0}'.format(rc))
    print('con: {0}'.format(con))



# Generated at 2022-06-16 23:29:42.390591
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux/config'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:29:45.255718
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'