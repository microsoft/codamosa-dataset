

# Generated at 2022-06-16 23:19:47.439897
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/hosts'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with an invalid path
    path = '/etc/hosts_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and mode
    path = '/etc/hosts'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a valid path and invalid mode

# Generated at 2022-06-16 23:19:53.143092
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    # FIXME: this is a hack to get around the fact that the unit test
    #        framework doesn't know how to handle the ctypes return
    #        values.  This should be fixed in the framework.
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-16 23:19:58.031586
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd-not-exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:01.369144
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:20:04.826580
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:15.585543
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a non-existent path
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path but invalid mode
    path = '/etc/passwd'
    mode = os.W_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:21.790119
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for file
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test for directory
    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for non-existent file
    path = '/etc/passwd-foo'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:31.050284
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    # Create a symbolic link to the file
    symlink = os.path.join(tmpdir, "symlink")
    os.symlink(tmpfile, symlink)
    # Create a directory
    dir = os.path.join(tmpdir, "dir")
    os.mkdir(dir)
    # Create a character device
    char = os.path.join(tmpdir, "char")
    os.mknod(char, stat.S_IFCHR | 0o666)
    # Create

# Generated at 2022-06-16 23:20:39.034645
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(testfile)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)


# Generated at 2022-06-16 23:20:47.105429
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with an invalid mode
    path = '/etc/passwd'
    mode = os.W_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

# Generated at 2022-06-16 23:21:01.239976
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and a mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path and a mode


# Generated at 2022-06-16 23:21:08.041758
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test for invalid mode
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:21:11.601028
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:21:19.119985
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon with valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for matchpathcon with invalid path
    path = '/etc/passwd1'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test for matchpathcon with invalid mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:21:30.034475
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:21:33.280864
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:21:37.179871
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:40.765365
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:43.472103
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:21:46.934553
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:22:03.194284
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:22:11.934211
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    rc, con = matchpathcon('/etc/passwd/invalid', 0)
    assert rc == -1
    assert con is None

    # Test with an invalid mode
    rc, con = matchpathcon('/etc/passwd', -1)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:22:20.269110
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 3)
    assert rc == 0

# Generated at 2022-06-16 23:22:26.577605
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:22:30.519828
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:22:33.722322
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:22:36.988188
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-16 23:22:39.966404
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    print('rc: {0}'.format(rc))
    print('con: {0}'.format(con))



# Generated at 2022-06-16 23:22:43.915162
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:22:55.778760
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the temporary directory
    rc, con = matchpathcon(tmpdir, 0)
    if rc != 0:
        raise Exception('matchpathcon failed: %s' % con)

    # Set the context of the temporary file
    rc = lsetfilecon(tmpfile, con)
    if rc != 0:
        raise Exception('lsetfilecon failed: %s' % os.strerror(rc))

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(tmpfile)


# Generated at 2022-06-16 23:23:01.785924
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:23:04.143476
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:23:15.033866
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = "/etc/hosts"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test with an invalid path
    path = "/etc/hosts/invalid"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ""

    # Test with an invalid mode
    path = "/etc/hosts"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ""



# Generated at 2022-06-16 23:23:24.294737
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 1: Test with a valid path
    path = "/etc/passwd"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test 2: Test with a non-existent path
    path = "/etc/passwd_"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test 3: Test with a valid path and mode
    path = "/etc/passwd"
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:23:32.675785
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file
    tmpfile = os.path.join(tmpdir, 'tmpfile')
    with open(tmpfile, 'w') as f:
        f.write('test')

    # Get the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:23:36.697804
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:23:46.838635
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    # Get the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    # Check the return code
    assert rc == 0
    # Check the context of the file
    assert con == 'system_u:object_r:user_tmp_t:s0'


# Generated at 2022-06-16 23:23:57.017631
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = os.stat(path).st_mode

# Generated at 2022-06-16 23:24:04.140310
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import selinux

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = selinux.lgetfilecon_raw(tmpfile)

    # Clean up
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)

    # Check the return code
    assert rc == 0

    # Check the context
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:24:16.038464
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-16 23:24:38.359343
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:24:41.238404
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:44.272685
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:24:46.724828
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test_matchpathcon'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:24:58.698925
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', os.W_OK)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', os.X_OK)
    assert rc == 0

# Generated at 2022-06-16 23:25:04.864713
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:25:15.316043
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 3)
    assert rc == 0

# Generated at 2022-06-16 23:25:26.329738
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
   

# Generated at 2022-06-16 23:25:32.661922
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test for a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd_does_not_exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:25:35.879353
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:26:02.665721
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-16 23:26:05.924721
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:26:09.399215
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:26:18.989158
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:26:25.867239
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd_does_not_exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:26:35.133081
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = os.stat(path).st_mode

# Generated at 2022-06-16 23:26:38.495601
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-16 23:26:44.952419
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that doesn't exist
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc/'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    #

# Generated at 2022-06-16 23:26:55.523886
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)

    # Delete the file
    os.unlink(path)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Check if the context is not empty
    if con:
        print("Context of the file: %s" % con)
    else:
        print("Context of the file is empty")


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-16 23:26:59.697913
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:27:25.969659
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd1') == [-1, None]


# Generated at 2022-06-16 23:27:28.695906
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:27:31.962130
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:27:39.403808
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    rc, con = matchpathcon('/etc/passwd/invalid', 0)
    assert rc == -1
    assert con == ''

    # Test with a valid path and mode
    rc, con = matchpathcon('/etc/passwd', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a valid path and invalid mode
    rc, con = matchpathcon('/etc/passwd', -1)
    assert rc == -1

# Generated at 2022-06-16 23:27:48.939928
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and an invalid mode
    path = '/etc/passwd'
    mode = -1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:27:51.612437
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:27:57.274674
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:27:59.439325
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:28:05.474620
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:28:08.881572
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd_does_not_exist') == [-1, None]


# Generated at 2022-06-16 23:29:01.490091
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/invalid/path'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:29:10.493844
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:29:20.911985
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the temporary directory
    rc, con = matchpathcon(tmpdir, 0)
    if rc != 0:
        raise Exception("matchpathcon failed: %s" % con)

    # Set the context of the temporary file
    rc = lsetfilecon(tmpfile, con)
    if rc != 0:
        raise Exception("lsetfilecon failed: %s" % con)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(tmpfile)

# Generated at 2022-06-16 23:29:27.422534
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:29:35.235576
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        fd, fpath = tempfile.mkstemp(dir=tmpdir)
        os.close(fd)
        rc, con = lgetfilecon_raw(fpath)
        assert rc == 0
        assert con == 'system_u:object_r:tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-16 23:29:44.318279
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon
    """
    from ansible.module_utils.selinux import matchpathcon
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
            mode=dict(type='int', required=True),
        ),
        supports_check_mode=True,
    )

    path = module.params['path']
    mode = module.params['mode']

    rc, con = matchpathcon(path, mode)
    if rc < 0:
        module.fail_json(msg='matchpathcon failed: {0}'.format(con))

    module.exit_json(changed=True, msg='matchpathcon succeeded', con=con)

