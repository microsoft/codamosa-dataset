

# Generated at 2022-06-16 23:19:50.549717
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, 'testfile')
    open(testfile, 'w').close()
    # Get the context of the file
    [rc, con] = matchpathcon(testfile, 0)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    # Check the return code
    assert rc == 0
    # Check the context
    assert con == 'system_u:object_r:user_tmp_t:s0'

# Generated at 2022-06-16 23:19:55.670665
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for successful call
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test for failure
    rc, con = lgetfilecon_raw('/etc/passwd_')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:19:59.541809
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:05.619351
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a non-existing path
    path = '/tmp/non-existing-path'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path
    path = '/tmp'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con is not None



# Generated at 2022-06-16 23:20:14.069890
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, os.R_OK)
    assert rc == 0
    assert con is not None

    # Clean up
    os.unlink(path)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:20:20.582302
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Close the file, we just need its name
    tmpfile.close()
    # Get the context of the file
    rc, con = matchpathcon(tmpfile.name, os.R_OK)
    # Remove the temporary file and directory
    os.unlink(tmpfile.name)
    shutil.rmtree(tmpdir)
    # Return the context
    return con

# Generated at 2022-06-16 23:20:26.259705
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(path)

# Generated at 2022-06-16 23:20:32.349679
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for function matchpathcon
    # This function is deprecated and should be rewritten on selabel_lookup (but will be a PITA)
    # FIXME: rewrite this test
    # assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    pass

# Generated at 2022-06-16 23:20:36.226443
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test_matchpathcon'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:20:40.138072
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:47.112828
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:52.710517
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        rc, con = lgetfilecon_raw(f.name)
        assert rc == 0
        assert con == 'system_u:object_r:unlabeled_t:s0'



# Generated at 2022-06-16 23:21:03.162218
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 1
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test 2
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test 3
    path = '/etc/passwd'
    mode = 2
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test 4
    path

# Generated at 2022-06-16 23:21:06.104556
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:14.328359
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, 'testfile')
        with open(path, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:21:27.211285
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:21:30.443592
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test'
    mode = 0
    rc, con = matchpathcon(path, mode)
    print(rc, con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-16 23:21:33.852270
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:44.203917
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with an invalid mode
    path = '/etc/passwd'
    mode = -1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:21:47.264564
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:02.945629
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:22:12.482890
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    path = '/tmp/test_file'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'
    # Test for matchpathcon with invalid path
    path = '/tmp/invalid_file'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None
    # Test for matchpathcon with invalid mode
    path = '/tmp/test_file'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None


# Generated at 2022-06-16 23:22:15.337843
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:20.230098
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:unlabeled_t:s0'
    finally:
        os.unlink(path)



# Generated at 2022-06-16 23:22:28.759324
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, 'testfile')
        with open(path, 'w') as f:
            f.write('test')

        rc, con = matchpathcon(path, 0)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:22:38.412783
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary directory
    (rc, con) = matchpathcon(tmpdir, 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Get the context of the temporary file
    (rc, con) = matchpathcon(tmpfile, 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Clean up
    os.unlink(tmpfile)
    os.rmdir(tmpdir)

# Generated at 2022-06-16 23:22:40.801412
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:22:49.255050
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-not-exist'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:23:00.499168
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-not-exist'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a file that exists and mode is 1
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    #

# Generated at 2022-06-16 23:23:07.427295
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that doesn't exist
    path = '/etc/passwd-does-not-exist'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a directory that exists
    path = '/etc'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that doesn't exist

# Generated at 2022-06-16 23:23:19.743214
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test matchpathcon
    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test matchpathcon
    rc, con = matchpathcon('/etc/passwd', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test matchpathcon
    rc, con = matchpathcon('/etc/passwd', 3)
    assert rc == 0

# Generated at 2022-06-16 23:23:22.896239
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for function matchpathcon
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:23:33.805680
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:23:45.975739
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with an invalid mode
    path = '/etc/passwd'
    mode = os.W_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:23:51.403484
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with an existing file
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test with a non-existing file
    path = "/etc/passwd_does_not_exist"
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con == None


# Generated at 2022-06-16 23:23:54.001185
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:23:59.837956
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None
    assert con != ''

    # Test with a file that doesn't exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None
    assert con == ''



# Generated at 2022-06-16 23:24:05.012783
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:24:11.122296
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:24:16.637897
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Clean up
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:24:35.929202
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test_matchpathcon'
    mode = 0o777
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:24:39.480782
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    print('rc: {0}'.format(rc))
    print('con: {0}'.format(con))


# Generated at 2022-06-16 23:24:41.031007
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:24:48.931287
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'
    path = '/etc/passwd'
    mode = 2
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'
    path = '/etc/passwd'
    mode = 3
    rc, con = matchpath

# Generated at 2022-06-16 23:24:59.765340
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and invalid mode
    path = '/etc/passwd'
    mode = -1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with an invalid path and invalid mode
    path = '/etc/passwd_invalid'
    mode

# Generated at 2022-06-16 23:25:07.361345
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(path)

# Generated at 2022-06-16 23:25:10.315522
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:25:13.897960
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:25:18.435076
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:25:26.379516
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Clean up
    os.unlink(path)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:26:04.632578
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:26:07.986430
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:26:18.216704
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:26:27.006633
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(path=dict(type='str', required=True),
                                              mode=dict(type='int', required=True)))
    path = module.params['path']
    mode = module.params['mode']
    rc, con = matchpathcon(path, mode)
    if rc == 0:
        module.exit_json(changed=True, rc=rc, con=con)
    else:
        module.fail_json(msg="Failed to get context of %s" % path)



# Generated at 2022-06-16 23:26:36.015143
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    rc, con = matchpathcon('/etc/passwd2', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that exists
    rc, con = matchpathcon('/etc', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist
    rc, con = matchpathcon('/etc2', 0)
    assert rc == 0

# Generated at 2022-06-16 23:26:41.134039
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Clean up
    os.remove(path)

# Generated at 2022-06-16 23:26:44.993868
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd-') == [2, None]



# Generated at 2022-06-16 23:26:55.574271
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    # Test with a directory that exists
    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist

# Generated at 2022-06-16 23:27:00.545441
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temp file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temp file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(path)

# Generated at 2022-06-16 23:27:03.634284
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:28:29.737607
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:28:33.682819
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    (rc, con) = lgetfilecon_raw(tmpfile)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Return the context
    return con

# Generated at 2022-06-16 23:28:43.369959
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
   

# Generated at 2022-06-16 23:28:54.709759
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
   

# Generated at 2022-06-16 23:29:01.660527
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    (rc, con) = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con is not None

    # Clean up
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:29:07.004729
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/tmp/test_file'
    mode = 0o777
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-16 23:29:09.168739
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:29:14.443298
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:29:23.403318
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for a file that exists
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    # Test for a file that does not exist
    assert matchpathcon('/etc/passwd_', 0) == [-1, None]
    # Test for a file that exists with a mode that does not exist
    assert matchpathcon('/etc/passwd', 1) == [-1, None]
    # Test for a file that does not exist with a mode that does not exist
    assert matchpathcon('/etc/passwd_', 1) == [-1, None]
    # Test for a file that exists with a mode that does exist

# Generated at 2022-06-16 23:29:30.775339
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        tmpfile = os.path.join(tmpdir, 'testfile')
        with open(tmpfile, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(tmpfile)
        assert rc == 0
        assert con == 'system_u:object_r:usr_t:s0'
    finally:
        shutil.rmtree(tmpdir)