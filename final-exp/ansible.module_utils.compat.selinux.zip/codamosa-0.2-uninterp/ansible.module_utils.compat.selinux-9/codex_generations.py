

# Generated at 2022-06-16 23:19:48.602312
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:19:52.155188
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test_file'
    mode = 0o777
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:19:55.195127
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:06.495164
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:20:08.299777
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:20:12.658168
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:20:19.482838
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Check the return code
    assert rc == 0

    # Check the context
    assert con is not None
    assert con != ''


# Generated at 2022-06-16 23:20:22.263496
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:20:31.964608
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that has a context
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not have a context
    path = '/etc/shadow'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is None

    # Test with a file that does not exist
    path = '/etc/shadow_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:37.115060
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    (fd, path) = tempfile.mkstemp()
    os.close(fd)

    (rc, con) = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'

    os.unlink(path)

# Generated at 2022-06-16 23:20:42.243906
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:20:47.913706
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    try:
        tmpfile = os.path.join(tmpdir, 'testfile')
        with open(tmpfile, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(tmpfile)
        assert rc == 0
        assert con.startswith('system_u:object_r:')
    finally:
        os.remove(tmpfile)
        os.rmdir(tmpdir)

# Generated at 2022-06-16 23:21:00.285166
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/does_not_exist'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that exists
    path = '/etc'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a

# Generated at 2022-06-16 23:21:08.161861
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for file
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for directory
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for invalid path
    path = '/invalid/path'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test for invalid mode

# Generated at 2022-06-16 23:21:16.502956
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create a temporary file
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)
    os.unlink(path)

    # Create a temporary file with the given context
    context = 'system_u:object_r:tmp_t:s0'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    rc = _selinux_lib.lsetfilecon(path, context)
    assert rc == 0

    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == context

    os.unlink(path)

# Generated at 2022-06-16 23:21:28.518116
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the temporary directory
    rc, con = matchpathcon(tmpdir, 0)
    assert rc == 0
    assert con is not None

    # Set the context of the temporary file
    rc = lsetfilecon(tmpfile, con)
    assert rc == 0

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con is not None

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:21:32.167462
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:36.693397
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    print('rc: {0}, con: {1}'.format(rc, con))


# Generated at 2022-06-16 23:21:44.939286
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        return

    if is_selinux_mls_enabled():
        return

    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    rc, con = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'

    rc, con = lgetfilecon_raw('/etc/shadow-')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:21:49.349611
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None
    assert con.startswith('system_u:object_r:etc_runtime_t:s0')



# Generated at 2022-06-16 23:21:57.102195
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:00.234839
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:11.216801
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a valid path and invalid mode

# Generated at 2022-06-16 23:22:19.958505
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:22:32.033975
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:22:38.023101
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:22:44.013980
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con is not None

    # Clean up
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:22:47.761961
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:22:53.119412
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Clean up
    os.remove(path)

# Generated at 2022-06-16 23:22:58.516684
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)

    # Delete the temporary file
    os.remove(path)

    # Return the context
    return con

# Generated at 2022-06-16 23:23:05.657378
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"


# Generated at 2022-06-16 23:23:17.909742
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for a file that does not exist
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for a file that exists with a mode that does not exist
    path = '/etc/passwd'
    mode = os.W_OK
    rc, con = matchpathcon(path, mode)

# Generated at 2022-06-16 23:23:25.398634
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
   

# Generated at 2022-06-16 23:23:32.304044
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:23:37.006666
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:23:41.980487
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    rc, con = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'


# Generated at 2022-06-16 23:23:51.688924
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    rc, con = matchpathcon('/etc/passwd2', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that exists
    rc, con = matchpathcon('/etc/', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist
    rc, con = matchpathcon('/etc2/', 0)
    assert rc == 0

# Generated at 2022-06-16 23:23:56.910242
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(tmpfile)

    # Clean up
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)

    # Return the context
    return con

# Generated at 2022-06-16 23:24:00.132382
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:24:02.664204
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test'
    mode = 0o777
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:24:16.618035
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Get the context of the temp file
    [rc, con] = lgetfilecon_raw(tmpfile.name)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Get the context of the temp directory
    [rc, con] = lgetfilecon_raw(tmpdir)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Cleanup
    tmpfile.close()
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:24:19.393829
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:24:26.298033
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in temporary directory
    tfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Get the security context of the file
    [rc, con] = matchpathcon(tfile.name, 0)
    assert rc == 0
    assert con is not None

    # Remove the directory after the test
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:24:30.229544
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:40.875209
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a valid path and mode

# Generated at 2022-06-16 23:24:43.394807
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:24:45.724294
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:24:52.787278
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test case 1
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test case 2
    path = '/etc/passwd-not-exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:25:02.220655
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-16 23:25:13.936618
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon function
    # This test is for a file that exists in the system
    # The file is /etc/passwd
    # The mode is 0
    # The expected result is 0
    # The expected context is system_u:object_r:passwd_file_t:s0
    path = "/etc/passwd"
    mode = 0
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert result[1] == "system_u:object_r:passwd_file_t:s0"

    # Test for matchpathcon function
    # This test is for a file that does not exist in the system
    # The file is /etc/passwd1
    # The mode is 0
    # The expected result is -1
    # The expected context is None
    path

# Generated at 2022-06-16 23:25:35.020702
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import sys
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    # Get context of the file
    (rc, con) = matchpathcon(tmpfile, 0)
    if rc != 0:
        print("matchpathcon failed: %s" % os.strerror(rc))
        sys.exit(1)
    print("matchpathcon returned: %s" % con)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-16 23:25:43.393057
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that has a context
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a file that does not have a context
    path = '/dev/null'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    # Test with a file that does not exist
    path = '/does/not/exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:25:49.481809
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:25:57.808491
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary directory
    (rc, con) = matchpathcon(tmpdir, 0)
    assert rc == 0
    assert con is not None

    # Get the context of the temporary file
    (rc, con) = matchpathcon(tmpfile, 0)
    assert rc == 0
    assert con is not None

    # Clean up
    os.unlink(tmpfile)
    os.rmdir(tmpdir)

# Generated at 2022-06-16 23:26:06.005762
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for a path that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test for a path that is not a file
    path = '/etc'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:26:08.936056
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:26:11.420918
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd-not-exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:26:15.034445
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:26:19.716228
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:26:23.373466
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:26:52.794768
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/tmp/does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:26:55.171137
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:27:04.652216
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:27:07.232224
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:27:13.786763
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)

    # Get the context of the file
    (rc, con) = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con is not None

    # Clean up
    os.close(fd)
    shutil.rmtree(tmpdir)



# Generated at 2022-06-16 23:27:15.637549
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    (fd, path) = tempfile.mkstemp()
    os.close(fd)
    try:
        (rc, con) = lgetfilecon_raw(path)
        assert rc == 0
        assert con is not None
    finally:
        os.unlink(path)



# Generated at 2022-06-16 23:27:24.718833
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and an invalid mode
    path = '/etc/passwd'
    mode = -1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:27:27.864924
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:27:30.791793
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:27:33.633243
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-16 23:28:25.040173
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with an invalid mode
    path = '/etc/passwd'
    mode = os.W_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:28:33.602630
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = "/etc/passwd"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a file that does not exist
    path = "/etc/passwd_does_not_exist"
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == None

    # Test with a directory that exists
    path = "/etc"
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test with a directory that does not exist

# Generated at 2022-06-16 23:28:40.024380
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:28:52.734393
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    (rc, con) = matchpathcon(tmpfile, 0)
    if rc != 0:
        raise Exception("matchpathcon failed")

    # Set the context of the file
    rc = lsetfilecon(tmpfile, con)
    if rc != 0:
        raise Exception("lsetfilecon failed")

    # Get the context of the file
    (rc, con) = lgetfilecon_raw(tmpfile)
    if rc != 0:
        raise Exception("lgetfilecon_raw failed")



# Generated at 2022-06-16 23:29:01.931831
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    import os
    import sys
    import stat

    if sys.platform.startswith('linux'):
        path = '/etc/passwd'
        mode = stat.S_IFREG
        rc, con = matchpathcon(path, mode)
        assert rc == 0
        assert con == 'system_u:object_r:passwd_file_t:s0'

    path = '/etc/passwd'
    mode = stat.S_IFDIR
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    path = '/etc/passwd'
    mode = stat.S_IFCHR
    rc, con = matchpathcon(path, mode)
    assert rc == -1

# Generated at 2022-06-16 23:29:05.476619
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    # FIXME: this test is not very useful, it should be rewritten to use selabel_lookup
    #        and test the return code and con value
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:29:09.654605
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd-not-exist')
    assert rc == -1
    assert con is None


# Generated at 2022-06-16 23:29:15.529634
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)

    # Remove the temporary file
    os.remove(path)

    # Check the return code
    assert rc == 0

    # Check the context
    assert con is not None



# Generated at 2022-06-16 23:29:20.801973
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:29:32.186726
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    rc, con = matchpathcon('/etc/passwd/', 0)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path and mode
    rc, con = matchpathcon('/etc/passwd/', 1)
    assert rc == -1
    assert con is None


# Unit