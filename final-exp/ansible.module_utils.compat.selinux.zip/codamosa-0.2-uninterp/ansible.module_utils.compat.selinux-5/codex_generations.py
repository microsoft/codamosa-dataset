

# Generated at 2022-06-16 23:19:48.229044
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, os.R_OK)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:19:54.178885
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/does_not_exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:19:59.372848
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:20:11.361522
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd-does-not-exist')
    assert rc == -1
    assert con is None

    # Test with a directory
    rc, con = lgetfilecon_raw('/etc')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a symlink
    rc, con = lgetfilecon_raw('/etc/passwd-')
    assert rc == 0

# Generated at 2022-06-16 23:20:16.090178
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(path)

# Generated at 2022-06-16 23:20:20.500997
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd-does-not-exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:26.209311
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:20:38.485725
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    from ansible.module_utils.selinux import matchpathcon

    (fd, path) = tempfile.mkstemp()
    os.close(fd)
    os.unlink(path)

    (rc, con) = matchpathcon(path, os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    (rc, con) = matchpathcon(path, os.W_OK)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    (rc, con) = matchpathcon(path, os.X_OK)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-16 23:20:44.109995
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        return

    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0, 'matchpathcon failed with rc: {0}'.format(rc)
    assert con == 'system_u:object_r:passwd_file_t:s0', 'matchpathcon failed with con: {0}'.format(con)



# Generated at 2022-06-16 23:20:55.273539
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-16 23:21:00.053701
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:21:03.478618
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:21:05.527862
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:21:10.246300
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd_not_exist') == [-1, None]


# Generated at 2022-06-16 23:21:14.198181
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:19.612753
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:23.226005
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/etc/passwd'
    rc, con = lgetfilecon_raw(test_path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:27.983100
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    if rc == 0:
        print('{0} has context {1}'.format(path, con))
    else:
        print('{0} has no context'.format(path))


# Generated at 2022-06-16 23:21:32.897164
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import os

    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con.startswith('unconfined_u:object_r:user_tmp_t:s0')
    finally:
        os.unlink(path)



# Generated at 2022-06-16 23:21:36.692986
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:21:45.565129
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    path = '/etc/doesnotexist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:21:52.914049
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    test_file = os.path.join(tmpdir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')

    # Get the context of the file
    [rc, con] = matchpathcon(test_file, 0)
    assert rc == 0

    # Cleanup
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:21:59.189252
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import os

    # create a temp file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # get the context of the temp file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # cleanup
    os.remove(path)

# Generated at 2022-06-16 23:22:06.836779
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, 'testfile')
    with open(tmpfile, 'w') as f:
        f.write('test')

    try:
        rc, con = lgetfilecon_raw(tmpfile)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:22:13.449510
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:22:17.166263
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test function lgetfilecon_raw
    """
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-16 23:22:28.120369
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a non-existent path
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and an invalid mode
    path = '/etc/passwd'
    mode = -1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

# Generated at 2022-06-16 23:22:37.937577
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/does_not_exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a file that exists and a mode that does not exist
    path = '/etc/passwd'
    mode = os.R_OK + os.W_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:22:45.378564
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for a file that exists with a mode that does not exist
    path = '/etc/passwd'
    mode = os.X_OK

# Generated at 2022-06-16 23:22:50.893546
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import os
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Set the file mode to 0644
    os.chmod(tmpfile.name, stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)
    # Get the file context
    [rc, con] = matchpathcon(tmpfile.name, 0)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    # Check the return code
    assert rc == 0
    # Check the file context

# Generated at 2022-06-16 23:23:02.456663
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:unlabeled_t:s0'
    finally:
        os.unlink(path)



# Generated at 2022-06-16 23:23:09.682626
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with an invalid mode
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:23:15.962120
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)

    # Clean up
    os.unlink(path)

    assert rc == 0
    assert con is not None

# Generated at 2022-06-16 23:23:19.433488
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert rc == 0
    assert con == 'system_u:object_r:root_t:s0'



# Generated at 2022-06-16 23:23:25.725713
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(testfile)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:23:35.039943
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    path = '/etc/passwd-invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a valid path and invalid mode
   

# Generated at 2022-06-16 23:23:41.718658
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(path)

# Generated at 2022-06-16 23:23:44.907383
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:23:47.668943
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:23:53.131833
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:24:06.287677
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a non-existent path
    rc, con = matchpathcon('/etc/passwd2', 0)
    assert rc == -1
    assert con is None

    # Test with a non-existent path and a mode that will not cause an error
    rc, con = matchpathcon('/etc/passwd2', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:24:16.394291
# Unit test for function lgetfilecon_raw

# Generated at 2022-06-16 23:24:24.127624
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:24:27.068100
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:24:38.813560
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:24:47.350209
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with valid path and mode

# Generated at 2022-06-16 23:24:52.325547
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/etc/passwd'
    rc, con = lgetfilecon_raw(test_path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:25:01.892904
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    # Test with a directory that exists
    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist

# Generated at 2022-06-16 23:25:05.720550
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:25:12.838814
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that doesn't exist
    path = '/etc/passwd-does-not-exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:25:34.424309
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test matchpathcon with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test matchpathcon with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test matchpathcon with a directory that exists
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:25:37.218058
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:25:40.091876
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:25:51.002286
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a non-existent path
    path = '/etc/passwd_'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a non-existent path and mode set to 1
    path = '/etc/passwd_'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Unit test

# Generated at 2022-06-16 23:25:54.405637
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:25:59.694682
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    # Get the context of the file
    rc, con = matchpathcon(tmpfile, 0)
    assert rc == 0
    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:26:03.050310
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/hosts'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-16 23:26:06.736960
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:26:14.266405
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    # Get the context of the file
    rc, con = matchpathcon(tmpfile, 0)
    # Delete the temporary directory
    shutil.rmtree(tmpdir)
    # Return the context
    return con

# Generated at 2022-06-16 23:26:21.068964
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:26:50.976036
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    [rc, con] = lgetfilecon_raw(tmpfile)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Check the return code
    assert rc == 0

    # Check the context
    assert con is not None


# Generated at 2022-06-16 23:27:01.002221
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the temporary directory
    (rc, con) = matchpathcon(tmpdir, os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Get the context of the temporary file
    (rc, con) = matchpathcon(tmpfile, os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Clean up
    os.unlink(tmpfile)
    os.r

# Generated at 2022-06-16 23:27:08.554589
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:27:18.124278
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as f:
        f.write('test')

    # Get the context of the file
    rc, con = lgetfilecon_raw(testfile)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Check the return code
    assert rc == 0

    # Check the context
    assert con == 'system_u:object_r:user_home_t:s0'

# Generated at 2022-06-16 23:27:22.958248
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:27:25.533106
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:27:31.053449
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd-does-not-exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:27:36.917799
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    rc, con = matchpathcon('/etc/passwd_invalid', 0)
    assert rc == -1
    assert con == ''

    # Test with an invalid mode
    rc, con = matchpathcon('/etc/passwd', -1)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:27:45.857060
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as f:
        f.write('test')

    # Get the context of the file
    [rc, con] = matchpathcon(testfile, 0)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:27:52.439892
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_not_exist'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:28:46.091013
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    # Test with a file that does not exist
    assert matchpathcon('/etc/passwd-does-not-exist', 0) == [-1, None]
    # Test with a directory that exists
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t:s0']
    # Test with a directory that does not exist
    assert matchpathcon('/etc-does-not-exist', 0) == [-1, None]
    # Test with a file that exists and a mode that does not exist
    assert matchpathcon('/etc/passwd', -1) == [-1, None]
   

# Generated at 2022-06-16 23:28:56.748806
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:28:59.827983
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:29:10.414769
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:29:20.734164
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:29:32.208553
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:29:38.293265
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:29:45.709046
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-not-exist'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist
   