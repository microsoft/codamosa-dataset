

# Generated at 2022-06-16 23:19:55.108167
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test if the function returns the expected value
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-16 23:19:59.371623
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd_not_exist') == [-1, None]



# Generated at 2022-06-16 23:20:03.311995
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:09.342686
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Test with a file that does not exist
    path = '/etc/passwd.bak'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:15.869088
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:28.217941
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path but invalid mode
    path = '/etc/passwd'
    mode = os.W_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:36.435049
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Get the context of the file
    [rc, con] = lgetfilecon_raw(tmpfile.name)

    # Clean up
    tmpfile.close()
    shutil.rmtree(tmpdir)

    # Check that the context was retrieved successfully
    assert rc == 0
    assert con is not None

# Generated at 2022-06-16 23:20:41.743566
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Get the context of the file
    context = matchpathcon(tmpfile.name, 0)[1]
    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    assert context is not None

# Generated at 2022-06-16 23:20:45.033167
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd_does_not_exist') == [-1, None]


# Generated at 2022-06-16 23:20:48.590308
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"



# Generated at 2022-06-16 23:20:54.280127
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:58.498895
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:07.018596
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
   

# Generated at 2022-06-16 23:21:10.589181
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:14.455598
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:19.714434
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:21:30.529261
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with invalid path and mode

# Generated at 2022-06-16 23:21:34.229629
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:36.442380
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/selinux/config', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-16 23:21:38.700403
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:44.375240
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:21:47.708923
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:55.605848
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
   

# Generated at 2022-06-16 23:22:03.287406
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(testfile)
        assert rc == 0
        assert con == 'system_u:object_r:user_home_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:22:07.184832
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:10.356937
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-16 23:22:14.264263
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/tmp/test_matchpathcon'
    test_mode = 0o777
    test_con = 'system_u:object_r:tmp_t:s0'
    rc, con = matchpathcon(test_path, test_mode)
    assert rc == 0
    assert con == test_con

# Generated at 2022-06-16 23:22:16.769732
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:22:21.395245
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that doesn't exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:22:33.391858
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test matchpathcon with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test matchpathcon with an invalid path
    path = '/etc/passwd_invalid'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test matchpathcon with a valid path and an invalid mode
    path = '/etc/passwd'
    mode = os.W_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''


# Unit test

# Generated at 2022-06-16 23:22:42.857646
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        fd, fname = tempfile.mkstemp(dir=tmpdir)
        os.close(fd)
        rc, con = lgetfilecon_raw(fname)
        assert rc == 0
        assert con.startswith('system_u:object_r:')
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:22:50.792421
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:23:01.756497
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that doesn't exist
    path = '/etc/passwd_does_not_exist'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:23:04.668018
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:23:10.875260
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, "testfile")
    with open(testfile, 'w') as f:
        f.write("test")

    # Get the context of the file
    rc, con = matchpathcon(testfile, 0)
    assert rc == 0
    assert con == "system_u:object_r:tmp_t:s0"

    # Clean up
    os.remove(testfile)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:23:17.683871
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        rc, con = matchpathcon(path, 0)
        assert rc == 0
        assert con == 'system_u:object_r:unlabeled_t:s0'
    finally:
        os.unlink(path)



# Generated at 2022-06-16 23:23:22.242911
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    fd, path = tempfile.mkstemp()
    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:unlabeled_t:s0'
    finally:
        os.close(fd)
        os.remove(path)



# Generated at 2022-06-16 23:23:28.886390
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Remove the temporary file
    os.remove(path)

# Generated at 2022-06-16 23:23:31.662927
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:23:34.341928
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = matchpathcon('/etc/passwd', 0)
        assert rc == 0
        assert con == 'system_u:object_r:etc_runtime_t:s0'
    except ImportError:
        pass

# Generated at 2022-06-16 23:23:43.847788
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    # Test for a file that does not exist
    assert lgetfilecon_raw('/etc/passwd_does_not_exist')[0] == -1

# Generated at 2022-06-16 23:23:52.684601
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that doesn't exist
    path = '/etc/passwd_does_not_exist'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that exists
    path = '/etc'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    #

# Generated at 2022-06-16 23:23:56.192365
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:23:59.039945
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:24:01.050244
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:24:03.521985
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/tmp/test_matchpathcon'
    mode = 0o777
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:24:08.161190
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']


# Generated at 2022-06-16 23:24:12.230241
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:24:14.540531
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:24:19.968558
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:24:31.704675
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:24:41.906873
# Unit test for function matchpathcon
def test_matchpathcon():
    # test with a file that exists
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # test with a file that does not exist
    rc, con = matchpathcon('/etc/passwd2', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # test with a directory that exists
    rc, con = matchpathcon('/etc', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # test with a directory that does not exist
    rc, con = matchpathcon('/etc2', 0)
    assert rc == 0

# Generated at 2022-06-16 23:24:52.652324
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:25:00.894173
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os
    import os.path
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as f:
        f.write('test')

    # Get the file context
    [rc, con] = lgetfilecon_raw(testfile)
    assert rc == 0
    assert con is not None

    # Remove the temporary directory
    shutil.rmtree(tmpdir)



# Generated at 2022-06-16 23:25:12.914622
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        # Create a file in the temporary directory
        fd, path = tempfile.mkstemp(dir=tmpdir)
        os.close(fd)

        # Get the context of the file
        rc, con = matchpathcon(path, 0)
        assert rc == 0
        assert con is not None

        # Set the context of the file
        rc = lsetfilecon(path, con)
        assert rc == 0

        # Get the context of the file again
        rc, con2 = lgetfilecon_raw(path)
        assert rc == 0
        assert con2 is not None

        # Compare the contexts
        assert con == con2

    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:25:17.033097
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for a file that does not exist
    path = '/etc/passwd_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:25:20.123166
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:25:31.308619
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    rc, con = matchpathcon('/etc/passwd_does_not_exist', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that exists
    rc, con = matchpathcon('/etc', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist
    rc, con = matchpathcon('/etc_does_not_exist', 0)


# Generated at 2022-06-16 23:25:37.564876
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    try:
        fd, path = tempfile.mkstemp(dir=tmpdir)
        os.close(fd)
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con.startswith('unconfined_u:object_r:user_tmp_t:s0')
    finally:
        os.unlink(path)
        os.rmdir(tmpdir)

# Generated at 2022-06-16 23:25:46.876849
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Get the context of the temporary directory
    rc, con = matchpathcon(tmpdir, 0)
    assert rc == 0
    assert con is not None

    # Get the context of the temporary file
    rc, con = matchpathcon(tmpfile.name, 0)
    assert rc == 0
    assert con is not None

    # Remove the temporary file and directory
    tmpfile.close()
    os.rmdir(tmpdir)

# Generated at 2022-06-16 23:25:58.925122
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:26:02.081599
# Unit test for function matchpathcon
def test_matchpathcon():
    # test matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:26:05.680249
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:26:08.936819
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:26:17.037237
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:26:28.332670
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:26:31.570582
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:26:34.103876
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    print('rc: {0}, con: {1}'.format(rc, con))



# Generated at 2022-06-16 23:26:41.240116
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-16 23:26:47.504597
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con.startswith('unconfined_u:object_r:user_home_t:s0')

    # Test with a file that doesn't exist
    rc, con = lgetfilecon_raw('/etc/passwd-does-not-exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:27:13.401457
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:27:23.873145
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'test_file')
    with open(test_file, 'w') as f:
        f.write('test')
    os.chmod(test_file, stat.S_IRWXU)

    # test file
    rc, con = lgetfilecon_raw(test_file)
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_home_t:s0'

    # test dir
    rc, con = lgetfilecon_raw(test_dir)
    assert rc == 0

# Generated at 2022-06-16 23:27:26.557989
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:27:32.654989
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    # Get the context of the file
    (rc, con) = matchpathcon(tmpfile, 0)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    # Return the context
    return con


# Generated at 2022-06-16 23:27:35.086469
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:27:40.391348
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for invalid path
    path = '/etc/passwd1'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test for invalid mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:27:43.753709
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:27:51.642261
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, 'testfile')
        with open(path, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'

    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:27:57.474502
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd_does_not_exist') == [-1, None]



# Generated at 2022-06-16 23:28:07.270165
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:29:01.896908
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = "/etc/passwd"
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a file that does not exist
    path = "/etc/passwd-does-not-exist"
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a directory that exists
    path = "/etc"
    mode = os.stat(path).st_mode

# Generated at 2022-06-16 23:29:06.727802
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:29:08.778485
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:29:13.682284
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-16 23:29:17.895550
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:29:21.069180
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:29:28.563263
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0

    # Delete the file
    os.unlink(path)

# Generated at 2022-06-16 23:29:33.674029
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:29:39.866243
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for success
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test for failure
    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:29:42.184713
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

