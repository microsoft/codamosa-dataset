

# Generated at 2022-06-16 23:19:47.173709
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Test with a file that doesn't exist
    path = '/etc/passwd-does-not-exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:19:48.481266
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:19:57.925877
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and a mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path and a

# Generated at 2022-06-16 23:20:00.865646
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:20:12.658196
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:20:20.832813
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test for a directory that exists
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for a directory that does not exist

# Generated at 2022-06-16 23:20:30.494471
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a valid

# Generated at 2022-06-16 23:20:34.099516
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:41.449867
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:51.585601
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path and mode

# Generated at 2022-06-16 23:20:57.183765
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:20:59.963360
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-16 23:21:03.123255
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-16 23:21:05.774877
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:21:11.365408
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:21:19.401112
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the temporary directory
    rc, con = matchpathcon(tmpdir, 0)
    if rc != 0:
        raise Exception("matchpathcon failed: %s" % con)

    # Set the context of the temporary file
    rc = lsetfilecon(tmpfile, con)
    if rc != 0:
        raise Exception("lsetfilecon failed: %s" % con)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(tmpfile)

# Generated at 2022-06-16 23:21:23.016342
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:21:27.057291
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:32.349040
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd2')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:21:43.915594
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.W_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:21:52.647600
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test for a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:21:57.403839
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-16 23:22:08.509054
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)

    # Clean up
    os.unlink(path)
    shutil.rmtree(tmpdir)

    if rc != 0:
        raise Exception('matchpathcon failed with error code %d' % rc)

    if con is None:
        raise Exception('matchpathcon returned None')

    if con == '':
        raise Exception('matchpathcon returned empty string')

    print('matchpathcon returned %s' % con)

# Generated at 2022-06-16 23:22:17.850083
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/invalid/path'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and a mode
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path and

# Generated at 2022-06-16 23:22:29.380034
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/doesnotexist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a file that exists but we do not have permission to read
    path = '/etc/shadow'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:22:34.209500
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/tmp/doesnotexist')
    assert rc == -1
    assert con is None

    # Test with a file that does exist
    rc, con = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert con is not None



# Generated at 2022-06-16 23:22:39.926066
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    try:
        test_file = os.path.join(test_dir, 'test_file')
        with open(test_file, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(test_file)
        assert rc == 0
        assert con

    finally:
        shutil.rmtree(test_dir)

# Generated at 2022-06-16 23:22:44.764585
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:22:56.515970
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a directory that exists
    path = '/etc'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist

# Generated at 2022-06-16 23:23:01.888833
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con is not None

    # Clean up
    os.remove(tmpfile)

# Generated at 2022-06-16 23:23:14.910352
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    tmpfile = os.path.join(tmpdir, "tmpfile")
    with open(tmpfile, 'w') as f:
        f.write("test")

    # Get the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con == "system_u:object_r:user_tmp_t:s0"

    # Clean up
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:23:24.237747
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = "/etc/passwd"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with an invalid path
    path = "/etc/passwd/invalid"
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    path = "/etc/passwd"
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a valid path and invalid mode

# Generated at 2022-06-16 23:23:34.132725
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Change the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Change the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Change the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc

# Generated at 2022-06-16 23:23:41.911582
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd_does_not_exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:23:45.753823
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:23:53.667933
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the file context
    rc, con = lgetfilecon_raw(path)

    # Delete the file and temporary directory
    os.unlink(path)
    shutil.rmtree(tmpdir)

    # Check the return code
    assert rc == 0

    # Check the file context
    assert con is not None
    assert con != ''



# Generated at 2022-06-16 23:23:58.603420
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Clean up
    os.unlink(path)

# Generated at 2022-06-16 23:24:05.447909
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd')[0] == 0
    assert lgetfilecon_raw(b'/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw(b'/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw(b'/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw(b'/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:24:15.449341
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary directory
    (rc, con) = matchpathcon(tmpdir, 0)
    assert rc == 0
    assert con is not None

    # Get the context of the temporary file
    (rc, con) = matchpathcon(tmpfile, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(tmpfile)
    os.rmdir(tmpdir)

# Generated at 2022-06-16 23:24:19.299623
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:24:36.311049
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon function
    """
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 3)
    assert rc == 0

# Generated at 2022-06-16 23:24:42.471822
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a file that does not exist
    path = "/etc/passwd_not_exist"
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None


# Generated at 2022-06-16 23:24:45.259928
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:52.917706
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    (rc, con) = matchpathcon(tmpfile, 0)
    assert rc == 0
    assert con is not None

    # Clean up
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:24:57.111023
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:25:03.264895
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import os
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Set the SELinux context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Clean up
    os.unlink(path)
    shutil.rmtree(tmpdir)


# Generated at 2022-06-16 23:25:14.509287
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test with a file that does not exist
    path = "/etc/passwd-not-exist"
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    # Test with a directory that exists
    path = "/etc"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test with a directory that does not exist
    path = "/etc-not-exist"

# Generated at 2022-06-16 23:25:25.400631
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Set the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0, "lgetfilecon_raw failed"
    assert con == "system_u:object_r:tmp_t:s0", "lgetfilecon_raw returned unexpected context"

    # Clean up
    os.close(fd)
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)


# Generated at 2022-06-16 23:25:29.015305
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:25:32.757530
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:25:53.349111
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = "/etc/passwd"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a file that does not exist
    path = "/etc/passwd_does_not_exist"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a directory that exists
    path = "/etc"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:26:01.297954
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = os.stat(path).st_mode

# Generated at 2022-06-16 23:26:05.403174
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/test_file'
    f = open(path, 'w')
    f.close()
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'
    os.remove(path)

# Generated at 2022-06-16 23:26:13.640474
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    try:
        path = os.path.join(temp_dir, 'test_file')
        with open(path, 'w') as f:
            f.write('test')

        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:user_home_t:s0'
    finally:
        shutil.rmtree(temp_dir)

# Generated at 2022-06-16 23:26:16.850623
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/test_matchpathcon"
    mode = 0o777
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:tmp_t:s0"

# Generated at 2022-06-16 23:26:25.111203
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file inside the temporary directory
    testfile = os.path.join(tmpdir, 'testfile')
    open(testfile, 'a').close()
    # Get the context of the file
    [rc, con] = matchpathcon(testfile, 0)
    # Delete the temporary directory
    shutil.rmtree(tmpdir)
    # Return the context
    return con

# Generated at 2022-06-16 23:26:30.485397
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        fd, fname = tempfile.mkstemp(dir=tmpdir)
        os.close(fd)
        rc, con = lgetfilecon_raw(fname)
        assert rc == 0
        assert con is not None
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:26:40.488802
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:26:51.176061
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that doesn't exist
    path = '/etc/passwd.bak'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:27:01.216769
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    rc, con = matchpathcon('/etc/passwd-does-not-exist', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    rc, con = matchpathcon('/etc', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist

# Generated at 2022-06-16 23:27:33.674718
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 3)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:27:37.984214
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that doesn't exist
    rc, con = lgetfilecon_raw('/tmp/file_does_not_exist')
    assert rc == -1
    assert con is None

    # Test with a file that does exist
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-16 23:27:49.107192
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:27:52.286921
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        rc, con = lgetfilecon_raw(tmpdir)
        assert rc == 0
        assert con is not None
    finally:
        shutil.rmtree(tmpdir)



# Generated at 2022-06-16 23:28:00.165263
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:28:05.525832
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:28:13.404064
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 3)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:28:22.143945
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:28:26.666376
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:28:31.587930
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:29:23.403422
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    (rc, con) = lgetfilecon_raw(tmpfile)
    if rc != 0:
        raise OSError(rc, os.strerror(rc))

    # Set the context of the file
    rc = lsetfilecon(tmpfile, con)
    if rc != 0:
        raise OSError(rc, os.strerror(rc))

    # Get the context of the file
    (rc, con) = lgetfilecon_raw(tmpfile)


# Generated at 2022-06-16 23:29:32.564763
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'
    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'
    rc, con = matchpathcon('/etc/passwd', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'
    rc, con = matchpathcon('/etc/passwd', 3)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'
    rc, con = matchpathcon('/etc/passwd', 4)

# Generated at 2022-06-16 23:29:43.058720
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = "/etc/passwd"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with an invalid path
    path = "/etc/passwd_"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ""

    # Test with a valid path and mode
    path = "/etc/passwd"
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test with a valid path and mode
    path