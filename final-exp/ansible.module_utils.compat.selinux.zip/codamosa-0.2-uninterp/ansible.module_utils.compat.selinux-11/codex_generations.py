

# Generated at 2022-06-16 23:19:44.400942
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with an invalid mode
    path = '/etc/passwd'
    mode = -1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:19:49.103267
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    rc, con = matchpathcon('/etc/passwd-does-not-exist', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    rc, con = matchpathcon('/etc', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist

# Generated at 2022-06-16 23:19:54.737450
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Test for a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:05.961148
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Check if the function is working properly
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    # Check if the function is returning the expected value
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    # Check if the function is returning the expected value
    assert lgetfilecon_raw('/etc/passwd')[1] != 'system_u:object_r:etc_runtime_t:s1'
    # Check if the function is returning the expected value
    assert lgetfilecon_raw('/etc/passwd')[1] != 'system_u:object_r:etc_runtime_t:s2'
    # Check if the function is returning the expected value
    assert lgetfilecon

# Generated at 2022-06-16 23:20:09.882223
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:20:16.350312
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd_does_not_exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:20:19.229186
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:20:27.549639
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Get the context of the temporary directory
    rc, con = matchpathcon(tmpdir, os.R_OK)
    # Get the context of the temporary file
    rc, con = matchpathcon(tmpfile.name, os.R_OK)
    # Clean up
    tmpfile.close()
    os.rmdir(tmpdir)

# Generated at 2022-06-16 23:20:30.577822
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-16 23:20:34.373136
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Cleanup
    os.remove(path)

# Generated at 2022-06-16 23:20:45.732128
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a valid path and invalid mode

# Generated at 2022-06-16 23:20:48.258108
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:20:53.300810
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:21:01.288807
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, context = lgetfilecon_raw(path)

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

    # Check the return code
    assert rc == 0

    # Check the context
    assert context is not None

# Generated at 2022-06-16 23:21:04.152043
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test'
    mode = 0o777
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:21:10.490615
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:21:14.695730
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test_matchpathcon'
    mode = 0o777
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-16 23:21:27.505737
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test for a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    # Test for a directory that exists
    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for a directory that does not exist
    path = '/etc_does_not_exist'

# Generated at 2022-06-16 23:21:30.699804
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:21:34.186647
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()
    try:
        os.close(fd)
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con is not None
    finally:
        os.unlink(path)

# Generated at 2022-06-16 23:21:41.479095
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:21:45.436972
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con.startswith('unconfined_u:object_r:user_tmp_t:s0')
    finally:
        os.unlink(path)



# Generated at 2022-06-16 23:21:51.094712
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Clean up
    os.unlink(path)

# Generated at 2022-06-16 23:21:57.820442
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0

    # Delete the temporary file
    os.unlink(path)



# Generated at 2022-06-16 23:22:06.731047
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that is not in the policy
    path = '/tmp/test_matchpathcon'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'
    # Test with a file that is in the policy
    path = '/etc/passwd'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:22:10.357707
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:15.012731
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:22:17.291071
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:22:29.019054
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-16 23:22:32.522804
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"


# Generated at 2022-06-16 23:22:44.073410
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)


# Generated at 2022-06-16 23:22:52.481958
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:23:03.180741
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-16 23:23:10.754790
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 2) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 3) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 4) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', 5)

# Generated at 2022-06-16 23:23:20.209825
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    (rc, con) = lgetfilecon_raw(tmpfile)

    # Clean up
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)

    # Check the return code
    assert rc == 0

    # Check the context
    assert con is not None

# Generated at 2022-06-16 23:23:25.445828
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Get the context of the temporary file
    [rc, con] = matchpathcon(tmpfile.name, os.R_OK)

    # Delete the temporary file
    tmpfile.close()

    # Delete the temporary directory
    os.rmdir(tmpdir)

    # Check the return code
    assert rc == 0

    # Check the context
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:23:34.872619
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 3)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc,

# Generated at 2022-06-16 23:23:39.414626
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:23:50.197070
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:23:58.238932
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test lgetfilecon_raw function
    """
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_no_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:24:20.441846
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:24:24.783204
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"



# Generated at 2022-06-16 23:24:36.493763
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 1: Test for a file that exists
    path = "/etc/passwd"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

    # Test 2: Test for a file that does not exist
    path = "/etc/passwd1"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ""

    # Test 3: Test for a directory that exists
    path = "/etc"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:24:39.771176
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:45.410060
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    (fd, path) = tempfile.mkstemp(dir=tmpdir)

    # Get the context of the file
    (rc, con) = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Change the context of the file
    rc = lsetfilecon(path, con)
    assert rc == 0

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:24:49.546004
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:24:57.248306
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test_file')
    with open(tmp_file, 'w') as f:
        f.write('test')

    rc, con = lgetfilecon_raw(tmp_file)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'

    os.remove(tmp_file)
    os.rmdir(tmp_dir)

# Generated at 2022-06-16 23:25:04.152441
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    rc, con = matchpathcon('/etc/passwd', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    rc, con = matchpathcon('/etc/passwd_does_not_exist', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    rc, con = matchpathcon('/etc', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a directory that does not exist
    rc,

# Generated at 2022-06-16 23:25:09.491757
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon
    # FIXME: this is not a real unit test, it just verifies that the function is callable
    #        and returns the expected type of values
    rc, con = matchpathcon('/', 0)
    assert isinstance(rc, int)
    assert isinstance(con, str)

# Generated at 2022-06-16 23:25:17.320720
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
   

# Generated at 2022-06-16 23:25:59.418668
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)

    # Get the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0

    # Clean up
    os.close(fd)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:26:05.798957
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:26:09.167012
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:26:12.466260
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:26:20.162001
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test for a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    # Test for a directory that exists
    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test for a directory that does not exist

# Generated at 2022-06-16 23:26:30.887866
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
   

# Generated at 2022-06-16 23:26:36.652154
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for valid path
    path = '/tmp'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Test for invalid path
    path = '/tmp/invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:26:44.498086
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    tmpfile = os.path.join(tmpdir, 'tmpfile')
    open(tmpfile, 'a').close()

    # Get the context of the file
    rc, con = matchpathcon(tmpfile, 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Clean up
    shutil.rmtree(tmpdir)



# Generated at 2022-06-16 23:26:50.777720
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test matchpathcon with a valid path
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test matchpathcon with an invalid path
    rc, con = matchpathcon('/etc/passwd_invalid', 0)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:27:00.452361
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/invalid/path'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and an invalid mode
    path = '/etc/passwd'
    mode = -1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:28:33.399579
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd-does-not-exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:28:43.233547
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Set the context of the file
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Set the context of the directory
    rc, con = lgetfilecon_raw(tmpdir)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Clean up
    os.unlink(tmpfile)

# Generated at 2022-06-16 23:28:54.710049
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 2
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a valid path and invalid mode

# Generated at 2022-06-16 23:28:59.755212
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/foo'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-16 23:29:08.053911
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:unlabeled_t:s0'
    finally:
        os.unlink(path)



# Generated at 2022-06-16 23:29:14.124630
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:29:18.770001
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:29:23.886157
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a file in the temporary directory
    tmppath = os.path.join(tmpdir, 'tmpfile')
    with open(tmppath, 'w') as f:
        f.write('temporary file')
    # Get the context of the file
    [rc, con] = matchpathcon(tmppath, 0)
    # Remove the temporary directory
    shutil.rmtree(tmpdir)
    # Check that the context is not empty
    assert con != ''

# Generated at 2022-06-16 23:29:32.548633
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/invalid'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with an invalid mode
    path = '/etc/passwd'
    mode = -1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:29:40.164297
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that doesn't exist
    rc, con = lgetfilecon_raw('/etc/passwd_does_not_exist')
    assert rc == -1
    assert con is None

