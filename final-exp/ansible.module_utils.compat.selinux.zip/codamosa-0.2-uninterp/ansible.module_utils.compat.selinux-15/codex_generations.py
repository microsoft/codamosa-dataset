

# Generated at 2022-06-16 23:19:49.760117
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a non-existent path
    path = '/etc/passwd_'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a non-existent mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:19:58.751803
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path and mode

# Generated at 2022-06-16 23:20:06.300327
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, 'testfile')
        with open(path, 'w') as f:
            f.write('test')
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:user_home_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:20:12.415065
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:20:18.705887
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        testfile = os.path.join(tmpdir, 'testfile')
        with open(testfile, 'w') as f:
            f.write('test')

        rc, con = matchpathcon(testfile, 0)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:20:28.700744
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that doesn't exist
    path = '/etc/passwd-does-not-exist'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a file that exists but is not readable
    path = '/etc/shadow'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:20:39.632148
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:20:48.121140
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', os.R_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', os.W_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', os.X_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:20:54.704841
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con

    # Remove the temporary file
    os.remove(path)



# Generated at 2022-06-16 23:20:58.842374
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test_file'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-16 23:21:03.156901
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:21:05.239217
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:21:15.609080
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for file with context
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test for file without context
    path = '/etc/shadow'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'

    # Test for file that does not exist
    path = '/etc/shadow-does-not-exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:21:25.822736
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in temporary directory
    tfile = open(os.path.join(tmpdir, 'testfile'), 'w')
    tfile.close()

    # Get the context of the file
    [rc, con] = matchpathcon(os.path.join(tmpdir, 'testfile'), 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Remove the temporary directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:21:29.001109
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:37.098436
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a directory
    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a non-existent file
    path = '/etc/passwd-not-found'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    # Test with a non-existent directory
    path = '/etc-not-found'
    rc, con = lgetfilecon

# Generated at 2022-06-16 23:21:40.291402
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:21:46.918199
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a directory that exists
    path = '/etc'
    mode = os.stat(path).st_mode

# Generated at 2022-06-16 23:21:55.250248
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path and mode


# Generated at 2022-06-16 23:22:05.301885
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil
    import os
    import os.path
    import stat
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    tmpfile = os.path.join(tmpdir, "file")
    open(tmpfile, 'a').close()

    # Get the context of the file
    [rc, con] = matchpathcon(tmpfile, stat.S_IFREG)
    if rc != 0:
        print("matchpathcon failed: %s" % con)
        sys.exit(1)

    # Clean up
    os.unlink(tmpfile)
    os.rmdir(tmpdir)

# Generated at 2022-06-16 23:22:10.451564
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:17.496134
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    try:
        # Create a file in the temp directory
        fd, fname = tempfile.mkstemp(dir=tmpdir)
        os.close(fd)
        # Get the context of the file
        rc, con = matchpathcon(fname, 0)
        assert rc == 0
        assert con is not None
        # Set the context of the file
        rc = lsetfilecon(fname, con)
        assert rc == 0
    finally:
        shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:22:20.072963
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:22:32.243516
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a directory that exists
    path = '/etc'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-16 23:22:35.032841
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:22:40.697118
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, path = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Set the context of the file
    rc = lsetfilecon(path, con)
    assert rc == 0

    # Get the context of the file
    rc, con2 = lgetfilecon_raw(path)
    assert rc == 0
    assert con2 is not None

    # Compare the contexts
    assert con == con2

    # Remove the temporary directory
   

# Generated at 2022-06-16 23:22:50.453134
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(tmpfile, 0)
    assert rc == 0

    # Set the context of the file
    rc = lsetfilecon(tmpfile, con)
    assert rc == 0

    # Clean up
    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)

# Generated at 2022-06-16 23:22:53.532846
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-16 23:23:00.171563
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Test with a file that doesn't exist
    rc, con = lgetfilecon_raw('/etc/passwd-not-exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:23:03.180188
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:23:11.724165
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:23:22.663413
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', os.R_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', os.W_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/passwd', os.X_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:23:33.777422
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:23:41.320637
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a valid path
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a non-existent path
    rc, con = lgetfilecon_raw('/etc/passwd_does_not_exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:23:45.096413
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_runtime_t:s0"

# Generated at 2022-06-16 23:23:50.928620
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''



# Generated at 2022-06-16 23:23:54.829105
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:23:59.364790
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the file
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:24:02.087831
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:04.657157
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for file that does not exist
    path = '/tmp/file_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None

    # Test for file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None


# Generated at 2022-06-16 23:24:16.204532
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    fd, tmp_path = tempfile.mkstemp()
    os.close(fd)

    try:
        rc, con = lgetfilecon_raw(tmp_path)
        assert rc == 0
        assert con is not None
    finally:
        os.unlink(tmp_path)



# Generated at 2022-06-16 23:24:27.030048
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    rc, con = matchpathcon('/etc/passwd', 3)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:24:31.773527
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:24:34.148247
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-16 23:24:43.799730
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for a file that exists
    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    if rc != 0:
        raise Exception('matchpathcon failed for file {0} with mode {1}'.format(path, mode))
    print('matchpathcon succeeded for file {0} with mode {1}'.format(path, mode))

    # Test for a file that does not exist
    path = '/etc/passwd_does_not_exist'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    if rc != 0:
        raise Exception('matchpathcon failed for file {0} with mode {1}'.format(path, mode))

# Generated at 2022-06-16 23:24:54.756829
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    [rc, con] = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    [rc, con] = matchpathcon('/etc/passwd_invalid', 0)
    assert rc == -1
    assert con is None

    # Test with a valid path and mode
    [rc, con] = matchpathcon('/etc/passwd', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path and mode
    [rc, con] = matchpathcon('/etc/passwd_invalid', 1)
    assert rc == -1

# Generated at 2022-06-16 23:24:58.098535
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:25:00.641947
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:25:04.152946
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-16 23:25:08.039178
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:25:31.922759
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # Cleanup
    os.unlink(path)

# Generated at 2022-06-16 23:25:40.901314
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a non-existent path
    path = '/etc/passwd_'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a valid path and invalid mode

# Generated at 2022-06-16 23:25:45.771947
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import os
    import stat

    fd, path = tempfile.mkstemp()
    os.close(fd)
    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con is not None
    finally:
        os.unlink(path)



# Generated at 2022-06-16 23:25:49.524797
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


# Generated at 2022-06-16 23:25:54.117896
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        return

    path = '/etc/passwd'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-16 23:25:56.258269
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-16 23:25:59.348774
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:26:05.081109
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with a file that does not exist
    rc, con = lgetfilecon_raw('/etc/passwd_not_exist')
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:26:16.341441
# Unit test for function lgetfilecon_raw

# Generated at 2022-06-16 23:26:28.062326
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con == ''

    # Test with a valid path and mode
    path = '/etc/passwd'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

    # Test with an invalid path and mode

# Generated at 2022-06-16 23:27:12.871297
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:27:16.296928
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-16 23:27:25.318678
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:27:34.108182
# Unit test for function matchpathcon

# Generated at 2022-06-16 23:27:37.757576
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-16 23:27:44.228067
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Get the context of the temporary file
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(path)



# Generated at 2022-06-16 23:27:51.917751
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in temporary directory
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Get the context of the file
    rc, con = matchpathcon(tmpfile, 0)
    assert rc == 0
    assert con is not None

    # Clean up
    os.unlink(tmpfile)
    os.rmdir(tmpdir)

# Generated at 2022-06-16 23:27:58.686639
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid path
    path = '/etc/passwd'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with an invalid path
    path = '/etc/passwd_invalid'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:28:04.147338
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None
    assert len(con) > 0

    # Test with a file that does not exist
    path = "/etc/passwd-not-found"
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:28:12.689831
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Test with a file that does not exist
    path = '/etc/passwd_does_not_exist'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-16 23:29:40.339855
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:etc_runtime_t:s0"
