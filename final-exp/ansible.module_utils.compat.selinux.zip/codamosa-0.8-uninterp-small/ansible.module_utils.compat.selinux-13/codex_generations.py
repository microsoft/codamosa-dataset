

# Generated at 2022-06-24 21:17:07.440949
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    f = open(__file__, 'r')
    path = f.name
    f.close()
    [rc, con] = lgetfilecon_raw(path)
    assert(rc < 0)
    assert(con is None)

# Generated at 2022-06-24 21:17:10.105488
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with known input
    test_file = '/etc/selinux/config'
    rc, output = lgetfilecon_raw(test_file)

    assert rc == 0
    assert output != ''


# Generated at 2022-06-24 21:17:16.192359
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/resolv.conf'
    mode = 0
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-24 21:17:18.965291
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon('/usr/bin/id', 0)
    print (rc)


# Generated at 2022-06-24 21:17:21.925439
# Unit test for function matchpathcon
def test_matchpathcon():
    expected = [0, 'system_u:object_r:user_home_dir_t:s0/foo']
    observed = matchpathcon('/foo', 0)
    assert observed == expected



# Generated at 2022-06-24 21:17:26.932440
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fn = lgetfilecon_raw
    #   return [rc, to_native(con.value)]
    path = os.environ.get('HOME', '/')

    rc, con = fn(path)
    assert rc == 0, 'unexpected rc'
    assert con, 'expected a non-empty context'



# Generated at 2022-06-24 21:17:37.739530
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon(b'/etc/hosts', 0)
    assert var_0[0] == -1
    #assert var_0[1] == b'unconfined_u:object_r:etc_t:s0'
    var_0 = matchpathcon(b'/etc/passwd', 0)
    assert var_0[0] == -1
    #assert var_0[1] == b'unconfined_u:object_r:etc_t:s0'
    var_0 = matchpathcon(b'/etc/group', 0)
    assert var_0[0] == -1
    #assert var_0[1] == b'unconfined_u:object_r:etc_t:s0'
    var_0 = matchpathcon(b'/etc/shadow', 0)

# Generated at 2022-06-24 21:17:43.782815
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, value = matchpathcon("/mnt/d/py-proj/ansible/test_utils/sandbox/private/tmp/foo", 0)
    assert rc == 0
    # assert value == "system_u:object_r:public_content_rw_t"
    assert value == "system_u:object_r:public_content_rw_t:s0"



# Generated at 2022-06-24 21:17:48.625128
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/usr/bin/python"
    c_path = c_char_p(path.encode('utf-8'))
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(c_path, byref(con))
    assert rc == 0, rc
    assert con.value is not None, con.value
    _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:17:57.839659
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/etc/shadow")[0] == 0
    assert lgetfilecon_raw("/etc/shadow")[1].startswith("system_u")
    assert lgetfilecon_raw("/etc/shadow")[1].endswith("_t:s0")
    assert lgetfilecon_raw("/etc/shadow")[1].find("_u:object_r:shadow_t") != -1
    assert lgetfilecon_raw("/etc/shadow")[1].find("_u:object_r:etc_runtime_t") == -1
    assert lgetfilecon_raw("/not_a_file")[0] == -1


# Generated at 2022-06-24 21:18:03.062183
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw("/test/test.txt")
    if var_1[0] > -1:
        print("File Label is %s" % var_1[1])
    else:
        print("File Label is unknown")

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-24 21:18:04.525293
# Unit test for function matchpathcon
def test_matchpathcon():
    var_an_arg = matchpathcon /users/test, 0



# Generated at 2022-06-24 21:18:10.399726
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import mock
    import pytest

    # Mocking libc.so.6.getcon function that lgetfilecon_raw relies on.
    # The function returns a static string based on the mocked path
    path_mock = '/var/log/messages'
    con_mock = b'foo:bar'
    libc_mock = mock.patch.object(
        'ctypes.CDLL', 'getcon',
        return_value=con_mock,
        autospec=True,
        kind='return'
    )

    with libc_mock:
        rc, con = lgetfilecon_raw(path_mock)
        assert rc == 0
        assert con == to_native(con_mock)



# Generated at 2022-06-24 21:18:14.757301
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/path/to/file"
    expected_results = (0, None)
    actual_results = lgetfilecon_raw(path)

    assert actual_results == expected_results, "Expected {0}, but got {1}".format(expected_results, actual_results)



# Generated at 2022-06-24 21:18:16.137970
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'file.txt'
    mode = os.O_RDONLY
    assert isinstance(matchpathcon(path, mode), list)



# Generated at 2022-06-24 21:18:16.658986
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw([])

# Generated at 2022-06-24 21:18:18.619516
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/path/to/file'
    mode = 0
    assert(matchpathcon(path, mode) == [0, 'system_u:object_r:usr_t:s0'])


# Generated at 2022-06-24 21:18:22.900237
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/selinux/config'
    mode = 0o600
    con = 'system_u:object_r:etc_t:s0'
    rc, result = matchpathcon(path, mode)
    assert rc == 0
    assert result == con

# Generated at 2022-06-24 21:18:28.182850
# Unit test for function matchpathcon
def test_matchpathcon():
    assert(matchpathcon('/etc/pam.d', 0) == [0, 'system_u:object_r:etc_runtime_t:s0'])
    assert(matchpathcon('/etc/pam.d/', 0) == [0, 'system_u:object_r:etc_runtime_t:s0'])
    assert(matchpathcon('/etc/foo/', 0) == [0, 'system_u:object_r:etc_t:s0'])


# Generated at 2022-06-24 21:18:31.482408
# Unit test for function matchpathcon
def test_matchpathcon():
    path = None
    mode = 0
    matchpathcon(path, mode)


# Generated at 2022-06-24 21:18:35.460642
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp/foo')
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-24 21:18:38.424055
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/path/to/myfile") == [0, 'unconfined_u:object_r:user_home_dir_t:s0']



# Generated at 2022-06-24 21:18:44.535844
# Unit test for function matchpathcon
def test_matchpathcon():
    _test_file = 'test_file.txt'
    _test_context = 'system_u'
    _test_mode = 755

    with open(_test_file, 'w'):
        os.chmod(_test_file, _test_mode)
        _selinux_lib.lsetfilecon(_test_file, _test_context)

    _rc, _context = matchpathcon(_test_file, 0)
    assert  _context == _test_context
    os.unlink(_test_file)



# Generated at 2022-06-24 21:18:51.110567
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
  path = '/tmp/'		# Specify the file path
  (rc, con) = lgetfilecon_raw(path)
  assert rc == 0
  assert con == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-24 21:18:55.730326
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp'
    data = lgetfilecon_raw(path)
    assert data[1] == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-24 21:19:02.420842
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert selinux_getpolicytype()[1] == 'targeted'
    assert matchpathcon('/etc/httpd/conf/httpd.conf', 0)[1] == 'system_u:object_r:httpd_config_t:s0'
    assert is_selinux_enabled()
    assert is_selinux_mls_enabled()
    assert lgetfilecon_raw('/etc/httpd/conf/httpd.conf')[1] == 'system_u:object_r:httpd_config_t:s0'

# Generated at 2022-06-24 21:19:06.901656
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Prepare test data
    path = "/etc/passwd"

    # Check if the function raises expected exceptions
    with pytest.raises(OSError):
        # Call the target function with invalid parameters
        lgetfilecon_raw(path)


# Generated at 2022-06-24 21:19:09.246025
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/test'
    r = lgetfilecon_raw(path)
    c = r[1]


# Generated at 2022-06-24 21:19:17.135698
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: this test is not particularly robust
    # NB: matchpathcon checks that CALLBACK_ERRNO is set and returns -1 if not
    # this check is not performed by this wrapper
    # The following code should be able to detect a failure.
    # It should be tested on multiple systems to ensure that this results in failure on all of them.
    if matchpathcon('/var/tmp', 0)[0] != 0:
        raise AssertionError('Function call failed')


# Generated at 2022-06-24 21:19:17.893400
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    assert True


# Generated at 2022-06-24 21:19:21.459805
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    arg_0 = b"/etc/hosts"

    ret_0 = lgetfilecon_raw(arg_0)


# Generated at 2022-06-24 21:19:27.173295
# Unit test for function matchpathcon
def test_matchpathcon():
    func_name = "matchpathcon"
    print("Testing function: %s" % func_name)

    path = "/"
    mode = 0

    _output = matchpathcon(path, mode)

    print("result: %s" % _output)


if __name__ == "__main__":
    test_case_0()
    test_matchpathcon()

# Generated at 2022-06-24 21:19:32.808248
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon("/home/amal/abc.txt", 0)
    assert result[0] == 0
    assert result[1] == "system_u:object_r:user_home_t:"


# Generated at 2022-06-24 21:19:40.649199
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # For some reason the file's context changes from user_u:user_r:user_t:s0-s0:c0.c1023 to user_u:object_r:user_tmp_t
    path = "/tmp/foo"
    var_0 = lgetfilecon_raw(path)
    print(var_0)
    var_0 = lgetfilecon_raw(path)
    print(var_0)
    assert to_native(var_0) == "[0, 'user_u:object_r:user_tmp_t:s0']"


# Generated at 2022-06-24 21:19:48.242875
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = open('/etc/selinux/targeted/contexts/files/file_contexts', 'w+')
    test_file.write('hello world\n')
    test_file.close()

    (rc, con) = lgetfilecon_raw('/etc/selinux/targeted/contexts/files/file_contexts')
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_tmp_t:s0'

    test_file.write('hello world\n')
    test_file.close()
    os.remove('/etc/selinux/targeted/contexts/files/file_contexts')



# Generated at 2022-06-24 21:19:57.579916
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("tempfile.txt", 0)[0] == -1
    assert matchpathcon("tempfile.txt", 1)[0] == -1
    assert matchpathcon("tempfile.txt", 2)[0] == -1
    assert matchpathcon("tempfile.txt", 3)[0] == -1
    assert matchpathcon("tempfile.txt", 4)[0] == -1
    assert matchpathcon("tempdir", 0)[0] == -1
    assert matchpathcon("tempdir", 1)[0] == -1
    assert matchpathcon("tempdir", 2)[0] == -1
    assert matchpathcon("tempdir", 3)[0] == -1
    assert matchpathcon("tempdir", 4)[0] == -1

# Generated at 2022-06-24 21:20:03.170649
# Unit test for function matchpathcon
def test_matchpathcon():
    assert _selinux_lib.matchpathcon("/home/ansible/file1", 0) == 0


# Generated at 2022-06-24 21:20:05.679952
# Unit test for function matchpathcon
def test_matchpathcon():
    file = '/etc/hosts.deny'
    mode = 384
    ret = matchpathcon(file, mode)
    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-24 21:20:10.782980
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw("/etc/motd")
    assert var_1[0] == 0


# Generated at 2022-06-24 21:20:12.652540
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:tmp_t:s0']


# Generated at 2022-06-24 21:20:18.477181
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-24 21:20:21.956074
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0, "Expected: 0, Received: %s" % lgetfilecon_raw('/etc/passwd')[0]
    assert lgetfilecon_raw('/etc/passwd')[1] == "system_u:object_r:passwd_file_t:s0", "Expected: system_u:object_r:passwd_file_t:s0, Received: %s" % lgetfilecon_raw('/etc/passwd')[1]


# Generated at 2022-06-24 21:20:22.957841
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp/test')
    assert con is None


# Generated at 2022-06-24 21:20:26.308773
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/'
    assert lgetfilecon_raw(path)[1] == 'system_u:object_r:root_t:s0'


# Generated at 2022-06-24 21:20:28.242877
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='/tmp/matchpathcon', mode=0) == [0, 'system_u:object_r:user_tmp_t:s0']

# Generated at 2022-06-24 21:20:30.733998
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path  = "/file/name"
    res = lgetfilecon_raw(path)
    assert res != (1, "context")
    assert res == (0, "context")


# Generated at 2022-06-24 21:20:37.432437
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        file_path = '/etc/hosts'
        var_1 = lgetfilecon_raw(file_path)
        if var_1[0] == 0:
            print("SELinux context of " + file_path + " is  " + var_1[1])
        else:
            raise OSError(var_1[0], " error in lgetfilecon_raw function: " + var_1[1])
    except OSError as e:
        print("error in lgetfilecon_raw: " + str(e))


# Generated at 2022-06-24 21:20:41.105396
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    return


# Generated at 2022-06-24 21:20:47.530653
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Unit test for function matchpathcon
    """
    con = c_char_p()
    rc = matchpathcon("/etc/passwd", 0)
    rc = lgetfilecon_raw("/etc/passwd")
    assert rc[0] == 0
    rc = matchpathcon("/etc/passwd", 1)
    assert rc[0] == 0
    rc = matchpathcon("/etc/passwd", 2)
    assert rc[0] == 0
    rc = matchpathcon("/etc/passwd", 3)
    assert rc[0] == 0
    rc = matchpathcon("/etc/passwd", 4)
    assert rc[0] == 0
    rc = matchpathcon("/etc/passwd", 5)
    assert rc[0] == 0

# Generated at 2022-06-24 21:20:51.000901
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = "/etc/hosts"
    rc, output = lgetfilecon_raw(file_path)
    assert rc == 0
    assert output == "system_u:object_r:etc_t:s0"



# Generated at 2022-06-24 21:21:01.444892
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    with open(__file__, 'r') as f:
        assert lgetfilecon_raw(f.fileno()) == ['system_u:object_r:lib_t:s0']


# Generated at 2022-06-24 21:21:03.785171
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/path'
    mode = -1
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:user_home_dir_t:s0']


# Generated at 2022-06-24 21:21:05.208497
# Unit test for function matchpathcon
def test_matchpathcon():
    path = None
    mode = None
    assert matchpathcon(path, mode) == [0, None]


# Generated at 2022-06-24 21:21:11.293808
# Unit test for function matchpathcon
def test_matchpathcon():
    rsrc = "/tmp/test.txt"
    mode = 0o600
    rc, val = matchpathcon(rsrc, mode)
    assert rc == 0
    assert val == "system_u:object_r:tmp_t:s0"



# Generated at 2022-06-24 21:21:14.200547
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, result) = matchpathcon('tests/data/selinux/', 0)
    assert rc == 0
    assert result == 'system_u:object_r:myfiles_t'



# Generated at 2022-06-24 21:21:17.990203
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = None
    try:
        rc, con = lgetfilecon_raw(path)
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:21:24.209043
# Unit test for function matchpathcon
def test_matchpathcon():
    con = c_char_p()
    try:
        # Test the option 'path'
        rc = _selinux_lib.matchpathcon("./selinux.py", 0, byref(con))
        assert to_native(con.value) == "system_u:object_r:ansible_python_t:s0"
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:21:28.152253
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/cron.d/', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('nonexistant', 0) == [-1, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:21:31.841595
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/dev/null', 1) == [0, 'system_u:object_r:null_device_t:s0']


# Generated at 2022-06-24 21:21:36.247121
# Unit test for function matchpathcon
def test_matchpathcon():
    enforcemode = selinux_getenforcemode()[1]
    if enforcemode == 1:
        if selinux_getpolicytype()[1] == 'targeted':
            assert matchpathcon('/etc/selinux/targeted/contexts/files', 0) == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-24 21:21:55.626174
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/home/admin', 0) == [0, b'unconfined_u:object_r:user_home_dir_t:s0']


# Generated at 2022-06-24 21:22:03.169757
# Unit test for function matchpathcon
def test_matchpathcon():
    assert os.path.exists('/usr/bin/matchpathcon'), 'SELinux command "matchpathcon" is not available'
    var_0 = _selinux_lib.matchpathcon('/usr/bin/matchpathcon', 0, None)
    assert var_0 == 0, 'Argument "path" is not a selinux path'
    var_1 = _selinux_lib.matchpathcon('/bin/bash', 0, None)
    assert var_1 == 0, 'Argument "path" is not a selinux path'
    var_2 = _selinux_lib.matchpathcon('/etc/passwd', 0, None)
    assert var_2 == 0, 'Argument "path" is not a selinux path'

# Generated at 2022-06-24 21:22:12.424503
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print('Unit test for lgetfilecon_raw')
    # test with a relative file path
    test_file_path = './test_file'
    fp = open(test_file_path, 'w')
    # get the current context of the file
    rc, selinux_ctx = lgetfilecon_raw(test_file_path)
    assert rc == 0, 'Error: failed lgetfilecon_raw'
    expected_result = 'system_u:object_r:user_tmp_t:s0'
    # File context should be current
    assert selinux_ctx == expected_result, 'Error: incorrect file context'
    # reload policy, so that we can change the file context
    reload_selinux_policy_fn = 'selinux_reload_policy'

# Generated at 2022-06-24 21:22:13.560994
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    current_path = os.getcwd()
    assert type(lgetfilecon_raw(current_path)) == list


# Generated at 2022-06-24 21:22:17.186005
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/ansible-test-dir/test_dir_file_context"
    [rc, result] = lgetfilecon_raw(path)

    if rc == 0:
        assert result == "system_u:object_r:user_tmp_t:s0"
    else:
        assert False


# Generated at 2022-06-24 21:22:20.511140
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert (lgetfilecon_raw('/path') == [0, '.'])


# Generated at 2022-06-24 21:22:22.807132
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, out = matchpathcon('/tmp/foo', 1)
    assert rc == 0
    assert out == 'system_u:object_r:mytest_file_t'



# Generated at 2022-06-24 21:22:26.892996
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "asdas"
    assert selinux_getenforcemode() == 0, "Error implementing lgetfilecon_raw"


# ansible_module_selinux_ctypes._module_setup()
# selinux_getenforcemode()

# Generated at 2022-06-24 21:22:29.368412
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert (matchpathcon('/etc/hosts', 0) == [0, 'system_u:object_r:etc_runtime_t:s0'])
    except:
        import traceback
        traceback.print_exc()
        assert False


# Generated at 2022-06-24 21:22:32.775592
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/etc/selinux/strict/contexts/files/file_contexts')
    if var_1[0] != 0:
        raise Exception('non-zero return value: {0}'.format(var_1[0]))

    # FIXME: assert var_1[1] == 'unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023'



# Generated at 2022-06-24 21:23:17.234161
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/foo')
    if rc != -1:
        assert rc != -1
        assert con == b"<<none>>:<<none>>"


# Generated at 2022-06-24 21:23:20.412281
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon('/', 0)
    assert var_1[0] == 0
    assert var_1[1] == 'system_u:object_r:root_t'



# Generated at 2022-06-24 21:23:21.953749
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(None, None) == [0, None]


# Generated at 2022-06-24 21:23:23.393166
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    lgetfilecon_raw('/tmp')

# Generated at 2022-06-24 21:23:29.805443
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/var/tmp'
    mode = 0
    ret = matchpathcon(path, mode)
    assert [0, 'system_u:object_r:var_tmp_t:s0'] == ret



# Generated at 2022-06-24 21:23:33.781758
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/foo/bar'
    mode = 0
    assert matchpathcon(path, mode) == [2, 'user_u:object_r:user_tmp_t']



# Generated at 2022-06-24 21:23:36.640358
# Unit test for function matchpathcon
def test_matchpathcon():
    assert to_native(matchpathcon(to_bytes(os.path.sep, errors='surrogate_or_strict'), 0)[1]) == 'system_u:object_r:root_t:s0'


# Generated at 2022-06-24 21:23:38.745781
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    @param path
    @param mode
    @return (rc, con)
    '''
    # TODO: need a test for this
    pass


# Generated at 2022-06-24 21:23:41.706355
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/sudoers')[0] == 0
    assert lgetfilecon_raw('/etc/sudoers')[1] == 'unconfined_u:object_r:etc_t:s0'


# Generated at 2022-06-24 21:23:46.968353
# Unit test for function matchpathcon
def test_matchpathcon():
    arg_path = '/path'
    arg_mode = 1
    expected_result = [0, 'system_u:object_r:svirt_tcg_file_t']
    with mock.patch.object(ctypes, 'create_string_buffer') as mock_create_string_buffer:
        with mock.patch.object(os, 'strerror') as mock_strerror:
            with mock.patch.object(ctypes, 'byref') as mock_byref:
                with mock.patch.object(ctypes, 'get_errno') as mock_get_errno:
                    with mock.patch.object(ctypes, 'CDLL') as mock_CDLL:
                        mock_CDLL.return_value.matchpathcon.return_value = 0
                        mock_byref.return_value = 0
                        mock

# Generated at 2022-06-24 21:25:26.191354
# Unit test for function matchpathcon
def test_matchpathcon():
    assert lgetfilecon_raw('/etc/system-release-cpe') == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/etc/system-release-cpe', 0)[1] == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-24 21:25:29.117478
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/path/to/file', 0)
    assert rc == 0
    assert con == 'root:object_r:unreserved_t:s0'


# Generated at 2022-06-24 21:25:31.848610
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp/foo', 0)
    assert type(rc) == int
    assert type(con) == str


__all__ = [test_case_0,
           test_matchpathcon,
           ]

# Generated at 2022-06-24 21:25:37.024910
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Try to use the function
    fn = "/tmp"
    in0 = lgetfilecon_raw(fn)
    if in0[0] != 0:
        sys.stderr.write("Failed to call lgetfilecon_raw('%s'): %s\n" % (fn, in0[1]))
        sys.exit(1)
    print("Checking context on '%s': %s" % (fn, in0[1]))


# Generated at 2022-06-24 21:25:48.167840
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Testing matchpathcon')
    var_0 = matchpathcon(b'/etc/passwd',0)
    if var_0[0] != -1 or str(var_0[1]) != 'None':
        raise Exception('Failed matchpathcon')
    var_1 = matchpathcon(b'/etc/passwd',3)
    if var_1[0] != -13 or str(var_1[1]) != 'None':
        raise Exception('Failed matchpathcon')
    var_2 = matchpathcon(b'/etc/selinux/config',0)
    if var_2[0] != -13 or str(var_2[1]) != 'None':
        raise Exception('Failed matchpathcon')
    var_3 = matchpathcon(b'/etc/selinux/config',3)


# Generated at 2022-06-24 21:25:53.672094
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        temp_file = tempfile.NamedTemporaryFile()
        # Call function to test
        result = lgetfilecon_raw(temp_file.name)

        assert result[0] == 1
        assert type(result[1]) == str
    finally:
        temp_file.close()



# Generated at 2022-06-24 21:26:01.266266
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        # absolute path
        rc, con = matchpathcon('/tmp/file1.txt', os.R_OK)
        assert rc == 0
        # relative path
        rc, con = matchpathcon('../tmp/file1.txt', os.R_OK)
        assert rc == -1
        # directory path is not allowed
        rc, con = matchpathcon('/tmp/', os.R_OK)
        assert rc == -1
    except Exception as e:
        raise AssertionError('Expected selinux matchpathcon to pass, but got {0}'.format(e))



# Generated at 2022-06-24 21:26:08.637342
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/group"
    rc, con = lgetfilecon_raw(path)
    if rc == 0:
        assert con == "system_u:object_r:etc_runtime_t:s0"
    else:
        # NOTE: at least one file in the system does not have the SELinux
        #       context set (at least on Fedora 34)
        assert rc == -1

# Unit tests for functions that can't be called on all systems

# def test_is_selinux_enabled():
#     # is_selinux_enabled is not always avaialble
#     rc = is_selinux_enabled()
#     assert rc == 0

# def test_is_selinux_mls_enabled():
#     # is_selinux_mls_enabled is not always av

# Generated at 2022-06-24 21:26:14.243239
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert(lgetfilecon_raw('/etc/resolv.conf')) == [0, 'system_u:object_r:net_conf_t:s0']

# Generated at 2022-06-24 21:26:23.627901
# Unit test for function matchpathcon
def test_matchpathcon():
    test_string = os.path.abspath(__file__)
    test_mode = 1
    retval = matchpathcon(test_string, test_mode)
    assert type(retval) == list
    assert len(retval) == 2
    assert type(retval[0]) in [int, long]
    assert type(retval[1]) == str
    if type(retval[0]) != int and type(retval[0]) != long:
        raise TypeError("Invalid type for 'retval[0]'")
    if type(retval[1]) != str:
        raise TypeError("Invalid type for 'retval[1]'")
