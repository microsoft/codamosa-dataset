

# Generated at 2022-06-24 21:17:05.849478
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/bin/ls"
    assert isinstance(lgetfilecon_raw(path), list)
    assert lgetfilecon_raw(path)[1] == "unconfined_u:object_r:bin_t:s0"

# Generated at 2022-06-24 21:17:07.497156
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/home/dharmit/ansible/lab/test_file"
    rc, con = lgetfilecon_raw(path)
    print(con)


# Generated at 2022-06-24 21:17:09.900263
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert to_native(lgetfilecon_raw(b"/root")[1]) == "system_u:object_r:root_t:s0"


if __name__ == "__main__":
    pass

# Generated at 2022-06-24 21:17:15.908548
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        result = matchpathcon('/etc/foo', 0)
    except OSError:
        # expected to get an error of some kind
        pass
    else:
        assert result[0] != 0, to_native(result[1])

# Generated at 2022-06-24 21:17:20.639449
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected_result = [0, 'system_u:object_r:svirt_image_t:s0:c123,c456']
    actual_result = lgetfilecon_raw('/some/image')
    assert expected_result == actual_result


# Generated at 2022-06-24 21:17:22.514375
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/foo"
    mode = 2
    assert matchpathcon(path, mode)[0] == 3

# Generated at 2022-06-24 21:17:23.496569
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(None, None)

# Generated at 2022-06-24 21:17:29.628307
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = None

    [rc, con] = matchpathcon(path, mode)

    assert rc >= 0, "Expected rc >= 0, got {0}".format(rc)

    # TODO: implement the following unit test
    # path = None
    # mode = None
    # assertRaises(TypeError, matchpathcon, path, mode)

    # TODO: implement the following unit test
    # path = '/etc/passwd'
    # mode = None
    # assertRaises(TypeError, matchpathcon, path, mode)

    assert con == 'system_u:object_r:passwd_file_t:s0', "Expected 'system_u:object_r:passwd_file_t:s0', got {0}".format(con)


# Unit

# Generated at 2022-06-24 21:17:32.072881
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/home/user/testfile") == [0, "user_u:object_r:user_home_t:s0"]


# Generated at 2022-06-24 21:17:37.250289
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    module = AnsibleModule(
        argument_spec={
            'path': {'type': 'str', 'required': True},
        },
        supports_check_mode=True,
    )

    path = module.params['path']
    # result = lgetfilecon_raw(path)
    result = _selinux_lib.lgetfilecon_raw(path, _to_char_p.from_param(None))

    if not result:
        result = 0

    module.exit_json(rc=result)


# Generated at 2022-06-24 21:17:42.603946
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw(b'[-1]')
    assert var_1[0] == 0
    assert var_1[1] == b'default_t'


# Generated at 2022-06-24 21:17:51.083846
# Unit test for function matchpathcon
def test_matchpathcon():
     assert matchpathcon("/etc", 0) == [0, 'system_u:object_r:etc_t:s0']
     assert matchpathcon("/etc/passwd", 0) == [0, 'system_u:object_r:shadow_t:s0']
     assert matchpathcon("/etc/passwd", 1) == [0, 'system_u:object_r:shadow_t:s0']
     assert matchpathcon("/bin/ls", 0) == [0, 'system_u:object_r:bin_t:s0']
     assert matchpathcon("/var/log/messages", 0) == [0, 'system_u:object_r:var_log_t:s0']

# Generated at 2022-06-24 21:17:53.977988
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/proc/self/status')
    assert rc == 0, con



# Generated at 2022-06-24 21:17:56.823743
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/home/user', 0) == [0, 'user_home_dir_t']
    assert matchpathcon('/home/foo', 0) == [0, 'user_home_dir_t']


# Generated at 2022-06-24 21:17:57.600144
# Unit test for function matchpathcon
def test_matchpathcon():
    assert False


# Generated at 2022-06-24 21:18:01.001026
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/foo.txt"
    (rc, con) = lgetfilecon_raw(path)
    assert rc == 0
    assert con.startswith("system_u:object_r:foo_t")
    print('Test passed')


# Generated at 2022-06-24 21:18:04.951832
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: make a tempfile to use
    path = '/lib64/libpcre.so.1'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0, 'lgetfilecon_raw({}) failed: {}'.format(path, rc)
    assert con.startswith('system_u:object_r:'), 'invalid selinux context: {}'.format(con)



# Generated at 2022-06-24 21:18:10.298313
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw('/etc/passwd', byref(con))
        assert rc == 0
        assert to_native(con.value) == 'system_u:object_r:etc_runtime_t:s0'
    finally:
        _selinux_lib.freecon(con)

    try:
        rc = _selinux_lib.lgetfilecon_raw('/var/run/nscd/socket', byref(con))
        assert rc == 0
        assert to_native(con.value) == 'system_u:object_r:nscd_var_run_t:s0'
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:18:12.593404
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/bin/foo', 1) == [0, 'system_u:object_r:rpm_exec_t:s0']



# Generated at 2022-06-24 21:18:21.903733
# Unit test for function matchpathcon
def test_matchpathcon():
    
    # Test with a string argument
    path = '/tmp/test.txt'
    mode = 0
    con = c_char_p()
    try:
        rc = _selinux_lib.matchpathcon(path, mode, byref(con))
        print(to_native(con.value))
    finally:
        _selinux_lib.freecon(con)
        
    # Test with a bytes argument
    path = b'/tmp/test.txt'
    mode = 0
    con = c_char_p()
    try:
        rc = _selinux_lib.matchpathcon(path, mode, byref(con))
        print(to_native(con.value))
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:18:26.803963
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('') == None
    assert matchpathcon('/dir/file', 0) == None


# Generated at 2022-06-24 21:18:30.990566
# Unit test for function matchpathcon
def test_matchpathcon():
    for i in range(100):
        testvar = matchpathcon('/var/log/audit', 0)


# Generated at 2022-06-24 21:18:35.644030
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon(path='/etc/selinux/config', mode=0)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-24 21:18:43.005443
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    success = 0
    for i in range(10):
        try:
            rc, con = lgetfilecon_raw("/tmp/foo")
        except OSError:  # FIXME: this probably shouldn't be a bare except
            e = sys.exc_info()[1]
            print("OSError: "+ to_native(e))
        except Exception:  # FIXME: this probably shouldn't be a bare except
            e = sys.exc_info()[1]
            print("Exception: "+ to_native(e))
        else:
            success += 1
            print(con)
            print(rc)
    if success > 0:
        print(success, "Tests succeeded")
    else:
        print("No tests succeeded")


# Generated at 2022-06-24 21:18:51.409618
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('', 0)[1] == 'unconfined_u:object_r:user_home_dir_t:s0'
    assert matchpathcon('/', 0)[1] == 'system_u:object_r:root_t:s0'
    assert matchpathcon('/usr/bin/ansible', 0)[1] == 'system_u:object_r:bin_t:s0'
    assert matchpathcon('/usr/bin/ansible', 1)[1] == 'system_u:object_r:bin_t:s0'
    assert matchpathcon('/usr/bin/ansible', 2)[1] == 'system_u:object_r:bin_t:s0'

# Generated at 2022-06-24 21:18:53.559716
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon('/etc/hosts', 0)


# Generated at 2022-06-24 21:18:59.193695
# Unit test for function matchpathcon
def test_matchpathcon():
    # Ensure we can call selinux.matchpathcon()
    if is_selinux_enabled() == 1:
        rc, con = matchpathcon('/etc/selinux/config', 0)
        assert rc in (0, -1)



# Generated at 2022-06-24 21:18:59.785600
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: refactor tests
    pass


# Generated at 2022-06-24 21:19:03.882069
# Unit test for function matchpathcon
def test_matchpathcon():
    expected_result = (0, 'system_u:object_r:svirt_image_t:s0')
    result = matchpathcon('/tmp/test_selinux.qcow2', 0)
    assert result[0] == expected_result[0]
    assert result[1] == expected_result[1]


# Generated at 2022-06-24 21:19:05.780768
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/srv/www', 0)


# Generated at 2022-06-24 21:19:16.049927
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Set up test inputs
    file_path = "unit test"
    path = "unit test"

    # Perform the raw call
    func_call_result = lgetfilecon_raw(path)

    # Perform any needed asserts on the raw call results
    rc, con = func_call_result



# Generated at 2022-06-24 21:19:19.060192
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert file_exists_0(['/etc/selinux/config'])
    rc, con_str = lgetfilecon_raw('/etc/selinux/config')
    assert type(con_str) == str
    assert rc == 0 or rc == -1


# Generated at 2022-06-24 21:19:28.610389
# Unit test for function matchpathcon
def test_matchpathcon():
    assert selinux_getenforcemode() == [0, 0]
    assert selinux_getpolicytype() == [0, 'targeted']
    # verbose unit test for lgetfilecon_raw
    var_1 = lgetfilecon_raw(b'/etc/passwd')
    assert var_1 == [0, 'system_u:object_r:etc_t:s0']
    # verbose unit test for matchpathcon
    var_2 = matchpathcon(b'/etc/passwd', 0)
    assert var_2 == [0, 'system_u:object_r:etc_t:s0']

# Test method for class AnsibleModule

# Generated at 2022-06-24 21:19:31.775682
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = '/etc/passwd'
    con = lgetfilecon_raw(file_path)
    assert con == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-24 21:19:33.471664
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')



# Generated at 2022-06-24 21:19:38.211153
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-24 21:19:43.503816
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(None, None) == [0, 'system_u:object_r:var_t:s0']


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-24 21:19:48.016338
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'data/file_contexts'
    mode = 2048
    matchpathcon(path, mode)


# Generated at 2022-06-24 21:19:54.858896
# Unit test for function matchpathcon
def test_matchpathcon():
    fd, fpath = tempfile.mkstemp()
    try:
        os.close(fd)
        rc, con = matchpathcon(fpath, os.R_OK)
        if rc != 0:
            raise OSError(rc, 'matchpathcon failed for {0}'.format(fpath))
        rc, con = lgetfilecon_raw(fpath)
        if rc != 0:
            raise OSError(rc, 'lgetfilecon failed for {0}'.format(fpath))
    finally:
        os.remove(fpath)



# Generated at 2022-06-24 21:19:57.580012
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    errmsg = "The function 'lgetfilecon_raw' is not implemented"
    assert not hasattr(selinux, 'lgetfilecon_raw'), errmsg


# Generated at 2022-06-24 21:20:12.265344
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/foo"
    desired_mode = selinux_getenforcemode()[1]
    assert _selinux_lib.matchpathcon(path, desired_mode, None) == 0


if __name__ == "__main__":
    pytest.main(["/home/user/workspace/ansible/lib/ansible/module_utils/selinux_ctypes.py"])

# Generated at 2022-06-24 21:20:16.155768
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    r = lgetfilecon_raw(path)
    assert r[0] == 0, r

    got = r[1]
    # NB: this is subject to change with different SELinux policy versions
    assert got == 'unconfined_u:object_r:user_home_t:s0'



# Generated at 2022-06-24 21:20:16.949584
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = ""
    lgetfilecon_raw_(path)


# Generated at 2022-06-24 21:20:22.375525
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: is this a good test path?
    result = lgetfilecon_raw("/etc/passwd")
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], str)
    assert result[0] == 0

    result = lgetfilecon_raw("/foo/bar/baz")
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], str)
    assert result[0] != 0

    result = lgetfilecon_raw(None)
    assert isinstance(result, list)
    assert len(result) == 2
    assert isinstance(result[0], int)

# Generated at 2022-06-24 21:20:29.559165
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for security context for file type 'regular file' and standard mode of 644
    case_0 = matchpathcon('/etc/hosts', 0o644)
    assert 'unconfined_u:object_r:etc_t:s0' in case_0[1]

    # Test for security context for file type 'directory' and standard mode of 755
    case_1 = matchpathcon('/etc', 0o755)
    assert 'unconfined_u:object_r:etc_t:s0' in case_1[1]

    # Test for security context for file type 'character special' and standard mode of 666
    case_2 = matchpathcon('/dev/null', 0o666)
    assert 'unconfined_u:object_r:dev_t:s0' in case_2[1]

   

# Generated at 2022-06-24 21:20:31.394481
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected_0 = ['root', 'object_r', 'security_t']
    con = lgetfilecon_raw(path='/selinux/')
    assert con.split(':') == expected_0



# Generated at 2022-06-24 21:20:33.090353
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw("/etc/passwd")
    assert var_1 == [0, 'unconfined_u:object_r:user_home_t:s0']


# Generated at 2022-06-24 21:20:35.519103
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        test_path = '/etc/shadow'
        test_mode = 3  # SELINUX_AND_TRANS
        results = lgetfilecon_raw(test_path)
        assert results[0] == 0, 'Invalid return code'
        assert results[1] is not None, 'Invalid return value'
    finally:
        pass


# Generated at 2022-06-24 21:20:42.515534
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='/bin', mode=0) == [0, 'unconfined_u:object_r:bin_t:s0']
    assert matchpathcon(path='/etc/hosts', mode=0) == [0, 'system_u:object_r:net_conf_t:s0']
    assert matchpathcon(path='/etc/hosts', mode=1) == [0, 'system_u:object_r:net_conf_t:s0']
    assert matchpathcon(path='/etc/hosts', mode=2) == [0, 'system_u:object_r:net_conf_t:s0']


# Generated at 2022-06-24 21:20:48.892407
# Unit test for function matchpathcon
def test_matchpathcon():
    if selinux_getenforcemode()[1] == 0:
        return
    var_1 = matchpathcon('/root',0)[1]
    assert any(var_1 == var for var in var_1)



# Generated at 2022-06-24 21:21:16.264341
# Unit test for function matchpathcon
def test_matchpathcon():
    path = None
    mode = 2
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    try:
        assert rc == 0
        assert matchpathcon(path, mode) == [rc, to_native(con.value)]
    finally:
        _selinux_lib.freecon(con)

    path = None
    mode = 0
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    try:
        assert rc == 0
        assert matchpathcon(path, mode) == [rc, to_native(con.value)]
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:21:17.646745
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/etc/hosts",0)


# Generated at 2022-06-24 21:21:18.291589
# Unit test for function matchpathcon
def test_matchpathcon():
    pass


# Generated at 2022-06-24 21:21:26.521815
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    Test function matchpathcon
    '''
    path = 'foo'
    mode = 2
    rc, out = matchpathcon(path, mode)
    matchpathcon_match = {
        'rc': 0,
        'out': 'unconfined_u:object_r:user_tmp_t:s0',
    }
    assert rc == matchpathcon_match.get('rc'), 'Expected {0}, but got {1}'.format(matchpathcon_match.get('rc'), rc)
    assert out == matchpathcon_match.get('out'), 'Expected {0}, but got {1}'.format(matchpathcon_match.get('out'), out)


# Generated at 2022-06-24 21:21:33.574979
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test lgetfilecon_raw
    """
    # FIXME: test when file is not present.

    if os.environ.get('TRAVIS_CI', None) == 'True':
        # skip this test on Travis
        return

    path = '/etc/passwd'
    result = lgetfilecon_raw(path)
    assert result[0] == 0
    assert isinstance(result[1], str)
    assert len(result[1]) > 0



# Generated at 2022-06-24 21:21:36.169392
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw(b'/etc/selinux/config')
        assert rc == 0
    finally:
        _selinux_lib.freecon(con)



# Generated at 2022-06-24 21:21:38.552883
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME
    raise NotImplementedError



# Generated at 2022-06-24 21:21:43.370582
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/var/log/messages')[1] is not None


# Generated at 2022-06-24 21:21:44.800579
# Unit test for function matchpathcon
def test_matchpathcon():
    assert(matchpathcon('/', 0) is None)


# Generated at 2022-06-24 21:21:51.285380
# Unit test for function matchpathcon
def test_matchpathcon():
    assert lgetfilecon_raw('/usr/lib')[1] == 'usr_t:object_r:lib_t:s0'
    assert matchpathcon('/usr/lib', 0)[1] == 'usr_t:object_r:lib_t:s0'
    assert lgetfilecon_raw('/usr/lib')[1] == matchpathcon('/usr/lib', 0)[1]
    assert matchpathcon('/usr/lib/invalid/path', 0) == [0, '']


if __name__ == '__main__':
    test_case_0()
    test_matchpathcon()

# Generated at 2022-06-24 21:22:29.029963
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/non-existent-file')[0] == -1


# Generated at 2022-06-24 21:22:30.981778
# Unit test for function matchpathcon
def test_matchpathcon():
    r = matchpathcon('/var/tmp', 2)
    assert isinstance(r, list)
    assert len(r) == 2
    assert r[0] == 0
    assert isinstance(r[1], str)


# Generated at 2022-06-24 21:22:37.286925
# Unit test for function matchpathcon
def test_matchpathcon():
    # Setup
    path = '/tmp/foo'
    mode = 0

    # Execution
    actual = matchpathcon(path, mode)

    # Verification
    assert actual[0] == 0
    assert actual[1] == 'system_u:object_r:admin_home_t:s0'


# Generated at 2022-06-24 21:22:41.666471
# Unit test for function matchpathcon
def test_matchpathcon():
    assert lgetfilecon_raw(None) == [-1, None]
    assert lgetfilecon_raw('/')[1].startswith('system_u:object_r:root_t')
    assert matchpathcon('/', 0)[1].startswith('system_u:object_r:root_t')

# Generated at 2022-06-24 21:22:44.134059
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/path/to/file"
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:unlabeled_t:s0']



# Generated at 2022-06-24 21:22:47.007206
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/pam.d/system-auth"
    mode = 0
    result = matchpathcon(path, mode)
    assert result[0] == 0

# Generated at 2022-06-24 21:22:51.278173
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Good case
    try:
        var_1 = lgetfilecon_raw("/usr")
    except OSError as e:
        assert False, "lgetfilecon_raw() failed: {0}".format(to_native(e))


# Generated at 2022-06-24 21:23:00.798144
# Unit test for function matchpathcon
def test_matchpathcon():
    assert selinux_getpolicytype()[1] == ('targeted', 'mcs')
    assert matchpathcon('/etc/resolv.conf', 0)[1] == 'system_u:object_r:etc_t:s0'
    assert matchpathcon('/sys/kernel/uids/0', 0)[1] == 'system_u:object_r:sysfs_t:s0'
    assert matchpathcon('/tmp/test_tmp_test', 0)[1] == 'system_u:object_r:tmp_t:s0'
    assert matchpathcon('/dev/null', 0)[1] == 'system_u:object_r:chr_file_t:s0'

# Generated at 2022-06-24 21:23:05.304672
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw('/usr/share/zoneinfo/America/New_York')
    expected = [0, 'system_u:object_r:usr_t:s0']
    assert ret == expected, 'Returned "{0}", expected "{1}"'.format(ret, expected)



# Generated at 2022-06-24 21:23:14.181673
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw('/etc/passwd')
    except OSError as e:
        # this will happen if the file doesn't exist, or if we're
        # on a distro where selinux isn't installed
        if e.errno == 2:
            return
        raise
    if rc == -1:
        raise SystemError('lgetfilecon_raw failed')
    if not con:
        raise SystemError('lgetfilecon_raw returned no label')
    assert con == 'system_u:object_r:etc_runtime_t:s0', 'lgetfilecon_raw returned unexpected label value'



# Generated at 2022-06-24 21:24:41.308879
# Unit test for function matchpathcon
def test_matchpathcon():
    # Setup test variables
    path = "/path/to/file"
    mode = 0

    # Run the matchpathcon function
    result = matchpathcon(path, mode)
    if (result[1] != "system_u:object_r:admin_home_t"):
        raise Exception('Return value mismatch. Returned "%s" instead of the expected "%s"' % (result[1], "system_u:object_r:admin_home_t"))


# Generated at 2022-06-24 21:24:44.828761
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/ansible_selinux_test'
    (rc, label) = lgetfilecon_raw(path)
    assert rc == 0
    assert label is not None


# Generated at 2022-06-24 21:24:49.548067
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/') == [0, b'root:object_r:root_t:s0']


# Generated at 2022-06-24 21:24:55.146521
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    # Use the default test_case_0 to validate the module
    var_0 = matchpathcon(path, mode)
    assert var_0[0] == 0
    assert var_0[1] == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-24 21:24:59.129776
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/etc/passwd") == [0, 'system_u:object_r:passwd_t:s0']


# Generated at 2022-06-24 21:25:04.991136
# Unit test for function matchpathcon
def test_matchpathcon():
    # path = (str | bytes)
    path = b'/home/ansible/playbooks/test.txt'

    # mode = (int)
    mode = 0

    out = matchpathcon(path, mode)
    print('libc return:', out[0])
    print('libc results:', out[1])



# Generated at 2022-06-24 21:25:12.959117
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    # Create tmpfile to set file context
    tmpfd, tmppath = tempfile.mkstemp()
    os.close(tmpfd)
    # Create dummy context
    dummy_context = "dummy_u:dummy_r:dummy_t:s0"
    # Set file context on tmpfile
    rc, out = lsetfilecon(tmppath, dummy_context)
    # Get file context
    rc, out = lgetfilecon_raw(tmppath)
    assert dummy_context in out

# Generated at 2022-06-24 21:25:22.349607
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/etc/passwd", 0) == [0, "system_u:object_r:etc_runtime_t:s0"]
    assert matchpathcon("/etc/shadow", 0) == [0, "system_u:object_r:etc_runtime_t:s0"]
    assert matchpathcon("/etc/sudoers", 0) == [0, "system_u:object_r:etc_runtime_t:s0"]
    assert matchpathcon("/etc/sudoers.d/ansible", 0) == [0, "unconfined_u:object_r:etc_runtime_t:s0"]
    assert matchpathcon("/etc/cron.d/ansible", 0) == [0, "system_u:object_r:etc_runtime_t:s0"]
    assert match

# Generated at 2022-06-24 21:25:27.687336
# Unit test for function matchpathcon
def test_matchpathcon():
    paths = ['/', '/usr', '/usr/bin', '/usr/sbin', '/usr/sbin/crond']
    for path in paths:
        rc, con = matchpathcon(path, 0)
        print("path: %s, security context: %s" % (path, repr(con)))
        assert rc == 0

# Generated at 2022-06-24 21:25:32.706878
# Unit test for function matchpathcon
def test_matchpathcon():
    con = 'system_u:object_r:bin_t:s0'
    mode = os.R_OK
    rc, matched_con = matchpathcon('/usr/bin/python2.6', mode)
    assert rc == 0, "test_matchpathcon: Expected successful return code, got {}".format(rc)
    assert con == matched_con, "test_matchpathcon: Expected retrieved context '{}', got '{}'".format(con, matched_con)
