

# Generated at 2022-06-24 21:17:06.624816
# Unit test for function matchpathcon
def test_matchpathcon():
    _rc, _con = matchpathcon('/root/selinux', 0)
    return _rc, _con


# Generated at 2022-06-24 21:17:07.948593
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('test_string', 'test_string')
    assert ret[0] == -1



# Generated at 2022-06-24 21:17:15.716406
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test case: no enforcement and non-compliant file
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:unlabeled_t:s0']
    # Test case: enforcement and non-compliant file
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:default_t:s0']



# Generated at 2022-06-24 21:17:19.800305
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/usr/bin', 0)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:bin_t:s0'


# Generated at 2022-06-24 21:17:29.364235
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/home/test_user', 0) == [0, 'user_home_dir_t']
    assert matchpathcon('/home/test_user', 1) == [0, 'user_home_dir_t']
    assert matchpathcon('/home/test_user', 2) == [0, 'user_home_dir_t']
    assert matchpathcon('/home/test_user', 3) == [0, 'user_home_dir_t']
    assert matchpathcon('/home/test_user', 4) == [0, 'user_home_dir_t']
    assert matchpathcon('/home/test_user', 5) == [0, 'user_home_dir_t']

# Generated at 2022-06-24 21:17:32.108551
# Unit test for function matchpathcon
def test_matchpathcon():
    assert os.path.exists('/tmp/test/test')
    assert matchpathcon('/tmp/test/test', 0) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-24 21:17:35.204497
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected_result = [0, 'system_u:object_r:sysfs_t:s0']
    actual_result = lgetfilecon_raw('/sys')
    assert(actual_result == expected_result)


# Generated at 2022-06-24 21:17:37.932682
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_shadow_t:s0']



# Generated at 2022-06-24 21:17:48.134177
# Unit test for function matchpathcon
def test_matchpathcon():
    class Mock_SelStat(object):

        def __init__(self, mode):
            self.st_mode = mode

    class Mock_SelContext(object):

        def __init__(self):
            self.path = '/a'
            self.defcon = 'b:c:d'
            self.mode = 123
            self.fcon = 'e:f:g'
            self.paths = {
                self.path: (self.defcon, self.mode),
            }
            self.files = {
                self.path: (self.fcon, self.mode, 0),
            }
        def __enter__(self, *args, **kwargs):
            return self
        def __exit__(self, *args, **kwargs):
            pass


# Generated at 2022-06-24 21:17:52.822517
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/testfile'
    mode = 0
    assert len(matchpathcon(path, mode)) == 2
    path = '/tmp'
    mode = 0
    assert len(matchpathcon(path, mode)) == 2


# Generated at 2022-06-24 21:17:58.922462
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Read file for testcase
    f = open("testfile.txt", "r")
    var_0 = f.read()
    # Run function
    var_1 = lgetfilecon_raw(var_0)
    # Assert function result
    assert var_1[0] == 0
    assert var_1[1] == "system_u:object_r:tmp_t:s0"


# Generated at 2022-06-24 21:18:01.286463
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/selinux/test"
    print("test_lgetfilecon_raw: {}".format(path))
    rc, con = lgetfilecon_raw(path)



# Generated at 2022-06-24 21:18:03.926811
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/var/log/audit'
    var_0 = lgetfilecon_raw(path)
    assert var_0[0] == 0
    assert var_0[1] == 'system_u:object_r:var_log_t:s0'



# Generated at 2022-06-24 21:18:04.968249
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: write unit tests
    assert False



# Generated at 2022-06-24 21:18:11.211136
# Unit test for function matchpathcon
def test_matchpathcon():
    file_name = "/tmp/test_file"
    res = matchpathcon(file_name, 0)
    assert res[0] == 0


# Generated at 2022-06-24 21:18:15.853472
# Unit test for function matchpathcon
def test_matchpathcon():
    _in = ('/tmp/testdir', 0)
    assert matchpathcon(*_in) == [0, 'system_u:object_r:user_tmp_t:s0']
    assert lgetfilecon_raw(*_in) == [0, 'system_u:object_r:user_tmp_t:s0']

# Generated at 2022-06-24 21:18:20.469998
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/'

    res = lgetfilecon_raw(path)

    assert res[0] == 0, 'Return value mismatch for lgetfilecon_raw'
    assert res[1] is not None, 'Return value mismatch for lgetfilecon_raw'
    assert isinstance(res[1], str), 'Return value mismatch for lgetfilecon_raw'

# Generated at 2022-06-24 21:18:30.796962
# Unit test for function matchpathcon
def test_matchpathcon():
    """
        Syntax: matchpathcon(path, mode)
        This function returns a tuple of three fields from libselinux.
        The first is an integer error code.
        If the error code is positive, the tuple also includes a string error message.
        If the error code is zero, the tuple also includes the string representation of the context.
        """
    assert len(matchpathcon(path='/etc/selinux/config', mode=0)) == 2
    assert len(matchpathcon(path='/proc/mounts', mode=0)) == 3
    assert matchpathcon(path='/proc/mounts', mode=0)[0] == -1
    assert matchpathcon(path='/etc/selinux/config', mode=0)[0] == 0

# Generated at 2022-06-24 21:18:35.390937
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/dev/null') == [0, 'system_u:object_r:device_t:s0']


# Generated at 2022-06-24 21:18:38.997074
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'?/foo/bar'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:default_t:s0'



# Generated at 2022-06-24 21:18:45.169859
# Unit test for function matchpathcon
def test_matchpathcon():
    assert lgetfilecon_raw("/dev/null") == [0, "system_u:object_r:null_device_t:s0"]

# Generated at 2022-06-24 21:18:49.056008
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/tmp", 0) == [0, 'system_u:object_r:tmp_t:s0\x00']



# Generated at 2022-06-24 21:18:53.309860
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = os.path.realpath(__file__)
    var_2 = matchpathcon(var_1, os.R_OK)
    assert var_2[0] == 0


# Generated at 2022-06-24 21:19:01.787288
# Unit test for function matchpathcon
def test_matchpathcon():
    # These tests will fail on distributions
    # where SELinux is not supported or not enabled
    path = b'/etc/hosts'
    mode = 0
    assert matchpathcon(path, mode) == [0, b'etc_t']
    path = b'/etc/passwd'
    mode = 0
    assert matchpathcon(path, mode) == [0, b'etc_t']
    path = b'/etc/hosts'
    mode = 1
    assert matchpathcon(path, mode) == [0, b'etc_t']
    path = b'/etc/passwd'
    mode = 1
    assert matchpathcon(path, mode) == [0, b'etc_t']



# Generated at 2022-06-24 21:19:05.463969
# Unit test for function matchpathcon
def test_matchpathcon():
    str1 = 'test_string'
    str2 = 'test_string'
    result = matchpathcon(str1, str2)
    assert result == [0, 'test_string']


# Generated at 2022-06-24 21:19:09.045658
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/var/log/audit/audit.log"
    assert to_native(lgetfilecon_raw(path)[1]) == "system_u:object_r:auditd_log_t:s0"



# Generated at 2022-06-24 21:19:11.230440
# Unit test for function matchpathcon
def test_matchpathcon():
    testpath = "foo/bar"
    # basic function call
    tmp = matchpathcon(testpath, 0)
    assert to_native(tmp[1]) != ""

# Generated at 2022-06-24 21:19:15.530888
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = None
    lgetfilecon_raw(path)
    assert True is True

# Generated at 2022-06-24 21:19:21.665700
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'any_string'
    mode = 1
    expected_result = [0, 'any_string']

    lgetfilecon_raw_mock = mocker.patch('selinux_common.lgetfilecon_raw')
    lgetfilecon_raw_mock.return_value = expected_result

    actual_result = matchpathcon(path, mode)

    assert expected_result == actual_result

    lgetfilecon_raw_mock.assert_called_once_with(path)


# Generated at 2022-06-24 21:19:25.174646
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if selinux_getenforcemode()[0] == 0:
        assert not lgetfilecon_raw("/usr/bin")[0]
    else:
        assert lgetfilecon_raw("/usr/bin")[0]


# Generated at 2022-06-24 21:19:40.123770
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create a test file
    with tempfile.NamedTemporaryFile() as f:
        path = f.name
        # Get the SELinux context for the file
        # Should have SELinux type unconfined_u
        # Should be in the unconfined_r role
        # Should be in the system_r role
        rc, con = matchpathcon(path, S_IFREG)
        assert rc == 0
        assert con == 'unconfined_u:object_r:user_tmp_t:s0'

# Generated at 2022-06-24 21:19:44.626995
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('test') == [0, 'system_u:object_r:boot_t:s0']


# Generated at 2022-06-24 21:19:45.701255
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert False


# Generated at 2022-06-24 21:19:51.517300
# Unit test for function matchpathcon
def test_matchpathcon():
    original = os.environ.get('PATH')

    try:
        os.environ['PATH'] = '/bin:/sbin'
        assert matchpathcon('/bin', 0) == [0, 'system_u:object_r:bin_t:s0']
    finally:
        if original is None:
            del os.environ['PATH']
        else:
            os.environ['PATH'] = original



# Generated at 2022-06-24 21:19:53.672620
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    check_function_results(module, expected_results, func_name='lgetfilecon_raw', arg_names=['path'], args=[path])


# Generated at 2022-06-24 21:19:57.373538
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test all arguments
    assert matchpathcon('test_path_in', 'test_mode_in') == [0, '']
    # Test all arguments
    assert matchpathcon('test_path_in', 'test_mode_in') == [0, '']


# Generated at 2022-06-24 21:20:01.883612
# Unit test for function matchpathcon
def test_matchpathcon():
    assert False, "Function not implemented"


# Generated at 2022-06-24 21:20:06.262590
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fname = 'test_filecon.raw'
    # Create temporary file
    tf = open(fname, 'w')
    tf.close()

    file_context_string = "system_u:object_r:bin_t:s0"

    result = lsetfilecon(fname, file_context_string)
    assert result == 0

    result = lgetfilecon_raw(fname)
    assert file_context_string == result[1]

    # Remove temporary file
    os.remove(fname)



# Generated at 2022-06-24 21:20:10.569217
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('foo', 'bar') == [0, 'bar']



# Generated at 2022-06-24 21:20:12.733718
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp'
    mode = 0
    assert _selinux_lib.matchpathcon(path, mode, byref(c_char_p())) == 0


# Generated at 2022-06-24 21:20:38.006753
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        path = '/etc/issue'
        var_2 = os.access(path, os.F_OK)
        if var_2:
            var_1 = lgetfilecon_raw(path)
            if var_1[0] == 0:
                assert True
            else:
                assert False
        else:
            assert False
    except NotImplementedError as err:
        # The pragma preprocessor directive does not allow assigning to variables.
        # Hence we create a new variable called "pragma_unreacheable"
        # that can be used to identify code paths that should be unreachable.
        # These code paths can then be excluded from coverage analysis.
        pragma_unreacheable = 1

# Generated at 2022-06-24 21:20:41.042733
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # Unit Test Variables
    var_0 = lgetfilecon_raw(path='/tmp/')
    var_1 = lgetfilecon_raw(path='/tmp')
    var_2 = lgetfilecon_raw(path=None)


# Generated at 2022-06-24 21:20:50.378252
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        from ansible.module_utils.selinux_policy import lgetfilecon_raw
    except ImportError:
        lgetfilecon_raw = sys.modules[__name__].lgetfilecon_raw

    # Many of these are on paths that are unique to the system being tested,
    # but the tests would fail on one without selinux if not these
    assert lgetfilecon_raw('/etc/selinux/config')[0] in (0, -1, -2)
    assert lgetfilecon_raw('/etc/selinux/targeted/contexts/files/file_contexts')[0] in (0, -1, -2)

# Generated at 2022-06-24 21:20:57.623873
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # con = c_char_p()
    # rc = _selinux_lib.lgetfilecon_raw("/var/run/docker.sock", byref(con))
    # if rc < 0:
    #     raise OSError(get_errno(), os.strerror(get_errno()))
    # return to_native(con.value)
    rc, con = lgetfilecon_raw("/var/run/docker.sock")
    return [rc, con]

# Generated at 2022-06-24 21:21:00.967838
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    assert isinstance(matchpathcon(path, mode), list)

# Generated at 2022-06-24 21:21:10.129529
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    v1 = selinux_getenforcemode()
    if v1[0] == 0:
        if v1[1] != 0:
            v2 = lgetfilecon_raw('/etc/passwd')
            if v2[0] == 0:
                v3 = len(v2[1])
                v4 = matchpathcon('/etc/passwd', 0)
                if v4[0] == 0:
                    v5 = len(v4[1])
                    if v3 != v5:
                        return False
                    else:
                        return True
                else:
                    return False
            else:
                return False
        else:
            return True
    return True



# Generated at 2022-06-24 21:21:12.191459
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw("")
    assert ret[0] == -1
    assert ret[1] is None


# Generated at 2022-06-24 21:21:18.102329
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        retval = matchpathcon('/path', 1)
    except OSError as ex:
        if ex.errno != errno.ENOENT:
            raise
        else:
            raise

    if retval[0] != 0:
        raise ValueError('{0}: {1}'.format(retval[0], retval[1]))


# Generated at 2022-06-24 21:21:23.749796
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/test.txt'
    result = lgetfilecon_raw(path)
    if b'nfs_t' in result[1]:
        print("test_lgetfilecon_raw: PASSED")
    else:
        print("test_lgetfilecon_raw: FAILED")
        print("result:", result[1])


# Generated at 2022-06-24 21:21:25.600443
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == (0, 'system_u:object_r:etc_t:s0')



# Generated at 2022-06-24 21:22:01.071347
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fnc_name = "lgetfilecon_raw"
    fnc_param_1 = (p_char_p)
    fnc_param_2 = (p_char_p)
    fnc_return_type = p_int



# Generated at 2022-06-24 21:22:05.281947
# Unit test for function matchpathcon
def test_matchpathcon():
    if not os.path.isfile('/etc/shadow'):
        raise Exception('/etc/shadow not found. Skipping test.')
    rc, selinux_context = matchpathcon('/etc/shadow', 0)
    assert rc == 0
    assert isinstance(selinux_context, str)



# Generated at 2022-06-24 21:22:08.367049
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert selinux_getenforcemode()[0] == 0, "no selinux support"
    assert lgetfilecon_raw("/etc/issue")[0] == 0, "error getting selinux context for /etc/issue"


# Generated at 2022-06-24 21:22:12.284598
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert callable(lgetfilecon_raw)


# Generated at 2022-06-24 21:22:18.425072
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test all branches of code path, but do not verify if path exists
    path = '/some/fake/path'
    mode = 0o644

    # check return code to see if it fails
    var_0 = matchpathcon(path, mode)
    if var_0[0] == -1:
        raise AssertionError("matchpathcon return value is not -1, it is %d" % var_0[0])
    # No assertion error of any kind, then means nothing was returned
    if var_0[1] is None:
        raise AssertionError("matchpathcon file context is expected, but None was returned")



# Generated at 2022-06-24 21:22:23.377845
# Unit test for function matchpathcon
def test_matchpathcon():
    assert "File not found" in matchpathcon("wrong_file.txt", 0)[1]
    assert "File not found" in matchpathcon("wrong_file.txt", 1)[1]
    assert "Permission denied" in matchpathcon("/proc/cpuinfo", 2)[1]
    assert "Permission denied" in matchpathcon("/proc/cpuinfo", 3)[1]
    assert "Invalid mode" in matchpathcon("/proc/cpuinfo", 4)[1]


# Generated at 2022-06-24 21:22:33.036574
# Unit test for function matchpathcon
def test_matchpathcon():
    paths = [
        'foo',
        '/usr/bin/bar',
        '/etc/baz',
        '/tmp/quux',
    ]

    mode_vals = [
        0,
        1,
        2,
    ]

    for ipath, imode in [(p, m) for p in paths for m in mode_vals]:
        rc, con = matchpathcon(ipath, imode)
        assert rc == 0, "unexpected error for {0}/{1}: {2}".format(ipath, imode, rc)
        assert not con is None, "unexpected result for {0}/{1}: {2}".format(ipath, imode, con)



# Generated at 2022-06-24 21:22:35.417848
# Unit test for function matchpathcon
def test_matchpathcon():
    path = ''
    mode = 0
    assert matchpathcon(path, mode) != False


# Generated at 2022-06-24 21:22:40.229238
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('test_file_path', 0) == [0, 'system_u:object_r:usr_t:s0']
    assert matchpathcon('test_dir_path', 0) == [0, 'system_u:object_r:usr_t:s0']



# Generated at 2022-06-24 21:22:43.723872
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: update this test case to use unittest module

    fp = open('/tmp/test_matchpathcon', 'w')
    fp.close()

    try:
        con = _selinux_lib.matchpathcon('/tmp/test_matchpathcon', os.R_OK)
        print('con: {}'.format(con))
    finally:
        os.unlink('/tmp/test_matchpathcon')

# Generated at 2022-06-24 21:24:03.379289
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: fix this test
    #assert _is_selinux_enabled() is True
    rc, new_context = matchpathcon('/var/log/messages', 0)
    assert rc == 0
    assert new_context == u'system_u:object_r:var_log_t:s0'

# Generated at 2022-06-24 21:24:09.937955
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    var_1 = matchpathcon(path, mode)
    assert var_1[0] == 0, "expected 0, got {0}".format(var_1[0])
    assert var_1[1] == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-24 21:24:13.129446
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var = to_native(lgetfilecon_raw("/etc/selinux/config")[1])
    assert var == "system_u:object_r:etc_t:s0"


# Generated at 2022-06-24 21:24:20.438607
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = 'path'
    try:
        assert type(lgetfilecon_raw(path)) is list
        assert len(lgetfilecon_raw(path)) == 2
        assert type(lgetfilecon_raw(path)[0]) is int
        assert type(lgetfilecon_raw(path)[1]) is str
    except:
        print("Unexpected error: ", sys.exc_info()[0])
        raise


# Generated at 2022-06-24 21:24:28.193536
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: there is probably a better way than mocking ctypes
    c_char_p.__repr__ = lambda _: 'con'
    c_char_p.value = 'foo'

    @classmethod
    def freecon(cls, _):
        c_char_p.__repr__ = _orig_repr

    _orig_repr = c_char_p.__repr__
    _selinux_lib.freecon = freecon
    rc, con = lgetfilecon_raw('/')
    print('{0} {1}'.format(rc, con))

    rc, con = lgetfilecon_raw('/path/to/file')
    print('{0} {1}'.format(rc, con))
    assert rc == 0
    assert con == 'foo'



# Generated at 2022-06-24 21:24:28.835439
# Unit test for function matchpathcon
def test_matchpathcon():
    assert True



# Generated at 2022-06-24 21:24:32.177068
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("./ansible/parted.py")


# Generated at 2022-06-24 21:24:34.680032
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r = lgetfilecon_raw('/path/to/file')
    assert r[0] == 0

# Generated at 2022-06-24 21:24:37.636674
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp"
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:tmp_t']


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-24 21:24:45.348656
# Unit test for function matchpathcon
def test_matchpathcon():
    if (selinux_getenforcemode()[1] == 0):
        rc = matchpathcon("/tmp/ansible-test-file", 0)
        if (rc[0] > 0):
            raise AssertionError("call to matchpathcon failed with code %d"%(rc[0]))
    else:
        raise AssertionError("SELinux is enabled, but is not enforced")

if __name__ == '__main__':
    test_matchpathcon()