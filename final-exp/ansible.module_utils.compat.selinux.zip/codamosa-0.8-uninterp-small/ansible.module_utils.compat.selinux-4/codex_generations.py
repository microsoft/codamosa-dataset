

# Generated at 2022-06-24 21:17:18.014928
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    with open("/tmp/ansible_selinux_payload", "w") as f:
        f.write("nonsense for the sake of empty file")

    # patch for backwards compatibility with ansible 2.4
    if hasattr(os, 'O_PATH'):
        _open = os.open
        _close = os.close
    else:
        _open = os.open
        _close = lambda x: os.close(x)

    fd = _open("/tmp/ansible_selinux_payload", os.O_RDONLY | os.O_PATH)
    if fd == -1:
        return [1, fd]

    rc, con = lgetfilecon_raw(fd)
    _close(fd)
    return [rc, con]

# Generated at 2022-06-24 21:17:21.299243
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected_output = [0, 'system_u:object_r:user_tmp_t:s0']
    assert lgetfilecon_raw(b'/tmp/pym/libc5_1.so.5') == expected_output


# Generated at 2022-06-24 21:17:22.864387
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw("/etc")


# Generated at 2022-06-24 21:17:31.008173
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        var_1 = matchpathcon("/")
    except OSError as e:
        var_1 = e
    try:
        var_2 = matchpathcon("/bin/ls")
    except OSError as e:
        var_2 = e
    try:
        var_3 = matchpathcon("/bin/ls", 1)
    except OSError as e:
        var_3 = e
    try:
        var_4 = matchpathcon("/bin/ls", 1, "system_u")
    except OSError as e:
        var_4 = e

# Generated at 2022-06-24 21:17:34.852852
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/ssh/sshd_config'
    mode = None
    ret = matchpathcon(path, mode)
    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:ssh_etc_t:s0'


# Generated at 2022-06-24 21:17:37.543357
# Unit test for function matchpathcon
def test_matchpathcon():
    assert os.path.exists("/etc/selinux/config"), "SELinux not installed"
    matchpathcon("/etc/selinux/config", 0)

# Generated at 2022-06-24 21:17:47.857286
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print("************* lgetfilecon_raw tests **************")
    # This makes sure we have all the relevant
    # functions defined, so we are working with
    # an actual selinux library
    assert(selinux_getenforcemode)
    assert(selinux_getpolicytype)
    assert(is_selinux_enabled)
    assert(is_selinux_mls_enabled)
    assert(matchpathcon)
    assert(lgetfilecon_raw)
    assert(security_getenforce)

    # This test should fail, because it's a non-existent path. It should
    # return -1.
    errno = 0
    mode = 0

# Generated at 2022-06-24 21:17:54.060434
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/usr/bin/ls'
    result = lgetfilecon_raw(path)

    var_0 = result[0]  # rc
    var_1 = result[1]  # con
    if var_0 != 0:
        raise AssertionError("rc: %s, expected: %s" % (str(var_0), '0'))



# Generated at 2022-06-24 21:17:58.865255
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/test'
    mode = 0o777

    [rc, _] = matchpathcon(path, mode)
    assert rc == 0

    [rc, con] = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None

    # NB: no real way to know the correct context as it's system dependent
    assert con.startswith('system_u:object_r:default_t:s0')



# Generated at 2022-06-24 21:18:03.151574
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/sample')[0] == -1


# Generated at 2022-06-24 21:18:14.985441
# Unit test for function matchpathcon
def test_matchpathcon():
    if selinux_getenforcemode()[1] == 'Disabled' or selinux_getenforcemode()[1] == 'Permissive':
        assert matchpathcon('/usr/sbin/semanage', 1)[1] == 'system_u:object_r:semanage_exec_t:s0'
    else:
        assert matchpathcon('/usr/sbin/semanage', 1)[1].startswith('system_u:object_r:selinux_config_t:')


# Generated at 2022-06-24 21:18:16.925612
# Unit test for function matchpathcon
def test_matchpathcon():
    assert os.path.exists('/home/vagrant/ansible-core/lib/ansible/module_utils/selinux.py')


# Generated at 2022-06-24 21:18:23.982389
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = 0
    var_0 = selinux_getenforcemode()
    if var_0[1] == 0 or var_0[1] == 2:
        mode = mode + 8
    if var_0[1] == 1 or var_0[1] == 2:
        mode = mode + 4
    mode = mode + 1
    var_1 = matchpathcon('/var/tmp', mode)
    print(var_1[1])



# Generated at 2022-06-24 21:18:25.530748
# Unit test for function matchpathcon
def test_matchpathcon():
    file_path = ''
    mode = 0
    assert matchpathcon(file_path, mode) == [0, '']

# Generated at 2022-06-24 21:18:31.992333
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # NotEnoughSpace
    path = u'/etc/passwd'

    try:
        # Try to call function with not enough arguments
        # Result
        result = lgetfilecon_raw(path)
    except TypeError:
        # Unit test worked
        assert True
    except:
        # Unit test failed
        assert False



# Generated at 2022-06-24 21:18:32.778557
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert False



# Generated at 2022-06-24 21:18:34.526051
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("val", 0) == 0

# Generated at 2022-06-24 21:18:36.199357
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = 'README.md'
    var_1 = lgetfilecon_raw(file)


# Generated at 2022-06-24 21:18:39.970969
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/foo/bar'
    mode = 0
    ret = matchpathcon(path, mode)
    assert isinstance(ret, list)
    assert len(ret) == 2
    assert all(isinstance(val, int) for val in ret)


# Generated at 2022-06-24 21:18:41.547730
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/var/foo') == [0, 'system_u:object_r:system_log_t:s0']



# Generated at 2022-06-24 21:18:46.143931
# Unit test for function matchpathcon
def test_matchpathcon():
    # set up
    path = '/var/log/httpd'
    mode = 0

    # run
    rc = matchpathcon(path, mode)

    # assert
    assert rc[0] == 0



# Generated at 2022-06-24 21:18:48.836252
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/foo', 1) == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-24 21:18:51.093656
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/etc/passwd')


# Generated at 2022-06-24 21:18:57.726086
# Unit test for function matchpathcon
def test_matchpathcon():
    if selinux_getenforcemode()[1] != 1:
        return
    
    test = matchpathcon("etc/hosts", 0)
    assert test[0] == 0
    
    test = matchpathcon("/", 0)
    assert test[0] == 0
    
    test = matchpathcon("/usr/bin/id", 0)
    assert test[0] == 0
    
    test = matchpathcon("/etc/passwd", 0)
    assert test[0] == 0


# Generated at 2022-06-24 21:19:05.717956
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Tests if the function can handle all the possible scenarios of its usage.
    """

    test_file = "/etc/hosts"

    # Tests if the function can handle the expected scenario, where it returns 0.
    assert lgetfilecon_raw(test_file)[0] == 0

    # Tests if the function can handle the expected scenario, where it returns 0, and
    # checks if the returned value is the expected one.
    assert lgetfilecon_raw(test_file)[0] == 0
    assert lgetfilecon_raw(test_file)[1] == "system_u:object_r:etc_t:s0"

    # Tests if the function can handle a scenario where the provided
    # path does not exist and it returns -1.
    assert lgetfilecon_raw("/foo/bar/file")[0]

# Generated at 2022-06-24 21:19:07.219857
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert callable(lgetfilecon_raw)


# Generated at 2022-06-24 21:19:10.503328
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # See if the lgetfilecon_raw function works
    expected_result = 0
    actual_result = lgetfilecon_raw('/etc/passwd')
    assert actual_result[0] == expected_result



# Generated at 2022-06-24 21:19:16.279356
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/tmp/test', 0)
    assert result
    assert result == [0, 'system_u:object_r:tmp_t:s0']


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:19:17.957081
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc"
    out, err = lgetfilecon_raw(path)
    assert out[0] == 0



# Generated at 2022-06-24 21:19:19.720681
# Unit test for function matchpathcon
def test_matchpathcon():
    assert ['0', '/foo/bar:system_u:object_r:dummy_t'] == matchpathcon('/foo/bar', 0)


# Generated at 2022-06-24 21:19:31.226463
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: seems to be a bug in this function*
    rc, con = selinux_getenforcemode()
    rc, policy = selinux_getpolicytype()

    if policy == 'targeted':
        if con == 1:
            # SELinux is enabled in enforcing mode
            mode = 1
        elif con == 0:
            # SELinux is enabled in permissive mode
            mode = 0
        else:
            raise Exception('Unexpected error: selinux_getenforcemode() failed')
    else:
        raise Exception('Unsupported SELinux policy "{0}"'.format(policy))

    rc, con = matchpathcon(b'/', mode)
    print(rc, con)

    rc, con = lgetfilecon_raw(b'/')
    print(rc, con)



# Generated at 2022-06-24 21:19:33.246584
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert var_0[0] == 0


var_0 = test_lgetfilecon_raw()


# Generated at 2022-06-24 21:19:36.968529
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = ('/var/log')
    assert True == lgetfilecon_raw(var_1)


# Generated at 2022-06-24 21:19:43.132591
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Set up test parameters
    path = "/bin/ping"
    path_type = type(path)

    # Perform the call to lgetfilecon_raw
    var_0 = lgetfilecon_raw(path)

    # Assert the call succeeded
    assert var_0[0] == 0, "Failed to call lgetfilecon_raw function.  Got rc: {0}".format(var_0[0])

    # Assert the return type is a 1-tuple
    assert isinstance(var_0, tuple), "Failed to call lgetfilecon_raw function.  Expected a tuple, but got: {0}".format(type(var_0))

# Generated at 2022-06-24 21:19:48.937066
# Unit test for function matchpathcon
def test_matchpathcon():
    testcase = {
        # TODO: this test needs a real policy
    }

    for fname, cfg in testcase.items():
        test_fn = getattr(sys.modules[__name__], 'test_{0}'.format(fname))
        cfg.setdefault('module', __name__)
        yield test_fn, cfg

# Generated at 2022-06-24 21:19:51.383952
# Unit test for function matchpathcon
def test_matchpathcon():
    err, msg = matchpathcon('/etc/passwd', 0)
    assert msg == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-24 21:19:55.645949
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon('/etc/selinux/config', '0644')
    # assert var_0[0] == 0
    # assert var_0[1] == 'system_u:object_r:selinux_config_t:s0'


# Generated at 2022-06-24 21:19:58.389797
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw('')
    len_of_var_0 = len(var_0)
    print(len_of_var_0)
    print(var_0)


# Generated at 2022-06-24 21:20:02.819950
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path='path') == [0, None]

# Generated at 2022-06-24 21:20:05.570810
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/ansible/ansible.cfg'
    mode = 1 # for non-directory
    retval = matchpathcon(path, mode)
    assert retval[0] == 0
    assert retval[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-24 21:20:18.587413
# Unit test for function matchpathcon
def test_matchpathcon():
    assert not matchpathcon(path=None, mode=None), "Expected function to return False, got {0}".format(matchpathcon(path=None, mode=None))



# Generated at 2022-06-24 21:20:19.538268
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 1 == lgetfilecon_raw(b"test_path")[0]


# Generated at 2022-06-24 21:20:25.100137
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test for function matchpathcon."""

    # test_matchpathcon_posix
    assert matchpathcon('/tmp', 0)[0] == 0
    assert matchpathcon('/tmp', 0)[1] == 'tmp:var_tmp_t'

    # test_matchpathcon_posix_error
    assert matchpathcon('/tmp/nonexistent_dir', 0)[0] == -1

    # test_matchpathcon_windows
    assert matchpathcon(r'c:\temp', 0)[0] == 0
    assert matchpathcon(r'c:\temp', 0)[1] == 'nt_file_t'

    # test_matchpathcon_windows_error
    assert matchpathcon(r'c:\temp\nonexistent_dir', 0)[0] == -1



# Generated at 2022-06-24 21:20:26.533566
# Unit test for function matchpathcon
def test_matchpathcon():
    # assert type(matchpathcon()) == list
    assert True # TODO: implement your test here


# Generated at 2022-06-24 21:20:29.498648
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected = [0, 'unconfined_u:object_r:user_home_t:s0']
    actual = lgetfilecon_raw(b'/home/test')
    assert expected == actual


# Generated at 2022-06-24 21:20:33.607054
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b"/" # https://bugzilla.redhat.com/show_bug.cgi?id=1388207
    assert lgetfilecon_raw(path) == [0, b"system_u:object_r:etc_t:s0"]

# Generated at 2022-06-24 21:20:42.788552
# Unit test for function matchpathcon
def test_matchpathcon():
    # From /usr/include/selinux/selinux.h
    SELINUX_ANDROID_RESTORECON_DATADATA = 1
    # From /usr/include/selinux/selinux.h
    SELINUX_DEFAULT_CONTEXT_PATH = "/etc/selinux/default/contexts/files/file_contexts"
    # From /usr/include/selinux/selinux.h
    SELINUX_DEFAULT_TYPE = "default_type"
    # From /usr/include/selinux/selinux.h
    SELINUX_ANDROID_RESTORECON_FORCE = 2
    # From /usr/include/selinux/selinux.h
    SELINUX_ANDROID_RESTOREC

# Generated at 2022-06-24 21:20:48.274895
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = 'test/test.txt'
    x = lgetfilecon_raw(path)[1]
    assert x



# Generated at 2022-06-24 21:20:54.033093
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Calling function matchpathcon with path=/etc/selinux/config and mode=0")
    assert matchpathcon('/etc/selinux/config', 0) == [0, 'unconfined_u:object_r:etc_t:s0']

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-24 21:20:59.967700
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = os.stat('/etc/passwd')
    var_2 = to_bytes('/etc/passwd')
    var_3 = to_bytes('unconfined_u:object_r:user_home_t:s0')
    assert lgetfilecon_raw(var_2) == [0, var_3], 'lgetfilecon /etc/passwd'
    assert lsetfilecon(var_2, var_3) == 0, 'lsetfilecon /etc/passwd'


# Generated at 2022-06-24 21:21:24.442665
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/tmp/1") == [0, "system_u:object_r:tmp_t:s0"]
    assert lgetfilecon_raw("/tmp/2") == [0, "system_u:object_r:tmp_t:s0"]
    assert lgetfilecon_raw("/tmp/3") == [0, "system_u:object_r:tmp_t:s0"]
    assert lgetfilecon_raw("/tmp/4") == [0, "system_u:object_r:tmp_t:s0"]
    assert lgetfilecon_raw("/tmp/5") == [0, "system_u:object_r:tmp_t:s0"]

# Generated at 2022-06-24 21:21:28.292451
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/ansible') == [0, 'unconfined_t']
    assert lgetfilecon_raw('/tmp/does-not-exist') == [-1, 'unconfined_t']


# Generated at 2022-06-24 21:21:31.631769
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/test/test1',0) == [0,'system_u:object_r:usr_t:s0']



# Generated at 2022-06-24 21:21:33.290937
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    with pytest.raises(NotImplementedError):
        lgetfilecon_raw(path)


# Generated at 2022-06-24 21:21:35.277380
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_name = "/tmp"
    con = lgetfilecon_raw(file_name)
    print(con)


# Generated at 2022-06-24 21:21:42.893551
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = None
    test_file = "/etc/passwd"
    con = c_char_p()

    rc = lgetfilecon_raw(test_file)[0]
    assert rc == 0, "Failure - expected return code of 0, got {}".format(rc)

    rc = lgetfilecon_raw(path)[0]
    assert rc == -1, "Failure - expected return code of -1, got {}".format(rc)


# Generated at 2022-06-24 21:21:50.718282
# Unit test for function matchpathcon

# Generated at 2022-06-24 21:21:58.925715
# Unit test for function matchpathcon
def test_matchpathcon():
    tests = [[None, 2, [1, None]],
             ['/proc/sys/kernel/printk', 0, [0, b'ox']],
             ['/proc/sys/kernel/printk', 2, [0, b'ox']],
             ['/dev/sda1', 0, [0, b'bx']],
             ['-', 0, [0, b'?']],
             ]

    for path, mode, should_be in tests:
        got = matchpathcon(path, mode)
        if got != should_be:
            raise Exception("matchpathcon({0}, {1}) == {2} should be {3}".format(path, mode, got, should_be))



# Generated at 2022-06-24 21:22:05.566698
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fixture_path = '/tmp/ansible_selinux_test_'

    try:
        os.mkdir(fixture_path)
        rc, con = lgetfilecon_raw(fixture_path)
        assert rc == 0
        assert con == 'system_u:object_r:ansible_temp_t:s0'
    finally:
        os.rmdir(fixture_path)

# Generated at 2022-06-24 21:22:08.282395
# Unit test for function matchpathcon
def test_matchpathcon():
    # Run unit test
    rc, con = matchpathcon('/path', 1)
    assert rc == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'



# Generated at 2022-06-24 21:22:44.930530
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/etc/cron.d")



# Generated at 2022-06-24 21:22:50.209356
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/bin/sh")
    # The following assertion looks strange, but it is what we expect
    assert rc == -1, "Expected return value to be -1, but it was %s" % rc
    assert con == None, "Expected return value to be None, but it was %s" % con

# Generated at 2022-06-24 21:22:51.921836
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # No need to test return value, this is just a wrapper
    lgetfilecon_raw('')


# Generated at 2022-06-24 21:22:53.046120
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='test', mode=1)


# Generated at 2022-06-24 21:22:57.263957
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/dev/null', 0) == [0, 'system_u:object_r:null_device_t:s0']


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-24 21:23:06.859793
# Unit test for function matchpathcon
def test_matchpathcon():
    # Order of path components has been changed from posix
    # (because the order of entries in the dict passed to the module
    # matters in python 2, but not python 3)
    assert matchpathcon(b"/home/foo/bar", 0) == [0, u'unconfined_u:object_r:user_home_dir_t:s0']
    assert matchpathcon(b"/etc/my.cnf", 0) == [0, u'unconfined_u:object_r:etc_t:s0']
    assert matchpathcon(b"/tmp/my.cnf", 0) == [0, u'unconfined_u:object_r:tmp_t:s0']

# Generated at 2022-06-24 21:23:09.490502
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, sout = matchpathcon('/path', 0)
    assert rc == 0 and sout == 'system_u:object_r:usr_t:s0'


# Generated at 2022-06-24 21:23:11.990281
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/foo"
    mode = 0
    expected = [0, 'bar']
    actual = matchpathcon(path, mode)
    assert actual == expected


# Generated at 2022-06-24 21:23:21.079994
# Unit test for function matchpathcon
def test_matchpathcon():
    paths = [
        '/usr/bin/ls',
        '/foo/bar/baz',
        '/this/directory/does/not/exist',
    ]
    modes = [0, 1, 2]
    fc_files = '/tmp/fc_files'

    # load the policy so we can run path matches
    with open(fc_files, 'rt') as f:
        fc_files = f.read().splitlines()

    for path in paths:
        for mode in modes:
            test_path = path
            rc = 0

# Generated at 2022-06-24 21:23:24.232569
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'any_value'
    mode = 0
    assert matchpathcon(path, mode) == [0, 'any_value']


# Generated at 2022-06-24 21:24:45.769216
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    tests = (
        ("/", ("system_u:object_r:root_t:s0", 0)),
    )
    for path, expected_result in tests:
        result = lgetfilecon_raw(path)
        assert result == expected_result, "Unexpected result returned.  Expected: {} Actual: {}".format(expected_result, result)
    # No more tests


# Generated at 2022-06-24 21:24:52.286112
# Unit test for function matchpathcon
def test_matchpathcon():
    # Testing return type
    rc, out = matchpathcon('/tmp/test_file', 0)
    assert type(rc) is int
    assert type(out) is str


if __name__ == '__main__':
    test_case_0()
    test_matchpathcon()

# Generated at 2022-06-24 21:24:56.680909
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: configure path to test against
    filepath = '/etc/default/ansible-test'
    var_1 = lgetfilecon_raw(filepath)
    return var_1


# Generated at 2022-06-24 21:24:59.142537
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Path does not exist
    con = '/nonexist'
    result = lgetfilecon_raw(con)

    assert result[0] == -1
    assert result[1] is None



# Generated at 2022-06-24 21:25:08.398651
# Unit test for function matchpathcon
def test_matchpathcon():

    # Check return value
    if selinux_getpolicytype()[1] == b'targeted':
        assert matchpathcon(b'/etc/passwd', 0)[1] == b'system_u:object_r:etc_t:s0'
        assert matchpathcon(b'/etc/passwd', 1)[1] == b'system_u:object_r:system_conf_t:s0'
        assert matchpathcon(b'/etc/shadow', 0)[1] == b'user_u:object_r:shadow_t:s0'
        assert matchpathcon(b'/etc/shadow', 1)[1] == b'user_u:object_r:shadow_t:s0'

# Generated at 2022-06-24 21:25:13.881703
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert(lgetfilecon_raw('/sbin/ping'))


# Generated at 2022-06-24 21:25:21.098165
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    var_0 = lgetfilecon_raw(path)
    if var_0[1] is None:
        print('file doesnt exist')
    else:
        print('selinux context is %s' % var_0[1])

    print()
    path = 'doesnt_exist'
    var_0 = lgetfilecon_raw(path)
    if var_0[1] is None:
        print('file doesnt exist')
    else:
        print('selinux context is %s' % var_0[1])



# Generated at 2022-06-24 21:25:26.009112
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # From global var
    global var_0
    # Assign to local var
    var_1 = var_0
    # Call function
    var_2 = lgetfilecon_raw(var_1)
    # Check type of function call
    assert isinstance(var_2, list)


# Generated at 2022-06-24 21:25:28.882256
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: matchpathcon only works with fixed paths
    #path = create_temp_file()
    #con = matchpathcon(path)
    #remove_temp_file(path)
    pass



# Generated at 2022-06-24 21:25:36.971845
# Unit test for function matchpathcon
def test_matchpathcon():
    # Clear the environment
    saved = {}
    for envvar in ('SELINUX_ROLE_REQUEST', 'SELINUX_LEVEL_REQUEST'):
        if envvar in os.environ:
            saved[envvar] = os.environ[envvar]
            del os.environ[envvar]
    assert os.environ.pop('SELINUX_ROLE_REQUEST', None) is None
    assert os.environ.pop('SELINUX_LEVEL_REQUEST', None) is None

    # Initial state
    assert selinux_getenforcemode() == [0, 1]
    assert security_getenforce() == True
    assert security_policyvers() == 28
    assert is_selinux_enabled() == [0, 1]
    assert is_selinux_ml