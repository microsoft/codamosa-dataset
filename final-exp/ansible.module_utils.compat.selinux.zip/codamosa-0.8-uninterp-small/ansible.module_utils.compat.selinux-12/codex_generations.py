

# Generated at 2022-06-24 21:17:06.854096
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon("/path", 0)
    assert rc[0] == 0

# Generated at 2022-06-24 21:17:13.452341
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'foo'
    mode = 0
    expected = [0, b'0']
    actual = matchpathcon(path, mode)
    assert actual == expected
    path = b'/etc/shadow'
    mode = os.R_OK
    expected = [0, b'0']
    actual = matchpathcon(path, mode)
    assert actual == expected


# Generated at 2022-06-24 21:17:15.345027
# Unit test for function matchpathcon
def test_matchpathcon():
    assert not matchpathcon('/test/test', 0)



# Generated at 2022-06-24 21:17:18.509569
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = '/etc/hosts'
    rc, result = lgetfilecon_raw(filename)
    assert rc == 0


# Generated at 2022-06-24 21:17:22.873120
# Unit test for function matchpathcon
def test_matchpathcon():

    assert matchpathcon('home/rhel')
    assert matchpathcon('home/rhel/test')
    assert matchpathcon('home/rhel/test.txt')


# Generated at 2022-06-24 21:17:25.384582
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'foo'
    mode = 0
    expected = [0, 'foo']
    actual = matchpathcon(path, mode)

    assert actual == expected, "Expected: %s, Actual: %s" % (expected, actual)



# Generated at 2022-06-24 21:17:32.501540
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, res = lgetfilecon_raw('/etc/passwd')
    assert res == 'unconfined_u:object_r:user_home_t:s0'


if __name__ == '__main__':
    test_case_0()
    sys.exit(0)

# Generated at 2022-06-24 21:17:36.285041
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp'
    path_octal = b'\x2f\x74\x6d\x70'
    assert lgetfilecon_raw(path)[0] == 0
    assert lgetfilecon_raw(path_octal)[0] == 0
    # Failure cases
    assert lgetfilecon_raw('\x2f\x74\x6d\x70_non_existent')[0] == -1
    assert lgetfilecon_raw('')[0] == -1
    assert lgetfilecon_raw(None)[0] == -1
    assert lgetfilecon_raw([])[0] == -1



# Generated at 2022-06-24 21:17:37.882252
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(path=None)


# Generated at 2022-06-24 21:17:38.479250
# Unit test for function matchpathcon
def test_matchpathcon():
    assert True

# Generated at 2022-06-24 21:17:44.303453
# Unit test for function matchpathcon
def test_matchpathcon():
    # Check edge cases
    assert matchpathcon(None, 0) == [0, 'unlabeled']
    assert matchpathcon('', 0) == [0, 'unlabeled']
    # Check real label
    real_label = matchpathcon('/etc/selinux/targeted/policy/policy.21', 0)[1]
    assert 'selinuxfs' in real_label
    assert 'system_u:object_r:file_t:s0' in real_label



# Generated at 2022-06-24 21:17:45.759228
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    assert lgetfilecon_raw(path) == [0, "system_u:object_r:etc_t:s0"]



# Generated at 2022-06-24 21:17:48.333296
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(to_bytes('./test_file'))
    assert rc == -1
    assert con == None


# Generated at 2022-06-24 21:17:53.465509
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert _selinux_lib.lgetfilecon_raw(b'/etc/passwd', c_char_p()) == 0
    assert _selinux_lib.lgetfilecon_raw(b'non_existent_file', c_char_p()) == -1


# Generated at 2022-06-24 21:17:56.973601
# Unit test for function matchpathcon
def test_matchpathcon():
    with open('/testpathcon') as file:
        mode = file.mode
        assert not (mode & 0o777 ^ 0o777)
    assert matchpathcon(b'/testpathcon/myfile', mode) == [0, u'user_u:user_r:user_t:s0']



# Generated at 2022-06-24 21:18:00.432216
# Unit test for function matchpathcon
def test_matchpathcon():
    exp_path = '/var/tmp/foo/bar'
    exp_ret = [0, 'bar_tmp_t']
    ret = matchpathcon(exp_path, os.X_OK)
    assert ret == exp_ret



# Generated at 2022-06-24 21:18:06.948412
# Unit test for function lgetfilecon_raw

# Generated at 2022-06-24 21:18:11.675899
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('path', 1)
    assert rc == 1, 'Expected 1, but got %s' % rc
    assert con.startswith('system_u:object_r:kernel_t:s0') or con == ''


# Generated at 2022-06-24 21:18:14.680474
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='/var/tmp/foo',mode=0) == [0, 'system_u:object_r:tmp_t:s0']


# Generated at 2022-06-24 21:18:15.814368
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert None is not lgetfilecon_raw(path=None)


# Generated at 2022-06-24 21:18:21.014545
# Unit test for function matchpathcon
def test_matchpathcon():
    assert(matchpathcon('/', 1)[0] == 0)


# Generated at 2022-06-24 21:18:27.542253
# Unit test for function matchpathcon
def test_matchpathcon():
    # Read test values
    test_values = test_case_0()
    test_path = test_values["test_path"]
    test_mode = test_values["test_mode"]

    expected = test_values["expected"]

    # Call the function
    result = matchpathcon(test_path, test_mode)

    print(result)

    assert result == expected

if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-24 21:18:31.583852
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/file_contexts.local"
    var_0 = lgetfilecon_raw(path)
    assert var_0[0] == 0, "Return value of 'lgetfilecon_raw' doesn't match expected return value"


# Generated at 2022-06-24 21:18:35.725750
# Unit test for function matchpathcon
def test_matchpathcon():
    if (os.getenv('ANSIBLE_SELINUX_GETPOLICYTYPE') and os.getenv('ANSIBLE_SELINUX_MATCHPATHCON_PATH')
        and os.getenv('ANSIBLE_SELINUX_MATCHPATHCON_MODE')):
        matchpathcon(os.getenv('ANSIBLE_SELINUX_MATCHPATHCON_PATH'), int(os.getenv('ANSIBLE_SELINUX_MATCHPATHCON_MODE')))


# Generated at 2022-06-24 21:18:39.613416
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "../../../../etc/bashrc"
    mode = 8
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert result[1] == "etc_t:object_r:etc_runtime_t"


# Generated at 2022-06-24 21:18:46.047244
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp"
    mode = 0

    try:
        mpc = matchpathcon(path, mode)
    except OSError as e:
        if e.args[0] == 13:
            raise
        else:
            raise

    rc = mpc[0]
    con = mpc[1]

    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-24 21:18:54.012521
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    stub_path = "/foo"
    stub_con = "/bar"

    _selinux_lib.lgetfilecon_raw.side_effect = lambda path, con: [0, stub_con]

    expected = "foo"
    actual = lgetfilecon_raw(stub_path)

    _selinux_lib.lgetfilecon_raw.assert_called_once_with(stub_path, expected)

    assert actual == expected


# Generated at 2022-06-24 21:19:00.896069
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/var/lib/OpenShift/pods/to_replace") == [-1, None]
    assert lgetfilecon_raw("/var/lib/OpenShift/pods/to_replace") == [-1, None]
    assert lgetfilecon_raw("/var/lib/OpenShift/pods/to_replace") == [-1, None]
    assert lgetfilecon_raw("/var/lib/OpenShift/pods/to_replace") == [-1, None]
    assert lgetfilecon_raw("/var/lib/OpenShift/pods/to_replace") == [-1, None]


# Generated at 2022-06-24 21:19:05.464298
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/usr/bin/passwd")[0] == 0
    assert lgetfilecon_raw("/usr/bin/passwd")[1].startswith("unconfined_u:object_r:passwd_exec_t:s0")



# Generated at 2022-06-24 21:19:07.375234
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/etc/passwd")


# Generated at 2022-06-24 21:19:18.069881
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/path/to/file'
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-24 21:19:20.071447
# Unit test for function matchpathcon
def test_matchpathcon():
    assert isinstance(matchpathcon(b'/foo/bar', 0), list)



# Generated at 2022-06-24 21:19:30.345547
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/null"
    
    # Make sure the file we are working with doesn't already exist
    if os.path.exists(path):
        os.remove(path)

    # Make sure we are dealing with a clean slate
    result = lgetfilecon_raw(path)
    if result[0] != -1 or result[1] != None:
        assert False
        
    # Create the file we are working with
    with open(path, "w") as f:
        f.write("test")
    
    # Make sure that the file now exists and has the correct context
    result = lgetfilecon_raw(path)
    if result[0] != 0 or result[1] != "system_u:object_r:default_t:s0":
        assert False
    
    # Cleanup the file

# Generated at 2022-06-24 21:19:34.009216
# Unit test for function matchpathcon
def test_matchpathcon():
    string_0 = '/var/log'
    int_0 = 0
    list_0 = matchpathcon(string_0, int_0)
    string_1 = ''
    assert list_0 == [0, string_1]


# Generated at 2022-06-24 21:19:40.201075
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/root/foo.txt"
    con = lgetfilecon_raw(path)
    assert con[0] == -1
    assert con[1] == None

# Generated at 2022-06-24 21:19:45.321228
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon("unittest_data_files/test_3", 0)


if __name__ == "__main__":
    test_case_0()
    test_matchpathcon()

# Generated at 2022-06-24 21:19:50.618058
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # TODO: Fix this test to return an array for comparison
    path = "/etc/fstab"
    var = lgetfilecon_raw(path)
    assert var[0] == 0, "lgetfilecon_raw does not return 0"
    assert len(var[1].split(":")) == 3, "lgetfilecon_raw does not return selinux context"


# Generated at 2022-06-24 21:19:59.742777
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/a', 0) == [0, u'system_u:object_r:var_t:s0']
    assert matchpathcon('/dev/pts', 0) == [0, u'system_u:object_r:devpts_t:s0']
    assert matchpathcon('/dev/kmsg', 0) == [0, u'system_u:object_r:unlabeled_t:s0']
    assert matchpathcon('/var/log', 0) == [0, u'system_u:object_r:var_log_t:s0']
    assert matchpathcon('/var/log/', 0) == [0, u'system_u:object_r:var_log_t:s0']

# Generated at 2022-06-24 21:20:02.465535
# Unit test for function matchpathcon
def test_matchpathcon():
    assert True


# Generated at 2022-06-24 21:20:04.655076
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon('/etc/my_file', 1)
    var_1 = matchpathcon('my_file', 1)


# Generated at 2022-06-24 21:20:26.044036
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/python3')[1] == 'system_u:object_r:bin_t:s0'
#

# Generated at 2022-06-24 21:20:27.167989
# Unit test for function matchpathcon
def test_matchpathcon():

    assert isinstance(matchpathcon(b"/etc/shadow", 0), list)

# Generated at 2022-06-24 21:20:31.438332
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = None
    assert lgetfilecon_raw(path) == [0, '']


# Generated at 2022-06-24 21:20:40.261584
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: this is not a valid test, it is dependant on the environment
    assert lgetfilecon_raw('/')[1] == 'system_u:object_r:boot_t:s0'
    assert matchpathcon('/', 0)[1] == 'system_u:object_r:boot_t:s0'
    # NB: the following are different cases
    assert lgetfilecon_raw('/etc')[1]
    assert matchpathcon('/etc', 0)[1]
    assert lgetfilecon_raw('/etc/passwd')[1]
    assert matchpathcon('/etc/passwd', 0)[1]
    assert lgetfilecon_raw('/etc/passwd-')[1]
    assert matchpathcon('/etc/passwd-', 0)[1]
    assert l

# Generated at 2022-06-24 21:20:43.450744
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with arguments:
    path = b'/tmp/ansible_test_file'
    open(path, 'a')
    var_0 = lgetfilecon_raw(path)
    assert(len(var_0) == 2)
    os.unlink(path)


# Generated at 2022-06-24 21:20:48.892401
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: implement function test_matchpathcon
    assert False, "function test_matchpathcon not implemented"



# Generated at 2022-06-24 21:20:53.429126
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/var/log') == ['system_u:object_r:var_log_t:s0-s0:c0.c1023']


# Generated at 2022-06-24 21:20:56.675680
# Unit test for function matchpathcon
def test_matchpathcon():
    pass # FIXME: raise NotImplementedError()


# Generated at 2022-06-24 21:21:01.222694
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/my.cnf"
    mode = 0
    assert matchpathcon(path, mode)[0] == 0


# Generated at 2022-06-24 21:21:02.105625
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('test')[0] == -1


# Generated at 2022-06-24 21:21:36.695633
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/selinux/config"
    rc, con = lgetfilecon_raw(path)
    if con:
        assert rc == 0
        assert con.startswith("system_u:object_r:selinux_config_t:s0")
    else:
        assert rc == -1



# Generated at 2022-06-24 21:21:42.219726
# Unit test for function matchpathcon
def test_matchpathcon():
    file_path = '/var/opt/myfile'
    PATH_MODE = 0x0
    res = matchpathcon(file_path, PATH_MODE)
    assert res[0] == 0
    assert res[1] == "system_u:object_r:var_t:s0"


# Generated at 2022-06-24 21:21:44.468052
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon('/var/lib/foo', 0)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-24 21:21:49.214522
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(sys.modules[__name__].__file__)))))
    assert lgetfilecon_raw(path) == [0, 'system_u:object_r:usr_t:s0']


# Generated at 2022-06-24 21:21:51.374889
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/test.txt'
    con_list = lgetfilecon_raw(path)
    print(con_list)


# Generated at 2022-06-24 21:21:55.210170
# Unit test for function matchpathcon
def test_matchpathcon():
    con = c_char_p()
    path = b'/path'
    mode = 1
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    assert rc == 0


# Generated at 2022-06-24 21:21:57.959724
# Unit test for function matchpathcon
def test_matchpathcon():
    args = ["/proc/self/fd/1", "1"]
    err_code, con = matchpathcon(*args)
    assert err_code == 0
    assert isinstance(con, str)


# Generated at 2022-06-24 21:22:02.527407
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/selinux/targeted/contexts/files/file_contexts"
    res = lgetfilecon_raw(path)
    assert res[0] == 0



# Generated at 2022-06-24 21:22:05.010091
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert to_native(lgetfilecon_raw(b'/etc/shadow')[1]) == b'system_u:object_r:shadow_t:s0'


# Generated at 2022-06-24 21:22:06.753708
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    assert lgetfilecon_raw('') == [0, 'unlabeled_t']


# Generated at 2022-06-24 21:23:24.569587
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/dev/null') == [0, 'system_u:object_r:null_device_t:s0']


# Generated at 2022-06-24 21:23:30.461305
# Unit test for function matchpathcon
def test_matchpathcon():
    # Assign example arguments
    path = '/var/www/html'
    mode = 0

    # Call matchpathcon
    var_0 = matchpathcon(path, mode)

    assert not var_0[0]
    assert var_0[1] == 'system_u:object_r:httpd_sys_content_t:s0'



# Generated at 2022-06-24 21:23:33.019754
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp')



# Generated at 2022-06-24 21:23:34.790081
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = lgetfilecon_raw('/etc/passwd')
    print(con[1])

# Generated at 2022-06-24 21:23:37.943332
# Unit test for function matchpathcon
def test_matchpathcon():
    path='/tmp/file'
    mode='r'
    assert matchpathcon(path,mode) == [0, 'system_u:object_r:unlabeled_t:s0']

# Generated at 2022-06-24 21:23:39.761397
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = 'test_file_0'
    var_2 = lgetfilecon_raw(var_1)


# Generated at 2022-06-24 21:23:43.962377
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon('/some/file', 0)

    assert var_1 == [0, 'system_u:object_r:usr_t:s0']


if __name__ == '__main__':
    print('testing local libselinux module')
    test_case_0()
    test_matchpathcon()
    print('success')

# Generated at 2022-06-24 21:23:46.867367
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: Run this test with an enabled context, then with a disabled context
    assert lgetfilecon_raw('/tmp')[0] == 0


# Generated at 2022-06-24 21:23:50.124047
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path=b'/var/tmp/test.py', mode=0) == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-24 21:23:52.948312
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/foo'
    result = lgetfilecon_raw(path)
    assert result == [0, 'system_u:object_r:tmp_t:s0']


# Generated at 2022-06-24 21:26:45.172914
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # Case 1
    var_1 = lgetfilecon_raw(path="/var/tmp/t")
    print(var_1)

    # Case 2
    var_1 = lgetfilecon_raw(path="./t")
    print(var_1)



# Generated at 2022-06-24 21:26:47.817700
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path_con = lgetfilecon_raw('/bin/ls')[1]
    assert file_path_con == 'unconfined_u:object_r:bin_t:s0'


# Generated at 2022-06-24 21:26:50.719161
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/tmp", 0)[0] == 0
    assert matchpathcon("/tmp/foo.txt", 0)[0] == 0


# Generated at 2022-06-24 21:26:55.622327
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, value = lgetfilecon_raw(b'/foo')
    assert rc == 0
    assert value == 'system_u:object_r:var_log_t:s0'


# Generated at 2022-06-24 21:27:03.221168
# Unit test for function matchpathcon
def test_matchpathcon():
    # Match our path with selinux
    assert matchpathcon('/var/tmp', 0)
    # Try again, with this path missing
    assert matchpathcon('/var/tmp/missing', 0)
    # Try again, with this path missing
    assert matchpathcon('/etc/passwd', 0)
    # Try again, with this path missing
    assert matchpathcon('/etc/', 0)
    # Try again, with this path missing
    assert matchpathcon('/', 0)
    # Test a path that does not exist
    assert matchpathcon('/var/tmp/foo', 0)
    # Match our path with selinux
    assert matchpathcon('/var/tmp', 1)
    # Try again, with this path missing
    assert matchpathcon('/var/tmp/missing', 1)
    # Try again, with