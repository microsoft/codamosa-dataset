

# Generated at 2022-06-24 21:17:18.720353
# Unit test for function matchpathcon
def test_matchpathcon():

    # Unit test for function matchpathcon
    assert matchpathcon('/var/www', 4) == [0, 'object_r:httpd_sys_content_t']
    assert matchpathcon('/var/www/index.html', 4) == [0, 'object_r:httpd_sys_content_t']
    assert matchpathcon('/var/www', 0) == [0, 'system_u:object_r:httpd_sys_content_t']
    assert matchpathcon('/var/www/index.html', 0) == [0, 'system_u:object_r:httpd_sys_content_t']
    assert matchpathcon('/var/www', 1) == [0, 'object_r:httpd_sys_content_t']

# Generated at 2022-06-24 21:17:19.639994
# Unit test for function matchpathcon
def test_matchpathcon():
    assert type(matchpathcon('/')[0]) is int


# Generated at 2022-06-24 21:17:20.664066
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/"
    mode = None
    assert matchpathcon(path, mode) == [0, "user_home_t"]



# Generated at 2022-06-24 21:17:25.499291
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert to_native(os.environ['PATH']) == lgetfilecon_raw(to_native(os.environ['PATH']))[1]
    assert to_native(os.environ['PATH']) == lgetfilecon_raw(to_native(os.environ['PATH']) + 'x')[1]

# Generated at 2022-06-24 21:17:35.137023
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def test0(path):
        con = c_char_p()
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        _selinux_lib.freecon(con)
        return rc

    def test1(path):
        con = c_char_p()
        rc = lgetfilecon_raw(path)[0]
        return rc

    # the ret code is 0 if the call works
    assert test0('/etc/passwd') == 0
    assert test1('/etc/passwd') == 0
    # the ret code is -1 if the call fails
    assert test0('/etc/passwd-bad') == -1
    assert test1('/etc/passwd-bad') == -1



# Generated at 2022-06-24 21:17:46.151829
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    invalid_file_path=''
    valid_file_path='/etc/passwd'
    invalid_retval,invalid_retval_msg = lgetfilecon_raw(invalid_file_path)
    valid_retval, valid_retval_msg = lgetfilecon_raw(valid_file_path)
    if invalid_retval != -1:
        raise Exception("For invalid file path '{}' the return value was not -1 it was {}".format(invalid_file_path,invalid_retval))
    if valid_retval != 0:
        raise Exception("For valid file path '{}' the return value was not 0 it was {}".format(valid_file_path,valid_retval))

# Generated at 2022-06-24 21:17:47.530833
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, result = lgetfilecon_raw('/tmp')


# Generated at 2022-06-24 21:17:51.798715
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert os.path.exists(to_native(lgetfilecon_raw(b'/usr/lib/libselinux.so.1')[1]))


# Generated at 2022-06-24 21:17:54.227309
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/bin/foo', 1) == [0, 'unconfined_u:object_r:user_home_t:s0']


# Generated at 2022-06-24 21:17:56.439943
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/home/') == [0, u'system_u:object_r:home_root_t:s0']


# Generated at 2022-06-24 21:18:03.128482
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/source')[0] == 0


# Generated at 2022-06-24 21:18:04.980888
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/hosts'
    mode = 0
    ret = matchpathcon(path, mode)
    assert ret[0] == 0



# Generated at 2022-06-24 21:18:14.641966
# Unit test for function matchpathcon
def test_matchpathcon():
    to_native_orig = to_native
    to_bytes_orig = to_bytes
    import ansible.module_utils.selinux as selinux
    to_native = to_native_orig
    to_bytes = to_bytes_orig
    # Create an instance of the function
    function = selinux.matchpathcon
    # Create an instance of the actual output
    actual_output = function('/foo/bar', 0)

    print("Output: {}".format(actual_output))


# Generated at 2022-06-24 21:18:16.083772
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/usr/sbin/ntpd")[0] == 0


# Generated at 2022-06-24 21:18:17.587166
# Unit test for function matchpathcon
def test_matchpathcon():
    assert selinux_getpolicytype() == [0, 'targeted']

    # matchpathcon() already returns an error code, just check for it
    assert matchpathcon('/admin/homedir/inode', 10)[0] == 0



# Generated at 2022-06-24 21:18:21.417353
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/bin/ls"
    assert lgetfilecon_raw(path) == [0, "unconfined_u:object_r:bin_t:s0"]


# Generated at 2022-06-24 21:18:23.317015
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon(
        '/home/docs',
        0,
    )


# Generated at 2022-06-24 21:18:27.060055
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(to_bytes('/etc/shadow'), 32768) == [0, 'system_u:object_r:shadow_t:s0']



# Generated at 2022-06-24 21:18:35.379321
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True),
        ),
        supports_check_mode=True,
    )

    path = module.params['path']

    rc, con = lgetfilecon_raw(path)
    if rc == 0:
        module.exit_json(changed=True, con=con)
    else:
        e = OSError(rc, os.strerror(rc))
        module.fail_json(msg=to_native(e), exception=traceback.format_exc())



# Generated at 2022-06-24 21:18:37.581548
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0)[0] in (0, -1)


# Generated at 2022-06-24 21:18:46.499969
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/hosts"
    var_0 = lgetfilecon_raw(path)
    if var_0[0] != 0:
        raise OSError('lgetfilecon_raw failed')
    if var_0[1] == '':
        raise AssertionError('empty string returned by lgetfilecon_raw')


# Generated at 2022-06-24 21:18:49.558847
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path="/etc/resolv.conf") == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-24 21:19:00.290572
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/tmp/', 0) == [0, 'system_u:object_r:tmp_t:s0\x00']
    assert matchpathcon('/tmp/foo', 0) == [0, 'system_u:object_r:tmp_t:s0\x00']
    assert matchpathcon('/home/foo/bar', 0) == [0, 'user_u:object_r:user_home_t:s0\x00']
    assert matchpathcon('/home/foo/bar/baz', 0) == [0, 'user_u:object_r:user_home_t:s0\x00']
    assert matchpathcon('/var/log/', 0) == [0, 'system_u:object_r:var_log_t:s0\x00']

# Generated at 2022-06-24 21:19:01.388252
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc', 0)



# Generated at 2022-06-24 21:19:05.324175
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/'
    mode = 0
    actual = matchpathcon(path, mode)
    expected = [0, 'system_u:object_r:tmp_t:s0']
    assert actual == expected


# Generated at 2022-06-24 21:19:07.704363
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/test') == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-24 21:19:09.925448
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = '/tmp'
    var_1 = 0
    result = matchpathcon(var_0, var_1)


# Generated at 2022-06-24 21:19:15.420455
# Unit test for function matchpathcon
def test_matchpathcon():
    args = {}
    args['path'] = "/tmp/some/file/name"

    ret = matchpathcon(**args)

    for i in ret:
        print(i)


# Generated at 2022-06-24 21:19:17.203038
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/home/test/test.txt')[0] == 0


# Generated at 2022-06-24 21:19:18.451781
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(1, 1) == [0, None]


# Generated at 2022-06-24 21:19:24.950719
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/sudoers'[0]) == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:19:27.375678
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp', 0) == [0, 'u:object_r:tmp_t:s0']


# Generated at 2022-06-24 21:19:31.886452
# Unit test for function matchpathcon
def test_matchpathcon():
    assert False

# TODO: No tests for function matchpathcon_index


# Generated at 2022-06-24 21:19:40.335697
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.basic import AnsibleModule

    expected_rc = 0
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str'),
            mode=dict(type='int', default=0),
        )
    )
    result = matchpathcon(module.params['path'], module.params['mode'])

    if result[0] != expected_rc:
        module.fail_json(msg='module returned wrong value {0}, expected {1}'.format(result[0], expected_rc))

    module.exit_json(changed=False, **result[1])

# Generated at 2022-06-24 21:19:46.723383
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Setup
    path = '/tmp/ansible_selinux_test_file'

    # Test
    try:
        with open(path, 'w') as f:
            f.write('ansible test file')
        rc, con = lgetfilecon_raw(path)

        assert rc == 0
        assert con is not None
    finally:
        os.unlink(path)



# Generated at 2022-06-24 21:19:48.221056
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/var')[1]

# Generated at 2022-06-24 21:19:50.289429
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert None is lgetfilecon_raw('/etc/passwd')[1]


# Generated at 2022-06-24 21:19:57.235115
# Unit test for function matchpathcon
def test_matchpathcon():
    assert not os.path.exists('/tmp/foobar.txt')
    assert not os.path.exists('/tmp/foobar')
    rc, con = matchpathcon('/tmp/foobar.txt', 0)
    assert rc == 0
    assert con is not None
    assert con.startswith('system_u:object_r:tmp_t:s0')
    assert not os.path.exists('/tmp/foobar.txt')


# Generated at 2022-06-24 21:20:04.641089
# Unit test for function matchpathcon
def test_matchpathcon():
    file = 'file.txt'
    mode = os.R_OK
    # Create a test file
    with open(file, 'w') as test_file:
        test_file.write('test')

    # Test the file has read rights
    result = matchpathcon(file, mode)
    assert result[1] == 'test_t:test_t:s0'
    # Delete the test file
    os.remove(file)

# Generated at 2022-06-24 21:20:14.127109
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test case 1
    # FIXME: support passing an os.stat_result argument
    #
    # FIXME: mode should be passed as a ctypes int, not a python int
    #
    # SKIP: rc, var_1 = matchpathcon(stat_result(st_mode=S_IFDIR|0o0755, st_ino=1, st_dev=1, st_nlink=2, st_uid=1000, st_gid=1000, st_size=4096, st_atime=1595007854, st_mtime=1595007854, st_ctime=1595007854), 0o755)
    # SKIP: assert var_1 == 'system_u:object_r:tmp_t:s0'
    var_2 = matchpathcon(b'3', 0)

# Generated at 2022-06-24 21:20:20.567964
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filepath = "/tmp/fake"
    mode = 0
    result = lgetfilecon_raw(filepath)
    if result[0] == 0:
        assert result[1] == "unconfined_u:object_r:user_tmp_t:s0"
    else:
        assert False



# Generated at 2022-06-24 21:20:26.677509
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/init/control-alt-delete.conf')
    assert rc == 0
    assert con == 'system_u:object_r:init_var_run_t:s0'


# Generated at 2022-06-24 21:20:31.874073
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filepath = 'some/file/path'
    value = [0, 'unconfined_u:object_r:user_tmp_t:s0']

    # patch lgetfilecon_raw with mock return
    def mock_lgetfilecon_raw(path):
        assert path == filepath
        return value

    lgetfilecon_raw.__wrapped__ = mock_lgetfilecon_raw
    rc, con = lgetfilecon_raw(filepath)
    assert rc == value[0]
    assert con == value[1]



# Generated at 2022-06-24 21:20:36.736733
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/selinux/default/contexts/files"
    mode = 0
    expected_result = [0, "system_u:object_r:default_contexts_t:s0\n"]

    actual_result = matchpathcon(path, mode)

    assert actual_result == expected_result, "Expected: {}, Actual: {}".format(expected_result, actual_result)



# Generated at 2022-06-24 21:20:44.151708
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        con = c_char_p()
        rc = _selinux_lib.lgetfilecon_raw('abc', byref(con))
        if rc == 0:
            raise AssertionError('lgetfilecon success on non-existent file')
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-24 21:20:50.092021
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/tmp/conftest', os.R_OK)
    assert rc == 0
    assert isinstance(con, str)

# Generated at 2022-06-24 21:20:54.456466
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = 0
    path = ''
    result = matchpathcon(path, mode)
    assert result == [0, 'system_u:object_r:named_zone_t:s0']


# Generated at 2022-06-24 21:21:00.250653
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Check if the function runs without error
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:tmp_t:s0']
    assert lgetfilecon_raw('/does/not/exist/inode') == [-1, "lgetfilecon_raw('/does/not/exist/inode') failed: No such file or directory"]
    assert lgetfilecon_raw('') == [0, 'system_u:object_r:unlabeled_t:s0']


# Generated at 2022-06-24 21:21:02.522603
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/pam.d', 0) == [0, 'etc_t']



# Generated at 2022-06-24 21:21:04.761952
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path='/tmp')[0] == -1



# Generated at 2022-06-24 21:21:20.438838
# Unit test for function matchpathcon
def test_matchpathcon():
    path = str()
    mode = c_int()

    try:
       _ret = matchpathcon(path, mode)
    except Exception as _ret:
       return (_ret)

    if _ret[0] is None:
        pass
    elif _ret[0] is False:
        pass
    elif _ret[0] is True:
        pass
    elif _ret[0] == 0:
        pass
    elif _ret[0] != 0:
        pass
    else:
        pass


# Generated at 2022-06-24 21:21:23.616936
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected = [0, 'system_u:object_r:lib_t:s0']
    actual = lgetfilecon_raw('/lib/libc.so.6')
    print("Expect %s and got %s" % (expected, actual))
    assert expected == actual


# Generated at 2022-06-24 21:21:26.170114
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '.'
    mode = 0
    returned = matchpathcon(path, mode)
    assertions = [
                (2, returned[0])
                #(True, returned[1])
                ]
    for assertion in assertions:
        expected = assertion[0]
        actual = assertion[1]
        assert expected == actual



# Generated at 2022-06-24 21:21:27.806173
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/blah"
    var_1 = lgetfilecon_raw(path)


# Generated at 2022-06-24 21:21:31.926376
# Unit test for function matchpathcon
def test_matchpathcon():
    filename = '/tmp/foo'
    os.mkdir(filename)
    try:
        assert matchpathcon(filename, 0)[0] == 0
    finally:
        os.rmdir(filename)



# Generated at 2022-06-24 21:21:35.362283
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    out = lgetfilecon_raw(path)
    assert out[0] > 0
    assert out[1] == 'unconfined_u:object_r:user_home_t:s0'


# Generated at 2022-06-24 21:21:40.234841
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/usr/bin/python3"
    mode = 0
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert result[1] == "system_u:object_r:python_exec_t:s0"


# Generated at 2022-06-24 21:21:43.506179
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, result = lgetfilecon_raw(b"/tmp/test")
    assert rc == 0
    assert result == "system_u:object_r:tmp_t:s0"


# Generated at 2022-06-24 21:21:47.323116
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon(b'/proc/self/fd/3', 4)
    assert var_0 == [0, 'system_u:object_r:unlabeled_t:s0']



# Generated at 2022-06-24 21:21:57.556479
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def __init__(self, var_0):
        self.arg_0 = var_0

    def __call__(self, *args, **kwargs):
        return self.arg_0

    setlocale = Mock(return_value=['/etc/selinux/targeted/policy/policy.24', 0])
    stderr = Mock(return_value=[b'SELinux is disabled\n'])


# Generated at 2022-06-24 21:22:15.148738
# Unit test for function matchpathcon
def test_matchpathcon():
    assert callable(matchpathcon)


# Generated at 2022-06-24 21:22:20.269158
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass


# Generated at 2022-06-24 21:22:23.851709
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/selinux/config"
    mode = 0o400
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert result[1] == "system_u:object_r:semanage_etc_t:s0"


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-24 21:22:26.388826
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path='foo') == [0, 'user_u:object_r:lib_t:s0']



# Generated at 2022-06-24 21:22:29.344964
# Unit test for function matchpathcon
def test_matchpathcon():
    path = ""
    mode = 0
    ret_exp = 0
    ret_out = matchpathcon(path, mode)
    assert ret_out[0] == ret_exp


# Generated at 2022-06-24 21:22:30.875439
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = "/etc/hosts"
    rc,con = lgetfilecon_raw(file)
    assert rc == 0
    assert con != ""


# Generated at 2022-06-24 21:22:37.554063
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("dir", 2)[0] == 0, \
        "matchpathcon('dir', 2) failed"
    assert matchpathcon("dir", 1)[0] == 0, \
        "matchpathcon('dir', 1) failed"
    assert matchpathcon("dir", 0)[0] == 0, \
        "matchpathcon('dir', 0) failed"


# Generated at 2022-06-24 21:22:42.962748
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon(path="/path/to/file", mode=0)
    match = "context"
    count = 0
    try:
        assert res[0] in (-1, -2)
        assert res[1] == match, "Fail: " + res[1]
        count += 1
    except AssertionError:
        assert False, "Test1 failed"
    finally:
        if count != 1:
            assert False, "Test1 failed"


# Generated at 2022-06-24 21:22:46.859819
# Unit test for function matchpathcon
def test_matchpathcon():
    path = ''
    mode = 0
    retval = matchpathcon(path, mode)
    # Check "retval" value
    assert retval is None
    return 



# Generated at 2022-06-24 21:22:52.449043
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/bin/ls'
    mode = 0
    ret = matchpathcon(path, mode)
    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:bin_t:s0'



# Generated at 2022-06-24 21:23:36.571772
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Test lgetfilecon_raw module
    '''
    path = '/etc/ansible/hosts'
    expected_result = [0, 'system_u:object_r:etc_t:s0']
    actual_result = lgetfilecon_raw(path)

    for i in range(0, len(expected_result)):
        assert actual_result[i] == expected_result[i],\
               "expected %s, got %s" % (expected_result[i], actual_result[i])

# Generated at 2022-06-24 21:23:41.298199
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    cmd = 'lgetfilecon -v /etc/shadow'
    rc, out, err = module.run_command(cmd)
    assert rc == 0
    out = out.split(':')[1].strip()
    cmd = 'lgetfilecon_raw /etc/shadow'
    rc = lgetfilecon_raw(cmd)
    assert rc[0] == 0
    assert rc[1] == out



# Generated at 2022-06-24 21:23:44.483428
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/example.txt'
    mode = 0o644
    con = 'unconfined_u:object_r:user_tmp_t:s0'
    [rc, result] = matchpathcon(path, mode)
    assert rc == 0 and result == con


# Generated at 2022-06-24 21:23:46.623455
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, _ = matchpathcon('/tmp', 0)
    assert rc == 0



# Generated at 2022-06-24 21:23:49.606254
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = '/app/app/app-1.0.jar'
    var_2 = lgetfilecon_raw(var_1)



# Generated at 2022-06-24 21:23:53.421266
# Unit test for function matchpathcon
def test_matchpathcon():
    assert [0, 'system_u:object_r:usr_t:s0'] == matchpathcon('/usr', 0)
    assert [0, 'system_u:object_r:usr_t:s0'] == matchpathcon('/usr/bin/pam_timestamp_check', 0)



# Generated at 2022-06-24 21:24:03.545854
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME - this needs to be converted to a testdeclared module
    assert selinux_getpolicytype()[1] == 'targeted'
    assert selinux_getenforcemode()[1] == 0
    assert security_getenforce() == 0
    assert is_selinux_enabled() == 1
    assert is_selinux_mls_enabled() == 0
    assert security_policyvers() == 29
    # assert lgetfilecon_raw('/var')[1] == 'system_u:object_r:virt_var_lib_t:s0'
    # assert matchpathcon('/var', 0)[1] == 'system_u:object_r:virt_var_lib_t:s0'

# Generated at 2022-06-24 21:24:05.002372
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/tmp/test1.txt', 1)
    assert res[0] == 0


# Generated at 2022-06-24 21:24:14.632939
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/test', 0) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/etc/selinux/', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t:s0']
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/run', 0) == [0, 'system_u:object_r:run_t:s0']
    assert matchpathcon('/home', 0) == [0, 'system_u:object_r:home_root_t:s0']

# Generated at 2022-06-24 21:24:23.287235
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Start function test_matchpathcon')

# Generated at 2022-06-24 21:25:53.527542
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon with a file in the system path
    """
    assert 0 == matchpathcon('/bin/bash', os.R_OK)[0]


# Generated at 2022-06-24 21:25:56.211455
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path='/sys/fs/cgroup/unified/system.slice.%c')[0] == 0


# Generated at 2022-06-24 21:26:04.551938
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(to_native(b'/etc/shadow')) == [0, to_native(b"system_u:object_r:shadow_t:s0")]
    assert lgetfilecon_raw(to_native(b'/etc/passwd')) == [0, to_native(b"system_u:object_r:etc_runtime_t:s0")]
    assert lgetfilecon_raw(to_native(b'/etc/sssd.conf')) == [0, to_native(b"system_u:object_r:sssd_etc_t:s0")]

# Generated at 2022-06-24 21:26:15.249743
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = var_0
    ret = lgetfilecon_raw(path)
    var_1 = ret


# Generated at 2022-06-24 21:26:22.291166
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/bin/setfiles -n -c -F /etc/selinux/targeted/contexts/files/file_contexts -r /etc/selinux/targeted/contexts/files/file_contexts.homedirs /', 1) == [0, 'system_u:object_r:bin_t:s0']


# Generated at 2022-06-24 21:26:25.959819
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/etc/hosts") == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:26:30.852831
# Unit test for function matchpathcon
def test_matchpathcon():
    retval = matchpathcon(u'/usr/share/foo/bar/kaz.txt', 0)
    retval = matchpathcon(u'/usr/share/foo/bar/zoo.txt', 0)
    retval = matchpathcon(u'/usr/share/foo/bar/zoo.txt', 1)

# Generated at 2022-06-24 21:26:34.911620
# Unit test for function matchpathcon
def test_matchpathcon():
    print(os.path.abspath(__file__))
    rc, con = matchpathcon(os.path.abspath(__file__), 0)
    print('context: %s' % con)


# Generated at 2022-06-24 21:26:38.413060
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/a/file'  # type: bytes
    res = lgetfilecon_raw(path)
    assert(type(res) is list)


# Generated at 2022-06-24 21:26:42.594101
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/resolv.conf'
    ret = lgetfilecon_raw(path)
    assert isinstance(ret, list)
    assert len(ret) == 2
    assert ret[0] == 0
    assert isinstance(ret[1], str)
    assert ret[1]

