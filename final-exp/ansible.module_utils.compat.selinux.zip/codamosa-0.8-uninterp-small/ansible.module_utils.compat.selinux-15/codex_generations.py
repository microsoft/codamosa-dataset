

# Generated at 2022-06-24 21:17:14.863206
# Unit test for function matchpathcon
def test_matchpathcon():
    path = ''
    mode = 0
    rc, con = matchpathcon(path, mode)
    if rc == 0:
        print("matchpathcon:{0}".format(con))
    else:
        print("matchpathcon failed")

if sys.argv[1] == 'test_case_0':
    test_case_0()

if sys.argv[1] == 'test_matchpathcon':
    test_matchpathcon()

# Generated at 2022-06-24 21:17:19.066663
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/fstab')[0] == 0
    assert lgetfilecon_raw(b'/tmp/libselinux-test-missing')[0] == -1


# Generated at 2022-06-24 21:17:23.480676
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = '/path/to/file'
    [rc, con] = lgetfilecon_raw(file)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-24 21:17:25.207448
# Unit test for function matchpathcon
def test_matchpathcon():
    assert callable(matchpathcon)
    assert matchpathcon('path', 0) == [0, 'system_u:object_r:bin_t:s0']



# Generated at 2022-06-24 21:17:28.061491
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert selinux_getenforcemode()[1] in ('enforcing', 'permissive', 'disabled')
    assert selinux_getpolicytype()[1] == 'targeted'


# Generated at 2022-06-24 21:17:33.283430
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    expected_rc = 0
    expected_out = 'system_u:object_r:etc_runtime_t:s0'
    actual_rc, actual_out = matchpathcon(path, mode)
    assert actual_rc == expected_rc
    assert actual_out == expected_out


# Generated at 2022-06-24 21:17:36.024740
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-24 21:17:40.459406
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon("/usr/sbin/rsyslogd", 0)
    if var_1[0] < 0:
        raise NotImplementedError("Error invoking {}: {}", var_1[0], var_1[1])



# Generated at 2022-06-24 21:17:47.677111
# Unit test for function matchpathcon
def test_matchpathcon():

    # Load function matchpathcon
    module_path = os.path.join(os.path.dirname(__file__), '../lib/ansible/module_utils/selinux.py')
    sys.path.append(os.path.expanduser(module_path))
    from ansible.module_utils.selinux import matchpathcon

    # Call function matchpathcon
    rc, constype = matchpathcon('/tmp', 0)
    print("rc: {0}, constype: {1}".format(rc, constype))


# Generated at 2022-06-24 21:17:51.020552
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw("/etc/passwd")


# Generated at 2022-06-24 21:17:54.513797
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/etc/ssh/sshd_config")[0] == 0


# Generated at 2022-06-24 21:17:56.733835
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert(lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_t:s0'])


# Generated at 2022-06-24 21:17:58.528113
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/etc/redhat-release', 0)
    assert result == [0, 'system_u:object_r:etc_runtime_t']



# Generated at 2022-06-24 21:18:05.041106
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test for lgetfilecon_raw"""
    _1 = lgetfilecon_raw(0)
    assert isinstance(_1, list)
    _2 = lgetfilecon_raw(1)
    assert isinstance(_2, list)
    _3 = lgetfilecon_raw(2)
    assert isinstance(_3, list)
    _4 = lgetfilecon_raw(3)
    assert isinstance(_4, list)
    _5 = lgetfilecon_raw(4)
    assert isinstance(_5, list)
    _6 = lgetfilecon_raw(5)
    assert isinstance(_6, list)
    _7 = lgetfilecon_raw(6)
    assert isinstance(_7, list)


# Generated at 2022-06-24 21:18:17.212655
# Unit test for function matchpathcon
def test_matchpathcon():

    if selinux_getenforcemode():
        # set (temporarily) to permissive mode
        assert selinux_getenforcemode() == [0, 1]

        # test_case_0
        var_1 = matchpathcon(b'/etc/shadow', 0)
        assert matchpathcon(b'/etc/shadow', 0) == [0, 'system_u:object_r:shadow_t:s0']
        assert matchpathcon(b'/etc/shadow', 1) == [0, 'system_u:object_r:shadow_t:s0']
        assert matchpathcon(b'/etc/shadow', 2) == [0, 'system_u:object_r:shadow_t:s0']

        # test_case_1
        var_2 = matchpathcon(b'/sys/', 4)

# Generated at 2022-06-24 21:18:26.609375
# Unit test for function matchpathcon
def test_matchpathcon():
    r = matchpathcon("/home/test/test_file", 1)
    assert r[0] == 0
    assert r[1] == 'system_u:object_r:user_home_dir_t:s0'
    r = matchpathcon("/home/test/test_file", 0)
    assert r[0] == 0
    assert r[1] == 'system_u:object_r:user_home_dir_t:s0'
    r = matchpathcon("/home/test/test_file", 2)
    assert r[0] == 1
    assert r[1] == 'system_u:object_r:user_home_dir_t:s0'


# Generated at 2022-06-24 21:18:32.745191
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/test_file"
    open(path, "w").close()
    var = lgetfilecon_raw(path)
    assert isinstance(var, list)
    assert var[1] is not None
    os.unlink(path)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:18:36.674398
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # call function
    var_0 = lgetfilecon_raw('/selinux/test')
    assert var_0 == [0, 'system_u:object_r:selinuxfs:s0']


# Generated at 2022-06-24 21:18:43.158490
# Unit test for function matchpathcon
def test_matchpathcon():
    assert _selinux_lib.matchpathcon is not None
    assert _selinux_lib.matchpathcon('file', 0)



# Generated at 2022-06-24 21:18:48.629324
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('foo') == [0, 'system_u:object_r:systemd_journal_dev_t:s0']
    assert lgetfilecon_raw('/etc/shadow') == [0, 'system_u:object_r:shadow_t:s0']
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:tmp_t:s0']


# Generated at 2022-06-24 21:18:59.603280
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/resolv.conf"
    mode = 0
    ret = matchpathcon(path, mode)
    # Check if the return code is as expected
    assert(ret[0] == 0)
    # Check if the return value is as expected
    assert(ret[1] == "system_u:object_r:net_conf_t:s0")

# Generated at 2022-06-24 21:19:02.948995
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    res = lgetfilecon_raw(path)
    assert res[0] >= 0 and res[0] < 2147483648, res[0]
    assert res[1] is not None, res[1]


# Generated at 2022-06-24 21:19:14.288066
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: refactor this test
    import os
    import random
    import string
    from ansible.module_utils.selinux import selinux_getpolicytype, matchpathcon

    # create a random file path in the root, call matchpathcon and then remove it
    policy_type, errno = selinux_getpolicytype()
    assert errno == 0

# Generated at 2022-06-24 21:19:15.892061
# Unit test for function matchpathcon
def test_matchpathcon():
    con = c_char_p()
    ret = matchpathcon('/etc/shadow', 1)

    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:shadow_t:s0'



# Generated at 2022-06-24 21:19:18.408831
# Unit test for function matchpathcon
def test_matchpathcon():
    target_file = "/etc/locale.conf"
    context = "system_u:object_r:textrel_shlib_t:s0"
    assert matchpathcon(target_file, 0) == [0, context]



# Generated at 2022-06-24 21:19:25.189347
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        # Unit test for function lgetfilecon_raw
        var_0 = lgetfilecon_raw('/etc/selinux/config')
    except ImportError as ie:
        print(ie)



# Generated at 2022-06-24 21:19:26.824048
# Unit test for function matchpathcon
def test_matchpathcon():
    assert(type(matchpathcon(None, 0)) == list)


# Generated at 2022-06-24 21:19:32.944162
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # read file and return context
    try:
        with open("blah", "r") as f:
            [rc, con] = lgetfilecon_raw("blah")
    except Exception as e:
        print("Test failed: {0}".format(str(e)))

# Generated at 2022-06-24 21:19:37.854815
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/var/log/audit/audit.log"
    label = lgetfilecon_raw(path)
    assert label == ('system_u:object_r:auditlog_t:s0', None)


# Generated at 2022-06-24 21:19:44.668698
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('non_empty', 0) == [0, b'non_empty']
    assert matchpathcon('non_empty', 1) == [0, b'non_empty']
    assert matchpathcon('non_empty', 2) == [0, b'non_empty']



# Generated at 2022-06-24 21:19:50.607021
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: stub out errcheck and implement Unit test for function lgetfilecon_raw
    pass


# Generated at 2022-06-24 21:19:55.922757
# Unit test for function matchpathcon
def test_matchpathcon():
    src_path = "/var/cache/ansible"
    mode = os.lstat(src_path).st_mode
    con = matchpathcon(src_path, mode)[1]
    assert con == "system_u:object_r:user_tmp_t:s0"


# Generated at 2022-06-24 21:19:57.235319
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var0 = lgetfilecon_raw(b"testvar0")
    print(var0)


# Generated at 2022-06-24 21:20:02.944786
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/etc/group', 0)[0] == -1


# Generated at 2022-06-24 21:20:04.772336
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/foo", 0) == [0, 'system_u:object_r:user_home_dir_t:s0']


# Generated at 2022-06-24 21:20:09.058281
# Unit test for function matchpathcon
def test_matchpathcon():
    assert True


# Generated at 2022-06-24 21:20:11.700696
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/some/file"
    # FIXME: write unit test
    # assert lgetfilecon_raw(path) ==
    # assert lgetfilecon_raw(path) is not None
    assert True



# Generated at 2022-06-24 21:20:14.998395
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/etc/shadow", 0)
    assert rc == 0, "matchpathcon(%r) failed: %r" % ("/etc/shadow", -rc)
    assert con == "shadow_t", "matchpathcon(%r) returned incorrect context: %r" % ("/etc/shadow", con)



# Generated at 2022-06-24 21:20:18.537408
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'somefile.txt'     # string
    mode = 0                  # int
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con.startswith('unconfined_u:object_r:')
    assert con.endswith('_t:s0')


# Generated at 2022-06-24 21:20:20.294162
# Unit test for function matchpathcon
def test_matchpathcon():
    # Prepare the arguments
    path = 'test_file'
    mode = 0

    # Run the function
    matchpathcon(path, mode)


# Generated at 2022-06-24 21:20:26.124022
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(None, None) == [0, None]
    assert matchpathcon(None, None) == [0, None]



# Generated at 2022-06-24 21:20:30.047029
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon(r"/home/ansible/test.txt", 0)
    assert len(var_1) == 2
    assert var_1[0] == 0
    assert var_1[1] == 'unconfined_u:object_r:user_home_t:s0'


# Generated at 2022-06-24 21:20:32.577137
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon("/nonexistant/path/to/file", 0)
    assert var_0[0] == -1


# Generated at 2022-06-24 21:20:34.958869
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, b'unconfined_u:object_r:user_home_t:s0']


# Generated at 2022-06-24 21:20:36.259967
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert(lgetfilecon_raw(None))


# Generated at 2022-06-24 21:20:42.343879
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected = [0, 'system_u:object_r:var_run_t:s0']
    with open('/var/run', 'r') as f:
        assert lgetfilecon_raw(f.fileno()) == expected


# Generated at 2022-06-24 21:20:45.882067
# Unit test for function matchpathcon
def test_matchpathcon():
    args = ["/home/ansible/ansible-test/test_collections/ansible_collections/roles/test_role/tasks/main.yml", 0]
    if matchpathcon(*args) != [0, "system_u:object_r:myrole_mytask_tmp_t:s0"]:
        raise AssertionError()


# Generated at 2022-06-24 21:20:47.018278
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Run your function being tested
    var_1 = lgetfilecon_raw("/etc/selinux/config")
    assert var_1[0] == 0



# Generated at 2022-06-24 21:20:50.687469
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'foo.txt' # The parameter to test with
    mode = '1' # The parameter to test with
    ret = matchpathcon(path, mode)
    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:unlabeled_t:s0'



# Generated at 2022-06-24 21:20:54.117457
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = os.stat(path).st_mode

    rc, con_actual = matchpathcon(path, mode)
    assert rc == 0, 'Expected 0, got {0}'.format(rc)

    con_expected = 'system_u:object_r:passwd_file_t:s0'
    assert con_actual == con_expected, 'Expected {0}, got {1}'.format(con_expected, con_actual)


if __name__ == '__main__':
    test_case_0()
    test_matchpathcon()

# Generated at 2022-06-24 21:21:06.344175
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    with mock.patch('ctypes.CDLL.lgetfilecon_raw') as mock_lgetfilecon_raw:
        mock_lgetfilecon_raw.return_value = (1, 2)
        strvalue = 'test_strvalue'
        test_instance = mock_selinux()
        result = test_instance.lgetfilecon_raw(strvalue)
        assert result == (1, 2)
        assert mock_lgetfilecon_raw.call_count == 1


# Generated at 2022-06-24 21:21:16.872817
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    good_path = '/etc/passwd'
    bad_path = '/etc/missing'
    # Create a file for testing
    os.mknod(good_path)

    # tests for rc
    rc, con = lgetfilecon_raw(good_path)
    if rc != 0:
        raise RuntimeError("Bad return code, expected 0, got {0}".format(rc))

    rc, con = lgetfilecon_raw(bad_path)
    if rc != -1:
        raise RuntimeError("Bad return code, expected -1, got {0}".format(rc))

    # tests for con
    rc, con = lgetfilecon_raw(good_path)
    if con is None:
        raise RuntimeError("Get file context failed")


# Generated at 2022-06-24 21:21:19.085117
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/dev/null'
    rc, con = lgetfilecon_raw(path)
    print(rc, con)


# Generated at 2022-06-24 21:21:21.653958
# Unit test for function matchpathcon
def test_matchpathcon():
    args = ['test_file', 0]
    rc, con = matchpathcon(*args)
    assert rc == 0
    assert con is not None


# Generated at 2022-06-24 21:21:31.181040
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        from collections import namedtuple
    except ImportError as ex:
        return 'skip'

    # TODO: what about py3?
    if sys.version_info[0] < 2:
        return 'skip'
    # FIXME: find a better way to do this test
    class _FileSystem:
        def __init__(self, fs_map):
            self._fs = fs_map

        def isfile(self, filename):
            return self._fs.get(filename) is not None

        def isdir(self, filename):
            return any(d.startswith(filename + '/') for d in self._fs)

        def getfilesystemencoding(self):
            return 'utf-8'

        # FIXME: add more fs functions required by this module

# Generated at 2022-06-24 21:21:32.861564
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc')
    assert rc == 0


# Generated at 2022-06-24 21:21:36.771481
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/some_file', 0)
    #
    # TODO: check the result
    #
    # AssertionError: l['/some_file'] != 'system_u:object_r:admin_home_t:s0'
    #
    #
    #
    #
    #

# Generated at 2022-06-24 21:21:48.611526
# Unit test for function matchpathcon
def test_matchpathcon():
    paths = [
        '/usr/bin/ping',
        '/sbin/init',
        '/etc/sudoers',
        '/run/systemd/system/docker.service',
        '/',
        '',
        '/does/not/exist',
    ]
    for path in paths:
        # path exists and is a file
        if os.path.isfile(path):
            mode = 0
        # path exists and is a dir
        elif os.path.isdir(path):
            mode = 1
        # path exists and is a symlink
        elif os.path.islink(path):
            mode = 2
        # path doesnt exist
        else:
            mode = 3

        rc, con = matchpathcon(path, mode)

# Generated at 2022-06-24 21:21:50.739153
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, out = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert out is not None



# Generated at 2022-06-24 21:21:55.910196
# Unit test for function matchpathcon
def test_matchpathcon():
    for path in [b'/tmp', '/tmp']:
        for mode in [0, 1, 2]:
            rc, con = matchpathcon(path, mode)
            assert rc == 0 and con
            assert isinstance(con, str)
            assert not con.startswith(b'selinux_err')



# Generated at 2022-06-24 21:22:15.275501
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # Test 1: Validate function returns expected data format and data
    path = "/etc/passwd"
    assert lgetfilecon_raw(path) == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-24 21:22:16.667412
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/sys', 1) == [0, 'sysfs_t']


# Generated at 2022-06-24 21:22:21.400741
# Unit test for function matchpathcon
def test_matchpathcon():
    func = getattr(__import__('selinux'), 'matchpathcon')
    assert func
    # Call the function
    func('/var/tmp/test', 0)
    func('/var/tmp/test', 1)


# Generated at 2022-06-24 21:22:24.244620
# Unit test for function matchpathcon
def test_matchpathcon():
    assert os.path.exists('/home')
    # TODO: testcon /home should only be executable by user or group taytay
    results = matchpathcon('/home', os.R_OK)
    assert results[0] == 0
    assert results[1] == 'user_home_dir_t'


# Generated at 2022-06-24 21:22:28.030267
# Unit test for function matchpathcon
def test_matchpathcon():
    assert os.path.exists(os.path.dirname(__file__))
    for path in [os.path.dirname(__file__)]:
        ret = matchpathcon(path, 0)
        assert isinstance(ret, list)
        assert len(ret) == 2
        assert isinstance(ret[0], int)
        assert ret[0] == 0
        assert isinstance(ret[1], str)
        assert ret[1] is not None


# Generated at 2022-06-24 21:22:33.552236
# Unit test for function matchpathcon
def test_matchpathcon():
    # the policy type is arbitrary for this test
    policy_type = 'selinux'

    if policy_type == 'selinux' and not is_selinux_enabled():
        pytest.skip('SELinux is not enabled')

    # setup the test scenario
    temp_folder = tempfile.mkdtemp()
    new_path = os.path.join(temp_folder, 'test_matchpathcon')
    os.mknod(new_path)

    # expected path context is in secontext_test.py
    expected_path_context = 'system_u:object_r:usr_t:s0'

    assert matchpathcon(new_path, 0)[1] == expected_path_context

    # tear down the test scenario
    os.remove(new_path)

# Generated at 2022-06-24 21:22:35.814614
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon('/tmp', 0)
    assert rc[0] == -1
    assert rc[1] == ''



# Generated at 2022-06-24 21:22:38.296977
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/fake/path', 1)[1] == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-24 21:22:47.172762
# Unit test for function matchpathcon
def test_matchpathcon():
    # Python 2 and 3 compatible replacement for these libc calls:
    #     return matchpathcon_init("/etc/selinux/targeted/contexts/files/file_contexts")
    #     return matchpathcon(path, mode, &con)
    #     freecon(con)

    import tempfile
    import pytest

    test_context = '''
        # /tmp       u:object_r:tmp_t:s0
        /tmp/*      u:object_r:tmp_t:s0
        /var/tmp/   u:object_r:var_tmp_t:s0
    '''
    with tempfile.NamedTemporaryFile() as f:
        f.write(to_bytes(test_context))
        f.flush()

# Generated at 2022-06-24 21:22:49.829654
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:var_t:s0']


# Generated at 2022-06-24 21:23:30.420811
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        var_0 = matchpathcon("/etc/passwd", 0)
    except OSError as ex:
        print("[-] Error: matchpathcon: [Errno %d] %s" % (ex.errno, ex.strerror))
        return False

    return True


# Generated at 2022-06-24 21:23:34.940727
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    exp_result = [0, 'system_u:object_r:etc_t:s0']
    result = lgetfilecon_raw(path)
    assert result == exp_result, 'Expected: {0}, Received: {1}'.format(result, exp_result)


# Generated at 2022-06-24 21:23:38.164482
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='/tmp/foo', mode=0) == [0, 'unconfined_u:object_r:user_tmp_t:s0']



# Generated at 2022-06-24 21:23:41.082136
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    results = lgetfilecon_raw("/etc/passwd")
    assert results[0] == 0
    assert results[1] == "system_u:object_r:passwd_t:s0"


# Generated at 2022-06-24 21:23:46.728139
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # https://github.com/ansible/ansible-modules-core/pull/12753/files#r624881366
    # AnsibleModule.check_mode() default is True, which will be handled in module
    # Assume the following file:
    #     -rw-r--r--. root root unconfined_u:object_r:usr_t:s0 test
    # the context is `unconfined_u:object_r:usr_t:s0`

    try:
        selinux_lib.is_selinux_enabled()
    except OSError as e:
        # No SELinux, no need to test the wrapper
        assert e.errno == 19
        assert e.strerror == 'No such file or directory'

# Generated at 2022-06-24 21:23:49.729982
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon('/foo', 1)
    assert rc[0] == 0
    assert rc[1] == 'system_u:object_r:usr_t:s0'

# Generated at 2022-06-24 21:23:52.949217
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-24 21:23:58.163565
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 'SELinux function: lgetfilecon_raw' == 'lgetfilecon_raw'
    dummy = lgetfilecon_raw('/path/to/file')
    assert dummy[0] == 'SELinux function: lgetfilecon_raw'


# Generated at 2022-06-24 21:23:59.431790
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # call function
    var_0, var_1 = lgetfilecon_raw(b'/home/foo')
    assert var_1[:1].isalpha()


# Generated at 2022-06-24 21:24:01.679921
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/example.txt') == (0, 'unconfined_u:object_r:tmp_t:s0')


# Generated at 2022-06-24 21:25:34.058337
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        assert lgetfilecon_raw(test_file) == ['test_file_contexts', 'test_file_contexts']
    except OSError as e:
        if e.errno == errno.ENOENT:
            pytest.xfail('test file missing, skipping test')
        else:
            raise


# Generated at 2022-06-24 21:25:38.091716
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/path/to/file'
    mode = 0
    ret = matchpathcon(path, mode)
    assert ret == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:25:48.833917
# Unit test for function matchpathcon
def test_matchpathcon():
    print('test_matchpathcon')
    assert matchpathcon('/test_path/test_file', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/test_path/test_file', 1) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/test_path/test_file', 2) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/test_path/test_file', 3) == [0, 'system_u:object_r:etc_t:s0']

    # invalid type

# Generated at 2022-06-24 21:25:55.674217
# Unit test for function matchpathcon
def test_matchpathcon():
    assert to_native(matchpathcon("/home", 33188)[1]) == "system_u:object_r:user_home_dir_t:s0"


# Run a quick test to check that this module's basic functionality is working
import os.path
if __name__ == '__main__':
    if not os.path.isfile("/usr/sbin/lgetfilecon"):
        sys.exit("ERROR: You must install the libselinux-python package to run this test.")

    if os.getuid() != 0:
        sys.exit("ERROR: You must be root to run this test.")

    # Run the main test
    test_case_0()

# Generated at 2022-06-24 21:25:58.883165
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/usr/sbin/semanage"
    assert lgetfilecon_raw(path) == [0, 'system_u:object_r:semanage_exec_t:s0']


# Generated at 2022-06-24 21:26:00.668671
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon('/dev/log', 0)


# Generated at 2022-06-24 21:26:06.555370
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='/usr/bin/perl', mode=0) == [0, 'usr_t']
    assert matchpathcon(path='/usr/bin/perl', mode=1) == [0, 'usr_t']
    assert matchpathcon(path='/usr/bin/perl', mode=2) == [0, 'usr_t']
    assert matchpathcon(path='/usr/bin/perl', mode=3) == [0, 'usr_t']
    assert matchpathcon(path='/usr/bin/perl', mode=4) == [0, 'usr_t']
    assert matchpathcon(path='/some/non/existing/path', mode=4) == [2, None]



# Generated at 2022-06-24 21:26:07.730736
# Unit test for function matchpathcon
def test_matchpathcon():
    assert True is True


# Generated at 2022-06-24 21:26:10.723623
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/issue')
    assert rc >= 0
    #assert con == "system_u:object_r:etc_t:s0"


# Generated at 2022-06-24 21:26:19.480559
# Unit test for function matchpathcon
def test_matchpathcon():
    var = matchpathcon(path = "/etc/passwd", mode = 0)
    assert var[0] == -1 and var[1] == None # fail to match path context


__all__ = (
    'selinux_getenforce',
    'selinux_getenforcemode',
    'selinux_getpolicytype',
    'is_selinux_enabled',
    'is_selinux_mls_enabled',
    'lgetfilecon_raw',
    'matchpathcon',
    'lsetfilecon',
    'security_policyvers',
)