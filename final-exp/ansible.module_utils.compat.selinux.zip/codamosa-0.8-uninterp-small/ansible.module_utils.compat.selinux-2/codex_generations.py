

# Generated at 2022-06-24 21:17:07.859771
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        var_0 = matchpathcon('/home/some_user', 0)
    except OSError as e:
        if not e.filename or e.filename != '/home/some_user':
            raise



# Generated at 2022-06-24 21:17:15.372532
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    current_dir = os.path.dirname(os.path.realpath(__file__))
    dummy_file = os.path.join(current_dir, "dummy")
    fd = os.open(dummy_file, os.O_RDWR | os.O_CREAT)
    os.close(fd)

    os.remove(dummy_file)

# Generated at 2022-06-24 21:17:26.845582
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/shadow')[0] == 0
    assert lgetfilecon_raw(b'/etc/shadow')[1] == 'system_u:object_r:shadow_t:s0'
    assert lgetfilecon_raw(b'/dev/null')[0] == 0
    assert lgetfilecon_raw(b'/dev/null')[1] == 'system_u:object_r:chr_file_t:s0'
    assert lgetfilecon_raw(b'/tmp')[0] == 0
    assert lgetfilecon_raw(b'/tmp')[1] == 'system_u:object_r:default_t:s0'
    assert lgetfilecon_raw(b'/tmp/lgetfilecon_raw')[0] == 0
    assert l

# Generated at 2022-06-24 21:17:30.811931
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/etc/selinux/config")
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"


# Generated at 2022-06-24 21:17:33.999183
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = None
    ret = lgetfilecon_raw(path)
    assert ret[0] == -1
    assert os.strerror(ret[0]) == "No such file or directory"


# Generated at 2022-06-24 21:17:36.950322
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw('foo')
    var_1 = lgetfilecon_raw('bar')
    var_2 = lgetfilecon_raw('asdf')


# Generated at 2022-06-24 21:17:39.715801
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/var/log/ansible.log', 1)
    assert result[0] == 0
    assert result[1] == 'var_log_t'

# Generated at 2022-06-24 21:17:49.064829
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: check return values of selinux_getenforcemode
    assert 1 == selinux_getenforcemode()[0]
    assert selinux_getenforcemode()[1] in (0, 1)

    # FIXME: also check return value of selinux_getpolicytype
    assert 1 == selinux_getpolicytype()[0]
    assert selinux_getpolicytype()[1] in ('targeted', 'mls')

    # FIXME: also check return value of is_selinux_mls_enabled
    assert is_selinux_mls_enabled() in (0, 1)

    assert is_selinux_enabled() in (0, 1)


if __name__ == '__main__':
    # Unit test for function lgetfilecon_raw
    test_lgetfilecon_raw

# Generated at 2022-06-24 21:17:52.291139
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(['root']) == [0, 'root']



# Generated at 2022-06-24 21:17:54.974873
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Expected result:
    Test lgetfilecon_raw function.
    :return:
    """
    var_0 = lgetfilecon_raw(b"/etc/passwd")



# Generated at 2022-06-24 21:17:58.784713
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd')[0] >= 0


# Generated at 2022-06-24 21:18:01.424872
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/')
    print('var_1:', var_1)
    var_2 = lgetfilecon_raw('')
    print('var_2:', var_2)



# Generated at 2022-06-24 21:18:05.312294
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test function with correct parameters
    """
    var_1 = '/tmp/test_ansible_selinux'
    with open(var_1, 'w') as f:
        f.write('')

    rc, con = lgetfilecon_raw(var_1)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'



# Generated at 2022-06-24 21:18:10.515620
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = None
    ret = lgetfilecon_raw(path)
    assert ret[0] == 0
    assert len(ret[1]) > 0


# Generated at 2022-06-24 21:18:13.978564
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('./common_module_utils/selinux.py') == [0, b'unconfined_u:object_r:default_t:s0']


# Generated at 2022-06-24 21:18:15.314319
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/etc/ssh', 0) == [0, 'system_u:object_r:sshd_etc_t:s0']


# Generated at 2022-06-24 21:18:16.390360
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/path/to/file'
    ret_val, err_str = lgetfilecon_raw(path)
    assert ret_val == 0

# Generated at 2022-06-24 21:18:18.590442
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b"/etc/shadow", 2)
    if rc == 0 and con:
        print("context: %s" % con)
    else:
        print("error: %s" % rc)


# Generated at 2022-06-24 21:18:26.257544
# Unit test for function matchpathcon
def test_matchpathcon():
    # call the function with valid parameters
    rc, con = matchpathcon('/etc/hosts', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    rc, con = matchpathcon('/etc/hosts', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # call the function with invalid parameters
    rc, con = matchpathcon('/etc/hosts', 2)
    assert rc == -1
    assert con == 'Error accessing file system information.'


# Generated at 2022-06-24 21:18:33.067621
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:user_tmp_t:s0']
    assert lgetfilecon_raw('/var/tmp') == [0, 'system_u:object_r:tmp_t:s0']
    assert lgetfilecon_raw('/unexisting/path') == [-1, '']



# Generated at 2022-06-24 21:18:37.485094
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test.txt'
    mode = 0
    res = matchpathcon(path, mode)
    print(res)


# Generated at 2022-06-24 21:18:43.433449
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/ansible', 0)
    if rc == 0:
        print("Context: %s" % con)
    else:
        print("Problem.")
        print("rc: %d" % rc)


# Generated at 2022-06-24 21:18:47.977949
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    _selinux_lib.lsetfilecon("/tmp/test", "system_u:object_r:user_tmp_t:s0")
    rc, con = lgetfilecon_raw("/tmp/test")
    assert rc == 0
    assert con == "system_u:object_r:user_tmp_t:s0"

    rc, con = lgetfilecon_raw("/tmp/nonexistentfile")
    assert rc == -1
    assert con is None



# Generated at 2022-06-24 21:18:51.296855
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    e = None
    try:
        lgetfilecon_raw('/tmp')
    except OSError as e:
        pass

    assert e.errno == 22


# Generated at 2022-06-24 21:18:53.813148
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/home/ansible') is not None


# Generated at 2022-06-24 21:19:03.241144
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    src_path = '/path/to/src_file'
    dest_path = '/path/to/dest_file'

    # should pass
    rc = lsetfilecon(src_path, 'system_u:object_r:usr_t:s0')
    assert 0 == rc

    rc, context = lgetfilecon_raw(src_path)
    assert 0 == rc
    assert context == 'system_u:object_r:usr_t:s0'

    rc, context = lgetfilecon_raw(dest_path)
    assert -1 == rc
    assert errno.ENOENT == get_errno()

    rc = lsetfilecon(dest_path, 'system_u:object_r:usr_t:s0')
    assert 0 == rc

    rc, context = lgetfilecon_raw

# Generated at 2022-06-24 21:19:04.227782
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass


# Generated at 2022-06-24 21:19:13.873899
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/"
    # FIXME: this test fails on Fedora 32 but the module works fine, something odd is going on
    # with libsemanage :/
    var_0, var_1 = lgetfilecon_raw(path)
    if var_0 != 0:
        raise RuntimeError("lgetfilecon_raw(%s) returned unexpected rc: %s" % (path, var_0))
    if var_1 != "system_u:object_r:root_t:s0":
        raise RuntimeError("lgetfilecon_raw(%s) returned unexpected context: %s" % (path, var_1))


# Generated at 2022-06-24 21:19:22.618636
# Unit test for function matchpathcon
def test_matchpathcon():

    text = 'Test for function selinux.matchpathcon'
    print(text)

    # Define username
    usrname = 'root'

    # Define path to home directory
    path = '/home/' + usrname

    # Get context of user
    context = matchpathcon(path, 0)[1]

    # Define expected context
    expected = 'unconfined_u:object_r:user_home_dir_t:s0'

    # Define assertion message
    msg = ("Context of {0} is {1} and not {2}").format(path, context, expected)

    # Verify that assertion is true
    assert context == expected, msg


# Generated at 2022-06-24 21:19:26.910181
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # create instance of class
    _thismod = sys.modules[__name__]

    # set up args
    path = _thismod.__file__

    # call function
    assert _thismod.lgetfilecon_raw(path) == [0, 'unlabeled_t']

# Generated at 2022-06-24 21:19:31.456434
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: mock the output of libselinux.matchpathcon and exercise this.

    pass


if __name__ == '__main__':
    print(test_matchpathcon())

# Generated at 2022-06-24 21:19:36.572141
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = (b'/var/log/')

    # FIXME: better test
    rc, con = lgetfilecon_raw(path)

    # FIXME: better test
    return ['rc', 'con']



# Generated at 2022-06-24 21:19:37.568646
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw('/root/')


# Generated at 2022-06-24 21:19:41.758210
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/hosts')
    if rc:
        print('failed to get context for /etc/hosts:', con)
    else:
        print('context for /etc/hosts:', con)

# Generated at 2022-06-24 21:19:48.679384
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    var_0 = lgetfilecon_raw(path)
    assert( var_0[0] == 0 )
    assert( type(var_0[1]) == type('') )
    assert( var_0[1] != '' )


# Generated at 2022-06-24 21:19:51.517078
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/shadow'
    mode = 0
    fn = getattr(_selinux_lib, 'matchpathcon')
    r = fn(path, mode)

# Generated at 2022-06-24 21:19:56.566730
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Testing function lgetfilecon_raw
    con = c_char_p()
    rc, con.value = _selinux_lib.lgetfilecon_raw(b'/etc/passwd', byref(con))
    assert rc == 0
    assert con.value.startswith(b'system_u:object_r:etc_runtime_t')



# Generated at 2022-06-24 21:20:02.304166
# Unit test for function matchpathcon
def test_matchpathcon():

    try:
        rc_0, var_1 = matchpathcon("/usr/sbin/seunshare", 0)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        msg = "Line {}: {}".format(exc_tb.tb_lineno, e)
        raise RuntimeError(msg)
    assert rc_0 == 0
    assert "system_u:object_r:unconfined_exec_t:SystemLow" in var_1


# Generated at 2022-06-24 21:20:03.959427
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert con is not None


# Generated at 2022-06-24 21:20:08.471603
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert sys.stdout == sys.__stdout__
    path = ''
    con = 'SystemHigh'
    result = lgetfilecon_raw(path)

    if result[0] == 0:
        assert result[1] == con


# Generated at 2022-06-24 21:20:20.994979
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Unit test function for the function lgetfilecon_raw
    '''
    path = "/etc/shadow"
    # No need to run test on file that will not be present on most systems and could possibly alert sysadmins
    if os.path.exists(path):
        result = lgetfilecon_raw(path)
        assert isinstance(result, list)
        assert isinstance(result[0], int)
        assert isinstance(result[1], str)
    else:
        assert True



# Generated at 2022-06-24 21:20:30.339775
# Unit test for function matchpathcon
def test_matchpathcon():
    assert selinux_getpolicytype()[1] == 'targeted'
    assert matchpathcon('/etc/shadow', 0)[1] == 'system_u:object_r:shadow_t:s0'
    assert matchpathcon('/etc', 0)[1] == 'system_u:object_r:etc_t:s0'
    assert matchpathcon('/tmp', 0)[1] == 'system_u:object_r:tmp_t:s0'
    assert matchpathcon('/home/foobar', 0)[1] == 'system_u:object_r:user_home_dir_t:s0'

# Generated at 2022-06-24 21:20:31.548821
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw


# Generated at 2022-06-24 21:20:33.488498
# Unit test for function matchpathcon
def test_matchpathcon():
    args = to_bytes("/tmp/test_file")
    args_1 = 0
    assert [0, to_native(b'/tmp/test_file')] == matchpathcon(args, args_1)



# Generated at 2022-06-24 21:20:35.856837
# Unit test for function matchpathcon
def test_matchpathcon():
    expected_result = errno.EINVAL
    actual_result = matchpathcon(None, None)
    assert expected_result == actual_result



# Generated at 2022-06-24 21:20:37.112893
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_2 = lgetfilecon_raw('foobar')



# Generated at 2022-06-24 21:20:41.738247
# Unit test for function matchpathcon
def test_matchpathcon():
    assert True



# Generated at 2022-06-24 21:20:45.881449
# Unit test for function matchpathcon
def test_matchpathcon():
    var_in = "../data/file"
    var_mode = 0
    var_in_1 = os.stat(var_in).st_mode
    (var_out_rc, var_out_con) = matchpathcon(var_in, var_mode)
    assert var_out_rc == 0
    assert var_out_con == 'system_u:object_r:unlabeled_t:s0'



# Generated at 2022-06-24 21:20:49.706385
# Unit test for function matchpathcon
def test_matchpathcon():
    assert to_native(matchpathcon('/usr/bin', 0)) == [0, 'system_u:object_r:usr_t:s0']


# Generated at 2022-06-24 21:20:56.468198
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as d:
        os.mkdir(os.path.join(d, "a"))
        rc, con = matchpathcon(os.path.join(d, "a"), 0)
        assert con == "d" + con.split("d")[1]  # check that the SELinux context has the "d" type.
    return 0


# Generated at 2022-06-24 21:21:06.888399
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "tbd"
    mode = 1
    out = matchpathcon(path, mode)
    print(out)


# Generated at 2022-06-24 21:21:11.880086
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('foo')
    assert var_1 == [0, 'system_u:object_r:admin_home_t:s0']


# Generated at 2022-06-24 21:21:23.640079
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:passwd_file_t:s0']
    assert matchpathcon('/etc/ssh/sshd_config', 0) == [0, 'system_u:object_r:sshd_config_t:s0']
    assert matchpathcon('/home/foo/bar', 0) == [0, 'unlabeled_t']
    assert matchpathcon('/home/foo', 0) == [0, 'user_home_dir_t']
    assert matchpathcon('/home', 0) == [0, 'home_root_t']
    assert matchpathcon('/var/www', 0) == [0, 'httpd_sys_content_t']

    assert matchpathcon('/etc/passwd', 1)

# Generated at 2022-06-24 21:21:28.596471
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path_data = 'foo/bar'
    path = path_data.encode('utf-8')
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_home_t:s0'
    path_data = '/usr/lib/locale/locale-archive'
    path = path_data.encode('utf-8')
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:locale_t:s0'


# Generated at 2022-06-24 21:21:33.042799
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = str()
    expected = (0, '')
    # this will return an error if /proc is not mounted or if selinux is not enabled
    actual = lgetfilecon_raw(path)
    assert actual == expected


# Generated at 2022-06-24 21:21:36.008255
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, out = lgetfilecon_raw('/etc/passwd')
    # assert rc == 0
    # assert out.startswith('system_u:object_r:etc_t:s0')


# Generated at 2022-06-24 21:21:42.688144
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    returncode, output = lgetfilecon_raw('/path/to/file')
    if returncode != 0:
        print(str(output))
        print('Failed to get file context for /path/to/file')
        sys.exit(1)
    print('The file context for /path/to/file is {}'.format(str(output)))
    sys.exit(0)


# Generated at 2022-06-24 21:21:44.848848
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b"this_file_should_not_exist")
    assert rc != 0
    assert not con



# Generated at 2022-06-24 21:21:49.525078
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/var/www/html"
    assert type(lgetfilecon_raw(path)) is list
    assert len(lgetfilecon_raw(path)) == 2
    assert type(lgetfilecon_raw(path)[0]) is int
    assert type(lgetfilecon_raw(path)[1]) is str


# Generated at 2022-06-24 21:21:51.519374
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'

    result = lgetfilecon_raw(path)

    assert result[0] == 0


# Generated at 2022-06-24 21:22:13.441292
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/etc/shadow')
    assert var_1[0] == 0
    assert var_1[1] == 'unconfined_u:object_r:shadow_t:s0'


# Generated at 2022-06-24 21:22:17.590965
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = "/etc/passwd"
    var_1 = lgetfilecon_raw(test_file)
    if var_1[0] == 0:
        print("Success for {} return is {} ".format(test_file,var_1[1]))
    else:
        print("Failed for {} return is {} ".format(test_file,var_1[1]))


# Generated at 2022-06-24 21:22:21.561967
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/selinux/config')
    assert rc == 0
    assert con
    rc, con = lgetfilecon_raw('/etc/selinux')
    assert rc == 0
    assert con
    rc, con = lgetfilecon_raw('/etc/selinux/no_exist')
    assert rc < 0

# Users should define a main() to make this more useful.

# Generated at 2022-06-24 21:22:23.675834
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [
        0,
        'unconfined_u:object_r:user_home_t:s0'
    ]



# Generated at 2022-06-24 21:22:27.109201
# Unit test for function matchpathcon
def test_matchpathcon():

    # setup
    path = None
    mode = None

    # perform
    action = matchpathcon(path, mode)

    # assert
    assert action == [0, "system_u:object_r:samba_share_t:s0"]


# Generated at 2022-06-24 21:22:30.298892
# Unit test for function matchpathcon
def test_matchpathcon():

    var_0 = matchpathcon('/', 0)
    assert var_0[0] == 0
    assert var_0[1] == 'system_u:object_r:rootfs:s0'

    var_1 = matchpathcon('/etc', 32768)  # Dangling sym link
    assert var_1[0] != 0
    assert var_1[1] is None

# Generated at 2022-06-24 21:22:32.596200
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/bin/ping"

    con, rc = lgetfilecon_raw(path)
    print("Context of {0} is {1}".format(path, con))


if __name__ == '__main__':
    test_case_0()
    test_lgetfilecon_raw()

# Generated at 2022-06-24 21:22:35.919622
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Unit test for function lgetfilecon_raw
    """

    # Path from filesystem root.
    path = "/dev/null"
    var_0 = lgetfilecon_raw(path)


# Generated at 2022-06-24 21:22:37.217503
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert callable(lgetfilecon_raw)


# Generated at 2022-06-24 21:22:40.422124
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/root/test', 0) == [0, u'unconfined_u:object_r:user_home_dir_t:s0']


# Generated at 2022-06-24 21:23:18.034857
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: we would need a system with selinux enabled to test this
    pass


# Generated at 2022-06-24 21:23:18.850876
# Unit test for function matchpathcon
def test_matchpathcon():
    assert True == True


# Generated at 2022-06-24 21:23:21.670802
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux/config'
    rc_expected = 0
    rc = lgetfilecon_raw(path)[0]
    assert rc == rc_expected


# Generated at 2022-06-24 21:23:23.144053
# Unit test for function matchpathcon
def test_matchpathcon():
    assert True


# Generated at 2022-06-24 21:23:25.059911
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/')[0] == 0


# Generated at 2022-06-24 21:23:28.018266
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path='/etc/resolv.conf') == [0, 'system_u:object_r:resolv_conf_t:s0']


# Generated at 2022-06-24 21:23:29.817253
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw("root")
    assert(var_0 == 0)

test_case_0()

# Generated at 2022-06-24 21:23:32.499987
# Unit test for function matchpathcon
def test_matchpathcon():
    expected_rc = __salt__['cmd.retcode']('matchpathcon -V', python_shell=True)
    assert matchpathcon(None, None)[0] == expected_rc, 'return value was not the expected value'


# Generated at 2022-06-24 21:23:37.901988
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        path = '/'
        var_0 =lgetfilecon_raw(path)
    except OSError as e:
        print(e)
        return None



# Generated at 2022-06-24 21:23:38.871465
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert True


# Generated at 2022-06-24 21:25:05.377669
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/hosts', 0)
    print(rc)
    print(con)

test_matchpathcon()


# Generated at 2022-06-24 21:25:10.186253
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/usr', 0) == [0, 'system_u:object_r:usr_t:s0']


# Generated at 2022-06-24 21:25:15.218071
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp')
    assert rc == 0, "con={}".format(con)
    rc, con = lgetfilecon_raw('/tmp/non-existing-file')
    assert rc == -1, "con={}, errno={}".format(con, os.strerror(rc))

# Generated at 2022-06-24 21:25:20.442411
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/path/to/file'

    mocked_ctypes = mocker.patch('ansible_collections.ansible.community.general.plugins.module_utils.selinux.ctypes')
    mocked_ctypes.CDLL.return_value.lgetfilecon_raw.return_value = 0

    results = lgetfilecon_raw(path)
    assert results == [0]



# Generated at 2022-06-24 21:25:22.846837
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/test/test', 0) == [0, 'u:object_r:user_tmp_t:s0']

# Generated at 2022-06-24 21:25:27.241932
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
     var_0 = lgetfilecon_raw('/')
     assert var_0[0] == 0
     assert isinstance(var_0[1], str)
     assert var_0[1] == 'system_u:object_r:rootfs:s0' 


# Generated at 2022-06-24 21:25:31.548961
# Unit test for function matchpathcon
def test_matchpathcon():
    src_path = '/var/log/messages'
    mode = 0
    # Testing with an existence path
    assert matchpathcon(src_path, mode) == [0, 'system_u:object_r:var_log_t:s0'], \
        'The return value should be system_u:object_r:var_log_t:s0.'


# Generated at 2022-06-24 21:25:36.933547
# Unit test for function matchpathcon
def test_matchpathcon():
    f_path = ""
    f_mode = 0
    want = []
    got = matchpathcon(f_path, f_mode)
    assert want == got



# Generated at 2022-06-24 21:25:41.769131
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = '/etc/passwd'
    rc, con = lgetfilecon_raw(file)
    assert rc == 0
    assert con == ('system_u:object_r:etc_runtime_t:s0')


# Generated at 2022-06-24 21:25:43.780044
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = '/tmp/selinux.py'
    var_2 = 0
    matchpathcon(var_1, var_2)

