

# Generated at 2022-06-24 21:17:05.234970
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/test')[1] is None


# Generated at 2022-06-24 21:17:15.935351
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    failure_message = ''
    path = "/etc/shadow"
    selinux_enabled = is_selinux_enabled()

    if not selinux_enabled:
        try:
           rc = lgetfilecon_raw(path)
        except OSError as e:
            pass
        else:
            error_message = 'lgetfilecon_raw should fail with EOPNOTSUPP when SELinux not enabled'
            failure_message += '{0}\n'.format(error_message)

    if selinux_enabled:
        try:
            # NB: this is just a simple smoke test, it does not validate context
            # for any specific path.
            rc, con = lgetfilecon_raw(path)
        except OSError as e:
            pass

# Generated at 2022-06-24 21:17:27.259876
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    This is a basic test to ensure that this function
    works as intended in Ansible.

    It first checks if SELinux is enabled. If it
    is, then it gets the context of a specific path
    and validates that it is a non-empty string (since
    we can't know the exact context of a path in advance).

    If SELinux isn't enabled, it simply returns,
    I'm sure it won't work. Seems like the ideal
    case right?
    """
    selinux_enabled = is_selinux_enabled()
    if selinux_enabled:
        var_1 = matchpathcon("/tmp/blah", 0)
        test_var_1 = len(var_1[1]) > 0
        assert test_var_1 == True

# Generated at 2022-06-24 21:17:29.594306
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc')[0] == 0


# Generated at 2022-06-24 21:17:39.902350
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/', 0) == [0, u'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/', 0) == [0, u'system_u:object_r:root_t:s0']
    assert matchpathcon('/trials', 0) == [0, u'system_u:object_r:root_t:s0']
    assert matchpathcon('/etc/shadow', 0) == [0, u'system_u:object_r:shadow_t:s0']
    assert matchpathcon('/etc/shadow', 1) == [0, u'system_u:object_r:shadow_t:s0']

# Generated at 2022-06-24 21:17:45.823063
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Input parameters
    path = '/var/selinux/contexts/files/file_contexts'

    # Output parameters
    rc = 0
    con = None

    # Execute the command
    rc, con = lgetfilecon_raw(path)

    # Verify the results
    assert rc == 0 and con == 'system_u:object_r:file_contexts_t:s0'


# Generated at 2022-06-24 21:17:53.347132
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    with open('/tmp/ansible_selinux_test_file', 'w') as f:
        f.write('Test file')

    try:
        result = lgetfilecon_raw('/tmp/ansible_selinux_test_file')
        os.remove('/tmp/ansible_selinux_test_file')
    except Exception as exception:
        os.remove('/tmp/ansible_selinux_test_file')
        raise exception



# Generated at 2022-06-24 21:17:55.233163
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/users/home/test"
    assert lgetfilecon_raw(path)[0] == -4


# Generated at 2022-06-24 21:17:59.203361
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw(b'/tmp/foo')
    if var_1[0] != 0:
        raise AssertionError(var_1[0])
    if not isinstance(var_1[1], str):
        raise AssertionError(var_1[1])


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-24 21:18:02.388271
# Unit test for function matchpathcon
def test_matchpathcon():
    # con = c_char_p()
    # path = "/etc/passwd"
    # mode = 0o600
    # rc = matchpathcon(path, mode, byref(con))
    # print(rc, to_native(con.value))
    test_case_0()

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-24 21:18:10.645675
# Unit test for function matchpathcon
def test_matchpathcon():
    # Tests run against selinux/selinux-testsuite
    assert matchpathcon('/var/lib/libvirt/qemu', 0)[1] == 'system_u:object_r:svirt_image_t:s0'
    assert matchpathcon('/var/lib/libvirt/qemu/test-domain', 0)[1] == 'system_u:object_r:svirt_qemu_net_t:s0'
    assert matchpathcon('/home/testuser/new-image', 0)[1] == 'system_u:object_r:user_home_t:s0'



# Generated at 2022-06-24 21:18:14.366061
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    arg_0 = '/path/to/file'
    assert lgetfilecon_raw(arg_0) == 0

if __name__ == '__main__':
    test_case_0()
    test_lgetfilecon_raw()

# Generated at 2022-06-24 21:18:15.624242
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/var/tmp'
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-24 21:18:16.173788
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO: implement
    assert False


# Generated at 2022-06-24 21:18:17.376925
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert isinstance(lgetfilecon_raw("/etc/passwd"), "list")



# Generated at 2022-06-24 21:18:19.860594
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = 'data_in'
    _rc, filecon = lgetfilecon_raw(path)


# Generated at 2022-06-24 21:18:22.503410
# Unit test for function matchpathcon
def test_matchpathcon():
    path = ''
    mode = 0
    ret = matchpathcon(path, mode)
    print(ret)



# Generated at 2022-06-24 21:18:23.851368
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('') == [0, None]


# Generated at 2022-06-24 21:18:31.439231
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path='') == [0, '?']
    assert lgetfilecon_raw(path='/etc/resolv.conf') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw(path='/non-existent') == [2, '?']


# Generated at 2022-06-24 21:18:34.882974
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc = lgetfilecon_raw('/etc/services')
    assert rc[0] == 0


# Generated at 2022-06-24 21:18:42.785701
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon(
        'a path',
         2
    ))
    print(matchpathcon(
        'another path',
         2
    ))


# Generated at 2022-06-24 21:18:47.811080
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    current_file_path = __file__
    current_file_temp_con = 'system_u:object_r:selinux_python_t:s0'
    current_file_con = lgetfilecon_raw(current_file_path)[1]
    assert current_file_con == current_file_temp_con, 'current file con is not expected'



# Generated at 2022-06-24 21:18:51.093282
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/tmp"
    mode = 0
    out = matchpathcon(path, mode)
    assert out[1] == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-24 21:18:56.359418
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'test_path'
    mode = 1
    try:
        rc, con = matchpathcon(path, mode)
    except Exception:
        rc = 1
        con = None

    assert rc >= 0
    assert con is not None
    assert isinstance(con, str)


# Generated at 2022-06-24 21:19:01.086403
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = './waf-functions/tests/testfile'
    result = lgetfilecon_raw(file_path)
    if (result[0] == -1):
        raise AssertionError("[Error]: %d %s", errno, strerror(errno))
    else:
        print(result[1])
        return 0


# Generated at 2022-06-24 21:19:02.881742
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = ''
    var_0 = lgetfilecon_raw(path)


# Generated at 2022-06-24 21:19:05.964851
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/doesnotexist"
    mode = os.R_OK
    result = matchpathcon(path, mode)
    assert result[0] == -1


# Generated at 2022-06-24 21:19:15.401853
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    try:
        import selinux
        selinux.is_selinux_enabled()
    except (ImportError, OSError):
        raise unittest.SkipTest('selinux not available on this system')
    rc, con = matchpathcon('/tmp', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'
    # path not found
    rc, con = matchpathcon('/tmp/does-not-exist', os.R_OK)
    assert rc != 0
    assert con is None
    # bad mode
    rc, con = matchpathcon('/tmp', os.O_RDWR)
    assert rc != 0

# Generated at 2022-06-24 21:19:20.203181
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b"/etc/passwd"
    mode = int(to_native(0))
    con = c_char_p()
    try:
        rc = _selinux_lib.matchpathcon(path, mode, byref(con))
        assert rc == int(to_native(0))
        assert to_native(con.value) == b"unconfined_u:object_r:etc_t:s0:c0.c1023"
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-24 21:19:26.184103
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/home/test1/file1.txt"
    rc,con = lgetfilecon_raw(path)
    if rc != 0:
        print("error in getting the context of the file %s" %path)
    else:
        print("Context of the file %s is %s" %(path, con))
        

# Generated at 2022-06-24 21:19:38.447972
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/', 0)
    assert rc == 0, "return code should be 0"
    assert "unconfined_u:object_r:user_home_dir_t:s0" in con, "policy type seems wrong"



# Generated at 2022-06-24 21:19:45.809400
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # unit test for function lgetfilecon_raw
    # Test file permissions of /usr/bin/python
    f = "/usr/bin/python"
    if os.path.isfile(f):
        var_1 = lgetfilecon_raw(f)

# Generated at 2022-06-24 21:19:47.752833
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon("test", 0)
    assert (res[0] == 0)


# Generated at 2022-06-24 21:19:50.567670
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/tmp") == [0, 'unconfined_u:object_r:tmp_t:s0']


# Generated at 2022-06-24 21:19:53.891130
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc = lgetfilecon_raw('/path/to/file')


# Generated at 2022-06-24 21:19:56.490535
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = 'abcd'
    var_1 = 1
    var_2 = lgetfilecon_raw(var_0)
    assert var_1 == var_2[0]


# Generated at 2022-06-24 21:19:59.504778
# Unit test for function matchpathcon
def test_matchpathcon():
    expected = [0, "system_u:object_r:bin_t:s0"]
    actual = matchpathcon("/bin/false", 0)

    assert(expected == actual)


# Generated at 2022-06-24 21:20:03.084940
# Unit test for function matchpathcon
def test_matchpathcon():
    test_input = "/usr/bin/false"
    test_mode = 0
    expected_output = 0

    assert matchpathcon(test_input, test_mode) == expected_output

# Generated at 2022-06-24 21:20:07.407894
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret, out, err = module.run_command("touch /tmp/ansible_test")

    path = "/tmp/ansible_test"
    to_native(path)

    ret1, out1, err1 = module.run_command("chcon -t user_home_t /tmp/ansible_test")
    con = lgetfilecon_raw(path)[1]
    if con == "system_u:object_r:user_home_t:s0":
        rc = True
    else:
        rc = False

    assert rc



# Generated at 2022-06-24 21:20:10.620279
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/path/to/file"
    mode = 0
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    print(rc, to_native(con.value))

# Generated at 2022-06-24 21:20:32.298059
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    mock_path = '/var/lib/test'

    def fake_lgetfilecon(path, con):
        if path == mock_path:
            if con:
                con.contents = b'blah'
            errno = 0
        else:
            errno = 1
        return errno

    _selinux_lib.lgetfilecon.restype = _selinux_lib.errno_t
    _selinux_lib.lgetfilecon.argtypes = [c_char_p, POINTER(c_char_p)]
    _selinux_lib.lgetfilecon.errcheck = fake_lgetfilecon

    var_0 = lgetfilecon_raw(mock_path)
    var_1 = lgetfilecon_raw('/var/lib/nope')


#

# Generated at 2022-06-24 21:20:32.955071
# Unit test for function matchpathcon
def test_matchpathcon():
    assert False


# Generated at 2022-06-24 21:20:34.711523
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(
        b'/etc/ansible/ansible.cfg',
        0o600)

    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-24 21:20:37.724661
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/hosts"
    con_spec_0 = lgetfilecon_raw(path)
    assert(con_spec_0 == [0, 'system_u:object_r:etc_t:s0'])



# Generated at 2022-06-24 21:20:47.414375
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == (0, u'system_u:object_r:usr_t:s0')
    assert matchpathcon('/', 1) == (0, u'unconfined_u:object_r:file_t:s0')
    assert matchpathcon('/', 2) == (0, u'unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023')
    assert matchpathcon('/', 3) == (0, u'unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023')
    assert matchpathcon('/', 4) == (0, u'system_u:object_r:usr_t:s0')
    assert matchpathcon

# Generated at 2022-06-24 21:20:53.810397
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/example.txt'
    mode = 0

    # assign return value to a list to avoid comparison failures with ctypes.
    result = matchpathcon(path, mode)
    assert type(result) == list
    assert len(result) == 2
    assert type(result[0]) == int
    assert result[0] == 0
    assert type(result[1]) == str


# Generated at 2022-06-24 21:20:55.741454
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b"/") == [0, 'system_u:object_r:root_t:s0']


# Generated at 2022-06-24 21:20:59.243018
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b"/etc/selinux/config"
    var_1 = lgetfilecon_raw(path)
    assert var_1 == [0, b"system_u:object_r:etc_t:s0"] or var_1 == [0, b"system_u:object_r:etc_t"]


# Generated at 2022-06-24 21:21:02.350074
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b"/tmp/foo", 0) == 0, "matchpathcon failed"



# Generated at 2022-06-24 21:21:06.450360
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/shadow"
    mode = 0
    # FIXME: eventually swap out to selinux_lgetfilecon_raw
    # context_raw = _selinux_lib.lgetfilecon_raw(path, c_char_p())
    context_raw = c_char_p()

    rc = _selinux_lib.matchpathcon(path, mode, byref(context_raw))
    print("%s: %s" % (rc, to_native(context_raw.value)))



# Generated at 2022-06-24 21:21:42.465557
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert lgetfilecon_raw('/etc') == [0, 'system_u:object_r:etc_t:s0']
        mode = 0
        assert matchpathcon('/etc', mode) == [0, 'system_u:object_r:etc_t:s0']
    except ImportError as ire:
        raise AssertionError(str(ire))



# Generated at 2022-06-24 21:21:50.587092
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/shadow', 0) == [0, 'unconfined_u:object_r:shadow_t:s0']

    assert matchpathcon('/etc/shadow', 0000) == [0, 'unconfined_u:object_r:shadow_t:s0']

# Generated at 2022-06-24 21:21:52.938769
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('test', 1) == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:21:55.046498
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Unit test for selinux.matchpathcon')
    var_0 = matchpathcon('/etc/hosts', matchpathcon.mode.FOLLOW)

# Generated at 2022-06-24 21:21:56.889828
# Unit test for function matchpathcon
def test_matchpathcon():
    pass

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-24 21:22:00.810290
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/xinetd.d/telnet', False) == [0, 'system_u:object_r:telnetd_exec_t:s0']



# Generated at 2022-06-24 21:22:04.371708
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: use a temp file and directory
    # FIXME: create an assertRaises with a list of expected exceptions
    rc, con = matchpathcon('/etc/localtime', 0)
    assert rc in [0, -1]

# Generated at 2022-06-24 21:22:07.505437
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/usr/bin/python2.7")
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_home_t:s0'



# Generated at 2022-06-24 21:22:13.478474
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/var/log/messages'

    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:var_log_t:s0'



# Generated at 2022-06-24 21:22:15.397853
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('var_0', 0) == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:23:28.126274
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This function is just an alias
    var_0 = lgetfilecon_raw("/tmp")


# Generated at 2022-06-24 21:23:29.194540
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
   var_1 = lgetfilecon_raw('/etc/shadow')


# Generated at 2022-06-24 21:23:33.159628
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path_0 = b'/selinux/testfile'

    # run the function
    var_0 = lgetfilecon_raw(path_0)


# Generated at 2022-06-24 21:23:36.187597
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = '/home/vagrant/conftest.py'
    var_1 = 0
    var_2 = matchpathcon(var_0, var_1)
    assert var_2[0] == 0


# Generated at 2022-06-24 21:23:40.029792
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/some/path/some_file'
    ansible_return = lgetfilecon_raw(path)
    assert ansible_return[0] == 0
    assert ansible_return[1] == 'system_u:object_r:admin_home_t:s0'


# Generated at 2022-06-24 21:23:42.022912
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # TODO: add test for lgetfilecon_raw
    assert False, "No test for lgetfilecon_raw"


# Generated at 2022-06-24 21:23:43.601662
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path='') == [0, '']


# Generated at 2022-06-24 21:23:45.490478
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/var/log/test.log', 0)

# Generated at 2022-06-24 21:23:48.636329
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Actually, this is a tri-state...
    assert lgetfilecon_raw('/etc/passwd')[0] in [0, 1, 2]



# Generated at 2022-06-24 21:23:53.712482
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/shadow'
    assert lgetfilecon_raw(path) == [0, 'system_u:object_r:shadow_t:s0']


# Generated at 2022-06-24 21:26:39.847405
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, value = matchpathcon('/tmp/foo', 0o644)
    assert rc == 0


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-24 21:26:41.163446
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass


# Generated at 2022-06-24 21:26:49.305752
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/tmp/foo"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:user_tmp_t:s0"
    path = "/var/tmp/foo"
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:user_tmp_t:s0"
    path = "/var/tmp/foo"
    mode = 2
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:user_tmp_t:s0"


# Generated at 2022-06-24 21:26:55.556919
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/"
    var_1 = lgetfilecon_raw(path)
    var_2 = var_1[0]
    var_3 = var_1[1]


# Generated at 2022-06-24 21:27:02.752925
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Failure case (zero return code)
    path = '/etc/hosts'
    # rc,con = lgetfilecon_raw(path)
    # assert rc == 0
    # assert con == 'system_u:object_r:net_conf_t:s0'

    # Negative case (non-zero return code)
    path = '/foo/bar/gibberish'
    # rc,con = lgetfilecon_raw(path)
    # assert rc > 0
    # assert con is None

    # Test passing unicode strings
    u_path = '\u03b2'
    # rc,con = lgetfilecon_raw(u_path)
    # assert rc > 0

