

# Generated at 2022-06-24 21:17:07.385269
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/lib/foo.txt"
    mode = 0
    data = matchpathcon(path, mode)
    assert(data[0] == -1)



# Generated at 2022-06-24 21:17:08.032021
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/',0)


# Generated at 2022-06-24 21:17:15.041818
# Unit test for function matchpathcon
def test_matchpathcon():
    print("""
    Since this is a new module, this test case is not yet written.
    The objective of this unit test script is to confirm that the
    code meets requirements related to callable functions.
    The module will be tested more thoroughly in integration tests.
    """)
    pass


# Generated at 2022-06-24 21:17:18.040933
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # TODO: Add proper asserts
    assert lgetfilecon_raw("/dev/null") is not None


# Generated at 2022-06-24 21:17:21.678113
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass


# Generated at 2022-06-24 21:17:24.999333
# Unit test for function matchpathcon
def test_matchpathcon():
    
    # var_1 = matchpathcon('test_value_1', 'test_value_2')
    # assert var_1 == 'test_value'
    pass # noqa: F821


# Generated at 2022-06-24 21:17:28.747601
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/usr/bin/python', 1)
    assert isinstance(result, list)
    assert result[0] == 0
    assert isinstance(result[1], str)
    assert result[1] == 'system_u:object_r:bin_t:s0'


# Generated at 2022-06-24 21:17:30.177540
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/ls')


# Generated at 2022-06-24 21:17:32.452323
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/lib64')
    assert lgetfilecon_raw(None, [1]) == -22


# Generated at 2022-06-24 21:17:35.008356
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw('/')
    assert var_0[0] == 0
    assert var_0[1] != b''


# Generated at 2022-06-24 21:17:40.556982
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "dummy"
    mode = 0

    out, err = capsys.readouterr()
    var_0 = matchpathcon(path, mode)
    assert out == selinux_getpolicytype()[1]


# Generated at 2022-06-24 21:17:44.801644
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    res = matchpathcon(path, mode)
    expected_result = [0, 'system_u:object_r:passwd_file_t']
    assert(res == expected_result)


# Generated at 2022-06-24 21:17:46.740786
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('test') == [0, 'system_u:object_r:usr_t:s0']



# Generated at 2022-06-24 21:17:47.999806
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("testval", os.R_OK) == 0


# Generated at 2022-06-24 21:17:58.183534
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test case to check lgetfilecon_raw

    :setup:
        Create a temporary file

    :steps:
        # (1)
        Run the function with a path that does not exist
        # (2)
        Run the function with a path that does exist

    :expectedresults:
        1. Function returns 0 and the context is 'unlabeled'
        2. Function returns 0 and the context is 'system_u:object_r:unlabeled_t:s0' or 'system_u:object_r:root_t:s0'

    :CaseImportance: Critical
    """
    path = None

# Generated at 2022-06-24 21:18:00.579058
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'unconfined_u:object_r:user_home_t:s0'


# Generated at 2022-06-24 21:18:03.994022
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: This test case needs to be properly fixed as per C test case
    # Ensure that the following call to lgetfilecon_raw does not fail
    #rc = ctypes.c_int.in_dll(_selinux_lib, 'errno')
    #assert rc.value == 0
    #self.assertEqual(rc.value, 0)
    return


# Generated at 2022-06-24 21:18:05.917053
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = None
    rc, con = lgetfilecon_raw(path)
    assert rc == -1


# Generated at 2022-06-24 21:18:07.436578
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'path/to/file'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0


# Generated at 2022-06-24 21:18:10.269166
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = u'/etc/passwd'
    (rc, con) = lgetfilecon_raw(path)
    assert rc == 0
    assert isinstance(con, type(u'')), "Expected type is string"
    assert con != u''
    assert con.startswith(u'system_u:object_r:etc_t:s0 ')



# Generated at 2022-06-24 21:18:15.646375
# Unit test for function lgetfilecon_raw

# Generated at 2022-06-24 21:18:16.590407
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/test')[0] >= 0


# Generated at 2022-06-24 21:18:27.544348
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    with patch('ansible_collections.ansible.posix.plugins.module_utils.selinux.selinux_getenforcemode', return_value=(0, 'Permissive')):
        with patch('ansible_collections.ansible.posix.plugins.module_utils.selinux._selinux_lib.lgetfilecon_raw', return_value=(0, 'unconfined_u:object_r:user_home_t:s0')):
            with patch('ansible_collections.ansible.posix.plugins.module_utils.selinux._selinux_lib.freecon', return_value=None):
                # Call tested function
                response = lgetfilecon_raw('/home/ansible')

# Generated at 2022-06-24 21:18:28.567405
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path, mode)


# Generated at 2022-06-24 21:18:31.758054
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: write test for lgetfilecon_raw
    assert False


# Generated at 2022-06-24 21:18:33.135480
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/testfile')[0] == 0


# Generated at 2022-06-24 21:18:36.721972
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = 'test/test_file_t'
    con = lgetfilecon_raw(path)[1]
    assert con.startswith('system_u:object_r:test_file_t:s0')


# Generated at 2022-06-24 21:18:43.172742
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = '/usr/sbin/semodule'
    var_1 = 1
    matchpathcon(var_0, var_1)


# Generated at 2022-06-24 21:18:46.814643
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert matchpathcon('/tmp/myfile', 0) == [0, 'system_u:object_r:tmp_t:s0']
    except OSError as exception:
        if exception.errno in (1, 13):
            pass
        else:
            raise

    return True



# Generated at 2022-06-24 21:18:52.845947
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw(path='/etc/passwd')
    var_1 = lgetfilecon_raw(path='/etc/passwd')
    var_2 = lgetfilecon_raw(path='/etc/passwd')
    var_3 = lgetfilecon_raw(path='/etc/passwd')


# Generated at 2022-06-24 21:19:02.843782
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path_0 = '/tmp/test-path-con'
    var_0 = lgetfilecon_raw(path_0)
    assert var_0[0] == 0
    # TODO: make this test do something useful


# Generated at 2022-06-24 21:19:07.600037
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path="/etc/shadow"
    test_mode=0
    retval = matchpathcon(test_path, test_mode)
    assert retval[0] == 0, "Failed to get context of '%s', Error %s" % (test_path, retval[0])


# Generated at 2022-06-24 21:19:11.541350
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/proc/loadavg'
    con_list = lgetfilecon_raw(path)
    if grep_from_list(con_list, 'avg_t'):
        print("lgetfilecon_raw() works")
    else:
        print("lgetfilecon_raw() does not work")


# Generated at 2022-06-24 21:19:18.528903
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    res = matchpathcon(path, mode)
    assert [res[0], res[1]] == [0, 'system_u:object_r:passwd_file_t:s0']


# Generated at 2022-06-24 21:19:26.007244
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    expected_rc = 0
    expected_con = b"system_u:object_r:passwd_etc_t"
    rc, con = matchpathcon(path, mode)
    assert rc == expected_rc
    assert con == expected_con


# Generated at 2022-06-24 21:19:28.745389
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    if rc != 0:
        raise ImportError('unable to load libselinux.so')


# Generated at 2022-06-24 21:19:32.538602
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'test_path'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con is not None

# Generated at 2022-06-24 21:19:37.570047
# Unit test for function matchpathcon
def test_matchpathcon():
    # Change the path to an existing path
    result = matchpathcon('/etc/passwd', 0)
    assert result[0] == -1
    assert 'libselinux.matchpathcon' in result[1]


# Generated at 2022-06-24 21:19:41.652506
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print("test_lgetfilecon_raw")
    assert lgetfilecon_raw("/etc/passwd") == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-24 21:19:48.294964
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'path/to/a/file'
    mode = 0

    assert matchpathcon(path, mode) == [0, 'unconfined_u:object_r:user_home_dir_t:s0']



# Generated at 2022-06-24 21:20:04.328659
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/var/log/audit', 0)[0] == 0
    assert matchpathcon(b'/dev/shm', 0)[0] == -1



# Generated at 2022-06-24 21:20:08.461093
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/home/doug/file.txt"
    mode = 0
    assert matchpathcon(path, mode) == [0, "user_u:object_r:user_home_t:s0"]


# Generated at 2022-06-24 21:20:09.384384
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 1 == 1


# Generated at 2022-06-24 21:20:10.811766
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 0 == matchpathcon(path='/home/foo/bar', mode=0)[0]


# Generated at 2022-06-24 21:20:13.019549
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/home/testuser") == [0, 'user_u:object_r:user_home_t:s0']


# Generated at 2022-06-24 21:20:16.553552
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('./ansible_test.py')[0] == 0


# Generated at 2022-06-24 21:20:16.958827
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert True



# Generated at 2022-06-24 21:20:20.600106
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0

    # FIXME: this raises an exception if selinux isn't enabled
    rc, rval = matchpathcon(path, mode)

    print('rc: %s' % rc)
    print('rval: %s' % rval)


if __name__ == '__main__':
    test_case_0()
    test_matchpathcon()

# Generated at 2022-06-24 21:20:21.924050
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/foo'
    mode = 1
    rc = matchpathcon(path, mode)
    print(rc)


# Generated at 2022-06-24 21:20:23.105479
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    res = lgetfilecon_raw(path)
    assert res[0] == 0

# Generated at 2022-06-24 21:20:58.816534
# Unit test for function matchpathcon
def test_matchpathcon():
    # Creating a file for test
    open('selinux/test_file.txt', 'a').close()
    # Calling the function
    var_0 = matchpathcon('selinux/test_file.txt', 1)
    # Deleting the file
    os.remove('selinux/test_file.txt')
    # Checking the output
    assert var_0[1] == 'system_u:object_r:default_t'

__all__ = (
    "selinux_getenforcemode",
    "selinux_getpolicytype",
    "lgetfilecon_raw",
    "matchpathcon",
)

# Generated at 2022-06-24 21:21:01.572788
# Unit test for function matchpathcon
def test_matchpathcon():
    print('This function is a stub for unit test matchpathcon')


# Generated at 2022-06-24 21:21:03.087566
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/ansible')[0] == 0


# Generated at 2022-06-24 21:21:05.866930
# Unit test for function matchpathcon
def test_matchpathcon():
    path="test_file"
    mode=0
    assert matchpathcon(path, mode)[0] == 0


# Generated at 2022-06-24 21:21:13.164862
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/bin/bash'     # Path to test if it has SELinux context label
    path_label = lgetfilecon_raw(test_path)
    context_label = path_label[1]
    if context_label is None:
        print('%s is not labeled' % test_path)
    else:
        print('%s is labeled as \"%s\"' % (test_path, context_label))



# Generated at 2022-06-24 21:21:24.632892
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    path = os.path.join(tempfile.gettempdir(), 'ansible.test.file')
    fd, path = tempfile.mkstemp(prefix='ansible.test.file', dir=tempfile.gettempdir())
    os.close(fd)

# Generated at 2022-06-24 21:21:29.913147
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/home/foo/bar/baz', 0) == [
        0,
        'user_home_dir_t:object_r:user_home_dir_t:s0'
    ], 'should return [0, \'user_home_dir_t:object_r:user_home_dir_t:s0\']'



# Generated at 2022-06-24 21:21:34.992963
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    with pytest.raises(TypeError):
        lgetfilecon_raw(path=1234)



# Generated at 2022-06-24 21:21:36.896259
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw(__file__)
    assert ret[0] == 0, "ret[0] should be zero"
    assert ret[1] == "unconfined_u:object_r:ansible_role_t:s0"
    print(ret)


# Generated at 2022-06-24 21:21:41.049279
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Testing selinux.matchpathcon()')
    var_0 = matchpathcon('/test', 0)
    print('var_0 = {0}'.format(var_0))


# Generated at 2022-06-24 21:22:44.719162
# Unit test for function matchpathcon
def test_matchpathcon():
    arg_0 = '/bin/ls'
    arg_1 = 0
    ret = matchpathcon(arg_0, arg_1)
    assert ret == [0, 'system_u:object_r:file_t:s0']



# Generated at 2022-06-24 21:22:49.003996
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/test.conf'
    mode = 0
    out = matchpathcon(path, mode)
    assert out[0] == 0
    assert out[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-24 21:22:52.681019
# Unit test for function matchpathcon
def test_matchpathcon():

    args = ["/home/ansible/data/foo.txt", 1]
    out = matchpathcon(args[0], args[1])
    pattern = "([0-9]+)"
    assert re.search(pattern, out[1])


# Generated at 2022-06-24 21:22:57.525765
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    # path = "ansible/module_utils/selinux.py"
    mode = 0

    (rc, con) = matchpathcon(path, mode)

    assert rc >= 0
    assert con == 'user_home_dir_t'


# Generated at 2022-06-24 21:22:59.301590
# Unit test for function matchpathcon
def test_matchpathcon():
    # No error handling is required
    assert matchpathcon('/etc/hosts', 0) is not None


# Generated at 2022-06-24 21:23:00.054541
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass


# Generated at 2022-06-24 21:23:06.158654
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test lgetfilecon_raw
    """
    # ensure selinux support is available and enabled
    assert is_selinux_enabled() == 1
    rc, con = lgetfilecon_raw("/")
    assert rc == 0
    assert len(con) > 0



# Generated at 2022-06-24 21:23:09.883433
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = ''
    out = lgetfilecon_raw(path)
    assert type(out) == list
    assert len(out) == 2
    assert out[0] == -1
    assert out[1] is None


# Generated at 2022-06-24 21:23:12.859984
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 0 == lgetfilecon_raw('./file_for_testing.txt')[0]
    assert 0 == lgetfilecon_raw('./unittest_direct_file.txt')[0]


# Generated at 2022-06-24 21:23:21.242311
# Unit test for function matchpathcon
def test_matchpathcon():
    paths = [
        (os.path.join(os.getcwd(), "file.txt"), selinux.SELINUX_ANDROID_RESTORECON_DATADATA),
        (os.path.join(os.getcwd(), "file.txt"), selinux.SELINUX_ANDROID_RESTORECON_FORCE),
    ]
    for path, mode in paths:
        rc, con = selinux.matchpathcon(path, mode)
        if rc < 0:
            print("Unable to get context for %s, rc=%d" % (path, rc), file=sys.stderr)
        else:
            print("Context for %s: %s, rc=%d" % (path, con, rc))


# Generated at 2022-06-24 21:25:55.942488
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, value = matchpathcon('/test/file', 0)
    assert rc == 0
    assert value.startswith('system_u:object_r:usr_t')


# Generated at 2022-06-24 21:26:00.105401
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    for path in ['/etc/fstab', '/etc/exports', '/etc/passwd', '/etc/crontab']:

        # test all different permission modes
        for mode in [0, 1, 2]:
            rc, con = lgetfilecon_raw(path)



# Generated at 2022-06-24 21:26:04.227281
# Unit test for function matchpathcon
def test_matchpathcon():
    assert False, "Test matchpathcon: unimplemented"


# Generated at 2022-06-24 21:26:08.761836
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/var/www/vhosts/example.com/httpdocs/index.html'
    expected = 0, 'system_u:object_r:httpd_sys_content_t:s0'  # noqa
    actual = lgetfilecon_raw(path)
    assert actual == expected



# Generated at 2022-06-24 21:26:17.300757
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # Get the file context for a file.
    path = '/usr/bin/python'
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))

    print("File context for {0}: {1}".format(path, con.value))
    _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:26:20.218332
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/sudoers"
    mode = 3

    assert matchpathcon(path, mode) == [0, 'unconfined_u:object_r:etc_t:s0']



# Generated at 2022-06-24 21:26:25.880807
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/selinux/booleans/allow_ftpd_full_access"
    assert os.path.exists(path)
    assert _selinux_lib.lgetfilecon_raw(path, 0).value == 0


# Generated at 2022-06-24 21:26:27.148362
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/path') == 0


# Generated at 2022-06-24 21:26:30.989295
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/ssh/sshd_config"
    mode = 0
    expected = 0
    actual = matchpathcon(path, mode)[0]

# Generated at 2022-06-24 21:26:36.386887
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fptr = open('temp', 'w+')
    path = 'temp'
    assert os.path.isfile(path)
    fptr.close()
    assert lgetfilecon_raw(path)[0] != -1
    os.remove(path)
