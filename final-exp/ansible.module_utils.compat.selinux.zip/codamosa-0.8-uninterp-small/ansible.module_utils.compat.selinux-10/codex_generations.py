

# Generated at 2022-06-24 21:17:14.187835
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/hosts"
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-24 21:17:17.514889
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert os.path.isdir('testdir')
    except OSError:
        os.mkdir('testdir')
    rc, con = matchpathcon('testdir', 0)



# Generated at 2022-06-24 21:17:23.649456
# Unit test for function matchpathcon
def test_matchpathcon():
    # input
    path = '/home/test'
    mode = 0
    con = matchpathcon(path, mode)
    assert con[0] == 0
    assert con[1] == 'system_u:object_r:user_home_t:s0'


# Generated at 2022-06-24 21:17:27.297586
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test case for function lgetfilecon_raw
    """
    var_1 = lgetfilecon_raw('/etc/passwd')
    assert var_1[0] == 0
    assert isinstance(var_1[1], str)


# Generated at 2022-06-24 21:17:29.059631
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert isinstance(lgetfilecon_raw('/tmp'), list)


# Generated at 2022-06-24 21:17:34.852835
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = 'test/data/test.conf'
    result = lgetfilecon_raw(path)

    try:
        assert result[0] == 0
        assert result[1] == 'system_u:object_r:etc_t:s0'
    except AssertionError as ae:
        print(ae)
        print('Test Failed - lgetfilecon_raw')
        sys.exit(1)


# Generated at 2022-06-24 21:17:36.764306
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/usr/bin/python')
    return var_1


# Generated at 2022-06-24 21:17:39.982054
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/', 0)
    assert rc == 0
    assert con.startswith('unconfined_u:object_r:user_home_t')



# Generated at 2022-06-24 21:17:40.944443
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp')[0] == 0

# Generated at 2022-06-24 21:17:48.535732
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: this test is incomplete and shows how selinux_errno can be used to get more details
    # NB: the returned tuple (rc, value) is arbitrary, and may actually be less useful for most
    # consumers.  It should be reviewed with a view to returning similar value as other functions
    # (possibly (rc, None, errno))
    rc, value = matchpathcon(b'/path/to/file', 0)
    assert rc in range(-1, 4)
    if value:
        assert isinstance(value, str)
        assert value[0] != ':'
    else:
        assert rc < 0



# Generated at 2022-06-24 21:17:57.532685
# Unit test for function matchpathcon
def test_matchpathcon():
    test_file = "/etc/selinux/config"
    mode = 0
    wanted_context = "user_u:object_r:etc_t:s0"
    context, rc = matchpathcon(test_file, mode)
    if rc != 0:
        raise Exception("Could not get context for path %s" % test_file)
    if context != wanted_context:
        raise Exception("Got wrong context for path %s: %s" % (test_file, context))


# Generated at 2022-06-24 21:18:04.592953
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    os.chmod('/tmp/test_get/test_file', 0o666)
    os.chmod('/tmp/test_get/test_link_file', 0o666)

    res, mode = lgetfilecon_raw('/tmp/test_get/test_file')
    assert res == 0

    res, mode = lgetfilecon_raw('/tmp/test_get/test_link_file')
    assert res == 0

    res, mode = lgetfilecon_raw('/tmp/test_get/test_folder')
    assert res == -1
    assert res == -errno.EISDIR

    res, mode = lgetfilecon_raw('/tmp/test_get/test_link_folder')
    assert res == -1
    assert res == -errno.EISDIR

    # When

# Generated at 2022-06-24 21:18:11.228314
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/foo'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con == 'system_u:object_r:user_home_t:s0'.encode('utf-8')



# Generated at 2022-06-24 21:18:18.805966
# Unit test for function matchpathcon
def test_matchpathcon():
    assert os.path.exists(MATCHPATHCON_TEST_FILE)

    con = matchpathcon(MATCHPATHCON_TEST_FILE, os.R_OK)[1]
    assert con == 'system_u:object_r:default_t:s0', "expected default_t, got '%s'" % con

    context = 'system_u:object_r:default_t:s0'
    rc = lsetfilecon(MATCHPATHCON_TEST_FILE, context)[0]
    assert rc == 0, "expected return value 0, got %d" % rc
    con = lgetfilecon_raw(MATCHPATHCON_TEST_FILE)[1]
    assert con == 'system_u:object_r:default_t:s0', 'expected default_t, got %s' % con

   

# Generated at 2022-06-24 21:18:27.051084
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    rc, result = lgetfilecon_raw('/etc/resolv.conf')

    # Success
    assert [rc, result] == [0, 'system_u:object_r:etc_t:s0']
    # Invalid path
    rc, result = lgetfilecon_raw('/a/nonexistent/file')
    assert [rc, result] == [-1, 'Failed to get context of /a/nonexistent/file: Invalid argument']
    # Not a file
    rc, result = lgetfilecon_raw('/')
    assert [rc, result] == [-1, 'Failed to get context of /: Not a directory']



# Generated at 2022-06-24 21:18:28.860851
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') != ['', '']


# Generated at 2022-06-24 21:18:38.804591
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test lgetfilecon_raw"""
    # FIXME: remove explicit test_case_0 and use a pytest fixture instead
    test_case_0()

    assert lgetfilecon_raw(b'/etc/passwd') == [0, b'unconfined_u:object_r:user_home_t:s0']
    assert lgetfilecon_raw(b'/does_not_exist') == [-1, None]
    assert lgetfilecon_raw(b'/etc/selinux') == [0, b'unconfined_u:object_r:selinux_etc_t:s0']
    assert lgetfilecon_raw(b'/var') == [0, b'unconfined_u:object_r:var_t:s0']

# Generated at 2022-06-24 21:18:44.601347
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/usr/sbin/se"
    mode = 0
    var_1 = matchpathcon(path, mode)
    assert(var_1[0] == var_1[1] == "system_u:object_r:bin_t:s0")


# Generated at 2022-06-24 21:18:51.506554
# Unit test for function matchpathcon
def test_matchpathcon():
    actual_rc, actual_con = matchpathcon("/path/to/something", 0)
    expected_con = "nfs_t:object_r:nfs_t:s0"

    assert actual_con == expected_con
    assert actual_rc == 0
    assert type(actual_rc) is int
    assert type(actual_con) is str

# Generated at 2022-06-24 21:18:54.799570
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = os.environ.get('SEC_TEST_FILE_CON')
    if file:
        rc, con = lgetfilecon_raw(file)
        assert rc == 0

# Generated at 2022-06-24 21:19:03.204867
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = '/home/testuser/testfile'
    var_2 = 0
    var_3 = matchpathcon(var_1, var_2)
    if var_3 == 0 and to_native(var_4) == 'system_u:object_r:user_home_t:s0':
        pass
    else:
        print('Test failed')

# Generated at 2022-06-24 21:19:05.464269
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: implement test
    assert matchpathcon('', 0) == []


# Generated at 2022-06-24 21:19:07.854848
# Unit test for function matchpathcon
def test_matchpathcon():
    path = ''
    mode = 0
    result = matchpathcon(path, mode)
    assert result == [0, '']


# Generated at 2022-06-24 21:19:10.388849
# Unit test for function matchpathcon
def test_matchpathcon():
    # make sure that the path is readable
    assert matchpathcon('/tmp/foo.txt', 0) == matchpathcon('/tmp/foo.txt', None)

# Generated at 2022-06-24 21:19:15.569216
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/"
    mode = os.R_OK
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:root_t:s0']

# Generated at 2022-06-24 21:19:17.818071
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: this should be turned into a pytest unit test
    print('selinux.matchpathcon(\'/tmp\', 0) = {0}'.format(matchpathcon('/tmp', 0)))

# Generated at 2022-06-24 21:19:22.035899
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    args = {}
    if not isinstance(args, dict):
        raise Exception('function only accepts keyword arguments')
    # No mandatory arguments
    arg_vals = [
    ]
    for arg_name, arg_default in zip([
    ], arg_vals):
        if arg_name in args:
            args[arg_name] = args[arg_name]
        else:
            args[arg_name] = arg_default
    rc, result = lgetfilecon_raw(**args)
    return rc, result


# Generated at 2022-06-24 21:19:28.297073
# Unit test for function matchpathcon
def test_matchpathcon():
    got_rc, got_con = matchpathcon("test_case_0", 0)
    expected_rc = 0
    expected_con = "system_u:object_r:svirt_lxc_net_t:s0"
    if got_rc != expected_rc:
        assert False, 'matchpathcon: got_rc != expected_rc fail'
    if got_con != expected_con:
        assert False, 'matchpathcon: got_con != expected_con fail'


# Generated at 2022-06-24 21:19:32.514629
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert str(lgetfilecon_raw('test.txt')) == "[0, 'system_u:object_r:user_home_t:s0']"


# Generated at 2022-06-24 21:19:36.772709
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/etc/selinux/config") == [0, "system_u:object_r:etc_t:s0\n"]


# Generated at 2022-06-24 21:19:45.212260
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        path = None
        assert lgetfilecon_raw(path) == [0, 'unlabeled']
    except ImportError:
        pass



# Generated at 2022-06-24 21:19:49.376083
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    str_0 = 'sysfs'
    var_0 = lgetfilecon_raw(str_0)
    assert var_0[0] == 3
    assert var_0[1] == 'system_u:object_r:sysfs_t'


# Generated at 2022-06-24 21:19:55.480757
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/foo") == [0, "system_u:object_r:admin_home_t:s0:c0.c1023"]


# Generated at 2022-06-24 21:19:57.583137
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 'Scripts' in matchpathcon('/usr/share/example-content', 0)



# Generated at 2022-06-24 21:20:02.958062
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/home/user/')
    assert rc == 0
    assert con == 'user_home_t:s0'


# Generated at 2022-06-24 21:20:05.255675
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path='/home/akshay/file_name'
    # Call function lgetfilecon_raw
    lgetfilecon_raw(path=file_path)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:20:15.048235
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with valid param
    mode = False
    con = matchpathcon('', mode)
    if not con:
        raise AssertionError('matchpathcon returned no value')
    # Test with valid param
    mode = False
    con = matchpathcon('/etc/passwd', mode)
    if not con:
        raise AssertionError('matchpathcon returned no value')
    # Test with valid param
    mode = True
    con = matchpathcon('/etc/passwd', mode)
    if not con:
        raise AssertionError('matchpathcon returned no value')
    # Test with valid param
    mode = False
    con = matchpathcon('/etc', mode)
    if not con:
        raise AssertionError('matchpathcon returned no value')
    # Test with valid param
    mode = True

# Generated at 2022-06-24 21:20:18.718540
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/hosts"
    out = lgetfilecon_raw(path)
    assert type(out) == list
    assert out[0] == 0
    assert type(out[1]) == str


# Generated at 2022-06-24 21:20:19.940344
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(['test', 'dummy', 'input']) == [0, '']


# Generated at 2022-06-24 21:20:25.437127
# Unit test for function matchpathcon

# Generated at 2022-06-24 21:20:31.389403
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO
    pass


# Generated at 2022-06-24 21:20:33.742792
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/var/log'
    mode = 4096
    rc, out = matchpathcon(path, mode)
    print(out)
    assert rc == 0



# Generated at 2022-06-24 21:20:35.401311
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/proc')
    print(result)



# Generated at 2022-06-24 21:20:38.045533
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    f = '/etc/shadow'
    rv = lgetfilecon_raw(f)
    assert type(rv[0]) is int
    assert type(rv[1]) is str



# Generated at 2022-06-24 21:20:38.909649
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert False



# Generated at 2022-06-24 21:20:43.086108
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    myfile = os.path.join(os.getcwd(), 'test_lgetfilecon_raw')
    with open(myfile, 'w') as f:
        pass

    results = lgetfilecon_raw(myfile)
    rc, con_value = results
    os.remove(myfile)
    assert isinstance(rc, int)
    assert isinstance(con_value, str)



# Generated at 2022-06-24 21:20:46.698351
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/")[0] == 0


# Generated at 2022-06-24 21:20:47.523983
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/tmp')
    return var_1


# Generated at 2022-06-24 21:20:57.907590
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    import os.path

    # make sure mode handles a list of strings properly
    path = "/etc/passwd"
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon(path, [mode, str(mode)]) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon(path, [mode, int(mode), mode]) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon(path, [str(mode), mode, int(mode)]) == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-24 21:21:01.277056
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp"
    mode = 0
    rc, result = matchpathcon(path, mode)



# Generated at 2022-06-24 21:21:07.761638
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/hosts"
    mode = 0
    retval = matchpathcon(path, mode)

# Generated at 2022-06-24 21:21:13.050673
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/path/to/unlabeled/file'
    mode = os.R_OK
    ret = matchpathcon(path, mode)
    print(ret)

# Generated at 2022-06-24 21:21:23.394565
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    os.mkdir('/tmp/ansible_selinux_test_dir')
    path = '/tmp/ansible_selinux_test_dir'
    con_t = selinux_getpolicytype()[1] + '.file_t'
    rc = lsetfilecon(path, con_t)
    expected_result = (0, con_t)
    assert lgetfilecon_raw(path) == expected_result, "Expected: %s, Actual: %s" % (expected_result, lgetfilecon_raw(path))
    os.rmdir('/tmp/ansible_selinux_test_dir')


# Generated at 2022-06-24 21:21:24.741544
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw("/tmp")
    assert var_1 == 0

# Generated at 2022-06-24 21:21:35.445527
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert callable(lgetfilecon_raw)
    # __doc__ (as of 2008-08-02) for libselinux.lgetfilecon_raw:
    # Prototype: int lgetfilecon_raw(const char *path, char ** context_raw)
    # Description: Get the context of a file.
    #
    # This function will get the raw context of a file.
    # The "raw context" here means that it is a malloced
    # string, with no magic processing, such as translating
    # into a canonical form.
    #
    # Arguments:
    #  path - the file to get the context of
    #  context_raw - a reference to the location to store
    #                the context
    # context_raw is a reference to a char * that is set
    # to point to a malloc

# Generated at 2022-06-24 21:21:47.570695
# Unit test for function matchpathcon
def test_matchpathcon():
    # Ensure that the test has access to the selinux library.
    import ctypes

    # Make sure that the function is in the selinux library.
    if not hasattr(selinux_lib, 'matchpathcon'):
        raise AssertionError(
            "Cannot find function 'matchpathcon' in selinux library.")

    # Retrieve the prototype for the matchpathcon function.
    signature = ctypes.CFUNCTYPE(ctypes.c_int,
                                 ctypes.c_char_p,
                                 ctypes.c_int,
                                 ctypes.POINTER(ctypes.c_char_p))
    matchpathcon = signature(selinux_lib.matchpathcon)

    # Create a variable for the return value of matchpathcon.
    rc = None

    # Create a variable for the context

# Generated at 2022-06-24 21:21:53.713239
# Unit test for function matchpathcon
def test_matchpathcon():
    f = 'example.txt'
    path = '/home/user/' + f
    # Default mode is 0
    mode = 0
    # Only tests if the function returns success or failure.
    a = matchpathcon(path, mode)
    if a[0] > 0:
        print('success')
    else:
        print(str(a[0]) + ": " + a[1])


# Generated at 2022-06-24 21:21:54.812578
# Unit test for function matchpathcon
def test_matchpathcon():

    retval = matchpathcon('test', 'test')


# Generated at 2022-06-24 21:21:57.556115
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')

    #verify the results
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-24 21:22:01.784901
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/issue', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-24 21:22:15.274509
# Unit test for function matchpathcon
def test_matchpathcon():
    tests = [
        {
            'input': {'path': '/home/ansible/test.txt', 'mode': None},
            'expected': [0, 'user_u:object_r:admin_home_t:s0']
        }
    ]

    for t in tests:
        expected = t['expected']
        actual = matchpathcon(**t['input'])

        assert actual == expected



# Generated at 2022-06-24 21:22:20.803155
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test for lgetfilecon_raw
    """
    # create a file
    fd = os.open(os.path.join(tempfile.gettempdir(), 'tmpfile'), os.O_CREAT)
    os.close(fd)

    (rc, context) = lgetfilecon_raw(os.path.join(tempfile.gettempdir(), 'tmpfile'))

    if rc == 0:
        assert isinstance(context, str)
    else:
        assert "Error getting the context of the file"

    os.remove(os.path.join(tempfile.gettempdir(), 'tmpfile'))



# Generated at 2022-06-24 21:22:21.974010
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert callable(lgetfilecon_raw)


# Generated at 2022-06-24 21:22:23.043675
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path) == [rc, con.value]

# Generated at 2022-06-24 21:22:28.372473
# Unit test for function matchpathcon
def test_matchpathcon():
    test_file_path = '/tmp/ansible-selinux-test-file'

    if not matchpathcon(test_file_path, 0)[1]:
        # this is the normal case if the file does not exist
        return

    import tempfile

    try:
        test_file_fd, file_name = tempfile.mkstemp(prefix='ansible-selinux-test-file-')
        assert matchpathcon(file_name, 0)[0] == 0
    finally:
        os.close(test_file_fd)
        os.remove(file_name)

# Generated at 2022-06-24 21:22:29.700302
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test for lgetfilecon_raw"""
    # FIXME: implement test
    # assert return_value == expected
    assert True


# Generated at 2022-06-24 21:22:33.070017
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/share/foo', 0) == [0, 'system_u:object_r:usr_t:s0']
    assert matchpathcon('/usr/lib/foo', 0) == [0, 'system_u:object_r:lib_t:s0']
    assert matchpathcon('/usr/lib/foo.so', 0) == [0, 'system_u:object_r:lib_t:s0']



# Generated at 2022-06-24 21:22:36.109147
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t:s0-s0:c0.c1023']

# Generated at 2022-06-24 21:22:42.545856
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc = lgetfilecon_raw('/tmp/tfile')
    # check return value
    if rc[0] > -1 and rc[1] == 'system_u:object_r:tmp_t:s0':
        print('SUCCESS: SELinux context of /tmp/tfile is system_u:object_r:tmp_t:s0')
    else:
        print('FAILURE: SELinux context of /tmp/tfile is {}'.format(rc[1]))

# Generated at 2022-06-24 21:22:46.219805
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/path/to/file', 0) == [0, 'system_u:object_r:nfs_t:s0']


# Generated at 2022-06-24 21:23:09.479858
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test that valid entries are placed into the output dict
    fake_path = "/usr/local/var/ansible"
    output = lgetfilecon_raw(fake_path)
    assert fake_path in output[1]


# Generated at 2022-06-24 21:23:16.407383
# Unit test for function matchpathcon

# Generated at 2022-06-24 21:23:22.910954
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc/passwd-') == [-1, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-24 21:23:26.394412
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    rc, con = matchpathcon(path, 0)
    assert rc == 0, "Failed to retrieve security context for path {}".format(path)


# Generated at 2022-06-24 21:23:27.431683
# Unit test for function matchpathcon
def test_matchpathcon():
    pass


# Generated at 2022-06-24 21:23:28.301504
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path) == None

# Generated at 2022-06-24 21:23:29.821562
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_00 = 'test.txt'
    var_01 = lgetfilecon_raw(var_00)
    return var_01


# Generated at 2022-06-24 21:23:34.474872
# Unit test for function matchpathcon
def test_matchpathcon():
    assert type(matchpathcon("/etc/lxc/default.conf", 0)) is list
    assert type(matchpathcon("/etc/lxc/default.conf", 1)) is list
    assert type(matchpathcon("/etc/lxc/default.conf", 2)) is list


# Generated at 2022-06-24 21:23:38.103318
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert to_native(lgetfilecon_raw(b'/var/log/audit/audit.log')[1]) == 'system_u:object_r:auditd_log_t:s0'


# Generated at 2022-06-24 21:23:43.037133
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test'
    mode = 0
    expected_rc = 0
    expected_result = 'user_tmp_t:object_r:tmp_t:s0'
    expected_con = 'user_tmp_t:object_r:tmp_t:s0'
    rc, con = matchpathcon(path, mode)
    assert rc == expected_rc
    assert con == expected_con



# Generated at 2022-06-24 21:24:32.340889
# Unit test for function matchpathcon
def test_matchpathcon():
    """ Test case for function matchpathcon. """

    rc, result = matchpathcon(os.getcwd(), 0)

    assert rc == 0
    assert result
    assert not result.startswith('Invalid')



# Generated at 2022-06-24 21:24:36.442749
# Unit test for function matchpathcon
def test_matchpathcon():
    target = "/etc/passwd"
    mode = 0
    ret = matchpathcon(target, mode)
    assert ret[0] == 0
    assert ret[1] == "system_u:object_r:passwd_file_t:s0"



# Generated at 2022-06-24 21:24:39.032815
# Unit test for function matchpathcon
def test_matchpathcon():
    # calling matchpathcon(path, mode)
    rc = matchpathcon('/etc/passwd', 0)
    assert rc == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:24:42.296984
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'


# Generated at 2022-06-24 21:24:47.954109
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # The result of this method is `[0, 'system_u:object_r:unlabeled_t:s0']`,
    # but it's hard to write a test for that because it depends on the context
    # of the current test system.  So just make sure we don't get an exception.
    ret = lgetfilecon_raw('/dev/null')
    assert isinstance(ret, list) and len(ret) == 2



# Generated at 2022-06-24 21:24:51.429818
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/usr/bin/ls" #Faked input
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None


# Generated at 2022-06-24 21:24:58.913852
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw(b'/etc/passwd')
        assert rc == 0

        rc, con = lgetfilecon_raw(b'/does/not/exist')
        assert rc != 0 and con is None
    except OSError as e:
        if e.errno == errno.ENOTSUP:
            # SELinux not supported by the OS
            pass
        else:
            raise e



# Generated at 2022-06-24 21:25:00.755995
# Unit test for function matchpathcon
def test_matchpathcon():
    with pytest.raises(ImportError):
        from ansible.module_utils.selinux import matchpathcon

# Generated at 2022-06-24 21:25:07.002348
# Unit test for function matchpathcon
def test_matchpathcon():
    path_0 = '/bin'
    mode_1 = 1
    # Test with valid arguments, None path
    assert matchpathcon(path_0, mode_1)[1] is not None
    # Test with invalid arguments, Invalid path
    assert matchpathcon("/bine", mode_1)[1] is None
    assert matchpathcon("/bine", mode_1)[0] is -3



# Generated at 2022-06-24 21:25:12.702338
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert False


# Generated at 2022-06-24 21:26:41.287554
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp')


# Generated at 2022-06-24 21:26:43.814370
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b''
    mode = 0
    assert isinstance(matchpathcon(path, mode), tuple) == True



# Generated at 2022-06-24 21:26:47.855564
# Unit test for function matchpathcon
def test_matchpathcon():

    # path is a file
    path = "/etc/shadow"
    mode = 0
    assert matchpathcon(path, mode)[0] == 0

    # path is a dir
    path = "/etc"
    mode = 0
    assert matchpathcon(path, mode)[0] == 0



# Generated at 2022-06-24 21:26:51.022595
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = ''
    rc, out = lgetfilecon_raw(filename)
    assert rc == 0
    assert out.startswith('system_u:object_r:')


# Generated at 2022-06-24 21:26:53.994940
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'test'
    mode = 0
    expected = [0, 'system_u:object_r:unlabeled_t:s0']

    ret = [0, ''] # FIXME: mock
    assert ret == expected


# Generated at 2022-06-24 21:26:55.287353
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO: implement test
    pass


# Generated at 2022-06-24 21:26:58.592728
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon('/etc/nginx/sites-enabled/default', 0)

# Generated at 2022-06-24 21:27:02.379781
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/lib/libvirt/images', 0) == [0, 'system_u:object_r:virt_image_t:s0']


# Generated at 2022-06-24 21:27:07.041486
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    actual = lgetfilecon_raw('/tmp/nested/dir1')
    expected = [0, 'system_u:object_r:tmp_t:s0']
    assert actual == expected, "Expected {0} but got {1}".format(expected, actual)
