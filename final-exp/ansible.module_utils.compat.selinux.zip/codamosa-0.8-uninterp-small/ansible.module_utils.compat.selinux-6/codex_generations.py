

# Generated at 2022-06-24 21:17:16.032287
# Unit test for function matchpathcon
def test_matchpathcon():
    if os.path.isdir("/var/log/ansible"):
        assert matchpathcon("/var/log/ansible", 0) == [0, 'system_u:object_r:var_log_t:s0']
    else:
        assert matchpathcon("/var/log/ansible", 0) != [0, 'system_u:object_r:var_log_t:s0']


# Generated at 2022-06-24 21:17:22.764439
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Put in a temp file
    import tempfile
    test_file = tempfile.NamedTemporaryFile(delete=False)

    # Read the output
    test_out = lgetfilecon_raw(test_file.name)
    assert test_out[0] == 0  # The return code should be 0

    # Close the file and remove it
    test_file.close()
    os.remove(test_file.name)



# Generated at 2022-06-24 21:17:28.949670
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = _selinux_lib.matchpathcon.argtypes[1]
    var_2 = _selinux_lib.matchpathcon.argtypes[2]
    # Call to matchpathcon
    matchpathcon(('/etc/groovy/policy/policy.30' if os.path.exists('/etc/groovy/policy/policy.30') else '/usr/libexec/selinux/mcs/contexts/users/unconfined_u'), 3)



# Generated at 2022-06-24 21:17:30.725936
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/home') == [0, 'unlabeled_t']


# Generated at 2022-06-24 21:17:35.262680
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # Test with dummy path
    path_test = '/tmp'
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(path_test, byref(con))
    _selinux_lib.freecon(con)
    print("rc: " + str(rc))


# Generated at 2022-06-24 21:17:46.272823
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_passed = 0
    test_failed = 0
    var_1 = "/sys/fs/selinux/"

    [rc, con] = lgetfilecon_raw(var_1)
    if [rc,con]!=[0,"system_u:object_r:selinuxfs:s0"]:
        print("lgetfilecon_raw failed for path " + var_1 + " with con:" + con)
        test_failed += 1
    else:
        test_passed += 1

    var_2 = "/etc"

    [rc, con] = lgetfilecon_raw(var_2)

# Generated at 2022-06-24 21:17:48.239426
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        path = ""
        assert lgetfilecon_raw(path)
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:17:53.303659
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/foo'
    mode = 0
    result = matchpathcon(path, mode)
    assert result == [0, 'system_u:object_r:default_t:s0']

if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-24 21:17:55.999554
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/foo', 1) == [0, 'system_u:object_r:foo_t:s0']


# Generated at 2022-06-24 21:17:57.418766
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(0, 0) == [0, None]


# Generated at 2022-06-24 21:18:03.716640
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/local/bin') == [0, 'unconfined_u:object_r:user_home_t:s0']


# Generated at 2022-06-24 21:18:05.916978
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('foo')
    assert isinstance(rc, int)
    assert isinstance(con, str)
    assert rc == 0

# Generated at 2022-06-24 21:18:08.681218
# Unit test for function matchpathcon
def test_matchpathcon():
    src = to_native(os.path.realpath(__file__))
    mode = os.R_OK
    dest = matchpathcon(src, mode)
    assert dest[0] == 0
    assert to_native(dest[1]) == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-24 21:18:13.562282
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/dev/null"
    try:
        con = c_char_p()
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        assert rc >= 0
        assert con.value
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:18:16.554053
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Use key argument
    args = dict(path=u'/tmp')
    actual = lgetfilecon_raw(**args)
    # Verify actual
    assert actual[0] == 0
    assert isinstance(actual[1], unicode)


# Generated at 2022-06-24 21:18:18.325787
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0

# Unit test of selinux_getenforcemode

# Generated at 2022-06-24 21:18:19.487007
# Unit test for function matchpathcon
def test_matchpathcon():
    assert True


# Generated at 2022-06-24 21:18:21.578820
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw(path=None)
    assert var_1 == [0, None]

# Generated at 2022-06-24 21:18:23.496216
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/var/log/audit/audit.log')


# Generated at 2022-06-24 21:18:27.554059
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/var/lib/") == [0, 'system_u:object_r:var_lib_t:s0']
    assert lgetfilecon_raw("/var") == [0, 'system_u:object_r:var_t:s0']



# Generated at 2022-06-24 21:18:36.027512
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    expected_rc = 0
    expected_cons = "system_u:object_r:passwd_file_t:s0"
    actual_rc, actual_cons = lgetfilecon_raw(path)
    assert actual_rc == expected_rc
    assert actual_cons == expected_cons


# Generated at 2022-06-24 21:18:40.592967
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/tmp/test'
    assert (matchpathcon(path, 0x1)[0] == 0)
    assert (matchpathcon(path, 0x400)[0] == 0)


if __name__ == '__main__':
    # test_matchpathcon()
    # test_case_0()

    for _ in range(1000):
        test_case_0()

# Generated at 2022-06-24 21:18:42.636736
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert filecon is not None

    # FIXME: add test cases
    assert False


# Generated at 2022-06-24 21:18:48.542306
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Path where your binary resides
    path = os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir)) + '/binary'

    # Get the security context for the given binary
    context = lgetfilecon_raw(path)[1]

    # Check if context is not empty
    if context:
        pass
    else:
        raise AssertionError("Context is empty")


# Generated at 2022-06-24 21:18:54.706966
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print('===> Running selinux test_lgetfilecon_raw')

    rc, msg = lgetfilecon_raw('/etc/hosts')
    assert rc == 0
    assert 'system_u:object_r' in msg
    rc, msg = lgetfilecon_raw('/etc/hosts_wrong_path')
    assert rc == -1


# Generated at 2022-06-24 21:18:58.744658
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw('/var/log/lastlog')
    print(var_0)
    print(var_0[0])
    print(var_0[1])

    var_1 = lgetfilecon_raw()
    print(var_1)



# Generated at 2022-06-24 21:19:00.245907
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    assert lgetfilecon_raw("path") == [0, None]

# Generated at 2022-06-24 21:19:02.911703
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp'
    mode = 0
    result = matchpathcon(path, mode)
    assert result == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-24 21:19:05.512543
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/foo', 0) == [0, 'u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:19:08.267771
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    output = lgetfilecon_raw('/etc/shadow')
    assert type(output[0]) == int
    assert type(output[1]) == str



# Generated at 2022-06-24 21:19:17.275884
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, value = matchpathcon('/', 0)
    assert value == 'system_u:object_r:root_t'


# Generated at 2022-06-24 21:19:20.139400
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/foo"
    mode = 0
    assert _selinux_lib.matchpathcon(path, mode, byref(c_char_p())) == -1


# Generated at 2022-06-24 21:19:24.899594
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert isinstance(lgetfilecon_raw("ansible/test/units/module_utils/selinux/_selinux_lib.py"), list)


# Generated at 2022-06-24 21:19:27.928361
# Unit test for function matchpathcon
def test_matchpathcon():
    # This test case will fail to execute until the LD_LIBRARY_PATH for the function is hardcoded.
    # When the function is fixed, we will remove the entire function
    assert True == True



# Generated at 2022-06-24 21:19:31.758511
# Unit test for function matchpathcon
def test_matchpathcon():

    try:
        rc, con = lgetfilecon_raw("/etc/localtime")
        if rc < 0:
            return 1
        print("context: %s" % con)
    except Exception as e:
        print("%s" % e)

    try:
        rc, con = matchpathcon("/etc/localtime", 0)
        if rc < 0:
            return 1
        print("context: %s" % con)
    except Exception as e:
        print("%s" % e)

    return 0



# Generated at 2022-06-24 21:19:33.418021
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO: Test matchpathcon
    pass


# Generated at 2022-06-24 21:19:38.797969
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'test_data/testdir/test.txt'
    mode = 'test_data/testdir'
    rc, con = matchpathcon(path, mode)
    assert con == 'u:object_r:usr_t:s0'
    assert rc == 0



# Generated at 2022-06-24 21:19:47.009610
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux.wrappers import matchpathcon
    # Check that matchpathcon throws an exception for an invalid file
    try:
        (rc, con) = matchpathcon('/foo/bar/baz', 0)
    except OSError as e:
        if e.errno == 22: # invalid argument
            return
        else:
            raise e

    assert False

if __name__ == '__main__':
    # test_case_0()
    test_matchpathcon()

# Generated at 2022-06-24 21:19:48.707571
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/path/con'
    mode = 0
    expect_0 = [0, 'mycontext']
    actual_0 = matchpathcon(path, mode)
    assert actual_0 == expect_0


# Generated at 2022-06-24 21:19:50.370631
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp', 0) == 0


# Generated at 2022-06-24 21:20:03.535189
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    results = lgetfilecon_raw("secrets")
    assert results[0] == 0
    assert results[1] == "system_u:object_r:etc_t:s0"


# Generated at 2022-06-24 21:20:08.205821
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/selinux/SELINUX'
    mode = 0

    actual = matchpathcon(path, mode)
    expected = [0, 'system_u:object_r:selinux_etc_t:s0']

    assert actual == expected


# Generated at 2022-06-24 21:20:09.805564
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw(b'/etc/hosts')


# Generated at 2022-06-24 21:20:12.196225
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw("test")
    assert var_1 == [0, 'system_u:object_r:selinux_config_file_t:s0']



# Generated at 2022-06-24 21:20:13.683254
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert matchpathcon('', 0)
    finally:
        pass


# Generated at 2022-06-24 21:20:17.021824
# Unit test for function matchpathcon
def test_matchpathcon():
    assert (matchpathcon('./etc/nsd/test', 0) == [0, 'system_u:object_r:etc_t:s0'])

# Generated at 2022-06-24 21:20:18.364060
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, var_0 = matchpathcon(b"/some/path", 0)
    assert rc == 0
    assert var_0 is not None


# Generated at 2022-06-24 21:20:22.363312
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import ctypes
    import pytest

    fd, temp = tempfile.mkstemp()
    os.close(fd)
    try:
        # Should fail with ctypes.ArgumentError since lgetfilecon_raw()
        # expects file argument of type bytes
        with pytest.raises(ctypes.ArgumentError):
            lgetfilecon_raw(temp)
    finally:
        os.unlink(temp)


# Generated at 2022-06-24 21:20:23.695039
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("path", 0) == [0, "system_u:object_r:user_home_dir_t:s0"]



# Generated at 2022-06-24 21:20:25.399788
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, result = lgetfilecon_raw('/usr/bin/python3.8')
    assert rc == 0
    assert result == 'unconfined_u:object_r:user_home_t:s0'



# Generated at 2022-06-24 21:20:42.109463
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 1 == 1

# Generated at 2022-06-24 21:20:45.177552
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc = lgetfilecon_raw(
        path='/var/log'
    )
    # assert rc == (0, "system_u:object_r:var_log_t:s0")
    # assert rc == (0, "system_u:object_r:container_var_log_t:s0")



# Generated at 2022-06-24 21:20:51.116804
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_name = 'test'
    file_path = '/etc/%s' % file_name

    # file created
    open(file_path, 'a').close()
    # file has context
    context = lgetfilecon_raw(file_path)[1]
    # file removed
    os.remove(file_path)

    assert context is not None, 'An error occurred while getting the context of a file'


# Generated at 2022-06-24 21:20:54.297628
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "test_path"
    mode = c_int()
    return matchpathcon(path,mode)


# Generated at 2022-06-24 21:20:57.142004
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    arg0 = '/root/foo'
    arg1 = 0
    retval = lgetfilecon_raw(arg0, arg1)

    assert isinstance(retval, list)
    assert len(retval) == 2



# Generated at 2022-06-24 21:21:01.834509
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('tests/test.txt')
    assert rc == 0
    assert isinstance(con, str)


# Generated at 2022-06-24 21:21:04.501785
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/log', os.R_OK) == [0, 'var_log_t']
    assert matchpathcon('/dev/null', os.R_OK) == [0, 'chr_file_t']


# Generated at 2022-06-24 21:21:06.205386
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('test_matchpathcon', 4) == None


# Generated at 2022-06-24 21:21:14.064212
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Prepare test
    test_string = 'test_lgetfilecon_raw'
    path = '/tmp/%s' % test_string
    with open(path, 'a'):
        pass

    # Execute function
    rc, con = lgetfilecon_raw(path)

    # Cleanup
    os.remove(path)

    # Uncomment for debugging
    # print(rc, con)

    # Assert rc is 0
    assert 0 == rc

    # Assert con is not None
    assert con is not None



# Generated at 2022-06-24 21:21:19.480929
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = 0
    path = '/foo/bar'

# Generated at 2022-06-24 21:21:56.364442
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon(b'/etc/passwd', 0)
    assert var_0[0] == 0


# Generated at 2022-06-24 21:22:00.174699
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/var/log'
    out = lgetfilecon_raw(path)
    assert out[0] == 0
    assert isinstance(out[1], str)



# Generated at 2022-06-24 21:22:04.918275
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    args = {
        'path': '/etc/passwd',
        'mode': None,
        'mkdir': False,
    }
    res = lgetfilecon_raw(**args)
    if res[0] == 0:
        assert res[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-24 21:22:07.006085
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, val = lgetfilecon_raw(b'/etc')
    assert (rc, val) == (0, '(null)')



# Generated at 2022-06-24 21:22:12.719861
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('None')
    assert(var_1[0] == -1)


# Generated at 2022-06-24 21:22:20.041739
# Unit test for function matchpathcon
def test_matchpathcon():

    # w/valid modes, should always return List[int, str]
    res, con = matchpathcon('/a/path', os.R_OK)
    assert isinstance(res, int)
    assert isinstance(con, str)
    res, con = matchpathcon('/a/path', os.R_OK | os.X_OK)
    assert isinstance(res, int)
    assert isinstance(con, str)
    res, con = matchpathcon('/a/path', 0)
    assert isinstance(res, int)
    assert isinstance(con, str)

    # w/invalid mode, should raise NotImplementedError

# Generated at 2022-06-24 21:22:22.873430
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/redhat-release"
    mode = 1

    # Call function
    function_result = matchpathcon(path, mode)

    # Check results
    assert function_result[0] == -14
    assert function_result[1] is None


# Generated at 2022-06-24 21:22:27.066823
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = "unit_test_path"
    test_mode = 0
    try:
        rc, con = matchpathcon(test_path, test_mode)
        assert rc == -1
        assert con == None
    finally:
        pass


# Generated at 2022-06-24 21:22:30.270889
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/var/tmp/foo'
    mode = 0
    assert matchpathcon(path, mode) == [0, b'var_tmp_t:file:s0']
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert result[1] == b'var_tmp_t:file:s0'


# Generated at 2022-06-24 21:22:36.737670
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if sys.version_info[0] >= 3:
        assert lgetfilecon_raw("/etc/hosts") == [0, "system_u:object_r:net_conf_t:s0"]
    assert lgetfilecon_raw("/bin/ls") == [0, "system_u:object_r:bin_t:s0"]



# Generated at 2022-06-24 21:24:04.571781
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    con = c_char_p()
    try:
        _selinux_lib.matchpathcon(os.path.sep, os.R_OK, byref(con))
        assert to_native(con.value) != ""
    finally:
        _selinux_lib.freecon(con)
    try:
        _selinux_lib.matchpathcon(tempfile.mkstemp()[1], os.R_OK, byref(con))
        assert to_native(con.value) != ""
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:24:09.978059
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        assert rc == 0
        assert to_native(con.value) is not None
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:24:13.179466
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con.startswith(b'unconfined_u')


# Generated at 2022-06-24 21:24:16.221712
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("foo", 0) == [0, 'system_u:object_r:user_home_t:s0']

# Generated at 2022-06-24 21:24:19.669876
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert to_native(lgetfilecon_raw(__file__)[1]) == "system_u:object_r:ansible_file_t:s0"


# Generated at 2022-06-24 21:24:28.173210
# Unit test for function matchpathcon
def test_matchpathcon():
    fname = 'matchpathcon'
    func = globals().get(fname)
    if not func:
        raise NotImplementedError('Function {0} is not implemented'.format(fname))

    rc, con = matchpathcon('/a/b/c/d', 0)
    if rc != -1:
        raise AssertionError('{0} did not fail'.format(fname))

    rc, con = matchpathcon('/a/b/c/d', 1)
    if rc != -1:
        raise AssertionError('{0} did not fail'.format(fname))

    rc, con = matchpathcon('/a/b/c/d', 2)
    if rc != 0:
        raise AssertionError('{0} did fail'.format(fname))



# Generated at 2022-06-24 21:24:34.867054
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='/home/test_user/test.py', mode=123)[1] == 'system_u:object_r:user_home_t:s0'
    assert matchpathcon(path=None, mode=123)[1] == 'system_u:object_r:user_home_t:s0'


if __name__ == '__main__':
    test_case_0()
    test_matchpathcon()

# Generated at 2022-06-24 21:24:38.050264
# Unit test for function matchpathcon
def test_matchpathcon():
    assert isinstance(matchpathcon("/tmp/test.txt",10), [int, str]), "Test matchpathcon"
    assert isinstance(matchpathcon("/tmp/test.txt",0), [int, str]), "Test matchpathcon"



# Generated at 2022-06-24 21:24:40.172475
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert rc >= 0
    assert con


# Generated at 2022-06-24 21:24:43.255277
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/selinux/config', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'