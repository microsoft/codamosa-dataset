

# Generated at 2022-06-24 21:17:05.561320
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/foo', 0)
    assert rc == 0
    assert con == 'system_u:object_r:user_home_dir_t:s0'


# Generated at 2022-06-24 21:17:13.451231
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 1 == matchpathcon('/a/b', 1)[0]
    assert 1 == matchpathcon('/a/b', 1)[0]
    assert -1 == matchpathcon('/a/b', 1)[1]
    assert 1 == matchpathcon('/a/b', 1)[0]
    assert -1 == matchpathcon('/a/b', 1)[1]
    assert 1 == matchpathcon('/a/b', 1)[0]
    assert -1 == matchpathcon('/a/b', 1)[1]


# Generated at 2022-06-24 21:17:15.817604
# Unit test for function matchpathcon
def test_matchpathcon():
    path = str()
    mode = int()
    assert matchpathcon(path, mode) == (0, '')

# Generated at 2022-06-24 21:17:19.066177
# Unit test for function matchpathcon
def test_matchpathcon():
    # MatchPathcon is deprecated and should be rewritten on selabel_lookup (but will be a PITA)
    pass



# Generated at 2022-06-24 21:17:23.447867
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    # Unit test for function lgetfilecon_raw
    """
    #
    # Test: lgetfilecon_raw returns 0 for success
    #
    var_1 = lgetfilecon_raw('/dev/console')
    assert var_1[0] == 0



# Generated at 2022-06-24 21:17:27.456260
# Unit test for function matchpathcon
def test_matchpathcon():
    con = c_char_p()
    try:
        rc = _selinux_lib.matchpathcon(b'/etc', 0, byref(con))
        assert rc == 0
    finally:
        _selinux_lib.freecon(con)



# Generated at 2022-06-24 21:17:31.717034
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/ansible_test_file'
    open(path, 'a').close()
    fcon = lgetfilecon_raw(path)[1]
    os.unlink(path)
    assert isinstance(fcon, str), "Expected a str/unicode string"


# Generated at 2022-06-24 21:17:34.171115
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = '/var/log'
    var_2 = lgetfilecon_raw(var_1)


# Generated at 2022-06-24 21:17:35.053457
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass


# Generated at 2022-06-24 21:17:39.189254
# Unit test for function matchpathcon
def test_matchpathcon():
    mpath = "/var/log/messages"
    mmode = 0
    (rc, con) = matchpathcon(mpath, mmode)
    assert rc == 0 and con == 'system_u:object_r:var_log_t:s0'



# Generated at 2022-06-24 21:17:48.100499
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    with open('/etc/selinux/config', 'r') as f:
        if "SELINUX=" in f.read():
            try:
                result = lgetfilecon_raw(to_bytes('/etc/selinux/config'))
                assert type(result) == list and len(result) == 2 and result[0] == 0
                if result[1]:
                    assert type(result[0]) == int and type(result[1]) == str
            except:
                raise AssertionError('Unable to run lgetfilecon_raw test')



# Generated at 2022-06-24 21:17:53.210210
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/foo/bar') == [0, 'system_u:object_r:bin_t:s0']
    assert lgetfilecon_raw('/foo/bar/non-existent')[0] != 0


# Generated at 2022-06-24 21:17:54.807880
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: Add code for testing lgetfilecon_raw here.
    assert 1 == 1


# Generated at 2022-06-24 21:17:57.959424
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/etc/grub.d/18_ubuntumate', 0)
    print('rc: {0}'.format(rc))
    print('con: {0}'.format(con))



# Generated at 2022-06-24 21:18:01.608831
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/home/foo/foo.conf', 0) == [0, u'u:object_r:home_conf_t:s0']
    assert matchpathcon('/home/foo/foo.py', 0) == [0, u'u:object_r:home_t:s0']


# Generated at 2022-06-24 21:18:03.291204
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = ''
    rc, out = lgetfilecon_raw(path)


# Generated at 2022-06-24 21:18:07.367776
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/tmp', 0)
    assert res[0] == 0
    assert res[1] == 'system_u:object_r:svirt_sandbox_file_t:s0'
    # FIXME: This is stupid, but errcheck doesn't work for string values
    # TODO: Better way to test this?
    res = matchpathcon('/', 0)
    assert res[0] == -1



# Generated at 2022-06-24 21:18:11.368697
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon(path='/tmp/test', mode=0)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-24 21:18:14.718472
# Unit test for function matchpathcon
def test_matchpathcon():
    file_path = 'foo'
    mode = 0
    assert matchpathcon(file_path, mode) == [0, 'system_u:object_r:file_t:s0']


# Generated at 2022-06-24 21:18:16.482339
# Unit test for function matchpathcon
def test_matchpathcon():
    assert type(matchpathcon(None, None)) is list, "%s does not return list" % matchpathcon(None, None)


# Generated at 2022-06-24 21:18:24.579581
# Unit test for function matchpathcon
def test_matchpathcon():
    # input arguments
    path = "/foo"
    mode = 0
    rc, con = matchpathcon(path, mode)
    if rc == 0 or rc == -1:
        assert isinstance(con, str)
    else:
        assert False, "Returned unexpected result: %s" % con



# Generated at 2022-06-24 21:18:26.415062
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/etc/security", 0) == [0, "system_u:object_r:security_t:s0"]


# Generated at 2022-06-24 21:18:28.250152
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/home/test", 2)


# Generated at 2022-06-24 21:18:35.579961
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, out = matchpathcon('/etc/shadow', 0)
    assert rc == 0
    assert out == 'system_u:object_r:shadow_t:s0'

    rc, out = matchpathcon('/etc/shadow', 0o100)
    assert rc == 0
    assert out == 'system_u:object_r:shadow_t:s0'

    # if selinux is not enabled, then we should still get a context
    rc, out = matchpathcon('/etc/shadow', 0, False)
    assert rc == 0
    assert out == 'system_u:object_r:shadow_t:s0'



# Generated at 2022-06-24 21:18:40.563327
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fpath = '/etc/resolv.conf'
    try:
        os.symlink(fpath, '/tmp/resolv.conf')
        assert lgetfilecon_raw('/tmp/resolv.conf')[1].strip() == 'system_u:object_r:resolv_conf_t:s0'
    finally:
        os.unlink('/tmp/resolv.conf')

# Generated at 2022-06-24 21:18:43.601054
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/')[1] is not None
    assert lgetfilecon_raw('/root')[1] is not None


# Generated at 2022-06-24 21:18:46.268541
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.curdir
    rc, con = lgetfilecon_raw(path)

    assert rc == 0
    assert (con is not None and con != '')


# Generated at 2022-06-24 21:18:47.793259
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp"
    mode = 0
    # noqa: F841
    var_1 = matchpathcon(path, mode)


# Generated at 2022-06-24 21:18:50.751864
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert [0, u'system_u:object_r:tmp_t:s0'] == lgetfilecon_raw(u'/bin/echo')



# Generated at 2022-06-24 21:18:54.511720
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r = lgetfilecon_raw('/etc/passwd')
    assert r[0] == 0
    assert r[1] == 'system_u:system_r:shadow_t:s0'


# Generated at 2022-06-24 21:19:04.874272
# Unit test for function matchpathcon
def test_matchpathcon():
    path_0 = '/tmp'
    mode_0 = 0
    out_expected_0 = '[0, None]'
    expected_0 = None
    out_0 = matchpathcon(path_0, mode_0)
    assert out_expected_0 == str(out_0)
    assert expected_0 == out_0[1]


# Generated at 2022-06-24 21:19:08.163507
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/some/random/file/path'
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:default_t:s0']



# Generated at 2022-06-24 21:19:13.988460
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: mock with fake file
    var_1 = '/var/lib/systemd/ask-password/passwd'
    rc_0, con_0 = lgetfilecon_raw(var_1)
    assert rc_0 == 0
    assert con_0 == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-24 21:19:16.427418
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert True


# Generated at 2022-06-24 21:19:18.604345
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = "/home/test"
    var_2 = 0
    matchpathcon(var_1,var_2,)


# Generated at 2022-06-24 21:19:24.497163
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    d = '/'
    if os.path.exists(d):
        rc, con = lgetfilecon_raw(d)
        assert rc == 0
        assert con



# Generated at 2022-06-24 21:19:27.247671
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/proc/1/stat') == [0, 'system_u:system_r:init_t:s0\x00']


# Generated at 2022-06-24 21:19:28.914504
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon("/tmp/file.txt", 0)
    # Expect Result: True
    assert result



# Generated at 2022-06-24 21:19:31.863250
# Unit test for function matchpathcon
def test_matchpathcon():
    assert lgetfilecon_raw(None) == [1, None]
    assert lgetfilecon_raw('/etc/passwd') == [0, 'passwd_t']


# Generated at 2022-06-24 21:19:41.211428
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 'bool' in str(type(is_selinux_enabled()))
    assert 'bool' in str(type(is_selinux_mls_enabled()))
    assert 'int' in str(type(security_getenforce()))
    assert 'int' in str(type(security_policyvers()))
    assert 'tuple' in str(type(selinux_getenforcemode()))
    assert 'tuple' in str(type(selinux_getpolicytype()))
    assert 'tuple' in str(type(lgetfilecon_raw('/tmp/foo')))
    assert 'tuple' in str(type(lsetfilecon('/tmp/blah', 'system_u:object_r:unlabeled_t:s0')))

# Generated at 2022-06-24 21:20:03.238228
# Unit test for function matchpathcon
def test_matchpathcon():
    # se_myhome is the context at /tmp
    se_myhome = 'system_u:object_r:se_unit_test_t:s0:c1,c2'
    se_mydir = 'system_u:object_r:se_unit_test_dir_t:s0:c1,c2'
    se_myfile = 'system_u:object_r:se_unit_test_file_t:s0:c1,c2'
    se_ctx = 'system_u:object_r:se_unit_test_ctx_t:s0:c1,c2'

    if not os.path.exists("/tmp/myhome"):
        # Create a new directory called myhome and change the context to se_myhome
        os.mkdir("/tmp/myhome")

# Generated at 2022-06-24 21:20:05.707501
# Unit test for function matchpathcon
def test_matchpathcon():
    os.mkdir("/tmp/test/")
    rc, con = matchpathcon("/tmp/test/", 0)
    assert rc == 0
    assert con == "user_tmp_t"
    os.rmdir("/tmp/test/")



# Generated at 2022-06-24 21:20:11.934917
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: this test is loading the real SELinux policy, which is probably something we should not be doing
    result = matchpathcon('/beer', 0)
    assert result[0] == 0, 'return value was not 0 (success)'
    assert isinstance(result[1], str), 'policy context was not a string'



# Generated at 2022-06-24 21:20:16.660265
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t']
    assert matchpathcon('/', 1) == [0, 'system_u:object_r:root_t']
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t']
    assert matchpathcon('/etc', 1) == [0, 'system_u:object_r:etc_t']


# Generated at 2022-06-24 21:20:19.069871
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/foo', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/dev/null', 0) == [0, 'system_u:object_r:device_t:s0']


# Generated at 2022-06-24 21:20:22.779552
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw("/etc/passwd")
    assert var_0[0] == 0
    assert isinstance(var_0[1], str)

    var_1 = lgetfilecon_raw("/etc/passwd-")
    assert var_1[0] == -1

    var_2 = lgetfilecon_raw("/etc/passwd-2")
    assert var_2[0] == -1


# Generated at 2022-06-24 21:20:23.672302
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw(b'/tmp')


# Generated at 2022-06-24 21:20:27.278714
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw

    rc, con = lgetfilecon_raw(b'/etc/hosts')
    print('/etc/hosts context:', con)
    assert rc == 0



# Generated at 2022-06-24 21:20:31.549722
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 'stdout_lines' in str(lgetfilecon_raw.__annotations__)



# Generated at 2022-06-24 21:20:33.090395
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='test', mode=1) == [0, 'system_u:object_r:admin_home_t:s0']


# Generated at 2022-06-24 21:21:05.317935
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '.'
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:user_home_t:s0']
    # Negative test for function matchpathcon
    path = '.'
    mode = 1
    try:
        matchpathcon(path, mode)
    except OSError:
        pass
    else:
        raise AssertionError('function is expected to fail')


# Generated at 2022-06-24 21:21:10.738063
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-24 21:21:16.585122
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/a') == [0, 'system_u:object_r:etc_t:s0\x00']
    assert lgetfilecon_raw('/a')[0] == 0
    assert lgetfilecon_raw('/a')[1] == 'system_u:object_r:etc_t:s0\x00'



# Generated at 2022-06-24 21:21:19.525805
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 0 == lgetfilecon_raw(to_bytes('/foo/bar'))[0]
    assert 1 == lgetfilecon_raw(to_bytes('/baz/quux'))[0]


# Generated at 2022-06-24 21:21:23.072933
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/var/log')[1] is not None
    assert lgetfilecon_raw('/foo/bar')[1] is None


# Generated at 2022-06-24 21:21:28.225647
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    return_value = lgetfilecon_raw('/tmp/test')
    assert return_value == (0, 'system_u:object_r:tmp_t:s0')



# Generated at 2022-06-24 21:21:31.934031
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/test') == [0, 'system_u:object_r:tmp_t:s0']


# Generated at 2022-06-24 21:21:34.548481
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Params:
    path = '/'

    # Response:
    rc = 0
    con = 'system_u:object_r:root_t:s0'

    # Call:
    result = lgetfilecon_raw(path)

    # Assert:
    assert result[0] == rc
    assert result[1] == con



# Generated at 2022-06-24 21:21:36.399610
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Setup fixture
    # Assertion: lgetfilecon_raw()
    assert to_native(con.value) == None



# Generated at 2022-06-24 21:21:44.206626
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Path to a file in the test directory
    TEST_DATA_DIR = os.path.dirname(os.path.realpath(__file__))
    TEST_FILE_PATH = os.path.join(TEST_DATA_DIR, 'test_file')
    # Run lgetfilecon_raw on the file and test for the expected
    # context string
    result = lgetfilecon_raw(TEST_FILE_PATH)
    assert result == [0, 'system_u:object_r:usr_t']

# Generated at 2022-06-24 21:22:52.146318
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/'
    rc, con = lgetfilecon_raw(path)
    if rc != 0:
        raise ValueError('Failed to get context for path: %s' % path)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:22:56.796068
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon('/usr/sbin/nologin', os.stat('/usr/sbin/nologin').st_mode)
    assert var_1 == [0, 'system_u:object_r:nologin_exec_t:s0']


# Generated at 2022-06-24 21:22:58.785368
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon(None, None)
    return var_0

# Generated at 2022-06-24 21:23:00.552939
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: need a file to test against
    path = None

    rc, con = lgetfilecon_raw(path)
    assert rc == 0


# Generated at 2022-06-24 21:23:03.543367
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def test_case_1():
        var_1 = lgetfilecon_raw('test')
    test_case_1()



# Generated at 2022-06-24 21:23:06.407917
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, result = matchpathcon(path='/var/www', mode=0)
    print(rc, result)


# Generated at 2022-06-24 21:23:08.371221
# Unit test for function matchpathcon
def test_matchpathcon():
    assert __selinux__.matchpathcon('','','','') == None


# Generated at 2022-06-24 21:23:14.929991
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw("/etc/passwd", byref(con))
        if rc == 0:
            assert con != None
        else:
            assert rc == -1
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:23:22.153447
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    f = '/etc/hosts'
    [err, con] = lgetfilecon_raw(f)
    if err == 0:
        assert con.startswith('system_u:object_r:etc_t:s0')
    else:
        # libselinux has SELINUX_ERRNO_ENOENT, but ctypes doesn't know it
        assert err == -2, err
        assert con.startswith('system_u:object_r:etc_t:s0')



# Generated at 2022-06-24 21:23:24.840893
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 0 == matchpathcon('/home/vagrant', os.R_OK)[0]


# Generated at 2022-06-24 21:26:00.579385
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/b/abcd'
    mode = 1
    result = matchpathcon(path, mode)
    assert result[0] == -13
    assert result[1] == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-24 21:26:05.475548
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var0 = selinux_getpolicytype()
    var1 = lgetfilecon_raw("/etc/selinux")


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-24 21:26:11.829810
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "test_file.txt"
    f = open(path, 'w')
    f.write('test')
    f.close()
    rc, out = lgetfilecon_raw(to_bytes(path))
    os.remove(path)
    assert out == "system_u:object_r:user_home_t:s0"


# Generated at 2022-06-24 21:26:15.601256
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/pam.d/system-auth'
    mode = 13
    res = matchpathcon(path, mode)
    print(res)
    assert res[0] == 0
    assert res[1] == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-24 21:26:22.679666
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, policytype = selinux_getpolicytype()

    if rc != 0:
        raise OSError(rc, 'selinux getpolicytype failed')

    print('selinux policytype: {0}'.format(policytype))

    rc, selinuxenforce = selinux_getenforcemode()

    if rc != 0:
        raise OSError(rc, 'selinux getenforcemode failed')

    print('selinux enforced: {0}'.format(selinuxenforce))

    rc, isselinuxenabled = is_selinux_enabled()

    if rc != 0:
        raise OSError(rc, 'selinux is_selinux_enabled failed')

    print('selinux enabled: {0}'.format(isselinuxenabled))

    rc, isselin

# Generated at 2022-06-24 21:26:32.760844
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import filecmp
    import tempfile

    # create a file in a temporary directory
    content = b"This is a test file"
    with tempfile.NamedTemporaryFile(delete=False) as tempf:
        # write content to the temporary test file
        tempf.write(content)
    # save the location and file name
    temp_file = tempf.name

    # get the security context for the temp file
    rc, statcon = lgetfilecon_raw(temp_file)
    # cleanup and delete the temp file
    os.remove(temp_file)
    # assert the return code is 0
    assert rc == 0, 'Expected rc from lgetfilecon_raw(%s) to be 0, but is %s' % (temp_file, rc)
    # assert the security context is not empty

# Generated at 2022-06-24 21:26:37.946886
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/shadow"

    var_1 = lgetfilecon_raw(path)
    assert var_1[0] == 0
    assert var_1[1] == 'system_u:object_r:shadow_t:s0'


# Generated at 2022-06-24 21:26:39.344766
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon("/bin/bash", 0)[0]

    assert rc == 0

# Generated at 2022-06-24 21:26:40.852983
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/tmp/test_selinux") == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-24 21:26:43.898754
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']

