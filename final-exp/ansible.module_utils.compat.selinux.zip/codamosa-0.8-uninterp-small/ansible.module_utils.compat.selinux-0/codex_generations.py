

# Generated at 2022-06-24 21:17:05.489217
# Unit test for function matchpathcon
def test_matchpathcon():
    p_0 = b'/path/to/file'
    p_1 = 0
    var_0 = matchpathcon(p_0, p_1)
    print(var_0)


# Generated at 2022-06-24 21:17:06.994713
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, value = lgetfilecon_raw(".")
    assert rc == 0
    assert value is not None


# Generated at 2022-06-24 21:17:08.626890
# Unit test for function matchpathcon
def test_matchpathcon():
    context = matchpathcon('/var/example', 0o40755)
    assert context[1] == 'system_u:object_r:var_t:s0'

# Generated at 2022-06-24 21:17:11.417790
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        matchpathcon('/etc/passwd', 1)
    except:
        pass

# Generated at 2022-06-24 21:17:19.640092
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'', 0) == [0, '']
    assert matchpathcon(b'/', 0) == [0, 'system_u:object_r:root_t:s0']
    assert matchpathcon(b'/etc', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon(b'/etc/foo.conf', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon(b'/etc/foo/bar/baz', 0) == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-24 21:17:20.544807
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 'deny' == matchpathcon('/var/www/html', 0)[1]


# Generated at 2022-06-24 21:17:29.113351
# Unit test for function matchpathcon
def test_matchpathcon():
    if selinux_getenforcemode()[1] is not 1:
        raise AssertionError('se_linux is not in enforcing mode')

    ret = matchpathcon(b'/tmp/test_file', 0)
    if ret[0] is -1:
        raise AssertionError('there is no se_linux policy configured for this file')

    ctx = ret[1]
    if not isinstance(ctx, str):
        raise AssertionError('selinux context should be a string')

    if not ctx.startswith('system_u:object_r:tmp_t:s0'):
        raise AssertionError('unexpected selinux context: {0}'.format(ctx))



# Generated at 2022-06-24 21:17:32.073811
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    res = lgetfilecon_raw('/tmp')
    assert res[0] == 0, "Unexpected return code"
    assert res[1].startswith('system_u:object_r:')



# Generated at 2022-06-24 21:17:38.929538
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/bin/ls') == [0, 'system_u:object_r:bin_t:s0']
    assert lgetfilecon_raw('/etc/sudoers') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/etc/shadow') == [0, 'system_u:object_r:shadow_t:s0']
    assert lgetfilecon_raw('/usr/bin/vim') == [0, 'root:object_r:usr_bin_t:s0']

# Generated at 2022-06-24 21:17:48.624289
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: work around for Python 3.4.
    # matchpathcon() is deprecated and should be rewritten on
    # selabel_lookup (but will be a PITA)
    if sys.version_info[:2] >= (3, 5):
        pass
    else:
        return
    if not have_selinux():
        return
    var_0 = matchpathcon("/etc/group", 0)
    assert var_0[0] == 0
    var_1 = matchpathcon("/etc/group", 2)
    assert var_1[0] == 0
    var_2 = matchpathcon("/etc/group", 4)
    assert var_2[0] == 0
    var_3 = matchpathcon("/etc/group", 1)
    assert var_3[0] == 0
    var

# Generated at 2022-06-24 21:17:54.515496
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test if lgetfilecon_raw function works as expected
    """

    # Check if current context is not equal to unconfined_u:unconfined_r:unconfined_t
    conf = lgetfilecon_raw('/')[1]
    if conf != "unconfined_u:unconfined_r:unconfined_t":
        raise ValueError("Unexpected result for lgetfilecon_raw")


if __name__ == '__main__':
    # test case event
    # test_case_0()
    test_lgetfilecon_raw()

# Generated at 2022-06-24 21:17:58.586976
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/bin/ls"
    mode = os.stat(path).st_mode
    pol_type, context = matchpathcon(path, mode)
    print("matchpathcon(%s, %d) results in %s for context %s" % (path, mode, pol_type, context))

if __name__ == "__main__":
    test_case_0()
    test_matchpathcon()

# Generated at 2022-06-24 21:18:05.649019
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = lgetfilecon_raw('/etc/passwd')
    except OSError:
        rc, con = -1, None

    if rc >= 0:
        try:
            rc, con_a = matchpathcon('/etc/passwd', 0)
        except OSError:
            rc, con_a = -1, None

        print(rc, con, con_a)
        if con and con_a and con.decode('utf-8') == con_a.decode('utf-8'):
            print("INFO: selinux::matchpathcon(/etc/passwd) matches lgetfilecon_raw()")
        else:
            print("WARN: selinux::matchpathcon(/etc/passwd) does not match lgetfilecon_raw()")
    #

# Generated at 2022-06-24 21:18:10.894719
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert(to_native(lgetfilecon_raw('/var/log/httpd/access_log')) == 'system_u:object_r:var_log_t:s0')

# Generated at 2022-06-24 21:18:16.158985
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO: mock selinux_getenforcemode and selinux_matchpath_init_prefix
    args = dict(
        path='/some/path/here',
        mode=0,
    )
    c = matchpathcon(**args)
    assert c[0] == 0
    assert c[1] == 'system_u:object_r:admin_home_t:s0'

# Generated at 2022-06-24 21:18:17.319384
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon('/etc/passwd', 0)
    # TODO: assert that the actual return value is the same as the expected return value
    return

# Generated at 2022-06-24 21:18:19.814492
# Unit test for function matchpathcon
def test_matchpathcon():
    filename = "/path/to/file"
    mode = 0
    assert matchpathcon(filename, mode)



# Generated at 2022-06-24 21:18:24.328264
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/path/to/file', 0) == 0
    assert matchpathcon('/path/to/file', 8) == 0
    assert matchpathcon('/path/to/file', 0) == 0
    assert matchpathcon('/path/to/file', 8) == 0


# Generated at 2022-06-24 21:18:27.084782
# Unit test for function matchpathcon
def test_matchpathcon():
    rc_0, var_0 = matchpathcon(path='/foo/bar', mode=0)
    assert rc_0 == 0
    assert var_0 == 'system_u:object_r:foo_t:s0'


# Generated at 2022-06-24 21:18:30.908429
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/var/tmp/')[0] == -1


# Generated at 2022-06-24 21:18:36.625384
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, value = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert value

# Generated at 2022-06-24 21:18:40.234996
# Unit test for function matchpathcon
def test_matchpathcon():
    assert lgetfilecon_raw('/')[1] == 'system_u:object_r:root_t:s0', 'lgetfilecon_raw returned invalid context string "{0}"'.format(lgetfilecon_raw('/')[1])



# Generated at 2022-06-24 21:18:42.164958
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    res, var_0 = lgetfilecon_raw('/etc/passwd')


# Generated at 2022-06-24 21:18:49.141722
# Unit test for function matchpathcon
def test_matchpathcon():
    # Run this function in a separate process
    # to prevent password prompts from being written
    # to stdout
    import multiprocessing

    cfg = dict(
        args=[
            '/etc/resolv.conf'
        ],
        returncode=0,
        output=[
            0,
            'system_u:object_r:net_conf_t:s0'
        ],
    )

    p = multiprocessing.Process(target=_ut_matchpathcon, kwargs=cfg)

    p.start()
    p.join()

    assert p.exitcode == 0


# Generated at 2022-06-24 21:18:54.116294
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = b'/sys/devices/pci0000:00/0000:00:00.0/resource'
    rc, context = lgetfilecon_raw(test_path)

    assert rc == 0
    assert type(context) == str


# Generated at 2022-06-24 21:18:56.566828
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var = lgetfilecon_raw('/etc/shadow')
    assert var == [0, 'system_u:object_r:shadow_t:s0']


# Generated at 2022-06-24 21:19:00.633489
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert _selinux_lib.lgetfilecon_raw
    rc, con = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con
    assert con == b'unconfined_u:object_r:shadow_t:s0'


# Generated at 2022-06-24 21:19:01.535980
# Unit test for function matchpathcon
def test_matchpathcon():
    # no tests provided
    pass



# Generated at 2022-06-24 21:19:03.685177
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/python') == [0, 'unconfined_u:object_r:user_home_t:s0']


# Generated at 2022-06-24 21:19:09.735220
# Unit test for function matchpathcon
def test_matchpathcon():
    p = b'/etc/hosts'
    var_0 = matchpathcon(p, os.R_OK)
    if var_0[0]:
        raise Exception('Failed to call matchpathcon({}, {})'.format(p, os.R_OK))
    print('Success! Call to matchpathcon({}, {})'.format(p, os.R_OK))


# Generated at 2022-06-24 21:19:17.961752
# Unit test for function matchpathcon
def test_matchpathcon():
    myArgs = ("/home", 0)
    myargs = {'path': myArgs[0], 'mode': myArgs[1]}
    retVal = matchpathcon(**myargs)
    print(retVal)

# Generated at 2022-06-24 21:19:19.690961
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = matchpathcon('/home/test', 0)
    assert var_0[0] == 0, 'unexpected return code'



# Generated at 2022-06-24 21:19:24.877527
# Unit test for function matchpathcon
def test_matchpathcon():
    test_0 = matchpathcon('/home/ansible/new_dir', 0)
    print(test_0)


# Generated at 2022-06-24 21:19:26.229318
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/etc/foo')


# Generated at 2022-06-24 21:19:33.064954
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test case for function 'matchpathcon'
    fn = '/tmp/some.file'
    open(fn, 'w').close()
    con = matchpathcon(fn, 0)[1]
    assert con

    # restore the file to its original context
    lsetfilecon(fn, con)

# Generated at 2022-06-24 21:19:37.193573
# Unit test for function matchpathcon
def test_matchpathcon():
    assert to_native(matchpathcon(b'/etc', 0)[1]) == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-24 21:19:42.667891
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc = matchpathcon('/etc', 0)
        print(rc)
    except OSError as e:
        if e.args[0] == errno.EINVAL:
            sys.exit(1)
        raise


# Generated at 2022-06-24 21:19:48.026525
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    assert os.path.isfile('/etc/selinux/config')

    # Test case 0
    assert var_0[0] == 0


# Generated at 2022-06-24 21:19:50.489143
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test/testfile.txt'
    mode = 0
    var_0 = matchpathcon(path, mode)


# Generated at 2022-06-24 21:19:59.743422
# Unit test for function matchpathcon
def test_matchpathcon():
    errno = 0
    rc = 0
    result = ''
    result_str = ''

    # create a temp file
    with open("/tmp/selinux_test_file", "w") as f:
        f.write("test content")

    # test matchpathcon against the temp file
    (rc, result) = matchpathcon("/tmp/selinux_test_file", 0)

    if rc < 0:
        if rc == -3:
            errno = get_errno()
            result_str = to_native("matchpathcon failed with error: " + os.strerror(errno))
        elif rc == -1:
            result_str = to_native("failed to load policy, is this an SELinux kernel?  If so, try booting with enforcing=0 and running this again")


# Generated at 2022-06-24 21:20:09.649208
# Unit test for function matchpathcon
def test_matchpathcon():
    var_a = matchpathcon(b'/etc/passwd', 0)
    assert var_a[0] == 0


# Generated at 2022-06-24 21:20:13.375924
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/foo/bar', 33188) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp/foo/baz', 33188) == [0, 'system_u:object_r:unlabeled_t:s0']


# Generated at 2022-06-24 21:20:16.996840
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/etc/passwd')
    assert rc == 0
    assert isinstance(con, str)


# Generated at 2022-06-24 21:20:19.373994
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, out = matchpathcon('/_test/test/test', 0)
    assert(rc == 0)
    assert(out.startswith('system_u:object_r:user_home_t:'))


# Generated at 2022-06-24 21:20:20.573496
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/etc/passwd", 0)[0] == 0


# Generated at 2022-06-24 21:20:21.460376
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon('/var', 1)



# Generated at 2022-06-24 21:20:25.241665
# Unit test for function matchpathcon
def test_matchpathcon():
    assert not matchpathcon(None,False)


# Generated at 2022-06-24 21:20:26.330440
# Unit test for function matchpathcon
def test_matchpathcon():
    assert None is not False

    assert True is not False

    assert None is not False

    assert True is not False


# Generated at 2022-06-24 21:20:29.258469
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Correct invocation
    assert lgetfilecon_raw('/foo/bar/baz') == (1, 'system_u:object_r:devpts_t:s0')
    assert lgetfilecon_raw('/dev') == (1, 'system_u:object_r:dev_t:s0')

    # Invalid paths
    assert lgetfilecon_raw('') == (-1, '')
    assert lgetfilecon_raw('foo') == (-1, '')



# Generated at 2022-06-24 21:20:34.790924
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    data = lgetfilecon_raw('/')
    assert data[0] == 0
    assert data[1] == 'unconfined_u:object_r:user_home_dir_t:s0'


# Generated at 2022-06-24 21:20:54.073006
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    v = lgetfilecon_raw(None)
    assert v[0] == 0, v[1]


# Generated at 2022-06-24 21:20:55.929958
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert callable(lgetfilecon_raw)
    assert isinstance(lgetfilecon_raw(), list)
    assert len(lgetfilecon_raw()) in (1, 2)


# Generated at 2022-06-24 21:21:00.097968
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    file_name = tempfile.mktemp()
    f = open(file_name, "w")
    f.close()
    assert matchpathcon(file_name, 0)[0] == 0
    assert matchpathcon(file_name, 256)[0] == 0


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 21:21:05.058917
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/opt/') == 0


# Generated at 2022-06-24 21:21:12.966375
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fpath = "/etc/passwd"
    # FIXME: why does this fail
    # TODO: try with valid file
    # res = lgetfilecon_raw(fpath)
    # assert res[0] == 0
    # assert res[1] == "system_u:object_r:passwd_file_t:s0"



# Generated at 2022-06-24 21:21:14.121750
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(path=None)


# Generated at 2022-06-24 21:21:17.991041
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon("/tmp", 0x4)
    print("var_1: %s" % var_1)

test_matchpathcon()

# Generated at 2022-06-24 21:21:21.693957
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/'
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-24 21:21:27.629607
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/', 0)
    assert con.split(':')


# Generated at 2022-06-24 21:21:29.129142
# Unit test for function matchpathcon
def test_matchpathcon():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-24 21:22:05.100940
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/home/user/foo.txt"
    mode = 0
    assert matchpathcon(path, mode)[0] == [0, "system_u:object_r:user_home_t:s0"]


# Generated at 2022-06-24 21:22:09.818500
# Unit test for function matchpathcon
def test_matchpathcon():
    # get absolute path
    path = os.path.realpath(__file__)
    # get current file's context and store it in a tuple
    context = matchpathcon(path, os.R_OK)
    assert isinstance(context, list)
    # check if tuple has context and rc
    assert len(context) == 2
    # check if context is a string
    assert isinstance(context[1], str)

# Generated at 2022-06-24 21:22:13.367245
# Unit test for function matchpathcon
def test_matchpathcon():
    # Call the function.
    path = "/home/test"
    mode = 0
    assert [0, 'user_home_t'] == matchpathcon(path, mode)


# Generated at 2022-06-24 21:22:14.938008
# Unit test for function matchpathcon
def test_matchpathcon():
    assert "tst3" in matchpathcon("tst3", 0)[1]


# Generated at 2022-06-24 21:22:24.246600
# Unit test for function matchpathcon
def test_matchpathcon():

    test_paths = [
        '/etc/foo/bar',
        'http://example.com',
        'http://example.com/',
        'http://example.com/foo/bar',
        'http://example.com/foo/bar/',
        'http://example.com/foo/bar/baz',
        'http://example.com/foo/bar/baz/',
        'https://example.com',
        'https://example.com/',
        'https://example.com/foo/bar',
        'https://example.com/foo/bar/',
        'https://example.com/foo/bar/baz',
        'https://example.com/foo/bar/baz/'
    ]

    for path in test_paths:
        print ('Path: ' + path)
       

# Generated at 2022-06-24 21:22:29.782335
# Unit test for function matchpathcon
def test_matchpathcon():

    assert _selinux_lib.matchpathcon(b'/etc/passwd', 0, None) == 0
    assert _selinux_lib.matchpathcon(b'/test', 0, None) == 1
    assert _selinux_lib.matchpathcon(b'/test', 1, None) == -1

# Generated at 2022-06-24 21:22:33.804753
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 'selinux' in sys.modules
    assert isinstance(selinux_getenforcemode(), list)
    assert selinux_getenforcemode()[0] >= 0
    assert isinstance(is_selinux_enabled(), bool)
    assert isinstance(is_selinux_mls_enabled(), bool)
    assert isinstance(security_getenforce(), int)
    assert isinstance(security_policyvers(), int)
    assert isinstance(lgetfilecon_raw('/tmp/'), list)
    assert isinstance(matchpathcon('/tmp', 0), list)



# Generated at 2022-06-24 21:22:40.145557
# Unit test for function matchpathcon
def test_matchpathcon():
    assert to_native(security_getenforce()) == 0
    assert not is_selinux_mls_enabled()
    assert is_selinux_enabled()
    assert security_policyvers() == 30

    assert matchpathcon('/etc/passwd', 0)[1] == 'system_u:object_r:etc_runtime_t:s0'


if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-24 21:22:42.146022
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc') == [0, '/etc(/.*)? system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:22:45.766543
# Unit test for function matchpathcon
def test_matchpathcon():
    rc,con = matchpathcon('/usr/sbin/useradd',0)
    rc2,con2 = lgetfilecon_raw('/usr/sbin/useradd')
    print('rc: %d, con: %s' % (rc, con))
    print('rc: %d, con: %s' % (rc2, con2))
    assert con == con2

# Generated at 2022-06-24 21:24:09.524986
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw(b'/etc/passwd')
    var_2 = lgetfilecon_raw(b'/etc/passwd')
    var_3 = lgetfilecon_raw(b'/etc/passwd')


# Generated at 2022-06-24 21:24:20.565243
# Unit test for function matchpathcon
def test_matchpathcon():
    assert [0, 'system_u:object_r:ssh_home_t:s0'] == matchpathcon('/tmp', 0)
    assert [0, 'system_u:object_r:ssh_home_t:s0'] == matchpathcon('/', 0)
    assert [0, 'system_u:object_r:ssh_home_t:s0'] == matchpathcon('/', 2)
    assert [0, 'system_u:object_r:ssh_home_t:s0'] == matchpathcon('/', 1)
    assert [0, 'system_u:object_r:ssh_home_t:s0'] == matchpathcon('/', 3)
    assert [0, 'system_u:object_r:ssh_home_t:s0'] == matchpathcon('/', 0)


# Generated at 2022-06-24 21:24:27.817306
# Unit test for function matchpathcon
def test_matchpathcon():
    assert os.getenv('SELINUX_ROLE_REQUEST', False) != False
    assert os.getenv('SELINUX_USER_REQUEST', False) != False
    assert selinux_getenforcemode()[1] == 1
    assert is_selinux_enabled() == 1
    [rc, con] = matchpathcon('/etc/xinetd.conf', 0)
    assert rc == 0
    assert con == 'system_u:object_r:named_conf_t'
    [rc, con] = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t'



# Generated at 2022-06-24 21:24:34.986430
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Ensure that path is a string (or unicode)
    try:
        os.lgetfilecon_raw(object())
    except TypeError:
        pass
    else:
        raise Exception('Expected TypeError but did not see one!')

    try:
        os.lgetfilecon_raw(b'foo')
    except TypeError:
        pass
    else:
        raise Exception('Expected TypeError but did not see one!')



# Generated at 2022-06-24 21:24:37.751361
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con_out = lgetfilecon_raw(path)
    assert rc == 0
    assert con_out.startswith('staff_u:object_r:user_home_t')



# Generated at 2022-06-24 21:24:40.370486
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/foobar"
    mode = 0o777
    var_0 = matchpathcon(path, mode)



# Generated at 2022-06-24 21:24:43.104061
# Unit test for function matchpathcon
def test_matchpathcon():
    path = ''
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:24:50.056415
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/etc/shadow', 0)
    assert isinstance(result[0], int)
    assert isinstance(result[1], str)

    assert result[0] == 0

    result = matchpathcon('/etc/shadow', 7)
    assert isinstance(result[0], int)
    assert isinstance(result[1], str)

    assert result[0] == 0



# Generated at 2022-06-24 21:24:55.718664
# Unit test for function matchpathcon
def test_matchpathcon():

    path = "/tmp"
    mode = 1

    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    print(to_native(con.value))
    assert rc == 0



# Generated at 2022-06-24 21:24:59.154204
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = "/etc/nsswitch.conf"
    var_2 = lgetfilecon_raw(var_1)
    assert var_2[0] == 0
