

# Generated at 2022-06-24 21:17:06.562667
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux/config'
    # FIXME: add asserts
    rc, con = lgetfilecon_raw(path)


# Generated at 2022-06-24 21:17:14.863084
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = None
    var_1 = ['', None]
    # lgetfilecon_raw: <class 'ansible.errors.AnsibleError'>: SELinux is not enabled on this host.  Missing libselinux1 package?
    with pytest.raises(AnsibleError) as excinfo:
        lgetfilecon_raw(path)
    assert to_native(excinfo.value) == 'SELinux is not enabled on this host.  Missing libselinux1 package?'


# Generated at 2022-06-24 21:17:23.057267
# Unit test for function matchpathcon
def test_matchpathcon():
    # Path to test file relative to data directory
    testfile = 'testfile'
    # Path to data directory containing test file
    datadir = 'testdata'
    path = os.path.join(datadir, testfile)    
    
    try:
        # Get test file context as defined in policy
        var_0 = matchpathcon(path, 0)
    except OSError as e:
        # Fail test if there is an error getting test file context
        assert False, 'Got error {0}'.format(str(e))


# Generated at 2022-06-24 21:17:26.436167
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon = ansible_module.matchpathcon
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('.lib', 0) == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-24 21:17:27.610559
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: the following should be an integration test
    pass

# Generated at 2022-06-24 21:17:30.813987
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/any/test.txt"
    result = lgetfilecon_raw(path)
    assert result[0] == 0
    assert result[1] is not None


# Generated at 2022-06-24 21:17:32.794526
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/home/user", 0) == [0, 'user_home_t']

# Generated at 2022-06-24 21:17:34.213240
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(None, None) == [None, None]


# Generated at 2022-06-24 21:17:39.380890
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon("/etc/passwd",0)
    assert ret[1] == "etc_t"
    ret = matchpathcon("/etc/passwd",2)
    assert ret[1] == "etc_t"
    ret = matchpathcon("/etc/passwd",1)
    assert ret[1] == "etc_t"



# Generated at 2022-06-24 21:17:48.877822
# Unit test for function matchpathcon

# Generated at 2022-06-24 21:17:53.984108
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/file.txt'
    try:
        f = open(path, 'a')
        f.write('Test Content')
        f.close()
    except OSError:
        assert False

    try:
        var_0 = lgetfilecon_raw(path)
        assert var_0[0] == 0
    except OSError:
        assert False
    finally:
        os.remove(path)


# Generated at 2022-06-24 21:17:59.798209
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        path = "foo/bar"
        mode = 0
        assert matchpathcon(path, mode) == [0, "system_u:object_r:foo_t"]
        path = "/dev/null"
        mode = 0
        assert matchpathcon(path, mode) == [0, "system_u:object_r:null_device_t"]
    except Exception as ex:
        print(ex)
        assert False, "Unhandled exception during test"


# Generated at 2022-06-24 21:18:03.002898
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert not lgetfilecon_raw(None)


# Generated at 2022-06-24 21:18:05.405048
# Unit test for function matchpathcon
def test_matchpathcon():
    data = matchpathcon('/bin/ping', 0)
    assert data[0] == 0
    assert data[1] == 'system_u:object_r:bin_t:s0'



# Generated at 2022-06-24 21:18:11.217945
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r = lgetfilecon_raw(b'/path')
    assert r[0] == 0
    assert isinstance(r[1], str)


# Generated at 2022-06-24 21:18:14.563632
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp'
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:tmp_t:s0']


# Generated at 2022-06-24 21:18:15.107201
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon('/etc/mtab', 1)

# Generated at 2022-06-24 21:18:16.554035
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = ""
    assert lgetfilecon_raw(path) == []


# Generated at 2022-06-24 21:18:19.624928
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp'
    resp = lgetfilecon_raw(path)
    if not resp[0] == 0:
        raise Exception('file context could not be retrieved (rc={})'.format(resp[0]))
    if not resp[1]:
        raise Exception('invalid file context: {}'.format(resp[1]))


# Generated at 2022-06-24 21:18:28.950748
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    src = tempfile.mktemp()
    tgt = tempfile.mktemp()
    open(src, 'a').close()
    os.chmod(src, 0o644)
    os.chown(src, os.getuid(), os.getuid())
    shutil.copy(src, tgt)

    # expected is "unlabeled"
    con = lgetfilecon_raw(tgt)[1]

    assert con is not None
    # FIXME: this check will fail until https://github.com/karelzak/util-linux/pull/818 is merged
    # assert con == "unlabeled"
    # FIXME: in the mean time we'll check for the start of the SELinux context
    assert con.startswith('unlabeled_t')

    # FIXME: for context, this

# Generated at 2022-06-24 21:18:38.583490
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (errno, ctx) = lgetfilecon_raw("/etc/passwd")
    assert errno == 0
    assert ctx == "system_u:object_r:etc_t:s0"
    (errno, ctx) = lgetfilecon_raw("/etc/nonexistent_file")
    assert errno == -1



# Generated at 2022-06-24 21:18:43.755686
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp'
    mode = 0
    rc = matchpathcon(path, mode)
    assert rc == [0, b'system_u:object_r:user_tmp_t:s0']



# Generated at 2022-06-24 21:18:50.929034
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This testcase is meant to generate a nul byte after the string
    # since nul bytes are not supported in C strings, this should cause
    # the buffer to be freed within the function.
    path = b"/selinux/null\x00\x00\x00\x00"
    assert lgetfilecon_raw(path) == [0, b'']

    # In this testcase, it should succeed, and index should be 0
    path = b"/selinux/null\x00\x00\x00\x01"
    assert lgetfilecon_raw(path) == [0, b'user_u:role_r:type_t:s0']



# Generated at 2022-06-24 21:18:53.105607
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/var/log/messages")


# Generated at 2022-06-24 21:18:57.983012
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/', '0')


# Generated at 2022-06-24 21:18:58.616182
# Unit test for function matchpathcon
def test_matchpathcon():
    pass


# Generated at 2022-06-24 21:19:06.151193
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw('/etc') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']
    assert lgetfilecon_raw('/home/user1') == [0, 'unconfined_u:object_r:user_home_t:s0']
    assert lgetfilecon_raw('/nonexistent') == [-2, '']
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']
    assert l

# Generated at 2022-06-24 21:19:08.112699
# Unit test for function matchpathcon
def test_matchpathcon():
    filename = '/tmp/test_file'
    mode = 0
    matchpathcon(filename, mode)


# Generated at 2022-06-24 21:19:10.534459
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/test', 0) == [0, 'system_u:object_r:tmp_t:s0\n']



# Generated at 2022-06-24 21:19:17.504764
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux/config'
    # Test of call to function 'lgetfilecon_raw'
    try:
        assert lgetfilecon_raw(path) == [0, 'system_u:object_r:etc_t:s0']
    except AssertionError:
        raise AssertionError(lgetfilecon_raw(path))


# Generated at 2022-06-24 21:19:28.947943
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/pam.d/su"
    rc, con = lgetfilecon_raw(path)
    if rc != 0:
        raise Exception("Test failed; expected lgetfilecon_raw to return 0, got: %d" % rc)
    assert con.startswith("system_u:object_r:etc_t:s0")


# Generated at 2022-06-24 21:19:31.164747
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/foo'
    mode = 0o644
    context = matchpathcon(path, mode)[1]


# Generated at 2022-06-24 21:19:41.039953
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    fname = os.path.join(root, 'test', 'utils', 'module_utils', 'selinux.py')
    rc, res = lgetfilecon_raw(fname)
    assert rc == 0
    # NB: this is RHEL8 specific
    assert res.split(':')[2] == 'system_u:object_r:usr_t:s0'

    rc, res = lgetfilecon_raw(os.path.dirname(fname))
    assert rc == 0
    # NB: this is RHEL8 specific

# Generated at 2022-06-24 21:19:45.893203
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    flag_0 = lgetfilecon_raw(path="/etc/services")
    sys.stdout.flush()
    assert flag_0 == [0, u'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:19:50.144480
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/foo.txt', 0) == [
        0,
        'user_tmp_t'
    ], "matchpathcon('/tmp/foo.txt', 0) should be [0, 'user_tmp_t']"


# Generated at 2022-06-24 21:19:57.235973
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test against the examples from the manpage
    rc, con = matchpathcon('/home/joe/file', 0)
    assert con == 'user_home_t'

    rc, con = matchpathcon('/home/joe/file', 0o755)
    assert con == 'user_home_t'

    rc, con = matchpathcon('/home/joe/file', 0o666)
    assert con == 'user_home_t'


# Generated at 2022-06-24 21:20:06.276211
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']
    assert lgetfilecon_raw('/selinux') == [0, 'system_u:object_r:sysfs_t:s0']
    assert lgetfilecon_raw('/selinux/dummy') == [-1, 'system_u:object_r:sysfs_t:s0']
    assert lgetfilecon_raw('/xxx/dummy') == [-1, 'system_u:object_r:sysfs_t:s0']



# Generated at 2022-06-24 21:20:11.432165
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw.__func__.restype is int
    assert lgetfilecon_raw.__func__.argtypes == [type(b''), ctypes.POINTER(ctypes.c_char_p)]


# Generated at 2022-06-24 21:20:17.095132
# Unit test for function matchpathcon
def test_matchpathcon():
    with pytest.raises(OSError):
        matchpathcon(None, -1)
    with pytest.raises(OSError):
        matchpathcon(None, 0)
    with pytest.raises(OSError):
        matchpathcon('/', -1)
    with pytest.raises(OSError):
        matchpathcon('/', 0)
    with pytest.raises(OSError):
        matchpathcon('/etc', -1)
    with pytest.raises(OSError):
        matchpathcon('/etc', 0)

# Generated at 2022-06-24 21:20:18.763115
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        print('0')

    elif is_selinux_mls_enabled():
        print('1')

    else:
        print(matchpathcon('', 0))


# Generated at 2022-06-24 21:20:35.419507
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon('/tmp/testfile.txt', 0)
    if len(var_1) != 2:
        raise AssertionError()
    if type(var_1[0]) is not int or var_1[0] != 0:
        raise AssertionError()
    if len(var_1[1]) == 0:
        raise AssertionError()


# Generated at 2022-06-24 21:20:36.973459
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/bin/ls')
    assert var_1[0] == 0, "Failed to read constraints from file."
    assert var_1[1] is not None, "Failed to get constraints for file."


# Generated at 2022-06-24 21:20:42.616300
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/test', 1) == [0, 'system_u:object_r:user_tmp_t:s0']

# Generated at 2022-06-24 21:20:48.691408
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/'
    result = lgetfilecon_raw(path)
    assert(result[1] == 'unconfined_u:object_r:user_tmp_t:s0')


# Generated at 2022-06-24 21:20:50.344383
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/path/to/file')

# Generated at 2022-06-24 21:20:56.384004
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/selinux/logsemanage.conf"
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        return [rc, to_native(con.value)]
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-24 21:20:59.210887
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0o777
    var_1 = matchpathcon(path, mode)
    assert var_1 == [0, "system_u:object_r:passwd_file_t:s0"]



# Generated at 2022-06-24 21:21:06.005950
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Ensure it raises an error when the file path is invalid
    try:
        lgetfilecon_raw('/this/is/a/invalid/path')
        assert False
    except OSError as e:
        assert e.errno == 2


# Generated at 2022-06-24 21:21:07.046562
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert True


# Generated at 2022-06-24 21:21:11.097077
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('/', 0)
    assert ret[0] == 0


# Generated at 2022-06-24 21:21:44.217619
# Unit test for function matchpathcon
def test_matchpathcon():
    # No error checking
    rc = matchpathcon('/foo/bar', 0)[0]

    # Error checking
    with pytest.raises(OSError):
        matchpathcon('/foo/bad/path', 0)


# Generated at 2022-06-24 21:21:48.512669
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = '/etc/selinux/config'
    var_2 = matchpathcon(var_1, 0)
    print(var_2)
    var_3 = lgetfilecon_raw(var_1)
    print(var_3)


# Generated at 2022-06-24 21:21:50.924784
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-24 21:21:54.297614
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/bin/passwd', 0)[1] == 'system_u:object_r:bin_t:s0'



# Generated at 2022-06-24 21:21:58.684907
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw("/etc/passwd")
    print(var_1)

    assert var_1[0] == 0
    return


if __name__ == "__main__":
    test_case_0()
    test_lgetfilecon_raw()

__metaclass__ = type

# Generated at 2022-06-24 21:22:04.181870
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/home/foo", 1) == [0, 'system_u:object_r:user_home_t:s0']
    assert matchpathcon("/home/foo/bar", 1) == [0, 'system_u:object_r:user_home_t:s0']

# Generated at 2022-06-24 21:22:06.270648
# Unit test for function matchpathcon
def test_matchpathcon():
  path = '/var/www'
  mode = 0
  assert matchpathcon(path, mode) == 0


# Generated at 2022-06-24 21:22:15.149185
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/selinux.txt'
    mode_oct = '0600'

    result = to_native(os.system('touch {0}'.format(path)))
    assert not result

    result = to_native(os.system('chmod {0} {1}'.format(mode_oct, path)))
    assert not result

    result = to_native(os.system('getfattr -d -m security.selinux {0} > '.format(path) + test_lgetfilecon_raw.__name__))
    assert not result

    rc, con = lgetfilecon_raw(path)
    assert con == 'unconfined_u:object_r:user_tmp_t:s0'
    assert rc == 0


# Generated at 2022-06-24 21:22:21.389235
# Unit test for function matchpathcon
def test_matchpathcon():
    var_0 = "/usr/local"
    var_1 = 0
    assert matchpathcon(var_0, var_1)


# Generated at 2022-06-24 21:22:22.743794
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con is not None


# Generated at 2022-06-24 21:23:37.411118
# Unit test for function matchpathcon
def test_matchpathcon():
    assert _selinux_lib.matchpathcon("/sys/fs/cgroup/foo", 0) == 0


# Generated at 2022-06-24 21:23:44.233294
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon("/var/lib", 0)
    matchpathcon("/var/lib/initconfig", 0)
    matchpathcon("/var/lib/initconfig/last", 0)
    matchpathcon("/var/lib/initconfig/last/ansible_facts.fact", 0)
    matchpathcon("/var/lib/initconfig/last/ansible_facts.fact/ansible_version", 0)
    matchpathcon("/var/lib/initconfig/last/ansible_facts.fact/ansible_version/epoch", 0)
    matchpathcon("/var/lib/initconfig/last/ansible_facts.fact/ansible_version/full", 0)
    matchpathcon("/var/lib/initconfig/last/ansible_facts.fact/ansible_version/major", 0)


# Generated at 2022-06-24 21:23:46.369042
# Unit test for function matchpathcon
def test_matchpathcon():
    # Default arguments
    assert len(matchpathcon('/tmp', 0)) == 2


# Generated at 2022-06-24 21:23:50.046569
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw("/root/")
    assert var_0[0] == 0
    assert var_0[1] == "system_u:object_r:admin_home_t:s0"


# Generated at 2022-06-24 21:23:51.929056
# Unit test for function matchpathcon
def test_matchpathcon():
    assert lgetfilecon('/')[1] == 'system_u:object_r:boot_t:s0'

# Generated at 2022-06-24 21:23:54.973596
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, res = lgetfilecon_raw(path=None)
        assert res is None
        assert rc == -1

        rc, res = lgetfilecon_raw(path='/')
        assert res == "system_u:object_r:root_t:s0"
        assert rc == 0
    except ImportError:
        pass

# Generated at 2022-06-24 21:23:58.712224
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = "file_path"
    rc, result = lgetfilecon_raw(file_path)



# Generated at 2022-06-24 21:24:03.546431
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw is not None
    assert lgetfilecon_raw(u'/etc/passwd') == [0, u'system_u:object_r:etc_t:s0']
    assert isinstance(lgetfilecon_raw(b'/etc/passwd'), list)
    assert lgetfilecon_raw('/example/doesntexist') == [2, None]



# Generated at 2022-06-24 21:24:08.338659
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/bin/grep')
    assert var_1[0] == 0
    assert var_1[1] == 'system_u:object_r:bin_t:s0'


# Generated at 2022-06-24 21:24:12.247808
# Unit test for function matchpathcon
def test_matchpathcon():
    expected_return_value = [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp', 0) == expected_return_value
    expected_errno = 2
    rc, _ = matchpathcon('/tmp/foo', 0)
    assert rc == -1
    assert get_errno() == expected_errno


# Generated at 2022-06-24 21:26:56.041752
# Unit test for function matchpathcon
def test_matchpathcon():
    # Testcase variables
    path = "/"
    mode = 0

    # Testcase execution
    rc, con = matchpathcon(path, mode)

    # Testcase assertion
    assert rc == 0
    assert con == "system_u:object_r:root_t:s0"


# Generated at 2022-06-24 21:27:00.508561
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        # FIXME: could use any path (or tempfile) here
        var_1 = matchpathcon(b'/etc/passwd', 0)
        # FIXME: add assertion
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:27:03.353882
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('str', 'str') == [0, 'system_u:object_r:nfs_t:s0']
