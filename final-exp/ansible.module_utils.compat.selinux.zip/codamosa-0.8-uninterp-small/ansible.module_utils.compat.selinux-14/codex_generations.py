

# Generated at 2022-06-24 21:17:06.939786
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert [0, 'system_u:object_r:usr_t:s0'] == lgetfilecon_raw('/usr')



# Generated at 2022-06-24 21:17:08.833739
# Unit test for function matchpathcon
def test_matchpathcon():
    expected_rc = [0, 'system_u:object_r:httpd_sys_content_t:s0']
    assert matchpathcon('/var/www', -1) == expected_rc

# Generated at 2022-06-24 21:17:16.665784
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        # FIXME: somehow make this not need 'user_u:object_r:unlabeled_t:s0'
        path = '/etc/shadow'
        [rc, con] = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:shadow_t:s0'
    finally:
        if os.path.exists(path):
            os.unlink(path)


# Generated at 2022-06-24 21:17:20.848621
# Unit test for function matchpathcon
def test_matchpathcon():
    arg0 = "/path"
    arg1 = 7
    result = matchpathcon(arg0, arg1)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:var_run_t:s0'

# Generated at 2022-06-24 21:17:26.676826
# Unit test for function matchpathcon
def test_matchpathcon():
    assert isinstance(matchpathcon(None, 0), list) and isinstance(matchpathcon(None, 0)[0], int) and isinstance(matchpathcon(None, 0)[1], str)
    assert matchpathcon(None, 0)[0] == 0 and matchpathcon(None, 0)[1] == 'system_u:object_r:unlabeled_t:s0'


# Generated at 2022-06-24 21:17:34.888294
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw(b'/tmp/test.t')
    var_2 = lgetfilecon_raw(b'/tmp/test-new.t')
    var_3 = lgetfilecon_raw(b'/tmp/test-new-1.t')
    var_4 = lgetfilecon_raw(b'/tmp/test-new-2.t')
    var_5 = lgetfilecon_raw(b'/tmp/test-new-3.t')
    var_6 = lgetfilecon_raw(b'/tmp/test-new-4.t')
    var_7 = lgetfilecon_raw(b'/tmp/test-new-5.t')



# Generated at 2022-06-24 21:17:37.198842
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_1 = lgetfilecon_raw('/etc/hosts')
    assert var_1[0] == 0


# Generated at 2022-06-24 21:17:38.575732
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert not lgetfilecon_raw(None)


# Generated at 2022-06-24 21:17:43.437289
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    args = dict(
        path='/bin/bash',
    )
    if 'path' in args:
        args['path'] = to_bytes(args['path'], errors='surrogate_or_strict')
    rc = lgetfilecon_raw(**args)
    return rc


# Generated at 2022-06-24 21:17:46.427814
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/fstab"
    mode = os.stat(path).st_mode
    rc, context = matchpathcon(path, mode)
    print('Output:', rc, context)


# Generated at 2022-06-24 21:17:55.777092
# Unit test for function matchpathcon
def test_matchpathcon():
    # path to be given as argument to the function
    path = '/etc/hosts'
    mode = 0
    # Expected output is: [0, 'system_u:object_r:etc_runtime_t:s0']
    expected = [0, 'system_u:object_r:etc_runtime_t:s0']
    # Calling the function
    result = matchpathcon(path, mode)
    # Checking the actual output against expected
    assert expected == result, "Unexpected output from matchpathcon"


# Generated at 2022-06-24 21:17:57.526538
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/test_file', 0) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-24 21:18:03.613282
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    paths = ['/etc/passwd', '/var/log/lastlog']
    for path in paths:
        con = lgetfilecon_raw(path)[1]
        print(con)


# Generated at 2022-06-24 21:18:04.558545
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Not sure how we are going to test this.
    pass


# Generated at 2022-06-24 21:18:06.831266
# Unit test for function matchpathcon
def test_matchpathcon():
    in_path = 'matchpathconin_path'
    in_mode = 'matchpathconin_mode'
    #var_0 = matchpathcon(in_path, in_mode)


# Generated at 2022-06-24 21:18:09.880592
# Unit test for function matchpathcon
def test_matchpathcon():
    output = matchpathcon("/foo", 1)
    assert output[0] == 0


# Generated at 2022-06-24 21:18:15.285696
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/test_file') == [0, 'system_u:object_r:tmp_t:s0']
    assert lgetfilecon_raw('/tmp/nonexistent') == [-1, None]
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-24 21:18:17.153863
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='/tmp',mode=0) == [0, 'unconfined_u:object_r:tmp_t:s0']


# Generated at 2022-06-24 21:18:19.124695
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='') == ('', 0)


# Generated at 2022-06-24 21:18:22.799884
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'python'
    mode = 0
    rc, result = matchpathcon(path, mode)
    if rc != 0:
        raise AssertionError('cannot find path')



# Generated at 2022-06-24 21:18:28.763271
# Unit test for function matchpathcon
def test_matchpathcon():
    # Run the following code:
    # matchpathcon("/", 0)
    assert matchpathcon("/", 0) == [0, 'system_u:object_r:system_dbusd_var_run_t:s0']


# Generated at 2022-06-24 21:18:32.292588
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']


# Generated at 2022-06-24 21:18:35.794413
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(path='/foo/bar', mode=0) == [0, 'system_u:object_r:foo_bar_t:s0']



# Generated at 2022-06-24 21:18:39.651446
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = matchpathcon(to_native(b'/tmp/test'), 0)

    assert var_1[0] == 0
    assert var_1[1] == to_native(b'unconfined_u:object_r:tmp_t:s0')



# Generated at 2022-06-24 21:18:42.071961
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw('/etc/passwd')


# Generated at 2022-06-24 21:18:47.292244
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/issue', 0)
    assert not rc, 'matchpathcon return code was {0}, expected 0'.format(rc)
    assert con.startswith('system_u:object_r:xdm_home_t:'), 'con should start with "system_u:object_r:xdm_home_t:"'


# Generated at 2022-06-24 21:18:50.518524
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, value = matchpathcon('/usr/bin/python3.7', 0)
    assert rc == 0
    assert value == 'usr_t:s0-s0:c0'


# Generated at 2022-06-24 21:18:56.477199
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/foo'
    mode = 0
    rc, out = matchpathcon(path, mode)
    assert rc == 0, 'got {0}, expected 0'.format(rc)
    assert isinstance(out, str), 'got {0}, expected str'.format(type(out))
    assert out == 'none', 'got {0}, expected "none"'.format(out)


# Generated at 2022-06-24 21:18:59.264491
# Unit test for function matchpathcon

# Generated at 2022-06-24 21:19:02.255066
# Unit test for function matchpathcon
def test_matchpathcon():
    path, mode, result = '/var/', 1, ['Warning, could not determine which version of matchpathcon is available', 0, None]
    assert matchpathcon(path, mode) == result


# Generated at 2022-06-24 21:19:10.817843
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    rc, con = lgetfilecon_raw('/etc/localtime')

    assert rc == 0, "Return code is not 0; indicates failure"
    # On CentOS8, the file context is system_u:object_r:etc_t:s0
    if "etc_t" not in con:
        assert False, "File context is not expected"



# Generated at 2022-06-24 21:19:20.987570
# Unit test for function matchpathcon
def test_matchpathcon():
    # path = "/tmp/ansible-test-file8279871"
    # mode = 2173

    path = "/etc/selinux/config"
    mode = 33188

    rc, context = matchpathcon(path, mode)
    assert rc >= 0
    assert context != ''

    # path = "/tmp/ansible-test-file8279871"
    # mode = 2173

    path = "/usr/local"
    mode = 33188

    rc, context = matchpathcon(path, mode)
    assert rc >= 0
    assert context != ''

    # path = "/tmp/ansible-test-file8279871"
    # mode = 2173

    path = "/usr/local/bin"
    mode = 33188

    rc, context = matchpathcon(path, mode)

# Generated at 2022-06-24 21:19:25.689935
# Unit test for function matchpathcon
def test_matchpathcon():
    # str path: value to init the path param with
    path = 'test'
    # int mode: value to init the mode param with
    mode = 0
    # call matchpathcon with correct args
    matchpathcon(str(path), int(mode))



# Generated at 2022-06-24 21:19:28.224477
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0)[0] == 0
    assert matchpathcon('/etc/no_such_file', 0)[0] == -1


# Generated at 2022-06-24 21:19:37.195812
# Unit test for function matchpathcon
def test_matchpathcon():
    def test_matchpathcon_func_pos(path, mode):
        try:
            var_0 = matchpathcon(path, mode)
            print(var_0)
        except Exception as e:
            print(str(e))
    test_matchpathcon_func_pos(b'/tmp/baz', 0)
    test_matchpathcon_func_pos(b'/tmp/', 0)
    test_matchpathcon_func_pos(b'/tmp/foo/bar/baz', 0)


# Generated at 2022-06-24 21:19:48.017637
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/etc/passwd", 0) == [0, "system_u:object_r:etc_runtime_t"]
    assert matchpathcon("/etc/passwd", 4) == [0, "system_u:object_r:etc_runtime_t"]
    assert matchpathcon("/etc/passwd", 256) == [0, "system_u:object_r:etc_runtime_t"]
    assert matchpathcon("/etc/passwd", 260) == [0, "system_u:object_r:etc_runtime_t"]
    assert matchpathcon("/etc/passwd", 512) == [0, "system_u:object_r:etc_runtime_t"]

# Generated at 2022-06-24 21:19:50.095924
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/test'
    var_1 = lgetfilecon_raw(path)


# Generated at 2022-06-24 21:19:54.414089
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("path", 1) == [0, "system_u:object_r:etc_t:s0"]


# Generated at 2022-06-24 21:19:57.928649
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, result = lgetfilecon_raw('asdf')
    expected_result = [0, 'asdf']
    assert [rc, result] == expected_result, "%s != %s" % ([rc, result], expected_result)


# Generated at 2022-06-24 21:20:02.993376
# Unit test for function matchpathcon
def test_matchpathcon():
    assert len(matchpathcon(path='/etc/passwd', mode=0)) == 2

# Generated at 2022-06-24 21:20:13.098892
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/etc/passwd",0) == [0, "system_u:object_r:netlink_audit_socket_t:s0-s0:c0.c1023"]


# Generated at 2022-06-24 21:20:19.764714
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert os.path.exists('/etc/selinux/config') == True
    assert lgetfilecon_raw('/etc/selinux/config') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/etc/selinux/config') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/etc/selinux/config') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/etc/selinux/config') == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-24 21:20:21.214634
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path='/etc/selinux/config') == 0


# Generated at 2022-06-24 21:20:24.435498
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for matchpathcon function
    # Path of the file to be tested
    file_path = "/etc/ansible/ansible.cfg"

    mode = 0
    ret, con = matchpathcon(file_path, mode)
    if ret == 0:
        # print("The context path is %s" % con)
        return True
    else:
        # If a library error occurs, set errno and return -1.
        print("matchpathcon failed with returncode %d" % ret)
        return False


# Generated at 2022-06-24 21:20:26.954059
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path='/home') == [0, 'unconfined_u:object_r:user_home_t:s0']


# Generated at 2022-06-24 21:20:35.089981
# Unit test for function matchpathcon
def test_matchpathcon():
    my_pathname = os.path.join(os.path.dirname(os.path.realpath(__file__)), '__file__')
    if os.path.islink(my_pathname):
        print('Skipping symlink test for matchpathcon')
    else:
        var_1 = matchpathcon(my_pathname, 0)
        assert var_1 == [0, 'system_u:object_r:default_t:s0']


# Generated at 2022-06-24 21:20:40.929830
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import os
    filename = os.path.join(tempfile.gettempdir(), "ansible_selinux.XXXXXX")
    fileh = os.fdopen(os.mkstemp(suffix=filename)[0], 'w+')
    try:
        fileh.write("test content")
        fileh.close()

        con = lgetfilecon_raw(filename)[1]
        assert con is not None
    finally:
        try:
            os.remove(filename)
        except:
            pass


# Generated at 2022-06-24 21:20:43.995705
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(to_bytes('/etc/hosts'))[1] == 'system_u:object_r:etc_t:s0'
    assert lgetfilecon_raw(to_bytes('/not/a/real/file'))[0] == -1



# Generated at 2022-06-24 21:20:49.700788
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/shadow', 1) == [0, 'shadow_t']


# Generated at 2022-06-24 21:20:54.785291
# Unit test for function matchpathcon
def test_matchpathcon():
    # Run the module code with the correct arguments
    rc, con = matchpathcon("/", 0)

    # Check rc
    assert rc == 0
    # Check con
    assert con == "system_u:object_r:usr_t"



# Generated at 2022-06-24 21:21:19.223232
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path_args = ['/tmp']  # List of positional arguments
    # Path to sample data files
    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    # List of keyword arguments
    args = dict(
        )
    # in the future we may need to add an option to only run a subset of tests
    # but for now let's just run them all
    test_suite = [test_case_0,test_lgetfilecon_raw]
    test_results = []
    for test_function in test_suite:
        test_results.append(test_function(*path_args, fixtures_path=fixtures_path, **args))
    # pprint(test_results)

# Generated at 2022-06-24 21:21:23.112203
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/shadow"
    var_0 = lgetfilecon_raw(path)
    assert var_0[0] == 0
    assert not var_0[1] is None


# Generated at 2022-06-24 21:21:25.710333
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw(str("/etc/shadow"))


# Generated at 2022-06-24 21:21:29.029255
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/usr/bin/passwd"
    mode = 0
    assert matchpathcon(path, mode) == [0, "system_u:object_r:passwd_exec_t:s0"]


# Generated at 2022-06-24 21:21:34.395724
# Unit test for function matchpathcon
def test_matchpathcon():
    for path in ["/usr/bin/source", "/usr/bin/ps", "/usr/bin/ls"]:
        con = matchpathcon(path, os.stat(path).st_mode)[1]

        # make sure context is not none and does not contain '?'
        assert con is not None and not "?" in con



# Generated at 2022-06-24 21:21:36.872920
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw('/path/to/file')
    assert [0, 'system_u:object_r:tmp_t:s0'] == var_0


# Generated at 2022-06-24 21:21:40.184259
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.expanduser('~/.bash_logout')
    var_0 = lgetfilecon_raw(path)


# Generated at 2022-06-24 21:21:43.089147
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/etc/fstab", 0) == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-24 21:21:47.279775
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/var/www'
    mode = int('0755', 8)
    assert matchpathcon(path, mode) == [0, u'system_u:object_r:httpd_sys_content_t']



# Generated at 2022-06-24 21:21:57.521840
# Unit test for function matchpathcon
def test_matchpathcon():
    # con is a str
    # path is a str
    # mode is a int

    path = "/"
    mode = 0

    # 'con' is a str
    # 'rc' is a int
    con, rc = matchpathcon(path, mode)
# 'con' is a str
# 'enforcemode' is a int
# 'rc' is a int
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode == 1


# 'con' is a str
# 'rc' is a int
    rc, con = lgetfilecon_raw(path)
    assert con == "system_u:object_r:rootfs:s0"


# 'con' is a str
# 'enforcemode' is a int
# 'rc' is a int
    rc, enforcemode = selinux

# Generated at 2022-06-24 21:22:33.233429
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/foo'
    mode = 0o600
    assert _selinux_lib.matchpathcon(path, mode, byref(c_char_p())) == 0



# Generated at 2022-06-24 21:22:43.095815
# Unit test for function matchpathcon
def test_matchpathcon():
    # set up a dummy test file and its context
    dummy_file = "/tmp/test_file"
    dummy_con = "user_u:object_r:default_t"
    with open(dummy_file, "w") as f:
        f.write("")

    # set dummy file's context
    rc, _ = lsetfilecon(dummy_file, dummy_con)
    if rc == -1:
        raise RuntimeError("Failed to set dummy file context")

    # get context and compare
    result = matchpathcon(dummy_file, 0)
    assert result[0] == 0, "Failed to get the context of the test file"
    assert result[1] == dummy_con, "Failed to match the context of the test file"

    os.unlink(dummy_file)


#

# Generated at 2022-06-24 21:22:53.856510
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/log/messages', 0)[0] == 0
    assert matchpathcon('/var/log/messages', 0)[1] == 'system_u:system_r:syslogd_t:s0'
    assert matchpathcon('/var/log/messages', 2)[0] == 0
    assert matchpathcon('/var/log/messages', 2)[1] == 'system_u:object_r:syslogd_log_t:s0'
    assert matchpathcon('/var/log/messages', 5)[0] == 0
    assert matchpathcon('/var/log/messages', 5)[1] == 'system_u:system_r:syslogd_t:s0'
    assert matchpathcon('/var/log/messages', 6)[0] == 0

# Generated at 2022-06-24 21:23:00.234022
# Unit test for function matchpathcon
def test_matchpathcon():
    # arg_0 path is type str
    # arg_1 mode is type int
    # ret is type tuple
    test_path = os.path.join(os.getcwd(), 'data/testfile')
    result = matchpathcon(test_path, 0)
    assert result[0] == 0, to_native(result[1])


# Generated at 2022-06-24 21:23:03.694239
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 1 == lgetfilecon_raw(path=b'doesnt_exist')[0]



# Generated at 2022-06-24 21:23:05.669992
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw() != 0


# Generated at 2022-06-24 21:23:09.394166
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/proc/loadavg', 0)
    assert con == 'system_u:object_r:proc_sysinfo_t:s0'

# Generated at 2022-06-24 21:23:13.614045
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/root/test') != [0, None]



# Generated at 2022-06-24 21:23:15.464427
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0


# Generated at 2022-06-24 21:23:19.520282
# Unit test for function matchpathcon
def test_matchpathcon():
    var_1 = './test_dir_1'
    var_2 = 0
    var_3 = matchpathcon(var_1, var_2)
    assert var_3 == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-24 21:24:41.536572
# Unit test for function matchpathcon
def test_matchpathcon():
    test_file = __file__
    if os.path.islink(test_file):
        test_file = os.path.realpath(test_file)
    result = matchpathcon(test_file, os.R_OK)
    assert result[0] == 0, result[0]
    assert(result[1] == 'unconfined_u:object_r:admin_home_t:s0')



# Generated at 2022-06-24 21:24:46.472902
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/www', 0) == [0, 'system_u:object_r:var_t:s0']
    assert matchpathcon('/etc/rc.local', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-24 21:24:52.025641
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret_val = lgetfilecon_raw(b"/etc/passwd")
    assert ret_val[1] == 'system_u:object_r:etc_runtime_t'


# Generated at 2022-06-24 21:24:57.015628
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/test"
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:user_tmp_t:s0"


# Generated at 2022-06-24 21:24:59.725748
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filepath = b'/etc/shadow'
    rc, con = lgetfilecon_raw(filepath)
    filepath= b'/etc/shadow1'
    rc1, con1 = lgetfilecon_raw(filepath)


# Generated at 2022-06-24 21:25:06.886917
# Unit test for function matchpathcon
def test_matchpathcon():
    matches = [
        (u'/tmp/foo', 1, (0, 'system_u:object_r:user_tmp_t:s0')),
        (u'/home/foo', -1, (0, 'system_u:object_r:user_home_t:s0')),
        (u'/tmp/bar', -1, (1, None)),
    ]

    for path, mode, expected in matches:
        import selinux
        rc, con = selinux.matchpathcon(path, mode)
        assert [rc, con] == expected



# Generated at 2022-06-24 21:25:13.892719
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    var_0 = lgetfilecon_raw('var_0')
    assert var_0 == [0, 'system_u:object_r:var_t:s0']


# Generated at 2022-06-24 21:25:17.553310
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/foo/bar"
    mode = 755
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:var_run_t:s0']



# Generated at 2022-06-24 21:25:21.285418
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/ansible_selinux_test_3'
    with open(path, 'a'):
        pass
    try:
        con, rc = lgetfilecon_raw(path)
        print('{0} {1}'.format(con, rc))
    finally:
        # os.remove(path)
        pass


# Generated at 2022-06-24 21:25:27.902702
# Unit test for function matchpathcon
def test_matchpathcon():
    # string con
    con = b"system_u:object_r:usr_t:s0"
    # string path
    path = b"/usr/bin/shell"
    assert isinstance(matchpathcon(path, 0), list) == True
    assert isinstance(matchpathcon(path, 0)[0], int) == True
    assert isinstance(matchpathcon(path, 0)[1], str) == True
