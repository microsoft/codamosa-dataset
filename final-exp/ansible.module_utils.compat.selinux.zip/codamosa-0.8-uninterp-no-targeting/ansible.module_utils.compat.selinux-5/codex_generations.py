

# Generated at 2022-06-20 16:36:01.178031
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1


# Generated at 2022-06-20 16:36:02.899946
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, mode) = selinux_getenforcemode()
    assert rc >= 0
    assert mode in [0, 1, 2]


# Generated at 2022-06-20 16:36:08.450256
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import unittest

    class LgetfileconRawTest(unittest.TestCase):
        def test_lgetfilecon_raw(self):
            self.assertEqual(lgetfilecon_raw('/tmp/')[0], 0)

    suite = unittest.TestLoader().loadTestsFromTestCase(LgetfileconRawTest)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-20 16:36:14.021639
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    run with:

    python -c 'import ansible.module_utils.selinux as f;f.test_matchpathcon()'
    '''


# Generated at 2022-06-20 16:36:18.522287
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con.split(':')[0] == 'unconfined_u'
    (rc, con) = lgetfilecon_raw('/nonexistent-file')
    assert rc == -1

# Generated at 2022-06-20 16:36:20.138821
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/test', 0)[1] == 'test_etc_t'

# Generated at 2022-06-20 16:36:21.399179
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-20 16:36:23.870973
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    con = c_char_p()
    rc = _selinux_lib.selinux_getpolicytype(byref(con))
    print("PolicyType=", to_native(con.value))


# Generated at 2022-06-20 16:36:30.113871
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import shutil
    import tempfile


# Generated at 2022-06-20 16:36:32.806304
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    testfile = to_bytes(os.environ['HOME'])
    results = lgetfilecon_raw(testfile)
    assert isinstance(results[0], int)
    assert isinstance(results[1], str)



# Generated at 2022-06-20 16:36:40.535716
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Make sure the test file exists (e.g. test from git main repo, not ansible-test)
    assert os.path.exists('/usr/bin/file')
    rc, con = lgetfilecon_raw('/usr/bin/file')
    assert rc == 0

# Generated at 2022-06-20 16:36:41.900045
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']



# Generated at 2022-06-20 16:36:43.594051
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert(rc == 0)


# Generated at 2022-06-20 16:36:54.618623
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        fd = os.open('/tmp/conftest', os.O_WRONLY | os.O_CREAT)
        path = '/tmp/conftest'
    except OSError:
        if os.path.exists('/tmp/conftest'):
            os.remove('/tmp/conftest')
            if os.path.exists('/tmp/conftest'):
                raise RuntimeError('unable to remove test file /tmp/conftest')
        raise RuntimeError('Unable to create test file /tmp/conftest')


# Generated at 2022-06-20 16:36:59.646168
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test the lgetfilecon_raw function"""
    try:
        rc, con = lgetfilecon_raw('/etc/hosts')
        print('rc: ' + str(rc))
        print('con: ' + con)
        assert rc == 0
    except OSError as e:
        print('failed with %s' % e)
        assert False



# Generated at 2022-06-20 16:37:01.752140
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    out = selinux_getpolicytype()
    print(out)


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:37:07.554432
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/', 0)
    assert rc == 0
    assert con == 'root:object_r:root_t:s0'
    rc, con = matchpathcon('/dev/null', 0)
    assert rc == 0
    assert con == 'system_u:object_r:char_device_t:s0'

# Generated at 2022-06-20 16:37:10.346012
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    arg = "/etc/shadow"
    ret, val = lgetfilecon_raw(arg)
    assert ret == 0
    assert val.startswith("system_u:object_r:shadow_t:s0")


# Generated at 2022-06-20 16:37:12.299958
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert rc == 0
    assert con == 'system_u:object_r:root_t:s0'


# Generated at 2022-06-20 16:37:18.707792
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        from ansible_collections.ansible.community.tests.unit.modules.utils.selinux_test_functions import test_selinux_getpolicytype as _test_selinux_getpolicytype
    except ImportError:
        return "SKIPPED"
    else:
        return _test_selinux_getpolicytype()


# Generated at 2022-06-20 16:37:26.632019
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/bin/sh"
    file_context = "system_u:object_r:sh_exec_t:s0"
    result = lgetfilecon_raw(path)
    assert result[0] == 0
    assert result[1] == file_context

# Generated at 2022-06-20 16:37:29.044424
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/'
    result = lgetfilecon_raw(path)
    assert result[0] >= 0
    assert result[1] is not None


# Generated at 2022-06-20 16:37:33.330012
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policy] = selinux_getpolicytype()
    assert rc == 0
    assert policy == "selinux"


# Generated at 2022-06-20 16:37:37.608065
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print('testing selinux_getenforcemode')
    rc, x = selinux_getenforcemode()
    print(rc, x)



# Generated at 2022-06-20 16:37:46.434455
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test function matchpathcon
    """

    import os
    import os.path as path

    test_dir = path.abspath(path.join(os.getcwd(), 'libselinux_test'))
    rc, con = matchpathcon(test_dir, os.R_OK)
    if rc == 0:
        print('successfully get SELinux context of {} - {}'.format(test_dir, con))
    else:
        print('failed to get SELinux context of {} with error code {}'.format(test_dir, rc))
        sys.exit(1)



# Generated at 2022-06-20 16:37:52.620590
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/bin/some_exec', os.X_OK)
    assert rc == 0, 'matchpathcon failed: {0}'.format(rc)
    assert con == 'system_u:object_r:bin_t', 'Unexpected matchpathcon context: {0}'.format(con)
    print('All tests ok')


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:37:53.764199
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-20 16:37:54.856551
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())



# Generated at 2022-06-20 16:37:58.988092
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    result = lgetfilecon_raw(path)
    assert result[0] == 0
    assert result[1] == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-20 16:38:01.716512
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforce_mode = selinux_getenforcemode()

    if rc == 0:
        print("Enforce mode = {}".format(enforce_mode))
    else:
        print("Error: rc = {}".format(rc))


# Generated at 2022-06-20 16:38:18.239456
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Testing function matchpathcon')
    rc, con = matchpathcon('/', 0)
    print('/ is {} ({})'.format(con, rc))
    rc, con = matchpathcon('/', 1)
    print('/ is {} ({})'.format(con, rc))
    rc, con = matchpathcon('/', 2)
    print('/ is {} ({})'.format(con, rc))
    rc, con = matchpathcon('/', 3)
    print('/ is {} ({})'.format(con, rc))
    rc, con = matchpathcon('/bin', 0)
    print('/bin is {} ({})'.format(con, rc))
    rc, con = matchpathcon('/bin', 1)
    print('/bin is {} ({})'.format(con, rc))

# Generated at 2022-06-20 16:38:23.007973
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import unittest
    class TestSelinuxGetpolicytype(unittest.TestCase):
        def test_selinux_getpolicytype_functionality(self):
            try:
                result = selinux_getpolicytype()
            except Exception:
                result = False
            self.assertIsNotNone(result)
            self.assertEqual(isinstance(result, list), True)

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-20 16:38:30.724235
# Unit test for function matchpathcon
def test_matchpathcon():
    path = to_bytes('/test_path')
    result = matchpathcon(path, os.R_OK)
    assert result[0] == 0
    assert result[1] == to_native('system_u:object_r:unlabeled_t:s0')

    path = to_bytes('/etc/shadow')
    result = matchpathcon(path, os.W_OK)
    assert result[0] == 0
    assert result[1] == to_native('system_u:object_r:shadow_t:s0')

    path = to_bytes('')
    result = matchpathcon(path, os.R_OK)
    assert result[0] == 0
    assert result[1] == to_native('system_u:system_r:unlabeled_t:s0')


# Generated at 2022-06-20 16:38:31.695843
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert policy == 'targeted'

# Generated at 2022-06-20 16:38:33.281941
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print(selinux_getenforcemode())


if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-20 16:38:36.979991
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    lgetfilecon_raw_res = lgetfilecon_raw(b"/etc/passwd")
    assert(len(lgetfilecon_raw_res) == 2)
    assert(type(lgetfilecon_raw_res) == list)
    assert(type(lgetfilecon_raw_res[0]) == int)
    assert(type(lgetfilecon_raw_res[1]) == str)

# Generated at 2022-06-20 16:38:43.065150
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.selinux import selinux_getenforcemode

    (rc, con) = selinux_getenforcemode()
    assert rc == 0, "Unexpected return code: {}"
    assert type(con) == int, "Unexpected return type: {}".format(type(con))



# Generated at 2022-06-20 16:38:50.022028
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, policy_type = selinux_getpolicytype()
        if rc == 0:
            assert policy_type in ['targeted', 'minimum', 'mls']
        else:
            assert isinstance(policy_type, str)
    except Exception as e:
        assert False, 'Exception unexpected in test_selinux_getpolicytype: ' + str(e)



# Generated at 2022-06-20 16:38:52.549916
# Unit test for function matchpathcon
def test_matchpathcon():
    d = matchpathcon('/dev/null', 0)
    assert d[0] == 0
    assert d[1].endswith('unlabeled_t')

# Generated at 2022-06-20 16:38:56.293908
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/home/')
    assert rc == 0
    assert con == 'system_u:object_r:usr_t:s0'



# Generated at 2022-06-20 16:39:13.851933
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    testobj = selinux_getenforcemode()
    assert(2 == len(testobj))
    assert(0 == testobj[0])
    assert(1 == testobj[1])

# Generated at 2022-06-20 16:39:24.504196
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import os.path
    import tempfile
    from ansible.module_utils.basic import env_fallback
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six import PY3

    # FIXME: These values come from ansible itself, should be shared somehow
    ANSIBLE_ALLOW_TMP_FILES = "ANSIBLE_ALLOW_TMP_FILES"
    ANSIBLE_ALLOW_TMP_FILES_FALLBACK = "no"


# Generated at 2022-06-20 16:39:32.464362
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = '/tmp/selinux_test'
    try:
        rc, old_context = lgetfilecon_raw(test_file)
        rc, enforcemode = selinux_getenforcemode()
        if enforcemode != 0:
            rc, policy_type = selinux_getpolicytype()
            if rc == 0 and policy_type != 'targeted':
                raise ValueError('Unit test can only run on targeted policy type')
    except OSError:
        raise ValueError('Unit test file {} is not available'.format(test_file))
    finally:
        os.remove(test_file)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:39:37.766012
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test function selinux_getenforcemode."""
    module = sys.modules[__name__]
    func = getattr(module, 'selinux_getenforcemode')

    [rc, enforce] = func()

    if rc < 0:
        if enforce == -1:
            assert rc == 1
        else:
            assert rc == 0
    else:
        assert rc == 0



# Generated at 2022-06-20 16:39:42.171231
# Unit test for function matchpathcon
def test_matchpathcon():
    print('matchpathcon(/foo/bar, 0): %s' % matchpathcon('/foo/bar', 0))
    print('matchpathcon(/foo/bar, os.F_OK): %s' % matchpathcon('/foo/bar', os.F_OK))


# Generated at 2022-06-20 16:39:48.044594
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for successful operation
    result = matchpathcon('/var/spool/somefile', 0)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:var_spool_t:s0'

    # Test for unsuccessful operation
    result = matchpathcon('/etc/somedirectory', 0)
    assert result[0] == 2
    assert result[1] == '<<none>>:<<none>>:<<none>>:<<none>>'

# Generated at 2022-06-20 16:39:51.328179
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert policy in ('mls', 'targeted')
    # TODO: add test for delims here, if we can figure out how to provoke mlspolicy or mlsrange

# Generated at 2022-06-20 16:39:56.161202
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        # Test against an existing file
        pass
    except Exception as e:
        print('test_matchpathcon failed: ' + str(e))
        return False

    return True


if __name__ == '__main__':
    if test_matchpathcon():
        print('PASS')
    else:
        print('FAIL')

# Generated at 2022-06-20 16:40:04.146712
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    from ansible.module_utils.selinux import matchpathcon

    path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '../library',
    )
    mode = os.R_OK
    test_con = matchpathcon(path, mode)

    assert test_con[0] == 0
    assert test_con[1] == 'system_u:object_r:default_t:s0'

# Generated at 2022-06-20 16:40:05.715038
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    return selinux_getenforcemode()

# Generated at 2022-06-20 16:40:37.966898
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    test_val = selinux_getenforcemode()
    assert test_val == [0, 1] or test_val == [0, 0]



# Generated at 2022-06-20 16:40:41.152804
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    if rc == 0:
        assert mode in ('Disabled', 'Permissive', 'Enforcing')
    else:
        assert mode == 0



# Generated at 2022-06-20 16:40:43.361781
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if selinux_getenforcemode() not in ([0, 0], [0, 1]):
        raise ImportError('error running selinux_getenforcemode test')



# Generated at 2022-06-20 16:40:55.172760
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, cont = matchpathcon("/etc/passwd", os.R_OK)
    assert(rc == 0)
    assert(cont == "system_u:object_r:passwd_file_t:s0")

    rc, cont = matchpathcon("/etc/super-secret-file", 0o000)
    assert(rc == 0)
    assert(cont == "system_u:object_r:secret_file_t:s0")

    rc, cont = matchpathcon("/dev/tty1", os.R_OK)
    assert(rc == 0)
    assert(cont == "system_u:object_r:devtty_t:s0")

    rc, cont = matchpathcon("/dev/tty1", os.W_OK)
    assert(rc == 0)

# Generated at 2022-06-20 16:41:00.429433
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert to_native(_selinux_lib.selinux_getenforcemode(None)) == to_native(_selinux_lib.selinux_getenforcemode.restype) == to_native(selinux_getenforcemode()[0])
    assert to_native(_selinux_lib.selinux_getenforcemode.resttype) == to_native(selinux_getenforcemode()[0])



# Generated at 2022-06-20 16:41:10.046622
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test function lgetfilecon_raw

    file_name_1: file name passed to function lgetfilecon_raw

    expected_result_1: expected result for file_name_1
    """

    # Test case 1: test_lgetfilecon_raw_1
    file_name_1 = "/etc/init.d/httpd"
    expected_result_1 = [0, 'system_u:object_r:httpd_exec_t:s0']
    result_1 = lgetfilecon_raw(file_name_1)
    assert result_1 == expected_result_1

    # Test case 2: test_lgetfilecon_raw_2
    file_name_2 = "/etc/init.d/httpd_not_exist"
    expected_result_2 = [0, None]


# Generated at 2022-06-20 16:41:15.312080
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con_path = "/usr/sbin/semodule"
    rc, con = lgetfilecon_raw(con_path)
    if rc == 0:
        assert con == "system_u:object_r:selinux_exec_t:s0"
    else:
        print(rc)

# Generated at 2022-06-20 16:41:26.202173
# Unit test for function matchpathcon
def test_matchpathcon():
    import random
    import string

    random_file_name = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(6))
    random_file_path = '/tmp/ansible_' + random_file_name + '_selinux'
    try:
        os.mknod(random_file_path)
        con = matchpathcon(random_file_path, 0)
        assert con[0] == 0
    except OSError as e:
        pass
    finally:
        os.remove(random_file_path)



# Generated at 2022-06-20 16:41:36.652837
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil
    # Create a tmp dir with a file in it
    tmpdir = tempfile.mkdtemp()
    fname = os.path.join(tmpdir, 'file')
    with open(fname, 'w') as f:
        f.write('foo')
    # Call the function with the path to the file
    rc, con = matchpathcon(fname, 0)
    assert rc == 0
    # Cleanup
    os.remove(fname)
    os.rmdir(tmpdir)


# Generated at 2022-06-20 16:41:42.869492
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    type = selinux_getpolicytype()
    if type[0] == -1:
        print('Get policy type failed')
        sys.exit(1)
    print('Current policy type: "' + type[1] + '"')
    sys.exit(0)



# Generated at 2022-06-20 16:42:53.402010
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    results = selinux_getenforcemode()
    return results



# Generated at 2022-06-20 16:42:56.551448
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if selinux_getenforcemode()[0] != 0:
        raise AssertionError("Unable to run selinux_getenforcemode")



# Generated at 2022-06-20 16:42:59.199503
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # test 1
    assert selinux_getenforcemode()[1] in [0, 1]


# Generated at 2022-06-20 16:43:02.266933
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    e, m = selinux_getenforcemode()
    assert m in [0, 1, 2]
    assert e == 0



# Generated at 2022-06-20 16:43:04.562242
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] in ['targeted', 'mls']

# Generated at 2022-06-20 16:43:08.747497
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policy) = selinux_getpolicytype()
    assert rc == 0
    assert policy is not None
    assert policy != ''


# Generated at 2022-06-20 16:43:13.987658
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/shadow'
    [rc, con] = lgetfilecon_raw(path)
    print('rc=%d con=%s' % (rc, con))
    assert rc == 0



# Generated at 2022-06-20 16:43:18.142800
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r = lgetfilecon_raw(b'/bin/ls')
    print('rc is: ', r[0])
    print('con is: ', r[1])
    r = lgetfilecon_raw(b'/bin/bogus')
    print('rc is: ', r[0])
    print('con is: ', r[1])



# Generated at 2022-06-20 16:43:21.693259
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/tmp')
    assert isinstance(rc, int)
    assert isinstance(con, str)


# Generated at 2022-06-20 16:43:24.869921
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Enable selinux
    rc, enforcemode = selinux_getenforcemode()
    assert not rc, 'failed to get selinux mode: {0}'.format(enforcemode)
    assert enforcemode, 'selinux not enabled'

