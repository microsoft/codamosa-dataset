

# Generated at 2022-06-20 16:36:00.364399
# Unit test for function matchpathcon
def test_matchpathcon():
    pass

# Generated at 2022-06-20 16:36:02.821359
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    def test_selinux_getpolicytype_is_null():
        assert selinux_getpolicytype()[1] != 'null'

    test_selinux_getpolicytype_is_null()


# Generated at 2022-06-20 16:36:04.582733
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[0] == 0


# Generated at 2022-06-20 16:36:06.848084
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b"/etc/hosts"
    result = lgetfilecon_raw(path)
    print(result)



# Generated at 2022-06-20 16:36:09.050234
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:36:11.520496
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test function selinux_getpolicytype
    """
    assert selinux_getpolicytype()[0] == 0


# Generated at 2022-06-20 16:36:13.369232
# Unit test for function matchpathcon
def test_matchpathcon():
    # the result of this command will vary by the configuration of selinux
    path = '/etc/passwd'
    mode = os.R_OK
    result = matchpathcon(path, mode)
    assert result[0] == 0

# Generated at 2022-06-20 16:36:19.664019
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        func = lgetfilecon_raw
        rc, con = func('/etc/passwd')
        if rc != 0:
            return False, "%s('/etc/passwd') returned an error" % func.__name__
        if con == None:
            return False, "%s('/etc/passwd') returned no context" % func.__name__
    except Exception as e:
        return False, str(e)
    return True, con


# Generated at 2022-06-20 16:36:25.293152
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil

    TEST_DIR = tempfile.mkdtemp()
    TEST_FILE = "/".join((TEST_DIR, "test_file"))
    fp = open(TEST_FILE, 'w')
    fp.close()

    try:
        [rc, con] = matchpathcon(TEST_FILE, 0)
        assert rc >= 0
        assert con is not None
    finally:
        os.remove(TEST_FILE)
        os.rmdir(TEST_DIR)

# Generated at 2022-06-20 16:36:28.361778
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    label = lgetfilecon_raw('/usr/bin/python')
    assert label[0] != -1
    assert label[1] == 'system_u:object_r:bin_t:s0'

# Generated at 2022-06-20 16:36:33.776192
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if os.path.isfile('/usr/bin/semodule'):
        rc, mode = selinux_getenforcemode()
        result = {'rc': rc, 'mode': str(mode)}
    else:
        result = {"skip_reason": "skip: no selinux installed"}
    return result



# Generated at 2022-06-20 16:36:38.432300
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/group'
    mode = 0

    [rc, con] = matchpathcon(path, mode)
    print("{0}: {1}".format(rc, con))



# Generated at 2022-06-20 16:36:41.192845
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    expected = [0, 1]
    actual = selinux_getenforcemode()
    assert actual == expected, 'actual: {0}, expected: {1}'.format(actual, expected)



# Generated at 2022-06-20 16:36:43.195967
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, result = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(result, str)

# Generated at 2022-06-20 16:36:44.753713
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc >= 0
    assert mode >= 0


# Generated at 2022-06-20 16:36:46.207404
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())



# Generated at 2022-06-20 16:36:51.994995
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        # Try reading the selinux context of /etc/hosts
        rc, con = lgetfilecon_raw(b'/etc/hosts')
        assert rc == 0
        assert con == 'unconfined_u:object_r:etc_runtime_t:s0'
    except Exception as e:
        assert False, 'Failed to read the selinux context of /etc/hosts:' + str(rc) + str(e)



# Generated at 2022-06-20 16:36:54.939818
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/var/log/cron')
    if rc == 0:
        print(con)
    else:
        print('Could not get context of /var/log/cron')

# Generated at 2022-06-20 16:36:57.463911
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # This is a stub test to validate we can actually load libselinux.so
    # and call this function.
    assert selinux_getenforcemode()[0] == 0

# Generated at 2022-06-20 16:37:01.374240
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/'
    expected_con = 'system_u:object_r:file_t:s0\x00'
    rc, con = lgetfilecon_raw(path)
    res = [rc, con]

    assert res == [0, expected_con]



# Generated at 2022-06-20 16:37:08.258588
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rslt = selinux_getenforcemode()
    if rslt:
        assert rslt[0] == 0
        assert rslt[1] == 1
    else:
        assert False


# Generated at 2022-06-20 16:37:10.732785
# Unit test for function matchpathcon
def test_matchpathcon():
    if matchpathcon('/etc/selinux/targeted/contexts/files/file_contexts.homedirs', 0):
        return True
    else:
        raise ImportError('matchpathcon is broken')

# Generated at 2022-06-20 16:37:13.748239
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if not os.path.exists('/etc/selinux/config'):
        raise Exception('Can not find /etc/selinux/config')

    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policy, str)
    assert policy == 'targeted'



# Generated at 2022-06-20 16:37:24.582506
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/usr/bin/ls', os.R_OK)
    print("rc: %d" % rc)
    print("con: %s" % con)

    rc, con = matchpathcon('/var/log/messages', os.R_OK)
    print("rc: %d" % rc)
    print("con: %s" % con)

    rc, con = matchpathcon('/usr/1bin/ls', os.R_OK)
    print("rc: %d" % rc)
    print("con: %s" % con)



# Generated at 2022-06-20 16:37:27.095855
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/shadow', os.F_OK) == [0, 'system_u:object_r:shadow_t:s0']

# Generated at 2022-06-20 16:37:29.949882
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # sanity check to ensure that the function has been wired up
    assert 'selinux_getpolicytype' in dir(sys.modules[__name__])

    # call the function directly
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype.endswith(b'targeted')

# Generated at 2022-06-20 16:37:33.288743
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()

    assert rc == 0
    assert con == "targeted"

# Generated at 2022-06-20 16:37:44.349794
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if is_selinux_enabled():
        rc, mode = selinux_getenforcemode()
        if rc == 0:
            if mode == 0:
                print(to_native(u'SELinux mode is disabled'))
            elif mode == 1:
                print(to_native(u'SELinux mode is permissive'))
            elif mode == 2:
                print(to_native(u'SELinux mode is enforcing'))
            else:
                print(to_native(u'unknown SELinux mode {0}'.format(mode)))
        else:
            print(to_native(u'error getting SELinux mode'))
    else:
        print(to_native(u'SELinux is disabled'))


# Generated at 2022-06-20 16:37:47.782379
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # If a good output is received then the function is good
    # If a bad output is received then the function needs to be fixed
    enforcemode = selinux_getenforcemode()
    return enforcemode



# Generated at 2022-06-20 16:37:52.782527
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        from selinux import getenforce

        if getenforce() == 'Enforcing':
            enforcemode = 1
        else:
            enforcemode = 0

        rc, mode = selinux_getenforcemode()
        assert rc >= 0 and mode == enforcemode
    except ImportError:
        pass



# Generated at 2022-06-20 16:38:03.246274
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    test_file = os.path.join(tempfile.gettempdir(), "ansible_test_file")
    fp = open(test_file, 'wb')
    fp.close()

    rc, selinux_context = matchpathcon(test_file, 0)

    assert rc == 0

# Generated at 2022-06-20 16:38:12.513151
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = '/etc/selinux/config'
    # lgetfilecon_raw returns a tuple (errno, context)
    (rc, context) = lgetfilecon_raw(test_file)

    # Test if errno is non-negative
    assert rc >= 0, "test_lgetfilecon_raw: error code {0}".format(rc)

    # Test if context is not None
    assert context is not None, "test_lgetfilecon_raw: context is None"

    # Test if context is not an empty string
    assert context != '', "test_lgetfilecon_raw: context is an empty string"


# Generated at 2022-06-20 16:38:17.572749
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    This method is written as a test for the method matchpathcon. The method tests the following cases:

    input - path(file), mode(read only)
    output - context(user:system:role:type:level:range)
    """
    path = '/var/log/secure'
    mode = os.R_OK
    con = _selinux_lib.matchpathcon(path, mode, byref(c_char_p()))
    print(con)
    assert True

# Generated at 2022-06-20 16:38:24.815187
# Unit test for function matchpathcon
def test_matchpathcon():
    if os.path.exists('/tmp/testfile'):
        os.stat('/tmp/testfile')
    else:
        with open('/tmp/testfile', 'w') as f:
            f.write('')

    (rc, out) = matchpathcon('/tmp/testfile', 0)
    print(rc, out)
    assert rc == 0
    assert out == 'system_u:object_r:tmp_t:s0'

    (rc, out) = selinux_getpolicytype()
    print(rc, out)
    assert rc == 0
    assert out == 'targeted'

# Generated at 2022-06-20 16:38:27.341760
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/selinux/targeted/contexts/files')
    print(con)
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-20 16:38:32.246328
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/passwd'
    mode = 0
    result = matchpathcon(path, mode)
    assert result[0] == 0, result[0]
    assert result[1] == b'etc_t:object_r:passwd_file_t:s0'

# Generated at 2022-06-20 16:38:35.734758
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("Test selinux_getenforcemode ...")
    [rc, enforcemode] = selinux_getenforcemode()
    if rc == 0:
        print("  result: {0:d}".format(enforcemode))
    else:
        print("  ERROR: rc = {0:d}".format(rc))
    print()



# Generated at 2022-06-20 16:38:39.315422
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()[1]
    print("Policy Type : %s" % (policytype))


# Generated at 2022-06-20 16:38:41.235022
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == 'targeted'

# Generated at 2022-06-20 16:38:44.428375
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result, out = selinux_getpolicytype()
    assert result == 0, 'selinux_getpolicytype failed: {0}'.format(out)
    print('selinux_getpolicytype succeeded: {0}'.format(out))

# Generated at 2022-06-20 16:39:01.522352
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/'
    rc, con = lgetfilecon_raw(path)
    print(rc, con)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:39:02.989994
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/')[1] == 'system_u:object_r:root_t:s0'


# Generated at 2022-06-20 16:39:04.363990
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, mode) = selinux_getenforcemode()
    assert rc >= 0
    assert mode in [0, 1, 2]



# Generated at 2022-06-20 16:39:07.558814
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("\nselinux_getenforcemode: ", selinux_getenforcemode())
    return True



# Generated at 2022-06-20 16:39:08.822380
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0)[0] == 0

# Generated at 2022-06-20 16:39:16.557352
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import json
    import ansible.module_utils.selinux_policy
    from ansible.module_utils._text import to_text

    test_path = '/tmp/' + to_text(os.urandom(4).encode('hex'))
    rc, con = ansible.module_utils.selinux_policy.matchpathcon(test_path, 0)
    print(json.dumps({'path': test_path, 'mode': 0, 'con': con, 'rc': rc}))
    os.unlink(test_path)

# Generated at 2022-06-20 16:39:19.792450
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, value = selinux_getpolicytype()
    print('{0}, {1}'.format(rc, value))
    assert type(rc) is int
    assert type(value) is str


# Generated at 2022-06-20 16:39:21.450122
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    con = c_char_p()
    assert selinux_getpolicytype() == [0, 'mcs']

# Generated at 2022-06-20 16:39:26.247991
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', os.R_OK)[0] == 0
    assert matchpathcon('/etc/passwd', os.W_OK)[0] == 1
    assert matchpathcon('/etc/passwd', os.X_OK)[0] == 1
    assert matchpathcon('/etc/passwd', os.F_OK)[0] == 0

# Generated at 2022-06-20 16:39:30.200528
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if hasattr(_selinux_lib, 'lgetfilecon_raw'):
        import os
        from ctypes import c_char_p
        con_p = c_char_p()
        rc = _selinux_lib.lgetfilecon_raw(b'/etc/passwd', byref(con_p))
        if rc < 0:
            # fall back to getfilecon
            rc = _selinux_lib.getfilecon(b'/etc/passwd', byref(con_p))
        if rc == 0:
            print(to_native(con_p.value))



# Generated at 2022-06-20 16:40:01.270340
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-20 16:40:03.013417
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policytype) = selinux_getpolicytype()
    assert rc == 0


# Generated at 2022-06-20 16:40:06.508334
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/lib/libvirtd', 0) == [0, 'system_u:object_r:lib_t:s0']
    assert matchpathcon('/var/lib', 0) == [0, 'system_u:object_r:var_lib_t:s0']



# Generated at 2022-06-20 16:40:09.263612
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/aliases'
    rc, con = lgetfilecon_raw(path)
    assert con.startswith('unconfined_u:object_r:etc_t:s0')


# Generated at 2022-06-20 16:40:12.140366
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == 'targeted'

# Generated at 2022-06-20 16:40:14.108861
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, context] = lgetfilecon_raw("/etc/hosts")
    print("/etc/hosts context: " + context)



# Generated at 2022-06-20 16:40:21.309682
# Unit test for function matchpathcon
def test_matchpathcon():
    # We will use the file in /etc/selinux as this is always there
    rc, con = matchpathcon('/etc/selinux/config', 0)
    assert rc == 0
    # Here is some sample output: system_u:object_r:etc_t:s0
    assert con.split(':')[-1] == 's0'



# Generated at 2022-06-20 16:40:22.661560
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = _selinux_lib.selinux_getpolicytype()
    assert rc == 0
    assert policytype in ['targeted', 'minimum', 'mls']

# Generated at 2022-06-20 16:40:23.923759
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-20 16:40:25.208779
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/python')


# Generated at 2022-06-20 16:41:32.745460
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(b"/tmp/selinux.tst", byref(con))
        return [rc, to_native(con.value)]
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-20 16:41:37.038135
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    if policy_type == "targeted" and rc == 0:
        print("Test passed")
        sys.exit(0)
    else:
        print("Test failed")
        sys.exit(1)



# Generated at 2022-06-20 16:41:41.870339
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fn = './test_ctypes.py'
    rc, con = lgetfilecon_raw(fn)
    assert rc == 0
    assert con == 'system_u:object_r:usr_t:s0'

# Generated at 2022-06-20 16:41:45.481679
# Unit test for function matchpathcon

# Generated at 2022-06-20 16:41:50.789098
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("=== START test_selinux_getpolicytype ===")
    assert selinux_getpolicytype()[0] == 0, "selinux_getpolicytype return code is not 0"
    assert selinux_getpolicytype()[1] != "", "selinux_getpolicytype policy type is empty"
    print("=== END test_selinux_getpolicytype ===")



# Generated at 2022-06-20 16:41:57.579165
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Unit test for the selinux getenforcemode function
    """
    try:
        import selinux
    except ImportError:
        return

    args = selinux.selinux_getenforcemode()
    rc = args[0]
    enforcemode = args[1]

    assert rc == 0
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-20 16:42:04.815695
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("testing selinux_getpolicytype...")
    rc, con = selinux_getpolicytype()
    print("selinux_getpolicytype returned: %d %s" % (rc, con))
    if rc < 0:
        print("could not load selinux policy")
        exit(rc)


# Generated at 2022-06-20 16:42:11.357601
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    path = '/tmp/test'
    os.mkdir(path)
    rc, con = matchpathcon(path, os.R_OK)
    print('rc = {0}, con = {1}'.format(rc, con))
    os.rmdir(path)

if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-20 16:42:14.549505
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing for matchpathcon")
    [rc, con] = matchpathcon("/etc/passwd", 0)
    print("RC: %s Con: %s" % (rc, con))


# Generated at 2022-06-20 16:42:17.343399
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:44:48.515061
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Check that selinux_getenforcemode function works as expected.
    """
    (rc, mode) = selinux_getenforcemode()
    assert rc == 0
    assert mode in [0, 1, 2]
    assert type(mode) is int


# Generated at 2022-06-20 16:44:58.859082
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing function matchpathcon")
    ret = matchpathcon("/var/log/audit", os.stat("/var/log/audit").st_mode)
    if ret[0] != 0:
        print("Failed to match valid path")
        sys.exit(1)

    ret = matchpathcon("/var/log/invalid", os.stat("/var/log/audit").st_mode)
    if ret[0] == 0:
        print("Matched invalid path")
        sys.exit(1)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:45:03.447811
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype_str = selinux_getpolicytype()
    assert rc == 0, "Policytype error code incorrect for selinux_getpolicytype"


# Generated at 2022-06-20 16:45:05.121826
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    return [rc, con]



# Generated at 2022-06-20 16:45:07.915604
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = '/etc/hosts'
    result = lgetfilecon_raw(filename)
    print(result)


# Generated at 2022-06-20 16:45:15.544669
# Unit test for function matchpathcon
def test_matchpathcon():
    sys.stdout.write("Testing SELinux\n")
    # Check if the Python bindings properly work
    # Should not raise any exception
    is_selinux_enabled()
    is_selinux_mls_enabled()
    security_getenforce()
    security_policyvers()
    test_path = os.getcwd() + "/selinux_helpers.py"
    sys.stdout.write("Testing matchpathcon on path %s\n" % test_path)
    rc, result = matchpathcon(test_path, 0)
    sys.stdout.write("Result: %s (rc=%s)\n" % (result, rc))
    sys.stdout.write("Testing selinux_getenforcemode\n")
    rc, result = selinux_getenforcemode()
   

# Generated at 2022-06-20 16:45:18.635955
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert None is selinux_getenforcemode()[1]


# Generated at 2022-06-20 16:45:27.185871
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import TemporaryFile
    from distutils.spawn import find_executable
    from shutil import which
    from ansible.module_utils._text import to_bytes

    context = []

    if find_executable('ps') is not None:
        context = to_native(to_bytes(os.popen('ps -Z 2>/dev/null | grep ^init | head -1 | tr -s " " | cut -d" " -f5').read().strip()))

    if not context:
        context = 'system_u:system_r:init_t:s0'

    tfile = TemporaryFile()
    fpath = tfile.name

# Generated at 2022-06-20 16:45:30.361218
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    RC, TYPE = selinux_getpolicytype()
    assert RC == 0, "Return code must be 0. Got %d." % RC
    assert TYPE == 'targeted', "SELinux type must be targeted. Got %s." % TYPE

# Generated at 2022-06-20 16:45:32.224280
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if not selinux_getpolicytype()[1]:
        return 1
