

# Generated at 2022-06-20 16:36:03.462159
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype is not None
    assert policytype != ''

# Generated at 2022-06-20 16:36:08.950744
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('\nTesting selinux_getpolicytype(...)')
    rc, policytype = selinux_getpolicytype()
    print('rc:', rc)
    print('policytype:', policytype)
    assert rc == 0, 'rc should be 0'
    assert len(policytype) > 0, 'policytype should not be empty'
    assert policytype == 'targeted', 'policytype should be targeted'



# Generated at 2022-06-20 16:36:12.233491
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """Test selinux_getpolicytype function."""
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'



# Generated at 2022-06-20 16:36:16.132876
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    # Check return code
    if rc == 0:
        print('SELinux context for /etc/passwd is', con)
    else:
        print('lgetfilecon_raw failed with error:', rc)


# Generated at 2022-06-20 16:36:23.184861
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/shadow'
    mode = 4
    se_context = matchpathcon(path, mode)
    assert isinstance(se_context, list)
    assert se_context[0] == -1
    se_context_string = se_context[1]
    expected_se_context_string = 'system_u:object_r:shadow_t:s0'
    assert se_context_string == expected_se_context_string

# Generated at 2022-06-20 16:36:25.550054
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("Running unit test for function selinux_getenforcemode")
    v, retval = selinux_getenforcemode()
    print("retval: ", retval)
    assert type(retval) == int


# Generated at 2022-06-20 16:36:30.665457
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    path_to_test = "/sys"
    context = matchpathcon(path_to_test, 0)[1]
    assert context == "system_u:object_r:sysfs_t:s0", "Context for {0} should be 'system_u:object_r:sysfs_t:s0' but it is '{1}'".format(path_to_test, context)


# Generated at 2022-06-20 16:36:34.921503
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    The below file used to cause a segmentation fault when using function lgetfilecon_raw.
    The file was modified to have a different SELinux context.
    This test should pass and not cause segmentation fault
    """
    result, value = lgetfilecon_raw('/var/log/kern.log')
    assert result == 0 and value == 'system_u:object_r:var_log_t:s0'

# Generated at 2022-06-20 16:36:38.370698
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-20 16:36:43.601818
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = 'tests/data/hello_world'
    (rc, con) = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_tmp_t:s0'
    path = 'tests/data/some_root_file'
    (rc, con) = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'unconfined_u:object_r:etc_t:s0'



# Generated at 2022-06-20 16:36:49.575941
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Test for function selinux_getpolicytype
    print('selinux_getpolicytype:', selinux_getpolicytype())


if __name__ == '__main__':
    # Unit test for the selinux python bindings, using ctypes
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:36:51.673364
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, val) = selinux_getenforcemode()
    assert rc == 0
    assert val in [0, 1, 2]


# Generated at 2022-06-20 16:36:55.595000
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/python3') == [0, 'system_u:object_r:bin_t:s0\n']
    assert lgetfilecon_raw('/usr/bin/python3-minimal') == [0, 'system_u:object_r:bin_t:s0\n']

# Generated at 2022-06-20 16:36:58.962387
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    if not (isinstance(result[0], int) and isinstance(result[1], int)):
        raise AssertionError()


# Generated at 2022-06-20 16:37:01.568033
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enf_mode, rc = selinux_getenforcemode()
    assert enf_mode in [0, 1, 2], enf_mode


# Generated at 2022-06-20 16:37:04.929882
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/hosts')
    assert rc == 0
    assert con == 'system_u:object_r:net_conf_t:s0'



# Generated at 2022-06-20 16:37:07.573808
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if not selinux_getpolicytype()[1] == 'targeted':
        raise Exception('Policy is not configured for targeted mode.')



# Generated at 2022-06-20 16:37:11.964659
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for directory
    test_path = '/etc/'
    test_mode = 0

    rc, value = lgetfilecon_raw(test_path)
    assert(rc == 0)

    rc, value = matchpathcon(test_path, test_mode)
    assert(rc == 0)

    # Test for file
    test_path = '/etc/passwd'
    test_mode = 0

    rc, value = lgetfilecon_raw(test_path)
    assert(rc == 0)

    rc, value = matchpathcon(test_path, test_mode)
    assert(rc == 0)

# Generated at 2022-06-20 16:37:18.151891
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    if rc is not 0:
        raise Exception('rc is not equal to 0')
    if policytype is 'selinuxfs':
        raise Exception('policytype is selinuxfs')
    if policytype is not 'targeted':
        raise Exception('policytype is not equal to targeted')


# Generated at 2022-06-20 16:37:28.776286
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        # Valid call to selinux_getpolicytype
        (ret, policy_type) = selinux_getpolicytype()
        # Verify return code is 0
        assert ret == 0, \
            "selinux_getpolicytype function should return 0 on success, but returned %d instead" \
            % ret
        # Verify policy type returned is known
        assert policy_type in ['targeted', 'strict', 'mls'], \
            "selinux_getpolicytype function returned unexpected policy type: %s" \
            % policy_type
    except NotImplementedError:
        # This is thrown if the wrapper functions aren't there
        assert False, "Error calling selinux_getpolicytype"

# Generated at 2022-06-20 16:37:33.025198
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    return _selinux_lib.selinux_getpolicytype()

# Generated at 2022-06-20 16:37:35.654119
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = '/etc/passwd'
    rc, con = lgetfilecon_raw(file)
    print('con: ' + con)



# Generated at 2022-06-20 16:37:39.362057
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/selinux'
    mode = os.R_OK | os.W_OK | os.X_OK
    value = matchpathcon(path, mode)
    assert value


# end unit test


# Generated at 2022-06-20 16:37:42.457078
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        is_selinux_enabled()
    except OSError:
        return True

    assert selinux_getpolicytype()[0] == 0

# Generated at 2022-06-20 16:37:45.993676
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.selinux_policy import selinux_getpolicytype
    res = selinux_getpolicytype()
    print(res)

test_selinux_getpolicytype()

# Generated at 2022-06-20 16:37:48.605609
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    out_data = selinux_getpolicytype()
    print(out_data)


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:37:51.376710
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-20 16:37:52.709333
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [1, 0]


# Generated at 2022-06-20 16:37:55.035715
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    expected = [0, 1]
    from ansible.module_utils.selinux_python3 import selinux_getenforcemode
    assert selinux_getenforcemode() == expected


# Generated at 2022-06-20 16:38:00.064112
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    os.close(fd)

    # Make sure we get a context back
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con is not None

    # Cleanup
    os.remove(path)

# Generated at 2022-06-20 16:38:09.366940
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test if we can get a policy context for an arbitrary path
    """
    # con = ctypes.cast(None, ctypes.c_char_p)
    try:
        result = matchpathcon('.', 0)
        print(result)
    except OSError as e:
        print(e.errno, e.strerror)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:38:13.040416
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/'
    output = lgetfilecon_raw(path)
    assert(output[0] == 0)
    assert(output[1] == 'system_u:object_r:root_t:s0')

# Generated at 2022-06-20 16:38:20.927948
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # get the selinux context of /etc/passwd file
    rc, selinux_context = lgetfilecon_raw(b'/etc/passwd')
    # check if the operation was successful or not
    if rc < 0:
        if rc == -1:
            if os.errno == os.ENOENT:
                print('No such file found')
            else:
                print('Some internal error occured: {}'.format(to_native(os.strerror(rc))))
        else:
            print('Some internal error occured: {}'.format(to_native(os.strerror(rc))))
    else:
        print('SELinux context for /etc/passwd file is: {}'.format(to_native(selinux_context)))



# Generated at 2022-06-20 16:38:23.388650
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, 'selinux_getpolicytype returned error'
    assert to_native(policytype) == 'targeted', 'selinux_getpolicytype returned incorrect policy type'

# Generated at 2022-06-20 16:38:26.743747
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    tf.write(b'testfile')
    tf.close()
    rc, con = lgetfilecon_raw(tf.name.encode('utf-8'))
    assert rc == 0
    assert b'unconfined_u:object_r:user_tmp_t:' in con.encode('utf-8')
    tf.close()

# Generated at 2022-06-20 16:38:34.577107
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    path = '/etc/selinux/config'
    mode = 0
    if os.path.isfile(path):
        rc = selinux_getenforcemode()[0]
        assert rc == 0
        rc = selinux_getpolicytype()[0]
        assert rc == 0
        rc = lgetfilecon_raw(path)[0]
        assert rc == 0
        rc = matchpathcon(path, mode)[0]
        assert rc == 0

# Generated at 2022-06-20 16:38:45.707403
# Unit test for function matchpathcon
def test_matchpathcon():
    assert len(matchpathcon('/lib/libc-2.28.so', 0)) == 2
    assert len(matchpathcon('/lib/libc.so.6', 0)) == 2
    assert len(matchpathcon('/lib/libc-2.28.so', -1)) == 2
    assert len(matchpathcon('/lib/libc.so.6', -1)) == 2
    assert len(matchpathcon('/lib/libc-2.28.so', 0x0ff)) == 2
    assert len(matchpathcon('/lib/libc.so.6', 0x0ff)) == 2

    assert len(matchpathcon('/lib/libc-2.28.so', 0)) == 2
    assert len(matchpathcon('/lib/libc.so.6', 0)) == 2

# Generated at 2022-06-20 16:38:49.600084
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    expected = [0, 1]
    actual = selinux_getenforcemode()
    assert actual == expected, \
        "selinux_getenforcemode returned: {0} expected: {1}".format(actual, expected)


# Generated at 2022-06-20 16:38:52.295350
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/etc/mytestfile'
    test_mode = 0

    result = matchpathcon(test_path, test_mode)
    print(result)


# Generated at 2022-06-20 16:38:57.390964
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0, 'function call failed (rc=%i)' % rc
    assert enforcemode in (0, 1, 2), 'function call returned unexpected value (enforcemode=%i)' % enforcemode
    # FIXME: actually determine if selinux is permissive or enforcing


# Generated at 2022-06-20 16:39:06.583045
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, tp = selinux_getpolicytype()
    if rc != 0:
        raise OSError(rc, 'selinux_getpolicytype failed with code: {0}'.format(rc))
    return tp

# Generated at 2022-06-20 16:39:11.136868
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # TODO: This test needs to be extended. We should be
    # getting a context from the filesystem, then calling
    # lsetfilecon() to change it to a known constant, then
    # calling lgetfilecon_raw() to verify it.

    path = b'/'
    c = lgetfilecon_raw(path)
    print(c)



# Generated at 2022-06-20 16:39:13.570091
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert policy_type is not None
    assert rc in [0, 1]



# Generated at 2022-06-20 16:39:23.035362
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        import sys
        path = "/var/log/syslog"
        mode = os.R_OK
        rc, type = matchpathcon(path, mode)
        if rc:
            raise Exception("Unable to match type for {0}".format(path))
        print("Context for path={0} is {1}".format(path, type))
        if type == "unlabeled_t":
            raise Exception("Context for /var/log/syslog should not be unlabeled_t")

    except Exception as e:
        print(e)
        sys.exit(1)



# Generated at 2022-06-20 16:39:27.784337
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import selinux

    test_file_path = os.path.join(os.path.dirname(__file__), 'test-file')

    with patch.object(selinux, 'lstat', return_value=dict(st_mode=0o100644)):
        assert selinux.matchpathcon(test_file_path, 0o100644) == [0, 'unconfined_t']


# Generated at 2022-06-20 16:39:33.251334
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))
    return [rc, enforcemode]



# Generated at 2022-06-20 16:39:35.449498
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert ['0', 'system_u:object_r:usr_t:s0'] == lgetfilecon_raw('/usr')

# Generated at 2022-06-20 16:39:45.626343
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Test selinux_getpolicytype function
    [rc1, value1] = selinux_getpolicytype()
    print("selinux_getpolicytype: %d %s" % (rc1, value1))

    # Test selinux_getenforcemode function
    [rc2, value2] = selinux_getenforcemode()
    print("selinux_getenforcemode: %d %s" % (rc2, value2))

    # Test lgetfilecon_raw function
    [rc3, value3] = lgetfilecon_raw("/proc/version")
    print("lgetfilecon_raw: %d %s" % (rc3, value3))

    # Test matchpathcon function
    [rc4, value4] = matchpathcon("/proc/version", 0)

# Generated at 2022-06-20 16:39:48.082487
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("selinux_getenforcemode: rc={} enforcemode={}".format(rc, enforcemode))



# Generated at 2022-06-20 16:39:49.945942
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    getpolicytype = selinux_getpolicytype()
    assert getpolicytype[0] == 0
    assert getpolicytype[1] == 'selinux'

# Generated at 2022-06-20 16:39:57.966973
# Unit test for function matchpathcon
def test_matchpathcon():
    filepath = b"/var/run/import/content/c5"
    filemode = 0
    assert matchpathcon(filepath, filemode)[1] == 'system_u:object_r:var_run_t:s0'

# Generated at 2022-06-20 16:40:04.479970
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create a tmp file
    path = '/var/tmp/.__test_selinux__'
    open(path, 'w').close()

    # Get the file context
    con_info = _selinux_lib.lgetfilecon_raw(path, None)
    print(con_info)

    # Clean
    os.remove(path)

# Call unit test
test_lgetfilecon_raw()

# Generated at 2022-06-20 16:40:06.904487
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Check that the function returns 0 or 1. Returning either 0 or 1
    # indicates a successful return code for this function
    assert selinux_getenforcemode()[0] in (0, 1)



# Generated at 2022-06-20 16:40:12.536304
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    # Create temporary directory for testing
    tempdir = tempfile.mkdtemp()

    # Get current context
    retval, con = lgetfilecon_raw(tempdir)
    assert retval == 0

    # Change context
    retval = lsetfilecon(tempdir, con)
    assert retval == 0

    # Get context (using matchpathcon)
    retval, con = matchpathcon(tempdir, 0)
    assert retval == 0

    # clean up
    os.rmdir(tempdir)



# Generated at 2022-06-20 16:40:16.140360
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/home/foo")
    assert rc == 0
    assert con == "system_u:object_r:user_home_dir_t:s0"



# Generated at 2022-06-20 16:40:18.071034
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print(lgetfilecon_raw(b'/tmp'))


# Generated at 2022-06-20 16:40:21.766518
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filepath = os.path.expanduser("~")
    assert lgetfilecon_raw(filepath)[0] == 0, "lgetfilecon_raw failed"


# Generated at 2022-06-20 16:40:25.515414
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    if rc < 0:
        raise AssertionError('selinux_getpolicytype failed with rc {0}'.format(rc))
    print('selinux_getpolicytype succeeded with rc {0}: {1}'.format(rc, con))



# Generated at 2022-06-20 16:40:28.923868
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforce = selinux_getenforcemode()
    assert enforce[0] == 0
    assert enforce[1] in [0, 1, 2]



# Generated at 2022-06-20 16:40:36.983183
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        (rc, con) = lgetfilecon_raw('/etc/passwd')
    except OSError as e:
        if e.errno == errno.EINVAL:
            print("SELinux is not enabled")
        else:
            print("Error: {}".format(e))
        assert False
    else:
        assert True
        # Verify that the context is a valid SELinux context
        m = re.match(r'^(?:unlabeled|system_u:object_r:{1}:{1}:s0)/{0,2}', con)
        if m:
            assert True
        else:
            assert False



# Generated at 2022-06-20 16:40:43.239017
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == 'selinux'


# Generated at 2022-06-20 16:40:51.649117
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Function selinux_getpolicytype:
    #   selinux_getpolicytype() => ['type', 0]
    #   selinux_getpolicytype => ['type', 0]
    #   selinux_getpolicytype => ['type', 0]
    #   selinux_getpolicytype => ['type', 0]
    #   selinux_getpolicytype => ['type', 0]
    #   selinux_getpolicytype => ['type', 0]
    #   selinux_getpolicytype => ['type', 0]
    assert selinux_getpolicytype() == ['targeted', 0]



# Generated at 2022-06-20 16:41:00.197274
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import selinux

    if not selinux.is_selinux_enabled():
        print("Abort: SELinux not enabled")
        return -2

    curpath = os.path.dirname(os.path.realpath(__file__))
    rc, con = matchpathcon(curpath, os.R_OK)
    if rc != 0:
        print("Failed to get context: {}".format(con))
        return -1

    print("The context of {} is {}".format(curpath, con))
    return 0


if __name__ == '__main__':
    sys.exit(test_matchpathcon())

# Generated at 2022-06-20 16:41:09.860253
# Unit test for function matchpathcon
def test_matchpathcon():
    import os, tempfile
    os.environ['LANG'] = 'C'
    # Reuse Ansible tempdir code to avoid creating file on filesystem
    testfile = tempfile.NamedTemporaryFile(delete=False, prefix='ansible_test_selinux', dir=None)
    testdir = tempfile.TemporaryDirectory(prefix='ansible_test_selinux')
    try:
        rc, con = matchpathcon(testfile.name, os.R_OK)
        if rc == 0:
            print(con)

        rc, con = matchpathcon(testdir.name, os.R_OK)
        if rc == 0:
            print(con)
    finally:
        testfile.close()
        testdir.cleanup()

if __name__ == '__main__':
    test_

# Generated at 2022-06-20 16:41:14.933714
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    if rc != 0:
        raise Exception('return value should have been 0, but was %d ' % rc)
    if not policytype:
        raise Exception('policytype should not have been empty')
    return policytype

# Generated at 2022-06-20 16:41:17.136537
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Expects existence of /etc/selinux/config
    rc, con = lgetfilecon_raw("/etc/selinux/config")
    assert rc == 0
    assert con == "etc_t"


# Generated at 2022-06-20 16:41:24.832961
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from os import getuid
    from os.path import abspath, dirname, join

    if getuid() != 0:
        raise AssertionError('Must be root for this test')
    # selinux_getenforcemode() return code should be 0 when in enforcing mode
    if selinux_getenforcemode()[0] != 0:
        raise AssertionError("selinux enforcing mode is not on!")



# Generated at 2022-06-20 16:41:29.930102
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Ensure that selinux is enabled
    if is_selinux_enabled() != 1:
        raise ImportError("selinux is not enabled")

    # Ensure that path is valid
    path = "/etc/passwd"
    if not os.access(path, os.F_OK):
        raise ImportError("file %s does not exist" % path)

    # Call function
    result = lgetfilecon_raw(path)

    assert len(result) == 2, \
        "length of result array should be 2, but is %d" % len(result)
    assert result[0] == 0, \
        "first element of result array should be 0, but is %d" % result[0]

# Generated at 2022-06-20 16:41:39.507823
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing matchpathcon")
    # One for ENOENT and one for EINVAL, both of which should be is_error_condition=True
    failures = 0
    failed_entries = []
    failed_entries.append(matchpathcon('/no/file/should/have/this/name', 0))
    failed_entries.append(matchpathcon('/', -1))
    for (x, y) in failed_entries:
        print("matchpathcon returned:  '{0}' and '{1}'".format(x, y))
        if x < 0:
            failures += 1
    if failures == len(failed_entries):
        print("matchpathcon test suite passed!")
    else:
        print("matchpathcon test suite failed!")



# Generated at 2022-06-20 16:41:41.480106
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp')

    if rc != 0:
        raise ImportError(con)

    rc, con = lgetfilecon_raw('./tmp')
    if rc != 0:
        raise ImportError(con)

# Generated at 2022-06-20 16:41:51.850981
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    print(rc, mode)



# Generated at 2022-06-20 16:41:54.812458
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    if rc == 0:
        print('/etc/passwd has the SELinux context:')
        print(con)
    else:
        print('unable to get SELinux context for /etc/passwd')

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:41:57.033226
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc >= 0


# Generated at 2022-06-20 16:42:01.429234
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_rc, test_rc_msg = lgetfilecon_raw('/etc/passwd')
    print("\nlgetfilecon_raw() returned [{0}]: {1}".format(test_rc, test_rc_msg))

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:42:11.670487
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print('\n Module selinux.py in function test_lgetfilecon_raw')
    if os.path.exists('/tmp/test_selinux'):
        os.remove('/tmp/test_selinux')
    try:
        with open('/tmp/test_selinux', 'w') as f:
            f.write('foo')
            f.flush()
        con = lgetfilecon_raw('/tmp/test_selinux')[1]
        assert con.startswith('unlabeled')
    finally:
        if os.path.exists('/tmp/test_selinux'):
            os.remove('/tmp/test_selinux')
    print('OK')


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:42:14.559358
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'
    assert selinux_getpolicytype()[0] == 0

# Generated at 2022-06-20 16:42:16.204089
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-20 16:42:28.052599
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Basic unit test for lgetfilecon_raw. This tests the following conditions:

    1. lgetfilecon_raw returns 0 if the file exists
    2. lgetfilecon_raw returns -ENOENT if the file doesn't exist
    3. lgetfilecon_raw must free the context after returning it

    This unit test ensures that we don't have a memory leak.
    '''

    file_path = '/tmp/file'
    if os.path.isfile(file_path):
        os.remove(file_path)
    if os.path.isfile(file_path):
        raise Exception('Failed to remove file {0}'.format(file_path))

    (rc, context) = lgetfilecon_raw(file_path)

# Generated at 2022-06-20 16:42:29.442742
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    assert result == [0, 'targeted']

# Generated at 2022-06-20 16:42:34.025776
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    con = None
    path = None
    mode = os.R_OK
    try:
        path = tempfile.mkdtemp()
        (rc, con) = matchpathcon(path, mode)
    finally:
        if path:
            os.rmdir(path)
    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))
    return con

# Generated at 2022-06-20 16:43:06.244527
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create a temporary file to test matchpathcon
    import tempfile
    fd, name = tempfile.mkstemp()

    # Test matchpathcon against a known context on a fresh file
    (rc, con) = matchpathcon(name, 0)
    assert rc == 0
    assert con == 'system_u:object_r:user_home_t:s0'

    # Test matchpathcon against a known context on a directory
    (rc, con) = matchpathcon(os.path.dirname(name), 0)
    assert rc == 0
    assert con == 'system_u:object_r:user_home_dir_t:s0'

    # Cleanup temporary file
    os.close(fd)
    os.unlink(name)

# Generated at 2022-06-20 16:43:09.949823
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert(result['rc'] == 0)
    assert(result['out'] == 0)


# Generated at 2022-06-20 16:43:15.607220
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''Check function selinux_getenforcemode'''
    from ctypes import c_int
    from ctypes import byref

    assert_raises(OSError, _selinux_lib.selinux_getenforcemode, byref(c_int()))


# Generated at 2022-06-20 16:43:25.828548
# Unit test for function matchpathcon
def test_matchpathcon():
    # This test takes a long time to run on Windows as it requires
    # creating temporary directories to test.
    test_dirs = [
        "/tmp/test_matchpathcon/tmp",
        "/tmp/test_matchpathcon/tmp/dir_a",
        "/tmp/test_matchpathcon/tmp/dir_a/dir",
        "/tmp/test_matchpathcon/tmp/dir_b",
        "/tmp/test_matchpathcon/var",
        "/tmp/test_matchpathcon/var/tmp",
        "/tmp/test_matchpathcon/var/tmp/dir_a",
        "/tmp/test_matchpathcon/var/tmp/dir_a/dir",
        "/tmp/test_matchpathcon/var/tmp/dir_b"
    ]

# Generated at 2022-06-20 16:43:36.230744
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw('/etc/passwd', byref(con))
        return [rc, to_native(con.value)]
    finally:
        _selinux_lib.freecon(con)


if __name__ == '__main__':
    print(test_lgetfilecon_raw())
    print(selinux_getenforcemode())
    print(selinux_getpolicytype())

# Generated at 2022-06-20 16:43:42.513281
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text

    dir_to_test = b'/tmp/python/selinux/matchpathcon/test'
    file_to_test = b'/tmp/python/selinux/matchpathcon/test/tmp.txt'

    ret = matchpathcon(dir_to_test, os.R_OK | os.W_OK | os.X_OK)
    print(u'ret: {0}'.format(to_text(repr(ret))))

    ret = matchpathcon(file_to_test, os.R_OK)
    print(u'ret: {0}'.format(to_text(repr(ret))))


# Generated at 2022-06-20 16:43:51.019548
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import subprocess

    # If the system is not selinux-enabled, all returned contexts will be the same
    # This makes testing hard.  We do it anyway.
    # Also, we assume that if selinux is enabled and has no policy, all returned contexts will be the same

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:43:52.889219
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc,con = lgetfilecon_raw("/")
    print("rc: {0} con: {1}".format(rc, con))


# Generated at 2022-06-20 16:43:56.874559
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    '''
    This can be run from the test.sh script.
    '''
    rc, policytype = selinux_getpolicytype()
    print(policytype)
    assert rc == 0



# Generated at 2022-06-20 16:43:58.489089
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] in [0, 1]



# Generated at 2022-06-20 16:44:25.423824
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/tmp', 0) == [0, 'tmp_t']


# Generated at 2022-06-20 16:44:29.547361
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/usr/bin/systemctl"
    mode = os.R_OK
    from selinux import matchpathcon as selinux_matchpathcon
    rc, con = matchpathcon(path, mode)
    rc, con_selinux = selinux_matchpathcon(path, mode)
    assert rc == 0
    assert con == con_selinux



# Generated at 2022-06-20 16:44:33.061426
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforce_mode = selinux_getenforcemode()
    assert rc == 0
    assert enforce_mode == 1 or enforce_mode == 0

# Generated at 2022-06-20 16:44:41.206607
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test root directory
    path = "/"
    mode = os.stat(path)[ST_MODE]
    con = matchpathcon(path, mode)[1]
    assert con == "system_u:object_r:root_t:s0", 'matchpathcon returned invalid value'
    # Test /etc directory
    path = "/etc"
    mode = os.stat(path)[ST_MODE]
    con = matchpathcon(path, mode)[1]
    assert con == "system_u:object_r:etc_t:s0", 'matchpathcon returned invalid value'
    # Test /etc/shadow file
    path = "/etc/shadow"
    mode = os.stat(path)[ST_MODE]
    con = matchpathcon(path, mode)[1]

# Generated at 2022-06-20 16:44:45.699290
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_var = lgetfilecon_raw('/etc/passwd')
    assert test_var[1] == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-20 16:44:52.101223
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import unittest
    import sys

    class TestSELinuxGetPolicyType(unittest.TestCase):
        def test_selinux_getpolicytype(self):
            results = selinux_getpolicytype()
            print(results)
            self.assertTrue(results[0] == 0)
            self.assertTrue(results[1] == 'targeted')

    # This runs only if called from the command line.
    # Alternately, you can run it with:
    #  python -m ansible.module_utils.selinux.test_selinux_getpolicytype
    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-20 16:44:58.121460
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import mkdtemp

    tmp_dir = mkdtemp()
    try:
        rc, output = lgetfilecon_raw(tmp_dir)
        assert rc == 0
        assert 'system_u:object_r:tmp_t:s0' in output
    finally:
        os.rmdir(tmp_dir)

# Generated at 2022-06-20 16:45:09.478160
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # run this test in a controlled context
    with _selinux_lib.selinux_mkpool():
        # no error, no string context
        rc, con = lgetfilecon_raw(b'/etc/shadow')
        assert rc == 0
        assert not con

        # no error, string context
        rc, con = lgetfilecon_raw(b'/etc/passwd')
        assert rc == 0
        assert con == 'system_u:object_r:shadow_t:s0'

        # negative error code
        rc, con = lgetfilecon_raw(b'/this doesnt exist')
        assert rc == -1
        assert con is None



# Generated at 2022-06-20 16:45:12.664315
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc = 0
    policytype = None
    try:
        rc, policytype = selinux_getpolicytype()
    except Exception as e:
        assert(rc == -1)
        assert(policytype is None)
    else:
        assert(isinstance(policytype, str))

# Generated at 2022-06-20 16:45:14.773870
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, selabel) = matchpathcon('/var/log/audit', 0)
    print('matchpathcon - rc={0} selabel={1}'.format(rc, selabel))


# Generated at 2022-06-20 16:45:48.873606
# Unit test for function matchpathcon
def test_matchpathcon():
    # Ansible should be able to call function matchpathcon,
    # because libselinux.so.1 is installed on the system
    try:
        matchpathcon("/etc/hosts", 0)
    except Exception as e:
        print("Error on module_utils/selinux_lib selinux_lib.py.  "
              "matchpathcon cannot be executed on this system: " + str(e))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:45:53.466792
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if not security_getenforce():
        sys.exit(2)
    res = selinux_getpolicytype()
    if res[1] != b'targeted':
        sys.exit(1)
    sys.exit(0)

# Generated at 2022-06-20 16:45:55.888677
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, 'rc should be 0, got {0}'.format(rc)
    assert policytype == 'targeted', 'policytype should be targeted, got {0}'.format(policytype)



# Generated at 2022-06-20 16:46:02.628141
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Running test_matchpathcon")
    ret = matchpathcon("/etc/hosts", 0)
    assert isinstance(ret, list)
    assert isinstance(ret[0], int)
    assert isinstance(ret[1], str)

    ret = matchpathcon("/etc/hosts", 1)
    assert isinstance(ret, list)
    assert isinstance(ret[0], int)
    assert isinstance(ret[1], str)

