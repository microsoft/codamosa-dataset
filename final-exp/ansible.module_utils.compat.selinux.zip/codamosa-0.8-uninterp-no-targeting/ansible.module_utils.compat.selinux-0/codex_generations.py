

# Generated at 2022-06-20 16:36:03.349271
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = os.R_OK
    res = matchpathcon(path, mode)
    assert res[0] == 0, "Failed to call matchpathcon with (path, mode): {0}, {1}".format(path, mode)
    assert res[1] == 'sysadm_t:sysadm_r:sysadm_t:s0-s0:c0.c1023', "Unexpected value returned by matchpathcon with (path, mode): {0}, {1}".format(path, mode)


# Generated at 2022-06-20 16:36:10.280709
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        test_file = os.path.join(tmpdirname,'test.txt')
        with open(test_file, "w") as f:
            f.write("hello")
        # First test with an existing file
        assert lgetfilecon_raw(test_file) == [0, "system_u:object_r:tmp_t:s0"]
        # Now cleanup testing with a non-existing file
        os.remove(test_file)
        assert lgetfilecon_raw(test_file) == [-1, "No such file or directory"]


# Generated at 2022-06-20 16:36:13.513624
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/var/www/html'
    mode = os.R_OK
    assert [0, 'system_u:object_r:httpd_sys_content_t:s0'] == matchpathcon(path, mode)



# Generated at 2022-06-20 16:36:23.207541
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux_policy import selinux_policy_version

    rc, _ = selinux_getenforcemode()
    assert rc == 0, 'Failed to get selinux mode'

    policy_type = selinux_getpolicytype()
    assert policy_type == 0, 'Failed to get selinux policy type'

    rc, fcon = lgetfilecon_raw('/')
    assert rc == 0, 'Failed to get file context of /'
    assert fcon != '<<none>>', 'File context was none'

    rc, mcon = matchpathcon('/', os.R_OK)
    assert rc == 0, 'Failed to get context of path=/'
    assert mcon == '<<none>>', 'File context was not none with selinux policy version < 34'
    assert selinux

# Generated at 2022-06-20 16:36:24.711340
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-20 16:36:27.241241
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b"/etc/shadow") == [0, "unconfined_u:object_r:user_shadow_t:s0"]

# Generated at 2022-06-20 16:36:32.802265
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()

    if rc == -1:
        raise OSError('could not get selinux mode')

    if mode == 1:
        enforce_mode = 'enforcing'
    elif mode == 0:
        enforce_mode = 'permissive'
    elif mode == -1:
        enforce_mode = 'disabled'
    else:
        raise Exception('Raw mode value is not supported: {0}.'.format(mode))

    return enforce_mode



# Generated at 2022-06-20 16:36:34.412374
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    con = c_char_p()
    rc, policytype = selinux_getpolicytype()
    return policytype

# Generated at 2022-06-20 16:36:42.280879
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("\nFunction selinux_getenforcemode")
    (rc, enforce) = selinux_getenforcemode()
    if rc < 0:
        print("Error: selinux_getenforcemode() " + os.strerror(rc))
    else:
        print("Enforce mode is: ", end='')
        if enforce == 0:
            print("Permissive")
        elif enforce == 1:
            print("Enforcing")
        else:
            print("Unknown")



# Generated at 2022-06-20 16:36:47.678202
# Unit test for function matchpathcon
def test_matchpathcon():
    # Simple test for matchpathcon
    # Expects a True for the return code, and a valid context for the context itself
    (ret, con) = matchpathcon('/etc/passwd', 0)
    if ret == -1:
        sys.exit(1)
    if not con.startswith('system_u:object_r:etc_t:s0'):
        sys.exit(1)

# Generated at 2022-06-20 16:36:52.536623
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test function to test lgetfilecon_raw
    """
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']

# Generated at 2022-06-20 16:36:54.780719
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    :rtype: object
    """
    path = "/etc/passwd"
    print(lgetfilecon_raw(path))


# Generated at 2022-06-20 16:36:56.970040
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/tmp')
    assert rc >= 0
    assert con != ''


# Generated at 2022-06-20 16:36:59.370751
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert policytype[0] == 0 and policytype[1] == 'targeted'

# Generated at 2022-06-20 16:37:04.271153
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # As selinux_getenforcemode uses getenv, the below code does not work in the test environment
    # selinux_enabled = is_selinux_enabled()
    # if selinux_enabled:
    #     rc, enforcemode = selinux_getenforcemode()
    #     assert rc == 0
    #     assert enforcemode == 1
    # else:
    #     assert False, "SELinux is not installed, testing selinux_getenforcemode is not possible"
    assert True

# Generated at 2022-06-20 16:37:11.428643
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if security_policyvers() != 0:
        raise Exception('libselinux is in permissive mode and cannot verify policy type')

    if not is_selinux_enabled():
        raise Exception('selinux is disabled and we cannot verify policy type')

    rc, policy_type = selinux_getpolicytype()
    if rc == -1:
        raise Exception('lselinux_getpolicytype failed')

    if not isinstance(policy_type, str):
        raise Exception('policy type is not a string')

    if len(policy_type) == 0:
        raise Exception('policy type is empty')

    return policy_type

# Generated at 2022-06-20 16:37:22.905202
# Unit test for function matchpathcon
def test_matchpathcon():
    import stat
    import tempfile

    d = tempfile.TemporaryDirectory()
    td = d.name
    test_file = 'test_file'
    test_subdir = 'test_subdir'
    test_file_path = td + '/' + test_file
    test_subdir_path = td + '/' + test_subdir

    os.mkdir(test_subdir_path)
    with open(test_file_path, "w"):
        pass
    os.chmod(test_file_path, 0o000)
    os.chmod(test_subdir_path, 0o000)
    lsetfilecon(test_file_path, 'unconfined_u:object_r:user_tmp_t:s0')

# Generated at 2022-06-20 16:37:25.205538
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    return (rc, enforcemode) == (0, 1)


# Generated at 2022-06-20 16:37:27.928720
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("selinux_getenforcemode test")
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 0
    print("selinux_getenforcemode test success")


# Generated at 2022-06-20 16:37:29.894034
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/bin/foo', 0)[1] == 'system_u:object_r:lib_t:s0'

# Generated at 2022-06-20 16:37:35.509217
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    assert [rc, enforcemode.value] == selinux_getenforcemode()



# Generated at 2022-06-20 16:37:37.944263
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:37:44.350429
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/bin/ls'
    flags = os.R_OK
    rc, con = matchpathcon(path, os.R_OK)
    if rc == 0:
        print('con attribute is {0}'.format(con))
    else:
        print('matchpathcon returned error code {0}'.format(rc))
        raise OSError(rc, os.strerror(rc))



# Generated at 2022-06-20 16:37:45.709265
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not is_selinux_enabled():
        return
    rc, mode = selinux_getenforcemode()
    assert rc == 0, "error code %d" % rc
    assert mode == security_getenforce(), "enforce mode %d" % mode


# Generated at 2022-06-20 16:37:47.307971
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [1, 0]



# Generated at 2022-06-20 16:37:54.240998
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, con = selinux_getpolicytype()
        if rc < 0:
            raise NotImplementedError('selinux_getpolicytype(2) is not implemented in this version of libselinux')
    except NotImplementedError:
        raise
    except Exception as ex:
        raise RuntimeError('Unexpected exception when calling selinux_getpolicytype(2), reported error: %s' % ex)
    else:
        assert isinstance(rc, int)
        assert isinstance(con, str)


# Generated at 2022-06-20 16:37:56.873324
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type = selinux_getpolicytype()[1]
    assert isinstance(policy_type, str)

# Generated at 2022-06-20 16:37:59.962276
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/home/sysadmin'
    mode = os.R_OK | os.W_OK | os.X_OK
    rc, con = matchpathcon(path, mode)
    print("matchpathcon rc=%d con=%s" % (rc, con))

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:38:01.790366
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    with tempfile.NamedTemporaryFile() as tmp:
        assert lgetfilecon_raw(tmp.name)[0] == -1

# Generated at 2022-06-20 16:38:08.182586
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Get file security context for directory "/root"
    rc, con = lgetfilecon_raw(b'/root')
    if rc == 0:
        print('File security context for file "/root" is "{0}"'.format(con))
    else:
        print('Error getting file security context for file "/root", errno = {0}'.format(rc))


# Generated at 2022-06-20 16:38:16.369433
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = "/etc/hosts"
    selinux_list = lgetfilecon_raw(test_file)
    assert(len(selinux_list) == 2)
    assert(selinux_list[0] == 0)
    assert(selinux_list[1] == "system_u:object_r:etc_t:s0")

# Generated at 2022-06-20 16:38:18.806244
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():

    # testing whether enforcement mode is enabled or disabled
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode == 0 or enforcemode == 1 or enforcemode == 2


# Generated at 2022-06-20 16:38:24.826219
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/home/test/.ssh/authorized_keys', os.R_OK)
    assert rc == 0
    rc, con = matchpathcon('/home/test/.ssh/authorized_keys', os.O_RDONLY)
    assert rc == 0
    rc, con = matchpathcon('/home/test/.ssh/authorized_keys', os.W_OK)
    assert rc == 0
    rc, con = matchpathcon('/home/test/.ssh/authorized_keys', os.X_OK)
    assert rc == 0
    rc, con = matchpathcon('/home/test/.ssh/authorized_keys', os.R_OK | os.W_OK)
    assert rc == 0

# Generated at 2022-06-20 16:38:31.656945
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc != 0:
        raise RuntimeError('selinux_getpolicytype failed: {0}'.format(rc))
    print('SELinux policy type is {0}'.format(policytype))

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:38:33.261379
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0,1,2)


# Generated at 2022-06-20 16:38:35.537833
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = 0o700
    path = '/tmp'
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:default_t:s0'



# Generated at 2022-06-20 16:38:37.128881
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert(selinux_getpolicytype()[1] == b'targeted')

# Generated at 2022-06-20 16:38:44.468625
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file_path = '/tmp/mysql-test.txt'
    if os.path.exists(test_file_path):
        rc, context = lgetfilecon_raw(test_file_path)
    else:
        # Fallback case if test file doesn't exist
        file = open('/etc/passwd', 'r')
        line = file.readline()
        rc, context = lgetfilecon_raw(line)
    assert rc == 0

# Generated at 2022-06-20 16:38:51.496615
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = os.path.join(os.getcwd(), 'ansible_test_selinux_module')
    if not os.path.isfile(test_path):
        with open(test_path, 'a'):
            os.utime(test_path, None)

    rc, con = lgetfilecon_raw(test_path)
    if rc >= 0:
        assert con
    else:
        assert not con

# Generated at 2022-06-20 16:38:57.060151
# Unit test for function matchpathcon
def test_matchpathcon():
    # test is running in an SELinux-enabled machine
    assert is_selinux_enabled() == 1
    assert matchpathcon('/etc/shadow', 0)[0] == 0
    # the mode must be valid
    assert matchpathcon('/etc/shadow', -999)[0] != 0

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:39:15.590681
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

# Generated at 2022-06-20 16:39:17.597289
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] in [0, 1]



# Generated at 2022-06-20 16:39:27.164596
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import unittest

    class SelinuxTestCase(unittest.TestCase):
        def test_selinux_getpolicytype(self):
            import stat
            import os

            # Create a temporary file
            with open('mytestfile', 'a'):
                os.utime('mytestfile', None)

            # Get the pathname of the file
            file_path = os.path.realpath('mytestfile')

            # Get the properties of the file
            file_stat = os.stat(file_path)

            # Print the type of the file
            policytype = selinux_getpolicytype()
            print("policytype: %s" % policytype)

            # Delete the temporary file
            os.remove('mytestfile')

    unittest.main()
    #python -m unittest example

# Generated at 2022-06-20 16:39:31.963820
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_bytes
    rc, result = matchpathcon(b'/etc/nginx', 1)
    assert rc == 0
    assert result == to_bytes(b'webadm_r:object_r:httpd_sys_content_t')

    rc, result = matchpathcon(b'/non-existed-file', 1)
    assert rc == 1

# Generated at 2022-06-20 16:39:37.605170
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = ''
    rc = ''
    enforcemode, rc = selinux_getenforcemode()
    if rc != 0:
        print("SELinux is disabled.")
    elif enforcemode == 1:
        print("SELinux is enabled in enforcing mode.")
    else:
        print("SELinux is enabled in permissive mode.")



# Generated at 2022-06-20 16:39:40.435502
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert(rc == 0)
    assert(enforcemode in [0, 1, 2])



# Generated at 2022-06-20 16:39:44.924872
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert isinstance(rc, int)
    assert rc in [0, 1]
    assert isinstance(mode, int)
    assert mode in [0, 1, 2]


if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-20 16:39:52.152433
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import lsetfilecon
    from ansible.module_utils.selinux import lgetfilecon
    from ansible.module_utils.selinux import lgetfilecon_raw
    from ansible.module_utils.selinux import matchpathcon

    # Need root privilege
    if os.getuid() != 0:
        print("Test script must be executed as root")
        sys.exit(27)

    stat_file = '/etc/passwd'
    con_old = lgetfilecon_raw(stat_file)[1]
    con_new = con_old.replace('user_u:object_r:', 'user_u:object_r:usr_t:s0-')
    print("old context: " + str(con_old))

# Generated at 2022-06-20 16:40:01.238210
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = '/etc/services'
    try:
        conref = lgetfilecon_raw(file)
        con = conref[1]
    except OSError as e:
        # check if the system is using SELinux or not
        if selinux_getenforcemode()[1] != 1:
            # if not using SELinux, return False
            return False

        # if using SELinux, OSError happens if file doesn't exist or is not accessible
        print("Failed to read file context: %s" % e)
        return False

# Generated at 2022-06-20 16:40:02.648888
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-20 16:40:21.989489
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert isinstance(enforcemode, int)


# Generated at 2022-06-20 16:40:25.379722
# Unit test for function matchpathcon
def test_matchpathcon():
    f_path = "/etc/shadow"
    f_mode = 0
    rc, con = matchpathcon(f_path, f_mode)
    assert rc == 0
    assert con == "system_u:object_r:shadow_t"


# Generated at 2022-06-20 16:40:26.219332
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('.', 0)
    assert rc == 0
    assert con is not None

# Generated at 2022-06-20 16:40:30.453061
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = b"/tmp"
    test_mode = 0
    rc, con = matchpathcon(test_path, test_mode)
    print(rc, con)
    return rc, con


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:40:32.441426
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert_equal(selinux_getpolicytype()[0], 0)


# Generated at 2022-06-20 16:40:35.116773
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    con = lgetfilecon_raw(path)
    assert len(con) == 2
    assert con[0] == 0
    assert con[1] != ''


# Generated at 2022-06-20 16:40:41.202278
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/etc/passwd'
    if 'SELINUX_ROLE_REQUESTED' not in os.environ:
        print('SELINUX_ROLE_REQUESTED is not set, skipping test')
    else:
        print('SELINUX_ROLE_REQUESTED is set to {}'.format(os.environ['SELINUX_ROLE_REQUESTED']))
        if lgetfilecon_raw(test_path)[0] == 0:
            print('lgetfilecon_raw() result for {}: {}'.format(test_path, lgetfilecon_raw(test_path)[1]))
        else:
            print('lgetfilecon_raw() for {} failed: {}'.format(test_path, lgetfilecon_raw(test_path)[0]))



# Generated at 2022-06-20 16:40:45.436516
# Unit test for function matchpathcon
def test_matchpathcon():
    con_type_tuple = matchpathcon('/var/log/spooler', 0)
    assert con_type_tuple[0] == 0
    assert con_type_tuple[1] == 'system_u:object_r:var_log_t:s0'



# Generated at 2022-06-20 16:40:51.033495
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw('/etc/passwd')
    except OSError as e:
        sys.stderr.write(str(e))
    else:
        print('return code: %s' % rc)
        print('context: %s' % con)

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:40:55.038041
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if selinux_getenforcemode()[1] == 0:
        print('SELinux is in Permissive mode')
    else:
        print('SELinux is in Enforcing mode')


# Generated at 2022-06-20 16:41:31.501931
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc == -1:
        print('Unable to get policy type')
        sys.exit(1)
    print('Policy type: {}'.format(policytype))


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:41:33.728106
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert policytype[0] == 0, 'Failed to get policytype'
    assert policytype[1] == 'targeted', 'Targeted policytype is not the default'


# Generated at 2022-06-20 16:41:36.359355
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    if rc == 0:
        assert mode in (0, 1, 2)



# Generated at 2022-06-20 16:41:39.723183
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    mode, value = selinux_getenforcemode()
    print(mode, value)



# Generated at 2022-06-20 16:41:46.647398
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    for _ in range(10):
        rc, policytype = selinux_getpolicytype()
        assert rc == 0, 'expected selinux_getpolicytype to return 0 but it returned {0}'.format(rc)
        assert policytype.startswith('targeted'), 'expected selinux_getpolicytype to return targeted but it returned {0}'.format(policytype)


# Generated at 2022-06-20 16:41:59.344137
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = '/tmp/ansible_test_file'
    test_context = 'system_u:object_r:usr_t:s0'
    test_mode = '644'
    rc = _selinux_lib.lsetfilecon(test_file, test_context)
    if rc == 0:
        rc, context = lgetfilecon_raw(test_file)
        if rc == 0:
            if test_context == context:
                print('PASSED lgetfilecon_raw()')
            else:
                print('FAILED lgetfilecon_raw()')
        else:
            print('FAILED lgetfilecon_raw()')
    else:
        print('FAILED lgetfilecon_raw()')
    _selinux_lib.unlink(test_file)



# Generated at 2022-06-20 16:42:02.902191
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    return [rc, enforcemode]


# Generated at 2022-06-20 16:42:12.054257
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    lgetfilecon_raw test
    """
    import os
    from ctypes import c_char_p
    libc = CDLL("libc.so.6", use_errno=True)

    def _check_rc(rc):
        if rc < 0:
            errno = get_errno()
            raise OSError(errno, os.strerror(errno))
        return rc

    input_path = "/tmp/input.txt"

    # https://docs.python.org/2/library/ctypes.html
    # Create a string buffer to receive the contents.
    string_buffer = c_char_p("/tmp/input.txt")

# Generated at 2022-06-20 16:42:16.885976
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = os.stat("/etc").st_mode
    con = matchpathcon("/etc", mode)
    print("con: %s" % con[1])
    mode = os.stat("/").st_mode
    con = matchpathcon("/", mode)
    print("con: %s" % con[1])

# Generated at 2022-06-20 16:42:24.369596
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    (tmp_fd, tmp_file) = tempfile.mkstemp()
    try:
        assert matchpathcon(tmp_file, 0) == [0, 'system_u:object_r:unlabeled_t:s0']
    finally:
        os.unlink(tmp_file)