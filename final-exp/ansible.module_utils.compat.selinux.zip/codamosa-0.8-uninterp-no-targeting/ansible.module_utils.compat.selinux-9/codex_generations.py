

# Generated at 2022-06-20 16:36:04.897110
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Check the retval is correct.
    retval = selinux_getenforcemode()
    assert retval[0] == 0
    assert isinstance(retval[1], int)



# Generated at 2022-06-20 16:36:12.153042
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.exists("./test.txt"):
        print("test.txt exists. Skipping test file creation.")
    else:
        with open("./test.txt", "w") as fd:
            fd.write("test")

    # 1. Test with file
    ret = lgetfilecon_raw("test.txt")
    print("lgetfilecon_raw() execution returned: ", ret)

    # 2. Test with file which does not exist
    ret = lgetfilecon_raw("test2.txt")
    print("lgetfilecon_raw() execution returned: ", ret)

    # 3. Test with directory
    ret = lgetfilecon_raw(".")
    print("lgetfilecon_raw() execution returned: ", ret)

    # Remove test file

# Generated at 2022-06-20 16:36:20.961365
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    mode = os.stat('/tmp/testfile').st_mode
    if not os.path.exists('/tmp/testfile') or not oct(stat.S_IMODE(mode)) == '0644':
        f = open('/tmp/testfile', 'w')
        f.close()
        os.chmod('/tmp/testfile', 0o644)
    path = '/tmp/testfile'
    mode = os.stat(path).st_mode
    assert oct(stat.S_IMODE(mode)) == '0644'
    assert lgetfilecon_raw(path)[1] == 'u:object_r:user_tmp_t:s0'



# Generated at 2022-06-20 16:36:23.184869
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/', 0) == [0, b'system_u:object_r:unlabeled_t:s0']

# Generated at 2022-06-20 16:36:29.482371
# Unit test for function matchpathcon
def test_matchpathcon():
    def mock_get_errno():
        return 22
    def mock_error(errno, strerror):
        raise OSError(2, 3)
    try:
        tmp_get_errno = get_errno
        tmp_error = OSError
        get_errno = mock_get_errno
        OSError = mock_error
        matchpathcon("test", 0)
    except:
        pass
    finally:
        get_errno = tmp_get_errno
        OSError = tmp_error

# Generated at 2022-06-20 16:36:29.871103
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    pass

# Generated at 2022-06-20 16:36:40.829444
# Unit test for function lgetfilecon_raw

# Generated at 2022-06-20 16:36:44.136821
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, data = selinux_getpolicytype()
    if rc != 0:
        raise Exception('selinux_getpolicytype failed with rc={0}'.format(rc))
    return (not data.startswith('error'))

# Generated at 2022-06-20 16:36:46.805056
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()

    assert(rc == 0)
    assert(mode in ['Permissive', 'Enforcing'])



# Generated at 2022-06-20 16:36:49.880950
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.selinux_policy import selinux_getpolicytype

    [rc, con] = selinux_getpolicytype()
    assert rc == 0
    assert con == 'targeted'

# Generated at 2022-06-20 16:36:53.402801
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # FIXME: this does not run in a clean selinux environment as root
    return False


# Generated at 2022-06-20 16:37:02.481540
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/etc/hosts', 0)[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert matchpathcon(b'/etc/hosts', 1)[1] == 'system_u:object_r:etc_t:s0'
    assert matchpathcon(b'/etc', 0)[1] == 'system_u:object_r:etc_runtime_t:s0'
    assert matchpathcon(b'/etc', 1)[1] == 'system_u:object_r:etc_t:s0'
    assert matchpathcon(b'/tmp', 0)[1] == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-20 16:37:05.670022
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = b'/home/user1'
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(test_path, 0, byref(con))
    assert rc == 0
    _selinux_lib.freecon(con)

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:37:11.083173
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import stat
    import tempfile
    import unittest

    if os.getenv('ANSIBLE_SELINUX_TEST') == '1':
        from ansible_collections.notstdlib.moveitallout.plugins.module_utils.selinux import selinux_getenforcemode, matchpathcon

        class SELinuxGetEnforceModeTestCase(unittest.TestCase):
            def test_selinux_getenforcemode(self):
                rv = selinux_getenforcemode()
                self.assertEqual(rv[0], 0)
                self.assertEqual(rv[1], 1)


# Generated at 2022-06-20 16:37:16.313350
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import module_utils.selinux.selinux as selinux
    [rc, enforce_mode] = selinux.selinux_getenforcemode()
    assert isinstance(rc, int)
    assert isinstance(enforce_mode, int)
    assert enforce_mode in [0, 1, 2], "enforce_mode out-of-range"

# Generated at 2022-06-20 16:37:25.005336
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Given
    path = "/etc/hosts"
    expected_rc = 0
    expected_con = b'system_u:object_r:etc_t:s0'

    # When
    actual_rc, actual_con = lgetfilecon_raw(path)

    # Then
    assert actual_rc == expected_rc, "Actual rc '%s' does not match expected rc '%s'" % (actual_rc, expected_rc)
    assert actual_con == expected_con, "Actual con '%s' does not match expected con '%s'" % (actual_con, expected_con)


# Generated at 2022-06-20 16:37:27.378199
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    version = selinux_getpolicytype()
    print('selinux_getpolicytype returns: ', version)



# Generated at 2022-06-20 16:37:29.392966
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1] or selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-20 16:37:42.413764
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import shutil
    import tempfile

    from ansible.module_utils.selinux import matchpathcon

    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, 'file')

    (rc, con) = matchpathcon(test_dir, os.R_OK)
    assert rc == 0, 'matchpathcon returned non-zero rc: %d' % rc

    con_type = con.split(':')[0]
    assert con_type == 'public_content_rw_t', 'matchpathcon returned wrong SELinux file context type: %s' % con_type

    os.close(os.open(test_file, os.O_CREAT))


# Generated at 2022-06-20 16:37:46.764942
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    (rc, con) = matchpathcon("/", 0)
    assert rc == 0, "matchpathcon failed"
    assert con == "system_u:object_r:admin_home_t:s0", "matchpathcon returned unexpected result " + con



# Generated at 2022-06-20 16:37:59.426555
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import pwd
    import grp
    import tempfile
    import shutil
    import selinux

    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-20 16:38:01.513315
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import os

    (rc, con) = selinux_getpolicytype()
    assert rc == 0
    if con not in ['targeted', 'mls']:
        assert False, "Failed to get selinux policy type"


# Generated at 2022-06-20 16:38:11.994900
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for success condition
    assert matchpathcon("/usr/sbin/sshd", 777) == [0, 'system_u:object_r:sshd_exec_t:s0']
    # Test for file not found condition
    assert matchpathcon("/usr/sbin/sshdXXX", 777) == [-1, 'system_u:object_r:sshd_exec_t:s0']
    # Test for invalid file mode
    assert matchpathcon("/usr/sbin/sshd", 888) == [-1, 'system_u:object_r:sshd_exec_t:s0']
    # Test for invalid file mode
    assert matchpathcon("/usr/sbin/sshd", 0) == [-1, 'system_u:object_r:sshd_exec_t:s0']
   

# Generated at 2022-06-20 16:38:20.350059
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: this tests needs to be completed
    # TODO: Tests for this module can be implemented by comparing the output of the module to output from the following commands:
    # is_selinux_enabled: getenforce
    # is_selinux_mls_enabled: getenforce -M
    # lgetfilecon_raw: stat -c %C /etc/passwd
    # matchpathcon: matchpathcon -p /etc/passwd
    # security_policyvers: sestatus
    # selinux_getenforcemode: getenforce
    # security_getenforce: getenforce
    # selinux_getpolicytype: sestatus

    assert os.path.exists('/etc/passwd') is True
    assert lgetfilecon_raw('/etc/passwd')[1] is not None

# Generated at 2022-06-20 16:38:22.048892
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == 'targeted'


# Generated at 2022-06-20 16:38:26.618495
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon(b"/usr/bin/git", 0)
    if rc == 0:
        assert con == b"system_u:object_r:bin_t:s0"
    else:
        assert False, "Unable to perform matchpathcon test"


# Generated at 2022-06-20 16:38:27.777486
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t:s0']



# Generated at 2022-06-20 16:38:34.201866
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        return
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as f:
        _, con = lgetfilecon_raw(f.name)
        assert con is not None
        # Assume that the context will always have 2 sections (i.e. user:role:type)
        assert len(con.split(":")) == 3

# Generated at 2022-06-20 16:38:36.620705
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/var/log/audit/'
    mode = os.stat(path).st_mode
    [rc, con] = matchpathcon(path, mode)
    print('%s %s %s %s' % (rc, path, mode, con))



# Generated at 2022-06-20 16:38:43.235167
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import selinux
    (rc, policytype) = selinux.selinux_getpolicytype()
    assert rc == 0
    assert policytype == b'targeted'


if __name__ == '__main__':
    try:
        test_selinux_getpolicytype()
    except ImportError:
        print("Error: selinux not available!")

# Generated at 2022-06-20 16:38:51.616808
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] is not None

# Generated at 2022-06-20 16:38:54.974628
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b"/etc/passwd"
    rc, con = lgetfilecon_raw(path)
    print(rc)
    print(con)



# Generated at 2022-06-20 16:39:02.900089
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils import basic
    import ansible_collections.ansible.community.plugins.module_utils.selinux as selinux_module

    test_path = "test_path"
    test_mode = 123
    test_result = ["test_result", "test_con"]

    def test_selinux_module_matchpathcon(self, path, mode, **kwargs):
        self.module.exit_json(path=path, mode=mode, result=test_result)

    setattr(selinux_module, "matchpathcon", test_selinux_module_matchpathcon)

    with basic.AnsibleModule(argument_spec={}) as module:
        selinux_module.matchpathcon(module, test_path, test_mode)
        assert module.params["path"] == test

# Generated at 2022-06-20 16:39:07.588696
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create the file for testing
    test_file = "/etc/selinux/test_file"
    f = open(test_file, "w")
    f.close()
    assert matchpathcon(test_file, os.R_OK)[0] == 0
    assert matchpathcon(test_file, os.W_OK)[0] == 0
    assert matchpathcon(test_file, os.X_OK)[0] == 0
    assert matchpathcon(test_file, os.F_OK)[0] == 0
    # Cleanup
    assert os.remove(test_file) == None

# Generated at 2022-06-20 16:39:10.314180
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('selinux_getpolicytype()')
    rc, val = selinux_getpolicytype()
    print('return code: %s, value is: %s' % (rc, val))



# Generated at 2022-06-20 16:39:15.192202
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        print('selinux is not enabled, skipping tests')
        return

    print('matchpathcon: ', matchpathcon('/etc/passwd', 0))
    print('matchpathcon: ', matchpathcon('/home/', 0))
    print('matchpathcon: ', matchpathcon('/', 0))

# Generated at 2022-06-20 16:39:18.342346
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """ test lgetfilecon_raw() """
    # If the file has no context, None is returned.
    return lgetfilecon_raw(b'/dev/null')



# Generated at 2022-06-20 16:39:19.655912
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-20 16:39:20.966587
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    mode = selinux_getenforcemode()
    print(mode)



# Generated at 2022-06-20 16:39:23.298366
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp'
    mode = 0
    result = matchpathcon(path, mode)
    print(result)



# Generated at 2022-06-20 16:39:41.205139
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/test_file'
    rc, con = lgetfilecon_raw(path)

    assert rc == 0
    assert con == 'unlabeled_t'

    rc, con = lgetfilecon_raw(path + '_not_exists')

    assert rc == -1

# Generated at 2022-06-20 16:39:44.035865
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, context = lgetfilecon_raw("/tmp")
    assert rc == 0
    assert context == "system_u:object_r:tmp_t:s0"



# Generated at 2022-06-20 16:39:50.235741
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    if not is_selinux_enabled():
        raise Exception('Unable to test lgetfilecon_raw(), SELinux is disabled')

    # FIXME: TODO: find something better to test against
    # test against kernel config source
    rc, con = lgetfilecon_raw('/boot/config-`uname -r`')
    if rc != 0:
        raise Exception('lgetfilecon_raw failed')
    print('con: {0}'.format(con))


if __name__ == '__main__':
    sys.exit(test_lgetfilecon_raw())

# Generated at 2022-06-20 16:39:54.072613
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp"

    rc, con = lgetfilecon_raw(path)
    if rc < 0:
        raise ImportError("lgetfilecon_raw failed: " + str(rc))

    print("lgetfilecon_raw: " + str(con))


# Generated at 2022-06-20 16:39:59.804133
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    '''
    Unit test for function selinux_getpolicytype
    '''

    # Check results for selinux disabled
    try:
        os.environ['SELINUX_INIT'] = 'NO'
        assert selinux_getpolicytype()[0] == -1
    finally:
        os.environ['SELINUX_INIT'] = 'YES'

    # Check results for selinux enabled
    assert selinux_getpolicytype()[0] == 0

# Generated at 2022-06-20 16:40:07.934860
# Unit test for function matchpathcon
def test_matchpathcon():
    def test_matchpathcon_helper(path, mode):
        rc, result = matchpathcon(path, mode)
        assert rc == 0
        print('{0} = {1}, {2}'.format(path, result, rc))

    test_matchpathcon_helper('/tmp/foo', 0)
    test_matchpathcon_helper('/root', 0)
    test_matchpathcon_helper('/etc', os.R_OK)
    test_matchpathcon_helper('/usr/bin/python', os.X_OK)
    test_matchpathcon_helper('/usr/bin/python', os.W_OK)

# Generated at 2022-06-20 16:40:10.905660
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    sys.modules.pop('selinux')
    import selinux
    con = selinux.lgetfilecon_raw('/proc/cpuinfo')
    assert con[1] == 'system_u:object_r:cpuinfo_t:s0'
    assert con[0] == 0

# Generated at 2022-06-20 16:40:13.289223
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy = selinux_getpolicytype()
    assert policy[0] == 0
    policy = selinux_getpolicytype()[1]
    assert policy in ['targeted', 'minimum', 'mls']


# Generated at 2022-06-20 16:40:15.227342
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] >= 0


# Generated at 2022-06-20 16:40:21.447927
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    print('selinux policy type: {}'.format(policytype), file=sys.stderr)
    assert rc == 0 and policytype in ['targeted', 'minimum', 'mls']


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:40:55.697572
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, out) = selinux_getpolicytype()
    if rc != 0:  # Unix return code
        raise RuntimeError('selinux_getpolicytype() failed: \n\tresult: {0}\n\tstderr: {1}'.format(rc, out))
    else:
        print('selinux_getpolicytype() success: {0}'.format(out))



# Generated at 2022-06-20 16:41:01.102658
# Unit test for function matchpathcon
def test_matchpathcon():
    # Selinux disabled, return None
    if _selinux_lib.is_selinux_enabled() == 0:
        return None

    # Selinux enabled, return string
    if _selinux_lib.is_selinux_enabled() == 1:
        rc, con = matchpathcon("/etc/shadow", 0)
        assert rc == 0
        assert con == "system_u:object_r:shadow_t:s0"



# Generated at 2022-06-20 16:41:09.827084
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test selinux_getpolicytype function
    """
    from ansible.module_utils.selinux_lib import selinux_getpolicytype

    try:
        rc, res = selinux_getpolicytype()
        if rc:
            print('selinux_getpolicytype failed')
        else:
            if res == 'mls':
                print('selinux_getpolicytype mls')
            if res == 'targeted':
                print('selinux_getpolicytype targeted')
    except OSError as ex:
        if ex.errno == 22:
            print('selinux_getpolicytype operation not permitted')
        else:
            raise ex



# Generated at 2022-06-20 16:41:13.658518
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    assert result[0] == 0
    assert result[1] in ['targeted', 'minimum', 'mls']


# Generated at 2022-06-20 16:41:14.927660
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    return selinux_getpolicytype()[1]



# Generated at 2022-06-20 16:41:21.288802
# Unit test for function matchpathcon
def test_matchpathcon():
    # Setup
    path = "/tmp/myfile"
    mode = 0

    def matchpathcon_replacement(path, mode, con):
        # Replace selinux.matchpathcon with a fake implementation for testing purpose
        return 0, "system_u:object_r:tmp_t:s0"

    # Record
    record = _selinux_lib.matchpathcon
    _selinux_lib.matchpathcon = matchpathcon_replacement
    try:
        # Actual call
        rc, con = matchpathcon(path, mode)
    finally:
        # Reset
        _selinux_lib.matchpathcon = record

    assert rc == 0
    assert con == "system_u:object_r:tmp_t:s0"

# Generated at 2022-06-20 16:41:26.645411
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, stdout, stderr) = module.run_command(['touch', 'test'])
    (rc, con) = matchpathcon('test', 0)
    assert rc == 0
    assert 'system_u:object_r:user_home_t:s0' in con
    (rc, stdout, stderr) = module.run_command(['rm', 'test'])


# Generated at 2022-06-20 16:41:35.764533
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible_collections.ansible.community.plugins.module_utils.selinux import lgetfilecon_raw
    from ansible.module_utils.six import PY2

    path = '/etc/shadow'
    if PY2:
        path = path.decode('utf-8')
    selabel = lgetfilecon_raw(path)
    assert selabel[1] == 'system_u:object_r:shadow_t:s0'

# Generated at 2022-06-20 16:41:46.722449
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # fake getpolicytype function to match hardcoded policytype
    policytype = b'MCS'

    def fake_selinux_getpolicytype(con):
        try:
            con.contents = policytype
            return 0
        except Exception as err:  # pylint: disable=broad-except
            return -1
    _selinux_lib.selinux_getpolicytype = fake_selinux_getpolicytype

    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == 'MCS'

# Generated at 2022-06-20 16:41:53.191933
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert isinstance(policytype, list)
    assert isinstance(policytype[0], int)
    assert policytype[1] in ('targeted', 'strict', 'mls')
    return policytype


# Generated at 2022-06-20 16:43:03.903797
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b"/bin/ls"
    mode = 0
    [rc, con] = matchpathcon(path, mode)
    if rc == 0:
        print("SELinux context for %s is %s" % (path, con))
    else:
        print("No SELinux context for %s" % path)


# Generated at 2022-06-20 16:43:09.539149
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # Verify if the function lgetfilecon_raw exists
    file_con_raw = _selinux_lib.lgetfilecon_raw
    file_con_raw.argtypes = [_to_char_p, POINTER(c_char_p)]
    file_con_raw.restype = c_int

    # Verify the function lgetfilecon_raw returns the expected context
    # The function lgetfilecon_raw returns a list with the return code and the context.
    # The return code must be 0 and the context must be system_u:object_r:cron_spool_t
    file_path = b'/etc/cron.d'
    file_con_raw_result_posix = file_con_raw(file_path, None)

# Generated at 2022-06-20 16:43:12.006114
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] == 1


# Generated at 2022-06-20 16:43:16.394870
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    path = to_native(b"/var/log")
    rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
    return [rc, to_native(con.value)]

# Generated at 2022-06-20 16:43:19.395621
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert type(policytype) == str


# Generated at 2022-06-20 16:43:25.300546
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        testvar = lgetfilecon_raw('/etc/selinux/config')[1]
        assert testvar == 'system_u:object_r:etc_runtime_t:s0'
    except:
        print('FAIL')
    else:
        print('PASS')

# Generated at 2022-06-20 16:43:30.941611
# Unit test for function matchpathcon
def test_matchpathcon():
    p = '/tmp/foo'
    m = os.stat(p).st_mode
    [rc, con] = matchpathcon(p, m)
    print(rc)
    print(con)

# Generated at 2022-06-20 16:43:37.956159
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    tmpdir = tempfile.mkdtemp()
    try:
        path = os.path.join(tmpdir, 'testfile')

        rc, con = lgetfilecon_raw(path)
        if rc < 0:
            raise OSError(rc, 'Failed to call lgetfilecon_raw')

    finally:
        os.rmdir(tmpdir)


# Generated at 2022-06-20 16:43:44.384853
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import os
    import sys
    import subprocess
    import pytest
    import tempfile

    __tracebackhide__ = True

    con = selinux_getpolicytype()[1]
    try:
        assert con
    except Exception as e:
        pytest.fail(e)



# Generated at 2022-06-20 16:43:51.284926
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        raise Exception("SELinux is disabled")

    # Test positive match of context
    path = '/etc/passwd'
    mode = os.stat(path).st_mode
    context = 'system_u:object_r:etc_t:s0'

    ret = matchpathcon(path, mode)
    assert ret[0] == 0
    assert ret[1] == context

    # Test negative match of context
    path = '/test/test'
    mode = 0o777
    context = '(null)'

    ret = matchpathcon(path, mode)
    assert ret[0] == -1
    assert ret[1] == context


__all__ = [feature for feature in dir() if not feature.startswith('_')]