

# Generated at 2022-06-20 16:36:03.199218
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, en_mode = selinux_getenforcemode()
    print('The return value is: %d' % rc)
    print('The value of enforcing status is: %d' % en_mode)



# Generated at 2022-06-20 16:36:07.540702
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    if rc != 0:
        raise OSError(rc, os.strerror(rc))
    return [enforcemode.value]



# Generated at 2022-06-20 16:36:16.840524
# Unit test for function matchpathcon
def test_matchpathcon():
    filename = b'/tmp/file_for_testing_matchpathcon'
    fd = os.open(filename, os.O_RDWR | os.O_CREAT, 0o666)
    os.close(fd)
    os.unlink(filename)

    try:
        rc = _selinux_lib.matchpathcon(filename, 0, None)
        errno = get_errno()
        assert rc < 0
        assert errno == 2
    finally:
        errno = get_errno()
        assert errno == 0
        get_errno.argtypes = None
        get_errno.restype = errno

# Generated at 2022-06-20 16:36:21.574176
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if sys.platform != 'linux':
        raise SkipTest("Requires Linux")
    policytype = selinux_getpolicytype()
    if policytype[0] != 0:
        assert False, "selinux_getpolicytype returned error code {0}".format(policytype[0])
    assert policytype[1] == "targeted"



# Generated at 2022-06-20 16:36:24.080333
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    print("return code is: {0}".format(rc))
    print("policy type is: {0}".format(policytype))



# Generated at 2022-06-20 16:36:26.059315
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if not selinux_getpolicytype()[1]:
        raise AssertionError('selinux_getpolicytype is not avaialable')
    return True

# Generated at 2022-06-20 16:36:30.265528
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("Testing function selinux_getenforcemode")
    [rc, enforcemode] = selinux_getenforcemode()
    print("rc: ", rc)
    print("enforcemode: ", enforcemode)
    if rc < 0:
        return 1
    else:
        return 0



# Generated at 2022-06-20 16:36:32.685840
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)


# Generated at 2022-06-20 16:36:37.276016
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = os.environ['HOME']
    rc, con = lgetfilecon_raw(file)
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_home_t:s0'

# Generated at 2022-06-20 16:36:39.432929
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0



# Generated at 2022-06-20 16:36:44.390556
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/selinux/config"
    rc, con = lgetfilecon_raw(path)
    assert type(con) == str
    assert rc == 0


# Generated at 2022-06-20 16:36:54.618079
# Unit test for function matchpathcon
def test_matchpathcon():
    cwd = os.getcwd()
    path = '/usr/bin'
    mode = 0o755
    rc, con = matchpathcon(path, mode)
    print("Path: %s, Mode: %o, Context: %s" % (path, mode, con))
    path = '/usr/bin/ls'
    mode = 0o755
    rc, con = matchpathcon(path, mode)
    print("Path: %s, Mode: %o, Context: %s" % (path, mode, con))
    path = 'example_dir'
    mode = 0o777
    os.mkdir(path)
    os.chdir('%s/%s' % (cwd, path))
    rc, con = matchpathcon(path, mode)

# Generated at 2022-06-20 16:36:59.001123
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    test_result_array = selinux_getenforcemode()
    test_result = test_result_array[1]
    if test_result == 0:
        enforce_mode = 'Permissive'
    else:
        enforce_mode = 'Enforcing'
    return enforce_mode


# Generated at 2022-06-20 16:37:03.981639
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """Unit test for function selinux_getpolicytype"""

    try:
        rc, policytype = selinux_getpolicytype()
    except Exception:
        sys.exit('Cannot find policytype')

    if rc != 0:
        sys.exit('Cannot get policytype: errno = %d' % rc)

    if policytype == "":
        sys.exit('Cannot get policytype: null')


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:37:06.260528
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    current_policy = selinux_getpolicytype()
    assert current_policy == [0, 'targeted']

# Generated at 2022-06-20 16:37:08.783933
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, convalue = matchpathcon('/etc/hosts', 0)
    assert rc == 0
    assert convalue == 'unconfined_u:object_r:etc_t:s0'



# Generated at 2022-06-20 16:37:10.579495
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc >= 0
    assert isinstance(enforcemode, int)



# Generated at 2022-06-20 16:37:12.967941
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/foo'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-20 16:37:25.104940
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # test successful call
    [rc, con] = lgetfilecon_raw('/proc/self/exe')
    assert rc == 0
    assert con == 'system_u:object_r:unconfined_t:s0'

    # test call on non-existing file
    # FIXME: selinux error codes do not seem to be consistent across linux
    # distributions.  We'll wait for a better solution.
    # [rc, con] = lgetfilecon_raw('/etc/zyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyzyz')
    # assert rc == -1



# Generated at 2022-06-20 16:37:34.012486
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test on a symbolic link, pass
    fname = b'/tmp/selinux_lgetfileconxtest'
    if os.path.exists(fname):
        os.remove(fname)
    os.symlink('/proc/cpuinfo', fname)
    try:
        rc, con = lgetfilecon_raw(fname)
        assert rc == 0
        assert con == 'system_u:object_r:lnk_file:s0'
    finally:
        os.remove(fname)
    # Test on a not existing file, should throw error
    fname = b'/tmp/selinux_lgetfileconxtest2'
    if os.path.exists(fname):
        os.remove(fname)

# Generated at 2022-06-20 16:37:37.859506
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert mode in [0, 1, 2]



# Generated at 2022-06-20 16:37:41.066081
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()

    assert isinstance(policytype, str)
    assert isinstance(rc, int)



# Generated at 2022-06-20 16:37:46.190821
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("Testing selinux_getpolicytype")
    [rc, con] = selinux_getpolicytype()
    if rc != -1:
        print("\tselinux_getpolicytype returned: {0}".format(con))
    else:
        raise Exception("\tselinux_getpolicytype failed")



# Generated at 2022-06-20 16:37:50.242109
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from os import path

    if not path.exists('/proc/self/attr/current'):
        raise SkipTest('SELinux not enabled')

    rc, con = lgetfilecon_raw('/')
    assert rc == 0

# Generated at 2022-06-20 16:37:57.421701
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
      unit test for selinux_getcon
    """
    con = lgetfilecon_raw('/usr/bin/passwd')
    assert con == [0, 'system_u:object_r:usr_t']
    con = lgetfilecon_raw('/etc/passwd')
    assert con == [0, 'system_u:object_r:etc_runtime_t']
    con = lgetfilecon_raw('/tmp/passwd')
    assert con == [-1, None]


# Generated at 2022-06-20 16:38:04.533423
# Unit test for function matchpathcon
def test_matchpathcon():
    if os.path.exists('/etc') and os.path.exists('/etc/passwd'):
        # Normal returns
        assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t:s0']
        assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:passwd_file_t:s0']
        assert matchpathcon('/etc', 16) == [0, 'system_u:object_r:etc_t:s0']
        assert matchpathcon('/etc/passwd', 16) == [0, 'system_u:object_r:passwd_file_t:s0']
        # Missing file
        assert matchpathcon('/missing', 0) == [-1, None]
        assert match

# Generated at 2022-06-20 16:38:08.657772
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    actual = lgetfilecon_raw(b'/etc/shadow')
    expected = [0, b'system_u:object_r:shadow_t:s0']
    assert actual == expected

# Generated at 2022-06-20 16:38:10.010194
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'

# Generated at 2022-06-20 16:38:13.729276
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, 'SELinux getpolicytype failed. Return Code: ' + str(rc) + ' Policy Type: ' + to_native(policytype)


# Generated at 2022-06-20 16:38:15.606157
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    output = lgetfilecon_raw('/etc/passwd')
    assert output[0] >= 0
    assert output[1] is not None


# Generated at 2022-06-20 16:38:20.841929
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # selinux_getenforcemode()
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0



# Generated at 2022-06-20 16:38:21.910194
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()


# Generated at 2022-06-20 16:38:30.595199
# Unit test for function matchpathcon
def test_matchpathcon():
    des = 'user_u:object_r:bin_t:s0'
    test_dir = b'testdir'
    test_file = b'testdir/afile'
    os.makedirs(test_dir, 0o775)
    with open(test_file, 'w') as f:
        f.write('a test file\n')
    os.chown(test_file, 1001, 1002)
    assert lgetfilecon_raw(test_file)[1] == des
    assert matchpathcon(test_file, os.R_OK)[1] == des
    assert matchpathcon(test_file, os.W_OK)[1] == des
    assert matchpathcon(test_file, os.X_OK)[1] == des

# Generated at 2022-06-20 16:38:33.345281
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, mode] = selinux_getenforcemode()
    assert rc == 0
    assert mode in [0, 1, 2]



# Generated at 2022-06-20 16:38:35.519786
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    if rc < 0:
        raise RuntimeError('unable to get selinux enforce mode')
    print(enforcemode)



# Generated at 2022-06-20 16:38:38.761038
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, result = selinux_getpolicytype()
    print(rc, result)



# Generated at 2022-06-20 16:38:40.380056
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/rc.local', 0)
    assert(rc == 0)
    assert(con == 'system_u:object_r:initrc_exec_t:s0')


# Generated at 2022-06-20 16:38:43.136766
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0
    assert selinux_getpolicytype()[1] == "targeted"

# Generated at 2022-06-20 16:38:49.679708
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create a test file
    TF = open('temp_file.txt', 'w')
    TF.write('')
    TF.close()
    [rc, con] = matchpathcon("temp_file.txt", 0)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'



# Generated at 2022-06-20 16:38:52.939140
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert os.path.exists('/')
    rc, con = lgetfilecon_raw('/')
    assert rc == 0
    assert con == 'system_u:object_r:root_t:s0'


# Generated at 2022-06-20 16:39:02.210410
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Testing function selinux_getpolicytype
    # Expected
    # 1. Call function selinux_getpolicytype to get value, the return value should be 0
    assert selinux_getpolicytype() == [0, 'targeted']



# Generated at 2022-06-20 16:39:04.472996
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/home/user/myfile'
    mode = 1
    rc, con_str = matchpathcon(path, mode)
    # This test case is only for fedora based systems
    assert rc == 0
    assert con_str == 'user_u:object_r:user_home_t:s0'

# Generated at 2022-06-20 16:39:15.089991
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import os

    try:
        cwd = os.getcwd()
        tmpdir = tempfile.mkdtemp()
        tmpfile = os.path.join(tmpdir, "ansible_module.py")
        shutil.copy(__file__, tmpfile)

        os.chdir(tmpdir)
        rc, output = lgetfilecon_raw(tmpfile)

    except Exception as e:
        return False
    finally:
        os.remove(tmpfile)
        os.rmdir(tmpdir)
        os.chdir(cwd)

    if rc != 0:
        return False

    return True

if __name__ == "__main__":
    print(test_lgetfilecon_raw())

# Generated at 2022-06-20 16:39:18.643188
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    rc, con = matchpathcon('test_file', 1)
    print(rc, con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:39:23.035413
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    output = []
    try:
        rc, mode = selinux_getenforcemode()
    except Exception as err:
        output = [None, to_native(err)]
    else:
        output = [rc, mode]

    return output



# Generated at 2022-06-20 16:39:25.461132
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, _ = selinux_getpolicytype()
    assert rc == 0, "failed to get policy type, rc={0}".format(rc)



# Generated at 2022-06-20 16:39:28.879999
# Unit test for function matchpathcon
def test_matchpathcon():
    r, c = matchpathcon('/', 0)
    assert r == 0
    assert c.startswith('system_u:object_r:etc_t:s0')



# Generated at 2022-06-20 16:39:39.386374
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Test 1: If a path is provided, ensure it returns the name of the current SELinux
    # policy module used by the kernel
    try:
        if is_selinux_enabled():
            rc, con = selinux_getpolicytype()
            if rc == 0:
                assert con == 'targeted', "Test 1: Test failed"
            else:
                assert rc    == 0, "Test 1: rc should be 0"
        else:
            assert is_selinux_enabled() == 1, "Test 1: SELinux should be enabled"
    except ImportError as e:
        print("Test 1: Error Loading libselinux: %s" % e)


# Generated at 2022-06-20 16:39:41.204124
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Not testing output in the tests, just that it doesn't throw an exception
    lgetfilecon_raw('/')

# Generated at 2022-06-20 16:39:43.750699
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_name = selinux_getpolicytype()
    if rc == 0:
        assert isinstance(policy_name, str)
    else:
        assert rc == -1

# Generated at 2022-06-20 16:40:00.888617
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    f = selinux_getenforcemode()
    assert f == [0, 0]



# Generated at 2022-06-20 16:40:02.825738
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        [rc, data] = selinux_getpolicytype()
    except NotImplementedError:
        return
    assert rc == 0, 'Error: failed to obtain policy type: %d' % rc
    assert data == 'targeted', 'Error unexpected policy type: %s' % repr(data)

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:40:06.940423
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_bytes

    path = '/./%s' % os.urandom(16).hex()
    os.mkdir(path)
    try:
        rc, con = matchpathcon(path, 0)
        assert rc == 0
        assert con is not None
    finally:
        os.rmdir(path)


# Generated at 2022-06-20 16:40:08.112400
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Print results
    print(selinux_getpolicytype())

# Generated at 2022-06-20 16:40:11.612026
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    cwd_con = lgetfilecon_raw('.')[1]
    tmp_con = lgetfilecon_raw('/tmp')[1]
    if cwd_con != tmp_con:
        raise Exception('cwd: {0}, tmp: {1}'.format(cwd_con, tmp_con))

# Generated at 2022-06-20 16:40:14.909055
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        _selinux_lib.freecon(con)
        return rc
    except:
        raise Exception('Unable to getfilecon_raw of path %s' % path)

# Generated at 2022-06-20 16:40:24.459886
# Unit test for function matchpathcon
def test_matchpathcon():
    # Selinux is not enabled on non-selinux systems
    if not is_selinux_enabled():
        print("Selinux is not enabled on this system")
        return

    # Try calling matchpathcon with sample path and mode
    # Print results
    res = matchpathcon('/var/log', os.R_OK)
    if res[0] == -1:
        print("Failed to retrieve the context of path /var/log")
        print("Please check if this path is present on system")
    else:
        print("Context of path /var/log: %s" % res[1])



# Generated at 2022-06-20 16:40:26.323054
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforce = selinux_getenforcemode()
    assert enforce[0] >= 0
    assert enforce[1] == 1 or enforce[1] == 0

# Generated at 2022-06-20 16:40:28.189345
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Example: /usr/bin/groups type=system_u:object_r:usr_t
    path = "/usr/bin/groups"
    command = ["lgetfilecon_raw", path]
    rc, stdout, stderr = module.run_command(command)
    assert rc == 0



# Generated at 2022-06-20 16:40:30.193457
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = matchpathcon('/foo/bar', 0)
        assert rc == 0
    except ImportError:
        assert True

# Generated at 2022-06-20 16:41:09.697716
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """ This function is called by the unit test to verify the module is working """
    rc, con = selinux_getpolicytype()
    assert rc is 0, 'selinux_getpolicytype failed'
    assert con is not None, 'selinux_getpolicytype failed: returned None'
    assert con == 'targeted', 'selinux_getpolicytype returned {} instead of "targeted"'.format(con)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('file', nargs='?', default=None, help='get context for this file')
    parser.add_argument('-v', '--validate', action='store_true', help='validate returned context of the given file')
    args = parser.parse_args()


# Generated at 2022-06-20 16:41:16.047595
# Unit test for function matchpathcon
def test_matchpathcon():
    b = matchpathcon('/tmp', 0)
    con = b[1]
    assert con

    b = matchpathcon('/', 0)
    con = b[1]
    assert con

    b = matchpathcon('/usr/share/foo', 0)
    con = b[1]
    assert con

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:41:22.408029
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp', os.R_OK)
    if rc != 0:
        raise ValueError('Unable to matchpathcon')

    print('Matched context: {0}'.format(con))


if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-20 16:41:26.200728
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/resolv.conf', 0)
    if rc == -1:
        raise OSError('unable to get selinux label')
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-20 16:41:33.425060
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing matchpathcon")
    rc, value = matchpathcon('/etc/security/sepermit.conf', 0)
    print("Return Code: %d" % (rc))
    print("Security Context: %s" % (value))
    if rc != 0:
        raise Exception("Test Failed")



# Generated at 2022-06-20 16:41:36.202219
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode in (0, 1, 2)



# Generated at 2022-06-20 16:41:43.083913
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, val = selinux_getenforcemode()
    assert isinstance(rc, int), "Return type of selinux_getenforcemode() should be 'int'."
    assert isinstance(val, int), "Return type of selinux_getenforcemode() should be 'int'."



# Generated at 2022-06-20 16:41:46.608576
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Test for function selinux_getenforcemode
    '''
    rc, enforcemode = selinux_getenforcemode()
    assert rc >= 0


# Generated at 2022-06-20 16:41:55.846179
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('Testing selinux_getpolicytype')
    [rc, sepolicy] = selinux_getpolicytype()

    if rc != 0:
        print('Unexpected return code: {}'.format(rc))
        print('Expected return code: {}'.format(0))

    if sepolicy != 'targeted':
        print('Unexpected policy: {}'.format(sepolicy))
        print('Expected policy: {}'.format('targeted'))


# Generated at 2022-06-20 16:42:00.075739
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # make sure its Enforce Mode is Enforcing
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1


# Generated at 2022-06-20 16:42:44.970729
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text
    if is_selinux_enabled():
        path = u'/var/tmp'
        mode = 0
        rc, con = matchpathcon(to_bytes(path, errors='surrogate_or_strict'), mode)
        if rc < 0:
            raise OSError(rc, to_native(os.strerror(rc)))
        else:
            rc = _selinux_lib.security_check_context(con)
            if rc < 0:
                raise OSError(rc, to_native(os.strerror(rc)))
    else:
        raise SystemError('SELinux not enabled')

# Generated at 2022-06-20 16:42:49.243924
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/tmp/foo.txt", 0) == [0, "system_u:object_r:tmp_t:s0:c0.c1023"]

# Generated at 2022-06-20 16:42:51.233216
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


# Generated at 2022-06-20 16:42:58.655228
# Unit test for function matchpathcon
def test_matchpathcon():
    # Module name, function name, test description, params, expected result
    test_inputs = [
        ('matchpathcon', 'test', 'Expected to return zero (success) when good params are passed', ['/etc/passwd', 0], 0),
    ]

    for test_input in test_inputs:
        module = test_input[0]
        test = test_input[1]
        desc = test_input[2]
        params = test_input[3]
        expected = test_input[4]

        function = getattr(sys.modules[__name__], module)
        result = function(*params)

        if result != expected:
            print('Test: {0} - {1}: FAILED'.format(test, desc))
            print('Expected: %s. Got %s' % (expected, result))

# Generated at 2022-06-20 16:43:04.793703
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))
    else:
        return [rc, enforcemode.value]



# Generated at 2022-06-20 16:43:10.549516
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, value) = selinux_getpolicytype()
    assert rc == 0, "selinux_getpolicytype returned an error"
    assert value == "targeted", "selinux_getpolicytype returned an unexpected value"



# Generated at 2022-06-20 16:43:14.130755
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-20 16:43:18.750530
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcement, return_val = selinux_getenforcemode()
    if enforcement == 0:
        print('SELinux is enforcing')
    elif enforcement == 1:
        print('SELinux is permissive')
    elif enforcement == -1:
        print('SELinux is disabled')
    else:
        print('Invalid enforcement value')
    print('return value: %d' % return_val)



# Generated at 2022-06-20 16:43:24.678559
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)


if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-20 16:43:29.608073
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    expected_value = [0, 1]
    return_value = selinux_getenforcemode()
    assert return_value == expected_value


# Generated at 2022-06-20 16:45:03.981409
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    @context: Function lgetfilecon_raw test
    """
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    def execute_module(path, mode, **kwargs):
        module_args = dict(path=path, mode=mode)
        module_args.update(**kwargs)

        module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

        rc, con = lgetfilecon_raw(path)
        module.exit_json(rc=rc, con=con)

    path = "/var/log"
    mode = '0400'

# Generated at 2022-06-20 16:45:09.382526
# Unit test for function matchpathcon
def test_matchpathcon():
    err, con = matchpathcon(b"/tmp/foo.txt", int(0o744))
    if con is not None:
        print(con)
    else:
        print("err is {0}".format(err))



# Generated at 2022-06-20 16:45:11.301267
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert isinstance(rc, int)
    assert isinstance(enforcemode, int)

# Generated at 2022-06-20 16:45:14.218514
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    Test for matchpathcon function
    In real world, we can't ensure that path with mode 0 is always exist
    '''
    result = matchpathcon('/', 0)
    assert result[0] == -1
    assert 'No such file or directory' in result[1]

# Generated at 2022-06-20 16:45:23.336746
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        import pytest
    except ImportError:
        return

    if not is_selinux_enabled():
        pytest.skip("selinux disabled")

    if not is_selinux_mls_enabled():
        pytest.skip("selinux mls disabled")

    rc, policytype = selinux_getpolicytype()
    assert rc == 0

    if policytype not in ['targeted', 'mls']:
        pytest.skip("selinux policy type %s not supported" % policytype)

    return True

# Generated at 2022-06-20 16:45:31.759618
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # this test is only performing one lookup
    _selinux_lib._test_selinux_load_policy.argtypes = [c_char_p]

    # backup variables
    _old_selinux_load_policy = _selinux_lib._test_selinux_load_policy
    _old_selinux_policy_root = _selinux_lib._test_selinux_policy_root
    _old_selinux_prefix_name = _selinux_lib._test_selinux_prefix_name
    _old_selinux_mnt_point = _selinux_lib._test_selinux_mnt_point
    _old_selinux_file_context_path = _selinux_lib._test_selinux_file_context_path

    # initialize variables

# Generated at 2022-06-20 16:45:35.558132
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    # This varaible doesn't actually exist, the only reason it's here is because
    # pylint doesn't like the fact that rc isn't used.
    #pylint: disable=unused-variable
    return mode


# Generated at 2022-06-20 16:45:39.063109
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    if result[0] < 0:
        print(to_native(os.strerror(result[0])))
        raise RuntimeError('selinux_getpolicytype failure')
    else:
        print(u"Policy Type = {0}".format(result[1]))

# Generated at 2022-06-20 16:45:43.288532
# Unit test for function matchpathcon
def test_matchpathcon():
    # should return 0 and the context string
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-20 16:45:50.798725
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    with open('/etc/fstab') as fstab:
        with open('/tmp/fstab-ctypes', 'w') as fout:
            for line in fstab:
                if line.startswith('#'):
                    fout.write(line)
                    continue
                [rc, sctx] = lgetfilecon_raw(line.split(' ')[0])
                if rc < 0:
                    continue
                print('%s %s' % (line.strip(), sctx), file=fout)