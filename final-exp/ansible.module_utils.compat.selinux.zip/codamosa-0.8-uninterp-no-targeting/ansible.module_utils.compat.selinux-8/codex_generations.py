

# Generated at 2022-06-20 16:36:05.500475
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from uuid import uuid4
    filename = str(uuid4())
    path = "/tmp/%s" % filename
    with open(path, 'w') as f:
        f.write("some content")
    get_con = lgetfilecon_raw(path)
    set_con = lsetfilecon(path, get_con[1])
    assert(get_con[0] == set_con[0])
    assert(get_con[1] == get_con[1])
    os.remove(path)


# Generated at 2022-06-20 16:36:08.185428
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, -1]



# Generated at 2022-06-20 16:36:13.248448
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/data/'
    mode = 0
    result = matchpathcon(path, mode)
    assert result[0] == 0
    if result[0] == 0:
        assert result[1] == u'system_u:object_r:var_lib_t:s0'



# Generated at 2022-06-20 16:36:15.318463
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert type(selinux_getenforcemode()) is list
    assert len(selinux_getenforcemode()) == 2



# Generated at 2022-06-20 16:36:17.528212
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'
    assert selinux_getpolicytype()[0] == 0



# Generated at 2022-06-20 16:36:19.266904
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-20 16:36:23.521311
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test selinux_getpolicytype()
    """
    # my environment has target policy type set to
    # "targeted", which should return 0 for success
    # and the policy type string for val
    rc, val = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(val, str)
    assert val == "targeted"



# Generated at 2022-06-20 16:36:27.409799
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etcd/member', os.R_OK)
    if rc != 0:
        raise Exception('%r: %r' % (rc, con))
    assert con == 'etcd_t:object_r:etcd_member_exec_t:s0'


# Generated at 2022-06-20 16:36:35.387387
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def check_result(rc, con):
        if rc != 0:
            raise OSError(rc, 'lgetfilecon_raw failed')
        if con is None:
            raise Exception('lgetfilecon_raw context should not be None')
        if con == '':
            raise Exception('lgetfilecon_raw context should not be empty')
        return True

    # Makes unit test run no matter where it is executed.
    # Unit test must be run from the same directory from which it is executed.
    orig_dir = os.getcwd()
    os.chdir(os.path.dirname(__file__))

# Generated at 2022-06-20 16:36:39.689743
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, mode) = _selinux_lib.selinux_getenforcemode()
    print('mode {0}'.format(mode))


# Generated at 2022-06-20 16:36:43.096809
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'


# Generated at 2022-06-20 16:36:47.627258
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('/foo/bar/baz', 0)
    assert ret[0] == 0, 'expected success but got %d' % ret[0]
    assert ret[1] == 'system_u:object_r:admin_home_t:s0', 'expected right security context but got %s' % ret[1]

# Generated at 2022-06-20 16:36:50.194362
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon(b'/tmp/testing.txt', 0)
    assert res == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-20 16:36:53.020063
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, file_context = lgetfilecon_raw('/etc/passwd')
    assert file_context == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-20 16:36:54.240960
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert [0, 'targeted'] == selinux_getpolicytype()


# Generated at 2022-06-20 16:36:56.769950
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, value) = selinux_getenforcemode()
    print("rc=%d value=%d" % (rc, value))


# Generated at 2022-06-20 16:36:57.996497
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print(lgetfilecon_raw('/etc/passwd'))


# Generated at 2022-06-20 16:37:00.911511
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    unit_test_flag = 0
    try:
        selinux_getpolicytype()
    except:
        unit_test_flag += 1
    assert unit_test_flag == 0


# Generated at 2022-06-20 16:37:03.417837
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path_con = lgetfilecon_raw(b'/etc')

    assert path_con[1] == b'system_u:object_r:etc_t:s0'
    assert path_con[0] == 0


# Generated at 2022-06-20 16:37:05.013311
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-20 16:37:13.721409
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Ensure that selinux_getpolicytype works correctly
    """
    print("selinux_getpolicytype()\n")
    rc, policytype = selinux_getpolicytype()
    print("selinux_getpolicytype():\n  rc: {0}\n  policytype: {1}\n".format(rc, policytype))

    if policytype == 'targeted':
        print("Success!\n")
        return True
    else:
        print("Failure!\n")
        raise RuntimeError("Policy type is {0} not targeted".format(policytype))


if __name__ == "__main__":
    # Test selinux_getpolicytype()
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:37:17.752911
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:file_t:s0']



# Generated at 2022-06-20 16:37:21.999856
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, 'selinux_getpolicytype failed with: {0}'.format(os.strerror(rc))
    assert policytype == 'targeted', 'selinux_getpolicytype did not return "targeted"'


# Generated at 2022-06-20 16:37:24.510112
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:37:30.600329
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Create a temporary file
    (fd, fn) = tempfile.mkstemp()
    try:
        # Close temporary file's file descriptor
        os.close(fd)
        # Make sure file exists
        if os.path.exists(fn):
            # Get policy type
            policytype = selinux_getpolicytype()
            # Check if policytype is not None
            if policytype is not None:
                # Assert that policy type is string
                assert isinstance(policytype, str)
            else:
                # Assert that policy type is not None
                assert policytype is not None
        else:
            # Assert that file exists
            assert os.path.exists(fn)
    finally:
        # Remove temporary file
        os.unlink(fn)

# Generated at 2022-06-20 16:37:32.974725
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc >= 0

# Generated at 2022-06-20 16:37:39.854162
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test if the function is implemented and callable
    assert callable(_selinux_lib.lgetfilecon_raw)
    libcall = _selinux_lib.lgetfilecon_raw
    path="self.python"

    # Test if NULL pointer as a path is handled correctly
    rc = libcall(None, None)
    assert rc == -1

    # Test if the call on a non-existing file is handled correctly
    rc = libcall(path, None)
    assert rc == -1



# Generated at 2022-06-20 16:37:49.323554
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = '/etc/passwd'
    # Write a string to the file and then use lgetfilecon_raw to get the mode for the file
    with open(filename, 'w') as f:
        f.write('This is a test')
        f.close()
    # Check the mode of the file
    rc, con = lgetfilecon_raw(filename)
    if rc == 0:
        print('The context of the file ' + filename + ' is: ' + con)
        os.remove(filename)
    else:
        print('Error while trying to get file context')


# Generated at 2022-06-20 16:37:52.500667
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if is_selinux_enabled():
        assert lgetfilecon_raw("/dev/kmsg")[0] == 0
    else:
        assert lgetfilecon_raw("/dev/kmsg")[0] == -1


# Generated at 2022-06-20 16:37:54.565374
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    retval = selinux_getpolicytype()
    assert retval[0] == 0
    assert isinstance(retval[1], str) or isinstance(retval[1], unicode)

# Generated at 2022-06-20 16:38:04.635440
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Set file context
    file_path = '/tmp/test1.txt'
    file_context = 'system_u:object_r:default_t:s0'
    with open(file_path, 'w') as f:
        f.write('test1')
        rc, _ = lsetfilecon(file_path, file_context)
        f.close()
        if rc != 0:
            raise AssertionError("Failed to set file context for %s with error %s" % (file_path, rc))

    # Get file context
    rc, file_context_ret = lgetfilecon_raw(file_path)

# Generated at 2022-06-20 16:38:09.316356
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Test function selinux_getenforcemode
    '''
    errno, enforcemode = selinux_getenforcemode()
    assert isinstance(enforcemode, int)
    assert isinstance(errno, int)



# Generated at 2022-06-20 16:38:12.960691
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    assert matchpathcon('/usr/sbin/booo', 0) == [0, 'system_u:object_r:initrc_exec_t:s0']


# Generated at 2022-06-20 16:38:20.861473
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create a file in scratch space for testing
    path = '/2013-08-14-21:49:01/YYYY-MM-DD/HH:mm:SS'
    fpath = '/tmp/ansible-selinux{}'.format(path)

    try:
        os.makedirs(fpath)
    except OSError:
        if not os.path.exists(fpath):
            raise

    assert os.path.exists(fpath)

    # Run matchpathcon
    res, con = matchpathcon(fpath, os.R_OK)
    assert con.endswith('/2013-08-14-21:49:01/YYYY-MM-DD(/.*)?')

    # Cleanup
    os.rmdir(fpath)

# Generated at 2022-06-20 16:38:23.463978
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode(), list)


# Generated at 2022-06-20 16:38:24.408942
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-20 16:38:29.395052
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforce = selinux_getenforcemode()
    if rc != 0:
        raise RuntimeError("unable to determine SELinux state")
    else:
        enforcemode = ['Disabled', 'Permissive', 'Enforcing']
        return enforcemode[enforce]



# Generated at 2022-06-20 16:38:31.455112
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-20 16:38:33.902457
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        return selinux_getenforcemode()
    except OSError:
        return [0, 0]


# Generated at 2022-06-20 16:38:36.226897
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.selinux import selinux_getenforcemode
    (rc, enforcemode) = selinux_getenforcemode()
    assert enforcemode in [0, 1, 2, 3]


# Generated at 2022-06-20 16:38:44.657399
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # set mock data
    os.environ["SELINUX_ENFORCE"] = "0"
    rc = 0
    expected_value = 0
    # call function
    actual_value = selinux_getenforcemode()
    # assert results
    assert actual_value == [rc, expected_value]


# Generated at 2022-06-20 16:38:47.733121
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, label) = selinux_getpolicytype()
    assert label == 'targeted'



# Generated at 2022-06-20 16:38:54.569981
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # First test if the module is loadable
    assert isinstance(selinux_getenforcemode, object)

    # Ensure that the function returns a tuple
    assert isinstance(selinux_getenforcemode(), tuple)

    # Ensure that the tuple len matches the number of return values
    assert len(selinux_getenforcemode()) == 2

    # Ensure that the tuple contains the required return values
    assert selinux_getenforcemode()[0] in (0, 1, -1)

    # Ensure that the tuple contains the required return values
    assert selinux_getenforcemode()[1] in (0, 1, 2)



# Generated at 2022-06-20 16:39:00.123948
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def _test_lgetfilecon_raw():
        print(type(libselinux))
        print(str(type(libselinux)))
        print(type(_selinux_lib))
        print(str(type(_selinux_lib)))
        print(dir(libselinux))
        print(dir(_selinux_lib))
        print(type(libselinux.lgetfilecon_raw))
        print(type(_selinux_lib.lgetfilecon_raw))
        print(dir(libselinux.lgetfilecon_raw))
        print(dir(_selinux_lib.lgetfilecon_raw))
        for i in range(0, 10):
            print(libselinux.lgetfilecon_raw('/sys/fs/cgroup/systemd'))


# Generated at 2022-06-20 16:39:05.648636
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import subprocess
    import tempfile

    def _setup_test_file(selinux_context):
        fd, path = tempfile.mkstemp()
        fcntl.close(fd)
        # If a path is created with os.mknod, SELinux doesn't allow for it to be
        # relabeled by default. To workaround this, the temporary file is removed
        # and the path is created using touch. mkstemp creates the file with a
        # tempname so this operation is safe.
        os.remove(path)
        subprocess.check_call(['touch', path])
        subprocess.check_call(['chcon', '-t', 'bin_t', path])
        return path


# Generated at 2022-06-20 16:39:09.040885
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon('test_file', 0)
    if rc[0] == 0:
        print('succeed in running matchpathcon function')
    else:
        print('failed to run matchpathcon function')
        raise



# Generated at 2022-06-20 16:39:17.645648
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test 1: test exception
    try:
        _selinux_lib.selinux_getenforcemode.argtypes = None
        _selinux_lib.selinux_getenforcemode.restype = None
    except ValueError as e:
        pass
    else:
        assert False, 'failed to raise exception'

    # Test 2: test return value
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    assert [rc, enforcemode.value] == selinux_getenforcemode()


# Generated at 2022-06-20 16:39:19.717288
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    path = os.path.join(tmp_dir, "test_matchpathcon")
    open(path, 'a').close()
    mode = 0o400
    con_result = matchpathcon(path, mode)
    mode = 0o600
    con_result = matchpathcon(path, mode)
    return con_result


# Generated at 2022-06-20 16:39:23.121451
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if os.path.exists("/etc/selinux/config"):
        assert selinux_getenforcemode() == [0, 1]
    else:
        assert selinux_getenforcemode() == [-1, 0]



# Generated at 2022-06-20 16:39:25.210628
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pathname = '/'
    result, context = lgetfilecon_raw(pathname)
    if context:
        print(context)


# Generated at 2022-06-20 16:39:33.912194
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    status, policytype = selinux_getpolicytype()
    assert status == 0
    assert isinstance(status, int)
    assert isinstance(policytype, str)
    assert policytype == 'targeted'


# Generated at 2022-06-20 16:39:37.604842
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    path = '/home/username/test.txt'
    with open(path, 'w') as f: f.write('test content')
    rc, policytype = selinux_getpolicytype()
    assert rc == 0 and policytype is not None

# Generated at 2022-06-20 16:39:42.342230
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/selinux/null', 0)
    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))
    assert con == "system_u:object_r:null_device_t:s0"

# Generated at 2022-06-20 16:39:44.288764
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1


# Generated at 2022-06-20 16:39:45.842178
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] == 0


# Generated at 2022-06-20 16:39:48.545462
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc = selinux_getenforcemode()
    # It should return [0, 1] if selinux is in enforcing mode
    # or [0, 0] otherwise
    assert rc == [0, 1] or rc == [0, 0]


# Generated at 2022-06-20 16:39:57.888007
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Computed concrete file name.
    file_name = "/tmp/ansible_test_file"
    # Create test file.
    open(file_name, "a").close()

    # Call function and verify return value.
    [rc, con] = lgetfilecon_raw(file_name)
    assert rc == 0
    assert con != "unlabeled"

    # Remove test file.
    os.remove(file_name)


__all__ = [
    'lgetfilecon_raw',
    'matchpathcon',
    'security_getenforce',
    'security_policyvers',
    'selinux_getenforcemode',
    'selinux_getpolicytype',
]

# Generated at 2022-06-20 16:40:00.884461
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(con, str)

# Generated at 2022-06-20 16:40:02.317885
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-20 16:40:08.067617
# Unit test for function matchpathcon
def test_matchpathcon():
    # Set the path of the file to get the security context
    # The file is created with the following context:
    # system_u:object_r:user_home_t:s0
    # To create the file, you can use the following command:
    # $ touch /tmp/testfile; chcon -t user_home_t /tmp/testfile;
    path = '/tmp/testfile'
    # Get the security context of the file
    mode = 0
    ret = matchpathcon(path, mode)
    print(ret)


# Generated at 2022-06-20 16:40:21.585371
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    if rc != 0:
        print('selinux_getenforcemode failed: %s', os.strerror(rc))
    print("Selinux enforcement mode: %s" % mode)



# Generated at 2022-06-20 16:40:28.727224
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import sys
    from ansible.module_utils.selinux_policy import selinux_getpolicytype

    cur_dir = sys.path[0]

    # Test for correct return codes
    assert selinux_getpolicytype()[0] == 0
    assert selinux_getpolicytype(to_bytes('/foo'))[0] == 0

    # Test for correct return values
    assert selinux_getpolicytype()[1] == 'targeted'
    assert selinux_getpolicytype(to_bytes(cur_dir))[1] == ''
    assert selinux_getpolicytype(to_bytes('/foo'))[1] == ''



# Generated at 2022-06-20 16:40:32.186645
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import os
    import sys
    rc, policy_type = selinux_getpolicytype()
    os.write(sys.stdout, 'selinux_getpolicytype: {0} {1}\n'.format(rc, policy_type).encode())

# Generated at 2022-06-20 16:40:33.432427
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1



# Generated at 2022-06-20 16:40:37.785048
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    if rc:
        errmsg = 'rc: expected 0, got %d' % rc
        assert False, errmsg
    else:
        if con:
            print('con: %s' % con)
        else:
            errmsg = 'con: expected non-empty, got: %s' % con
            assert False, errmsg


# Generated at 2022-06-20 16:40:40.669725
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/etc/passwd', 0)
    assert result == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-20 16:40:42.191576
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0 and policytype == 'targeted'

# Generated at 2022-06-20 16:40:48.939996
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        fn = os.path.join(os.path.dirname(__file__), 'readable')
        expected = 'unconfined_u:object_r:user_home_t:s0'
        returned = lgetfilecon_raw(fn)[1]
        assert returned == expected, "Returned SELinux context %s does not match expected %s for file %s" % (returned, expected, fn)


# Generated at 2022-06-20 16:40:59.584279
# Unit test for function matchpathcon
def test_matchpathcon():
    # Set SELinux boolean
    rc, _ = selinux_getenforcemode()
    assert rc == 0

    # Set SELinux boolean
    rc, policytype = selinux_getpolicytype()
    assert rc == 0

    # Get SELinux boolean
    rc, con = matchpathcon('/bin/ls', sys.maxsize)
    assert rc == 0

    # Get SELinux boolean
    rc, con2 = lgetfilecon_raw('/bin/ls')
    assert rc == 0
    assert con == con2

    # Get SELinux boolean
    rc, _ = security_getenforce()
    assert rc == 0

    # Get SELinux boolean
    rc, _ = security_policyvers()
    assert rc == 0

    # Get SELinux boolean
    rc,

# Generated at 2022-06-20 16:41:02.672303
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, con] = selinux_getpolicytype()
    if rc < 0:
        raise OSError(rc, os.strerror(rc))



# Generated at 2022-06-20 16:41:22.541994
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0, rc
    assert enforcemode == -1, enforcemode


# Generated at 2022-06-20 16:41:25.455036
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert _selinux_lib.selinux_getpolicytype()
    assert selinux_getpolicytype()

# Generated at 2022-06-20 16:41:27.431200
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type = selinux_getpolicytype()
    assert isinstance(policy_type[0], int)
    assert isinstance(policy_type[1], str)



# Generated at 2022-06-20 16:41:30.253006
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test module selinux_getenforcemode()
    """
    result = selinux_getenforcemode()

    assert result is not None
    assert result[0] == 0
    assert result[1] in ['enforcing', 'permissive', 'disabled']


# Generated at 2022-06-20 16:41:34.632127
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0
    assert selinux_getenforcemode()[1] == 1 or selinux_getenforcemode()[1] == 0


# Generated at 2022-06-20 16:41:37.631332
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(con, str)



# Generated at 2022-06-20 16:41:39.483475
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("Return code from selinux_getenforcemode is " + str(rc))
    print("Enforcemode is " + str(enforcemode))


# Generated at 2022-06-20 16:41:47.064438
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        import selinux
        rc, policytype = selinux.selinux_getpolicytype()
        if rc != 0:
            raise Exception(to_native(selinux.error_message(rc)))
        print('Context is: {0}'.format(policytype))
    except ImportError:
        print('Impossible to import selinux')

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:41:52.486340
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/selinux/config')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-20 16:41:58.113739
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected = ['targeted']
    rc, policytype = selinux_getpolicytype()
    if policytype in expected:
        print("SELinux policy type = {0}".format(policytype))
        assert(rc == 0)
    else:
        print("SELinux policy type = {0}".format(policytype))
        assert(rc != 0)

# Generated at 2022-06-20 16:42:38.977021
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == "targeted"

# Generated at 2022-06-20 16:42:44.265202
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Sanity check by using function in a test case.
    """
    con = '/home/user/.ssh/invalid'
    path = '/home/user'
    mode = os.R_OK
    result = matchpathcon(path, mode)
    assert result[1] == con

# Generated at 2022-06-20 16:42:50.745346
# Unit test for function matchpathcon
def test_matchpathcon():
    fpath = b'/home/me/my_file'
    [rc, res] = matchpathcon(fpath, 0)
    if rc != -1:
       print(res, rc)

if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-20 16:42:56.776815
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/test.txt'
    mode = 0o444
    os.mknod(path, mode)
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon(path.decode("utf-8"), byref(con))
        assert rc == 0
        assert con.value is not None
    finally:
        _selinux_lib.freecon(con)



# Generated at 2022-06-20 16:43:06.674702
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():

    enforceid = selinux_getenforcemode()

    assert enforceid[0] >= 0, \
        "selinux_getenforcemode returned error: %d" % enforceid[0]

    if enforceid[1] == 1:
        assert enforceid[0] == 1, \
            "selinux_getenforcemode returned error: %d" % enforceid[0]
    elif enforceid[1] == 0:
        assert enforceid[0] == 0, \
            "selinux_getenforcemode returned error: %d" % enforceid[0]
    else:
        assert False, \
            "selinux_getenforcemode returned bad value: %d" % enforceid[1]



# Generated at 2022-06-20 16:43:12.563148
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Unit test to test the selinux_getenforcemode() function
    """
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 0 or enforcemode == 1


# Generated at 2022-06-20 16:43:15.826940
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    # Just do some basic testing.
    assert rc == 0
    assert isinstance(policytype, str)


# Generated at 2022-06-20 16:43:20.403515
# Unit test for function matchpathcon
def test_matchpathcon():
    """Unit test code"""

    [rc, matchpathcon_value] = matchpathcon(b'/tmp/test', 1)
    assert matchpathcon_value == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-20 16:43:27.329353
# Unit test for function matchpathcon
def test_matchpathcon():
    # matchpathcon is a synchronous call, so use the current process context
    # to validate the expected response from the call
    from ansible.module_utils.selinux import get_context_of_process

    path = '/usr/bin/python3'
    rc, context = matchpathcon(path, 0)
    assert rc == 0
    assert context == get_context_of_process(os.getpid())

# Generated at 2022-06-20 16:43:39.431446
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils import basic
    import sys
    import os

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    try:
        selinux_enabled = is_selinux_enabled()
    except OSError as e:
        module.fail_json(msg='selinux error: {0}'.format(e))

    if not selinux_enabled:
        module.exit_json(msg='selinux is not enabled on the system')

    try:
        out_var = selinux_getenforcemode()
    except OSError as e:
        module.fail_json(msg='selinux error: {0}'.format(e))

    if out_var[1] == 0:
        module.exit

# Generated at 2022-06-20 16:45:14.924032
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.exists("/etc/selinux"):
        (rc, ret) = lgetfilecon_raw("/etc/selinux")
        if rc == 0:
            assert "selinux_config_t" in ret
        else:
            assert False
    else:
        assert False


# Generated at 2022-06-20 16:45:21.236450
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (iReturnCode, cContext) = lgetfilecon_raw(b"/")
    if iReturnCode < 0:
        raise OSError(None, "test_lgetfilecon_raw: Unable to get context of /")
    return [iReturnCode, cContext]


# Generated at 2022-06-20 16:45:24.757030
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/', 0)
    assert con == 'system_u:object_r:rootfs:s0'
    (rc, con) = matchpathcon('/etc/passwd', 0)
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-20 16:45:34.425700
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon("/etc/selinux/config", 0)
    if rc < 0:
        raise ValueError("selinux_matchpathcon failed")
    else:
        print("SELinux type is %s" % con)

    [rc, enforcemode] = selinux_getenforcemode()
    if rc < 0:
        raise ValueError("selinux_getenforcemode failed")
    else:
        print("SELinux enforce mode is %d" % enforcemode)

    if is_selinux_enabled():
        print("SELinux is enabled")
    else:
        print("SELinux is not enabled")

    if is_selinux_mls_enabled():
        print("MLS SELinux is enabled")

# Generated at 2022-06-20 16:45:37.724133
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    path = os.path.dirname(__file__)
    [rc, res] = selinux_getenforcemode()
    assert rc == 0
    assert res is not None
    assert isinstance(res, int)


# Generated at 2022-06-20 16:45:41.572998
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/sys/block/sda"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0


# Generated at 2022-06-20 16:45:46.547307
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/etc/passwd")
    assert con == "system_u:object_r:etc_runtime_t:s0"
    assert rc == 0



# Generated at 2022-06-20 16:45:49.858028
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = "/usr/sbin/sshd"
    context = "system_u:object_r:sshd_exec_t:s0"
    assert lgetfilecon_raw(filename) == [0, context]



# Generated at 2022-06-20 16:45:53.402316
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result, context = lgetfilecon_raw(b'/tmp')
    print('result: %s' % result)
    print('context: %s' % context)



# Generated at 2022-06-20 16:45:56.764058
# Unit test for function matchpathcon
def test_matchpathcon():
    # Return [rc, value]
    result = matchpathcon(b'/usr/bin/tee', os.R_OK)

    # Test the return code, value should be zero
    assert result[0] == 0

    # Test the value, should be 'system_u:object_r:bin_t:s0'
    assert result[1] == 'system_u:object_r:bin_t:s0'

