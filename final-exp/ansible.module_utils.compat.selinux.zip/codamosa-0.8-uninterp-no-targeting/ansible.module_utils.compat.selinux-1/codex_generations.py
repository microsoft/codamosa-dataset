

# Generated at 2022-06-20 16:36:02.418995
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw('/tmp')
    if rc >= 0:
        print("file context for /tmp:", con)
    else:
        print("failed to get context for /tmp:", rc)
if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:36:06.888744
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.selinux.selinux_getenforcemode import selinux_getenforcemode
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]


# Generated at 2022-06-20 16:36:08.981769
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert [0, 'system_u:object_r:container_file_t:s0'] == lgetfilecon_raw('/selinux')



# Generated at 2022-06-20 16:36:12.989755
# Unit test for function matchpathcon
def test_matchpathcon():
    path = os.path.split(__file__)[0]
    expected_result = [0, 'system_u:object_r:systemd_unit_file_t:s0']
    result = matchpathcon(path, os.R_OK)
    assert result == expected_result

# Generated at 2022-06-20 16:36:15.774294
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        import selinux
    except ImportError:
        return
    s = selinux_getpolicytype()
    assert isinstance(s[0], int)
    assert isinstance(s[1], str)

# Generated at 2022-06-20 16:36:25.097998
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # In order to test selinux_getenforcemode, we will need to bypass the _selinux_lib.selinux_getenforcemode
    # wrapper function. We will do this by using the ctypes module to simulate the _selinux_lib.selinux_getenforcemode
    # function.
    print("Testing function selinux_getenforcemode")
    # We will start by instantiating a selinux_getenforcemode class, and passing in an enforcemode value of 1.
    enforcemode_1 = c_int(value=1)
    selinux_getenforcemode_1 = c_char_p()
    selinux_getenforcemode_1.value = "enforcing"
    # patch selinux_getenforcemode_1.value

# Generated at 2022-06-20 16:36:27.793092
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/selinux/policy') == [0, 'system_u:object_r:selinux_policy_t:s0']


# Generated at 2022-06-20 16:36:35.082342
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    To run this unit test:
    - install a distro with selinux
    - install python ctypes
    - run this test with `python -m unittest python_selinux.py`
    """
    import unittest

    class TestValidateSelinuxLibFuncs(unittest.TestCase):
        def test_lgetfilecon_raw(self):
            self.assertTrue(os.path.exists('/proc/cpuinfo'))
            con, rc = lgetfilecon_raw(b'/proc/cpuinfo')
            self.assertTrue(isinstance(con, str))
            self.assertNotEqual(rc, -1)
            self.assertEqual(rc, 0)

    unittest.main()

# Generated at 2022-06-20 16:36:40.663350
# Unit test for function matchpathcon
def test_matchpathcon():
    # Match the class of /usr/bin/semodule-1
    (rc, con) = matchpathcon('/usr/bin/semodule-1', os.R_OK)
    assert rc == 0
    assert con == 'unlabeled_t:file_t:s0'

# Generated at 2022-06-20 16:36:44.565676
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This is a unit test for function lgetfilecon_raw
    # This function could return not null value
    # and it should be a dictionary
    output = lgetfilecon_raw(b'/')
    assert output[0] == 0
    assert type(output) is list


# Generated at 2022-06-20 16:36:52.040550
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    test_dir = tempfile.mkdtemp()
    rc, output = lgetfilecon_raw(test_dir)
    # allow_user_defined is set to True to supress the linter
    # pylint: disable=undefined-variable
    assert rc == 0
    assert output == "system_u:object_r:tmp_t:s0"


# Generated at 2022-06-20 16:36:54.009886
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode in (0, 1, 2)


# Generated at 2022-06-20 16:37:02.989081
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        res = selinux_getenforcemode()
    except OSError as e:
        errno_i = e.errno
        errno_s = os.strerror(errno_i)
        raise Exception("OSError [Errno {0}] {1}: {2}".format(errno_i, errno_s, e))
    if len(res) != 2:
        raise Exception("Returned invalid tuple len {0}".format(len(res)))
    if res[0] != 0:
        if res[0] == -2:
            raise Exception("SELinux is not enabled")
        else:
            raise Exception("Returned invalid return code {0}".format(res[0]))
    enforcemode = res[1]

# Generated at 2022-06-20 16:37:08.705180
# Unit test for function matchpathcon
def test_matchpathcon():
    # False test
    assert matchpathcon('/etc/not-exist-file', 0) != [0, 'system_u:object_r:svirt_sandbox_file_t:s0']
    # True test
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:svirt_sandbox_file_t:s0']

# Generated at 2022-06-20 16:37:12.037803
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/usr/bin/ruby'
    result_list = lgetfilecon_raw(test_path)
    assert result_list[0] == 0
    assert 'system_u:object_r:bin_t:s0' in result_list[1]


# Generated at 2022-06-20 16:37:16.157620
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/tmp/selinux_test")
    assert rc == -1 and con.decode('utf-8') == 'unlabeled_t'

# Generated at 2022-06-20 16:37:20.651281
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcement_mode_dict = {0: "Permissive", 1: "Enforcing", -1: "Unknown"}
    rc, enforcemode = selinux_getenforcemode()
    print("Syscall return code:", rc)
    print("Enforcement mode:", enforcement_mode_dict[enforcemode])


# Generated at 2022-06-20 16:37:23.023912
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, type = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(type, str)



# Generated at 2022-06-20 16:37:24.582992
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, value = selinux_getenforcemode()
    print("rc:", rc)
    print("value:", value)



# Generated at 2022-06-20 16:37:30.773569
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """ Verify that lgetfilecon_raw works as expected """

    # First, create a temp file to work with.
    filetemp = tempfile.NamedTemporaryFile(mode='w')
    file1 = filetemp.name

    # Get the SELinux context of the file
    success, con_file1_before = lgetfilecon_raw(file1)

    # Verify that we received a context and that it matches the type of the file
    assert con_file1_before != None
    assert con_file1_before.split(':')[1] == 'file_t'

    # Then set the SELinux context to the user_home_t type
    success = lsetfilecon(file1, "user_u:object_r:user_home_t:s0")
    assert success == 0

    # Get

# Generated at 2022-06-20 16:37:38.079563
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    current_mode = selinux_getenforcemode()
    if current_mode[0] == 0:
        print("Current SELinux mode: {0}".format(current_mode[1]))



# Generated at 2022-06-20 16:37:49.966559
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/var/log/audit/audit.log', 2)
    assert rc == 0
    assert con == 'system_u:object_r:auditd_log_t:s0'
    rc, con = matchpathcon(b'/var/log/audit', 2)
    assert rc == 0
    assert con == 'system_u:object_r:auditd_log_t:s0'
    rc, con = matchpathcon(b'/var/log/audit/', 2)
    assert rc == 0
    assert con == 'system_u:object_r:auditd_log_t:s0'
    rc, con = matchpathcon(b'/var/log/audit/apcupsd.events', 2)
    assert rc < 0
    assert con

# Generated at 2022-06-20 16:37:51.376890
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, _ = selinux_getpolicytype()
    assert rc == 0

# Generated at 2022-06-20 16:37:52.578596
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'mcs']

# Generated at 2022-06-20 16:37:54.383202
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[0] == 0 and result[1] in [0, 1, 2]



# Generated at 2022-06-20 16:38:02.077290
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Sample policy types
    policy_types = ['targeted', 'minimum', 'mls']
    # Get policy type
    rc, policy_type = selinux_getpolicytype()
    # Check if the return value and policy type is not empty
    assert rc >= 0 and policy_type, \
        "Error while fetching policy type: rc: {0}, policy_type: {1}".format(rc, policy_type)
    # Check if the returned policy type is in valid policy types
    assert policy_type in policy_types, \
        "Policy type is not valid: policy_type: {0}".format(policy_type)

# Generated at 2022-06-20 16:38:03.272596
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'


# Generated at 2022-06-20 16:38:13.696320
# Unit test for function matchpathcon
def test_matchpathcon():
    import shutil
    from ansible.module_utils._text import to_bytes

    shutil.rmtree("/tmp/foo", True)
    os.mkdir("/tmp/foo")

    good_match = matchpathcon("/tmp/foo", 0)
    assert good_match[0] == 0
    assert good_match[1] == "system_u:object_r:tmp_t:s0"

    no_match = matchpathcon("/tmp/foo_not_found", 0)
    assert no_match[0] == -1

    good_match_with_mode = matchpathcon("/tmp/foo", 0o777)
    assert good_match_with_mode[0] == 0

# Generated at 2022-06-20 16:38:15.836537
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp', 0)
    assert isinstance(rc, int)
    assert isinstance(con, str)



# Generated at 2022-06-20 16:38:27.036702
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_data = (
        ('/tmp/foo', (0, 'tmp_t')),
        ('/etc/hosts', (0, 'etc_t')),
        ('/dev/null', (0, 'dev_t')),
        ('/dev/zero', (0, 'dev_t')),
        ('/bin/true', (0, 'bin_t')),
        ('/bin/false', (0, 'bin_t'))
    )

    for path, expected_output in test_data:
        assert lgetfilecon_raw(path) == expected_output, 'lgetfilecon_raw({0}) had unexpected output'.format(path)


# Generated at 2022-06-20 16:38:39.822031
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t']
    assert matchpathcon('/thispathwontexist', 0) == [0, '']

# Generated at 2022-06-20 16:38:42.412879
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc = selinux_getenforcemode()
    assert isinstance(rc, list)
    assert len(rc) == 2


# Generated at 2022-06-20 16:38:48.471278
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected_output = 'system_u:object_r:unlabeled_t:s0'
    # This path should exist
    path = '/etc/selinux/config'

    assert lgetfilecon_raw(path)[1].startswith(expected_output)

# Generated at 2022-06-20 16:38:50.762566
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert(selinux_getpolicytype()[1] == 'targeted')
    assert(selinux_getpolicytype()[0] == 0)


# Generated at 2022-06-20 16:38:56.500828
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, result] = selinux_getpolicytype()
    print("Return code: {}".format(rc))
    print("Return value: {}".format(result))
    if rc != 0:
        print("Error getting SELinux policy type")
        sys.exit(1)
    print("SELinux policy type: {}".format(result))


# Generated at 2022-06-20 16:39:00.564624
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Note: If the unit test fails, please check whether the selinux is enabled or not.
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    if enforcemode:
        assert enforcemode == 1
    else:
        assert enforcemode == 0

if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-20 16:39:04.336272
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = "testfile"
    try:
        with open(test_path, 'w') as f:
            f.write('Testing ...')
        f.close()
    except IOError as e:
        print("I/O error: %s" % e)
    finally:
        if os.path.exists(test_path):
            os.remove(test_path)
    print("Test passed")


# Generated at 2022-06-20 16:39:13.291914
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import json
    import subprocess

    # Test selinux_getenforcemode with Enforcing mode
    subprocess.run(['setenforce', 'Enforcing'])
    assert selinux_getenforcemode() == [0, 1]

    # Test selinux_getenforcemode with Permissive mode
    subprocess.run(['setenforce', 'Permissive'])
    assert selinux_getenforcemode() == [0, 0]

    # Test selinux_getenforcemode with Disabled mode
    subprocess.run(['setenforce', 'disabled'])
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-20 16:39:16.240953
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import selinux
    (rc, result) = selinux_getenforcemode()
    assert result == selinux.security_getenforce()
    assert rc == 0


# Generated at 2022-06-20 16:39:19.873332
# Unit test for function matchpathcon
def test_matchpathcon():
    """ Interface for matchpathcon() """
    path = '/bin/sh'
    mode = os.stat(path).st_mode
    label = matchpathcon(path, mode)
    assert label[1] is not None



# Generated at 2022-06-20 16:39:39.470093
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # call function selinux_getenforcemode
    rc, value = selinux_getenforcemode()

    # assert the return code
    assert rc == 0

    # assert the return value
    assert isinstance(value, int) and value in [0, 1, 2]



# Generated at 2022-06-20 16:39:41.617196
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0, con
    assert con == 'targeted'
    del con


# Generated at 2022-06-20 16:39:43.738464
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if selinux_getenforcemode()[0]:
        raise RuntimeError('unable to determine selinux enforce mode')



# Generated at 2022-06-20 16:39:45.968118
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, ret = selinux_getenforcemode()
    print(rc, ret)
    print(type(ret))


# Generated at 2022-06-20 16:39:48.929983
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/var/log/audit/audit.log"
    rc, con_val = lgetfilecon_raw(path)
    print ('[{0}]'.format(rc))
    print ('[{0}]'.format(con_val))


# Generated at 2022-06-20 16:39:54.535078
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible_collections.ansible.community.plugins.module_utils.selinux.wrappers.test_selinux_test_file import create_test_file

    # following files created:
    # - /tmp/test_lgetfilecon_raw_test_file
    # - /tmp/test_lgetfilecon_raw_test_dir/test_lgetfilecon_raw_test_file
    # with expected security contexts:
    # - system_u:object_r:tmp_t:s0
    # - system_u:object_r:tmp_t:s0
    with create_test_file() as test_file:
        expected_con = "system_u:object_r:tmp_t:s0"
        filecon = lgetfilecon_raw(test_file)[1]
       

# Generated at 2022-06-20 16:40:03.230395
# Unit test for function matchpathcon
def test_matchpathcon():

    import tempfile
    import shutil
    from tempfile import mkdtemp
    from shutil import rmtree

    def _test_matchpathcon(selinux_enabled, selinux_mls_enabled, security_getenforce, selinux_getenforcemode, expected):

        fd, temp_file_path = tempfile.mkstemp()
        os.close(fd)

        if selinux_enabled:
            if not security_getenforce:
                shutil.rmtree(temp_file_path)
                return
        else:
            if security_getenforce:
                shutil.rmtree(temp_file_path)
                return
            if not selinux_enabled:
                if selinux_mls_enabled:
                    shutil.rmtree(temp_file_path)
                    return True

# Generated at 2022-06-20 16:40:07.934297
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import mkdtemp
    from shutil import rmtree

    d = mkdtemp()
    try:
        assert os.path.isdir(d)
        assert type(lgetfilecon_raw(d)[1]) is str
        assert lgetfilecon_raw(os.path.join(d, 'foo'))[0] == -1
    finally:
        rmtree(d)

# Generated at 2022-06-20 16:40:12.320004
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = [None, None]
    enforcemode[0], enforcemode[1] = selinux_getenforcemode()
    return_value = enforcemode[0] == 0
    if return_value is True:
        if enforcemode[1] == 0:
            return_value = 'Permissive'
        elif enforcemode[1] == 1:
            return_value = 'Enforcing'
    return return_value


# Generated at 2022-06-20 16:40:15.430281
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp/anyfile', 0)
    assert rc >= 0
    assert type(con) == str

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:40:31.711861
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    return selinux_getpolicytype()



# Generated at 2022-06-20 16:40:37.606414
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Check if libselinux is present
    lib_exists = os.path.exists('/lib64/libselinux.so')

    if lib_exists:
        # Check if enforced
        [rc, enforcemode] = selinux_getenforcemode()
        assert rc == 0
        assert enforcemode == 1
    else:
        # Check if disabled
        [rc, enforcemode] = selinux_getenforcemode()
        assert rc == 0
        assert enforcemode == 0



# Generated at 2022-06-20 16:40:44.480842
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/usr/sbin/policy'
    mode = 0

    (rc, ctx) = matchpathcon(path, mode)
    print('SeLinux context for path \'{0}\' with mode {1}: {2}, rc: {3}'.format(path, mode, ctx, rc))
    if rc == -1:
        print('Unable to find context for path \'{0}\' with mode: {1}'.format(path, mode))
        exit(0)

    exit(0)


# Generated at 2022-06-20 16:40:47.296151
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policytype) = selinux_getpolicytype()
    if rc == 0:
        print("Policy Type is " + policytype)


# Generated at 2022-06-20 16:40:52.094155
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    if enforcemode[0] == -1:
        raise OSError('SELinux support not available')
    elif not enforcemode[1]:
        raise AssertionError('SELinux is not enabled')
    else:
        print('SELinux is enabled')

# Generated at 2022-06-20 16:40:54.862972
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    assert result[0] == 0
    print(result[1])



# Generated at 2022-06-20 16:40:55.876630
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    return selinux_getpolicytype()


# Generated at 2022-06-20 16:41:03.823354
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import re
    import stat
    import tempfile
    import time

    # Create a temporary file
    mode = 0o600
    (fd, path) = tempfile.mkstemp(text=True, dir='.')
    with os.fdopen(fd, 'w') as f:
        f.write('hello world')

    # Set the file mode
    os.chmod(path, mode)

    # Set the SELinux file context
    stat_result = os.stat(path)
    start_time = stat_result.st_mtime

    (rc, con) = lgetfilecon_raw(path)
    if rc != 0:
        raise Exception('lgetfilecon_raw(%s): expected = 0, rc = %d, con = %s' % (path, rc, con))

    # The connection

# Generated at 2022-06-20 16:41:07.811250
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    _selinux_lib.lgetfilecon_raw("/etc/passwd", byref(con))
    assert con.value == b"system_u:object_r:passwd_file_t\x00"
    _selinux_lib.freecon(con)


# Generated at 2022-06-20 16:41:11.394468
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc = selinux_getpolicytype()
    assert rc[0] == 0
    assert rc[1] == 'mls'



# Generated at 2022-06-20 16:41:49.078479
# Unit test for function matchpathcon
def test_matchpathcon():
    status = matchpathcon('/etc/passwd', 0)
    assert status[0] != -1, 'Call to selinux matchpathcon failed'
    assert status[1] == 'system_u:object_r:etc_runtime_t', 'Call to selinux matchpathcon did not match expected context'


if __name__ == '__main__':
    test_matchpathcon()
    print('Done!')

# Generated at 2022-06-20 16:41:50.450705
# Unit test for function matchpathcon
def test_matchpathcon():
    """ TODO: Add Unit tests
    """
    pass

# Generated at 2022-06-20 16:41:54.682388
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforce = selinux_getenforcemode()
    assert isinstance(enforce[0], int)
    assert enforce[1] in [0, 1, 2]



# Generated at 2022-06-20 16:41:59.612700
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = matchpathcon('/etc/ssh/sshd_config', 0)
        assert rc == 0
        assert con == 'system_u:object_r:ssh_config_t:s0'
    except ImportError:
        assert True

# Generated at 2022-06-20 16:42:09.937908
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import platform
    import os
    module_type = os.environ.get('ANSIBLE_MODULE_TYPE', 'command')

    # selinux.getpolicytype() is only supported on Linux
    if platform.system() != 'Linux':
        raise NotImplementedError('selinux.selinux_getpolicytype is not supported on non Linux platforms')

    # selinux.getpolicytype() is not supported on Windows Powershell
    if module_type == 'powershell':
        raise NotImplementedError('selinux.selinux_getpolicytype is not supported on Windows Powershell')

    rc, policy_type = selinux_getpolicytype()

    if rc != 0:
        raise OSError(rc, os.strerror(rc))

# Generated at 2022-06-20 16:42:12.086532
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # check that function returns expected output
    res = selinux_getpolicytype()
    assert type(res) == list
    assert 'targeted' in res[1]

# Generated at 2022-06-20 16:42:14.976996
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    r = selinux_getenforcemode()
    assert r[0] >= 0, r[1]
    assert r[1] in [0, 1, 2]



# Generated at 2022-06-20 16:42:17.165644
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()[1]
    assert isinstance(policytype, str)
    assert policytype in ('refpolicy', 'targeted')
    print(policytype)



# Generated at 2022-06-20 16:42:21.404802
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policytype, str)



# Generated at 2022-06-20 16:42:25.145118
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux/config'
    rc, con = lgetfilecon_raw(path)
    print('rc=', rc)
    print('con=', con)



# Generated at 2022-06-20 16:43:42.757739
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0, "selinux_getenforcemode failed"
    assert type(enforcemode) == int, "enforcemode is not an int"



# Generated at 2022-06-20 16:43:46.950663
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc == 0:
        assert enforcemode == 1
    else:
        assert enforcemode == 0

# Generated at 2022-06-20 16:43:48.797996
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = "/etc/passwd"
    # Return value of matchpathcon is 1 if permission is denied, 0 otherwise
    assert matchpathcon(test_path, 0)[0] == 1

# Generated at 2022-06-20 16:43:52.414814
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc = selinux_getenforcemode()
    assert rc[0] == 0

# Generated at 2022-06-20 16:43:55.348711
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import sys, ctypes
    sys.exit(ctypes.test(selinux_getenforcemode))


# Generated at 2022-06-20 16:43:58.821051
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        print(selinux_getenforcemode())
    except Exception as e:
        print("selinux_getenforcemode failed: %s" % to_native(e))



# Generated at 2022-06-20 16:44:01.460537
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'



# Generated at 2022-06-20 16:44:06.075737
# Unit test for function matchpathcon
def test_matchpathcon():
    x = matchpathcon('/foo', 0)
    assert x == [0, 'system_u:object_r:svirt_sandbox_file_t:s0']


# Unit tests for function lgetfilecon_raw

# Generated at 2022-06-20 16:44:15.972723
# Unit test for function matchpathcon

# Generated at 2022-06-20 16:44:17.809822
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc == 0:
        assert policytype == 'targeted', "selinux policy type test failed"