

# Generated at 2022-06-20 16:36:02.242265
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, policytype = selinux_getpolicytype()
        if rc < 0:
            raise OSError(rc, os.strerror(rc))
        print("selinux policy type: [rc = {0}] {1}".format(rc, policytype))
    except OSError as e:
        print("error {0}: {1}".format(e.errno, e))
        sys.exit(1)

# Generated at 2022-06-20 16:36:03.994002
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[0] == 0


# Generated at 2022-06-20 16:36:10.701570
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/var/log/messages'
    mode = os.R_OK | os.W_OK | os.X_OK
    expected_return_code = 0
    expected_return_value = 'system_u:object_r:var_log_t:s0'
    rc, con = matchpathcon(path, mode)
    if rc != expected_return_code or con != expected_return_value:
        raise AssertionError("Function matchpathcon returned a wrong result for path {} and mode {}. Expected was {} {} but was: {} {} ".format(path, mode, expected_return_code, expected_return_value, rc, con))


# Generated at 2022-06-20 16:36:16.833011
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test that the function lgetfilecon_raw returns the expected results.
    """
    from ansible.module_utils.selinux_funcs_wrapper import lgetfilecon_raw

    # Set a known file and context to use in tests
    path = "/etc/selinux/config"
    expected_context = "system_u:object_r:etc_t:s0"
    (rc, con) = lgetfilecon_raw(path)
    assert rc == 0 and con == expected_context

# Generated at 2022-06-20 16:36:20.526544
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert len(policytype) == 2
    rc = policytype[0]
    type = policytype[1]
    assert rc == 0
    assert isinstance(type, str)


# Generated at 2022-06-20 16:36:26.607783
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import shutil

    home = tempfile.mkdtemp()
    try:
        filename = os.path.join(home, 'test.txt')
        with open(filename, 'w') as test_file:
            test_file.write('')
        rc, con = lgetfilecon_raw(filename)
        assert rc == 0
        assert len(con) > 0
        assert con == 'unconfined_u:object_r:user_home_t:s0'
    finally:
        shutil.rmtree(home)


# Generated at 2022-06-20 16:36:27.757222
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    ret, policytype = selinux_getpolicytype()
    assert ret >= 0
    assert isinstance(policytype, str)

# Generated at 2022-06-20 16:36:30.049447
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # FIXME: need to test with selinux enabled
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode == 0



# Generated at 2022-06-20 16:36:36.712812
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os

    # Create a test file for testing
    temp_file_path = '/tmp/ansible_test_file'
    with open(temp_file_path, 'w') as f:
        f.write('Ansible lgetfilecon_raw unit test')

    # Get the SELinux context of the file
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(temp_file_path, byref(con))
        if rc == 0:
            # con.value should be a string containing a SELinux security context
            print(to_native(con.value))
    finally:
        _selinux_lib.freecon(con)
        os.remove(temp_file_path)

# Generated at 2022-06-20 16:36:40.951277
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0, "Invalid policy was returned: {0}, {1}".format(rc, policy)
    assert policy == "targeted", "Invalid policy was returned: {0}, {1}".format(rc, policy)

# Generated at 2022-06-20 16:36:44.926109
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-20 16:36:47.728797
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert(rc == 0)
    assert(enforcemode in [0, 1, 2])



# Generated at 2022-06-20 16:36:49.205862
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0



# Generated at 2022-06-20 16:36:50.503098
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


# Generated at 2022-06-20 16:36:53.280150
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc >= 0
    assert isinstance(enforcemode, int)
    assert (enforcemode >= 0 and enforcemode <= 2)


# Generated at 2022-06-20 16:36:58.661021
# Unit test for function matchpathcon
def test_matchpathcon():
    # test matchpathcon with no match
    path = "/dev/null/there/should/be/no/match/here"
    mode = 0o600
    rc, con = matchpathcon(path, mode)
    assert rc == 0, "matchpathcon retrun code should be 0 when no match is found."
    assert con == "<<none>>", "matchpathcon should return '<<none>>' when no match is found."

# Generated at 2022-06-20 16:37:00.795565
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert isinstance(rc, int)
    assert isinstance(policy_type, str)
    assert rc == 0

# Generated at 2022-06-20 16:37:02.447928
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/sys/fs/cgroup", 0) == [0, 'system_u:object_r:sysfs_t:s0']

# Generated at 2022-06-20 16:37:04.543092
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    if rc != 0:
        raise OSError('Failed to get selinux policy type')
    return policytype


# Generated at 2022-06-20 16:37:11.088225
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import stat
    import pytest

    # validate a valid file path
    rc, con = matchpathcon('/tmp', stat.S_IFDIR)
    assert rc == 0
    assert con == 'system_u:object_r:tmpfs:s0'

    # test with a directory that doesn't exist
    with pytest.raises(OSError) as err:
        matchpathcon('/tmp/doesnt_exist', stat.S_IFDIR)
    assert err.value.errno == 2  # ENOENT



# Generated at 2022-06-20 16:37:17.948601
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/bin', 0) == [0, 'system_u:object_r:bin_t:s0']

# Generated at 2022-06-20 16:37:20.701750
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, out = selinux_getpolicytype()
    assert rc == 0
    assert out in ("targeted", "minimum", "mls")



# Generated at 2022-06-20 16:37:27.661787
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    Test for matchpathcon, also serves as an example
    '''

    # hardcoded based on the current path
    path = b'/etc/selinux/config'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0, 'failed to match path context, rc={}'.format(rc)
    assert con == 'system_u:object_r:etc_t:s0', 'failed to match path context, con={}'.format(con)



# Generated at 2022-06-20 16:37:35.354772
# Unit test for function matchpathcon
def test_matchpathcon():
    def _setup_fs(tmpdir):
        tmpdir.mkdir('sys')
        tmpdir.mkdir('sys/fs')
        tmpdir.mkdir('sys/fs/cgroup')

    result = matchpathcon(b'/sys/fs/cgroup/name=systemd/cgroup.procs', 0)

    if result[0] != 0:
        raise AssertionError('matchpathcon() failed with error:' + str(result[0]))

    if 'system_u:object_r:systemd_cgroup_t:s0' not in result[1]:
        raise AssertionError('matchpathcon() failed with: {1}'.format(result[1]))


# Generated at 2022-06-20 16:37:46.809928
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not selinux_getpolicytype()[1] == "targeted":
        raise Exception("Unit test for function lgetfilecon_raw is only supported for 'targeted' policy type")

    # Dummy file (will be created in /tmp)
    test_file = "/tmp/ansible_selinux_test"
    # Create a dummy file and set its context to 'user_home_t'
    open(test_file, 'a').close()
    with open(test_file, 'r+b') as f_obj:
        fd = f_obj.fileno()
        _selinux_lib.fsetfilecon(fd, b'user_home_t')

    # Now, get the context of this dummy file
    [rc, con] = lgetfilecon_raw(test_file)

# Generated at 2022-06-20 16:37:50.012367
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, ret = lgetfilecon_raw('/')
    assert rc == 0
    assert ret.startswith("system_u:object_r:rootfs")

# Generated at 2022-06-20 16:37:52.422111
# Unit test for function matchpathcon
def test_matchpathcon():
    """Unit test for function matchpathcon"""

    assert matchpathcon('/usr/bin/ls', 0)[1] == 'system_u:object_r:bin_t:s0'

# Generated at 2022-06-20 16:37:54.191996
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0
    assert selinux_getpolicytype()[1] != None


# Generated at 2022-06-20 16:37:55.800080
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] in [0, 1, 2]  # Only valid values are 0, 1 and 2



# Generated at 2022-06-20 16:38:02.991661
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/etc/passwd', 0)

    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'
    rc, con = matchpathcon(b'/etc/passwd', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'
    rc, con = matchpathcon(b'/etc/passwd', os.R_OK | os.W_OK)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-20 16:38:15.545210
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, context = matchpathcon('/usr/bin/ansible-config', os.R_OK)
    if rc == -1:
        raise AssertionError('matchpathcon(path, mode) failed: ' + str(rc))
    if context != 'system_u:object_r:ansible_etc_t:s0':
        raise AssertionError('matchpathcon(path, mode) returned ' + context)



# Generated at 2022-06-20 16:38:18.412704
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, content = selinux_getpolicytype()
    assert rc == 0
    assert content == 'targeted'



# Generated at 2022-06-20 16:38:21.723247
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        [rc, policy_type] = selinux_getpolicytype()
        assert rc == 0
        assert isinstance(policy_type, str)
    except NotImplementedError:
        pass
    except Exception as e:
        raise Exception(to_native(e))



# Generated at 2022-06-20 16:38:24.823021
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policy) = selinux_getpolicytype()
    if rc != 0:
        raise AssertionError('selinux_getpolicytype() failed with exit code: {0}'.format(rc))
    else:
        print('selinux_getpolicytype() policy: {0}'.format(policy))
        return policy



# Generated at 2022-06-20 16:38:29.342297
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    mypath = '/etc'
    myrc, mycon = lgetfilecon_raw(mypath)
    assert myrc == 0
    assert mycon == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-20 16:38:33.747286
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = '/etc/hosts'
    rc, con = lgetfilecon_raw(test_file)
    assert rc == 0
    assert con.startswith('system_u:object_r:etc_t')



# Generated at 2022-06-20 16:38:35.189968
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, val = lgetfilecon_raw('/root')
    assert val
    assert rc == 0

# Generated at 2022-06-20 16:38:40.217908
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/home/ansible/.ssh/authorized_keys", 0)

    assert rc == 0
    assert con == "system_u:object_r:ssh_home_t:s0"


# Generated at 2022-06-20 16:38:43.729600
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon() function
    """
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        context = matchpathcon(tmpdir, 0)[1]

    assert context is not None, 'Could not get file context'

# Generated at 2022-06-20 16:38:54.306132
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import json
    import sys
    import tempfile

    test_value = 1

    # test for error return code
    module_args = dict(
    )
    errno_test = tempfile.NamedTemporaryFile(mode='w+', delete=False)
    os.rename(errno_test.name, errno_test.name + '.py')
    errno_test.close()
    argv = [sys.executable, '-c', 'import sys; sys.exit(1)', errno_test.name + '.py']


# Generated at 2022-06-20 16:39:08.349458
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/selinux/config')
    print(rc, con)

    rc, con = lgetfilecon_raw('this_file_does_not_exist')
    print(rc, con)



# Generated at 2022-06-20 16:39:12.105989
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0, 'Function failed rc = %d' % rc
    assert mode in (0, 1, 2), "enforce mode should be 0 (permissive), 1 (enforcing) or 2 (unknown)"


# Generated at 2022-06-20 16:39:15.707354
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    type_string, type_context = lgetfilecon_raw('/etc/passwd')
    assert type_string == 'etc_t' and type_context == 'unconfined_u:object_r:etc_t:s0'


# Generated at 2022-06-20 16:39:25.906909
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    tempdir = "./matchpathcon_testdir"
    dir_path = os.path.dirname(os.path.realpath(__file__))
    filename = "testfile"
    filepath = os.path.join(dir_path, tempdir, filename)

    os.mkdir(tempdir)
    f = open(filepath, "w")
    f.close()

    con = c_char_p()
    rc = _selinux_lib.matchpathcon(filepath, os.stat(filepath).st_mode, byref(con))
    assert rc == 0
    assert con.value is not None
    _selinux_lib.freecon(con)

    os.unlink(filepath)
    os.rmdir(tempdir)

# Generated at 2022-06-20 16:39:35.218218
# Unit test for function matchpathcon
def test_matchpathcon():
    sys.stdout.write('Testing function matchpathcon ... ')
    try:
        [rc, con] = matchpathcon('/var/empty', 0)
    except OSError as e:
        sys.stdout.write('SKIPPED (OSError: {0})'.format(e))
        return
    assert rc == 0
    assert con == 'system_u:object_r:var_empty_t:s0'
    sys.stdout.write('PASSED')

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:39:41.369072
# Unit test for function matchpathcon
def test_matchpathcon():
    # Return a tuple consisting of return code
    # and the string containing the context
    (rc, scon) = matchpathcon('/usr/local/bin/data', 0)
    if rc < 0:
        print('Failed to get SELinux Context for /usr/local/bin/data')
    else:
        print('SELinux Context for /usr/local/bin/data is {0} and return code is {1}'.format(scon, rc))



# Generated at 2022-06-20 16:39:49.951369
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import (
        lgetfilecon_raw,
        security_getenforce,
        security_policyvers,
    )

    # Test if SELinux is enabled
    if security_getenforce() == 1 and security_policyvers() >= 14:
        # Test if the function lgetfilecon_raw works properly
        assert len(lgetfilecon_raw('.')) == 2
        assert len(lgetfilecon_raw('')) == 2
        assert len(lgetfilecon_raw('/')) == 2
        assert len(lgetfilecon_raw('/proc')) == 2
        assert len(lgetfilecon_raw('/tmp')) == 2


# Generated at 2022-06-20 16:39:52.811818
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp"
    mode = 0
    [rc, con] = matchpathcon(path, mode)
    print('[%d] %s' % (rc,con))


# Generated at 2022-06-20 16:39:56.773673
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    realpath = os.path.realpath(__file__)
    rc, policytype = selinux_getpolicytype()
    assert rc == 0 and policytype in ['targeted', 'mls']
    return [rc, policytype]

# Generated at 2022-06-20 16:40:07.672244
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    test_file = os.tmpnam()
    test_file_context = "system_u:object_r:tmp_t:s0"
    test_open_file = open(test_file, 'w')
    test_open_file.close()

    # set file's extended attribute
    _selinux_lib.lsetfilecon(test_file, test_file_context)
    # get file's extended attribute
    (rc, file_context) = lgetfilecon_raw(test_file)
    os.remove(test_file)

    # validate test_file_context
    for context in [file_context, test_file_context]:
        context_list = context.split(":")
        assert len(context_list) == 4
        assert context_list[2] == "tmp_t"



# Generated at 2022-06-20 16:40:18.464889
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert(policy == 'targeted')


# Generated at 2022-06-20 16:40:22.167292
# Unit test for function matchpathcon
def test_matchpathcon():
    for mode in (0, 1, 2):
        result = matchpathcon('/test', mode)
        print('result: {}'.format(result))



# Generated at 2022-06-20 16:40:25.210259
# Unit test for function matchpathcon
def test_matchpathcon():
    import selinux
    con_var = selinux.matchpathcon('/home/user/data', selinux.mode_t.S_IFREG)

# Generated at 2022-06-20 16:40:31.005885
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import selinux
    [rc, enforcemode] = selinux_getenforcemode()
    assert isinstance(rc, int)
    for i in [selinux.SELINUX_ENFORCE, selinux.SELINUX_PERMISSIVE, selinux.SELINUX_DISABLED]:
        assert enforcemode == i


# Generated at 2022-06-20 16:40:35.429159
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/proc/selinux/enforce'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0, "lgetfilecon_raw should return 0, got %s" %(str(rc))
    assert isinstance(con, str), "lgetfilecon_raw should return a string"


# Generated at 2022-06-20 16:40:37.408708
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    print("Type of SELinux policy: {0}".format(policytype))
    assert rc == 0


# Generated at 2022-06-20 16:40:40.373061
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'foo'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'foo:dir:s0'

# Generated at 2022-06-20 16:40:41.868069
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret = selinux_getenforcemode()
    assert ret == [0, 0]


# Generated at 2022-06-20 16:40:45.852199
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/ssh/sshd_config'
    mode = 0o600
    [rc, context] = matchpathcon(path, mode)
    print("rc = {0}".format(rc))
    print("context = {0}".format(context))


# Generated at 2022-06-20 16:40:48.802309
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert(rc == 0)
    assert(con == 'system_u:object_r:root_t:s0')

# Generated at 2022-06-20 16:41:00.487928
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0, "Unable to verify the enforcement mode"
    assert enforcemode > 0, "Unable to verify the enforcement mode"



# Generated at 2022-06-20 16:41:07.458740
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    f = "/sys/devices/virtual/net/sockXX/sock_label"
    rc, con = lgetfilecon_raw(f)
    assert rc == -1
    assert con is None

    rc, con = lgetfilecon_raw("/etc/shadow")
    assert rc == -1
    assert con is None

    rc, con = lgetfilecon_raw("/")
    assert rc == 0
    assert con == "system_u:object_r:root_t:s0"

# Generated at 2022-06-20 16:41:13.371446
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    with temp_file as f:
        fname = f.name

    status, con = lgetfilecon_raw(fname)
    assert status == 0
    assert con is not None

# Generated at 2022-06-20 16:41:16.349461
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    is_enforcing = selinux_getenforcemode()
    assert isinstance(is_enforcing[0], int)
    assert isinstance(is_enforcing[1], str) or is_enforcing[1] is None



# Generated at 2022-06-20 16:41:18.024848
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()[1]
    assert policytype == "targeted"


# Generated at 2022-06-20 16:41:23.271478
# Unit test for function matchpathcon
def test_matchpathcon():
    my_file = '/usr/bin/ansible'
    my_mode = 0o777
    output = matchpathcon(my_file, my_mode)
    print(output)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:41:28.715125
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/test_file_path', 1)
    if rc != 0:
        print('Return code did not match 0, instead returned {}'.format(rc))
    elif con == '':
        print('Returned context is empty')
    else:
        print('Successfully retrieved context for /test_file_path')
        print('Context is: {}'.format(con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:41:34.328763
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/init.d/', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']


if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-20 16:41:36.968777
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, ret] = selinux_getpolicytype()
    print("Return code: " + str(rc))
    print("Return value: " + str(ret))



# Generated at 2022-06-20 16:41:41.800310
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, target = selinux_getpolicytype()
    assert rc == 0
    assert target == 'targeted'


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:42:02.341373
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-20 16:42:07.882399
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0, "Failed to retrieve SELinux policy type"
    assert policy_type == "targeted", "Failed to retrieve SELinux policy type"


# Generated at 2022-06-20 16:42:11.066803
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/tmp/test', 0) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-20 16:42:12.622818
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    assert lgetfilecon_raw(path)[0] == 0


# Generated at 2022-06-20 16:42:16.084540
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.selinux import selinux_getpolicytype
    print(selinux_getpolicytype())


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:42:21.840999
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/proc/cpuinfo'
    rc, con = lgetfilecon_raw(path)
    print('rc: {0}, con: {1}'.format(rc, con))


# Generated at 2022-06-20 16:42:24.621632
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    ret = selinux_getpolicytype()
    assert ret[0] == 0
    assert ret[1] == 'targeted'



# Generated at 2022-06-20 16:42:34.148994
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert isinstance(_selinux_lib.selinux_getpolicytype, CDLL.__init__)
    assert _selinux_lib.selinux_getpolicytype(None) == -1
    # actual lib-function occurs outside module-scope, so we import it directly
    from ctypes.util import find_library
    libc = CDLL(find_library('c'))
    import ctypes
    assert libc.getenv(b'selinux') is None
    rc, res = selinux_getpolicytype()
    assert rc == -1
    assert res == ''
    assert libc.setenv(b'selinux', b'', 1) == 0
    rc, res = selinux_getpolicytype()
    assert rc == 0
    assert res == 'targeted'

# Generated at 2022-06-20 16:42:40.109457
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    #
    # test list
    #
    list = selinux_getpolicytype()
    assert list == [0, 'targeted'], list
    #
    # test dict
    #
    dict = dict(selinux_getpolicytype())
    assert dict == {0: 'targeted'}, dict

# Generated at 2022-06-20 16:42:45.688426
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # return a string with the same value as a macro selinux_policy_root()
    # Even if the policy is not loaded in the kernel.
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert policy_type is not None
    assert policy_type == b"kernel" or policy_type == b"targeted" or policy_type == b"minimum" or policy_type == b"mls"

