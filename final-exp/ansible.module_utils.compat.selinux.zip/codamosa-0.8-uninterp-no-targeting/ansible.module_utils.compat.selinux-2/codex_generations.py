

# Generated at 2022-06-20 16:36:03.007866
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert (selinux_getenforcemode()[0] == 0)
    assert (selinux_getenforcemode()[1] == 1)



# Generated at 2022-06-20 16:36:04.823605
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # This function is callable
    assert selinux_getenforcemode()



# Generated at 2022-06-20 16:36:08.149372
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/foo/bar')
    assert rc == -1
    assert con == to_native('')
    assert os.strerror(errno.ENOENT) in repr(con)


# Generated at 2022-06-20 16:36:11.426518
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'


# Generated at 2022-06-20 16:36:18.477877
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    if rc == 0:
        if enforcemode == 0:
            print("SELinux is in permissive mode")
        elif enforcemode == 1:
            print("SELinux is in enforcing mode")
        else:
            print("Unexpected value for enforcemode")
    else:
        print("Can't get enforcemode")
        print("errno=%d (%s)" % (rc, os.strerror(rc)))
        sys.exit(1)



# Generated at 2022-06-20 16:36:20.447521
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, output = selinux_getpolicytype()  # Execute wrapper
    assert rc == 0
    assert output == 'targeted'


# Generated at 2022-06-20 16:36:29.524085
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil
    import os

    # create new tempdir
    ansible_tmpdir = tempfile.mkdtemp()

    # create ansible_tmpdir as testfile
    testfilepath = os.path.join(ansible_tmpdir, "testfile")
    file = open(testfilepath, "w")
    file.close()

    # get filecon of ansible_tmpdir and testfile
    filedirpath = os.path.dirname(ansible_tmpdir)
    filedircon = lgetfilecon_raw(filedirpath)[1]
    testfilecon = lgetfilecon_raw(testfilepath)[1]

    # get context of /sbin/nologin
    con = matchpathcon('/sbin/nologin', 0)[1]

    # delete tmp

# Generated at 2022-06-20 16:36:40.251512
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 01
    rc, con = matchpathcon(b"/etc/fstab", 0)
    assert rc == 0
    assert con == "system_u:object_r:fstab_t:s0"

    # Test 02
    rc, con = matchpathcon(b"/etc/foo", 0)
    assert rc == 0
    assert con is None

    # Test 03
    rc, con = matchpathcon(b"/etc/fstab", 128)
    assert rc == 0
    assert con == "system_u:object_r:fstab_t:s0"

    # Test 04
    rc, con = matchpathcon(b"/etc/foo", 128)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

    # Test 05
   

# Generated at 2022-06-20 16:36:43.511870
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/hosts')
    if rc > 0:
        print('error calling lgetfilecon_raw')
    else:
        print('con = {0}'.format(con))



# Generated at 2022-06-20 16:36:46.853641
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon()
    """

    rc, con = matchpathcon(b'/etc', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-20 16:36:53.030987
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:36:55.614748
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp"
    result = lgetfilecon_raw(path)
    assert result[0] == 0
    assert len(result) == 2
    assert isinstance(result[0], int)
    assert isinstance(result[1], str)


# Generated at 2022-06-20 16:37:02.550806
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # TEST1: Get SELinux policy type as string
    policy_type = selinux_getpolicytype()
    assert isinstance(policy_type, list), "Expected a list, but got a: {}".format(type(policy_type))
    assert len(policy_type) == 2, "Expected a list of length 2, but got a list of length: {}".format(len(policy_type))
    assert isinstance(policy_type[0], int), "Expected an int, but got a: {}".format(type(policy_type[0]))
    assert isinstance(policy_type[1], str), "Expected a string, but got a: {}".format(type(policy_type[1]))

# Generated at 2022-06-20 16:37:05.102882
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/test/test_file') == [0, "system_u:object_r:user_home_t:s0"]
    assert lgetfilecon_raw(b'/test/test_none') == [-1, ""]



# Generated at 2022-06-20 16:37:13.259730
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/bin/ping', 0) == [0, 'system_u:object_r:ping_exec_t:s0']
    assert matchpathcon('/usr/bin/ping', 2) == [0, 'system_u:object_r:unlabeled_t:s0']
    assert matchpathcon('/usr/bin/ping', 1) == [1, 'system_u:object_r:ping_exec_t:s0']
    assert matchpathcon('/usr/bin/ping', 3) == [1, 'system_u:object_r:ping_exec_t:s0']
    assert matchpathcon('/usr/bin/ping', 4) == [0, 'system_u:object_r:ping_exec_t:s0']

# Generated at 2022-06-20 16:37:25.504684
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('Testing if the selinux_getpolicytype function works as expected')

    # This is what selinux_getpolicytype should return on a system without selinux
    TRUE_POLICYTYPE_NO_ENFORCEMENT = ['targeted', 0]

    # This is what selinux_getpolicytype should return on a system with selinux
    TRUE_POLICYTYPE_ENFORCEMENT = ['targeted', 0]

    # This is what selinux_getpolicytype should return on a system with selinux in permissive mode
    TRUE_POLICYTYPE_ENFORCEMENT_PERMISSIVE = ['targeted', 0]

    # This is what selinux_getpolicytype should return on a system with selinux disabled
    TRUE_POLICYTYPE_NOT_ENABLED = ['targeted', 0]

    # Check if the function returns the

# Generated at 2022-06-20 16:37:34.240649
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import subprocess

    def _check_mode(rc, mode):
        if rc != 0:
            raise AssertionError("selinux_getenforcemode failed:\nrc: {0}\nmode: {1}".format(rc, mode))

        if mode not in (0, 1, 2):
            raise AssertionError("selinux_getenforcemode returned an unknown mode:\nrc: {0}\nmode: {1}".format(rc, mode))

        # Check the same mode is returned by sestatus
        sestatus_out = subprocess.check_output(['sestatus'])
        sestatus_out = str(sestatus_out)

        if 'Current' not in sestatus_out:
            raise AssertionError("sestatus did not contain the Current mode setting.")

        #

# Generated at 2022-06-20 16:37:38.691708
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/etc/ssh/sshd_config'
    test_mode = 340
    [rc, result] = matchpathcon(test_path, test_mode)
    assert rc == 0
    assert result == 'system_u:object_r:sshd_etc_t:s0'

# Generated at 2022-06-20 16:37:44.757827
# Unit test for function matchpathcon
def test_matchpathcon():
    def _assert_rc_ok(rc):
        assert rc[0] == 0, rc[0]

    rc = matchpathcon('/etc/passwd', 0)
    _assert_rc_ok(rc)
    assert rc[1] == 'system_u:object_r:etc_runtime_t:s0', rc[1]


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:37:47.077484
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    errcode, enforcemode = selinux_getenforcemode()
    assert enforcemode == 1



# Generated at 2022-06-20 16:37:53.334858
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_name = "test_selinux.py"
    file_path = os.path.realpath(__file__)
    file_dir = os.path.dirname(file_path)
    file_path = os.path.join(file_dir, file_name)
    if os.path.exists(file_path):
        [rc, con] = lgetfilecon_raw(file_path)
    else:
        print("File %s does not exist" % file_name)

# Generated at 2022-06-20 16:38:01.260649
# Unit test for function matchpathcon
def test_matchpathcon():
    if not os.path.exists('/etc/selinux/config'):
        assert False
    from stat import S_ISDIR, S_ISLNK, S_ISREG
    mode = S_ISDIR(os.stat('/etc/selinux/config').st_mode) * 4
    mode |= S_ISLNK(os.stat('/etc/selinux/config').st_mode) * 2
    mode |= S_ISREG(os.stat('/etc/selinux/config').st_mode)
    rc, con = matchpathcon('/etc/selinux/config', mode)
    assert rc == 0

# Generated at 2022-06-20 16:38:05.039181
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("Testing selinux_getpolicytype")
    rc, enforcemode = selinux_getenforcemode()
    print("policy type: {0}".format(selinux_getpolicytype()[1]))
    assert enforcemode != 2


# Generated at 2022-06-20 16:38:10.779660
# Unit test for function matchpathcon
def test_matchpathcon():
    dir_path = '/tmp'
    [rc, con] = matchpathcon(dir_path, os.R_OK)
    if rc != 0:
        print ('Unexpected matchpathcon return code: %s' % (rc))
        sys.exit(1)
    print ('SELinux context for "%s" is "%s"' % (dir_path, con))



# Generated at 2022-06-20 16:38:12.666750
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret = selinux_getenforcemode()
    assert ret[0] == 0
    assert ret[1] in [0, 1]


# Generated at 2022-06-20 16:38:16.098402
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("selinux_getenforcemode() -> Non SeLinux enabled")
    ret, mode = selinux_getenforcemode()
    print("ret: ", ret)
    print("mode: ", mode)
    assert ret in [0, -1]
    assert mode in [0, 1]


# Generated at 2022-06-20 16:38:19.815037
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/etc/shadow')
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'



# Generated at 2022-06-20 16:38:22.402098
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/usr/bin/env'
    con = c_char_p()
    rc, con_value = lgetfilecon_raw(path)
    assert rc == 0
    print(con_value)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:38:27.813527
# Unit test for function matchpathcon
def test_matchpathcon():
    # For some reason, this test fails when running on Travis CI, so we need to skip it
    import os
    if os.environ.get('TRAVIS', 'False') == 'True':
        return None

    path = to_native('/etc/selinux/targeted/contexts/files/file_contexts')
    (rc, con) = matchpathcon(path, 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    rc, con = matchpathcon(path, 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0-s0:c0.c1023'

    rc, con = matchpathcon(path, 2)
    assert rc == 0

# Generated at 2022-06-20 16:38:28.723306
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass

# Generated at 2022-06-20 16:38:40.684946
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc < 0:
        raise OSError()

    print("Policy type is {}".format(policytype))


# Generated at 2022-06-20 16:38:43.696985
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected = [0, 'targeted']
    actual = selinux_getpolicytype()
    assert expected == actual, "expected {0}, got {1}".format(expected, actual)



# Generated at 2022-06-20 16:38:47.875467
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert policy in ('targeted', 'strict', 'minimum', 'none', 'mls')

# Generated at 2022-06-20 16:38:51.450021
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert matchpathcon('/', 0)[0] == 0
    except AssertionError:
        print("assertion failed in matchpathcon")

# Generated at 2022-06-20 16:38:55.289123
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    This function tests the function lgetfilecon_raw
    '''
    test_dir = '/tmp'
    rc, output = lgetfilecon_raw(test_dir)
    assert rc == 0

# Generated at 2022-06-20 16:38:57.558945
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-20 16:39:00.602081
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test matchpathcon()."""
    (result, label) = matchpathcon(b"/selinux", 0)
    assert result == 0
    assert label == 'system_u:object_r:selinuxfs_t:s0'



# Generated at 2022-06-20 16:39:04.109873
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.exists('/etc/issue'):
        [rc, con] = lgetfilecon_raw('/etc/issue')
        if rc < 0:
            raise OSError(rc, os.strerror(rc))
        assert isinstance(con, str)
        assert 'system_u' in con, "con did not contain 'system_u'"
    else:
        # Just check it doesn't raise an exception
        lgetfilecon_raw('/etc/issue')



# Generated at 2022-06-20 16:39:07.209614
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    result = enforcemode
    return result


# Generated at 2022-06-20 16:39:17.549535
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test function definition matchpathcon"""

    # lgetfilecon on a tmpdir to get a context
    path = '/tmp/test_matchpathcon'
    result = lgetfilecon_raw(path)
    assert result[0] == 0, 'lgetfilecon_raw failed'
    expected = result[1]

    # matchpathcon on a tmpfile with 0 as mode
    path = '/tmp/test_matchpathcon'
    result = matchpathcon(path, 0)
    assert result[0] == 0, 'matchpathcon failed'
    context = result[1]
    expected = expected.split(':')[-1]
    assert context == expected, 'matchpathcon gave invalid context'

    # matchpathcon on a tmpfile with 2 as mode
    path = '/tmp/test_matchpathcon'
    result

# Generated at 2022-06-20 16:39:38.352033
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/home/dummy/file'
    mode = 0
    con = c_char_p()
    try:
        rc = _selinux_lib.matchpathcon(path, mode, byref(con))
        print("matchpathcon returned")
        print("Output: " + str(con.value))
        print("Result: " + str(rc))
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-20 16:39:43.120327
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/test"
    mode = 0
    try:
        con = c_char_p()
        rc = _selinux_lib.matchpathcon(path, mode, byref(con))
        return [rc, to_native(con.value)]
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-20 16:39:50.574743
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # create a file in the tmpdir to test with
    with open('testfile', 'w') as fh:
        fh.write('This is a test')

    # set the context on the test file
    lsetfilecon('testfile', 'system_u:object_r:tmp_t:s0')

    # read the context back with lgetfilecon_raw
    [rc, con] = lgetfilecon_raw('testfile')
    assert rc == 0, 'lgetfilecon_raw returned non-zero'
    assert con == 'system_u:object_r:tmp_t:s0', 'lgetfilecon_raw returned %s instead of system_u:object_r:tmp_t:s0' % con


# Generated at 2022-06-20 16:39:54.111751
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Call the function with a test file and use the expected context
    """
    fname = 'test_lgetfilecon_raw'
    open(fname, 'w').close()

# Generated at 2022-06-20 16:39:57.152751
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/selinux/config') == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-20 16:40:02.565871
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.isfile('/etc/fstab'):
        rc, con = lgetfilecon_raw('/etc/fstab')
        assert rc == 0
        assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-20 16:40:09.263393
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import stat
    import tempfile

    try:
        tmpdir = tempfile.mkdtemp()
        myfd, mypath = tempfile.mkstemp(dir=tmpdir)
        os.close(myfd)
        mystat = os.lstat(mypath)
        print(mystat)
        mymode = stat.S_IMODE(mystat.st_mode)
        rc, con = matchpathcon(to_bytes(mypath), mymode)
        print(rc)
        print(con)
    finally:
        os.remove(mypath)
        os.rmdir(tmpdir)

# Generated at 2022-06-20 16:40:11.812687
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert len(selinux_getpolicytype()) == 2


# Generated at 2022-06-20 16:40:12.937033
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert [1, 'targeted'] == selinux_getpolicytype()


# Generated at 2022-06-20 16:40:18.375452
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test function matchpathcon."""
    path = '/tmp/somewhere'
    mode = 0o500
    ret = matchpathcon(path, mode)
    if ret[0] < 0:
        raise Exception('matchpathcon error: {}'.format(os.strerror(ret[0])))


# Generated at 2022-06-20 16:40:56.955242
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type = None
    enforc_mode = 0
    is_enabled = 0
    is_mls_enabled = 0

    try:
        enforc_mode, policy_type = selinux_getpolicytype()
        is_enabled = is_selinux_enabled()
        is_mls_enabled = is_selinux_mls_enabled()
    except NotImplementedError:
        pass

    assert enforc_mode != -1 and is_enabled is not None and is_mls_enabled is not None and isinstance(
        policy_type, str
    )



# Generated at 2022-06-20 16:40:58.619686
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype, rc = selinux_getpolicytype()
    assert rc == 0
    assert policytype == b'targeted'

# Generated at 2022-06-20 16:41:05.370088
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import unittest
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.selinux import selinux_getpolicytype
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.selinux import security_policyvers

    class TestSelinuxGetpolicytype(unittest.TestCase):

        def test_get_policytype_method(self):

            # Arrange
            expected_value = ["targeted", 0]
            selinux_policyvers = int(security_policyvers()[1])

            # Act
            result = selinux_getpolicytype()

            # Assert
            self.assertEqual(result, expected_value)
            self.assertEqual(selinux_policyvers > 0, True)


# Generated at 2022-06-20 16:41:11.750588
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Check that the output is a tuple with 2 elements
    assert(len(lgetfilecon_raw("/")) == 2)

    # Check that the second element of the tuple is a string
    assert(type("") == type(lgetfilecon_raw("/")[1]))

# Generated at 2022-06-20 16:41:20.373312
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test empty path
    (code, value) = matchpathcon('', 0)
    assert(code == -1)
    assert(value is None)

    # Test error code for non-existent path
    (code, value) = matchpathcon('/non/existent/path', 0)
    assert(code == -1)
    assert(value is None)

    # Test error code for unreadable path
    (code, value) = matchpathcon('/dev/full', 0)
    assert(code == -1)
    assert(value is None)

    # Test that a non-existent path yields a context
    (code, value) = matchpathcon('/non/existent/path', 1)
    assert(code == 0)

# Generated at 2022-06-20 16:41:28.789734
# Unit test for function matchpathcon
def test_matchpathcon():
    from ctypes import sizeof
    from ctypes.util import find_library

    if not bool(find_library('selinux')):
        raise ImportError('unable to load libselinux.so')

    if sizeof(c_int) == 4:
        assert matchpathcon(b'/etc/passwd', 4)[1] == 'system_u:object_r:etc_runtime_t:s0'
    elif sizeof(c_int) == 8:
        assert matchpathcon(b'/etc/passwd', 4)[1] == 'system_u:object_r:etc_runtime_t:s0'
    else:
        raise RuntimeError('unsupported size of c_int')


__all__ = tuple(set(dir(sys.modules[__name__])) - {'_selinux_lib'})

# Generated at 2022-06-20 16:41:30.486917
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode == 0


# Generated at 2022-06-20 16:41:36.545012
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: this is just a quick smoke test to make sure the ctypes wrapper has been correctly implemented
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t']
    assert matchpathcon('/var/lib/', 0) == [0, 'system_u:object_r:var_lib_t']

# Generated at 2022-06-20 16:41:45.046159
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/hosts')
    if rc != 0:
        raise AssertionError('Failed to get file SELinux context')
    assert con.startswith('system_u:object_r:etc_t:s0'), 'Not expected SELinux context'
    print('PASSED: lgetfilecon_raw')



# Generated at 2022-06-20 16:41:47.276015
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """Test for selinux_getpolicytype"""
    ast, val = selinux_getpolicytype()
    assert val is not None


# Generated at 2022-06-20 16:43:00.475275
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc_val, result = selinux_getenforcemode()
    assert isinstance(rc_val, int)
    assert isinstance(result, int)



# Generated at 2022-06-20 16:43:08.365186
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Ensure that selinux is enabled
    if is_selinux_enabled() is not 1:
        return True

    rc, con = lgetfilecon_raw('/')
    if rc == 0:
        # context con will be in form of "system_u:object_r:root_t:s0"
        # which is the form of a security context, we will only
        # check that it contains at least one of the delimiters
        if not con.find('_u') or not con.find('_r') or not con.find('_t'):
            print("lgetfilecon_raw() returned invalid security context %s" % con)
            return False
    else:
        print("lgetfilecon_raw() returned error code %i" % rc)
        return False

    # Return True to indicate test passed
   

# Generated at 2022-06-20 16:43:09.035152
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0



# Generated at 2022-06-20 16:43:12.639075
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc >= 0
    assert enforcemode in (0, 1, 2)


# Generated at 2022-06-20 16:43:16.977907
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    stdout, stderr, rc, args, kwargs = bind_address_args(target='selinux_getpolicytype', name='selinux_getpolicytype')
    rc, name = selinux_getpolicytype()
    assert rc == 0
    assert name in ('unknown', 'mcs', 'targeted')

# Generated at 2022-06-20 16:43:18.510248
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/proc')
    assert rc == 0
    assert con == b'unlabeled_t'

# Generated at 2022-06-20 16:43:23.332945
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/selinux"
    mode = 0

    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:selinux_var_t:s0'



# Generated at 2022-06-20 16:43:28.009240
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import mock
    import selinux

    with mock.patch.object(selinux, '_selinux_lib', spec=CDLL) as selinux_lib_mock:
        selinux_lib_mock.selinux_getenforcemode.return_value = 0
        assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-20 16:43:30.079157
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-20 16:43:34.714639
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] != ''
    assert lgetfilecon_raw('/tmp/does_not_exist')[0] != 0
