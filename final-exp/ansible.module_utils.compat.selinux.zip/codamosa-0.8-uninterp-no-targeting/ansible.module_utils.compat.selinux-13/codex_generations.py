

# Generated at 2022-06-20 16:36:02.678091
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'



# Generated at 2022-06-20 16:36:07.314924
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    print("Return code: {0}".format(rc))
    print("Policy: {0}".format(policy))
    assert (rc == 0)
    assert (isinstance(policy, str))

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:36:11.928048
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if os.environ.get('ANSIBLE_TEST_UTILS_SELINUX_GETPOLICYTYPE', False):
        print(selinux_getpolicytype())



# Generated at 2022-06-20 16:36:16.177180
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''This test is expected to run under a system with SELinux enabled
    with enforcing mode and in permissive mode.
    '''
    rc, enforce = selinux_getenforcemode()
    assert rc == 0
    assert enforce == 1

    rc, enforce = selinux_getenforcemode()
    assert rc == 0
    assert enforce == 0

# Generated at 2022-06-20 16:36:19.409034
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('/etc/passwd', 0)
    print('ret', ret)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:36:23.014884
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        import selinux
    except ImportError:
        print('Missing module selinux, skipping test_selinux_getpolicytype')
        return
    [rc, con] = selinux_getpolicytype()
    assert rc == 0
    assert con == 'targeted'


# Generated at 2022-06-20 16:36:27.902427
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    from ansible.module_utils._text import to_bytes
    # find path to a file
    path = to_bytes(os.path.realpath(__file__))
    res = matchpathcon(path, 0)
    assert res[0] == 0
    print(res[1])

    # find path to a directory
    path = to_bytes(os.path.dirname(path))
    res = matchpathcon(path, 0)
    assert res[0] == 0
    print(res[1])



# Generated at 2022-06-20 16:36:31.750265
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, output = lgetfilecon_raw(b'/home/testuser/filetest')
    # This test may fail if something has happened to
    # the user's home directory (for instance)
    assert rc == 0
    assert output == 'unconfined_u:object_r:user_home_t:s0'


# Generated at 2022-06-20 16:36:42.319516
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import time

    [rc, context] = matchpathcon(os.path.expanduser('~/foobar'), 0)

    if rc:
        print('Error in matchpathcon')
        print('Return code: %d' % rc)
        print('Return message: %s' % os.strerror(rc))
        print('\n')
    else:
        print('Context before: %s' % context)
        print('Waiting 20 seconds for context change')
        time.sleep(20)
        [rc, context] = matchpathcon(os.path.expanduser('~/foobar'), 0)
        if rc:
            print('Error in matchpathcon')
            print('Return code: %d' % rc)
            print('Return message: %s' % os.strerror(rc))

# Generated at 2022-06-20 16:36:47.317379
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 1
    rc, con = matchpathcon('/etc/resolv.conf', os.R_OK)
    if rc < 0:
        raise OSError(get_errno(), os.strerror(get_errno()))
    assert rc == 0 and con == "system_u:object_r:net_conf_t:s0"



# Generated at 2022-06-20 16:36:59.001120
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_dir = "/tmp/selinux_testfile"
    test_file = "testfile"
    filecon = 'user_u:object_r:user_tmp_t:s0'
    rc = os.system("mkdir {0}".format(test_dir))
    if rc != 0:
        raise AssertionError('Unable to create test directory {0}'.format(test_dir))
    rc = os.system("touch {0}/{1}".format(test_dir,test_file))
    if rc != 0:
        raise AssertionError('Unable to create test file {0}/{1}'.format(test_dir,test_file))
    rc = os.system("chcon --reference=. {0}/*".format(test_dir))

# Generated at 2022-06-20 16:37:01.651167
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/fstab') == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-20 16:37:11.612340
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME: this test only works on selinux systems (and it still has issues)
    import logging
    logging.basicConfig(level=logging.DEBUG)
    log = logging.getLogger(__name__)
    log.info("selinux.lgetfilecon_raw() test")
    [rc, con] = selinux_getenforcemode()
    log.info("selinux_getenforcemode %s %s" % (rc, con))
    if con <= 0:
        log.error("selinux_getenforcemode() %s %s" % (rc, con))
        return False

    [rc, con] = selinux_getpolicytype()
    log.info("selinux_getpolicytype %s %s" % (rc, con))

# Generated at 2022-06-20 16:37:14.251319
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert to_native(lgetfilecon_raw('/etc/passwd')[1]).startswith('unconfined_u:object_r:user_home_t:s0')



# Generated at 2022-06-20 16:37:17.046787
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-20 16:37:19.815786
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert type(policytype[0]) == type(int()) and type(policytype[1]) == type(str())



# Generated at 2022-06-20 16:37:21.167324
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    return selinux_getenforcemode()


# Generated at 2022-06-20 16:37:27.069533
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()

    if rc < 0:
        raise Exception("unable to determine selinux enforcemode: %s" % enforcemode)
    else:
        enforcemode_map = {-1: 'permissive', 0: 'disabled', 1: 'enforcing'}
        print("selinux enforcemode is: %s" % enforcemode_map[enforcemode])



# Generated at 2022-06-20 16:37:29.811537
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    test_arg = 'path'
    expected = 0
    actual = _selinux_lib.selinux_getpolicytype(test_arg)
    assert expected == actual


# Generated at 2022-06-20 16:37:38.737525
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon
    """
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    if rc != 0:
        raise Exception('matchpathcon returned non-zero: expected: 0 got: %d' % rc)
    if con != 'system_u:object_r:etc_t:s0':
        raise Exception('matchpathcon returned incorrect context: expected: system_u:object_r:etc_t:s0 got: %s' % con)



# Generated at 2022-06-20 16:37:53.529555
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def _test_error(errno, exctype=None):
        if exctype is None:
            exctype = OSError

        real_errno = errno
        errno = get_errno()
        set_errno(real_errno)
        try:
            con = c_char_p()
            rc = _selinux_lib.lgetfilecon_raw('', byref(con))
            assert rc == -real_errno
            raise AssertionError('unexpected success')
        except exctype as ex:
            assert ex.errno == real_errno, 'errno {0} != {1}'.format(ex.errno, real_errno)
        finally:
            set_errno(errno)


# Generated at 2022-06-20 16:37:56.271676
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Unit test for function selinux_getpolicytype

    Test case:
    Test that selinux_getpolicytype is returning a string
    """
    assert isinstance(selinux_getpolicytype()[1], str), \
        'function selinux_getpolicytype returned unexpected result'

# Generated at 2022-06-20 16:37:59.738437
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        import selinux
    except ImportError:
        return

    rc = selinux_getenforcemode()
    if rc[0] == 0:
        assert rc[0] == 0
        assert rc[1] == 1 or rc[1] == 0
    else:
        print("Unable to get selinux_getenforcemode")


# Generated at 2022-06-20 16:38:05.562338
# Unit test for function matchpathcon
def test_matchpathcon():
    _selinux_lib.security_set_boolean_list.restype = c_int
    _selinux_lib.security_set_boolean_list.argtypes = [c_char_p, POINTER(c_int)]

    # Remove an already declared Boolean
    _selinux_lib.security_boolean_mls_enabled.restype = c_int
    _selinux_lib.security_boolean_mls_enabled.argtypes = [POINTER(c_int)]
    mls_enabled = c_int()
    _selinux_lib.security_boolean_mls_enabled(byref(mls_enabled))
    if mls_enabled == 0:  # it is false, so remove it
        null_bool = POINTER(c_int)()
        null_bool = c

# Generated at 2022-06-20 16:38:10.121665
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test.txt'

    # Read and write mode
    matchpathcon(path, 0)
    # Write only mode
    matchpathcon(path, 1)

    try:
        # Negative mode
        matchpathcon(path, -5)
    except Exception as e:
        if e.args[0] == 22:
            assert e.args[1] == 'Invalid argument'
        else:
            assert False



# Generated at 2022-06-20 16:38:13.891811
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == b'system_u:object_r:etc_t:s0'


# Generated at 2022-06-20 16:38:15.176460
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0



# Generated at 2022-06-20 16:38:17.267471
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    returncode, output = selinux_getpolicytype()

    assert isinstance(output, str)
    assert isinstance(returncode, int)


# Generated at 2022-06-20 16:38:19.056242
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con_type = selinux_getpolicytype()
    assert 0 == rc
    assert "targeted" == con_type


# Generated at 2022-06-20 16:38:20.746391
# Unit test for function matchpathcon
def test_matchpathcon():
    ret, _ = matchpathcon("/tmp", 0)
    assert ret == 0
    assert _ == u'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-20 16:38:27.209074
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/passwd'
    mode = 0o600

    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:etc_runtime_t:s0-s0:c0.c1023'

# Generated at 2022-06-20 16:38:29.243242
# Unit test for function matchpathcon
def test_matchpathcon():
    sys.modules[__name__].matchpathcon = matchpathcon
    v = sys.modules[__name__].matchpathcon("/var/lib/sss/mc/passwd", 0)
    assert v == [0, 'unconfined_u:object_r:usr_t:s0']



# Generated at 2022-06-20 16:38:32.330804
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fd, path = tempfile.mkstemp(prefix='ansible_test_lgetfilecon')
    os.close(fd)

    try:
        # Test files created by Python's tempfile module are correctly
        # labeled with user_home_t.
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'unconfined_u:object_r:user_home_t:s0'
    finally:
        os.remove(path)

# Generated at 2022-06-20 16:38:34.796055
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test of function selinux_getenforcemode"""
    [rc, mode] = selinux_getenforcemode()
    print('return code is {0} and mode is {1}'.format(rc, mode))
    return



# Generated at 2022-06-20 16:38:45.923777
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def test_setup(tf_path, tf_content):
        with open(tf_path, 'w') as tf:
            tf.write(tf_content)

    try:
        tf_path = '/tmp/filecon-test-file'
        test_setup(tf_path, 'some test content')
        assert lgetfilecon_raw(tf_path)[1] == 'system_u:object_r:etc_t:s0'
        test_setup(tf_path, 'some test content')
        assert lgetfilecon_raw(tf_path)[1] == 'system_u:object_r:etc_t:s0'
        os.unlink(tf_path)
    except OSError as e:
        print('OSError: {0}'.format(e))
        # raise



# Generated at 2022-06-20 16:38:50.399544
# Unit test for function matchpathcon
def test_matchpathcon():
    if sys.version > '3':
        assert matchpathcon(b'/etc', 0) == [0, 'system_u:object_r:etc_t']
    else:
        assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t']



# Generated at 2022-06-20 16:38:52.295372
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print('Testing libselinux.lgetfilecon_raw')
    assert lgetfilecon_raw('.')

# Generated at 2022-06-20 16:38:54.985430
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert len(policy) > 0



# Generated at 2022-06-20 16:38:56.023222
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] in ('selinux', 'refpolicy', 'unknown')

# Generated at 2022-06-20 16:39:01.557937
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes

    def _validate_output(key, expected=None, actual=None, msg_headers=(), *args, **kwargs):
        if expected:
            output = 'got {0} expected {1}'.format(actual, expected)
        else:
            output = 'got {0}'.format(actual)

        output = ' '.join(msg_headers) + ' ' + output

        # basic is a dict subclass, avoid dict operations that overwrite data
        if actual == expected:
            basic[key] = output
        else:
            if 'err' not in basic:
                basic['err'] = {key: output}
            else:
                basic

# Generated at 2022-06-20 16:39:20.105644
# Unit test for function matchpathcon
def test_matchpathcon():
    if not os.path.exists('/tmp/.selunittest'):
        os.mkdir('/tmp/.selunittest')
        os.chmod('/tmp/.selunittest', 0o777)

    # if "matchpathcon" return a list of 2 items, the first one is the return code
    # and the second one is the value return, if the return code is not -1, the second
    # one is not the expected value:

    # Expected to be Not the expected value
    # the return code will be 0, so the second item will be the context value
    # UNDEF since the path does not exist
    my_matchpath = matchpathcon('/tmp/.selunittest/UNDEF', os.F_OK)
    if my_matchpath[0] != -1:
        assert my_matchpath

# Generated at 2022-06-20 16:39:26.024530
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Validate that selinux_getpolicytype() returns the correct string
    for the policy type.
    """
    rc, con = selinux_getpolicytype()

    if not rc == 0:
        raise Exception("Could not get SELinux Policy type. Error {}".format(rc))
    if not con.lower() in ['targeted', 'strict', 'mls']:
        raise Exception("Unexpected SELinux Policy type found: {}".format(con))

# Generated at 2022-06-20 16:39:35.295213
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """ Unit tests for module function 'lgetfilecon_raw' """
    # create file to test
    f = open("/tmp/test_file", "a")
    f.close()

    # get context of the file
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw("/tmp/test_file", byref(con))
        return [rc, to_native(con.value)]
    finally:
        _selinux_lib.freecon(con)
    os.remove("/tmp/test_file")

# Generated at 2022-06-20 16:39:41.497036
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
  if not is_selinux_enabled():
    print("SELinux not enabled on the system, skipping test")
    return
  if selinux_getenforcemode()[1] == 0:
    print("SELinux enforcing mode disabled on the system, skipping test")
    return
  con = lgetfilecon_raw("/etc/selinux/config")
  assert con[1] != '', 'lgetfilecon_raw returns an empty string'


# Generated at 2022-06-20 16:39:45.028141
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0] or selinux_getenforcemode() == [0, 1]


if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-20 16:39:47.545164
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/system/bin/sh"
    mode = 0
    assert matchpathcon(path, mode) == [0, 'u:object_r:system_file:s0']



# Generated at 2022-06-20 16:39:53.246167
# Unit test for function matchpathcon
def test_matchpathcon():
    # Setting the path to "/tmp/testfile" and mode to 0
    rc, con = matchpathcon("/tmp/testfile", 0)
    # Asserting that the actual return code is equal to the expected return code 0
    assert rc==0
    # Asserting that the actual file context is equal to the expected file context "unconfined_u:object_r:user_tmp_t:s0"
    assert con=="unconfined_u:object_r:user_tmp_t:s0"

# Generated at 2022-06-20 16:39:57.886354
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils import selinux

    test_directory = "/usr"
    rc, con = selinux.matchpathcon(test_directory, 0)
    if rc >= 0:
        print("Test: matchpathcon: success")
    else:
        print("Test: matchpathcon: failed")



# Generated at 2022-06-20 16:40:03.090404
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp/selinux', 0o0 )
    if rc == -1:
        print('could not get the context for /tmp/selinux')
    else:
        print('New SELinux context is: {0}'.format(con))



# Generated at 2022-06-20 16:40:05.011287
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, "system_u:object_r:passwd_file_t:s0"]

# Generated at 2022-06-20 16:40:22.621934
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/shadow') == [0, 'system_u:object_r:shadow_t:s0']

# Generated at 2022-06-20 16:40:25.631791
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    x = selinux_getenforcemode()
    assert isinstance(x, list)
    assert len(x) == 2
    assert isinstance(x[0], int)
    assert isinstance(x[1], int)



# Generated at 2022-06-20 16:40:27.265033
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Setup
    rc = 0
    expected_rc = 0
    enforcemode = 0

    # Test execution
    (rc, enforcemode) = selinux_getenforcemode()

    # Verification
    assert rc == expected_rc

# Generated at 2022-06-20 16:40:30.023500
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        import selinux
    except ImportError:
        pass
    else:
        assert selinux.selinux_getpolicytype() == selinux_getpolicytype()

# Generated at 2022-06-20 16:40:39.052195
# Unit test for function matchpathcon
def test_matchpathcon():
    test_entries = [
        ("/",                      0),
        ("/usr",                   0),
        ("/usr/bin",               0),
        ("/dev",                   -13),
        ("/tmp",                   0),
        ("/tmp/test",              0),
        ("/tmp/test/testing",      0),
        ("/tmp/test/testing/more", 0),
        ("/selinux/stub",          -13),
    ]
    for (path, rc_exp) in test_entries:
        (rc, con) = matchpathcon(path, os.R_OK)
        assert rc == rc_exp, "{0}: Expected rc {1}, got {2}".format(path, rc_exp, rc)

# Generated at 2022-06-20 16:40:44.611987
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # set up things
    test = '/tmp/my_temporary_file'
    f = open(test, 'w')
    f.close()

    # run
    res = lgetfilecon_raw(test)[1]

    # tear down things
    os.remove(test)

    # assert
    assert res == 'system_u:object_r:unlabeled_t:s0'


# Generated at 2022-06-20 16:40:48.650945
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.basic import AnsibleModule  # noqa: F401
    expected = (0, b'static')
    actual = selinux_getpolicytype()
    assert expected == actual, 'Failed to execute selinux_getpolicytype()'



# Generated at 2022-06-20 16:40:51.119355
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    This function is used to return policy type
    """
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0


# Generated at 2022-06-20 16:41:01.393448
# Unit test for function matchpathcon
def test_matchpathcon():
    assert isinstance(matchpathcon('/', 0), list)
    try:
        matchpathcon('/', None)
    except TypeError:
        pass
    else:
        print('FAILURE: argtypes for matchpathcon() does not reject None for mode')
    try:
        matchpathcon('/', 'foo')
    except TypeError:
        pass
    else:
        print('FAILURE: argtypes for matchpathcon() does not reject non-integer type for mode')
    try:
        matchpathcon(None, 0)
    except TypeError:
        pass
    else:
        print('FAILURE: argtypes for matchpathcon() does not reject None for path')
    try:
        matchpathcon(12, 0)
    except TypeError:
        pass

# Generated at 2022-06-20 16:41:02.856082
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert(selinux_getenforcemode())

# Generated at 2022-06-20 16:41:40.438709
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile, shutil
    import subprocess

    tmppath = tempfile.mkdtemp()
    tmppath2 = tempfile.mkdtemp(dir=tmppath)
    tmppath3 = tempfile.mkdtemp(dir=tmppath)
    temp3dir = os.path.join(tmppath3, 'test')
    temp3file = os.path.join(temp3dir, 'file')
    tmpfilepath = tempfile.mkstemp(dir=tmppath)[1]

# Generated at 2022-06-20 16:41:44.690952
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/selinux/config', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-20 16:41:47.364973
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, path = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert path == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-20 16:41:59.696072
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """Unit test for selinux_getpolicytype()"""

    try:
        import selinux
    except ImportError:
        raise NotImplementedError('unable to import selinux library for native selinux matchpathcon')

    alt_policy_types = [
        'targeted',
        'minimum',
        'mls',
        'unconfined_u',
        'strict',
        'unconfined_r',
    ]

    # The policy type should be one of the standard policy types listed above, but
    # in case anyone adds a custom policy type, we need to handle that.
    policy_type = selinux.getpolicytype()
    if not policy_type in alt_policy_types:
        alt_policy_types.append(policy_type)

    # Make sure we can get the policy type

# Generated at 2022-06-20 16:42:03.109073
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _, policytype = selinux_getpolicytype()
    assert policytype == 'targeted'



# Generated at 2022-06-20 16:42:05.313134
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print(selinux_getpolicytype())


# Generated at 2022-06-20 16:42:09.830808
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, res) = matchpathcon('etc/hosts', 0)
    assert res == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-20 16:42:15.309819
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon function
    """

    path = "/etc/shadow"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    if rc < 0:
        raise Exception("rc is less than 0")
    if con is None or con == "":
        raise Exception("invalid con string returned by matchpathcon")
    print("con: %s" % con)



# Generated at 2022-06-20 16:42:17.782806
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/etc/selinux/config")
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"

# Generated at 2022-06-20 16:42:23.253195
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils._selinux import selinux_getenforcemode

    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert type(enforcemode) == int
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-20 16:43:36.646358
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    test_rc, test_type = selinux_getpolicytype()
    assert test_rc == 0
    assert test_type == 'targeted'


# Generated at 2022-06-20 16:43:44.719682
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, 'selinux_getpolicytype returned rc=%d' % rc
    assert policytype, 'selinux_getpolicytype returned type=%s' % policytype
    assert policytype.startswith('\x00'), 'policytype not null terminated'

# Generated at 2022-06-20 16:43:47.624161
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert matchpathcon('/', 0)[0] == 0
    except OSError:
        # If SELinux is not enabled, this function will fail with "Invalid argument"
        if get_errno() == 22:
            return
        raise



# Generated at 2022-06-20 16:43:49.809600
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    test matchpathcon function with a random path
    """
    assert matchpathcon("/tmp/xyz", 0) == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-20 16:43:50.675799
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-20 16:43:58.682038
# Unit test for function matchpathcon
def test_matchpathcon():
    import errno

    # Note, this test will only work on a system that has SELinux installed
    # and has selinux policy installed.  This test will not work if SELinux
    # is in Permissive mode, since the matchpathcon call will fail.

    (rc, con) = matchpathcon('/', 0)
    if rc == -errno.ENOENT:
        return

    assert rc == 0
    assert con[:19] == 'system_u:object_r:'

# Generated at 2022-06-20 16:44:05.679181
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert policy_type != ''
    # test for failure
    _selinux_lib.selinux_getpolicytype = None
    with pytest.raises(NotImplementedError):
        selinux_getpolicytype()


# Generated at 2022-06-20 16:44:11.571096
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("Testing function selinux_getenforcemode")

    # Exercise function
    function_rc, function_result = selinux_getenforcemode()

    # Verify the result
    print("Result: " + str(function_result))
    if function_rc != 0:
        raise AssertionError(str(function_rc))


if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-20 16:44:14.084278
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    mode = 'u:object_r:user_tmp_t:s0'
    path = tempfile.mktemp(prefix='ansible-test-', dir='/tmp')

    rc, _ = lsetfilecon(path, mode)
    assert rc >= 0

    rc, context = lgetfilecon_raw(path)
    assert rc >= 0
    assert context == mode

    rc, _ = lsetfilecon(path, None)
    assert rc >= 0

# Generated at 2022-06-20 16:44:15.677558
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]