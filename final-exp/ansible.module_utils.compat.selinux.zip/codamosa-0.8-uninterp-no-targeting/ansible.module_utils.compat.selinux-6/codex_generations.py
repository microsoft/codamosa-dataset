

# Generated at 2022-06-20 16:36:04.744914
# Unit test for function matchpathcon
def test_matchpathcon():
    con = c_char_p()
    try:
        rc = _selinux_lib.matchpathcon("/usr/share/applications/gnome-terminal.desktop", 0, byref(con))
        print(rc)
        print(con)
        print(to_native(con.value))
    finally:
        _selinux_lib.freecon(con)

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:36:06.692131
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policy, str)

# Generated at 2022-06-20 16:36:09.050489
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("Testing function 'selinux_getpolicytype'")
    print(selinux_getpolicytype())


# Generated at 2022-06-20 16:36:12.344921
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    mode_file_type = 0
    path = "/"
    rc, con  = lgetfilecon_raw(path)
    print('Returns: {} File context: {}'.format(rc, con))
    if rc < 0:
        raise Exception('path: {} return code: {}'.format(path, rc))
    if con == "<<none>>":
        raise Exception('path: {} context: {}'.format(path, con))


# Generated at 2022-06-20 16:36:13.293700
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'  # Unconfined

    return True

# Generated at 2022-06-20 16:36:18.569673
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0, 'Test selinux_getenforcemode returned %d, expected 0' % rc
    if mode in {0, 1, 2}:
        return
    raise AssertionError('Test selinux_getenforcemode returned bad mode %d, expected 0, 1, or 2' % mode)


# Generated at 2022-06-20 16:36:19.834280
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0


# Generated at 2022-06-20 16:36:24.336127
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    if rc != 0:
        print('Failed to get policy type: %s' % con)
        sys.exit(1)

    print('SELinux policy type: %s' % con)
    sys.exit(0)

if __name__ == "__main__":
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:36:27.926541
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = 0
    rc, con = matchpathcon("/tmp", mode)
    if (rc >= 0):
        print("Context for /tmp is %s" % con)
    else:
        print("Could not get context for /tmp")


# Generated at 2022-06-20 16:36:30.539353
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    output = selinux_getenforcemode()
    assert isinstance(output, list)
    assert len(output) == 2
    assert isinstance(output[1], int)
    assert output[0] == 0


# Generated at 2022-06-20 16:36:36.492503
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("Testing: selinux_getpolicytype")
    policytype, rc = selinux_getpolicytype()
    if rc == 0:
        print("{}".format(policytype))
        return True
    else:
        return False


# Generated at 2022-06-20 16:36:44.870725
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    # On debian/Ubuntu at least
    # /etc/selinux/mcs/contexts/files/file_contexts:
    #     /tmp/foo(/.*)?   system_u:object_r:tmp_t:s0
    """
    rc, con = matchpathcon(b'/tmp/foo', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    rc, con = matchpathcon(b'/tmp/foo/bar', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    # removes the last component
    rc, con = matchpathcon(b'/tmp/foo/bar/baz', 0)
    assert rc == 0

# Generated at 2022-06-20 16:36:46.748762
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    print("%s %s" % (rc, policytype))

# Generated at 2022-06-20 16:36:51.718557
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.basic import AnsibleModule

    rvalue, rc = selinux_getpolicytype()
    if rvalue == 0:
        print('Selinux type is: ', rc)
    else:
        print('Selinux type is not set')


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:37:01.122131
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """This is a selinux only test which should fail to run on non selinux systems or systems without python selinux bindings
       selinux is a security module for the linux kernel.  on selinux systems this test should return the selinux context of the
       current working directory.

       This is a basic unit test to ensure the selinux bindings are working.  Other tests could be added that would attempt to
       acquire the context of directories and files.

       https://docs.python.org/2/library/ctypes.html
       https://wiki.python.org/moin/ctypes
       https://www.redhat.com/archives/libvir-list/2008-August/msg00179.html
    """

    result = lgetfilecon_raw(os.getcwd())
    assert not result[0]
    assert isinstance(result[1], str)



# Generated at 2022-06-20 16:37:06.323248
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    print('rc: %s, enforcemode: %s, type(enforcemode): %s' % (rc, enforcemode, type(enforcemode)))
    assert rc == 0 and isinstance(enforcemode, int)


# Generated at 2022-06-20 16:37:11.628796
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Test case for function selinux_getenforcemode.
    """
    verify_getenforcemode = selinux_getenforcemode()
    print(verify_getenforcemode)
    verify_getenforcemode2 = security_getenforce()
    print("Verify that selinux_getenforcemode and security_getenforce return the same value.")
    if verify_getenforcemode[1] == verify_getenforcemode2:
        print("These functions do return the same value.")
    else:
        print("These functions do not return the same value.")
    print("Check the return code to see if call was successful.")
    if verify_getenforcemode[0] == 0:
        print("The return code is 0, indicating successful call.")

# Generated at 2022-06-20 16:37:16.895461
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():

    (rc, enforcemode) = selinux_getenforcemode()
    if rc == 0:
        print("SELinux current mode is: " + str(enforcemode))
    else:
        print("Failed to get SELinux mode with status " + str(rc))



# Generated at 2022-06-20 16:37:19.104755
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if is_selinux_enabled():
        assert selinux_getenforcemode()[1] != -1


# Generated at 2022-06-20 16:37:20.968862
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(__file__) == [0, b'unlabeled_t']

# Generated at 2022-06-20 16:37:30.262426
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, enforcemode = selinux_getenforcemode()
    except OSError:
        raise AssertionError("selinux_getenforcemode() threw an OSError exception.")
    if rc != 0:
        raise AssertionError("selinux_getenforcemode() returned a non-zero rc: %d." % rc)
    if enforcemode < 0 or enforcemode > 2:
        raise AssertionError("selinux_getenforcemode() returned an unknown enforcemode: %d." % enforcemode)



# Generated at 2022-06-20 16:37:42.504250
# Unit test for function matchpathcon
def test_matchpathcon():
    # The test is based on this test case at https://github.com/besser82/selinux-python/blob/master/test_selinux.py
    # The function would typically return mode=1 and con="" on success
    # So we test that the function returns the proper context
    path = '/etc/selinux/'
    expected_context = 'system_u:object_r:etc_t:s0'
    mode = 1
    con = c_char_p()
    try:
        rc = _selinux_lib.matchpathcon(path, mode, byref(con))
        if rc >= 0:
            assert expected_context == to_native(con.value)
        else:
            assert rc < 0
    finally:
        _selinux_lib.freecon(con)

#

# Generated at 2022-06-20 16:37:53.453324
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    selinux_mode_list = [
        "enforcing",
        "permissive",
        "disabled"
    ]
    for selinux_mode in selinux_mode_list:
        spawn_cmd = 'python -c "import selinux; print selinux.selinux_getpolicytype()" | grep -v None'
        spawn_cmd = '/usr/bin/python -c "import selinux; print selinux.selinux_getpolicytype()" | grep -v None'
        rc, stdout, stderr = module.run_command(spawn_cmd)
        if rc != 0:
            module.fail_json(msg='selinux_getpolicytype failed')
        policytype = stdout.strip()
        module.exit_json(selinux_mode=selinux_mode, policytype=policytype)

# Generated at 2022-06-20 16:37:56.018876
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw(b'/dev/null')
    if result == [0, 'system_u:object_r:null_device_t:s0']:
        print('Success')
    else:
        print('Failure')


# Generated at 2022-06-20 16:37:58.304580
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, _ = selinux_getenforcemode()
    assert rc == 0


# Generated at 2022-06-20 16:38:00.026429
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, result = selinux_getenforcemode()
    assert 0 <= rc
    assert isinstance(result, int)



# Generated at 2022-06-20 16:38:01.827551
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/selinux/config', 0)[1] == 'system_u:object_r:etc_runtime_t'

# Generated at 2022-06-20 16:38:08.570631
# Unit test for function matchpathcon
def test_matchpathcon():
    retval = matchpathcon("/tmp/testdir", os.R_OK)
    assert retval[0] == 0
    assert retval[1].startswith("unconfined_u:object_r:user_tmp_t")
    retval = matchpathcon("/tmp/testdir", 2)
    assert retval[0] == 0
    assert retval[1] is None

# Generated at 2022-06-20 16:38:10.613372
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    assert rc == 0

# Generated at 2022-06-20 16:38:14.008617
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/usr/bin/python')
    if rc != 0:
        raise AssertionError('lgetfilecon_raw returned %d' % rc)


# Generated at 2022-06-20 16:38:23.492011
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    test_data = {
        'domain': 'unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023',
        'result': 'targeted'
    }
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, 'call to selinux_getpolicytype failed'
    assert type(policytype) == str, 'selinux_getpolicytype returned unexpected result'
    assert policytype in str(test_data['domain'])


# Generated at 2022-06-20 16:38:28.349338
# Unit test for function matchpathcon
def test_matchpathcon():
    if selinux_getenforcemode()[0] != 0 and selinux_getenforcemode()[1] != 0:
        assert matchpathcon('/etc/passwd', 0)[0] == 0
        assert matchpathcon('/testfile', 0)[0] == 1
    else:
        assert matchpathcon('/etc/passwd', 0)[0] == 1
        assert matchpathcon('/testfile', 0)[0] == 1

# Generated at 2022-06-20 16:38:31.062907
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw("/etc/selinux/config")
    assert result[0] == 0



# Generated at 2022-06-20 16:38:35.191350
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_con = b'unconfined_u:object_r:user_home_t:s0'
    test_path = b'/home/' + os.environ['USER']
    test_list = lgetfilecon_raw(test_path)
    assert test_list[0] == 0
    assert test_list[1] == test_con

# Generated at 2022-06-20 16:38:40.820385
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    selinux_enforce = selinux_getenforcemode()
    if selinux_enforce[0] == 0:
        assert selinux_enforce[1] == 1 or selinux_enforce[1] == 0, 'invalid enforce mode return'



# Generated at 2022-06-20 16:38:45.273623
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0, 'got: %d expected: %d' % (rc, 0)
    assert enforcemode == -1 or enforcemode == 0 or enforcemode == 1,\
        'got: %d expected: on of {-1, 0, 1}' % enforcemode



# Generated at 2022-06-20 16:38:54.726079
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import os
    import tempfile
    import shutil
    import os.path

    # Construct TEST_DIR in the system's temporary directory
    top_tmp_dir = tempfile.gettempdir()
    test_dir = os.path.normpath(os.path.join(top_tmp_dir, 'test-selinux-getpolicytype'))
    shutil.rmtree(test_dir, ignore_errors=False, onerror=None)
    os.makedirs(test_dir)

    # Create empty file in the temporary directory
    test_file = 'test_file-selinux-getpolicytype'
    test_path = os.path.join(test_dir, test_file)
    open(test_path, 'a').close()

    # Test function
    [rc,policy] = selinux_get

# Generated at 2022-06-20 16:38:55.977561
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-20 16:38:58.207425
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policytype) = selinux_getpolicytype()
    if rc == 0:
        print(policytype)
    else:
        print(rc)



# Generated at 2022-06-20 16:39:01.752104
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/tmp'
    rc, con = lgetfilecon_raw(test_path)

    if rc != -1:
        print('Path: %s has the context: %s' % (test_path, con))
    else:
        print('Get the context for %s failed.' % test_path)


# Generated at 2022-06-20 16:39:15.135865
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc:
        # FIXME: the unit test should actually raise an error so we can detect this
        # this is a dummy value so the unit test doesn't run into an error if
        # the selinux_getpolicytype call fails.
        policytype = "I Don't Know"

    assert isinstance(policytype, str)

# Generated at 2022-06-20 16:39:16.769047
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    return lgetfilecon_raw(b'/etc/shadow')


# Generated at 2022-06-20 16:39:26.604051
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/dev/null'
    ret = lgetfilecon_raw(path)

# Generated at 2022-06-20 16:39:28.204334
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]
    assert selinux_getenforcemode()[1] == 1



# Generated at 2022-06-20 16:39:36.666928
# Unit test for function matchpathcon
def test_matchpathcon():
    import pytest

    # Unit test for function matchpathcon

    result = matchpathcon('/', 4)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:var_t:s0'
    result = matchpathcon('/', 68)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:var_t:s0'


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:39:37.509745
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']


# Generated at 2022-06-20 16:39:39.808926
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Testing for non-MLS policy (e.g. default policy)
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-20 16:39:42.461271
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon('/etc/passwd', 0)
    print('rc from matchpathcon: {0}'.format(rc))
    assert rc == 0


# Generated at 2022-06-20 16:39:45.058325
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    print('selinux_getpolicytype returned: ', rc)
    print('selinux_getpolicytype returned: ', con)

# Generated at 2022-06-20 16:39:45.967686
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 16:40:03.140519
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

# Generated at 2022-06-20 16:40:05.046286
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]
    assert selinux_getenforcemode()[1] == 0


# Generated at 2022-06-20 16:40:12.922579
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from os import mkdir
    from shutil import rmtree
    from tempfile import mkdtemp

    con_type = 's0:system_r:ansible_managed_t:s0'
    filename = 'testfile'

    tmpdir_name = mkdtemp()
    filename_path = os.path.join(tmpdir_name, filename)
    os.symlink('/bin/bash', filename_path)

    rc, con = lgetfilecon_raw(filename_path)
    assert rc == 0
    assert con_type in con

    os.remove(filename_path)

    rc, con = lgetfilecon_raw(tmpdir_name)
    assert rc == 0
    assert con_type in con

    rmtree(tmpdir_name, ignore_errors=True)


# Generated at 2022-06-20 16:40:16.289882
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    print("rc:", rc, "mode:", mode)
    assert rc == 0, 'Enforce mode should be 0'


# Generated at 2022-06-20 16:40:23.712041
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Test to verify selinux_getenforcemode function
    """
    result = selinux_getenforcemode()
    if result[0] == 0:
        assert result[1] in [-1, 0, 1], 'Unexpected result'
    elif result[0] == 1:
        assert result[1] == -1, 'Unexpected result'
    else:
        assert result[1] == -1, 'Unexpected result'



# Generated at 2022-06-20 16:40:31.063633
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'test'
    mode = 0

    # FIXME: make this work off of selabel_lookup, but that's going to be annoying - maybe it's this type: b'/path/to/file:type:role:level'
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    if rc != -1:
        print(to_native(con.value))
        _selinux_lib.freecon(con)

    print('{0}'.format(rc))
    errno = get_errno()
    print('{0}'.format(os.strerror(errno)))


# Generated at 2022-06-20 16:40:39.184291
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    '''
    Ansible module to test the lgetfilecon_raw function.
    :return:
    '''
    import json

    for entry in ['/etc/fedora-release', '/etc/redhat-release']:
        try:
            rc, con = lgetfilecon_raw(entry)
            if rc != 0:
                print("Unable to get file context: %s" % con)
                continue
        except OSError as exc:
            print("Unable to get file context: %s" % exc)
            continue
        print("File: %s, Context: %s" % (entry, con))

    # This code will also dump out the current policy type
    # and enforce mode.
    rc, pt = selinux_getpolicytype()

# Generated at 2022-06-20 16:40:41.982242
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    if rc != 0:
        raise RuntimeError('selinux_getenforcemode failed - aborting test')
    assert mode == 1


# Generated at 2022-06-20 16:40:44.871251
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():

    rc, enforcemode = selinux_getenforcemode()
    assert(rc == 0)
    assert(enforcemode == 0 or enforcemode == 1)


# Generated at 2022-06-20 16:40:50.852615
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This test is based of the following command in python3:
    #     import selinux
    #     selinux.lgetfilecon_raw('/etc/passwd')
    result = lgetfilecon_raw(b'/etc/passwd')
    assert result[0] >= 0, "lgetfilecon_raw return code is not zero"
    assert result[1], "lgetfilecon_raw return value is None"


# Generated at 2022-06-20 16:41:00.429723
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-20 16:41:05.947150
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import pytest

    try:
        import selinux
    except ImportError:
        pytest.skip('selinux unavailable')

    if not selinux.is_selinux_enabled():
        pytest.skip('selinux is not enabled')

    assert selinux_getenforcemode() == selinux.getenforcemode()



# Generated at 2022-06-20 16:41:14.851626
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = './test.txt'

    with open(filename, 'w') as file:
        file.write('content')

    rc, con = lgetfilecon_raw(filename)
    #if not rc == 0:
    #    print(rc)
    #else:
    #    print(con)
    assert con == b'unconfined_u:object_r:user_home_t:s0'
    os.remove(filename)

# Generated at 2022-06-20 16:41:16.836594
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, out = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(out, str)
    assert out.strip() == 'refpolicy'


# Generated at 2022-06-20 16:41:18.796735
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-20 16:41:20.649931
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert [0, 1] == selinux_getenforcemode()



# Generated at 2022-06-20 16:41:22.541343
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert [0, 1] == selinux_getenforcemode()


# Generated at 2022-06-20 16:41:26.384672
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2), "unexpected enforcemode: {0}".format(enforcemode)


# Generated at 2022-06-20 16:41:29.122222
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, mode) = selinux_getenforcemode()
    assert rc == 0, 'unable to get enforce mode on this system.'
    assert mode == 0 or mode == 1 or mode == 2, 'unable to get enforce mode on this system.'



# Generated at 2022-06-20 16:41:33.051970
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    assert isinstance(rc, int)
    assert isinstance(con, str)


# Generated at 2022-06-20 16:41:52.185103
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    if isinstance(result[0], int):
        assert result[0] == 0
    else:
        assert result[0] >= 0
    assert result[1] == 'targeted'



# Generated at 2022-06-20 16:41:55.778253
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    return [rc, enforcemode.value]

# Generated at 2022-06-20 16:41:59.152262
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = '/tmp/TestFile'
    with open(filename, 'w') as test_fd:
        test_fd.write('the test file')
    filecon = lgetfilecon_raw(filename)[1]
    assert filecon == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-20 16:42:03.455485
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1] or selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-20 16:42:09.021703
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    from ansible_collections.ansible.community.plugins.module_utils.selinux import is_selinux_enabled

    if not is_selinux_enabled():
        raise ImportError('SELinux is not enabled')

    fd, path = tempfile.mkstemp()
    try:
        rc, con = lgetfilecon_raw(path)
        os.close(fd)
        assert rc == 0
        assert con is not None
    finally:
        os.remove(path)



# Generated at 2022-06-20 16:42:10.808838
# Unit test for function selinux_getenforcemode

# Generated at 2022-06-20 16:42:11.941674
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print(selinux_getenforcemode())


# Generated at 2022-06-20 16:42:13.737300
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0


# Generated at 2022-06-20 16:42:16.540097
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    if result[1] == 'targeted':
        assert result[0] == 0
    else:
        assert result[0] == 0
        raise AssertionError('selinux module broken')

# Generated at 2022-06-20 16:42:22.103072
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # selinux_getenforcemode should return tuple of length 2 - we ignore second return value as it is a mode code
    assert len(selinux_getenforcemode()) == 2


# Generated at 2022-06-20 16:43:05.244939
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, mode] = selinux_getenforcemode()
    if rc == 0 and mode == 1:
        return True
    return False

# Generated at 2022-06-20 16:43:14.063192
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.selinux import selinux_getenforcemode
    if selinux_getenforcemode()[0] >= 0:
        assert(
            selinux_getenforcemode()[1] in [0, 1]
        ), 'SELinux enforce mode must be 0 or 1'
    else:
        raise OSError('SELinux get enforce mode failed')


# Generated at 2022-06-20 16:43:18.351014
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, enforcemode = selinux_getenforcemode()
        return 'rc: {0} enforcemode: {1}'.format(rc, enforcemode)
    except Exception as e:
        return 'selinux_getenforcemode exception {0}'.format(e)



# Generated at 2022-06-20 16:43:26.143771
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_runtime_t:s0-s0:c0.c1023'
    assert lgetfilecon_raw('/etc/passwd')[1] != 'system_u:object_r:etc_runtime_t:s0-s0:c0.c10'
    assert lgetfilecon_raw('/etc/passwd')[1] != 'system_u:object_r:etc_runtime_t:s0-s0:c0.c1024'


# Generated at 2022-06-20 16:43:30.645010
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("enforce mode:", rc, enforcemode)



# Generated at 2022-06-20 16:43:35.081188
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert rc == 0
    assert con.startswith('system_u:object_r:root_t:s0')



# Generated at 2022-06-20 16:43:42.467896
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create temporary directory in /tmp
    tdir = '/tmp/ansible_test_dir'
    os.mkdir(tdir, 0o755)

    # Set the context of the temporary directory
    rc, con = matchpathcon(tdir, 0)
    if rc != 0:
        raise ValueError('failed to matchpathcon on "{0}": {1}'.format(tdir, con))

    rc = lsetfilecon(tdir, con)
    if rc != 0:
        raise ValueError('failed to setfilecon on "{0}": {1}'.format(tdir, con))

    rc, new_con = lgetfilecon_raw(tdir)
    if rc != 0:
        raise ValueError('failed to getfilecon on "{0}": {1}'.format(tdir, con))

    #

# Generated at 2022-06-20 16:43:46.142548
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test for a non-zero return code for success
    assert selinux_getenforcemode()[0] == 0



# Generated at 2022-06-20 16:43:52.888621
# Unit test for function matchpathcon
def test_matchpathcon():
    if os.path.exists("/etc/selinux/config") and os.path.exists("/usr/sbin/getenforce"):
        rc, mode = selinux_getenforcemode()

        if rc == -1:
            raise OSError("selinux_getenforcemode failed: {0}".format(mode))
        else:
            mode = mode & 3  # only keep the lower 2 bits

        if mode == 0:
            raise OSError("selinux_getenforcemode failed: SELinux is disabled!")
        else:
            rc, valid_context = matchpathcon("/etc/selinux/config", mode)
            if rc == -1:
                raise OSError("matchpathcon failed: {0}".format(valid_context))

# Generated at 2022-06-20 16:44:01.205831
# Unit test for function matchpathcon
def test_matchpathcon():
    # test for pathname not absolute
    path = 'not_absolute/pathname'
    mode = 0
    result, con = matchpathcon(path, mode)
    assert result == -1
    assert con == 'system_u:object_r:s0'

    # test for pathname absolute
    path = os.path.dirname(os.path.abspath(__file__)) + '/__init__.py'
    mode = 0
    result, con = matchpathcon(path, mode)
    assert result == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-20 16:45:40.897089
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = "/tmp/selinux/selinux-python-test"
    test_src_path = "/selinux/selinux-python-test"
    test_con = "system_u:object_r:selinux_python_test_t:s0"

    with open(test_path, 'w') as f:
        f.write("test\n")

    rc, current_con = lgetfilecon_raw(test_src_path)
    assert rc == 0, "failed to get context of file %s" % test_src_path
    assert current_con == test_con, "current context %s != expected context %s" % (current_con, test_con)


# Generated at 2022-06-20 16:45:50.352831
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import sys
    import os
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins
    builtins.__dict__['_test_selinux_getenforcemode'] = 0
    import selinux
    def test_getenforcemode():
        selinux._test_selinux_getenforcemode = 2
        pass
    test_getenforcemode()
    assert selinux._test_selinux_getenforcemode == 2
    os.remove(__file__)


# Generated at 2022-06-20 16:45:52.825110
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    print(policytype)


# Generated at 2022-06-20 16:46:03.652580
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.common.text.converters import to_bytes
    import pwd
    import grp
    import stat
    test_uid = pwd.getpwnam('test').pw_uid
    test_gid = grp.getgrnam('test').gr_gid
    test_path = to_bytes('/selinux/test')

    os.chdir('/')
    os.chroot('/')
    os.mkdir('selinux', 0o755)
    os.chown('selinux', test_uid, test_gid)

    os.mkdir('selinux/test', 0o644)
    os.chown('selinux/test', test_uid, test_gid)
