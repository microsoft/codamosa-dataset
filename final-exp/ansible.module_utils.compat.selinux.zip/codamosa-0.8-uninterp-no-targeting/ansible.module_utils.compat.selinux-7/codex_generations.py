

# Generated at 2022-06-20 16:36:01.843422
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert isinstance(_selinux_lib, CDLL)
    path = '/usr/bin/runcon'
    rc, con = lgetfilecon_raw(path)
    assert con
    print('{0} context: {1}'.format(path, con))

# Generated at 2022-06-20 16:36:02.935478
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0


# Generated at 2022-06-20 16:36:05.076188
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Testing on Ubuntu Linux where policy will be "targeted"
    assert selinux_getpolicytype()[1] == "targeted"



# Generated at 2022-06-20 16:36:07.755830
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[0] == 0

# Generated at 2022-06-20 16:36:14.684502
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test lgetfilecon_raw function."""
    path = "/"
    (rc, con) = lgetfilecon_raw(path)
    if con is not None:
        if rc == 0:
            print("Path " + path + " has context "+ con)
        else:
            print("Error: Path " + path + "  call failed")
    else:
        print("Error: Path " + path + "  call failed")


# Generated at 2022-06-20 16:36:15.998998
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-20 16:36:20.441571
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert rc == 0
    # FIXME: this assertion is not useful for testing (or anywhere else)
    # assert isinstance(con, str)
    assert con == "unconfined_u:object_r:root_t:s0"



# Generated at 2022-06-20 16:36:23.185054
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 1
    assert enforcemode == 0 or enforcemode == 1



# Generated at 2022-06-20 16:36:28.446941
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import os
    enforcemode = os.environ["ANSIBLE_SELINUX_ENFORCE_MODE"]
    try:
        os.environ["ANSIBLE_SELINUX_ENFORCE_MODE"] = "1"
        assert selinux_getenforcemode()[1] == 1
        os.environ["ANSIBLE_SELINUX_ENFORCE_MODE"] = "0"
        assert selinux_getenforcemode()[1] == 0
    finally:
        os.environ["ANSIBLE_SELINUX_ENFORCE_MODE"] = enforcemode


# Generated at 2022-06-20 16:36:35.972990
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/etc/passwd", 1)
    assert rc == 0
    assert con == "usr_t"
    rc, con = matchpathcon("/etc", 1)
    assert rc == 0
    assert con == "etc_t"
    rc, con = matchpathcon("/selinux", 1)
    assert rc == 0
    assert con == "selinux_var_t"
    rc, con = matchpathcon("/tmp", 1)
    assert rc == 0
    assert con == "tmp_t"
    rc, con = matchpathcon("/root", 1)
    assert rc == 0
    assert con == "root_t"
    rc, con = matchpathcon("/home", 1)
    assert rc == 0
    assert con == "home_root_t"
    rc

# Generated at 2022-06-20 16:36:42.320644
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert enforcemode in [0, 1, 2], "unexpected enforcment mode: [0, 1, 2] expected"


# Generated at 2022-06-20 16:36:44.754583
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/usr')
    assert rc == 0
    assert con == 'system_u:object_r:usr_t'

# Generated at 2022-06-20 16:36:46.596198
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, value] = selinux_getpolicytype()
    assert rc == 0
    assert value == 'targeted'

# Generated at 2022-06-20 16:36:49.340847
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, out) = selinux_getenforcemode()
    if rc == 0 and out == 1:
        return rc
    else:
        return -1


# Generated at 2022-06-20 16:36:53.189504
# Unit test for function matchpathcon
def test_matchpathcon():
    tpath = '/var/lib/my-container/container.conf'
    tmode = 0
    rc, string_returned = matchpathcon(tpath, tmode)
    print(string_returned)
    assert rc == 0
    assert isinstance(string_returned, str)


# Generated at 2022-06-20 16:36:56.743983
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policytype) = selinux_getpolicytype()
    assert rc == 0, "selinux_getpolicytype call failed"
    assert policytype == "MLS", "selinux_getpolicytype returned policytype with value {0} instead of MLS ".format(policytype)

# Generated at 2022-06-20 16:37:00.727824
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/test"
    mode = os.stat(path).st_mode
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    print(rc, to_native(con.value))


# Generated at 2022-06-20 16:37:02.317798
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-20 16:37:03.946542
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert isinstance(mode, int)



# Generated at 2022-06-20 16:37:09.915141
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw('/tmp', byref(con))
        if rc != 0:
            print('lgetfilecon_raw failed, rc=%d' % rc)
        else:
            print('lgetfilecon_raw succeeded, con=%s' % con)
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-20 16:37:17.752627
# Unit test for function matchpathcon
def test_matchpathcon():
    fd, path = tempfile.mkstemp()
    status, context = matchpathcon(path, 0)
    assert status == 0

# Generated at 2022-06-20 16:37:20.114021
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(con, str)



# Generated at 2022-06-20 16:37:24.057361
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    test_input = [i for i in range(0, 4)]
    return_val = [selinux_getenforcemode()]
    assert return_val == test_input, "Expected " + str(test_input) + ", got: " + str(return_val)

# Generated at 2022-06-20 16:37:33.400701
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def compare_to_command_output(path, command):
        '''Compare the result of lgetfilecon_raw to the result of the
        command `command` run on path `path`.'''
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == command(path).rstrip()

    def ls_Z(path):
        '''Implementation of `ls -Z`.'''
        import subprocess
        command = ['ls', '-Z', path]
        return to_native(subprocess.check_output(command))

    def getfattr(path):
        '''Implementation of `getfattr --absolute-names --only-values -n security.selinux`.'''
        import subprocess

# Generated at 2022-06-20 16:37:36.748767
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret, con = lgetfilecon_raw(None)
    if ret == 0:
        print('File context is:', con)
    else:
        print('Got error code', ret)



# Generated at 2022-06-20 16:37:38.870166
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    info, policytype = selinux_getpolicytype()
    assert policytype == 'targeted'
    assert info == 0



# Generated at 2022-06-20 16:37:43.721424
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    efm = selinux_getenforcemode()
    assert (len(efm) == 2)
    assert (efm[0] == 0 or efm[0] == 1 or efm[0] == 2)
    assert (efm[1] in [0, 1, 2])



# Generated at 2022-06-20 16:37:46.387129
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, mypolicytype = selinux_getpolicytype()
    assert rc == 0, 'selinux_getpolicytype call failed'

# Generated at 2022-06-20 16:37:50.422579
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = 0
    [rc, con] = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

# Generated at 2022-06-20 16:37:53.098153
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/proc/self/', 0)
    assert result[0] == 0
    assert result[1] == 'system_u:system_r:proc_t:s0'

# Generated at 2022-06-20 16:38:00.445786
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    testfile_context = 'system_u:object_r:bin_t:s0'
    testfile_name = '/bin/ls'

    (rc, output) = lgetfilecon_raw(testfile_name)
    assert rc == 0
    assert testfile_context == output


# Generated at 2022-06-20 16:38:03.231090
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test for function to get selinux enforce mode
    # This function needs to run only if selinux is installed
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode in [0, 1, 2]
    assert rc == 0



# Generated at 2022-06-20 16:38:11.425882
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        result = selinux_getenforcemode()
    except OSError as e:
        if e.errno != errno.EOPNOTSUPP:
            raise
        result = (1, None)

    # NB: if selinux is not enabled the result code will be an error
    if is_selinux_enabled():
        assert result[0] == 0
    else:
        assert result[0] != 0
        return

    enforcemode = result[1]
    assert enforcemode in (-1, 0, 1)



# Generated at 2022-06-20 16:38:14.727363
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc != 0:
        raise OSError(rc, 'selinux_getenforcemode failed.')
    print('enforcemode = {0}'.format(enforcemode))



# Generated at 2022-06-20 16:38:16.215180
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    system = selinux_getenforcemode()
    assert system[0] == 0


# Generated at 2022-06-20 16:38:18.994673
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, context) = lgetfilecon_raw("/usr/bin/python")
    print("context = {0}".format(context))
    assert rc == 0

# Generated at 2022-06-20 16:38:26.107605
# Unit test for function matchpathcon
def test_matchpathcon():
    import sys
    import os
    import pytest
    import tempfile

    def _setup():
        file_name = tempfile.mkstemp()[1]
        with open(file_name, 'w') as fp:
            fp.write('')
        return file_name

    def _teardown(file_name):
        os.unlink(file_name)

    # Running the matchpathcon will cause the matchpathcon
    # function to have a return code of -1.  This is expected
    # since the file does not exist.  It's still called since
    # the unit test itself is testing the wrapper function itself
    file_name = _setup()
    rc, con = matchpathcon('/tmp/does_not_exist', os.R_OK)
    assert rc == -1
    _teard

# Generated at 2022-06-20 16:38:33.303151
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, contxt) = lgetfilecon_raw("/etc")
    if rc == -1:
        raise OSError("SELinux: Could not find the context of /etc")

    if "system_u:object_r:etc_t:" not in contxt:
        raise Exception("SELinux: Could not find context for /etc")



# Generated at 2022-06-20 16:38:34.966862
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/test', 0) == [0, b'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-20 16:38:42.046588
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    if rc != 0:
        raise Exception('Unable to get selinux policy type: {0}'.format(rc))
    else:
        print('selinux policy type: {0}'.format(policy))


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:38:56.193372
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/www/html"
    mode = os.R_OK | os.X_OK | os.W_OK
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    print(rc)
    print(con.value)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:39:00.294367
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    path = u'/tmp/somefile'
    mode = 0
    rc, con = matchpathcon(path, mode)
    print("matchpathcon(path='{}', mode={}) => [rc={}, con='{}']".format(path, mode, rc, con))



# Generated at 2022-06-20 16:39:01.365530
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: implement or remove
    pass


# Generated at 2022-06-20 16:39:02.464391
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print(lgetfilecon_raw('/home'))


# Generated at 2022-06-20 16:39:14.288155
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux.selinux import matchpathcon
    from ansible.module_utils.selinux.secon import string_to_con
    from ansible.module_utils.selinux.secon import label_compare

    # for testing, matchpathcon should never return (1, None) as that would indicate a failure
    # instead, it should return (0, None) or (0, <context>) where context is either "?" or a valid context
    rc, con = matchpathcon("/tmp/foo", 0)
    assert rc == 0
    if con == "?":
        # this is always a selinux problem, not a scripting problem
        raise SystemError("unable to determine selinux context for \"/tmp/foo\"")


# Generated at 2022-06-20 16:39:25.088265
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    def validate_lgetfilecon_raw(path, expected_con):
        rc, con = lgetfilecon_raw(path)
        if rc != 0:
            raise Exception('lgetfilecon_raw({0!r}, ...) failed with rc {1}: {2}'.format(path, rc, con))
        if con != expected_con:
            raise Exception('lgetfilecon_raw({0!r}, ...) => {1!r} != {2!r}'.format(path, con, expected_con))

    validate_lgetfilecon_raw('/dev/full', 'system_u:object_r:device_t:s0')
    validate_lgetfilecon_raw('/dev/null', 'system_u:object_r:char_device_t:s0')

# Generated at 2022-06-20 16:39:31.524602
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import os.path
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, "conftest")
    open(test_file, 'a').close()

    (rc, con) = lgetfilecon_raw(test_file)

    assert (rc >= 0), "lgetfilecon_raw failed: rc=%d" % rc
    assert (con is not None), "lgetfilecon_raw failed: con is None"

    shutil.rmtree(tmpdir)


# Generated at 2022-06-20 16:39:33.897329
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policytype] = selinux_getpolicytype()
    assert rc == 0
    assert policytype in ['targeted', 'minimum', 'mls']

# Generated at 2022-06-20 16:39:35.244831
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0
    assert selinux_getpolicytype()[1] == "targeted"


# Generated at 2022-06-20 16:39:38.434530
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/fstab', 0)
    print('return code =', rc)
    print('context =', con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:39:59.874354
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Test for function selinux_getenforcemode
    """
    print("Test for function selinux_getenforcemode")
    rc, enforcemode = selinux_getenforcemode()
    if rc != 0:
        print("Error: " + str(enforcemode))
    else:
        if enforcemode == 1:
            print("Enabled")
        else:
            print("Disabled")


# Generated at 2022-06-20 16:40:08.639659
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def _check_output(rc, strvalue, expect_rc, expect_strvalue):
        assert rc == expect_rc, 'expected: {0}, got: {1}'.format(expect_rc, rc)
        assert strvalue == expect_strvalue, 'expected: {0}, got: {1}'.format(expect_strvalue, strvalue)

    test_file_path = '/etc/hosts'
    if os.path.exists(test_file_path):
        rc, strvalue = lgetfilecon_raw(test_file_path)
        _check_output(rc, strvalue, 0, 'system_u:object_r:etc_t:s0')
    else:
        _check_output(rc, strvalue, -1, '')

# Generated at 2022-06-20 16:40:12.106852
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/'
    test_rc, test_con = lgetfilecon_raw(test_path)
    if test_rc == 0:
        print("Test for function lgetfilecon_raw: PASSED")
    else:
        print("Test for function lgetfilecon_raw: FAILED")


# Generated at 2022-06-20 16:40:14.011529
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert isinstance(selinux_getpolicytype(), list)


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:40:20.946730
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Verify that lgetfilecon_raw returns a list.
    """
    result = lgetfilecon_raw("/etc/hosts")
    if not isinstance(result, list):
        raise AssertionError("Function 'lgetfilecon_raw' did not return a list. Type is {0}".format(type(result)))

# Generated at 2022-06-20 16:40:24.371971
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print("test_lgetfilecon_raw", end=': ')
    res = lgetfilecon_raw(b'/tmp/')
    if res[0] != 0:
        print(res[0])
    else:
        print(res[1])


# Generated at 2022-06-20 16:40:32.126421
# Unit test for function matchpathcon
def test_matchpathcon():
    """ See https://www.linuxquestions.org/questions/linux-security-4/selinux-what-does-libselinux-so-matchpathcon-return-code-2-mean-473066/
    """
    test_paths = [
        '/sys/kernel/debug/clk/clk_summary',
        '/sys/kernel/debug/clk/clk_summary_NOT-PRESENT',
        '/proc/20000/fd',
        '/proc/20000/fd/NOT-PRESENT',
        '/proc/20000/something_else',
        '/proc',
        '/proc/NOT-PRESENT',
        '/sys',
        '/sys/NOT-PRESENT',
        '/etc',
        '/etc/NOT-PRESENT',
    ]

# Generated at 2022-06-20 16:40:35.135454
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r, con = lgetfilecon_raw('/etc/selinux/config')
    assert r == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-20 16:40:37.693084
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, stype = selinux_getpolicytype()

    if rc != 0:
        raise Exception('return code: {0}, value: {1}'.format(rc, stype))

    print(stype)


# Generated at 2022-06-20 16:40:41.907794
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/home')
    assert rc == 0
    assert isinstance(con, str)
    assert b'unconfined_u:object_r' in con
    assert con.split()[0] == b'system_u:object_r:user_home_dir_t:'

# Generated at 2022-06-20 16:41:24.306752
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():

    result = selinux_getenforcemode()
    assert result[0] >= 0, 'Error: selinux_getenforcemode failed with error code: {0} {1}'.format(result[0], result[1])
    assert result[1] in ['disabled', 'permissive', 'enforcing'], 'Error: selinux_getenforcemode returned unknown enforcement mode: {0}'.format(result[1])



# Generated at 2022-06-20 16:41:27.356618
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/selinux.log"
    mode = 0o777
    # Create temp directory
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:tmp_t:s0"

# Generated at 2022-06-20 16:41:31.261172
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/data/test/file.txt', os.R_OK) == [0, b'user_u:object_r:bin_t:s0']

# Generated at 2022-06-20 16:41:33.691572
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert len(res) == 2
    assert isinstance(res[0], int)
    assert res[0] == 0
    assert isinstance(res[1], str)
    assert res[1] == 'selinux'



# Generated at 2022-06-20 16:41:36.357982
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-20 16:41:41.443990
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    assert rc == 0
    assert enforcemode.value in [0, 1]

# Generated at 2022-06-20 16:41:50.150096
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def run_test(test_dir, ofile_name, expected_output):
        ofile = test_dir + '/' + ofile_name
        fd = os.open(ofile, os.O_RDONLY)
        rc, output = lgetfilecon_raw(fd)
        os.close(fd)
        if expected_output != output:
            raise AssertionError('expected {0}, got {1}'.format(output, expected_output))

    def cleanup(test_dir):
        for f in os.listdir(test_dir):
            os.remove(test_dir + '/' + f)
        os.rmdir(test_dir)

    test_dir = '/tmp/sysctl_test'

# Generated at 2022-06-20 16:41:52.186070
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('/root', 0)
    assert ret[0] == 0
    assert ret[1] == b'u:object_r:admin_home_t:s0'

# Generated at 2022-06-20 16:41:55.064437
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str')
        ),
    )

    (rc, con) = matchpathcon("/etc/shadow", 0)
    module.exit_json(rc=rc, con=con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:41:57.433345
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, value] = selinux_getpolicytype()
    assert rc == 0
    assert value is not None


# Generated at 2022-06-20 16:43:23.665606
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/selinux/targeted/contexts/files/file_contexts'
    mode = 0
    con_list = matchpathcon(path, mode)
    assert con_list[0] == 0
    assert con_list[1] == 'unconfined_u:object_r:etc_runtime_t:s0'

    # test for return codes
    bad_path = '/etc/selinux/targeted/contexts/files/file_contexts123'
    bad_mode = 123
    bad_con_list = matchpathcon(bad_path, mode)
    assert bad_con_list[0] == -1

    bad_con_list = matchpathcon(path, bad_mode)
    assert bad_con_list[0] == -1

    # test for Exceptions

# Generated at 2022-06-20 16:43:26.763895
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Verify the implementation defined function selinux_getenforcemode exists
    assert hasattr(_selinux_lib, 'selinux_getenforcemode'), 'selinux_getenforcemode not found'


# Generated at 2022-06-20 16:43:34.464788
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b"/etc/selinux/config"
    rc, security_context = lgetfilecon_raw(path)  # nosec
    assert rc == 0, 'lgetfilecon(%s) failed with rc=%d' % (path, rc)
    assert isinstance(security_context, str)


# Generated at 2022-06-20 16:43:35.666978
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    pass



# Generated at 2022-06-20 16:43:39.150840
# Unit test for function matchpathcon
def test_matchpathcon():
    # Path doesn't exist
    [rc, con] = matchpathcon(b'/noexistent', 0)
    if rc != -1:
        raise RuntimeError('matchpathcon returns {}'.format(rc))
    if con:
        raise RuntimeError('con does not return None')



# Generated at 2022-06-20 16:43:40.463123
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    print(rc, policy)



# Generated at 2022-06-20 16:43:44.177522
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policy] = selinux_getpolicytype()
    assert (rc == 0)


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:43:47.157785
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected_rc = 0
    expected_value = b"selinuxfs"

    test_rc, test_value = selinux_getpolicytype()

    assert test_rc == expected_rc
    assert test_value == expected_value


# Generated at 2022-06-20 16:43:48.432284
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/'
    assert len(lgetfilecon_raw(path)) == 2


# Generated at 2022-06-20 16:43:59.962523
# Unit test for function matchpathcon
def test_matchpathcon():
    if os.path.exists('/etc/selinux'):
        rc, con = selinux_getpolicytype()
        if rc < 0:
            print('Error: Failed to get selinux policy type.')
            return 1

        rc, context = matchpathcon('/usr/bin/oscap', 1)
        if rc < 0:
            print('Error: Failed to get default context for /usr/bin/oscap: %s' % context)
            return 1

        rc, oldcontext = lgetfilecon_raw('/usr/bin/oscap')
        if rc < 0:
            print('Error: Failed to get current context for /usr/bin/oscap')
            return 1

        print('Policy type is: %s' % con)