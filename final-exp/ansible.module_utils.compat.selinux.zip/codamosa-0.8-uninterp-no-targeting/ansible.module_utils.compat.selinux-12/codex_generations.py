

# Generated at 2022-06-20 16:35:59.519475
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc >= 0, to_native(os.strerror(rc))
    assert enforcemode in [0, 1, 2], 'Invalid enforcemode: {}'.format(enforcemode)


# Generated at 2022-06-20 16:36:02.644669
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    This function will throw if selinux is disabled.
    """
    assert lgetfilecon_raw("/tmp")[0] == -1  # ENOENT
    assert lgetfilecon_raw("/proc/self/status")[0] == 0

# Generated at 2022-06-20 16:36:04.745038
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/home/travis/build/ansible/ansible")
    return con



# Generated at 2022-06-20 16:36:08.366729
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    assert type(enforcemode) is list
    assert len(enforcemode) == 2
    assert type(enforcemode[0]) is int
    assert type(enforcemode[1]) is int



# Generated at 2022-06-20 16:36:12.421302
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux.test_data import tests
    for test in tests:
        for path, expected_rc, expected_con_value in test:
            rc, con_value = matchpathcon(path, 0)
            if rc != expected_rc or con_value != expected_con_value:
                raise AssertionError('For path=%s expected rc=%s and con_value=%s, but got %s and %s' % (
                    path, expected_rc, expected_con_value, rc, con_value))

# Generated at 2022-06-20 16:36:18.420255
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import sys
    # Execute matchpathcon with sample path name
    rc, con = matchpathcon("/etc/hosts", os.R_OK)
    # Test if rc is less than zero, which indicates failure
    if rc < 0:
        sys.exit("matchpathcon failed")
    # Test if the context is valid
    if con is None:
        sys.exit("context is not valid")


# Generated at 2022-06-20 16:36:19.659071
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-20 16:36:21.274629
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    a,b=selinux_getenforcemode()
    print(a,b)


# Generated at 2022-06-20 16:36:23.523687
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1


# Generated at 2022-06-20 16:36:32.208068
# Unit test for function matchpathcon

# Generated at 2022-06-20 16:36:38.470219
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    path = os.path.abspath("/")
    con = lgetfilecon_raw(path)[1]
    assert con


# Generated at 2022-06-20 16:36:43.687017
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if 'selinux_getenforcemode' not in dir():
        raise ImportError('skipping selinux_getenforcemode test, function not found')

    ret, enforcemode = selinux_getenforcemode()

    if ret < 0:
        raise OSError('selinux_getenforcemode return {0}: {1}'.format(ret, os.strerror(abs(ret))))

    print('enforcemode: {0}'.format(enforcemode))



# Generated at 2022-06-20 16:36:47.934360
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # unit tests depend on fakeselinux
    rc = selinux_getpolicytype()
    assert rc[0] == 0
    assert rc[1] == 'targeted'
    rc = selinux_getpolicytype()
    assert rc[0] == 0
    assert rc[1] == 'targeted'

# Generated at 2022-06-20 16:36:53.030897
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create a file to match against
    os.umask(0o0022)
    open('/tmp/matchpathcon', 'w').close()
    assert matchpathcon('/tmp/matchpathcon', 0o755) == [0, 'system_u:object_r:tmp_t:s0']
    os.unlink('/tmp/matchpathcon')



# Generated at 2022-06-20 16:36:58.948707
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/', 0)
    assert rc == 0
    assert con == '/etc(/.*)? system_u:object_r:etc_t'

    rc, con = matchpathcon('/etc/shadow', 0o400)
    assert rc == 0
    assert con == '/etc/shadow system_u:object_r:shadow_t'

    rc, con = matchpathcon('/etc/shadow-', 0o400)
    assert rc == -2
    assert con == ''

    rc, con = matchpathcon('/etc/motd', 0o777)
    assert rc == 0
    assert con == '/etc/motd system_u:object_r:motd_file_t'

    # Test in sparse mode

# Generated at 2022-06-20 16:37:01.667176
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if selinux_getenforcemode()[0] < 0:
        raise Exception("Error while executing selinux_getenforcemode: %s" %
                        os.strerror(get_errno()))



# Generated at 2022-06-20 16:37:06.766359
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import os
    from ansible_collections.os.linux.tests.unit.modules.backports.selinux_support import selinux_getpolicytype as selinuxtype
    rc, con = selinuxtype()
    assert rc == 0
    assert con == os.getenv("SELINUXTYPE")

# Generated at 2022-06-20 16:37:09.313840
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/etc')
    assert not rc
    assert con.startswith('system_u:object_r:etc_t:s0')


# Generated at 2022-06-20 16:37:11.087882
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, result) = selinux_getenforcemode()
    assert rc == 0
    assert result in [0, 1]


# Generated at 2022-06-20 16:37:22.094585
# Unit test for function matchpathcon
def test_matchpathcon():
    import selinux

    ret, con = selinux.matchpathcon("/foo", 0)
    assert ret == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'

    ret, con = selinux.matchpathcon("/foo", os.R_OK)
    assert ret == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'

    ret, con = selinux.matchpathcon("/foo", os.W_OK)
    assert ret == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'

    ret, con = selinux.matchpathcon("/foo", os.X_OK)
    assert ret == 0

# Generated at 2022-06-20 16:37:26.633131
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1


# Generated at 2022-06-20 16:37:31.272034
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    if rc >= 0:
        if enforcemode.value in (0, 1):
            print("Enforcemode OK - value = %d" % (enforcemode.value))
            return enforcemode.value
    print("FAIL")
    return -1


# Generated at 2022-06-20 16:37:38.177757
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    def unit_test(test_mode_value):
        enforcemode = c_int()
        ensure_mode = c_int(test_mode_value)
        rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
        assert rc == 0
        assert enforcemode.value == ensure_mode.value

    unit_test(1)
    unit_test(0)
    unit_test(0)



# Generated at 2022-06-20 16:37:45.780558
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text
    fd, test_file = tempfile.mkstemp()
    os.close(fd)
    try:
        os.chmod(test_file, 0o700)
        rc, con = matchpathcon(test_file, os.F_OK)
        assert rc == 0 and con == 'unconfined_u:object_r:user_home_t:s0'
    finally:
        os.unlink(test_file)

# Generated at 2022-06-20 16:37:50.292833
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''unit test for selinux_getenforcemode'''
    [rc, enforce] = selinux_getenforcemode()
    if rc != 0:
        raise OSError('selinux_getenforcemode failed, return code: %d' % rc)



# Generated at 2022-06-20 16:37:53.297251
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    a, b = selinux_getenforcemode()
    if a == 0:
        print("Mode of SELinux is :",b)
    else:
        print("SELinux is not enabled")


# Generated at 2022-06-20 16:38:00.164003
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''Validate that selinux_getenforcemode works as expected'''
    import sys
    import os

    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args, H
    from ansible_collections.notstdlib.moveitallout.plugins.modules import selinux_getenforcemode as selinux_getenforcemode_
    # on python2, mock_open returns an open file obj, so we need to override all read/write/readline, thus
    # implementing the interface of a fileobj, since fileobj.tell() is called
    if sys.version_info[0] == 2:
        from StringIO import StringIO


# Generated at 2022-06-20 16:38:02.515291
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc >= 0
    assert isinstance(con, str)
    assert con
    assert con in ('targeted', 'mls')



# Generated at 2022-06-20 16:38:04.605448
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, poltype) = selinux_getpolicytype()
    assert rc == 0
    assert poltype == 'targeted'



# Generated at 2022-06-20 16:38:13.444428
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = b"/usr/bin/python3"
    test_output = lgetfilecon_raw(test_path)
    if os.path.isfile(test_path):
        # only if python3 is installed
        assert test_output[0] == 0
        assert test_output[1] == "system_u:object_r:bin_t:s0"
    else:
        assert test_output[0] == -1
    test_path = b"foobar"
    test_output = lgetfilecon_raw(test_path)
    assert test_output[0] == -1
    assert test_output[1] is None



# Generated at 2022-06-20 16:38:26.172011
# Unit test for function matchpathcon
def test_matchpathcon():
    # Invoke matchpathcon function with a valid path.
    # Return code should be 0.
    # Return value should be a string.
    rc, value = matchpathcon("/var/log/boot.log", 0)
    assert rc == 0
    assert isinstance(value, str)
    print("matchpathcon() with valid path returned: " + value)

    # Invoke matchpathcon function with an invalid path.
    # Return code should be -1.
    # Return value should be an empty string.
    rc, value = matchpathcon("/var/log/invalid", 0)
    assert rc == -1
    assert value == ""


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:38:29.547165
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-20 16:38:33.944459
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/passwd'
    mode = 0

    [rc, con] = matchpathcon(path, mode)
    print(rc, con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:38:35.143791
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0



# Generated at 2022-06-20 16:38:46.167681
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for invalid path
    invalid_path = "/foo/bar"
    expected_rc = 1
    expected_con = ''
    rc, con = matchpathcon(invalid_path, 0)
    if rc != expected_rc:
        raise AssertionError("RC for invalid path is incorrect", "Expected '%s' Received '%s'" % (expected_rc, rc))

    if con != expected_con:
        raise AssertionError("CON for invalid path is incorrect", "Expected '%s' Received '%s'" % (expected_con, con))

    # Test for valid path
    valid_path = "/var/log"
    expected_rc = 0
    expected_con = "system_u:object_r:var_log_t:s0"

# Generated at 2022-06-20 16:38:48.721799
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy = selinux_getpolicytype()
    if not policy[0]:
        print(policy[1])



# Generated at 2022-06-20 16:38:50.998032
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None


# Generated at 2022-06-20 16:38:59.787461
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _mock_type = 'mock_policy_type'

    class mock_selinux_getpolicytype(object):
        def __init__(self, *args, **kwargs):
            self.con = c_char_p(_mock_type)

        def __call__(self, con):
            con[0] = self.con
            return 0

    try:
        _selinux_lib.selinux_getpolicytype = mock_selinux_getpolicytype()
        rc, policy_type = selinux_getpolicytype()
        assert policy_type == _mock_type
        assert rc == 0
    finally:
        del _selinux_lib.selinux_getpolicytype

# Generated at 2022-06-20 16:39:01.571303
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]


# Generated at 2022-06-20 16:39:07.157896
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/home', 0)
    assert rc == 0
    assert con == b'user_home_dir_t'

    rc, con = matchpathcon('/etc', 0)
    assert rc == 0
    assert con == b'system_etc_t'



# Generated at 2022-06-20 16:39:14.516644
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # On x86_64 self.selinux_lib.selinux_getpolicytype(byref(con)) returns 0 (success)
    rc, con = selinux_getpolicytype()
    assert rc == 0
    # On x86_64 value of con is b'file\x00\x00\x00\x00\x00'
    assert con == 'file'



# Generated at 2022-06-20 16:39:19.084025
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = 0
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 0 or enforcemode == 1

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-20 16:39:21.453778
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/home') == [0, b'system_u:object_r:user_home_dir_t:s0']



# Generated at 2022-06-20 16:39:25.944906
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test the function lgetfilecon_raw for failure or success.

    :return:
    """
    t = "/etc/hosts"
    rc, d = lgetfilecon_raw(t)
    if rc:
        print("Failed to get context")
        print(d)
    else:
        print("Success")

# Generated at 2022-06-20 16:39:27.652503
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-20 16:39:31.076321
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    result = selinux_getpolicytype()
    assert result[0] == 0


# Generated at 2022-06-20 16:39:34.599729
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    actual_result = selinux_getenforcemode()
    expected_result = [0, 1]
    assert actual_result == expected_result, "Expected {0}, got {1}".format(expected_result, actual_result)


# Generated at 2022-06-20 16:39:37.603962
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert isinstance(con, str)

# Generated at 2022-06-20 16:39:40.434957
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/var/log', 0)
    assert res == [0, 'system_u:object_r:var_log_t:s0']



# Generated at 2022-06-20 16:39:48.108058
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():

    # Unit test for function selinux_getenforcemode
    def test_selinux_getenforcemode():
        import selinux

        # Ensure that selinux is loaded and enabled
        assert selinux.is_selinux_enabled()
        assert selinux.selinux_getenforcemode()[0] == 0

        # Verify that a non-zero return means selinux is not enforcing
        selinux.security_setenforce(0)
        assert selinux.selinux_getenforcemode()[1] == 0
        selinux.security_setenforce(1)
        assert selinux.selinux_getenforcemode()[1] == 1


if __name__ == '__main__':
    test_selinux_getpolicytype()
    test_selinux_getenforcemode()

# Generated at 2022-06-20 16:39:52.642826
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type, rc = selinux_getpolicytype()
    if rc != 0:
        raise Exception('unable to selinux_getpolicytype')
    else:
        print('selinux policy type: {0}'.format(policy_type))


# Generated at 2022-06-20 16:39:58.239031
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # No selinux
    if selinux_getenforcemode()[0] == -1:
        assert True
    # Permissive mode
    elif selinux_getenforcemode()[1] == 0:
        assert True
    # Enforcing mode
    elif selinux_getenforcemode()[1] == 1:
        assert True
    else:
        assert False



# Generated at 2022-06-20 16:40:01.221466
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert isinstance(result, list) and len(result) == 2
    return result


# Generated at 2022-06-20 16:40:05.005726
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (ret, con) = selinux_getpolicytype()
    if ret < 0:
        print(('Error: Failed to get policytype.', ret))
        sys.exit(1)
    else:
        print(('Current policy', con))
    sys.exit(0)



# Generated at 2022-06-20 16:40:07.934888
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    result = lgetfilecon_raw(path=path)

    if result[0] == 0:
        assert result[1] is not None
        return True
    else:
        assert result[1] is None

# Generated at 2022-06-20 16:40:11.060902
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert len(selinux_getpolicytype()) == 2


# Generated at 2022-06-20 16:40:13.298254
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'unconfined_u:object_r:etc_t:s0'



# Generated at 2022-06-20 16:40:16.755705
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policy, str)
    assert len(policy) > 0



# Generated at 2022-06-20 16:40:27.136805
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/tmp/some_file'
    # mode = 0
    rc, con = matchpathcon(test_path, 0)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'

    # mode = 1
    rc, con = matchpathcon(test_path, 1)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'

    # mode = 2
    rc, con = matchpathcon(test_path, 2)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'

    # mode = 4
    rc, con = matchpathcon(test_path, 4)
    assert rc == 0

# Generated at 2022-06-20 16:40:29.896745
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/myfile', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-20 16:40:33.074811
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, info) = selinux_getenforcemode()
    assert isinstance(info, int)
    assert rc == 0



# Generated at 2022-06-20 16:40:35.837634
# Unit test for function matchpathcon
def test_matchpathcon():
    # path: the absolute path of a file or directory
    # mode: the mode of the file/directory
    # con: the context string associated with the file/directory
    # rc: the return value of matchpathcon. 0 if successfully returns the context.
    path = b'/'
    mode = 0
    rc, con = matchpathcon(path, mode)

    print('path = {0}, context = {1}, return value = {2}'.format(path, con, rc))
    assert rc == 0



# Generated at 2022-06-20 16:40:39.724499
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # testing selinux_getenforcemode.
    # TODO: implement real unit-test
    rc, out = selinux_getenforcemode()

    if not rc:
        return [False, "Error output: " + out]

    return [True, "Success"]



# Generated at 2022-06-20 16:40:41.588884
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, con] = selinux_getenforcemode()
    assert rc == 1
    assert con == -1


# Generated at 2022-06-20 16:40:50.166560
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create a test directory
    os.mkdir('/tmp/test_matchpathcon')
    assert os.path.isdir('/tmp/test_matchpathcon')
    rc, con = matchpathcon('/tmp/test_matchpathcon', 0)
    assert rc == 0
    assert con.startswith('system_u:object_r:tmp_t')
    os.rmdir('/tmp/test_matchpathcon')
    assert not os.path.isdir('/tmp/test_matchpathcon')


if __name__ == '__main__':
    test_matchpathcon()
    print('Selinfux module loaded')

# Generated at 2022-06-20 16:40:54.960281
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Unit test for function selinux_getpolicytype

    """
    rc, con = selinux_getpolicytype()
    if rc < 0:
        raise RuntimeError('unable to get policy type')

    print('policy type: {0}'.format(con))



# Generated at 2022-06-20 16:40:56.658516
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    val = selinux_getenforcemode()
    assert type(val) == list


# Generated at 2022-06-20 16:41:01.610103
# Unit test for function matchpathcon
def test_matchpathcon():
    _selinux_lib.matchpathcon.restype = c_char_p

    con = _selinux_lib.matchpathcon('/bin/ls', 0)
    assert con
    con = _selinux_lib.matchpathcon('/usr/bin/ls', 0)
    assert con
    con = _selinux_lib.matchpathcon('notrealpath', 0)
    assert con is None



# Generated at 2022-06-20 16:41:03.874187
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print(selinux_getenforcemode())

# Generated at 2022-06-20 16:41:12.619052
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fname = 'testfile'
    with open(fname, 'w') as f:
        f.write('hello world')

    try:
        rc, con = lgetfilecon_raw(fname)
        print('lgetfilecon_raw({0}) returned [{1}, {2}]'.format(fname, rc, con))
    finally:
        os.remove(fname)



# Generated at 2022-06-20 16:41:20.448889
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw('/usr')
    assert rc == 0
    assert con == 'system_u:object_r:usr_t:s0'

# Generated at 2022-06-20 16:41:26.529282
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # init function selinux_getpolicytype
    rc, policytype = selinux_getpolicytype()
    if rc == 0:
        # zero return code for success and will return policytype
        print(policytype)
    else: 
        # non zero return code for failure and return error number and error message
        print(rc)
        # get error message
        errmsg = os.strerror(rc)
        print(errmsg)

# Generated at 2022-06-20 16:41:28.711157
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_rc, context = lgetfilecon_raw('/')
    assert test_rc == 0
    assert context == 'unconfined_u:object_r:root_t:s0'

# Generated at 2022-06-20 16:41:30.939002
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path="/etc/system-fips")[1] == "system_u:object_r:fips_immutable_t:s0"


# Generated at 2022-06-20 16:41:37.631383
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux.selinux import matchpathcon
    import os
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()
    tmppath = os.path.join(tmpdir, "test")
    with open(tmppath, "w+") as f:
        print("test", file=f)

    rc, con = matchpathcon(tmpdir, 0)
    assert rc == 0
    assert con == "system_u:object_r:tmp_t:s0"

    rc, con = matchpathcon(tmppath, 0)
    assert rc == 0
    assert con == "system_u:object_r:tmp_t:s0"

    rc, con = matchpathcon(tmpdir, os.F_OK)
    assert rc

# Generated at 2022-06-20 16:41:38.448469
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] >= 0



# Generated at 2022-06-20 16:41:45.555061
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import unittest
    # Test failure case
    class Test_selinux_getpolicytype(unittest.TestCase):
        def test_selinux_getpolicytype(self):
            self.assertEqual(selinux_getpolicytype()[0], 0, "return code should not be 0")
    # Run test case
    unittest.main()


# Generated at 2022-06-20 16:41:49.042805
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon("/tmp", os.R_OK)
    if ret[0] != -1:
        return True
    else:
        return False

# Generated at 2022-06-20 16:42:00.036799
# Unit test for function matchpathcon
def test_matchpathcon():
    # Function matchpathcon: test case 1
    if 1:
        path = "/sys/fs/cgroup/cpu/user.slice/user-1000.slice/session-1.scope"
        mode = os.stat(path).st_mode & 0o777
        rc, result = matchpathcon(path, mode)
        print('rc = ', rc)
        print('result = ', result)
        assert rc == 0
        assert result == 'system_u:object_r:cgroup_session_slice_t:s0'

    # Function matchpathcon: test case 2
    if 1:
        path = "/sys/fs/cgroup/cpu,cpuacct/user.slice/user-1000.slice/session-1.scope"
        mode = os.stat(path).st_mode & 0o777

# Generated at 2022-06-20 16:42:07.929925
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b"/etc/fstab")
    if rc < 0:
        if get_errno() == 2:
            print("selinux is not enabled")
        else:
            print(con)
            sys.exit(1)
    else:
        print(con)
        sys.exit(0)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:42:21.458471
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, value] = selinux_getenforcemode()
    assert isinstance(value, int)
    assert value in (0, 1)



# Generated at 2022-06-20 16:42:26.429910
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = "../test/testdata/ansible/enforcemode"
    (rc, con_value) = matchpathcon(test_path, os.R_OK)
    assert rc == 0
    assert con_value == b"system_u:object_r:bin_t:s0"
    return 0



# Generated at 2022-06-20 16:42:30.948552
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    got = selinux_getenforcemode()
    assert(0 <= got[0] < 2)
    assert(0 <= got[1] < 4)
    assert(isinstance(got[0], int))
    assert(isinstance(got[1], int))


# Generated at 2022-06-20 16:42:32.575459
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, value = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(value, str)



# Generated at 2022-06-20 16:42:34.991682
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("rc: %d enforcemode: %d" % (rc, enforcemode))



# Generated at 2022-06-20 16:42:44.043537
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Workaround for no pytest in core
    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    tmppath = os.path.join(tmpdir, 'testfile')
    with open(tmppath, 'w'):
        pass
    rc, fcon = lgetfilecon_raw(tmppath)
    assert rc == 0
    assert fcon is not None
    shutil.rmtree(tmpdir)



# Generated at 2022-06-20 16:42:51.238308
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/usr/lib64') == [0, 'system_u:object_r:usr_t:s0']



# Generated at 2022-06-20 16:42:55.214434
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import selinux
    retcode, con = lgetfilecon_raw('/')
    assert retcode == 0
    assert isinstance(con, str)
    print("lgetfilecon_raw returned: {0}".format(con))


# Generated at 2022-06-20 16:43:01.593383
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0, "selinux_getenforcemode() failed with rc: {0}".format(rc)
    assert enforcemode == 1 or enforcemode == 0, "Returned enforcemode is invalid."



# Generated at 2022-06-20 16:43:04.360812
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    return [rc, enforcemode]

# Generated at 2022-06-20 16:43:29.085189
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Running matchpathcon tests...")
    rc, con = matchpathcon('/', os.R_OK)
    assert rc == 0
    print("\tTest 1/3 passed...")
    rc, con = matchpathcon('/', os.R_OK | os.X_OK)
    assert rc == 0
    print("\tTest 2/3 passed...")
    rc, con = matchpathcon('/', os.R_OK | os.W_OK)
    assert rc != 0
    print("\tTest 3/3 passed...")
    print("All matchpathcon tests passed.")

# Generated at 2022-06-20 16:43:34.777070
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw('/home/ansible/.bashrc')
    assert rc == 0
    assert con is not None
    assert "{0}".format(con).startswith("unconfined_u:object_r:home_file_t:s0")

# Generated at 2022-06-20 16:43:42.348408
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert mode in (0, 1, 2), "Unsupported mode"


if __name__ == '__main__':
    # test_selinux_getenforcemode()
    rc, mode = selinux_getenforcemode()
    if mode != 0:
        # Kernel is enforcing SELinux policy
        rc, policy_type = selinux_getpolicytype()
        if rc == 0 and policy_type == 'targeted':
            # The path has been designated for this module
            # Attempt to retrieve file context
            rc, con = lgetfilecon_raw('/var/log/cloud-init.log')
            if rc == 0:
                # Success
                print('/var/log/cloud-init.log SELinux context: %s' % con)


# Generated at 2022-06-20 16:43:50.985563
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil

    test_files = ['/var/message', '/etc/selinux/targeted/contexts/files/file_contexts', '/etc/passwd']
    failed_files = []
    for test_file in test_files:
        try:
            rc, con = lgetfilecon_raw(test_file)
        except:
            failed_files.append(test_file)
            continue
        if rc != 0:
            failed_files.append(test_file)
            continue
        try:
            rc, _ = lgetfilecon_raw('/bogus/bogus')
            if rc == 0:
                failed_files.append(test_file)
        except:
            failed_files.append(test_file)
            continue


# Generated at 2022-06-20 16:44:00.260378
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.selinux import matchpathcon

    # Test matchpathcon for file
    path = to_text('/usr/bin/python')
    mode = 0
    result, con = matchpathcon(path, mode)

    # Test matchpathcon for directory
    path = to_text('/usr/bin')
    mode = 1
    result, con = matchpathcon(path, mode)

    # Test matchpathcon for symlink file
    path = to_text('/lib64/libc.so.6')
    mode = 0
    result, con = matchpathcon(path, mode)

    # Test matchpathcon for symlink directory
    path = to_text('/lib64')

# Generated at 2022-06-20 16:44:12.232001
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import sys
    import tempfile

    # On some OSes, matchpathcon doesn't like a relative path, so we
    # make a temporary dir, cd into it, and create a relative path from there.
    curdir = os.getcwd()

    d = tempfile.mkdtemp()
    os.chdir(d)

# Generated at 2022-06-20 16:44:14.438956
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, strvalue = selinux_getpolicytype()
    assert rc == 0
    assert strvalue

# Generated at 2022-06-20 16:44:16.358227
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()[1]
    assert enforcemode in (-1, 0, 1)



# Generated at 2022-06-20 16:44:21.409696
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os.path

    for path in ('/etc/passwd', '/etc', '/', 'not_there'):
        rc, con = lgetfilecon_raw(path)

        # This is a cheat because errno values aren't portable.
        # We want to be sure that if errno has been set that it's
        # the value we expect.
        assert rc
        if rc < 0 and rc != -2:
            raise OSError(rc, os.strerror(rc))

        if os.path.exists(path):
            assert con



# Generated at 2022-06-20 16:44:25.066574
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/tmp/abc', 0)
    if rc >= 0:
        print(con)
    else:
        print('no context')


# Generated at 2022-06-20 16:45:16.226235
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Test lgetfilecon_raw function
    '''
    __system_context = "unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023"

    try:
        rc, context = lgetfilecon_raw('/sys')
        assert rc >= 0  # rc < 0 on error
        assert context == __system_context
    except NotImplementedError:
        assert False


# Generated at 2022-06-20 16:45:20.252614
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)



# Generated at 2022-06-20 16:45:23.625564
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # We only have the '-1' and '1' cases, libselinux does not
    # expose a way to test for the 0 mode.
    if selinux_getenforcemode() == [-1, 1]:
        # success
        return True
    else:
        return False

# Generated at 2022-06-20 16:45:25.845409
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    assert enforcemode[0] >= 0
    assert enforcemode[1] == 0 or enforcemode[1] == 1 or enforcemode[1] == 2


# Generated at 2022-06-20 16:45:29.925551
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    if rc == -1:
        print('selinux_getpolicytype failed')

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:45:37.236567
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    rc = res[0]
    policy_type = res[1]
    if rc != 0:
        raise Exception("selinux_getpolicytype returned non-zero ({}).".format(rc))
    print("selinux_getpolicytype returned {}".format(policy_type))

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:45:41.773993
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test 1: Test if the function selinux_getenforcemode returns the correct value or not
    assert(selinux_getenforcemode() == [0, 1])



# Generated at 2022-06-20 16:45:43.751466
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp')[0] == 0


# Generated at 2022-06-20 16:45:54.254958
# Unit test for function matchpathcon
def test_matchpathcon():
    '''Test that selinux.matchpathcon raises errors in the same way as libselinux'''
    import os
    import stat

    rc = 0
    mode = 0
    path = '/tmp/myfile'

    # delete file if exists
    try:
       os.remove(path)
    except OSError:
       pass

    # (1) test path does not exist
    try:
       assert matchpathcon(path, mode) == [0, 'system_u:object_r:unlabeled_t:s0']
       assert os.path.exists(path) is False
    except AssertionError:
       rc = 1
       raise

    # (2) test file exists, but is unreadable
    with open(path, 'a') as f:
        f.write('hi')