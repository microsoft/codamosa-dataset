

# Generated at 2022-06-20 16:36:09.155434
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Unit test for function matchpathcon")
    #Should return error if selinux is disabled

    if is_selinux_enabled() == 0:
        print("Selinux is disabled. Skipping test")
        return 1

    print("Testing function matchpathcon")
    ret = matchpathcon("/test/test", 0)
    if ret[0] != 0:
        print("matchpathcon failed. Error:" + str(ret[0]))
        return ret[0]

    print("matchpathcon returned success")
    return 0



# Generated at 2022-06-20 16:36:14.499632
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, policy = selinux_getpolicytype()
        print("selinux_getpolicytype() = {}, {}".format(rc, policy))
    except OSError as e:
        print("selinux_getpolicytype() raised OSError({}): {}".format(e.errno, to_native(e.strerror)), file=sys.stderr)



# Generated at 2022-06-20 16:36:17.496446
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    print("selinux_getenforcemode rc={0} enforcemode={1}".format(rc, enforcemode))


# Generated at 2022-06-20 16:36:19.920834
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforce = selinux_getenforcemode()
    assert rc >= 0
    assert isinstance(enforce, int)


# Generated at 2022-06-20 16:36:24.413309
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import ansible_collections.misc.not_a_real_collection.plugins.modules.selinux as selinux_module

    result = selinux_module.lgetfilecon_raw(b'/var/spool/cron/lastrun/opt')
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:var_spool_t:s0'


# Generated at 2022-06-20 16:36:28.445056
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        return

    [rc, con] = matchpathcon('/etc/resolv.conf', os.R_OK)
    if rc != 0:
        raise AssertionError('matchpathcon failed with code {0}'.format(rc))

    if con is None:
        raise AssertionError('matchpathcon returned null')


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:36:30.457505
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t:s0']
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-20 16:36:32.685823
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:rootfs:s0']


# Generated at 2022-06-20 16:36:34.566264
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Check if selinux_getenforcemode returns 'disabled'
    assert selinux_getenforcemode() == [0, 0]


# Generated at 2022-06-20 16:36:38.641354
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] == 0
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-20 16:36:48.510282
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        # This should succeed and return a valid string
        rc, policytype = selinux_getpolicytype()
    except NotImplementedError:
        # The function is not supported on this platform/selinux support
        policytype = None
    except OSError as e:
        # We should not get any other exceptions
        raise RuntimeError('unexpected OSError {0}: {1}'.format(e.args[0], e.args[1]))

    if policytype != 'targeted':
        raise RuntimeError('unexpected policy type: {0}'.format(policytype))


# Generated at 2022-06-20 16:36:51.672467
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        [rc, policytype] = selinux_getpolicytype()
    except OSError:
        [rc, policytype] = [-1, 'undefined']

    return [rc, policytype]



# Generated at 2022-06-20 16:36:54.329473
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policy_type, str)
    assert policy_type == 'targeted'



# Generated at 2022-06-20 16:36:55.874128
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    return rc


# Generated at 2022-06-20 16:37:04.517138
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, default_con) = lgetfilecon_raw("/tmp")
    assert rc == 0
    assert default_con == "system_u:object_r:tmp_t:s0"
    (rc, sys_con) = lgetfilecon_raw("/sys")
    assert rc == 0
    assert sys_con == "system_u:object_r:sysfs_t:s0"
    (rc, proc_con) = lgetfilecon_raw("/proc")
    assert rc == 0
    assert proc_con == "system_u:object_r:proc_t:s0"
    (rc, dev_con) = lgetfilecon_raw("/dev")
    assert rc == 0
    assert dev_con == "system_u:object_r:device_t:s0"

# Generated at 2022-06-20 16:37:09.793605
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # expects a two-item tuple with rc and result
    rc, enforcemode = selinux_getenforcemode()
    if rc < 0:
        raise
    else:
        print("enforcemode: %d, 0-PErmissive, 1-Enforcing" % enforcemode)
        if isinstance(enforcemode, int):
            pass
        else:
            raise TypeError("invalid enforcemode type")



# Generated at 2022-06-20 16:37:11.965629
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, mode) = selinux_getenforcemode()
    assert isinstance(rc, int)
    assert rc == 0
    assert isinstance(mode, int)
    assert mode in [0, 1, 2]



# Generated at 2022-06-20 16:37:13.647429
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    res = selinux_getpolicytype()
    assert res == [0, 'targeted'], 'res: {0}'.format(res)

# Generated at 2022-06-20 16:37:18.911720
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret, enforcemode = selinux_getenforcemode()
    if ret == 1:
        return_value = True
    else:
        return_value = False
    return [return_value, enforcemode]



# Generated at 2022-06-20 16:37:21.953557
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, con = selinux_getpolicytype()
        assert (rc == 0)
        assert (con != "")
    except NotImplementedError:
        pass

# Generated at 2022-06-20 16:37:29.044399
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ret_val = selinux_getenforcemode()
    assert isinstance(ret_val, list)
    assert isinstance(ret_val[0], int)
    assert isinstance(ret_val[1], int)



# Generated at 2022-06-20 16:37:31.956880
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()


# Generated at 2022-06-20 16:37:33.956394
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # set the module args
    test_args = {"path": "/etc/selinux/semanage.conf"}
    result = selinux_getenforcemode()
    assert result[0] == 0

# Generated at 2022-06-20 16:37:41.005435
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for the simplest possible case username=root and key=selinux
    result = matchpathcon(b'/', 32768)
    assert isinstance(result, list)
    if result[0] != 0:
        raise AssertionError("matchpathcon(): Failed to get the SELinux label, acl_type=root, err_return_code={0}, err_msg={1}".format(result[0], result[1]))



# Generated at 2022-06-20 16:37:43.614990
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print('Test selinux_getenforcemode')
    print('\texp_result: ', selinux_getenforcemode()[1])


# Generated at 2022-06-20 16:37:46.673671
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policytype) = selinux_getpolicytype()
    assert rc == 0
    assert policytype
    assert isinstance(policytype, str)



# Generated at 2022-06-20 16:37:51.543600
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, policy_type] = selinux_getpolicytype()
    if rc != 0:
        print('return value:', rc)
    else:
        print('Policy Type:', policy_type)


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:37:58.829843
# Unit test for function matchpathcon
def test_matchpathcon():
    # First test with a file that exists
    path = '/etc/hosts'
    mode = os.R_OK

    rc, con = matchpathcon(path, mode)

    assert(rc == 0)
    assert(con == 'system_u:object_r:etc_t')

    # Next test with a file that doesn't exist
    path = '/etc/hosts_does_not_exist'
    mode = os.R_OK

    rc, con = matchpathcon(path, mode)

    assert(rc == 0)
    assert(con == 'system_u:object_r:etc_t')

    # Next test with a file that does exist
    path = '/etc/hosts'
    mode = os.W_OK

    rc, con = matchpathcon(path, mode)

    assert(rc == 0)

# Generated at 2022-06-20 16:38:05.362445
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Check if we're running on an SELinux-enabled host
    if selinux_getenforcemode()[1] != 0:
        # If we are, check if we can read the SELinux type of this script
        try:
            con = lgetfilecon_raw(__file__)[1]
        except OSError as e:
            print(e)
            raise
        else:
            # Check if the SELinux context has a ':user:role:type:' component
            if ":" in con:
                print('SELinux context: %s' % con)
                print('SELinux policy type: %s' % selinux_getpolicytype()[1])

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:38:11.806841
# Unit test for function matchpathcon
def test_matchpathcon():
    # These are paths on my system with the correct context on them
    assert matchpathcon('/usr/bin', 0)[1] == 'system_u:object_r:bin_t:s0'
    # This is a path on my system with a context of "system_u:object_r:unknown_t"
    assert matchpathcon('/sys/fs/binfmt_misc', 0)[1].startswith('system_u:object_r:unknown_t:')



# Generated at 2022-06-20 16:38:20.482056
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("policy type: %s" % selinux_getpolicytype())



# Generated at 2022-06-20 16:38:25.539849
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from subprocess import check_output, CalledProcessError
    from tempfile import mkstemp
    from os import close, unlink

    fd, path = mkstemp()
    close(fd)
    unlink(path)
    try:
        try:
            check_output(['touch', path])
        except CalledProcessError:
            raise AssertionError('unable to create test file: {0}'.format(path))

        rc, con = lgetfilecon_raw(path)
        if rc != 0 or con is None or len(con) == 0:
            raise AssertionError('unable to get file context for: {0}'.format(path))
    finally:
        unlink(path)

# Generated at 2022-06-20 16:38:28.274262
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.selinux import selinux_getenforcemode
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0, "selinux_getenforcemode()"
    if enforcemode == 1:
        assert "Enforcing" == "Enforcing"
    elif enforcemode == 0:
        assert "Permissive" == "Permissive"


# Generated at 2022-06-20 16:38:31.773451
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, poltype = selinux_getpolicytype()
    if rc >= 0:
        return rc
    else:
        raise OSError(rc, os.strerror(rc))



# Generated at 2022-06-20 16:38:33.583164
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/var/log/audit/audit.log')
    print((rc, con))


# Generated at 2022-06-20 16:38:39.440488
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _selinux_lib.selinux_getpolicytype.argtypes = [POINTER(c_char_p)]
    _selinux_lib.selinux_getpolicytype.restype = int

    # CASE 1: SELinux is in enforcing mode
    os.environ['SELINUX_INIT'] = 'YES'
    os.environ['SELINUX_ENFORCE'] = '1'

    retval, policytype = selinux_getpolicytype()
    expected_result = [0, 'targeted']
    assert policytype == expected_result[1]
    assert retval == expected_result[0]

    # CASE 2: SELinux is in permissive mode
    os.environ['SELINUX_ENFORCE'] = '0'

    retval, policytype = se

# Generated at 2022-06-20 16:38:43.066095
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc'
    ret, rc = lgetfilecon_raw(path)
    assert rc == b'system_u:object_r:etc_t:s0'
    assert ret == 0



# Generated at 2022-06-20 16:38:47.318415
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/dev/null')
    if rc < 0:
        raise Exception('lgetfilecon failed')
    return con

# Generated at 2022-06-20 16:38:49.129783
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    x = lgetfilecon_raw('/etc/fstab')
    assert x[0] == 0

# Generated at 2022-06-20 16:38:53.073989
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test matchpathcon
    from tempfile import mkdtemp
    from shutil import rmtree
    dirpath = mkdtemp()
    try:
        rc, con = matchpathcon(dirpath, 0)
        assert rc == 0
        assert con != ""
    finally:
        rmtree(dirpath)

# Generated at 2022-06-20 16:39:05.857109
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/hosts'
    # mode should be equal to 0
    mode = 0
    # return value should be a list of length 2
    assert len(matchpathcon(path, mode)) == 2
    # return value must be a int
    assert isinstance(matchpathcon(path, mode)[0], int)
    # return value must be a str
    assert isinstance(matchpathcon(path, mode)[1], str)
    # return value must be a valid file context
    assert matchpathcon(path, mode)[1] == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-20 16:39:14.063161
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Assume that we are located in a directory
    # i.e. /home/user/ansible/lib/ansible/module_utils/selinux/selinux.py
    rc = lgetfilecon_raw(b'../')[0]
    assert rc == -1, 'lgetfilecon_raw should fail on directory'

    # Assume that we are located in a directory
    # i.e. /home/user/ansible/lib/ansible/module_utils/selinux/selinux.py
    rc = lgetfilecon_raw(b'selinux.py')[0]
    assert rc == 0, 'lgetfilecon_raw should succeed'

# Generated at 2022-06-20 16:39:19.321561
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        import argparse
    except ImportError:
        import optparse as argparse
    import os

    parser = argparse.ArgumentParser(description='Test lgetfilecon_raw')
    parser.add_argument('path', nargs=1,
                        help='Path to file to test')
    parser.add_argument('--raw',
                        dest='raw',
                        default=False,
                        action='store_true',
                        help='Get raw context without post-processing')

    args = parser.parse_args()
    rc, con = lgetfilecon_raw(args.path[0])
    if rc < 0:
        print('Failed to get context for {0}: {1}'.format(args.path[0], os.strerror(rc * -1)))

# Generated at 2022-06-20 16:39:23.436546
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policytype) = selinux_getpolicytype()
    if rc == 0:
        print('SELinux Policy type: %s' % policytype)
    else:
        print('Could not get SELinux policytype. Error: %d' % rc)


# Generated at 2022-06-20 16:39:25.170353
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    num, value = selinux_getenforcemode()
    assert num == 0
    assert value



# Generated at 2022-06-20 16:39:26.886725
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert policytype == 'targeted'


# Generated at 2022-06-20 16:39:29.948797
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    res = selinux_getenforcemode()
    if res[0] < 0:
        raise ValueError("Unable to get the selinux enforcing mode")
    print("selinux enforcing mode is " + res[1])
    return res[0]


# Generated at 2022-06-20 16:39:40.822965
# Unit test for function matchpathcon
def test_matchpathcon():
    from ctypes import c_int
    from os import makedirs
    from shutil import rmtree
    from tempfile import mkdtemp
    from ansible.module_utils.common.text.converters import to_bytes

    # Create test directory structure
    tmpdir = mkdtemp()
    makedirs(os.path.join(tmpdir, 'etc', 'selinux'))
    makedirs(os.path.join(tmpdir, 'opt', 'app'))

    open(os.path.join(tmpdir, 'etc', 'selinux', 'file_contexts'), 'w')
    open(os.path.join(tmpdir, 'opt', 'app', 'test.war'), 'w')

    # Test matchpathcon with a valid directory

# Generated at 2022-06-20 16:39:46.009599
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/') == [0, b'']
    assert lgetfilecon_raw(b'/etc/') == [0, b'>etc<']
    assert lgetfilecon_raw(b'/etc') == [0, b'']
    assert lgetfilecon_raw(b'/etc/hosts') == [0, b'etc_t:object_r:etc_t:s0']

# Generated at 2022-06-20 16:39:49.707417
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/proc/sys/net/ipv4/ip_forward'
    errors = []
    try:
        rc, con = lgetfilecon_raw(path)
    except OSError:
        errors.append(1)

    assert not errors, 'Function lgetfilecon_raw has errors, details: %s' % errors


# Generated at 2022-06-20 16:40:09.223485
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/")
    assert rc == 0
    assert con == "system_u:object_r:root_t:s0"

    rc, con = lgetfilecon_raw("/non-existent")
    assert rc == -1
    assert con is None



# Generated at 2022-06-20 16:40:13.228310
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    print("\nTesting selinux_getenforcemode function:\n")
    rc, mode = selinux_getenforcemode()
    print("\nSELinux mode: {} with return code: {}".format(mode, rc))
    if rc != 0:
        print("Error running selinux_getenforcemode function:\n{}".format(os.strerror(rc)))


# Generated at 2022-06-20 16:40:15.866382
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b"/etc/passwd")
    print("lgetfilecon_raw(\"/etc/passwd\") returned:", rc, con)
    rc, con = lgetfilecon_raw(b"/etc/")
    print("lgetfilecon_raw(\"/etc/\") returned:", rc, con)



# Generated at 2022-06-20 16:40:21.677048
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    got = lgetfilecon_raw('/etc/shadow')
    assert got[0] == 0
    assert got[1] == 'system_u:object_r:shadow_t:s0'


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:40:26.655603
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.expanduser('~')
    if not os.path.exists(path):
        raise Exception('"{0}" does not exists'.format(path))

    rc, context = lgetfilecon_raw(path)
    assert rc == 0
    assert context is not None, 'context is None'
    assert context.startswith('user_home_t'), 'context is wrong "' + context + '"'



# Generated at 2022-06-20 16:40:32.441595
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import os
    osname = os.uname()[0]
    if osname != "Linux":
        print("Info: %s not supported on %s" % (__name__, osname))
        return
    (rc, con) = selinux_getpolicytype()
    assert rc == 0, "could not get policy type from selinux"
    assert con == "targeted", "policy type %s not supported" % con

# Generated at 2022-06-20 16:40:42.070823
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os.path
    import os
    import tempfile
    import shutil
    import stat
    import ansible_collections.ansible.builtin
    from ansible_collections.ansible.builtin.plugins.module_utils.basic import AnsibleModule

    fd, fd_name = tempfile.mkstemp(suffix='.txt', prefix='ansible_test_libselinux_')
    os.close(fd)


# Generated at 2022-06-20 16:40:46.537593
# Unit test for function matchpathcon
def test_matchpathcon():
    exc_value = None
    try:
        matchpathcon('/usr/bin', 0)
    except OSError as exc:
        exc_value = exc.errno
    assert exc_value == 0, 'No error should be returned by calling functio `matchpathcon`'



# Generated at 2022-06-20 16:40:51.649031
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 1) == [0, u'<<none>>']
    assert matchpathcon('/foo/bar', 1) == [0, u'<<none>>']
    assert matchpathcon('/', 0) == [0, u'<<none>>']
    assert matchpathcon('/foo/bar', 0) == [0, u'<<none>>']

# Generated at 2022-06-20 16:40:54.771570
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test that selinux_getenforcemode returns the expected result."""
    assert not selinux_getenforcemode()[0]



# Generated at 2022-06-20 16:41:30.670744
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy = selinux_getpolicytype()
    if rc == 0:
        print("policy type: " + policy)



# Generated at 2022-06-20 16:41:39.723957
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert con.startswith('unconfined_u:object_r:tmp_t:s0')
    (rc, con) = lgetfilecon_raw('/dev/null')
    assert rc == 0
    assert con.startswith('system_u:object_r:chr_file:s0')
    (rc, con) = lgetfilecon_raw('/no/such/file')
    assert rc == -1
    assert rc != 0
    # Unit test for function is_selinux_enabled
    assert is_selinux_enabled() == 1
    # Unit test for function is_selinux_mls_enabled
    assert is_selinux_mls_enabled() == 1
    # Unit

# Generated at 2022-06-20 16:41:41.479029
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-20 16:41:47.423358
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    val = selinux_getpolicytype()
    if val[0] != 0:
        raise Exception('selinux_getpolicytype returned failure: {0}'.format(val))

    if val[1] not in ('targeted', 'minimum', 'mls'):
        raise Exception('selinux_getpolicytype returned unexpected result: {0}'.format(val))



# Generated at 2022-06-20 16:41:59.695740
# Unit test for function matchpathcon
def test_matchpathcon():
    tests_passed = 0
    tests_failed = 0

    if not os.path.exists("/usr/bin/python3"):
        print("Skipping matchpathcon unit test, python3 binary not found")
        return


# Generated at 2022-06-20 16:42:04.459344
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()
    assert selinux_getpolicytype()[1] == 'targeted'


test_selinux_getpolicytype()

# Generated at 2022-06-20 16:42:07.508923
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert type(rc) is int
    assert type(enforcemode) is int


# Generated at 2022-06-20 16:42:13.431995
# Unit test for function matchpathcon
def test_matchpathcon():
    """ Unit test for function matchpathcon.
    """
    path = '/tmp/testfile'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-20 16:42:19.880593
# Unit test for function matchpathcon
def test_matchpathcon():
    import json

    # NB: this test will succeed when the test binary is compiled + linked with libselinux.so
    # any other binary (python, bash, etc) will fail because of the way selinux implements path
    # lookups for exec
    # $ sesearch -AC -s ucontext_t -c file -t /usr -p execute
    (rc, mode) = security_getenforce()
    assert rc == 0

    con = None
    if mode == 1:
        (rc, con) = matchpathcon('/usr/bin/python', 0)
        assert rc == 0, 'matchpathcon failed: {0}'.format(rc)

    print(json.dumps({
        'rc': rc,
        'mode': mode,
        'con': con,
    }))



# Generated at 2022-06-20 16:42:23.352666
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    retval = selinux_getenforcemode()
    assert retval[0] == 0
    assert type(retval[1]) == int


# Generated at 2022-06-20 16:43:07.615090
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        policy = selinux_getpolicytype()
    except OSError as e:
        if e.errno == 2:
            sys.stderr.write("selinux not installed or policy not loaded\n")
        raise e
    print("selinux policy type: ", policy)


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:43:10.408487
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] in (0, 1, 2)



# Generated at 2022-06-20 16:43:15.099615
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import pytest
    import re

    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert re.match(r"^(targeted|minimum)$", policytype)



# Generated at 2022-06-20 16:43:17.073769
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon(b'/some_path', 0)
    assert rc == 0
    assert con.endswith('system_u:object_r:tmp_t')

# Generated at 2022-06-20 16:43:19.861243
# Unit test for function matchpathcon
def test_matchpathcon():

    def _matchpathcon(path, mode):
        rc, con = matchpathcon(path, mode)
        return con

    assert _matchpathcon(b'/etc/localtime', 0) == b'etc_t:etc_t:s0'



# Generated at 2022-06-20 16:43:24.838470
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/hosts'
    mode = 0
    con = matchpathcon(path, mode)
    print(con)

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:43:31.085819
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    assert con == 'targeted', "selinux_getpolicytype failed!"
    assert rc == 0, "selinux_getpolicytype failed!"



# Generated at 2022-06-20 16:43:36.414645
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enf = selinux_getenforcemode()
    assert (enf[0] == 0) or (enf[0] == 1)
    assert enf[1] in (0, 1, 2)

if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-20 16:43:40.555711
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Validate that selinux_getpolicytype returns a list
    assert type(selinux_getpolicytype()) is list

# Generated at 2022-06-20 16:43:46.415220
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.selinux_wrappers import selinux_getenforcemode

    rc, mode = selinux_getenforcemode()
    assert mode in [0, 1, 2]

# Generated at 2022-06-20 16:44:34.362168
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-20 16:44:37.948847
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw("/usr/bin/python")
    if result[0] != 0:
        assert False, "lgetfilecon_raw returned: " + str(result)



# Generated at 2022-06-20 16:44:43.062481
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/tmp/test', 1)
    assert res[0] == 0
    assert res[1] == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-20 16:44:47.885358
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, "Failed to get selinux policytype(rc:%d)" % (rc)
    assert policytype == "targeted", "Invalid selinux policytype(%s)" % (policytype)


# Generated at 2022-06-20 16:44:55.530366
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Test function by checking return of call to selinux_getpolicytype.
    On most Linux systems, this will be 'targeted'.
    """
    assert selinux_getpolicytype()[1] in ['targeted', 'mls']


if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:44:59.429878
# Unit test for function matchpathcon
def test_matchpathcon():
    rctuple = matchpathcon('/etc/ssh', os.R_OK)
    if rctuple[0] == -1:
        raise OSError(rctuple[0], os.strerror(rctuple[0]))
    else:
        print(rctuple)


# Generated at 2022-06-20 16:45:04.018876
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert type(policytype) is str
    assert len(policytype) > 0



# Generated at 2022-06-20 16:45:07.740875
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enf) = selinux_getenforcemode()
    assert rc == 0
    assert enf == 1 or enf == 0 or enf == 2


# Generated at 2022-06-20 16:45:11.190483
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """Test function selinux_getpolicytype."""
    rc, con = selinux_getpolicytype()
    assert rc == 0, "unexpected return code"
    assert isinstance(con, str), "unexpected return"
    assert con, "policy type should not be empty"



# Generated at 2022-06-20 16:45:11.796665
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    ret, out = selinux_getpolicytype()
    return ret, out