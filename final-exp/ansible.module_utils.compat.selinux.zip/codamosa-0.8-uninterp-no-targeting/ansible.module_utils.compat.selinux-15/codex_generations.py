

# Generated at 2022-06-20 16:36:04.833680
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Make sure the function returns the expected values
    # The expected value is the type of the loaded policy
    _, policytype = selinux_getpolicytype()
    assert policytype == 'targeted'


# Generated at 2022-06-20 16:36:07.851568
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print("rc: {0}".format(rc))
    print("Value: {0}".format(enforcemode))


# Generated at 2022-06-20 16:36:15.408633
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = 'foo'
    test_mode = 0

    path = c_char_p(test_path)
    mode = c_int(test_mode)
    con = c_char_p()

    rc = matchpathcon(path, mode)
    assert(type(rc) == list)
    assert(rc[0] == 0)
    assert(rc[1] == 'system_u:object_r:user_home_dir_t:s0')


# Generated at 2022-06-20 16:36:18.830262
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/etc/passwd', 0)
    print("rc: %d" % res[0])
    print("context: %s" % res[1])



# Generated at 2022-06-20 16:36:26.882083
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import fileinput
    def get_security_context(filename):
        # Inspired by https://unix.stackexchange.com/questions/8045/how-to-set-change-the-context-of-a-file-to-a-particular-context
        output = lgetfilecon_raw(filename)
        if output[0] == -1:
            print("Couldn't find file {}".format(filename))
            return None
        return output[1]

    def change_security_context(filename, context):
        # Inspired by https://unix.stackexchange.com/questions/8045/how-to-set-change-the-context-of-a-file-to-a-particular-context
        rv = lsetfilecon(filename, context)

# Generated at 2022-06-20 16:36:28.448530
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp'
    assert lgetfilecon_raw(path) == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-20 16:36:31.318111
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux/targeted/contexts/files/file_contexts'
    con_list = lgetfilecon_raw(path)
    if con_list[0] < 0:
        raise OSError(os.strerror(con_list[0]))
    else:
        assert con_list[1] == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-20 16:36:32.818641
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/foo', 0)
    assert rc == -1
    assert con is None



# Generated at 2022-06-20 16:36:40.493454
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, mode) = selinux_getenforcemode()

    if rc == -1 and mode == -1:
        assert False, "selinux not enabled"
    elif mode == 1:
        assert True, "selinux enabled and in enforcing mode"
    elif mode == 0:
        assert True, "selinux enabled and in permissive mode"
    else:
        assert False, "unexpected selinux enforce mode, {}".format(mode)


# Generated at 2022-06-20 16:36:42.796441
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/', 0)
    assert res == [0, 'system_u:object_r:system_dbusd_exec_t:s0']


# Generated at 2022-06-20 16:36:51.066642
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import os
    try:
        f = open("/sys/fs/selinux/enforce", "r")
        enforce = f.read().rstrip("\n")
        f.close()
    except:
        return
    if enforce == "0":
        assert selinux_getenforcemode() == [0, 0]
    elif enforce == "1":
        assert selinux_getenforcemode() == [0, 1]
    else:
        assert False

# Generated at 2022-06-20 16:36:54.779946
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = "/etc/passwd"
    rc, con = lgetfilecon_raw(file_path)
    rc = matchpathcon(file_path, os.stat(file_path).st_mode)
    assert rc == 0
    assert con is not None
    assert type(con) == str

# Generated at 2022-06-20 16:36:59.163695
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    getenforcemode = selinux_getenforcemode()
    assert type(getenforcemode) == list
    assert len(getenforcemode) == 2
    assert type(getenforcemode[0]) == int
    assert type(getenforcemode[1]) == int


# Generated at 2022-06-20 16:37:01.259370
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    print('selinux_getenforcemode() is {}'.format(enforcemode))



# Generated at 2022-06-20 16:37:03.999404
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/home/ansible/selinux'
    result = lgetfilecon_raw(path)
    print(result)


# Generated at 2022-06-20 16:37:05.782310
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')

# Generated at 2022-06-20 16:37:08.504029
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/var/log/httpd', 0)
    print(rc, con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-20 16:37:09.396059
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # FIXME
    assert False

# Generated at 2022-06-20 16:37:15.437690
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import ansible.module_utils.selinux_testlib as testlib

    # python3 bytes vs unicode object
    if not isinstance('test', str):
        str_type = bytes

    testfile = os.path.join(tempfile.gettempdir(), "test")

    testlib.create_bogus_file(testfile)
    (rc, con) = lgetfilecon_raw(testfile)
    os.unlink(testfile)
    if rc:
        raise(Exception("Failed to get the file context of %s" % testfile))

    if not con.startswith(str_type(b"unconfined_u:object_r:")):
        raise(Exception("Could not determine the context type: %s" % con))



# Generated at 2022-06-20 16:37:18.809300
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    assert matchpathcon('/tmp/hello.txt', 0) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-20 16:37:26.794332
# Unit test for function matchpathcon
def test_matchpathcon():

    from ansible.module_utils._text import to_bytes

    path = '/tmp/foo'
    contents = to_bytes('system_u:system_r:tmp_t:s0')


# Generated at 2022-06-20 16:37:28.125043
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # TODO: add tests for selinux
    pass


# Generated at 2022-06-20 16:37:31.272028
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fname = to_bytes('/etc/selinux/config')
    rc, context = lgetfilecon_raw(fname)
    assert rc == 0
    assert context == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-20 16:37:35.112306
# Unit test for function matchpathcon
def test_matchpathcon():
    # Match a file in /tmp and test the context
    rc, con = matchpathcon('/tmp/testfile', 0)
    if rc == 0:
        print(con)
    else:
        print('Error with matchpathcon')


# Generated at 2022-06-20 16:37:36.799277
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0


# Generated at 2022-06-20 16:37:38.177616
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # FIXME: how to unit test?
    pass


# Generated at 2022-06-20 16:37:45.770348
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw

    [rc, con] = lgetfilecon_raw('/etc/passwd')
    if rc != 0 or con is not None:
        raise Exception("Test for lgetfilecon_raw failed")

    [rc, con] = lgetfilecon_raw('/etc/passwd_not_exist')
    if rc != -1:
        raise Exception("Test for lgetfilecon_raw failed")


# Generated at 2022-06-20 16:37:55.486088
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    rc, val = lgetfilecon_raw('/usr/bin/python3')
    assert rc == 0, 'Error %s: %s' % (rc, val)
    assert val != '', 'Unexpected empty value'

    f = tempfile.mktemp()
    open(f, 'w').close()
    rc, val = lgetfilecon_raw(f)
    os.remove(f)
    assert rc == 0, 'Error %s: %s' % (rc, val)
    assert val != '', 'Unexpected empty value'

    rc, val = lgetfilecon_raw('/usr/bin/python3.2')
    assert rc == -1, 'Unexpected return code %s, expected -1' % rc
    assert val == '', 'Unexpected non-empty value'

   

# Generated at 2022-06-20 16:37:59.213318
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected_rc = [0, 'unconfined_u:object_r:user_home_dir_t:s0']
    res = lgetfilecon_raw('/home/test_user')
    assert res == expected_rc


# Generated at 2022-06-20 16:38:02.008420
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    Test selinux_getenforcemode function
    """
    (rc, result) = selinux_getenforcemode()
    assert rc == 0, 'selinux_getenforcemode returned non-zero return code'
    assert result in [1, 0], 'selinux_getenforcemode returned unexpected value'


# Generated at 2022-06-20 16:38:18.845906
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import six

    path = '/foo/bar'
    con = b'system_u:object_r:sysadm_var_lib_t:s0'
    test_lgetcon = lgetfilecon_raw

    class getcon(object):
        def __init__(self, con=None):
            self.con = con

        def __call__(self, path, con):
            con.contents = self.con.encode('utf-8')
            return 0

    # Test 1: Success
    print("\nTest Success")
    _selinux_lib.lgetfilecon_raw = getcon(con)
    rc, value = test_lgetcon(path)
    assert rc == 0
    assert value == con

    # Test 2: Failure
    print("\nTest Failure")
    _sel

# Generated at 2022-06-20 16:38:22.118750
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/sys"
    mode = 0
    # This should return success (0) and a valid context
    rc, context = matchpathcon(path, mode)
    assert rc == 0
    assert context

# Generated at 2022-06-20 16:38:26.632591
# Unit test for function matchpathcon
def test_matchpathcon():
    # unit test for function matchpathcon
    # when there is no selinux enabled, the function should return None
    # when there is no selinux enabled, the return code should be 0
    # when there is no selinux enabled, errno should be 0
    [rc, con] = matchpathcon('/tmp/null', 0)
    if rc == 0 and con is None:
        print('PASS: test_matchpathcon() for no selinux enabled')
    else:
        print('FAIL: test_matchpathcon() for no selinux enabled')



# Generated at 2022-06-20 16:38:31.009794
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = c_int()
    rc = selinux_getenforcemode(byref(enforcemode))
    return [rc, enforcemode.value]



# Generated at 2022-06-20 16:38:33.589478
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/")
    print(rc, ":", con)


# Generated at 2022-06-20 16:38:36.199693
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    if rc == -1:
        raise OSError(errno, os.strerror(errno))
    print('/etc/passwd context: %s' % con)


# Generated at 2022-06-20 16:38:39.402363
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, _ = lgetfilecon_raw('/')
    assert rc == 0


# Generated at 2022-06-20 16:38:43.033580
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/hosts')[0] == 0
    assert lgetfilecon_raw('/etc/hosts')[1].startswith('system_u:object_r:etc_t:s0')

# Generated at 2022-06-20 16:38:46.171530
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert rc == 0



# Generated at 2022-06-20 16:38:54.964663
# Unit test for function matchpathcon
def test_matchpathcon():
    rc1, con1 = matchpathcon(b'/usr/bin/python', 0)
    rc2, con2 = matchpathcon(b'/usr/bin/python', 0)
    rc3, con3 = matchpathcon(b'/usr/bin/python', 1)
    rc4, con4 = matchpathcon(b'/usr/bin/python', 1)
    rc5, con5 = matchpathcon(b'/usr/bin/python', 2)
    rc6, con6 = matchpathcon(b'/usr/bin/python', 2)

# Generated at 2022-06-20 16:39:12.922954
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Returns [0, 'selinuxfs'] on success
    assert selinux_getpolicytype() == [0, 'selinuxfs']



# Generated at 2022-06-20 16:39:16.769068
# Unit test for function matchpathcon
def test_matchpathcon():

    pth = "/sys/fs/selinux/null"
    rc, con = matchpathcon(pth, os.R_OK)
    assert rc == 0
    assert con == "system_u:object_r:selinuxfs:s0"

# Generated at 2022-06-20 16:39:25.709765
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert isinstance(selinux_getpolicytype(), list), "selinux_getpolicytype does not return a list"
    assert isinstance(selinux_getpolicytype(), list), "selinux_getpolicytype does not return a list"
    assert len(selinux_getpolicytype()) == 2, "selinux_getpolicytype does not return a list with 2 elements"
    assert isinstance(selinux_getpolicytype()[0], int), "selinux_getpolicytype[0] does not return an integer"
    assert isinstance(selinux_getpolicytype()[1], str), "selinux_getpolicytype[1] does not return a string"

# Generated at 2022-06-20 16:39:27.418043
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    pass


# Generated at 2022-06-20 16:39:29.605204
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('/home', 0)
    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:user_home_dir_t:s0'



# Generated at 2022-06-20 16:39:32.285546
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test that the call returns a value
    assert lgetfilecon_raw("/")[1] is not None


# Generated at 2022-06-20 16:39:35.334302
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Test that two executions of the function do not
    # give the same result.
    first = selinux_getpolicytype()
    second = selinux_getpolicytype()
    assert first != second

# Generated at 2022-06-20 16:39:40.482883
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # create a fake file and set the context
    import tempfile
    with tempfile.NamedTemporaryFile() as f:
        rc, con = lgetfilecon_raw(f.name)
        assert rc == 0 and con is not None
    # the tempfile is automatically removed

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-20 16:39:43.296972
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # test for non-existent file
    test_rc, test_con = lgetfilecon_raw("/this/file/does/not/exist")
    assert test_rc == -1


# Generated at 2022-06-20 16:39:45.883675
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policy_type = selinux_getpolicytype()
    print(policy_type[1])


if __name__ == "__main__":
    test_selinux_getpolicytype()

# Generated at 2022-06-20 16:40:27.136042
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        test_selinux_getpolicytype.policy_type
    except AttributeError:
        rc, test_selinux_getpolicytype.policy_type = selinux_getpolicytype()
    return test_selinux_getpolicytype.policy_type


if __name__ == '__main__':
    print('testing selinux from python - this should not be run from within Ansible directly')

    policy_type = test_selinux_getpolicytype()
    print('policy_type: {0}'.format(policy_type))

    rc, enforcemode = selinux_getenforcemode()
    print('enforcemode: {0}'.format(enforcemode))

    rc = security_getenforce()
    print('security_getenforce: {0}'.format(rc))


# Generated at 2022-06-20 16:40:30.579073
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.exists("/etc/issue"):
        assert lgetfilecon_raw("/etc/issue")[0] == 0
    else:
        assert lgetfilecon_raw("/etc")[0] == 0


# Generated at 2022-06-20 16:40:33.198996
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/tmp', 0)
    assert(rc >= 0)
    assert(con == "system_u:object_r:tmp_t:s0")

# Generated at 2022-06-20 16:40:35.234079
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]
    assert selinux_getenforcemode() == [0, 1]


# Generated at 2022-06-20 16:40:36.991832
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc = selinux_getenforcemode()
    assert rc[0] == 0
    assert rc[1] == 1



# Generated at 2022-06-20 16:40:39.847580
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Test the return value of selinux_getenforcemode
    assert selinux_getenforcemode()[0] >= 0


# Generated at 2022-06-20 16:40:44.742186
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        [rc, enforcemode] = selinux_getenforcemode()
    except OSError as e:
        assert False, "OSError: " + to_native(e)
    else:
        assert rc == 0, "Successful call failed"
        assert enforcemode == 1 or enforcemode == 0 or enforcemode == 2, "Invalid return code"


# Generated at 2022-06-20 16:40:47.998006
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    if rc == -1:
        raise OSError(os.strerror(get_errno()))
    return [rc, con]


# Generated at 2022-06-20 16:40:53.550770
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b"/proc/version"
    mode = 0
    rc, result = matchpathcon(path, mode)
    assert rc == 0, "rc = {0}".format(rc)
    assert result == "system_u:object_r:proc_t:s0", "result = {0}".format(result)

# Generated at 2022-06-20 16:40:57.455480
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/var/tmp/', os.R_OK)
    print('rc: {0} con: {1}'.format(rc, con))

    (rc, con) = matchpathcon('/var/tmp', os.R_OK)
    print('rc: {0} con: {1}'.format(rc, con))

    (rc, con) = matchpathcon('/tmp', os.R_OK)
    print('rc: {0} con: {1}'.format(rc, con))

# Generated at 2022-06-20 16:42:07.351500
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This test is specific to CentOS/RHEL 7, since this function is
    # implemented in newer systemd releases that provide 'tmpfiles.d'
    rc, con = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-20 16:42:10.536330
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policytype, str)


# Generated at 2022-06-20 16:42:16.965581
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = "/var/log/httpd"
    mode = os.R_OK
    rc, con = matchpathcon(test_path, mode)
    assert rc == 0
    assert con is not None
    rc, con = matchpathcon(b"invalid/path", mode)
    assert rc == -1
    rc, con = matchpathcon(test_path, -1)
    assert rc == -1



# Generated at 2022-06-20 16:42:21.338773
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    handle = dict(selinux_getenforcemode())
    assert handle['rc'] == 0
    assert handle['stdout'] == 0


# Generated at 2022-06-20 16:42:24.571286
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import pdb; pdb.set_trace()
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]

# Generated at 2022-06-20 16:42:26.486175
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()

    assert(rc == 0)
    assert(enforcemode is not None)



# Generated at 2022-06-20 16:42:31.469226
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # This is a test of the selinux_getpolicytype function
    (rc, con) = selinux_getpolicytype()
    assert rc == 0, "selinux_getpolicytype returned non-zero"
    assert con.endswith("_t"), "selinux_getpolicytype returned %s" % con

# Generated at 2022-06-20 16:42:36.525190
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fname = 'selinux.py'
    path = os.path.join(os.path.dirname(__file__), fname)
    if not os.path.exists(path):
        raise Exception("Path '%s' does not exist" % path)

    (code, con) = lgetfilecon_raw(path)
    if code != 0:
        raise Exception("Failed to get SELinux context (code %d)" % code)

    pos = con.find((':'))
    if pos < 0:
        raise Exception("Failed to get SELinux context '%s'" % con)



# Generated at 2022-06-20 16:42:39.248196
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert isinstance(result, list)



# Generated at 2022-06-20 16:42:44.574959
# Unit test for function matchpathcon
def test_matchpathcon():
    tests = [
        ('/etc/selinux/config', os.R_OK),
        ('/selinux', os.W_OK),
        ('/home/user/foo', os.R_OK),
        ('/home/user/foo', os.W_OK),
    ]

    for fn, mode in tests:
        rc, con = matchpathcon(fn, mode)
        print('{0}({1}) -> {2}'.format(fn, mode, con))



# Generated at 2022-06-20 16:45:28.319992
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    def test_enforce_mode(enforce_mode):
        if enforce_mode == 0:
            print("Enforce mode set to 'Permissive'")
        elif enforce_mode == 1:
            print("Enforce mode set to 'Enforcing'")
        else:
            print("Error:  Unsupported Enforce Mode value returned")
        return

    if is_selinux_enabled() == 0:
        print("SELinux is disabled.  Exiting test.")
        return

    [rc, enforce_mode] = selinux_getenforcemode()
    print("Return code from selinux_getenforcemode is " + to_native(rc))
    test_enforce_mode(enforce_mode)
    return



# Generated at 2022-06-20 16:45:32.492182
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-20 16:45:35.901413
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
     # 'python -m ansible.modules.files.selinux --test-module' triggers this test
     assert selinux_getenforcemode()[1] in (0, 1, 2)

# Generated at 2022-06-20 16:45:37.095530
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    return


# Generated at 2022-06-20 16:45:42.110459
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con_out = matchpathcon('/test/test.test', 1)
    assert rc == 0
    assert con_out == 'system_u:object_r:file_t:s0'

# Generated at 2022-06-20 16:45:52.268152
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing matchpathcon")
    try:
        print(matchpathcon("/var/log/messages", 0))
    except OSError as e:
        print("Error caught:")
        print(e)
    try:
        print(matchpathcon("/var/log/not_a_file", 0))
    except OSError as e:
        print("Error caught:")
        print(e)
    try:
        print(matchpathcon("/var/log/not_a_file", 3))
    except OSError as e:
        print("Error caught:")
        print(e)



# Generated at 2022-06-20 16:45:59.950298
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    from ansible.module_utils.pycompat24 import get_exception
    try:
        assert lgetfilecon_raw('/nonexistent_file') == [-1, os.strerror(2)]
    except Exception:
        errstr = get_exception()
    else:
        errstr = None
    assert errstr is None