

# Generated at 2022-06-11 01:50:46.914119
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0)[0] == -1
    assert matchpathcon('/etc/passwd', 0)[1] == 'system_u:object_r:etc_t:s0'
    assert matchpathcon('/etc', 0)[0] == -1
    assert matchpathcon('/etc', 0)[1] == 'system_u:object_r:etc_t:s0'
    assert matchpathcon('/usr', 0)[0] == -1
    assert matchpathcon('/usr', 0)[1] == 'system_u:object_r:usr_t:s0'
    assert matchpathcon('/usr/bin', 0)[0] == -1

# Generated at 2022-06-11 01:50:49.164269
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0


# Generated at 2022-06-11 01:50:52.683170
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'./test'
    mode = os.stat(path).st_mode
    mode = mode & 0o777
    rc, con = matchpathcon(path, mode)
    print(rc)
    print(con)


# Generated at 2022-06-11 01:50:55.810627
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/sys/kernel/debug', 0)
    assert con == b'debugfs:file'
    if rc == 0:
        rc, con = matchpathcon(b'/sys/kernel/debug', 1)
        assert con == b'debugfs:file system_u:object_r:debugfs_t:s0'
    assert rc == 0



# Generated at 2022-06-11 01:51:06.909171
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import stat

    # We want to use /dev/random, however on some platforms this is a
    # character device, on some it's a block device, and we need to know
    # what it is as we need to match the file type when calling stat().
    standard_lgetfilecon_raw_path = '/dev/random'
    standard_lgetfilecon_raw_ino_result = 8
    standard_lgetfilecon_raw_expected_value = 'system_u:object_r:random_device_t:s0'
    standard_matchpathcon_path = '/dev/random'
    standard_matchpathcon_mode = stat.S_IFCHR
    standard_matchpathcon_expected_value = 'system_u:object_r:random_device_t:s0'
    standard_selinux_getenforcemode

# Generated at 2022-06-11 01:51:11.017631
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        return False
    if _selinux_lib.matchpathcon(b'/etc/passwd', 1, None) == 0:
        return True
    return False


# Generated at 2022-06-11 01:51:16.209730
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Linux tests
    if os.uname()[0] == 'Linux':
        # Missing file path
        rc, con = lgetfilecon_raw('/tmp/i_dont_exist')
        assert type(rc) is int
        assert rc == -1
    else:
        # OS X - no tests
        assert True

# Generated at 2022-06-11 01:51:22.818555
# Unit test for function matchpathcon
def test_matchpathcon():
    assert _selinux_lib.matchpathcon("/var/log", 0) == 0
    assert _selinux_lib.matchpathcon("/var/log", os.R_OK) == 0
    assert _selinux_lib.matchpathcon("/var/log", os.W_OK) == 0
    assert _selinux_lib.matchpathcon("/var/log", os.R_OK|os.W_OK) == 0
    assert _selinux_lib.matchpathcon("/var/log", os.W_OK|os.X_OK) == 0
    assert _selinux_lib.matchpathcon("/var/log", os.R_OK|os.W_OK|os.X_OK) == 0

# Generated at 2022-06-11 01:51:26.506337
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    status, context = lgetfilecon_raw("/bin/ls")
    if status == -1 and context is None:
        sys.exit(0)
    else:
        sys.exit(1)


# Generated at 2022-06-11 01:51:30.517509
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test for function lgetfilecon_raw"""
    _file = "/etc/selinux/config"
    con = lgetfilecon_raw(_file)[1]
    assert con == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-11 01:51:36.433024
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    tempdir = tempfile.mkdtemp()
    (rc, con) = matchpathcon(to_bytes(tempdir), 0)
    assert rc == 0
    print(con)
    import os
    os.rmdir(tempdir)



# Generated at 2022-06-11 01:51:43.780962
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    if selinux_getenforcemode()[1] == 0:
        path = tempfile.mkdtemp(prefix="/tmp/test_matchpathcon")
        normpath = os.path.normpath(path)
        normpath = normpath.replace("\\", "/")
        result = matchpathcon(normpath, 0)
        assert result[0] == 0, "error with matchpathcon, %s != 0" % result[0]
        os.rmdir(path)
    else:
        assert True


# Generated at 2022-06-11 01:51:49.033403
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/usr/bin/python')[0] == 0
    assert lgetfilecon_raw(b'/usr/bin/python')[1] == 'unconfined_u:object_r:usr_t:s0'
    assert lgetfilecon_raw(b'/usr/bin/python')[0] == lgetfilecon_raw('/usr/bin/python')[0]
    assert lgetfilecon_raw(b'/usr/bin/python')[1] == lgetfilecon_raw('/usr/bin/python')[1]



# Generated at 2022-06-11 01:51:50.437204
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "user_tmp_t"

# Generated at 2022-06-11 01:52:00.622176
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/shadow') == [0, 'unconfined_u:object_r:shadow_t:s0']
    assert lgetfilecon_raw('/etc/shadow2') == [-1, '']
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:shadow_t:s0']


__all__ = [
    'selinux_getpolicytype',
    'selinux_getenforcemode',
    'lgetfilecon_raw',
    'matchpathcon',
    'is_selinux_enabled',
    'is_selinux_mls_enabled',
    'security_policyvers',
    'security_getenforce',
    'lsetfilecon',
]

# Generated at 2022-06-11 01:52:10.147504
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/')
    assert rc == 0
    assert con == 'system_u:object_r:root_t:s0'
    (rc, con) = lgetfilecon_raw('/usr/lib/libselinux.so.1')
    assert rc == 0
    assert con == 'system_u:object_r:lib_t:s0'
    (rc, con) = lgetfilecon_raw('/dev/null')
    assert rc == 0
    assert con == 'system_u:object_r:chr_file:s0'



# Generated at 2022-06-11 01:52:15.362146
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon('/tmp', 0)
    if rc[0]:
        raise RuntimeError('unable to test matchpathcon for success: {0}'.format(rc[0]))
    if rc[1] != 'system_u:object_r:tmp_t:s0':
        raise RuntimeError('unexpected matchpathcon success result: {0}'.format(rc[1]))

# Generated at 2022-06-11 01:52:23.793344
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.selinux import matchpathcon
    import os
    import subprocess
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile()
    rc, con = matchpathcon(tmp_file.name, 0)
    assert rc == 0
    assert con != ''
    os.remove(tmp_file.name)
    try:
        rc, con = matchpathcon('/I/dont/exist', 0)
        assert False
    except OSError as e:
        assert e.errno == 2


# Generated at 2022-06-11 01:52:34.062922
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Unit test for matchpathcon.
    """

    # FIXME: this will fail if:
    # - no policy is active
    # - selinux is in permissive mode
    # - mac_selinux policy is active
    # - setfiles is unavailable
    # - file has a matching file context

    from tempfile import TemporaryDirectory
    from random import randint
    from time import sleep

    tmpdir = TemporaryDirectory(prefix='ansible-test_selinux')

    # seed with filename to prevent interleaving
    # test_selinux_matchpathcon_fSCG2Q.tmp/1_3
    # test_selinux_matchpathcon_fSCG2Q.tmp/1_3/file
    # test_selinux_matchpathcon_fSCG2Q.tmp/1_3

# Generated at 2022-06-11 01:52:36.429730
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("test/test_file")
    assert con is not None


# Generated at 2022-06-11 01:52:43.068041
# Unit test for function matchpathcon
def test_matchpathcon():
    # Try matchpathcon on a directory
    path = os.path.dirname(os.path.realpath(__file__))  # Current directory
    mode = os.R_OK
    con = matchpathcon(path, mode)
    print(con)



# Generated at 2022-06-11 01:52:53.500667
# Unit test for function matchpathcon
def test_matchpathcon():
    for mode in [0, 1, 2]:
        # Testing realpath
        rc, context = matchpathcon("/usr/", mode)
        assert rc == 0
        if mode == 0:
            assert context == "system_u:object_r:usr_t:s0"
        elif mode == 1:
            assert context == "system_u:object_r:usr_t:s0"
        elif mode == 2:
            assert context == "system_u:object_r:usr_t:s0"
        # Testing path that does not exists
        rc, context = matchpathcon("/usr/does_not_exists_" + str(mode), mode)
        assert rc == 0
        if mode == 0:
            assert context == "system_u:object_r:usr_t:s0"
        el

# Generated at 2022-06-11 01:52:56.841664
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    [rc, con] = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"


# Generated at 2022-06-11 01:53:01.661169
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp'

    [rc, lcon] = lgetfilecon_raw(path)
    assert lcon == 'system_u:object_r:tmp_t', 'Failed to retrieve context for path {0} ({1})'.format(path, lcon)

# Unit tests for function matchpathcon

# Generated at 2022-06-11 01:53:08.657617
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test case 1: path exists
    path = '/etc/shadow'
    mode = os.stat(path).st_mode
    mode &= 0o7777
    
    assert matchpathcon(path, mode)[0] == 0
    assert matchpathcon(path, mode)[1] == 'system_u:object_r:shadow_t:s0'

    # Test case 2: path does not exist
    path = '/etc/shadow_dummy'
    try:
        os.stat(path)
        assert False
    except FileNotFoundError:
        pass

    assert matchpathcon(path, mode)[0] == -1

# Generated at 2022-06-11 01:53:11.306764
# Unit test for function matchpathcon
def test_matchpathcon():
    context = matchpathcon(b"/etc/resolv.conf", os.R_OK)[1]
    print(context)

# Generated at 2022-06-11 01:53:14.031161
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/bin/sh', 0)
    assert rc == 0
    assert con == 'system_u:object_r:shell_exec_t:s0'

# Generated at 2022-06-11 01:53:25.064308
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    _, tmp_path = tempfile.mkstemp()
    path = tmp_path.encode()
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'
    rc, con = matchpathcon(path, 0o100)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'
    rc, con = matchpathcon(path, 0o400)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'
    rc, con = matchpathcon(path, 0o600)
    assert rc == 0

# Generated at 2022-06-11 01:53:29.923561
# Unit test for function matchpathcon
def test_matchpathcon():
    # This test requires selinux-policy-devel which is not in the default RHEL 8 installation
    # This test should be skipped if selinux-policy-devel is not installed
    try:
        rc, con = matchpathcon('/bin/sh', 0)
    except Exception:
        con = None
    assert con == '(dev_t=chr_file, type=unconfined_t)'
    assert isinstance(con, str)



# Generated at 2022-06-11 01:53:34.888742
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/hosts', 0)
    print('rc: %s' % rc)
    print('con: %s' % con)
    (rc, con) = matchpathcon('/dev/null', 0)
    print('rc: %s' % rc)
    print('con: %s' % con)

# Generated at 2022-06-11 01:53:42.825165
# Unit test for function matchpathcon
def test_matchpathcon():
    test_list = [
        {
            'description': 'success case',
            'path': '/mnt/mountpoint',
            'mode': os.R_OK,
            'expected': True
        },
        {
            'description': 'wrong mode',
            'path': '/mnt/mountpoint',
            'mode': 0x0,
            'expected': False
        },
        {
            'description': 'non existing path',
            'path': '/mnt/nonexistent',
            'mode': os.R_OK,
            'expected': False
        },
        {
            'description': 'path too long',
            'path': 'a' * 256,
            'mode': os.R_OK,
            'expected': False
        },
    ]
    for item in test_list:
        out = match

# Generated at 2022-06-11 01:53:49.836700
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''Testing lgetfilecon_raw'''

    # Begin test_lgetfilecon_raw

    # Test case 1
    # Create a log directory
    logdir = '/tmp/log'
    if not os.path.isdir(logdir):
        os.mkdir(logdir)
    # Get the context of the directory
    rc, logdir_con = lgetfilecon_raw(logdir)
    # Check if context of the directory is getting properly
    if rc == -1:
        raise Exception('Error getting context of %s' % logdir)
    # Make sure the context of the directory is root:object_r:var_log_t:s0

# Generated at 2022-06-11 01:53:56.313760
# Unit test for function matchpathcon
def test_matchpathcon():
    path = './test_dir_1/test_file_1'
    mode = os.R_OK
    try:
        rc, con = matchpathcon(path, mode)
        assert rc == 0
        assert con == "unconfined_u:object_r:default_t"
    except Exception as e:
        print(e)
        raise


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:53:59.580251
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Return type from the function lgetfilecon_raw is [int,str]
    :return:
    """
    __context__.source = 'selinux'
    return 0


# Generated at 2022-06-11 01:54:06.561610
# Unit test for function matchpathcon
def test_matchpathcon():
    if not isinstance(__file__, str):
        return
    if not os.path.exists(__file__):
        return
    try:
        rc, con = matchpathcon(__file__, 0)
    except OSError as e:
        if e.errno in (1, 13):
            return
        raise
    if rc:
        raise Exception('matchpathcon exitcode failure: {0}'.format(rc))
    if not con:
        raise Exception('matchpathcon con failure: {0}'.format(con))
    print('matchpathcon success: {0}'.format(con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:54:17.806619
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def _fake_lgetfilecon_raw(path, con):
        rc = 0 if path == b'lgetfilecon_raw' else -1
        if rc == 0:
            if con:
                con.contents.value = b'system_u:object_r:ssh_home_t:s0'
        else:
            get_errno.errno = 1
        return rc

    old_lgetfilecon_raw = _selinux_lib.lgetfilecon_raw
    _selinux_lib.lgetfilecon_raw = _fake_lgetfilecon_raw

# Generated at 2022-06-11 01:54:22.889966
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    with tempfile.NamedTemporaryFile() as temp_file:
        temp_file_name = temp_file.name

        (rc, con) = lgetfilecon_raw(temp_file_name)
        assert rc == 0
        assert con[0] == 'u'
        assert con[1] == ':'



# Generated at 2022-06-11 01:54:25.138165
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, result = lgetfilecon_raw(b"/etc/hosts")
    assert rc == 0
    assert result.startswith(b"system_u:object_r:etc_t:s0")


# Generated at 2022-06-11 01:54:32.218796
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp', 0) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/etc/shadow', 0) == [0, 'system_u:object_r:shadow_t:s0']
    assert matchpathcon('/usr/bin/foo', 0) == [0, 'system_u:object_r:unlabeled_t:s0']
    assert matchpathcon('/usr/bin/python3', 0) == [0, 'system_u:object_r:unlabeled_t:s0']

# Generated at 2022-06-11 01:54:35.857300
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/modprobe.d/distmodprobe.conf', 1)
    if rc != 0:
        raise Exception('matchpathcon(): rc is not 0, error: ' + str(rc))

# Generated at 2022-06-11 01:54:45.463407
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import json

    path = b"/etc/shadow"
    [rc, con] = lgetfilecon_raw(path)
    if rc != 0:
        print('No SELinux context for', path)
    else:
        print('Path:', path)
        print('Context:', con)
        ctx = json.loads(con)
        print('User:', ctx['user'])
        print('Role:', ctx['role'])
        print('Type:', ctx['type'])
        print('Level:', ctx['level'])


# Generated at 2022-06-11 01:54:52.058815
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/') == [0, b'unconfined_u:object_r:root_t:s0']
    assert lgetfilecon_raw(b'/dev/null') == [0, b'unconfined_u:object_r:chr_file_t:s0']
    assert lgetfilecon_raw(b'/non/existent') == [-1, None]



# Generated at 2022-06-11 01:54:57.436194
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = os.stat("/usr/bin/top").st_mode
    print("/usr/bin/top mode is:",mode)
    [rc, con] = matchpathcon("/usr/bin/top", mode)
    if rc == -1:
        print("error in matchpathcon")
    else:
        print("/usr/bin/top context is:",con)

# Generated at 2022-06-11 01:55:01.929776
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/hello'
    f = open(path, 'wb')
    f.close()
    try:
        rc, con = lgetfilecon_raw(path)
        assert type(con) == str
    finally:
        os.remove(path)



# Generated at 2022-06-11 01:55:07.194376
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fp = None
    try:
        path = "/tmp/test_selinux"
        fp = open(path, 'w')
        fp.write("Test")
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'unconfined_u:object_r:user_tmp_t:s0'
    finally:
        if fp is not None:
            fp.close()
            os.unlink(path)

# Generated at 2022-06-11 01:55:13.558305
# Unit test for function matchpathcon
def test_matchpathcon():
    print("selinux_python test_matchpathcon")
    path = "/etc/hosts"
    mode = 0
    con = matchpathcon(path, mode)
    print("Matchpathcon is expected to return: 'system_u:object_r:etc_t:s0'")
    print("Matchpathcon returned: %s" % con[1])
    if (con[1] == 'system_u:object_r:etc_t:s0'):
        print("Test passed")
    else:
        print("Test failed")

if __name__ == "__main__":
    test_matchpathcon()


# Generated at 2022-06-11 01:55:17.205123
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    testfile = tempfile.mkstemp()[1]

    try:
        os.unlink(testfile)
    except OSError:
        pass

    open(testfile, 'a').close()

    rc, context = lgetfilecon_raw(testfile)
    assert rc == 0  # rc == 0 mean success
    assert context.startswith('unconfined_u:object_r:user_home_t:')

    os.unlink(testfile)

# Generated at 2022-06-11 01:55:23.414721
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Unit test for function lgetfilecon_raw.
    """
    filename = "/etc/passwd"
    rc, err = lgetfilecon_raw(filename)
    if rc == 0:
        print("{0} context is: {1}".format(filename, err))
    else:
        print("{0} context is not available".format(filename))



# Generated at 2022-06-11 01:55:33.734038
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "./path"
    # Create directory
    try:
        os.mkdir(path)
    except OSError as e:
        print(e)
        raise

# Generated at 2022-06-11 01:55:36.317577
# Unit test for function matchpathcon
def test_matchpathcon():
    # Passing /etc/passwd to this function should return
    # 0: matched label etc_t
    assert matchpathcon('/etc/passwd', 0) == [0, 'etc_t']

# Generated at 2022-06-11 01:55:42.271357
# Unit test for function matchpathcon
def test_matchpathcon():
    r1, r2 = matchpathcon('/tmp/example', 0)
    assert r1 == 0
    assert r2 == 'system_u:object_r:tmp_t:s0'

    r1, r2 = matchpathcon('/some/invalid/path', 0)
    assert r1 == -1

# Generated at 2022-06-11 01:55:52.005270
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Example of testing lgetfilecon_raw function"""
    test_dir = os.path.dirname(os.path.realpath(__file__))
    # We should change context of the file to be able to read it back

# Generated at 2022-06-11 01:55:55.535423
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    dn = tempfile.mkdtemp()
    try:
        # test with a process context that doesn't match path context
        [rc, con] = matchpathcon(dn, 0)
        assert rc == -1
        assert con == ''
    finally:
        import shutil
        shutil.rmtree(dn)



# Generated at 2022-06-11 01:55:58.219321
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/home/testuser/test.txt', 0) == [0, 'user_home_t:file']



# Generated at 2022-06-11 01:56:02.051029
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, val = lgetfilecon_raw('/usr/bin/id')
    print(val)
    rc, val = lgetfilecon_raw('/selinux/should/not/exist')
    print(val)

# Generated at 2022-06-11 01:56:06.902741
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/tmp/testpath'
    rc, con = matchpathcon(test_path, os.R_OK)
    if rc == 0:
        print ('[matchpathcon] matchpathcon for {}: {}'.format(test_path, con))
    else:
        print ('[matchpathcon] failed matching context for {}: {}'.format(test_path, rc))



# Generated at 2022-06-11 01:56:17.644254
# Unit test for function matchpathcon

# Generated at 2022-06-11 01:56:24.002700
# Unit test for function matchpathcon
def test_matchpathcon():
    if security_getenforce():
        # Check that the following paths are not labeled with unlabeled_t.
        # These tests are only valid when SELinux is enabled and in enforcing mode.
        # If the matchpathcon function returns an error it does not get to the part
        # where it checks the label for unlabeled_t.
        # The 2nd test fails.
        result = matchpathcon(b'/home', os.F_OK)
        if result[0] != 0:
            assert False, 'matchpathcon failed: {0}'.format(result)
        assert 'unlabeled_t' not in result[1]

        result = matchpathcon(b'/var', os.F_OK)
        if result[0] != 0:
            assert False, 'matchpathcon failed: {0}'.format(result)

# Generated at 2022-06-11 01:56:26.492923
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:rootfs:s0']


# Generated at 2022-06-11 01:56:29.674629
# Unit test for function matchpathcon
def test_matchpathcon():
    import pytest
    rc, con = matchpathcon("/usr", 0)
    assert isinstance(rc, int)
    assert isinstance(con, str)
    assert rc == 0
    assert con == "usr_t"


# Generated at 2022-06-11 01:56:41.637564
# Unit test for function matchpathcon
def test_matchpathcon():
    def do_pathcon_test(path, mode, expected_results):
        result = matchpathcon(path, mode)
        if result != expected_results:
            raise AssertionError('matchpathcon(%r, %r) returned %r, expected %r' % (path, mode, result, expected_results))

    # these are hard-coded relative to the current dir

    # if selinux is not enabled, the context returned is None
    if not is_selinux_enabled():
        do_pathcon_test(b'./foo/bar', 0, [0, None])

    # standard behavior for selinux

# Generated at 2022-06-11 01:56:46.126233
# Unit test for function matchpathcon
def test_matchpathcon():
    # function returns a list and a string
    assert(isinstance(matchpathcon('/', 0), list))
    assert(isinstance(matchpathcon('/', 0)[0], int))
    assert(isinstance(matchpathcon('/', 0)[1], str))



# Generated at 2022-06-11 01:56:55.128695
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon function
    """
    path = sys.executable
    mode = os.R_OK | os.W_OK

    rc, context = matchpathcon(path, mode)
    if rc != 0:
        print("Failed to get SELinux context. "
              "Return code '{}', error '{}'".format(rc, os.strerror(rc)))
        return

    print("SELinux context of the file '{}' is: {}".format(
        path, context
    ))
    print("Security information of '{}' is: {}".format(
        path, os.stat(path, follow_symlinks=False)
    ))


# This allows us to unit test the function in standalone mode
if __name__ == '__main__':
    test_matchpath

# Generated at 2022-06-11 01:57:00.272297
# Unit test for function matchpathcon
def test_matchpathcon():
    ret, con = matchpathcon(b'/tmp/test.txt', os.R_OK)
    if ret == 0:
        print('SELinux Context for path /tmp/test.txt is {}'.format(con))
    else:
        print('Failed to get SELinux Context for path /tmp/test.txt')

# Generated at 2022-06-11 01:57:04.015368
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    b = lgetfilecon_raw(b'/etc/passwd')
    print(b)
    assert b[0] == 0
    assert b[1] == 'unconfined_u:object_r:etc_t:s0'

# Generated at 2022-06-11 01:57:08.742332
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/resolv.conf'
    result = lgetfilecon_raw(path)
    assert(result[0] >= 0)
    assert(result[1] == 'system_u:object_r:net_conf_t:s0')


# Generated at 2022-06-11 01:57:10.428772
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon("/", 0)
    return (rc, con)

# Generated at 2022-06-11 01:57:16.024693
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        # TODO: How can I get this to work on a non-Linux machine
        rc, con = lgetfilecon_raw("/bin/ls")
        assert rc == 0
        assert con == "system_u:object_r:blah_t:s0"
    except Exception as e:
        print("Exception occurred {}".format(str(e)))



# Generated at 2022-06-11 01:57:26.411686
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('/etc/passwd', 0)
    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:passwd_file_t:s0'
    ret = matchpathcon('/etc/passwd.invalid', 0)
    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:default_t:s0'
    ret = matchpathcon('/etc/passwd.huh', 0)
    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:default_t:s0'
    ret = matchpathcon('/usr/bin/passwd', 0)
    assert ret[0] == 0

# Generated at 2022-06-11 01:57:31.158445
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/usr/bin/python'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0, "Error in getting context for path: %s" % path
    assert con is not None, "Expected not none for matching context for path: %s" % path


# Generated at 2022-06-11 01:57:39.832924
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/etc/shadow')
    if rc != 0:
        raise AssertionError('lgetfilecon_raw failed ({0})'.format(to_native(os.strerror(rc))))
    if not con.startswith(b'unconfined_u:object_r:shadow_t:'):
        raise AssertionError('expected result did not match for lgetfilecon_raw: "{0}"'.format(con))


# Generated at 2022-06-11 01:57:46.095807
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    retvalue = lgetfilecon_raw('/')
    assert retvalue == [0, 'system_u:object_r:root_t:s0']
    retvalue = lgetfilecon_raw('/etc')
    assert retvalue == [0, 'system_u:object_r:etc_t:s0']
    retvalue = lgetfilecon_raw('/etc/selinux')
    assert retvalue == [0, 'system_u:object_r:selinux_etc_t:s0']
    # test invalid path
    retvalue = lgetfilecon_raw('/this/path/does/not/exist')
    assert retvalue == [-1, 'ENOENT: No such file or directory']


# Generated at 2022-06-11 01:57:48.924718
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon(b'/etc/shadow', 0)
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'

# Generated at 2022-06-11 01:57:55.328981
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    tempdir = tempfile.mkdtemp(prefix='ansible-selinux-test.')
    test_file = os.path.join(tempdir, "test")
    try:
        rc, con = lgetfilecon_raw(test_file)
        assert rc == 0
        assert con == "system_u:object_r:user_home_dir_t:s0"
    finally:
        os.unlink(test_file)
        os.rmdir(tempdir)

# Generated at 2022-06-11 01:57:59.593993
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert isinstance(lgetfilecon_raw('/etc/passwd'), list)
    assert isinstance(lgetfilecon_raw('/etc/passwd')[0], type(0))
    assert isinstance(lgetfilecon_raw('/etc/passwd')[1], type(''))

# Generated at 2022-06-11 01:58:08.708592
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/a.conf', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/etc/a.conf', 1) == [0, 'system_u:object_r:etc_t:s0']
    assert matchpathcon('/etc', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/', 0) == [0, 'system_u:object_r:root_t:s0']
    assert matchpathcon('/', 1) == [0, 'system_u:object_r:root_t:s0']

# Generated at 2022-06-11 01:58:13.210129
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = '/etc/shadow'
    rc, con = lgetfilecon_raw(file_path)
    assert rc == 0
    assert isinstance(con, str)


# Generated at 2022-06-11 01:58:14.981301
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/home/test/file_test', 0))



# Generated at 2022-06-11 01:58:17.121799
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-11 01:58:22.262305
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/selinux/targeted/contexts/users/role/system_r', 0) == [0, 'system_u:object_r:system_conf_t:s0']
    assert lgetfilecon_raw('/etc/selinux/targeted/contexts/users/role/system_r') == [0, 'system_u:object_r:system_conf_t:s0']



# Generated at 2022-06-11 01:58:27.631628
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/test', 0)
    print(rc, con)


if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-11 01:58:37.838432
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # if this test fails, you should run "sudo touch /test_file000; sudo chcon -t etc_t /test_file000"
    expected_rc, expected_con = [0, 'unconfined_u:object_r:etc_t:s0']
    test_file = '/test_file000'
    rc, con = lgetfilecon_raw(test_file)
    assert rc == expected_rc, 'lgetfilecon_raw return value is "%s", should be "%s".  %s' % (str(rc), str(expected_rc), test_file)
    assert con == expected_con, 'lgetfilecon_raw context is "%s", should be "%s".  File: %s' % (con, expected_con, test_file)


# Generated at 2022-06-11 01:58:39.882244
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-11 01:58:42.047963
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/bin/python', 0) == [0, 'unconfined_u:object_r:user_home_t:s0']


# Generated at 2022-06-11 01:58:45.490188
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon(b'/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-11 01:58:54.898913
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing function 'lgetfilecon_raw' with path: {0}".format("/tmp/test"))

    rc, con = lgetfilecon_raw("/tmp/test")

    if rc < 0 and rc != -2:
        print("Error: %d" % rc)
        print("Error Message: %s" % os.strerror(abs(rc)))

    print("Return Code: %d" % rc)
    print("Context: %s" % con)

    print("Testing function 'matchpathcon' with path: {0}".format("/tmp/test"))

    rc, con = matchpathcon("/tmp/test", 0)

    if rc < 0 and rc != -2:
        print("Error: %d" % rc)

# Generated at 2022-06-11 01:58:57.401838
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc', 0)
    # A real path should yield no error and a context value
    assert rc == 0 and con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-11 01:59:03.308531
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test the case where the file exists
    path = os.path.abspath(__file__)
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is None or con.startswith("unconfined_u:")
    # Test the case where the file doesn't exists
    path = os.path.abspath(__file__) + "foo"
    rc, con = lgetfilecon_raw(path)
    assert rc != 0
    assert con is None


# Generated at 2022-06-11 01:59:07.481009
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/dev/null"
    [rc, con] = lgetfilecon_raw(path)
    if rc < 0:
        raise Exception("lgetfilecon_raw for " + path + " failed with return code " + str(rc))


# Generated at 2022-06-11 01:59:16.168288
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, selabel = matchpathcon('/etc/shadow', 0)
    assert rc == 0
    assert selabel == 'shadow_t'
    # TODO: test error handling
    rc, selabel = matchpathcon('/etc/shadow', 0)
    assert rc == 0
    assert selabel == 'shadow_t'
    # TODO: test error handling
    rc, selabel = matchpathcon('/etc/shadow', 0)
    assert rc == 0
    assert selabel == 'shadow_t'
    # TODO: test error handling
    rc, selabel = matchpathcon('/etc/shadow', 0)
    assert rc == 0
    assert selabel == 'shadow_t'


# Generated at 2022-06-11 01:59:27.313370
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import os
    import stat

    tmpdir = tempfile.mkdtemp()
    print(tmpdir)
    open(tmpdir + "/examplefile", "w").close()

    def getfilecon(f):
        st = os.stat(f)
        lgetfilecon_raw(f)
        return matchpathcon(f, stat.S_IFMT(st.st_mode))

    print(getfilecon(tmpdir + "/examplefile"))

# Generated at 2022-06-11 01:59:36.595315
# Unit test for function matchpathcon
def test_matchpathcon():
    """ function matchpathcon should return a tuple of (rc, con) where rc is the returncode and con is the context
    """
    # the return code should be 0
    assert matchpathcon('/etc/passwd', 0)[0] == 0
    # the context should be system_u:object_r:passwd_file_t:s0
    assert matchpathcon('/etc/passwd', 0)[1] == 'system_u:object_r:passwd_file_t:s0'
    # the return code should be 0
    assert matchpathcon('/etc/', 0)[0] == 0
    # the context should be system_u:object_r:etc_t:s0
    assert matchpathcon('/etc/', 0)[1] == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-11 01:59:43.997833
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test lgetfilecon_raw, a wrapper function around libselinux.lgetfilecon_raw().
    If this test fails attempting to load the libselinux module, double check
    that libselinux.so.1 is installed and in the library load path. If it still
    fails, it is likely that your libselinux.so.1 and header files are mismatched.
    """
    # TODO: unit test to ensure that we can call the wrapped function
    # Additional unit test to ensure that we can call the wrapped function
    assert lgetfilecon_raw('/etc/passwd')[0] == 0

# Generated at 2022-06-11 01:59:48.050515
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = "selinux/test_file.txt"
    with open(test_path, 'w') as fd:
        fd.write('Hello, world!\n')
    path, con = lgetfilecon_raw(test_path)
    assert con != '<<none>>'
    os.remove(test_path)



# Generated at 2022-06-11 01:59:53.156406
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import json
    test_file = "test/libselinux_test/test_file"
    rc, result = lgetfilecon_raw(test_file)
    assert rc == 0
    assert result == "system_u:object_r:libselinux_test_t:s0"


# Generated at 2022-06-11 01:59:57.596422
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from pathlib import Path
    new_file = Path("new_file.txt")
    new_file.touch()
    rc = lgetfilecon_raw("new_file.txt")
    assert rc[0] == 0, "function 'lgetfilecon_raw' returned non-zero rc: {}".format(rc)
    new_file.unlink()

# Generated at 2022-06-11 01:59:59.433260
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test to get file context for path"""
    assert len(lgetfilecon_raw('/etc/hosts')) == 2


# Generated at 2022-06-11 02:00:01.162314
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/ansible/ansible.cfg"
    rc, result = lgetfilecon_raw(path)
    assert result == "unconfined_u:object_r:ansible_config_t:s0"

# Generated at 2022-06-11 02:00:04.279189
# Unit test for function matchpathcon
def test_matchpathcon():
    if is_selinux_enabled():
        result = matchpathcon('/etc/passwd', 0)
        assert result[0] == 0
        assert result[1] == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-11 02:00:10.009189
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/etc/selinux/config'
    test_mode = 0o000
    rc, con = matchpathcon(test_path, test_mode)
    print("rc: {}".format(rc))
    print("con: {}".format(con))

    assert rc == 0
    assert con == "system_u:object_r:selinux_config_t:s0"

if __name__ == '__main__':
    test_matchpathcon()
    print("matchpathcon unit tests passed!")

# Generated at 2022-06-11 02:00:25.494640
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test selinux module with the function matchpathcon
    """
    rc, con = matchpathcon('/var/log/audit', 0)

    if rc != 0:
        print('[failed] matchpathcon failed to find a context: {0}', to_native(os.strerror(rc)))
        sys.exit(1)

    assert con == 'system_u:object_r:var_log_t:s0'

    rc, con = matchpathcon('/var/log/audit/audit.log', 0)

    if rc != 0:
        print('[failed] matchpathcon failed to find a context: {0}', to_native(os.strerror(rc)))
        sys.exit(1)


# Generated at 2022-06-11 02:00:30.558347
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = b"/tmp/testfile"
    with open(to_native(test_file), "w") as f:
        f.write("This is a test")

    assert isinstance(lgetfilecon_raw(test_file), list)
    rc, val = lgetfilecon_raw(test_file)
    assert rc == 0
    assert isinstance(val, str)
    assert val == "unconfined_u:object_r:user_tmp_t:s0"

    os.unlink(to_native(test_file))



# Generated at 2022-06-11 02:00:35.425770
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not os.path.exists('/etc/selinux'):
        print('Unable to test lgetfilecon_raw: /etc/selinux does not exist')
        return

    rc, con = lgetfilecon_raw('/etc/selinux')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-11 02:00:39.632636
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, output = lgetfilecon_raw(b'/etc/passwd')
    if rc == -1:
        print('An error occured')
    else:
        print('The context of /etc/passwd is %s' % output)

if __name__ == '__main__':
    test_lgetfilecon_raw()