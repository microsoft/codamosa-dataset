

# Generated at 2022-06-11 01:50:44.647639
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    test_path = os.path.join(tempfile.gettempdir(), 'test_file')
    try:
        rc = lgetfilecon_raw(test_path)
    except OSError as err:
        # We are expecting Errno 2 No such file or directory
        if err.errno == 2:
            return
    # Raise an error if we didn't catch the OSError 2
    raise Exception('lgetfilecon_raw did not return the expected OSError 2')


# Generated at 2022-06-11 01:50:47.318439
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw("/etc/passwd")
    assert result[0] < 0

# Generated at 2022-06-11 01:50:52.294804
# Unit test for function matchpathcon
def test_matchpathcon():
    path = to_bytes('/tmp/test/file.txt')
    mode = to_bytes('666')
    try:
        _selinux_lib.matchpathcon(path, mode, byref(mode))
    except OSError as e:
        assert e.errno == -22
    else:
        assert False
    return True

# Generated at 2022-06-11 01:50:56.560664
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    status, con = lgetfilecon_raw('/etc/passwd')
    assert status == 0 and con == 'system_u:object_r:etc_t:s0'

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:51:06.339913
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import os
    import selinux

    try:
        tempdir = tempfile.mkdtemp()
        tempcon = "[temp_t]"
        res = selinux.lsetfilecon(tempdir, tempcon)
        assert res == 0
        tmppath = tempdir + "/a"
        os.mknod(tmppath)
        res, con = selinux.matchpathcon(tmppath, selinux.X_OK)
        assert res == 0
        res, con = selinux.matchpathcon(tempdir, selinux.X_OK)
        assert res == 0
    finally:
        os.remove(tmppath)
        os.rmdir(tempdir)

# Generated at 2022-06-11 01:51:13.721294
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # create test file
    with open('/tmp/test_file', 'w') as fd:
        print(fd.name)

    SELINUX_LABEL = "system_u:object_r:tmp_t:s0"
    lscon = lgetfilecon_raw(b'/tmp/test_file')
    assert lscon == [0, SELINUX_LABEL]

    # we need to remove the test file
    os.remove('/tmp/test_file')

# Generated at 2022-06-11 01:51:20.285956
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Unit tests for matchpathcon
    :return:
    """
    rule_path = '/etc/selinux/targeted/contexts/files'
    path = '/etc/selinux/targeted/contexts/files/file_contexts'
    rc, context = matchpathcon(path, 1)
    assert rc == 0
    assert context == 'system_u:object_r:etc_runtime_t:s0'
    rc, context = matchpathcon(rule_path, 1)
    assert rc == 2
    assert context == ''

# Generated at 2022-06-11 01:51:32.000663
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        _selinux_lib.lgetfilecon_raw
    except:
        raise Exception("Undefined function lgetfilecon_raw in _selinux_lib")

    rc, con = lgetfilecon_raw(b'/etc/hosts')
    assert rc == 0
    assert 'system_u:object_r:etc_t:s0' in con
    rc, con = lgetfilecon_raw(b'/dev/zero')
    assert rc == 0
    assert 'system_u:object_r:zero_device_t:s0' in con
    rc, con = lgetfilecon_raw(b'/dev/tty')
    assert rc == 0
    assert 'system_u:object_r:unlabeled_t:s0' in con
    rc, con = lgetfilecon_raw

# Generated at 2022-06-11 01:51:37.684287
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # create a file to get its context
    f = open('test_selinux.txt', 'w+')
    f.write('test_selinux')

    rc, ctx = lgetfilecon_raw('test_selinux.txt')
    assert rc == 0
    assert ctx != ''
    print(ctx)

    f.close()
    os.remove('test_selinux.txt')


# Generated at 2022-06-11 01:51:39.632274
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw('/')
    print('lgetfilecon_raw', ret)



# Generated at 2022-06-11 01:51:43.962198
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, pathcon = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert pathcon == 'system_u:object_r:unlabeled_t:s0'

# Generated at 2022-06-11 01:51:48.553224
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    #  If this test fails, verify that the file listed here
    #  e.g. /etc/passwd
    #  has a valid selinux context assigned
    #
    #  To get a file's default selinux security context, try running:
    #  $ sudo semanage fcontext -l | grep /etc/passwd
    # 
    fn = "/etc/passwd"
    (rc, con) = lgetfilecon_raw(fn)
    assert rc == 0
    assert con is not None

# Generated at 2022-06-11 01:51:52.460781
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create namespace to test function matchpathcon
    rc, con = matchpathcon('/etc/rc.local', os.R_OK)
    print(rc)
    print(con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:51:55.702918
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, output = matchpathcon(b'/var/lib/libvirt', 0)
    assert rc == 0
    assert output.startswith('system_u:object_r:lib_t:s0')



# Generated at 2022-06-11 01:52:01.958437
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_name = '/etc/shadow'
    """
    Test on RHEL 8.2
    rc, con = lgetfilecon_raw(file_name)
    assert rc == 0
    assert con == "system_u:object_r:shadow_t:s0"

    rc, con = lgetfilecon_raw("/tmp/file_not_exist")
    assert rc == -1
    assert con == None
    """



# Generated at 2022-06-11 01:52:07.524928
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print('>>> test_lgetfilecon_raw: ', end='')
    path = '/etc'
    rc, context = lgetfilecon_raw(path)

    if rc == 0 and context:
        print('PASS')
    else:
        print('FAIL')



# Generated at 2022-06-11 01:52:16.711815
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def check_con(path, ctx):
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == ctx

    check_con('/etc/passwd', 'system_u:object_r:etc_runtime_t:s0')
    check_con('/etc/shadow', 'system_u:object_r:shadow_t:s0')
    check_con('/etc/gshadow', 'system_u:object_r:shadow_t:s0')
    check_con('/etc/hosts', 'system_u:object_r:hosts_file_t:s0')
    check_con('/etc/hostname', 'system_u:object_r:net_conf_t:s0')

# Generated at 2022-06-11 01:52:18.149540
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: create test for function matchpathcon
    pass

# Generated at 2022-06-11 01:52:20.061332
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, pathcon = matchpathcon(b'/', 0)
    if rc < 0:
        raise ImportError('unable to run test_matchpathcon')
    print('{0}:{1}'.format(rc, to_native(pathcon)))

# Generated at 2022-06-11 01:52:23.772877
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp/foo"
    mode = os.stat(path).st_mode
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    if rc == 0:
        print("con=%s" % (to_native(con.value)))
    else:
        print("error=%s" % (os.strerror(-rc)))


# Generated at 2022-06-11 01:52:28.484937
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/var/tmp', 0)
    assert rc == 0
    assert con == 'var_tmp_t'



# Generated at 2022-06-11 01:52:36.722204
# Unit test for function matchpathcon
def test_matchpathcon():

    assert os.path.exists('/proc/mounts')
    [rc, con] = matchpathcon('/proc/mounts', 0)
    assert rc == 0, 'matchpathcon succeded'
    assert con == 'system_u:object_r:proc_mounts_t:s0', 'matchpathcon returned the correct context'

    [rc, con] = matchpathcon('/proc/mountsss', 0)
    assert rc != 0, 'matchpathcon failed'
    assert con is None, 'matchpathcon failed and returned the correct context'

    [rc, con] = matchpathcon('/', 0)
    assert rc == 0, 'matchpathcon succeded'
    assert con == 'system_u:object_r:root_t:s0', 'matchpathcon returned the correct context'

# Generated at 2022-06-11 01:52:40.286103
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """ Dummy unit test to check that lgetfilecon_raw is working """
    assert lgetfilecon_raw(__file__) == [0, 'system_u:object_r:initrc_exec_t:s0']

# Generated at 2022-06-11 01:52:42.618002
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/root')
    assert result[0] == 0
    assert result[1] is not None


# Generated at 2022-06-11 01:52:51.358423
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible_collections.community.general.tests.unit.compat import mock

    path = "foo_bar"
    con = "system_u:object_r:foo_bar_t:s0"
    err = 0

    with mock.patch.object(
        _selinux_lib, 'lgetfilecon_raw',
        return_value=[err, con]
    ) as mock_lgetfilecon_raw:
        module = selinux_getfilecon_raw(path)
        mock_lgetfilecon_raw.assert_called_once_with(path)
        assert module == [err, con]



# Generated at 2022-06-11 01:52:54.520460
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/dev/pts/ptmx')
    assert rc == 0
    assert con.startswith('system_u:object_r:devpts_ptmx_device_t:')

# Generated at 2022-06-11 01:53:05.651772
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # SELINUX is disabled
    if not is_selinux_enabled():
        return

    # SELinux is enabled
    assert is_selinux_enabled() == 1

    # SELinux is not in enabled in permissive mode
    assert selinux_getenforcemode()[1] != 'Permissive'

    # If /var/log/secure is present continue with testing
    if os.path.isfile('/var/log/secure'):
        # SELinux policy is targeted
        assert selinux_getpolicytype()[1] == 'targeted'

        # SELinux security_getenforce() is enabled and it should return 1
        assert security_getenforce() == 1

        # SELinux security_policyvers() should return 24
        assert security_policyvers() == 24

        #

# Generated at 2022-06-11 01:53:09.867854
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    [rc, con] = matchpathcon('/proc', 0)
    assert rc == 0
    assert con == 'system_u:object_r:proc_t:s0'


# Generated at 2022-06-11 01:53:13.445153
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    (rc, con) = lgetfilecon_raw(b"/")
    print(rc)
    print(con)


# Generated at 2022-06-11 01:53:24.349833
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    In order to verify the function is not broken, run it against the library
    test_matchpathcon() is the test function.
    """

    if not (is_selinux_enabled() and not is_selinux_mls_enabled()):
        print("INFO: SELinux seems not in permissive or enforcing mode, skip unit test")
        return

    # This is a usecase to verify there is no error
    # from library function matchpathcon
    # the return value is the security context
    # in the test environment, I have redhat 7.4 with selinux permissive
    # for different environment, the security context will be different
    # especially for MLS
    rc, con = matchpathcon('/sys/cgroup', 0)
    print("con={0}".format(con))
    assert rc == 0

# Generated at 2022-06-11 01:53:31.821872
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/foo/bar/baz'
    mode = os.R_OK
    (rc, con) = matchpathcon(path, mode)
    assert(rc == 0)



# Generated at 2022-06-11 01:53:40.849058
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_con_list = list()

    file_con_list.append(lgetfilecon_raw('/')[1])
    file_con_list.append(lgetfilecon_raw('/usr')[1])
    file_con_list.append(lgetfilecon_raw('/usr/bin')[1])
    file_con_list.append(lgetfilecon_raw('/usr/share/man')[1])
    file_con_list.append(lgetfilecon_raw('/usr/share/man/man1')[1])
    file_con_list.append(lgetfilecon_raw('/etc')[1])
    file_con_list.append(lgetfilecon_raw('/etc/cron.d')[1])

# Generated at 2022-06-11 01:53:44.737401
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert to_native(lgetfilecon_raw('/tmp')[1]) == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-11 01:53:48.141134
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test lgetfilecon_raw"""
    rc, con = lgetfilecon_raw(b'/proc')
    assert rc == 0
    assert con == b'system_u:object_r:proc_t:s0'



# Generated at 2022-06-11 01:53:55.978807
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def _test_lgetfilecon_raw(src):
        path = os.path.join(os.path.dirname(__file__), src)
        rc, con = lgetfilecon_raw(path)
        if rc < 0:
            errno = get_errno()
            raise OSError(errno, os.strerror(errno))
        return con

    assert _test_lgetfilecon_raw('test_selinux_module_setup.py') == 'system_u:object_r:ansible_module_t:s0'

# Generated at 2022-06-11 01:54:04.373137
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This test depends on a correct setup of the test system.
    # Test case: Python code calls lgetfilecon_raw on a file that is labeled by a
    #             SELinux policy and there is no error in the Python wrapper
    file_path = "/var/log/ansible.log"
    result = lgetfilecon_raw(file_path)
    assert type(result) == list
    assert len(result) == 2
    assert type(result[0]) == int
    assert result[0] == 0
    assert type(result[1]) == str
    assert result[1] == "system_u:object_r:var_log_t:s0"

# Generated at 2022-06-11 01:54:09.958255
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test case 1: mode = 0, path = "/tmp"
    assert matchpathcon(b"/tmp", 0) == [0, b'unconfined_u:object_r:tmp_t:s0']

    # Test case 2: mode = 0, path = "/root"
    assert matchpathcon(b"/root", 0) == [0, b'unconfined_u:object_r:admin_home_t:s0']

# Generated at 2022-06-11 01:54:18.120458
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.utils.path import unfrackpath

    con_list = lgetfilecon_raw(unfrackpath("/bin/ls"))[1]
    if con_list == b"system_u:object_r:bin_t:s0":
        return True
    else:
        return False


if __name__ == '__main__':
    if not test_lgetfilecon_raw():
        sys.stderr.write("test_lgetfilecon_raw failed\n")
        sys.exit(1)

# Generated at 2022-06-11 01:54:21.719359
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/'
    exp_con = b'unlabeled_t'

    got_con = lgetfilecon_raw(path)
    assert(got_con[1] == exp_con)



# Generated at 2022-06-11 01:54:32.266132
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import subprocess

    # Create test files
    file1 = "/tmp/file1"
    file2 = "/tmp/file2"
    with open(file1, "w"):
        pass
    with open(file2, "w"):
        pass

    # Test for current context
    con1 = lgetfilecon_raw(file1)[1]
    con2 = lgetfilecon_raw(file2)[1]

    # Test restorecon
    cmd = ["/sbin/restorecon", file1]
    rc = subprocess.call(cmd)
    con3 = lgetfilecon_raw(file1)[1]

    # Test setfilecon
    cmd = ["/usr/bin/chcon", con2, file2]
    rc = subprocess.call(cmd)
    con4 = lgetfilecon

# Generated at 2022-06-11 01:54:48.921888
# Unit test for function matchpathcon
def test_matchpathcon():
    data = matchpathcon('/etc/selinux/config', 0)
    assert data == [0, 'system_u:object_r:etc_t:s0']


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == '--test':
        print('running unit tests')
        for name in sorted(dir()):
            if name.startswith('test_'):
                print('running {0}...'.format(name))
                globals()[name]()
        print('done')
        sys.exit()

    print('available functions: {0}'.format(', '.join(sorted(dir()))))

# Generated at 2022-06-11 01:54:51.308812
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/etc/selinux/config')
    assert result[0] == 0



# Generated at 2022-06-11 01:54:59.743289
# Unit test for function matchpathcon
def test_matchpathcon():
    err_list = (
        (ENOENT, 'No such file or directory'),
        (EINVAL, 'Invalid argument'),
        (EACCES, 'Permission denied'),
    )
    for errno, strerror in err_list:
        err = OSError(errno, strerror)
        try:
            matchpathcon('/etc/shadow', 0)
        except OSError as e:
            assert e.args[0] == err.args[0]
            assert e.args[1] == err.args[1]



# Generated at 2022-06-11 01:55:01.978449
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd') == (0, 'system_u:object_r:etc_t:s0')

# Generated at 2022-06-11 01:55:07.224195
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/dev/kmsg', 0)
    if rc != 0:
        raise Exception("matchpathcon() returned %d" % (rc,))

    if not con:
        raise Exception("matchpathcon() returned no context")

    print("'%s'" % (con,))
    if con != 'system_u:object_r:dmesg_t:s0':
        raise Exception("matchpathcon() returned bad context")

# Generated at 2022-06-11 01:55:14.475873
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    class File(object):
        def __init__(self):
            self.name = '/tmp/test_file'
            self.file = open(self.name, 'a')
            self.file.close()

        def __enter__(self):
            return self

        def __exit__(self, type, value, traceback):
            os.remove(self.name)

    with File() as f:
        con = lgetfilecon_raw(f.name)
        assert con[0] == 0
        assert con[1] is not None

    con = lgetfilecon_raw('/this/file/should/not/be/here')
    assert con[0] == -1, 'Expected non-zero return code for invalid path'
    assert con[1] is None


# Generated at 2022-06-11 01:55:19.258607
# Unit test for function matchpathcon
def test_matchpathcon():
    from os.path import dirname, join
    from tempfile import gettempdir
    from shutil import rmtree
    from ansible.module_utils.selinux import matchpathcon

    test_file = join(gettempdir(), 'file_%s' % next(tempfile._get_candidate_names()))
    test_dir = join(gettempdir(), 'dir_%s' % next(tempfile._get_candidate_names()))

    # Create test files
    open(test_file, 'a').close()
    os.makedirs(test_dir)

    rc, con = matchpathcon(test_file, os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:file_t:s0'


# Generated at 2022-06-11 01:55:24.837069
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/tmp/testfile', 0)
    assert res[0] == 0, 'Error generating context for path'


# Generated at 2022-06-11 01:55:29.326808
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/shadow"
    rc, con = lgetfilecon_raw(path)
    if rc < 0:
        print("error calling lgetfilecon_raw: ", os.strerror(rc))
    else:
        print("context for " + path + " is " + con)


# Generated at 2022-06-11 01:55:34.495332
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = os.R_OK
    conlist = matchpathcon(path, mode)
    rc = conlist[0]
    con = conlist[1]
    # If a file does not contain a context, matchpathcon will return 0
    # and an empty context, which means the source context is unconfined.
    assert rc == 0 and con == ""


# Generated at 2022-06-11 01:55:56.707889
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert rc == 0, "lgetfilecon_raw failed with rc {} (expected 0)".format(rc)
    assert con == "system_u:object_r:root_t:s0", "lgetfilecon_raw returned wrong context ({}) (expected system_u:object_r:root_t:s0)".format(con)
    rc, con = lgetfilecon_raw('/dev')
    assert rc == 0, "lgetfilecon_raw failed with rc {} (expected 0)".format(rc)
    assert con == "system_u:object_r:dev_t:s0", "lgetfilecon_raw returned wrong context ({}) (expected system_u:object_r:dev_t:s0)".format(con)
    rc, con

# Generated at 2022-06-11 01:56:03.590816
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        test_result = matchpathcon("/etc/shadow", 0)
        assert test_result[0] == 0
        # On some systems (e.g. Fedora 32-64)
        # TODO: fix selinux_utils to remove the following line.
        assert test_result[1] == "system_u:object_r:shadow_t:s0"
    except AttributeError:
        pass

# Generated at 2022-06-11 01:56:10.235113
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/passwd')
    assert rc == 0, 'error in lgetfilecon_raw: %d' % rc
    assert con == 'system_u:object_r:etc_runtime_t:s0'
    assert con == lgetfilecon_raw('/etc/passwd')[1]
    assert con == lgetfilecon_raw(b'/etc/passwd')[1]
    assert con != lgetfilecon_raw('/etc/')[1]
    assert con != lgetfilecon_raw('/etc')[1]
    assert con != lgetfilecon_raw('/')[1]
    (rc, con) = lgetfilecon_raw('/etc/')

# Generated at 2022-06-11 01:56:13.407078
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = 0o777

    [rc, con] = matchpathcon('/etc/shadow', mode)
    assert rc >= 0
    assert con == 'system_u:object_r:shadow_t:s0'

# Generated at 2022-06-11 01:56:15.743430
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/dev/null') == [0, 'system_u:object_r:null_device_t:s0']

# Generated at 2022-06-11 01:56:23.241522
# Unit test for function matchpathcon
def test_matchpathcon():
    import shutil
    import tempfile
    import pytest

    selinux_contexts = {
        'selinuxfs': '/selinux',
        'gidmin': '500',
        'usermax': '500',
        'disablenonblock': '1',
        'policy_url': 'file:/etc/selinux/policy/policy.32',
        'permissive': '0',
        'level': 's0',
        'minimum': '0',
        'policytype': 'strict',
        'mls': '0',
        'gidtarget': 'targeted',
        'autorelabel': '1',
        'targeted': '1',
        'enforcing': '1',
        'usrtarget': 'targeted',
        'usermin': '500',
    }


# Generated at 2022-06-11 01:56:26.146686
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']


# Generated at 2022-06-11 01:56:31.936283
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("tests/test_selinux.py")
    assert rc == 0, "fail to call selinux function lgetfilecon_raw()"
    assert con == "system_u:object_r:ansible_managed_tmp_t:s0", "context of test_selinux.py is not ansible_managed_tmp_t"


# Generated at 2022-06-11 01:56:40.103285
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    import filecmp
    import shutil

    test_file = tempfile.mkstemp()[1]

    with open(test_file, 'w') as f:
        f.write("Testing")

    con = lgetfilecon_raw(test_file)[1]

    shutil.copyfile(test_file, test_file + ".copy")

    lsetfilecon(test_file + ".copy", con)

    assert filecmp.cmp(test_file, test_file + ".copy") == True

    os.remove(test_file)
    os.remove(test_file + ".copy")

# Generated at 2022-06-11 01:56:50.830023
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import sys
    import tempfile

    if sys.version_info[0] == 2:
        from cStringIO import StringIO
    else:
        from io import StringIO

    # Redirect stdout so we can grab the output of the matchpathcon call
    # We'll use the output to set the file context for the temporary file we're
    # about to create
    try:
        orig_stdout = sys.stdout
        sys.stdout = stdout = StringIO()
        matchpathcon('/tmp', os.R_OK | os.W_OK)
        con = stdout.getvalue().strip()
    finally:
        sys.stdout = orig_stdout

    (fd, filename) = tempfile.mkstemp()

# Generated at 2022-06-11 01:57:25.910815
# Unit test for function matchpathcon
def test_matchpathcon():
    ''' Test matchpathcon function '''
    path = "/tmp"
    mode = 0
    [rc, con] = matchpathcon(path, mode)
    print("matchpathcon({}, {}) = [{}, {}]".format(path, mode, rc, con))
    return



# Generated at 2022-06-11 01:57:29.774976
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/hosts'
    if os.path.isfile(path):
        rc, con = lgetfilecon_raw(path)
    else:
        rc = con = 0
    assert rc.__class__ is int
    assert con.__class__ is str
    return

# Generated at 2022-06-11 01:57:35.459104
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/foo/bar', 0)
    assert rc == 0
    assert con is not None

    [rc, con] = matchpathcon('/foo/barx', 0)
    assert rc == 1

    [rc, con] = matchpathcon('/foo/bar', 1073741824)
    assert rc == 0
    assert con is not None

    [rc, con] = matchpathcon('/foo/barx', 1073741824)
    assert rc == 1

# Generated at 2022-06-11 01:57:44.233314
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test against unix-like file system
    test_path = '/foo/bar'
    test_mode = 0o644
    con = matchpathcon(test_path, test_mode)
    # Con must be "bar_t"
    if con[1] != 'bar_t':
        return False
    # Creation of a file must succeed
    try:
        with open(test_path, 'w') as f:
            f.write('test')
    except Exception as e:
        return False
    # Check the context
    con = lgetfilecon_raw(test_path)
    # Con must be "bar_t"
    if con[1] != 'bar_t':
        return False
    # Clean up
    remove(test_path)
    return True

# Generated at 2022-06-11 01:57:49.482725
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    path = "/etc/passwd"
    statinfo = os.stat(path)
    # we will not deal with the case when selinux is not enabled
    assert is_selinux_enabled() == 1
    # if selinux is enabled, the return code should be zero
    assert lgetfilecon_raw(path)[0] == 0

# Generated at 2022-06-11 01:57:51.637953
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r = lgetfilecon_raw('/usr')
    assert isinstance(r, list)



# Generated at 2022-06-11 01:57:54.719397
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/usr/bin/python")
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_home_t:s0'



# Generated at 2022-06-11 01:57:57.192465
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/usr/bin/id")
    if rc != 0:
        raise Exception("Unexpected: lgetfilecon_raw(\"/usr/bin/id\") returned %d" % (rc))
    print("lgetfilecon_raw(\"/usr/bin/id\") returned [%d, \"%s\"]" % (rc, con))


# Generated at 2022-06-11 01:58:04.907257
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, "test")
    path_context = matchpathcon(tempdir, os.R_OK)[1]
    lsetfilecon(tempdir, path_context)
    file_context = matchpathcon(filename, os.R_OK)[1]
    lsetfilecon(filename, file_context)
    os.remove(filename)
    os.rmdir(tempdir)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:58:11.919584
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test that when a file is specified as an argument and it exists
    # lgetfilecon_raw should return 0 and a context string.
    path = "/etc/passwd"
    for res in lgetfilecon_raw(path):
        assert res == 0
    for res in lgetfilecon_raw(path):
        assert isinstance(res, str)

    # Test that when a file is specified as an argument and it does not exist
    # lgetfilecon_raw should return -1 and None.
    path = "/non/existing/path"
    for res in lgetfilecon_raw(path):
        assert res == -1
    for res in lgetfilecon_raw(path):
        assert not res

    # Test that if NULL is passed as an argument lgetfilecon_raw should
    # return -1 and None.

# Generated at 2022-06-11 01:59:24.781933
# Unit test for function matchpathcon
def test_matchpathcon():
    import sys
    path = sys.argv[1]
    mode = int(sys.argv[2])
    rc, con = matchpathcon(path, mode)
    print(con)

# Generated at 2022-06-11 01:59:27.090189
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    (rc, con) = lgetfilecon_raw('/etc/ssh/sshd_config')
    module.exit_json(rc=rc, con=con)



# Generated at 2022-06-11 01:59:29.756666
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/test/test.txt"
    import stat
    mode = stat.S_IFDIR | 0o777
    con = matchpathcon(path, mode)
    print(con)



# Generated at 2022-06-11 01:59:38.314242
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/var/empty', 0)
    assert rc == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'

    [rc, con] = matchpathcon('/var/empty', 1)
    assert rc == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'

    [rc, con] = matchpathcon('/var/empty', 2)
    assert rc == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'

    [rc, con] = matchpathcon('/var/empty', 3)
    assert rc == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'


# Generated at 2022-06-11 01:59:44.659025
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os

    cwd = os.getcwd()
    fname = '/selinux/access'
    path = os.path.join(cwd, fname)
    _selinux_lib.open(path, os.O_RDWR | os.O_CREAT, int('0755', 8))

    rc, con = lgetfilecon_raw(fname)
    assert rc == 0

    # Verify that the initialized context is the context of the parent directory
    assert con == 'system_u:object_r:filesystem_t:s0'



# Generated at 2022-06-11 01:59:48.121981
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Give any valid file path, it should retun a proper selinux context
    filename = "/etc/passwd"
    rc, con = lgetfilecon_raw(filename)
    assert rc == 0
    assert "system_u:object_r:passwd_t:s0" in con


# Generated at 2022-06-11 01:59:58.155502
# Unit test for function matchpathcon
def test_matchpathcon():
    import selinux
    testfile = "./testfile"
    fp = open(testfile, "wb")
    fp.close()
    os.chmod(testfile, 0o777)
    rc = 0
    try:
        mode = selinux.matchpathcon.MODE_OUT
        rc = selinux.matchpathcon(testfile, mode)[0]
        if rc != -1:
            raise "Failed to match path context"
        mode = selinux.matchpathcon.MODE_IGNORE
        rc = selinux.matchpathcon(testfile, mode)[0]
    except:
        pass
    finally:
        os.remove(testfile)


if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-11 02:00:06.209659
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/sys/devices/pci0000:00/0000:00:1a.0/usb1/1-2', 0)
    assert rc == 0
    assert con == 'system_u:object_r:usb_device_t:s0'

    rc, con = matchpathcon('/sys/devices/pci0000:00/0000:00:1a.0/usb1', 0)
    assert rc == 0
    assert con == 'system_u:object_r:usb_device_t:s0'

    rc, con = matchpathcon('/sys/devices/pci0000:00/0000:00:1a.0', 0)
    assert rc == 0
    assert con == 'system_u:object_r:usb_device_t:s0'

    rc, con = match

# Generated at 2022-06-11 02:00:09.966191
# Unit test for function matchpathcon
def test_matchpathcon():
    if is_selinux_enabled():
        rc, con1 = matchpathcon(b"/etc/selinux/", 0)
        rc, con2 = matchpathcon(b"/etc/selinux/config", 1)
        assert rc == 0
        assert con1 == con2

# Generated at 2022-06-11 02:00:12.256129
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for valid path
    rc, con = matchpathcon('/usr/bin/ls', 0)
    if rc != 0:
        raise Exception("Unexpected error {0}".format(rc))
    if con != 'system_u:object_r:bin_t:s0':
        raise Exception("Unexpected context {0}".format(con))


if __name__ == "__main__":
    test_matchpathcon()