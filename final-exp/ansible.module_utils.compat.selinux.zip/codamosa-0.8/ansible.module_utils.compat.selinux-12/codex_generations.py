

# Generated at 2022-06-11 01:50:44.280430
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # should get a non None value
    assert lgetfilecon_raw('/') != None

    # should get an error as path is not a string
    try:
        assert lgetfilecon_raw(1) == None
    except OSError as e:
        assert e.errno == 22  # 22: Invalid argument

    # should get an error as path does not exist
    try:
        assert lgetfilecon_raw('/foo/1') == None
    except OSError as e:
        assert e.errno == 2  # 2: No such file or directory

# Generated at 2022-06-11 01:50:48.196377
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    fcon = lgetfilecon_raw(path)
    print("Path: {0}, Context: {1}".format(path, fcon))


# Generated at 2022-06-11 01:50:56.994675
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec={
        },
        supports_check_mode=True,
    )

    result = {}

    result['path'] = '/etc/selinux/targeted/contexts/users/local'
    status, selinux_context = matchpathcon(result['path'], 0)
    result['status'] = status
    result['selinux_context'] = selinux_context

    module.exit_json(**result)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:51:00.019993
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/sys/fs/cgroup")[0:2] == [0, "system_u:object_r:cgroup_t:s0"]

# Generated at 2022-06-11 01:51:03.875100
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/group')
    print(rc, con)
    assert 0 == rc and 'system_u:object_r:etc_runtime_t:s0' == con, "lgetfilecon_raw failed"

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:51:10.508459
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if os.path.isfile('/etc/os-release'):
        rc, con = lgetfilecon_raw('/etc/os-release')
        assert rc == 0
        assert con != 'unlabeled'
    else:
        rc, con = lgetfilecon_raw('/')
        assert rc == 0
        assert con != 'unlabeled'


# Generated at 2022-06-11 01:51:14.975160
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    for path in ['/', '/etc/passwd']:
        rc, con = lgetfilecon_raw(path)
        assert isinstance(con, str), "Return type must be string"
        assert rc == 0, "Return code must be 0"


# Generated at 2022-06-11 01:51:18.405553
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon("/etc/passwd", 0)
    if rc == 0:
        print("/etc/passwd: " + con)
    else:
        print("Error in matchpathcon")


# Generated at 2022-06-11 01:51:30.063840
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Unit test for lgetfilecon_raw, testing if return type and return value is correct.
    """
    import tempfile

    tmp_filename = tempfile.mkstemp()[1]
    rc, con = lgetfilecon_raw(tmp_filename)
    if rc == -1:
        result = "Failed to get security context of file {0}. Error {1}".format(tmp_filename, con)
    else:
        result = "Security context of file {0} is {1}".format(tmp_filename, con)

    os.remove(tmp_filename)
    return_val = to_native(result)
    return isinstance(return_val, str) and return_val.startswith("Security context of file")



# Generated at 2022-06-11 01:51:36.785463
# Unit test for function matchpathcon
def test_matchpathcon():
    from tempfile import mkstemp
    from os import fdopen, close, path

    # create a temp file to test matchpathcon
    handle, filename = mkstemp()
    f = fdopen(handle, "w")
    f.close()
    close(handle)

    # run test
    rc, con = matchpathcon(filename, 0)

    # check result
    if rc < 0:
        raise OSError(rc, 'matchpathcon failed')
    if not path.exists(filename):
        raise IOError('matchpathcon deleted the file')

    # cleanup
    os.unlink(filename)

# Generated at 2022-06-11 01:51:44.821952
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, context_string = lgetfilecon_raw('/etc/hosts')
    assert rc == 0, \
        "lgetfilecon_raw failed with return code: {0}".format(rc)
    assert context_string == 'system_u:object_r:net_conf_t:s0', \
        "lgetfilecon_raw failed with unexpected context_string: {0}".format(context_string)



# Generated at 2022-06-11 01:51:51.040209
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test for normal call
    rc, stdout = lgetfilecon_raw(b'/etc/passwd')
    assert rc == 0
    assert stdout

    # Test for exception
    rc, stdout = lgetfilecon_raw(b'/etc/passwd_foobar')
    assert rc == -1
    assert stdout == ''



# Generated at 2022-06-11 01:51:54.780671
# Unit test for function matchpathcon
def test_matchpathcon():
    print("--- matchpathcon ---")
    print("lgetfilecon_raw:", lgetfilecon_raw("/tmp"))
    print("matchpathcon:", matchpathcon("/tmp", os.R_OK))
    print("selinux_getpolicytype:", selinux_getpolicytype())

# Generated at 2022-06-11 01:52:03.541720
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    from shutil import rmtree
    my_temp_dir = tempfile.mkdtemp()
    try:
        my_temp_file = os.path.join(my_temp_dir, 'test_file')
        with open(my_temp_file, 'a'):
            pass
        my_file_con = lgetfilecon_raw(my_temp_file)[1]
        assert my_file_con
        my_dir_con = lgetfilecon_raw(my_temp_dir)[1]
        assert my_dir_con
    finally:
        rmtree(my_temp_dir, ignore_errors=True)

# Generated at 2022-06-11 01:52:09.257370
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = to_bytes(os.path.realpath(__file__))
    path_rc, path_con = lgetfilecon_raw(path)
    assert path_rc == 0
    assert path_con == b"unconfined_u:object_r:usr_t:s0"

# Generated at 2022-06-11 01:52:12.988092
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing matchpathcon")
    assert matchpathcon("/sys/block/sda/sda1", os.stat("/sys/block/sda/sda1").st_mode)[0] == 0



# Generated at 2022-06-11 01:52:23.408401
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    for path in ['/etc/profile', '/tmp/doesntexist', '/root/doesntexist']:
        print('Testing lgetfilecon: {0}'.format(path))
        [rc, con] = lgetfilecon_raw(path)
        print('rc: {0}, context: {1}'.format(rc, con))

    for path in ['/etc/profile', '/tmp/doesntexist', '/root/doesntexist']:
        print('Testing matchpathcon: {0}'.format(path))
        [rc, con] = matchpathcon(path, os.R_OK)
        print('rc: {0}, context: {1}'.format(rc, con))

    print('Test write/delete of file in tmp dir')
    tmp_dir = tempfile.Temporary

# Generated at 2022-06-11 01:52:33.788530
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    test = tempfile.mkdtemp()
    os.makedirs(os.path.join(test, "etc"))
    os.makedirs(os.path.join(test, "etc", "selinux"))

# Generated at 2022-06-11 01:52:37.112375
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    _ans = lgetfilecon_raw('/var/log/ansible.log')
    assert _ans[0] == 0 and _ans[1] == 'system_u:object_r:var_log_t:s0'



# Generated at 2022-06-11 01:52:44.188624
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    p = "/etc/hosts"
    rc, con = lgetfilecon_raw(p)
    if rc < 0:
        print("lgetfilecon on %s failed with: %s" % (p, str(os.strerror(rc))))
    elif con is None:
        print("lgetfilecon on %s succeeded with: %s" % (p, str(None)))
    else:
        print("lgetfilecon on %s succeeded with: %s" % (p, con.decode()))



# Generated at 2022-06-11 01:52:53.692873
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.selinux import matchpathcon, lgetfilecon_raw, is_selinux_mls_enabled
    (rc, _) = matchpathcon(os.path.realpath(__file__), 0)
    assert rc == 0
    (rc, _) = lgetfilecon_raw(os.path.realpath(__file__))
    assert rc == 0
    assert is_selinux_mls_enabled() == 0

# Generated at 2022-06-11 01:52:58.535108
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test normal case
    rc, con = matchpathcon(b"/test", 0)
    assert rc == 0
    assert con == "system_u:object_r:test_file_t:s0"

    # Test an invalid path
    rc, con = matchpathcon(b"/invalid", 0)
    assert rc == -1

# Generated at 2022-06-11 01:53:08.141437
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import stat
    import tempfile
    from ctypes import c_char_p
    # Create a temp file and make sure the context of the tempfile is
    # the default context of the machine
    fd, tmpfile = tempfile.mkstemp()
    _selinux_lib.fsetfilecon(fd, c_char_p("unconfined_u:object_r:user_tmp_t:s0"))
    os.close(fd)
    assert os.path.exists(tmpfile)
    os.chown(tmpfile, -1, -1)
    os.chmod(tmpfile, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXG)
    rc, con = matchpathcon(tmpfile, 0)

# Generated at 2022-06-11 01:53:12.210640
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = "/tmp"
    ret = lgetfilecon_raw(file_path)
    assert ret[0] == 0, "return value"
    assert isinstance(ret[1], str), "return type"


# Generated at 2022-06-11 01:53:16.318323
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/tmp/something'

    rc, old_con = matchpathcon(test_path, 0)
    assert rc == 0

    rc, new_con = matchpathcon(test_path, 1)
    assert rc == 0

    rc = lsetfilecon(test_path, old_con)
    assert rc == 0



# Generated at 2022-06-11 01:53:24.446325
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    data_path = os.path.dirname(os.path.abspath(__file__)) + '/../../../lib/ansible/module_utils/selinux.py'
    rc, label = lgetfilecon_raw(data_path)
    assert rc == 0
    assert label == 'unconfined_u:object_r:usr_t:s0'
    rc, label = lgetfilecon_raw(data_path + "missing_file")
    assert rc == -1
    assert label == None


# Generated at 2022-06-11 01:53:27.974754
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/usr/bin/python')
    assert result[0] == 0
    assert result[1] == 'unconfined_u:object_r:usr_t:s0'



# Generated at 2022-06-11 01:53:31.585283
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        [rc, con] = matchpathcon('/etc/passwd', 0)
        assert(rc == 0)
        assert(con)
    except:
        return 1
    return 0


# Generated at 2022-06-11 01:53:34.689289
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp'
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert con == "system_u:object_r:tmp_t", con



# Generated at 2022-06-11 01:53:42.307173
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/some/path'
    con = 'unconfined_u:object_r:user_tmp_t:s0'
    _selinux_lib.lgetfilecon_raw.return_value = 0
    _selinux_lib.lgetfilecon_raw.argtypes = [c_char_p, POINTER(c_char_p)]
    _selinux_lib.lgetfilecon_raw.side_effect = lambda *args: (con, args[1])
    _selinux_lib.freecon.argtypes = [c_char_p]
    _selinux_lib.freecon.side_effect = lambda *args: (None,)
    results = lgetfilecon_raw(path)
    assert results == [0, con]


# Generated at 2022-06-11 01:53:50.716233
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    >>> from ansible.module_utils.selinux import lgetfilecon_raw
    >>> (rc, con) = lgetfilecon_raw('/etc/shadow')
    >>> con
    '/etc/shadow system_u:object_r:shadow_t:s0'
    >>> (rc, con) = lgetfilecon_raw('/etc/shadow_invalid_path')
    >>> con
    None
    >>> rc
    -1
    """
    pass



# Generated at 2022-06-11 01:53:55.678789
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # /etc/selinux/config should have context label 'system_u:object_r:etc_t:s0'
    label = lgetfilecon_raw('/etc/selinux/config')[1]
    assert label == "system_u:object_r:etc_t:s0"

# Generated at 2022-06-11 01:53:58.911771
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-11 01:54:06.855585
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test 1: check if context of "/etc/passwd" is "system_u:object_r:etc_t:s0"
    result = lgetfilecon_raw("/etc/passwd")
    if result[0] == -1:
        # fail the test and print the error message
        raise OSError(result[0], os.strerror(result[0]))
    # pass the test
    if result[1] == "system_u:object_r:etc_t:s0":
        pass

    # Test 2: check if context of "/home/sda" is "system_u:object_r:user_home_dir_t:s0"
    result = lgetfilecon_raw("/home/sda")
    if result[0] == -1:
        raise OSError

# Generated at 2022-06-11 01:54:11.272717
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/testfile'
    with open(path, 'a'):
        pass
    ret, context = matchpathcon(path, 0)
    os.remove(path)
    assert ret == 0
    assert context == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-11 01:54:21.014777
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/log/audit/audit.log"
    mode = 0o600

    # is the file at path in a place where we can set selinux
    # context?
    enforcemode, enforcemode_val = selinux_getenforcemode()
    if enforcemode < 0:
        raise RuntimeError("Unable to determine SELinux enforcing mode")

    if enforcemode_val == 1 and matchpathcon(path, mode)[0] > 0:
        raise RuntimeError("Unable to determine SELinux context for path")

    # is this policy type supported?
    rc, policy_type = selinux_getpolicytype()
    if rc < 0:
        raise RuntimeError("Unable to determine SELinux policy type")


# Generated at 2022-06-11 01:54:25.779135
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/tmp", os.R_OK) == [0, "system_u:object_r:tmp_t:s0"]
    assert matchpathcon("/somepath", os.R_OK) == [0, "system_u:object_r:default_t:s0"]



# Generated at 2022-06-11 01:54:32.077023
# Unit test for function matchpathcon
def test_matchpathcon():
    from core import Fs
    test_file_paths = ['/etc/passwdd', '/var/tmp', '/some/non/existent/path']
    for test_file_path in test_file_paths:
        if Fs.exists(test_file_path):
            result = matchpathcon(test_file_path, 0)
            if result[0] != 0:
                raise Exception("Test: matchpathcon, Error calling matchpathcon for input file: " + str(test_file_path) + " error: " + str(result[1]))
            else:
                print("Test: matchpathcon, File: " + str(test_file_path) + " Security context: " + str(result[1]))

# Generated at 2022-06-11 01:54:35.331624
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        x = lgetfilecon_raw("/tmp/foo.txt")

    except Exception as e:
        print(e)

    assert x[0] == 0



# Generated at 2022-06-11 01:54:40.906732
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    >>> lgetfilecon_raw('/etc/selinux/config')
    [0, 'system_u:object_r:etc_runtime_t:s0']
    '''
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    sys.exit(0)

# Generated at 2022-06-11 01:54:52.966000
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        (rc, con) = matchpathcon("/home/selinux/yml/test/defautl_t.txt", 384)
        if rc == 0:
            print("SELinux context for /home/selinux/yml/test/defautl_t.txt is: " + con)
        else:
            print("SELinux context for /home/selinux/yml/test/defautl_t.txt get failed with return code: " + str(rc))
    except OSError as e:
        raise OSError("Failure while trying to get SELinux context for /home/selinux/yml/test/defautl_t.txt by matchpathcon")


# Generated at 2022-06-11 01:55:00.203871
# Unit test for function matchpathcon
def test_matchpathcon():
    if selinux_getenforcemode()[1]:
        print("SELinux is enabled - will proceed with test")
        print("SELinux policy type: " + selinux_getpolicytype()[1])
        test_matchpathcon_result = matchpathcon("/etc/hosts", 0)
        print("Test output: " + test_matchpathcon_result[1])

if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-11 01:55:06.680964
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/sbin/init')
    assert rc == 0
    assert con is not None
    rc, con = lgetfilecon_raw('/invalid/path')
    assert rc == -1
    assert con is None
    rc, con = lgetfilecon_raw(b'/sbin/init')
    assert rc == 0
    assert con is not None
    rc, con = lgetfilecon_raw(b'/invalid/path')
    assert rc == -1
    assert con is None


# Generated at 2022-06-11 01:55:09.829230
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw("/etc/passwd")
    print("rc is: " + str(rc))
    print("con is : " + str(con))



# Generated at 2022-06-11 01:55:11.191776
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw("/proc")
    assert rc == 0
    assert con is not None

# Generated at 2022-06-11 01:55:17.991450
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    testpath = "/etc/group"
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(testpath, byref(con))
    assert rc == 0
    assert isinstance(con.value, bytes)
    assert to_native(con.value) == 'system_u:object_r:etc_runtime_t:s0'


# Generated at 2022-06-11 01:55:20.726627
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, msg = lgetfilecon_raw('/')
    assert rc == 0, msg
    assert 'system_u' in msg, msg



# Generated at 2022-06-11 01:55:23.671246
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc', 0)
    assert rc == 0, 'Return code is not zero'
    assert con == 'etc_t', 'No match found'

# Generated at 2022-06-11 01:55:26.034515
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/file"
    result = lgetfilecon_raw(path)
    assert result is not None


# Generated at 2022-06-11 01:55:28.952929
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    print(lgetfilecon_raw('/')[1])



# Generated at 2022-06-11 01:55:34.946727
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # The path has a label with an invalid context
    path = "/proc/sys/fs/binfmt_misc/register"
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert isinstance(con, str)

# Generated at 2022-06-11 01:55:41.083407
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.realpath('/etc/passwd')
    answer = [0, b'unconfined_u:object_r:user_home_t:s0']
    if 'linux' in sys.platform:
        result = lgetfilecon_raw(path)
        if result != answer:
            raise AssertionError('lgetfilecon_raw failed: result was {0} expected {1}'.format(result, answer))
        else:
            print('Test has successfully passed')


# unit test for function matchpathcon

# Generated at 2022-06-11 01:55:43.844787
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/usr/bin/vim', 0)
    assert rc == 0
    assert con == "system_u:object_r:usr_t:s0"


# Generated at 2022-06-11 01:55:46.774235
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/etc/passwd'
    rc, con = lgetfilecon_raw(test_path)

    assert isinstance(con, str)
    assert len(con) > 0



# Generated at 2022-06-11 01:55:53.020459
# Unit test for function matchpathcon
def test_matchpathcon():
    if 'test_matchpathcon' in globals():
        print('Skipping unit test for libselinux')
        return
    if not _selinux_lib:
        print('Skipping unit test for libselinux')
        return

    file_path = b'/etc/password'
    (rc, result) = matchpathcon(file_path, 0)
    assert rc == 0, 'Test matchpathcon Failed'
    assert result, 'Test matchpathcon Failed'



# Generated at 2022-06-11 01:55:58.117338
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/proc/1/exe'
    mode = os.R_OK
    rc, context = matchpathcon(path, mode)
    # This file is readable by everyone
    assert context == 'system_u:object_r:unlabeled_t:s0'
    assert rc == 0



# Generated at 2022-06-11 01:56:07.685023
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import stat

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-11 01:56:11.048335
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con_type = matchpathcon("/etc/passwd", 0)
    assert rc == 0
    assert con_type.startswith("system_u:object_r:shadow_t:s0")



# Generated at 2022-06-11 01:56:18.938829
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fn = '.test_lgetfilecon_raw'

    # Ensure test file does not exist
    os.system("rm -f {0}".format(fn))

    # Create test file
    fh = open(fn, 'wb')
    fh.write('Hello World')
    fh.close()

    assert lgetfilecon_raw(fn)[1] == 'system_u:object_r:unlabeled_t:s0\0'

    # Cleanup
    os.system("rm -f {0}".format(fn))



# Generated at 2022-06-11 01:56:19.646224
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon('/', 0)

# Generated at 2022-06-11 01:56:28.228942
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import stat
    import os

    path = '/etc/mtab'
    mode = stat.S_IFREG | 0o444

    rc, con = lgetfilecon_raw(path)
    assert rc == 0, "lgetfilecon_raw() Failed. rc=%s errno=%s" % (rc, os.strerror(rc))
    assert con == "system_u:object_r:mtab_t:s0", "lgetfiklecon_raw() did not return expected value for %s" % path



# Generated at 2022-06-11 01:56:37.982479
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # First test a file whose context we expect to be system_u:object_r:etc_t:s0 - the policy for the /etc configuration
    # directory.
    rc, con = lgetfilecon_raw('/etc/fstab')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'
    # Now test for a file we expect not to exist.
    rc, con = lgetfilecon_raw('/etc/idonotexist')
    assert rc == -1
    # We expect rc == -1 and the exception set to ENOENT
    assert errno.errorcode[get_errno()] == 'ENOENT'

# Generated at 2022-06-11 01:56:41.211475
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/selinux/config'
    mode = 0
    result = matchpathcon(path, mode)
    expected = [0, 'system_u:object_r:etc_t:s0']
    assert result == expected



# Generated at 2022-06-11 01:56:46.170869
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon("/home/testuser", 0)
    print("\nFunction matchpathcon return code: " + str(ret[0]) + 
          "\nFunction matchpathcon value: " + str(ret[1]))

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:56:52.717215
# Unit test for function matchpathcon
def test_matchpathcon():
    _path = "/var/log/elasticsearch"
    try:
        rc, con = matchpathcon(_path, os.R_OK)
        if rc == -1:
            print("matchpathcon failed: {}".format(matchpathcon.__name__))
        else:
            print("matchpathcon successful: {}".format(con))

    except OSError as e:
        print("matchpathcon failed: error {}".format(e.errno))
        sys.exit(rc)

# Generated at 2022-06-11 01:56:55.916676
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    (rc, con) = lgetfilecon_raw('/')
    assert rc == 0 and con is not None, 'lgetfilecon_raw error'

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:57:01.244028
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/var/log/audit'
    [rc, con] = lgetfilecon_raw(path)
    assert rc == 1, 'unexpected rc value: {0}'.format(rc)
    assert con == 'system_u:object_r:auditd_log_t:s0', 'unexpected context: {0}'.format(con)



# Generated at 2022-06-11 01:57:12.094503
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import sys
    import unittest

    from ansible.module_utils.common.text.converters import to_bytes

    myjoin = os.path.join

    # Dynamic paths
    pwd = to_native(os.popen('pwd').read().rstrip())
    tmpdir = os.path.basename(pwd)
    tmpdir = 'tmp' if tmpdir == 'module_utils' else myjoin('module_utils', tmpdir)
    tmpdir = myjoin('/tmp', tmpdir)
    systmpdir = '/tmp'

    thisfile = sys.argv[0]
    thisfile = os.path.abspath(thisfile)

    def _check(path, expected_con):
        rc, actual_con = matchpathcon(path, 0)

# Generated at 2022-06-11 01:57:16.117953
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon("/foo", 0)
    assert result[0] == 0
    assert result[1] == "system_u:object_r:foo_root_t:s0"



# Generated at 2022-06-11 01:57:25.299506
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    from ansible.module_utils.six import PY3

    TEST_FILE = 'test_file'

    if PY3:
        f = open(TEST_FILE, 'w')
    else:
        f = open(TEST_FILE, 'w')

    f.close()

    rc, con = matchpathcon(TEST_FILE, 0)
    os.remove(TEST_FILE)
    if rc != 0:
        raise AssertionError(
            'matchpathcon failed with rc {0} and err {1}'.format(rc, con)
        )



# Generated at 2022-06-11 01:57:31.371930
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def _test_lgetfilecon_raw(filename):
        assert lgetfilecon_raw(filename)[1] is not None

    _test_lgetfilecon_raw("/dev/null")
    _test_lgetfilecon_raw("/")



# Generated at 2022-06-11 01:57:34.752833
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = to_bytes("/tmp/ansible_selinux_lgetfilecon_raw")
    # Create test file
    open(test_path, "w").close()
    try:
        # Test whether the above function works
        assert lgetfilecon_raw(test_path) is not None
    finally:
        # Remove test file
        os.remove(test_path)

# Generated at 2022-06-11 01:57:43.975444
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = b'give path'
    test_mode = 1
    test_pmode = 2
    test_con = b'give context'
    test_pcon = b'give parent context'

    def mock_matchpathcon(path, mode, pcon):
        assert path == test_path
        assert mode == test_mode
        assert pcon.value == test_pcon
        return 0

    _selinux_lib.matchpathcon = mock_matchpathcon
    con = c_char_p(test_con)
    rc = test_matchpathcon(test_path, test_mode, byref(con))
    assert rc == 0
    assert con.value == test_con
    _selinux_lib.matchpathcon = mock_matchpathcon

# Generated at 2022-06-11 01:57:46.804537
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/var/lib/libvirt/images/test.img', 0)
    return [rc, con]

# Generated at 2022-06-11 01:57:52.921673
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test SELinux mode enforcing
    rc, con = matchpathcon('/tmp', os.R_OK)
    assert rc == -1 and con == 'Invalid argument'

    rc, mode = selinux_getenforcemode()
    assert rc == 0
    assert mode == 1

    # Test SELinux mode permissive
    rc, con = matchpathcon('/tmp', os.R_OK)
    assert rc == 0



# Generated at 2022-06-11 01:57:53.894838
# Unit test for function matchpathcon
def test_matchpathcon():
    return _selinux_lib.matchpathcon(b"/test",0,None)

# Generated at 2022-06-11 01:57:56.575916
# Unit test for function matchpathcon
def test_matchpathcon():
    # Run matchpathcon and check that the code rc is zero
    # This will test that selinux was loaded and it has the matchpathcon function.
    # This will also test if matchpathcon can be called and if selinux is disabled.s
    rc, message = matchpathcon('/etc/selinux/config', 0)
    assert rc == 0

# Generated at 2022-06-11 01:58:05.031851
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test sym-linked dir
    # If a relative symlink links to a parent directory,
    # dir_fd must not be relative to its parent directory.
    # It must be set to the directory containing the symlink.
    if os.path.exists('/tmp/test_matchpathcon'):
        os.rmdir('/tmp/test_matchpathcon')

    os.mkdir('/tmp/test_matchpathcon')
    os.symlink('../test_matchpathcon/subdir', '/tmp/test_matchpathcon/subdir')

    assert matchpathcon('/tmp/test_matchpathcon/subdir', 0)[0] == 0

# Generated at 2022-06-11 01:58:11.978614
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import re
    import subprocess

    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.selinux_utils import lgetfilecon_raw

    if not is_selinux_enabled():
        return

    homedir = to_bytes(os.environ['HOME'])

    # test file
    test_file = os.path.join(homedir, '.ansible.test.file')
    if not os.path.exists(test_file):
        with open(test_file, 'w') as f:
            f.write('test')

    test_dir = os.path.join(homedir, '.ansible.test.dir')

# Generated at 2022-06-11 01:58:16.778133
# Unit test for function matchpathcon
def test_matchpathcon():
    path = 'test_file'
    mode = 0o770
    [rc, con] = matchpathcon(path, mode)
    if rc != 0:
        print('ERROR: matchpathcon %s %s failed' % (path, oct(mode)))
        sys.exit(1)
    print('con %s %s %s' % (path, oct(mode), con))


# Generated at 2022-06-11 01:58:21.933627
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/') == [0, 'system_u:object_r:root_t:s0']

# Generated at 2022-06-11 01:58:25.337492
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    rc, con = lgetfilecon_raw(to_bytes(path))
    assert rc == 0
    assert con == "system_u:object_r:etc_t"



# Generated at 2022-06-11 01:58:27.892324
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/home/foo', None)
    print('matchpathcon returned {0} with context {1}'.format(rc, con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:58:30.332892
# Unit test for function matchpathcon
def test_matchpathcon():
    con = matchpathcon('/tmp', 0)
    print(con)
    return con


# Generated at 2022-06-11 01:58:32.450761
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        print(matchpathcon('/etc', 0))
    except Exception as e:
        print('Error: %s' % e)

# Generated at 2022-06-11 01:58:33.854030
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    lgetfilecon_raw('/etc/shadow')


# Generated at 2022-06-11 01:58:40.785745
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = '/etc/passwd'
    # Check if function exist
    assert hasattr(_selinux_lib, "lgetfilecon_raw")

    # Check the return code
    if not security_getenforce():
        assert lgetfilecon_raw(filename)[0] > -1
    else:
        assert lgetfilecon_raw(filename)[0] < 0

    # Check the return context
    if not security_getenforce():
        assert lgetfilecon_raw(filename)[1] == 'system_u:object_r:passwd_file_t:s0'
    else:
        assert lgetfilecon_raw(filename)[1] == ''


# Generated at 2022-06-11 01:58:45.613909
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/var/log'
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        return [rc, to_native(con.value)]
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-11 01:58:50.355730
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/etc/passwd', os.R_OK)
    assert res[0] == 0
    assert res[1] == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-11 01:58:55.816487
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/")
    assert rc >= 0, "lgetfilecon_raw failed"
    assert con, "lgetfilecon_raw didn't return a context"


# Generated at 2022-06-11 01:59:10.328981
# Unit test for function matchpathcon
def test_matchpathcon():

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    # We have a set of different combinations of prefixes, con and rc
    # This generates a test case that returns a tuple with:
    #   - The ctypes patched function to be called (eg: matchpathcon)
    #   - The return value of the patch function: The expected return code
    #   - The return value of the patch function: The expected context
    #   - The function parameters: path, mode
    def patch_match_generator(results):

        # Generates a patched function according the list of expected results
        def patched_match_fn(**kwargs):
            patch_returns = results.pop(0)
            return patch_returns

        return patched_match_fn


# Generated at 2022-06-11 01:59:16.556177
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        if selinux_getenforcemode() == 0:
            return
        import tempfile
        import os
        fd, fname = tempfile.mkstemp()
        os.close(fd)
        (rc, ftype) = lgetfilecon_raw(fname)
        assert rc == 0, "call to lgetfilecon_raw failed"
        assert ftype is not None, "No SELinux context found"
        os.unlink(fname)
    except:
        return

# Generated at 2022-06-11 01:59:25.685269
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import shutil
    import tempfile

    (tmpdir, target) = tempfile.mkstemp()

    try:
        oldcon = lgetfilecon_raw(target)[1]
        lsetfilecon(target, 'system_u:object_r:tmp_t:s0')
        assert(lgetfilecon_raw(target)[1] == 'system_u:object_r:tmp_t:s0')
        lsetfilecon(target, oldcon)
        assert(lgetfilecon_raw(target)[1] == oldcon)
    finally:
        shutil.rmtree(os.path.dirname(target))

# Generated at 2022-06-11 01:59:33.363398
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, security_context = matchpathcon('/tmp', 0)
    assert rc == 0
    assert security_context == b'system_u:object_r:tmp_t:s0'

    rc, security_context = matchpathcon('/tmp', os.R_OK)
    assert rc == 0
    assert security_context == b'system_u:object_r:tmp_t:s0'

    rc, security_context = matchpathcon('/tmp', os.R_OK | os.W_OK)
    assert rc == 0
    assert security_context == b'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-11 01:59:43.063351
# Unit test for function matchpathcon
def test_matchpathcon():
    lxc_path = '/var/lib/lxd/containers//test/rootfs'
    print(matchpathcon(lxc_path, os.R_OK))
    print(matchpathcon(lxc_path, os.W_OK))
    print(matchpathcon(lxc_path, os.X_OK))
    print(matchpathcon(lxc_path, os.R_OK | os.W_OK))
    print(matchpathcon(lxc_path, os.R_OK | os.X_OK))
    print(matchpathcon(lxc_path, os.W_OK | os.X_OK))
    print(matchpathcon(lxc_path, os.R_OK | os.W_OK | os.X_OK))


# Generated at 2022-06-11 01:59:46.494575
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "../../../../usr/bin/whoami"
    # This returns the SELinux file context of path
    # Returns a list with [0] status and [1] file context of path
    print(lgetfilecon_raw(path))


# Generated at 2022-06-11 01:59:52.369075
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/', 0)[0] == 0
    assert matchpathcon(b'/', 1)[0] in {0, 1}
    assert matchpathcon(b'/', 2)[0] in {0, 1}
    assert matchpathcon(b'/', 3)[0] == 0


if __name__ == '__main__':
    # FIXME: add some module level tests
    test_matchpathcon()

# Generated at 2022-06-11 02:00:02.321322
# Unit test for function matchpathcon
def test_matchpathcon():
    lib = CDLL('libselinux.so.1')
    lib.is_selinux_enabled.restype = c_int
    assert lib.is_selinux_enabled() == 1
    lib.is_selinux_mls_enabled.restype = c_int
    assert lib.is_selinux_mls_enabled() == 1
    lib.matchpathcon.restype = c_int
    lib.matchpathcon.argtypes = [c_char_p, c_int, POINTER(c_char_p)]
    path = b"/etc/selinux/targeted/policy/policy.29/modules/services/apache.pp"
    mode = 256
    p_con = c_char_p(b"null")

# Generated at 2022-06-11 02:00:04.301758
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/hosts')
    assert rc == 0
    assert con.startswith('system_u')


# Generated at 2022-06-11 02:00:07.410458
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/hosts'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-11 02:00:16.402815
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = lgetfilecon_raw('/etc/passwd')
    assert con == (0, u"system_u:object_r:etc_runtime_t:s0")

# Generated at 2022-06-11 02:00:19.978828
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    matchpathcon will return 0 on success and a value less than 0 on failure
    '''
    result = matchpathcon('/var/log/messages', 0)
    assert result[0] == 0
    assert result[1] == 'var_log_t'



# Generated at 2022-06-11 02:00:23.521748
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # If a path doesn't exist, lgetfilecon will return -1 and an errno of 2.
    test_path = '/tmp/non-existent'
    out = lgetfilecon_raw(test_path)
    assert out[0] == -1
    assert out[1] == 2


# Generated at 2022-06-11 02:00:30.791395
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test valid path
    print("Testing matchpathcon on valid path")
    result = matchpathcon("/usr/bin/curl", 0)
    assert result[0] == 0, "matchpathcon failed on valid path"
    assert result[1] == "system_u:object_r:bin_t:s0", "matchpathcon did not return expected context"

    # Test invalid path
    print("Testing matchpathcon on invalid path")
    result = matchpathcon("/usr/bin/not_a_binary", 0)
    assert result[0] == 0, "matchpathcon failed on valid path"
    assert result[1] == "system_u:object_r:default_t:s0", "matchpathcon did not return expected context"


# Generated at 2022-06-11 02:00:34.454899
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/passwd', 0)
    print('rc: ', rc)
    print('con: ', con)


if __name__ == "__main__":
    test_matchpathcon()