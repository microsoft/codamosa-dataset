

# Generated at 2022-06-11 01:50:41.739709
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    del _selinux_lib
    try:
        exp = (-1, "No such file or directory")
        res = lgetfilecon_raw(b'/tmp/lgetfilecon_raw.test')
        assert res == exp, 'Expected {0}, got {1}'.format(exp, res)
    except Exception:
        raise AssertionError('Module selinux has a problem')

# Generated at 2022-06-11 01:50:44.613942
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, out) = lgetfilecon_raw("/usr/bin/python")
    print("Return value of lgetfilecon_raw is {}".format(rc))
    print("Context of /usr/bin/python is: {}".format(out))



# Generated at 2022-06-11 01:50:56.126402
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    class Test:
        def __init__(self, path, rc, con):
            self.path = path
            self.rc = rc
            self.con = con

    test_list = [
        Test(path="/", rc=0, con="u:object_r:root:s0"),
        Test(path="/usr/bin/kubelet", rc=0, con="u:object_r:usr_t:s0"),
        Test(path="/etc/xxx", rc=1, con=None),
    ]
    for t in test_list:
        res_rc, res_con = lgetfilecon_raw(t.path)
        assert t.rc == res_rc
        if res_rc == 0:
            assert t.con == res_con


# Generated at 2022-06-11 01:51:02.798190
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path="/"
    test_mode=0
    print("running matchpathcon unittest")
    print("calling with path %s and mode %s" % (test_path, test_mode))
    [rc, context] = matchpathcon(test_path, test_mode)
    if rc == 0:
        print("return value: %s" % context)
    else:
        print("return value: %s" % rc)
if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-11 01:51:09.737828
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:tmp_t:s0']
    assert lgetfilecon_raw('/usr') == [0, 'system_u:object_r:usr_t:s0']

# Generated at 2022-06-11 01:51:18.875725
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for valid path
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0, 'matchpathcon returned invalid rc'
    assert con == 'unconfined_u:object_r:etc_runtime_t:s0', 'matchpathcon returned invalid context'

    # Test for non-existent path
    rc, con = matchpathcon('/etc/non-existent-file', 0)
    assert rc == -1, 'matchpathcon returned invalid rc'

    # Test for invalid mode
    rc, con = matchpathcon('/etc/passwd', 'invalid-mode')
    assert rc == -1, 'matchpathcon returned invalid rc'

# Generated at 2022-06-11 01:51:30.064637
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not os.path.exists('/etc/passwd'):
        raise ImportError('test file does not exist: {0}'.format('/etc/passwd'))

    con, rc = lgetfilecon_raw('/etc/passwd')
    if rc != 0:
        raise ValueError('unable to retrieve context for /etc/passwd')

    if not con:
        raise ValueError('invalid context for /etc/passwd: {0}'.format(con))

    # verify that the con string can be parsed
    split_con = con.split(':')
    if len(split_con) != 5:
        raise ValueError('malformed context for /etc/passwd: {0}'.format(con))


# Generated at 2022-06-11 01:51:31.835947
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # GIVEN
    path = '/etc/passwd'
    expected_result = [0, 'unconfined_u:object_r:user_home_t:s0']

    # WHEN
    result = lgetfilecon_raw(path)

    # THEN
    assert result == expected_result


# Generated at 2022-06-11 01:51:35.849863
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw('.')
        if rc != 0:
            raise Exception('lgetfilecon_raw failed')
    except OSError as e:
        if e.errno == os.errno.ENOENT:
            raise Exception('lgetfilecon_raw failed')
        else:
            raise



# Generated at 2022-06-11 01:51:40.612437
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    test matchpathcon with a real file on the system
    '''
    # first call should succeed as we are in enforcing mode
    [rc, con] = matchpathcon('/etc/mtab', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-11 01:51:54.125197
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.selinux import selinux_getenforcemode, lgetfilecon_raw, security_getenforce

    try:
        policytype = selinux_getpolicytype()
        if policytype[0] != 0:
            print('SELinux is not enabled')
        else:
            print('SELinux policy type: {0}'.format(to_native(policytype[1])))
    except OSError as e:
        print('SELinux is not enabled: {0}'.format(to_native(e)))


# Generated at 2022-06-11 01:51:56.642028
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/selinux/config') == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-11 01:52:05.419546
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        # On systems without selinux, lgetfilecon_raw should throw an OSError
        # and thus return a non-zero exit code
        try:
            lgetfilecon_raw()
        except OSError as e:
            assert e.errno == get_errno()
            assert e[1] == os.strerror(e.errno)
    else:
        # On systems with selinux, lgetfilecon_raw should return a zero exit
        # code and the valid context of the file system object
        assert lgetfilecon_raw('/')[0] == 0
        assert matchpathcon('/', 0)[0] == 0
    return True

# Generated at 2022-06-11 01:52:12.825979
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Unit test for matchpathcon.
    """
    rc, con = matchpathcon('/home/foo', 0)
    assert rc == 0
    assert con == "system_u:object_r:user_home_dir_t:s0"

    rc, con = matchpathcon('/home/foo', 1)
    assert rc == 0
    assert con == "system_u:object_r:user_home_t:s0"



# Generated at 2022-06-11 01:52:22.717312
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) != -1
    assert matchpathcon('/', 0) != -1
    assert matchpathcon('/etc/', 0) != -1
    assert matchpathcon('/non/existent', 0) == -1
    assert matchpathcon('/etc', 0) == -1
    assert matchpathcon('/etc/', 0) != -1
    assert matchpathcon('/etc/passwd', 5) == -1


__all__ = [
    'is_selinux_enabled',
    'is_selinux_mls_enabled',
    'lgetfilecon_raw',
    'matchpathcon',
    'selinux_getenforcemode',
    'selinux_getpolicytype',
]

# Generated at 2022-06-11 01:52:27.270732
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp/doesnotexist_942', 0)
    assert rc == -1
    rc, con = matchpathcon('/tmp', 0)
    assert rc == 0
    assert con[:4] == 'tmp:'

# Generated at 2022-06-11 01:52:33.352724
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Check if function 'lgetfilecon_raw' returns non-zero to indicate an error
    file_name = "/tmp/krb5cc_0"
    rc = _selinux_lib.lgetfilecon_raw(file_name, None)
    # If file does not exist, return value is -1 and errno is set to 2, else return value < 0
    if rc == -1 and get_errno() == 2:
        print("File does not exist, which is the case here. Skip this check")
    else:
        # The value of 'rc' should be greater than 0 for success
        assert rc >= 0
    print("rc: %s" % rc)
    return

# Generated at 2022-06-11 01:52:43.485890
# Unit test for function matchpathcon
def test_matchpathcon():
    from tempfile import mkdtemp
    from shutil import rmtree
    import sys
    import os

    def _check_rc(rc, expected_rc):
        if rc != expected_rc:
            print("{0} - FAIL: Expected return value of {1}, got {2}".format(sys._getframe().f_code.co_name, expected_rc, rc))
            os._exit(1)
        # end if
    # end def

    def _check_string(string, expected_string):
        if string != expected_string:
            print("{0} - FAIL: Expected string of '{1}', got '{2}'".format(sys._getframe().f_code.co_name, expected_string, string))
            os._exit(1)
        # end if
    # end

# Generated at 2022-06-11 01:52:46.879349
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = to_bytes('/bin/sh')
    con = lgetfilecon_raw(path)[1]
    assert con.startswith(b'system_u:object_r:')

# Generated at 2022-06-11 01:52:55.885585
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils import basic
    from ansible.module_utils.selinux import convert_context
    from ansible.module_utils.basic import AnsibleModule

    if is_selinux_enabled() != 0:
        module = AnsibleModule(argument_spec={})
        path = '/etc/passwd'
        rc, current_context = lgetfilecon_raw(path)
        if rc < 0:
            module.fail_json(msg='Unable to get current context for %s: %s' % (path, to_native(os.strerror(rc * -1))))
        module.exit_json(msg=convert_context(current_context, to_text=True))
    else:
        print('SELinux is not enabled')



# Generated at 2022-06-11 01:53:02.709703
# Unit test for function matchpathcon
def test_matchpathcon():
    assert [1, 'system_u:object_r:svirt_sandbox_file_t:s0'] == matchpathcon('/tmp', os.R_OK)



# Generated at 2022-06-11 01:53:07.915861
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert con.startswith('unconfined_u:object_r:rootfs:s0')

    rc, con = lgetfilecon_raw('/root')
    assert con.startswith('unconfined_u:object_r:default_t:s0')

    rc, con = lgetfilecon_raw('/tmp/does_not_exist')
    assert rc == 0
    assert con is None

# Generated at 2022-06-11 01:53:17.047658
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw('/usr')
    assert rc == 0, 'lgetfilecon_raw returned {0} expected 0'.format(rc)
    assert con == 'system_u:object_r:usr_t:s0', 'lgetfilecon_raw returned {0} expected system_u:object_r:usr_t:s0'.format(con)
    [rc, con] = lgetfilecon_raw('/')
    assert rc == 0, 'lgetfilecon_raw returned {0} expected 0'.format(rc)
    assert con == 'system_u:object_r:root_t:s0', 'lgetfilecon_raw returned {0} expected system_u:object_r:root_t:s0'.format(con)
    [rc, con] = lgetfile

# Generated at 2022-06-11 01:53:19.575701
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/foo/bar/baz')
    print(rc)
    print(con)


# Generated at 2022-06-11 01:53:22.897307
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/etc/shadow', 0)
    assert res[1] == 'system_u:object_r:shadow_t:s0'



# Generated at 2022-06-11 01:53:27.097613
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/myfile'
    mode = 0

    r = matchpathcon(path, mode)
    assert r == [0, 'system_u:object_r:tmp_t:s0']


if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-11 01:53:37.271034
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print("\nStart test_lgetfilecon_raw\n")
    file_path = "/tmp"
    rc, con = lgetfilecon_raw(file_path)
    print("Return code from lgetfilecon_raw is %s " % rc)
    if rc == 0:
        print("SELinux context: %s " % con)
    if rc == -2:
        print("File %s does not exist" % file_path)
    if rc == -1:
        errno = get_errno()
        print("lgetfilecon_raw failed: %s " % os.strerror(errno))
    print("\nEnd test_lgetfilecon_raw\n")


# Generated at 2022-06-11 01:53:47.389085
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    from ansible.module_utils.selinux_policycoreutils import is_selinux_enabled, security_getenforce

    module = AnsibleModule(argument_spec={})

    if not is_selinux_enabled():
        module.fail_json(msg="SELinux is not enabled on the host")

    if security_getenforce() == 0:
        module.fail_json(msg="SELinux is in Permissive mode on the host, Permissive mode is not supported. Please rerun with enforcing mode")

    tempDir = tempfile.mkdtemp()
    rc, con = lgetfilecon_raw(tempDir)
    if rc != 0:
        module.fail_json(msg="Failed to get file context of %s" % tempDir)

# Generated at 2022-06-11 01:53:51.300552
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux'
    rc, con = lgetfilecon_raw(path)
    if rc != 0:
        raise Exception('lgetfilecon_raw with path "{0}" failed with error "{1}"'.format(path, rc))
    print(con)



# Generated at 2022-06-11 01:53:57.444329
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    with tempfile.NamedTemporaryFile(prefix='ansible_selinux_lib_') as f:
        rc, con = lgetfilecon_raw(f.name)
        assert rc == 0
        assert con.startswith('system_u:object_r:tmp_t:s0')

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:54:07.275328
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test that matchpathcon function returns 0 when given a valid path
    assert matchpathcon("/etc/sudoers.d", os.R_OK)[0] == 0



# Generated at 2022-06-11 01:54:09.473590
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/group') == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-11 01:54:11.177807
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/etc/foo', 0))



# Generated at 2022-06-11 01:54:20.986090
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Using a file with no context
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    # Using a directory with no context
    rc, con = lgetfilecon_raw('/etc')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    # Using a file with context
    rc, con = lgetfilecon_raw('/etc/httpd/conf/httpd.conf')
    assert rc == 0
    assert con.startswith('system_u:object_r:etc_t:s0')

    # Using a directory with context
    rc, con = lgetfilecon_raw('/tmp/testdir')

# Generated at 2022-06-11 01:54:31.469889
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon('/', 0)[0]
    if rc != 0:
        raise NotImplementedError('matchpathcon function not implemented or no selinux policy')
    # tst_fs_type, tst_fs_default
    rc, con = matchpathcon('/bin/ls', 3)
    # get the default context for a file system
    if rc != 0:
        raise NotImplementedError('matchpathcon function not implemented or no selinux policy')
    assert con == 'bin_t:object_r:bin_t:s0'

    # get the default context for a file system
    rc, con = matchpathcon('/bin/ls', 0)
    if rc != 0:
        raise NotImplementedError('matchpathcon function not implemented or no selinux policy')

# Generated at 2022-06-11 01:54:36.288391
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/', 0)
    assert rc == 0
    assert con.startswith('system_u:object_r:rootfs:s0')

    rc, con = matchpathcon('/dev', 0)
    assert rc == 0
    assert con.startswith('system_u:object_r:dev:s0')

# Generated at 2022-06-11 01:54:46.315438
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import sys
    import os
    from os.path import dirname, realpath, exists
    sys.path.insert(0, dirname(realpath(__file__)))
    from selinux_test_module import selinux_test_module

    # try invalid inputs
    invalid = [
        None,
        "",
        " ",
        "path",
        "path:",
        "path: ",
        "path:level",
        "path:level:",
        "path:level: ",
        "path:level:type",
        "path:level:type:",
        "path:level:user:role",
    ]

# Generated at 2022-06-11 01:54:49.296866
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon(b'/var/tmp', 0)

    if rc < 0:
        raise OSError(rc, con)



# Generated at 2022-06-11 01:54:56.792337
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        print("Test cannot run while SELinux is not enabled", file=sys.stderr)
        return

    if security_getenforce() == 1:
        print("Test cannot run while SELinux is in enforcing mode", file=sys.stderr)
        return

    # Check if a valid SELinux policy is installed:
    policy_type = selinux_getpolicytype()
    print("SELinux policy type: {}".format(policy_type[1]))
    if policy_type[1] == "":
        print("Test cannot run without a valid SELinux policy installed", file=sys.stderr)
        return

    print("Testing pathcon for path /tmp/foo")
    ret = matchpathcon("/tmp/foo", 0)
   

# Generated at 2022-06-11 01:55:02.026099
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/ansible/foo.conf', 0) == [0, "ansible_etc_t"]
    # -1 is expected when matching a file path that does not exist
    assert matchpathcon('/etc/ansible/foo.conf', -1) == [-1, None]

# Generated at 2022-06-11 01:55:21.786842
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/passwd"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    if rc != 0:
        print("Test failed for matchpathcon")
        sys.exit(1)
    else:
        print("Test passed for matchpathcon")
        sys.exit(0)


# Generated at 2022-06-11 01:55:25.495945
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        (rc, con) = matchpathcon('/tmp/test-selinux', 0)
        assert rc == 0
    except OSError as e:
        # If this fails, try to run the test as root
        assert e.errno == 1


# Generated at 2022-06-11 01:55:32.972443
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/proc/self/exe') == [0, 'unconfined_u:object_r:textrel_shlib_t:s0']
    assert lgetfilecon_raw('/etc/sudoers') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/etc/shadow') == [0, 'system_u:object_r:shadow_t:s0']
    assert lgetfilecon_raw('non_existent_file') == [-1, None]


# Generated at 2022-06-11 01:55:38.042041
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 1 with a file that has no SELinux context (permissive mode enabled)
    path = '/tmp/a'
    mode = 0o600
    # Create file with open mode 0600
    with open(path, 'w') as f:
        f.write('matchpathcon test')
    con, rc = matchpathcon(path, mode)
    assert rc == -1
    assert con is None


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:55:38.547137
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pass

# Generated at 2022-06-11 01:55:42.228405
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/group')

    if rc != 0:
        raise Exception("lgetfilecon_raw() returned a non-zero value: {}".format(rc))

    if con is None:
        raise Exception("con returned from lgetfilecon_raw is None")

# Generated at 2022-06-11 01:55:44.196179
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/tmp', 0)
    assert con == "system_u:object_r:tmp_t:s0"

# Generated at 2022-06-11 01:55:53.696622
# Unit test for function matchpathcon
def test_matchpathcon():
    test_inputs = [
        (to_bytes('/etc'), 0, [0, 'etc_t']),
        (to_bytes('/etc'), 1, [0, 'etc_t']),
        (to_bytes('/etc/test'), 0, [1, None]),
        (to_bytes('/etc/test'), 1, [0, 'etc_t']),
        (to_bytes('/var'), 0, [0, 'var_t']),
        (to_bytes('/var/empty'), 0, [0, 'var_empty_t']),
        (to_bytes('/var/empty/test'), 0, [0, 'var_empty_t']),
        (to_bytes('/var/empty/test'), 1, [0, 'var_empty_t']),
    ]


# Generated at 2022-06-11 01:56:02.694143
# Unit test for function matchpathcon
def test_matchpathcon():
    for mode in [0, 1, 2]:
        rc, con = matchpathcon("/tmp", mode)
        if rc < 0:
            print("Failure for /tmp %d" % mode)

        rc, con = matchpathcon("/tmp/does-not-exist", mode)
        if rc >= 0:
            print("Success for /tmp/does-not-exist %d" % mode)

        rc, con = matchpathcon("/tmp/does-not-exist-2", mode)
        if rc >= 0:
            print("Success for /tmp/does-not-exist-2 %d" % mode)



# Generated at 2022-06-11 01:56:08.058048
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Note: This test only tests the RC returned by the function.
    #       The actual context output is tested in unit testing of
    #       chcon_changes module.
    test_path = os.path.abspath(__file__)
    if os.path.exists(test_path):
        assert [0, None] == lgetfilecon_raw(test_path)
    else:
        assert [errno.ENOENT, None] == lgetfilecon_raw(test_path)



# Generated at 2022-06-11 01:56:44.645700
# Unit test for function matchpathcon
def test_matchpathcon():
    # the file is a regular file
    assert matchpathcon('/var/www/html', 0) == [0, 'httpd_sys_content_t']

    # the file is a directory
    assert matchpathcon('/var/www', 1) == [0, 'httpd_sys_content_t']

    # the file is a socket
    assert matchpathcon('/var/lib/libvirt/libvirt-sock', 2) == [0, 'system_dbusd_var_run_t']

    # the file is a FIFO
    assert matchpathcon('/var/lib/libvirt/virtlockd-sock', 3) == [0, 'system_dbusd_var_run_t']

    # the file is a symlink

# Generated at 2022-06-11 01:56:45.731865
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/test', 0)
    assert rc == -1
    rc, con = matchpathcon('/test/test', 0)
    assert rc == 0

# Generated at 2022-06-11 01:56:48.347606
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/') == [0, b'system_u:object_r:root_t:s0']

# Generated at 2022-06-11 01:56:54.556391
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected_rc = 0
    expected_con = 'unconfined_u:object_r:user_tmp_t:s0'

    # Try getting the context of a file in /tmp
    (rc, con) = lgetfilecon_raw('/tmp/file.txt')
    if rc != expected_rc and con != expected_con:
        print('FAILED: expected ' + expected_con + ' rc ' + str(expected_rc) + ' instead got ' + con + ' rc ' + str(rc))
        sys.exit(1)



# Generated at 2022-06-11 01:56:58.031715
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/selinux')
    assert rc == 0
    assert con == 'system_u:object_r:selinux_config_t:s0'



# Generated at 2022-06-11 01:57:01.157548
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw('/etc/passwd')
    print('rc=%d' % rc)
    print('con=%s' % con)


# Generated at 2022-06-11 01:57:02.897919
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/tmp', 0)[1] == b'user_tmp_t'



# Generated at 2022-06-11 01:57:12.872826
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    testfile = os.path.dirname(os.path.realpath(__file__)) + "/testfile"
    if not os.path.isfile(testfile):
        raise RuntimeError("Unable to find testfile: %s" % testfile)

    testcontent = "This is a test file"
    with open(testfile, 'w') as f:
        f.write(testcontent)
    try:
        (rc, con) = lgetfilecon_raw(testfile)
        if rc == -1:
            raise RuntimeError("Unable to find context for %s: %s" % (testfile, con))
    finally:
        os.remove(testfile)

if __name__ == "__main__":
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:57:24.744346
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    FNAME = 'lgetfilecon_raw_test_file'
    if not os.path.exists(FNAME):
        print('Creating test file: %s' % FNAME)
        with open(FNAME, 'w'):
            pass
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(FNAME, byref(con))
    if rc == -1:
        print('Error: %s' % OSError(_selinux_lib.get_errno(), os.strerror(_selinux_lib.get_errno())))
    assert rc != -1
    print('Selinux context: %s' % to_native(con.value))
    assert con.value is not None

# Generated at 2022-06-11 01:57:28.591099
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert lgetfilecon_raw(b'/etc/ssh/sshd_config') == [0, 'system_u:object_r:ssh_etc_t:s0']

# Generated at 2022-06-11 01:58:52.844758
# Unit test for function matchpathcon
def test_matchpathcon():
    '''matchpathcon'''
    # Test successful return and security context value
    path = "/var/tmp/testfile"
    mode = 0o600
    test_context = "system_u:object_r:tmp_t:s0"
    [rc, context] = matchpathcon(path, mode)
    assert rc == 0, "matchpathcon for path %s with mode %s failed with rc: %s, error: %s" % \
                    (path, mode, rc, context)
    assert context == test_context, "Context is %s, expected %s" % (context, test_context)



# Generated at 2022-06-11 01:58:54.832625
# Unit test for function matchpathcon
def test_matchpathcon():
    con = matchpathcon('/etc/passwd', 0)[1]
    assert con is not None
    assert type(con) == str


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:59:02.106378
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert matchpathcon('/etc/hosts', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
        assert matchpathcon('/etc/hosts', 1) == [0, 'system_u:object_r:etc_runtime_t:s0']
        assert matchpathcon('/etc/hoist', 0) == [1, '/etc/hoist']
        assert matchpathcon('/etc/hoist', 1) == [1, '/etc/hoist']
    except (AttributeError, ImportError):
        raise NotImplementedError

# Generated at 2022-06-11 01:59:04.558003
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon("/tmp", 3)
    assert result[0] == 0
    assert result[1].startswith("tmp")


# Generated at 2022-06-11 01:59:13.874848
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import shutil
    tempdir = tempfile.mkdtemp()
    tempfile_path = os.path.join(tempdir, 'foo')
    try:
        fd, mode = tempfile.mkstemp(dir=tempdir)
        assert mode == 0o600
        try:
            os.close(fd)
            rc, context = matchpathcon(tempfile_path, mode)
            assert rc == 0
            assert context == 'system_u:object_r:user_tmp_t:s0'
        finally:
            os.remove(tempfile_path)
    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-11 01:59:22.054855
# Unit test for function matchpathcon
def test_matchpathcon():
    pcon = c_char_p()
    # Call the function
    rc = _selinux_lib.matchpathcon(b"/tmp/foo/bar/foobar", 0, byref(pcon))
    print("rc is %d" % rc)
    if rc < 0:
        print("ERROR: %s" % os.strerror(-rc))
        exit(rc)
    print("pcon: %s" % to_native(pcon.value))
    _selinux_lib.freecon(pcon)
    exit(0)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:59:27.930447
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = to_bytes("/var/log/audit")
    (rc, con) = lgetfilecon_raw(path)
    if rc < 0:
        print("Failed to get file context of path %s" % path)
    else:
        print("File context of path %s is %s" % (path, con))

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:59:35.599569
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Example function to show how to use lgetfilecon_raw
    """

    test_file_name = '/tmp/test_file_name'
    if os.path.isfile(test_file_name):
        os.remove(test_file_name)
    file_handle = open(test_file_name, 'w')
    file_handle.close()

    test_return_code, test_context = lgetfilecon_raw(test_file_name)
    assert test_return_code == 0
    assert isinstance(test_context, str)
    assert test_context != ''

    os.remove(test_file_name)

# Generated at 2022-06-11 01:59:38.955505
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/hosts'
    mode = 0
    ret = matchpathcon(path, mode)
    print('[rc, con]: {}'.format(ret))



# Generated at 2022-06-11 01:59:46.069974
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Setup file with context
    import os
    import stat
    import tempfile
    fd, tmp = tempfile.mkstemp()
    os.close(fd)
    os.chmod(tmp, stat.S_IRWXU)
    _selinux_lib.lsetfilecon_raw(tmp, c_char_p(b'system_u:system_r:unconfined_t:s0'))
    con = _selinux_lib.lgetfilecon_raw(tmp, c_char_p(b'system_u:system_r:unconfined_t:s0'))
    os.remove(tmp)
    assert con == 'system_u:object_r:unconfined_t:s0'
