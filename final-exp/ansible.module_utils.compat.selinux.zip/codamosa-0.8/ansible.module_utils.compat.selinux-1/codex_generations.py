

# Generated at 2022-06-11 01:50:45.812215
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for non-existent path - should fail
    path = '/abc/abc'
    mode = 0
    rc, msg = matchpathcon(path, mode)
    if rc == 0:
        raise AssertionError('selinux_lib.matchpathcon(%s, %s), expected failure, but returned %s, %s' % (path, mode, rc, msg))

    # Test for real path
    path = '/var/log'
    mode = 0
    rc, msg = matchpathcon(path, mode)
    if rc != 0:
        raise AssertionError('selinux_lib.matchpathcon(%s, %s), expected success, but returned %s, %s' % (path, mode, rc, msg))



# Generated at 2022-06-11 01:50:52.283748
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    from ansible.module_utils.selinux import lgetfilecon_raw

    tempdir = tempfile.mkdtemp()
    try:
        (rc, con) = lgetfilecon_raw(tempdir)
        assert rc == 0
        assert con == 'system_u:object_r:tmp_t:s0'
    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-11 01:50:56.994464
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/home/john", 0)
    assert rc == 0
    rc, con = matchpathcon("/home/john", 1)
    assert rc == 1, con
    rc, con = matchpathcon("/home/john", 2)
    assert rc == 0, con



# Generated at 2022-06-11 01:51:00.019062
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert isinstance(con, str)

# Generated at 2022-06-11 01:51:04.169174
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    file = "tests/resources/files/lgetfilecon_raw.txt"
    mode = 0

    test_results = lgetfilecon_raw(file)
    assert test_results is not None
    assert test_results[0] == 1
    assert test_results[1] == "system_u:object_r:etc_t:s0"




# Generated at 2022-06-11 01:51:13.417878
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')

    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))
    else:
        return con == 'system_u:object_r:root_t:s0'


if __name__ == '__main__':
    if test_lgetfilecon_raw():
        print("Unit test for function lgetfilecon_raw: PASSED")
    else:
        print("Unit test for function lgetfilecon_raw: FAILED")

# Generated at 2022-06-11 01:51:19.515805
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/test'
    mode = 1832
    try:
        os.mkdir(path)
        os.chmod(path, mode)
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert con == 'system_u:object_r:tmp_t:s0'
    finally:
        os.rmdir(path)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:51:27.270038
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc = 1
    output = ''
    path = '/etc/passwd'
    full_output = lgetfilecon_raw(path)
    rc = full_output[0]
    output = full_output[1]
    if rc == 0:
        print('{0} {1} {2}'.format('PASS', path, output))
    else:
        print('{0} {1} {2} {3} {4}'.format('FAIL',path, rc, '-', output))


# Generated at 2022-06-11 01:51:34.285654
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        [rc, con] = lgetfilecon_raw('/etc/passwd')
    except OSError as e:
        # if have no selinux, rc will be -1 and errno set to ENOTSUP
        assert e.errno == getattr(os, 'ENOTSUP', 45)
        assert rc == -1
        return
    # we have selinux and sample path has a context
    assert rc == 0
    assert con == '[system_u:object_r:etc_runtime_t:s0]'



# Generated at 2022-06-11 01:51:42.449892
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from os import system

    # Create file
    system('touch /tmp/selinux_test_file')

    # Get filecon
    fcon = lgetfilecon_raw('/tmp/selinux_test_file')
    print ('Return code: {0}\nFile context: {1}'.format(fcon[0], fcon[1]))

    # If python 2, remove file
    from sys import version_info
    if version_info.major == 2:
        system('rm /tmp/selinux_test_file')


# Generated at 2022-06-11 01:51:47.929998
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    con = lgetfilecon_raw(path)
    assert con[1] == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-11 01:51:52.532896
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        os.path.join('/tmp/nonexistant.txt')
    except OSError as err:
        rc, con = lgetfilecon_raw('/tmp/nonexistant.txt')
        assert rc == -1
        assert err.errno == get_errno()

# Generated at 2022-06-11 01:51:57.509175
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if is_selinux_enabled():
        rc, con = lgetfilecon_raw('/tmp/foo')
        if rc < 0:
            print(rc)
        else:
            print(rc, con)
        assert rc >= 0
        assert isinstance(con, str)
    else:
        assert False



# Generated at 2022-06-11 01:52:01.638393
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert type(lgetfilecon_raw('/tmp')) == list
    assert type(lgetfilecon_raw('/etc/passwd')) == list
    assert type(lgetfilecon_raw('/dev/null')) == list


# Generated at 2022-06-11 01:52:06.261977
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, context) = lgetfilecon_raw('/tmp/foo')
    if rc != 900:
        return False
    if context != 'system_u:object_r:tmp_t:s0':
        return False
    return True



# Generated at 2022-06-11 01:52:10.994047
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    mode = os.stat('/etc/passwd').st_mode
    rc, con = matchpathcon('/etc/passwd', mode)
    assert rc == 0
    assert con == u'unconfined_u:object_r:etc_t:s0'

# Generated at 2022-06-11 01:52:15.948288
# Unit test for function matchpathcon
def test_matchpathcon():
    if is_selinux_enabled():
        with open('/etc/shadow', 'a') as out:
            pass
        con = matchpathcon('/etc/shadow', os.R_OK)
        assert con[0] == 0
        assert con[1] == 'shadow:shadow:system_u:object_r:shadow_file_t:s0'
        os.remove('/etc/shadow')

# Generated at 2022-06-11 01:52:19.869593
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for if context is set for path
    context = 'system_u:object_r:usr_t:s0'
    path = '/usr/bin'
    rc, con_type = matchpathcon(path, 0)
    assert rc == 0
    assert con_type == context

# Generated at 2022-06-11 01:52:30.691108
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from sys import executable
    from os import path
    from tempfile import mkstemp

    fd, fname = mkstemp()


# Generated at 2022-06-11 01:52:32.629785
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    actual = lgetfilecon_raw('/')
    expected = [0, 'system_u:object_r:root_t:s0']
    assert actual == expected


# Generated at 2022-06-11 01:52:41.501116
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = "/etc/shadow"
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(file, byref(con))
    if rc == -1:
        print("Failed to get context for", file, file=sys.stderr)
        sys.exit(1)
    print("Context for", file, "is", to_native(con.value))
    _selinux_lib.freecon(con)


# Generated at 2022-06-11 01:52:46.776281
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        print('selinux not supported, skipping test')
        return
    path = os.path.realpath(__file__)
    rc, con = lgetfilecon_raw(path)

    assert rc == 0, 'lgetfilecon_raw for {0} failed: {1}'.format(path, os.strerror(rc))
    assert con, 'returned context for {0} is empty'.format(path)

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:52:55.827792
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp', 0) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp', 0o100) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp', 0o200) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp', 0o300) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp', 0o400) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-11 01:53:06.744805
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    tempdir_name = tempfile.mkdtemp(prefix="selinux-test-")

# Generated at 2022-06-11 01:53:14.512249
# Unit test for function matchpathcon
def test_matchpathcon():
    testpath = "/etc"
    testmode = 0
    try:
        res = matchpathcon(testpath, testmode)
    except ImportError:
        print("Test skipped. Unable to load libselinux.so.1")
        return

    if res[0] < 0:
        print("Test failed. matchpathcon returned {}".format(res[0]))
        return
    print("Test passed. matchpathcon returned: {}".format(res[1]))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:53:19.167002
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert is_selinux_enabled()
        rc, con = matchpathcon("/", 0)
        assert rc == 0
        assert con.startswith("system_u:object_r:")
    except (OSError, AssertionError):
        pass
    return rc == 0



# Generated at 2022-06-11 01:53:27.184325
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/proc/sys/net/ipv4/ip_forward'
    mode = 0o644
    ret = matchpathcon(path, mode)
    assert ret[0] == -1
    errno, strerror = os.strerror(ret[0]).split(': ', 1)
    assert int(errno) == ret[0]
    assert strerror == 'libsepol.print_missing_requirements_full: libsepol.print_missing_requirements_full: No applicable policy loaded'
    assert ret[1] is None

# Generated at 2022-06-11 01:53:29.931778
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/usr/bin/id', 1) == [0, b'system_u:object_r:bin_t:s0']

# Generated at 2022-06-11 01:53:39.714676
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # We expect a path with a valid SELinux context to return a success value of 0
    # and a context to validate it's working
    assert lgetfilecon_raw('/etc') == [0, 'system_u:object_r:etc_t:s0']
    # Likewise, anything in /dev should also have a context as it's often used as a
    # test fixture
    assert lgetfilecon_raw('/dev') == [0, 'system_u:object_r:device_t:s0']
    # However, paths that don't have a context will have a context of :
    assert lgetfilecon_raw('/') == [0, ':']
    # Paths that don't exist will have a return code of -1

# Generated at 2022-06-11 01:53:48.726346
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import shutil
    import subprocess


# Generated at 2022-06-11 01:54:02.210905
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test lgetfilecon_raw with valid path and invalid path
    """
    vaild_path = "/"
    invalid_path = "/invalid/path"
    print("Testing lgetfilecon_raw with valid path: {0}".format(vaild_path))
    rc, result = lgetfilecon_raw(vaild_path)
    if rc == 0:
        print("Pass: lgetfilecon_raw() with valid path - rc=0, result={0}".format(result))
    else:
        print("Fail: lgetfilecon_raw() with valid path - rc={0}, result={1}".format(rc, result))
    print("Testing lgetfilecon_raw with invalid path: {0}".format(invalid_path))

# Generated at 2022-06-11 01:54:08.846414
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        raise AssertionError('SELinux required for unit test')

    (rc, con) = matchpathcon('/usr/bin/id', 0)
    if rc != 0:
        raise AssertionError('matchpathcon returned 0 != %d' % rc)

    # This assertion is somewhat brittle as it depends on the specific policy in use
    if con != 'system_u:object_r:initrc_exec_t:s0':
        raise AssertionError('matchpathcon returned %s != system_u:object_r:initrc_exec_t:s0' % con)

# Generated at 2022-06-11 01:54:14.983849
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # avoid using the actual module, we just want to test the function
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']
    assert lgetfilecon_raw('/nonexistent') == [0, 'system_u:object_r:default_t:s0']

# Generated at 2022-06-11 01:54:22.251467
# Unit test for function matchpathcon
def test_matchpathcon():
    from os.path import dirname, abspath
    from os import makedirs, mkdir
    from shutil import rmtree

    from tempfile import mkdtemp

    ref_con = 'system_u:object_r:initrc_var_cache_t:s0'

    #
    # Create test directory tree
    #
    test_root = mkdtemp()

    # Create directory and set proper context
    test_dir = os.path.join(test_root, 'var/cache')
    makedirs(test_dir, mode=0o755)
    os.chmod(test_dir, 0o755)

    rc, con = matchpathcon(test_dir, 0)
    if rc != 0:
        raise OSError('Could not match label for %s' % test_dir)

# Generated at 2022-06-11 01:54:27.697087
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    con = lgetfilecon_raw(path)
    con_expected = 'system_u:object_r:passwd_file_t:s0'
    if con[1] != con_expected:
        raise AssertionError('{0} != {1}'.format(con[1], con_expected))
    return True


# Generated at 2022-06-11 01:54:30.034935
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/') == [0, 'system_u:object_r:etc_t:s0']

# Generated at 2022-06-11 01:54:36.192631
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        print('SELinux is not enabled')
        return

    rc, con = lgetfilecon_raw('/etc/passwd')
    print('lgetfilecon_raw /etc/passwd returned:')
    print('  rc: {0}'.format(rc))
    print('  context: {0}'.format(con))
    # /etc/passwd should be type: etc_t



# Generated at 2022-06-11 01:54:46.225001
# Unit test for function matchpathcon
def test_matchpathcon():
    from distutils.spawn import find_executable
    import pytest
    from ansible.module_utils.selinux import matchpathcon
    if find_executable('getenforce') is not None:
        if os.path.exists('/etc/selinux/config'):
            (rc, policy) = selinux_getenforcemode()
            if rc == 0 and policy == 1:
                (rc, con) = matchpathcon('/etc/selinux/config', os.R_OK)
                assert rc == 0
                assert con is not None
            else:
                pytest.skip('SELinux is in permissive or disabled mode')
        else:
            pytest.skip('Unable to locate /etc/selinux/config')

# Generated at 2022-06-11 01:54:54.529027
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test the lgetfilecon_raw function.
    """
    import os
    import tempfile
    try:
        test_file = tempfile.TemporaryFile()
        test_file.close()
        os.chmod(test_file.name, 0o777)
        rc, con = lgetfilecon_raw(test_file.name)
        if rc < 0:
            raise RuntimeError("lgetfilecon_raw failed: %s", os.strerror(-rc))
        if con is None:
            raise RuntimeError("lgetfilecon_raw returned NULL con")
    finally:
        os.unlink(test_file.name)



# Generated at 2022-06-11 01:54:57.629514
# Unit test for function matchpathcon
def test_matchpathcon():
    sys.stderr.write('SELinux is not available on this system\n')


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:55:06.315257
# Unit test for function matchpathcon
def test_matchpathcon():
    # This test is likely only to work on a system with selinux enabled, but it
    # might work on a system with a dummy selinux implementation as well.  This
    # function returns a security context, so it is difficult to test.
    res = matchpathcon('/etc/issue', 0)
    assert res[0] == 0, res[0]
    assert res[1], res[1]

# Generated at 2022-06-11 01:55:11.139377
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/file_with_unlabeled_context', 0)
    if rc == 0 and con == 'unlabeled_t:object_r:etc_t:s0':
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:55:16.183397
# Unit test for function matchpathcon
def test_matchpathcon():
    # This test case also covers _check_rc()
    # _check_rc() assumes that rc < 0 implies failure
    # Given that matchpathcon returns rc >= 0, errcheck() is a hack
    rc, con = matchpathcon('/foo/bar', os.R_OK)
    assert rc == 1

# Generated at 2022-06-11 01:55:26.261170
# Unit test for function matchpathcon
def test_matchpathcon():
    import argparse

    p = argparse.ArgumentParser(description='unit tester for matchpathcon Wrapper')
    p.add_argument('path', help='file on filesystem to check')
    p.add_argument('mode', help='Mode of file, must be one of: [0-7]', type=int)
    args = p.parse_args()
    rc, con = matchpathcon(args.path, args.mode)
    if rc < 0:
        print("exit code: {0}, errno: {1}, strerror: {2}".format(rc, os.strerror(rc), get_errno()))
    else:
        print("exit code: {0}, context of path {1} is {2}".format(rc, args.path, con))


# Generated at 2022-06-11 01:55:35.688574
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/'
    mode = os.R_OK
    [rc, con] = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:root_t'
    [rc, con] = matchpathcon(path, mode + 1)
    assert rc == 0
    assert con == 'system_u:object_r:root_t'
    [rc, con] = matchpathcon(path, mode + 2)
    assert rc == 0
    assert con == 'system_u:object_r:root_t'
    [rc, con] = matchpathcon(path, mode + 3)
    assert rc == 0
    assert con == 'system_u:object_r:root_t'



# Generated at 2022-06-11 01:55:42.127258
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """ Unit test for function lgetfilecon_raw """
    rc, value = lgetfilecon_raw('/usr/bin/cal')
    msg = 'rc: {0}, value: {1}'.format(rc, value)
    assert rc == 0
    assert value == 'system_u:object_r:user_home_t:s0'
    rc, value = lgetfilecon_raw('/usr/bin/cal123')
    msg = 'rc: {0}, value: {1}'.format(rc, value)
    assert rc == -1
    assert value == ''


# Generated at 2022-06-11 01:55:47.931597
# Unit test for function matchpathcon
def test_matchpathcon():
    # test when the function return SUCCESS
    # NB: this is the same value returned by the non-wrapped function
    expected_result = [0, "system_u:object_r:bin_t:s0"]
    test_result = matchpathcon("/bin/less", 0)
    assert test_result == expected_result, "Test 1 - matchpathcon() returned {} instead of {}" \
                                           .format(test_result, expected_result)

# Generated at 2022-06-11 01:55:56.079369
# Unit test for function matchpathcon
def test_matchpathcon():
    # test mode value 0
    path = os.path.expanduser("~")
    mode = 0
    (rc, strcon) = matchpathcon(path, mode)
    assert rc == 0
    assert strcon is not None
    assert strcon == "unconfined_u:object_r:user_home_dir_t:s0"

    # test mode value 1
    path = os.path.expanduser("~")
    mode = 1
    (rc, strcon) = matchpathcon(path, mode)
    assert rc == 0
    assert strcon is not None
    assert strcon == "unconfined_u:object_r:user_home_dir_t:s0"

    # test mode value 2
    path = os.path.expanduser("~")
    mode = 2

# Generated at 2022-06-11 01:55:59.533696
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    testfile = '/etc/passwd'
    result = lgetfilecon_raw(testfile)
    # We are expecting that selinux is enabled
    assert is_selinux_enabled()[1] == 1, "SELinux is not enabled"
    assert result[0] == 0, 'An error occurred when getting the context of {0}. Error: {1}'.format(testfile, result[1])
    assert result[1] is not None, 'The context of {0} is None'.format(testfile)
    assert len(result[1]) > 0, 'The context of {0} is an empty string'.format(testfile)



# Generated at 2022-06-11 01:56:08.254012
# Unit test for function matchpathcon
def test_matchpathcon():
    # TODO: split this function into multiple tests
    # TODO: add unit test for lsetfilecon
    assert(matchpathcon(b'/tmp', 0) == [0, b'system_u:object_r:tmp_t:s0'] or matchpathcon(b'/tmp', 0) == [0, b'unconfined_u:object_r:tmp_t:s0'])
    assert(lgetfilecon_raw(b'/tmp') == [0, b'system_u:object_r:tmp_t:s0'] or matchpathcon(b'/tmp', 0) == [0, b'unconfined_u:object_r:tmp_t:s0'])
    assert(selinux_getenforcemode() == [0, 1])

# Generated at 2022-06-11 01:56:19.987115
# Unit test for function matchpathcon
def test_matchpathcon():
    assert 0 == matchpathcon('/', 0)[0]
    assert 0 == matchpathcon(u'/', 0)[0]
    assert 0 == matchpathcon('/tmp', 0)[0]
    assert 0 == matchpathcon(u'/tmp', 0)[0]

# Generated at 2022-06-11 01:56:24.048368
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    process_context = lgetfilecon_raw('/proc/self/exe')
    print('Process context: {0}'.format(process_context))

    home_context = lgetfilecon_raw(os.path.expanduser('~'))
    print('Home context: {0}'.format(home_context))



# Generated at 2022-06-11 01:56:26.845467
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon("/etc/passwd", 0)
    print("Matchpathcon test result: " + str(result[1]))


# Generated at 2022-06-11 01:56:30.026092
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/usr/bin/gettext'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:usr_t:s0'


# Generated at 2022-06-11 01:56:36.748843
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create a temporary file
    with tempfile.TemporaryFile(mode='w+b') as f:
        # Retrieve the file context
        fcontext = f'{to_native(f.name)}:system_u:object_r:tmp_t:s0'

        # Retrieve the file context
        ret = lgetfilecon_raw(to_native(f.name))
        assert ret == [0, fcontext]



# Generated at 2022-06-11 01:56:42.049455
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    from ansible.module_utils.basic import env_fallback

    fp = tempfile.NamedTemporaryFile()
    try:
        rc, con = matchpathcon(fp.name, 0)
        assert rc == 0
        assert con == 'default_t:object_r:unlabeled_t'
    finally:
        fp.close()


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:56:45.558474
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    current_selinux_type = lgetfilecon_raw("/tmp/selinux_type")
    print("current_selinux_type = %s" % current_selinux_type)


# Generated at 2022-06-11 01:56:54.805866
# Unit test for function matchpathcon
def test_matchpathcon():
    import subprocess
    import tempfile

    fd, name = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as tmp:
        tmp.write('content')

    def _get_context(name, mode):
        rc, con = matchpathcon(name, mode)
        assert rc == 0
        return con

    assert _get_context(name, os.F_OK) == _get_context(name, os.R_OK | os.W_OK | os.X_OK)

    con = _get_context(name, os.F_OK)

    assert con == _get_context(name, os.R_OK)
    assert _get_context(name, os.W_OK) == con
    assert _get_context(name, os.X_OK) == con


# Generated at 2022-06-11 01:57:05.886619
# Unit test for function matchpathcon
def test_matchpathcon():
    import random
    import os


# Generated at 2022-06-11 01:57:13.250063
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    tf = tempfile.mkstemp()
    try:
        os.close(tf[0])
        fp = open(tf[1], 'w')
    except:
        print("Unable to create file")
        sys.exit(1)
    try:
        rc, value = lgetfilecon_raw(tf[1])
    except:
        print("lgetfilecon_raw is not properly implemented")
        sys.exit(1)
    try:
        os.unlink(tf[1])
    except:
        print("Unable to delete the file")
        sys.exit(1)

# Generated at 2022-06-11 01:57:32.886806
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/selinux/config'
    mode = 0
    expected = ['0', 'system_u:object_r:etc_t:s0']
    assert matchpathcon(path, mode) == expected



# Generated at 2022-06-11 01:57:36.928281
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/var/log/audit/audit.log'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:auditd_log_t:s0'

# Generated at 2022-06-11 01:57:39.542667
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon(b"/etc/foo", 0)
    print('matchpathcon([rc, con])')
    print('con: %s' % con)



# Generated at 2022-06-11 01:57:41.227465
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/etc/passwd', 0))


# Generated at 2022-06-11 01:57:43.750235
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw('/etc/shadow')
    if con is None:
        return False
    elif rc < 0:
        return False
    else:
        return True


# Generated at 2022-06-11 01:57:53.488385
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test case 1 - that the function returns a list with two elements
    assert len(matchpathcon(".", 0)
               ) == 2, "matchpathcon(.,0) did not return a list of two elements"

    # Test case 2 - that the first element of the list returned
    # by matchpathcon is an integer
    assert isinstance(matchpathcon(".", 0)[0], int), "matchpathcon(.,0)[0] is not an integer"

    # Test case 3 - that the second element of the list returned
    # by matchpathcon is a string
    assert isinstance(matchpathcon(".", 0)[1], str), "matchpathcon(.,0)[1] is not a string"


# Generated at 2022-06-11 01:57:55.888967
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test to see that matchpathcon returns a type in the format expected.
    """
    rc = matchpathcon('/','0')
    assert rc[0] == 0
    assert rc[1][0] == 'u'

# Generated at 2022-06-11 01:57:59.509632
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    libselinux_globals.RESOLVABLE = 0
    assert lgetfilecon_raw("/etc/passwd") == [0, "unconfined_u:object_r:user_home_t:s0"]

# Generated at 2022-06-11 01:58:04.254851
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = to_bytes('/')
    try:
        rc, con = lgetfilecon_raw(path)
    except OSError as e:
        assert (e.errno == 95)
        assert (e.strerror == 'Operation not supported')
    else:
        assert False, 'expected OSError with errno 95'


# Generated at 2022-06-11 01:58:07.188201
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert rc == 0, 'failed to retrieve context for root dir.'
    assert isinstance(con, str), 'SELinux context is not a string.'



# Generated at 2022-06-11 01:58:56.530912
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    print(tmp_dir)
    print(matchpathcon(tmp_dir, 0))
    print(matchpathcon(tmp_dir, 0o755))
    print(matchpathcon(tmp_dir, 0o777))



# Generated at 2022-06-11 01:59:04.465692
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/usr/bin/id", 0)[1] == 'system_u:object_r:unlabeled_t:s0'
    assert matchpathcon("/dev/zero", 0)[1] == 'system_u:object_r:zero_device_t:s0'
    assert matchpathcon("/tmp/user_tmp_t/foo", 0)[1] == "user_u:object_r:user_tmp_t:s0"
    assert matchpathcon("/tmp/user_tmp_t/foo", 1)[1] == "user_u:object_r:user_home_t:s0"
    assert matchpathcon("/tmp/user_tmp_t/foo", 2)[1] == "user_u:object_r:user_tmp_t:s0"
    assert matchpath

# Generated at 2022-06-11 01:59:10.963999
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_home_t:s0'
    # check non-existent file
    rc, con = lgetfilecon_raw('/etc/no-such-file')
    assert rc == -1
    assert con is None
    assert get_errno() == 2  # ENOENT



# Generated at 2022-06-11 01:59:16.168617
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Valid case returns value
    [rc, con] = lgetfilecon_raw(b'/tmp')
    assert rc == 0
    assert con
    assert con == b'unconfined_u:object_r:user_tmp_t:s0'

    # Invalid path
    [rc, con] = lgetfilecon_raw(b'/tmp/not_exist')
    assert rc == -1
    assert con is None

# Generated at 2022-06-11 01:59:23.138376
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/localtime', 0)
    assert rc == 0, 'matchpathcon failed with %d: %s' % (rc, os.strerror(-rc))
    assert ((con == 'system_u:object_r:timezone_file_t:s0') or
            (con == 'system_u:object_r:timezone_file_t:s0:c0.c1023')), 'matchpathcon returned unexpected value: %s' % con

# Generated at 2022-06-11 01:59:26.939102
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']
    assert lgetfilecon_raw('/non-existing') == [-1, None]



# Generated at 2022-06-11 01:59:30.828927
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test lgetfilecon_raw
    """
    [rc, con] = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-11 01:59:35.809427
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Construct a known path in the /tmp directory
    path = '/tmp/this_is_a_directory_created_by_unit_tests'
    # Create the directory
    os.mkdir(path)
    # Get the context for the path
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None
    # Delete the path and get out of here
    os.rmdir(path)

# Generated at 2022-06-11 01:59:43.750191
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    fd, file_name = tempfile.mkstemp()
    assert os.path.isfile(file_name)
    mode = os.stat(file_name).st_mode
    if mode & 0o600 != 0o600:
        os.chmod(file_name, mode | 0o600)
    assert lgetfilecon_raw(file_name)[1]
    os.close(fd)
    assert os.path.isfile(file_name)
    os.remove(file_name)
    assert not os.path.isfile(file_name)



# Generated at 2022-06-11 01:59:45.239584
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/selinux/config')[0] == 0
