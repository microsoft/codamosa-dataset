

# Generated at 2022-06-11 01:50:44.344577
# Unit test for function matchpathcon
def test_matchpathcon():
    from os import chdir, getcwd
    from tempfile import mkdtemp

    (rc, con) = matchpathcon('.', 0)
    print("matchpathcon('.', 0) = %d %s" % (rc, to_native(con)))

    orig_dir = getcwd()
    work_dir = mkdtemp()
    chdir(work_dir)
    try:
        (rc, con) = matchpathcon('.', 0)
        print("matchpathcon('.', 0) = %d %s" % (rc, to_native(con)))
    finally:
        chdir(orig_dir)


# Generated at 2022-06-11 01:50:47.522547
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/etc/hosts', 0)[1] == b'etc_t:etc_t:s0'

# Generated at 2022-06-11 01:50:55.444226
# Unit test for function matchpathcon
def test_matchpathcon():
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='path'),
            mode=dict(required=False, default=0, type='int'),
        ),
        supports_check_mode=False
    )
    rc, con = matchpathcon(module.params['path'], module.params['mode'])
    if rc != 0:
        module.fail_json(msg='error getting matchpathcon, rc={}'.format(rc))
    module.exit_json(con=con)


# Generated at 2022-06-11 01:50:56.417461
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/')

# Generated at 2022-06-11 01:51:07.518001
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print("SELinux is enabled: %d" % is_selinux_enabled())
    print("SELinux MLS is enabled: %d" % is_selinux_mls_enabled())
    print("SELinux policy version: %d" % security_policyvers())
    print("SELinux 'enforce' mode: %d" % security_getenforce())
    print("SELinux 'permissive' mode: %d" % selinux_getenforcemode()[1])
    print("SELinux policy type: %s" % selinux_getpolicytype()[1])
    path = sys.argv[0] if len(sys.argv) > 1 else '/etc/passwd'

# Generated at 2022-06-11 01:51:11.686073
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux_utils import lgetfilecon_raw
    expected_result = -1
    result = lgetfilecon_raw(b"/tmp")
    assert result[0] == expected_result

# Generated at 2022-06-11 01:51:15.600631
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon(b'/etc/hosts.equiv', 0)
    assert rc == 0
    assert con == 'system_u:object_r:net_conf_t:s0'



# Generated at 2022-06-11 01:51:19.515920
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # Test: get file context for /tmp/foo
    path = '/tmp/foo'
    con = 'system_u:object_r:tmp_t:s0'
    rc, result = lgetfilecon_raw(path)
    assert rc == 0
    assert result == con



# Generated at 2022-06-11 01:51:26.404345
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    lgetfilecon("/") should return:
          [0, 'system_u:object_r:root_t:s0']
    """
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon("/", byref(con))
        return [rc, to_native(con.value)]
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-11 01:51:30.017122
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    (rc, con) = matchpathcon('/dev/sda', 0)
    if rc == -1:
        print('Failed to find policy:', os.strerror(rc))

    print(con)



# Generated at 2022-06-11 01:51:36.241216
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert con is not None


# Generated at 2022-06-11 01:51:46.111082
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    from ansible.module_utils.six.moves import xrange

    # Create the test directory
    test_dir = tempfile.mkdtemp()
    # Create the test files
    test_paths = [os.path.join(test_dir, "test_file{0}".format(i)) for i in xrange(0, 10)]
    for path in test_paths:
        with open(path, 'w') as tf:
            pass
    # Create a test symlink
    link_path = os.path.join(test_dir, 'test_link')
    os.symlink(test_paths[0], link_path)
    # Get the contexts for the different files
    con_out = {}

    # Don't use the wrapper function, since it returns the error

# Generated at 2022-06-11 01:51:50.317648
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con_str = matchpathcon('test_matchpathcon', 0)
    print(rc)
    if con_str:
        print(con_str)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:51:52.402951
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw("/", byref(con))
    return [rc, to_native(con.value)]


# Generated at 2022-06-11 01:51:57.892347
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b"/etc/selinux/policy/file_contexts", 0)
    if rc < 0:
        raise RuntimeError("test_matchpathcon failed: %d", rc)
    print("rc: %d\ncontext: %s" % (rc, con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:52:02.196035
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b"/etc/passwd") == [0, b"system_u:object_r:etc_runtime_t:s0"]
    assert lgetfilecon_raw(b"/usr/share/whale") == [3, None]


# Generated at 2022-06-11 01:52:12.976874
# Unit test for function matchpathcon
def test_matchpathcon():
    class _TestDummy:
        pass

    # Running with no parameters should return -1 and "unknown path"
    result, result_str = matchpathcon(None, None)

    # This should __eq__ -1
    assert result

    assert "unknown path" == result_str

    # This should __ne__ -1
    assert result != 0

    # The path should be empty
    result, result_str = matchpathcon("", None)

    assert result

    # The path should be non-empty
    result, result_str = matchpathcon("/foo/bar", None)

    # This should __eq__ 0
    assert result == 0

    # This should __ne__ 0
    assert result != 1

# Generated at 2022-06-11 01:52:17.446543
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    results = lgetfilecon_raw('/etc/resolv.conf')
    assert results[0] == 0
    assert results[1] == 'system_u:object_r:resolv_conf_t:s0'
    # resolv.conf must be on file system with SELinux support


# Generated at 2022-06-11 01:52:18.977391
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print(lgetfilecon_raw('/'))


# Generated at 2022-06-11 01:52:20.322182
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
   assert lgetfilecon_raw('/usr/bin/less')[0] == 0

# Generated at 2022-06-11 01:52:30.085670
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    p = _selinux_lib.lgetfilecon_raw
    expected_rc = 1
    test_path = '/usr/lib/libselinux.so.1'
    try:
        [rc, context] = lgetfilecon_raw(test_path)
        if rc == expected_rc:
            return True
    except OSError as e:
        module.fail_json(msg="Error: %s.  Try running with --debug to see the exception." % e.strerror)
    return False


# Generated at 2022-06-11 01:52:33.913013
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    module_path = os.path.dirname(os.path.abspath(__file__))
    rc, con = lgetfilecon_raw(module_path)
    assert rc == 0
    assert con == 'system_u:object_r:ansible_python_library_t:s0'


# Generated at 2022-06-11 01:52:37.268843
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/fstab'
    mode = 0
    con = matchpathcon(path, mode)[1]
    assert con == 'etc_t:object_r:fstab_etc_t:s0'



# Generated at 2022-06-11 01:52:41.036500
# Unit test for function matchpathcon
def test_matchpathcon():
    sys.argv = ['ansible-test', 'debug']
    result = matchpathcon("/var/lib/libvirt/", 0)
    assert result[1] == "system_u:object_r:svirt_lib_t:s0"

# Generated at 2022-06-11 01:52:44.188690
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fname = "/etc/passwd"
    result = lgetfilecon_raw(fname)
    print(f'lgetfilecon_raw {fname} = {result}')
    assert result[0] == 0



# Generated at 2022-06-11 01:52:48.362728
# Unit test for function matchpathcon
def test_matchpathcon():
    if is_selinux_enabled():
        path = '/etc/services'
        mode = os.F_OK
        res = matchpathcon(path, mode)
        assert 'system_u:object_r:etc_runtime_t:s0' in res[1]

# Generated at 2022-06-11 01:52:56.441487
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import sys
    import unittest

    class LgetfileconRawTest(unittest.TestCase):
        def test_lgetfilecon_raw_symlink(self):
            # create a symlink to /bin/bash
            os.symlink(sys.executable, "/tmp/test")
            # check that lgetfilecon_raw returns with rc 0 and the context of the file
            result = lgetfilecon_raw("/tmp/test")
            # remove the symlink
            os.remove("/tmp/test")
            self.assertEqual(result[0], 0)
            self.assertEqual(result[1][:6], 'system')

    suite = unittest.TestLoader().loadTestsFromTestCase(LgetfileconRawTest)
    unittest.Text

# Generated at 2022-06-11 01:53:03.928774
# Unit test for function matchpathcon
def test_matchpathcon():
    test_input = [
        ['/sys', 0],
        ['/sys/fs/selinux', 0],
        ['/sys/fs/selinux/checkreqprot', 0],
    ]
    for input in test_input:
        ret, out = matchpathcon(
            input[0],
            input[1]
        )
        assert ret == 0
        assert ':system_r:' in out
        assert ':system_c:' in out



# Generated at 2022-06-11 01:53:14.801994
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, value = matchpathcon(b'/etc/passwd', 0)
    assert rc == 0
    assert value == 'system_u:object_r:passwd_file_t:s0'

    rc, value = matchpathcon(b'/etc/passwd', os.O_RDWR)
    assert rc == 0
    assert value == 'system_u:object_r:passwd_file_t:s0'

    rc, value = matchpathcon(b'/etc/passwd', os.O_RDWR | os.O_CREAT)
    assert rc == 0
    assert value == 'system_u:object_r:passwd_file_t:s0'

    rc, value = matchpathcon(b'/etc/passwd', os.O_APPEND)
    assert rc == 0

# Generated at 2022-06-11 01:53:16.598234
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b"/etc/passwd")[1] is not None


# Generated at 2022-06-11 01:53:27.392321
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc', 0) == [0, b'etc_t']
    assert matchpathcon('/etc/sysconfig', 0) == [0, b'etc_t']
    assert matchpathcon('/etc/sysconfig/', 0) == [0, b'etc_t']
    assert matchpathcon('/etc/sysconfig/network-scripts', 0) == [0, b'etc_t']



# Generated at 2022-06-11 01:53:35.834482
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    sys.stdout.write("Testing lgetfilecon_raw('/etc/fstab')\n")
    sys.stdout.flush()
    rc, con = lgetfilecon_raw('/etc/fstab')
    sys.stdout.write("Return code: %s\n" % rc)
    sys.stdout.write("File context: %s\n" % con)
    assert con.startswith("system_u:object_r:etc_t:s0")

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:53:38.167905
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    sys.path.insert(0, os.path.dirname(__file__))
    import test_utils
    test_utils.run_function(__file__, 'function_name')

# Generated at 2022-06-11 01:53:45.868110
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        return
    path = '/var/ansible'
    mode = 0
    result = _selinux_lib.matchpathcon(path, mode)
    assert result == 0, "Not the expected result"
    #This function is only available in selinux 1.38 or higher
    if hasattr(_selinux_lib, 'selinux_getpolicytype'):
        result = selinux_getpolicytype()
        assert result[0] == 0, "Not the expected result"
    else:
        return

# Generated at 2022-06-11 01:53:50.186658
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file_path = '/tmp/test-file-1'
    rc, context = lgetfilecon_raw(test_file_path)
    assert rc == 0
    assert context == 'unlabeled_t'
    # Remove test file
    os.remove(test_file_path)


# Generated at 2022-06-11 01:53:52.117208
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/resolv.conf')
    assert rc == 0


# Generated at 2022-06-11 01:53:59.979051
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # file with static context
    assert lgetfilecon_raw(b'/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']
    # file with dynamic context
    assert lgetfilecon_raw(b'/tmp') == [0, 'system_u:object_r:tmp_t:s0']
    # file does not exist
    assert lgetfilecon_raw(b'/nonexistant') == [-1, 'libselinux.so: No such file or directory']


# Generated at 2022-06-11 01:54:06.802252
# Unit test for function matchpathcon
def test_matchpathcon():
    from os import geteuid, mkdir
    from shutil import rmtree
    from tempfile import mkdtemp
    from ansible.module_utils.selinux_utils import matchpathcon

    path = mkdtemp()
    try:
        mkdir(os.path.join(path, "test.d"))
        return_code, context = matchpathcon(os.path.join(path, "test.d"), 0)
        if return_code == 0 and context == "system_u:object_r:default_t:s0":
            pass
        else:
            raise Exception('matchpathcon() test failed')
    finally:
        rmtree(path)


# Generated at 2022-06-11 01:54:18.090203
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    import os

    # Test to make sure we get the same context back for /etc/passwd
    [rc, con] = lgetfilecon_raw(b'/etc/passwd')
    assert rc == 0
    assert os.stat('/etc/passwd').st_mode & 0o1777 == 0o755
    assert con == 'system_u:object_r:etc_t:s0'

    # Test to make sure we get the same context back for / etc.
    [rc, con] = lgetfilecon_raw(b'/')
    assert rc == 0
    assert os.stat('/').st_mode & 0o1777 == 0o755
    assert con == 'system_u:object_r:root_t:s0'

# Generated at 2022-06-11 01:54:22.074324
# Unit test for function matchpathcon
def test_matchpathcon():
    """ matchpathcon test function. """
    path = '/tmp'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:default_t:s0'



# Generated at 2022-06-11 01:54:30.111105
# Unit test for function matchpathcon
def test_matchpathcon():
    required_rc = [0, 'test_user_r:test_role_r:test_type_r:s0']
    test_rc = matchpathcon('/tmp/test_file', 0)

    assert test_rc == required_rc, "test_rc = {0} required_rc = {1}".format(test_rc, required_rc)


# Generated at 2022-06-11 01:54:33.275991
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/tmp"
    rc, con = matchpathcon(path, 0)
    assert rc is 0
    assert con == "system_u:object_r:tmp_t:s0"



# Generated at 2022-06-11 01:54:42.500499
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    # Any existing file will do for this test
    filename = os.path.expanduser('~/.ssh/known_hosts')
    # SELinux mode of 0 is equivalent to stat.S_IFMT
    mode = os.stat(filename).st_mode & 0o170000

    rc, con = matchpathcon(filename, mode)
    print('[%s] rc: %s' % (os.path.basename(__file__), rc))
    print('[%s] con: %s' % (os.path.basename(__file__), con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:54:45.847948
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.expanduser("~")
    # Expect [rc, con]
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None


# Generated at 2022-06-11 01:54:52.681751
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    real_path = b'/tmp/test.txt'
    bad_path = b'/bad/path'
    try:
        open(real_path, 'a').close()
        rc, cntx = lgetfilecon_raw(real_path)
        assert rc == 0 and cntx
        rc, cntx = lgetfilecon_raw(bad_path)
        assert rc != 0
    finally:
        os.remove(real_path)


# Generated at 2022-06-11 01:54:55.441930
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/proc')
    assert rc == 0
    assert con == 'system_u:object_r:proc_t:s0'


# Generated at 2022-06-11 01:55:00.528903
# Unit test for function matchpathcon
def test_matchpathcon():
    unittest.TestCase().assertEqual(matchpathcon("/tmp", 0), (0, "system_u:object_r:tmp_t:s0"))


if __name__ == '__main__':
    import unittest

    unittest.main()

# Generated at 2022-06-11 01:55:06.389288
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text
    import tempfile

    fd, testfile = tempfile.mkstemp(prefix='test_file_')
    os.close(fd)
    rc, con = matchpathcon(testfile, 0)
    os.remove(testfile)
    assert type(con) is str
    assert rc == 0
    assert len(con) > 0
    assert con == to_text(con)


# Generated at 2022-06-11 01:55:12.224962
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os.path
    import os

    # Get file sample.txt context
    file_context = lgetfilecon_raw(os.path.join(os.path.dirname(__file__),"sample.txt"))
    # Check if file_context is 0 and context is unconfined_u:object_r:user_tmp_t:s0
    assert(file_context == [0, 'unconfined_u:object_r:user_tmp_t:s0'])



# Generated at 2022-06-11 01:55:21.365820
# Unit test for function matchpathcon
def test_matchpathcon():
    # with and without SELinux enabled
    if selinux_getenforcemode()[1] == 0:
        path = '/etc/hosts'
        mode = os.R_OK
        output = matchpathcon(path, mode)
        if output[0] == 0:
            print("{0}:{1} {2}".format(path, mode, output[1]))
            print(lgetfilecon_raw(path))
        else:
            print("error: {0}".format(output[0]))
    else:
        print("SELinux disabled")



# Generated at 2022-06-11 01:55:29.787605
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    [rc, con] = lgetfilecon_raw(path)
    assert rc >= 0 and con is not None, 'lgetfilecon_raw on path {} failed with rc={}, con={}'.format(path, rc, con)


# Generated at 2022-06-11 01:55:38.525423
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()

    rc = _selinux_lib.lgetfilecon_raw(b'/sys/fs/selinux/policyvers', byref(con))
    assert rc == 0
    assert con.value == b"system_u:object_r:selinuxfs:s0\x00"

    rc = _selinux_lib.lgetfilecon_raw(b'/selinux/policyvers', byref(con))
    assert rc == -1
    assert get_errno() == 2

    rc = _selinux_lib.lgetfilecon_raw(b'/sys/fs/', byref(con))
    assert rc == -1
    assert get_errno() == 2


# Generated at 2022-06-11 01:55:42.575212
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    res = lgetfilecon_raw("/")
    assert res[0] == 0, "The return code is 0"
    assert res[1].startswith("system_u:object_r:rootfs"), "The function returned the correct context"

if __name__ == "__main__":
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:55:52.299464
# Unit test for function matchpathcon
def test_matchpathcon():
    # This function test for the basic functionality of matchpathcon.
    # Change the path if required on different machines.
    # directory path should be test/test0, test/test1
    # symlink path should be test/testsym0, test/testsym1
    dir_list = ["test/test0", "test/test1"]
    sym_list = ["test/testsym0", "test/testsym1"]
    dir_out = ["test/test0:dir:object_r:tmp_t:s0", "test/test1:dir:object_r:tmp_t:s0"]
    sym_out = ["test/testsym0:lnk_file:object_r:tmp_t:s0", "test/testsym1:lnk_file:object_r:tmp_t:s0"]
    c

# Generated at 2022-06-11 01:55:55.797959
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/selinux'
    assert lgetfilecon_raw(path)[1] == 'system_u:object_r:selinux_var_t:s0'



# Generated at 2022-06-11 01:55:58.354885
# Unit test for function matchpathcon
def test_matchpathcon():
    retval, result = matchpathcon("/tmp", 0)
    assert result == "system_u:object_r:tmp_t:s0"

# Generated at 2022-06-11 01:56:01.336214
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        # Should raise OSError if libselinux.so.1 is not available
        matchpathcon('/foo', 0)
    except OSError:
        pass

# Generated at 2022-06-11 01:56:05.465737
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test_matchpathcon'
    try:
        os.mkdir(path)
        (rc, context) = matchpathcon(path, 0)
        assert rc == False
        assert context is not None
        assert context != ''
    finally:
        os.rmdir(path)

# Generated at 2022-06-11 01:56:10.848483
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        return

    data = [
        ('/etc', 0),
        ('/etc/', 0),
        ('/etc/ssh/sshd_config', 0),
        ('/etc/ssh/sshd_config/', 0),
    ]
    for path, mode in data:
        rc, con = matchpathcon(path, mode)
        assert rc == 0
        assert con is not None

# Generated at 2022-06-11 01:56:20.836589
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = os.path.join(os.environ['HOME'], ".ansible", "tmp", "test_file")
    test_con = "user_u:user_r:user_t:s0"
    mode = 0
    result = lsetfilecon(test_path, test_con)
    if (result[0] == -1):
        raise Exception("Unable to set context of {0} to {1}".format(test_path, test_con))
    result = matchpathcon(test_path, mode)
    if result[0] != 0:
        raise Exception("Unable to get context of {0}".format(test_path))
    result_con = result[1]

# Generated at 2022-06-11 01:56:29.793914
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # test with a valid path
    assert lgetfilecon_raw('/var/log/') == [0, 'system_u:object_r:var_log_t:s0']
    # test with an invalid path
    assert lgetfilecon_raw('/foo/bar') == [-1, None]


# Generated at 2022-06-11 01:56:33.633177
# Unit test for function matchpathcon
def test_matchpathcon():
    data = matchpathcon(b'/', 0)
    assert data[0] == 0
    assert data[1] == 'system_u:object_r:rootfs:s0'



# Generated at 2022-06-11 01:56:41.102212
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import ansible_collections.ansible.community.plugins.module_utils.basic  # noqa: F401
    ctx = 'test_lgetfilecon_raw'
    r = lgetfilecon_raw('/etc/resolv.conf')
    if r[0] != 0:
        sys.stderr.write('%s: unable to get context for /etc/resolv.conf: %s\n' % (ctx, r[1]))
    else:
        print('context for /etc/resolv.conf: %s' % r[1])


# Generated at 2022-06-11 01:56:43.594084
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = "/usr/sbin/apache2"
    assert(lgetfilecon_raw(test_path) == 0)


# Generated at 2022-06-11 01:56:49.546306
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = os.path.dirname(__file__)
    if test_path == '':
        test_path = '.'
    assert lgetfilecon_raw(test_path) == [0, 'system_u:object_r:default_t:s0']


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:56:51.395519
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/tmp', 0)
    assert con == 'system_u:object_r:default_t:s0'

# Generated at 2022-06-11 01:56:54.836727
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/hosts', os.R_OK)
    if rc == 0:
        print('matchpathcon returned: {0}'.format(con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:57:01.329408
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test matchpathcon with a positive result
    test_path = "/etc"
    test_mode = 0
    [rc, con] = matchpathcon(test_path, test_mode)
    assert rc == 0

    # Test matchpathcon with a negative result
    test_path = "/not_a_path"
    test_mode = 0
    [rc, con] = matchpathcon(test_path, test_mode)
    assert rc == -1



# Generated at 2022-06-11 01:57:12.156949
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert(lgetfilecon_raw("/etc/passwd")[1] == "system_u:object_r:netlink_audit_socket_t:s0")
    assert(lgetfilecon_raw("/etc/shadow")[1] == "system_u:object_r:shadow_t:s0")
    assert(lgetfilecon_raw("/usr/bin/python3")[1] == "system_u:object_r:bin_t:s0")
    assert(lgetfilecon_raw("/etc/selinux/targeted/policy/policy.30")[1] == "system_u:object_r:etc_t:s0")

# Generated at 2022-06-11 01:57:24.212984
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import os.path
    import platform

    from ansible.module_utils.selinux import matchpathcon
    from ansible.module_utils._text import to_text

    if platform.system() == 'Darwin':
        os.environ.pop('SELINUX_INIT', None)
        rc, context = matchpathcon(os.path.abspath(__file__), 0)
        assert rc == 0, rc
        assert context.startswith('system_u:object_r:'), context

    if platform.system() == 'Linux':
        os.environ['SELINUX_INIT'] = 'YES'
        rc, context = matchpathcon(os.path.abspath(__file__), 0)
        assert rc == 0, rc

# Generated at 2022-06-11 01:57:39.023848
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # path is a directory
    dir_path = '/tmp'
    result = lgetfilecon_raw(dir_path)
    # result[0] the return code of lgetfilecon_raw
    # result[1] the file context of path
    if result[0] == 0 and result[1] == 'unconfined_u:object_r:tmp_t:s0':
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-11 01:57:46.082852
# Unit test for function matchpathcon
def test_matchpathcon():

    if security_policyvers() == 0:
        print("Not a SELinux system")
        sys.exit(1)


# Generated at 2022-06-11 01:57:51.251361
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This assumes that /usr has a context of:
    # unconfined_u:object_r:user_home_dir_t:s0
    assert lgetfilecon_raw('/usr') == [0, 'unconfined_u:object_r:user_home_dir_t:s0']



# Generated at 2022-06-11 01:57:54.080521
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import selinux
    path = selinux.security_getenforce()
    [rc, con] = selinux.lgetfilecon_raw(path)
    assert rc == 0


# Generated at 2022-06-11 01:57:56.726420
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = matchpathcon('/usr/bin/ping', 0)
    except OSError as e:
        print(e)
        rc = e.errno
        con = 0
    assert rc == 0
    assert isinstance(con, str)
    print('rc = {0} con = {1}'.format(rc, con))



# Generated at 2022-06-11 01:58:02.484727
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expect = b'unconfined_u:object_r:usr_t:s0'
    results = lgetfilecon_raw(b'/etc/passwd')
    assert isinstance(results[0], int) and results[0] == 0, "lgetfilecon_raw did not return rc 0"
    assert isinstance(results[1], str) and results[1] == to_native(expect), "lgetfilecon_raw did not return expected con"


# Generated at 2022-06-11 01:58:09.855206
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        t = lgetfilecon_raw('/sys')
    except Exception as e:
        print("'lgetfilecon_raw' raised an exception: {0}".format(e))
        return 1
    if t[0] < 0:
        print('Could not check the context of {0}'.format('/sys'))
        return 1
    if t[1] != "system_u:object_r:sysfs_t:s0":
        print('Expected context: {0}, got {1}'.format("system_u:object_r:sysfs_t:s0", t[1]))
        return 1
    return 0

# Generated at 2022-06-11 01:58:15.463957
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/fstab'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'
    path = '/etc/shadow'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None



# Generated at 2022-06-11 01:58:20.832363
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/var/log'
    mode = 0x01FF
    result = matchpathcon(path, mode)
    assert result[0] == 0, 'assert selinux_getpolicytype() == 0'
    assert result[1] is not None, 'assert selinux_getpolicytype() is not None'

    path = '/var/log/test.txt'
    result = lgetfilecon_raw(path)
    assert result[0] == 0, 'assert lgetfilecon_raw() == 0'
    assert result[1] is not None, 'assert lgetfilecon_raw() is not None'

# Generated at 2022-06-11 01:58:23.386896
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw("/tmp")
    assert rc >= 0
    assert con
    assert type(con) == type(u"")



# Generated at 2022-06-11 01:58:52.038997
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create test file
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    tf.close()

    path = tf.name

    # Get the context of the file and test that it is set correctly
    _, context = lgetfilecon_raw(path)
    assert context == 'system_u:object_r:tmp_t:s0'

    # Remove test file
    os.unlink(path)

# Generated at 2022-06-11 01:59:00.972750
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import shutil
    import tempfile

    if not os.path.exists('/tmp/test_selinux_wrapper'):
        os.mkdir('/tmp/test_selinux_wrapper')
        shutil.copytree('tests/selinux_wrapper_data/', '/tmp/test_selinux_wrapper/')
        rc, msg = matchpathcon('/tmp/test_selinux_wrapper/', os.R_OK)
        print(rc, msg)
        print("cleanup")
        shutil.rmtree('/tmp/test_selinux_wrapper')
    else:
        print("skip cleanup")


# Generated at 2022-06-11 01:59:03.206848
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 0) == [0, 'unconfined_u:object_r:root_t:s0']

# Generated at 2022-06-11 01:59:11.870495
# Unit test for function matchpathcon
def test_matchpathcon():
    """ Unit test for function matchpathcon """
    try:
        [rc, con] = matchpathcon('/etc/inittab', 0)
    except OSError:
        if os.path.exists('/etc/inittab'):
            raise
        [rc, con] = matchpathcon(
            '/etc/system-release',
            0
        )
    if rc != 0:
        print('failed matchpathcon: {}'.format(rc))
    if not con:
        print('failed matchpathcon con: {}'.format(con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:59:14.541906
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/bin/zsh', 0)
    assert result == [0, 'system_u:object_r:bin_t:s0']

# Generated at 2022-06-11 01:59:17.855021
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/shadow'
    rc, con = lgetfilecon_raw(path)
    print(''.join(('RC: ', str(rc), '  Con: ', str(con))))



# Generated at 2022-06-11 01:59:20.238350
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    _, con = lgetfilecon_raw('/usr')
    assert con == 'user_u:object_r:user_home_dir_t:s0'



# Generated at 2022-06-11 01:59:30.911929
# Unit test for function matchpathcon
def test_matchpathcon():
    msg = matchpathcon("/", 0)
    print("path: /, mode: 0, context: {}".format(msg[1]))
    msg = matchpathcon("/home/michael", 0)
    print("path: /home/michael, mode: 0, context: {}".format(msg[1]))
    msg = matchpathcon("/home/michael", 1)
    print("path: /home/michael, mode: 1, context: {}".format(msg[1]))
    msg = matchpathcon("/home/michael", 2)
    print("path: /home/michael, mode: 2, context: {}".format(msg[1]))
    # if the directory doesn't exist, an exception will be returned
    msg = matchpathcon("/home/michael/test/path", 0)


# Generated at 2022-06-11 01:59:33.373887
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/group"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    if rc == 0:
        print("Label for '%s' is '%s'" % (path, con))
    else:
        print("matchpathcon failed for '%s'" % path)



# Generated at 2022-06-11 01:59:36.558654
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    rc, ctx = lgetfilecon_raw('/etc/passwd')
    assert rc == 0, "return code is not 0"
    assert ctx == 'system_u:object_r:etc_t:s0', "context is not equal"


# Generated at 2022-06-11 02:00:04.043787
# Unit test for function matchpathcon
def test_matchpathcon():
    if is_selinux_enabled():
        rc, con = matchpathcon('/etc/passwd', 0)
        assert rc == 0, 'matchpathcon returned non-zero'
        assert con == 'system_u:object_r:passwd_file_t', 'matchpathcon returned incorrect context'



# Generated at 2022-06-11 02:00:09.026163
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Validate the module can get file security context
    """
    import sys
    import pytest

    test_file = "/etc/passwd"
    if sys.platform.startswith("darwin"):
        test_file = "/etc/master.passwd"

    rc, con = lgetfilecon_raw(test_file)
    assert rc == 0, con
    assert "user_u:object_r:etc_t" in con, con



# Generated at 2022-06-11 02:00:18.642255
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    NOTE: matchpathcon is deprecated and should be rewritten on selabel_lookup (but will be a PITA)
    '''
    this_dir = os.path.dirname(__file__)
    assert matchpathcon(this_dir, 0) == [0, 'system_u:object_r:selinux_python_test_t:s0']

    rc = matchpathcon('/', 0)
    assert rc[0] == 0
    assert rc[1] == 'system_u:object_r:root_t:s0'

    # test a file that doesn't exist
    rc = matchpathcon('/tmp/doesnotexist12345', 0)
    assert rc[0] == -1
    assert rc[1] == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-11 02:00:23.944636
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    fd, path = tempfile.mkstemp()
    test_con = [
        'system_u:object_r:bin_t:s0',
        'system_u:object_r:usr_t:s0',
    ]
    rc, actual_con = lgetfilecon_raw(path)
    os.close(fd)
    os.unlink(path)
    assert actual_con in test_con


# Generated at 2022-06-11 02:00:28.505725
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Function requires that SELinux is disabled (if not, fail)
    if security_getenforce() != 0:
        return False

    # Try to get an SELinux context, shouldn't work
    try:
        rc, con = lgetfilecon_raw("/")
    except Exception:
        return False
    if rc == 0:
        return False
    return True



# Generated at 2022-06-11 02:00:32.795564
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def check_result(result):
        return (type(result) is list) and (len(result) == 2) and (type(result[0]) is int) and (type(result[1]) is str)

    assert check_result(lgetfilecon_raw(''))



# Generated at 2022-06-11 02:00:35.664210
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/lib/libselinux.so', 0)
    assert matchpathcon(b'/usr/lib/libselinux.so', 0)
