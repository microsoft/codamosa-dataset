

# Generated at 2022-06-11 01:50:46.614655
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from datetime import datetime
    from tempfile import NamedTemporaryFile

    start = datetime.now()
    tempfile = NamedTemporaryFile(delete=False)
    tempfile.close()

    _, con = lgetfilecon_raw(tempfile.name)

    os.unlink(tempfile.name)

    took = datetime.now() - start
    print('took {0} secs'.format(took.microseconds / 1000000.0))

    assert con is not None
    print('con = {0}'.format(con))  # should be user:object_r:user_tmp_t:s0

# Generated at 2022-06-11 01:50:54.770816
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/srv/www'

    try:
        rc, con = lgetfilecon_raw(path)
    except OSError as ex:
        raise AssertionError("OSError found: {0} ({1})".format(ex.errno, os.strerror(ex.errno)))

    if rc != 0:
        raise AssertionError("Function lgetfilecon_raw returned {0} instead of 0".format(rc))

    print("The file {0} is labelled with: {1}".format(path, con))


# Generated at 2022-06-11 01:50:56.895499
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon('/etc/pam.d/system-auth', 0)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-11 01:51:01.027206
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/foo'
    [rc, con] = lgetfilecon_raw(path)
    print('RC:', rc, 'Con:', con)

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:51:02.936378
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/tmp') == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-11 01:51:05.928800
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con != None


# Generated at 2022-06-11 01:51:15.119968
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/', 0)
    assert rc == 0
    assert con == b':file:system_u:object_r:root_t:s0'
    rc, con = matchpathcon('/bin/echo', 0)
    assert rc == 0
    assert con == b':file:system_u:object_r:bin_t:s0'
    rc, con = matchpathcon('/foo/bar/baz', 0)
    assert rc == 2
    assert con is None
    rc, con = matchpathcon(None, 0)
    assert rc == -1
    assert con is None

# Generated at 2022-06-11 01:51:22.666931
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/selinux/config', 0)
    assert rc >= 0
    assert con == 'etc_selinux_t'

    rc, con = matchpathcon('/etc/selinux/', 0)
    assert rc >= 0
    assert con == 'etc_t'

    rc, con = matchpathcon('/etc/', 0)
    assert rc >= 0
    assert con == 'etc_t'

    rc, con = matchpathcon('/usr/', 0)
    assert rc >= 0
    assert con == 'usr_t'

    rc, con = matchpathcon('/usr/local', 0)
    assert rc >= 0
    assert con == 'usr_t'

    rc, con = matchpathcon('/usr/local/', 0)
    assert rc >= 0
   

# Generated at 2022-06-11 01:51:25.874370
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-11 01:51:29.070388
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, result = matchpathcon("/etc/passwd", 0)
    assert rc == 0 and result == "system_u:object_r:passwd_file_t:s0"


# Generated at 2022-06-11 01:51:38.290815
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc', os.R_OK)
    assert(rc == 0 and con == "system_u:object_r:etc_t:s0")
    rc, con = matchpathcon('/proc/1/maps', os.R_OK)
    assert(rc == 0 and con == "system_u:object_r:proc_t:s0")
    rc, con = matchpathcon('/proc/2/maps', os.R_OK)
    assert(rc == 0 and con == "system_u:object_r:proc_t:s0")
    rc, con = matchpathcon('/proc/3/maps', os.R_OK)
    assert(rc == 0 and con == "system_u:object_r:proc_t:s0")
    rc, con = matchpath

# Generated at 2022-06-11 01:51:47.599588
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/hosts', os.R_OK)
    assert rc == 0
    assert con == 'system_u:object_r:net_conf_t:s0'
    (rc, con) = matchpathcon('/etc/hosts', os.W_OK)
    assert rc == -13
    assert con == 'system_u:object_r:net_conf_t:s0'
    (rc, con) = matchpathcon('/etc/hosts', os.X_OK)
    assert rc == 0
    assert con == 'system_u:object_r:net_conf_t:s0'
    (rc, con) = matchpathcon('/etc/hosts/foo', os.R_OK)
    assert rc == -2

# Generated at 2022-06-11 01:51:52.605671
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp', 0)
    assert rc == 0, "matchpathcon failed"
    assert con == 'system_u:object_r:tmp_t:s0', "Expected context %s but got %s instead" % ('system_u:object_r:tmp_t:s0', con)


# Generated at 2022-06-11 01:52:03.293195
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux_functions import matchpathcon
    from stat import S_ISDIR
    from os import stat, makedirs, getenv
    from shutil import rmtree

    tmpdir = getenv('TMPDIR')

    if tmpdir is None:
        tmpdir = '/tmp/'

    fname = tmpdir + "test_selinux_functions.py"
    (rc, ctx) = matchpathcon(fname, S_ISDIR)

    if rc != 0:
        return False

    (rc, ctx) = matchpathcon(fname, 0)

    if rc != 0:
        return False

    fname = tmpdir + "ansible_test_dir"

# Generated at 2022-06-11 01:52:09.404788
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/group')
    assert rc == 0 and con == 'passwd_file_t:object_r:usr_t:s0'

    rc, con = lgetfilecon_raw('/etc/group_does_not_exist')
    assert rc == -1 and con == None



# Generated at 2022-06-11 01:52:16.679768
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    f = '/tmp/test_lgetfilecon_raw.txt'
    path = b'/tmp/test_lgetfilecon_raw.txt'
    try:
        with open(f, 'w') as fd:
            fd.write('test')
        con = c_char_p()
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        assert rc >= 0
        assert b'unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023' == con.value
    finally:
        os.unlink(f)

# Generated at 2022-06-11 01:52:19.820092
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/var/log/local'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == b'var_log_t'

# Generated at 2022-06-11 01:52:23.843460
# Unit test for function matchpathcon
def test_matchpathcon():
    import ctypes
    ctypes.pythonapi.Py_Initialize()
    assert_equals(matchpathcon('/tmp/test', 0), [0, 'system_u:object_r:tmp_t:s0'])
    ctypes.pythonapi.Py_Finalize()

# Generated at 2022-06-11 01:52:30.168304
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from random import randint

    test_dir = "/tmp/selinux_wrapper_pytest" + str(randint(1111, 9999))
    os.mkdir(test_dir)
    try:
        [rc, con] = lgetfilecon_raw(test_dir)
        assert rc == -14  # Function not implemented
        assert con is None
    finally:
        os.rmdir(test_dir)

# Generated at 2022-06-11 01:52:36.466881
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    (handle, path) = tempfile.mkstemp()
    path_bytes = path.encode('utf-8')
    os.close(handle)

    # Make sure the temporary file exists and is empty
    assert os.path.exists(path)
    assert os.stat(path).st_size == 0

    # Get SELinux context of the temporary file
    context = lgetfilecon_raw(path_bytes)[1]

    # Make sure it is non-empty
    assert context

    # Drop the temporary file
    os.unlink(path)

# Generated at 2022-06-11 01:52:41.035391
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/home", 0) == [0, 'user_home_dir_t']

# Generated at 2022-06-11 01:52:45.719793
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/tmp'
    # Check if the path we test exists
    assert os.path.exists(test_path) is True
    # Check if selinux is enabled
    assert is_selinux_enabled() is True
    # Check if the return code is 0 and the context is not None
    assert lgetfilecon_raw(test_path)[0] == 0 and lgetfilecon_raw(test_path)[1] is not None

# Generated at 2022-06-11 01:52:49.344063
# Unit test for function matchpathcon
def test_matchpathcon():
    print("matchpathcon('/etc/passwd', 0):", matchpathcon('/etc/passwd', 0))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:52:52.877896
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    with tempfile.NamedTemporaryFile() as fd:
        rc, con = lgetfilecon_raw(fd.name)
        assert rc == 0
        assert con == "system_u:object_r:temp_t:s0"


# Generated at 2022-06-11 01:52:58.590780
# Unit test for function matchpathcon
def test_matchpathcon():
    # Function matchpathcon is deprecated and has been removed from libselinux. This test is merely to
    # ensure that the ctypes wrapper works and we can call matchpathcon during runtime.
    try:
        assert matchpathcon('/bin', 0) == [0, 'bin_t']
    except AttributeError:
        raise AssertionError('matchpathcon function is missing')

# Generated at 2022-06-11 01:53:00.890128
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, result = lgetfilecon_raw("/etc/passwd")
    print(rc)
    print(result)



# Generated at 2022-06-11 01:53:04.655167
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/sys/kernel/debug/'
    rc = lgetfilecon_raw(path)
    assert rc == [0, 'system_u:object_r:debug_file_t:s0']

# Generated at 2022-06-11 01:53:15.415050
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def test_getfilecon(path, expected_rc, expected_con):
        rc, con = lgetfilecon_raw(path)
        assert rc == expected_rc, 'Unexpected return code: {0} != {1} when calling lgetfilecon(path={2})'.format(rc, expected_rc, path)
        if expected_rc == 0:
            assert con == expected_con, 'Unexpected context: {0} != {1} when calling lgetfilecon(path={2})'.format(con, expected_con, path)

    test_getfilecon('/proc/1/mountinfo', 0, '<<none>>')
    test_getfilecon('/proc/1/cgroups', 0, '<<none>>')
    test_getfilecon('/proc/1/cmdline', 0, '<<none>>')


# Generated at 2022-06-11 01:53:20.757338
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/test.txt'
    f = open(path, 'w+')
    f.write('Hello World')
    f.close()
    try:
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
    finally:
        os.remove('/tmp/test.txt')



# Generated at 2022-06-11 01:53:23.912797
# Unit test for function matchpathcon
def test_matchpathcon():
    ret, con = matchpathcon('', 0)
    assert ret == 0
    assert con == 'system_u:object_r:unlabeled_t:s0'



# Generated at 2022-06-11 01:53:34.228007
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Starting unit test for matchpathcon")
    _selinux_lib.matchpathcon = lambda x, y, z: -1
    from ansible_collections.ansible.community.plugins.module_utils.selinux import matchpathcon
    assert matchpathcon("foo", 1) == (-1, None)
    print("Passed unit test for matchpathcon")



# Generated at 2022-06-11 01:53:42.081390
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import json
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdirname:
        testfile = os.path.join(tmpdirname, 'testfile')
        with open(testfile, 'w') as fh:
            fh.write("foo bar")
        rc, output = lgetfilecon_raw(to_bytes(testfile))
        print("rc = %d" % rc)
        print("output = %s" % output)
        print("error = %s" % os.strerror(errno))

# Generated at 2022-06-11 01:53:46.377449
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test function lgetfilecon_raw("/etc/shadow")
    """
    test = lgetfilecon_raw("/etc/shadow")
    assert test[0] == 1
    assert test[1] == "system_u:object_r:shadow_t:s0"



# Generated at 2022-06-11 01:53:50.671260
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file = os.path.realpath(__file__)

    if(os.path.exists(file)):
        [rc, context] = lgetfilecon_raw(file)

        if rc == 0:
            print(context)
        else:
            print('ERROR: {0}'.format(rc))



# Generated at 2022-06-11 01:53:52.711076
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "data/dummy"
    print(matchpathcon(path, 0))



# Generated at 2022-06-11 01:53:59.711217
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = "ansible_test"
    tmp_fp = open(test_path, 'w')
    tmp_fp.write("test")
    tmp_fp.close()
    expected = matchpathcon(test_path, os.stat(test_path).st_mode)
    if expected == 0:
        print("Matched: " + str(expected))
    else:
        print("Didn't match: " + str(expected))
    os.unlink(test_path)

# Generated at 2022-06-11 01:54:06.859598
# Unit test for function matchpathcon
def test_matchpathcon():
    # Match a file
    file_path = 'tests/functional/module_utils/ansible_test_folder_selinux/test_file'
    mode = 0
    rc = matchpathcon(file_path, mode)
    assert rc[0] == 0
    assert rc[1] == 'system_u:object_r:tmp_t:s0'

    # Match a directory
    dir_path = 'tests/functional/module_utils/ansible_test_folder_selinux'
    mode = 1
    rc = matchpathcon(dir_path, mode)
    assert rc[0] == 0
    assert rc[1] == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-11 01:54:08.684439
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-11 01:54:11.691941
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/'
    rc, con = lgetfilecon_raw(path)
    print(rc, con)


# Generated at 2022-06-11 01:54:16.452945
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw("/etc/hosts")
    print('{0}'.format(ret))
    assert ret[0] == 0
    assert ret[1] == "system_u:object_r:etc_runtime_t:s0"


# Generated at 2022-06-11 01:54:24.512449
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    bc = lgetfilecon_raw('/usr')
    assert type(bc[0]) == int
    assert type(bc[1]) == str
    assert bc[0] == 0
    assert bc[1] == 'usr_t'



# Generated at 2022-06-11 01:54:28.907768
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    res = lgetfilecon_raw("/selinux")
    assert res == [0, 'system_u:object_r:selinuxfs:s0']
    res = lgetfilecon_raw("/nonexistingfile")
    assert res == [errno.ENOENT, '']

# Generated at 2022-06-11 01:54:34.005709
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        rc, con = matchpathcon(path, 0)
        assert rc == 0
        assert con == 'unconfined_u:object_r:user_tmp_t:s0'
    finally:
        os.unlink(path)

# Generated at 2022-06-11 01:54:44.707854
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def runtest(test_path):
        try:
            # check that path exists
            assert os.path.exists(test_path), test_path
            # check that lgetfilecon_raw works
            rc, con = lgetfilecon_raw(test_path)
            assert rc == 0 and con, '{0} rc={1} con={2}'.format(test_path, rc, con)
        except AssertionError:
            sys.stderr.write('TEST FAILED: {0}\n'.format(test_path))

    test_path = os.environ.get('SELINUX_TEST_PATH', '/')


# Generated at 2022-06-11 01:54:53.699894
# Unit test for function matchpathcon
def test_matchpathcon():
    set_path = '/tmp/file'
    mode = 0o0644
    [rc, con] = matchpathcon(set_path, mode)
    if rc < 0:
        raise OSError("Unable to get file context of {0}".format(set_path))

    if not con.startswith('system_u:object_r:user_tmp_t:'):
        raise ValueError("Unexpected result: {0} for path {1}. Expected to start with 'system_u:object_r:user_tmp_t:'".format(con, set_path))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:55:05.077018
# Unit test for function matchpathcon
def test_matchpathcon():
    # no SELinux test environment available
    if selinux_getenforcemode()[1] != 0:
        return

    # no SELinux test environment available
    if selinux_getpolicytype()[1] != "ubuntu":
        return

    # no SELinux test environment available
    if selinux_getpolicytype()[1] != "ubuntu":
        return

    # no SELinux test environment available
    if not os.path.exists('/etc/selinux/config'):
        return

    # no SELinux test environment available
    if not os.path.exists('/usr/sbin/selinuxenabled'):
        return

    # in permissive test environment just return
    if selinux_getenforcemode()[1] != 1:
        return

    # test the

# Generated at 2022-06-11 01:55:13.702138
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import pytest
    from tempfile import TemporaryDirectory
    from ctypes import C_NULL
    from ansible.module_utils.selinux import matchpathcon
    from base64 import b64encode


# Generated at 2022-06-11 01:55:15.455608
# Unit test for function matchpathcon
def test_matchpathcon():
    results = matchpathcon('/etc/passwd', 0)
    assert(results[0] >= 0)
    assert(results[1] == 'system_u:object_r:etc_runtime_t:s0')

# Generated at 2022-06-11 01:55:21.870143
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    sys.modules['selinux'] = sys.modules[__name__]
    from ansible.module_utils import selinuxutils
    selinux = selinuxutils.SELinuxUtils()
    rc, con = selinux.getfilecon_raw('/tmp')
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'
    del sys.modules['selinux']

# Generated at 2022-06-11 01:55:27.098190
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    This testcase the function _selinux.matchpathcon.
    The matchpathcon function matches a pathname to a context stored in a
    persistent database.  The function returns the context for the path
    specified.  This testcase verifies the context value and the status code
    returned by matchpathcon is as expected.
    """
    path = "/selinux"
    mode = 32771
    status, context = matchpathcon(path, mode)
    assert status == -1
    assert context is None

# Generated at 2022-06-11 01:55:35.325351
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test function matchpathcon
    """
    path = "/tmp"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:tmp_t:s0"

# Generated at 2022-06-11 01:55:39.808306
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    This test is just to give an example of how matchpathcon works.
    '''
    # pylint: disable=undefined-variable
    rc, con = matchpathcon('/etc', 0)
    if rc >= 0:
        print('/etc context is %s' % con)
    else:
        raise AssertionError('con not returned')

# Generated at 2022-06-11 01:55:43.299293
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    with tempfile.NamedTemporaryFile() as fp:
        ret = matchpathcon(fp.name, 0)
        assert ret[0] == 0
        assert ret[1] == 'system_u:object_r:default_t:s0'

# Generated at 2022-06-11 01:55:52.299346
# Unit test for function matchpathcon
def test_matchpathcon():
    import os.path
    import tempfile

    fd, fp = tempfile.mkstemp()
    os.close(fd)
    os.unlink(fp)

    rc, fp_con = matchpathcon(fp, os.R_OK)
    assert rc == 0
    assert fp_con

    rc, dir_con = matchpathcon(os.path.dirname(fp), os.R_OK)
    assert rc == 0
    assert dir_con == fp_con

    rc, tmp_con = matchpathcon('/tmp', os.R_OK)
    assert rc == 0
    assert tmp_con != dir_con


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:55:55.218918
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/etc/passwd", 0) == [0, 'system_u:object_r:etc_runtime_t:s0']



# Generated at 2022-06-11 01:56:06.133738
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import is_selinux_enabled
    from ansible.module_utils.selinux import is_selinux_mls_enabled
    from ansible.module_utils.selinux import selinux_getenforcemode
    from ansible.module_utils.selinux import selinux_getpolicytype
    from ansible.module_utils.selinux import security_policyvers
    from ansible.module_utils.selinux import matchpathcon

    if is_selinux_enabled():
        print("selinux is enabled")
    else:
        print("selinux is not enabled")

    if is_selinux_mls_enabled():
        print("selinux is mls enabled")
    else:
        print("selinux is not mls enabled")

# Generated at 2022-06-11 01:56:09.291298
# Unit test for function matchpathcon
def test_matchpathcon():
    path, mode = 'test', 0o655
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:userns_var_lib_t:s0'

# Generated at 2022-06-11 01:56:15.049779
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/"
    [rc, con] = lgetfilecon_raw(path)
    assert rc == 0
    assert con == "system_u:object_r:tmp_t:s0"

    path = "/tmp/nosuchfile"
    [rc, con] = lgetfilecon_raw(path)
    assert rc == -1
    assert con == None


# Generated at 2022-06-11 01:56:21.277033
# Unit test for function matchpathcon
def test_matchpathcon():
    # NB: the return code of this function is the drive letter "D" when the path is on a windows drive and
    # the drive letter is in lowercase.  Unfortunately, this is not documented anywhere in the selinux
    # documentation...
    import platform
    test_path = '/etc/passwd'
    if platform.system().lower() == 'windows':
        test_path = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'

    rc, result = matchpathcon(test_path, 0)
    assert rc >= 0

# Generated at 2022-06-11 01:56:30.740574
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.basic import *
    if not module_utils.is_selinux_enabled():
        module.exit_json(changed=False, msg="selinux is not enabled")

    path = "/home/user/test.txt"

    module = AnsibleModule(argument_spec=dict(
        path=dict(type='str', default="/home/user/test.txt"),
        mode=dict(type='int', default=32768),
    ))

    path = module.params['path']
    mode = module.params['mode']

    rc, con = matchpathcon(path, mode)
    if rc == 0:
        module.exit_json(changed=True, msg="matchpathcon: %s" % con)

# Generated at 2022-06-11 01:56:50.381008
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import sys
    import subprocess

    # create test file
    fn = '/tmp/mctester.txt'
    with open(fn, 'w') as f:
        f.write("This is a test.")

    # get the type of the file
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(fn, byref(con))
        fcon = to_native(con.value)
    finally:
        _selinux_lib.freecon(con)

    # set the type of the file
    rc = _selinux_lib.lsetfilecon(fn, 'user_home_dir_t')

    # get the type of the file
    con = c_char_p()

# Generated at 2022-06-11 01:56:52.071843
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/")
    assert rc == 0
    assert con is not None

# Generated at 2022-06-11 01:56:55.092653
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/bin/ls'
    rc, con = lgetfilecon_raw(path)
    print('Return code: %s' % rc)
    print('File context: %s' % con)


# Generated at 2022-06-11 01:56:57.983246
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/test_file", 0) == [0, "system_u:object_r:user_home_t:s0"]



# Generated at 2022-06-11 01:57:00.742593
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert (lgetfilecon_raw(b'/etc')) == [0, u'unconfined_u:object_r:etc_t:s0']



# Generated at 2022-06-11 01:57:11.706684
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon("/tmp", 0)
    assert (ret[0] > -1), "matchpathcon did not return a valid status for the file /tmp"
    if ret[0] == 0:
        print("Security context for /tmp is: " + ret[1])

    ret = matchpathcon("/tmp", 0o700)
    assert (ret[0] > -1), "matchpathcon did not return a valid status for the file /tmp with mode 0o700"
    if ret[0] == 0:
        print("Security context for /tmp with mode 0o700 is: " + ret[1])

    ret = matchpathcon("/tmp", 0o600)
    assert (ret[0] > -1), "matchpathcon did not return a valid status for the file /tmp with mode 0o600"

# Generated at 2022-06-11 01:57:19.751695
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon_path = '/etc'
    mode = 0
    rc, con = matchpathcon(matchpathcon_path, mode)
    if rc != 0:
        print('Error in matchpathcon')
        sys.exit(1)
    if con:
        print('Context for {0} is {1}'.format(matchpathcon_path, con))
    else:
        print('No context for {0}'.format(matchpathcon_path))
    sys.exit(0)



# Generated at 2022-06-11 01:57:26.443577
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Verify that lgetfilecon_raw returns the security context of a specified file
    from ansible.module_utils import basic
    args = {}
    if basic.AnsibleModule(argument_spec=args).check_mode:
        # Check mode does not modify state
        pass
    else:
        # Execute module code
        pass
    # Verify idempotency
    if basic.AnsibleModule(argument_spec=args).check_mode:
        # Check mode does not modify state
        pass
    else:
        # Execute module code
        pass

# Generated at 2022-06-11 01:57:30.853860
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor', os.R_OK)
    if rc != 0:
        raise OSError('unable to get SELinux context')

    print(con)



# Generated at 2022-06-11 01:57:33.157789
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-11 01:57:55.433781
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/shadow') == [0, 'system_u:object_r:shadow_t']


# Generated at 2022-06-11 01:58:05.277395
# Unit test for function matchpathcon
def test_matchpathcon():
    # ensure the selinux shared object is on the path
    import ctypes
    from ctypes import wintypes

    ctypes.windll.kernel32.SetDllDirectoryW.argtypes = (wintypes.LPCWSTR,)
    ctypes.windll.kernel32.SetDllDirectoryW(None)

    # grab the initial message that the shared object was loaded
    ret = matchpathcon(None, 0)

    # set to safe context
    assert 0 == lsetfilecon(b"/", b"system_u:object_r:tmp_t:s0")

    # change context to system_u:object_r:tmp_t:s0
    # the :s0 is needed for systems that aren't using MLS

# Generated at 2022-06-11 01:58:12.090073
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with file that exists
    path = '/tmp/test_selinux'
    mode = os.R_OK

    os.open(path, os.O_CREAT, 0o600)

    [rc, con] = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:user_home_t:s0"

    os.remove(path)

    # Test with file that does not exist
    [rc, con] = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:user_home_t:s0"

    # Test with wrong access mode
    path = '/etc/passwd'
    mode = os.W_OK

    [rc, con] = matchpathcon(path, mode)

# Generated at 2022-06-11 01:58:20.705224
# Unit test for function matchpathcon
def test_matchpathcon():

    path = "./ansible-selinux/tests/files/context/matchpathcon_test_file"
    ret = matchpathcon(path, 0)
    if ret[0] != 0:
        print("Problem with matchpathcon\n")
        exit(1)

    print(ret[1])

    path = "./ansible-selinux/tests/files/context/matchpathcon_test_file1"
    ret = matchpathcon(path, 0)
    if ret[0] != 0:
        print("Problem with matchpathcon\n")
        exit(1)

    print(ret[1])

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:58:30.193787
# Unit test for function matchpathcon
def test_matchpathcon():
    from tempfile import mkdtemp, mkstemp
    from shutil import rmtree

    try:
        tmp_dir = mkdtemp()
        path = tmp_dir + '/test_matchpathcon_file'
        fd, path = mkstemp()

        assert matchpathcon(path, 0) == [0, 'system_u:object_r:user_tmp_t:s0']

        assert _selinux_lib.chcon(tmp_dir, 'system_u:object_r:tmp_t:s0') == 0

        assert matchpathcon(path, 0) == [0, 'system_u:object_r:tmp_t:s0']

    finally:
        os.close(fd)
        rmtree(tmp_dir)


# Generated at 2022-06-11 01:58:39.005996
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert 0 == _selinux_lib.is_selinux_enabled()[0]
    assert 0 == _selinux_lib.is_selinux_mls_enabled()[0]
    assert 3 == _selinux_lib.security_policyvers()
    assert 0 == _selinux_lib.security_getenforce()[0]
    assert 0 == _selinux_lib.selinux_getenforcemode()[0]
    assert 0 == _selinux_lib.selinux_getpolicytype()[0]
    assert 0 == lgetfilecon_raw('/etc/motd')[0]
    assert 0 == lgetfilecon_raw('/etc/hosts')[0]



# Generated at 2022-06-11 01:58:42.321203
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    PATH = b"/var/log"

    rc, con = lgetfilecon_raw(PATH)
    assert rc >= 0, "unexpected return value from lgetfilecon_raw"

    print("path: {0}, con: {1}".format(PATH, con))



# Generated at 2022-06-11 01:58:49.775424
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Function for testing function lgetfilecon_raw
    :return: True on success, False on failure.
    """
    test_path = '/tmp/test_selinux_utils_file'
    rc, con = lgetfilecon_raw(path=test_path)
    assert rc == 0
    assert con.startswith('system_u:object_r:')
    os.remove(test_path)
    return True

# Generated at 2022-06-11 01:58:58.668774
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    try:
        fd, tmp = tempfile.mkstemp()
        os.close(fd)

        con, rc = lgetfilecon_raw(tmp)

        assert con == 'system_u:object_r:tmp_t:s0'

        # NB: we don't actually care what the error code is as long as
        # it is negative
        assert rc < 0
    finally:
        os.unlink(tmp)


# Unit function test for function matchpathcon

# Generated at 2022-06-11 01:59:03.393902
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    temp_f = tempfile.NamedTemporaryFile(suffix=".txt")
    temp_path = temp_f.name
    # Pass sample path to matchpathcon
    try:
        rc, con = matchpathcon(temp_path, 0)
        assert isinstance(con, str)
        assert not isinstance(con, bytes)
        assert rc == 0
    finally:
        temp_f.close()

# Generated at 2022-06-11 01:59:49.766921
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import pwd
    import grp
    # Create a file to run test on
    os.mkdir("test_file")
    os.chown("test_file", pwd.getpwnam("root").pw_uid, grp.getgrnam("root").gr_gid)
    # Call lgetfilecon_raw
    assert lgetfilecon_raw("test_file") == [0, 'unconfined_u:object_r:user_home_dir_t:s0']
    # Clean up
    os.rmdir("test_file")

# Generated at 2022-06-11 01:59:56.432946
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file_name = "/etc/hosts"
    con = c_char_p()

    rc = _selinux_lib.lgetfilecon_raw(test_file_name, byref(con))

    if rc == 0:
        assert to_native(con.value) == "system_u:object_r:net_conf_t:s0"
    else:
        raise Exception("Error code: {}".format(rc))


# Generated at 2022-06-11 02:00:01.812441
# Unit test for function matchpathcon
def test_matchpathcon():
    module = AnsibleModule(argument_spec=dict(
        path=dict(type='str', required=True),
        mode=dict(type='int', required=True),
    ))

    path = os.path.dirname(__file__)
    mode = os.R_OK
    rc, out = matchpathcon(path, mode)
    module.exit_json(rc=rc, out=out)



# Generated at 2022-06-11 02:00:05.228916
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/test/test1'
    mode = 0o666
    rc, mode = matchpathcon(path, mode)
    if rc >= 0:
        assert(mode == "system_u:object_r:test_t:s0")
    else:
        print(os.strerror(rc))


# Generated at 2022-06-11 02:00:07.877820
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, mode = lgetfilecon_raw("/usr/bin/nc")
    assert rc == 0
    assert mode == "unconfined_u:object_r:bin_t:s0"

# Generated at 2022-06-11 02:00:15.426311
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if _selinux_lib.is_selinux_enabled():
        con = c_char_p()
        try:
            rc = _selinux_lib.lgetfilecon_raw("/etc/passwd", byref(con))
            if (rc == 0):
                print("/etc/passwd context: " + to_native(con.value))
            else:
                print("Failed to get context of /etc/passwd!! errno: " + to_native(con.value))
        finally:
            _selinux_lib.freecon(con)


# Generated at 2022-06-11 02:00:24.117099
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.utils.selinux import SELINUX_CONTEXT_DEFAULT
    from ansible.module_utils._text import to_bytes
    files = [('/etc/hosts', SELINUX_CONTEXT_DEFAULT),
             ('/etc/passwd', SELINUX_CONTEXT_DEFAULT),
             ('/etc/group', SELINUX_CONTEXT_DEFAULT),
             ('/etc/shadow', SELINUX_CONTEXT_DEFAULT),
             ('/etc/gshadow', SELINUX_CONTEXT_DEFAULT),
             ('/etc/sudoers', SELINUX_CONTEXT_DEFAULT),
             ('/etc/sudoers.d', SELINUX_CONTEXT_DEFAULT)]


# Generated at 2022-06-11 02:00:26.688838
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rtn = lgetfilecon_raw(b'/etc')
    print('lgetfilecon_raw returns', rtn)
    return rtn[0] != -1


# Generated at 2022-06-11 02:00:28.780034
# Unit test for function matchpathcon
def test_matchpathcon():
    r = matchpathcon('/etc/hosts', 0)
    assert r == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-11 02:00:33.604286
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    print('rc: {0} con: {1}'.format(rc, con))
    if rc != 0:
        raise Exception('selinux unit test failed: {0}'.format(rc))

