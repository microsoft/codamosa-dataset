

# Generated at 2022-06-11 01:50:38.648369
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']

# Generated at 2022-06-11 01:50:41.648245
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/sys/kernel/debug', os.R_OK)
    assert(res[1].startswith('system_u:object_r:'))

# Generated at 2022-06-11 01:50:43.473252
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert len(lgetfilecon_raw('/etc/passwd')) == 2, 'lgetfilecon_raw function is broken'

# Generated at 2022-06-11 01:50:45.866047
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # print the context of current module
    print(lgetfilecon_raw(__name__))



# Generated at 2022-06-11 01:50:50.675968
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/etc/hosts', 0)
    if rc != 0:
        print('failed to get matchpathcon')
        return False
    print('context: {}'.format(con))
    return True

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:51:01.698969
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert matchpathcon('/etc/os-release', os.F_OK)[0] == 0
    except AssertionError:
        raise AssertionError('matchpathcon function did not return expected value')

    try:
        assert matchpathcon('/dev/null', os.F_OK)[0] == 0
    except AssertionError:
        raise AssertionError('matchpathcon function did not return expected value')

    try:
        assert matchpathcon('/bin/false', os.F_OK)[0] == 0
    except AssertionError:
        raise AssertionError('matchpathcon function did not return expected value')

    try:
        assert matchpathcon('/etc/os-release', os.W_OK)[0] == 0
    except AssertionError:
        raise Assertion

# Generated at 2022-06-11 01:51:03.321403
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print(lgetfilecon_raw(b'/etc/passwd'))


# Generated at 2022-06-11 01:51:11.116293
# Unit test for function matchpathcon
def test_matchpathcon():
    assert security_getenforce() == 1
    assert lgetfilecon_raw('/etc/shadow') == [0, 'system_u:object_r:shadow_t:s0']
    assert matchpathcon('/etc/shadow', 0) == [0, 'system_u:object_r:shadow_t:s0']
    assert matchpathcon('/etc/shadow', 16384) == [0, 'system_u:object_r:shadow_t:s0']

# Generated at 2022-06-11 01:51:15.925393
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/shadow'
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        assert rc == 0
    finally:
        _selinux_lib.freecon(con)


# Generated at 2022-06-11 01:51:23.024834
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    rc, selabel = matchpathcon("/", 0)
    assert(rc == 0)
    rc, selabel = matchpathcon("/etc/hosts", 0)
    assert(rc == 0)
    rc, selabel = matchpathcon("/etc/hosts", os.R_OK)
    assert(rc == 0)
    rc, selabel = matchpathcon("/etc/hosts", os.R_OK | os.W_OK)
    assert(rc == 0)
    rc, selabel = matchpathcon("/etc/hosts", os.R_OK | os.W_OK | os.X_OK)
    assert(rc == 0)
    rc, selabel = matchpathcon("/dev/null", 0)
    assert(rc == 0)
    rc, selabel = matchpath

# Generated at 2022-06-11 01:51:31.853787
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw(b'/proc/cpuinfo')
    print('rc={0} con={1}'.format(rc, con))
    if rc < 0:
        raise OSError(rc, os.strerror(rc))


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:51:42.171290
# Unit test for function matchpathcon
def test_matchpathcon():
    data_dir = os.path.dirname(os.path.abspath(__file__)) + '/../../data/selinux/'

    # Prepare test data
    # data[0]: expected return code
    # data[1]: mode
    # data[2]: path
    # data[3]: expected security context

# Generated at 2022-06-11 01:51:52.203709
# Unit test for function matchpathcon
def test_matchpathcon():
    import unittest
    import tempfile
    from os import path

    class MatchPathConTestCase(unittest.TestCase):

        def setUp(self):
            self.tempdir = tempfile.TemporaryDirectory()
            self.cwd = path.abspath(self.tempdir.name)
            self.file_path = path.join(self.cwd, 'file')

        def tearDown(self):
            self.tempdir.cleanup()

        def test_matchpathcon_return_value(self):
            import os

            rc, con = matchpathcon(self.file_path, os.R_OK)
            self.assertEqual(rc, 0)
            self.assertEqual(con, 'system_u:object_r:default_t:s0')


# Generated at 2022-06-11 01:51:58.822505
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.ansible.community.plugins.module_utils.selinux import (
        matchpathcon
    )

    rc = matchpathcon("/test_matchpathcon", 0)
    assert rc[0] == 0
    assert rc[1] == 'system_u:object_r:usr_t:s0'

    rc = matchpathcon("/test_matchpathcon2", 0)
    assert rc[0] == 2

# Generated at 2022-06-11 01:52:02.743103
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Note that this test assumes that the user running the test on the system has an SELinux context that starts with "unconfined_u"
    result, path_context = lgetfilecon_raw('/')
    assert result == 0
    assert path_context.startswith('unconfined_u')



# Generated at 2022-06-11 01:52:06.082865
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(".") == [0, "unconfined_u:object_r:user_home_t:s0"]


# Generated at 2022-06-11 01:52:13.027827
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        raise ImportError('SELinux is not enabled')
    (rc, fcon) = lgetfilecon_raw('/etc/passwd')
    if rc < 0:
        raise ImportError('Error getting file context: %s' % os.strerror(rc))
    assert rc == 0
    print('/etc/passwd context: %s' % fcon)



# Generated at 2022-06-11 01:52:17.945761
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/tmp')
    if rc == -1:
        try:
            (rc2, enforcemode) = selinux_getenforcemode()
            if rc2 == 0 and enforcemode == 0:
                return True
        except:
            pass
        return False
    else:
        return True



# Generated at 2022-06-11 01:52:28.376446
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    fd, path = tempfile.mkstemp(prefix='test_matchpathcon-')
    try:
        assert matchpathcon(path, 0) == [0, 'system_u:object_r:tmp_t:s0']

        os.unlink(path)
        rc, con = matchpathcon(path, 0)
        assert rc == -1
        assert con == ''

        assert selinux_getenforcemode() == [0, 1]

        rc, policy = selinux_getpolicytype()
        assert rc == 0

        rc, con = lgetfilecon_raw(path)
        assert rc == -1
        assert con == ''
    finally:
        os.unlink(path)

# Generated at 2022-06-11 01:52:30.902244
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    libselinux_so_1 = CDLL('libselinux.so.1', use_errno=True)
    return lgetfilecon_raw(libselinux_so_1)

# Generated at 2022-06-11 01:52:40.580139
# Unit test for function matchpathcon
def test_matchpathcon():
    import pprint

    try:
        rc, value = matchpathcon('/tmp', 0)
        print('rc: {0}\nvalue: {1}'.format(rc, pprint.pprint(value)))
    except OSError as e:
        print('OSError: {0}'.format(to_native(e)))
    except Exception as e:
        print('Exception: {0}'.format(to_native(e)))

# Generated at 2022-06-11 01:52:43.618223
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw("/etc/passwd")
    assert ret[0] == 0

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:52:54.059086
# Unit test for function matchpathcon

# Generated at 2022-06-11 01:53:00.138305
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        # Get the con value for /etc/shadow file
        # This will fail on macOS as file doesn't exist
        # and give ImportError
        rc, con = lgetfilecon_raw('/etc/shadow')
        assert rc == 0
        assert con == 'unconfined_u:object_r:shadow_t:s0'
    except ImportError:
        print('This test will fail on macOS as the file doesn\'t exist on this system')

# Generated at 2022-06-11 01:53:05.094350
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/home/ansible/ansible/lib/ansible/module_utils/selinux.py'
    rc, con = matchpathcon(path, os.F_OK)
    assert rc == 0
    assert con == 'system_u:object_r:file_t:s0'


# Generated at 2022-06-11 01:53:13.786801
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    try:
        rc, con = lgetfilecon_raw('/var/www')
    except FileNotFoundError:
        print('/var/www does not exist, skipping test')
        sys.exit(0)

    if rc != 0:
        print('File stat failed')
        sys.exit(rc)

    if not con.startswith('unconfined_u:object_r:'):
        print('Expected unconfined_u:object_r: ..., got ' + str(con))
        sys.exit(1)

    sys.exit(0)



# Generated at 2022-06-11 01:53:15.544724
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/bogus')
    assert rc == -1
    assert con == None



# Generated at 2022-06-11 01:53:27.309001
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os

    file_with_context = "/usr/share"
    file_without_context = "/root"

    if os.getuid():
        raise AssertionError('test must be executed as root')

    [rc, context] = lgetfilecon_raw(file_with_context)

    if rc == 0:
        print('The file "%s" has the context "%s"' % (file_with_context, context))
    else:
        raise AssertionError('test must be executed on SELinux enabled system')

    [rc, context] = lgetfilecon_raw(file_without_context)

    if rc == 0:
        raise AssertionError('test must be executed on SELinux enabled system')
    else:
        print('The file "%s" has no context' % file_without_context)

# Generated at 2022-06-11 01:53:30.863543
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, context] = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert 'system_u:object_r:etc_t:s0' == context


# Generated at 2022-06-11 01:53:39.165520
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test ENOENT
    try:
        lgetfilecon_raw('/foo/bar')
    except IOError as e:
        if e.errno == 2:
            print('Pass: lgetfilecon_raw() returned error code 2')
        else:
            raise(e)

    # Test EPERM
    try:
        lgetfilecon_raw('/dev/tty0')
    except IOError as e:
        if e.errno == 1:
            print('Pass: lgetfilecon_raw() returned error code 1')
        else:
            raise(e)

if __name__ == '__main__':
    test_lgetfilecon_raw()