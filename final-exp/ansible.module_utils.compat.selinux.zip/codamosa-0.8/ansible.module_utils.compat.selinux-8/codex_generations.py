

# Generated at 2022-06-11 01:50:41.794400
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/foo", 0)
    print("return code: {}, context: {}".format(rc, con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:50:43.882186
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = b'/'
    rc, con = lgetfilecon_raw(test_path)
    assert isinstance(con, str)



# Generated at 2022-06-11 01:50:48.684497
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = matchpathcon("/tmp", 0)
        assert rc == 0 and con == "system_u:object_r:tmp_t:s0"
    except ImportError:
        raise AssertionError("SELinux python bindings not found")

# Generated at 2022-06-11 01:50:57.887538
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create a test context string:
    #  - user: apache
    #  - role: object_r
    #  - type: httpd_sys_content_t
    #  - range: s0
    path = '/var/www/html/test.html'
    context_string = 'system_u:object_r:httpd_sys_content_t:s0'
    file_context = c_char_p()
    rc = _selinux_lib.matchpathcon(path, 0, byref(file_context))
    assert rc == 0
    assert to_native(file_context.value) == context_string

# Generated at 2022-06-11 01:51:09.385598
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

# Generated at 2022-06-11 01:51:16.209765
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw(b'/usr')
    assert rc == 0
    assert con.startswith(b'system_u')


## Unit test for function matchpathcon
#def test_matchpathcon():
#    (rc, con) = matchpathcon(b'/usr', 0)
#    assert rc == 0
#    assert con.endswith(b':dir:system_u:object_r:usr_t')
#

# Generated at 2022-06-11 01:51:19.704134
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    output = lgetfilecon_raw('/tmp')
    assert isinstance(output, list)
    assert len(output) == 2
    assert isinstance(output[0], c_int)
    assert isinstance(output[1], str)


# Generated at 2022-06-11 01:51:26.619833
# Unit test for function matchpathcon
def test_matchpathcon():

    path = b'/var/tmp/test/test.txt'
    mode = 1
    con = c_char_p()

    rc = _selinux_lib.matchpathcon(path, mode, byref(con))

    print('return value: ' + str(rc))
    print('object context: ' + to_native(con.value))

    _selinux_lib.freecon(con)



# Generated at 2022-06-11 01:51:29.399378
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/etc/passwd', 0) == [0, 'system_u:object_r:passwd_file_t:s0']



# Generated at 2022-06-11 01:51:30.728827
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r, ret = lgetfilecon_raw(b'/etc/mtab')
    print('lgetfilecon_raw() returned {0}, {1}'.format(r, ret))



# Generated at 2022-06-11 01:51:43.070182
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """verify the functionality of lgetfilecon()"""

    # file context match
    test_file = './test_selinux'
    file_con = 'test_selinux:test_selinux_type:test_selinux_level:test_selinux_range'
    fp = open(test_file, 'w+')
    fp.close()
    rc, con = lgetfilecon_raw(test_file)
    if rc == -1:
        raise Exception("Error: lgetfilecon_raw() failed {0}: {1}".format(rc, con))

    if con == file_con:
        print("PASSED: lgetfilecon_raw() passed for {0}".format(con))

# Generated at 2022-06-11 01:51:45.631205
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con_value = matchpathcon('/tmp/foo.txt', 0)
    assert rc == 0
    assert con_value == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-11 01:51:54.574935
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import os.path


# Generated at 2022-06-11 01:51:56.064442
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp')[0] == 0

# Generated at 2022-06-11 01:52:05.814145
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test selinux matchpathcon
    """
    (rc, con) = matchpathcon('/tmp', 0)
    assert rc >= 0, "selinux matchpathcon failed"
    assert con == "system_u:object_r:tmp_t:s0", "selinux matchpathcon produced wrong context"

    (rc, con) = matchpathcon('/etc/hosts', 0)
    assert rc < 0, "selinux matchpathcon on non-existent path succeeded"
    assert rc == -1 * os.errno.ENOENT and os.strerror(os.errno.ENOENT) == con, "selinux matchpathcon failed"

    (rc, con) = matchpathcon('/var', 0)
    assert rc >= 0, "selinux matchpathcon failed"

# Generated at 2022-06-11 01:52:08.920868
# Unit test for function matchpathcon
def test_matchpathcon():
    assert [0, 'system_u:object_r:cgroup_t:s0'] == matchpathcon('/sys/fs/cgroup', 0)

# Generated at 2022-06-11 01:52:13.418332
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    path = os.path.join(tempfile.gettempdir(), 'test_matchpathcon')
    os.mknod(path)
    mode = os.stat(path).st_mode
    print(matchpathcon(path, mode))



# Generated at 2022-06-11 01:52:15.352165
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/test')
    assert rc == 0

# Generated at 2022-06-11 01:52:18.834088
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0, 'rc is non-zero'
    assert con is None, 'con is not None'


# Generated at 2022-06-11 01:52:26.698388
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(None, None) == [0, 'u:object_r:unlabeled_t:s0']
    # test if root context is not enforced
    assert security_getenforce() == 0
    assert lsetfilecon(None, None) == 0
    assert lgetfilecon_raw(None) == [0, 'u:object_r:unlabeled_t:s0']
    assert matchpathcon(None, None) == [0, 'u:object_r:unlabeled_t:s0']
    # test if root context is enforced
    assert security_getenforce() == 1
    assert lsetfilecon(None, None) == -1
    assert lgetfilecon_raw(None) == [-1, None]
    assert matchpathcon(None, None) == [-1, None]

# Generated at 2022-06-11 01:52:38.824152
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import unittest
    import shutil

    test_dir = os.path.dirname(__file__)
    test_dir = os.path.join(test_dir, "test_matchpathcon_testdir")

    class TestMatchpathcon(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            shutil.copytree(os.path.join(test_dir, 'test_data'), tempfile.mkdtemp())

        @classmethod
        def tearDownClass(cls):
            shutil.rmtree(tempfile.mkdtemp())

        def test_matchpathcon(self):
            dir_path = tempfile.mkdtemp()
            filename = "testfile"
            filepath_w_o_context = os.path

# Generated at 2022-06-11 01:52:41.676160
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b"/etc/hosts", 0)
    assert rc == 0
    assert isinstance(con, str)

# Generated at 2022-06-11 01:52:43.724758
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    for p in ('/', '/dev/zero'):
        assert (lgetfilecon_raw(p) == [0])


# Generated at 2022-06-11 01:52:46.515563
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test 1
    rc, con = lgetfilecon_raw("/etc/services")
    print("rc:", rc)
    print("con:", con)



# Generated at 2022-06-11 01:52:49.434761
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = lgetfilecon_raw("/tmp")
    assert con == [0, "system_u:object_r:tmp_t:s0"]

# Generated at 2022-06-11 01:52:53.841915
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/etc/passwd')
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:passwd_file_t:s0'
    result = lgetfilecon_raw('/not/a/path')
    assert result[0] == -1
    assert result[1] == None



# Generated at 2022-06-11 01:53:04.276036
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import ansible.module_utils.selinux.semanage as semanage
    import ansible.module_utils.selinux as selinux
    import tempfile
    import os
    import shutil

    tmpdir = tempfile.mkdtemp()
    tmpfile = os.path.join(tmpdir, "targetfile")
    f = open(tmpfile, "w")
    f.close()
    (rc, con) = selinux.lgetfilecon_raw(tmpfile)
    assert rc == 0
    assert con != 'unlabeled'

    os.unlink(tmpfile)
    shutil.rmtree(tmpdir)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:53:15.162642
# Unit test for function matchpathcon
def test_matchpathcon():
    # path not exist
    path = "/not/exists/aaa"
    mode = 0
    rc, ret = matchpathcon(path, mode)
    assert(rc == -1 and ret == None)

    # file exist
    path = "/usr/bin/python2.7"
    mode = 0
    rc, ret = matchpathcon(path, mode)
    assert(rc == 0 and ret == "system_u:object_r:bin_t:s0")

    # dir exist
    path = "/tmp"
    mode = 0
    rc, ret = matchpathcon(path, mode)
    assert(rc == 0 and ret == "system_u:object_r:tmp_t:s0")

    # path not exist
    path = "/not/exists/aaa"
    mode = 0x10000
    rc,

# Generated at 2022-06-11 01:53:22.942936
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/usr/bin/vi')
    if rc != 0:
        if rc == -1 and con == 'Operation not permitted':
            # access denied, just report the errno
            raise OSError(rc, con)
        else:
            # something else went wrong, bail
            raise OSError(rc, con)

    assert con == 'unconfined_u:object_r:user_home_t:s0'


# Generated at 2022-06-11 01:53:26.759747
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/bin/ls"
    mode = 0o777
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == "system_u:object_r:bin_t:s0"

# Generated at 2022-06-11 01:53:36.931790
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/selinux/config"
    rc, con = _selinux_lib.lgetfilecon_raw(path, None)
    assert rc == 0
    assert con


# Generated at 2022-06-11 01:53:42.575624
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/tmp/ansible-selinux-test.file'

    if os.path.exists(test_path):
        os.unlink(test_path)

    with open(test_path, 'w'):
        pass

    if lgetfilecon_raw(test_path)[0] != 0:
        raise RuntimeError('expected a valid context for {0}'.format(test_path))

    if lgetfilecon_raw('/non/existent/path')[0] != -1:
        raise RuntimeError('expected error for non-existent file')

    if lgetfilecon_raw('/non/existent/path')[1] != None:
        raise RuntimeError('expected no context for non-existent file')

    os.unlink(test_path)

# Generated at 2022-06-11 01:53:49.415423
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:tmp_t:s0']
    assert lgetfilecon_raw('/dev/null') in ([0, 'system_u:object_r:chr_file_t:s0'] or [0, 'system_u:object_r:null_device_t:s0'])
    assert lgetfilecon_raw('/dev/urandom') in ([0, 'system_u:object_r:random_device_t:s0'] or [0, 'system_u:object_r:dev_t:s0'])
    assert lgetfilecon_raw('/missing') == [-2, None]


# Generated at 2022-06-11 01:53:55.827213
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = b'/'
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(test_path, byref(con))
        assert(rc == 0)
        assert(con.value is not None)
    finally:
        _selinux_lib.freecon(con)

if __name__ == "__main__":
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:54:03.672078
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/home/unconfined_u/unconfined_r', 0)[1] == 'unconfined_u:object_r:user_home_t:s0'
    assert matchpathcon('/etc/ansible/tmp/test.tmp', 0)[1] == 'system_u:object_r:admin_home_t:s0'
    assert matchpathcon('/home/unconfined_u/no_such_dir/test.tmp', 0)[1] == 'unconfined_u:object_r:user_home_t:s0'


# Generated at 2022-06-11 01:54:07.316602
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/var/www/html/index.html', 0)
    assert rc == 0
    assert con == 'user_u:object_r:httpd_sys_content_t:s0'


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:54:13.155677
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    text = b'u:object_r:var_t:s0'
    (rc, con) = lgetfilecon_raw(b'/etc/passwd')
    if rc < 0:
        raise AssertionError("Error getting context for {0}: rc={1}".format(b'/etc/passwd', rc))
    assert con == text

# Generated at 2022-06-11 01:54:20.649044
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = os.stat('/etc/selinux/config').st_mode
    (rc, con) = matchpathcon('/etc/selinux/config', mode)
    if rc == -1:
        print("matchpathcon failed: cannot determine context for /etc/selinux/config")
        exit(1)
    print("/etc/selinux/config context is " + con)
    if rc == 1:
        print("matchpathcon failed: cannot determine context for /etc/selinux/config")
        exit(1)
    exit(0)

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:54:28.909759
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # test data directory
    test_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(test_dir, 'data')

    # if SELinux is not enabled, the function should return [1, None]
    if is_selinux_enabled()[0] != 1:
        assert lgetfilecon_raw(data_dir)[1] is None
    else:
        assert lgetfilecon_raw(data_dir)[1] == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-11 01:54:31.680129
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    path = b'/etc'
    _selinux_lib.lgetfilecon_raw(path, byref(con))
    print(con.value)

# Generated at 2022-06-11 01:54:55.608657
# Unit test for function matchpathcon
def test_matchpathcon():

    try:
        os.symlink('/etc/passwd', '/tmp/e')
    except OSError:
        os.unlink('/tmp/e')

    def test_matchpathcon_internals(path, mode, exp_rc, exp_con):
        [act_rc, act_con] = matchpathcon(path, mode)
        assert act_rc == exp_rc
        assert act_con == exp_con

    test_matchpathcon_internals('/etc/passwd', 0, 0, 'system_u:object_r:etc_t:s0')
    test_matchpathcon_internals('/tmp/e', 0, 0, 'system_u:object_r:etc_t:s0')
    test_matchpathcon_internals('/foo', 0, 2, '')

# Generated at 2022-06-11 01:54:59.480469
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw('/etc/passwd')
    print(rc, con)
    assert rc == 0



# Generated at 2022-06-11 01:55:02.518356
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b"/bin/sh")
    assert con == "system_u:object_r:shell_exec_t:s0"
    assert rc == 0

# Generated at 2022-06-11 01:55:13.306805
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    from os.path import relpath
    from ctypes import create_string_buffer
    from ansible.module_utils._selinux import lgetfilecon_raw
    from ansible.module_utils.common.text.converters import to_native

    # Create temporary file
    tmp_dir = tempfile.mkdtemp()
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)

# Generated at 2022-06-11 01:55:18.309146
# Unit test for function matchpathcon
def test_matchpathcon():
    libselinux = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    path = '/etc/ansible/ansible.cfg'
    mode = os.R_OK
    [rc, con] = matchpathcon(path, mode)
    assert rc == -1
    assert con == 'system_u:object_r:ansible_conf_t:s0'
    # test case for invalid path
    path = '/etc/ansible/bad/ansible.cfg'
    [rc, con] = matchpathcon(path, mode)
    assert rc == -2
    assert con == ''
    # test case for invalid mode
    path = '/etc/ansible/ansible.cfg'
    mode = os.W_OK

# Generated at 2022-06-11 01:55:21.048808
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/log/syslog', 0) == (0, 'system_u:object_r:var_log_t:s0')



# Generated at 2022-06-11 01:55:24.340079
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'user_u:object_r:etc_t:s0'


# Generated at 2022-06-11 01:55:29.499181
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = '/etc/passwd'
    rc, con_val = lgetfilecon_raw(file_path)
    assert rc == 0
    assert '/etc/passwd system_u:object_r:etc_t:s0' in con_val
    assert con_val.find(':') == 10



# Generated at 2022-06-11 01:55:38.913877
# Unit test for function matchpathcon
def test_matchpathcon():
    if is_selinux_enabled() == 0:
        return 0
    if is_selinux_mls_enabled() == 0:
        return 0
    [rc, con] = matchpathcon("/var/log/audit.log", 0)
    [rc1, type1] = selinux_getpolicytype()
    if rc != -1:
        if type1 == "targeted":
            if con != "system_u:object_r:auditd_log_t:s0":
                return 1
        elif type1 == "minimum":
            if con != "system_u:object_r:auditd_log_t:s0":
                return 1

# Generated at 2022-06-11 01:55:41.975011
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b"/tmp/foo"
    res = matchpathcon(path, os.R_OK)
    assert len(res) == 2
    if res[0] == 0:
        print(res[1])


# Generated at 2022-06-11 01:56:15.002237
# Unit test for function matchpathcon
def test_matchpathcon():
    # Valid result
    assert matchpathcon('/path/to/file', 0) == [0, 'system_u:object_r:x_t:s0']

    # Invalid result
    assert matchpathcon('/path/to/file', 1) == [-1, '']



# Generated at 2022-06-11 01:56:21.015860
# Unit test for function matchpathcon
def test_matchpathcon():
    # For example:
    # {"changed": false, "invocation": {"module_args": {"mode": 0, "path": "/var/run/utmp"}}, "path": "/var/run/utmp", "rc": 0, "role": "object_r", "seuser": "root", "type": "var_run_t"}
    assert matchpathcon(b"/var/run/utmp", 0) == [0, b'object_r:var_run_t:s0']



# Generated at 2022-06-11 01:56:24.367841
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = '/etc/selinux/config'
    mode = 4
    rc, con = matchpathcon(test_path, mode)
    assert con == 'system_u:object_r:etc_t:s0'
    assert rc == 0



# Generated at 2022-06-11 01:56:30.395515
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    for test_path in ['/tmp/test_selinux', '/tmp/test_selinux_sys']:
        rc, con = lgetfilecon_raw(test_path)
        assert rc == 0, "rc should be 0, got %d : %s" % (rc, con)
        assert con[:len("system_u:object_r:")] == "system_u:object_r:", "Expected system_u:object_r: prefix: %s" % con

# Generated at 2022-06-11 01:56:38.906476
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        os.getenv('SELINUX_ROLE_REQUESTED')
    except Exception:
        print('SELinux is not running on this host')
        sys.exit(1)

    rc, con = lgetfilecon_raw('/tmp/a.txt')
    assert rc == 0, "failed to getfilecon for /tmp/a.txt"
    assert "system_u" in con, "unable to parse file context"
    assert "_logrotate_t" in con, "unable to parse file context"



# Generated at 2022-06-11 01:56:41.631806
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/selinux/config'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0 and con.startswith('system_u:object_r:etc_t:s0')

# Generated at 2022-06-11 01:56:45.314822
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/hosts')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:SystemLow'


# Generated at 2022-06-11 01:56:48.348757
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/home/test/test.txt', 0)
    assert rc == 0
    assert con == 'user_home_dir_t'



# Generated at 2022-06-11 01:56:51.086794
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/test/test.txt', 0)
    print(res)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:56:55.971620
# Unit test for function matchpathcon
def test_matchpathcon():
    test_list = ['/etc/localtime', '/etc', '/', '/tmp/test']
    for item in test_list:
        (rc, con_text) = matchpathcon(item, 0)
        print('rc: {0} \tcon_text: {1}'.format(rc, con_text))

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:58:07.841513
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        return

    for path, con in [
        ('/proc/1/fd/1', 'system_u:object_r:devpts_t:s0'),
        ('/proc/1/fd/2', 'system_u:object_r:devpts_t:s0'),
        ('/proc/self/fd/3', 'system_u:object_r:devpts_t:s0'),
        ('/proc/self/fd/4', 'system_u:object_r:devpts_t:s0'),
    ]:
        rc, value = lgetfilecon_raw(path)
        assert rc == 0
        assert con == value


# Generated at 2022-06-11 01:58:10.195086
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0 and con == 'system_u:object_r:passwd_file_t:s0'



# Generated at 2022-06-11 01:58:16.293586
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = to_bytes('/')
    mode = 0o755
    rc, con = matchpathcon(test_path, mode)
    assert rc == 0, "Failed to get context for path " + test_path.decode('utf-8')
    assert con == 'system_u:object_r:root_t:s0', "Wrong context found for path " + test_path.decode('utf-8')
    return True

# Generated at 2022-06-11 01:58:23.877765
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    def null_context(path):
        # Create an unusable context for testing error conditions
        out = to_native(matchpathcon(path, 0)[1])
        # FIXME: is there a better way to represent a context?
        return out.rsplit(":", 1)[0] + ':system_u:object_r:null_security_t'

    with tempfile.NamedTemporaryFile('w') as tf:
        fname = tf.name
        # this is just to ensure that the context is, indeed, nullable
        null_ctx = null_context(fname)
        rc, con = matchpathcon(fname, 0)
        print("matchpathcon(%s) -> %s, %s" % (fname, rc, con))
        rc, con = lgetfilecon_

# Generated at 2022-06-11 01:58:25.785074
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert not rc
    assert con



# Generated at 2022-06-11 01:58:29.702673
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # pylint: disable=protected-access
    if os.path.exists('/usr/share/ansible/'):
        path = '/usr/share/ansible/'
    else:
        path = '/etc'
    return _selinux_lib.lgetfilecon_raw(path, None)

# Generated at 2022-06-11 01:58:32.402892
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if selinux_getenforcemode()[1] == 0:
        return
    assert lgetfilecon_raw("/tmp/test.txt")[0] == 0

# Generated at 2022-06-11 01:58:35.687055
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert not lgetfilecon_raw('t/selinux/test_file.txt')[1]
    assert lgetfilecon_raw('t/selinux/test_cfile.txt')[1]

# Generated at 2022-06-11 01:58:42.419543
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon("/usr/bin/python", 0)
    matchpathcon("/usr/bin/python", 1)
    matchpathcon("/sbin/modprobe", 0)
    matchpathcon("/sbin/modprobe", 1)
    matchpathcon("/bin/ps", 0)
    matchpathcon("/bin/ps", 1)
    matchpathcon("/etc/sysconfig", 0)
    matchpathcon("/etc/sysconfig", 1)
    matchpathcon("/usr/lib/systemd/system/sshd.service", 0)
    matchpathcon("/usr/lib/systemd/system/sshd.service", 1)
    matchpathcon("/etc/sysconfig/init", 0)
    matchpathcon("/etc/sysconfig/init", 1)

# Generated at 2022-06-11 01:58:47.360936
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/")
    if rc < 0:
        print("lgetfilecon_raw(): Error getting context of /", file=sys.stderr)
    else:
        print("lgetfilecon_raw(): context of / is", con)

