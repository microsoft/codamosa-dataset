

# Generated at 2022-06-11 01:50:42.773017
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    tests = [('/tmp', 0, 'system_u:object_r:tmp_t:s0')]

    for (path, rc, expected) in tests:
        actual = lgetfilecon_raw(path)[1]
        assert (rc, actual) == (rc, expected)



# Generated at 2022-06-11 01:50:47.323597
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = "/etc/passwd"
    test_con = "unconfined_u:object_r:user_home_t:s0"
    assert matchpathcon(test_path, 0)[1] == test_con

# Generated at 2022-06-11 01:50:58.235123
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    If this test fails with Permission denied, you are not root or it is not
    possible to create a file in the current directory.
    """
    try:
        # Create a file to be able to use the function
        tmpfile = '/etc/ansible/test'
        b = open(tmpfile, 'w')
        b.close()

        try:
            rc, output = matchpathcon(tmpfile, 0)
            if rc == -1:
                raise Exception('Operation not permitted')
        finally:
            # Cleanup
            os.unlink(tmpfile)
    except Exception as e:
        raise Exception('Cannot run the test: %s' % to_native(e))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:51:00.689555
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/shadow', 0) == [0, 'system_u:object_r:shadow_t:s0']

# Generated at 2022-06-11 01:51:02.924842
# Unit test for function matchpathcon
def test_matchpathcon():
    res = matchpathcon('/tmp', 0)
    assert(res[0] == 0)
    assert(res[1] != '')



# Generated at 2022-06-11 01:51:09.887706
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        _selinux_lib.matchpathcon(b'/etc', 0)
    except Exception as e:
        if to_native(e.args[1]) == 'Operation not permitted':
            # Test matchpathcon without selinux enabled
            return True
        else:
            raise Exception('unexpected errno: {0}'.format(to_native(e.args[1])))
    return False

# Generated at 2022-06-11 01:51:12.480755
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/tmp', 0)
    assert rc == 0
    assert con == 'tmp_t'

# Generated at 2022-06-11 01:51:15.314796
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test case for lgetfilecon_raw
    """
    # Create a temporary file
    # Get the context
    # Delete the temporary file
    pass

# Generated at 2022-06-11 01:51:20.878814
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansibilite.selinux.consts import selinux_context_t

    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0

    obj = selinux_context_t.from_string(con)
    assert obj.role == 'system_r'
    assert obj.user == 'system_u'
    assert obj.type == 'etc_t'
    assert 'etc_t' in str(obj)



# Generated at 2022-06-11 01:51:24.341360
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = '/dev/null'
    rc, con = lgetfilecon_raw(filename)
    print("RC: {0}; con: {1}".format(rc, con))



# Generated at 2022-06-11 01:51:35.954878
# Unit test for function matchpathcon
def test_matchpathcon():
    """ Test function matchpathcon """
    print("Running test_matchpathcon")
    try:
        _selinux_lib.matchpathcon.restype = None
        _selinux_lib.matchpathcon.argtypes = [c_char_p, c_int, POINTER(c_char_p)]
        _selinux_lib.matchpathcon.errcheck = lambda res, func, args: args[2][0]
        data = _selinux_lib.matchpathcon(b'/tmp', 0, c_char_p(None))
        if data is None:
            print("Failure: matchpathcon returned None, expected string")
        else:
            print("matchpathcon returned: {}".format(data))
    except ImportError as e:
        print("ImportError: {0}".format(e))


# Generated at 2022-06-11 01:51:41.326291
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fd, path = mkstemp()
    f = os.fdopen(fd)
    try:
        [rc, con] = lgetfilecon_raw(path)
        f.write("some data")
        f.close()

    except Exception as e:
        print(e)
    finally:
        os.remove(path)


# Generated at 2022-06-11 01:51:44.674638
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test the matchpathcon() function.

    The main goal here is to test the interface, not the underlying
    Linux MatchPathCon mechanism.
    """
    (_rc, con) = matchpathcon('/foo/bar', 0)
    if _rc < 0:
        raise OSError(con)
    print(con)



# Generated at 2022-06-11 01:51:48.924064
# Unit test for function matchpathcon
def test_matchpathcon():
    test_path = b'/tmp'
    mode = 1
    expected_rc = -1
    expected_con = None
    rc, con = matchpathcon(test_path, mode)
    assert rc == expected_rc
    assert con == expected_con

# Generated at 2022-06-11 01:51:53.952666
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    projid = os.getgid()
    rc, con = lgetfilecon_raw('/tmp')
    print('/tmp', rc, con)
    expected = 'system_u:object_r:tmp_t:s0:{0}:{1}'.format(projid, projid)
    assert con == expected


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:52:00.078561
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test that matchpathcon actually works
    """
    # we should get an error for an invalid path
    assert matchpathcon('/nonexistentpath')[0] == -1

    # we should get a result for a valid path
    # TODO: replace this with a test with a real selinux policy loaded
    assert matchpathcon('/')[0] == 0

# Generated at 2022-06-11 01:52:07.113056
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = u'file_test'
    # Create a file to test
    with open(u'file_test', 'w') as test_file:
        test_file.write(u'This is a file to test.')
    # Test with a file
    rc, con = lgetfilecon_raw(test_file)
    assert rc == 0
    assert con == b'unconfined_u:object_r:user_home_t:s0'
    # Test with a directory
    rc, con = lgetfilecon_raw(u'.')
    assert rc == 0
    assert con == b'unconfined_u:object_r:user_home_dir_t:s0'

# Generated at 2022-06-11 01:52:16.807587
# Unit test for function matchpathcon
def test_matchpathcon():
    # Path must exist
    path = '/tmp'
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    assert rc < 0
    assert con.startswith("No filename for test_matchpathcon")
    # Remove "No filename for"
    errno = int(con[20:].split(" ", 1)[0])
    assert errno > 0
    assert os.strerror(errno) == "No such file or directory"

    # Path must not be symlink
    lnk = "/tmp/selinux-matchpathcon-symlink"
    os.symlink(path, lnk)
    rc, con = matchpathcon(lnk, mode)
    os.unlink(lnk)
    assert rc < 0

# Generated at 2022-06-11 01:52:28.078385
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import filecmp
    import stat

    fd, path = tempfile.mkstemp(prefix='selinux_test')

# Generated at 2022-06-11 01:52:30.198400
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw(b'/etc')
    assert result[0] == 0, "lgetfilecon_raw failed with error: {}".format(result[0])



# Generated at 2022-06-11 01:52:37.117222
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # test for a file which does not exist in the current directory
    path = b"/tmp/does_not_exist"
    [rc, con] = lgetfilecon_raw(path)
    if rc < 0:
        print("lgetfilecon_raw: could not get context for %s: %s" % (to_native(path), con))
    else:
        print("lgetfilecon_raw: context for %s is %s" % (to_native(path), con))



# Generated at 2022-06-11 01:52:40.433403
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon(b'/usr/share/nmap/nmap.xsl', 0)
    assert rc == 0
    assert con == 'staff_u:object_r:usr_t:s0'

# Generated at 2022-06-11 01:52:45.859627
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.selinux import matchpathcon
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, bypass_checks=True)
    rc, mode = matchpathcon('/home', module.selinux.SELINUX_AND_APPS)
    module.exit_json(msg="Failed to get context", rc=rc, mode=mode)



# Generated at 2022-06-11 01:52:55.382352
# Unit test for function matchpathcon
def test_matchpathcon():
    # test the first path which should always work
    (rc, con) = matchpathcon('/usr', 0)
    assert rc == 0 and con == 'system_u:object_r:usr_t:s0'

    # test a path which should also work
    (rc, con) = matchpathcon('/etc', 0)
    assert rc == 0 and con == 'system_u:object_r:etc_t:s0'

    # test a nonexistent path
    (rc, con) = matchpathcon('/etc/this/should/not/exist', 0)
    assert rc == -1 and con == ''

    # test a path which is not valid to specify
    (rc, con) = matchpathcon('/usr/bin/python', 0)
    assert rc == -1 and con == ''



# Generated at 2022-06-11 01:52:59.294987
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    pathname = b'/'
    rc, con = lgetfilecon_raw(pathname)
    if rc != 0:
        raise Exception('lgetfilecon_raw({0}) failed with {1}'.format(pathname, rc))

# Generated at 2022-06-11 01:53:08.510142
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not isinstance(lgetfilecon_raw('/'), list):
        raise AssertionError(
            "lgetfilecon_raw function did not return a list as expected")
    if not len(lgetfilecon_raw('/')) == 2:
        raise AssertionError(
            "lgetfilecon_raw function did not return a list of length 2")
    if not isinstance(lgetfilecon_raw('/')[0], int):
        raise AssertionError(
            "lgetfilecon_raw function index 0 did not return an int as expected")
    if not isinstance(lgetfilecon_raw('/')[1], str):
        raise AssertionError(
            "lgetfilecon_raw function index 1 did not return a str as expected")


# Generated at 2022-06-11 01:53:11.252390
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/passwd')
    print((rc, con))


# Generated at 2022-06-11 01:53:13.951766
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    >>> print(lgetfilecon_raw('/etc/resolv.conf'))
    [0, 'system_u:object_r:etc_t:s0']
    """
    pass

# Generated at 2022-06-11 01:53:18.015851
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw("/")
    print("%d: %s" % (rc, con))
    assert(rc == 0)
    assert(con == "system_u:object_r:root_t:s0")


# Generated at 2022-06-11 01:53:25.157809
# Unit test for function matchpathcon
def test_matchpathcon():
    is_enabled = _selinux_lib.is_selinux_enabled()
    if is_enabled != 1:
        return
    mode = 0
    (rc, result) = matchpathcon('/var/log/messages', mode)
    assert rc >= 0
    assert result == 'system_u:object_r:var_log_t:s0' or result == 'system_u:object_r:var_log_t:s0-s0:c0.c1023'

# Generated at 2022-06-11 01:53:31.918675
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:53:40.946764
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    This test validates matchpathcon against existing ACLs
    '''
    def _match(path, expected_type):
        # create test path
        os.mkdir(path)
        try:
            [rc, path_type] = matchpathcon(path, 0)
            assert rc == 0, "matchpathcon failed: {} {}".format(path, to_native(os.strerror(rc)))
            type_perm_re = r'^system_u:object_r:{}'.format(expected_type)
            import re
            if not re.match(type_perm_re, path_type):
                raise AssertionError("{} type {} did not match {}".format(path, expected_type, path_type))
        finally:
            os.rmdir(path)

# Generated at 2022-06-11 01:53:45.789808
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    s, f = tempfile.mkstemp()

    try:
        assert lgetfilecon_raw(f)[1] is not None
    finally:
        os.close(s)
        os.remove(f)



# Generated at 2022-06-11 01:53:55.932130
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    class TestSelinux(object):
        def test_lgetfilecon_raw(self):
            (fd, tempfile_name) = tempfile.mkstemp()
            assert os.path.exists(tempfile_name)

            con = c_char_p()
            rc = _selinux_lib.lgetfilecon_raw(tempfile_name, byref(con))

            assert rc == 0
            assert con.value is not None
            assert len(con.value) > 0
            assert to_native(con.value) == "system_u:object_r:tmp_t:s0"

            os.close(fd)
            os.remove(tempfile_name)


# Generated at 2022-06-11 01:54:01.468326
# Unit test for function matchpathcon
def test_matchpathcon():
    print('matchpathcon({0},{1}): {2}'.format('/tmp/foo.txt', 0, matchpathcon('/tmp/foo.txt', 0)))
    print('matchpathcon({0},{1}): {2}'.format('/tmp/bar.txt', 0, matchpathcon('/tmp/bar.txt', 0)))



# Generated at 2022-06-11 01:54:03.633424
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/")
    assert rc == 0
    assert con.startswith("system_u:object_r:root_t:s0")

# Generated at 2022-06-11 01:54:05.960217
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', os.R_OK) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-11 01:54:11.920005
# Unit test for function matchpathcon
def test_matchpathcon():
    from ctypes import create_string_buffer, c_char
    from ansible.module_utils.common.text.converters import to_bytes

    con = c_char_p()
    path = create_string_buffer(to_bytes('./test'))
    mode = 0o600

    [rc, label] = matchpathcon(path, mode)
    assert rc == 0
    assert label == to_native(label)



# Generated at 2022-06-11 01:54:17.685526
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    testpath = "/var/tmp"
    # testpath = "fred"
    (rc, con) = lgetfilecon_raw(testpath)
    if rc == -1:
        print("Get file context failed with errno {}".format(get_errno()))
    else:
        print("Get file context successful with context {}".format(con))



# Generated at 2022-06-11 01:54:28.477635
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    from ansible.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest

    # Create temporary file
    from tempfile import NamedTemporaryFile
    file_fd = NamedTemporaryFile(delete=False)
    file_path = file_fd.name

    # Save file context

# Generated at 2022-06-11 01:54:35.375984
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_list = ['/etc/hosts', '/proc/self/exe']
    for file in file_list:
        result = lgetfilecon_raw(to_bytes(file))
        if result[0] >= 0:
            print(result[1])
        else:
            raise Exception("lgetfilecon_raw failed")



# Generated at 2022-06-11 01:54:43.395164
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    import tempfile
    filename = None
    try:
        (fd, filename) = tempfile.mkstemp(dir='/tmp')
        with os.fdopen(fd, 'w'):
            pass
        ret = lgetfilecon_raw(filename)
        assert ret[1].startswith('system_u:object_r:user_tmp_t:')
    finally:
        if filename:
            os.remove(filename)



# Generated at 2022-06-11 01:54:53.163022
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    from os.path import join, dirname, realpath

    def try_matchpathcon(path):
        rc, con = matchpathcon(path, os.R_OK)
        print('%s has context %s' % (path, con))

    try:
        cur_dir = os.getcwd()
        tmpfile = tempfile.NamedTemporaryFile()
        os.chdir(tmpfile.name)
        try_matchpathcon('/')
        try_matchpathcon(join(cur_dir, dirname(realpath(__file__))))
        try_matchpathcon(tmpfile.name)
    finally:
        os.chdir(cur_dir)
        tmpfile.close()



# Generated at 2022-06-11 01:55:04.619823
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    from errno import ENOENT
    from stat import S_IRUSR, S_IWUSR, S_IXUSR, S_IRGRP, S_IWGRP, S_IXGRP, S_IROTH, S_IWOTH, S_IXOTH

    # create a tempfile and make sure it got created
    tempdir = tempfile.mkdtemp()
    assert os.path.isdir(tempdir)

    # get the context of this tempdir
    (rc, ctx) = lgetfilecon_raw(tempdir)
    tempdir_ctx = ctx

    # create a tempfile for testing purposes
    (tempfd, tempfilepath) = tempfile.mkstemp(dir=tempdir)
    assert os.path.isfile(tempfilepath)

    # get the

# Generated at 2022-06-11 01:55:07.765011
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd') == [0, b'system_u:object_r:etc_t:s0']



# Generated at 2022-06-11 01:55:11.320045
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    context = lgetfilecon_raw(path)
    assert context[0] == 0
    assert context[1] == 'unconfined_u:object_r:user_home_t:s0'


# Generated at 2022-06-11 01:55:20.124407
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_con = lgetfilecon_raw('/dev/null')

    print(str(test_con[0]) + ' ' + test_con[1])

    if test_con[0] < 0:
        return 1

    return 0


if __name__ == '__main__':
    print('Testing libselinux wrappers')

    if test_lgetfilecon_raw() != 0:
        print('Test of function lgetfilecon_raw failed.')
        sys.exit(1)
    else:
        print('Test of function lgetfilecon_raw passed.')

# Generated at 2022-06-11 01:55:25.156172
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw('/', byref(con))
    assert rc == 0
    assert to_native(con.value) == 'system_u:object_r:root_t'


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:55:35.090839
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test for invalid path - should return errno 2
    test_path = "/invalid/path"
    rc, con = matchpathcon(test_path, 0)
    assert rc == -2
    assert con == None

    if os.path.isdir("/bin"):
        # Test for existing path - should return success
        test_path = "/bin"
        rc, con = matchpathcon(test_path, 0)
        assert rc == 0
        assert con == "system_u:object_r:bin_t:s0"

    if os.path.isdir("/tmp"):
        test_path = "/tmp"
        rc, con = matchpathcon(test_path, 0)
        assert rc == 0
        assert con == "system_u:object_r:tmp_t:s0"


# Generated at 2022-06-11 01:55:39.594099
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/home/foo')
    if rc < 0:
        print('lgetfilecon_raw() error:', os.strerror(rc))
        return
    if con is None:
        print('lgetfilecon_raw() con is NULL')
        return
    print('con:', con)


# Generated at 2022-06-11 01:55:46.284129
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw(b'/')
    assert rc == 0, 'Failed to get the context of /'
    assert con is not None, 'String returned was None'
    assert con.startswith(b'system_u:object_r:'), 'String returned was {}'.format(con)


# Generated at 2022-06-11 01:55:49.755343
# Unit test for function matchpathcon
def test_matchpathcon():
    if os.geteuid() == 0:
        ret, con = matchpathcon('/tmp', 0)
        if ret != 0:
            raise Exception('matchpathcon failed')
        else:
            print(con)


# Generated at 2022-06-11 01:55:53.940071
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    lgetfilecon_raw function test
    """
    fpath = "test_file"
    with open(fpath, 'w') as f:
        rc, context = lgetfilecon_raw(fpath)
        assert rc == 0
        assert context == 'system_u:object_r:unlabeled_t:s0'
    os.remove(fpath)

# Generated at 2022-06-11 01:55:57.325583
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = "/etc/resolv.conf"
    rc, con = lgetfilecon_raw(test_path)
    assert rc == 0
    assert con == "system_u:object_r:resolv_conf_t:s0"

# Generated at 2022-06-11 01:56:07.443935
# Unit test for function matchpathcon
def test_matchpathcon():
    test_paths = [
        {'path': '/etc/hosts', 'mode': 0x1, 'con': 'system_u:object_r:etc_t:s0'},
        {'path': '/etc/hosts', 'mode': 0x0, 'con': 'system_u:object_r:etc_t:s0'},
        {'path': '/tmp/ansible_selinux.log', 'mode': 0x1, 'con': 'system_u:object_r:var_log_t:s0'}
    ]
    for path in test_paths:
        rc, con = matchpathcon(path['path'], path['mode'])
        assert rc == 0
        assert con == path['con']
    print('matchpathcon function test passed')



# Generated at 2022-06-11 01:56:11.464290
# Unit test for function matchpathcon
def test_matchpathcon():
    if is_selinux_enabled():
        # Verify no exception is thrown when file exists
        assert matchpathcon('/etc', 0)[0] == 0
    else:
        # Verify no exception is thrown when file does not exist
        assert matchpathcon('/dev/sda2', 0)[0] == 0

# Generated at 2022-06-11 01:56:14.186365
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/var/foo', 0)
    print('rc=%d con=%s' % (rc, con))


# Generated at 2022-06-11 01:56:22.639473
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Run some tests on the function matchpathcon.
    """
    # Python3 on Debian (Jessie) returns:
    # [0, 'system_u:object_r:user_home_t:s0']
    # Python2 on Debian (Jessie) returns:
    # [0, 'system_u:object_r:user_home_t:s0\x00']
    #
    # We add rstrip('\x00') for safety.
    for path in ("/home/user",
                 "/home/user/",
                 "/home/user/file"):
        if os.path.isdir(path):
            mode = 1
        elif os.path.isfile(path):
            mode = 0

# Generated at 2022-06-11 01:56:25.684579
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/ssh/sshd_config', 0)
    assert rc == 0
    assert con == 'system_u:object_r:sshd_config_t:s0'

# Generated at 2022-06-11 01:56:36.433434
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    path = tempfile.mktemp()
    rc, con = lgetfilecon_raw(path)
    assert rc == -1
    assert con is None
    # Test the default behavior for matchpathcon for a file which does not yet
    # exist.
    rc, con = matchpathcon(path, os.R_OK)
    assert rc == 0
    assert con == 'unlabeled'
    # Test with a file that exists
    with open(path, 'w') as f:
        f.write('test')
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None
    assert con.startswith('unconfined_u:object_r:')
    # Test that the con is returned by matchpathcon
    rc, con = matchpathcon

# Generated at 2022-06-11 01:56:39.940788
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, '(null)']

# Generated at 2022-06-11 01:56:41.551206
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/hosts')[1].startswith(b'system_u:object_r:etc_t:s0')

# Generated at 2022-06-11 01:56:43.217724
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon('/etc/localtime', os.R_OK)

# Generated at 2022-06-11 01:56:47.484332
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon(b'/', 0))
    print(matchpathcon(b'/usr/bin', 0))
    print(matchpathcon(b'/etc', 0))
    print(matchpathcon(b'/etc', os.X_OK))



# Generated at 2022-06-11 01:56:55.889571
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_bytes

    path = to_text(b'/.pwd.lock')
    mode = 0
    rc, context = matchpathcon(path, mode)
    assert isinstance(rc, int)
    assert isinstance(context, str)

    # some versions of libselinux.so is not compiled with debug symbols so we're unable to use inspect module
    # to get the name of the functions in the library. The opposite is also true, some versions of libselinux
    # are compiled with debug symbols and running the code without setting -O3 flag would cause the test to fail
    # due to the optimization, and the ability to get function name using inspect module

# Generated at 2022-06-11 01:57:07.205025
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_bytes


    # test file
    filename = '/etc/group'
    m = matchpathcon('/etc/group', 0)
    assert m[0] == 0
    assert m[1] == to_text(b'\x1f\x04\x00\x00\t\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00system_u:object_r:etc_t:s0')

    # test symlink
    filename = '/var/tmp'
    m = match

# Generated at 2022-06-11 01:57:14.705547
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'', 0) == [0, b'u:object_r:root_t:s0']
    assert matchpathcon(b'/', 0) == [0, b'u:object_r:root_t:s0']
    assert matchpathcon(b'/etc', 0) == [0, b'u:object_r:etc_t:s0']
    assert matchpathcon(b'/etc', 2) == [0, b'system_u:object_r:etc_t:s0']
    assert matchpathcon(b'/etc/foo', 0) == [0, b'u:object_r:etc_t:s0']
    assert matchpathcon(b'/etc/foo', 2) == [0, b'system_u:object_r:etc_t:s0']



# Generated at 2022-06-11 01:57:20.833811
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/var/log/audit/audit.log'

    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con == b"system_u:object_r:auditd_log_t:s0"


if __name__ == '__main__':
    # Unit tests
    test_matchpathcon()

    print('All passed!')

# Generated at 2022-06-11 01:57:28.915607
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Try a path
    (rc, context) = lgetfilecon_raw('/dev/null')
    if rc != 0:
        raise Exception('non-zero rc: {0}'.format(rc))
    if context not in [b'unlabeled_t', b'system_u:object_r:unlabeled_t:s0', b'system_u:object_r:device_t:s0']:
        raise Exception('Unexpected context string: {0}'.format(context))

    # Try a non-existent path
    try:
        (rc, context) = lgetfilecon_raw('/foo')
    except OSError as e:
        if e.errno != 2:
            raise Exception('Unexpected OSError errno: {0}'.format(e.errno))

# Generated at 2022-06-11 01:57:33.204222
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux_policy import is_selinux_enabled_python_only
    if is_selinux_enabled_python_only():
        path = '/tmp'
        rc, con = lgetfilecon_raw(path)
        assert rc == 0
        assert isinstance(con, str)


# Generated at 2022-06-11 01:57:39.787669
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b"/etc/hosts"
    [rc, con] = matchpathcon(path, 0)
    if rc != 0:
        print("error: matchpathcon: rc=%d" % rc)
    else:
        print("con=%s" % con)



# Generated at 2022-06-11 01:57:42.368270
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/etc/group')
    assert con == 'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-11 01:57:44.149416
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/etc/localtime")
    print("rc: %s\tcon: %s" % (rc, con))



# Generated at 2022-06-11 01:57:47.384733
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/')[0] == 0
    assert lgetfilecon_raw('/foo')[0] != 0


# Generated at 2022-06-11 01:57:55.365799
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/foo.conf', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    (rc, con) = matchpathcon('/etc/foo.conf', 1)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'

    (rc, con) = matchpathcon('/etc/foo.conf', 2)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'



# Generated at 2022-06-11 01:58:01.253833
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print('Testing function "lgetfilecon_raw"')
    try:
        ret = lgetfilecon_raw(b'/')
        print('Return code: {0}'.format(ret[0]))
        print('Return value: {0}'.format(ret[1]))
    except NotImplementedError:
        print('Function not implemented')
    except OSError as e:
        print('OSError: {0}'.format(e))


# Generated at 2022-06-11 01:58:04.362823
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert_result = [0, "system_u:object_r:boot_t:s0"]
    assert lgetfilecon_raw("/boot/virt-x.x.x.x") == assert_result
    assert_result = [0, "user_u:object_r:virt_image_t:s0"]
    assert lgetfilecon_raw("/var/lib/libvirt/images/virt-x.x.x.x") == assert_result


# Generated at 2022-06-11 01:58:11.681006
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil

    [rc, con] = matchpathcon('/var/log/audit/audit.log', 0)
    assert con == 'system_u:object_r:auditd_log_t:s0'


# Generated at 2022-06-11 01:58:21.060837
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import socket
    import errno

    try:
        path = '/proc/{0}/exe'.format(os.getpid())
        os.stat(path)
    except OSError as e:
        if e.errno not in [errno.EPERM, errno.ENOENT]:
            raise

        # EACCESS and ENOENT are raised if the file does not exist.
        # In that case we fallback to the test /tmp dir
        path = '/tmp'

    # We know `path` is accessible so it is a good candidate for testing
    # the function lgetfilecon_raw
    con, rc = lgetfilecon_raw(path)
    assert con == b"system_u:object_r:tmp_t:s0"

# Generated at 2022-06-11 01:58:23.660755
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/python') == [0, 'system_u:object_r:bin_t:s0']


# Generated at 2022-06-11 01:58:31.691894
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Check for `context of /proc/self/exe`
    '''
    rc, con = lgetfilecon_raw(b'/proc/self/exe')
    assert rc == 0 and con is not None
    assert con.startswith(b'system_u:object_r:')



# Generated at 2022-06-11 01:58:34.012930
# Unit test for function matchpathcon
def test_matchpathcon():
    c = matchpathcon('/var/log/containers/myproject', 0)
    print(c)


# Generated at 2022-06-11 01:58:36.486471
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, result = matchpathcon('/some/not/existing/path', 0)
    assert rc == -1
    assert result is None



# Generated at 2022-06-11 01:58:40.591909
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test calling matchpathcon
    :return:
    """
    try:
        import selinux
    except ImportError:
        print("selinux not installed, skipping selinux python bindings test")
        return

    rc, val = matchpathcon('/etc/passwd', 0)
    assert val == 'system_u:object_r:etc_runtime_t:s0', "incorrect context returned from matchpathcon"



# Generated at 2022-06-11 01:58:45.308193
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.utils.path import unfrackpath

    path = unfrackpath(__file__)
    rc, con = lgetfilecon_raw(path)

    if rc == -1:
        raise OSError(os.strerror(get_errno()))
    else:
        return len(con) > 0



# Generated at 2022-06-11 01:58:51.582172
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:root_t:s0']
    assert lgetfilecon_raw('/etc') == [0, 'system_u:object_r:etc_t:s0']
    assert lgetfilecon_raw('/this_path_does_not_exist') == [-1, 'file does not exist']


# Generated at 2022-06-11 01:58:58.197543
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, context) = matchpathcon('/bin/ls', 0)
    assert rc == 0
    assert context == 'system_u:object_r:bin_t:s0'

    (rc, context) = matchpathcon('/non-existing-file', 0)
    assert rc != 0
    assert context == ''


if __name__ == '__main__':
    test_matchpathcon()
    print('SELinux test passed')

# Generated at 2022-06-11 01:59:00.457424
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert _selinux_lib.lgetfilecon_raw(b'/etc/foo.conf', None) > 0



# Generated at 2022-06-11 01:59:03.292466
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/')
    assert(rc == 0)
    assert(con == 'system_u:object_r:root_t:s0')



# Generated at 2022-06-11 01:59:06.677128
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/sys/fs/cgroup/systemd/system.slice', 0)[1] == 'system_u:object_r:cgroup_t:s0'



# Generated at 2022-06-11 01:59:14.984555
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con_tuple] = lgetfilecon_raw("/etc/hosts")
    if rc != 0:
        print("Error: lgetfilecon_raw failed with return code {}".format(rc))
        exit(1)
    else:
        print("lgetfilecon_raw passed and returned tuple {}".format(con_tuple))


if __name__ == "__main__":
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:59:17.853726
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/passwd"
    subset = lgetfilecon_raw(path)
    assert subset[0] == 0, subset[1]


# Generated at 2022-06-11 01:59:25.972955
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import shutil
    import tempfile

    # create temporary dir
    tmp_dir = tempfile.mkdtemp()

    # create temporary file
    with open(os.path.join(tmp_dir, 'file'), 'w') as f:
        f.write('This is just a test file!')

    # get context of temporary file
    [ret, context] = lgetfilecon_raw(os.path.join(tmp_dir, 'file'))
    assert ret == 0

    # remove temporary dir
    shutil.rmtree(tmp_dir)



# Generated at 2022-06-11 01:59:32.302857
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    d = tempfile.mkdtemp()
    create_file = os.path.join(d, 'create_file')
    mode = os.R_OK
    try:
        os.mkdir(create_file)
        assert matchpathcon(create_file, mode) == [0, 'system_u:object_r:user_tmp_t:s0']
    finally:
        os.rmdir(create_file)
        os.rmdir(d)

# Generated at 2022-06-11 01:59:34.887477
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    Tests matchpathcon function
    :return: None
    '''
    rc, con = matchpathcon('/tmp', 0)
    print(rc, con)
    return None



# Generated at 2022-06-11 01:59:43.234569
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import shutil
    import tempfile

    fd, fname = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        try:
            f.write('test')
        except:
            try:
                os.remove(fname)
            except:
                pass
            raise
    try:
        # Use a bare try/except as we may not have the correct permissions
        # to set an SELinux context.
        lgetfilecon_raw(fname)
    finally:
        os.remove(fname)

# Generated at 2022-06-11 01:59:53.637825
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import os.path
    if os.access('/usr/sbin/semanage', os.X_OK):
        if os.path.exists('/usr/sbin/semanage'):
            rc, con = matchpathcon('/usr/sbin/semanage', os.R_OK)
            assert rc == 0, 'rc should be 0, got %d' % rc
            assert con == 'system_u:object_r:semanage_exec_t:s0', \
                   'con should be system_u:object_r:semanage_exec_t:s0, got %s' % con

# Generated at 2022-06-11 02:00:03.300590
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansibullbot.utils.file_tools import get_tmp_dir
    from os.path import dirname, join
    from os import makedirs, unlink, symlink, mkdir, rmdir
    import pytest

    tmpdir = get_tmp_dir()
    testdir = join(tmpdir, 'testdir')
    makedirs(testdir, mode=0o700)
    con = b'u:r:init_shell:s0:c0,c1023'
    assert lsetfilecon(testdir, con) == 0
    assert matchpathcon(testdir, 0)[1] == con
    assert matchpathcon(join(testdir, 'foo'), 0)[1] == con
    assert matchpathcon(join(testdir, 'bar'), 0)[1] == con


# Generated at 2022-06-11 02:00:05.398818
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, res) = matchpathcon('/etc/somedir/somesubdir', mode=0)
    assert rc == 0
    assert res == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-11 02:00:11.408105
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os

    if not os.path.isfile(os.path.realpath(__file__)):
        raise AssertionError('Test file not found: {0}'.format(os.path.realpath(__file__)))

    rc, con = lgetfilecon_raw(os.path.realpath(__file__))
    assert rc == 0
    assert con.startswith('unconfined_u:object_r:python_content_t:s0')



# Generated at 2022-06-11 02:00:17.214459
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/")
    print("rc: {0}".format(rc))
    print("con: {0}".format(con))



# Generated at 2022-06-11 02:00:18.481212
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/etc/passwd', 0))

# Generated at 2022-06-11 02:00:20.778827
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/etc/shadow", 1)
    assert rc != -1
    assert con == "system_u:object_r:shadow_t"


# Generated at 2022-06-11 02:00:26.102327
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file_path = '/etc/selinux/config'
    assert lgetfilecon_raw(test_file_path)[0] == 0
    assert lgetfilecon_raw('/etc/selinux/config1')[0] == -1
    assert lgetfilecon_raw('/etc/selinux/config')[1] == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-11 02:00:29.254624
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "./test_selinux.py"
    rc, con = lgetfilecon_raw(path)
    if rc < 0:
        raise RuntimeError('lgetfilecon_raw({0}): {1}'.format(path, rc))
    else:
        print(con)
        assert rc == 0



# Generated at 2022-06-11 02:00:38.667280
# Unit test for function matchpathcon
def test_matchpathcon():
    # case 1: file doesn't exist
    path = '/path/does/not/exist'
    mode = 0
    [rc, con] = matchpathcon(path, mode)
    assert rc == -1

    # case 2: verify operation on the actual system
    # NB: running this on a system without selinux won't work
    path = '/etc/passwd'
    mode = 0
    [rc, con] = matchpathcon(path, mode)
    assert rc == 0

    # case 3: verify operation on the actual system
    # NB: running this on a system without selinux won't work
    path = '/etc/passwd'
    mode = 1
    [rc, con] = matchpathcon(path, mode)
    assert rc == 0
