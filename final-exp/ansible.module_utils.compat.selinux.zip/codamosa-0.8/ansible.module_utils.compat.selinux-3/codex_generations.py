

# Generated at 2022-06-11 01:50:46.152253
# Unit test for function matchpathcon
def test_matchpathcon():
    import os.path
    import stat

    tmpdir = '/tmp/___test_matchpathcon'
    try:
        os.mkdir(tmpdir)
        os.chmod(tmpdir, stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
        tmppath = os.path.join(tmpdir, 'test')
        with open(tmppath, 'w') as f:
            f.flush()

        con = matchpathcon(tmppath, stat.S_IFREG)[1].strip()
        assert con.startswith('unconfined_u:object_r:user_tmp_t')
    finally:
        os.remove(tmppath)
        os.rmdir(tmpdir)

# Generated at 2022-06-11 01:50:50.224000
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/etc/mtab")
    assert rc == 0
    assert con == 'system_u:object_r:etc_t'


#Unit test for function matchpathcon

# Generated at 2022-06-11 01:50:53.332050
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/tmp/foo/bar', 1)
    if rc < 0:
        raise OSError(os.strerror(get_errno()))



# Generated at 2022-06-11 01:51:00.859219
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert con == 'system_u:object_r:passwd_file_t:s0'
    rc, con = matchpathcon('/bin/init', 0)
    assert con == 'system_u:system_r:init_t:s0'
    rc, con = matchpathcon('/usr/bin/python', 0)
    assert con == 'system_u:object_r:bin_t:s0'

# Generated at 2022-06-11 01:51:06.363938
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    expected_con = 'system_u:object_r:tmp_t:s0'
    path = '/tmp/'

    if not os.path.exists(path):
        raise Exception("Test directory {} doesn't exist. Cannot run tests.".format(path))

    rc, con = matchpathcon(path, os.R_OK)

    if rc != 0:
        raise Exception("Failed to get context for {}".format(path))

    if expected_con != con:
        raise Exception("Expected context {} doesn't match obtained context {}".format(expected_con, con))

# Generated at 2022-06-11 01:51:07.903358
# Unit test for function matchpathcon
def test_matchpathcon():
    matchpathcon(path=b'/foo/bar', mode=0)

# Generated at 2022-06-11 01:51:13.166001
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp', os.R_OK)
    print("rc = {0}".format(rc))
    print("con = {0}".format(con))


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 01:51:19.629207
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile

    test_file = tempfile.NamedTemporaryFile(delete=False)
    path = test_file.name
    test_file.close()

    try:
        (rc, con) = lgetfilecon_raw(to_bytes(path))
    finally:
        os.remove(path)

    if rc != 0:
        raise Exception("unable to call lgetfilecon_raw")
    if not con:
        raise Exception("return label from lgetfilecon_raw is empty")

# Generated at 2022-06-11 01:51:23.900219
# Unit test for function matchpathcon
def test_matchpathcon():
    # return code is less than zero when no SELinux system is present
    rc, con = matchpathcon('con', 24)
    if rc < 0:
        sys.exit(0)
    else:
        print(con)
        sys.exit(1)



# Generated at 2022-06-11 01:51:33.417144
# Unit test for function matchpathcon
def test_matchpathcon():
    # test_dir path is defined in ansible/test/units/module_utils/test_selinux.py
    test_dir = "/tmp/test_dir/a/b/c"
    try:
        os.makedirs(test_dir, exist_ok=True)
        expected = "pass"
        result = matchpathcon(test_dir, 0)[1]
    finally:
        os.removedirs(test_dir)

    # FIXME: to_native is not currently used directly in the module code, so this is not a comprehensive test
    #        for now, we assume it will be used when it is needed
    assert result == to_native(expected)

# Generated at 2022-06-11 01:51:39.345738
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    rc = lgetfilecon_raw('/proc')
    assert rc[0] == 0
    assert rc[1] == 'system_u:object_r:proc_t:s0'


# Generated at 2022-06-11 01:51:46.001019
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = to_bytes("/tmp/ansible_file_selinux_test")
    test_context = to_bytes("system_u:object_r:svirt_lxc_net_t:s0")
    with open(test_file, 'w+') as f:
        f.write(to_native(""))
        f.close()
    rc, context = lgetfilecon_raw(test_file)
    assert context == test_context
    os.remove(test_file)


# Generated at 2022-06-11 01:51:54.740841
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Example module function wrapper used in unit tests
    '''
    if selinux_getenforcemode()[1] == 0:
        print("SELinux is disabled")
        return
    else:
        print("SELinux is enabled")
        policytype = selinux_getpolicytype()[1]
        print("SELinux policy type = %s" % policytype)
        file_path = '/etc/fstab'
        con = lgetfilecon_raw(file_path)[1]
        if con is None:
            print('Unable to get the context of file %s' % file_path)
        else:
            print('Context of file %s is %s' % (file_path, con))
        return


# Generated at 2022-06-11 01:51:57.510330
# Unit test for function matchpathcon
def test_matchpathcon():
    err, con = matchpathcon('/foo/bar', 0)
    assert err == 0  # success
    assert con == 'system_u:object_r:default_t:s0'

# Generated at 2022-06-11 01:52:01.638559
# Unit test for function matchpathcon
def test_matchpathcon():
    print("matchpathcon test")
    (rc, con) = matchpathcon("/etc/passwd", 0)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"



# Generated at 2022-06-11 01:52:13.748580
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        return

    import selinux
    from tempfile import mkstemp
    from shutil import move

    # test file
    fd, fname = mkstemp()
    os.close(fd)
    move(fname, fname + '.tmp')
    label = selinux.matchpathcon(fname, 0)[1]
    os.link(fname + '.tmp', fname)
    os.remove(fname + '.tmp')
    for bool in [False, True]:
        [rc, context] = lgetfilecon_raw(fname, bool)
        assert rc == 0, 'lgetfilecon_raw failed'
        if bool:
            assert context == label, 'lgetfilecon_raw (bool=True) failed'

# Generated at 2022-06-11 01:52:19.727267
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', 0)
    assert rc == 0
    assert con == 'system_u:object_r:passwd_file_t:s0'
    rc, con = matchpathcon('/tmp/passwd', 0)
    assert rc == 2
    assert not con
    rc, con = matchpathcon('/tmp/foo', 0)
    assert rc == 2
    assert not con

# Generated at 2022-06-11 01:52:21.628799
# Unit test for function matchpathcon
def test_matchpathcon():
    d = matchpathcon("/foo", 0)
    assert d[1] == "foo_t"
    assert d[0] == 0

# Generated at 2022-06-11 01:52:29.341764
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = "/etc"
    rc, con = lgetfilecon_raw(test_path)
    if rc < 0:
        print("Error calling libselinux function lgetfilecon_raw: %s" % os.strerror(rc))
        return False

    if rc == 0 and con is not None:
        print("Received context from lgetfilecon_raw: %s" % con)
        return True
    else:
        print("Failed to receive context from lgetfilecon_raw")
        return False


# Generated at 2022-06-11 01:52:31.126555
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/')
    assert rc == 0
    assert con is not None

# Generated at 2022-06-11 01:52:37.229912
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = "/usr/sbin/rsyslogd"
    fname = lgetfilecon_raw(test_file)[1]
    if (fname != ''):
        print("Function lgetfilecon_raw is working fine")
    else:
        print("Function lgetfilecon_raw is not working fine")

# Generated at 2022-06-11 01:52:40.980973
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, res = lgetfilecon_raw(b'/etc/passwd')
    print('Result rc:', rc)
    print('Result res:', res)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:52:46.914829
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        _selinux_lib.matchpathcon.argtypes = [c_char_p, c_int, POINTER(c_char_p)]
        _selinux_lib.matchpathcon.restype = c_int
        mode = 0
        path = b'/'
        con = c_char_p()
        rc = _selinux_lib.matchpathcon(path, mode, byref(con))
        print(rc, to_native(con.value))
    finally:
        _selinux_lib.freecon(con)

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:52:50.402773
# Unit test for function matchpathcon
def test_matchpathcon():
    # return the context of path in order to verify it is correct
    mode = os.stat(os.environ["HOME"]).st_mode
    return matchpathcon(os.environ["HOME"], mode)



# Generated at 2022-06-11 01:52:53.654658
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con1 = lgetfilecon_raw(b'/etc/hosts')
    assert rc == 0
    rc, con2 = lgetfilecon_raw(b'/etc/hosts')
    assert con1 == con2
    return True


# Generated at 2022-06-11 01:53:00.645792
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile

    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, 'tempfile')
    testfile = open(filename, 'w')
    testfile.close()

    rc, con = lgetfilecon_raw(filename)
    assert rc == 0
    assert con == 'system_u:object_r:user_tmp_t:s0'

    os.unlink(filename)
    os.rmdir(tempdir)


# Generated at 2022-06-11 01:53:08.948738
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_bytes
    # This is the path to the ansible executable.
    # NOTE: You need to use the path to the executable that exists on the system you are running the tests on.
    #       Or alternatively, if you are running the test script on the same system where ansible is installed,
    #       then you can use the below command to automatically populate the path to the executable.
    #
    # $ python -c 'import sys, os, inspect; print(os.path.realpath(sys.argv[1]))' $(which ansible)
    path = to_bytes('/usr/bin/ansible')
    mode = 0
    rc, con = matchpathcon(path=path, mode=mode)
    print(rc, con)

# Generated at 2022-06-11 01:53:17.413741
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    import stat

    def matchpathcon_test(path,
                          should_succeed=True,
                          condition=None,
                          expected_con=None,
                          mode=None,
                          fmode=0o777,
                          create=False):
        path = to_bytes(path, errors='surrogate_or_strict')
        if create:
            with tempfile.NamedTemporaryFile(mode=fmode) as f:
                path = f.name
        if mode is None:
            mode = os.lstat(path).st_mode
        mode = stat.S_IFMT(mode)

        if should_succeed:
            rc, con = matchpathcon(path, mode)
            if condition is None or condition(rc):
                assert rc

# Generated at 2022-06-11 01:53:28.307935
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import socket
    import tempfile

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
    fd, fpath = tempfile.mkstemp()
    os.close(fd)

    rc, con = lgetfilecon_raw(fpath)
    assert rc == 0, "lgetfilecon_raw rc=%d con=%s" % (rc, con)
    rc, con = lgetfilecon_raw('/proc/self/fd/%d' % s.fileno())
    assert rc == 0, "lgetfilecon_raw rc=%d con=%s" % (rc, con)

    rc, con = lgetfilecon_raw

# Generated at 2022-06-11 01:53:33.094019
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/hosts"
    rc, con = matchpathcon(path, os.R_OK)
    assert rc == 0
    assert con is not None
    assert con != ''

if __name__ == '__main__':
    test_matchpathcon()
    print('unit test tests pass')

# Generated at 2022-06-11 01:53:40.607207
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Tests for matchpathcon() in selinux.py using the test path
    /etc/selinux/targeted/contexts/files/file_contexts
    """
    from ansible.module_utils.selinux import matchpathcon

    con, rc = matchpathcon('/etc/selinux/targeted/contexts/files/file_contexts', 0)
    assert rc == 0
    assert con == 'system_u:object_r:selinux_config_t:s0'
    return


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:53:45.120750
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0)[1] is not None
    assert matchpathcon('/etc/passwd', 0)[1] == 'system_u:object_r:passwd_file_t:s0'

# Generated at 2022-06-11 01:53:47.100981
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc')[1] is not None


# Generated at 2022-06-11 01:53:57.827380
# Unit test for function matchpathcon
def test_matchpathcon():
    import shutil
    from tempfile import mkdtemp

    from ansible.module_utils.selinux import _selinux_lib
    from ansible.module_utils.selinux import matchpathcon

    _selinux_lib.matchpathcon.argtypes = [c_char_p, c_int, POINTER(c_char_p)]


# Generated at 2022-06-11 01:54:04.791526
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        from ansible.module_utils.facts.selinux import _selinux_lib
    except ImportError:
        pass
    else:
        path = "/foo"
        test_lgetfilecon_raw.con = c_char_p()
        try:
            test_lgetfilecon_raw.rc = _selinux_lib.lgetfilecon_raw(path, byref(test_lgetfilecon_raw.con))
        finally:
            _selinux_lib.freecon(test_lgetfilecon_raw.con)

# Generated at 2022-06-11 01:54:07.932646
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
  if not is_selinux_enabled():
    rc, context = lgetfilecon_raw(b"/dev/null")
    # NB: -1 is returned if SELinux is not enabled
    assert rc == -1


# Generated at 2022-06-11 01:54:11.585589
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/home/ansible/', 0) == [0, 'user_home_dir_t']
    assert matchpathcon('/dev/null', 0) == [0, 'chr_file_t']

# Generated at 2022-06-11 01:54:17.477930
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    This function will normally return a string which contains the current security context
    for the specified file or directory.
    """

    # Get the current folder context
    _, context = lgetfilecon_raw(b'.')

    # Output to stdout
    print(context)

    # This test is successful if the function returns 0
    assert(context is not None)



# Generated at 2022-06-11 01:54:22.892563
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    confile = tempfile.NamedTemporaryFile()
    confile.write(b'system_u:object_r:tmp_t:s0')
    confile.flush()
    rc, con = lgetfilecon_raw(confile.name)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-11 01:54:25.137924
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/dev/null'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert '/dev/null system_u:object_r:null_device_t:s0' in con


# Generated at 2022-06-11 01:54:40.468791
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/sys/block/sda'
    mode = os.R_OK | os.W_OK | os.X_OK

    rc = matchpathcon(path, mode)
    if rc[0] != 0:
        print("matchpathcon failed: {0}: {1}".format(rc[0], rc[1]))
        sys.exit(1)
    print("matchpathcon success: {0}: {1}".format(rc[0], rc[1]))

    rc = selinux_getpolicytype()
    if rc[0] != 0:
        print("selinux_getpolicytype failed: {0}: {1}".format(rc[0], rc[1]))
        sys.exit(1)

# Generated at 2022-06-11 01:54:42.865323
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path='/tmp/test'
    os.remove(path)
    os.mkfifo(path)
    res = lgetfilecon_raw(path)
    os.remove(path)
    return True

# Generated at 2022-06-11 01:54:52.516271
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    _, path = tempfile.mkstemp()
    os.unlink(path)
    os.mkdir(path)
    _, con = lgetfilecon_raw(path)
    os.rmdir(path)
    assert con
    assert con.startswith('system_u:object_r:')

    # Check success with a context label specified.
    assert lsetfilecon(path, 'system_u:object_r:unlabeled_t:s0') == 0

    # Check success without a context label specified.
    assert lsetfilecon(path, '') == 0


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:55:00.950280
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        (rc, con) = matchpathcon(b'/some/context', 1)
        assert rc == 0 or rc == 2, 'matchpathcon failed with error code %d' % rc
    except OSError as e:
        sys.stderr.write('OSError: %s\n' % e)
        sys.exit(1)
    finally:
        del(rc, con)


if __name__ == '__main__':
    sys.stderr.write('Running sample test for function matchpathcon\n')
    test_matchpathcon()

# Generated at 2022-06-11 01:55:05.470677
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Test for matchpathcon')
    try:
        rc, con = matchpathcon('/tmp', 0)
    except OSError as e:
        print('Error: {0}'.format(str(e)))
        return

    print('Result is {0}, {1}'.format(rc, con))



# Generated at 2022-06-11 01:55:07.808370
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/usr/bin/whoami') == [0, 'system_u:object_r:usr_t']

# Generated at 2022-06-11 01:55:14.683079
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import selinux_helpers
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common._collections_compat import Mapping

    # Test for path_mode_t's
    # S_IFMT     0170000   bit mask for the file type bit fields
    # S_IFSOCK   0140000   socket
    # S_IFLNK    0120000   symbolic link
    # S_IFREG    0100000   regular file
    # S_IFBLK    0060000   block device
    # S_IFDIR    0040000   directory
    # S_IFCHR    0020000   character device
    # S_IFIFO    0010000   FIFO
    # S_ISUID    0004000   set UID bit
    # S_ISG

# Generated at 2022-06-11 01:55:25.395729
# Unit test for function matchpathcon
def test_matchpathcon():  # noqa
    test_file = '/tmp/ansible_test_matchpathcon'
    rc, con = matchpathcon(test_file, 0)
    print('test_matchpathcon file: {0} rc: {1} con: {2}'.format(test_file, rc, con))
    if rc == 0:
        rc = lsetfilecon(test_file, con)
        print('test_matchpathcon file: {0} lsetfilecon rc: {1}'.format(test_file, rc))
        if rc == 0:
            rc, con = lgetfilecon_raw(test_file)
            print('test_matchpathcon file: {0} lgetfilecon_raw rc: {1} con: {2}'.format(test_file, rc, con))



# Generated at 2022-06-11 01:55:29.833496
# Unit test for function matchpathcon
def test_matchpathcon():
    pathname = b"/etc/securetty"
    mode = os.stat(to_native(pathname)).st_mode
    rc, con = matchpathcon(pathname, mode)
    assert rc == 0
    assert con == "system_u:object_r:securetty_device_t"


# Generated at 2022-06-11 01:55:32.740652
# Unit test for function matchpathcon
def test_matchpathcon():
    assert _selinux_lib.matchpathcon("test/test.txt", 1, 0) == 0
    assert _selinux_lib.matchpathcon("test/test.txt", 0, 0) == 0

# Generated at 2022-06-11 01:55:45.509761
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/resolv.conf', os.R_OK) == [0, 'system_u:object_r:resolv_conf_t:s0']
    assert matchpathcon('/etc/not_exist_file', os.R_OK) == [-1, '']


# Generated at 2022-06-11 01:55:54.461231
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import subprocess

    fd, fname = tempfile.mkstemp()

# Generated at 2022-06-11 01:55:59.595603
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon() function
    """
    result, context = matchpathcon("/tmp/testfile1", 0)
    if result == 0:
        print("Context of file is: %s" % context)
    else:
        print("Empty Context")
        context = None



# Generated at 2022-06-11 01:56:08.281514
# Unit test for function matchpathcon
def test_matchpathcon():

    # Get a filename
    file_name = os.path.realpath(__file__)

    # Get the context
    context = matchpathcon(file_name, os.R_OK)[1]

    # Create an SELinux module to change the context of the file to guest_u:object_r:user_home_t
    module_text = '''
module selinux_example 1.0;

require {
        type user_home_t;
        type unconfined_t;
        class file { write getattr };
}

#============= unconfined_t ==============
allow unconfined_t user_home_t:file { write getattr };
    '''
    module_path = '/tmp/selinux_example.pp'
    module_name = 'selinux_example'

# Generated at 2022-06-11 01:56:11.588033
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/home') == [0, 'system_u:object_r:user_home_t:s0']

# TODO: add unit tests for the other functions, but first have to figure out how to mock them

# Generated at 2022-06-11 01:56:14.266616
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con_raw = lgetfilecon_raw('/')
    except OSError:
        pass
    return


# Generated at 2022-06-11 01:56:18.683432
# Unit test for function matchpathcon
def test_matchpathcon():
    # test case if selinux is disabled
    rc, con = matchpathcon("/tmp/test.txt", os.R_OK)
    assert rc == 0 and con == "system_u:object_r:user_tmp_t:s0"



# Generated at 2022-06-11 01:56:27.641631
# Unit test for function matchpathcon
def test_matchpathcon():
    from random import randint
    from tempfile import mkdtemp
    from shutil import rmtree

    def check_file(dir, target, mode, expected_return, expected_con):
        file_path = os.path.join(dir, target)
        with open(file_path, 'w'):
            pass

        actual_return, actual_con = matchpathcon(file_path.encode('utf-8'), mode)
        assert actual_return == expected_return
        assert actual_con == expected_con

    # Test cases:
    #
    #  1. The dir with this test code is used.  Since the test code is run in
    #     python virtual environment, /tests/.selinux will be used as context
    #     file.
    #  2. The python script will write a file first and then call the

# Generated at 2022-06-11 01:56:34.272520
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Test calling the library function lgetfilecon_raw().
    '''
    try:
        rc, con = lgetfilecon_raw('/etc/passwd')
        assert rc == 0
        assert (con.startswith('system_u:object_r:passwd_file_t:s0'))
    except OSError as e:
        assert e.errno == 2


# Generated at 2022-06-11 01:56:36.084464
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b"/selinux/contexts/files/file_contexts"
    mode = 6
    rc = matchpathcon(path, mode)
    assert rc[0] == -1
    assert rc[1] == "system_u:object_r:selinux_var_lib_t:s0"



# Generated at 2022-06-11 01:56:58.634727
# Unit test for function matchpathcon
def test_matchpathcon():
    import pytest
    from ansible.module_utils.selinux import matchpathcon

    pytest.importorskip('selinux')

    rc, con = matchpathcon('/', 1)
    assert rc == 0, 'matchpathcon returned unexpected rc: %s' % rc
    assert con == 'system_u:object_r:svirt_sandbox_file_t:s0', 'matchpathcon returned unexpected con: %s' % con

# Generated at 2022-06-11 01:57:06.205740
# Unit test for function matchpathcon
def test_matchpathcon():
    enforcemode = selinux_getenforcemode()[1]
    policytype = selinux_getpolicytype()[1]

    if policytype != 'targeted':
        raise Exception('matchpathcon can only be used with the targeted policy')

    # FIXME: turn this into a unit test
    if enforcemode != 1:
        print('please enable SELinux policy enforcement')
    else:
        [rc, con] = matchpathcon('/sysconfig/network-scripts/ifcfg-eth0', 0)
        print(con)



# Generated at 2022-06-11 01:57:09.515277
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print('Testing function lgetfilecon_raw')
    print(lgetfilecon_raw(b'/tmp/ansible-test-file'))


# Generated at 2022-06-11 01:57:12.634157
# Unit test for function matchpathcon
def test_matchpathcon():

    # Test a directory
    testpath = '/tmp/ansible_test_matchpathcon'

    # Validate
    assert matchpathcon(testpath, 0)[1] == 'unlabeled_t:object_r:user_tmp_t:s0'

    # Cleanup
    os.rmdir(testpath)

# Generated at 2022-06-11 01:57:23.620479
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path_arg = b'/etc/selinux'

    # Create sample output
    def mock_lgetfilecon_raw(path):
        return [0, 'system_u:object_r:etc_t:s0']

    lgetfilecon_raw_orig = lgetfilecon_raw

    lgetfilecon_raw.side_effect = mock_lgetfilecon_raw
    try:
        rc, con = lgetfilecon_raw(path_arg)
    finally:
        lgetfilecon_raw = lgetfilecon_raw_orig
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-11 01:57:26.345753
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os

    file_name = os.path.basename(sys.argv[0])
    res, txt = lgetfilecon_raw(file_name)
    print("context for file", file_name, "is", txt)

# Generated at 2022-06-11 01:57:30.365504
# Unit test for function matchpathcon
def test_matchpathcon():
    for mode in {0, 1, 2}:
        rc, selinux_context = matchpathcon(b'/etc/localtime', mode)
        assert rc == 0
        assert selinux_context == 'system_u:object_r:timezone_file_t'

# Generated at 2022-06-11 01:57:32.649733
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/usr", 0)
    assert rc == 0
    assert con == "system_u:object_r:usr_t:s0"

# Generated at 2022-06-11 01:57:35.211537
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_output = lgetfilecon_raw('/')
    assert test_output == [0, 'system_u:object_r:initrc_exec_t:s0'], "Test case failed"

# Generated at 2022-06-11 01:57:43.551697
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not os.path.isdir('/sys/fs/selinux'):
        raise AssertionError('OS does not support SELinux')

    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw('/proc/1/cgroup', byref(con))
    assert rc == 0
    assert con.value is not None
    _selinux_lib.freecon(con)

    rc = _selinux_lib.lgetfilecon_raw('/proc/1/cgroup-garbage', byref(con))
    assert rc == -1
    assert con.value is None
    assert get_errno() != 0



# Generated at 2022-06-11 01:58:34.147282
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    expected_rc = 0
    assert rc == expected_rc
    expected_con = 'system_u:object_r:etc_runtime_t:s0'
    assert con == expected_con


# Generated at 2022-06-11 01:58:37.734207
# Unit test for function matchpathcon
def test_matchpathcon():
    # $ cd /
    # $ python3 -c "from ansible.module_utils.selinux import matchpathcon; print(matchpathcon('/',0))"
    print(matchpathcon('/', 0))

    # $ cd /
    # $ python3 -c "from ansible.module_utils.selinux import matchpathcon; print(matchpathcon('/proc',0))"
    print(matchpathcon('/proc', 0))

    # $ cd /
    # $ python3 -c "from ansible.module_utils.selinux import matchpathcon; print(matchpathcon('/proc/1',0))"
    print(matchpathcon('/proc/1', 0))

    # $ cd /
    # $ python3 -c "from ansible.module_utils.selinux import matchpathcon

# Generated at 2022-06-11 01:58:44.353420
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create a file
    with open('test_lgetfilecon_raw.txt', 'w') as f:
        f.write("This is a test file")
    # Call lgetfilecon_raw
    con = lgetfilecon_raw('test_lgetfilecon_raw.txt')
    if con[0] == 0:
        con = con[1]
        assert con.startswith('unconfined_u:object_r:user_tmp_t:s0')
    os.remove('test_lgetfilecon_raw.txt')

# Generated at 2022-06-11 01:58:47.256933
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    for path in ('.', '/'):
        rc, output = lgetfilecon_raw(path)
        assert rc == 0
        assert len(output) > 0


# Generated at 2022-06-11 01:58:53.475547
# Unit test for function matchpathcon
def test_matchpathcon():
    if selinux_getpolicytype()[0] == 0 and security_getenforce() == 1:
        file_name = "/etc/shadow"
        file_mode = os.stat(file_name).st_mode
        fcontext = matchpathcon(file_name, file_mode)[1]
        assert fcontext == "system_u:object_r:shadow_t:s0"

    else:
        # selinux is not enabled
        assert selinux_getenforcemode() == [0, 0]

# Generated at 2022-06-11 01:58:55.229522
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/hosts') == [0, 'system_u:object_r:etc_t:s0']


# Generated at 2022-06-11 01:58:57.217561
# Unit test for function matchpathcon

# Generated at 2022-06-11 01:59:01.843876
# Unit test for function matchpathcon
def test_matchpathcon():
    import pytest

    # test parameter validation
    with pytest.raises(ValueError):
        matchpathcon(None, 0)
    with pytest.raises(ValueError):
        matchpathcon('', 0)

    # test matchpathcon
    r = matchpathcon(b'/etc/passwd', 0)
    assert r[0] == 0



# Generated at 2022-06-11 01:59:03.837188
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret, out = lgetfilecon_raw('/etc/passwd')
    assert ret == 0
    assert out is not None


# Generated at 2022-06-11 01:59:07.726742
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    rc, result = matchpathcon(os.path.dirname(__file__), 0)
    assert rc == 0
    assert result == "system_u:object_r:bin_t:s0"



# Generated at 2022-06-11 02:00:42.208787
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('test', 0o666)
    assert rc == -1  # should fail
    if rc != -1:  # if not fail, then free the allocated memory
        _selinux_lib.freecon(con)

    # selinux_lib.matchpathcon from posix module should get a different
    # error code, as selinux.py will decode the errno value and
    # throw an exception
    # with pytest.raises(OSError) as matchpathcon_exc:
    #     matchpathcon('test', 0o666)
    # assert matchpathcon_exc.value.errno == 2  # No such file or directory