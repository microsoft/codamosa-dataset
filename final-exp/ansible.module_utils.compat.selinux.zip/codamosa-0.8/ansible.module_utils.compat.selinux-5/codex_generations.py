

# Generated at 2022-06-11 01:50:43.990508
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, path = lgetfilecon_raw('/etc/selinux/config')
    assert rc == 0
    assert path.startswith('unconfined_u')
    assert ':system_r:etc_t:s0' in path

# Generated at 2022-06-11 01:50:56.031249
# Unit test for function matchpathcon
def test_matchpathcon():
    # python version of matchpathcon in t/selinux/matchpathcon.c
    # matchpathcon(2) is deprecated and not really useful.
    # It tests that "selinux_getenforce" and "security_getenforce"
    # and "selinux_getenforcemode" are consistent.
    # First copy the policy to /tmp/policy
    policy = b'libselinux/test/policy'
    orig_policy = policy + b'_orig'
    test_policy = b'/tmp/policy'
    if os.path.exists(test_policy):
        os.unlink(test_policy)
    os.symlink(orig_policy, test_policy)
    sec_enforce = security_getenforce()
    enable = is_selinux_enabled()

# Generated at 2022-06-11 01:51:03.048909
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    assert lgetfilecon_raw(b'\x08\x02') == [22, None]
    assert lgetfilecon_raw(b'') == [22, None]
    assert lgetfilecon_raw(os.path.expanduser(b'~/.viminfo')) == [0, b'system_u:object_r:user_home_t:s0']
    assert lgetfilecon_raw(b'/') == [0, b'root:object_r:root_t:s0']



# Generated at 2022-06-11 01:51:15.410110
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/hosts.allow"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    if rc < 0:
        print("Failed to get context for {}: {}".format(path, con))
    assert rc >= 0
    del(rc)

    path = "/etc/hosts.allow"
    mode = os.W_OK
    rc, con = matchpathcon(path, mode)
    if rc < 0:
        print("Failed to get context for {}: {}".format(path, con))
    assert rc >= 0
    del(rc)

    path = "/tmp/does_not_exist"
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)

# Generated at 2022-06-11 01:51:18.103311
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp/ansible-test-file') == [0, 'system_u:object_r:tmp_t:s0']


# Generated at 2022-06-11 01:51:30.739089
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import textwrap
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.selinux_utils import lgetfilecon_raw

    test_file_path = '/tmp/lgetfilecon_raw_test'

    # (content, context)

# Generated at 2022-06-11 01:51:36.032689
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import ansible.module_utils.selinux
    (rc, con) = ansible.module_utils.selinux.lgetfilecon_raw(__file__)
    if rc < 0:
        print("Error number {0}".format(rc))
        import os.path
        print("File exists: {0}".format(os.path.exists(__file__)))
    else:
        print("OK Con = {0}".format(con))



# Generated at 2022-06-11 01:51:43.715831
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # create a temporary file
    test_filename = 'tmp_lgetfilecon_raw.txt'
    with open(test_filename, 'w') as tmp_file:
        tmp_file.write('Test file for lgetfilecon_raw')

    result, mode = lgetfilecon_raw(test_filename)
    print('result: {0}'.format(result))

    # remove the temporary file
    os.remove(test_filename)

    assert result == 0
    assert mode == 'system_u:object_r:container_file_t:s0'



# Generated at 2022-06-11 01:51:48.800796
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, value = matchpathcon('/etc/selinux/config', 0)
    except ImportError as e:
        # this will happen on systems with an old selinux lib
        print('INFO: matchpathcon test skipped ({0!s})'.format(str(e)))
    else:
        if rc != 0:
            raise AssertionError('matchpathcon failed with rc={0}\n'.format(rc))
        print('DONE: matchpathcon\n')

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:51:51.420404
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp') == [0, b'u:object_r:tmp_t:s0\x00']

# Generated at 2022-06-11 01:52:03.149739
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This will cause the function to raise an exception with the given message
    # when it is invoked.
    def raise_oserror(*args):
        raise OSError(errno.ENOENT, "No such file or directory")

    lgetfilecon_raw_orig = _selinux_lib.lgetfilecon_raw
    _selinux_lib.lgetfilecon_raw = raise_oserror

    try:
        rc, con = lgetfilecon_raw('unittestpath')
        print(rc)
        print(con)
        assert False, 'Expected OSError'
    except OSError as err:
        assert err.errno == errno.ENOENT

# Generated at 2022-06-11 01:52:11.240659
# Unit test for function matchpathcon
def test_matchpathcon():
    # normal case
    assert matchpathcon('/var/tmp/file.txt', 0) == [0, 'system_u:object_r:tmp_t:s0']

    # not existing file
    assert matchpathcon('/nonexisting/file.txt', 0) == [-1, None]

    # normal case, fakeroot
    assert matchpathcon('/var/tmp/file.txt', 0) == [0, 'user_u:object_r:user_tmp_t:s0']



# Generated at 2022-06-11 01:52:13.014185
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/file_with_extension.txt', 0) == [0, 'system_u:object_r:usr_t:s0']

# Generated at 2022-06-11 01:52:18.834034
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/var/log/audit'
    mode = 0o700
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:var_log_t:s0'

    # Test with invalid path
    path = '/invalid/path'
    mode = 0o700
    rc, con = matchpathcon(path, mode)
    assert rc != 0

# Generated at 2022-06-11 01:52:29.788269
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils._text import to_bytes
    import ctypes

    ctypes.CDLL.lgetfilecon_raw.restype = ctypes.c_int
    ctypes.CDLL.lgetfilecon_raw.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_char_p)]

    _selinux_lib.lgetfilecon_raw.restype = _selinux_lib.lgetfilecon_raw.argtypes = None
    _selinux_lib.freecon.argtypes = [ctypes.c_char_p]

    path = to_bytes('/etc/passwd')
    con = ctypes.c_char_p()

    assert _selinux_lib.lgetfilecon_raw(path, con) == 0


# Generated at 2022-06-11 01:52:36.429083
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    path = "/etc/hosts"
    rc, con = lgetfilecon_raw(path)
    if rc == 0:
        print("lgetfilecon_raw() OK")
    else:
        print("lgetfilecon_raw() FAILED")
        return

    if con.find("system_u") > -1:
        print("lgetfilecon_raw() system_u OK")
    else:
        print("lgetfilecon_raw() system_u FAILED")
        return



# Generated at 2022-06-11 01:52:40.040251
# Unit test for function matchpathcon
def test_matchpathcon():
    results = matchpathcon('/etc/ssh/sshd_config', 0)
    assert results[0] == 0
    assert results[1] == 'system_u:object_r:sshd_config_t:s0'



# Generated at 2022-06-11 01:52:44.073797
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/test/dir'
    mode = 0
    try:
        rc, con = matchpathcon(path, mode)  # type: ignore
        assert rc == 0 and con == 'system_u:object_r:device_t:s0'
    except OSError:
        pass

# Generated at 2022-06-11 01:52:48.790706
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/test'
    mode = 0
    [rc, con] = matchpathcon(path, mode)
    print('rc={0}, con={1}'.format(rc, con))
    assert isinstance(rc, int)
    assert isinstance(con, str)



# Generated at 2022-06-11 01:52:52.712689
# Unit test for function matchpathcon
def test_matchpathcon():
    """Function matchpathcon() Unit Test"""

    ret, context = matchpathcon('/var/log/audit', 0)

    if ret != 0:
        print('Error setting context for /var/log/audit')


if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-11 01:52:56.888299
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    s = lgetfilecon_raw('/usr/bin/crontab')
    assert s[0] == 0, s[0]



# Generated at 2022-06-11 01:53:07.471925
# Unit test for function matchpathcon
def test_matchpathcon():
    # Setting mode
    # mode = 1 = S_IFREG
    # mode = 2 = S_IFDIR
    import filecmp as fc
    import os
    import shutil
    import tempfile
    import time

    # TODO: This can be a parameter
    # TODO: Cleanup for this
    n_tries = 20

    # Create temporary directory, set the file to be created, and build the file path
    tmpdir = tempfile.mkdtemp()
    testfile = 'test.txt'
    testpath = os.path.join(tmpdir, testfile)

    # Create the test file so we can check the context
    # TODO: Add code to create a file with the proper context for this test
    # TODO: Add code to compare the expected con with the actual con
    f = open(testpath,'w')

# Generated at 2022-06-11 01:53:16.964087
# Unit test for function matchpathcon
def test_matchpathcon():
    # For the test to run you must be running in an SELinux environment
    # The test will pass if the function returns the specified context
    # and fail if the function returns a different context or an error
    result = selinux_getenforcemode()
    if result[1] != 1:
        sys.stderr.write('SELinux must be enabled for the matchpathcon test to run\n')
        sys.exit(1)
    econtext = "system_u:object_r:httpd_sys_content_t:s0"
    result = matchpathcon('/foo/bar', 0)
    if result[0] == 0 and result[1] == econtext:
        sys.stderr.write('Test passed - matchpathcon function is properly calling libselinux\n')
        sys.exit(0)

# Generated at 2022-06-11 01:53:22.472511
# Unit test for function matchpathcon
def test_matchpathcon():
    from ctypes import c_char_p
    current_dir = os.getcwd()
    filecon = c_char_p()
    rc = _selinux_lib.matchpathcon(current_dir, 0, byref(filecon))
    assert rc == 0, "Return code is not zero"


# Generated at 2022-06-11 01:53:30.877158
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import sys
    import tempfile
    import os
    import os.path

    from ansible.module_utils.selinux_impl import lgetfilecon_raw
    from ansible.module_utils.common.text.converters import to_native

    fd, config_file = tempfile.mkstemp(prefix="ansible-test-", text=True)
    print("TESTFILE={0}".format(config_file), file=sys.stderr)


# Generated at 2022-06-11 01:53:40.311868
# Unit test for function matchpathcon
def test_matchpathcon():
    from os import makedirs
    from os.path import join, exists

    rc, con = matchpathcon(join('../', 'test', 'data', 'bin', 'false'), 0)
    assert rc == 0
    assert con == 'unlabeled_t:unlabeled_t:s0'

    with open(join('../', 'test', 'data', 'bin', 'false'), 'w') as f:
        f.write("")

    rc, con = matchpathcon(join('../', 'test', 'data', 'bin', 'false'), 0)
    assert rc == 2
    assert con == 'system_u:object_r:lib_t:s0'

    rc, con = is_selinux_enabled()
    assert rc == 1
    assert con == 1

    rc, con = selinux_getenforce

# Generated at 2022-06-11 01:53:45.752418
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp') == [0, 'system_u:object_r:default_t:s0']
    assert lgetfilecon_raw('/tmp/foo')[0] == -1
    assert os.getenv('ANSIBLE_SELINUX_PYLIB_SKIP_ERROR_TEST') is None

# Generated at 2022-06-11 01:53:49.360523
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc/passwd')
    if rc == 0:
        print(con)
    else:
        print('lgetfilecon_raw failed with ' + str(rc))


# Generated at 2022-06-11 01:53:57.443319
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test if the function matchpathcon is working properly.
    # Use a path from /etc and run it against the system policy.
    # We should get no error. This test doesn't work if the system
    # policy is set to targeted, but generally minimum will be configured,
    # and that won't break. This test is therefore fairly ugly.
    path = to_bytes('/etc/resolv.conf')
    mode = 0
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, mode, byref(con))
    assert rc == 0

# Generated at 2022-06-11 01:54:06.149415
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.selinux_utils import lgetfilecon_raw
    from tempfile import mkdtemp

    results = {}

    module = AnsibleModule(
        argument_spec=dict(
            path=dict(type='str', required=True)
        )
    )
    params = module.params

    path = params.get('path', None)

    if os.path.exists(path):
        module.fail_json(msg='Path already exists: {0}'.format(path))

    tmpdir = mkdtemp()
    try:
        _, new_path = lgetfilecon_raw(tmpdir + '/foo')
        results['con'] = new_path
    except OSError as e:
        errno = e

# Generated at 2022-06-11 01:54:14.388145
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "selinux_test.py"
    [rc, value] = lgetfilecon_raw(path)
    print("lgetfilecon_raw(%s): %s" % (path, value))


# Generated at 2022-06-11 01:54:17.726943
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/group"
    con = lgetfilecon_raw(path)
    assert con == [0, "system_u:object_r:etc_t:s0"]



# Generated at 2022-06-11 01:54:28.526856
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    from ctypes import create_string_buffer

    fd, path = os.pipe()
    os.close(fd)
    rc, con = lgetfilecon_raw(path)
    assert rc == 0, 'rc: {0}'.format(rc)
    assert con, 'con is empty, path: {0}'.format(path)
    assert con.count('.') >= 2, 'con: {0}'.format(con)

    # Test with path including null byte
    path = create_string_buffer(os.urandom(5) + b'\0' + os.urandom(5), 255)
    rc, con = lgetfilecon_raw(path)
    assert rc == 0, 'rc: {0}'.format(rc)

# Generated at 2022-06-11 01:54:39.731784
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import unittest

    class TestLgetfileconRaw(unittest.TestCase):
        def setUp(self):
            self.fn = "/tmp/python-selinux-test"
            self.con = "system_u:object_r:unlabeled_t:s0"
            os.system("touch %s" % self.fn)
            os.system("touch /etc/test-python-selinux-test")  # for matchpathcon
            os.system("chcon -t unlabeled_t %s" % self.fn)
            os.system("restorecon %s" % self.fn)

        def test_lgetfilecon_raw(self):
            rc, con = lgetfilecon_raw(self.fn)
            self.assertEqual(0, rc)

# Generated at 2022-06-11 01:54:43.005414
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/etc/selinux/config')
    assert rc >= 0
    # con is something like: system_u:object_r:etc_t:s0
    assert len(con) > 0
    assert con.split(b':') >= 4


# Generated at 2022-06-11 01:54:53.586801
# Unit test for function matchpathcon
def test_matchpathcon():
    assert _selinux_lib.matchpathcon(b"/", 0, None) == 0
    assert _selinux_lib.matchpathcon(b"/", 0, None) == -1
    assert _selinux_lib.matchpathcon(b"/", 0, None) == -1
    assert _selinux_lib.matchpathcon(b"/", 0, None) == -1
    assert _selinux_lib.matchpathcon(b"/", 0, None) == -1
    assert _selinux_lib.matchpathcon(b"/", 0, None) == -1
    assert _selinux_lib.matchpathcon(b"/", 0, None) == -1
    assert _selinux_lib.matchpathcon(b"/", 0, None) == -1


# Generated at 2022-06-11 01:55:00.478971
# Unit test for function matchpathcon
def test_matchpathcon():
    # matchpathcon success
    rc, con = matchpathcon('/tmp', 0)
    assert rc == 0, con
    assert con == 'system_u:object_r:default_t:s0'

    # matchpathcon fail
    rc, con = matchpathcon('/tmp', 0xFFFF)
    assert rc == -1, con
    assert con == 'system_u:object_r:default_t:s0'



# Generated at 2022-06-11 01:55:08.603215
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Tests the wrapper function lgetfilecon_raw"""
    import tempfile
    import shutil
    import atexit

    data = """
      package:
        name: ansible-test-module-selinux
        version: 1.0
      files:
        -   name: /tmp/mike
            mode: 0600
            policy: {0}
        -   name: /tmp/mike2
            mode: 0600
    """


# Generated at 2022-06-11 01:55:19.869083
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import sys
    from tempfile import NamedTemporaryFile

    from ansible.module_utils.selinux import matchpathcon

    thismodule = sys.modules[__name__]

    if not hasattr(thismodule, 'SELINUX_MKDIRCON'):
        return

    with NamedTemporaryFile(dir='/tmp') as f:
        rc, con = matchpathcon(f.name, os.R_OK)
        assert rc == 0, 'matchpathcon failed: {0}'.format(rc)

        rc, con = matchpathcon(f.name, os.W_OK)
        assert rc == 0, 'matchpathcon failed: {0}'.format(rc)

        rc, con = matchpathcon(f.name, os.X_OK)

# Generated at 2022-06-11 01:55:27.817616
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Ansible matchpathcon() test')
    import tempfile
    tmpdir = tempfile.mkdtemp()
    try:
        print('Creating a test directory:', tmpdir)
        tmppath = os.path.join(tmpdir, 'test.txt')
        print('Creating a test file:', tmppath)
        test_file = open(tmppath, 'w')
        test_file.write('test file content')
        test_file.close()
        print('Checking selinux context for the file')
        con = matchpathcon(tmppath, os.R_OK)
        print('matchpathcon() result: %r' % con)
    finally:
        print('Removing test directory')
        import shutil
        shutil.rmtree(tmpdir)

# Generated at 2022-06-11 01:55:34.674201
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/root') == [0, 'system_u:object_r:admin_home_t:s0']


# Generated at 2022-06-11 01:55:42.735929
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import selinux

    t_file = tempfile.NamedTemporaryFile()

    t_file_path = t_file.name

    if selinux.is_selinux_enabled():
        rc, t_file_con = selinux.lgetfilecon_raw(t_file_path)

        if rc < 0:
            raise OSError(rc, os.strerror(rc))
    else:
        t_file_con = t_file_path + ":security.context:unlabeled"

    print(t_file_con)

    # rc = selinux.lsetfilecon_raw(t_file_path, t_file_con)
    #
    # if rc < 0:
    #     raise OSError(rc, os.strerror(rc))


# Generated at 2022-06-11 01:55:47.399782
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(b'/etc/selinux/config', byref(con))
    _selinux_lib.freecon(con)

    assert rc == 0
    assert con.value == b"unconfined_u:object_r:etc_t:s0"

# Generated at 2022-06-11 01:55:55.817481
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import os.path
    from ansible.module_utils.common.text.converters import to_native
    from ctypes import CDLL, c_char_p, c_int, byref
    selinux_lib = CDLL('libselinux.so.1')
    config_path = '/etc/selinux/targeted/contexts/files/file_contexts.local'
    if not os.path.isfile(config_path):
        # create file_contexts.local
        open(config_path, 'a').close()
    constr = c_char_p()
    rc = selinux_lib.matchpathcon("/etc/selinux/targeted/contexts/files/file_contexts.local", 0, byref(constr))

# Generated at 2022-06-11 01:55:57.079865
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, x = matchpathcon('/tmp', 0)
    print('rc=%d, context=%s' % (rc, x))
    assert rc == 0

# Generated at 2022-06-11 01:56:00.515059
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = '/etc/passwd'
    (rc, con) = lgetfilecon_raw(file_path)
    print('con: ' + con)

# Generated at 2022-06-11 01:56:05.425267
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    myfile = "myfile"
    try:
        os.mknod(myfile)
        rc, out = lgetfilecon_raw(myfile)
        os.unlink(myfile)
        if rc < 0:
            raise Exception("lgetfilecon_raw failed")
    except Exception as e:
        print(e)


# Generated at 2022-06-11 01:56:06.453938
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon("/var/www/html/test.html", 0))

# Generated at 2022-06-11 01:56:11.047755
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/test'

    with open(path, 'a+') as f:
        f.write('test')

        con = lgetfilecon_raw(path)
        try:
            assert con[1] is not None
        finally:
            _selinux_lib.freecon(con[1])


# Generated at 2022-06-11 01:56:13.776360
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    actual = lgetfilecon_raw('/')
    expected = [0, b'system_u:object_r:root_t:s0']
    assert actual == expected


# Generated at 2022-06-11 01:56:19.993015
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp/foo', 0) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-11 01:56:29.634995
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    from .. import selinux_utils

    filepath = os.path.join(os.sep, 'var', 'www', 'html', 'index.html')
    (rc, con) = selinux_utils.matchpathcon(filepath, 0)
    assert con == 'system_u:object_r:httpd_sys_content_t:s0'
    assert rc == 0

    filepath = os.path.join(os.sep, 'var', 'www')
    (rc, con) = selinux_utils.matchpathcon(filepath, 0)
    assert con == 'system_u:object_r:httpd_sys_content_t:s0'
    assert rc == 0


# Generated at 2022-06-11 01:56:37.983452
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    from ansible.module_utils.common.text.converters import to_bytes

    fh, path = tempfile.mkstemp()
    os.close(fh)
    os.unlink(path)

    fh, path = tempfile.mkstemp()
    os.close(fh)

    try:
        [rc, con] = lgetfilecon_raw(path)
        assert rc == 0, "lgetfilecon_raw failed with error {}".format(rc)
    finally:
        os.unlink(path)

# Generated at 2022-06-11 01:56:40.955010
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/test', 0)
    assert con == 'system_u:object_r:default_t:s0'
    rc, con = matchpathcon('/test/invalid/con', 0)
    assert con is None

# Generated at 2022-06-11 01:56:44.507944
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print("Testing function lgetfilecon_raw")
    [rc, con] = lgetfilecon_raw("/home")
    print("RC = ", rc)
    print("Context = ", con)



# Generated at 2022-06-11 01:56:50.912071
# Unit test for function matchpathcon
def test_matchpathcon():
    test_result = matchpathcon("/usr/.shadow_t", 0)
    if test_result[0] != -1:
        if test_result[1] == "system_u:object_r:shadow_t:s0":
            print("matchpathcon function works correctly")
        else:
            print("matchpathcon function doesn't work correctly")
    else:
        print("matchpathcon function doesn't work correctly")


# Generated at 2022-06-11 01:56:54.487174
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('/tmp/foo', os.R_OK)
    print("return code: %d" % ret[0])
    print("context: %s" % ret[1])

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:57:05.410682
# Unit test for function matchpathcon
def test_matchpathcon():
    ret, con = matchpathcon('/tmp', 0)
    # On success 0 is returned, on error -1 is returned, and errno is set appropriately.
    assert(ret == 0)
    assert(con == 'system_u:object_r:tmp_t:s0')

    ret, con = matchpathcon('/boot/efi', 0)
    assert(ret == 0)
    assert(con == 'system_u:object_r:boot_t:s0')

    ret, con = matchpathcon('/boot/efi', 2)
    assert(ret == 0)
    assert(con == 'system_u:object_r:boot_t:s0')

    # This directory doesn't exist
    ret, con = matchpathcon('/boot/efi2', 0)
    assert(ret == -1)

# Generated at 2022-06-11 01:57:10.655927
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/hosts'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t'
    path = '/etc/hostsx'
    rc, con = lgetfilecon_raw(path)
    assert rc == -1


# Generated at 2022-06-11 01:57:18.761043
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = os.stat(__file__).st_mode
    rc, con = matchpathcon(__file__, mode)
    assert 0 == rc
    assert con == "system_u:object_r:system_tmp_t:s0"
    rc, con = matchpathcon("/", mode)
    assert 0 == rc
    assert con == "system_u:object_r:root_t:s0"
    rc, con = matchpathcon("/asdf", mode)
    assert rc != 0
    assert con is None