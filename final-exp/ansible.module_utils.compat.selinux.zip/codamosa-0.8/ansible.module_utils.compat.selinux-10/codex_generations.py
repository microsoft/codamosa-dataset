

# Generated at 2022-06-11 01:50:40.358179
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/usr/bin/id')
    assert rc == 0
    assert con == 'system_u:object_r:setuid_exec_t:s0'


# Generated at 2022-06-11 01:50:43.747841
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/selinux/targeted/contexts/files/file_contexts.homedirs'
    assert lgetfilecon_raw(path) == [0, 'system_u:object_r:home_root_t:s0']

# Generated at 2022-06-11 01:50:48.149022
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/tmp')
    rc = result[0]
    con = result[1]
    assert rc == 0
    assert con.startswith('system_u:object_r')



# Generated at 2022-06-11 01:50:52.429955
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon(b'/etc/selinux/semanage.conf', 0)
    assert ret[0] == 0
    assert ret[1] == 'system_u:object_r:semanage_conf_t:s0'


# Generated at 2022-06-11 01:50:55.876697
# Unit test for function matchpathcon
def test_matchpathcon():
    testvalue = matchpathcon('/', 0)
    assert testvalue[0] == 0
    assert testvalue[1] == 'system_u:object_r:root_t:s0'

# Generated at 2022-06-11 01:50:58.789222
# Unit test for function matchpathcon
def test_matchpathcon():
    """Basic Selinux unit test for function matchpathcon"""
    path = "/var/log/testlog"
    mode = 0
    rc, con = matchpathcon(path, mode)
    if rc < 0:
        raise OSError(os.strerror(rc))
    print(con)
    return 0


# Generated at 2022-06-11 01:51:06.734128
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: this test should be written to actually use selinux and match
    # the path of a file. We should run it with selinux policies that don't
    # enforce on one system and then on a system that does.
    # But we don't have a system at our disposal that enforces selinux.
    if not os.path.exists(b'test_file'):
        with open(b'test_file', 'w') as f:
            f.write('test')
    try:
        rc, con = matchpathcon(b'test_file', 0)
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0\n'
    finally:
        os.remove(b'test_file')

# Generated at 2022-06-11 01:51:11.738526
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ctypes import create_string_buffer

    val = 'system_u:object_r:syslogd_exec_t:s0'
    buf = create_string_buffer(val.encode('utf-8'))
    rc, con = lgetfilecon_raw(buf)
    assert con == val

# Generated at 2022-06-11 01:51:14.862287
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, result = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert isinstance(result, str)



# Generated at 2022-06-11 01:51:19.553978
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/dev/null'
    mode = 0
    [rc, con] = lgetfilecon_raw(path)
    if rc < 0:
        errno = get_errno()
        raise OSError(errno, os.strerror(errno))
    print("SELinux context for {} is {}".format(path, con))

# Generated at 2022-06-11 01:51:26.506627
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc = 0
    [rc, con] = lgetfilecon_raw("/etc/fstab")
    if rc == 0:
       print("[rc, con] = lgetfilecon_raw(\"/etc/fstab\") = [%s, %s]" % (rc, con))


# Generated at 2022-06-11 01:51:29.277005
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/var/log/audit.log', 0) == [0, b'system_u:object_r:auditlog_t:s0']

# Generated at 2022-06-11 01:51:33.580444
# Unit test for function matchpathcon
def test_matchpathcon():
    # we only want to test the python wrapper
    from ansible.module_utils.selinux import matchpathcon

    context = matchpathcon('/foo', 0)
    assert context[0] == 0
    assert context[1] == 'system_u:object_r:user_home_dir_t:s0'

# Generated at 2022-06-11 01:51:44.280193
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    python -m ansible.module_utils.common.selinux.selinux_base test_matchpathcon
    """
    import os
    import pwd
    import socket

    sock_path = os.path.join('/tmp', 'ansible-test-{0}'.format(str(os.getpid())))

    uid_str = str(pwd.getpwuid(os.geteuid()).pw_uid)
    gid_str = str(os.getgroups()[0])
    con = 'unconfined_u:{0}:{1}'.format(uid_str, gid_str)

    (rc, msg) = lsetfilecon(sock_path, con)
    if rc != 0:
        raise RuntimeError(rc, to_native(msg))


# Generated at 2022-06-11 01:51:51.895638
# Unit test for function matchpathcon
def test_matchpathcon():
    # test failure
    path = os.path.join(os.path.expanduser("~"), "selinux_test_file")
    rc, con = matchpathcon(path, 0)
    assert rc == -1
    assert con == "ERROR"

    # test success
    path = '/etc/fstab'
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con == "system_u:object_r:etc_t:s0"



# Generated at 2022-06-11 01:52:02.589817
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    import os

    def cleanup(filepath):
        try:
            os.remove(filepath)
        except OSError:
            pass

    if not is_selinux_enabled():
        print('selinux not enabled')
        return

# Generated at 2022-06-11 01:52:05.869068
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/hosts"
    (rc, con) = lgetfilecon_raw(path)
    print("context of file %s is %s" % (path, con))

# Generated at 2022-06-11 01:52:09.352920
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/resolv.conf"
    mode = 0
    con = None

    (rc, con) = matchpathcon(path, mode)

    assert rc == 0
    assert con == "system_u:object_r:resolv_conf_t:s0"


# Generated at 2022-06-11 01:52:12.054785
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/selinux/config') == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-11 01:52:14.227806
# Unit test for function matchpathcon
def test_matchpathcon():
    _path = '/tmp'
    _mode = 0o600
    _rc, _con = matchpathcon(_path, _mode)
    print(_rc, _con)



# Generated at 2022-06-11 01:52:20.545151
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/'
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(path, byref(con))

    assert rc == 0
    assert to_native(con.value) == b'root:object_r:rootfs:s0'

# Generated at 2022-06-11 01:52:22.613506
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert _selinux_lib.lgetfilecon_raw == lgetfilecon_raw


# Generated at 2022-06-11 01:52:32.050930
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        from ansible.modules.system.selinux import lgetfilecon_raw
    except ImportError:
        skip('test_lgetfilecon_raw: Unable to import lgetfilecon_raw')

    if not os.path.exists('./test'):
        os.mkdir('./test')

    fd = open('./test/testfile', 'w')
    fd.write('test text')
    fd.close()

    rc, con = lgetfilecon_raw('./test/testfile')
    assert rc == 0
    assert con == "system_u:object_r:bin_t:s0"
    os.remove('./test/testfile')

# Generated at 2022-06-11 01:52:35.487908
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/hosts', 0)
    print('{0} {1}'.format(rc, con))
    rc, con = matchpathcon('/tmp/hosts', 0)
    print('{0} {1}'.format(rc, con))



# Generated at 2022-06-11 01:52:38.202735
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc')[0] == 0
    assert lgetfilecon_raw('/etc')[1] == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-11 01:52:40.870915
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/tmp/foo", 0) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-11 01:52:44.645843
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/hosts', 0) == [0, 'system_u:object_r:etc_runtime_t:s0']
    assert matchpathcon('/var/run', 0) == [0, 'system_u:object_r:var_run_t:s0']

# Generated at 2022-06-11 01:52:49.732890
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils import basic
    rc, ctx = matchpathcon('/etc/fstab', 0)
    if rc == 0:
        basic.display_results(c='get selinux context', ctx=ctx)
    else:
        basic.display_results(c='get selinux context', rc=rc)

# Generated at 2022-06-11 01:52:55.911578
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    expected_rc, expected_con = _selinux_lib.lgetfilecon_raw('/etc/passwd', None)
    assert [expected_rc, to_native(expected_con)] == lgetfilecon_raw('/etc/passwd')
    del expected_rc, expected_con

    expected_rc, expected_con = _selinux_lib.lgetfilecon_raw('/etc/passwd', None)
    assert [expected_rc, to_native(expected_con)] == lgetfilecon_raw('/etc/passwd')
    del expected_rc, expected_con



# Generated at 2022-06-11 01:53:06.779230
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp/ansible_test_file'
    test_file = open(path, 'w')
    test_file.write('#!/bin/sh\necho Hello World\n')
    test_file.close()

    # check permissions
    path_perms = os.stat(path).st_mode & 0o777
    assert path_perms == 0o666, 'permissions mismatch: {0} != 0o666'.format(path_perms)

    # check file context
    rc, ctx = lgetfilecon_raw(path)
    assert rc == 0, 'unable to get context: {0}'.format(rc)
    assert ctx != None, 'context is None'

    # check file context is unusable due to missing security context
    os.remove(path)
    rc, ctx = l

# Generated at 2022-06-11 01:53:12.597814
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    result = lgetfilecon_raw('/')
    assert result[0] == 0
    assert result[1].startswith('system_u:object_r:')

# Generated at 2022-06-11 01:53:23.437418
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with path that exists
    res = matchpathcon('/etc/shadow', os.R_OK)
    assert res[0] == -1
    assert res[1] == 'system_u:object_r:shadow_t'

    # Test with path that doesn't exists
    res = matchpathcon('/etc/shadow/blabla', os.R_OK)
    assert res[0] == -1
    assert res[1] == 'system_u:object_r:shadow_t'

    # Test with path that doesn't exists and doesn't have a context
    res = matchpathcon('/etc/no_such_file', os.R_OK)
    assert res[0] == -1
    assert res[1].startswith('system_u:object_r:')

    # Test with invalid path
   

# Generated at 2022-06-11 01:53:29.137131
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create a test file and get its context
    test_file = '/tmp/seltest'
    with open(test_file, "w") as out_file:
        out_file.write("Testing")

    res = lgetfilecon_raw('/tmp/seltest')
    assert res[0] == 0
    assert res[1] != ""

    os.unlink(test_file)

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:53:37.805615
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Test if the lgetfilecon_raw function library call is working properly

    :return:
    """
    import tempfile
    import os

    # Create temporary file
    tmp_filename = tempfile.mktemp()
    tmp_file = open(tmp_filename, "wb")

    # Write something to the temporary file
    tmp_file.write(b"Some random text in the test file")
    tmp_file.close()

    # Get context of the file
    rc, ctx = lgetfilecon_raw(tmp_filename)

    assert rc >= 0

    # Delete temporary file
    os.remove(tmp_filename)

# Generated at 2022-06-11 01:53:46.950095
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/test_lgetfilecon_raw"
    # Create file
    f = open(path, 'w')
    f.write("test lgetfilecon_raw")
    f.close()
    # Get the context of the file
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
    if rc == 0:
        print("File %s has context %s" % (path, to_native(con.value)))
        _selinux_lib.freecon(con)
    else:
        raise OSError(os.strerror(get_errno()))

    return True

# Generated at 2022-06-11 01:53:49.036937
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp')
    print('rc=', rc)
    print('con=', con)



# Generated at 2022-06-11 01:53:53.824336
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: we should eventually test selabel_lookup instead of this deprecated thing

    res = matchpathcon('/foo', 0)
    assert len(res) == 2 and res[0] == -1, 'matchpathcon error'
    assert res[0] != 0, 'matchpathcon shouldn\'t return success'



# Generated at 2022-06-11 01:54:04.046846
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/a'
    mode = 0
    assert matchpathcon(path, mode) == [0, 'system_u:object_r:etc_t:s0\n']
    # Unit test for function selinux_getenforcemode
    assert selinux_getenforcemode() == [0, 1]
    # Unit test for function selinux_getpolicytype
    assert selinux_getpolicytype() == [0, 'targeted']
    # Unit test for function matchpathcon
    path = '/etc/b'
    mode = 0
    assert matchpathcon(path, mode) != [0, 'system_u:object_r:etc_t:s0\n']


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:54:06.504251
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw("/sys/class") == [0, 'system_u:object_r:class_device_t:s0']


# Generated at 2022-06-11 01:54:17.767362
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import random
    import string
    import shutil
    import tempfile

    # Test for a few files that should exist in most Linux distributions
    # Directory for config files for vim
    for testfile in ['/etc/vim', '/usr/share/vim']:
        if os.path.exists(testfile):
            (rc, con) = lgetfilecon_raw(testfile)
            assert rc == 0
            assert con.startswith('system_u:object_r:etc_t')

    # Directory for config files for vsftpd
    for testfile in ['/etc/vsftpd', '/usr/share/doc/vsftpd']:
        if os.path.exists(testfile):
            (rc, con) = lgetfilecon_raw(testfile)
            assert rc == 0
           

# Generated at 2022-06-11 01:54:32.492043
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # On Ubuntu 18.04, there is a bug in libselinux-utils 2.8-1ubuntu1.1
    # https://bugs.launchpad.net/ubuntu/+source/libselinux-utils/+bug/1818819
    # So, on Ubuntu 18.04 we will skip lgetfilecon_raw tests.
    import platform
    if platform.linux_distribution()[0] == 'Ubuntu' and platform.linux_distribution()[1] == '18.04':
        import pytest
        pytest.skip('Skipping lgetfilecon_raw tests on Ubuntu 18.04')

    # Set a temporary file for testing
    from tempfile import mkstemp
    from subprocess import PIPE, Popen
    from os import fdopen
    from shutil import chown
    from stat import S_IRUS

# Generated at 2022-06-11 01:54:41.433310
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    from stat import S_ISREG
    from os import stat

    path = tempfile.mkstemp()[1]
    if not S_ISREG(stat(path).st_mode):
        raise AssertionError('{0} is not a file'.format(path))
    rc, con = lgetfilecon_raw(path)
    if rc != 0:
        raise AssertionError('rc not 0, got {0}'.format(rc))
    if con == '':
        raise AssertionError('con was empty')
    print(con)



# Generated at 2022-06-11 01:54:47.742046
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create a temp file
    import tempfile
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Get the context and free
    rc, con = lgetfilecon_raw(tmpfile)
    assert rc > -1 and con is not None and len(con) > 0

    # Remove the temp file
    if os.path.exists(tmpfile):
        os.remove(tmpfile)

# Generated at 2022-06-11 01:54:56.178725
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text

    def _check(path, mode, rc, con):
        res, con_ = matchpathcon(path, mode)
        assert res == rc, 'failed on path: %s, expected: %s, got: %s' % (path, rc, res)
        assert con_ == con, 'failed on path: %s, expected: %s, got: %s' % (path, con, con_)


# Generated at 2022-06-11 01:55:00.815708
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Verify that the lgetfilecon_raw function doesn't crash"""
    import filecmp
    # pylint: disable=unused-variable
    [rc, con] = lgetfilecon_raw("/etc/passwd")


# Generated at 2022-06-11 01:55:08.108864
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    # Disable for now because it is failing on ubuntu 20.04 in automation
    if False:
        rc, con = matchpathcon('/var/log/audit/audit.log', os.R_OK)
        if rc != 0:
            raise ImportError("matchpathcon failed")

        if not con.startswith("system_u"):
            raise ImportError("con does not start with system_u: %s" % con)

        if not con.endswith("object_r:auditd_log_t:s0"):
            raise ImportError("con does not end with object_r:auditd_log_t:s0: %s" % con)


# Generated at 2022-06-11 01:55:13.222685
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    TESTDATA = b"./testfile"
    STATUS_SUCCESS = 0

    test_file = open(TESTDATA, 'a')
    test_file.close()

    try:
        [rc, con] = _selinux_lib.lgetfilecon_raw(TESTDATA, )
    except OSError as e:
        raise e

    if rc != STATUS_SUCCESS:
        os.remove(TESTDATA)
        raise ValueError

    os.remove(TESTDATA)

# Generated at 2022-06-11 01:55:17.430961
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw('/home/')
    if ret[0] == 0:
        return True
    else:
        return False

if __name__ == '__main__':
    print(test_lgetfilecon_raw())

# Generated at 2022-06-11 01:55:25.590639
# Unit test for function matchpathcon
def test_matchpathcon():
    with open('/etc/passwd') as f:
        for line in f:
            fields = line.strip().split(':')
            # magic number -1 is used to indicate that only a file type is to be matched
            # from the man page of matchpathcon
            rc, con = matchpathcon('/etc/passwd', -1)
            if rc:
                raise Exception('matchpathcon failed with rc={0}'.format(rc))
            if con != fields[3]:
                raise Exception('matchpathcon failed with con={0}'.format(con))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:55:27.888999
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, value = lgetfilecon_raw('/')
    assert rc == 0
    assert value is not None

# Generated at 2022-06-11 01:55:41.061240
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Unit test for function matchpathcon
    """
    path = 'test_path'
    mode = os.R_OK
    rc, con = matchpathcon(path, mode)
    print('matchpathcon() result: {0} {1}'.format(rc, con))

if __name__ == '__main__':
    # Unit test for function matchpathcon
    test_matchpathcon()

# Generated at 2022-06-11 01:55:43.466989
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    file_path = "/tmp/test_selinux.tmp"

    with open(file_path, "w") as file:
        file.write("testing")

    [rc, file_con] = lgetfilecon_raw(file_path)
    assert(rc == 0)

    os.remove(file_path)

# Generated at 2022-06-11 01:55:46.733779
# Unit test for function matchpathcon
def test_matchpathcon():
    import sys
    if sys.platform == 'linux':
        rc, secontext = matchpathcon('/etc/passwd', 0)
        assert rc == 0
        assert secontext == 'system_u:object_r:user_home_t:s0'

# Generated at 2022-06-11 01:55:53.290201
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test with a valid file
    assert matchpathcon('/etc/foo', 0) == [0, 'system_u:object_r:file_t:s0']

    # Test with an invalid file
    assert matchpathcon('/bin/foo', 0) == [0, 'unlabeled_t']

    # Test with an invalid mode
    assert matchpathcon('/etc/foo', 3) == [-1, None]

    # Test with an invalid path
    assert matchpathcon('/bin/foo/bar', 0) == [-1, None]

# Generated at 2022-06-11 01:55:56.988322
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:56:03.445715
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    This method tests the lgetfilecon_raw function.
    """
    output = lgetfilecon_raw('/etc/passwd')
    # output should be a tuple of length 2 that contains an integer and a string
    assert isinstance(output, tuple)
    assert len(output) == 2
    assert isinstance(output[0], int)
    assert isinstance(output[1], str)



# Generated at 2022-06-11 01:56:05.011426
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = matchpathcon("/etc/passwd", 0)
    assert(rc[0] == -1)



# Generated at 2022-06-11 01:56:10.832990
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.facts import selinux

    # /etc should always be labeled correctly, assumes not mounted with noatime
    path = b'/etc'
    mode = os.stat(path).st_mode

    rc, con = selinux.matchpathcon(path, mode)

    assert rc == 0, 'rc should be zero'
    assert con == 'etc_t', 'incorrect context, rc={0} con={1!r}'.format(rc, con)



# Generated at 2022-06-11 01:56:19.396093
# Unit test for function matchpathcon
def test_matchpathcon():
    test_environ = dict(os.environ)
    if not test_environ.get('SELINUX_CONTEXT_PATH'):
        test_environ['SELINUX_CONTEXT_PATH'] = "/etc/selinux/targeted/contexts/files/file_contexts"
    os.environ.update(test_environ)

    assert matchpathcon('/etc/selinux/config', 0)[1] == 'system_u:object_r:selinux_config_t:s0'
    assert matchpathcon('/', 0)[1] == 'system_u:object_r:root_t:s0'

# Generated at 2022-06-11 01:56:23.906323
# Unit test for function matchpathcon
def test_matchpathcon():
    dirname = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(dirname, "conftest.py")
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con.startswith("unconfined_u:object_r:test_test_t:s0")


# Generated at 2022-06-11 01:56:51.036664
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import selinux
    test_path = os.path.abspath(__file__)
    stat_buf = selinux.lstat(test_path)
    rc, con = selinux.matchpathcon(test_path, stat_buf.st_mode)
    assert rc >= 0, "matchpathcon failed"
    assert selinux.security_check_context(con) >= 0, "matchpathcon returned invalid context"
    rc, con = selinux.lgetfilecon_raw(test_path)
    assert rc >= 0, "lgetfilecon failed"
    assert selinux.security_check_context(con) >= 0, "lgetfilecon returned invalid context"
    assert rc == con



# Generated at 2022-06-11 01:56:55.419842
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Get a known path, check that the function returns 0 and returns a valid context
    rc, retval = lgetfilecon_raw(path='/')
    if rc == 0 and retval is not None:
        print("Success")
    else:
        print("Failed")


if __name__ == "__main__":
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:57:06.668972
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import shutil
    import tempfile
    import unittest

    class MatchPathConTestCase(unittest.TestCase):
        def setUp(self):
            '''This function creates a temporary file with permissions 777 and
            sets the context to system_u:object_r:lib_t:s0. Then it changes the
            permissions of the temporary file to 000 and checks the context.
            This is a test case to see if context is used to determine file
            permissions.
            '''
            self.tmpfile = tempfile.mktemp()
            shutil.copyfile(
                '/usr/bin/ls',
                self.tmpfile,
            )
            os.chmod(
                self.tmpfile,
                0o777,
            )

# Generated at 2022-06-11 01:57:10.233959
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # test_path is defined at the end of the file
    assert lgetfilecon_raw(test_path) == [0, b'system_u:object_r:boot_t:s0']


# Generated at 2022-06-11 01:57:20.615135
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        return

    test_file = "/etc/hosts"
    (rc, con) = lgetfilecon_raw(test_file)
    if rc == -1:
        raise OSError(rc, f'failed to get file context for: {test_file}')
    if con is None:
        raise OSError(rc, f'no context found for: {test_file}')
    if not con.startswith('system_u:object_r:net_conf_t'):
        raise OSError(rc, f'unexpected context: {con}')

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:57:26.274633
# Unit test for function matchpathcon
def test_matchpathcon():
    # This function is not working in selinux policy, its failing with error:
    # Operation not supported
    # Unable to find a matching path for /etc/selinux/config

    # Below code will work when matchpathcon function will be available in selinux policy
    # rc, con = matchpathcon('/etc/selinux/config', 4)
    # print(rc)
    # print(con)
    return


# Generated at 2022-06-11 01:57:28.551457
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/tmp')[1] == 'system_u:object_r:tmp_t:s0'


# Generated at 2022-06-11 01:57:35.914528
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Actual return is a tuple of return code and context string
    # We test for the return code in the selinux_test module
    # Here we will just test the return string
    try:
        con = lgetfilecon_raw('/usr/bin/id')
        if con[1] == b'unlabeled_t':
            return con
    except Exception as e:
        if e.args == 'unable to load libselinux.so':
            print("Unable to find libselinux.so.1. Skipping test_lgetfilecon_raw")
            return 3
        else:
            raise e



# Generated at 2022-06-11 01:57:42.033964
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test using stat()
    assert lgetfilecon_raw("/etc/hosts")[1] == "unconfined_u:object_r:etc_t:s0"
    assert lgetfilecon_raw("/etc/hosts")[0] == 0
    assert lgetfilecon_raw("/etc/hosts/doesnotexist")[0] == -1
    assert lgetfilecon_raw("/etc/hosts/doesnotexist")[1] == "none"

# Generated at 2022-06-11 01:57:44.565350
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    rc, output = lgetfilecon_raw('/etc/redhat-release')
    assert rc >= 0
    assert len(output) > 0
    assert isinstance(output, str)

# Generated at 2022-06-11 01:58:39.311416
# Unit test for function matchpathcon
def test_matchpathcon():
    for pair in (
            (b'/tmp/foo', [0, 'system_u:object_r:tmp_t:s0']),
            (b'/usr/bin/ls', [0, 'system_u:system_r:bin_t:s0']),
            (b'/dev/zero', [0, 'system_u:object_r:zero_device_t:s0']),
            (b'/dev/zero/bar', [-1, None]),  # file does not exist
    ):
        path, expected = pair
        actual = matchpathcon(path, 0)
        assert actual == expected, '{0} -> {1} != {2}'.format(path, actual, expected)



# Generated at 2022-06-11 01:58:41.351923
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/shadow') == [0, 'system_u:object_r:shadow_t:s0']


# Generated at 2022-06-11 01:58:52.276017
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # In case that the function lgetfilecon_raw is not available
    # the test should finish without error
    if not hasattr(sys.modules[__name__], 'lgetfilecon_raw'):
        return

    try:
        rc, con = lgetfilecon_raw('/bin/ls')
    except Exception:
        return

    # Check if the return code has a valid value
    # In case of failure the return code will be -1
    assert rc >= 0, 'The function lgetfilecon_raw() failed'
    # Check if the return value con is empty (when SELinux is not enabled)
    # or has a valid SELinux context

# Generated at 2022-06-11 01:59:00.676711
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with file that should have label
    [rc, con] = lgetfilecon_raw("/")
    if rc != 0:
        raise Exception("Failed to getcon for /")
    if not con:
        raise Exception("Got null context for /")
    # Test with file that should have default label
    [rc, con] = lgetfilecon_raw("/file_not_created")
    if rc != -1:
        raise Exception("Not getting -1 for getcon of /file_not_created")
    if not con:
        raise Exception("Got null context for /file_not_created")



# Generated at 2022-06-11 01:59:03.589743
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/bin/ls', 0)
    assert rc == 0
    assert con == 'system_u:object_r:bin_t:s0'



# Generated at 2022-06-11 01:59:07.825067
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/etc/foo"
    mode = 0
    result = matchpathcon(path, mode)
    assert type(result) is list
    assert len(result) == 2
    assert result[0] == 0  # rc
    assert type(result[1]) is str

# Generated at 2022-06-11 01:59:09.961475
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/')
    assert rc == 0
    assert con[0] == 'u'

# Generated at 2022-06-11 01:59:18.197697
# Unit test for function matchpathcon
def test_matchpathcon():
    # path must exist
    try:
        matchpathcon("DOESNOTEXIST", 0)
        assert False, "matchpathcon call should throw exception"
    except OSError:
        pass

    # path must be absolute
    try:
        matchpathcon("/tmp", 0)
        assert False, "matchpathcon call should throw exception"
    except OSError as e:
        assert e.errno == 22 and e.strerror == "Invalid argument"

    # path must be a string
    try:
        matchpathcon(None, 0)
        assert False, "matchpathcon call should throw exception"
    except TypeError:
        pass

    # mode must be int

# Generated at 2022-06-11 01:59:22.354305
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/hosts"
    rc, context = lgetfilecon_raw(path)
    # On success, rc == 0
    assert(rc == 0)

    # An SELinux context should be returned
    assert(context is not None)
    assert(context != '')



# Generated at 2022-06-11 01:59:22.970456
# Unit test for function matchpathcon
def test_matchpathcon():
    pass

