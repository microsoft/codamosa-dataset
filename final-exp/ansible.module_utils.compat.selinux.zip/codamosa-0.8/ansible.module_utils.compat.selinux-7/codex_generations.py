

# Generated at 2022-06-11 01:50:43.125529
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        return  # Matchpathcon isn't available without selinux enabled.
    (rc, con) = matchpathcon('/', 0)
    print(con)
    assert rc == 0
    (rc, con) = matchpathcon('/', os.F_OK)
    assert rc == 0
    (rc, con) = matchpathcon('/', os.R_OK)
    assert rc == 0

# Generated at 2022-06-11 01:50:54.672192
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    def assert_rc(rc, expected):
        assert rc == expected, "Got {}, expected {}".format(rc, expected)

    def assert_con(con, expected):
        assert con == expected, "Got {}, expected {}".format(con, expected)

    def assert_lgetfilecon_raw(path, expected_rc=0, expected_con=None):
        rc, con = lgetfilecon_raw(path)
        assert_rc(rc, expected_rc)
        assert_con(con, expected_con)

    # Test the root dir (e.g., '/')

# Generated at 2022-06-11 01:50:57.117619
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/usr/sbin/ntpd')
    expected_con = 'system_u:object_r:system_cronjob_t:s0'
    assert rc == 0
    assert con == expected_con

# Generated at 2022-06-11 01:51:01.572970
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    path = '/etc/selinux/config'
    ret, val = lgetfilecon_raw(path)
    if ret:
        raise Exception('lgetfilecon_raw failed')
    print(val)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:51:07.654143
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if selinux_getenforcemode()[0] != 0:
        raise RuntimeError("selinux enforcing mode not enabled. can not run test")

    context = lgetfilecon_raw("/etc/hosts")[1]
    if len(context) == 0:
        raise RuntimeError("context not found for /etc/hosts")
    print("context is: " + context)



# Generated at 2022-06-11 01:51:18.676094
# Unit test for function matchpathcon
def test_matchpathcon():
    # This tests the python wrapper around libselinux's matchpathcon() only,
    # NOT the selinux module code that consumes this wrapper!
    #
    # The Python wrapper basically just converts a Python string arg to a C
    # string arg, calls the C function, and converts and returns the result.

    path = '/etc/passwd'
    mode = os.F_OK

    # Test Python str arg
    result = matchpathcon(path, mode)
    assert result[0] == 0
    assert len(result[1]) > 0

    # Test Python bytes arg
    path_bytes = path.encode('utf-8')
    result = matchpathcon(path_bytes, mode)
    assert result[0] == 0
    assert len(result[1]) > 0

# Generated at 2022-06-11 01:51:27.117678
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    sys.stdout.write("lgetfilecon_raw: ")
    try:
        ret = lgetfilecon_raw("/")
        if ret[0] == 0:
            sys.stdout.write("success\n")
        else:
            sys.stdout.write("failure %d\n" % ret[0])
    except OSError as e:
        sys.stdout.write("OSError %d\n" % e.errno)



# Generated at 2022-06-11 01:51:31.204651
# Unit test for function matchpathcon
def test_matchpathcon():
    rc = _selinux_lib.matchpathcon(b'/dev/null', 0, None)
    assert rc in (0, -1), 'matchpathcon(b"/dev/null", 0, None) failed: rc: {0}'.format(rc)



# Generated at 2022-06-11 01:51:34.079106
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Select a file that definitely exists on all distros, and is unlikely to be
    # relabeled.
    (rc, con) = lgetfilecon_raw('/usr/bin/python3')
    assert rc == 0
    assert con == 'unconfined_u:object_r:user_home_t:s0'

# Generated at 2022-06-11 01:51:37.874401
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not is_selinux_enabled():
        # We cannot test if SELinux is disabled
        return

    rc, value = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert len(value) > 0

# Generated at 2022-06-11 01:51:43.028013
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, val = matchpathcon('/home/test_user/test.txt', 0)
    assert rc == 0
    assert val == 'system_u:object_r:user_home_t:s0'

# Generated at 2022-06-11 01:51:46.469413
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    path = tempfile.mkdtemp()
    try:
        (rc, con) = _selinux_lib.matchpathcon(path, 0)
        assert rc == 0
        assert isinstance(con, str)
    finally:
        os.rmdir(path)



# Generated at 2022-06-11 01:51:49.029637
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(path="/test1") == [0, ""], "lgetfilecon_raw does not work as expected"


# Generated at 2022-06-11 01:51:53.235246
# Unit test for function matchpathcon
def test_matchpathcon():
    filename = 'matchpathcon_example'
    try:
        os.mknod(filename)
        rc, con = matchpathcon(filename, 0)
        print('rc={0}'.format(rc))
        print('con={0}'.format(con))
    finally:
        os.remove(filename)


# Generated at 2022-06-11 01:52:03.832301
# Unit test for function matchpathcon
def test_matchpathcon():
    # Make sure we have a policy loaded
    if not is_selinux_enabled():
        # this test function is only valid when selinux is enabled
        return

    # The selinux module_utils require some configuration to run
    # this unit test successfully. The following section is part of
    # that configuration.
    #
    # The test needs a file where selinux can determine its context.
    # The only file that is guaranteed to be present is '/', so it
    # is used.

    rc, selinux_policy = selinux_getpolicytype()
    assert rc == 0
    assert selinux_policy == 'targeted'
    rc, enforce = selinux_getenforcemode()
    assert rc == 0
    assert enforce == 1

    # Now we can run the actual unit test itself.


# Generated at 2022-06-11 01:52:09.258031
# Unit test for function matchpathcon
def test_matchpathcon():
    # selinux_context = matchpathcon()
    # assert selinux_context[0] == 0
    # assert selinux_context[1] == 'system_u:object_r:usr_t:s0'
    # assert type(selinux_context[1]) is str
    pass



# Generated at 2022-06-11 01:52:15.018539
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if not os.path.exists('/etc/selinux/config'):
        raise RuntimeError('cannot run test, selinux not enabled')

    rc, con = lgetfilecon_raw('/etc/selinux/config')
    if rc:
        raise OSError(rc)
    elif not con:
        raise RuntimeError('con is empty')
    else:
        return rc, con



# Generated at 2022-06-11 01:52:18.057988
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/sbin/ping"
    rc, result = lgetfilecon_raw(path)
    assert result == "system_u:object_r:ping_exec_t:s0"


# Generated at 2022-06-11 01:52:25.871461
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    context = lgetfilecon_raw('/etc/selinux/config')[1]
    assert context is not None
    assert context.startswith('system_u:object_r:etc_t:s0')
    assert lgetfilecon_raw('/etc/selinux/config') is not None
    assert lgetfilecon_raw('/etc/selinux/config')[0] == 5
    assert lgetfilecon_raw('/etc/selinux/config')[1] == b''



# Generated at 2022-06-11 01:52:30.138241
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con_value = matchpathcon('/var/www', os.R_OK)
    except OSError as e:
        print(to_native(e))
        sys.exit(1)
    print('rc:', rc, 'con:', con_value)


# Generated at 2022-06-11 01:52:36.841809
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp/fred')
    print('rc: {0}'.format(rc))
    print('con: {0}'.format(con))


# Generated at 2022-06-11 01:52:44.508753
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    tmp_file = open('/tmp/test_file.txt', 'w+')
    tmp_file.write('hello world')
    tmp_file.close()
    try:
        rc, con = lgetfilecon_raw(b'/tmp/test_file.txt')
        assert rc == 0
        assert con == 'system_u:object_r:user_tmp_t:s0'
    except OSError as e:
        print('OSError: {0}'.format(to_native(e)))
        assert False
    finally:
        os.remove('/tmp/test_file.txt')

# Generated at 2022-06-11 01:52:51.134436
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = b'/etc/passwd'
    try:
        # Test that lgetfilecon_raw returns a zero and a valid context string
        rc,con = lgetfilecon_raw(test_path)
        assert rc == 0
        assert con.__class__ == str
        assert con.__len__() > 0
    except OSError:
        pass

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:53:01.318049
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.pytest_runner import PyTestRunner


# Generated at 2022-06-11 01:53:07.828654
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import shutil

    try:
        # create test directory
        tmpdir_name = tempfile.mkdtemp()

        # get context for test directory
        try:
            rc, con = matchpathcon(tmpdir_name, 0)
            assert rc >= 0, 'matchpathcon returned error code: {0}'.format(rc)

            print(to_native(con))
        finally:
            shutil.rmtree(tmpdir_name)
    except ImportError:
        raise ImportError('libselinux is not available')

# Generated at 2022-06-11 01:53:17.050637
# Unit test for function matchpathcon
def test_matchpathcon():
    # path = '/etc/passwd'
    # mode = os.R_OK
    # res = matchpathcon(path, mode)
    # print(res)
    """
    [0, 'system_u:object_r:etc_t:s0']
    """
    path = '/usr/bin'
    mode = os.R_OK
    res = matchpathcon(path, mode)
    print(res)
    """
    [0, 'system_u:object_r:bin_t:s0']
    """
    path = '/usr/bin/'
    mode = os.R_OK
    res = matchpathcon(path, mode)
    print(res)
    """
    [0, 'system_u:object_r:bin_t:s0']
    """

# Generated at 2022-06-11 01:53:24.253770
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    ensures function lgetfilecon_raw() returns the correct SELinux file context
    """

    result = lgetfilecon_raw(b"/path/to/test/file")

    assert result[0] != -1, "test_lgetfilecon_raw() failed with unexpected error"
    assert result[1] == "system_u:object_r:usr_t:s0", "test_lgetfilecon_raw() returned unexpected context"



# Generated at 2022-06-11 01:53:27.555837
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as tf:
        rc, con = lgetfilecon_raw(tf.name)
        assert rc == 0
        assert con



# Generated at 2022-06-11 01:53:32.102080
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/tmp/test', 0))
    # print(matchpathcon('/usr/bin/tar', 1))
    print(matchpathcon('/tmp/test/', 0))
    print(matchpathcon('/tmp/test/', 1))



# Generated at 2022-06-11 01:53:38.129953
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, context = lgetfilecon_raw('/etc/passwd')
    if rc == -1:
        raise Exception('Unable to get SELinux context')

    print('File SELinux context:', context)

    rc, context = lgetfilecon_raw('/root/file')
    if rc == -1:
        raise Exception('Unable to get SELinux context')

    print('File SELinux context:', context)



# Generated at 2022-06-11 01:53:47.855726
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/tmp', 0)
    print("Matchpathcon rc:", rc, "\tcon:", con)

# Generated at 2022-06-11 01:53:56.990870
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw(None)
        assert False, "%s: unexpected success rc=%d con=%r" % (sys._getframe().f_code.co_name, rc, con)
    except OSError as e:
        if e.errno != 22:
            raise
    try:
        rc, con = lgetfilecon_raw('/')
        assert rc == 0, "%s: unexpected failure rc=%d con=%r" % (sys._getframe().f_code.co_name, rc, con)
    except OSError as e:
        raise
    return True


# Generated at 2022-06-11 01:53:58.960697
# Unit test for function matchpathcon
def test_matchpathcon():
    return matchpathcon('/var/www', os.R_OK|os.X_OK)


# Generated at 2022-06-11 01:54:04.046408
# Unit test for function matchpathcon
def test_matchpathcon():
    dev_null = '/dev/null'
    if os.path.exists(dev_null):
        (rc, con) = matchpathcon(dev_null, 0)
        print('Context of {0} is {1}'.format(dev_null, con))
        assert rc == 0
    else:
        print('File {0} does not exist'.format(dev_null))


# Generated at 2022-06-11 01:54:08.449613
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import stat
    from tempfile import mkdtemp
    from shutil import rmtree

    tmpdir = mkdtemp()
    con = matchpathcon(tmpdir, stat.S_IFDIR)[1]
    assert con == 'system_u:object_r:tmp_t:s0'
    print(tmpdir)
    rmtree(tmpdir)

# Generated at 2022-06-11 01:54:13.726876
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/etc/hosts')
    assert result[0] == 0
    assert type(result[1]) == str
    assert result[1].split(' ')[0] == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-11 01:54:21.963151
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 0: return success if paths are labeled properly
    path1 = b'/tmp/matchpathcon_test/file1'
    path2 = b'/tmp/matchpathcon_test/file2'
    path3 = b'/tmp/matchpathcon_test/symlink'
    os.makedirs('/tmp/matchpathcon_test')
    open(path1, 'a').close()
    rc, con = lgetfilecon_raw(path1)
    assert rc == 0
    os.symlink('file1', path3)
    fd = os.open(path2, os.O_CREAT | os.O_EXCL)
    rc = _selinux_lib.fsetfilecon(fd, con)
    assert rc == 0
    rc = _selinux_lib.lsetfilecon

# Generated at 2022-06-11 01:54:27.783812
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/tmp/matchpathcon.py'
    with open(path, 'w') as f:
        print('', file=f)
    rc, con = matchpathcon(path, os.R_OK)
    os.remove(path)
    print(rc, con)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-11 01:54:38.893980
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        raise Exception("SELinux not enabled")

    SELINUX_MODE_ENFORCING = 1
    SELINUX_MODE_PERMISSIVE = 0
    SELINUX_MODE_DISABLED = -1

    def check_matchpathcon(path, mode):
        if mode == SELINUX_MODE_DISABLED:
            if not (matchpathcon(path, mode)[0] == -1 and get_errno() == 1):
                raise Exception("matchpathcon failed for SELinux_MODE_DISABLED")
        else:
            if matchpathcon(path, mode)[0] < 0:
                raise Exception("matchpathcon failed for path {} \
                                 in SELinux mode {}".format(path, mode))

    # files

# Generated at 2022-06-11 01:54:47.197973
# Unit test for function matchpathcon
def test_matchpathcon():
    from tempfile import mkstemp
    from shutil import rmtree
    from os.path import join as pjoin

    from ansible.module_utils.selinux import matchpathcon

    tmpdir = '/tmp/ansible-test-selinux-matchpathcon'

    rc, con = matchpathcon(tmpdir, 0)
    if rc == -1:
        # Ignore if /tmp is not preserving context.
        return


# Generated at 2022-06-11 01:55:06.559122
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/usr/local/sbin/xorphan', os.R_OK)
    if rc < 0:
        if rc == -1:
            raise OSError(errno, os.strerror(errno))
        else:
            raise OSError(rc, os.strerror(-rc))
    print(con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:55:11.560920
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Use /usr/sbin/useradd as an example because it should always exist in the path
    # And should have a context that is a human readable string.
    (rc, con) = lgetfilecon_raw('/usr/sbin/useradd')
    assert rc == 0
    assert con is not None
    assert 'system_u:object_r:usr_t:s0' in con



# Generated at 2022-06-11 01:55:14.430293
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin')[1] is not None
    assert lgetfilecon_raw('/')[1] is not None

# Generated at 2022-06-11 01:55:25.295209
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = lgetfilecon_raw(__file__)

    print(con)

    if is_selinux_enabled() != 1:
        raise Exception("selinux is not enable")

    if security_getenforce() != 1:
        raise Exception("selinux is not enable")

    if is_selinux_mls_enabled() != 1:
        raise Exception("selinux mls is not enable")

    if security_policyvers() != 0:
        raise Exception("Could not get policy version")

    # if selinux_getpolicytype()!=4:
    #    raise Exception("Could not get policy type")

    if selinux_getenforcemode()[1] != 1:
        raise Exception("getenforcemode = 1")


# Generated at 2022-06-11 01:55:35.204942
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing matchpathcon")
    # invalid mode
    rc, con = matchpathcon("/etc/shadow", 0)
    print("Testing invalid mode - rc={0} con={1}".format(rc, con))
    # bad file
    rc, con = matchpathcon("/file/does/not/exist", 1)
    print("Testing bad file - rc={0} con={1}".format(rc, con))
    # regular file
    rc, con = matchpathcon("/etc/selinux/semanage.conf", 1)
    print("Testing regular file - rc={0} con={1}".format(rc, con))
    # directory
    rc, con = matchpathcon("/etc/selinux", 1)

# Generated at 2022-06-11 01:55:39.408468
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/root'
    mode = 0
    try:
        rc, context = matchpathcon(path, mode)
    except OSError as e:
        rc = e.errno
        context = None

    assert rc == 0
    assert context == 'system_u:object_r:root_t:s0'

# Generated at 2022-06-11 01:55:44.239522
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/tmp'
    mode = 0
    [rc, role] = selinux_getpolicytype()
    if rc != 0:
        con = 'test_t'
    else:
        [rc, con] = matchpathcon(path, mode)
        if rc == -1:
            con = ''
    print(con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:55:47.067520
# Unit test for function matchpathcon
def test_matchpathcon():
    ret = matchpathcon('/home/test_user/test_file', 1)
    assert ret[0] == 0
    assert ret[1] == 'test_file_context_t'



# Generated at 2022-06-11 01:55:52.981126
# Unit test for function matchpathcon
def test_matchpathcon():
    err_none, rc_none = matchpathcon("/usr/bin/date", 0)
    assert err_none == 0
    assert rc_none == "unconfined_u:object_r:user_home_t:s0"
    err_mode, rc_mode = matchpathcon("/usr/bin/date", 1)
    assert err_mode == 0
    assert rc_mode == "unconfined_u:object_r:user_home_exec_t:s0"

# Generated at 2022-06-11 01:56:04.550702
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing matchpathcon()")
    print("Testing matchpathcon for '/var/log':", matchpathcon('/var/log', 0o400))
    print("Testing matchpathcon for '/var/log/messages':", matchpathcon('/var/log/messages', 0o600))
    print("Testing matchpathcon for '/var/log/messages1':", matchpathcon('/var/log/messages1', 0o600))
    print("Testing matchpathcon for '/var/lib':", matchpathcon('/var/lib', 0o600))
    print("Testing matchpathcon for '/var/lib/foo':", matchpathcon('/var/lib/foo', 0o600))
    print("Testing matchpathcon for '/tmp':", matchpathcon('/tmp', 0o600))

# Generated at 2022-06-11 01:56:36.654736
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-11 01:56:40.915418
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/'
    con = c_char_p()
    (rc, str) = lgetfilecon_raw(path)
    assert rc == 0
    assert isinstance(str, str)
    assert str == 'system_u:object_r:tmp_t:s0'
    assert str[0] == 's'

# Generated at 2022-06-11 01:56:46.631963
# Unit test for function matchpathcon
def test_matchpathcon():
    _selinux_lib.matchpathcon = lambda path, mode, con: 0
    res = matchpathcon("path", 1)
    assert res[0] == 0

    _selinux_lib.matchpathcon = lambda path, mode, con: -1
    res = matchpathcon("path", 1)
    assert res[0] == -1



# Generated at 2022-06-11 01:56:55.410864
# Unit test for function matchpathcon
def test_matchpathcon():
    # A few basic cases
    assert matchpathcon('/', os.R_OK)[1] == 'system_u:object_r:root_t'
    assert matchpathcon('/dev', os.R_OK)[1] == 'system_u:object_r:device_t'
    assert matchpathcon('/dev/null', os.R_OK)[1] == 'system_u:object_r:chr_file_t'

    # Make sure we can use an invalid mode
    assert matchpathcon('/dev/null', -1)[1] == 'system_u:object_r:chr_file_t'

    # Make sure we check for a string path
    assert matchpathcon(None, os.R_OK)[0] == -22


if __name__ == "__main__":
    import pytest

# Generated at 2022-06-11 01:56:58.278111
# Unit test for function matchpathcon
def test_matchpathcon():
    result = matchpathcon("/etc/passwd", 0)
    assert type(result[0]) == int
    assert type(result[1]) == str


# Generated at 2022-06-11 01:57:00.570978
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/python')[1] == 'unconfined_u:object_r:usr_t:s0'

# Generated at 2022-06-11 01:57:04.357945
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = '/var/log'
    test_output = lgetfilecon_raw(test_path)
    assert test_output == [0, 'system_u:object_r:var_log_t:s0']


# Generated at 2022-06-11 01:57:12.986458
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test case 1: call lgetfilecon_raw on /usr/bin.
    print("Testing: lgetfilecon_raw on file /usr/bin")
    rc_actual, context_actual = lgetfilecon_raw('/usr/bin')
    assert rc_actual == 0
    assert 'unconfined_u:object_r:bin_t:s0' == context_actual

    # Test case 2: call lgetfilecon_raw on a file that does not exists.
    print("Testing: lgetfilecon_raw on a file that does not exists.")
    rc_actual, context_actual = lgetfilecon_raw('/tmp/doesnotexists')
    assert rc_actual == -1



# Generated at 2022-06-11 01:57:16.907282
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/etc')
    assert rc == 0 and con == 'system_u:object_r:etc_t:s0'
# end unit test


# Generated at 2022-06-11 01:57:20.312792
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/var/log/audit/audit.log'
    rc, con = lgetfilecon_raw(path)
    print(rc)
    print(con)


# Generated at 2022-06-11 01:58:36.829524
# Unit test for function matchpathcon
def test_matchpathcon():
    ret, con = matchpathcon('/bin/touch', 0)
    print(ret, con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:58:40.125567
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/some/nonexistent/path"
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(path, 0, byref(con))
    print(rc, con.value)
    assert rc != 0
    print(_selinux_lib.freecon(con))
    assert rc != 0

# Generated at 2022-06-11 01:58:51.329778
# Unit test for function matchpathcon
def test_matchpathcon():
    from unittest import TestCase

    class TestMatchpathcon(TestCase):
        def test_matchpathcon(self):
            from os import path
            from os import mkdir
            from tempfile import gettempdir
            from shutil import rmtree

            # Create test directory and file
            testdir = path.join(gettempdir(), 'ansible-test-selinux')
            testfile = path.join(testdir, 'test-file')
            if path.isdir(testdir):
                rmtree(testdir)
            mkdir(testdir, 0o755)
            with open(testfile, 'w'):
                pass

            # Get test directory context
            rc_dir, context_dir = matchpathcon(testdir, 0)
            self.assertEqual(rc_dir, 0)

            #

# Generated at 2022-06-11 01:59:00.173936
# Unit test for function matchpathcon
def test_matchpathcon():
    # Return value of rc is 0 and con is 'system_u:object_r:boot_t:s0'
    [rc, con] = matchpathcon('/boot', 0)
    assert rc == 0
    assert con == 'system_u:object_r:boot_t:s0'

    # Return value of rc is 0 and con is 'system_u:object_r:sysfs_t:s0'
    [rc, con] = matchpathcon('/sys', 0)
    assert rc == 0
    assert con == 'system_u:object_r:sysfs_t:s0'


# Generated at 2022-06-11 01:59:10.407242
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import datetime
    test_path = "/tmp/ansible_test_filecon"
    file_owner = os.getuid()
    file_group = os.getgid()
    if os.path.exists(test_path):
        print("File exists, attempting to remove to start fresh.")
        os.remove(test_path)
    with open(test_path, 'a') as testfile:
        testfile.write(datetime.datetime.now().strftime("%H:%M:%S%f"))
    assert os.path.exists(test_path), "Failed to create test file. Check permissions"
    file_stats = os.stat(test_path)

# Generated at 2022-06-11 01:59:16.368090
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile
    from ansible.module_utils.selinux import matchpathcon

    if not os.path.exists('/usr/bin/matchpathcon'):
        raise RuntimeError("no matchpathcon tool available on this system")

    # Test a selinuxfs tmpfs mount point
    tmpfs = tempfile.mkdtemp()
    assert matchpathcon(tmpfs, 0) == [0, 'tmpfs default']
    return True

# Generated at 2022-06-11 01:59:27.069327
# Unit test for function matchpathcon
def test_matchpathcon():
    mode = 0  # flags are available from the selinux.h file
    path = "/tmp"
    msg = matchpathcon(path, mode)
    assert(msg[0] == 0), msg[0]
    assert(msg[1].split(":")[0] == "system_u")
    assert(msg[1].split(":")[1] == "object_r")
    assert(msg[1].split(":")[2] == "tmp_t")
    mode = 1
    path = "/usr/bin/python"
    msg = matchpathcon(path, mode)
    assert(msg[0] == 0), msg[0]
    assert(msg[1].split(":")[0] == "system_u")
    assert(msg[1].split(":")[1] == "object_r")

# Generated at 2022-06-11 01:59:29.390566
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/passwd', os.R_OK)
    assert rc == 0
    assert isinstance(con, str)
    assert len(con) > 0

# Generated at 2022-06-11 01:59:37.579813
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = "/usr/bin/id"
    if not os.path.isfile(test_file):
        raise Exception("File not found.")

    if not is_selinux_enabled():
        raise Exception("SELinux must be enabled to run this test.")

    test_con = lgetfilecon_raw(test_file)
    if test_con[0] != 0:
        raise Exception("lgetfilecon_raw failed: " + str(rc) + " errno: " + str(errno))
    if "system_u:object_r:bin_t:s0" not in test_con[1]:
        raise Exception("lgetfilecon_raw did not return expected context string.")



# Generated at 2022-06-11 01:59:44.483153
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test with a file that exists
    r = lgetfilecon_raw(b'/etc/passwd')
    assert r[0] == 0, 'lgetfilecon_raw should return 0 if successful'
    assert r[1] == 'system_u:object_r:passwd_file_t:s0', "lgetfilecon_raw should return the correct context"
    # Test with a file that doesn't exist
    r = lgetfilecon_raw(b'/tmp/dummytest')
    assert r[0] == -1, 'lgetfilecon_raw should return -1 if unsuccessful'
