

# Generated at 2022-06-11 01:50:39.347246
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print(lgetfilecon_raw('/etc/passwd'))
    print(lgetfilecon_raw('/etc/passwd_missing'))


# Generated at 2022-06-11 01:50:44.060842
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if is_selinux_enabled():
        path = '/etc/selinux/config'
        if os.path.isfile(path):
            rc, security_context = lgetfilecon_raw(path)
            assert rc == 0
            assert security_context

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:50:56.125796
# Unit test for function matchpathcon
def test_matchpathcon():
    import stat

    files = (
        # (path, mode, expected_rc, expected_con)
        (b'/', stat.S_IFDIR, 0, 'system_u:object_r:rootfs:s0'),
        (b'/selinux_python', stat.S_IFREG, 0, 'user_u:object_r:user_home_t:s0'),
    )

    for path, mode, expected_rc, expected_con in files:
        (rc, con) = matchpathcon(path, mode)
        if expected_rc != rc or expected_con != con:
            raise RuntimeError("Unexpected result from matchpathcon({0}, {1}): {2} != {3} or {4} != {5}".format(path, mode, expected_rc, expected_con, rc, con))

# Generated at 2022-06-11 01:51:00.409691
# Unit test for function matchpathcon
def test_matchpathcon():
    r = matchpathcon("/", 0)
    assert r[0] == 0
    assert len(r[1]) > 0

    r = matchpathcon("/", 0xFFFF)  # Invalid mode
    assert r[0] == -1


# Generated at 2022-06-11 01:51:01.745239
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # The function is tested in unit tests in selinux_permissive module
    pass

# Generated at 2022-06-11 01:51:13.734346
# Unit test for function matchpathcon
def test_matchpathcon():
    # Try a valid file in a valid directory
    rc, con = matchpathcon("/var/log/journal/", os.R_OK)
    print(rc, con)
    assert(rc == 0)
    assert(con == "system_u:object_r:var_log_t:s0")

    # Try a file that doesn't exist
    rc, con = matchpathcon("/var/log/journal/does_not_exist", os.R_OK)
    print(rc, con)
    assert(rc == 0)
    assert(con == "system_u:object_r:var_log_t:s0")

    # Try a directory that doesn't exist
    rc, con = matchpathcon("/blah/blah/blah/", os.R_OK)
    print(rc, con)


# Generated at 2022-06-11 01:51:20.529517
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, con = lgetfilecon_raw('.')
        assert rc == 0
        assert len(con) > 0
    except OSError as e:
        # NB: Not all Linux distros are compiled with SELinux.
        # e.g. https://wiki.ubuntu.com/SELinux
        # It's fine if it's not implemented.
        if e.errno == os.errno.ENOSYS:
            print('SKIP: lgetfilecon_raw is not implemented.')
            return
        else:
            raise



# Generated at 2022-06-11 01:51:28.709659
# Unit test for function matchpathcon
def test_matchpathcon():
    """ Mimic the selinux module and assert the return code """

    # Basic test
    assert matchpathcon('/etc/passwd', 0)[0] == 0

    # Path that should fail
    assert matchpathcon('/etc/doesnotexist', 0)[0] == -1

    # Path with missing file
    assert matchpathcon('/proc/uptime', 0)[0] == -1

    # Path for which we can't read the SELinux context
    assert matchpathcon('/selinux/load', 0)[0] == -1

# Generated at 2022-06-11 01:51:37.168984
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/id')[0] == 0
    assert lgetfilecon_raw('/usr/bin/id')[1] == 'unconfined_u:object_r:usr_t:s0'
    assert lgetfilecon_raw('/usr/bin/id')[0] == 0
    assert lgetfilecon_raw('/usr/bin/id')[1] == 'unconfined_u:object_r:usr_t:s0'
    assert lgetfilecon_raw('/usr/bin/id')[0] == 0
    assert lgetfilecon_raw('/usr/bin/id')[1] == 'unconfined_u:object_r:usr_t:s0'
    assert lgetfilecon_raw('/usr/bin/id')

# Generated at 2022-06-11 01:51:45.053468
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/path/to/file'
    (rc, context) = matchpathcon(path, 0)
    assert rc == 0
    if hasattr(context, 'startswith'):
        assert context.startswith('u:object_r:')
    else:
        assert False, 'matchpathcon returned unexpected result'
    (rc, context) = matchpathcon(path, 2)
    assert rc == 0
    if hasattr(context, 'startswith'):
        assert context.startswith('u:object_r:')
    else:
        assert False, 'matchpathcon returned unexpected result'

# Generated at 2022-06-11 01:51:52.202865
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    lib_path = '/lib/libc.so.6'
    libc_con = lgetfilecon_raw(lib_path)[1]
    if libc_con != 'system_u:object_r:lib_t:s0':
        raise OSError('libc context is not correct')



# Generated at 2022-06-11 01:51:56.590846
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print("Running unit test: lgetfilecon_raw")
    test_results = lgetfilecon_raw(b"/etc/shadow")
    print("Test result is: ")
    print(str(test_results))


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:52:02.745766
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Check using /etc/selinux/config file
    rc, con = lgetfilecon_raw('/etc/selinux/config')
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'
    # Invalid file path
    rc, con = lgetfilecon_raw('/testpath')
    assert rc == -1
    assert con is None


# Generated at 2022-06-11 01:52:06.482512
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc'
    mode = 0
    rc, con = matchpathcon(path, mode)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-11 01:52:09.555280
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/') == [0, 'system_u:object_r:file_t:s0']


# Generated at 2022-06-11 01:52:17.650459
# Unit test for function matchpathcon
def test_matchpathcon():
    if not is_selinux_enabled():
        raise ImportError('selinux not enabled')

    if not is_selinux_mls_enabled():
        raise ImportError('selinux mls not enabled')

    # pylint: disable=undefined-loop-variable
    for path in ['/etc/passwd',
                 '/home/nobody',
                 '/etc/shadow']:
        rc, con = matchpathcon(path, 0)
        if rc != 0:
            # This is most likely a bug in the selinux libs, not a test failure
            raise Exception("matchpathcon rc != 0: {0}:{1}".format(rc, con))

        rc, con2 = lgetfilecon_raw(path)

# Generated at 2022-06-11 01:52:27.216766
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    default_context = 'system_u:object_r:usr_t:s0'

    # Test insecure mode
    result = matchpathcon('/usr/bin/wc', os.R_OK)
    if result[1] != default_context:
        raise RuntimeError('Insecure mode test failed. matchpathcon returned: {0}'.format(result[1]))

    # Test secure mode
    result = matchpathcon('/usr/bin/wc', os.R_OK | os.X_OK)
    if result[1] != default_context:
        raise RuntimeError('Secure mode test failed. matchpathcon returned: {0}'.format(result[1]))

# Generated at 2022-06-11 01:52:28.980986
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/localtime'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:time_conf_t:s0'

# Generated at 2022-06-11 01:52:31.016525
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/', 1) == [0, 'system_u:object_r:file_t:s0']



# Generated at 2022-06-11 01:52:35.207380
# Unit test for function matchpathcon
def test_matchpathcon():
    pathname = b"/home/foo"
    mode = 0
    expected_return_code = 0
    expected_context = b"system_u:object_r:user_home_t:s0"

    return_code, context = matchpathcon(pathname, mode)
    assert return_code == expected_return_code
    assert context == expected_context


# Generated at 2022-06-11 01:52:44.779432
# Unit test for function matchpathcon
def test_matchpathcon():
    test = matchpathcon('/etc/shadow', os.R_OK)
    assert test[0] == 0
    assert test[1] == 'system_u:object_r:shadow_t:s0'
    test = matchpathcon('/etc/shadow', os.W_OK)
    assert test[0] == 0
    assert test[1] == 'system_u:object_r:shadow_t:s0'


# Generated at 2022-06-11 01:52:52.462562
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/foo/bar'
    mode = os.stat(path).st_mode

    # If you don't have selinux enabled, it returns -1 as the code, 0 as the string and -1 as the errno value
    # which is the same default value returned by get_errno()
    [rc, con] = matchpathcon(path, mode)

    assert rc == -1
    assert con == ''

    assert type(os.strerror(get_errno())) is str
    assert os.strerror(get_errno()) == 'Permission denied'

# Generated at 2022-06-11 01:52:56.317200
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/usr/bin/cat', 0)[1] == 'system_u:object_r:bin_t:s0'
    assert matchpathcon('/dev/null', 0)[1] == 'system_u:object_r:null_device_t:s0'

# Generated at 2022-06-11 01:53:03.773227
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.dirname(os.path.abspath(__file__))
    rc, con = lgetfilecon_raw(path)
    assert rc == 0, 'Result of call to lgetfilecon_raw: ' + str(rc)
    assert con != '', 'SELinux context for: ' + path + ' is empty.'
    assert 'system_u' in con, 'SELinux context for: ' + path + ' does not contain system_u.'

# Generated at 2022-06-11 01:53:06.064142
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_result = lgetfilecon_raw("/sys/fs")
    assert test_result == [0, 'system_u:object_r:sysfs_t:s0']

# Generated at 2022-06-11 01:53:12.309837
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/etc/group'
    mode = 0
    errcode, con = matchpathcon(path, mode)
    if errcode != 0:
        raise Exception('error while running matchpathcon: {0}'.format(os.strerror(errcode)))


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:53:19.253827
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test function lgetfilecon_raw
    """
    path = "/etc/passwd"
    try:
        if os.path.exists(path):
            (rc, con) = lgetfilecon_raw(path)
            assert rc == 0
            print("Context for "+path+" is "+con)
        else:
            print("File "+path+" do not exist")
    except OSError as e:
        print("Error "+str(e.errno)+" "+e.strerror)


# Generated at 2022-06-11 01:53:24.156230
# Unit test for function matchpathcon
def test_matchpathcon():
    print("matchpathcon")
    print(_selinux_lib.matchpathcon('/bin/ps', 0))
    print(_selinux_lib.matchpathcon('/bin/ps', 0))
    print(_selinux_lib.matchpathcon('/tmp/a', 0))


# Generated at 2022-06-11 01:53:29.349936
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw('/etc/shadow', byref(con))
    assert rc >= 0
    assert con.value
    assert isinstance(con.value, bytes)
    con_value = to_native(con.value)
    assert con_value == "user_home_t\0"
    _selinux_lib.freecon(con)



# Generated at 2022-06-11 01:53:32.699243
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/etc/")
    print("Return code: " + str(rc))
    print("SELinux context: " + con)



# Generated at 2022-06-11 01:53:44.602202
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, con] = lgetfilecon_raw('/sys/fs/selinux')
    assert rc == 0
    assert con == 'system_u:object_r:selinuxfs:s0'


# Generated at 2022-06-11 01:53:47.466327
# Unit test for function matchpathcon
def test_matchpathcon():
    import pytest

    rc, target = matchpathcon('/etc/shadow', os.R_OK)
    assert rc >= 0
    assert target == 'system_u:object_r:shadow_t:s0'

# Generated at 2022-06-11 01:53:49.874066
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'.'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con is not None
    assert con != ''



# Generated at 2022-06-11 01:53:52.201706
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp', 0) == [0, 'system_u:object_r:tmp_t']



# Generated at 2022-06-11 01:53:57.826138
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    rc, con = matchpathcon('/etc/ssl/private', 0)
    print('rc={0} con={1}'.format(rc, con))
    assert rc == 0
    assert con == 'system_u:object_r:ssl_cert_t:s0'



# Generated at 2022-06-11 01:54:04.539765
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    This test is only run if selinux is enabled in the test system.
    """

    import tempfile

    if not is_selinux_enabled():
        raise ImportError('cannot run test_matchpathcon() when selinux is not enabled')

    with tempfile.NamedTemporaryFile(prefix='ansible_test') as tmp_file:
        rc, con = matchpathcon(tmp_file.name, os.R_OK)
        if rc < 0 or not con:
            raise ValueError('matchpathcon() returned bad value')

# Generated at 2022-06-11 01:54:10.934565
# Unit test for function matchpathcon
def test_matchpathcon():
    # path to unit test dir
    test_dir = os.path.dirname(os.path.abspath(__file__))
    # subject to unit test
    test_file = test_dir + '/__init__.py'

    # call function
    rc, con = matchpathcon(test_file, 0)

    # assert results
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-11 01:54:20.868685
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import re
    import sys
    import tempfile
    from ansible.module_utils.common.system import platform_family

    if platform_family() == 'Windows':
        # pathname is Windows path, not a valid one for selinux
        path = r'C:\Users\System\Documents'
        # SELinux is not supported on Windows
        expected_rc = -1
        expected_con = None
    else:
        path = os.path.abspath(sys.argv[0])
        # SELinux requires a valid file
        if not os.path.isfile(path):
            return "Cannot test with non-existing file: {0}".format(path)
        expected_rc = 0

# Generated at 2022-06-11 01:54:25.682970
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/etc/passwd', 0)
    assert rc == 0, 'rc = {0}'.format(rc)
    assert con == 'system_u:object_r:passwd_file_t:s0', 'con = {0}'.format(con)



# Generated at 2022-06-11 01:54:29.412914
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/lilo.conf', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_runtime_t:s0'
    assert con == matchpathcon('/etc/lilo.conf', 0)[1]

# Generated at 2022-06-11 01:54:48.322265
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    fd, file_name = tempfile.mkstemp()
    assert lgetfilecon_raw(file_name)[0] == 0
    os.close(fd)
    os.unlink(file_name)



# Generated at 2022-06-11 01:54:52.142981
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')

    assert rc == 0
    assert con == 'unconfined_u:object_r:passwd_file_t:s0-s0:c0.c1023'


# Generated at 2022-06-11 01:54:54.951893
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test matchpathcon()
    """
    rc, con = matchpathcon('/dev/sdb1', 0)
    assert con == "u:object_r:virt_image_t:s0"

# Generated at 2022-06-11 01:54:59.589436
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/tmp/abc'
    rc, con = matchpathcon(path, 0)
    assert rc == 0
    assert con == 'unconfined_u:object_r:tmp_t:s0'

# Generated at 2022-06-11 01:55:01.445965
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/resolv.conf')[0] > 0

# Generated at 2022-06-11 01:55:09.163670
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/foo', mode=0) == [0, 'system_u:object_r:admin_home_t:s0']
    assert matchpathcon('/foo/bar', mode=0) == [0, 'system_u:object_r:admin_home_t:s0']
    assert matchpathcon('/foo/bar/', mode=0) == [0, 'system_u:object_r:admin_home_t:s0']
    assert matchpathcon('/foo/bar//', mode=0) == [0, 'system_u:object_r:admin_home_t:s0']
    assert matchpathcon('/foo/bar//baz', mode=0) == [0, 'system_u:object_r:admin_home_t:s0']

# Generated at 2022-06-11 01:55:11.880244
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        matchpathcon('/tmp/test.tmp', 0)
    except OSError as e:
        if e.errno == 13:
            raise NotImplementedError(e)
        raise


# Generated at 2022-06-11 01:55:16.895306
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    :return: True if matchpathcon function is implemented
    """
    try:
        rc, con = selinux.matchpathcon('/tmp', 0)
        # Return status code is 0 if successful
        return rc == 0
    except ImportError:
        return False


# Generated at 2022-06-11 01:55:26.643561
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: these tests won't work on systems which don't have selinux enabled
    import os
    import tempfile

    (tmp1, tmpfile1) = tempfile.mkstemp()
    (tmp2, tmpfile2) = tempfile.mkstemp()


# Generated at 2022-06-11 01:55:36.214602
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.path.expanduser('~/')

    # first check if selinux is enabled or disabled
    selinux_status = security_getenforce()
    if selinux_status == 0:
        return {'changed': False, 'rc': 0, 'results': ['SELinux is disabled'], 'unreachable': False, 'failed': False}


# Generated at 2022-06-11 01:56:11.819193
# Unit test for function matchpathcon
def test_matchpathcon():
    print("CTYPES: Test for selinux function matchpathcon")
    (rc, con) = matchpathcon("/etc/passwd", 0)
    print("CTYPES: Return code is: %s" % rc)
    print("CTYPES: Context is: %s" % con)
    assert rc == 0
    assert con == "system_u:object_r:passwd_file_t:s0"

# Generated at 2022-06-11 01:56:14.145081
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/tmp')
    assert rc == 0
    assert isinstance(con, str)

# Generated at 2022-06-11 01:56:19.192973
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    filename = os.environ['HOME']
    rc, data = lgetfilecon_raw(filename)
    if rc:
        print("Failed to get security context for %s(%d).\n" % (filename, rc))
    else:
        print("%s has security context of %s\n" % (filename, data))



# Generated at 2022-06-11 01:56:28.192010
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os

    import pytest

    # create a testfile
    f = open('/tmp/testfile', 'w')
    f.write('hello world')
    f.close()

    # get file context
    [rc, con] = lgetfilecon_raw('/tmp/testfile')

    # check rc value
    if rc != 0:
        raise Exception('ERROR: lgetfilecon_raw returned rc ' + rc)

    # check file context
    if con != 'system_u:object_r:tmp_t:s0':
        raise Exception('ERROR: lgetfilecon_raw returned con ' + con)

    # remove file
    os.remove('/tmp/testfile')

    # check if /etc/passwd file context is correct

# Generated at 2022-06-11 01:56:30.739993
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert len(con) > 0


# Generated at 2022-06-11 01:56:38.121463
# Unit test for function matchpathcon
def test_matchpathcon():
    data = matchpathcon('/etc/passwd', 0)
    assert data[0] == 0
    assert data[1] == 'system_u:object_r:etc_t:s0\x00'
    data = matchpathcon('/usr/sbin/useradd', 0)
    assert data[0] == 0
    assert data[1] == 'system_u:system_r:useradd_t:s0\x00'



# Generated at 2022-06-11 01:56:44.742758
# Unit test for function matchpathcon

# Generated at 2022-06-11 01:56:51.079107
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = matchpathcon('/etc/passwd', 0)
    except ImportError:
        pass
    except OSError as e:
        # fail if libselinux is not available
        assert e.errno == 2
    if rc == 0:
        assert con == "system_u:object_r:etc_t:s0"
    else:
        assert rc == -2

# Generated at 2022-06-11 01:56:55.971173
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Verfiy that lgetfilecon_raw returns the SE Linux context correctly
    target_path = '/'
    expected_result = ['unconfined_u:object_r:user_home_t:s0', 0]
    result = lgetfilecon_raw(target_path)
    assert result[1] == expected_result[0]
    assert result[0] == expected_result[1]

# Generated at 2022-06-11 01:57:07.201453
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """ Test for function lgetfilecon_raw """
    # pylint: disable=import-outside-toplevel
    from ansible.module_utils.selinux_policy import (
        selinux_getpolicytype, selinux_getenforcemode, lgetfilecon_raw,
    )
    file_path = to_bytes(os.path.realpath(__file__))
    policy_type = selinux_getpolicytype()[1]
    enforce_mode = selinux_getenforcemode()[1]
    attr_expect = '{0}:object_r:ansible_module_utils_selinux_file:{1}'.format(policy_type, 'o' if enforce_mode == 1 else '*').encode('utf-8')

# Generated at 2022-06-11 01:58:22.050190
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Test for the lgetfilecon_raw() function"""
    (rc, actualresult) = lgetfilecon_raw("/tmp")
    if rc < 0:
        raise OSError("failed to retrieve the SELinux context from path /tmp")
    assert actualresult == "system_u:object_r:tmp_t:s0"


# Generated at 2022-06-11 01:58:28.409575
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    # create a temporary file for testing
    tmpfile = tempfile.NamedTemporaryFile(mode='w+b', delete=False)
    tmpfile.close()

    # get the context of the temporary file
    context_arr = matchpathcon(tmpfile.name, 1)

    # remove the temporary file
    os.unlink(tmpfile.name)

    # assert the return codes
    assert context_arr[0] == 0

    # assert the context
    assert context_arr[1] == 'system_u:object_r:user_tmp_t:s0'

# Generated at 2022-06-11 01:58:32.028635
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/var/tmp', 0o755)
    assert(rc == 0)
    assert(con == 'system_u:object_r:user_tmp_t:s0')

# Generated at 2022-06-11 01:58:37.118945
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    fd, tfile = tempfile.mkstemp()
    f = os.fdopen(fd, 'wb')
    f.close()
    os.unlink(tfile)
    path = tfile
    rc, con = lgetfilecon_raw(path)
    assert(rc == 0)
    assert(con == 'unlabeled')



# Generated at 2022-06-11 01:58:39.849874
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/etc/hosts'
    filecon = lgetfilecon_raw(path)
    assert filecon[0] == 0
    assert filecon[1] == b'unconfined_u:object_r:etc_t:s0\x00'


# Generated at 2022-06-11 01:58:41.981648
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret = lgetfilecon_raw(b'conftest')
    if ret[0] == 0:
        assert ret[1]
        assert isinstance(ret[1], str)

# Generated at 2022-06-11 01:58:48.627062
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This is a unit test for function _lgetfilecon_raw. The following should hold:
    # _lgetfilecon_raw("/proc/version") = ['0', 'system_u:object_r:proc_version_t:s0']
    assert lgetfilecon_raw("/proc/version") == ['0', 'system_u:object_r:proc_version_t:s0']



# Generated at 2022-06-11 01:58:56.325194
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import subprocess
    (rc, con) = matchpathcon(b"/etc/dfile.conf", 0)
    assert rc == 0
    assert con == "system_u:object_r:etc_runtime_t:s0"
    (rc, con) = matchpathcon(b"/dev/null", 0)
    assert rc == 0
    assert con == "system_u:object_r:null_device_t:s0"
    devnull = os.open("/dev/null", os.O_WRONLY)
    subprocess.check_call(["chcon", "-t", "tmp_t", "/dev/null"])
    (rc, con) = matchpathcon(b"/dev/null", 0)
    assert rc == 0

# Generated at 2022-06-11 01:59:03.102697
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (result, context) = lgetfilecon_raw('/etc/passwd')
    if result == 0:
        if context == 'system_u:object_r:etc_runtime_t:s0':
            print('PASSED')
        else:
            print('FAILED: context not matched')
            sys.exit(1)
    elif result == -1:
        print('FAILED: file /etc/passwd not found')
        sys.exit(1)
    else:
        print('FAILED: function returned {0}'.format(result))
        sys.exit(1)



# Generated at 2022-06-11 01:59:05.658151
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b'/tmp/'
    assert lgetfilecon_raw(path)[1] == 'system_u:object_r:tmp_t'
