

# Generated at 2022-06-11 01:50:43.550906
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    from ansible.module_utils.selinux import matchpathcon

    path = '/etc/passwd'
    (rc, con) = matchpathcon(path, 0)
    print('{0}: {1}'.format(path, con))


# Generated at 2022-06-11 01:50:52.683169
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            path=dict(required=True, type='str'),
        ),
    )

    path = module.params['path']

    rc, con = lgetfilecon_raw(path)

    if rc == 0:
        module.exit_json(changed=False, selinux_context=con)
    else:
        module.fail_json(msg='Failed to get selinux context', rc=rc, path=path, errno=os.strerror(rc))



# Generated at 2022-06-11 01:50:55.733951
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon(b'/tmp/selinux-is-active', 0) == [0, 'system_u:object_r:tmp_t:s0']



# Generated at 2022-06-11 01:51:01.447683
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux.matchpathcon import matchpathcon
    MODES = {
        'current': 0,
        'minimum': 1,
        'reset': 2,
    }

    [rc, con] = matchpathcon(b'/tmp/test_file', MODES['current'])
    assert con == 'user_tmp_t:object_r:tmp_t:s0'

# Generated at 2022-06-11 01:51:07.152307
# Unit test for function matchpathcon
def test_matchpathcon():
    import unittest

    class TestMatchpathcon(unittest.TestCase):
        @unittest.skipIf(os.geteuid() == 0, "requires non-root user")
        def test_matchpathcon_without_root(self):
            # Test matchpathcon for non-root user.  This should raise OSError
            self.assertRaises(OSError, matchpathcon, 'test_matchpathcon', 1)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestMatchpathcon)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-11 01:51:12.861230
# Unit test for function matchpathcon
def test_matchpathcon():
    # NB: disabling this until a unit test environment can be simulated
    return
    path = '/'
    mode = 0  # FIXME: mock this with mox

    ret, con = matchpathcon(path, mode)
    if not 0 <= ret <= 3:
        raise Exception('unexpected return code: {0}'.format(ret))

# Generated at 2022-06-11 01:51:16.456902
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux/config'
    [rc, con] = lgetfilecon_raw(path)
    assert rc == 0, 'Called failed'
    assert con is not None, 'con should not be None'



# Generated at 2022-06-11 01:51:20.152908
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/etc/fstab')
    print ("Result is:", result[0])
    if (result[0] == 0):
        print ("SELinux security context is:", result[1])
    else:
        print ("Error:", result[0])


# Generated at 2022-06-11 01:51:31.854119
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # python3
    is_python3 = sys.hexversion >= 0x03000000
    # selinux is disabled
    is_selinux_enabled = is_selinux_enabled()
    if is_selinux_enabled == 0:
        return
    # Run some tests to be sure it works
    # Create a file and check that the context is correct
    with open("/tmp/test_file", "w") as f:
        f.write("test line\n")
    assert lgetfilecon_raw("/tmp/test_file")[1] == 'system_u:object_r:tmp_t:s0\n'

# Generated at 2022-06-11 01:51:37.731226
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('This is a test file\n')
    f.close()
    (rc, con) = lgetfilecon_raw(fname)
    if rc < 0:
        raise OSError(os.strerror(rc))
    os.remove(fname)
    print(con)


# Generated at 2022-06-11 01:51:41.476514
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/tmp', 0))



# Generated at 2022-06-11 01:51:51.700864
# Unit test for function matchpathcon
def test_matchpathcon():
    # Set global test variables
    # pylint: disable=global-statement
    global is_selinux_enabled, selinux_getpolicytype, matchpathcon
    is_selinux_enabled = True
    selinux_getpolicytype = lambda: [1, 'targeted']

    # Construct the wrapper function to test
    def matchpathcon_test(path, mode):
        # pylint: disable=missing-function-docstring
        return [1, '/tmp(/.*)?          system_u:object_r:tmp_t:s0']

    matchpathcon = matchpathcon_test
    # Test the wrapper
    rc, con = matchpathcon('/tmp', os.F_OK)
    assert rc == 1

# Generated at 2022-06-11 01:51:55.354020
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = "/etc/hosts"
    expected_return = 0
    actual_return = lgetfilecon_raw(test_path)
    if not int(expected_return) == int(actual_return[0]):
        raise ValueError


# Generated at 2022-06-11 01:52:01.733018
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # sanity checks for function lgetfilecon_raw
    tempfile = '/tmp/ansible_test_file'
    rc, con = lgetfilecon_raw(tempfile)

    if rc == 0:
        print('context of {0} is {1}'.format(tempfile, con))
    else:
        print('failed to get context of {0} due to {1}'.format(tempfile, rc))


# Generated at 2022-06-11 01:52:05.868440
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Check that getfilecon_raw(path, con) returns the context of a file.
    """
    test_path = os.getcwd()
    lgetfilecon_raw(path=test_path)


# Generated at 2022-06-11 01:52:11.395274
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con_context = matchpathcon(b'/etc/fstab', 0)
    assert rc == 0, 'unable to get selinux context for path: {0}'.format(rc)
    assert con_context == 'system_u:object_r:etc_runtime_t:s0', 'unexpected selinux context for path'



# Generated at 2022-06-11 01:52:14.745335
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    if rc == 0:
        print(con)
    else:
        print(con)
        print('# Failed to call lgetfilecon_raw')


# Generated at 2022-06-11 01:52:25.812067
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print('Running test_lgetfilecon_raw')
    from ansible.module_utils.basic import AnsibleModule
    import json
    import os

    module_args = dict()
    module_args['path'] = '/home'

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    if not os.path.isdir(module_args['path']):
        module.fail_json(
            msg='path must be a directory'
        )

    try:
        response = lgetfilecon_raw(module_args['path'])
    except OSError as e:
        module.fail_json(
            msg='failed to get file context, error: {}'.format(to_native(e))
        )


# Generated at 2022-06-11 01:52:35.221659
# Unit test for function matchpathcon
def test_matchpathcon():
    import unittest
    import os

    class MatchPathconTestCase(unittest.TestCase):
        def test_matchpathcon_1(self):
            (rc, con) = matchpathcon("/etc", 0)
            self.assertEqual(rc, 0, "test_matchpathcon_1{0} != 0".format(rc))
            self.assertEqual(con, "system_u:object_r:etc_t:s0", "test_matchpathcon_1{0} != system_u:object_r:etc_t:s0".format(con))

        def test_matchpathcon_2(self):
            (rc, con) = matchpathcon("/home/foo", 0)

# Generated at 2022-06-11 01:52:44.977446
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/tmp', 0) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp/foo.1', 0) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp/foo.2', 0) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp/foo.3', 0) == [0, 'system_u:object_r:tmp_t:s0']
    assert matchpathcon('/tmp/foo.4', 0) == [0, 'system_u:object_r:tmp_t:s0']

# Generated at 2022-06-11 01:52:52.999707
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/usr/bin/id'
    mode = 0
    con = c_char_p()
    try:
        rc = _selinux_lib.matchpathcon(path, mode, byref(con))
        assert rc == 0
        assert to_native(con.value) == 'system_u:object_r:user_exec_t:s0'
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-11 01:53:04.797399
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Unit test for lgetfilecon_raw()

    This test is executed when this module is imported.
    """

    if not is_selinux_enabled():
        return

    results = lgetfilecon_raw(__file__)

    assert results[0] == 0
    assert results[1] != ''

    results = lgetfilecon_raw('/this/path/does/not/exist')

    assert results[0] == -1
    assert results[1] == ''


if __name__ == '__main__':
    # Run unit test for this module
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-11 01:53:11.020733
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = b"/etc/passwd"
    ret = lgetfilecon_raw(path)
    exp_ret = [0, "system_u:object_r:fusefs_t:s0"]
    assert ret[0] == exp_ret[0]
    assert ret[1].startswith(exp_ret[1])



# Generated at 2022-06-11 01:53:13.274496
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = __file__
    rc, value = lgetfilecon_raw(path)
    assert rc == 0
    assert value is not None

# Generated at 2022-06-11 01:53:15.842278
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon("/bin/bash", 0o0)
    assert rc == 0
    assert con == "system_u:object_r:shell_exec_t:s0"

# Generated at 2022-06-11 01:53:22.801610
# Unit test for function matchpathcon
def test_matchpathcon():
    path = to_bytes('/var/opt/lib/pe-puppetdb/stuff')
    mode = 0

    rc, con = matchpathcon(path, mode)

    print('rc: {0}, con: {1}'.format(rc, con))

    assert con == 'system_u:object_r:pe_puppetdb_content_t:s0'


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-11 01:53:29.015116
# Unit test for function matchpathcon
def test_matchpathcon():
    # This test is only useful when run on the target system
    pathname = '/etc/passwd'
    mode = 0

    (rc, con) = matchpathcon(pathname, mode)
    assert rc == 0
    assert con == 'unconfined_u:object_r:etc_t:s0'

    # negative test
    pathname = '/nonexistent'
    (rc, con) = matchpathcon(pathname, mode)
    assert rc != 0
    assert con is None


# Generated at 2022-06-11 01:53:32.249237
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc >= 0
    assert con is not None
    assert type(con) == str

# Generated at 2022-06-11 01:53:41.098521
# Unit test for function matchpathcon
def test_matchpathcon():
    # selinux is not enabled on debian9.
    if os.path.exists('/etc/debian_version') and not os.path.exists('/selinux/enforce'):
        return

    expected_contexts = ['file_t', 'system_u:object_r:unlabeled_t:s0', 'system_u:object_r:unlabeled_t:s0',
                         'system_u:object_r:unlabeled_t:s0', 'system_u:object_r:init_var_run_t:s0',
                         'system_u:object_r:unlabeled_t:s0']

# Generated at 2022-06-11 01:53:45.240271
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw(u'/etc/selinux/config')
    assert rc == 0
    assert con == b'system_u:object_r:etc_runtime_t:s0'

# Generated at 2022-06-11 01:53:55.933319
# Unit test for function matchpathcon
def test_matchpathcon():
    from os import chdir
    from tempfile import mkdtemp

    def test_matchpathcon_cb(tmpdir):
        chdir(tmpdir)
        os.mkdir('etc/')
        os.mkdir('etc/init.d/')
        rc, con = matchpathcon('etc/init.d/', 0)
        assert rc == 0
        assert 'system_u:object_r:initrc_exec_t:s0' == con

    tmpdir = mkdtemp()
    try:
        test_matchpathcon_cb(tmpdir)
    finally:
        import shutil
        shutil.rmtree(tmpdir)

# Generated at 2022-06-11 01:54:03.131852
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    files = ['/.autorelabel', '/.autorelabel_console', '/.autorelabel_sysadm', '/.autorelabel_tmp']
    for file in files:
        [rc, out] = lgetfilecon_raw(file)
        if not rc:
            print('{0}: {1}'.format(file, out))
        else:
            print('{0}: error: {1}'.format(file, rc))

if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-11 01:54:04.661462
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/etc/passwd", 0) == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-11 01:54:08.845647
# Unit test for function matchpathcon
def test_matchpathcon():
    # The mode should be either 0, 1 or 2
    assert matchpathcon('/root', 1)[0] == 0
    # Not passing a valid path will return -1
    assert matchpathcon('/root-test', 1)[0] == -1
    assert matchpathcon('/root-test', 2)[0] == -1



# Generated at 2022-06-11 01:54:19.505366
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux.common import SELINUX_ROLE_RE

    def is_valid_role(role):
        return SELINUX_ROLE_RE.match(role) is not None

    # FIXME: this test needs to be fleshed out much more
    path = '/etc/passwd'
    sys.stderr.write('test lgetfilecon_raw\n')
    rc, con = lgetfilecon_raw(path)
    if rc < 0:
        raise OSError(rc, 'lgetfilecon_raw failed')
    sys.stderr.write('con: %s\n' % con)
    assert True if con and is_valid_role(con) else False



# Generated at 2022-06-11 01:54:28.173621
# Unit test for function matchpathcon
def test_matchpathcon():
    # Ensure the wrapper returns the same result as a raw call
    # to the c library. For example:
    # $ python -c 'from ansible.module_utils.selinux_python_wrap import matchpathcon; print(matchpathcon("/path/to/file", 36))'

    # Try a bad path
    rc, con = matchpathcon("/bad/path", 36)
    assert rc == 1
    assert con == ""

    # Try a good path
    rc, con = matchpathcon("/path/to/file", 36)
    assert rc == 0
    assert con == "system_u:object_r:file_t:s0"

# Generated at 2022-06-11 01:54:32.220047
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/shadow') == [0, 'system_u:object_r:shadow_t:s0']
    assert lgetfilecon_raw(b'/etc/shadow') == [0, 'system_u:object_r:shadow_t:s0']



# Generated at 2022-06-11 01:54:43.607835
# Unit test for function matchpathcon
def test_matchpathcon():
    # well-defined good path
    path = '/var/log/mytestfile.txt'
    mode = 0

    rc, con = matchpathcon(path, mode)

    if rc:
        raise ValueError('unable to call matchpathcon, rc: {0}, con: {1}'.format(rc, con))

    if not con:
        raise ValueError('unable to call matchpathcon, rc: {0}'.format(rc))

    print(con)

    # non-existent not-well-defined path
    path = '/var/log/mytestfile.txt.bad'
    rc, con = matchpathcon(path, mode)

    if rc:
        raise ValueError('unable to call matchpathcon, rc: {0}, con: {1}'.format(rc, con))


# Generated at 2022-06-11 01:54:51.356420
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/test/path/to/a/directory"
    mode = os.stat(path).st_mode
    try:
        print("Calling matchpathcon with path: {0} with mode: {1}".format(path, mode))
        rc, con = matchpathcon(path, mode)
        print("matchpathcon returned rc: {0} and context: {1}".format(rc, con))
    except OSError as e:
        print("OSError raised with errno: {0}".format(e.errno))

# Generated at 2022-06-11 01:55:02.618775
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    import os
    import pwd
    import stat
    import tempfile
    import unittest

    # Create a temporary directory via tempfile and change to it.
    with tempfile.TemporaryDirectory() as tmpdirname:
        # Change to it
        os.chdir(tmpdirname)

        # TEST 1: Directory created by root with default context
        # Create a directory whose context will be changed to
        folderA = os.path.join(tmpdirname, "folderA")
        os.mkdir(folderA)

        # Change the context of the directory
        (rc, con) = matchpathcon(folderA, stat.S_IFDIR)

        # Create user and change ownership of the directory
        username = "testuser"

# Generated at 2022-06-11 01:55:10.161770
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/home/user/playbook.yml'
    # Get the mode of the file
    mode = os.stat(path).st_mode
    rc, con = matchpathcon(path, mode)
    print(rc, con)

# Generated at 2022-06-11 01:55:13.106215
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-11 01:55:22.980030
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import sys
    out = sys.stdout
    # accept only one argument
    result = lgetfilecon_raw('/etc/shadow')
    assert result[0] == 0, 'failed to read file context of /etc/shadow'
    out.write('file context of /etc/shadow is %s\n' % result[1])
    # accept only one argument
    result = lgetfilecon_raw(b'/etc/shadow')
    assert result[0] == 0, 'failed to read file context of /etc/shadow'
    out.write('file context of /etc/shadow is %s\n' % result[1])


# Generated at 2022-06-11 01:55:33.701118
# Unit test for function matchpathcon
def test_matchpathcon():
    # If a path is passed as argument of a context call
    # it will return an entry of the policy type
    # If a path is passed as argument of a context call
    # it will return an entry of the policy type
    # If a path is passed as argument of a context call
    # it will return an entry of the policy type
    # If a path is passed as argument of a context call
    # it will return an entry of the policy type
    assert(matchpathcon('/tmp/a/b.txt', 0) == [0, 'system_u:object_r:tmp_t'])
    # If a path is passed as argument of a context call
    # it will return an entry of the policy type
    # If a path is passed as argument of a context call
    # it will return an entry of the policy type
    # If a path is

# Generated at 2022-06-11 01:55:37.648922
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, output) = lgetfilecon_raw('/etc/selinux/config')
    assert rc == 0
    assert output == 'system_u:object_r:etc_runtime_t:s0'
    (rc, output) = lgetfilecon_raw('/tmp/test123')
    assert rc != 0
    assert output == ''


# Generated at 2022-06-11 01:55:41.514595
# Unit test for function matchpathcon
def test_matchpathcon():
    path = "/var/lib/nfs/rpc_pipefs"
    mode = os.stat(path).st_mode
    retval = matchpathcon(path, mode)
    assert retval[0] == 0
    assert retval[1] == "system_u:object_r:rpc_pipefs_t:s0"

# Generated at 2022-06-11 01:55:47.728459
# Unit test for function matchpathcon
def test_matchpathcon():
    get_con = os.environ.get('ANSIBLE_SELINUX_MATCHPATHCON_CONTEXT')
    path = os.environ.get('ANSIBLE_SELINUX_MATCHPATHCON_PATH')
    if get_con is not None:
        rc, con = matchpathcon(path, '0')
        if rc != 0:
            raise OSError('matchpathcon failed: {0}'.format(rc))
        return con
    else:
        raise ImportError('matchpathcon unavailable')

# Generated at 2022-06-11 01:55:55.973725
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test 1
    assert matchpathcon(b'/etc/hosts', os.R_OK) == [0, 'system_u:object_r:etc_t:s0']
    # Test 2
    assert matchpathcon(b'/etc/hosts', 0o777) == [0, 'system_u:object_r:etc_t:s0']
    # Test 3
    assert matchpathcon(b'/tmp/does_not_exist', os.R_OK) == [0, 'system_u:object_r:tmp_t:s0']
    # Test 4
    assert matchpathcon(b'/tmp/does_not_exist', 0o777) == [0, 'system_u:object_r:tmp_t:s0']
    # Test 5

# Generated at 2022-06-11 01:56:06.586122
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Basic test for lgetfilecon_raw

    This will attempt to get the file context of /etc/passwd.
    '''
    import ctypes
    from ansiblite.module_utils.ansible_release import __version__ as ansible_version
    from ansiblite.module_utils.common.text.converters import to_native


    if 'selinux' not in sys.modules:
        return False, None, None


# Generated at 2022-06-11 01:56:17.386569
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import selinux
    from selinux.selinux import sename

    ctx = None
    if os.path.exists("/etc/selinux/config"):
        ctx = lgetfilecon_raw("/etc/selinux/config")[1]
    else:
        ctx = lgetfilecon_raw("/etc")[1]
    print("/etc/selinux/config context is: {}".format(ctx))

    print("selinux.is_selinux_enabled() returns {}".format(selinux.is_selinux_enabled()))
    print("selinux.is_selinux_mls_enabled() returns {}".format(selinux.is_selinux_mls_enabled()))

# Generated at 2022-06-11 01:56:26.314307
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Negative test
    rc, con = lgetfilecon_raw('/noexist')
    assert rc == -1 and con is None
    # Positive test
    rc, con = lgetfilecon_raw('/')
    assert rc == 0 and con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-11 01:56:28.416601
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    print(lgetfilecon_raw(__file__))

# Generated at 2022-06-11 01:56:33.352780
# Unit test for function matchpathcon
def test_matchpathcon():
    if is_selinux_enabled():
        assert matchpathcon('tests/selinux-test.py', 0) == [0, 'system_u:object_r:usr_t:s0']


# Unit tests for function lgetfilecon_raw

# Generated at 2022-06-11 01:56:34.787752
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd')[0] == 0

# Generated at 2022-06-11 01:56:39.431345
# Unit test for function matchpathcon
def test_matchpathcon():
    # FIXME: selinux.matchpathcon is deprecated and this function should be rewritten to use selinux.selabel_lookup
    (rc, con) = matchpathcon('/etc/ansible/ansible.cfg', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-11 01:56:44.694564
# Unit test for function matchpathcon
def test_matchpathcon():
    # Negative scenario

    # File does not exist
    [rc, con] = matchpathcon("/tmp/foobar", 0)
    assert rc != 0

    # Positive scenario

    # File exists
    [rc, con] = matchpathcon("/tmp", 0)
    assert rc == 0

    # Invalid file path
    [rc, con] = matchpathcon("/foo/bar", 0)
    assert rc != 0



# Generated at 2022-06-11 01:56:51.999318
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile() as filehandle:
        path = filehandle.name

    for path in (path, b'/tmp',):
        for path in [path, to_bytes(path)]:
            rc, con = lgetfilecon_raw(path)

            if rc == -1:
                assert con is None
                assert get_errno() == 2
                continue

            assert isinstance(con, str)
            assert con.startswith('unconfined_u:object_r:')



# Generated at 2022-06-11 01:56:59.854752
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/etc/hosts')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'

    rc, con = lgetfilecon_raw(b'/tmp')
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    rc, con = lgetfilecon_raw(b'/tmp/selinux_test')
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-11 01:57:04.309891
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    ret_code, con = lgetfilecon_raw('/usr/bin/node')
    if ret_code != 0:
        raise RuntimeError('Cannot retrieve SELinux context string')
    if not con:
        raise RuntimeError('Retrieved SELinux context string is empty')


# Generated at 2022-06-11 01:57:07.253133
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert(lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0'])


# Generated at 2022-06-11 01:57:12.525341
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    return lgetfilecon_raw('/')

# Generated at 2022-06-11 01:57:15.879574
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, result = lgetfilecon_raw('/etc/passwd')
    assert rc >= 0
    assert isinstance(result, str)

# Generated at 2022-06-11 01:57:24.085732
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import errno
    # Create a temporary file
    fdes, fname = os.pipe()
    os.close(fdes)
    try:
        # Call lgetfilecon_raw
        rc, context = lgetfilecon_raw(fname)
        # Check that it returns 0 and not NULL
        assert rc == 0, "lgetfilecon_raw returned unexpected return code: {:d}".format(rc)
        assert context is not None, "lgetfilecon_raw returned NULL"
    finally:
        os.remove(fname)


# Generated at 2022-06-11 01:57:26.128377
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_path = b'/tmp/test_file_0.txt'
    rc, con = lgetfilecon_raw(test_path)
    assert rc == 0
    assert type(con) == str


# Generated at 2022-06-11 01:57:29.730108
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/shadow'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'


# Generated at 2022-06-11 01:57:35.706785
# Unit test for function matchpathcon
def test_matchpathcon():
    if _selinux_lib.is_selinux_enabled() == 1:

        # create file to test
        with open('/tmp/test_selinux', 'a'):
            # check if matchpathcon works
            test_match = _selinux_lib.matchpathcon('/tmp/test_selinux', 0)

            # delete file after test
            os.remove('/tmp/test_selinux')

            return (test_match[0] == 0)

    else:
        # selinux is not enabled
        return True

# Generated at 2022-06-11 01:57:44.578439
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text
    from ctypes import byref, create_string_buffer, c_char_p, c_char, c_void_p

    # Invalid path
    path = u'/test/test2'
    mode = 0o755
    con = c_char_p()
    is_ok = _selinux_lib.matchpathcon(path, mode, byref(con))
    assert is_ok != 0
    assert to_text(con.value) == u'Invalid arguments'

    # Path ok
    path = b'/foo/bar'
    mode = 0o755
    rc, context = matchpathcon(path, mode)
    assert rc == 0
    assert context.startswith(u'system_u')
    _selinux_lib.freecon(con)

# Generated at 2022-06-11 01:57:51.782297
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import server_module_utils.selinux as ansible_selinux
    resource = '/usr'
    result = ansible_selinux.matchpathcon(resource, os.stat(resource).st_mode)
    if result[0] == 0:
        print("Successful operation. Path: %s, Context: %s" % (resource, result[1]))
    else:
        print("Operation failed. Path: %s, Error: %s" % (resource, result[1]))

# Generated at 2022-06-11 01:57:57.240810
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        rc, con = matchpathcon('/etc/passwd', 3)
        assert rc == 0
        assert con == 'system_u:object_r:passwd_file_t:s0'

        rc, con = matchpathcon('/etc/fstab', 0)
        assert rc == 0
        assert con == 'system_u:object_r:etc_t:s0'

    except ImportError as e:
        print('Module selinux not found', e)

# Generated at 2022-06-11 01:58:06.941439
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import sys
    import os
    import time

    tmpdir = './lgetfilecon_raw_test'
    file_name = 'test_file'
    file_full_name = tmpdir + '/' + file_name

    def cleanup():
        if os.path.exists(file_full_name):
            os.remove(file_full_name)
        if os.path.exists(tmpdir):
            os.rmdir(tmpdir)


# Generated at 2022-06-11 01:58:16.556025
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    func = globals()['lgetfilecon_raw']
    path = "/etc/passwd"
    if os.path.exists(path):
        rc, con = func(path)
    else:
        raise Exception("%s not exists" % path)



# Generated at 2022-06-11 01:58:22.229121
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    lgetfilecon_raw function unit test
    """
    # Create a test file
    file = open("test_selinux.txt","w+")
    file.write("This is test file\n")
    file.close()

    # Get the context of the test file
    rc, con = lgetfilecon_raw("test_selinux.txt")
    assert rc == 0
    assert con == 'unconfined_u:object_r:default_t:s0'

    # Cleanup
    os.remove("test_selinux.txt")


# Generated at 2022-06-11 01:58:23.770652
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0


# Generated at 2022-06-11 01:58:31.471557
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    name = '/tmp/test.selinux'
    if not os.path.isfile(name):
        with open(name, 'w') as f:
            pass
    curpath = os.getcwd()
    os.chdir('/tmp')
    ret = lgetfilecon_raw('test.selinux')
    os.remove(name)
    os.chdir(curpath)
    assert type(ret) is list
    assert type(ret[0]) is int
    assert type(ret[1]) is str
    assert ret[0] == 0

# Generated at 2022-06-11 01:58:36.320209
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = "ansible_test_file"
    open(test_file, "w").close()
    rc, con = lgetfilecon_raw(test_file)
    assert rc in [0, -1]
    assert isinstance(con, basestring)
    os.remove(test_file)



# Generated at 2022-06-11 01:58:42.751203
# Unit test for function matchpathcon
def test_matchpathcon():
    # First we need to create a temporary file.
    # We will use subprocess module to test this utility.
    import subprocess
    SUBPROC_MODULE = subprocess.Popen(["cat", "/etc/hosts"],
                                      stdout=subprocess.PIPE)
    SUBPROC_MODULE.wait()
    HOSTS_FILE = SUBPROC_MODULE.communicate()[0].decode()

    # Create a temporary file and write HOSTS_FILE to it.
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile(delete=False) as HOSTS_TEMP_FILE:
        HOSTS_TEMP_FILE.write(HOSTS_FILE)
        FILENAME = HOSTS_TEMP_FILE.name

    # Context of the file created above.
    CONT

# Generated at 2022-06-11 01:58:45.573111
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/home/user/.ssh')[1] == 'user_home_t:object_r:user_ssh_home_t:s0'

# Generated at 2022-06-11 01:58:53.147319
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/usr/bin/sort'
    mode = os.R_OK
    try:
        print(_selinux_lib)
        rc, con = matchpathcon(path, mode)
        print('return code = {0}'.format(rc))
        print('context = {0}'.format(con))
    except OSError as e:
        print('OSError: return code = {0}'.format(e.errno))
        print('OSError: strerr = {0}'.format(os.strerror(e.errno)))


# Generated at 2022-06-11 01:58:58.699103
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'
    rc, con = matchpathcon('/tmp', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con in ['targeted', 'strict', 'minimum']
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [-1, 0, 1]

# Generated at 2022-06-11 01:59:02.142890
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        [rc, context] = matchpathcon('/etc/passwd', 0)
        assert rc == 0
        assert context == 'system_u:object_r:etc_runtime_t:s0'
    except NotImplementedError:
        pass

# Generated at 2022-06-11 01:59:18.630179
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # should fail with ENOENT
    _, rc = lgetfilecon_raw('/var/noent')
    if rc != -2:
        print('test failed: %d, expected %d' % (rc, -2))
        return

    # should return a valid context for an existing file
    _, rc = lgetfilecon_raw('/var/log/messages')
    if rc is None:
        print('test failed: %s, not %s' % (rc, None))
        return

    # should fail with EINVAL when given a directory
    _, rc = lgetfilecon_raw('/var/log')
    if rc != -22:
        print('test failed: %d, expected %d' % (rc, -22))
        return

    print('test passed')



# Generated at 2022-06-11 01:59:26.018342
# Unit test for function matchpathcon
def test_matchpathcon():
    print('Test matchpathcon')
    [rc, con] = matchpathcon('/tmp', os.R_OK)
    if rc < 0:
        print('ERROR: matchpathcon returned: {0}'.format(rc))
        return
    [rc, type] = selinux_getpolicytype()
    if rc < 0:
        print('ERROR: selinux_getpolicytype returned: {0}'.format(rc))
        return
    print('Test matchpathcon returned: {0} {1}'.format(con, type))


# Generated at 2022-06-11 01:59:27.970708
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/var/log/httpd/access_log', 0)
    return (rc, con)



# Generated at 2022-06-11 01:59:37.107562
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import time

    (rc, con) = matchpathcon('/proc/self/fd', os.R_OK)
    print('matchpathcon: expected: [0, None] actual: {0}'.format([rc, con]))
    (rc, con) = matchpathcon('/', os.R_OK)
    print('matchpathcon: expected: [1, system_u:object_r:root_t:s0] actual: {0}'.format([rc, con]))
    (rc, con) = matchpathcon('/usr/bin', os.R_OK)
    print('matchpathcon: expected: [0, system_u:object_r:bin_t:s0] actual: {0}'.format([rc, con]))

# Generated at 2022-06-11 01:59:41.371575
# Unit test for function matchpathcon
def test_matchpathcon():
    import os

    path = '/etc/fstab'
    mode = os.R_OK

    (rc, con) = matchpathcon(path, mode)

    if rc != 0:
        print('not ok')
        return

    print(con)


# Generated at 2022-06-11 01:59:46.136775
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = selinux_getenforcemode()
    assert rc == 0
    assert con in (0, 1, 2)

    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == 'targeted'

    rc, con = lgetfilecon_raw('/etc/shadow')
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'

    rc, con = matchpathcon('/etc/shadow', 0)
    assert rc == 0
    assert con == 'system_u:object_r:shadow_t:s0'

# Generated at 2022-06-11 01:59:56.162312
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import pytest

    from ansible.module_utils.selinux import lgetfilecon_raw

    if not os.path.exists('/usr/sbin/getenforce'):
        pytest.skip('selinux not installed')
    elif not os.path.exists('/etc/selinux/config'):
        pytest.skip('selinux configured')

    filepath = '/etc/shadow'
    if not os.path.exists(filepath):
        pytest.skip('{} not found'.format(filepath))

    rc, con = lgetfilecon_raw(filepath)

    assert(rc == 0)
    assert(isinstance(con, str))
    assert(con != '')

# Generated at 2022-06-11 01:59:57.702318
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd')[0] == 0


# Generated at 2022-06-11 02:00:00.484165
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    print(lgetfilecon_raw(b'/etc/passwd'))
    print(lgetfilecon_raw(b'/etc/foo'))


# Generated at 2022-06-11 02:00:05.426587
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():

    # check if SELinux is enabled
    if not is_selinux_enabled():
        return True

    # fetch the context of a test file
    con = lgetfilecon_raw('/etc/modprobe.d/50-aspeed.conf')

    # check if returned context is a valid security context
    if con[1] and con[1].startswith('unconfined_u:object_r:sysfs_t:'):
        return True
    else:
        return False

# Generated at 2022-06-11 02:00:35.381592
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    from ansible.module_utils.selinux import security_context
    path = os.getcwd()
    result = lgetfilecon_raw(path)
    print(result)
    assert result[0] == -1
    assert result[1] == None
    assert result == result[0] == security_context.getfilecon_raw(path)


# Generated at 2022-06-11 02:00:37.330196
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw("/")
    assert rc == 0
    assert con is not None



# Generated at 2022-06-11 02:00:41.283969
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/var/www/html'
    mode = 0

    rc, con = matchpathcon(path, mode)
    assert isinstance(rc, int)
    assert rc in [0, -1]
    if rc == -1:
        assert con is None
    else:
        assert con is not None
