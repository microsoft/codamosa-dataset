

# Generated at 2022-06-22 22:22:42.683462
# Unit test for function matchpathcon
def test_matchpathcon():
    # The path and mode should match the ones in the context manifest from test/integration/context_manifest/context.yml
    # This test validates that the path is in a virtualenv with selinux
    path = '/tmp/ansible-test-virtualenv-selinux/bin/python'
    mode = os.stat(path).st_mode
    assert matchpathcon(path, mode) == [0, "system_u:object_r:lib_t:s0"]


# Generated at 2022-06-22 22:22:44.047190
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert [0, 0] == selinux_getenforcemode()

# Generated at 2022-06-22 22:22:45.377584
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0



# Generated at 2022-06-22 22:22:48.725173
# Unit test for function matchpathcon
def test_matchpathcon():
    context = matchpathcon("/etc/hosts", 0)
    print("context of /etc/hosts is %s\n" % context)


# Generated at 2022-06-22 22:22:50.931162
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # FIXME: this test won't run unless selinux is enabled
    rc, enforcemode = selinux_getenforcemode()
    return [rc, enforcemode]



# Generated at 2022-06-22 22:22:55.191440
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():

    # Invoke the selinux_getpolicytype function
    rc, out = selinux_getpolicytype()
    assert rc == 0, "Expected rc=0, got rc={0}".format(rc)
    assert out == "targeted", "Expected out=targeted, got out={0}".format(out)


# Generated at 2022-06-22 22:22:58.046687
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [status, value] = selinux_getenforcemode()
    assert status >= 0, "Function selinux_getenforcemode failed"
    assert value in [1, 0, -1], "Function selinux_getenforcemode failed"



# Generated at 2022-06-22 22:23:02.507844
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policy_type = selinux_getpolicytype()
    print('return code: {0}'.format(rc))
    print('policy type: {0}'.format(policy_type))


# Generated at 2022-06-22 22:23:06.285078
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    result = lgetfilecon_raw('/etc/selinux/config')
    print('result:', result)


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:23:09.956456
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected_output = "selinux_mls"
    policytype = selinux_getpolicytype()
    if policytype[1] == expected_output:
        print("Test Success")
    else:
        print("Test Failed")


# Generated at 2022-06-22 22:23:13.704961
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        rc, result = lgetfilecon_raw('/etc/selinux/config')
        assert rc == 0
    except OSError as e:
        assert e.errno == 2
        assert e.strerror == 'No such file or directory'



# Generated at 2022-06-22 22:23:15.088729
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/data/test"
    context = lgetfilecon_raw(path)[1]
    assert isinstance(context, str)


# Generated at 2022-06-22 22:23:21.431538
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    try:
        fp = tempfile.NamedTemporaryFile()
        rc, con = lgetfilecon_raw(fp.name)
        if rc < 0:
            raise OSError(rc, 'failed to get selinux context')
        else:
            print(con)
    finally:
        fp.close()

# Generated at 2022-06-22 22:23:26.420501
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, ptype = selinux_getpolicytype()
    if rc != 0:
        raise ValueError('selinux_getpolicytype did not return 0: {0}'.format(rc))
    if not isinstance(ptype, str):
        raise TypeError('selinux_getpolicytype did not return a str: {0}'.format(type(ptype)))

# Generated at 2022-06-22 22:23:30.487934
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    filepath = tempfile.mkstemp()[1]
    assert matchpathcon(filepath, 0) == [0, None]
    os.unlink(filepath)

# Generated at 2022-06-22 22:23:33.879409
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw(b'/etc/passwd')
    print('rc: %d' % rc)
    print('con: %s' % con)


# Generated at 2022-06-22 22:23:36.327881
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """Test function"""
    response = selinux_getenforcemode()
    assert response[0] == 0 and response[1] in [0, 1, 2]



# Generated at 2022-06-22 22:23:38.431907
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con == b'standard'


# Generated at 2022-06-22 22:23:44.922769
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        import selinux
    except ImportError:
        # selinux not installed
        return
    import subprocess
    cmd = ["getenforce"]
    p = subprocess.Popen(cmd,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE)
    output = p.stdout.read().rstrip()
    err = p.stderr.read().rstrip()
    p.stdout.close()
    p.stderr.close()
    if err:
        raise AssertionError("Cannot get SELinux status because: %s" % err)
    rc, enforcemode = selinux.selinux_getenforcemode()

# Generated at 2022-06-22 22:23:49.641509
# Unit test for function matchpathcon
def test_matchpathcon():
    # Test case with a symlink to a file
    symlink_file = os.path.join(os.path.dirname(__file__), "selinux_matchpathcon.link")
    if not os.path.islink(symlink_file):
        os.symlink(os.path.join(os.path.dirname(__file__), "selinux_matchpathcon.py"), symlink_file)
    rc, con = matchpathcon(symlink_file, os.R_OK)
    os.unlink(symlink_file)
    assert rc == 0

# Generated at 2022-06-22 22:23:51.697562
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, type = selinux_getpolicytype()
    print(rc, type)



# Generated at 2022-06-22 22:23:53.232939
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-22 22:24:01.215982
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    '''
    The policy reload module depends on the selinux_getpolicytype function
    to support automation.  This test supports unit testing the selinux_getpolicytype
    funcion.
    '''
    rc, policytype = selinux_getpolicytype()
    assert rc >= 0, "Unexpected error code, expecting >= Zero"
    assert isinstance(policytype, str), "Policytype is not a string"
    assert policytype == 'targeted' or policytype == 'minimum', \
        "Policytype is not expected value, expecting 'targeted' or 'minimum'"

# Generated at 2022-06-22 22:24:03.340162
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():

    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert type(enforcemode) is int

# Generated at 2022-06-22 22:24:06.546586
# Unit test for function matchpathcon
def test_matchpathcon():
    print(matchpathcon('/tmp/file1', 0))
    # print(matchpathcon('/tmp/file2', 0))
    # print(matchpathcon('/etc/selinux/foo', 0))



# Generated at 2022-06-22 22:24:16.779528
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    temppath = os.path.join(tmpdir, 'test_matchpathcon')
    open(temppath, 'wb').close()
    mode = os.stat(temppath).st_mode
    print("Mode before setting access controls %s" % mode)

    print("\nCalling matchpathcon with a mode of 0o777 "
          "file should be owned by user %s group %s" % (os.getuid(), os.getgid()))
    print("Result %s" % matchpathcon(temppath, 0o777))
    mode = os.stat(temppath).st_mode
    print("After matchpathcon mode is %s\n" % mode)


# Generated at 2022-06-22 22:24:18.485292
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]



# Generated at 2022-06-22 22:24:21.419469
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert isinstance(con, str)


# Generated at 2022-06-22 22:24:26.269379
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    if selinux_getpolicytype()[0] == 0:
        print('Pass: test_selinux_getpolicytype')
    else:
        print('Failed: test_selinux_getpolicytype')

# Generated at 2022-06-22 22:24:30.667710
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    ''' Test for function selinux_getenforcemode'''
    rc, ret = selinux_getenforcemode()
    assert(type(ret) == int) or (ret == -1)

    rc, ret = selinux_getenforcemode()
    assert(type(ret) == int) or (ret == -1)


# Generated at 2022-06-22 22:24:32.542258
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    x = lgetfilecon_raw('/home/kubeuser')
    assert x[0] != -1


# Generated at 2022-06-22 22:24:38.701416
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Feed in a non-existent file
    try:
        rc, con = lgetfilecon_raw(to_native('/ansible_test_non_existent_path'))
        assert False, 'ERROR: unexpected lgetfilecon_raw return value'
    except OSError as e:
        assert e.errno == 2
        # Test passed, OSError raised as expected

    # Feed in a file that has SELinux context
    try:
        rc, con = lgetfilecon_raw(to_native('/etc/passwd'))
    except OSError as e:
        assert False, 'ERROR: unexpected lgetfilecon_raw error {0}'.format(e)

    # Test passed, no OSError raised

# Generated at 2022-06-22 22:24:45.146428
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    try:
        rc, enforcemode = selinux_getenforcemode()
        if enforcemode == 0:
            print("\nselinux is permissive")
        elif enforcemode == 1:
            print("\nselinux is enforcing")
        else:
            print("\nselinux is unknown")
    except Exception as e:
        print("\nCaught exception: {}".format(e))
    finally:
        print("\nFunction selinux_getenforcemode has completed.\n")



# Generated at 2022-06-22 22:24:48.756857
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/usr/bin/python')[1] == 'unconfined_u:object_r:usr_t:s0'


# Generated at 2022-06-22 22:24:50.205679
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-22 22:24:56.565631
# Unit test for function matchpathcon
def test_matchpathcon():
    PATH = b'/etc/hosts'
    mode = 0
    con = c_char_p()
    rc = _selinux_lib.matchpathcon(PATH, mode, byref(con))
    assert rc == 0
    assert to_native(con.value) == 'system_u:object_r:etc_t:s0'
    _selinux_lib.freecon(con)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:24:59.784744
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    '''
    Return information about SELinux context of path
    '''

    (rc, con) = lgetfilecon_raw('/tmp')
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'



# Generated at 2022-06-22 22:25:03.836343
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    policytype = selinux_getpolicytype()
    assert len(policytype) == 2
    assert policytype[0] == 0
    assert isinstance(policytype[1], str)


# Generated at 2022-06-22 22:25:11.089633
# Unit test for function matchpathcon
def test_matchpathcon():

    path = '/var/log/audit/audit.log'
    flag = os.O_RDWR | os.O_APPEND | os.O_CREAT
    mode = os.stat(path).st_mode
    mode |= flag
    ret = matchpathcon(path, mode)
    assert ret[0] == 0
    print(ret[1])
    print("Unit test success")


if __name__ == "__main__":
    test_matchpathcon()

# Generated at 2022-06-22 22:25:14.176429
# Unit test for function matchpathcon
def test_matchpathcon():
    (rc, con) = matchpathcon('/tmp/foo', 0)
    assert rc == 0
    assert con == 'unconfined_u:object_r:tmp_t:s0'

# Generated at 2022-06-22 22:25:17.526304
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # This should be replaced with a mock
    path = os.path.dirname(os.path.abspath(__file__))
    expected = [0, "system_u:object_r:ansible_module_exec_t:s0"]

    assert lgetfilecon_raw(to_bytes(path)) == expected


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:25:20.924047
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    global selinux_getpolicytype
    # if the selinux is not installed, it will return error code
    policy, rc = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(policy, str)



# Generated at 2022-06-22 22:25:22.808153
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0
    assert type(policytype) == str



# Generated at 2022-06-22 22:25:24.669185
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/') == [0, 'system_u:object_r:rootfs:s0']



# Generated at 2022-06-22 22:25:27.410569
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/usr')
    # con should be "system_u:object_r:usr_t:s0"
    # rc should be zero
    # errno could be anything, so ignore it


# Generated at 2022-06-22 22:25:30.225978
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    rc, result = matchpathcon('/etc/hosts', os.R_OK)
    assert rc == 0
    assert result == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-22 22:25:41.680077
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile, shutil

    # For making a directory like /tmp/perms/foo/bar.
    temp_dir = tempfile.mkdtemp()
    perms_dir = os.path.join(temp_dir, 'perms')
    foo_dir = os.path.join(perms_dir, 'foo')
    bar_dir = os.path.join(foo_dir, 'bar')
    os.mkdir(perms_dir)
    os.mkdir(foo_dir)
    os.mkdir(bar_dir)

    # Set a specific SELinux context for this directory.
    mode = os.stat(bar_dir).st_mode
    (status, con) = matchpathcon(bar_dir, mode)
    # If there is no error, test passes.

# Generated at 2022-06-22 22:25:45.112948
# Unit test for function matchpathcon
def test_matchpathcon():
    home = os.environ['HOME']
    con = matchpathcon(home, 0)[1]
    print(con)
    assert con is not None

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:25:47.428534
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/')
    assert rc == 0
    assert con == 'system_u:object_r:root_t:s0'



# Generated at 2022-06-22 22:25:55.441662
# Unit test for function matchpathcon
def test_matchpathcon():
    # Create file with security context system_u:object_r:svirt_sandbox_file_t:s0:c7,c434
    with open("test", "w") as f:
        f.write("test")
    # Fail matchpathcon
    assert matchpathcon("test", os.O_RDWR)[0] == -1
    # Success matchpathcon
    assert matchpathcon("test", os.O_RDONLY)[0] == 0
    assert matchpathcon("test", os.O_RDONLY)[1] == "system_u:object_r:svirt_sandbox_file_t:s0:c7,c434"
    # Cleanup
    os.remove("test")

# Generated at 2022-06-22 22:25:58.439810
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # This should be type='targeted'
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-22 22:26:00.230503
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Check if the function selinux_getenforcemode returns a tuple of 2
    '''
    result = selinux_getenforcemode()
    assert type(result) is list
    assert len(result) == 2


# Generated at 2022-06-22 22:26:01.526776
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]


# Generated at 2022-06-22 22:26:03.324863
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        assert selinux_getpolicytype()[0] == 0
    except NotImplementedError:
        pass

# Generated at 2022-06-22 22:26:11.185959
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print("UNIT TEST FOR selinux_getpolicytype WITH TESTING FOR VALID OUTPUT")
    rc, output = selinux_getpolicytype()
    assert rc == 0, "ERROR: The return code was not 0"
    assert isinstance(output, str), "ERROR: The return type is not a string"
    assert output != "", "ERROR: The returned string is empty"
    assert output in ["targeted", "strict"], "ERROR: The returned string is not in the expected contexts"
    print("Unit Test Passed")



# Generated at 2022-06-22 22:26:13.230378
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]


# Generated at 2022-06-22 22:26:17.577783
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/foo'
    mode = 0
    rc = 1
    con = ''
    result = matchpathcon(path, mode)
    if result[0] != rc or result[1] != con:
        raise ValueError('matchpathcon failed to execute correctly')

# Generated at 2022-06-22 22:26:25.241205
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        selinux_enabled = is_selinux_enabled()
    except OSError:
        selinux_enabled = False

    if not selinux_enabled:
        raise AssertionError("SELinux is not enabled. Only run this test in a SELinux enabled environment.")

    [rc, con] = matchpathcon("/etc/pam.d", 0)
    if rc != 0:
        raise AssertionError("Matchpathcon failed to return a context for /etc/pam.d")

    if "etc_t" not in con:
        raise AssertionError("Matchpathcon returned an unexpected context: {0}".format(con))



# Generated at 2022-06-22 22:26:30.400934
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible.module_utils.selinux import lgetfilecon_raw
    from ansible.module_utils._text import to_native
    name = 'file-name'
    context = 'user_u:object_r:unlabeled_t:s0'
    rc, con = lgetfilecon_raw(name)
    assert rc == 0
    assert to_native(con) == context

# Generated at 2022-06-22 22:26:31.421289
# Unit test for function matchpathcon
def test_matchpathcon():
    pass


# Generated at 2022-06-22 22:26:36.278492
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon
    assert matchpathcon('/bin/cat', os.R_OK)[1] == 'system_u:object_r:bin_t:s0'



# Generated at 2022-06-22 22:26:38.694634
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert type(selinux_getenforcemode()[0]) == int
    assert type(selinux_getenforcemode()[1]) == int



# Generated at 2022-06-22 22:26:51.196733
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from subprocess import Popen, PIPE
    import stat

    def get_testfile_con_ctx():
        p = Popen(['ls', '-Zd', '/etc/ansible'], stdout=PIPE, stderr=PIPE)
        stdout, stderr = p.communicate()
        return stdout.decode('utf-8').split()[0]

    testfile_con_ctx = get_testfile_con_ctx()
    rc, con = lgetfilecon_raw('/etc/ansible')
    assert rc >= 0
    assert con == testfile_con_ctx

    testfile_con_ctx = get_testfile_con_ctx()
    rc, con = lgetfilecon_raw('/etc/ansible/')
    assert rc >= 0

# Generated at 2022-06-22 22:26:54.982687
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible_collections.ansible.community.tests.unit.compat.selinux.mock_selinux import MockSelinux, selinux_getenforcemode
    with MockSelinux([selinux_getenforcemode]):
        assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-22 22:27:00.350740
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = os.environ.get('PATH')
    assert isinstance(lgetfilecon_raw(path), list)
    assert isinstance(lgetfilecon_raw(path)[0], int)
    assert isinstance(lgetfilecon_raw(path)[1], str)


# Generated at 2022-06-22 22:27:05.543566
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Unit test for function lgetfilecon_raw."""
    path = '/tmp/'
    [rc, con] = lgetfilecon_raw(path)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t'



# Generated at 2022-06-22 22:27:14.643634
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import platform
    import subprocess
    import sys

    if platform.machine() != 'x86_64':
        print('Not x86_64 platform. Skipping test.')
        sys.exit(0)
    if 'SELinux' not in subprocess.check_output('sestatus').decode('utf-8'):
        print('SELinux not enabled on platform. Skipping test.')
        sys.exit(0)

    if selinux_getenforcemode()[0] != 0:
        print('Non-zero rc returned by selinux_getenforcemode()')
        sys.exit(1)

    print('selinux_getenforcemode() passed.')
    sys.exit(0)



# Generated at 2022-06-22 22:27:16.686656
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert (selinux_getenforcemode() == [0, 2])


# Generated at 2022-06-22 22:27:20.315027
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0
    assert selinux_getpolicytype()[1].startswith('targeted')

# Generated at 2022-06-22 22:27:25.131043
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Tests function matchpathcon
    """

    rc, con = matchpathcon('/', 0)
    if rc < 0:
        raise RuntimeError('Failed to match path: {0}'.format(con))
    else:
        print ('Successfully matched path: {0}'.format(con))


# Generated at 2022-06-22 22:27:29.986597
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = './tests/files/file.txt'
    con = c_char_p()
    try:
        rc = _selinux_lib.lgetfilecon_raw(path, byref(con))
        assert rc == 0, 'lgetfilecon_raw failed'
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-22 22:27:34.513294
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/sys/fs/cgroup/systemd/user.slice', 0)
    assert rc == 0
    assert con == 'system_u:object_r:user_cgroup_t:s0'

# Generated at 2022-06-22 22:27:36.938093
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        _selinux_lib.lgetfilecon_raw(b'/', byref(c_char_p()))
    except AttributeError:
        assert False

# Generated at 2022-06-22 22:27:40.298788
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, enforcemode) = selinux_getpolicytype()
    print("RC: %s - Enforcetype: %s" % (rc, enforcemode))


if __name__ == "__main__":
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:27:43.606546
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Returns [rc, con]
    # rc = 0 if successful
    # con = string containing current policy type
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert isinstance(con, str)



# Generated at 2022-06-22 22:27:51.397695
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import atexit

    tmpdir = "test_selinux_tmp"
    tmpfile = tmpdir + "/test_file"
    if not os.path.exists(tmpdir):
        os.makedirs(tmpdir)

    def teardown():
        if os.path.exists(tmpfile):
            os.remove(tmpfile)
        if os.path.exists(tmpdir):
            os.rmdir(tmpdir)

    atexit.register(teardown)
    f = open(tmpfile, "w")
    f.close()
    print(lgetfilecon_raw(tmpfile))

# Generated at 2022-06-22 22:27:59.801583
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    global selinux_getpolicytype
    global _selinux_lib
    def mock_selinux_getpolicytype(a):
        from ctypes import Structure, c_char_p

        class Data(Structure):
            _fields_ = [
                ('word', c_char_p),
            ]
        data = Data()
        data.word = 'mock'
        a.contents = data
        return 0

    _selinux_lib.selinux_getpolicytype.side_effect = mock_selinux_getpolicytype
    assert selinux_getpolicytype() == [0, 'mock']

# Generated at 2022-06-22 22:28:02.962246
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    for rc, con in selinux_getpolicytype():
        assert rc == 0, "error {0}".format(con)
        assert isinstance(con, str), "unexpected return type {0}".format(type(con))



# Generated at 2022-06-22 22:28:07.154695
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    assert con and isinstance(con, str)


# Generated at 2022-06-22 22:28:10.503604
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    This function tests the selinux_getenforcemode function.
    """
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1)



# Generated at 2022-06-22 22:28:12.986041
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/passwd') == [0, 'system_u:object_r:etc_runtime_t:s0']

# Generated at 2022-06-22 22:28:18.370555
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon("/usr/bin/X11/X", 0) == [0, "system_u:object_r:xserver_exec_t:s0"]
    assert matchpathcon("/usr/bin/X11/X", 1) == [1, None]

# Generated at 2022-06-22 22:28:23.453604
# Unit test for function matchpathcon
def test_matchpathcon():
    '''
    Test case for the matchpathcon function
    '''
    path = '/home/ansible/ansible.cfg'
    mode = 0
    rc, context = matchpathcon(path, mode)

    assert rc == 0
    assert context == 'unconfined_u:object_r:user_home_t:s0'



# Generated at 2022-06-22 22:28:25.756840
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] is not None
    assert isinstance(selinux_getpolicytype()[1], str)



# Generated at 2022-06-22 22:28:28.075283
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc in (0, 1) and enforcemode in (0, 1), "Invalid value"



# Generated at 2022-06-22 22:28:36.746497
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import sys
    # selinux must be enabled on the system to run this unit test
    if not is_selinux_enabled():
        return

    this_file_path = sys.argv[0]
    # lgetfilecon_raw returns a list of two values: the first value is rc and the second one is the context of the file
    rc, context = lgetfilecon_raw(this_file_path)
    assert rc == 0
    assert os.path.isfile(this_file_path)
    assert context is not None
    print(context)



# Generated at 2022-06-22 22:28:48.611498
# Unit test for function lgetfilecon_raw

# Generated at 2022-06-22 22:28:51.009030
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    return selinux_getpolicytype()[-1] == 'targeted'



# Generated at 2022-06-22 22:28:55.113523
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile
    import stat
    import os

    fd, filename = tempfile.mkstemp()
    try:
        st = os.fstat(fd)
        assert matchpathcon(filename, st.st_mode)[1] is not None
    finally:
        os.unlink(filename)

# Generated at 2022-06-22 22:29:01.100710
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Call the function
    results = selinux_getenforcemode()
    # Test to make sure the call succeeded
    assert type(results) == list and results[0] == 0
    # Test to make sure the function returned the correct data
    assert isinstance(results[1], int)



# Generated at 2022-06-22 22:29:02.480811
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert 'targeted' == selinux_getpolicytype()[1]

# Generated at 2022-06-22 22:29:08.109373
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    mode, rc = selinux_getenforcemode()
    if rc != 0:
        raise RuntimeError('could not run selinux_getenforcemode, rc: {0}'.format(rc))
    return mode


if __name__ == '__main__':
    print(test_selinux_getenforcemode())

# Generated at 2022-06-22 22:29:11.259241
# Unit test for function matchpathcon
def test_matchpathcon():

    (rc, con) = matchpathcon('/var/log/httpd/access_log', os.F_OK)
    assert rc == 0
    assert con == 'system_u:object_r:var_log_t:s0'

# Generated at 2022-06-22 22:29:18.538348
# Unit test for function matchpathcon
def test_matchpathcon():

    # Skip checking this function if selinux isn't installed
    if _selinux_lib.security_getenforce() < 0 and _selinux_lib.selinux_getenforcemode() < 0:
        return

    path = '/test'
    mode = 0
    rc, out = matchpathcon(path, mode)
    assert rc == 0, 'rc: {0}'.format(rc)
    assert out is not None, "'out' is None"



# Generated at 2022-06-22 22:29:20.800920
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    from ansible.module_utils.selinux import selinux_getpolicytype

    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-22 22:29:25.050133
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = _selinux_lib.lgetfilecon_raw('/usr/bin/finger', None)

    assert rc == 0
    assert con == b'unconfined_u:object_r:finger_exec_t:s0'


# Generated at 2022-06-22 22:29:26.343457
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode(), list)



# Generated at 2022-06-22 22:29:31.505073
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, selinux_mode = selinux_getpolicytype()
    except Exception:
        selinux_mode = None

    if selinux_mode is not None:
        return True

    return False

# Generated at 2022-06-22 22:29:34.037974
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Return code should be 0
    assert lgetfilecon_raw('/var') == [0, 'system_u:object_r:var_t:s0']

# Generated at 2022-06-22 22:29:36.499938
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    enforcemode = selinux_getenforcemode()
    assert enforcemode[0] == 0


# Generated at 2022-06-22 22:29:39.377540
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    default = selinux_getpolicytype()
    assert default[0] == 0
    assert default[1] == 'targeted'



# Generated at 2022-06-22 22:29:41.763176
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    expected = [0, 2]
    actual = selinux_getenforcemode()
    assert expected == actual


# Generated at 2022-06-22 22:29:47.940297
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Check for existence of the module
    assert hasattr(sys.modules[__name__], 'lgetfilecon_raw')
    # Check that the function returns a list
    assert isinstance(lgetfilecon_raw("/bin/bash"), list)
    # Check that the function returns the code from the __check_rc function
    assert lgetfilecon_raw("/bin/bash")[0] == 0
    # Check that the function returns a string
    assert isinstance(lgetfilecon_raw("/bin/bash")[1], str)



# Generated at 2022-06-22 22:29:51.215505
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/selinux/targeted/contexts/files/file_contexts'
    rc, con = lgetfilecon_raw(path)
    assert rc == 0 and 'system_u:object_r:etc_t:s0' in con

# Generated at 2022-06-22 22:29:57.697141
# Unit test for function matchpathcon
def test_matchpathcon():
    path = b'/usr/lib/foo.so'

    ret, con = matchpathcon(path, os.R_OK)
    assert ret == 0, "Failed to match pathcon: %d" % ret
    assert con == 'system_u:object_r:lib_t:s0', "Invalid context: %s" % con

# Generated at 2022-06-22 22:30:03.231702
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _selinux_lib.selinux_getpolicytype.argtypes = [c_char_p]
    _selinux_lib.selinux_getpolicytype.restype = c_int

    con = c_char_p()
    rc = _selinux_lib.selinux_getpolicytype(byref(con))
    return [rc, to_native(con.value)]

# Generated at 2022-06-22 22:30:06.730613
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """ test_selinux_getenforcemode: test for function selinux_getenforcemode """
    assert selinux_getenforcemode()[1] == 0


# Generated at 2022-06-22 22:30:11.624550
# Unit test for function matchpathcon
def test_matchpathcon():
    sample_path = "/tmp/sample_file"
    sample_mode = os.stat(sample_path).st_mode
    test_con = matchpathcon(sample_path, sample_mode)
    assert 'system_u:object_r:tmp_t:s0' in str(test_con[1]), \
        "matchpathcon returned: " + str(test_con[1]) + " which is wrong"



# Generated at 2022-06-22 22:30:15.239241
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Passed a path to a file then expect a string with selinux context
    # Check if SELinux is enabled, if not no need to continue
    if is_selinux_enabled():
        # Get the context of a file that exist
        test_path = '/tmp'
        [rc, con] = lgetfilecon_raw(test_path)
        assert type(con) == str
    else:
        assert True

# Generated at 2022-06-22 22:30:17.412339
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]

if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-22 22:30:25.271670
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import os
    import sys

    if sys.version_info[0] >= 3 and sys.version_info[1] >= 8 and platform.system() == 'Linux':
        import ctypes
        ctypes.pythonapi.Py_IsInitialized.restype = ctypes.c_int
        ctypes.pythonapi.Py_IsInitialized.argtypes = []
        return ctypes.pythonapi.Py_IsInitialized() != 0

    # TODO: use the actual testable version once python3.8+ is in a supported environment
    return True


# Generated at 2022-06-22 22:30:27.676340
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/issue') == [0, 'system_u:object_r:etc_t:s0']



# Generated at 2022-06-22 22:30:33.124027
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert os.path.exists('/etc/hosts'), ('Missing /etc/hosts file, '
                                          'ensure /etc is mounted')
    rc, con = lgetfilecon_raw('/etc/hosts')
    assert rc == 0, ('Missing SELinux context, '
                     'please set SELINUX=permissive in /etc/selinux/config')
    print(con)

# Generated at 2022-06-22 22:30:36.731379
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        (rc, con) = _selinux_lib.matchpathcon(b'/etc/readme.txt', 0, b'')
        if rc == 0:
            print(con)

        (_, policy_type) = selinux_getpolicytype()
        print(policy_type)

    except Exception as e:
        print(e)


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:30:40.004825
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[1] in [0, 1]
    assert selinux_getenforcemode()[0] == 0


# Generated at 2022-06-22 22:30:44.141914
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, value = matchpathcon('/etc/passwd', 0)
    if rc != 0:
        raise AssertionError('selinux_lib test: matchpathcon failed, rc = %d, value=%s' % (rc, value))



# Generated at 2022-06-22 22:30:49.776134
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    print("test_selinux_getenforcemode rc: " + str(rc) + " mode: " + str(mode))
    assert rc == 0



# Generated at 2022-06-22 22:30:55.164584
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Return value should be a list
    assert isinstance(lgetfilecon_raw('/etc/shadow'), list)
    # Return value should be a tuple
    assert len(lgetfilecon_raw('/etc/shadow')) == 2
    # Return value should be a list of integers
    assert isinstance(lgetfilecon_raw('/etc/shadow')[0], int)
    # Return value should be a list of strings
    assert isinstance(lgetfilecon_raw('/etc/shadow')[1], str)

# Generated at 2022-06-22 22:30:59.290532
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/shadow')[1] is None
    assert lgetfilecon_raw('/var/log/audit')[1] is not None


# Generated at 2022-06-22 22:31:04.105519
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    if rc != 0:
        raise Exception("Error, unable to get policy type - {}".format(policytype))

    print("Policy type is {}".format(policytype))



# Generated at 2022-06-22 22:31:15.347441
# Unit test for function matchpathcon
def test_matchpathcon():

    def fake_freecon():
        pass

    def fake_getfilecon(path):
        if path == '/etc':
            return [0, 'system_u:object_r:etc_t:s0']
        return [-1, '']

    _selinux_lib.freecon.side_effect = fake_freecon
    _selinux_lib.getfilecon.side_effect = fake_getfilecon
    _selinux_lib.matchpathcon.side_effect = None

    assert matchpathcon('/etc/redhat-release', 0) == [0, 'system_u:object_r:etc_t:s0']

    _selinux_lib.freecon.assert_called_once_with(None)

# Generated at 2022-06-22 22:31:18.978986
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc > 0:
        raise RuntimeError('Cannot determine SELinux mode')
    if enforcemode > 1:
        raise ValueError('Invalid SELinux mode')



# Generated at 2022-06-22 22:31:23.008979
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/var/log/audit.log')
    assert rc == 0
    assert con == 'system_u:object_r:auditd_log_t:s0'
    return

# Generated at 2022-06-22 22:31:26.886036
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Dummy test file
    path = '/tmp/test_file'
    # Create dummy test file
    f = open(path, 'a+')
    f.close()
    # Call function lgetfilecon_raw
    result = lgetfilecon_raw(path)
    # Remove dummy test file
    os.remove(path)
    # Return result
    return result


# Generated at 2022-06-22 22:31:27.714999
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]


# Generated at 2022-06-22 22:31:36.381900
# Unit test for function matchpathcon
def test_matchpathcon():
    # First run a command that does not return an error.
    # The second element should be a valid security context.
    rc, con = matchpathcon('/tmp', 0)
    assert rc == 0
    assert con is not None and con != ''

    # Next try a bogus path name
    # The first element should be an error, the second element
    # should be None.
    rc, con = matchpathcon('/someboguspath', 0)
    assert rc > 0 and rc < 2
    assert con is None

    # Now set the context on a path
    # The first element should be success
    rc, con = matchpathcon('/tmp', 0)
    assert rc == 0
    assert con is not None and con != ''

    rc, con = lsetfilecon('/tmp/testdir', con)
    assert rc == 0

# Generated at 2022-06-22 22:31:40.622881
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw(b'/etc/passwd') == [0, b'unconfined_u:object_r:user_home_t:s0']


# Generated at 2022-06-22 22:31:42.910808
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    result = selinux_getenforcemode()
    assert result[0] == 0
    assert isinstance(result[1], int)



# Generated at 2022-06-22 22:31:46.026733
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    assert isinstance(rc, int)
    assert isinstance(mode, int)



# Generated at 2022-06-22 22:31:51.417254
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create simple test file
    with open("/tmp/testfile", "w") as f:
        f.write("This is a test file.")

    # Call lgetfilecon_raw on test file
    rc, con = lgetfilecon_raw("/tmp/testfile")
    if rc != 0:
        raise RuntimeError(con)
    else:
        print(con)

    # Remove test file
    os.remove("/tmp/testfile")

# Generated at 2022-06-22 22:31:56.441581
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()

    # Verify rc is 0
    assert rc == 0, "Expected rc = 0, received rc = %s" % rc

    # Verify con is either "targeted" or "mls"
    assert con == "targeted" or con == "mls", "Expected con = targeted or mls, received con = %s" % con

# Generated at 2022-06-22 22:32:02.372943
# Unit test for function matchpathcon
def test_matchpathcon():
    ''' test the function matchpathcon '''
    path = "/foo"
    mode = 0
    try:
        rc, con = matchpathcon(path, mode)
    except OSError as err:
        print("ERROR:", err)
    else:
        print("rc: ", rc)
        print("con:", con)


# Unit Test for function selinux_getenforcemode

# Generated at 2022-06-22 22:32:04.471680
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in (0, 1, 2)


# Generated at 2022-06-22 22:32:10.543629
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    """
    selinux_getenforcemode function:
    """
    rc , mode = selinux_getenforcemode()
    print("SELinux Enforce mode=%d RC=%d" % (mode, rc))
    if mode == 0:
        print("SELinux is enforcing")
    else:
        print("SELinux is not enforcing")



# Generated at 2022-06-22 22:32:20.100278
# Unit test for function matchpathcon
def test_matchpathcon():
    print("Testing matchpathcon Function...")
    path = "/usr/bin/python3"
    mode = 1 # S_IFREG
    print("Testing matchpathcon Function with path='/usr/bin/python3'")
    [rc, con] = matchpathcon(path, mode)
    if rc < 0:
        raise OSError(rc, os.strerror(rc))
    print("{0} contains context '{1}'".format(path, con))


# Generated at 2022-06-22 22:32:21.448814
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert len(selinux_getenforcemode()) == 2


# Generated at 2022-06-22 22:32:29.093381
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, value) = selinux_getenforcemode()
    if rc != 0:
        print("SELinux is not enabled in this machine")
    else:
        print("SELinux is enabled in this machine")

    if value == 0:
        print("SELinux is in Permissive mode")
    elif value == 1:
        print("SELinux is in Enforcement mode")
    elif value == 2:
        print("SELinux is in Disabled mode")

if __name__ == '__main__':
    test_selinux_getenforcemode()

# Generated at 2022-06-22 22:32:40.331523
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text
    import os
    import sys

    if not os.path.exists('/test/test_matchpathcon'):
        os.mkdir('/test/test_matchpathcon', 0o700)
        os.chmod('/test/test_matchpathcon', 0o700)

    if not os.path.exists('/test/test_matchpathcon/test'):
        os.mkdir('/test/test_matchpathcon/test', 0o700)
        os.chmod('/test/test_matchpathcon/test', 0o700)

    open('/test/test_matchpathcon/test/testfile', 'w').close()
    os.chmod('/test/test_matchpathcon/test/testfile', 0o700)

