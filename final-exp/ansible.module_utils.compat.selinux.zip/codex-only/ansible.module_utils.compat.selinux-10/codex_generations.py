

# Generated at 2022-06-22 22:22:44.399198
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    filepath = os.path.join(tmpdir, "testfile")

    try:
        with open(filepath, "w") as tmpfile:
            tmpfile.write("test")

        print(matchpathcon(filepath, 0o644))
        print(matchpathcon(filepath, 0o400))
        print(matchpathcon(filepath, 0o600))
        print(matchpathcon(filepath, 0o000))
        print(matchpathcon(filepath, 0o700))
    finally:
        os.remove(filepath)
        os.rmdir(tmpdir)


# Generated at 2022-06-22 22:22:51.396441
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # test a file that exists
    rc, con = lgetfilecon_raw('/usr/share/zoneinfo/Canada/Mountain')
    assert rc == 0
    assert con == 'system_u:object_r:usr_t:s0:c10,c837,c904'

    # test a file that does not exist
    rc, con = lgetfilecon_raw('/not/a/real/file')
    assert rc == -1
    assert con is None



# Generated at 2022-06-22 22:22:53.455610
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[1] == 'targeted'

# Unit test function lgetfilecon_raw

# Generated at 2022-06-22 22:22:55.686180
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp'
    rc, con = lgetfilecon_raw(path)
    print("the path is ", path, "and the context is ", con, "with rc=", rc)

# Generated at 2022-06-22 22:22:56.929518
# Unit test for function matchpathcon
def test_matchpathcon():
    # XXX: To be completed
    pass



# Generated at 2022-06-22 22:22:58.405551
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Return code must be equal to 0
    assert selinux_getpolicytype()[0] == 0

# Generated at 2022-06-22 22:23:03.991912
# Unit test for function matchpathcon
def test_matchpathcon():
    test_call = matchpathcon('/etc/', 0)
    assert test_call[0] == 0
    assert test_call[1] == 'unconfined_u:object_r:etc_t:s0'



# Generated at 2022-06-22 22:23:08.205260
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0, f'Unexpected return code: {rc}'
    assert isinstance(enforcemode, int) and enforcemode == 1, f'Unexpected value for enforcemode: {enforcemode}'



# Generated at 2022-06-22 22:23:11.110870
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    if rc < 0:
        raise OSError('unable to determine policy type: {0}'.format(con))
    return rc



# Generated at 2022-06-22 22:23:12.397608
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype() == [0, 'targeted']

# Generated at 2022-06-22 22:23:16.894466
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    '''
    Calling selinux_getenforcemode just returns 0 or 1
    '''
    print("Testing selinux_getenforcemode")
    # If we are in enforcing mode security_getenforce should be 1
    assert selinux_getenforcemode()[1] == 1

    # If we are in permissive mode security_getenforcemode should be 0
    os.environ['SELINUX_INIT'] = 'YES'
    os.environ['SELINUX_BOOTPARAM'] = 'enforcement=0'
    assert selinux_getenforcemode()[1] == 0


# Generated at 2022-06-22 22:23:20.801674
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw('/tmp/')
    assert rc == 0
    assert len(con) > 0
    assert con[:7] == 'system_'

# Generated at 2022-06-22 22:23:26.224912
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """test selinux_getpolicytype"""
    try:
        # selinux not enabled
        module = AnsibleModule(argument_spec={})
        result = selinux_getpolicytype()
        module.fail_json(msg='selinux not enabled')
    except ImportError as err:
        module = AnsibleModule(argument_spec={})
        module.fail_json(msg=str(err))



# Generated at 2022-06-22 22:23:29.160706
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert enforcemode in [0, 1, 2]

# Generated at 2022-06-22 22:23:32.649298
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc < 0:
        raise OSError(rc, os.strerror(rc))
    return [rc, enforcemode]



# Generated at 2022-06-22 22:23:35.553161
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/tmp'
    rc = lgetfilecon_raw(path)
    if rc[0] == 0:
        print(rc[1])
    else:
        print(rc[0])



# Generated at 2022-06-22 22:23:37.760261
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/shadow', 0)
    print('rc: %s, con: %s' % (rc, con))



# Generated at 2022-06-22 22:23:40.622702
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/etc/ansible/ansible.cfg'
    mode = 0o644
    rc, con = matchpathcon(path, mode)
    assert rc >= 0
    assert con == 'system_u:object_r:etc_t'



# Generated at 2022-06-22 22:23:44.928036
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    # Set the return values
    rc = return_value = 0
    enforcemode = 1

    # Call the function
    rc, enforcemode = selinux_getenforcemode()

    return rc, enforcemode



# Generated at 2022-06-22 22:23:55.424468
# Unit test for function matchpathcon
def test_matchpathcon():
    mod = sys.modules[__name__]
    tests = {
        "/tmp/test": "user_tmp_t",
        "/a/b/c/foo.txt": "system_u:object_r:myfile_t",
        "/a/b/c/bar.txt": "system_u:object_r:bar_file_t",
    }
    for path, con in tests.items():
        rc, selinux_con = intermod.matchpathcon(path, 0)
        if rc != 0:
            raise AssertionError('matchpathcon(%s, 0) rc=%d, expected 0' % (path, rc))

# Generated at 2022-06-22 22:23:59.682801
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('Test function selinux_getpolicytype... ', end="")

    rc, policytype = selinux_getpolicytype()
    print('result: {0}; type: {1}'.format(rc, policytype))



# Generated at 2022-06-22 22:24:08.000827
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ansible_collections.ansible.community.plugins.module_utils.selinux import lgetfilecon_raw
    from ansible_collections.ansible.community.plugins.module_utils.selinux import lsetfilecon
    from ansible_collections.ansible.community.plugins.module_utils.selinux import lgetfilecon_raw
    from ansible_collections.ansible.community.plugins.module_utils.selinux import matchpathcon
    from ansible_collections.ansible.community.plugins.module_utils.selinux import selinux_getpolicytype
    from ansible_collections.ansible.community.plugins.module_utils.selinux import selinux_getenforcemode

# Generated at 2022-06-22 22:24:10.793197
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc = selinux_getenforcemode()
    assert rc[0] == 0
    assert rc[1] == 1



# Generated at 2022-06-22 22:24:14.095970
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    results = selinux_getenforcemode()
    assert results[0] == 0 or results[0] == 1
    assert results[1] == 0 or results[1] == 1


# Generated at 2022-06-22 22:24:20.550770
# Unit test for function matchpathcon
def test_matchpathcon():
    import tempfile

    fd, file_name = tempfile.mkstemp()
    try:
        # there was a bug here, where file_name was being converted to bytes
        rc, con = matchpathcon(file_name, 0)
        assert rc >= 0
    finally:
        os.close(fd)
        os.unlink(file_name)

# Generated at 2022-06-22 22:24:23.376966
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, context = lgetfilecon_raw("/var/log")
    print("rc is: {0}  context is: {1}".format(rc, context))


# Generated at 2022-06-22 22:24:28.694525
# Unit test for function matchpathcon
def test_matchpathcon():
    """Test case matchpathcon"""
    (r, con) = matchpathcon("/etc", os.R_OK)
    if r == 0:
        print("/etc: {0}".format(con))
    else:
        print("/etc could not be classified")

if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:24:31.519028
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _test_selinux_getpolicytype_value = selinux_getpolicytype()[1]
    assert _test_selinux_getpolicytype_value in ("targeted", "mls")

# Generated at 2022-06-22 22:24:35.112938
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch.object(_selinux_lib, "matchpathcon", return_value=0) as mocked_matchpathcon:
        rc, con = matchpathcon(b"", 0)
    assert mocked_matchpathcon.call_count == 1

# Generated at 2022-06-22 22:24:43.739445
# Unit test for function matchpathcon
def test_matchpathcon():

    con = c_char_p()
    result = matchpathcon('/etc/hosts', os.R_OK)
    assert result[0] == 0
    assert result[1] == 'system_u:object_r:net_conf_t:s0'
    result = matchpathcon('/etc/hosts', os.W_OK)
    assert result[0] == -1
    assert result[1] == ''
    result = matchpathcon('/etc/hosts', os.R_OK | os.W_OK)
    assert result[0] == -1
    assert result[1] == ''

# Generated at 2022-06-22 22:24:47.260422
# Unit test for function matchpathcon
def test_matchpathcon():
    # os.environ['SELINUX_INIT'] = 'YES'
    # os.environ['SELINUX_COMPILE_DOMAIN'] = 'test'

    rc, msg = matchpathcon('/tmp', os.R_OK)
    assert rc == 0, msg


if __name__ == '__main__':

    test_matchpathcon()
    sys.exit(0)

# Generated at 2022-06-22 22:24:52.917710
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        _selinux_lib.matchpathcon
    except AttributeError:
        raise ImportError('missing selinux function: matchpathcon')

    dev_null = '/dev/null'
    rc, con = matchpathcon(dev_null, os.R_OK)

    if rc != 0:
        raise OSError(rc, 'matchpathcon called against {0} failed'.format(dev_null))



# Generated at 2022-06-22 22:24:57.521152
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert (lgetfilecon_raw('/usr/bin/python') == [0, 'unconfined_u:object_r:usr_t:s0'])
    assert (lgetfilecon_raw('/usr/bin/python3') == [0, 'system_u:object_r:bin_t:s0'])


# Generated at 2022-06-22 22:25:01.367872
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, res = matchpathcon('/etc/sudoers', 0)
    assert res == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-22 22:25:04.428064
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc == 0:
        print('Returned: ', enforcemode)
    else:
        print('Error: ', rc)



# Generated at 2022-06-22 22:25:07.939194
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert 0 == rc
    assert 1 >= enforcemode
    assert 0 <= enforcemode



# Generated at 2022-06-22 22:25:10.236517
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    st = selinux_getenforcemode()
    assert type(st[0]) is int
    assert type(st[1]) is int



# Generated at 2022-06-22 22:25:12.629478
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    [rc, enforcemode] = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode == 1 or enforcemode == 0


# Generated at 2022-06-22 22:25:18.576881
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import os
    import tempfile
    dummy_path = os.path.join(tempfile.gettempdir(), 'ansible_test_file')
    os.open(dummy_path, os.O_CREAT)

    rc, file_cxt = lgetfilecon_raw(dummy_path)
    os.unlink(dummy_path)

    assert rc == 0
    assert type(file_cxt) == str

# Generated at 2022-06-22 22:25:21.240250
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/', os.R_OK)
    assert con == 'system_u:object_r:usr_t:s0'


# Generated at 2022-06-22 22:25:26.156400
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [1, 2, 3], 'unexpected value {0}'.format(enforcemode)



# Generated at 2022-06-22 22:25:29.624979
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    try:
        rc, policytype = selinux_getpolicytype()
        if rc == 0 and policytype == 'targeted':
            print("PASS: SELinux policy is %s" % policytype)
        else:
            print("FAIL: SELinux policy is %s, rc: %d" % (policytype, rc))
    except Exception as e:
        print("FAIL: selinux_getpolicytype() call failed. Exception %s" % e)

if __name__ == "__main__":
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:25:31.972145
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    (rc, enforcemode) = selinux_getenforcemode()
    assert rc == 0 and enforcemode in [0, 1, 2]

# Generated at 2022-06-22 22:25:41.679681
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    Test function matchpathcon

    If non-zero return code, exit with return code.
    If return code is zero, display the context.
    """
    _, enforce = selinux_getenforcemode()
    if enforce == 1:
        try:
            _, policytype = selinux_getpolicytype()
        except OSError as e:
            print(e)
            sys.exit(0)
        if policytype == 'targeted':
            path = '/etc/passwd'
            mode = os.R_OK

# Generated at 2022-06-22 22:25:45.112990
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """Return file context of the path."""
    context = lgetfilecon_raw('/etc/rc.local')[1]
    print('The context of /etc/rc.local is %s' % context)



# Generated at 2022-06-22 22:25:47.247537
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() is not None, 'selinux_getenforcemode is missing'



# Generated at 2022-06-22 22:25:53.396397
# Unit test for function matchpathcon
def test_matchpathcon():
    from os.path import join

    path = join("test", "path", "test_file")
    expected_context = "system_u:object_r:usr_t:s0"

    rc, con = matchpathcon(path, 0)
    if rc != 0:
        raise Exception("matchpathcon failed to return context for " + path)
    if con != expected_context:
        raise Exception("Expected secontext " + expected_context + " but returned " + con)



# Generated at 2022-06-22 22:25:54.956346
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, x = selinux_getpolicytype()
    assert rc == 0

# Generated at 2022-06-22 22:25:59.159625
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode()[0] == 0
    assert isinstance(selinux_getenforcemode()[1], int)



# Generated at 2022-06-22 22:26:00.768189
# Unit test for function matchpathcon
def test_matchpathcon():
    return os.path.exists('/usr/sbin/matchpathcon')

# Generated at 2022-06-22 22:26:05.761739
# Unit test for function matchpathcon
def test_matchpathcon():
    # Example:
    # selinux.matchpathcon("/var/tmp/myfile", 0)
    # =>
    # [0, 'system_u:object_r:var_tmp_t:s0']
    rc, txt = matchpathcon("/var/tmp/myfile", 0)
    print("matchpathcon returns ", rc, txt)



# Generated at 2022-06-22 22:26:15.164130
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from os import getpid, path
    import errno

    if 'test_lgetfilecon_raw' not in sys.modules:
        print('skip - ctypes test_lgetfilecon_raw not supported')
        return

    test_pid = getpid()
    test_path = path.join('/proc', str(test_pid), 'exe')

    if not path.exists(test_path):
        print('skip - /proc test_path not found')
        return

    # should return rc of 0 and not-None on success
    rc, _ = lgetfilecon_raw(test_path)
    if rc != 0:
        print('bad - test_lgetfilecon_raw({0}) = {1}: {2}\n'.format(test_path, rc, errno.errorcode.get(rc)))
       

# Generated at 2022-06-22 22:26:24.569533
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if os.path.exists("/usr/sbin/getenforce"):
        try:
            test_cmd_path = "/usr/sbin/getenforce"
            os.chmod(test_cmd_path, 0o700)
            os.chown(test_cmd_path, 0, 0)
        except OSError:
            pass

    if os.path.exists("/bin/getenforce"):
        try:
            test_cmd_path = "/bin/getenforce"
            os.chmod(test_cmd_path, 0o700)
            os.chown(test_cmd_path, 0, 0)
        except OSError:
            pass


# Generated at 2022-06-22 22:26:27.745036
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/etc/mtab', 0)
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'



# Generated at 2022-06-22 22:26:33.205811
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        from selinux import lgetfilecon
    except ImportError:
        assert lgetfilecon_raw('foo') == (1, None)
    else:
        assert lgetfilecon_raw('foo') == lgetfilecon('foo')



# Generated at 2022-06-22 22:26:37.382420
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import tempfile
    test_file = tempfile.NamedTemporaryFile(delete=False).name
    rc, con = lgetfilecon_raw(test_file)
    # FIXME: we should be able to actually test this properly
    assert rc == 0



# Generated at 2022-06-22 22:26:49.955110
# Unit test for function matchpathcon
def test_matchpathcon():

    # Create empty file
    fd = os.open('/tmp/foo', os.O_CREAT | os.O_WRONLY, 0o666)
    os.write(fd, to_bytes('bar'))
    os.close(fd)
    os.chmod('/tmp/foo', 0o777)

    # Call matchpathcon
    path = to_bytes('/tmp/foo')
    [rc, con] = matchpathcon(path, os.R_OK)

    # Check that the function returned successfully
    assert rc == 0

    # Check the permission context
    assert con == 'system_u:object_r:user_tmp_t:s0'

    # Delete the file
    os.remove('/tmp/foo')

    print('SUCCESS: matchpathcon unit test completed')



# Generated at 2022-06-22 22:26:52.325782
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/etc/passwd'
    rc, con = lgetfilecon_raw(path)
    assert con == 'system_u:object_r:etc_t:s0'

# Generated at 2022-06-22 22:26:59.416050
# Unit test for function matchpathcon
def test_matchpathcon():
    """Unit test for function matchpathcon"""
    def _mkdir(dirname):
        try:
            os.mkdir(dirname)
        except OSError:
            pass

    # get the path to a writable directory
    for dirname in ['/tmp', '/var/tmp']:
        if os.path.isdir(dirname) and os.access(dirname, os.W_OK):
            break

    # create a dummy file to test against
    _mkdir(os.path.join(dirname, 'foo'))
    test_file = os.path.join(dirname, 'foo', 'bar')
    test_file_handle = open(test_file, 'w')
    test_file_handle.close()

    # get the context for the test file
    rc, context = lgetfilecon

# Generated at 2022-06-22 22:27:05.187112
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    assert lgetfilecon_raw('/etc/selinux/config')[1] == 'etc_t:etc_t'
    assert lgetfilecon_raw('/etc/selinux/targeted/modules/active/file_contexts')[1] == 'etc_t:etc_t'

# Generated at 2022-06-22 22:27:15.031857
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    from ctypes import create_string_buffer
    from tempfile import mktemp
    from os.path import exists, isdir, islink
    from subprocess import call
    from shutil import rmtree

    # create a temporary directory
    tmpdir = mktemp(prefix='selinux-')
    if not exists(tmpdir):
        raise OSError('cannot create temporary directory "{0}"'.format(tmpdir))
    call(["chcon", "-t", "user_home_dir_t", tmpdir])
    is_selinux_enabled = True
    if not is_selinux_enabled:
        raise AssertionError('is_selinux_enabled() returned False')
    if not isdir(tmpdir):
        raise AssertionError('{0} is not a directory'.format(tmpdir))
   

# Generated at 2022-06-22 22:27:18.011458
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    print(rc)
    print(con)

if __name__ == '__main__':
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:27:27.110389
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    import os
    import sys

    rc, mode = selinux_getenforcemode()

    if rc < 0:
        if mode == -1:
            if os.path.exists('/proc/filesystems'):
                with open('/proc/filesystems', 'r') as fh:
                    data = fh.read()
                    if 'selinuxfs' not in data:
                        print('FAILED AS EXPECTED')
                        sys.exit(0)

        sys.exit(1)
    else:
        sys.exit(0)



# Generated at 2022-06-22 22:27:29.764952
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    Basic test that should return success code with the policy
    """
    code, policy = selinux_getpolicytype()
    assert code == 0
    assert isinstance(policy, str)

# Generated at 2022-06-22 22:27:32.424818
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    assert selinux_getpolicytype()[0] == 0
    assert selinux_getpolicytype()[1] == 'targeted'

# Generated at 2022-06-22 22:27:35.408371
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw('/etc/host.conf')
    assert rc == 0
    assert con == 'system_u:object_r:etc_t:s0'


# Generated at 2022-06-22 22:27:39.037934
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, policy_type) = selinux_getpolicytype()
    if rc == 0:
        return {'failed': False, 'message': 'policy_type: {0}'.format(policy_type)}
    else:
        return {'failed': True, 'message': 'Failed to get policy type'}

# Generated at 2022-06-22 22:27:50.084764
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    """
    Verify that the lgetfilecon_raw function:

    * returns two values
    * returns a list
    * returns the first value of the list as an integer

    Also verify that:

    * the function returns two values with the first value -1 on failure
    * the function returns two values with the first value 0 on success
    * the second value of the list is a string on success
    * the second value of the list is None on failure
    """
    import inspect

    args = inspect.getargspec(lgetfilecon_raw)

    assert args.args == ['path']
    assert args.varargs is None
    assert args.keywords is None
    assert args.defaults is None

    assert isinstance(lgetfilecon_raw('/'), list)

# Generated at 2022-06-22 22:27:51.572833
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    lgetfilecon_raw("/usr")



# Generated at 2022-06-22 22:27:55.160825
# Unit test for function matchpathcon
def test_matchpathcon():
    path = os.path.abspath(__file__)
    mode = 1
    rc, con = matchpathcon(path, mode)
    assert rc == 0

# Generated at 2022-06-22 22:28:01.432236
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # This is a test wrapper function to verify the return value of selinux_getpolicytype
    def test_selinux_getpolicytype():
        A = selinux_getpolicytype()
        # Check if the first return value is 0
        assert (A[0] == 0)
        # If yes, check if the policy type is targeted
        if (A[0] == 0):
            assert (A[1] == 'targeted')
    test_selinux_getpolicytype()

# Generated at 2022-06-22 22:28:13.533907
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import BytesIO

    for path in (b'/', b'/etc/pwd.db', b'/etc/group', b'/usr/bin/id'):
        rc, context = matchpathcon(path, 0)
        assert rc == 0
        assert to_text(context, errors='surrogate_or_strict') == u"system_u:object_r:etc_runtime_t:s0"

    test_path = b'/tmp/ansible-test-file'

# Generated at 2022-06-22 22:28:18.471601
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    if selinux_getpolicytype()[1] == 'targeted':
        path = '/etc/shadow'
        [rc, con] = lgetfilecon_raw(path)
        if rc != 0:
            modul

# Generated at 2022-06-22 22:28:24.309535
# Unit test for function matchpathcon
def test_matchpathcon():
    [rc, con] = matchpathcon('/tmp', 0)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    [rc, con] = matchpathcon('/tmp', 0o777)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

    [rc, con] = matchpathcon('/tmp/foo', 0o777)
    assert rc == 0
    assert con == 'system_u:object_r:tmp_t:s0'

# Generated at 2022-06-22 22:28:28.022376
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    from ansible.module_utils.facts import selinux
    rc, mode = selinux.selinux_getenforcemode()
    assert rc >= 0
    assert mode in [0, 1, 2]



# Generated at 2022-06-22 22:28:36.744041
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    r = lgetfilecon_raw('/etc/fstab')
    if isinstance(r[1], int):
        st = 'converter failed: {}'.format(r[1])
        raise AssertionError(st)
    if r[1] == 'system_u:object_r:etc_t:s0':
        raise AssertionError('SELinux not enabled')
    else:
        raise AssertionError('SELinux enabled')


if __name__ == '__main__':
    test_lgetfilecon_raw()

# Generated at 2022-06-22 22:28:40.969981
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    if rc == 0:
        return [enforcemode]
    else:
        raise OSError(rc, os.strerror(rc))


# Generated at 2022-06-22 22:28:46.411314
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Verify that we get back the expected context for a known file
    rc, con = lgetfilecon_raw('/sys/fs/selinux')
    assert rc == 0
    assert con in ('system_u:object_r:selinuxfs:s0', 'system_u:object_r:admin_home_t:s0')

# Generated at 2022-06-22 22:28:56.462056
# Unit test for function matchpathcon
def test_matchpathcon():
    """
    This function must be run as root (otherwise it will not have the permissions to create the files and directories.

    You must have "type_transition" enabled in the selinux policy in order to run this test.

    The directories and files will be created in the current working directory.
    """
    import shutil

    # First create a directory
    try:
        os.mkdir("testdir")
    except OSError:
        print("Failed to create 'testdir' directory")

    # Set the mode and default context of 'testdir' to what we expect
    rc = lsetfilecon("testdir", "system_u:object_r:usr_t:s0")
    if rc[0] != 0:
        raise Exception("Failed to set security context of 'testdir'")

    # Get the mode and default context

# Generated at 2022-06-22 22:28:58.915763
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 2]

# Same as above, but return code is optional

# Generated at 2022-06-22 22:29:05.478122
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if not isinstance(_selinux_lib, CDLL):
        raise ImportError('unable to load libselinux.so')

    # test return values for selinux_getenforcemode
    [rc, val] = selinux_getenforcemode()
    if rc == 0:
        if val in (-1, 0, 1):
            assert True
        else:
            raise AssertionError(
                'selinux_getenforcemode returned unexpected value {}'.format(val)
            )
    else:
        assert False



# Generated at 2022-06-22 22:29:10.860121
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    assert rc == 0, "selinux_getpolicytype failed"
    assert policytype is not None, "selinux_getpolicytype didn't return expected value"
    assert isinstance(policytype, str), "selinux_getpolicytype didn't return string"



# Generated at 2022-06-22 22:29:22.018763
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import os
    import tempfile
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes, to_text

    # haproxy does not like running as root
    if os.getuid() == 0:
        return "SKIP"

    # Don't run these tests if SELinux is not running or if it is running in
    # disabled mode
    if not is_selinux_enabled():
        return "SKIP"
    if security_getenforce() == 0:
        return "SKIP"

    import haproxy
    haproxy_path = haproxy.get_exec_path()
    if haproxy_path is None:
        return "SKIP"

    haproxy_context = 'haproxy_t'
    haproxy_setcon = '{0}:{1}'.format

# Generated at 2022-06-22 22:29:25.705432
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    [rc, selinuxcon] = lgetfilecon_raw('/var/log')
    if rc > 0:
        return rc
    print('Selinux context of /var/log is %s' % selinuxcon)
    return rc



# Generated at 2022-06-22 22:29:29.026219
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    print('selinux_getpolicytype:')
    [rc, policytype] = selinux_getpolicytype()
    print('\treturn value: %s' % rc)
    print('\tpolicy: %s' % policytype)



# Generated at 2022-06-22 22:29:38.033925
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    import filecmp
    import tempfile

    from ansible.module_utils.selinux.selinux import lgetfilecon_raw
    from ansible.module_utils.common.text.converters import to_bytes

    fd, path = tempfile.mkstemp(prefix='ansible_test_selinux_')
    os.close(fd)

# Generated at 2022-06-22 22:29:47.596104
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible_collections.ansible.community.plugins.module_utils.selinux import matchpathcon
    from os.path import abspath
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import close, rmdir, unlink, mkdir, access, W_OK, R_OK
    from os import chmod
    from pwd import getpwnam
    from grp import getgrnam

    # Create a temporary directory
    tmpdir = mkdtemp()
    tmpdir = abspath(tmpdir)

    # Change to that directory
    cwd = os.getcwd()
    os.chdir(tmpdir)

    # Create a file
    (fd, tmppath) = os.mkstemp()
    os.close(fd)

    # Create a (temporary

# Generated at 2022-06-22 22:29:48.892476
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 1]



# Generated at 2022-06-22 22:29:54.291245
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con = lgetfilecon_raw(b'/tmp')
    assert rc == 0
    assert 'system_u:object_r:tmp_t:s0' in con, 'unexpected context returned: %s' % con


# Generated at 2022-06-22 22:29:58.019834
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/etc/resolv.conf"
    rc, con = lgetfilecon_raw(path)
    print(rc, con)
#

# Generated at 2022-06-22 22:30:01.180173
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    res = lgetfilecon_raw('/dev/null')
    assert res[0] == 0
    assert res[1] == 'system_u:object_r:chr_file:s0'


# Generated at 2022-06-22 22:30:02.994799
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    return lgetfilecon_raw("/etc/dummy")



# Generated at 2022-06-22 22:30:06.001359
# Unit test for function matchpathcon
def test_matchpathcon():
    rc, con = matchpathcon('/proc/self/cwd/foo', 0)
    assert rc == 0
    assert isinstance(con, str)

# Generated at 2022-06-22 22:30:07.079538
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = '/usr/bin/passwd'
    assert isinstance(lgetfilecon_raw(path)[1], str)



# Generated at 2022-06-22 22:30:10.345241
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    [rc, con] = selinux_getpolicytype()
    assert rc == 0
    assert con == 'default'



# Generated at 2022-06-22 22:30:15.941183
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    try:
        if os.getenv('SELINUX_MODE') in ('enforcing', 'permissive'):
            result = lgetfilecon_raw('/etc/passwd')
            assert result[0] == 0
            assert to_native(result[1]).startswith('unconfined_u')
        else:
            assert True
    except OSError:
        assert False


# Generated at 2022-06-22 22:30:20.767878
# Unit test for function matchpathcon
def test_matchpathcon():
    path = '/'
    mode = os.stat(path).st_mode
    [rc, con] = matchpathcon(path, mode)
    assert rc == 0
    assert con == b'system_u:object_r:root_t:s0'


if __name__ == '__main__':
    test_matchpathcon()

# Generated at 2022-06-22 22:30:26.771473
# Unit test for function matchpathcon
def test_matchpathcon():
    assert matchpathcon('/etc/passwd', 0) == [0, b'user_home_t']
    assert matchpathcon('/linux', 0) == [0, b'dir_t']
    assert matchpathcon('/linux/nonexistent', 0) == [0, b'dir_t']
    assert matchpathcon('/dev/null', 0) == [0, b'chr_file_t']


# Generated at 2022-06-22 22:30:29.283664
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    rc, con_value = lgetfilecon_raw(b'/')
    assert rc == 0
    assert con_value is not None



# Generated at 2022-06-22 22:30:35.757407
# Unit test for function matchpathcon
def test_matchpathcon():
    from ansible.module_utils.selinux import matchpathcon

    # NB: this one is easy
    assert matchpathcon('/var/www/', 0) == [0, 'system_u:object_r:httpd_sys_content_t:s0']

    # NB: ensure standard errno rules are being obeyed
    assert matchpathcon('/var/www/foo', 0) == [-1, '/var/www/foo: No such file or directory']

    assert matchpathcon('/var/www', -1) == [-22, 'Invalid argument']

# Generated at 2022-06-22 22:30:41.919807
# Unit test for function matchpathcon
def test_matchpathcon():
    import os
    test_path = "/tmp/test_" + os.urandom(4).hex()
    os.mkdir(test_path)

    rc, con = matchpathcon(test_path, os.F_OK)
    assert rc == 0

    os.rmdir(test_path)

# Generated at 2022-06-22 22:30:46.242880
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, policytype = selinux_getpolicytype()
    try:
        assert rc == 0
        assert policytype == 'targeted'
    except AssertionError:
        errmsg = "selinux_getpolicytype returned unexpected values:" \
                 "rc={rc}\npolicytype={policytype}".format(rc=rc, policytype=policytype)
        raise AssertionError(errmsg)


# Generated at 2022-06-22 22:30:48.305803
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    """
    This function tests the function selinux_getpolicytype.
    """
    policy_type = selinux_getpolicytype()[1]
    print(policy_type)

# Generated at 2022-06-22 22:30:53.113552
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, mode = selinux_getenforcemode()
    if rc < 0:
        raise OSError(get_errno(), os.strerror(get_errno()))
    if mode < 0 or mode > 2:
        raise ValueError('mode {0} must be 0, 1 or 2'.format(mode))
    return rc, mode


# Generated at 2022-06-22 22:31:01.344511
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    c_int_value = c_int()
    c_int_value.value = 0
    assert c_int_value.value == 0
    c_int_value.value = 1
    assert c_int_value.value == 1

    enforcemode = c_int()
    rc = _selinux_lib.selinux_getenforcemode(byref(enforcemode))
    assert rc == 0
    assert enforcemode.value in [0, 1, 2]


# Generated at 2022-06-22 22:31:06.777598
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, value = selinux_getenforcemode()
    if rc == 0:
        assert value in [0, 1, 2], 'unexpected value for selinux_getenforcemode'
    else:
        assert rc == -1 and value == 0, 'unexpected value for selinux_getenforcemode'



# Generated at 2022-06-22 22:31:16.060055
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Test an existing file
    [rc, output] = lgetfilecon_raw('/etc/passwd')
    assert rc == 0
    assert output == "system_u:object_r:etc_runtime_t:s0"
    # Test a non-existent file
    [rc, output] = lgetfilecon_raw('/etc/passwd_not_exist')
    assert rc == -1
    # Test a directory
    [rc, output] = lgetfilecon_raw('/etc/')
    assert rc == 0
    assert output == "system_u:object_r:etc_t:s0"


# Generated at 2022-06-22 22:31:18.926638
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    test_file = "/usr/lib/selinux/mcs/mcs.init"
    assert lgetfilecon_raw(test_file)[1] is not None

# Generated at 2022-06-22 22:31:21.300535
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, output) = selinux_getpolicytype()
    assert rc == 0
    assert output != None
    assert type(output) is str


# Generated at 2022-06-22 22:31:25.250453
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    import json
    import platform

    from ansible_collections.ansible.community.tests.unit import module_utils

    if not module_utils.HAVE_CTYPES or platform.system() == "Windows":
        return (False, None)

    rc, con = selinux_getpolicytype()

    return (rc == 0, json.dumps(con))

# Generated at 2022-06-22 22:31:31.568680
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    if is_selinux_enabled():
        rc, value = selinux_getenforcemode()
        if rc == 0:
            if value < 1:
                print("SELinux status is disabled")
            else:
                print("SELinux status is enabled")
        else:
            print("Failed to get SELinux status")
    else:
        print("SELinux is not supported on this system.")



# Generated at 2022-06-22 22:31:32.747257
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert isinstance(selinux_getenforcemode(), list)



# Generated at 2022-06-22 22:31:35.289071
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    (rc, con) = selinux_getpolicytype()
    assert rc == 0
    assert con == 'targeted'



# Generated at 2022-06-22 22:31:43.536665
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    # Test "selinux_getpolicytype()"
    #
    # This is just a sanity test to ensure ctypes are successfully loading
    # the library and calling the function.
    #
    # The actual behavior of selinux_getpolicytype() is tested by the
    # unit tests for ansible.module_utils.selinux
    rc, policy = selinux_getpolicytype()
    assert isinstance(policy, str)
    assert policy in ('targeted', 'minimum', 'mls')

# Generated at 2022-06-22 22:31:52.626648
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    path = "/tmp/selinux-test"
    ret, con = lgetfilecon_raw(path)
    assert ret == 0
    assert con == "system_u:object_r:unlabeled_t:s0"

    ret, con = lgetfilecon_raw("/usr/bin/hostname")
    assert ret == 0
    assert con == "system_u:object_r:bin_t:s0"
    assert lgetfilecon_raw("/run/addtest")[0] == -2
    assert lgetfilecon_raw("/run/nosuchfile")[0] == -1
    assert lgetfilecon_raw("/run/nosuchfile")[1] == "Permission denied"

# Generated at 2022-06-22 22:31:54.990216
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    data1 = selinux_getenforcemode()
    assert data1[0] >= 0
    assert data1[1] in [0, 1, 2]

# Generated at 2022-06-22 22:32:01.335847
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    (rc, con) = lgetfilecon_raw("/etc/passwd")
    if rc < 0:
        if rc != -1:
            print("error calling lgetfilecon_raw: %s" % os.strerror(rc))
            exit(1)
        else:
            exit(0)

    print(con)
    exit(0)



# Generated at 2022-06-22 22:32:06.711091
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    _selinux_lib = CDLL('libselinux.so.1', use_errno=True)
    con = c_char_p()
    try:
        rc = _selinux_lib.selinux_getpolicytype(byref(con))
        assert rc == 0
        assert to_native(con.value) == "targeted"
    finally:
        _selinux_lib.freecon(con)

# Generated at 2022-06-22 22:32:12.484325
# Unit test for function matchpathcon
def test_matchpathcon():
    try:
        assert matchpathcon('/tmp', 0) == [0, 'system_u:object_r:tmp_t:s0']
        assert matchpathcon('/tmp/foo', 0) == [0, 'system_u:object_r:tmp_t:s0']
    except (OSError, NotImplementedError):
        pass

# Generated at 2022-06-22 22:32:22.707835
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # Create a temporary file
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()

    # Check if a SELinux function exists for getting a file context
    if not hasattr(_selinux_lib, 'lgetfilecon_raw'):
        raise ImportError('missing selinux function: lgetfilecon_raw')

    con = c_char_p()
    rc = _selinux_lib.lgetfilecon_raw(temp_file.name, byref(con))

    if rc < 0:
        print("Error in lgetfilecon_raw")
        return False

    # Delete the temporary file
    temp_file.close()

    return True

# Generated at 2022-06-22 22:32:25.567095
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    expected_return = [0, "targeted"]
    actual_return = selinux_getpolicytype()
    assert expected_return == actual_return



# Generated at 2022-06-22 22:32:27.678132
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    rc, enforcemode = selinux_getenforcemode()
    assert rc == 0
    assert enforcemode in [0, 1, 2]



# Generated at 2022-06-22 22:32:28.870036
# Unit test for function selinux_getenforcemode
def test_selinux_getenforcemode():
    assert selinux_getenforcemode() == [0, 0]


# Generated at 2022-06-22 22:32:30.450740
# Unit test for function selinux_getpolicytype
def test_selinux_getpolicytype():
    rc, con = selinux_getpolicytype()
    assert rc == 0
    print("SELinux Policy Type: " + con)

# Generated at 2022-06-22 22:32:40.922619
# Unit test for function lgetfilecon_raw
def test_lgetfilecon_raw():
    # noinspection PyUnresolvedReferences
    """
    Pytest unit test for lgetfilecon_raw()
    Returns:
        None: module prints test results to stdout

    Raises:
        No exceptions expected

    """
    # pylint: disable=unused-argument
    def _test_module(module):
        # pylint: disable=global-statement
        global _selinux_lib

        # create test file
        (test_file_fd, test_file) = os.pipe()

        rc, _ = lgetfilecon_raw(test_file)
        assert rc != -1

        os.close(test_file_fd)

        return module.exit_json(changed=False)

    import pytest
